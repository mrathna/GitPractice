/*
Added by Ayub on 25.06.2018
 */
package com.framework.pages.SHELL;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.ExtentTest;
import com.framework.basepage.BasePage;
import com.framework.repo.Locator;

public class SHELLReportsPage extends BasePage {

	// Adeed by Ayub on 23.06.2018
	@FindBy(id = Locator.STORED_REPORTS_TYPE)
	public WebElement storedReportsType;

	@FindBy(id = Locator.CREATE_DATE_FROM)
	public WebElement createdDateFrom;

	@FindBy(id = Locator.CREATE_DATE_TO)
	public WebElement createdDateTo;

	@FindBy(id = Locator.SEARCH_CARDS)
	public WebElement searchCard;

	@FindBy(id = Locator.STORED_REPORTS_EXPORT_OPTION)
	public WebElement exportReports;

	@FindBy(id = Locator.SCHEDULED_REPORT)
	public WebElement scheduledReport;

	@FindBy(xpath = Locator.SELECT_REPORT_TYPE_FROM_SCHEDULED_REPORT_PAGE)
	public WebElement reportType;

	@FindBy(xpath = Locator.SELECT_FREQUENCY_FROM_SCHEDULED_REPORT_PAGE)
	public WebElement frequency;

	@FindBy(how = How.ID, using = Locator.TRANSACTION_LIST_TABLE)
	public WebElement transactionListPage;

	@FindBy(how = How.ID, using = Locator.REPORTS_SEARCH)
	public WebElement reportsSearch;

	@FindBy(how = How.ID, using = Locator.SCHEDULE_REPORT_EXPORT_BUTTON)
	public WebElement exportScheduleReports;	

	@FindBy(how = How.XPATH, using = Locator.ADHOC_AVALIABLE_REPORT)
	public WebElement adhocAvaliableReport;

	@FindBy(how = How.ID, using = Locator.REPORT_PARAM_EMAIL_ADDRESS)
	public WebElement emailAddress;	

	@FindBy(how = How.ID, using = Locator.REPORT_GENERATE)
	public WebElement reportGenerate;


	@FindBy(how = How.ID, using = Locator.BACK_TO_ADHOC_REPORT_LINK)
	public WebElement backToAdhocReportsPage;	


	@FindBy(how = How.ID, using = Locator.ADHOC_REPORTS_EXPORT)
	public WebElement exportAdhocReports;

	// Added by Ayub on 26.06.2018
	@FindBy(how = How.ID, using = Locator.ADD_SCHEDULE_REPORT_BUTTON)
	public WebElement addScheduleReportButton;

	@FindBy(how = How.ID, using = Locator.SCHEDULE_REPORT_TYPE)
	public WebElement scheduleReporType;

	@FindBy(how = How.XPATH, using = Locator.SCHEDULE_FREQUENCY_DROPDOWN)
	public WebElement frequenceyDrop;

	@FindBy(how = How.XPATH, using = Locator.SCHEDULE_DELIVERY_TYPE)
	public WebElement deliveryType;

	@FindBy(how = How.ID, using = Locator.EMAIL_FIELD)
	public WebElement emailfield;

	@FindBy(how = How.ID, using = Locator.SCHEDULE_SAVE_BUTTON)
	public WebElement scheduleSaveBtn;	

	// Added by Ayub on 28.06.2018 

	@FindBy(how = How.ID, using = Locator.CLICK_HERE_INVOICE_LINK)
	public WebElement clickHereLink;

	public SHELLReportsPage(WebDriver driver, ExtentTest test) {
		super(driver, test);
		PageFactory.initElements(driver, this);
		// TODO Auto-generated constructor stub
	}

	public void validateExportStoredReports() {
		checkTextInPageAndValidate("STORED REPORTS", 20);
		//selectDropDownByIndex(storedReportsType, 1);
		sleep(2);
		isDisplayedThenEnterText(createdDateFrom, "From Date", "11/09/2016");
		sleep(2);
		isDisplayedThenEnterText(createdDateTo, "To Date", "01/11/2016");
		isDisplayedThenActionClick(searchCard, "Search Button");
		sleep(2);
		isDisplayedThenClick(exportReports, "Export Reports");
	}

	public void validateBlankFieldwithDateRangeStoredReports() {
		checkTextInPageAndValidate("STORED REPORTS", 20);
		isDisplayedThenEnterText(createdDateFrom, "From Date", "11/09/2016");
		sleep(2);
		isDisplayedThenEnterText(createdDateTo, "To Date", "01/11/2016");
		sleep(2);
		isDisplayedThenActionClick(searchCard, "Search Button");
		sleep(2);
		isDisplayedThenClick(exportReports, "Export Reports");
		sleep(3);
	}
	public void validateBlankFieldStoredReports() {
		checkTextInPageAndValidate("STORED REPORTS", 20);
		isDisplayedThenActionClick(searchCard, "Search Button");
		sleep(2);
		isDisplayedThenClick(exportReports, "Export Reports");
		sleep(2);
	}

	public void selectReportTypaNDFrequency() {
		selectDropDownByIndex(reportType, 1);
		sleep(2);
		selectDropDownByIndex(frequency,1);
		sleep(2);
		isDisplayedThenActionClick(reportsSearch, "Search button");


	}

	public boolean validateTheSearchResults()
	{		 

		boolean isNoScheduledReportFound = waitForTextToAppear("No scheduled report found.", 30);	

		System.out.println("isNoTransactionFound"+isNoScheduledReportFound);

		if(isNoScheduledReportFound)
		{
			logInfo("No transactions found for the search filter provided - It depends on IFCS desktop");
		}
		else
		{
			isDisplayed(transactionListPage, "Transaction List displayed");
		}

		return isNoScheduledReportFound;
	}

	public void exportScheduleReports() {

		isDisplayedThenActionClick(exportScheduleReports, "Export Reports");

	}

	public void validateGenerateReports() {
		isDisplayedThenActionClick(adhocAvaliableReport, "Adhoc reports");
		sleep(2);
		// Executing person's email address need to be added here
		isDisplayedThenEnterText(emailAddress,"email Address", "sasikumar.manikandan@wexinc.com");
		isDisplayedThenClick(reportGenerate, "Generate Button");
		sleep(2);
		isDisplayedThenActionClick(backToAdhocReportsPage, "Back to Adhoc Reports Page");
	}

	// Added by Ayub on 26.06.2018
	public void validateExportReportsAndToolTip() {
		isDisplayedThenActionClick(exportAdhocReports, "Export Adhoc Reports");
		// Create action class object
		Actions builder = new Actions(driver);

		// find the tooltip xpath
		WebElement username_tooltip = driver
				.findElement(By.xpath("//div[contains(@id,'lform:avaliableReport')]//div[contains(@id,'content')]"));

		// Mouse hover to that text message
		builder.moveToElement(username_tooltip).perform();

		// Extract text from tooltip
		String tooltip_msg = username_tooltip.getText();

		// Print the tooltip message just for our refrences
		System.out.println("Tooltip/ Help message is " + tooltip_msg);
	}
	// Added by Ayub on 26.06.2018

	public void validateAddscheduleRepotsPage() {
		isDisplayedThenActionClick(addScheduleReportButton, "Schedule Report Button");
		sleep(2);
		selectDropDownByIndex(scheduleReporType, 1);
		sleep(2);
		selectDropDownByIndex(frequenceyDrop, 0);
		sleep(2);
		selectDropDownByIndex(deliveryType, 1);
		sleep(2);
		// Executing person's mail address need to be added here
		isDisplayedThenEnterText(emailfield, "Email ", "sasikumar.manikandan@wexinc.com");
		sleep(2);
		isDisplayedThenClick(scheduleSaveBtn, " Save button");	
		sleep(5);

	}
	public void validateClickHerePage() {
		isDisplayedThenClick(clickHereLink, "Click Here Link");
		sleep(5);
	}

	public void invoiceSearch() {
		isDisplayedThenClick(searchCard, "Search");	
		sleep(5);
		boolean searchResult = waitForTextToAppear("No Stored Reports Found",30);
		if(!searchResult) {			
			isDisplayedThenClick(exportReports, "Export");	
		} else {
			logInfo("No Stored Reports");
		}
	}


}
