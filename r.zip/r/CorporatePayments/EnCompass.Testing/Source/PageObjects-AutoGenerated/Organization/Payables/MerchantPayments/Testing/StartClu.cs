using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using Common;
using Common.PageObjects;
using Common.ScenarioConfigurations;
using Common.Utility;

namespace EnCompass.Testing.Source.PageObjects.Organization.Payables.MerchantPayments.Testing 
{
	/// <summary>
	/// Auto-generated Page Model Class
	/// Navigation Paths: 
		/// [Organization Home]->Payables->Accounts Payable->Start CLU or ECLU
		/// [Organization Home]->Reports->Report Wizard->Step 1: Select Your Focus
		/// [Organization Home]->Reports->Report Wizard->Step 2: Select Your Fields
		/// [Organization Home]->Reports->Report Wizard->Step 3: Group Your Fields
		/// [Organization Home]->Reports->Report Wizard->Step 4: Apply Filters
		/// [Organization Home]->Reports->Report Wizard->Step 5: Format Your Report
		/// [Organization Home]->Reports->Report Wizard->Step 6: Run Your Report
		/// </summary>
	[PageModel(@"/payables/merchantPayments/Testing/StartCLU.aspx")]
	public partial class StartClu : EnCompassOrgPageModel 
	{
		public override string RelativeUrl => @"/payables/merchantPayments/Testing/StartCLU.aspx";
		public override string PageIdentifierXPath_Generated => @"//li[contains(@class, 'breadcrumb-item active')][]";

		#region Navigation
				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Merchant Logs']")]
		private IWebElement _payables_AccountsPayable_StartCluOrEclu_MerchantLogs { get; set; }
		public void NavigateTo_Payables_AccountsPayable_StartCluOrEclu_MerchantLogs()
		{
			NavigateToMenuItem(_payables_AccountsPayable_StartCluOrEclu_MerchantLogs);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Create Merchant Log']")]
		private IWebElement _payables_AccountsPayable_StartCluOrEclu_CreateMerchantLog { get; set; }
		public void NavigateTo_Payables_AccountsPayable_StartCluOrEclu_CreateMerchantLog()
		{
			NavigateToMenuItem(_payables_AccountsPayable_StartCluOrEclu_CreateMerchantLog);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Merchant Log Reconciliation']")]
		private IWebElement _payables_AccountsPayable_StartCluOrEclu_MerchantLogReconciliation { get; set; }
		public void NavigateTo_Payables_AccountsPayable_StartCluOrEclu_MerchantLogReconciliation()
		{
			NavigateToMenuItem(_payables_AccountsPayable_StartCluOrEclu_MerchantLogReconciliation);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Merchant Log Settings']")]
		private IWebElement _payables_AccountsPayable_StartCluOrEclu_MerchantLogSettings { get; set; }
		public void NavigateTo_Payables_AccountsPayable_StartCluOrEclu_MerchantLogSettings()
		{
			NavigateToMenuItem(_payables_AccountsPayable_StartCluOrEclu_MerchantLogSettings);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Disputes']")]
		private IWebElement _payables_AccountsPayable_StartCluOrEclu_Disputes { get; set; }
		public void NavigateTo_Payables_AccountsPayable_StartCluOrEclu_Disputes()
		{
			NavigateToMenuItem(_payables_AccountsPayable_StartCluOrEclu_Disputes);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Merchants']")]
		private IWebElement _payables_AccountsPayable_StartCluOrEclu_Merchants { get; set; }
		public void NavigateTo_Payables_AccountsPayable_StartCluOrEclu_Merchants()
		{
			NavigateToMenuItem(_payables_AccountsPayable_StartCluOrEclu_Merchants);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Merchant Enrollment Status']")]
		private IWebElement _payables_AccountsPayable_StartCluOrEclu_MerchantEnrollmentStatus { get; set; }
		public void NavigateTo_Payables_AccountsPayable_StartCluOrEclu_MerchantEnrollmentStatus()
		{
			NavigateToMenuItem(_payables_AccountsPayable_StartCluOrEclu_MerchantEnrollmentStatus);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='EnCircle Enrollment']")]
		private IWebElement _payables_AccountsPayable_StartCluOrEclu_EncircleEnrollment { get; set; }
		public void NavigateTo_Payables_AccountsPayable_StartCluOrEclu_EncircleEnrollment()
		{
			NavigateToMenuItem(_payables_AccountsPayable_StartCluOrEclu_EncircleEnrollment);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='AR-Exchange Invoices']")]
		private IWebElement _payables_AccountsPayable_StartCluOrEclu_ArExchangeInvoices { get; set; }
		public void NavigateTo_Payables_AccountsPayable_StartCluOrEclu_ArExchangeInvoices()
		{
			NavigateToMenuItem(_payables_AccountsPayable_StartCluOrEclu_ArExchangeInvoices);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Create Single-Use Accounts']")]
		private IWebElement _payables_AccountsPayable_StartCluOrEclu_CreateSingleUseAccounts { get; set; }
		public void NavigateTo_Payables_AccountsPayable_StartCluOrEclu_CreateSingleUseAccounts()
		{
			NavigateToMenuItem(_payables_AccountsPayable_StartCluOrEclu_CreateSingleUseAccounts);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Create Test Transactions']")]
		private IWebElement _payables_AccountsPayable_StartCluOrEclu_CreateTestTransactions { get; set; }
		public void NavigateTo_Payables_AccountsPayable_StartCluOrEclu_CreateTestTransactions()
		{
			NavigateToMenuItem(_payables_AccountsPayable_StartCluOrEclu_CreateTestTransactions);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Start CLU or ECLU']")]
		private IWebElement _payables_AccountsPayable_StartCluOrEclu_StartCluOrEclu { get; set; }
		public void NavigateTo_Payables_AccountsPayable_StartCluOrEclu_StartCluOrEclu()
		{
			NavigateToMenuItem(_payables_AccountsPayable_StartCluOrEclu_StartCluOrEclu);
		}

		
		private void NavigateToMenuItem(IWebElement element)
		{
			Driver.Url = element.GetAttribute("href");
		}
		#endregion

		public StartClu(GlobalSettings settings) : base(settings) { }
	}  
}
