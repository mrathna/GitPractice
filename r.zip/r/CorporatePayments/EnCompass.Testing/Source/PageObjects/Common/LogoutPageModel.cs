﻿using Common;
using Common.PageObjects;
using Common.Utility;
using NFluent;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EnCompass.Testing.Source.PageObjects.Common
{
	public class LogoutPageModel : PageModel
	{
		private const string LOGIN_XPATH = @"//input[contains(@id,'logIn')]";

        public IWebElement _loginAction
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(LOGIN_XPATH), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Debug("Found _loginAction");
                return element;
            }
        }

        public override string RelativeUrl => "logout.aspx";

		public override string PageIdentifierXPath_Generated => LOGIN_XPATH;

		public bool IsLoggedOut
		{
			get
			{
				try
				{
					WaitForLoad();
					var isDisplayed = _loginAction.Displayed;
					// included isDisplayed below to prevent the compiler from optimizing out the line above (just in case)
					return isDisplayed || true;

				}
				catch { return false; }
			}
		}

		public LogoutPageModel(GlobalSettings settings) : base(settings) { }

		public void PressLoginButton()
		{
			_loginAction.JSClickWithFocus(Driver);
		}
	}
}
