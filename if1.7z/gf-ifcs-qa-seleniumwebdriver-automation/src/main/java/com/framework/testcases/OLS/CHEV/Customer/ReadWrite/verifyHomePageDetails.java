package com.framework.testcases.OLS.CHEV.Customer.ReadWrite;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.CHEV.CHHomePage;
import com.framework.pages.CHEV.CHTransactionPage;
import com.framework.pages.OLS.common.CommonPage;
import com.framework.pages.OLS.common.LoginPage;

public class verifyHomePageDetails extends BaseTest {
	@Parameters({ "clientCountry", "clientName"})
	@Test(priority = 1)
	public void testCustomerReadWriteHomePage(@Optional("PH") String clientCountry, @Optional("CHV") String clientName) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  OLS - Home Page Details", "Chevron Customer Screens Read/Write");

		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		if (clientCountry.equals("SG")||clientCountry.equals("MY")||clientCountry.equals("HK")) {
			loginPage.Login("CHV_URL", "CHV_Customer_UN_RW_ONLY_"+clientCountry, "CHV_Customer_PWD_RW_ONLY_"+clientCountry, "CHV");
		} else if (clientCountry.equals("TH")) {
			loginPage.Login("CHV_URL", "CHV_Customer_UN_"+clientCountry, "CHV_Customer_PWD_"+clientCountry, "CHV");
		} else if (clientCountry.equals("PH")) {
			loginPage.Login("CHV_URL", "CHV_Customer_UN_"+clientCountry, "CHV_Customer_PWD_"+clientCountry, "CHV");
		}	
		CHHomePage chHomePage= new CHHomePage(driver,test);
		CHTransactionPage chTransactionPage=new CHTransactionPage(driver,test);
		CommonPage commonPage=new CommonPage(driver,test);
		
		chHomePage.verifyHomePageText();
		commonPage.selectAccountFromDropdownAndValidate();
		
		//OrderCard Page
		chHomePage.loadFindAndValidateOrderCardPage();
		chHomePage.clickOnHome();
		chHomePage.verifyHomePageText();
		
		//Card Status QuickLink
		chHomePage.findVerifyAndClickCardStatusQuickLink();
		chHomePage.clickOnHome();
		chHomePage.verifyHomePageText();
		
		//move to Transaction Page
		chHomePage.findAndClickFindtransactions();
		
		//Transaction Page
		chTransactionPage.verifyTransactionPage();
		chHomePage.clickOnHome();
		chHomePage.verifyHomePageText();
		
		//Export Transactions
		chHomePage.findAndClickExportTransactionQuickLink();
		chHomePage.verifyAccountNoForFileVerification();
		
		//Logout
		loginPage.Logout();
			
		}	
		
	}

