using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using Common;
using Common.PageObjects;
using Common.ScenarioConfigurations;
using Common.Utility;

namespace EnCompass.Testing.Source.PageObjects.Organization.Admin.TransactionEnvelope 
{
	/// <summary>
	/// Auto-generated Page Model Class
	/// Navigation Paths: 
		/// [Organization Home]->Administration->Transaction Envelopes
		/// </summary>
	[PageModel(@"/Admin/TransactionEnvelope/CalculatedFields.aspx")]
	public partial class CalculatedFields : EnCompassOrgPageModel 
	{
		public override string RelativeUrl => @"/Admin/TransactionEnvelope/CalculatedFields.aspx";
		public override string PageIdentifierXPath_Generated => @"//li[contains(@class, 'breadcrumb-item active')][text() = 'Envelope Calculated Fields']";

		#region Navigation
		
		private void NavigateToMenuItem(IWebElement element)
		{
			Driver.Url = element.GetAttribute("href");
		}
		#endregion

		public CalculatedFields(GlobalSettings settings) : base(settings) { }
	}  
}
