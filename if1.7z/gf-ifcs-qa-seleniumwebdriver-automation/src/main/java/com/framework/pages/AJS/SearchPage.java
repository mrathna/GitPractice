package com.framework.pages.AJS;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

import com.aventstack.extentreports.ExtentTest;
import com.framework.basepage.BasePage;
import com.framework.pages.AJS.common.Common;
import com.framework.repo.Locator_IFCS;
import com.framework.util.PropUtils;

// Added by Ayub 11-02-2019
public class SearchPage extends BasePage {

	@FindBy(xpath = Locator_IFCS.SEARCH_MENU)
	public WebElement searchMenu;

	@FindBy(xpath = Locator_IFCS.SEARCH_CARDS_TEXTBOX)
	public List<WebElement> textBoxes;
	@FindBy(xpath = Locator_IFCS.Customer_SEARCH_FIRST)
	public WebElement CustomersearchFirst;
	
	private String f_DriverName = "";
	private String f_vrn = "";

	Common common = new Common(driver, test);

	public SearchPage(WebDriver driver, ExtentTest test) {
		super(driver, test);
		PageFactory.initElements(new AjaxElementLocatorFactory(driver, 15), this);
	}

	String customerNo;
	String locationNo;
	String transactionDate;
	String invoiceDate;

	public void enterCustomerNumberAndSearch(String clientCountry) {
		common.clearingAllTextBoxes(textBoxes);
		
		customerNo = common.getACustomerWithCard(PropUtils.getPropValue(configProp, clientCountry).replaceAll("\"", ""));
		enterValueInTextBox("Filter By", "Customer No", customerNo);
		sleep(2);
		common.searchListTorch();
		sleep(3);
		common.validateSearchTable("Customer No", customerNo, true);
	}

	// Added by Ayub on 13-02-2019
	public void enterCustomerNoHasTransactionAndSearch(String clientCountry) {
		common.clearingAllTextBoxes(textBoxes);
		customerNo = common
				.getCustomerNoHasTransaction(PropUtils.getPropValue(configProp, clientCountry).replaceAll("\"", ""));
		enterValueInTextBox("Transaction Filter Fields", "Customer No", customerNo);
		common.searchListTorch();
		sleep(3);
		common.validateSearchTable("Customer No", customerNo, true);
	}

	public void enterLocationNoHasTransactionAndSearch(String clientCountry) {
		common.clearingAllTextBoxes(textBoxes);
		locationNo = common
				.getLocationNoHasTransaction(PropUtils.getPropValue(configProp, clientCountry).replaceAll("\"", ""));
		enterValueInTextBox("Transaction Filter Fields", "Location No", locationNo);
		common.searchListTorch();
		sleep(5);
		// common.validateSearchTable("Location No", locationNo, true);
	}

	public void enterProcessDateAndSearch(String labelName, String clientCountry) {
		common.clearingAllTextBoxes(textBoxes);
		System.out.println("Inside of enter processdate from and search" + clientCountry);
		transactionDate = common
				.getTransactionDateFromTheDB(PropUtils.getPropValue(configProp, clientCountry).replaceAll("\"", ""));
		enterValueInTextBox("Transaction Filter Fields", labelName, transactionDate);
		common.searchListTorch();
		sleep(3);
		// common.validateSearchTable("Customer No", transactionDate, true);
	}

	public void enterProcessDateFromAndPartReferenceNoAndSearch(String labelName, String clientCountry) {
		common.clearingAllTextBoxes(textBoxes);
		System.out.println("Inside of enter processdate from and search" + clientCountry);
		transactionDate = common
				.getTransactionDateFromTheDB(PropUtils.getPropValue(configProp, clientCountry).replaceAll("\"", ""));
		enterValueInTextBox("Transaction Filter Fields", labelName, transactionDate);
		common.searchReferenceValueAndValidate("Partial");
		common.searchListTorch();
		sleep(3);
		// common.validateSearchTable("Customer No", transactionDate, true);
	}

	public void enterProcessDateAndPartialCardSearch(String labelName, String clientCountry) {
		common.clearingAllTextBoxes(textBoxes);
		System.out.println("Inside of enter processdate from and search" + clientCountry);
		transactionDate = common
				.getTransactionDateFromTheDB(PropUtils.getPropValue(configProp, clientCountry).replaceAll("\"", ""));
		enterValueInTextBox("Transaction Filter Fields", labelName, transactionDate);
		common.searchCardnumberAndValidate("Partial", "Transaction Filter Fields");
		common.searchListTorch();
		sleep(3);
		// common.validateSearchTable("Customer No", transactionDate, true);
	}

	public void enterCustomerNumberWithWildcardSymbolAndSearch() {
		common.clearingAllTextBoxes(textBoxes);
		f_DriverName= fakerAPI().name().username().toString();
		enterValueInTextBox("Filter By", "Customer No", f_DriverName);
		common.searchListTorch();
	}

		public void enterUnknownDriverNameAndSearch() {
		common.clearingAllTextBoxes(textBoxes);
		f_DriverName= fakerAPI().name().username().toString();
		enterValueInTextBox("Filter By", "Driver Name", f_DriverName);
		common.searchListTorch();
	}
    public void enterUnknownVRNeAndSearch() {
		common.clearingAllTextBoxes(textBoxes);
		f_vrn = fakerAPI().name().username().toString();
		enterValueInTextBox("Filter By", "VRN", f_vrn);
		common.searchListTorch();
		sleep(3);
		verifyValidationResult("Details not found");
	}

	public void enterUnknownReferenceNoAndSearch() {
		common.clearingAllTextBoxes(textBoxes);
		f_vrn = fakerAPI().name().username().toString();

		enterValueInTextBox("Transaction Filter Fields", "Reference No", f_vrn);
		common.searchListTorch();
		sleep(3);
		verifyValidationResult("Details not found");
	}

	public void enterFutureDateAndSearch(String clientCountry) {
		common.clearingAllTextBoxes(textBoxes);
		String currentIFCSDate=common.getCurrentIFCSDateFromDB(clientCountry);
		String expiringTo = common.enterADateValueInStatusBeginDateField("Future", currentIFCSDate);
		enterValueInTextBox("Transaction Filter Fields", "Process Date From", expiringTo);
		common.searchListTorch();
		sleep(3);
		verifyValidationResult("Details not found");
	}

	public void enterInvoicesFutureDateAndSearch(String clientCountry) {
		common.clearingAllTextBoxes(textBoxes);
		String currentIFCSDate=common.getCurrentIFCSDateFromDB(clientCountry);
		String expiringTo = common.enterADateValueInStatusBeginDateField("Future", currentIFCSDate);
		enterValueInTextBox("Filter By", "Created From", expiringTo);
		common.searchListTorch();
		sleep(3);
		verifyValidationResult("Details not found");
	}

	public void enterInvoicesDateAndSearch(String labelName, String clientCountry) {
		common.clearingAllTextBoxes(textBoxes);
		System.out.println("Inside of enter processdate from and search" + clientCountry);
		/*invoiceDate = common
				.getStoredInvoiceDateFromTheDB(PropUtils.getPropValue(configProp, clientCountry).replaceAll("\"", ""));*/
		invoiceDate = common
				.getStoredInvoiceDateFromTheDB();
		enterValueInTextBox("Filter By", labelName, invoiceDate);
		common.searchListTorch();
		sleep(3);
		// common.validateSearchTable("Customer No", transactionDate, true);
	}

	public void enterInvoicesDateAndPartRemittanceIDSearch(String labelName, String clientCountry) {
		common.clearingAllTextBoxes(textBoxes);
		System.out.println("Inside of enter processdate from and search" + clientCountry);
		/*invoiceDate = common
				.getStoredInvoiceDateFromTheDB(PropUtils.getPropValue(configProp, clientCountry).replaceAll("\"", ""));*/
		invoiceDate = common.getStoredInvoiceDateFromTheDB();
		enterValueInTextBox("Filter By", labelName, invoiceDate);
		common.searchRemittanceIDHasInvoicesAndValidate("Partial");
		common.searchListTorch();
		sleep(3);
		// common.validateSearchTable("Customer No", transactionDate, true);
	}

	public void enterUnknownRemittanceIDAndSearch() {
		common.clearingAllTextBoxes(textBoxes);
		f_vrn = fakerAPI().name().username().toString();

		enterValueInTextBox("Filter By", "Remittance ID", f_vrn);
		common.searchListTorch();
		sleep(3);
		verifyValidationResult("Details not found");
	}
	
	public void selectClientInDropDownAndSearch(String labelName, String clientCountry) {
		// Client
		common.clearingAllTextBoxes(textBoxes);
		chooseOptionFromDropdown(labelName,PropUtils.getPropValue(configProp, clientCountry).replaceAll("\"", ""));
		common.searchListTorch();
		sleep(5);
		//common.verifyContainsInBottomLeftMessage("Record Read OK - Page Size");
		verifyValidationResult("Record Read OK - Page Size");

	}
	public void enterCustomerNumberAndSelect(String CustomerNumber) {
		common.clearingAllTextBoxes(textBoxes);
		enterValueInTextBox("Filter By", "Customer No", CustomerNumber);
		sleep(2);
		common.searchListTorch();
		doubleClick(CustomersearchFirst);
		sleep(3);
		
	}
	
	public void SelectCustormerFromCustomerList() {
		doubleClick(CustomersearchFirst);
		sleep(3);
		
	}

	

}
