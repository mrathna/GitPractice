﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using TestResourceLibrary;
using Common;

namespace Common.ScenarioConfigurations
{
	public class TacoScenarioConfiguration : BaseScenarioConfiguration
	{
		private DataSet _data;

		public override DataSourceType SourceType => DataSourceType.Taco;
		public override DataSet Data => _data;

		public string TestName { get; set; }
		public string GroupName { get; set; }

		public bool HasGroupName { get { return !string.IsNullOrWhiteSpace(GroupName); } }

		public override bool LoadData()
		{
			if (HasGroupName)
			{
				var table = TestDataReader.Instance.RetrieveData(Environment, Customer, TestName, GroupName);
				if (table != null)
				{
					_data = new DataSet();
					_data.Tables.Add(table);
					return true;
				}
				return false;
			}
			else
			{
				var result = TestDataReader.Instance.RetrieveData(Environment, Customer, TestName);
				if (result != null)
				{
					_data = result;
					return true;
				}
				return false;
			}
		}
	}
}
