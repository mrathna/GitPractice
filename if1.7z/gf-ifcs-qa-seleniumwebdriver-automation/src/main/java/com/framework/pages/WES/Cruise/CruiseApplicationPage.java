package com.framework.pages.WES.Cruise;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.ExtentTest;
import com.framework.basepage.BasePage;
import com.framework.pages.WES.common.CommonPage;
import com.framework.repo.Locator_WES;
import com.framework.util.Constants;
import com.framework.util.PdfUtils;
import com.framework.util.SikuliUtils;

public class CruiseApplicationPage extends BasePage {
	
	String firstName = fakerAPI().name().firstName();
	String lastName = fakerAPI().name().lastName();
	String fnumber = fakerAPI().number().digits(4);
	String comapnyName = fakerAPI().company().name();
	String addres = fakerAPI().address().cityName();
	String town = fakerAPI().address().cityName();
	String emailAddress = fakerAPI().internet().emailAddress();

	@FindBy(xpath = Locator_WES.CRUISE_FULE_CARD_APPLICATION)
	public WebElement fuleCardAppliction;


	@FindBy(xpath = Locator_WES.CRUISE_WES_CHECK_BOX)
	public WebElement wesCheckBox;
	@FindBy(xpath = Locator_WES.HOME_MENU_OPTION)
	public WebElement homeMenu;

	@FindBy(xpath = Locator_WES.CRUISE_ESSO_CHECK_BOX)
	public WebElement essoCheckbox;

	@FindBy(xpath = Locator_WES.CRUISE_MONTHLY_DIESEL)
	public WebElement dieselBox;

	@FindBy(xpath = Locator_WES.CRUISE_MONTHLY_PETROL)
	public WebElement petrolBox;

	@FindBy(xpath = Locator_WES.CRUISE_OBU_NO_RADIO_BUTTON)
	public WebElement obuNoButton;

	@FindBy(xpath = Locator_WES.CRUISE_VAT_NO_RADIO_BUTTON)
	public WebElement vatNoButton;

	@FindBy(xpath = Locator_WES.CRUISE_NUMBER_OF_VEHICLES)
	public WebElement noOfVehicles;

	@FindBy(xpath = Locator_WES.VEHICLES_TYPE_CARS)
	public WebElement vehiclesType;

	@FindBy(xpath = Locator_WES.PROSPECT_TYPE_DROPDOWN)
	public WebElement prospectTypeDropdown;

	@FindBy(xpath = Locator_WES.PROSPECT_NAME)
	public WebElement prospectCompanyName;
	
	@FindBy(xpath = Locator_WES.BUSINESS_TYPE_BUTTON)
	public WebElement businessTypeBtn;

	@FindBy(xpath = Locator_WES.BUSINESS_TYPE_DROPDOWN)
	public WebElement businessTypeDropdown;
	
	@FindBy(xpath = Locator_WES.BUSINESS_TYPE_NEWDROPDOWN)
	public List<WebElement> businessTypeNewDropdown;

	@FindBy(xpath = Locator_WES.TRADING_YEAR)
	public WebElement tradingYear;

	@FindBy(xpath = Locator_WES.COMPANY_REGO)
	public WebElement companyRegoNo;

	@FindBy(xpath = Locator_WES.CONTACT_TITILE)
	public WebElement contactTitile;

	@FindBy(xpath = Locator_WES.CONTACT_FIRST_NAME)
	public WebElement contactFirstName;

	@FindBy(xpath = Locator_WES.CONTACT_SUR_NAME)
	public WebElement contactSurName;

	@FindBy(xpath = Locator_WES.CONTACT_NUM)
	public WebElement contactNumber;

	@FindBy(xpath = Locator_WES.PROSPECT_ADDRESS1)
	public WebElement prospectAddress;

	@FindBy(xpath = Locator_WES.PROSPECT_TOWN)
	public WebElement prospectTown;

	@FindBy(xpath = Locator_WES.PROSPECT_POST_CODE)
	public WebElement prospectCode;

	@FindBy(xpath = Locator_WES.INVOICE_FORMATE)
	public WebElement invoiceFormated;

	@FindBy(xpath = Locator_WES.FULE_CARD_EMBOSS_NAME)
	public WebElement fuleCardEmbossgName;

	@FindBy(xpath = Locator_WES.FULE_CARD_NOCARDS)
	public WebElement noOfCard;

	@FindBy(xpath = Locator_WES.VRN_DRIVER_EMBOSS_LINE1)
	public WebElement vrnOrDriver;

	@FindBy(xpath = Locator_WES.ESSO_CARD_CHECKBOX1)
	public WebElement essoCard;

	@FindBy(xpath = Locator_WES.PIN_BOX_1)
	public WebElement pinBox1;

	@FindBy(xpath = Locator_WES.PIN_BOX_2)
	public WebElement pinBox2;

	@FindBy(xpath = Locator_WES.VELOCITY_EMAIL)
	public WebElement velocityEmail;

	@FindBy(xpath = Locator_WES.FINAL_COMMENT_BOX)
	public WebElement finalCommentBox;

	@FindBy(xpath = Locator_WES.OUTSIDE_CARDLIST)
	public WebElement outSideCardList;

	@FindBy(how = How.ID, using = Locator_WES.SAVE_BUT)
	public WebElement saveButton;

	@FindBy(xpath = Locator_WES.FUEL_APPLICATION_HEADERTEXT)
	public WebElement fuelApplicationHeader;

	@FindBy(xpath = Locator_WES.CUSTOMER_RETURNED_PAPERWORK)
	public WebElement customerReturnedPaperwork;

	@FindBy(xpath = Locator_WES.PAY_BY_CHEQUE)
	public WebElement payByCheque_checkBox;

//	@FindBy(xpath = Locator_WES.WARNING_PAY_BY_CHEQUE)
//	public WebElement warning_payByCheque;

	@FindBy(xpath = Locator_WES.APPLICATION_SIGNED_DATE)
	public WebElement application_signed_date;

	@FindBy(xpath = Locator_WES.DD_MANDATE_SIGNED)
	public WebElement dd_Mandate_Signed;

	@FindBy(xpath = Locator_WES.APP_COMPLETED)
	public WebElement app_Completed;

	@FindBy(xpath = Locator_WES.PAYMENT_BY_CHEQUE)
	public WebElement paymentByCheque;

	@FindBy(xpath = Locator_WES.APPLICATION_PASSED)
	public WebElement applicationPassed;

	@FindBy(xpath = Locator_WES.ACTIONS)
	public WebElement actions;

	@FindBy(xpath = Locator_WES.ENTER_DECISION)
	public WebElement enterDecision;

	@FindBy(xpath = Locator_WES.INVOICE_FREQUENCY)
	public WebElement invoiceFrequency;

	@FindBy(xpath = Locator_WES.PAYMENT_TERMS)
	public WebElement paymentTerms;

	@FindBy(xpath = Locator_WES.DECISION_SELECT)
	public WebElement decisionSelect;

	@FindBy(xpath = Locator_WES.CREDIT_AUTHORISED_LIMIT)
	public WebElement creditAuthorisedLimit;

	@FindBy(xpath = Locator_WES.SECURITY_TYPE)
	public WebElement securityType;

	@FindBy(xpath = Locator_WES.SECURITY_DATE_RECEIVED)
	public WebElement securityDateReceived;

	@FindBy(xpath = Locator_WES.SECURITY_EXPIRY_DATE)
	public WebElement securityExpiryDate;

	@FindBy(xpath = Locator_WES.RISK_CATEGORY)
	public WebElement riskCategory;

	@FindBy(xpath = Locator_WES.DUNNING_CLASSIFICATION)
	public WebElement dunningClassification;

	@FindBy(xpath = Locator_WES.UNDERWRITINGTYPE)
	public WebElement underwritingtype;

	@FindBy(xpath = Locator_WES.PERIODIC_ASSIGNMENT)
	public WebElement periodicAssignment;

	@FindBy(xpath = Locator_WES.OVERALL_FUEL_CREDIT_LIMIT)
	public WebElement overAllFuelCreditLimit;

	@FindBy(xpath = Locator_WES.COMMENTS)
	public WebElement comments;

	@FindBy(xpath = Locator_WES.RECORD_DECISION_BUTTON)
	public WebElement recordDecisionButton;

	@FindBy(xpath = Locator_WES.DECISION_TITLE)
	public WebElement decisiontitle;

	@FindBy(xpath = Locator_WES.MY_CRDEIT_CHECK_RECORD)
	public WebElement myCreditCheckRecord;

	@FindBy(xpath = Locator_WES.MY_CREDIT_CHECK_REF)
	public WebElement myCreditCheckRef;

	@FindBy(how = How.ID, using = Locator_WES.IFRAME_ID)
	public WebElement iframeId;

	@FindBy(xpath = Locator_WES.APP_FORM_PDF_DOCUMENT)
	public WebElement appFormPdfDocument;

	@FindBy(xpath = Locator_WES.RETURN_TO_HOMEPAGE_LINK)
	public WebElement returnToHomePageLink;
	
	@FindBy(how = How.ID, using = Locator_WES.LITE_APPLICATION)
	public WebElement liteApp;
	
	@FindBy(css = Locator_WES.LONG_APPLICATION)
	public WebElement longApp;
	
	@FindBy(how = How.ID, using = Locator_WES.SHORT_APPLICATION)
	public WebElement shortApp;
	
	@FindBy(how = How.ID, using = Locator_WES.BANK_TRANSFER)
	public WebElement bankTransfer;
	
	@FindBy(how = How.ID, using = Locator_WES.PAY_BY_CHEQUE)
	public WebElement cheque;
	
	@FindBy(how = How.ID, using = Locator_WES.WARNING_PAY_BY_BANK_TRANS)
	public WebElement warning_payByBankTrans;
	
	@FindBy(how = How.ID, using = Locator_WES.WARNING_PAY_BY_CHEQUE)
	public WebElement warning_payByCheque;
	
	@FindBy(how = How.ID, using = Locator_WES.BANK_ACC_NAME)
	public WebElement bankAccName;
	
	@FindBy(how = How.ID, using = Locator_WES.BANK_SORT_CODE_1)
	public WebElement bankCode1;
	
	@FindBy(how = How.ID, using = Locator_WES.BANK_SORT_CODE_2)
	public WebElement bankCode2;
	
	@FindBy(how = How.ID, using = Locator_WES.BANK_SORT_CODE_3)
	public WebElement bankCode3;
	
	@FindBy(how = How.ID, using = Locator_WES.BANK_ACC_NO)
	public WebElement bankAccNo;
	
	@FindBy(how = How.ID, using = Locator_WES.SIGNATORY_NAME)
	public WebElement signatoryName;
	
	@FindBy(how = How.ID, using = Locator_WES.BANK_NAME)
	public WebElement bankName;
	
	@FindBy(how = How.ID, using = Locator_WES.BANK_ADDRESS1)
	public WebElement bankAddress;
	
	@FindBy(how = How.ID, using = Locator_WES.BANK_TOWN)
	public WebElement bankTown;
	
	@FindBy(how = How.ID, using = Locator_WES.BANK_POSTCODE)
	public WebElement bankPostCode;
	
	@FindBy(xpath = Locator_WES.ROLE_IN_CMPY)
	public WebElement cmpyRole;
	
	@FindBy(how = How.ID, using = Locator_WES.APP_COMPLETED_CHECKBOX)
	public WebElement appComplCheckBox;
	
	@FindBy(css = Locator_WES.RUN_BUTTON)
	public WebElement runBtn;
	
	@FindBy(css = Locator_WES.DD1_YES_Button)
	public WebElement yesBtn;
	
	@FindBy(how = How.ID, using = Locator_WES.PAYMENT_BY_BankTrans)
	public WebElement payByBankTrans;
	
	public CruiseApplicationPage(WebDriver driver, ExtentTest test) {
		super(driver, test);
		// TODO Auto-generated constructor stub
		PageFactory.initElements(new AjaxElementLocatorFactory(driver, 15), this);
	}

	// Ayub and Prakalpha
	public void createNewEDCOrUKOrESSOCards(String cardType, int noOfCards, String multipleCardType,String appType) {

		verifyTitle("New Application");
		isDisplayed(fuleCardAppliction, "Fuel Card Appliction");
		
		selectApplicationType(appType);
		fuelSelection();
		fuelRequirementDetails();
		
		prospectDetails();
		contactDetails();
		
		prospectAddress();
		invoicePreference();
		fuelCardsDetail(cardType,noOfCards,multipleCardType);
		velocityPreferenceDetails(appType);
		
		verifyTitle("Print Letter Tabs");		
	}
	
	private void velocityPreferenceDetails(String appType) {
		isDisplayedThenEnterText(velocityEmail, "Velocity Email", emailAddress);
		isDisplayedThenEnterText(finalCommentBox, "Final Comment Box", "Good");
		
		if(appType.contains("Lite")) {
			System.out.println("Lite");
			isDisplayedThenActionClick(appComplCheckBox, "app completed check box");
			isDisplayedThenActionClick(runBtn, "run button is clicked");
			isDisplayedThenActionClick(yesBtn, "yes button is clicked");
			driver.switchTo().alert().accept();
			waitForPageLoad(30);			
		}
		sleep(5);
		saveNewApplication();
		waitForPageLoad(150);
		
	}

	private void fuelCardsDetail(String cardType, int noOfCards, String multipleCardType) {
		isDisplayedThenEnterText(noOfCard, "No of Card", Integer.toString(noOfCards));
		takeScreenshot();
		sleep(2);
		Click(outSideCardList, "Outside Card List");
		if (noOfCards == 1) {
			sleep(3);
			isDisplayedThenEnterText(vrnOrDriver, "VRN OR Driver", firstName);
			sleep(5);
			if (cardType.equals("Esso")) {
				WebElement essoCard = driver.findElement(
						By.xpath("//li[contains(@class,'ui-state-default ui')][descendant::a[contains(text(),'"
								+ cardType + "')]]//input[@name='cards[0].selectedBrands']"));
				Click(essoCard, "Esso Checkbox");
				sleep(3);
				isDisplayedThenEnterText(pinBox1, "PIN Box", fnumber);
				sleep(3);

			} else {
				WebElement cardCheckBox = driver.findElement(
						By.xpath("//li[contains(@class,'ui-state-default ui')][descendant::a[contains(text(),'"
								+ cardType + "')]]//input[@name='cards[0].selectedBrands']"));
				Click(cardCheckBox, cardType + " Checkbox");
				sleep(3);
			}
		} else if (noOfCards > 1 && cardType.equals("Esso") && multipleCardType.equals("same")) {
			selectMultipleCheckBoxsWithSameCardType(cardType, noOfCards);
			sleep(3);
			for (int i = 1; i <= noOfCards; i++) {
				WebElement pin = driver.findElement(By.xpath("//input[@id='cardProperties_" + i + "_2_pin']"));
				isDisplayedThenEnterText(pin, "PIN Box", fnumber);
			}
			sleep(2);
		} else if (!cardType.equals("Esso") && noOfCards > 1 && multipleCardType.equals("same")) {
			selectMultipleCheckBoxsWithSameCardType(cardType, noOfCards);
		} else if (noOfCards == 3 && multipleCardType.equals("different")) {

			for (int i = 0; i < noOfCards; i++) {
				WebElement vrnOrDrivername = driver
						.findElement(By.xpath("//input[@name='cards[" + i + "].embossedLine3']"));
				sleep(3);
				isDisplayedThenEnterText(vrnOrDrivername, "VRN OR Driver", firstName);
			}
			WebElement EDCCheckBox = driver.findElement(By.xpath(
					"//li[contains(@class,'ui-state-default ui')][descendant::a[contains(text(),'EDC')]]//input[@name='cards[0].selectedBrands']"));
			Click(EDCCheckBox, "EDC CheckBox");
			WebElement EssoCheckBoxBox = driver.findElement(By.xpath(
					"//li[contains(@class,'ui-state-default ui')][descendant::a[contains(text(),'Esso')]]//input[@name='cards[1].selectedBrands']"));
			Click(EssoCheckBoxBox, cardType + "Esso CheckBox");
			sleep(3);
			isDisplayedThenEnterText(pinBox2, "PIN Box", fnumber);
			WebElement UkFuelsCheckBoxBox = driver.findElement(By.xpath(
					"//li[contains(@class,'ui-state-default ui')][descendant::a[contains(text(),'UK Fuels')]]//input[@name='cards[2].selectedBrands']"));
			Click(UkFuelsCheckBoxBox, cardType + "Esso CheckBox");
		}
//		Taking ScreenShots 
		takeScreenshot();
		sleep(3);
		scrollDownPage();
		
	}

	private void invoicePreference() {
		selectDropDownByVisibleText(invoiceFormated, "Hard Copy");
		isDisplayedThenEnterText(fuleCardEmbossgName, "Card Embossing", firstName);
		sleep(3);
		
	}

	private void fuelSelection() {
		isDisplayedThenActionClick(wesCheckBox, " WES CHECK BOX");
		sleep(2);
		scrollDownPage();
		isDisplayedThenActionClick(essoCheckbox, " ESSO CHECK BOX");
//		Taking ScreenShots 
		takeScreenshot();
		sleep(2);
		scrollDownPage();
		
	}

	private void prospectDetails() {
		selectDropDownByVisibleText(prospectTypeDropdown, "Public Limited Company");
		isDisplayedThenEnterText(prospectCompanyName, "Company Name", comapnyName);
		isDisplayedThenActionClick(businessTypeBtn, "businessTypeBtn");
		isDisplayedThenActionClick(businessTypeNewDropdown.get(2), "businessTypeNewDropdown");
//		selectDropDownByIndex(businessTypeDropdown, 3);
		isDisplayedThenEnterText(tradingYear, "Trading Year", "1");
		isDisplayedThenEnterText(companyRegoNo, "Rego No", fnumber);		
	}

	private void contactDetails() {
		selectDropDownByIndex(contactTitile, 1);
		isDisplayedThenEnterText(contactFirstName, "Contact First Name", firstName);
		isDisplayedThenEnterText(contactSurName, "Contact SurName", lastName);
		isDisplayedThenEnterText(contactNumber, "Phone Number", "+44 (0)1223 355555");
//		Taking ScreenShots 
		takeScreenshot();
		sleep(3);
		scrollDownPage();	
	}
	
	private void prospectAddress() {
		isDisplayedThenEnterText(prospectAddress, "Pros pect Address", addres);
		isDisplayedThenEnterText(prospectTown, "Pros town", town);
		isDisplayedThenEnterText(prospectCode, "Pros code", "WC2N 5DU");
		scrollDownPage();	
	}
	
	private void fuelRequirementDetails() {
		isDisplayedThenEnterText(dieselBox, "Diesel text box", "20");
		isDisplayedThenEnterText(petrolBox, "petrol text box", "20");
		isDisplayedThenActionClick(obuNoButton, "OBU Radio Button");
		sleep(2);
		isDisplayedThenActionClick(vatNoButton, "VAT Radio Button");
//		Taking ScreenShots 
		takeScreenshot();
		sleep(2);
		scrollDownPage();
		isDisplayedThenEnterText(noOfVehicles, "Vehicles Text Box", "1");
		sleep(2);
		isDisplayedThenActionClick(vehiclesType, "Vehicles Type Cars");
		scrollDownPage();
		
	}

	private void selectApplicationType(String applType) {
		System.out.println("applType: "+applType);
		if(applType.contains("Lite")) {
			System.out.println("Lite");
			isDisplayedThenActionClick(liteApp, "LiteApplication");
		}else if(applType.contains("Long")) {
			sleep(3);
			isDisplayedThenActionClick(longApp, "LongApplication");
			System.out.println("Long");
		}/*else{
			isDisplayedThenActionClick(shortApp, "ShortApplication");
		System.out.println("Short");
		}
		*/
//	Taking ScreenShots 
	takeScreenshot();
	sleep(3);
	}

	// Prakalpha -->23/07/2019
	public void selectMultipleCheckBoxsWithSameCardType(String cardType, int cards) {
		String firstName = fakerAPI().name().firstName();

		for (int i = 0; i < cards; i++) {
			// waitForPageLoad(20);
			WebElement vrnOrDrivername = driver
					.findElement(By.xpath("//input[@name='cards[" + i + "].embossedLine3']"));
			sleep(2);
			isDisplayedThenEnterText(vrnOrDrivername, "VRN OR Driver", firstName);
			WebElement cardsCheckBox = driver
					.findElement(By.xpath("//li[contains(@class,'ui-state-default ui')][descendant::a[contains(text(),'"
							+ cardType + "')]]//input[@name='cards[" + i + "].selectedBrands']"));
			System.out.println("CheckBoxElement::" + cardsCheckBox);
			Click(cardsCheckBox, cardType + " CheckBox");
		}
	}

	/*
	 * Prakalpha Fill mandatory for Created Customer
	 */
	public void fillMandatoryForCreatedCustomer(String paymentType) {
		verifyTitle("New Application");
		isDisplayed(fuelApplicationHeader, "Fuel Card Application");
		isDisplayedThenClickRadioBTN(customerReturnedPaperwork, "The Customer is returning their paperwork");
		if(paymentType.contains("Transfer")) {
			isDisplayedThenClick(bankTransfer, "Pay By Bank Transfer checkbox is selected");
			isDisplayed(warning_payByBankTrans, "Warning Meassage");
		}else if(paymentType.contains("Details")){
			isDisplayedThenEnterText(bankAccName, "accName", "SUNNY TEST");
			isDisplayedThenEnterText(bankCode1, "bankCode1", "40");
			isDisplayedThenEnterText(bankCode2, "bankCode2", "47");
			isDisplayedThenEnterText(bankCode3, "bankCode3", "84");
			isDisplayedThenEnterText(bankAccNo, "accNo", "70872490");
			isDisplayedThenEnterText(signatoryName, "signName", "SUNNY");
			isDisplayedThenEnterText(bankName, "bankName", "TEST BANK");
			isDisplayedThenEnterText(bankAddress, "bankAddress", "1 TEST STREET");
			isDisplayedThenEnterText(bankTown, "bankTown", "TEST TOWN");
			isDisplayedThenEnterText(bankPostCode, "accName", "ST87LZ");
			selectDropDownByVisibleText(cmpyRole, "CEO");
		}else {
			isDisplayedThenClick(cheque, "Pay By Cheque checkbox is selected");
			isDisplayed(warning_payByCheque, "Warning Meassage");
		}
//		Taking ScreenShots 
		takeScreenshot();
		sleep(2);
		
		isDisplayedThenClick(application_signed_date, "Application signed and Dated");
		isDisplayedThenClick(dd_Mandate_Signed, "Direct Debit Mandate Signed and dated");
		isDisplayedThenClick(app_Completed, "Application SignedUp and Completed");
//		Taking ScreenShots 
		takeScreenshot();
		sleep(2);
		isDisplayedThenActionClick(saveButton, "Save Button");
		sleep(10);
		driver.navigate().refresh();
	}

	/*
	 * Prakalpha -->22/07/2019 edit Credit Status for FuelCard
	 */
	public void editCreditStatusFuelCardApplication(String paymentType) {
		isDisplayed(fuelApplicationHeader, "Fuel Card Application");
		if(paymentType.contains("Transfer")) {
			isDisplayedThenClick(payByBankTrans, "Payment By Bank Transfer");
		}else if(paymentType.contains("Details")){
			isDisplayedThenClick(paymentByCheque, "Payment By Cheque Authorised");
		}else {
			isDisplayedThenClick(paymentByCheque, "Payment By Cheque Authorised");
		}	
		isDisplayedThenClick(applicationPassed, "Application Passed Security Checks");
//		Taking ScreenShots 
		takeScreenshot();
		sleep(2);
		Click(saveButton, "Save Button");
		sleep(10);
		driver.navigate().refresh();
	}

	/*
	 * sowmiya My Credit check
	 */
	public void validateMyCreditCheckAndEnterDecisionDetails(String referenceNo) {
		WebDriverWait wait=new WebDriverWait(driver,20);
		
		String authorisedLimit = "450";
		verifyTitle("Credit Check App");
		mouseHover(actions);
		isDisplayedThenActionClick(enterDecision, "Enter Decision");
		verifyTitle("Enter Decision Data");
		verifyText(decisiontitle, "Decision");
		selectDropDownByVisibleText(invoiceFrequency, "Daily Billing");
//		Taking ScreenShots 
		takeScreenshot();
		sleep(2);
		
		selectDropDownByVisibleText(paymentTerms, "4 Days Following Invoice Date");
		selectDropDownByVisibleText(decisionSelect, "Accept");
		isDisplayedThenEnterText(creditAuthorisedLimit, "Credit Authorised Limit", authorisedLimit);
		selectDropDownByVisibleText(securityType, "Cash Deposit");
		
		isDisplayedThenEnterText(securityDateReceived, "Security Date Received text box", "14/12/2017");
		
		isDisplayedThenEnterText(securityExpiryDate, "Security Expiry Date", "31/03/2018");
		selectDropDownByVisibleText(riskCategory, "1 - Very Low");
		
		selectDropDownByVisibleText(dunningClassification, "Standard Customer");
		
		selectDropDownByVisibleText(underwritingtype, "Sign Off");
//		Taking ScreenShots 
		takeScreenshot();
		sleep(2);
		
		isDisplayedThenEnterText(periodicAssignment, "Periodic assignment text box", "14/12/2017");
		isDisplayedThenClick(decisiontitle, "Decision Title");
		sleep(3);
		isDisplayedThenEnterText(comments, "Comments Text Area", "Approved!");
		sleep(2);

		isDisplayedThenActionClick(recordDecisionButton, "Record Decision Button");
//		Taking ScreenShots 
		takeScreenshot();
		sleep(2);
		
		// For clicking ok button in alert Popup
		if(wait.until(ExpectedConditions.alertIsPresent())!=null)
		{
		driver.switchTo().alert().accept();
		}
		waitForPageLoad(30);
		verifyTitle("Cruise");
		driver.switchTo().frame("mycreditFrame");
		isDisplayedThenEnterText(myCreditCheckRef, "My credit check Reference No text box", referenceNo);
		isDisplayed(myCreditCheckRecord, "No Record to view");

	}
	
	// Added by raxsana 23/07/2019
	public String getReferenceNumberFromPDFFileDownloaded() {
		CommonPage commonPage = new CommonPage(driver, test);
		String referenceNum = null;
		String appCreation = fakerAPI().number().digits(2);
		String fileName = "ApplicationCreation" + appCreation;
		driver.switchTo().frame("appFrame");
		sleep(5);
		mouseHoverOverSpecificPixel(appFormPdfDocument, 80, 30);
		SikuliUtils.waitUntilObjectisLoaded(1);
		SikuliUtils.clickElement(Constants.DOWNLOAD_PDF);
		 sleep(5);
		commonPage.uploadOrSaveLatestCruiseFile(fileName);
		String pdfFilePathLocal = System.getProperty("user.home") + System.getProperty("file.separator") + "Downloads"
				+ System.getProperty("file.separator") + fileName + ".pdf";
		System.out.println("file path local" + pdfFilePathLocal);
		String text = null;
		List<String> textFromForm = PdfUtils.getTextFromForm(pdfFilePathLocal, 3);
		for (int i = 0; i < textFromForm.size(); i++) {
			text = textFromForm.get(i);
			if (text.contains("App:")) {
				referenceNum = text.split(":")[1];
				System.out.println("text::" + text);
				break;
			}
		}
		driver.switchTo().defaultContent();
		isDisplayedThenClick(returnToHomePageLink, "Return to Home Page Link");
		waitForPageLoad(20);
		driver.navigate().refresh();
		return referenceNum;
	}

	public void saveNewApplication() {
		JavascriptExecutor executor = (JavascriptExecutor) driver;
		executor.executeScript("arguments[0].click();", saveButton);
		System.out.println("application has been saved");
	}

}
