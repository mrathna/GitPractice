﻿using Common;
using Common.Utility;
using EnCompass.Testing.Source.PageObjects.Controls;
using NFluent;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Support.UI;
using System;

namespace EnCompass.Testing.Source.PageObjects.Organization.Admin.AccountProfiles
{
    [PageModel(@"/admin/accountProfiles/editCardProfile.aspx")]
    public class EditCardProfile : EnCompassOrgPageModel
    {
        public override string RelativeUrl => @"/admin/accountProfiles/editCardProfile.aspx";
        public override string PageIdentifierXPath_Override => @"//h1[contains(@id,'title')]";

        #region XPath page Elements

        public string TEXT_CREDIT_LIMIT_XPATH = "//input[contains(@id,'txtCreditLimit')]";
        private const string _nameTextBoxXPath = @"//input[contains(@id,'nameTextBox')]";
        private const string _descriptionTextBoxXPath = @"//input[contains(@id,'descriptionTextBox')]";
        private const string _hierarchyLinkXPath = @"//a[contains(@id, 'hierarchyExplorer')]";
        private const string _txtCreditLimitXPath = "//input[contains(@id,'txtCreditLimit')]";
        private const string _nextXPath = @"//input[contains(@id,'nextButton')]";
        private const string _mccGroupXPath = @"//*[contains(@id,'DdlIncludeExcludeProfiles')]";
        private const string _saveXPath = @"//input[contains(@id,'saveButton')]";
        private const string _addAssignedProfilesXPath = @"//button[contains(@id,'ThisToThat1')]";
        private const string _selectAssignedProfilesXPath = @"//select[contains(@id, 'From')]" + @"//*[normalize-space(text())='PROFILE1']";
        private const string _errorMessageXPath = @"//div[contains(@id,'ValidationSummary') and contains(@class,'alert-danger')]";
        private const string _ddlAccountStatusesXPath = @"//*[contains(@id,'ddlAccountStatuses')]";
        private const string _rbWithNodeXPath = @"//*[contains(@id,'rbWithNode')]";
        private const string _expandCardXPath = "(//div[contains(@id,'content_contents_acStep1')]/div[contains(@id,'_apCard')]/h2/a[@data-toggle='collapse'])[1]";
        private const string _expandSetUpXPath = "//div[contains(@id,'content_contents_acStep1')]/div[contains(@id,'_apSetup')]/h2/a[@data-toggle='collapse']";
        private const string _expandCardHolderXPath = "//div[contains(@id,'content_contents_acStep1')]/div[contains(@id,'_apCardholder')]/h2/a[@data-toggle='collapse']";
        private const string _expandLimitsXPath = "//div[contains(@id,'content_contents_acStep1')]/div[contains(@id,'_apLimits')]/h2/a[@data-toggle='collapse']";
        #endregion

        #region Page Elements
        private IWebElement _nameTextBox
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_nameTextBoxXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Info("Found _nameTextBox");
                return element;
            }
        }

        private IWebElement _descriptionTextBox
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_descriptionTextBoxXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Info("Found _descriptionTextBox");
                return element;
            }
        }

        IWebElement _hierarchyLink
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_hierarchyLinkXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Info("Found _hierarchyLink");
                return element;
            }
        }

        private IWebElement _txtCreditLimit
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_txtCreditLimitXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Info("Found _txtCreditLimit");
                return element;
            }
        }

        private IWebElement _next
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_nextXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Info("Found _next");
                return element;
            }
        }

        private IWebElement _mccGroup
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_mccGroupXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Info("Found _mccGroup");
                return element;
            }
        }

        private IWebElement _save
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_saveXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Info("Found _save");
                return element;
            }
        }

        private IWebElement _addAssignedProfiles
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_addAssignedProfilesXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Info("Found _addAssignedProfiles");
                return element;
            }
        }

        private IWebElement _selectAssignedProfiles
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_selectAssignedProfilesXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Info("Found _selectAssignedProfiles");
                return element;
            }
        }

        private IWebElement _errorMessage
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_errorMessageXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Info("Found _errorMessage");
                return element;
            }
        }

        private IWebElement _ddlAccountStatuses
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_ddlAccountStatusesXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Info("Found _ddlAccountStatuses");
                return element;
            }
        }

        public IWebElement _rbWithNode
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_rbWithNodeXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Info("Found _rbWithNode");
                return element;
            }
        }
        #endregion

        #region Expand Elements
        private const string AC_STEP1 = "content_contents_acStep1";
        private const string AP_CARD = "_apCard";
        private const string AP_SETUP = "_apSetup";
        private const string AP_CARD_HOLDER = "_apCardholder";
        private const string AP_LIMITS = "_apLimits";
        #endregion

        public string NameTextBox
        {
            set
            {
                _nameTextBox.Clear();
                _nameTextBox.SendKeys(value);
            }
        }

        public string DescriptionTextBox
        {
            set
            {
                _descriptionTextBox.Clear();
                _descriptionTextBox.SendKeys(value);
            }
        }

        public string CreditLimit
        {
            set
            {
                _txtCreditLimit.Clear();
                _txtCreditLimit.SendKeys(value);
            }
        }

        public void PressNext()
        {
            _next.JSClickWithFocus(Driver);
        }

        //Accessing OrgHierarchy object which has the common functionality of Choosing the TOP Org as its Hierarchy Option.
        private OrgHierarchy _hierarchy;
        public OrgHierarchy Hierarchy
        {
            get
            {
                return _hierarchy ?? (_hierarchy = new OrgHierarchy(_hierarchyLink, Driver, Settings));
            }
        }

        public void SetMccGroup(string whichText)
        {
            var selectElement = new SelectElement(_mccGroup);
            selectElement.SelectByText(whichText);
			Settings.EnCompassExtentTest.Info("Selected : " + whichText);
        }
        public void Save()
        {
            _save.JSClickWithFocus(Driver);
			this.AttachOnDemandScreenShot();
		}
        public void SelectAssignedProfiles()
        {
            _selectAssignedProfiles.JSClickWithFocus(Driver);
        }
        public void AddAssignedProfiles()
        {
            _addAssignedProfiles.JSClickWithFocus(Driver);
        }

        public string ErrorMessage
        {
            get
            {
                return _errorMessage.Text;
            }
        }

        public void ErrorMessageName()
        {
            Check.That(ErrorMessage.Contains("Name is a required value.")).IsTrue();
        }

        public void ErrorMessageDescription()
        {
            Check.That(ErrorMessage.Contains("Description is a required value.")).IsTrue();
        }

        public void SetAccountStatus(string whichText)
        {
            var selectElement = new SelectElement(_ddlAccountStatuses);
            selectElement.SelectByText(whichText);
        }

        public void SetRadBox(IWebElement radBox)
        {
            if (!radBox.Selected)
            {
                radBox.JSClickWithFocus(Driver);
                this.RefreshModel();
            }
        }

        public void ExpandCard()
        {
            //Changed to the generic method
            ExpandCardHeader(AC_STEP1, AP_CARD);
            Settings.EnCompassExtentTest.Info("Expanded Card Section");
        }

        public void ExpandSetUp()
        {
            //Changed to the generic method
            ExpandCardHeader(AC_STEP1, AP_SETUP);
			Settings.EnCompassExtentTest.Info("Expanded SetUp Section");
		}

        public void ExpandCardHolder()
        {
            //Changed to the generic method
            ExpandCardHeader(AC_STEP1, AP_CARD_HOLDER);
			Settings.EnCompassExtentTest.Info("Expanded CardHolder Section");
		}

        public void ExpandLimits()
        {
            //Changed to the generic method
            ExpandCardHeader(AC_STEP1, AP_LIMITS);
            Settings.EnCompassExtentTest.Info("Expanded Limits Section");
		}

        public EditCardProfile(GlobalSettings settings) : base(settings) { }
    }
}