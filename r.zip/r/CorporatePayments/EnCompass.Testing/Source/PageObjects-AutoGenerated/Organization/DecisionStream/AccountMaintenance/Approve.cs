using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using Common;
using Common.PageObjects;
using Common.ScenarioConfigurations;
using Common.Utility;

namespace EnCompass.Testing.Source.PageObjects.Organization.DecisionStream.AccountMaintenance 
{
	/// <summary>
	/// Auto-generated Page Model Class
	/// Navigation Paths: 
		/// [Organization Home]->Cards->Card Maintenance->Review Card Edits
		/// </summary>
	[PageModel(@"/decisionStream/accountMaintenance/Approve.aspx")]
	public partial class Approve : EnCompassOrgPageModel 
	{
		public override string RelativeUrl => @"/decisionStream/accountMaintenance/Approve.aspx";
		public override string PageIdentifierXPath_Generated => @"//li[contains(@class, 'breadcrumb-item active')][text() = 'Review Card Edits']";

		#region Navigation
				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Cards']")]
		private IWebElement _cards_CardMaintenance_ReviewCardEdits_Cards { get; set; }
		public void NavigateTo_Cards_CardMaintenance_ReviewCardEdits_Cards()
		{
			NavigateToMenuItem(_cards_CardMaintenance_ReviewCardEdits_Cards);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='History']")]
		private IWebElement _cards_CardMaintenance_ReviewCardEdits_History { get; set; }
		public void NavigateTo_Cards_CardMaintenance_ReviewCardEdits_History()
		{
			NavigateToMenuItem(_cards_CardMaintenance_ReviewCardEdits_History);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Activate Cards']")]
		private IWebElement _cards_CardMaintenance_ReviewCardEdits_ActivateCards { get; set; }
		public void NavigateTo_Cards_CardMaintenance_ReviewCardEdits_ActivateCards()
		{
			NavigateToMenuItem(_cards_CardMaintenance_ReviewCardEdits_ActivateCards);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Review Card Edits']")]
		private IWebElement _cards_CardMaintenance_ReviewCardEdits_ReviewCardEdits { get; set; }
		public void NavigateTo_Cards_CardMaintenance_ReviewCardEdits_ReviewCardEdits()
		{
			NavigateToMenuItem(_cards_CardMaintenance_ReviewCardEdits_ReviewCardEdits);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Create Test Cards']")]
		private IWebElement _cards_CardMaintenance_ReviewCardEdits_CreateTestCards { get; set; }
		public void NavigateTo_Cards_CardMaintenance_ReviewCardEdits_CreateTestCards()
		{
			NavigateToMenuItem(_cards_CardMaintenance_ReviewCardEdits_CreateTestCards);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Create Test Transactions']")]
		private IWebElement _cards_CardMaintenance_ReviewCardEdits_CreateTestTransactions { get; set; }
		public void NavigateTo_Cards_CardMaintenance_ReviewCardEdits_CreateTestTransactions()
		{
			NavigateToMenuItem(_cards_CardMaintenance_ReviewCardEdits_CreateTestTransactions);
		}

		
		private void NavigateToMenuItem(IWebElement element)
		{
			Driver.Url = element.GetAttribute("href");
		}
		#endregion

		public Approve(GlobalSettings settings) : base(settings) { }
	}  
}
