﻿using Common;
using Common.Utility;
using EnCompass.Testing.Source.PageObjects.Controls;
using NFluent;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;

namespace EnCompass.Testing.Source.PageObjects.Organization.ExpenseManager.Transactions
{
	[PageModel(@"/expenseManager/transactions/FinancialCodeProfileEdit.aspx")]
    public class FinancialCodeProfileEdit : EnCompassOrgPageModel
    {
        public override string RelativeUrl => @"/expenseManager/transactions/FinancialCodeProfileEdit.aspx";
        public override string PageIdentifierXPath_Override => @"//h1[normalize-space(text())='Create' or text() = 'Edit' or text() = 'Edit FC Profile']";

        #region XPath page Elements
        private const string _newProfileNameXPath = @"//input[contains(@id,'txtNewProfileName')]";
        private const string _saveXPath = @"//input[contains(@id,'btnName')]";
        private const string _AssignmentCheckboxXPath = @"//input[contains(@id,'CheckboxColumnBoxActual')]";
        private const string _AssignmentCheckboxLabelXPath = @"//label[contains(@for,'CheckboxColumnBoxActual')]";
        private const string _searchCodeDescXPath = @"//input[contains(@id,'txtSearchCodeDesc')]";
        private const string _searchXPath = @"//input[contains(@id,'btnSearch')]";
        private const string _assignmentStatusTextXPath = @"//select[contains(@id,'ddlSearchAssignmentMode')]";
        #endregion

        #region Page Elements
        private IWebElement _newProfileName
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_newProfileNameXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Info("Found _newProfileName");
                return element;
            }
        }

        private IWebElement _save
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_saveXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Info("Found _save");
                return element;
            }
        }
        private IWebElement _AssignmentCheckbox
        {
            get
            {
                bool found = Driver.TryFindElement(By.XPath(_AssignmentCheckboxXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Info("Found _AssignmentCheckbox");
                return element;
            }
        }

        private IWebElement _AssignmentCheckboxLabel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_AssignmentCheckboxLabelXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Info("Found _AssignmentCheckboxLabel");
                return element;
            }
        }

        private IWebElement _searchCodeDesc
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_searchCodeDescXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Info("Found _searchCodeDesc" +found);
                return element;
            }
        }

        private IWebElement _search
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_searchXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Info("Found _search button");
                return element;
            }
        }

        private IWebElement _assignmentStatusText
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_assignmentStatusTextXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Info("Found _assignmentStatusText");
                return element;
            }
        }
        #endregion
       
		public string NewProfileName
        {
            set
            {
                _newProfileName.Clear();
                _newProfileName.SendKeys(value);
            }
        }

        public void Save()
        {
            _save.JSClickWithFocus(Driver);
			this.AttachOnDemandScreenShot();
			Settings.EnCompassExtentTest.Info("Clicked on Save Button");
		}
		
		public string SearchCodeDesc
        {
            set
            {
                _searchCodeDesc.Clear();
                SearchAssignmentStatus("All");
                _searchCodeDesc.ForceDocumentLoadOnSendKeys(value,Driver);
				Settings.EnCompassExtentTest.Info("Search Code Description =" + value);
            }
        }

        public void PressSearchCode()
        {
            _search.WaitUntilElementIsInteractable();
            _search.JSClickWithFocus(Driver, _searchXPath, Settings);
			Settings.EnCompassExtentTest.Info("Clicked on Search Code");
            WaitForLoad();
        }

        public void AssignFinancialCode(string code)
        {
            SearchCodeDesc = code;
            PressSearchCode();
            _AssignmentCheckbox.SetCheckboxStateWithLabel(_AssignmentCheckboxLabel, true, Driver);
            Save();
            Settings.EnCompassExtentTest.Info(code + " is saved");
            Check.That(HasSuccessMessage).IsTrue();
        }

		public void UnAssignFinancialCode(string code)
		{
			SearchCodeDesc = code;
			PressSearchCode();
			WaitForLoad();
			_AssignmentCheckbox.SetCheckboxStateWithLabel(_AssignmentCheckboxLabel, false);
			WaitForLoad();
		}

		public void SearchAssignmentStatus(string whichText)
		{
            //Mobile specific change
            _assignmentStatusText.SetListboxByText(whichText, SelectTextOptions.StartsWith, Driver, Settings, _assignmentStatusTextXPath);
            WaitForLoad();
        }

		private GridControl _mGrid;
		public GridControl FinancialCodeProfileListGrid
		{
			get
			{
				GridControl grid = _mGrid ?? (_mGrid = new GridControl("dgCodes", Driver));
				grid.WaitForGrid();
				return grid;
			}
		}

		public void VerifyValuesGridAssignedCode(List<string> financialCodesNames)
		{
			for (int i=0; i< financialCodesNames.Count(); i++)
			{
				IWebElement firstRow = FinancialCodeProfileListGrid.GetRow(i);
				Check.That((firstRow.Text).Contains(financialCodesNames.ToString()));
			}
		}

		public FinancialCodeProfileEdit(GlobalSettings settings) : base(settings) { }
	}
}
