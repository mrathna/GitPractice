package com.framework.pages.CHEV;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.ExtentTest;
import com.framework.basepage.BasePage;
import com.framework.repo.Locator;

public class CHContactListPage extends BasePage {

	@FindBy(how = How.XPATH, using = Locator.SCHEDULE_REPORT_MAINTENANCE_PAGE)
	public WebElement contactListTitle;

	@FindBy(how = How.XPATH, using = Locator.CH_MERCHANT_CONTACT_LIST_CONTACT_TYPE_TABLE)
	public WebElement contactTypeColumn;

	@FindBy(how = How.XPATH, using = Locator.CH_MERCHANT_CONTACT_LIST_DEFAULT_CONTACT_TYPE_TABLE)
	public WebElement defaultContactTypeColumn;

	@FindBy(how = How.XPATH, using = Locator.CH_MERCHANT_CONTACT_LIST_CONTACT_NAME_TABLE)
	public WebElement contactNameColumn;

	@FindBy(how = How.XPATH, using = Locator.CH_MERCHANT_CONTACT_LIST_CONTACT_PHONE_TABLE)
	public WebElement contactPhoneColumn;

	@FindBy(how = How.XPATH, using = Locator.CH_MERCHANT_CONTACT_LIST_CONTACT_EMAIL_TABLE)
	public WebElement contactEmailColumn;

	@FindBy(how = How.ID, using = Locator.ADD_MANUAL_BATCH)
	public WebElement addContactButton;

	@FindBy(how = How.ID, using = Locator.CONTACT_EXPORT)
	public WebElement exportButton;

	public CHContactListPage(WebDriver driver, ExtentTest test) {
		super(driver, test);
		PageFactory.initElements(driver, this);
	}

	public void verifyContactListPage() {
		sleep(3);
		isDisplayed(contactListTitle, "Contacts");
		logPass("Redirected to the Contacts List Page");
	}

	public void verifyContactTableColumns() {
		verifyText(contactTypeColumn, "Contact Type");
		verifyText(contactEmailColumn, "Email");
		verifyText(defaultContactTypeColumn, "Default");
		verifyText(contactNameColumn, "Name");
		verifyText(contactPhoneColumn, "Phone");
	}

	public void verifyAddContactAndExportButton() {
		if (addContactButton.isEnabled()) {
			logPass("Add Contact Button is enabled");
		} else {
			logFail("Add Contact Button is not enabled");
		}
		if (exportButton.isEnabled()) {
			logPass("Export Button is enabled");
		} else {
			logFail("Export Button is not enabled");
		}
	}
	
	public void clickExportButton() {
		
		if (exportButton.isEnabled()) {
			isDisplayedThenClick(exportButton,"Export button");
			logPass("Export Button is clicked");
		} else {
			logFail("Export Button is not clicked");
		}
	}
}
