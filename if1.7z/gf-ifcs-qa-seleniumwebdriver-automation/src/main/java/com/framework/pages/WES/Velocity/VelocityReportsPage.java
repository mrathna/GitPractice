package com.framework.pages.WES.Velocity;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;
import com.aventstack.extentreports.ExtentTest;
import com.framework.basepage.BasePage;
import com.framework.repo.Locator_WES;

public class VelocityReportsPage extends BasePage {

	@FindBy(how = How.ID, using = Locator_WES.REPORTS_MENU)
	public WebElement reportMenu;

	@FindBy(how = How.ID, using = Locator_WES.REGULAR_TRANSREPORT)
	public WebElement standardReports;

	@FindBy(how = How.ID, using = Locator_WES.CARD_REPORT)
	public WebElement cardReport;

	@FindBy(how = How.ID, using = Locator_WES.CARDS_SELECTED_BUTTON)
	public WebElement cardSelectBtn;

	@FindBy(how = How.ID, using = Locator_WES.PREV_YEAR_BUTTON)
	public WebElement preYearBtn;

	@FindBy(how = How.ID, using = Locator_WES.DATE_RANGE_SUBMITBUTTON)
	public WebElement dateRangeSubmitBtn;

	@FindBy(how = How.ID, using = Locator_WES.SELECT_ALL_CARDS)
	public WebElement selectAllCards;

	@FindBy(how = How.ID, using = Locator_WES.TRANS_SUMMARY)
	public WebElement transSummary;

	@FindBy(how = How.ID, using = Locator_WES.TRANSACTION_INDIVIDUAL)
	public WebElement individualTransaction;

	@FindBy(how = How.ID, using = Locator_WES.TRANSACTION_EXTRACT_REPORT)
	public WebElement transactionExtractReport;

	@FindBy(how = How.ID, using = Locator_WES.MKII_REPORT)
	public WebElement mkii_report;

	@FindBy(how = How.ID, using = Locator_WES.PREV_MONTH_BTN)
	public WebElement prevMonthBtn;

	@FindBy(how = How.ID, using = Locator_WES.DOWNLOAD_EXCEL)
	public WebElement downloadExcel;

	@FindBy(how = How.ID, using = Locator_WES.DOWNLOAD_CSV)
	public WebElement downloadCSV;

	@FindBy(how = How.CSS, using = Locator_WES.OK_BUTTON)
	public WebElement searchIcon;

	@FindBy(how = How.ID, using = Locator_WES.INVOICES_MENU)
	public WebElement invoices;

	@FindBy(how = How.CSS, using = Locator_WES.INVOICES_SUBMENU)
	public WebElement invoiceSubMenu;

	@FindBy(how = How.CSS, using = Locator_WES.PAYMENT_INVOICE)
	public WebElement paymentInvoice;

	@FindBy(how = How.CSS, using = Locator_WES.SEARCH_INVOICE)
	public WebElement searchInvoice;

	@FindBy(how = How.ID, using = Locator_WES.SEARCH_DATA_RANGE)
	public WebElement searchDataRange;

	@FindBy(how = How.ID, using = Locator_WES.START_DATE)
	public WebElement startDate;

	@FindBy(how = How.ID, using = Locator_WES.END_DATE)
	public WebElement endDate;

	@FindBy(how = How.CSS, using = Locator_WES.SEARCH_INVOICE_BTN)
	public WebElement searchInvoiceBtn;

	@FindBy(how = How.CSS, using = Locator_WES.SUBMIT_DATE_BTN)
	public WebElement submitDateBtn;

	@FindBy(how = How.ID, using = Locator_WES.SEARCH_INVOICE_NUMBER)
	public WebElement searchInvoiceNum;

	@FindBy(how = How.ID, using = Locator_WES.INVOICE_NUM_TXT_BOX)
	public WebElement invoiceNumberTxtBox;

	@FindBy(how = How.ID, using = Locator_WES.QUANTITY_TEXTBOX)
	public WebElement quantityTxtBox;

	@FindBy(how = How.CSS, using = Locator_WES.SEARCH_HEADER)
	public WebElement searchHeader;

	public VelocityReportsPage(WebDriver driver, ExtentTest test) {
		super(driver, test);
		PageFactory.initElements(new AjaxElementLocatorFactory(driver, 15), this);
	}

	public void navigatingToReports() {
		sleep(2);
		isDisplayedThenActionClick(reportMenu, "reportMenu");
		verifyTitle("Reports");
	}

	public void navigatingToStandardReports() {
		sleep(2);
		isDisplayedThenActionClick(standardReports, "standardReports");
		verifyTitle("Reports");
	}

	public void navigatingToCardReport() {
		sleep(2);
		isDisplayedThenActionClick(cardReport, "cardReport");
		verifyTitle("Reports");
	}

	public void verifyingCustomerTransactions(String quantity, String cardNo) {
		navigatingToReports();
		navigatingToStandardReports();
		navigatingToCardReport();
		sleep(2);
		isDisplayedThenActionClick(selectAllCards, "selectAllCards option");
		isDisplayedThenActionClick(cardSelectBtn, "cardSelectBtn");
		sleep(2);
		JavascriptExecutor executor = (JavascriptExecutor) driver;
		executor.executeScript("arguments[0].click();", preYearBtn);
		isDisplayedThenActionClick(dateRangeSubmitBtn, "dateRangeSubmitBtn");
		sleep(2);
		isDisplayedThenActionClick(individualTransaction, "individualTransaction");
		scrollDownPage();
		takeScreenshot();
		sleep(2);
		isDisplayedThenEnterText(quantityTxtBox, "Entering quantity value", quantity);
		sleep(2);
		if (waitToCheckElementIsDisplayed(By.cssSelector("tr[class*='table-row card-pan-pack-header']>td"), 20)) {
			// isDisplayedThenActionClick(downloadExcel, "downloadExcel");
			// sleep(2);
			// isDisplayedThenActionClick(downloadCSV, "downloadCSV");
			// sleep(2);
			scrollDownPage();
			takeScreenshot();
			sleep(2);
			if (getText(searchHeader).contains(cardNo)) {
				logPass("Transaction are reflected in velocity");
			} else
				logFail("Transaction are not reflected in velocity");
		} else
			logFail("Transaction are not reflected in velocity");
	}

	public void navigatingToTransExportReport() {
		sleep(2);
		isDisplayedThenActionClick(transactionExtractReport, "transactionExtractReport");
		verifyTitle("Reports");
	}

	public void navigatingToMKIIReport() {
		sleep(2);
		isDisplayedThenActionClick(mkii_report, "mkii_report");
		verifyTitle("Reports");
	}

	public void verifyingMKIIReports() {
		navigatingToReports();
		navigatingToTransExportReport();
		navigatingToMKIIReport();
		sleep(2);
		isDisplayedThenActionClick(prevMonthBtn, "downloadExcel");
		sleep(2);
		takeScreenshot();
		sleep(1);
		isDisplayedThenActionClick(downloadExcel, "downloadExcel");
		sleep(2);
		isDisplayedThenActionClick(downloadCSV, "downloadCSV");
		sleep(2);
	}

	public void verifyingCustInvoices(String type) {
		navigatingToInvoices();
		sleep(3);
		isDisplayedThenActionClick(invoiceSubMenu, "invoiceSubMenu");
		sleep(2);
		isDisplayedThenActionClick(searchInvoice, "searchInvoice");
		sleep(2);
		if (type.equalsIgnoreCase("historic")) {
			isDisplayedThenActionClick(searchDataRange, "searchDataRange");
			sleep(2);
			isDisplayedThenEnterText(startDate, "START_DATE", "11/05/2018");
			sleep(1);
			takeScreenshot();
			sleep(2);
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", submitDateBtn);
		} else {
			isDisplayedThenActionClick(searchInvoiceNum, "searchInvoiceNum");
			sleep(1);
			isDisplayed(invoiceNumberTxtBox, "invoiceNumberTxtBox");
			sleep(2);
			isDisplayedThenEnterText(invoiceNumberTxtBox, "invoiceNumberTxtBox", type);
			takeScreenshot();
			sleep(2);
			isDisplayedThenActionClick(searchInvoiceBtn, "Search");

		}
		sleep(1);
		verifyTitle("Invoice Search Results");
		takeScreenshot();
		sleep(2);
	}

	private void navigatingToInvoices() {
		sleep(2);
		isDisplayedThenActionClick(invoices, "invoices");
		verifyTitle("Invoices");
	}

	private void navigatingToPaymentInvoices() {
		sleep(2);
		isDisplayedThenActionClick(paymentInvoice, "paymentInvoice");
		verifyTitle("Payment Advices");
	}

	public void verifyingPaymentAdvice() {
		navigatingToInvoices();
		navigatingToPaymentInvoices();
		takeScreenshot();
		sleep(2);
	}

}
