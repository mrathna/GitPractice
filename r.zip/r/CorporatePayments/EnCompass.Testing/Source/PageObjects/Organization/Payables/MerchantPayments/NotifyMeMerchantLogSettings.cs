﻿ using Common.Utility;
using EnCompass.Testing.Source.PageObjects.Controls;
using NFluent;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EnCompass.Testing.Source.PageObjects.Organization.Payables.MerchantPayments
{
    public enum MerchantLogSettings
    {
        SetCardLimitAboveMerchantLogAmountAtCurrencyLevel = 1,
        AddThisPadForEachMerchantLog = 2,
        HonorCreditInvoices = 3,
        InvoiceMatch = 4,
        CRIMatch = 5,
        AggregateInvoices = 6,
        AggregatePayMeInvoices = 7,
        ReduceCreditLimitOnMerchantLogExpiration = 8,
        ReduceCreditLimitOnMerchantLogClose = 9,
        RequireNoteWhenClosingMerchantLogs=10,
        RequireInvoice=11,
        EnableEffectiveDates=12,
        UndefinedMerchantsPurchaseLogEmailNotificationEnabled=13,
        UndefinedMerchantsEnablePurchaseLogFAXNotification=14,
        UndefinedMerchantsRequirePINforEmailedPurchaseLogs=15,
        DefinedMerchantsRequirePINforEmailedMerchantLogs=16,
		DefinedMerchantsEmailPINNotice=17,
		MaxNumOfLoginAttempts=18
    }
    public partial class NotifyMeMerchantLogSettings
    {
        #region XPath page Elements
        private const string _merchantLogExpirationXPath = @"//input[contains(@id, 'txtMLogExpDays')]";
        private const string _toggleMerchantLogExpirationXPath = @"//a[contains(@id, 'toggletxtMLogExpDays')]";
        private const string _merchantLogExpirationReminderXPath = @"//input[contains(@id, 'txtRemindersPeriod')]";
        private const string _toggleMerchantLogExpirationReminderXPath = @"//button[contains(@id, 'toggletxtRemindersPeriod')]";
        private const string _merchantLogAfterExpirationReconciliationXPath = @"//input[contains(@id, 'txtAfterExpirationReconciliation')]";
        private const string _setCardLimitAboveMLogAmountCheckboxXPath = @"//input[contains(@id, 'CardLimitIncreaseAtCurrencyLevel')]";
        private const string _setCardLimitAboveMLogAmountCheckboxLabelXPath = @"//label[contains(@for, 'CardLimitIncreaseAtCurrencyLevel')]";
        private const string _addThisPadForEachMLogCheckboxXPath = @"//input[contains(@id, 'CardLimitIncreaseIsPerMlog')]";
        private const string _addThisPadForEachMLogCheckboxLabelXPath = @"//label[contains(@for, 'CardLimitIncreaseIsPerMlog')]";
        private const string _honorCreditInvoicesCheckboxXPath = @"//input[contains(@id, 'ExactMatchHonorCreditInvoicesOverride')]";
        private const string _honorCreditInvoicesCheckboxLabelXPath = @"//label[contains(@for, 'ExactMatchHonorCreditInvoicesOverride')]";
        private const string _cardLmtAbvMLogAmtXPath = @"//input[contains(@id, '_txtCardLimitIncrease')]";
        private const string _cardLmtAbvMLogAmtDDLXPath = @"//select[contains(@id, '_ddlCardLimitIncreaseType')]";
        private const string _invoiceMatchCheckboxXPath = @"//input[contains(@id, 'cbInvoiceMatch')]";
        private const string _invoiceMatchCheckboxLabelXPath = @"//label[contains(@for, 'cbInvoiceMatch')]";
        private const string _criMatchCheckboxXPath = @"//input[contains(@id, 'CRIMatch')]";
        private const string _criMatchCheckboxLabelXPath = @"//label[contains(@for, 'CRIMatch')]";
        private const string _aggregateInvoicesCheckboxXPath = @"//input[contains(@id, '_cbAggregateInvoices')]";
        private const string _aggregateInvoicesCheckboxLabelXPath = @"//label[contains(@for, '_cbAggregateInvoices')]";
        private const string _aggregatePayMeInvoicesCheckboxXPath = @"//input[contains(@id, 'PayMeAggregateInvoices')]";
        private const string _aggregatePayMeInvoicesCheckboxLabelXPath = @"//label[contains(@for, 'PayMeAggregateInvoices')]";
        private const string _reduceCreditLimitOnMLogExpirationCheckboxXPath = @"//input[contains(@id, 'ReduceCreditLimitOnExpire')]";
        private const string _reduceCreditLimitOnMLogExpirationCheckboxLabelXPath = @"//label[contains(@for, 'ReduceCreditLimitOnExpire')]";
        private const string _reduceCreditLimitOnMLogCloseCheckboxXPath = @"//input[contains(@id, 'ReduceCreditLimitOnClose')]";
        private const string _reduceCreditLimitOnMLogCloseCheckboxLabelXPath = @"//label[contains(@for, 'ReduceCreditLimitOnClose')]";
        private const string _requireNoteWhenClosingMLogsCheckboxXPath = @"//input[contains(@id, 'CloseNoteCheckBox')]";
        private const string _requireNoteWhenClosingMLogsCheckboxLabelXPath = @"//label[contains(@for, 'CloseNoteCheckBox')]";
        private const string _requireInvoiceCheckboxXPath = @"//input[contains(@id, 'RequireInvoice')]";
        private const string _requireInvoiceCheckboxLabelXPath = @"//label[contains(@for, 'RequireInvoice')]";
        private const string _enableEffectiveDatesCheckboxXPath = @"//input[contains(@id, 'EnableEffectiveDatesCheckBox')]";
        private const string _enableEffectiveDatesCheckboxLabelXPath = @"//label[contains(@for, 'EnableEffectiveDatesCheckBox')]";
        private const string _undefinedMerchantsPLogEmailNotificationEnabledCheckboxXPath = @"//input[contains(@id, 'PlogEmailEnabled')]";
        private const string _undefinedMerchantsPLogEmailNotificationEnabledCheckboxLabelXPath = @"//label[contains(@for, 'PlogEmailEnabled')]";
        private const string _undefinedMerchantsEnablePLogFAXNotificationCheckboxXPath = @"//input[contains(@id, 'PlogFaxEnabled')]";
        private const string _undefinedMerchantsEnablePLogFAXNotificationCheckboxLabelXPath = @"//label[contains(@for, 'PlogFaxEnabled')]";
        private const string _undefinedMerchantsRequirePINforEmailedPLogsCheckboxXPath = @"//input[contains(@id, 'PlogEmailRequiresPin')]";
        private const string _maxNoOfLoginAttemptsXPath = @"//input[contains(@id, 'txtMaxNumberOfLoginAttempts')]";
        private const string _toggleMaxNoOfLoginAttemptsXPath = @"//button[contains(@id, 'toggletxtMaxNumberOfLoginAttempts')]";
        private const string _undefinedMerchantsRequirePINforEmailedPLogsCheckboxLabelXPath = @"//label[contains(@for, 'PlogEmailRequiresPin')]";
        private const string _definedMerchantsRequirePINforEmailedMLogsCheckboxXPath = @"//input[contains(@id, 'SugaEmailRequiresPin')]";
        private const string _definedMerchantsRequirePINforEmailedMLogsCheckboxLabelXPath = @"//label[contains(@for, 'SugaEmailRequiresPin')]";
        private const string _definedMerchantsEmailPINNoticeCheckBoxXPath = @"//input[contains(@id, 'cbEmailPinToDefinedMerchant')]";
        private const string _definedMerchantsEmailPINNoticeCheckBoxLabelXPath = @"//label[contains(@for, 'cbEmailPinToDefinedMerchant')]";
        private const string _autoReconcilePercentAboveXPath = @"//input[contains(@id,'txtAutoReconcilePercentAbove')]";
        private const string _autoReconcileDollarAboveXPath = @"//input[contains(@id,'txtAutoReconcileDollarsAbove')]";
        private const string _autoReconcilePercentBelowXPath = @"//input[contains(@id,'txtAutoReconcilePercentBelow')]";
        private const string _autoReconcileDollarBelowXPath = @"//input[contains(@id,'txtAutoReconcileDollarsBelow')]";
        private const string _saveXPath = @"//input[contains(@id, 'btnsubmit')]";
        private const string _mLogReconcilitationAfterExpirationXPath = @"//input[contains(@id, 'AfterExpirationReconciliationDays')]";
        private const string _cancelXPath = @"//button[text()='Cancel']";
        private const string _reduceCreditLimitOnCloseXPath = @"//input[contains(@id,'cbReduceCreditLimitOnClose')]";
        private const string _historyTabXPath = @"//button[contains(@id,'tcHistory_Tab')]";
        private const string _reduceCreditLimitOnCloseCheckboxXPath = @"//input[contains(@id,'cbReduceCreditLimitOnClose')]";
        private const string _reduceCreditLimitOnCloseCheckboxLabelXPath = @"//label[contains(@for,'cbReduceCreditLimitOnClose')]";
        private const string _toggletxtMaxNumberOfLoginAttemptsXpath = ".//div[contains(@id, 'txtMaxNumberOfLoginAttemptsContainer')]";
        private const string _faxNumXPath = ".//input[contains(@id,'tcMLogSettings_tcSettings_ctlFax_txtPhone')]";
        #endregion

        #region IwebElements Props

        public IWebElement _merchantLogExpiration
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_merchantLogExpirationXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_merchantLogExpiration element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _toggleMerchantLogExpiration
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_toggleMerchantLogExpirationXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_toggleMerchantLogExpiration element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _merchantLogExpirationReminder
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_merchantLogExpirationReminderXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_merchantLogExpirationReminder element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _toggleMerchantLogExpirationReminder
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_toggleMerchantLogExpirationReminderXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_toggleMerchantLogExpirationReminder element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _merchantLogAfterExpirationReconciliation
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_merchantLogAfterExpirationReconciliationXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_merchantLogAfterExpirationReconciliation element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _setCardLimitAboveMLogAmountCheckbox
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_setCardLimitAboveMLogAmountCheckboxXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_setCardLimitAboveMLogAmountCheckbox element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _setCardLimitAboveMLogAmountCheckboxLabel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_setCardLimitAboveMLogAmountCheckboxLabelXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_setCardLimitAboveMLogAmountCheckboxLabel element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _addThisPadForEachMLogCheckbox
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_addThisPadForEachMLogCheckboxXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_addThisPadForEachMLogCheckbox element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _addThisPadForEachMLogCheckboxLabel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_addThisPadForEachMLogCheckboxLabelXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_addThisPadForEachMLogCheckboxLabel element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _honorCreditInvoicesCheckbox
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_honorCreditInvoicesCheckboxXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_honorCreditInvoicesCheckbox element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _honorCreditInvoicesCheckboxLabel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_honorCreditInvoicesCheckboxLabelXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_honorCreditInvoicesCheckboxLabel element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _cardLmtAbvMLogAmt
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_cardLmtAbvMLogAmtXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_cardLmtAbvMLogAmt element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _cardLmtAbvMLogAmtDDL
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_cardLmtAbvMLogAmtDDLXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_cardLmtAbvMLogAmtDDL element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _invoiceMatchCheckbox
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_invoiceMatchCheckboxXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_invoiceMatchCheckbox element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _invoiceMatchCheckboxLabel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_invoiceMatchCheckboxLabelXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_invoiceMatchCheckboxLabel element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _criMatchCheckbox
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_criMatchCheckboxXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_criMatchCheckbox element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _criMatchCheckboxLabel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_criMatchCheckboxLabelXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_criMatchCheckboxLabel element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _aggregateInvoicesCheckbox
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_aggregateInvoicesCheckboxXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_aggregateInvoicesCheckbox element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _aggregateInvoicesCheckboxLabel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_aggregateInvoicesCheckboxLabelXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_aggregateInvoicesCheckboxLabel element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _aggregatePayMeInvoicesCheckbox
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_aggregatePayMeInvoicesCheckboxXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_aggregatePayMeInvoicesCheckbox element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _aggregatePayMeInvoicesCheckboxLabel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_aggregatePayMeInvoicesCheckboxLabelXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_aggregatePayMeInvoicesCheckboxLabel element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _reduceCreditLimitOnMLogExpirationCheckbox
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_reduceCreditLimitOnMLogExpirationCheckboxXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_reduceCreditLimitOnMLogExpirationCheckbox element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _reduceCreditLimitOnMLogExpirationCheckboxLabel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_reduceCreditLimitOnMLogExpirationCheckboxLabelXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_reduceCreditLimitOnMLogExpirationCheckboxLabel element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _reduceCreditLimitOnMLogCloseCheckbox
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_reduceCreditLimitOnMLogCloseCheckboxXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_reduceCreditLimitOnMLogCloseCheckbox element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _reduceCreditLimitOnMLogCloseCheckboxLabel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_reduceCreditLimitOnMLogCloseCheckboxLabelXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_reduceCreditLimitOnMLogCloseCheckboxLabel element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _requireNoteWhenClosingMLogsCheckbox
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_requireNoteWhenClosingMLogsCheckboxXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_requireNoteWhenClosingMLogsCheckbox element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _requireNoteWhenClosingMLogsCheckboxLabel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_requireNoteWhenClosingMLogsCheckboxLabelXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_requireNoteWhenClosingMLogsCheckboxLabel element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _requireInvoiceCheckbox
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_requireInvoiceCheckboxXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_requireInvoiceCheckbox element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        public IWebElement _requireInvoiceCheckboxLabel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_requireInvoiceCheckboxLabelXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_requireInvoiceCheckboxLabel element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _enableEffectiveDatesCheckbox
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_enableEffectiveDatesCheckboxXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_enableEffectiveDatesCheckbox element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _enableEffectiveDatesCheckboxLabel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_enableEffectiveDatesCheckboxLabelXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_enableEffectiveDatesCheckboxLabel element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _undefinedMerchantsPLogEmailNotificationEnabledCheckbox
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_undefinedMerchantsPLogEmailNotificationEnabledCheckboxXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_undefinedMerchantsPLogEmailNotificationEnabledCheckbox element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _undefinedMerchantsPLogEmailNotificationEnabledCheckboxLabel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_undefinedMerchantsPLogEmailNotificationEnabledCheckboxLabelXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_undefinedMerchantsPLogEmailNotificationEnabledCheckboxLabel element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _undefinedMerchantsEnablePLogFAXNotificationCheckbox
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_undefinedMerchantsEnablePLogFAXNotificationCheckboxXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_undefinedMerchantsEnablePLogFAXNotificationCheckbox element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        public IWebElement _undefinedMerchantsEnablePLogFAXNotificationCheckboxLabel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_undefinedMerchantsEnablePLogFAXNotificationCheckboxLabelXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_undefinedMerchantsEnablePLogFAXNotificationCheckboxLabel element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _undefinedMerchantsRequirePINforEmailedPLogsCheckbox
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_undefinedMerchantsRequirePINforEmailedPLogsCheckboxXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_undefinedMerchantsRequirePINforEmailedPLogsCheckbox element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _maxNoOfLoginAttempts
        {
            get
            {
                //TryWaitForElementToBeVisible fails for _maxNoOfLoginAttemptsXPath input control because it is disabled hence replaced with TryWaitForElement
                bool found = Driver.TryWaitForElement(By.XPath(_maxNoOfLoginAttemptsXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_maxNoOfLoginAttempts element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _toggleMaxNoOfLoginAttempts
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_toggleMaxNoOfLoginAttemptsXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_toggleMaxNoOfLoginAttempts element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _undefinedMerchantsRequirePINforEmailedPLogsCheckboxLabel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_undefinedMerchantsRequirePINforEmailedPLogsCheckboxLabelXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_undefinedMerchantsRequirePINforEmailedPLogsCheckboxLabel element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _definedMerchantsRequirePINforEmailedMLogsCheckbox
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_definedMerchantsRequirePINforEmailedMLogsCheckboxXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_definedMerchantsRequirePINforEmailedMLogsCheckbox element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _definedMerchantsRequirePINforEmailedMLogsCheckboxLabel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_definedMerchantsRequirePINforEmailedMLogsCheckboxLabelXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_definedMerchantsRequirePINforEmailedMLogsCheckboxLabel element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _definedMerchantsEmailPINNoticeCheckBox
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_definedMerchantsEmailPINNoticeCheckBoxXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_definedMerchantsEmailPINNoticeCheckBox element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _definedMerchantsEmailPINNoticeCheckBoxLabel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_definedMerchantsEmailPINNoticeCheckBoxLabelXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_definedMerchantsEmailPINNoticeCheckBoxLabel element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _autoReconcilePercentAbove
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_autoReconcilePercentAboveXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_autoReconcilePercentAbove element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _autoReconcileDollarAbove
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_autoReconcileDollarAboveXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_autoReconcileDollarAbove element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _autoReconcilePercentBelow
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_autoReconcilePercentBelowXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_autoReconcilePercentBelow element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _save
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_saveXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_save element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _cancel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_cancelXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_cancel element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _reduceCreditLimitOnClose
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_reduceCreditLimitOnCloseXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_reduceCreditLimitOnClose element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _historyTab
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_historyTabXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_historyTab element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
      
        public IWebElement _mLogReconcilitationAfterExpiration
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_mLogReconcilitationAfterExpirationXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_mLogReconcilitationAfterExpiration element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _autoReconcileDollarBelow
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_autoReconcileDollarBelowXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_autoReconcileDollarBelow element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _reduceCreditLimitOnCloseCheckbox
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_reduceCreditLimitOnCloseCheckboxXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_reduceCreditLimitOnCloseCheckbox element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _reduceCreditLimitOnCloseCheckboxLabel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_reduceCreditLimitOnCloseCheckboxLabelXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_reduceCreditLimitOnCloseCheckboxLabel element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _faxNum
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_faxNumXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_faxNum element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        #endregion

        public string MerchantLogExpiration
		{
			set
			{
				_merchantLogExpiration.Clear();
				_merchantLogExpiration.SendKeys(value);
            }
		}

		public string MerchantLogExpirationReminder
		{
			set
			{
                _toggleMerchantLogExpirationReminder.JSClickWithFocus(Driver);
				_merchantLogExpirationReminder.Clear();
				_merchantLogExpirationReminder.SendKeys(value);
                _toggleMerchantLogExpirationReminder.JSClickWithFocus(Driver);
            }
		}        

		
        public string MerchantLogReconciliationAfterExpiration
        {
            set
            {
                _mLogReconcilitationAfterExpiration.Clear();
                _mLogReconcilitationAfterExpiration.SendKeys(value);
            }
        }

		
		public string MaxNumLoginAttempts
		{
			set
			{
				try
				{
					if (_maxNoOfLoginAttempts.GetAttribute("disabled").Equals("disabled"))
					{
						Settings.EnCompassExtentTest.Warning("Setting Max Login Attempts is disabled, could not set value :" + value);
					}
				}
				catch (Exception)
				{
					//check to see if the toggle has been fliped to allow input
					if (Driver.IsElementPresent(By.XPath(_toggletxtMaxNumberOfLoginAttemptsXpath + "//div[contains(@class, 'min-slider-handle round')] "))) 
					{
						IWebElement _toggletxtMaxNumberOfLoginAttempts = Driver.WaitForVisible(By.XPath(_toggletxtMaxNumberOfLoginAttemptsXpath));
						_toggletxtMaxNumberOfLoginAttempts.JSClickWithFocus(Driver);
						Settings.EnCompassExtentTest.Info("Toggled Max Login Attempts from slider to text field input.");
					}
					Driver.WaitForDocumentLoadToComplete();

                    ToggleMaxNoOfLoginAttemptsClick();
					_maxNoOfLoginAttempts.Clear();
					_maxNoOfLoginAttempts.SendKeys(value);
					Settings.EnCompassExtentTest.Info("Setting Max Login Attempts :" + value);
				}
			}
			get
			{
				return _maxNoOfLoginAttempts.GetAttribute("value");
			}
		}

		public string FaxNumber
		{
			get
			{
				return _faxNum.GetAttribute("value");
			}
			set
			{
				_faxNum.Clear();
                _faxNum.SendKeys(value);
				Settings.EnCompassExtentTest.Info("Set Fax No = " + value);
			}
		}


		public string AutoReconcilePercentAbove
		{
			set
			{
				_autoReconcilePercentAbove.Clear();
				_autoReconcilePercentAbove.SendKeys(value);
			}
		}

		public string AutoReconcileDollarAbove
		{
			set
			{
				_autoReconcileDollarAbove.Clear();
				_autoReconcileDollarAbove.SendKeys(value);
			}
		}

		public bool HonorCreditInvoices
		{
			set
			{
				_honorCreditInvoicesCheckbox.SetCheckboxStateWithLabel( _honorCreditInvoicesCheckboxLabel,value);
			}
		}

		public bool AggregateInvoices
		{
			set
			{
				_aggregateInvoicesCheckbox.SetCheckboxStateWithLabel(_aggregateInvoicesCheckboxLabel , value);
			}
		}

		public bool EnableEffectiveDates
		{
			set
			{
				_enableEffectiveDatesCheckbox.SetCheckboxStateWithLabel(_enableEffectiveDatesCheckboxLabel, value);
			}
		}

		public bool ReduceCreditLimitOnMLogClose
		{
			set
			{
				_reduceCreditLimitOnCloseCheckbox.SetCheckboxStateWithLabel(_reduceCreditLimitOnCloseCheckboxLabel, value);
			}
		}

		public string AutoReconcilePercentBelow
		{
			set
			{
				_autoReconcilePercentBelow.Clear();
				_autoReconcilePercentBelow.SendKeys(value);
			}
		}
		public string AutoReconcileDollarBelow
		{
			set
			{
				_autoReconcileDollarBelow.Clear();
				_autoReconcileDollarBelow.SendKeys(value);
			}
		}
			
		public string CardLimitAboveMLogAmount
		{
			set
			{
				_cardLmtAbvMLogAmt.Clear();
				_cardLmtAbvMLogAmt.SendKeys(value);
			}
		}

		public string CardLimitAboveMLogIncreaseType
		{
			set
			{
				new SelectElement(_cardLmtAbvMLogAmtDDL).SelectByText(value);
			}
			get
			{
				return new SelectElement(_cardLmtAbvMLogAmtDDL).SelectedOption.Text;
			}
		}

		public void SetInvoiceMatchCheckBox(bool state)
		{
			_invoiceMatchCheckbox.SetCheckboxStateWithLabel(_invoiceMatchCheckboxLabel ,state);
		}

		public void SaveClick()
		{			
			// Firefox related change
			_save.JSClickWithFocus(Driver, _saveXPath, Settings);
			// At times modal would appear due to one or more merchants configured for separate invoices
			// hence confirm on modal call is added
			ConfirmOnModal(null, 15);
			this.AttachOnDemandScreenShot();
			Settings.EnCompassExtentTest.Info("Clicked on Save button in Mlog Setting Page");
		}

        public void ToggleMaxNoOfLoginAttemptsClick()
        {
            _toggleMaxNoOfLoginAttempts.JSClickWithFocus(Driver);

            Settings.EnCompassExtentTest.Info("Clicked on Toggle Max Login Attempts button in Mlog Setting Page");
        }

        public void CancelClick()
        {
            _cancel.JSClickWithFocus(Driver);
            WaitForLoad();
        }
		
        public void SetReduceCreditLimitExpiration(bool state)
        {
            _reduceCreditLimitOnMLogExpirationCheckbox.SetCheckboxStateWithLabel(_reduceCreditLimitOnMLogExpirationCheckboxLabel ,state);
        }

		public void UpdateSetting(MerchantLogSettings setting, bool checkStatus)
        {
            switch(setting)
            {
                case MerchantLogSettings.SetCardLimitAboveMerchantLogAmountAtCurrencyLevel:
					_setCardLimitAboveMLogAmountCheckbox.SetCheckboxStateWithLabel(_setCardLimitAboveMLogAmountCheckboxLabel,checkStatus);
                    break;
                case MerchantLogSettings.AddThisPadForEachMerchantLog:
					_addThisPadForEachMLogCheckbox.SetCheckboxStateWithLabel(_addThisPadForEachMLogCheckboxLabel,checkStatus);
                    break;
                case MerchantLogSettings.HonorCreditInvoices:
					_honorCreditInvoicesCheckbox.SetCheckboxStateWithLabel(_honorCreditInvoicesCheckboxLabel,checkStatus);
                    break;
                case MerchantLogSettings.InvoiceMatch:
					_invoiceMatchCheckbox.SetCheckboxStateWithLabel(_invoiceMatchCheckboxLabel,checkStatus);
                    WaitForLoad();
                    break;
                case MerchantLogSettings.CRIMatch:
					_criMatchCheckbox.SetCheckboxStateWithLabel(_criMatchCheckboxLabel,checkStatus);
					WaitForLoad();
                    break;
                case MerchantLogSettings.AggregateInvoices:
					_aggregateInvoicesCheckbox.SetCheckboxStateWithLabel(_aggregateInvoicesCheckboxLabel,checkStatus);
                    break;
                case MerchantLogSettings.AggregatePayMeInvoices:
					_aggregatePayMeInvoicesCheckbox.SetCheckboxStateWithLabel(_aggregatePayMeInvoicesCheckboxLabel,checkStatus);
                    break;
                case MerchantLogSettings.ReduceCreditLimitOnMerchantLogExpiration:
					_reduceCreditLimitOnMLogExpirationCheckbox.SetCheckboxStateWithLabel(_reduceCreditLimitOnMLogExpirationCheckboxLabel,checkStatus);
                    break;
                case MerchantLogSettings.ReduceCreditLimitOnMerchantLogClose:
					_reduceCreditLimitOnMLogCloseCheckbox.SetCheckboxStateWithLabel(_reduceCreditLimitOnMLogCloseCheckboxLabel,checkStatus);
                    break;
                case MerchantLogSettings.RequireNoteWhenClosingMerchantLogs:
					_requireNoteWhenClosingMLogsCheckbox.SetCheckboxStateWithLabel(_requireNoteWhenClosingMLogsCheckboxLabel,checkStatus);
                    break;
                case MerchantLogSettings.RequireInvoice:
					_requireInvoiceCheckbox.SetCheckboxStateWithLabel(_requireInvoiceCheckboxLabel,checkStatus);
                    break;
                case MerchantLogSettings.EnableEffectiveDates:
					_enableEffectiveDatesCheckbox.SetCheckboxStateWithLabel(_enableEffectiveDatesCheckboxLabel,checkStatus);
                    break;
                case MerchantLogSettings.UndefinedMerchantsPurchaseLogEmailNotificationEnabled:
					_undefinedMerchantsPLogEmailNotificationEnabledCheckbox.SetCheckboxStateWithLabel(_undefinedMerchantsPLogEmailNotificationEnabledCheckboxLabel,checkStatus);
                    break;
                case MerchantLogSettings.UndefinedMerchantsEnablePurchaseLogFAXNotification:
					_undefinedMerchantsEnablePLogFAXNotificationCheckbox.SetCheckboxStateWithLabel(_undefinedMerchantsEnablePLogFAXNotificationCheckboxLabel,checkStatus);
                    break;
                case MerchantLogSettings.UndefinedMerchantsRequirePINforEmailedPurchaseLogs:
					_undefinedMerchantsRequirePINforEmailedPLogsCheckbox.SetCheckboxStateWithLabel(_undefinedMerchantsRequirePINforEmailedPLogsCheckboxLabel,checkStatus);
                    break;
                case MerchantLogSettings.DefinedMerchantsRequirePINforEmailedMerchantLogs:
					_definedMerchantsRequirePINforEmailedMLogsCheckbox.SetCheckboxStateWithLabel(_definedMerchantsRequirePINforEmailedMLogsCheckboxLabel,checkStatus);
					WaitForLoad();
                    break;
				case MerchantLogSettings.DefinedMerchantsEmailPINNotice:
					_definedMerchantsEmailPINNoticeCheckBox.SetCheckboxStateWithLabel(_definedMerchantsEmailPINNoticeCheckBoxLabel, checkStatus);
					break;
            }

            Settings.EnCompassExtentTest.Info($"Checkbox {setting} status set to {checkStatus}");
        }

        private GridControl _settingsHistory;
        public GridControl MlogSettingsHistoryGrid
        {
            get
            {
                GridControl grid = _settingsHistory ?? (_settingsHistory = new GridControl("HistoryDataGrid", Driver));
                grid.WaitForGrid();
                return grid;
            }
        }

        public void VerifySettingsHistory(string mlogExp, string mlogRemNot, string mlogRecThres, string cardLimit)
        {
            _historyTab.JSClickWithFocus(Driver);
            var Expiration = MlogSettingsHistoryGrid.GetRowContaining("Merchant Log Expiration Days").FindElement(By.XPath("./td[3]"));
            string ExpirationValue = Expiration.Text;
            Check.That(ExpirationValue).Equals(mlogExp);
            var Reminder = MlogSettingsHistoryGrid.GetRowContaining("Merchant Log Reminders Period").FindElement(By.XPath("./td[3]"));
            string ReminderValue = Reminder.Text;
            Check.That(ReminderValue).Equals(mlogRemNot);
            var Reconcile = MlogSettingsHistoryGrid.GetRowContaining("Auto Reconcile Percent Above").FindElement(By.XPath("./td[3]"));
            string ReconcileValue = Reconcile.Text;
            Check.That(ReconcileValue).Equals(mlogRecThres);
            var CardLimit = MlogSettingsHistoryGrid.GetRowContaining("Card Limit Increase Amount").FindElement(By.XPath("./td[3]"));
            string CardLimitValue = CardLimit.Text;
            Check.That(CardLimitValue).Equals(cardLimit);

        }

        public string GetValidationMessages
        {
            get { return Settings.EnCompassWebDriver.WaitForVisible(By.XPath("//div[contains(@id,'ValidationSummary')]")).Text; }
        }       
    }
}
