package com.framework.testcases.OLS.CHEV.Customer.ReadWrite;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.CHEV.CHBulkCardOrderPage;
import com.framework.pages.CHEV.CHBulkCardUpdatePage;
import com.framework.pages.CHEV.CHCardListPage;
import com.framework.pages.CHEV.CHChangeCardReplacePage;
import com.framework.pages.CHEV.CHHomePage;
import com.framework.pages.CHEV.CHOrderCardPage;
import com.framework.pages.CHEV.CHViewCardPage;
import com.framework.pages.OLS.common.LoginPage;

public class ValidateOLSCardsMenu extends BaseTest {
	@Parameters({ "clientCountry", "clientName" })
	@Test(priority = 1)
	public void testCustomerReadWriteOLSCardsMenu(@Optional("SG") String clientCountry,
			@Optional("CHV") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  Read or Write OLS - Cards menu", "Chevron Customer Screens Read or Write");

		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		if (clientCountry.equals("SG")||clientCountry.equals("MY")||clientCountry.equals("HK")) {
			loginPage.Login("CHV_URL", "CHV_Customer_UN_RW_ONLY_"+clientCountry, "CHV_Customer_PWD_RW_ONLY_"+clientCountry, "CHV");
		} else if (clientCountry.equals("TH")) {
			loginPage.Login("CHV_URL", "CHV_Customer_UN_"+clientCountry, "CHV_Customer_PWD_"+clientCountry, "CHV");
		} else if (clientCountry.equals("PH")) {
			loginPage.Login("CHV_URL", "CHV_Customer_UN_"+clientCountry, "CHV_Customer_PWD_"+clientCountry, "CHV");
		}

		CHHomePage chHomePage = new CHHomePage(driver, test);
		CHCardListPage cardListPage = new CHCardListPage(driver, test);
		CHOrderCardPage chOrderCardPage = new CHOrderCardPage(driver, test);
		CHViewCardPage chViewCardPage = new CHViewCardPage(driver, test);
		CHBulkCardOrderPage chBulkCardOrderPage = new CHBulkCardOrderPage(driver, test);
		CHBulkCardUpdatePage chBulkCardUpdatePage = new CHBulkCardUpdatePage(driver, test);
		CHChangeCardReplacePage chChangeCardReplacePage = new CHChangeCardReplacePage(driver, test);

		chHomePage.loadFindAndOrderCardPage();
		chOrderCardPage.verifyOrderCardPageTitle();
		chOrderCardPage.verifyOrderCardSubSections();
		chOrderCardPage.createANewCard();

		chHomePage.loadFindAndUpdateCardPage();
		cardListPage.verifySearchButton();
		cardListPage.verifyExportButton();
		cardListPage.verifyPageSubTitles();

		// Find Cards
		chHomePage.loadFindAndUpdateCardPage();
		cardListPage.verifySearchButton();
		cardListPage.verifyExportButton();
		cardListPage.verifyPageSubTitles();
		cardListPage.clickSearchCard();
		cardListPage.verifyCardlistSearchtableHeaders();
		String cardResult = cardListPage.getActiveCardNumber();
		if (cardResult != null) {
			cardListPage.enterCardNumber(cardResult);
			cardListPage.clickSearchCard();
			cardListPage.clickFirstCardNumberFromCardsList();
			cardListPage.pickCardDetailsOption();
			cardListPage.verifyViewCardPage();
			//chViewCardPage.verifySubTitles();
			// chViewCardPage.verifyReadOnlyMode();
			chViewCardPage.navigateBacktoCardList();
		} else {
			System.out.println("No Card Result found to Proceed");
		}

		// Change PIN

		// Replace Cards
		chHomePage.loadFindAndUpdateCardPage();
		if (cardResult != null) {
			cardListPage.enterCardNumber(cardResult);
			cardListPage.clickSearchCard();
			cardListPage.clickFirstCardNumberFromCardsList();
			cardListPage.pickReplaceCardOption();
			chChangeCardReplacePage.verifyReplaceCardStatusPage();
			chChangeCardReplacePage.navigateBacktoCardList();
		}

		chHomePage.loadFindAndBulkOrderPage();
		chBulkCardOrderPage.verifyDownloadButton();
		chBulkCardOrderPage.verifyUploadButton();
		chHomePage.loadFindAndBulkUpdatePage();
		chBulkCardUpdatePage.verifyDownloadButton();
		chBulkCardUpdatePage.verifyUploadButton();
		
		loginPage.Logout();

	}

}
