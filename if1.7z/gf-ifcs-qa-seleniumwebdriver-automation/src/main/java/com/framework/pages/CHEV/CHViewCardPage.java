package com.framework.pages.CHEV;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.ExtentTest;
import com.framework.basepage.BasePage;
import com.framework.repo.Locator;

public class CHViewCardPage extends BasePage {

	@FindBy(how = How.XPATH, using = Locator.CH_TRANSACTION_LIST_TITLE)
	public WebElement viewCardPageTitle;

	@FindBy(how = How.ID, using = Locator.CH_VIEW_CARD_NUMBER_TITLE)
	public WebElement cardNumberSubTitle;

	@FindBy(how = How.ID, using = Locator.CH_VIEW_LICENSE_NO_TITLE)
	public WebElement licenseNumberSubTitle;

	@FindBy(how = How.ID, using = Locator.CH_VIEW_DRIVER_NAME_TITLE)
	public WebElement driverNameSubTitle;

	@FindBy(how = How.ID, using = Locator.CH_VIEW_CARD_CENTRE_TITLE)
	public WebElement costCentreSubTitle;

	@FindBy(how = How.ID, using = Locator.CH_VIEW_CARD_CARD_STATUS_TITLE)
	public WebElement cardStatusSubTitle;

	@FindBy(how = How.ID, using = Locator.CH_VIEW_CARD_CARD_TYPE_TITLE)
	public WebElement cardTypeSubTitle;

	@FindBy(how = How.ID, using = Locator.CH_VIEW_CARD_CARD_EXPIRY_TITLE)
	public WebElement cardExpiryTitle;
	@FindBy(how = How.XPATH, using = Locator.CH_VIEW_CARD_POS_PROMPTS_TITLE)
	public WebElement posPromptsTitle;

	@FindBy(how = How.ID, using = Locator.CH_VIEW_CARD_PIN_TITLE)
	public WebElement cardPinTitle;

	@FindBy(how = How.XPATH, using = Locator.CH_VIEW_CARD_ODOMETER_TITLE)
	public WebElement odometerTitle;

	@FindBy(how = How.XPATH, using = Locator.CH_VIEW_CARD_PURCHASE_CONTROLS_TITLE)
	public WebElement purchaseControlsTitle;

	@FindBy(how = How.XPATH, using = Locator.CH_VIEW_CARD_TIME_LIMIT_TITLE)
	public WebElement timeLimitTitle;

	@FindBy(how = How.ID, using = Locator.CH_VIEW_CARD_VEHICLE_DESC_TITLE)
	public WebElement vehicleDescSubTitle;

	@FindBy(how = How.ID, using = Locator.CH_VIEW_LICENSE_NO_TITLE)
	public WebElement licenseNumTitle;

	@FindBy(how = How.XPATH, using = Locator.CH_VIEW_CARD_MONTHLY_DOLLAR_LIMIT)
	public WebElement monthlyDollarLimit;

	@FindBy(how = How.XPATH, using = Locator.CH_VIEW_CARD_DAILY_TRANS_LIMIT)
	public WebElement dailyTransLimit;

	@FindBy(how = How.XPATH, using = Locator.CH_VIEW_CARD_DAILY_DOLLAR_LIMIT)
	public WebElement dailyDollarLimit;

	@FindBy(how = How.XPATH, using = Locator.CH_VIEW_CARD_MONTHLY_VOLUME_LIMIT)
	public WebElement monthlyVolumeLimit;

	@FindBy(how = How.XPATH, using = Locator.CH_VIEW_CARD_DAILY_VOLUME_LIMIT)
	public WebElement dailyVolumeLimit;

	@FindBy(how = How.XPATH, using = Locator.CH_VIEW_CARD_TRANS_VOLUME_LIMIT)
	public WebElement transVolumeLimit;

	@FindBy(how = How.XPATH, using = Locator.CH_VIEW_CARD_TRANS_DOLLAR_LIMIT)
	public WebElement transDollarLimit;

	@FindBy(how = How.ID, using = Locator.CH_VIEW_CARD_BACK_BUTTON)
	public WebElement backToCardList;

	public CHViewCardPage(WebDriver driver, ExtentTest test) {
		super(driver, test);
		PageFactory.initElements(driver, this);
	}

	public void verifyCardPageTitle() {
		sleep(3);
		isDisplayed(viewCardPageTitle, "Cards page");
		logPass("Redirected to the View Cards Page");

	}

	public void verifySubTitles() {

		if (cardNumberSubTitle.isDisplayed()) {
			logPass("Card Number is displayed");
		} else {
			logFail("Card Number is not displayed");
		}
		if (licenseNumberSubTitle.isDisplayed()) {
			logPass("License Number is displayed");
		} else {
			logFail("License Number is not displayed");
		}

	//	if (driverNameSubTitle.isDisplayed()) {
	//		logPass("Driver Name is displayed");
	//	} else {
	//		logFail("Driver Name is not displayed");
	//	}

		if (costCentreSubTitle.isDisplayed()) {
			logPass("Cost Centre is displayed");
		} else {
			logFail("Cost Centre is not displayed");
		}

		if (cardStatusSubTitle.isDisplayed()) {
			logPass("Card Status is displayed");

		} else {
			logFail("Card Status is not displayed");
		}

		if (cardTypeSubTitle.isDisplayed()) {
			logPass("Card Type is displayed");
		} else {
			logFail("Card Type is not displayed");
		}

		if (cardExpiryTitle.isDisplayed()) {
			logPass("Card Expiry is displayed");
		} else {
			logFail("Card Expiry is not displayed");
		}

		if (posPromptsTitle.isDisplayed()) {
			logPass("POS PROMPTS is displayed");
		} else {
			logFail("POS PROMPTS is not displayed");
		}

		if (cardPinTitle.isDisplayed()) {
			logPass("Card PIN is displayed");
		} else {
			logFail("Card PIN is not displayed");
		}

		if (odometerTitle.isDisplayed()) {
			logPass("Odometer is displayed");
		} else {
			logFail("Odometer is not displayed");
		}

//		if (purchaseControlsTitle.isDisplayed()) {
//			logPass("Purchase Controls is displayed");
//		} else {
//			logFail("Purchase Controls is not displayed");
//		}

//		if (timeLimitTitle.isDisplayed()) {
//			logPass("Time Limit is displayed");
//		} else {
//			logFail("Time Limit is not displayed");
//		}

		if (vehicleDescSubTitle.isDisplayed()) {
			logPass("Vehicle Description is displayed");
		} else {
			logFail("Vehicle Description is not displayed");
		}

		if (licenseNumTitle.isDisplayed()) {
			logPass("License Number is displayed");
		} else {
			logFail("License Number is not displayed");
		}
	}

	public void verifyReadOnlyMode() {

		if (monthlyDollarLimit.isEnabled()) {
			logPass("Monthly Dollar Limit is not enabled");
		} else {
			logFail("Monthly Dollar Limit is enabled");
		}

		if (dailyTransLimit.isEnabled()) {
			logPass("Daily Trans Limit is not enabled");
		} else {
			logFail("Daily Trans Limit is enabled");
		}

		if (dailyDollarLimit.isEnabled()) {
			logPass("Daily Dollar Limit is not enabled");
		} else {
			logFail("Daily Dollar Limit is enabled");
		}

		if (monthlyVolumeLimit.isEnabled()) {
			logPass("Monthly Volume Limit is not enabled");
		} else {
			logFail("Monthly Volume Limit is enabled");
		}

		if (dailyVolumeLimit.isEnabled()) {
			logPass("Daily Volume Limit is not enabled");
		} else {
			logFail("Daily Volume Limit is enabled");
		}

		if (transVolumeLimit.isEnabled()) {
			logPass("Trans Volume Limit is not enabled");
		} else {
			logFail("Trans Volume Limit is enabled");
		}

		if (transDollarLimit.isEnabled()) {
			logPass("Trans Dollar Limit is not enabled");
		} else {
			logFail("Trans Dollar Limit is enabled");
		}

	}

	public void navigateBacktoCardList() {
		if (backToCardList.isDisplayed()) {
			actionClick(backToCardList);
		}
		sleep(3);
	}
}
