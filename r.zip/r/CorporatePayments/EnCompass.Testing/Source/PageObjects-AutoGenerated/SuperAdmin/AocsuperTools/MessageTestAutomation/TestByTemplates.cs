using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using Common;
using Common.PageObjects;
using Common.ScenarioConfigurations;
using Common.Utility;

namespace EnCompass.Testing.Source.PageObjects.SuperAdmin.AocsuperTools.MessageTestAutomation 
{
	/// <summary>
	/// Auto-generated Page Model Class
	/// Navigation Paths: 
		/// [Organization Home]->Super Admin Tools->Messages->Test by Template
		/// </summary>
	[PageModel(@"/superAdmin/AOCSuperTools/MessageTestAutomation/TestByTemplates.aspx")]
	public partial class TestByTemplates : EnCompassSuperPageModel 
	{
		public override string RelativeUrl => @"/superAdmin/AOCSuperTools/MessageTestAutomation/TestByTemplates.aspx";
		public override string PageIdentifierXPath_Generated => @"//li[contains(@class, 'breadcrumb-item active')][text() = 'Test by Template']";

		#region Navigation
				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Search']")]
		private IWebElement _superAdminTools_Messages_TestByTemplate_Search { get; set; }
		public void NavigateTo_SuperAdminTools_Messages_TestByTemplate_Search()
		{
			NavigateToMenuItem(_superAdminTools_Messages_TestByTemplate_Search);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Render Message']")]
		private IWebElement _superAdminTools_Messages_TestByTemplate_RenderMessage { get; set; }
		public void NavigateTo_SuperAdminTools_Messages_TestByTemplate_RenderMessage()
		{
			NavigateToMenuItem(_superAdminTools_Messages_TestByTemplate_RenderMessage);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Test by Template']")]
		private IWebElement _superAdminTools_Messages_TestByTemplate_TestByTemplate { get; set; }
		public void NavigateTo_SuperAdminTools_Messages_TestByTemplate_TestByTemplate()
		{
			NavigateToMenuItem(_superAdminTools_Messages_TestByTemplate_TestByTemplate);
		}

		
		private void NavigateToMenuItem(IWebElement element)
		{
			Driver.Url = element.GetAttribute("href");
		}
		#endregion

		public TestByTemplates(GlobalSettings settings) : base(settings) { }
	}  
}
