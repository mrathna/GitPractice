﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Common.Utility
{
	public static class Tools
	{
		/// <summary>
		/// This method will return the Date by adding/subtracting the daysToAdd in the appropriate format based on FourDigitYear and LeadingZeros.
		/// </summary>
		/// <param name="daysToAdd">Number</param>
		/// <param name="fourDigitYear">True/False</param>
		/// <param name="leadingZeros">True/False</param>
		/// <returns></returns>
		public static string GetDateFromToday(int daysToAdd, bool fourDigitYear, bool leadingZeros)
		{
			if (fourDigitYear == true)
			{
				if (leadingZeros == true)
				{
					return System.DateTime.Today.AddDays(daysToAdd).ToString("MM/dd/yyyy");
				}
				else
				{
					return System.DateTime.Today.AddDays(daysToAdd).ToString("M/d/yyyy");
				}
			}
			else
			{
				if (leadingZeros == true)
				{
					return System.DateTime.Today.AddDays(daysToAdd).ToString("MM/dd/yy");
				}
				else
				{
					return System.DateTime.Today.AddDays(daysToAdd).ToString("M/d/yy");
				}
			}
		}

		/// <summary>
		/// This method returns TODAY's Date without timestamp in various FORMATS.
		/// </summary>
		/// <param name="format"></param>
		/// <returns></returns>
		public static string GetTodaysDate(string format = "YMD")
		{
			string myDate = "";
			if (format.Equals("YMD", StringComparison.InvariantCultureIgnoreCase))
				myDate = System.DateTime.Today.ToString("yyyyMMdd");
			else if (format.Equals("YDM", StringComparison.InvariantCultureIgnoreCase))
				myDate = System.DateTime.Today.ToString("yyyyddMM");
			else if (format.Equals("MDY", StringComparison.InvariantCultureIgnoreCase))
				myDate = System.DateTime.Today.ToString("MMddyyyy");
			else if (format.Equals("MYD", StringComparison.InvariantCultureIgnoreCase))
				myDate = System.DateTime.Today.ToString("MMyyyydd");
			else if (format.Equals("DYM", StringComparison.InvariantCultureIgnoreCase))
				myDate = System.DateTime.Today.ToString("ddyyyyMM");
			else if (format.Equals("DMY", StringComparison.InvariantCultureIgnoreCase))
				myDate = System.DateTime.Today.ToString("ddMMyyyy");

			return myDate;
		}

		/// <summary>
		/// This method returns the FIRST DAY of the month based on the passed NUMBER OF MONTHS FROM TODAY.
		/// </summary>
		/// <param name="whichMonthFromToday"></param>
		/// <returns></returns>
		public static string GetFirstDayOfTheMonth(int whichMonthFromToday)
		{ 
			return System.DateTime.Today.AddMonths(whichMonthFromToday).AddDays(-System.DateTime.Today.AddMonths(whichMonthFromToday).Day + 1).ToString("MM/dd/yyyy");
		}

		/// <summary>
		/// This method returns the LAST DAY of the month based on the passed NUMBER OF MONTHS FROM TODAY.
		/// </summary>
		/// <param name="whichMonthFromToday"></param>
		/// <returns></returns>
		public static string GetLastDayOfTheMonth(int whichMonthFromToday)
		{
			return System.DateTime.Today.AddMonths(whichMonthFromToday+1).AddDays(-System.DateTime.Today.AddMonths(whichMonthFromToday+1).Day).ToString("MM/dd/yyyy"); 
		}

		/// <summary>
		/// This method returns the EXACT MONTH AND DAY based on the passed NUMBER OF MONTHS FROM TODAY & HOW MANY DAYS INTO THE MONTH.
		/// </summary>
		/// <param name="whichMonthFromToday"></param>
		/// <param name="howManyDaysIntoTheMonth"></param>
		/// <returns></returns>
		public static string GetMonthAndDayOfTheMonth(int whichMonthFromToday, int howManyDaysIntoTheMonth)
		{
			return System.DateTime.Today.AddMonths(whichMonthFromToday+1).AddDays(-System.DateTime.Today.AddMonths(whichMonthFromToday+1).Day).AddDays(howManyDaysIntoTheMonth).ToString("MM/dd/yyyy");
		}

		/// <summary>
		/// This method returns ONLY THE MONTH AND DAY by adding/subtracting the daysToAdd in the MMDD or MD format based on LeadingZeros.
		/// </summary>
		/// <param name="daysToAdd"></param>
		/// <param name="leadingZeros"></param>
		/// <returns></returns>
		public static string GetDayMonth(int daysToAdd, bool leadingZeros)
		{
			if(leadingZeros == true)
			{
				return System.DateTime.Today.AddDays(daysToAdd).ToString("MMdd");
			}
			else
			{
				return System.DateTime.Today.AddDays(daysToAdd).ToString("M/d");
			}
		}

		/// <summary>
		/// This method returns the current TIME portion. The return format is dependent on the passed format. If it doesn't match : or - or , then by default this returns HHmmss.
		/// </summary>
		/// <param name="whichFormat"></param>
		/// <returns></returns>
		public static string CurrentTime(char whichFormat)
		{
			if (whichFormat == ':')
			{
				return System.DateTime.Now.ToString("HH:mm:ss");
			}
			else if (whichFormat == '-')
			{
				return System.DateTime.Now.ToString("HH-mm-ss");
			}
			else if (whichFormat == ',')
			{
				return System.DateTime.Now.ToString("HH,mm,ss");
			}
			else
			{
				return System.DateTime.Now.ToString("HHmmss");
			}
		}


		public static string FindLatestFile(string folder, string filePattern = "*.*", TimeSpan? since = null)
		{
			Thread.Sleep(2000); // there is a delay from the file downloading to being added to the dir.
			folder = Environment.ExpandEnvironmentVariables(folder);
			// find latest archived file
			var query =
				new DirectoryInfo(folder)
					.GetFiles(filePattern).AsQueryable();
			if (since.HasValue)
			{
				query = query.Where(f => f.LastWriteTime >= DateTime.Now - since);
			}
			var fileInfo = query.OrderByDescending(f => f.LastWriteTime)
					.FirstOrDefault();

			return fileInfo?.FullName;
		}
	}
}
