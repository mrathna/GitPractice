package com.framework.testcases.AJS.SHELL;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.MaintainCustomerPage;
import com.framework.pages.AJS.common.Common;
import com.framework.pages.AJS.common.IFCSHomePage;
import com.framework.pages.AJS.common.IFCSLoginPage;

public class ValidateBulkReissueTestCases extends BaseTest {
	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test(groups = { "Regression" })
	public void validateIFCSLogin(@Optional("RU") String clientCountry, @Optional("SHELL") String clientName,
			@Optional("APA") String cardType) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  IFCS Login Page", "01 Set the Client");
		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);

		IFCSloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME","IFCS_SHELL_PASSWORD");
		IFCSHomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);
		IFCSHomePage.exitIFCS();
	}
 
	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test(groups = { "Regression" })
	public void validateIFCSCustomer(@Optional("RU") String clientCountry, @Optional("SHELL") String clientName,
			@Optional("APA") String cardType) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  IFCS customer Page", "02 Set Customer");
		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		MaintainCustomerPage MaintainCustomer = new MaintainCustomerPage(driver, test);
		Common common=new Common(driver,test);

		IFCSloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME","IFCS_SHELL_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, cardType);
		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		String customerNumber=common.getActiveCustomerNoUsingCardType();
     		if (customerNumber.equals(" ")) {
			common.logForNoDataFound(this.getClass().getSimpleName(),
					"Need to Create A Active Customer with Card Type and rerun");
		} else {
			MaintainCustomer.verifyExistingCustomerHasACardProgram(customerNumber);

		}
		
		IFCSHomePage.exitIFCS();
	}

}
