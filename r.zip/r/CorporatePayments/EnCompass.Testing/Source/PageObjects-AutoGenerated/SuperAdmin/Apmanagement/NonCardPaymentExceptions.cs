using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using Common;
using Common.PageObjects;
using Common.ScenarioConfigurations;
using Common.Utility;

namespace EnCompass.Testing.Source.PageObjects.SuperAdmin.Apmanagement 
{
	/// <summary>
	/// Auto-generated Page Model Class
	/// Navigation Paths: 
		/// [Organization Home]->Payables->Accounts Payable->AP Non-Card Payments
		/// </summary>
	[PageModel(@"/superAdmin/APManagement/NonCardPaymentExceptions.aspx")]
	public partial class NonCardPaymentExceptions : EnCompassSuperPageModel 
	{
		public override string RelativeUrl => @"/superAdmin/APManagement/NonCardPaymentExceptions.aspx";
		public override string PageIdentifierXPath_Generated => @"//li[contains(@class, 'breadcrumb-item active')][text() = 'AP Non-Card Payments']";

		#region Navigation
				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Organizations']")]
		private IWebElement _payables_AccountsPayable_ApNonCardPayments_Organizations { get; set; }
		public void NavigateTo_Payables_AccountsPayable_ApNonCardPayments_Organizations()
		{
			NavigateToMenuItem(_payables_AccountsPayable_ApNonCardPayments_Organizations);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Prefund Solution Final Close']")]
		private IWebElement _payables_AccountsPayable_ApNonCardPayments_PrefundSolutionFinalClose { get; set; }
		public void NavigateTo_Payables_AccountsPayable_ApNonCardPayments_PrefundSolutionFinalClose()
		{
			NavigateToMenuItem(_payables_AccountsPayable_ApNonCardPayments_PrefundSolutionFinalClose);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Prefund Solution Payments']")]
		private IWebElement _payables_AccountsPayable_ApNonCardPayments_PrefundSolutionPayments { get; set; }
		public void NavigateTo_Payables_AccountsPayable_ApNonCardPayments_PrefundSolutionPayments()
		{
			NavigateToMenuItem(_payables_AccountsPayable_ApNonCardPayments_PrefundSolutionPayments);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='AP Non-Card Payments']")]
		private IWebElement _payables_AccountsPayable_ApNonCardPayments_ApNonCardPayments { get; set; }
		public void NavigateTo_Payables_AccountsPayable_ApNonCardPayments_ApNonCardPayments()
		{
			NavigateToMenuItem(_payables_AccountsPayable_ApNonCardPayments_ApNonCardPayments);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='EnCircle Enrollment']")]
		private IWebElement _payables_AccountsPayable_ApNonCardPayments_EncircleEnrollment { get; set; }
		public void NavigateTo_Payables_AccountsPayable_ApNonCardPayments_EncircleEnrollment()
		{
			NavigateToMenuItem(_payables_AccountsPayable_ApNonCardPayments_EncircleEnrollment);
		}

		
		private void NavigateToMenuItem(IWebElement element)
		{
			Driver.Url = element.GetAttribute("href");
		}
		#endregion

		public NonCardPaymentExceptions(GlobalSettings settings) : base(settings) { }
	}  
}
