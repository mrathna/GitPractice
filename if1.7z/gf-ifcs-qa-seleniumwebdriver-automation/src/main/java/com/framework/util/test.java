package com.framework.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class test {
	public static void main(String[] argv) throws Exception {
        String qry = "select Card.* from ttpa_pdacct card where card.acctid='9100001464084'";
        //9100001464084
        String parseValue = getMySQLConnection(qry,"jdbc:oracle:thin:@apa-qtods-sc:1521/qtods.wexinc.com");
        if (parseValue == "true") {
        	System.out.println("Data Successfully Integrated to ODS...");
        }
        else {
        	System.out.println(parseValue);
        }
          
    }
	
	public static String getMySQLConnection(String query, String dbName) throws ClassNotFoundException, SQLException, InterruptedException {
		String returnValue = "";
		String uname = "USERNAME GOES HERE";
		String pwd = "PWD GOES HERE";
		boolean valFound = false;
		try {
	        Class.forName("oracle.jdbc.driver.OracleDriver");
	        System.out.println("Oracle JDBC Driver Registered!");	        
	    } catch (ClassNotFoundException e) {
	        System.out.println("Oracle JDBC Driver not found...");
	        returnValue = "Oracle JDBC Driver not found...";
	        e.printStackTrace();
	        return returnValue;
	    }
		Connection con = null;
		try {
			con = DriverManager.getConnection(dbName, uname, pwd);
        } catch (SQLException e) {
            System.out.println("Connection Failed! Check output console");
            returnValue = "Connection Failed! Check output console...";
            e.printStackTrace();
            return returnValue;
        }
		if (con != null) {
			System.out.println("You made it, take control your database now!");
			Statement st = con.createStatement();
		    //ResultSet rs = st.executeQuery(query);
		    int i = 1;
			while (i<=10 && valFound == false )
			{
				System.out.println("Running Loop " + i + " valFound " + valFound + "\n");
				if (i==3) query="select Card.* from ttpa_pdacct card where card.acctid='9100001464084'";
				
				Thread.sleep(5000);
				ResultSet rs = st.executeQuery(query);
				while(rs.next() && valFound == false)
				{
					int rowCount = rs.getRow();
					if(rowCount == 1) {
						valFound = true;
						returnValue="true";
					}					
				}
				i=i+1;
				rs.close();
			}
			st.close();
			con.close();
		} else {
			System.out.println("Failed to make connection!");
            returnValue = "Failed to make connection!";
		} 
	      
		return returnValue;
	}

}
