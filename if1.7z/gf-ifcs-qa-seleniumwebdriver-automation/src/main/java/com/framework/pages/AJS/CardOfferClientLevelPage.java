package com.framework.pages.AJS;

import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;
import com.framework.basepage.BasePage;
import com.framework.pages.AJS.common.Common;

public class CardOfferClientLevelPage  extends BasePage {

	
//	@FindBy(xpath = Locator_IFCS.SEARCH_RESULTS_TABLE)
//	public List<WebElement> cardsTable;
	
	
	public CardOfferClientLevelPage(WebDriver driver, ExtentTest test) {
		super(driver, test);
		// TODO Auto-generated constructor stub
	}
	
	
	//Method to choose "Card Products" in Admin->Client and validate the embossing rules in the dropdown
	public void chooseCardProductsFromClient() {
		chooseSubMenuFromLeftPanel("Client Config","Card Offers");
		chooseSubMenuFromLeftPanel("Card Offers","Card Products");
		
	}
	
	public void validateCardProductValuesInClient(){
		Common common=new Common(driver,test);
		String description;
		
		description = common.getSpecifiedColValueInSearchTable("Description");
		System.out.println("expectedValue  :  " +description);
		common.validateCardProductsInSearchTable();


	}

	public void validateVersionNumberMaxLength() {
		Common common=new Common(driver,test);
		String description;
		
		description = common.getSpecifiedColValueInSearchTable("Description");
		System.out.println("expectedValue  :  " +description);
		common.validateVersionNumberMaxLengthInSearchTable();
		}
	}
	

		
