package com.framework.testcases.OLS.BP.Customer;


import java.util.LinkedHashSet;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.BP.BPHomePage;
import com.framework.pages.BP.BPRecurringReportPage;
import com.framework.pages.BP.BPRunAReportPage;
import com.framework.pages.OLS.HomePage;
import com.framework.pages.OLS.common.LoginPage;

public class ValidateRecurringReports extends BaseTest {

	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "Regression" })
	public void validateTheEditFunctionalityOfRecurringReports(@Optional("AU") String clientCountry,
			@Optional("BP") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  Edit Recurring Reports and Validate", "Edit Recurring Reports and Validate");
		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		HomePage homePage = new HomePage(driver, test);
		BPHomePage bpHomePage = new BPHomePage(driver, test);
		BPRecurringReportPage bpRecurringReportPage = new BPRecurringReportPage(driver, test);

		// Calling Functions
		loginPage.Login("BP_URL", "BP_UN_Customer_" + clientCountry, "BP_PWD_Customer_" + clientCountry, clientName);
		bpHomePage.ValidateBPCustomerLogo();
		bpHomePage.ValidateCustomerWelcomeText();
		homePage.ValidateLogoutLink();
		homePage.ValidateHelpLink();		
		bpHomePage.validateTheNavOfRecurringReportSubMenu();
		bpRecurringReportPage.verifyTheRecurringReportsArePresentAndEdit();	
		loginPage.Logout();
	}

	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "Regression" })
	public void verifyTheViewAllPageOfPastReports(@Optional("AU") String clientCountry,
			@Optional("BP") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  Verify the View All Page Of Past Reports",
				"Verify the View All Page of Past Reports");
		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		HomePage homePage= new HomePage(driver,test);
		BPHomePage bpHomePage = new BPHomePage(driver, test);
		BPRecurringReportPage bpRecurringReportPage = new BPRecurringReportPage(driver, test);
		// Calling Functions
		loginPage.Login("BP_URL", "BP_UN_Customer_" + clientCountry, "BP_PWD_Customer_" + clientCountry, clientName);
		bpHomePage.ValidateBPCustomerLogo();
		bpHomePage.ValidateCustomerWelcomeText();
		homePage.ValidateLogoutLink();
		homePage.ValidateHelpLink();		
		bpRecurringReportPage.validateTheNavOfPastReportsSubMenu();
		boolean isRecurringReportPResent = bpRecurringReportPage.checkRecurringReportPresentorNot();
		if(!isRecurringReportPResent)
		{
			bpRecurringReportPage.clickViewAllAndValidateThePage();
			bpRecurringReportPage.validateThePastReportsPageButton();
			bpRecurringReportPage.clearData();
		}
		loginPage.Logout();
	}

	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "Regression" })
	public void createAndVerifyTheRecurringReports(@Optional("AU") String clientCountry,
			@Optional("BP") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  Create and Verify the Recurring Reports", "Create Recurring report and verify that");
		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		HomePage homePage= new HomePage(driver,test);
		BPHomePage bpHomePage = new BPHomePage(driver, test);
		BPRecurringReportPage bpRecurringReportPage = new BPRecurringReportPage(driver, test);		
		BPRunAReportPage bpRunReportPage = new BPRunAReportPage(driver, test);
		// Calling Functions
		loginPage.Login("BP_URL", "BP_UN_Customer_" + clientCountry, "BP_PWD_Customer_" + clientCountry, clientName);
		bpHomePage.ValidateBPCustomerLogo();
		bpHomePage.ValidateCustomerWelcomeText();
		homePage.ValidateLogoutLink();
		homePage.ValidateHelpLink();		
		bpHomePage.validateTheNavOfRecurringReportSubMenu();
		boolean isReportsPresent = bpRecurringReportPage.checkReportPresentorNot();
		
		System.out.println("------ isReportsPresent ---------"+isReportsPresent);
		LinkedHashSet<String> RTypeRDtl = null;
		
		if(!isReportsPresent)
		{ 
			bpRecurringReportPage.setAndValidateRecurringReportData();
			RTypeRDtl = bpRecurringReportPage.getReportTypeAndDetail(false);
		}
							
		bpRecurringReportPage.createNewRecurringReport(clientCountry);
		String reportData= bpRunReportPage.enterValuesCreateRecurringReportAndValidate(RTypeRDtl);		
		bpHomePage.validateTheNavOfRecurringReportSubMenu();
		bpRecurringReportPage.deleteTheCreatedReport(reportData);	
		loginPage.Logout();
	}

	@Parameters({ "clientCountry", "clientName" }) // Seeing sorting issue - Need to check With Geetha Goli 
	@Test( groups = { "Regression" })
	public void sortAndVerifyThePastRecurringReports(@Optional("AU") String clientCountry,
			@Optional("BP") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  Sort the Report Type and Report Detail and Verify ",
				"Navigate to the Past Reports and Verify the sort");
		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		HomePage homePage= new HomePage(driver,test);
		BPHomePage bpHomePage = new BPHomePage(driver, test);
		BPRecurringReportPage bpRecurringReportPage = new BPRecurringReportPage(driver, test);		
		// Calling Functions
		loginPage.Login("BP_URL", "BP_UN_Customer_" + clientCountry, "BP_PWD_Customer_" + clientCountry, clientName);
		bpHomePage.ValidateBPCustomerLogo();
		bpHomePage.ValidateCustomerWelcomeText();
		homePage.ValidateLogoutLink();
		homePage.ValidateHelpLink();		
		bpRecurringReportPage.validateTheNavOfPastReportsSubMenu();
		boolean isRecurringReportPResent = bpRecurringReportPage.checkRecurringReportPresentorNot();
		if(!isRecurringReportPResent)
		{
			bpRecurringReportPage.sortReportTypeDetailAndValidate();		
			bpRecurringReportPage.clearData();
		}
		loginPage.Logout();
	}
 
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "Regression" })
	public void makeTheActiveReportToHoldAndVerify(@Optional("AU") String clientCountry,
			@Optional("BP") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  Make the Active Report to Hold",
				" Navigate to Recurring Report and Make the Active Report to Hold");
		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		HomePage homePage= new HomePage(driver,test);
		BPHomePage bpHomePage = new BPHomePage(driver, test);
		BPRecurringReportPage bpRecurringReportPage = new BPRecurringReportPage(driver, test);		
		// Calling Functions
		loginPage.Login("BP_URL", "BP_UN_Customer_" + clientCountry, "BP_PWD_Customer_" + clientCountry, clientName);
		bpHomePage.ValidateBPCustomerLogo();
		bpHomePage.ValidateCustomerWelcomeText();
		homePage.ValidateLogoutLink();
		homePage.ValidateHelpLink();		
		bpHomePage.validateTheNavOfRecurringReportSubMenu();
		
		boolean isRecurringReportPResent = bpRecurringReportPage.checkReportPresentorNot();
		if(!isRecurringReportPResent)
		{
		
			bpRecurringReportPage.makeTheActiveReportToHold();
			bpRecurringReportPage.validateTheActiveReportChangedToHold(); 
		}
		loginPage.Logout();
	}

	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "Regression" })
	public void makeTheHoldReportToActiveAndVerify(@Optional("AU") String clientCountry,
			@Optional("BP") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  Make the OnHold report to Active",
				" Navigate to Recurring Report and make the hold report to active");
		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		HomePage homePage= new HomePage(driver,test);
		BPHomePage bpHomePage = new BPHomePage(driver, test);
		BPRecurringReportPage bpRecurringReportPage = new BPRecurringReportPage(driver, test);		
		// Calling Functions
		loginPage.Login("BP_URL", "BP_UN_Customer_" + clientCountry, "BP_PWD_Customer_" + clientCountry, clientName);
		bpHomePage.ValidateBPCustomerLogo();
		bpHomePage.ValidateCustomerWelcomeText();
		homePage.ValidateLogoutLink();
		homePage.ValidateHelpLink();		
		bpHomePage.validateTheNavOfRecurringReportSubMenu(); 
		
		boolean isRecurringReportPResent = bpRecurringReportPage.checkReportPresentorNot();
		if(!isRecurringReportPResent)
		{
		
			bpRecurringReportPage.makeTheHoldReportToActive();
			bpRecurringReportPage.validateTheHoldReportChangedToActive();
		}
		loginPage.Logout();
	}

	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "Regression" })
	public void validateTheDownloadOptionOfRecurringReports(@Optional("AU") String clientCountry,
			@Optional("BP") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  Edit Recurring Reports and Validate", "Edit Recurring Reports and Validate");
		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		HomePage homePage = new HomePage(driver, test);
		BPHomePage bpHomePage = new BPHomePage(driver, test);
		BPRecurringReportPage bpRecurringReportPage = new BPRecurringReportPage(driver, test);

		// Calling Functions
		loginPage.Login("BP_URL", "BP_UN_Customer_" + clientCountry, "BP_PWD_Customer_" + clientCountry, clientName);
		bpHomePage.ValidateBPCustomerLogo();
		bpHomePage.ValidateCustomerWelcomeText();
		homePage.ValidateLogoutLink();
		homePage.ValidateHelpLink();		
		bpRecurringReportPage.validateTheNavOfPastReportsSubMenu();
		boolean isRecurringReportPResent = bpRecurringReportPage.checkRecurringReportPresentorNot();
		if(!isRecurringReportPResent)
		{
			bpRecurringReportPage.verifyTheRecurringReportsArePresentAndDownloadLatestCopy();
		}
		loginPage.Logout();
	}

}
