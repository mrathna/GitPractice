package com.framework.pages.BP;


import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Set;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.ss.usermodel.Sheet;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;


import com.aventstack.extentreports.ExtentTest;
import com.framework.basepage.BasePage;
import com.framework.pages.AJS.common.Common;
import com.framework.pages.AJS.common.IFCSCommonPage;
import com.framework.pages.OLS.common.CommonPage;
import com.framework.pages.OLS.common.FindAndUpdateCardPage;
import com.framework.repo.Locator;
import com.framework.util.ExcelUtils;
import com.framework.util.PropUtils;

public class BPOrderCard extends BasePage {

	@FindBy(how = How.ID, using = Locator.CARDS_MENU)
	public WebElement cardMenu;
	@FindBy(how = How.ID, using = Locator.ORDER_A_CARD)
	public WebElement orderCard;
	@FindBy(how = How.CSS, using = Locator.ORDER_A_CARD_PAGE_TITLE)
	public WebElement orderCardPagetitle;
	@FindBy(how = How.ID, using = Locator.AN_EXISTING_CARD_BUTTON)
	public WebElement anExistingCardBtn;
	@FindBy(how = How.ID, using = Locator.EXISTING_CARD_POPUP_TITLE)
	public WebElement anExistingCardPopupHeader;
	@FindBy(how = How.ID, using = Locator.ACCOUNT_FIELD_IN_EXISTING_CARD_POPUP)
	public WebElement anExistingCardPopupAccountField;
	@FindBy(how = How.ID, using = Locator.CARD_STATUS_FIELD_IN_EXISTING_CARD_POPUP)
	public WebElement anExistingCardPopupCardStatusField;
	@FindBy(how = How.ID, using = Locator.SEARCH_CARDS)
	public WebElement searchCardButton;
	@FindBy(how = How.ID, using = Locator.BCU_MULTI_FIELD_SEARCH)
	public WebElement multiCardSearchField;
	@FindBy(how = How.XPATH, using = Locator.CARD_NUMBER_FROM_EXISING_CARD_SEARCH_RECORD)
	public WebElement selectCardNumberFromSearchRecord;
	@FindBy(how = How.ID, using = Locator.VIEW_CARD_POPUP_HEADER)
	public WebElement viewCardPopupHeader;
	@FindBy(how = How.XPATH, using = Locator.VIEW_CARD_CLOSE_BUTTON)
	public WebElement viewCardCloseBtn;
	@FindBy(how = How.XPATH, using = Locator.RADIO_BUTTON_FROM_SEARCH_RECORDS)
	public WebElement radioButtonSearchRecords;
	@FindBy(how = How.ID, using = Locator.APPLY_TO_NEW_CARD_ORDER_BUTTON)
	public WebElement applyToNewCardOrderBtn;
	@FindBy(how = How.ID, using = Locator.BCU_MULTI_FIELD_SEARCH)
	public WebElement multiFieldSearch;
	@FindBy(how = How.CSS, using = Locator.CARD_NUMBER_FROM_SEARCH_TABLE)
	public List<WebElement> cardNumberFromSearchTable;
	@FindBy(how = How.XPATH, using = Locator.ORDER_CARD_PAGE)
	public WebElement orderCardPage;
	@FindBy(how = How.ID, using = Locator.VEHICLE_DESCRIPTION_FIELD)
	public WebElement vehicleDescriptionField;
	@FindBy(how = How.ID, using = Locator.REGO_NUMBER_FIELD)
	public WebElement regoNumberField;
	@FindBy(how = How.ID, using = Locator.CONTINUE_BUTTON)
	public WebElement continueButton;
	@FindBy(how = How.XPATH, using = Locator.UNUSUAL_ACTIVITY_LIMITS_HEADER)
	public WebElement unusualActivityLimitsHeader;
	@FindBy(how = How.XPATH, using = Locator.DELIVERY_ADDRESS_HEADER)
	public WebElement deliveryAddressHeader;
	@FindBy(how = How.XPATH, using = Locator.PLACE_ORDER_PAGE_HEADER)
	public WebElement placeOrderSubPageHeader;
	@FindBy(how = How.ID, using = Locator.ORDER_CARD_BUTTON)
	public WebElement orderCardButton;
	@FindBy(how = How.XPATH, using = Locator.SUCCESS_MESSAGE)
	public WebElement successMessage;
	@FindBy(how = How.XPATH, using = Locator.SUCCESS_MESSAGE_CARD_NUMBER)
	public WebElement successMessageWithCardNumber;
	@FindBy(how = How.ID, using = Locator.SAVE_CONFIGURATION_AS_PROFILE_BUTTON)
	public WebElement saveConfigurationAsProfileBtn;
	@FindBy(how = How.XPATH, using = Locator.SAVE_CONFIGURATION_AS_PROFILE_POPUP)
	public WebElement saveConfigurationAsProfilePopup;
	@FindBy(how = How.ID, using = Locator.CARD_CONFIGURATION_PROFILE_NAME_FIELD)
	public WebElement cardConfigProfileNameField;
	@FindBy(how = How.ID, using = Locator.DESCRIPTION_COMMON)
	public WebElement cardConfigProfileDescField;
	@FindBy(how = How.ID, using = Locator.CARD_CONFIGURATION_PROFILE_SAVE_BTN)
	public WebElement cardConfigProfileSaveBtn;
	@FindBy(how = How.ID, using = Locator.CONFIRMATIONMESSAGE)
	public WebElement successMsgPopup;
	@FindBy(how = How.XPATH, using = Locator.CONFIG_PROFILE_CLOSE_BUTTON)
	public WebElement configProfileCloseBtn;
	@FindBy(how = How.XPATH, using = Locator.HOME_MENU)
	public WebElement HomeMenu;
	@FindBy(how=How.XPATH, using = Locator.ACCOUNT_LIST_BOX)
	public WebElement accountListBox;
	@FindBy(how = How.XPATH, using = Locator.LIST_OF_CARD_NUMBER)
	public List<WebElement> cardNumberListfromTable;
	@FindBy(how = How.ID, using = Locator.VEHICLE_RADIO_BUTTON)
	public WebElement clickVehicleRadioButton;
	@FindBy(how = How.ID, using = Locator.CARD_INFORMATION_DRIVER)
	public WebElement clickDriverRadioButton;
	@FindBy(how = How.ID, using = Locator.CARD_PURCHASE_PRODUCTS_ALL)
	public WebElement clickSelectedFuelProduct;
	@FindBy(how = How.ID, using = Locator.PRODUCT_RESTRICTION)
	public WebElement productRestriction;
	@FindBy(how = How.ID, using = Locator.CARD_PURCHASE_PRODUCTS_LPG)
	public WebElement clickLPGFuelProduct;
	@FindBy(how = How.XPATH, using = Locator.CARD_PURCHASE_NON_FUEL_ALL_NON_FUEL)
	public WebElement clickAllNonFuelsProduct;
	@FindBy(id = Locator.CDA_RETURNTO_UNUSUAL_ACTIVITY_LIMITS)
	public WebElement returnToUnusualActivityLimits;
	@FindBy(how = How.XPATH, using = Locator.CARD_PURCHASE_LUBRICATION_YES)
	public WebElement cardPurchaseYes;
	@FindBy(how = How.ID, using = Locator.PLACE_ORDER_SUCCESS)
	public WebElement orderSucessmsg;
	@FindBy(how = How.ID, using = Locator.CARD_INFORMATION_PIN)
	public WebElement clickPIN;
	@FindBy(how = How.ID, using = Locator.CARD_INFORMATION_SIGNATURE)
	public WebElement clickSignature;
	@FindBy(css = Locator.SELECTED_POS_VALUES)
	public List<WebElement> selectedPOSValues;

	@FindBy(css = Locator.POS_VALUES)
	public List<WebElement> allPOSValues;

	@FindBy(css = Locator.SELECT_FUEL_TRANSACTION_COST)
	public WebElement selectFuelTransactionCostDropdownValue;

	@FindBy(id = Locator.PLACE_ORDER_DELIVERY_ADDRESS_EDIT)
	public WebElement placeOrderDeliveryAddressEdit;

	@FindBy(id = Locator.SUCCESS_MSG_AFTER_EDIT_CARD)
	public WebElement successMsgAfterEditCard;

	@FindBy(how = How.XPATH, using = Locator.ACTIVECARDS_WITHPIN)
	public List<WebElement> activeCardsWithPin;

	@FindBy(how = How.XPATH, using = Locator.EDIT_CARD)
	public WebElement editCard;

	@FindBy(id = Locator.MULTIFIELD_SEARCH)
	public WebElement cardNumberSearchFilter;

	@FindBy(id = Locator.CURRENT_CARD_STATUS)
	public WebElement cardStatus;

	@FindBy(id = Locator.CARD_INFORMATION_DRIVER_NAME)
	public WebElement cardDriverName;

	@FindBy(id = Locator.CARD_INFORMATION_DRIVER_ID_TEXTBOX)
	public WebElement cardDriverId;
	
	@FindBy(id = Locator.CARD_INFORMATION_EMBOSSING_NAME)
	public WebElement embossName;
	

	@FindBy(id = Locator.CARD_INFORMATION_VEHICLE_DESCRIPTION)
	public WebElement cardVehicleDescription;

	@FindBy(id = Locator.CARD_INFORMATION_VEHICLE_REGO_NUMBER)
	public WebElement cardVehicleRegNo;

	@FindBy(css = Locator.TRANSACTION_LIMITS_DROPDOWN)
	public List<WebElement> transactionLimitsDropdown;

	@FindBy(css = Locator.ADDRESS_RADIO)
	public List<WebElement> addressRadios;

	@FindBy(id = Locator.PLACE_ORDER_CARDTYPE_EDIT)
	public WebElement placeOrderCardTypeEdit;

	@FindBy(id = Locator.PLACE_ORDER_PURCHASE_RESTRICTIONS_EDIT)
	public WebElement placeOrderPurchaseRestrictionsEdit;

	@FindBy(id = Locator.PLACE_ORDER_UNUSUAL_ACTIVITY_EDIT)
	public WebElement placeOrderUnusualActivity;

	@FindBy(id = Locator.PLACE_ORDER_DELIVERY_ADDRESS_EDIT)
	public WebElement placeOrderDeliveryAddress;

	// 31-05-2018 Added by Ayub

	@FindBy(xpath = Locator.CONFIGURE_ROAD_USER)
	public WebElement configureRoadUser;

	@FindBy(id = Locator.CARD_INFORMATION)
	public WebElement cardInformation;

	@FindBy(id = Locator.ROAD_USER_CHARGE)
	public WebElement roadUserCharge;

	@FindBy(id = Locator.RUC_CUSTOMER_NUMBER)
	public WebElement rucCustomerNumber;

	@FindBy(id = Locator.RUC_CUSTOMER_NAME)
	public WebElement rucCustomerName;

	@FindBy(id = Locator.PRIMARY_VEHICLE_REG)
	public WebElement primaryVehicleReg;

	@FindBy(id = Locator.PRIMARY_VEHICLE_LICENCE_GROSS)
	public WebElement primaryVehicleLicenceGross;

	@FindBy(id = Locator.PRIMARY_VEHICLE_DISTACNE)
	public WebElement primaryVehicleDistance;

	@FindBy(id = Locator.SECONDARY_VEHICLE_REG)
	public WebElement secondaryVehicleReg;

	@FindBy(id = Locator.SECONDARY_VEHICLE_LICENCE_GROSS)
	public WebElement secondaryVehicleLicenceGross;

	@FindBy(id = Locator.SECONDARY_VEHICLE_DISTACNE)
	public WebElement secondaryVehicleDistance;

	@FindBy(id = Locator.TERTIARY_VEHICLE_REG)
	public WebElement tertiaryVehicleReg;

	@FindBy(id = Locator.TERTIARY_VEHICLE_LICENCE_GROSS)
	public WebElement tertiaryVehicleLicenceGross;

	@FindBy(id = Locator.TERTIARY_VEHICLE_DISTACNE)
	public WebElement tertiaryVehicleDistance;

	@FindBy(id = Locator.RETURN_TO_PREVIOUS_PAGE)
	public WebElement returnToPreviousPage;
	@FindBy(how = How.XPATH, using = Locator.CARD_DETAILS)
	public WebElement cardDetails;
	@FindBy(how = How.XPATH, using = Locator.PURCHASE_RESTRICTIONS)
	public WebElement purchaseRestrictions;
	@FindBy(how = How.XPATH, using = Locator.ACTIVITY_LIMITS)
	public WebElement activityLimits;
	@FindBy(how = How.XPATH, using = Locator.DELIVERY_ADDRESS)
	public WebElement deliveryAddress;
	@FindBy(how = How.XPATH, using = Locator.ORDER_ANOTHER_CARD)
	public WebElement orderAnotherCard;
	@FindBy(how = How.ID, using = Locator.SAVE_A_PROFILE)
	public WebElement saveProfile;
	@FindBy(how = How.ID, using = Locator.SELECT_PROFILE)
	public WebElement selectProfile;
	@FindBy(how = How.ID, using = Locator.SAVE_A_PROFILE_APPLYANDCLOSE)
	public WebElement saveAndClose;

	@FindBy(id = Locator.CARD_LIST_TABLE)
	public WebElement cardListTable;
	
	@FindBy(xpath = Locator.EDIT_CARD_MENU_OPTION)
	public WebElement editCardMenuButton;
	
	@FindBy(xpath = Locator.CUSTOMER_NUMBER_LIST)
	public List<WebElement> customerNumberList;
	
	@FindBy(how = How.ID, using = Locator.CARDSFOUND_ASCENDING)
	public WebElement cardsFoundAscending;

	@FindBy(how = How.ID, using = Locator.ORDERED_CARD_NUMBER)
	public WebElement orderedCardNumber;
	
	@FindBy(how = How.XPATH, using = Locator.GO_TO_CARD_BUTTON)
	public WebElement btnGoToCard;
    @FindBy(how = How.ID, using = Locator.AN_EXISTING_CARDTYPE_SEARCH)
    public WebElement anExistingCardTypeSearch;
    
    @FindBy(how = How.XPATH, using = Locator.LI_EXISTING_CARD_NUMBER)
    public WebElement liExistingCardNumber;

	@FindBy(how = How.ID, using = Locator.AN_EXISTING_MULTICARD_SEARCH)
	public WebElement multiCardSearch;

	@FindBy(how = How.ID, using = Locator.BULKORDER_UPDATECARDS)
	public WebElement bulkCardOrder;

	@FindBy(how = How.XPATH, using = Locator.PAGE_TITLE_DP)
	public WebElement bulkCardOrderTitle;

	@FindBy(how = How.ID, using = Locator.BULK_CARD_ORDER_UPDATE)
	public WebElement bulkCardOrderbtn;

	@FindBy(how = How.ID, using = Locator.BULKCARD_ORDER_DOWNLOAD)
	public WebElement bulkCardOrderdwnld;

	@FindBy(how = How.XPATH, using = Locator.UPLOAD_BULKCARD_ORDER)
	public WebElement bulkCardUpdate;
	
	@FindBy(how = How.XPATH, using = Locator.BROWSER_POP_UP_ORDER)
	public WebElement browserPopUpOrder;
	
	@FindBy(how = How.XPATH, using = Locator.BROWSER_POP_UP_UPDATE)
	public WebElement browserPopUpUpdate;

	 @FindBy(how = How.ID, using = Locator.BULK_ORDER_CARD_SUCCESS)
	public WebElement successMsgOrder;
	 
	 @FindBy(how = How.ID, using = Locator.BULK_UPDATE_CARD_SUCCESS)
	public WebElement successMsgUpdate;
	 
	 
	 @FindBy(xpath = Locator.SHELL_UPLOAD_FILE)
	 public WebElement upLoadFile;
	 
	 @FindBy(how = How.ID, using = Locator.BCU_UPLOAD_EXCEL_FILE)
		public WebElement bulkUploadExcel;

	private String cardTypeStatus = "";

	public BPOrderCard(WebDriver driver, ExtentTest test) {
		super(driver, test);
		PageFactory.initElements(driver, this);
		// TODO Auto-generated constructor stub
	}

	public void clickOrderCardAndValidatePage() {

		clickSubMenuAndValidate(cardMenu, orderCard, orderCardPagetitle);

	}

	public void clickExistingCardButton() {
		isDisplayedThenActionClick(anExistingCardBtn, "An Existing Card Button");
		sleep(3);
	}

	public void validateExistingCardPopupDisplayed() {
		isDisplayed(anExistingCardPopupHeader, "Menu Item Payments");
		sleep(3);
	}

	public void clickSearchButton() {
		isDisplayedThenActionClick(searchCardButton, "Search Card Button");
		sleep(6);
	}

	public String selectCardNumberAndGetText() {
		int randomNo;
		String cardNumber = null;
		System.out.println("cardNumberFromSearchTable.size()---" + cardNumberFromSearchTable.size());
		if (cardNumberFromSearchTable.size() > 0) {

			randomNo = getRandomNumber(0, cardNumberFromSearchTable.size() - 1);
			cardNumber = cardNumberFromSearchTable.get(randomNo).getText();
		} else {
			logFail("No Cards Found");
		}
		return cardNumber;
	}
     
	public void selectAccountFromTheExistingPopup(String accountName) {
		selectDropDownByVisibleText(accountListBox,accountName);
		sleep(3);
	}
	public void selectAccountAndCardNumberStatusFromExistingCardPopup(String cardNumber) {

		System.out.println("card number ---" + cardNumber);
		isDisplayedThenActionClick(multiFieldSearch, "Multi Search Field");
		multiFieldSearch.clear();
		isDisplayedThenEnterText(multiFieldSearch, "Multi Field Search", cardNumber);
		logPass("Multi search fields is Displayed");

		//selectDropDownByVisibleText(anExistingCardPopupAccountField, "All Accounts");

		selectDropDownByVisibleText(anExistingCardPopupCardStatusField, "Active");
		sleep(3);

	}

	public void clickCardNumberFromSearchRecords() {
		sleep(2);
		isDisplayedThenActionClick(selectCardNumberFromSearchRecord, "Card Number from search records");
		sleep(5);
	}

	public void validateViewCardPopupDisplayed() {
		// isDisplayed(viewCardPopupHeader, "ViewCard header");
		verifyText(viewCardPopupHeader, "View Card");
	}

	public void validateOrderCardPageDisplayed() {
		verifyText(orderCardPage, "Order Card");
		sleep(3);
	}

	public void clickCloseButtonAtViewCardPopup() {
		isDisplayedThenActionClick(viewCardCloseBtn, "ViewCard header Close Button");
		sleep(3);
	}

	public void clickVehicleRadioButton() {
		isDisplayedThenActionClick(clickVehicleRadioButton, "Vehicle radio button");
		System.out.println("clicked radio button");
		sleep(5);
	}

	public void clickRadioButtonFromSearchRecords() {
		isDisplayedThenActionClick(radioButtonSearchRecords, "Radio Button from search records");
		sleep(3);
	}

	public void clickApplyToNewCardOrderButton() {
		isDisplayedThenActionClick(applyToNewCardOrderBtn, "Apply to New card order button");
		sleep(3);
	}

	public void enterVehicleDescription() {
		isDisplayedThenActionClick(vehicleDescriptionField, "Vehicle Description field");
		vehicleDescriptionField.sendKeys(fakerAPI().name().name());
	}

	public void enterRegoNumber() {
		isDisplayedThenActionClick(regoNumberField, "Rego Number field");
		regoNumberField.sendKeys(fakerAPI().number().digits(5));
		sleep(3);
	}
	
	public void enterEmbossname() {
		isDisplayedThenActionClick(embossName, "Emboss Name");
		embossName.clear();
		sleep(2);
		embossName.sendKeys(fakerAPI().name().firstName());
	}

	public void clickContinueButton() {
		isDisplayedThenActionClick(continueButton, "Continue Button");
		sleep(5);
	}

	public void validateUnusualActivityLimitsHeader() {
		verifyText(unusualActivityLimitsHeader, "Unusual Activity Limits");
		sleep(10);
	}

	public void validateDeliveryAddressHeader() {
		verifyText(deliveryAddressHeader, "Delivery Address");
		sleep(3);
	}

	public void validatePlaceOrderSubPage() {
		verifyText(placeOrderSubPageHeader, "Place Order");
		sleep(3);
	}

	public void clickOrderCardButton() {
		isDisplayedThenActionClick(orderCardButton, "Order Card Button");
		sleep(6);
	}

	public void validateSuccessMsgWithCardNumber(String cardNumberFromSuccessMsg) {
		System.out.println("Getting into the method");
		try {
			if (successMessage.isDisplayed()) {
				String getSuccessMsgCardNumber = successMessageWithCardNumber.getText();
				System.out.println("Getting card number from Success msg" + getSuccessMsgCardNumber);
				if (getSuccessMsgCardNumber.equals(cardNumberFromSuccessMsg)) {
					logPass("Success message with card number is Displayed");
				}
			} else {
				logFail("Success message with card number is Not Displayed");
			}
		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
	}

	public void clickSaveAsConfigurationProfileButton() {
		isDisplayedThenActionClick(saveConfigurationAsProfileBtn, "Save Configuration As Profile Btn");
		sleep(3);
	}

	public void validateSaveAsConfigProfilePopup() {
		verifyText(saveConfigurationAsProfilePopup, "Save this Configuration as a Profile");
	}

	public void enterCardConfigProfileName() {

		isDisplayedThenActionClick(cardConfigProfileNameField, "Card Config Profile Name");
		isDisplayedThenEnterText(cardConfigProfileNameField, "Card Config Profile Name", fakerAPI().name().name());
	}

	public void enterCardConfigProfileDesc() {

		isDisplayedThenActionClick(cardConfigProfileDescField, "Card Config Profile Description");
		isDisplayedThenEnterText(cardConfigProfileDescField, "Card Config Profile Description",
				fakerAPI().name().name());
	}

	public void clickConfigProfileSaveButton() {

		isDisplayedThenActionClick(cardConfigProfileSaveBtn, "Card Config Profile Save Button");
	}

	public void validateSuccessMessage() {

		isDisplayedThenActionClick(successMsgPopup, "Save Successful Msg");
	}

	public void clickConfigProfileCloseBtn() {

		isDisplayedThenActionClick(configProfileCloseBtn, "Click Close Button");
	}

	public void clickHomeMenuTab() {

		isDisplayedThenActionClick(HomeMenu, "Home Menu Tab");
	}

	public boolean iterateAndSearch(String cardNumberFromIterate) {
		int listSize = cardNumberListfromTable.size();
		System.out.println("Size of Dropdown" + listSize);
		for (int i = 0; i < listSize; i++) {
			String searchCardNumber = cardNumberListfromTable.get(i).getText();
			System.out.println("accountname:::::" + searchCardNumber);
			System.out.println("Homepage accountname:::::" + cardNumberFromIterate);
			if (searchCardNumber.contains(cardNumberFromIterate)) {
				break;
			}
		}
		return true;
	}

	public void selectDifferentProductRestriction() {
		if(clickSelectedFuelProduct.getAttribute("checked")!=null) {
			logInfo("Already Option Checked");
		} else {
			isDisplayedThenClick(clickSelectedFuelProduct, "Click the default All Fuel Product");
			sleep(3); 
		}		
		if(clickLPGFuelProduct.getAttribute("checked")!=null) {
			logInfo("Already Option Checked");
		} else {
			isDisplayedThenClick(clickLPGFuelProduct, "Click the LPG fuel Product");
			sleep(3);
		}	
	}

	String posOptionChoosen, cardNumberChoosen, fuelCostDropdownValue;

	public void choosePOSValuesInEditCard() {
		for (int i = 0; i < selectedPOSValues.size(); i++) {
			isDisplayedThenClick(selectedPOSValues.get(i), "Deselect POS Values");
			sleep(1);
		}
		int randomNo = getRandomNumber(0, allPOSValues.size());
		posOptionChoosen = getAttribute(allPOSValues.get(randomNo), "id");
		isDisplayedThenClick(allPOSValues.get(randomNo), "Select POS Value");
		sleep(1);
	}

	public void selectFuelTransactionCostDropdown() {
		selectInputFromDropdown(selectFuelTransactionCostDropdownValue, 0);
		fuelCostDropdownValue = selectedStringFrmDropDown(selectFuelTransactionCostDropdownValue);
	}

	public void clickEditDeliveryAddressOption() {
		isDisplayedThenClick(placeOrderDeliveryAddressEdit, "Edit Order Delivery Address");
		sleep(4);
	}

	public void clickReturnToUnusualActivity() {
		isDisplayedThenClick(returnToUnusualActivityLimits, " Return to Unusual Activity");
		sleep(3);
	}

	public void validateSuccessMessageAfterEditCard() {
		sleep(5);
		// System.out.println("Text" + getText(successMsgAfterEditCard));
		if (getText(successMsgAfterEditCard).contains(
				"Congratulations. The changes you’ve made to your card have been successfully applied. Below is confirmation of the details that now apply to your card.")) {
			logPass("Success Message after Edit Card present");
		} else {
			logFail("Success Message after Edit Card not present");
		}
	}

	public void verifyEditCardPageTitle(String expectedTitle) {
		verifyText(orderCardPagetitle, expectedTitle);
	}

	/**
	 * Select a Active Card Number
	 */
	public void pickActiveCardAndEdit() {
		/*boolean elementPresent=waitToCheckElementIsDisplayed(By.xpath("//a[@class='descending']"),10);
		if(elementPresent) {
		isDisplayedThenClick(cardsFoundAscending,"Ascending clicked");
		sleep(10);
		}*/
		CommonPage commonPage=new CommonPage(driver,test);
		commonPage.changeSearchListIntoAscendingOrder();
		System.out.println("After Clicked Ascending --------->");
		if (activeCardsWithPin.size() > 0) {
			cardNumberChoosen = getText(activeCardsWithPin.get(0));
			isDisplayedThenClick(activeCardsWithPin.get(0), "Pick Active Card");
			isDisplayedThenActionClick(editCard, "Card Table Menu");
			sleep(2);
			logPass("Active card choosen :: Card Number - >" + cardNumberChoosen);
		} else {
			logFail("No Active Cards");
		}
	}

	public void enterCardNumberInSearchFilter() {
		isDisplayedThenEnterText(cardNumberSearchFilter, "Card number in search field", cardNumberChoosen);
	}

	public void validatePOSValueChoosen() {
		String selectedPOSId = getAttribute(selectedPOSValues.get(0), "id");
		if (posOptionChoosen.equals(selectedPOSId)) {
			logPass("POS Option choosen in edit card was updated");
		} else {
			logFail("POS Option choosen in edit card was not updated on the card ");
		}
	}

	public void validateFuelTransactionCostDropdownValueChoosen() {
		String selectedTransactionCostDropdown = selectedStringFrmDropDown(selectFuelTransactionCostDropdownValue);
		if (selectedTransactionCostDropdown.equals(fuelCostDropdownValue)) {
			logPass("Fuel transaction cost drop down value choosen in edit card was updated");
		} else {
			logFail("Fuel transaction cost drop down value choosen in edit card was not updated");
		}
	}

	public void validateFieldsOnEditCardInformationPage() {
		isDisplayed(cardStatus, "Card Status");
		isDisplayed(cardDriverName, "Card Driver Name");
		isDisplayed(cardDriverId, "Card Driver Id");
		isDisplayed(cardVehicleRegNo, "Card Vehicle Reg");
		isDisplayed(cardVehicleDescription, "Card Vehicle Description");
	}

	public void validateFieldsOnEditCardUnusualActivityPage(int expectedDropdownsCount) {
		sleep(6);
		if (transactionLimitsDropdown.size() == expectedDropdownsCount) {
			logPass("Transactions dropdown count on the edit card page displayed as expected");
		} else {
			logFail("Transactions dropdown count on the edit card page not displayed as expected");
		}
	}

	public void validateFieldsOnEditCardDeliveryAddressPage() {
		if (addressRadios.size() == 2) {
			logPass("Address Radio Buttons Present in Delivery Address");
		} else {
			logFail("Address Radio Buttons not present in Delivery Address");
		}
	}

	public void validateFieldsOnEditCardReviewChangesPage() {
		isDisplayed(placeOrderCardTypeEdit, "Place Order Card Type Edit");
		isDisplayed(placeOrderPurchaseRestrictionsEdit, "Place Order Purchase Restriction Edit");
		isDisplayed(placeOrderUnusualActivity, "Place Order Unusual Activity");
		isDisplayed(placeOrderDeliveryAddress, "Place Order Delivery Address");

	}

	// 31.05.2018 Added by Ayub

	public void validateConfigureRoadUserChargeslinkPage() {
		sleep(5);
		isDisplayedThenClick(configureRoadUser, "Cofigure Road User Charge Link");
		sleep(3);
		checkTextInPageAndValidate("Change Card - Setup Road User Charges", 10);
		isDisplayed(cardInformation, "Card Information");
		checkTextInPageAndValidate("This card is for a", 10);
		checkTextInPageAndValidate("Card number", 10);
		checkTextInPageAndValidate("Vehicle Details", 10);
		isDisplayed(roadUserCharge, " Road User Charge");
		isDisplayed(rucCustomerNumber, "RUC Customer Number");
		isDisplayed(rucCustomerName, "RUC Customer Name");
		isDisplayed(primaryVehicleReg, " Primary Vehicle Registration field");
		isDisplayed(primaryVehicleLicenceGross, "Primary Vehicle LicenceGross field");
		isDisplayed(primaryVehicleDistance, " Primary Vehicle Distance");
		isDisplayed(secondaryVehicleReg, "Secondary Vehicle Registration field");
		isDisplayed(secondaryVehicleLicenceGross, "Secondary Vehicle Licence Gross field");
		isDisplayed(secondaryVehicleDistance, "Secondary Vehicle Distance");
		isDisplayed(tertiaryVehicleReg, "Tertiary VehicleReg field");
		isDisplayed(tertiaryVehicleLicenceGross, "Tertiary Vehicle Licence Gross field");
		isDisplayed(tertiaryVehicleDistance, "Tertiary Vehicle Distance");
		isDisplayed(returnToPreviousPage, "ReturnToPreviousPage");
	}

	/**
	 * Oder Card - Page Validation
	 */
	public void orderCardPageValidation() {
		isDisplayed(cardDetails, "Card Details");
		isDisplayed(purchaseRestrictions, "Purchase Restrictions");
		isDisplayed(activityLimits, "Unusual Activity Limits");
		isDisplayed(deliveryAddress, "Delivery Address");
	}

	/**
	 * Saved Profile
	 */
	public void clickSavedProfile() {
		clickOrderCardAndValidatePage();
		isDisplayedThenClick(saveProfile, "Click Saved Profile");
		sleep(3);
		isDisplayedThenClick(selectProfile, "Select Profile");
		sleep(3);
		isDisplayedThenClick(saveAndClose, "Apply and Close");
		sleep(3);
		orderCard("Driver");
	}
	
	
	/**
	 * Save Configuration Profile
	 */
	public void saveConfigurationProfile() {
		clickSaveAsConfigurationProfileButton();
		validateSaveAsConfigProfilePopup();
		enterCardConfigProfileName();
		enterCardConfigProfileDesc();
		clickConfigProfileSaveButton();
		sleep(2);
		if(orderSucessmsg.isDisplayed()) {
			logInfo("Save Configuration Profile - Successfully done");	
		} else {
			logInfo("Configuration Profile not done");
		}
		clickConfigProfileCloseBtn();
	}

	/**
	 * Order Card
	 * @param cardFor
	 */
	public void orderCard(String cardFor) {
		if(clickDriverRadioButton.getAttribute("data-summary-value").equals(cardFor)) {
			isDisplayedThenActionClick(clickDriverRadioButton, "Driver radio button");
			sleep(5);
			isDisplayedThenActionClick(cardDriverName, "Driver Name field");
			cardDriverName.sendKeys(fakerAPI().name().name());
			isDisplayedThenActionClick(cardDriverId, "Driver ID");
			cardDriverId.sendKeys(fakerAPI().number().digits(5));
			sleep(3);
		} else {
			clickVehicleRadioButton();
			enterVehicleDescription();
			enterRegoNumber();
		}
		if(clickSelectedFuelProduct.getAttribute("checked")!=null) {
			logInfo("Already Option Checked");
		} else {
			isDisplayedThenClick(clickSelectedFuelProduct, "Click the LPG fuel Product");
			sleep(3);
		}	
		if(cardPurchaseYes.getAttribute("checked")!=null) {
			logInfo("Already Option Checked");
		} else {
			isDisplayedThenClick(cardPurchaseYes, "Click Yes for Lubricants");
			sleep(3);
		}	
		if(clickAllNonFuelsProduct.getAttribute("checked")!=null) {
			logInfo("Already Option Checked");
		} else {
			//isDisplayedThenClick(clickAllNonFuelsProduct, "Click All Non Fuels");
			sleep(3);
		}	
		clickContinueButton();
		validateUnusualActivityLimitsHeader();
		clickContinueButton();
		validateDeliveryAddressHeader();
		clickContinueButton();
		validatePlaceOrderSubPage();	
		orderCardPageValidation();
		orderCardButton.click();
		sleep(2);
		if(orderSucessmsg.isDisplayed()) {
			logPass("New Card Ordered Succesfully");	
		} else {
			logFail("Card Order Fails");
		}
		String orderedCardNo=orderedCardNumber.getText();
		setOrderedCardNumber(orderedCardNo);
		saveConfigurationProfile();
		sleep(2);
	}
	
	//rax added 18/06/19
	public void setOrderedCardNumber(String orderedCardNo) {
		PropUtils.setProps(configProp, "OrderCardNumber", orderedCardNo);
	}
	
	public void clickEditCardFromCardListAndValidate() {
		setCellDataFromTable(cardListTable, 8, false);
		System.out.println("inside edit card");
		List<WebElement> rowElements =  cardListTable.findElements(By.xpath("./tbody[contains(@id,'lform:tableCardList:tb')]/tr"));
		System.out.println("inside rowElements card"+rowElements.size());
		for (int j = 0; j < rowElements.size(); j++) {
			cardTypeStatus = getCellDataFromTable(j+1, 5, false);
			System.out.println("Current card Type::"+cardTypeStatus);
			if ("Vehicle".equals(cardTypeStatus)) {
	
				System.out.println("inside edit card if method");
				clickCardNumber(j+1);
				clickCardTableMenuOption(editCard);
				sleep(5);		
				break;
			} else {
				System.out.println("Edit card sub menu not clicked");
			}
		}
		sleep(10);
	}
	public void clickCardNumber(int index) {
		try {
			isDisplayedThenActionClick(customerNumberList.get(index - 1), "Click selected Card from card list");
			// System.out.println("Get Text for element"+ expAccount.getr);
			sleep(3);

		} catch (Exception e) {
			logInfo(e.getMessage());

		}

	} 
	public void clickCardTableMenuOption(WebElement option) {
		isDisplayedThenActionClick(option, "Card Table Menu");
		//isDisplayedThenClick(option, "Card Table Menu");
		sleep(5);
		// verifyHeaderTitle(titleTOCheck);
	}

	//Raxsana
	public HashMap<String, String> orderCardUsingExcelSheetTemplate(String fileName, String accountNumber, String cardType) {
		IFCSCommonPage ifcsCommonPage = new IFCSCommonPage(driver, test);
		String downloadedFileName = getLatestDownloadedFileFromDir(fileName).getName();
		String downloadedFilePath = System.getProperty("user.home") + "\\Downloads\\" + downloadedFileName;
		HSSFSheet hssfSheet = ExcelUtils.readExcel(downloadedFilePath, "BULKCARD");
		HashMap<String, String> keysAndValues = new HashMap<String, String>();
		int rowCount = 0;
		HSSFRow row = null;
		HSSFCell cell = null;
		keysAndValues = ifcsCommonPage.readKeyAndValueFromPropertyFile(bulkCardOrderInputValuesConfigProp, configProp,
				accountNumber, cardType);
		System.out.println("Keys and values---->" + keysAndValues);
		ArrayList<String> columnHeaders = ExcelUtils.readHeader(hssfSheet, 2);
		if (fileName.equals("Bulk_Order_")) {
			rowCount = getRowNumberForBulkCardOrder(hssfSheet, 2);
			System.out.println("rowCount" + (rowCount));
			row = hssfSheet.getRow(rowCount - 1);
			row = hssfSheet.createRow(rowCount - 1);
			for (int a = 0; a < columnHeaders.size(); a++) {
				for (String entry : keysAndValues.keySet()) {
					if (columnHeaders.get(a).equals(entry)) {
						cell = row.getCell(a);
						cell = row.createCell(a);
						cell.setCellValue(keysAndValues.get(entry));
					}
				}
			}
		}
		ExcelUtils.writeExcel(downloadedFilePath);
		return keysAndValues;
	}

	public int getRowNumberForBulkCardOrder(HSSFSheet workSheet, int rowNum) {
		int i, k = 0, count = 0, defaultCount = 2;
		//System.out.println("Last row num-->" + workSheet.getLastRowNum());
		for (i = rowNum; i < workSheet.getLastRowNum(); i++) {
			for (int j = 0; j < defaultCount; j++) {
				//System.out.println("i-->" + i);
				//System.out.println("j-->" + j);
				String value = workSheet.getRow(i).getCell(j).getStringCellValue();
				//System.out.println("Value" + value);

				if (value.equals("")) {
					k = 1;
					count++;
					break;
				}
			}
			if (k == 1 && count == defaultCount) {
				break;
			}
		}
		return i;
	}

	public String getCardNumberForCardType(HashMap<String, String> keyAndValues, String cardType) {

		String cardNumber = null;
		for (String key : keyAndValues.keySet()) {
			if (cardType.equals("Vehicle")) {
				if (key.equals("RegoNumber")) {
					String cardNumberFromDB = "Select card_no from cards where vehicle_oid in (select vehicle_oid from vehicles where license_plate='"
							+ keyAndValues.get(key) + "')";
					cardNumber = connectDBAndGetValue(cardNumberFromDB,
							PropUtils.getPropValue(configProp, "sqlODSServerName"));
				}
			} else {
				if (key.equals("DriverName")) {
					String cardNumberFromDB = "Select card_no from cards where driver_oid in (select driver_oid from drivers where driver_name='"
							+ keyAndValues.get(key).toUpperCase() + "')";
					cardNumber = connectDBAndGetValue(cardNumberFromDB,
							PropUtils.getPropValue(configProp, "sqlODSServerName"));
				}
			}
		}
		return cardNumber;

	}

	public void validateOrderedCardInOLS(String cardNo) {
		FindAndUpdateCardPage findAndUpdateCardPage = new FindAndUpdateCardPage(driver, test);
		try {
			multiCardSearch.clear();
			enterText(multiCardSearch, cardNo);
			findAndUpdateCardPage.clickSearchButtonInFindUpdateCardPage();
			findAndUpdateCardPage.iterateAndCheckCardNumberIsPresent(cardNo);
		} catch (Exception e) {
			e.getMessage();
		}
	}

	public void clickBulkOrderAndUpdateCard() {

		clickSubMenuAndValidate(cardMenu, bulkCardOrder, bulkCardOrderTitle);
	}

	public void clickBulkCardOrderBtnAndValidate(String fileName) {
		isDisplayedThenActionClick(bulkCardOrderbtn, "Bulk Order Card Button");
		sleep(3);
		isDisplayedThenActionClick(bulkCardOrderdwnld, "Bulk order card download link");
		sleep(2);
		verifyTheDownloadedFile(fileName);
	}
	
	public void bulkOrderUpload(String text) {

		try {
			if(text.equals("Bulk_Order")) {
		isDisplayedThenActionClick(bulkCardUpdate, "UpLoad the Bulk Order");
		mouseHover(browserPopUpOrder);
		sleep(3);
		isDisplayedThenActionClick(browserPopUpOrder, "Browse File");
		}
		else {
			isDisplayedThenActionClick(bulkUploadExcel, "Bulk Upload Excel");
			mouseHover(browserPopUpUpdate);
			sleep(3);
			isDisplayedThenActionClick(browserPopUpUpdate, "Browse File");
		}
		uploadTheExcelSheetFromTheLocal(text);
		sleep(10);
		isDisplayedThenActionClick(upLoadFile, "Upload File");
		sleep(20);
		if(text.equals("Bulk_Order")) {
		isDisplayed(successMsgOrder, "success msg");
		}
		else {
			isDisplayed(successMsgUpdate, "success msg");
		}
		sleep(5);
		
		} catch (Exception e) {
		e.getMessage();
		}
		}
	
	public void assertColumnHeaders(String sheet) {
		CommonPage commonPage = new CommonPage(driver,test);
		String filePath = verifyColumnHeaders();

		//Excel read and validate
		Sheet sheetName = ExcelUtils.readExcel(filePath, sheet);
		ArrayList<String> colHead = ExcelUtils.readHeaderInList((HSSFSheet) sheetName,2);
		ArrayList<String> dbColumnHeader = commonPage.getDescriptionHeadersInDB();
		System.out.println(dbColumnHeader);
		System.out.println(colHead);
		boolean ans ;
		for(int i=0;i<colHead.size();i++) {
			ans= dbColumnHeader.contains(colHead.get(i));
		  if (ans)
		            System.out.println("The list contains "+colHead.get(i));
		        else
		            System.out.println("The list does not contains "+colHead.get(i));
		}
		}
	
	public String verifyColumnHeaders() {
		String fileName = downloadedFile("Bulk_Order");
		String filePath = System.getProperty("user.home") + "//" + "Downloads" + "//" +  fileName;
		return filePath;

		}
	
	public String downloadedFile(String text) {
		String fileName = getLatestDownloadedFileFromDir(text).getName();
		return fileName;
		}
	
	
	
	public HashMap<String, String> bulkCardOrderUsingExcelSheetTemplate(String fileName, String accountNumber, String cardType,int bulkCount)  {
		String downloadedFileName = getLatestDownloadedFileFromDir(fileName).getName();
		String downloadedFilePath = System.getProperty("user.home") + "\\Downloads\\" + downloadedFileName;
		HSSFSheet hssfSheet = ExcelUtils.readExcel(downloadedFilePath, "BULKCARD");
		//HashMap<String, String> keysAndValues = new HashMap<String, String>();
		HashMap<String, String>  validationValues=new HashMap<String, String>();
		//IFCSCommonPage ifcsCommonPage = new IFCSCommonPage(driver, test);
		int rowCount = 0;
		HSSFRow row = null;
		HSSFCell cell = null;
		HashMap<String, String> map = new HashMap<String, String>();
		HashMap<String, Integer> mapInteger = new HashMap<String, Integer>();
		ArrayList<String> columnHeaders = ExcelUtils.readHeader(hssfSheet, 2);
		Set<Object> keys;
		System.out.println("column headers::"+columnHeaders);
		String clientName=PropUtils.getPropValue(configProp, "clientName");
		String clientCountry=PropUtils.getPropValue(configProp, "clientCountry");
		boolean faker;
		String key,value;
		SimpleDateFormat formatter ;
		Date date = new Date();
		String currentIFCSDate;
		Common common=new Common(driver,test);
		for(int i=0;i<bulkCount;i++) {
			/*keysAndValues = ifcsCommonPage.readKeyAndValueFromPropertyFile(bulkCardOrderInputValuesConfigProp, configProp,
					accountNumber, cardType);*/
			//----------------------------------------------------------------------------------------------------------------
			
			keys = bulkCardOrderInputValuesConfigProp.keySet();
			
			// System.out.println("Keys---->"+ keys);
			int value1;
			for (Object k : keys) {
				faker = false;
				key = String.valueOf(k);
				// System.out.println("Key-->"+key);
				value = PropUtils.getPropValue(bulkCardOrderInputValuesConfigProp, key);
				// System.out.println("Value---->"+value);
				if (value.equals("getFakerName")) {
						value = fakerAPI().name().firstName();
						map.put(key, value);
						faker = true;
				} 
				else if(value.equals("getFakerPIN")) {
					value1=Integer.parseInt(fakerAPI().number().digits(4));	
					mapInteger.put(key, value1);
					faker = true;
				}
				else if(value.equals("getProductRestriction")) {
					
					if(clientCountry.equals("AU")) {
						map.put(key, "1A FUEL VM SHP C BG O DNR");
						faker = true;
					}
					else if(clientCountry.equals("NZ")){
						map.put(key, "All Purchases");
						faker = true;
					}
				}
					else if (value.contains("func")) {
					value = accountNumber;
					map.put(key, value);
					faker = true;
				} else if (value.equals("getDriverOrVehicleCardTypeValues")) {
					if (cardType.equals("Driver")) {
						formatter = new SimpleDateFormat("YYMMddHHmmss");
						String currentDate = formatter.format(date);
						map.put("CardType", "Driver");
						map.put("DriverName", fakerAPI().name().firstName() + currentDate);
						map.put("DriverID", "Driver"+fakerAPI().number().digits(4));
						faker = true;
					} else if (cardType.equals("Vehicle")) {
						formatter = new SimpleDateFormat("YYMMmmss");
						String currentDate = formatter.format(date);
						map.put("CardType", "Vehicle");
						map.put("RegoNumber", currentDate);
						map.put("VehicleDescription", fakerAPI().name().firstName() + currentDate);
						faker = true;
					}

				}
				else if(value.equals("getFakerPermName")) {
					value = "PermName"+fakerAPI().number().digits(3);
					map.put(key, value);
					faker = true;
				}
				else if(value.equals("getFakerPermTitle")) {
					value = "PermTitle"+fakerAPI().number().digits(2);
					map.put(key, value);
					faker = true;		
				}
				else if(value.equals("getFakerPermAddress")) {
					value = "PermAddress"+fakerAPI().number().digits(3);
					map.put(key, value);
					faker = true;
				}else if(value.equals("getFakerPermSubAddress")) {
					value = "PermSubAddress"+fakerAPI().number().digits(3);
					map.put(key, value);
					faker = true;
				}else if(value.equals("getFakerPermPostalCode")) {
					value1 = Integer.parseInt(fakerAPI().number().digits(4));
					mapInteger.put(key, value1);
					faker = true;
				}else if(value.equals("getFakerPermState")) {
					value ="PermState"+fakerAPI().number().digits(2);
					map.put(key, value);
					faker = true;
				}else if(value.equals("getFakerTempName")) {
					value = "TempName"+fakerAPI().number().digits(3);
					map.put(key, value);
					faker = true;
				}else if(value.equals("getFakerTempTitle")) {
					value = "TempTitle"+fakerAPI().number().digits(2);
					map.put(key, value);
					faker = true;
				}else if(value.equals("getFakerTempAddress")) {
					value = "TempAddress"+fakerAPI().number().digits(3);
					map.put(key, value);
					faker = true;
				}else if(value.equals("getFakerTempSubAddress")) {
					value = "TempSubAddress"+fakerAPI().number().digits(3);
					map.put(key, value);
					faker = true;
				}else if(value.equals("getFakerTempPostalCode")) {
					value1 = Integer.parseInt(fakerAPI().number().digits(4));
					mapInteger.put(key, value1);
					faker = true;
				}else if(value.equals("getFakerTempState")) {
					value ="TempState"+fakerAPI().number().digits(2);
					map.put(key, value);
					faker = true;
				}else if(value.equals("getExpiryDate")) {
					
					currentIFCSDate=common.getCurrentIFCSDateFromDB(clientName + clientCountry);
					value=common.enterADateValueInStatusBeginDateField("WayFuture",currentIFCSDate);
					map.put(key, value);
					faker = true;
				}
				else if (faker == false) {
					map.put(key, value);
				}
			}
			//----------------------------------------------------------------------------------------------------------------
			//System.out.println("keysAndValuesMap::::"+keysAndValues);
			for (String entry : map.keySet()) {
				if(cardType.equals("Driver")) {
					if(entry.equals("DriverName")) {
						validationValues.put(entry+i,map.get(entry));		
					}
					}else {
					if(entry.equals("RegNumber")){
						validationValues.put(entry+i,map.get(entry));
					}
					}
				}
			//System.out.println("Keys and values---->" + keysAndValues);
			rowCount = getRowNumberForBulkCardOrder(hssfSheet, 2);
			//System.out.println("rowCount" + (rowCount));
			row = hssfSheet.getRow(rowCount - 1);
			row = hssfSheet.createRow(rowCount - 1);
			for (int a = 0; a < columnHeaders.size(); a++) {
				for (String entry : map.keySet()) {
					if (columnHeaders.get(a).equals(entry)) {
						//int cellType=cell.getCellType();
						//System.out.println("cellType::"+cellType);
						cell = row.getCell(a);
						cell = row.createCell(a);
						cell.setCellValue(map.get(entry));
					}
				}
				for (String entry : mapInteger.keySet()) {
					if (columnHeaders.get(a).equals(entry)) {
						int cellType=cell.getCellType();
						System.out.println("cellType::"+cellType);
						cell = row.getCell(a);
						cell = row.createCell(a);
						cell.setCellValue(mapInteger.get(entry));
					}
				}
			}
		
		}
		ExcelUtils.writeExcel(downloadedFilePath);
		return validationValues;
	}
	
	public ArrayList<String> getBulkCardNumberForCardType(HashMap<String, String> keyAndValues, String cardType) {
		String cardNumberFromDB ;
		String cardNumber = null;
		ArrayList<String> bulkCardNumbers=new ArrayList<String>();
		for(int i=0;i<keyAndValues.size();i++) {
		for (String key : keyAndValues.keySet()) {
			if (cardType.equals("Vehicle"+i)) {
				if (key.equals("RegoNumber")) {
					cardNumberFromDB= "Select card_no from cards where vehicle_oid in (select vehicle_oid from vehicles where license_plate='"
							+ keyAndValues.get(key) + "')";
					cardNumber = connectDBAndGetValue(cardNumberFromDB,
							PropUtils.getPropValue(configProp, "sqlODSServerName"));
				}
			} else {
				if (key.equals("DriverName"+i)) {
					cardNumberFromDB = "Select card_no from cards where driver_oid in (select driver_oid from drivers where driver_name='"
							+ keyAndValues.get(key).toUpperCase() + "')";
					cardNumber = connectDBAndGetValue(cardNumberFromDB,
							PropUtils.getPropValue(configProp, "sqlODSServerName"));
				}
			}
		}
		bulkCardNumbers.add(cardNumber);
		}
		return bulkCardNumbers;

	}
	
	public void validateBulkOrderedCardsInOLS(ArrayList<String> cardNos) {
		FindAndUpdateCardPage findAndUpdateCardPage = new FindAndUpdateCardPage(driver, test);
		try {
			for(int i=0;i<cardNos.size();i++) {
			multiCardSearch.clear();
			enterText(multiCardSearch, cardNos.get(i));
			findAndUpdateCardPage.clickSearchButtonInFindUpdateCardPage();
			findAndUpdateCardPage.iterateAndCheckCardNumberIsPresent(cardNos.get(i));
			}
		} catch (Exception e) {
			e.getMessage();
		}
	}

public void clickGoToCardButtonFirstCard(){
        isDisplayedThenActionClick(btnGoToCard, "Search Card Button on Find and Update Cards menu");
        sleep(6);
    }
    public void clickExistingCardTypeSearchButton(){
        isDisplayedThenActionClick(anExistingCardTypeSearch, "Search Card Button on Find and Update Cards menu");
        sleep(6);
    }
    public void clickExistingCardNumber(){
        isDisplayedThenClick(liExistingCardNumber,"Click on Card Number from Find And Update Cards menu");
    }
}
