﻿using AventStack.ExtentReports;
using Common;
using Common.Utility;
using EnCompass.Testing.Source.PageObjects.Controls;
using NFluent;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Support.UI;
using System;

namespace EnCompass.Testing.Source.PageObjects.Organization.ExpenseManager.AllocationManagement
{
	public partial class AllocationCodes : EnCompassOrgPageModel
	{
        #region XPath page Elements
        private const string _addNewBtnXpath = @"//a[contains(@class,'btn-primary') and text()=' Create']";
        private const string _codeGroupDropdownXpath = @"//select[contains(@id, 'GroupCodes')]";
        private const string _financialCodeTextBoxXpath = @"//input[contains(@id, 'FinancialCode')]";
        private const string _descriptionTextBoxXpath = @"//input[contains(@id, 'Description')]";
        private const string _disabledDropdownXpath = @"//select[contains(@id, 'Disabled')]";
        private const string _searchBtnXpath = @"//input[contains(@id, 'btnSearch')]";
        private const string _exportBtnXpath = @"//input[contains(@id, 'btnExportGridText')]";
        private const string _gridRecordsMessageXpath = @"//td[@class='gridNoRecordsMessage']";
        private const string _confirmDeleteBtnXpath = @"//div[contains(@id, 'Modal')]//button[contains(normalize-space(text()),'Delete')]";
		private static string _createButton = "//div[contains(@id, 'AddItem')]//a[contains(@class,'btn') and contains(normalize-space(text()), 'Create')]";

        #endregion
        #region Page Elements
		private IWebElement _create
		{
			get
			{
				bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_createButton), out IWebElement element);
				Settings.EnCompassExtentTest.Info("_createButton element exist is :" + found);
				Check.That(found).IsTrue();
				return element;
			}
		}

        private IWebElement _addNewBtn
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_addNewBtnXpath), out IWebElement element);
				Settings.EnCompassExtentTest.Info("_addNewBtn element exist is :" + found);
				Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _codeGroupDropdown
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_codeGroupDropdownXpath), out IWebElement element);
				Settings.EnCompassExtentTest.Info("_codeGroupDropdown element exist is :" + found);
				Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _financialCode
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_financialCodeTextBoxXpath), out IWebElement element);
				Settings.EnCompassExtentTest.Info("_financialCode element exist is :" + found);
				Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _descriptionTextBox
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_descriptionTextBoxXpath), out IWebElement element);
				Settings.EnCompassExtentTest.Info("_descriptionTextBox element exist is :" + found);
				Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _disabledDropdown
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_disabledDropdownXpath), out IWebElement element);
				Settings.EnCompassExtentTest.Info("_disabledDropdown element exist is :" + found);
				Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _searchBtn
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_searchBtnXpath), out IWebElement element);
				Settings.EnCompassExtentTest.Info("_searchBtn element exist is :" + found);
				Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _exportBtn
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_exportBtnXpath), out IWebElement element);
				Settings.EnCompassExtentTest.Info("_exportBtn element exist is :" + found);
				Check.That(found).IsTrue();
                return element;
            }
        }

        #endregion

        private IWebElement _gridRecordsMessage
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_gridRecordsMessageXpath), out IWebElement element);
				Settings.EnCompassExtentTest.Info("_gridRecordsMessage element exist is :" + found);
				Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _confirmDeleteBtn
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_confirmDeleteBtnXpath), out IWebElement element);
				Settings.EnCompassExtentTest.Info("_confirmDeleteBtn element exist is :" + found);
				Check.That(found).IsTrue();
                return element;
            }
        }


        private GridControl _financialCodeGrid;
		public GridControl FinancialCodeGrid
		{
			get
			{
				return _financialCodeGrid ?? (_financialCodeGrid = new GridControl("dgAllocations", Driver));
			}
		}

        public void ExportGridText()
        {
			_exportBtn.JSClickWithFocus(Driver, _exportBtnXpath, Settings);
			Settings.EnCompassExtentTest.Info("Clicked on Export Button");
        }

		public void PressAddNew()
		{
            _addNewBtn.JSClickWithFocus(Driver, _addNewBtnXpath, Settings);
            Settings.EnCompassExtentTest.Info("Clicked on Add New Button");
        }

		public void PressSearchBtn()
		{
			_searchBtn.JSClickWithFocus(Driver, _searchBtnXpath, Settings);
			Settings.EnCompassExtentTest.Info("Clicked on Search Button");
		}

		public void SelectCodeGroupByText(string whichText)
		{
			var selectElement = new SelectElement(_codeGroupDropdown);
			selectElement.SelectByText(whichText);
		}

		public void SelectDisabledByText(string whichText)
		{
			var selectElement = new SelectElement(_disabledDropdown);
			selectElement.SelectByText(whichText);
		}

		public string FinancialCode
		{
			get { return _financialCode.GetAttribute("value"); }
			set { _financialCode.Clear(); _financialCode.SendKeys(value); }
		}

		public string Description
		{
			get { return _descriptionTextBox.GetAttribute("value"); }
			set { _descriptionTextBox.Clear(); _descriptionTextBox.SendKeys(value); }
		}

        public void VerifySearchCriteriaNotAvailableInTheGrid(string financialCodeName, string disabled, ExtentTest test)
        {
            FinancialCode = financialCodeName;
            test.Info("Enter financial Code Name to Search");
            SelectDisabledByText(disabled);
            test.Info("Select disabled (Yes/No) to Search");
            PressSearchBtn();
            test.Info("Click search button");
        }

        public void VerifyGridNoRecordsMessageFC(string gridRecordsMessage)
        {
            string _actErrMsg = this.NORecordsMessage;
            Check.That(_actErrMsg).Equals(gridRecordsMessage);
        }

		public void ConfirmDelete()
		{
            IWebElement _confirm = _confirmDeleteBtn;
			_confirm.WaitUntilElementIsInteractable();
			_confirm.JSClickWithFocus(Driver);
		}

        public string NORecordsMessage
        {
            get
            {
                return _gridRecordsMessage.GetAttribute("innerText");
            }
        }

		/// <summary>
		/// Click on Create Button
		/// </summary>
		public void Create()
		{
			_create.JSClickWithFocus(Driver, null, Settings);
			Settings.EnCompassExtentTest.Debug("Clicked on Create Button");
		}

		/// <summary>
		/// Create Financial Codes based on the Fin Group, Value and Description provided
		/// </summary>
		public void CreateFinCodes(string finCodeGrp, string value, string desc)
		{
			AllocationCodeEdit CreateFinCode = new AllocationCodeEdit(Settings);
			CreateFinCode.WaitForLoad();
			CreateFinCode.SelectFinancialCodeGroupByText(finCodeGrp);
			CreateFinCode.FinancialCodeValue = value;
			CreateFinCode.Description = desc;
			CreateFinCode.Enable = true;
			CreateFinCode.Create();
			CreateFinCode.WaitForLoad();
			Check.That(CreateFinCode.HasSuccessMessage).IsTrue();
		}

    }	
	
}
