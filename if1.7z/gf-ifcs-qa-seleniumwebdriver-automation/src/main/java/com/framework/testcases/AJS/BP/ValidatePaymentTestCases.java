package com.framework.testcases.AJS.BP;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.CardMaintenancePage;
import com.framework.pages.AJS.MaintainCustomerPage;
import com.framework.pages.AJS.common.Common;
import com.framework.pages.AJS.common.IFCSCommonPage;
import com.framework.pages.AJS.common.IFCSHomePage;
import com.framework.pages.AJS.common.IFCSLoginPage;
import com.framework.pages.BP.BPHomePage;
import com.framework.pages.OLS.common.FindAndExportTransactionPage;
import com.framework.pages.OLS.common.LoginPage;

/**
 * @author smanikandan
 *
 */
public class ValidatePaymentTestCases extends BaseTest{
	

	/**
	 * Implemented by Nithya
	 * 
	 * @param clientCountry
	 * @param clientName    Business Flow ID:BF-102
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow" })
	public void postManualPaymentFromIFCS(@Optional("BE") String clientCountry, @Optional("WFE") String clientName) {

		test = extent.createTest(clientName + ":" + clientCountry + " TC01_BP_Payments_Cheque_Payment",
				"RQ-144 Customer is paying using cheque payment");
		IFCSLoginPage ifcsLoginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage ifcsHomePage = new IFCSHomePage(driver, test);
		IFCSCommonPage ifcsCommonPage = new IFCSCommonPage(driver, test);
		Common common = new Common(driver, test);
		 ifcsLoginPage.login("IFCS_URL_BP", "IFCS_BP_USERNAME", "IFCS_BP_PASSWORD");
	      // ifcsHomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);
		ifcsLoginPage.setClientCountryCardTypeDetails(clientName, clientCountry, " ");
		// Selecting client from Application Menu
		ifcsHomePage.gotoApplicationAndClickApplicationMenu();
		ifcsHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);
		String customerNumber = common.getActiveOrTemporaryBlockCustomerNoHavingCardsAndRowIndex(1, "Active");
		//ifcsCommonPage.postManualPayments(customerNumber, "Other Payments", clientName + "_" + clientCountry);
		ifcsCommonPage.postManualPayments(customerNumber, "Cheque Payment", clientName + "_" + clientCountry);

		ifcsHomePage.exitIFCS();
	}
	

}
