package com.framework.testcases.AJS.BP.Interface;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.TransactionListPage;
import com.framework.pages.AJS.common.Common;
import com.framework.pages.AJS.common.IFCSHomePage;
import com.framework.pages.AJS.common.IFCSLoginPage;
import com.framework.pages.BP.BPAccountDetailsPage;
import com.framework.pages.BP.BPHomePage;
import com.framework.pages.OLS.common.BPCommonPage;
import com.framework.pages.OLS.common.LoginPage;
import com.github.javafaker.Faker;

public class ValidateAccountTestCases extends BaseTest{

	
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "Smoke" ,"BusinessFlow"})
	public void validateAccountBalanceAlert(@Optional("AU") String clientCountry,
			@Optional("BP") String clientName) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  Cust_AU_009_Account Balance Alert", "Validate Account Balance Alert");
		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		LoginPage loginPage = new LoginPage(driver, test);
		BPHomePage bpHomePage = new BPHomePage(driver, test);
		BPCommonPage bpCommonPage = new BPCommonPage(driver, test);
		Common common=new Common(driver, test);
		BPAccountDetailsPage accountPage=new BPAccountDetailsPage(driver,test);
		TransactionListPage transactionListPage=new TransactionListPage(driver,test);
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		
		loginPage.Login("BP_URL", "BP_UN_Customer_" + clientCountry, "BP_PWD_Customer_" + clientCountry, clientName);
		
		// Calling Functions
		
		bpHomePage.ValidateBPCustomerLogo();
     
		//Below step requires valid mailid as a parameter for execution 
        int transAmount=accountPage.accountBalanceAlert("venkata.davu@wexinc.com");
        
        bpCommonPage.clickHomeMenu();
        String accountNumber =bpCommonPage.getAccountNumber();
        
        loginPage.Logout();
        
        IFCSloginPage.login("IFCS_URL_BP", "IFCS_BP_USERNAME", "IFCS_BP_PASSWORD");
        
    	String currentDate = common.getCurrentIFCSDateFromDB(clientName+clientCountry);
        String ifcsCurrentDate = common.enterADateValueInStatusBeginDateField("Current", currentDate);
		String cardNumber=common.getCardNumberWithCustomerNo(accountNumber);
		String locationNo=common.chooseALocationWithNonFuelProduct("Y");
		String productCode=common.chooseANonFuelProductExtCodeInTheLocation(locationNo,"N","external code");
		
		
		Faker fakerN = new Faker();
		String f_referenceNo = fakerN.number().digits(3);
		IFCSHomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);
		IFCSHomePage.gotoTransactionAndClickManageTransaction();
		
		//Post Manual Transaction
        transactionListPage.enterTransactionBatchDetails(false,String.valueOf(transAmount+100),"1",clientName);
        transactionListPage.enterManualTransactionDetails(ifcsCurrentDate,f_referenceNo,cardNumber,"",locationNo,String.valueOf(transAmount+100),"");
		transactionListPage.enterTransactionLineItems(productCode,String.valueOf(transAmount+100),String.valueOf(transAmount+100),"100");
		transactionListPage.validatePostManualTransaction("Validation successful");
        
		//Run Control-M jobs
        IFCSHomePage.gotoAdminBatchMenuAndChooseClient(clientName,clientCountry);
		common.batchJobExecution("Regular", "Alerts",
				"Generate Alerts");
		common.batchJobExecution("Regular", "Alerts", "Generate an Account Balance Alert Report.");
		
		//validate the Alert message
		transactionListPage.validateAccountAlertMessage(ifcsCurrentDate,accountNumber);
		
		IFCSHomePage.exitIFCS();
		
		
	}
}
