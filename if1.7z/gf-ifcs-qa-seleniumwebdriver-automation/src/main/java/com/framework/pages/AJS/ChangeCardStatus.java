package com.framework.pages.AJS;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

import com.aventstack.extentreports.ExtentTest;
import com.framework.basepage.BasePage;
import com.framework.pages.AJS.common.Common;
import com.framework.repo.Locator_IFCS;
import com.framework.util.SeleniumWrappers;

public class ChangeCardStatus extends BasePage {

	Common common = new Common(driver, test);

	public ChangeCardStatus(WebDriver driver, ExtentTest test) {
		super(driver, test);
		PageFactory.initElements(new AjaxElementLocatorFactory(driver, 15), this);
	}

	@FindBy(xpath = Locator_IFCS.SEARCH_CARD_IN_LEFT_PANEL)
	public WebElement searchCardInLeftPanel;
	@FindBy(xpath = Locator_IFCS.ACCOUNT_STATUS)
	public WebElement accountStatus;
	@FindBy(xpath = Locator_IFCS.SEARCH_RESULTS_TABLE)
	public List<WebElement> searchResultsTable;
	private String cardNo = "";
	private String cardBalance = "";
	//private String CurrentAccountBalance = "";
	private String ActualAccountBalance = "";

	// Double Click on particular cell in the table
	public void verifyCardNumberAndDoubleClick(String cardNo) {

		List<WebElement> cardsTableHeaders = driver.findElements(
				By.xpath("//div[@class='JViewport']/div[@class='JTableHeader']//div[@class='HeaderRenderer']"));
		int columnNo = SeleniumWrappers.getColumnNoForColumnHeader("Card Number", cardsTableHeaders);
		System.out.println("*******columNo*****" + columnNo);
		// int column=0;
		WebElement cellElement;

		int size;
		try {
			List<WebElement> list = driver
					.findElements(By.xpath("//div[@class='FALTableCellEditor_StrikeThruField JTextComponent']"));
			//SeleniumWrappers.setTotalTableHeaders(cardsTableHeaders.size());
			size = SeleniumWrappers.getTotalNumberOfRows(list, driver);
			// System.out.println(size);
			for (int row = 0; row <= size; row++) {
				System.out.println(row + " " + columnNo);
				System.out.println(SeleniumWrappers.getTableDataWithRowAndColumnNumber(columnNo, row, driver));
				if (SeleniumWrappers.getTableDataWithRowAndColumnNumber(columnNo, row, driver).equals(cardNo)) { // Need to fetch the card number
																						// from database as
																						// NoBalancedAllowed Card
					cellElement = SeleniumWrappers.getTableDataWithCellElement(row, columnNo, driver);
					doubleClick(cellElement);
					sleep(10);
					break;
				}
			}
		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
	}

	public void verifyNoBalanceCardNumberAndDoubleClick() {

		List<WebElement> cardsTableHeaders = driver.findElements(
				By.xpath("//div[@class='JViewport']/div[@class='JTableHeader']//div[@class='HeaderRenderer']"));
		int columnNo = SeleniumWrappers.getColumnNoForColumnHeader("Card Number", cardsTableHeaders);
		System.out.println("*******columNo*****" + columnNo);
		// int column=0;
		WebElement cellElement;

		int size;
		try {
			List<WebElement> list = driver
					.findElements(By.xpath("//div[@class='FALTableCellEditor_StrikeThruField JTextComponent']"));
			size = SeleniumWrappers.getTotalNumberOfRows(list, driver);
			// System.out.println(size);
			for (int row = 0; row <= size; row++) {
				System.out.println(row + " " + columnNo);
				System.out.println(SeleniumWrappers.getTableDataWithRowAndColumnNumber(columnNo, row, driver));
				if (SeleniumWrappers.getTableDataWithRowAndColumnNumber(columnNo, row, driver).equals(cardNo)) { // Need to fetch the card number
																						// from database as
																						// NoBalancedAllowed Card
					cellElement = SeleniumWrappers.getTableDataWithCellElement(row, columnNo, driver);
					doubleClick(cellElement);
					sleep(5);
					break;
				}
			}
		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
	}

	public void verifyBalanceCardNumberAndDoubleClick() {
		List<WebElement> cardsTableHeaders = driver.findElements(
				By.xpath("//div[@class='JViewport']/div[@class='JTableHeader']//div[@class='HeaderRenderer']"));
		int columnNo = SeleniumWrappers.getColumnNoForColumnHeader("Card Number", cardsTableHeaders);
		System.out.println("*******columNo*****" + columnNo);
		// int column=0;
		WebElement cellElement;

		int size;
		try {
			List<WebElement> list = driver
					.findElements(By.xpath("//div[@class='FALTableCellEditor_StrikeThruField JTextComponent']"));
			size = SeleniumWrappers.getTotalNumberOfRows(list, driver);
			// System.out.println(size);
			for (int row = 0; row <= size;) {
				/*System.out.println("Expected Row and Col:"+row + " " + columnNo);
				System.out.println("Data Got:"+SeleniumWrappers.getTableDataWithRowAndColumnNumber(columnNo, row, driver));
				if (SeleniumWrappers.getTableDataWithRowAndColumnNumber(columnNo, row, driver).equals(cardNo)) { // Need to fetch the card number
*/				// NoBalancedAllowed Card
					cellElement = SeleniumWrappers.getTableDataWithCellElement(row, columnNo, driver);
					doubleClick(cellElement);
					sleep(10);
					break;
				//}
			}
		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
	}

	public String searchCardsWithNoBalanceOrWithBalanceAndsetInContext(String cardinfo, String cardStatus) {
		isDisplayed(searchCardInLeftPanel, "Search Card");
		if (cardinfo.equals("withBalance")) {
			cardNo = common.getCardsWithStatusAndWithBalance(cardStatus);

		} else if (cardinfo.equals("noBalance")) {
			cardNo = common.getActiveCardsWithNoBalance();
		}
		sleep(3);
		common.clickDetailSearchIfFilterFieldsNotPresent();
		enterValueInTextBox("Filter By", "Card Number", cardNo);
		sleep(2);
		common.searchListTorch();
		sleep(2);
		return cardNo;
	}

	public void changeCardStatusAndClickNoAndValidate(String changeStatus) {

		chooseSubMenuFromLeftPanel("Card Maintenance", "Card Status");
		chooseOptionFromComboPopup("New", changeStatus);
		sleep(5);
		common.clickSaveIcon();
		sleep(5);
		common.clickNoButton();
		sleep(5);
		// common.verifyContainsInBottomLeftMessage("Card status changed OK");
		String currentStatus = common.getValueFromProtectedTextBox("Change Card Status", "Current status");

		if (currentStatus.equalsIgnoreCase(changeStatus)) {
			logPass("Card status changed successfully");

		} else if (currentStatus.equalsIgnoreCase("Card Ordered")) {
			logPass("Card status was changed successfully - Active to Lost");

		} else {
			logFail("Expected card status is not present");
		}
		verifyValidationResult("Card status changed OK");
	}

	public void changeCardStatusAndClickYesAndValidate(String changeStatus) {

		// String clientName = PropUtils.getPropValue(configProp, "clientName");

		chooseSubMenuFromLeftPanel("Card Maintenance", "Card Status");
		chooseOptionFromComboPopup("New", changeStatus);
		sleep(5);
		common.clickSaveIcon();
		sleep(5);

		if (!(changeStatus.equals("Cancelled") || changeStatus.equals("Active") || changeStatus.equals("100 Normal Service") )) {
			common.clickYesButton();
		}

		sleep(10);
		// common.verifyContainsInBottomLeftMessage("Card status changed OK");
		String currentStatus = common.getValueFromProtectedTextBox("Change Card Status", "Current status");
		System.out.println("Current status: " + currentStatus );
		System.out.println("change status: " + changeStatus );
		if (currentStatus.equalsIgnoreCase(changeStatus)) {
			logPass("Card status changed successfully");
			if (!(changeStatus.equals("Cancelled") || changeStatus.equals("Active")|| changeStatus.equals("100 Normal Service") || changeStatus.equals("Temporary Card Close") )) {
				verifyValidationResult("Card Reissue submitted OK");
			} else {
				verifyValidationResult("Card status changed OK");
			}
		} else if (currentStatus.equalsIgnoreCase("Card Ordered")) {
			logPass("Card status was changed successfully - Active to Lost");

		}
		/*
		 * else if (currentStatus.equalsIgnoreCase("Requested not issued")){
		 * logPass("Card status was changed successfully - Active to Damage - Requested not issued"
		 * );
		 * 
		 * }
		 */
		else {
			logFail("Expected card status is not present");
		}

	}

	public void validateCardStatus(String status) {

		List<WebElement> cardsTableHeaders = driver.findElements(
				By.xpath("//div[@class='JViewport']/div[@class='JTableHeader']//div[@class='HeaderRenderer']"));
		int columnNo = SeleniumWrappers.getColumnNoForColumnHeader("Status", cardsTableHeaders);
		System.out.println("*******columNo*****" + columnNo);
		// int column=0;

		int size;
		try {
			List<WebElement> list = driver
					.findElements(By.xpath("//div[@class='FALTableCellEditor_StrikeThruField JTextComponent']"));
			size = SeleniumWrappers.getTotalNumberOfRows(list, driver);
			System.out.println(size);
			for (int row = 0; row <= size; row++) {
				System.out.println(row + " " + columnNo);
				System.out.println(SeleniumWrappers.getTableDataWithRowAndColumnNumber(columnNo, row, driver));
				if (SeleniumWrappers.getTableDataWithRowAndColumnNumber(columnNo, row, driver).equals(status)) {
					logPass("Card status changed sucssfully");
					break;
				}
			}
		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
	}

	public void checkCurrentAvailableBalance(String currentBalance, String updatedBalance, String beforeCardBalance,
			String accountOrCardflag) {

		if (accountOrCardflag.equalsIgnoreCase("Account")) {
			Double beforecardBal = Double.parseDouble(beforeCardBalance);
			Double beforeAccountBal = Double.parseDouble(currentBalance);
			Double CurrentAccountBalance = beforecardBal + beforeAccountBal;

			System.out.println(
					"Current Account Bal:- " + CurrentAccountBalance + "Actual Account Balance" + updatedBalance);

			if (String.valueOf(CurrentAccountBalance).equalsIgnoreCase(updatedBalance)) {
				logPass("Card balance was added successsfully to the Account");
			} else {
				logFail("Balance is not updated");
			}
		} else if (accountOrCardflag.equalsIgnoreCase("Card")&&beforeCardBalance!=" ") {
			Double beforecardBal = Double.parseDouble(beforeCardBalance);
			if(!(beforecardBal==0)) {
			if (!currentBalance.equals(updatedBalance)) {

				logPass("Card balance is different- And upadated Balance" + updatedBalance);

			} else {
				logFail("Card Balance is not updated" + updatedBalance);

			}
			}else {
				logInfo("Card has no balance");
			}

		}

		else if (accountOrCardflag.equalsIgnoreCase("DamagedNoReplace")) {
			if (currentBalance.equals(updatedBalance)) {

				logPass("Card status is upadated to Damaged and Before Balance" + currentBalance + " And After Balance"
						+ updatedBalance + " is same");

			} else {
				logFail("Card Balance is updated " + currentBalance + " To" + updatedBalance);

			}
		}
		logInfo("Card has no balance");
	}

	public String getCardBalance() {

		cardBalance = common.getValueFromProtectedTextBox("Balance", "Available Balance");
		System.out.println("Card Bal:" + cardBalance);
		sleep(5);
		return cardBalance;

	}

	public String getAccountBalance() {

		ActualAccountBalance = common.getValueFromProtectedTextBox("Account Status", "Available Balance");
		System.out.println("Account Bal:" + ActualAccountBalance);
		sleep(5);
		return ActualAccountBalance;

	}
	
	
	public void updateExistingCardFeeProfile()
	{
		chooseSubMenuFromLeftPanel("Card Details", "Cards");
		sleep(5);
		ScrollToElement("Filter By", "Card Status");
		chooseOptionFromDropdown("Card Status", "Normal Service");
		common.searchListTorch();
		sleep(5);
		if(common.isValidationMessageExists("Record Read OK - Page Size"))
		{
		isDisplayedThenDoubleClick(searchResultsTable.get(0).findElement(By.xpath(".//div[@class]")),
				"Selected a row from search result");
		}
		else
		{
			logInfo("Details not found");
		}
		// to select charge fee checkbox, its in disabled, no updated from WFE team
	}

	public void validateCustomerHasCards() {

		chooseSubMenuFromLeftPanel("Card Details", "Cards");
		sleep(2);
		common.searchListTorch();
		sleep(5);
		verifyValidationResult("Record Read OK - Page Size");
		sleep(5);
	}

	public void changeCustomerAccountStatus(String accountDropDownStatus) {

		isDisplayed(accountStatus, "Account status");
		ScrollToElement("Account Status","Status");
		chooseOptionFromDropdown("Status", accountDropDownStatus);
		common.clickSaveIcon();
		sleep(3);
	}

	public void validateTemporaryLockStatusInCards(String customerCardStatus) {
		List<WebElement> cardsTableHeaders = driver.findElements(
				By.xpath("//div[@class='JViewport']/div[@class='JTableHeader']//div[@class='HeaderRenderer']"));
		int columnNo = SeleniumWrappers.getColumnNoForColumnHeader("Status", cardsTableHeaders);
		System.out.println("*******columNo*****" + columnNo);

		int size;
		try {
			List<WebElement> list = driver
					.findElements(By.xpath("//div[@class='FALTableCellEditor_StrikeThruField JTextComponent']"));
			SeleniumWrappers.setTotalTableHeaders(cardsTableHeaders.size());
			size = SeleniumWrappers.getTotalNumberOfRows(list, driver);
			System.out.println(size);
			for (int row = 0; row < size; row++) {
				System.out.println(row + " " + columnNo);
				// System.out.println(SeleniumWrappers.getTableCellValue(row,columnNo));
				String cardStatus = SeleniumWrappers.getTableDataWithRowAndColumnNumber(columnNo, row,driver);
				System.out.println("Card Status is" + cardStatus);

				if (cardStatus.equals(customerCardStatus)) {
					logPass("Card Status" + cardStatus + "Changed successfully");
				} else {
					logFail("Expected Card Status is not changed successfully");
				}
			}
		} catch (Exception ex) {
			logFail(ex.getMessage());
		}

	}

	public void validateActiveStatusInCards() {
		List<WebElement> cardsTableHeaders = driver.findElements(
				By.xpath("//div[@class='JViewport']/div[@class='JTableHeader']//div[@class='HeaderRenderer']"));
		int columnNo = SeleniumWrappers.getColumnNoForColumnHeader("Status", cardsTableHeaders);
		System.out.println("*******columNo*****" + columnNo);

		int size;
		try {
			List<WebElement> list = driver
					.findElements(By.xpath("//div[@class='FALTableCellEditor_StrikeThruField JTextComponent']"));
			size = SeleniumWrappers.getTotalNumberOfRows(list, driver);
			System.out.println(size);
			for (int row = 0; row < size; row++) {
				System.out.println(row + " " + columnNo);
				// System.out.println(SeleniumWrappers.getTableCellValue(row,columnNo));
				String cardStatus = SeleniumWrappers.getTableDataWithRowAndColumnNumber(columnNo, row, driver);
				System.out.println("Card Status is" + cardStatus);

				if (cardStatus.equals("700 No Transactions") || (cardStatus.equals("100 Normal Service"))) {
					logPass("Card Status" + cardStatus + " Changed successfully ");
				} else
					logFail("Expected Card Status is not Changed successfully");

			}

		} catch (Exception ex) {
			logFail(ex.getMessage());
		}

	}
	
	public void validateStatusInCardsAfterUnblock() {
		List<WebElement> cardsTableHeaders = driver.findElements(
				By.xpath("//div[@class='JViewport']/div[@class='JTableHeader']//div[@class='HeaderRenderer']"));
		int columnNo = SeleniumWrappers.getColumnNoForColumnHeader("Status", cardsTableHeaders);
		System.out.println("*******columNo*****" + columnNo);

		int size;
		try {
			List<WebElement> list = driver
					.findElements(By.xpath("//div[@class='FALTableCellEditor_StrikeThruField JTextComponent']"));
			size = SeleniumWrappers.getTotalNumberOfRows(list, driver);
			System.out.println(size);
			for (int row = 0; row < size; row++) {
				System.out.println(row + " " + columnNo);
				// System.out.println(SeleniumWrappers.getTableCellValue(row,columnNo));
				String cardStatus = SeleniumWrappers.getTableDataWithRowAndColumnNumber(columnNo, row, driver);
				System.out.println("Card Status is" + cardStatus);

				if (!(cardStatus.equals("400 Temporary Acct Lock"))) {
					logPass("Card Status" + cardStatus + " changed successfully ");
				} else
					logFail("Expected Card Status is not changed successfully at index:" + row);
			}

		} catch (Exception ex) {
			logFail(ex.getMessage());
		}

}
	
	

}
