using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using Common;
using Common.PageObjects;
using Common.ScenarioConfigurations;
using Common.Utility;

namespace EnCompass.Testing.Source.PageObjects.SuperAdmin.MccGroup 
{
	/// <summary>
	/// Auto-generated Page Model Class
	/// Navigation Paths: 
		/// [Organization Home]->Merchant Category Codes->Company Groups
		/// </summary>
	[PageModel(@"/superAdmin/mccGroup/Company.aspx")]
	public partial class Company : EnCompassSuperPageModel 
	{
		public override string RelativeUrl => @"/superAdmin/mccGroup/Company.aspx";
		public override string PageIdentifierXPath_Generated => @"//li[contains(@class, 'breadcrumb-item active')][text() = 'Company Groups']";

		#region Navigation
		
		private void NavigateToMenuItem(IWebElement element)
		{
			Driver.Url = element.GetAttribute("href");
		}
		#endregion

		public Company(GlobalSettings settings) : base(settings) { }
	}  
}
