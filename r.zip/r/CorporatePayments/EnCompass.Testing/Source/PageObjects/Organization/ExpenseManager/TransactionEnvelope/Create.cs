﻿using Common;
using Common.Utility;
using EnCompass.Testing.Source.PageObjects.Controls;
using NFluent;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EnCompass.Testing.Source.PageObjects.Organization.ExpenseManager.TransactionEnvelope
{
    [PageModel(@"/expenseManager/transactionEnvelope/create.aspx")]

    public partial class Create : EnCompassOrgPageModel
    {
        public override string RelativeUrl => @"/expenseManager/transactionEnvelope/create.aspx";
        public override string PageIdentifierXPath_Generated => @"//h1[normalize-space(text())='Create']";

        #region Navigation

        private void NavigateToMenuItem(IWebElement element)
        {
            Driver.Url = element.GetAttribute("href");
        }
        #endregion

        public Create(GlobalSettings settings) : base(settings) { }

        #region XPath page Elements

        private const string _searchCriteriaSearchTermXPath = @"//div[contains(@id, 'SearchOutput')]/select[1]";
        private const string _searchCriteriaFilterTypeXPath = @"//div[contains(@id, 'SearchOutput')]/select[2]";
        private const string _searchCriteriaTextSearchValueXPath = @"//div[contains(@id, 'SearchOutput')]/input[1]";
        private const string _searchCriteriaListboxSearchValueXPath = @"//div[contains(@id, 'SearchOutput')]/select[3]";
        private const string _searchCriteriaResetBtnXPath = @"//input[@type='button' and @value='Reset']";
        private const string _searchCriteriaAddBtnXPath = @"//input[@type='button' and @value='Add']";
        private const string _searchXPath = @"//input[contains(@id, 'btnSearch')]";
        private const string _employeeFirstNameXPath = @"//input[contains(@id, 'EmployeeFirstName')]";
        private const string _employeeLastNameXPath = @"//input[contains(@id, 'EmployeeLastName')]";
        private const string _envelopeNameXPath = @"//input[contains(@id, 'EnvelopeName')]";
        private const string _dateSelectionMonthXPath = @"//input[contains(@id, 'rbMonth')]";
        private const string _dateSelectionMonthLabelXPath = @"//label[contains(@for, 'rbMonth')]";
        private const string _dateSelectionCustomXPath = @"//input[contains(@id, 'rbCustom')]";
        private const string _dateSelectionCustomLabelXPath = @"//label[contains(@for, 'rbCustom')]";
        private const string _customDateStartDayXPath = @"//input[contains(@id, 'tbCustomStart')]";
        private const string _customDateEndDayXPath = @"//input[contains(@id, 'tbCustomEnd')]";
        private const string _saveEnvelopeXPath = @"//input[contains(@id, 'Create')]";
        private const string _cancelEnvelopeXPath = @"//input[contains(@id, 'cmdClose')]";
        private const string _selectMonthXPath = @"//select[contains(@id, 'ddlMonth')]";
        private const string _emulatedProxyUserXPath = @"//p[contains(text(),'You are emulating')]//following-sibling::strong";
        private const string _autoFillCheckboxXPath = @"//input[contains(@id, 'CheckBoxAutofillEnvelope')]";
        private const string _rbCycleXPath = @"//input[contains(@id, 'rbCycle')]";
        private const string _ddlCycleXPath = @"//select[contains(@id, 'ddlCycle')]";
        private string _OOPButtonXpath = "//a[contains(@id, 'selectAccount_oop')]";
        #endregion

        #region Page Elements

        private IWebElement _searchCriteriaSearchTerm
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_searchCriteriaSearchTermXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_searchCriteriaSearchTerm element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _searchCriteriaFilterType
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_searchCriteriaFilterTypeXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_searchCriteriaFilterType element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _searchCriteriaTextSearchValue
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_searchCriteriaTextSearchValueXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_searchCriteriaTextSearchValue element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _searchCriteriaListboxSearchValue
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_searchCriteriaListboxSearchValueXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_searchCriteriaListboxSearchValue element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _searchCriteriaResetBtn
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_searchCriteriaResetBtnXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_searchCriteriaResetBtn element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _searchCriteriaAddBtn
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_searchCriteriaAddBtnXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_searchCriteriaAddBtn element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _search
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_searchXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_search element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _employeeFirstName
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_employeeFirstNameXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_employeeFirstName element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _employeeLastName
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_employeeLastNameXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_employeeLastName element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _envelopeName
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_envelopeNameXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_envelopeName element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _dateSelectionMonth
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_dateSelectionMonthXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_dateSelectionMonth element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _dateSelectionMonthLabel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_dateSelectionMonthLabelXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_dateSelectionMonthLabel element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _dateSelectionCustom
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_dateSelectionCustomXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_dateSelectionCustom element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _dateSelectionCustomLabel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_dateSelectionCustomLabelXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_dateSelectionCustomLabel element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _customDateStartDay
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_customDateStartDayXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_customDateStartDay element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _customDateEndDay
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_customDateEndDayXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_customDateEndDay element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _saveEnvelope
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_saveEnvelopeXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_saveEnvelope element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _cancelEnvelope
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_cancelEnvelopeXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_cancelEnvelope element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _selectMonth
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_selectMonthXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_selectMonth element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _emulatedProxyUser
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_emulatedProxyUserXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_emulatedProxyUser element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _autoFillCheckbox
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_autoFillCheckboxXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_autoFillCheckbox element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _rbCycle
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_rbCycleXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_rbCycle element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _ddlCycle
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_ddlCycleXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_ddlCycle element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        #endregion

        public void setAutoFillCheckbox(string value)
        {
            _autoFillCheckbox.SetCheckboxStateWithLabelJS(Driver, value.ToLowerInvariant().Equals("check"));
        }
        public bool IsCustomDate { get; set; } = false;

        public void SetSearchCriteriaSearchTerm(string whichText)
        {
            var selectElement = new SelectElement(_searchCriteriaSearchTerm);
            selectElement.SelectByText(whichText);
        }

        public void SetSearchCriteriaSearchTermByValue(string whichText)
        {
            var selectElement = new SelectElement(_searchCriteriaSearchTerm);
            selectElement.SelectByValue(whichText);
        }

        public string SearchCriteriaTextSearchValue
        {
            set
            {
                _searchCriteriaTextSearchValue.SendKeys(value);
            }
        }

        public void SetSearchCriteriaListboxSearchValue(string whichText)
        {
            var selectElement = new SelectElement(_searchCriteriaListboxSearchValue);
            selectElement.SelectByText(whichText);
        }

        public void Reset()
        {
            _searchCriteriaResetBtn.JSClickWithFocus(Driver);
        }
        public void Add()
        {
            _searchCriteriaAddBtn.JSClickWithFocus(Driver);
        }

        public void Search()
        {
            _search.JSClickWithFocus(Driver);
            WaitForLoad();
        }

        private GridControl _cardSearchGrid;
        public GridControl CardSearchGrid
        {
            get
            {
                return _cardSearchGrid ?? (_cardSearchGrid = new GridControl("dgAccounts", Driver));
            }
        }

        public string FirstName
        {
            get { return _employeeFirstName.GetAttribute("value"); }
            set { _employeeFirstName.Clear(); _employeeFirstName.SendKeys(value); }
        }

        public string LastName
        {
            get { return _employeeLastName.GetAttribute("value"); }
            set { _employeeLastName.Clear(); _employeeLastName.SendKeys(value); }
        }

        public string EnvelopeName
        {
            get
            {
                return _envelopeName.GetAttribute("value");
            }
            set
            {
                _envelopeName.WaitUntilElementIsInteractable();
                _envelopeName.Clear();
                _envelopeName.SendKeys(value);
            }
        }

        public void ClickDateSelectionMonth()
        {
            _dateSelectionMonth.SetRadioButtonStateWithLabel(_dateSelectionMonthLabel, true);
        }

        public void ClickDateSelectionCustom()
        {
            _dateSelectionCustom.SetRadioButtonStateWithLabel(_dateSelectionCustomLabel, true);
        }

        public void ClickCycle()
        {
            _rbCycle.JSClickWithFocus(Driver);
        }

        public bool DateSelectionMonth
        {
            get { return _dateSelectionMonth.Selected; }
            set { _dateSelectionMonth.SetRadioButtonState(value); }
        }

        public bool DateSelectionCustom
        {
            get { return _dateSelectionCustom.Selected; }
            set { _dateSelectionCustom.SetRadioButtonState(value); }
        }

        public string CustomDateStart
        {
            get { return _customDateStartDay.GetAttribute("value"); }
            set
			{
                _customDateStartDay.Clear();
                _customDateStartDay.SendKeys(value);
				Settings.EnCompassExtentTest.Info("CustomDateStart to set to :" + value);
			}
        }

        public string CustomDateEnd
        {
            get { return _customDateEndDay.GetAttribute("value"); }
            set
			{
                _customDateEndDay.Clear();
                _customDateEndDay.SendKeys(value);
				Settings.EnCompassExtentTest.Info("CustomDateEnd to set to :" + value);
			}
        }

        public void OutOfPocketBtn()
        {
            Driver.FindElement(By.XPath(_OOPButtonXpath)).JSClickWithFocus(Driver);
        }
        public string SelectMonth
        {
            get
            {
                Settings.EnCompassWebDriver.WaitForVisible(By.XPath(_selectMonthXPath));
                return new SelectElement(_selectMonth).SelectedOption.Text;
            }
            set
            {
                Settings.EnCompassWebDriver.WaitForVisible(By.XPath(_selectMonthXPath));
                new SelectElement(_selectMonth).SelectByText(value);
            }
        }

        public string SelectCycle
        {
            get
            {
                Settings.EnCompassWebDriver.WaitForVisible(By.XPath(_ddlCycleXPath));
                return new SelectElement(_ddlCycle).SelectedOption.Text;
            }
            set
            {
                Settings.EnCompassWebDriver.WaitForVisible(By.XPath(_ddlCycleXPath));
                new SelectElement(_ddlCycle).SelectByText(value);
            }
        }

        public void Save()
        {
            _saveEnvelope.JSClickWithFocus(Driver);
			this.AttachOnDemandScreenShot();
		}

        public void Cancel()
        {
            _cancelEnvelope.JSClickWithFocus(Driver);
        }
        public void SelectcardByLastName(string lastname)
        {
            IWebElement myCardLink = Settings.EnCompassWebDriver.FindElement(By.XPath(string.Format(".//li[contains(text(),'{0}')]//following-sibling::a[contains(@id,'selectAccount')]", lastname)));
            myCardLink.JSClickWithFocus(Driver);
        }

        public void SelectProxiedCardByLastName(string lastname)
        {
            IWebElement myCardLink = Settings.EnCompassWebDriver.FindElement(By.XPath(string.Format(".//span[contains(text(),'{0}')]//..//a[contains(@id,'proxySelectAccount')]", lastname)));
            myCardLink.JSClickWithFocus(Driver);
        }

        public void SelectProxiedCardByCardNumber(string account)
        {
            IWebElement myCardLink = Settings.EnCompassWebDriver.FindElement(By.XPath(string.Format("//a[contains(text(),'" + account + "')]")));
            myCardLink.JSClickWithFocus(Driver);
        }

        public void SelectOutOfPocketOnly()
        {
            IWebElement outOfPocketOnly = Settings.EnCompassWebDriver.FindElement(By.XPath(string.Format("//a[contains(@id,'selectAccount_oop') or contains(@id,'SelectAccount_oop')]")));
            outOfPocketOnly.JSClickWithFocus(Driver);
        }

        public string EmulatedUserName
        {
            get { return _emulatedProxyUser.Text; }
        }

        //UI_New
        public bool isAutoFillPresent()
        {
            try
            {
                return _autoFillCheckbox.Displayed;
            }
            catch (Exception)
            {
                return false;
            }
            
        }

        public bool IsOOPButtonEnabled
        {
            get
            {
                if (Driver.TryFindElement(By.XPath(@_OOPButtonXpath), out IWebElement element))
                {
                    return element.Enabled;
                }
                else
                    return false;
            }
        }

    }
}
