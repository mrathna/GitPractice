package com.framework.testcases.OLS.BP.Merchant;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.BP.BPHomePage;
import com.framework.pages.BP.MerchantSettlementPage;
import com.framework.pages.OLS.common.LoginPage;

public class ValidateMerchantSettlementPage extends BaseTest {
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "Smoke", "Regression" })
	public void merchentSettlement(@Optional("AU") String clientCountry, @Optional("BP") String clientName)
			throws Exception {
		test = extent.createTest(clientName+ ":" +clientCountry+"  BP Merchant Settlement Validation", "Checking BP Merchant Settlement Feature");

		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		BPHomePage bpHomePage = new BPHomePage(driver, test);
		MerchantSettlementPage merchantSettlementPage = new MerchantSettlementPage(driver, test);

		// Call Function
		loginPage.Login("BP_URL", "BP_UN_Merchant_" + clientCountry, "BP_PWD_Merchant_" + clientCountry, clientName);
		bpHomePage.ValidateMerchantLogo();

		// Select input values from Account drop down
		// bpHomePage.selectInputFromAccountDropdown("Rampage National Pty Ltd
		// (0190034832)");

		// Select settlement from transaction menu
		bpHomePage.clickSettlementSubMenuAndValidatePage();

		// findsettlementDetailsForMerchent
		merchantSettlementPage.findsettlementDetailsForMerchent(clientCountry);
		boolean isMerchantsettlementListPresentorNot = merchantSettlementPage.verifySettlementListIsAvailable();
		if(isMerchantsettlementListPresentorNot) {
			merchantSettlementPage.printNoSettlementListPresent();
		}else {
		merchantSettlementPage.clicksettlementList();
		merchantSettlementPage.clickBackToSettlementList();
		}
		merchantSettlementPage.clickExportExcel();

		loginPage.Logout();

	}
}
