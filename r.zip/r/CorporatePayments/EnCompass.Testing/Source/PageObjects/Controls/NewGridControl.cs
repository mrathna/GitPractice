﻿using AventStack.ExtentReports;
using Common;
using Common.Utility;
using EnCompass.Testing.Source.StepDefinitions.ReportStudio;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EnCompass.Testing.Source.PageObjects.Controls
{
    public class NewGridControl
    {
        public enum GridColumnSortOrder
        {
            ASC,
            DESC,
            FORCESORT
        };

        private string _controlIdentifier;
        private IWebDriver _driver;
        private int _defaultRowIndex;
        private string _baseTableHeaderXPath;
        private string _baseEditableGridRow;
        public string _baseTableRowXPath;
        private string _baseActionRelativeXPath;
        private string _baseTableRowXPathWithRowIndex;
        private string _baseTableRowXPathWithRowIndexCustom;
        private string _actionDDLButtonRelativeXPath;
        private string _actionDDLOptionsRelativeXPath;
        private string _baseRowXPathForGridsWithMultipleChildRows;
        private string _basePageSizeXPath;
        private string _headerSortingRelativeXPath;
        private string _gridToolbarColumnsButtonXPath;
        private string _gridToolbarExportButtonXPath;
        private string _gridToolbarFullscreenButtonXPath;
        private string _gridToolbarExportFormatXpath;
        private string _nongridCompareWithPrevious;
        private string _nongridReturnToNewGrid;

        private GlobalSettings _globalSettings;

        public NewGridControl(string controlIdentifier, IWebDriver driver, GlobalSettings settings, int defaultRowIndex = 0)
        {
            _controlIdentifier = controlIdentifier;
            _driver = driver;
            _defaultRowIndex = defaultRowIndex;
            _globalSettings = settings;

            InitializeXPaths();
        }

        private string spinnerXpath = ".//div[contains(@class,'fa-spin')]";
        /// <summary>
        /// This method waits for the form overlay for appearance and disappearance
        /// thus ensuring the form update is completed and its available again for interaction.
        /// </summary>
        void WaitForFormLoadingOverlay(TimeSpan? tSpan = null)
        {
            //certain pages (like JTA) the spiner dosen't appear
            var grids = _driver.FindElements(By.XPath(".//table[@data-encompass-table]"));
            bool gridsLoaded = grids.All(g => g.FindElements(By.XPath("//thead/tr")).Any());

            if (grids.Any() && !gridsLoaded)
            {

                _driver.WaitForVisible(By.XPath(spinnerXpath), tSpan ?? TimeSpan.FromSeconds(10));
                _globalSettings.EnCompassExtentTest.Info($"Found {grids.Count} Grids and at least one was not loaded. Waited for all grids to load");
            }

            _driver.WaitForAbsence(By.XPath(spinnerXpath), tSpan ?? TimeSpan.FromSeconds(20));
            _globalSettings.EnCompassExtentTest.Info($"Waited for spinner icon to disappear");

        }

        public void WaitForGrid()
        {
            //Temporarily switching to the NEW GRID. So, when the Old Grid is completely gone, then update only this method for no code re-work.
            if (_globalSettings.EnCompassWebDriver.TryFindElement(By.XPath(_nongridReturnToNewGrid), out IWebElement element))
            {
                element.JSClickWithFocus(_driver);
            }
            _driver.ScrollToXPATH(_baseTableHeaderXPath);
            // Mobile specific change
            // Since for mobile browser based on view port the header's visibility depends
            if(! String.IsNullOrEmpty(GlobalSettings.MobileDeviceName))
                _driver.WaitFor(By.XPath(_baseTableHeaderXPath));
            else
                _driver.WaitForVisible(By.XPath(_baseTableHeaderXPath));

            WaitForFormLoadingOverlay();
        }

        private void InitializeXPaths()
        {
            _baseTableHeaderXPath = $@"//table[contains(@id, '{_controlIdentifier}')]/thead/tr";
            _baseTableRowXPath = $@"//table[contains(@id, '{_controlIdentifier}')]/tbody/tr";
            _baseTableRowXPathWithRowIndex = $@"//table[contains(@id, '{_controlIdentifier}')]/tbody/tr[@data-index='{_defaultRowIndex}']";
            _baseTableRowXPathWithRowIndexCustom = string.Format(@"//table[contains(@id, '{0}')]/tbody/tr[@data-index='{1}']", _controlIdentifier, "{0}");
            _baseActionRelativeXPath = @"//td/div[contains(@class,'card-view') or contains(@class,'btn-group')]//*[normalize-space(text())='{0}']"; // Mobile specific change
            _actionDDLButtonRelativeXPath = "//button[normalize-space(@title)='More Actions']"; // "//following-sibling::button"
            _actionDDLOptionsRelativeXPath = @"//following-sibling::div[contains(@class, 'dropdown-menu')]/*[normalize-space(text()) = '{0}']";
            _baseRowXPathForGridsWithMultipleChildRows = $@"//table[contains(@id,'{_controlIdentifier}')]/tbody/tr[not(contains(@id, '_R'))][not(contains(@class, 'Pager'))]"; // Eg Transaction Grid Table
            _basePageSizeXPath = $@"//table[contains(@id, '{_controlIdentifier}')]/ancestor::div//span[contains(@class, 'page-list')]";
            _gridToolbarColumnsButtonXPath = @"//button[@aria-label = 'Columns']";
            _gridToolbarExportButtonXPath = @"//button[@aria-label = 'Export type']";
            _gridToolbarFullscreenButtonXPath = @"//button[@aria-label = 'Fullscreen']";
            _gridToolbarExportFormatXpath = @"//div[contains(@class, 'dropdown-menu')]/a[@data-type='{0}']";
            _baseEditableGridRow = $@"//table[contains(@id, 'etMLogs')]/tbody/tr/td/input";
            _nongridCompareWithPrevious = $@"//input[contains(@id, 'UIVersionToggle') and @value='Switch to Current Grid']";
            _nongridReturnToNewGrid = $@"//input[contains(@id, 'UIVersionToggle') and @value='Switch to New Grid']";
        }

        /// <summary>
        /// The 'Fullscreen' button is always present for the New Grid. So, checking on this element will make sure that the user can access the new grid as opposed to the older one.
        /// </summary>
        /// <returns></returns>
        public bool IsNewGridPresentInPage()
        {
            if (_driver.TryFindElement(By.XPath(_gridToolbarFullscreenButtonXPath), out IWebElement element))
            {
                return element.Displayed;
            }
            else
            {
                return false;
            }
        }

        #region Grid Toolbar Buttons

        /// <summary>
        /// Method to disable all columns applicable of the grid. Relies on AddOrRemoveColumnsToGrid.
        /// </summary>
        public void DisableAllColumns(ExtentTest test)
        {
            string column = "Toggle all";
            // The first time you set false, Toggle All is already false, but none columns is disabled. That will happen only the
            // second time you set it to false.
            AddOrRemoveColumnsToGrid(column, test, false);
            AddOrRemoveColumnsToGrid(column, test, true);
            AddOrRemoveColumnsToGrid(column, test, false);
        }

        /// <summary>
        /// Add new columns to Grid on top of existing columns present or remove existing columns
        /// based on the "addCol" bool value.
        /// if set to true then it adds a col, otherwise it removes or unchecks the col.
        /// </summary>
        public void AddOrRemoveColumnsToGrid(string columnName, ExtentTest test, bool addCol = true)
        {
            string columnNameLabelXPath = $"//div[@title = 'Columns']//div//label[normalize-space(contains(text(), '{columnName}'))]";
            string columnNameCheckboxXPath = $"{columnNameLabelXPath}/preceding-sibling::input";

            IWebElement gridToolbarColumnsButton = _driver.WaitFor(By.XPath(_gridToolbarColumnsButtonXPath));
            gridToolbarColumnsButton.JSClickWithFocus(_driver);
            test.Info("Clicked on 'Columns' button to show list of columns available.");

            IWebElement columnNameCheckbox = _driver.WaitFor(By.XPath(columnNameCheckboxXPath));
            IWebElement columnNameLabel = _driver.WaitForVisible(By.XPath(columnNameLabelXPath));
            test.Info($"Column {columnName} has appeared on UI.");

            // The grid behavior hides the div after you change the status of the checkbox.
            if (columnNameCheckbox.Selected != addCol)
            {
                columnNameCheckbox.SetCheckboxStateWithLabelJS(_driver, addCol);
                test.Info($"Column {columnName} is set to :" + addCol.ToString());
            }

            // If the status of the checkbox is unchanged, we have to regain focus on the grid.
            if(columnNameLabel.Displayed)
            {
                gridToolbarColumnsButton.JSClickWithFocus(_driver);
                test.Info("Cliked on 'Columns' button to hide list of columns available.");
                _driver.WaitForAbsence(By.XPath(columnNameLabelXPath));
                test.Info($"Column {columnName} has disappeared from UI.");
            }
        }

        public bool IsColumnPresentForAddingToGrid(string columnName, ExtentTest test)
        {
            test.Info($@"The column name: {columnName} is being checked if present in the list of columns that can be added to the grid.");

            if (_driver.TryFindElement(By.XPath($@"//div[@title = 'Columns']//div//label[normalize-space(text()) = '{columnName}']"), out IWebElement element))
            {
                test.Info($"Column: {columnName} is present in the list of columns.");
                return true;
            }
            else
            {
                test.Info($"Column: {columnName} is NOT present in the list of columns.");
                return false;
            }
        }

        /// <summary>
        /// Method to edit the value of an editable row in a grid. Index is 0 based. 
        /// </summary>
        /// <param name="headerName"></param>
        /// <param name="index"></param>
        /// <param name="value"></param>
        public void EditGridValueByHeader(string headerName, int index, string value)
        {
            _driver.TryWaitForElementToBeVisible(By.XPath($"{_baseEditableGridRow}[@id = '{headerName}_{index}']"), out IWebElement gridInput);
            gridInput.Clear();
            gridInput.SendKeys(value);
        }

        public void SetMerchantLogStatus(string status, int index)
        {
            _driver.TryWaitForElementToBeVisible(By.XPath($"{_baseTableRowXPath}[{index}]//td/select[@data-field = 'StatusOptions']"), out IWebElement gridStatus);
            var selectElement = new SelectElement(gridStatus);
            gridStatus.SetListboxByText(status);
        }

        /// <summary>
        /// Expand the Details view by the "row" index number
        /// </summary>
        /// <param name="rowIndex"></param>
        public void ExpandDetailsByIndex(int rowIndex)
        {
            IWebElement chevron;
            string attribute = String.Empty;
            if (GlobalSettings.DeviceType.Equals(GlobalSettings.Device.MOBILE.ToString()))
            {
                _driver.TryWaitForElementToBeVisible(By.XPath($@"{_baseTableRowXPath}[{rowIndex}]/td//span[text()='Expand']/ancestor::a"), out chevron, TimeSpan.FromSeconds(5));
                attribute = "text";
            }
            else
            {
                _driver.TryWaitForElementToBeVisible(By.XPath($@"{_baseTableRowXPath}[{rowIndex}]/td/a"), out chevron, TimeSpan.FromSeconds(5));
                attribute = "title";
            }

            var IsExpand = chevron.GetAttribute(attribute).Trim();
            if (IsExpand == "Expand")
                chevron.JSClickWithFocus(_driver);
        }

        /// <summary>
		/// Collapse the Details view by the "row" index number
		/// </summary>
		/// <param name="rowIndex"></param>
		public void CollapseDetailsByIndex(int rowIndex)
        {
            _driver.TryWaitForElementToBeVisible(By.XPath($@"({_baseTableRowXPath}/td/a)[{rowIndex}]"), out IWebElement chevron, TimeSpan.FromSeconds(5));
            var IsExpand = chevron.GetAttribute("title");
            if (IsExpand == "Collapse")
                chevron.JSClickWithFocus(_driver);
        }
        /// <summary>
        /// You can have more than one Details view open on the page. Specify the xpath index, and the name of the details record that you want to retrieve. You must expand the details view before this will work.
        /// </summary>
        /// <param name="name"></param>
        /// <param name="index"></param>
        /// <returns></returns>
        public string GetDetailsValueByName(string name, int index)
        {
            _driver.TryWaitForElementToBeVisible(By.XPath($@"{_baseTableRowXPath}[{index}]/following-sibling::tr[1]//li[normalize-space(text()) = '{name}:']/strong"), out IWebElement element);
            return element.Text;
        }

        /// <summary>
        /// Expand the row first. This method will fill a fillable area inside the details accordion 
        /// </summary>
        /// <param name="index"></param>
        /// <param name="name"></param>
        /// <param name="text"></param>
        public void FillDetailsTextByLabelName(int index, string name, string text)
        {
            _driver.TryWaitForElementToBeVisible(By.XPath($@"{_baseTableRowXPath}[{index}]/following-sibling::tr[1]//label[normalize-space(text()) = '{name}']"), out IWebElement label);
            var id = label.GetAttribute("for");
            var element = _driver.FindElement(By.XPath($"//*[@id = '{id}']"));
            element.Clear();
            element.SendKeys(text);
        }


        /// <summary>
        /// Expand the row first. This method will get the text inside the details accordion 
        /// </summary>
        /// <param name="index"></param>
        /// <param name="name"></param>
        /// <returns></returns>
        public string GetDetailsTextByLabelName(int index, string name)
        {
            _driver.TryWaitForElementToBeVisible(By.XPath($@"{_baseTableRowXPath}[{index}]/following-sibling::tr[1]//label[normalize-space(text()) = '{name}']"), out IWebElement label, TimeSpan.FromSeconds(3));
            var id = label.GetAttribute("for");
            var element = _driver.FindElement(By.XPath($"//*[@id = '{id}']"));
            if (element.Text == string.Empty)
            {
                var attribute = element.GetAttribute("data-stored-value");
                return attribute;
            }
            return element.Text;
        }

        /// <summary>
        /// Expand the row first. This method will click the Find button for Transactions Codes
        /// </summary>
        /// <param name="index"></param>
        /// <param name="name"></param>
        public void ClickFindByLableName(int index, string name)
        {
            _driver.TryWaitForElementToBeVisible(By.XPath($@"{_baseTableRowXPath}[{index}]/following-sibling::tr[1]//label[normalize-space(text()) = '{name}']"), out IWebElement label);
            var id = label.GetAttribute("for");
            var element = _driver.FindElement(By.XPath($"//button[contains(@onclick, '{id}')]"));
            element.JSClickWithFocus(_driver);
        }

        /// <summary>
        /// Expand the row first. Used to check to see if an editable section is visible  under the details accordion
        /// </summary>
        /// <param name="index"></param>
        /// <param name="name"></param>
        /// <returns></returns>
        public bool IsEditableSectionVisableByLableName(int index, string name)
        {
            var visible = _driver.TryWaitForElementToBeVisible(By.XPath($@"{_baseTableRowXPath}[{index}]/following-sibling::tr[1]//label[normalize-space(text()) = '{name}']/following-sibling::textarea"), out IWebElement element);
            return visible;
        }

        /// <summary>
        /// Returns a list with the details for the row index provided.
        /// </summary>
        /// <param name="index">Index of the row</param>
        /// <returns></returns>
        public List<string> GetDetailsHeaderNames(int index)
        {
            List<string> text = new List<string>();
            var ele = _driver.WaitForElementsToBeVisible(By.XPath($@"{_baseTableRowXPath}[{index}]/following-sibling::tr[1]//h4"));

            foreach (var e in ele)
            {
                text.Add(e.Text);
            }

            return text;
        }

        /// <summary>
        /// Method to export the Grid to a specified format. It uses the Export Grid Toolbar Button.
        /// </summary>
        public void ExportGridAs(string format, ExtentTest test, string exprtFileName = null)
        {
            _driver.TryWaitForElementToBeVisible(By.XPath(_gridToolbarExportButtonXPath), out IWebElement exportButton);
            exportButton.JSClickWithFocus(_driver);
            test.Info("Clicked on Export button.");

            _gridToolbarExportFormatXpath = String.Format(_gridToolbarExportFormatXpath, format.ToLower());
            _driver.TryWaitForElement(By.XPath(_gridToolbarExportFormatXpath), out IWebElement exportFormat);
            exportFormat.JSClickWithFocus(_driver);
            test.Info("Clicked on Format to Export as " + format);
            var reportStudioSteps = new ReportStudioSteps(_globalSettings);
            if (exprtFileName != null)
            {
                if (IsNewGridPresentInPage())
                    reportStudioSteps.ThenIWaitTillTheFileIsDownloadedInDefaultDownloadLocationRenameItAndDoDeleteAction(exprtFileName, false);
                else
                    reportStudioSteps.ThenIWaitTillTheFileSer_PdfIsDownloadedInDefaultDownloadLocation(exprtFileName, false);
            }
        }


        #endregion
        /// <summary>
        /// Method to set grid to Fullscreen or retrun it to its normal size. It uses the FullScreen Grid Toolbar Button.
        /// </summary>
        public void SetGridToFullScreen(bool state, ExtentTest test)
        {
            string tableDivXPath = "/ancestor::div[contains(@class,'bootstrap-table')]";
            IWebElement _fullscreenButton = _driver.WaitFor(By.XPath(_gridToolbarFullscreenButtonXPath));
            IWebElement tableDivElement = _driver.WaitFor(By.XPath(_gridToolbarFullscreenButtonXPath + tableDivXPath));

            string value = tableDivElement.GetAttribute("class");

            if (state)
            {
                if (!value.Contains("fullscreen"))
                {
                    _fullscreenButton.JSClickWithFocus(_driver);
                    test.Info("Clicked on Fullscren. Grid maximized.");
                }
            }
            else
            {
                if (value.Contains("fullscreen"))
                {
                    _fullscreenButton.JSClickWithFocus(_driver);
                    test.Info("Clicked on Fullscren. Grid minimzed.");
                }
            }
        }

        #region Table Header



        /// <summary>
        /// This method simply checks if the COLUMN HEADER is present in the grid and if so returns TRUE else FALSE.
        /// </summary>
        public bool HeaderColumnExist(string colHeaderName)
        {
            var precedingHeaderXPath = $@"{_baseTableHeaderXPath}/th/*[@data-field='{colHeaderName}' or contains(normalize-space(text()), '{colHeaderName}') or contains(@data-field, translate('{colHeaderName}',' ',''))]";
            var precedingHeaders = _driver.FindElements(By.XPath(precedingHeaderXPath));

            if (precedingHeaders.Count == 0)
            {
                _globalSettings.EnCompassExtentTest.Info($"Header Column {colHeaderName} was NOT found on the grid.");
                return false;
            }
            else
            {
                _globalSettings.EnCompassExtentTest.Info($"Header Column {colHeaderName} was found on the grid.");
                return true;
            }
        }

        /// <summary>
        /// Clicks a Table Header Column for Sorting it as per the name of the col specified. Works in 3 modes :
        /// Ascending ,Descending and Force Sort.  
        /// If existing sort order matches either of Asc or Desc it will ignore a sort, however for ForceSort it will always
        /// sort the column no matter the existing order.
        /// </summary>
        public void ClickColumnForSorting(string columnName, GridColumnSortOrder sortOrder = GridColumnSortOrder.FORCESORT)
        {
            string _columnNamepath = $@"{_baseTableHeaderXPath}/th//button[contains(text(), '{columnName.Trim()}')]";

            if (_driver.TryFindElement(By.XPath(_columnNamepath), out IWebElement sortColumn))
            {
                switch (sortOrder)
                {
                    case GridColumnSortOrder.ASC: // click on the column to be sorted ONLY IF the current sort order is NOT ascending
                        if (!sortColumn.GetAttribute("class").ToLowerInvariant().Contains(GridColumnSortOrder.ASC.ToString().ToLowerInvariant()))
                        {
                            sortColumn.JSClickWithFocus(_driver);
                            WaitForGrid();
                        }
                        break;

                    case GridColumnSortOrder.DESC:// click on the column to be sorted ONLY IF the current sort order is NOT descending
                        if (!sortColumn.GetAttribute("class").ToLowerInvariant().Contains(GridColumnSortOrder.DESC.ToString().ToLowerInvariant()))
                        {
                            sortColumn.JSClickWithFocus(_driver);
                            WaitForFormLoadingOverlay();
                        }
                        break;

                    case GridColumnSortOrder.FORCESORT: // No need to check for existing sort order, just blindly force a sort 
                        sortColumn.JSClickWithFocus(_driver);
                        WaitForFormLoadingOverlay();
                        break;
                }
            }

            else
            {
                throw new NotFoundException($"Element button for column {columnName} not present.");
            }
        }

        #endregion

        #region Perform Actions on Table Rows

        /// <summary>
        /// In the newly created Grid, Edit Action is clubbed with other options (like History, Transactions) as a 
        /// seperate WebElements but binded together in the same control. Hence we need to provide either value
        /// for Action or Options to execute on the grid as an Action.
        /// </summary>
        public void PerformActionByText(string action = null, string option = null, int row = 0)
        {
            _defaultRowIndex = row;
            InitializeXPaths();

            // Verify if Action is null, then try to execute options
            if (String.IsNullOrEmpty(action) || String.IsNullOrWhiteSpace(action))
            {
                //If the action selected by the user is the one already presented in the screen, the test just need to click on it.
                if (String.IsNullOrEmpty(option) || String.IsNullOrWhiteSpace(option))
                    throw new Exception("Either action or option string inputs must have valid value to perform action on the Row");
                else//However, if the user needs an extra option, the select list button should be clicked and the option should be selected.
                {
                    //temporary handle to click in the Reject Transaction button switching for the old grid
                    if (option.Equals("Reject Transaction"))
                    {
                        IWebElement element;
                        if (IsNewGridPresentInPage())
                        {
                            _driver.TryFindElement(By.XPath(_nongridCompareWithPrevious), out element);
                            element.JSClickWithFocus(_driver);
                        }
                        GridControl _transactionOldGrid = new GridControl("content_contents", _driver);
                        _transactionOldGrid.WaitForGrid();
                        _transactionOldGrid.SelectFirstRow();
                        _transactionOldGrid.PerformActionByText("Reject Transaction");
                    }
                    else
                    {
                        IWebElement rowActionDdlButton = _driver.WaitForVisible(By.XPath(_baseTableRowXPathWithRowIndex + _actionDDLButtonRelativeXPath), TimeSpan.FromSeconds(10));
                        rowActionDdlButton.JSClickWithFocus(_driver);
                        IWebElement rowActionDdlOption = _driver.WaitForVisible(By.XPath(_baseTableRowXPathWithRowIndex + string.Format(_actionDDLOptionsRelativeXPath, option)), TimeSpan.FromSeconds(10));
                        rowActionDdlOption.JSClickWithFocus(_driver);
                    }
                }
            }
            else
            {
                // If User has provided an Action value, execute it (ignore the options, because both can't happen simultaneously)
                _baseActionRelativeXPath = string.Format(_baseActionRelativeXPath, action);
                // RowAction Text -  e.g. Edit 
                _driver.TryWaitForElement(By.XPath(_baseTableRowXPathWithRowIndex + _baseActionRelativeXPath), out IWebElement rowActionText);
                rowActionText.JSClickWithFocus(_driver);
            }
        }

        #endregion

        #region Get Rows 

        /// <summary>
        /// This method BUILDS returns the EXACTLY MATCHED ROW XPATH from the TABLE GRID based on the passed COLUMN VALUES.
        /// </summary>
        public IWebElement GetRowExactly(int instance, params string[] textList)
        {
            var individualCriteria = textList.Select(s => $"/./td[text()='{s}']/ancestor::tr");
            var combinedCriteria = (string.Join(string.Empty, individualCriteria).Substring(5) + $")[{instance}]");

            var rowElement = _driver.WaitFor(By.XPath($@"({_baseTableRowXPath}//*{combinedCriteria}"), TimeSpan.FromSeconds(10));
            return rowElement;
        }

        /// <summary>
        /// Get a specific row from a table based on the text input as col name
        /// </summary>
        public IWebElement GetRowContaining(params string[] textList)
        {
            var individualCriteria = textList.Select(s => $"[contains(text(), '{s}')]");
            var combinedCriteria = string.Join(string.Empty, individualCriteria);

            var rowElement = _driver.WaitFor(By.XPath($@"{_baseTableRowXPath}//*{combinedCriteria}/ancestor::tr[1]"), TimeSpan.FromSeconds(10));
            return rowElement;
        }

        /// <summary>
        /// Get a row from a table for the specified index.
        /// </summary>
        public IWebElement GetRow(int index)
        {
            _defaultRowIndex = index;
            InitializeXPaths();
            var rowElement = _driver.WaitFor(By.XPath(_baseTableRowXPathWithRowIndex), TimeSpan.FromSeconds(10));
            _driver.ScrollToXPATH(_baseTableRowXPathWithRowIndex);
            return rowElement;
        }

        /// <summary>
        /// Get all rows of a table
        /// </summary>
        public IEnumerable<IWebElement> GetRows()
        {
            var rowElements = _driver.WaitForElements(By.XPath($@"{_baseTableRowXPath}"));
            return rowElements;
        }

        public IEnumerable<IWebElement> GetRowsWithChild()
        {
            var rowElements = _driver.WaitForElements(By.XPath($@"{_baseRowXPathForGridsWithMultipleChildRows}"));
            return rowElements;
        }

        /// <summary>
        /// Exceptional cases where row.FindElement do not work and rather appending the xpath
        /// to the xpath of the base row element works.  e.g.  Invoiced Grid while creating Mlogs
        /// </summary>
        public IWebElement GetSpecificColInRowIdentifiedByXpath(int index, string additionalXpath)
        {
            var rowElement = _driver.FindElement(By.XPath($@"{_baseTableRowXPath}[{index + 1}]" + additionalXpath));
            return rowElement;
        }

        #endregion

        #region Get Column Texts

        /// <summary>
        /// Private method returns a collection of data from all rows for a specific col Header name
        /// </summary>
        private IEnumerable<IWebElement> GetColumnByHeaderText(string colHeaderName, bool multipleChildRows = false)
        {
            var precedingHeaderXPath = _baseTableHeaderXPath + $"/th/*[normalize-space(text())='{colHeaderName}']//ancestor-or-self::*[self::td or self::th][1]/preceding-sibling::*";
            var precedingHeaders = _driver.FindElements(By.XPath(precedingHeaderXPath));
            var anyPrecedingHidden = precedingHeaders.Any(h => !h.Displayed);
            int headerIndex = precedingHeaders.Count + 1; //Header position
            IEnumerable<IWebElement> allRows = null;
            if (!multipleChildRows)
                allRows = GetRows(); // Get all the rows to be used later.
            else
                allRows = GetRowsWithChild(); // Get all the rows to be used later.

            if (!allRows.Any())
            {
                return new List<IWebElement>(); // Return empty list if there are no elements.
            }

            if (!anyPrecedingHidden)
            {
                // Find hidden columns and add that count to the main header index.
                // Mobile Specific Change - xpath change needed due to card view
                if (GlobalSettings.DeviceType.Equals(GlobalSettings.Device.MOBILE.ToString()))
                    headerIndex += allRows.First().FindElements(By.XPath("div[normalize-space(@class)='card-views']/div/*[1]")).Count(e => !e.Displayed);
                else
                    headerIndex += allRows.First().FindElements(By.XPath("td")).Count(e => !e.Displayed);
            }

			List<string> results = new List<string>();

            // Mobile specific change - For Mobile view port the Xpath shifts to card view
            if(GlobalSettings.DeviceType.Equals(GlobalSettings.Device.MOBILE.ToString()))
                return allRows.Select(s => s.FindElement(By.XPath($"td/div[normalize-space(@class)='card-views']/div[{headerIndex}]")));
            else
                return allRows.Select(s => s.FindElement(By.XPath($"td[{headerIndex}]"))); 
        }

        /// <summary>
        /// Private method returns a List of all columns visible name
        /// </summary>
        public List<String> GetAllVisibleColumns()
        {
            List<IWebElement> visibleColumns = _driver.FindElements(By.XPath(_baseTableHeaderXPath + $"/th[not(contains(@class, 'detail'))]")).ToList<IWebElement>();
            List<String> list = new List<string>();
            foreach (IWebElement item in visibleColumns)
            {
                string columnName = item.Text;
                list.Add(columnName);
            }
            return list;
        }

        /// <summary>
        /// This method returns an array of strings if passed the 'COLUMN HEADER NAME'.
        /// NOTE: ANY HIDDEN COLUMN(S) BEYOND ON THE INSPECTED COLUMN RESULTS IN WRONG COLUMN DATA. IF SO THIS METHOD NEEDS TO BE RE-VISITED.
        /// </summary>
        public IEnumerable<string> GetColumnText(string colHeaderName, bool multipleChildRows = false)
		{
			List<string> results = new List<string>();
			var cells = (multipleChildRows) ? GetColumnByHeaderText(colHeaderName, multipleChildRows) : GetColumnByHeaderText(colHeaderName);
			IWebElement innerElement;
			foreach (var cell in cells)
			{
                bool flag = false;
                // Mobile specific change - For Mobile view port the Xpath changes to '2' index, since the Table rows for
                // mobile viewport comprises of Column Header as well as Col Value in Horizontal orientation.
                if (GlobalSettings.DeviceType.Equals(GlobalSettings.Device.MOBILE.ToString()))
                    flag = cell.TryFindElement(By.XPath(@"./*[not(contains(@class,'sr-only'))][2]"), out innerElement);
                else
                     flag =  cell.TryFindElement(By.XPath(@"./*[not(contains(@class,'sr-only'))][1]"), out innerElement);

                if (flag)
				{
					if (innerElement.TagName.Equals("select", StringComparison.InvariantCultureIgnoreCase))
					{
						results.Add(new SelectElement(innerElement).SelectedOption.Text);
					}
					else if (innerElement.TagName.Equals("input", StringComparison.InvariantCultureIgnoreCase))
					{
						results.Add(innerElement.GetAttribute("value"));
					}
					else if (innerElement.TagName.Equals("td", StringComparison.InvariantCultureIgnoreCase))
					{
						results.Add(new SelectElement(innerElement.FindElement(By.XPath(@"select"))).SelectedOption.Text);
					}
					else if (innerElement.TagName.Equals("span", StringComparison.InvariantCultureIgnoreCase))
					{
                        if (innerElement.TryFindElement(By.XPath(@"select"), out IWebElement subElement))
                                results.Add(new SelectElement(subElement).SelectedOption.Text);
                        else if (String.IsNullOrEmpty(innerElement.Text))
                            results.Add(cell.Text);
                        else
                            results.Add(innerElement.Text);
					}
					else if (innerElement.TagName.Equals("br", StringComparison.InvariantCultureIgnoreCase))
					{
						// Add the parent's text if the inner element is a break line
						results.Add(cell.Text);
					}
					else if (innerElement.TagName.Equals("div", StringComparison.InvariantCultureIgnoreCase))
					{
						if (innerElement.TryFindElement(By.XPath(@"select"), out IWebElement subElement))
							results.Add(new SelectElement(subElement).SelectedOption.Text);
						else if (innerElement.TryFindElement(By.XPath(@"span"), out IWebElement subElementSpan))
							results.Add(subElementSpan.Text);
						else
							results.Add(innerElement.Text);
					}
					else
					{
						results.Add(innerElement.Text);
					}
				}
				else
				{
					results.Add(cell.Text);
				}
			}
			return results;
		}

        #endregion

        #region Table Footer	

		/// <summary>
		/// Sets the Page Size of a Grid
		/// </summary>
		public void SetPageSize(int size)
		{
			string _pageSizeButtonXpath = _basePageSizeXPath + "//button[contains(@class,'dropdown-toggle')]";
			if( _driver.TryWaitForElement(By.XPath(_pageSizeButtonXpath), out IWebElement _pageSizeButton))
			{
				_pageSizeButton.JSClickWithFocus(_driver);
				string _pageSizeXpath = _basePageSizeXPath + $@"//div[contains(@class,'dropdown-menu')]/a[normalize-space(text())={size}]";
				if (_driver.TryWaitForElement(By.XPath(_pageSizeXpath), out IWebElement _pageSizeElement))
				{
					_pageSizeElement.JSClickWithFocus(_driver);
				}
				else
				{
					throw new Exception("Unable to locate element for intended Page Size :" + size);
				}
			}
			else
			{
				throw new Exception("Unable to locate button to click for selecting intended Page Size :" + size);
			}
		}

		#endregion


        public void SelectRow(int row, bool _checked)
        {
            var chkRow = string.Concat(string.Format(_baseTableRowXPathWithRowIndexCustom,row.ToString()) + "//input[@name='selectionElement']");
            var selectionElement = _driver.FindElement(By.XPath(chkRow));
            if (selectionElement.Selected!=_checked)
                selectionElement.JSClickWithFocus(_driver);
        }

        public bool ColumnContainsValue(string column, string value)
        {
            var columnResult = GetColumnText(column);
            return columnResult.Contains(value.Trim());
        }

        /// <summary>
		/// This method CHECKS THE CHECKBOX PRESENT IN THE HEADER and NOT THE COLUMN.
		/// </summary>
		/// <param name="checkboxIdentifierText"></param>
		/// <param name="check"></param>
		public void SetCheckboxColumn(string checkboxIdentifierText, bool check)
        {
            // This method will check the checkbox in the Header.
            if (_driver.TryFindElement(By.XPath($@"//input[@type='checkbox' and contains(@id, '{checkboxIdentifierText}')]"), out IWebElement myHeaderCheckbox))
            {
                myHeaderCheckbox.JsScrollToElement(_driver);
                myHeaderCheckbox.SetCheckboxStateWithLabel(null, check);
            }
        }
    }
}
