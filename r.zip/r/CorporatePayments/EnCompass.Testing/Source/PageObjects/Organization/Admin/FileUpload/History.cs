﻿using Common.Utility;
using EnCompass.Testing.Source.PageObjects.Controls;
using NFluent;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace EnCompass.Testing.Source.PageObjects.Organization.Admin.FileUpload
{
	public partial class History
	{
        #region XPath

        private const string _fileTypeXPath = @"//select[contains(@id, 'FileType')]";
        private const string _fileStatusXPath = @"//select[contains(@id, 'Status')]";
        private const string _fileNameXPath = @"//input[contains(@id, 'txtFile')]";
        private const string _dateRangeField1XPath = @"//select[contains(@id, 'ddlOptions')]";
        private const string _dateRangeField2XPath = @"//select[contains(@id, 'ddlPeriod')]";
        private const string _orgGroupOrgXPath = @"//input[contains(@id, 'orgGroupInclude_0')]";
        private const string _orgGroupAllXPath = @"//input[contains(@id, 'orgGroupInclude_1')]";
        private const string _searchBtnXPath = @"//input[contains(@id, 'btnSearch')]";
        private const string _homeButtonXPath = @"//a[@data-link = 'topLevelLink'][normalize-space(text())='Home']";
        private const string _administration_PurchaseLogFileXpath = @"//ul[contains(@id, 'sideNav')]//a[text()='Purchase Log File']";
        private const string _administration_FileUploads_PurchaseLogFileXPath = @"//ul[contains(@id, 'sideNav')]//a[text()='Purchase Log File']";

        public override string PageIdentifierXPath_Override => @"//h1[normalize-space(text())='History']";

        #endregion

        #region IWebElement Prop

        public IWebElement _fileType
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_fileTypeXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Debug("Found _fileType");
                return element;
            }
        }

        public IWebElement _fileStatus
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_fileStatusXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Debug("Found _fileStatus");
                return element;
            }
        }

        public IWebElement _fileName
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_fileNameXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Debug("Found _fileName");
                return element;
            }
        }

        public IWebElement _dateRangeField1
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_dateRangeField1XPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Debug("Found _dateRangeField1");
                return element;
            }
        }

        public IWebElement _dateRangeField2
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_dateRangeField2XPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Debug("Found _dateRangeField2");
                return element;
            }
        }

        public IWebElement _orgGroupOrg
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_orgGroupOrgXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Debug("Found _orgGroupOrg");
                return element;
            }
        }

        public IWebElement _orgGroupAll
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_orgGroupAllXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Debug("Found _orgGroupAll");
                return element;
            }
        }

        public IWebElement _searchBtn
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_searchBtnXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Debug("Found _searchBtn");
                return element;
            }
        }

        public IWebElement _homeButton
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_homeButtonXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Debug("Found _homeButton");
                return element;
            }
        }

        public IWebElement _administration_FileUploads_PurchaseLogFile
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_administration_FileUploads_PurchaseLogFileXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Debug("Found _administration_FileUploads_PurchaseLogFile");
                return element;
            }
        }


        #endregion


        public void SetFileTypeByText(string whichText)
		{
			var selectElement = new SelectElement(_fileType);
			selectElement.SelectByText(whichText);
		}

		public void NavigateTo_Administration_FileUploads_PurchaseLogFile()
		{
			NavigateToMenuItem(_administration_FileUploads_PurchaseLogFile);
		}

		public void SetFileName(string fileName)
		{
			_fileName.Clear();
			_fileName.SendKeys(fileName);
		}

		public string SetRangePeriod
		{
			get { return new SelectElement(_dateRangeField2).SelectedOption.Text.Trim(); }
			set { new SelectElement(_dateRangeField2).SelectByText(value); }
		}

		public string SetRangeOption
		{
			get { return new SelectElement(_dateRangeField1).SelectedOption.Text.Trim(); }
			set { new SelectElement(_dateRangeField1).SelectByText(value); }
		}

		public void Search()
		{
			_searchBtn.JSClickWithFocus(Driver);
			Settings.EnCompassExtentTest.Info("Clicked on Search  Button");
		}

        public bool IsUploadTypeAvailable(string type)
        {
            return Driver.IsElementPresent(By.XPath($"//a[text()= '{type}']"));
        }

        public void clickHome()
        {
            _homeButton.JSClickWithFocus(Driver);
        }
        // This Grid Control is in the Errors in History page.
        private GridControl _historyErrorsGrid;
		public GridControl FileUploadHistoryErrorsGrid
		{
			get
			{
				return _historyErrorsGrid ?? (_historyErrorsGrid = new GridControl("dgErrors", Driver));
			}
		}


		// This Grid Control is in the History home page.
		private GridControl _historyGrid;
		public GridControl FileUploadHistoryGrid
		{
			get
			{
				return _historyGrid ?? (_historyGrid = new GridControl("dgFiles", Driver));
			}
		}


		public bool RefreshUploadPage(string untilStatus, string noOfSuccessfullRecords)
		{
			int x = 0; //Counter for the number of times you want the page to refreshed.
			var firstRow = FileUploadHistoryGrid.GetRow(0); //This is ZERO based index.
			string processingStatus = firstRow.FindElement(By.XPath("td[7]")).Text;
			string successfulRecord;
			string processingStatusText = "File submitted for processing";
			bool isWaitingForProcessingStatus = processingStatusText.Equals(untilStatus, StringComparison.InvariantCultureIgnoreCase);

			do
			{
				// Wait 15 seconds
				Thread.Sleep(TimeSpan.FromSeconds(15));

				// Search again
				_searchBtn.JSClickWithFocus(Driver);
				WaitForLoad();

				// Get updated Success value
				firstRow = FileUploadHistoryGrid.GetRow(0); //This is ZERO based index.
				processingStatus = firstRow.FindElement(By.XPath("td[7]")).Text;
			}
			while (! (processingStatus.Equals(untilStatus, StringComparison.InvariantCultureIgnoreCase) || processingStatus.Equals("System Error", StringComparison.InvariantCultureIgnoreCase)) 
				&& processingStatusText.Equals(processingStatus, StringComparison.InvariantCultureIgnoreCase)
				&& x++ < 20);

			successfulRecord = firstRow.FindElement(By.XPath("td[9]")).Text;

			return (processingStatus.Equals(untilStatus, StringComparison.InvariantCultureIgnoreCase))
				   && (successfulRecord.Trim().Equals(noOfSuccessfullRecords, StringComparison.InvariantCultureIgnoreCase));
		}

		// This Grid Control is in the View Failed Records page.
		private GridControl _failedRecordsGrid;
		public GridControl FileUploadFailedRecordsGrid
		{
			get
			{
				return _failedRecordsGrid ?? (_failedRecordsGrid = new GridControl("aceErrors", Driver));
			}
		}

		private GridControl _cardAccountUpdateErrorsGrid;
		public GridControl CardAccountUpdateErrorsGrid
		{
			get
			{
				return _cardAccountUpdateErrorsGrid ?? (_cardAccountUpdateErrorsGrid = new GridControl("cardAccountUpdateErrors", Driver));
			}
		}

	}
}
