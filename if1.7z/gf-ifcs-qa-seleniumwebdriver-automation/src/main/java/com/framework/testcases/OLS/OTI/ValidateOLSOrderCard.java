package com.framework.testcases.OLS.OTI;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.OLS.common.LoginPage;
import com.framework.pages.OTI.OTICardPage;
import com.framework.pages.OTI.OTIHomePage;

public class ValidateOLSOrderCard extends BaseTest {
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "Regression" })
	public void validateOLSOrderCard(@Optional("BW") String clientCountry, @Optional("OTI") String clientName) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  OLS Order Card", "Create  OLS order card  in OTI");
		LoginPage loginPage = new LoginPage(driver, test);
		OTIHomePage OTIHomePage = new OTIHomePage(driver, test);
		OTICardPage OTICardPage = new OTICardPage(driver, test);
		if (clientCountry.equals("BW")) {
			loginPage.Login("OTIBW_URL", "OTI_UN_" + clientCountry, "OTI_PWD_" + clientCountry, clientName);
		}
		OTIHomePage.verifyHomePageText();
		OTIHomePage.verifyUserNameAndLogoutLink();
		OTICardPage.selectAccountFromDropdownAndValidate();
		OTICardPage.goToCardMenuOrderCard();
		OTICardPage.enterNewCardDetailsInOrderCardPage();
		loginPage.Logout();
	}
}
