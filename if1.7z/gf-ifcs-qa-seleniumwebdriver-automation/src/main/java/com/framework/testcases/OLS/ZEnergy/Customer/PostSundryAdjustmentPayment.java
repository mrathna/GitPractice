package com.framework.testcases.OLS.ZEnergy.Customer;

import org.testng.annotations.Test;

import com.framework.SundryAdjustmentPayment.SundryAdjustmentTestData;
import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.common.Common;
import com.framework.pages.AJS.common.IFCSHomePage;
import com.framework.pages.AJS.common.IFCSLoginPage;
import com.framework.util.PropUtils;

public class PostSundryAdjustmentPayment extends BaseTest {
	
	int rowIndex = 1;
	
	@Test(dataProvider = "Sundry Adjustment Payments", dataProviderClass = SundryAdjustmentTestData.class)
	public void postSundryAdjustmentPayments(String accountNo, String adjustmentType, String amount, String refNo) {
		
		Common common=new Common(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		
		test = extent.createTest("  Sundry Payment for Z Customers", "Sundry Payment for Z Customers");
		// login Z_Energy -with valid user name and password
		//loginZEnergyAjaxApplication("SundryA", "Spring@1234");
		
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		
		IFCSloginPage.login("IFCS_URL_ZENERGY", "IFCS_ZENERGY_USERNAME", "IFCS_ZENERGY_PASSWORD");
		
		String clientName = PropUtils.getPropValue(configProp, "ZEnergy_Z");
		IFCSHomePage.gotoAccountAndClickAccountDetails();
		common.gotoSundryAdjustMentAndSetClient(clientName);
	
		System.out.println("Record Choosen: "+accountNo +":"+adjustmentType+":"+amount+":"+refNo);
		
		System.out.println("Row count::"+rowIndex);
		
		common.validatePostSundryAdjustmentTransaction(accountNo, adjustmentType, amount, refNo);
		rowIndex++;
	}

}
