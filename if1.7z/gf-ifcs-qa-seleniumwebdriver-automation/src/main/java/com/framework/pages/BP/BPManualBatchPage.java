/*
 * Author = Anton
 */

package com.framework.pages.BP;

import java.text.SimpleDateFormat;
//import java.util.Date;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.ExtentTest;
import com.framework.basepage.BasePage;
import com.framework.repo.Locator;

public class BPManualBatchPage extends BasePage {

	BPHomePage bpHomePage = new BPHomePage(driver, test);

	public BPManualBatchPage(WebDriver driver, ExtentTest test) {
		super(driver, test);
		PageFactory.initElements(driver, this);
	}

	@FindBy(id = Locator.TRANSACTIONS_MENU)
	public WebElement transactionsMenu;

	@FindBy(id = Locator.MENU_MANUAL_BATCHES)
	public WebElement manualBatchSubMenu;

	@FindBy(xpath = Locator.MANUAL_BATCHES_TITLE)
	public WebElement manualBatchTitle;

	@FindBy(id = Locator.ADD_MANUAL_BATCH)
	public WebElement addManualBatchBTN;

	/*
	 * @FindBy(id = Locator.BATCHNO_TEXT) public WebElement batchRefText;
	 */

	@FindBy(id = Locator.CONTROL_COUNT)
	public WebElement ctrlCountText;

	/*
	 * @FindBy(xpath = Locator.ACTUAL_COUNT) public WebElement actualCountText;
	 * 
	 * @FindBy(id=Locator.ACTUAL_AMOUNT) public WebElement actualAmtText;
	 */
	@FindBy(id = Locator.CREATED_ON)
	public WebElement createdOn;

	@FindBy(id = Locator.CONTROL_AMOUNT)
	public WebElement ctrlAmount;

	@FindBy(id = Locator.ADD_TRANSC_M_BATCH)
	public WebElement addTranscBatch;

	@FindBy(id = Locator.MANUAL_TRANSAC_TABLE)
	public WebElement manualTransTable;

	@FindBy(xpath = Locator.MANUAL_TRANSC_POPUP)
	public WebElement manualTransPopup;

	@FindBy(id = Locator.LOCATION_LABEL)
	public WebElement locFieldLabel;

	@FindBy(id = Locator.LOCATION_SELECT_BOX)
	public WebElement locSelectBox;

	@FindBy(id = Locator.REFERENCE_LABEL)
	public WebElement refLabel;

	@FindBy(id = Locator.REFERENCE_TB)
	public WebElement referenceTBOX;

	@FindBy(id = Locator.TRANS_AMT_TB)
	public WebElement transAmtTB;

	@FindBy(id = Locator.TRANS_AMT_LABEL)
	public WebElement transAmtLabel;

	@FindBy(id = Locator.EFF_DATE_TB)
	public WebElement effDateTB;

	@FindBy(id = Locator.EFF_DATE_LABEL)
	public WebElement effDateLabel;

	@FindBy(id = Locator.CARD_NUM_LABEL)
	public WebElement cardNumLabel;

	@FindBy(id = Locator.CARD_NUM_TB)
	public WebElement cardNTB;

	@FindBy(id = Locator.UPLOAD_VOUCHER)
	public WebElement uploadVoc;

	@FindBy(id = Locator.ADD_PROD)
	public WebElement addProdBtn;

	@FindBy(xpath = Locator.PROD_SELECT_BOX)
	public WebElement prodSelBox;

	@FindBy(xpath = Locator.PROD_VALUE)
	public WebElement prodValue;

	@FindBy(id = Locator.CANCEL_BTN_MAN_TRANS_POPUP)
	public WebElement cancel_BTN;

	@FindBy(id = Locator.SAVE_BTN_MAN_TRANS_POPUP)
	public WebElement save_BTN;

	@FindBy(id = Locator.SEARCH_BTN)
	public WebElement searchBatch;

	@FindBy(id = Locator.RESULT_TABLE)
	public WebElement batchTable;

	SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");

	public void clickManualBatchSubMenuAndValidatePage() {
		clickSubMenuAndValidate(transactionsMenu, manualBatchSubMenu, manualBatchTitle);

	}

	public void clickAddManualBatchAndVerify() {
		isDisplayedThenClick(addManualBatchBTN, "Add Manual Batch");
		sleep(5);
		verifyManualBatchPage();
	}

	public void verifyManualBatchPage() {
		try {
			boolean isTitlePresent = waitForTextToAppear("Manual Transactions", 15);
			boolean isSubTitlePresent = waitForTextToAppear("Batch Detail", 15);

			if (isTitlePresent && isSubTitlePresent) {
				logPass("We are navigated to the Add Manual Batch Page");
			}

			else {
				logFail("We are not navigated to the Add Manual Batch Page");
			}
		} catch (Exception e) {
			logFail(e.getMessage());
		}
	}

	public void enterBatchDetailsAddTransactionAndValidate() {
		try {
			String dateF = dateFormat.format(fakerAPI().date().birthday());
			// System.out.println("--------- Date -------"+dateF);
			isDisplayedThenEnterText(createdOn, "Created on Date", dateF);
			isDisplayedThenEnterText(ctrlAmount, "Control Account", fakerAPI().number().digits(5));
			isDisplayedThenEnterText(ctrlCountText, "Control Count", "1");

			int beforeSize = getRowSize(manualTransTable);

			isDisplayedThenClick(addTranscBatch, "Add Transactions");
			sleep(3);

			int afterSize = getRowSize(manualTransTable);

			if (afterSize == (beforeSize + 1)) {
				logPass("Blank Manual Transaction is created");
			}

			else {
				logPass("Blank Manual Transaction is not created");
			}
		} catch (Exception e) {
			logFail(e.getMessage());
		}
	}

	public void clickTheBlankTransactionCheckDetailsAndValidate() {

		WebElement lasTransRow = getLastRowFromTable(manualTransTable,"Manual transaction");
		isDisplayedThenClick(lasTransRow, "Blank Transaction newly added");
		sleep(3);
		isDisplayed(manualTransPopup, "Manual transaction Popup");
		checkTextInPageAndValidate("Manual Transaction Details", 15);
		isDisplayed(locFieldLabel, "Location Label");
		isDisplayed(locSelectBox, "Location Select Box");
		isDisplayed(refLabel, "Reference Label");
		isDisplayed(referenceTBOX, "Reference Text box");
		isDisplayed(transAmtLabel, "Transaction Amount label");
		isDisplayed(transAmtTB, "Transaction Amount Text box");
		isDisplayed(cardNumLabel, "Card Number Label");
		isDisplayed(cardNTB, "Card Number Text box");
		isDisplayed(effDateLabel, "Effective Date Label");
		isDisplayed(effDateTB, "Effectve Date Text box");
		isDisplayed(uploadVoc, "Upload Voucher button");
		//isDisplayed(addProdBtn, "Add Product button");
		checkTextInPageAndValidate("Line Item Details", 15);
		checkTextInPageAndValidate("Product code", 15);
		checkTextInPageAndValidate("Value", 15);
		isDisplayed(save_BTN, "Add Product button");
		isDisplayedThenClick(cancel_BTN, "Cancel button");
		sleep(5);
		verifyManualBatchPage();
	}

	public void validateHeaders(WebElement tableBatch, String message) {
		isDisplayed(tableBatch, message);
		checkTextInPageAndValidate("Reference No", 10);
		checkTextInPageAndValidate("Created On", 10);
		checkTextInPageAndValidate("Batch Status", 10);
		checkTextInPageAndValidate("Control Count", 10);
		checkTextInPageAndValidate("Actual Count", 10);
		checkTextInPageAndValidate("Control Amount", 10);
		checkTextInPageAndValidate("Actual Amount", 10);
	}

	public void viewBatchInTableAndVerify(WebElement batTable, String message) {
		try {
			sleep(3);
			// getRowSize(table) Need to update.

			validateHeaders(batTable, message);

			int size = 0;
			List<WebElement> rowTable = batTable
					.findElements(By.xpath("./tbody[contains(@id,'lform:tableManBatchTransList:tb')]/tr"));
			size = rowTable.size();

			if (size > 0) {
				List<WebElement> columns = batTable
						.findElements(By.xpath("./tbody[contains(@id,'lform:tableManBatchTransList:tb')]/tr/td"));
				if (columns.size() > 0) {
					logPass("Batches are available");
				}

				else {
					logPass("Batches data are not available");
				}
			}

			else {
				checkTextInPageAndValidate("No items found.", 20);
			}
		} catch (Exception e) {
			logFail(e.getMessage());
		}

	}

	public void searchAndVerifyManualBatches() {
		// TODO Auto-generated method stub
		checkTextInPageAndValidate("Use filter fields to narrow search", 15);
		isDisplayedThenClick(searchBatch, "Search Batch Button");
		viewBatchInTableAndVerify(batchTable, "Batches List table");

	}

}
