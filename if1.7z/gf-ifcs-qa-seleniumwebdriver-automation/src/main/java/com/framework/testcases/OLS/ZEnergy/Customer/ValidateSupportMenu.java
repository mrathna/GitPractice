package com.framework.testcases.OLS.ZEnergy.Customer;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.OLS.common.LoginPage;
import com.framework.pages.Z.ZHomePage;
import com.framework.pages.Z.ZsupportPage;

public class ValidateSupportMenu extends BaseTest {

	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "Smoke" })
	public void verifySupportSubMenus(@Optional("Z") String clientCountry,@Optional("ZEnergy") String clientName) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  Verify all submenus are display in support page","Verfing that all submenus are display in support page");

		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		ZHomePage zHomePage = new ZHomePage(driver, test);
		loginPage.Login("ZEnergy_URL", "ZEnergy_UN_Customer_" + clientCountry, "ZEnergy_PWD_Customer_" + clientCountry,clientName);
		zHomePage.validateSupportSubMenus();
        loginPage.Logout();
	}
	
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "Smoke" })
	public void verifyChangePasswordPresence(@Optional("Z") String clientCountry,@Optional("ZEnergy") String clientName) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  Verify display change password option, Password Manitenance page & Success message displays after clicking submit button ","Verfing  change password option, Password Manitenance page & Success message");

		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		ZsupportPage zSupportPage = new ZsupportPage(driver, test);
		loginPage.Login("ZEnergy_URL", "ZEnergy_UN_Customer_" + clientCountry, "ZEnergy_PWD_Customer_" + clientCountry,clientName);
		zSupportPage.goToChangePasswordMaintenancePageAndValidate();
//		zSupportPage.enterValidPwdNewPwdConfirmPwdAndValidate("ZEnergy_PWD_Customer_" + clientCountry);
        loginPage.Logout();
	}
}
