using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using Common;
using Common.PageObjects;
using Common.ScenarioConfigurations;
using Common.Utility;

namespace EnCompass.Testing.Source.PageObjects.Organization.Admin.MccGroupProfiles 
{
	/// <summary>
	/// Auto-generated Page Model Class
	/// Navigation Paths: 
		/// [Organization Home]->Administration->Merchant Category Codes->Hierarchy
		/// </summary>
	[PageModel(@"/admin/mccGroupProfiles/Hierarchy.aspx")]
	public partial class Hierarchy : EnCompassOrgPageModel 
	{
		public override string RelativeUrl => @"/admin/mccGroupProfiles/Hierarchy.aspx";
		public override string PageIdentifierXPath_Generated => @"//li[contains(@class, 'breadcrumb-item active')][text() = 'Apply Profile to Hierarchy']";

		#region Navigation
				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Groups']")]
		private IWebElement _administration_MerchantCategoryCodes_Hierarchy_Groups { get; set; }
		public void NavigateTo_Administration_MerchantCategoryCodes_Hierarchy_Groups()
		{
			NavigateToMenuItem(_administration_MerchantCategoryCodes_Hierarchy_Groups);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Profiles']")]
		private IWebElement _administration_MerchantCategoryCodes_Hierarchy_Profiles { get; set; }
		public void NavigateTo_Administration_MerchantCategoryCodes_Hierarchy_Profiles()
		{
			NavigateToMenuItem(_administration_MerchantCategoryCodes_Hierarchy_Profiles);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Hierarchy']")]
		private IWebElement _administration_MerchantCategoryCodes_Hierarchy_Hierarchy { get; set; }
		public void NavigateTo_Administration_MerchantCategoryCodes_Hierarchy_Hierarchy()
		{
			NavigateToMenuItem(_administration_MerchantCategoryCodes_Hierarchy_Hierarchy);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Profiles by Card']")]
		private IWebElement _administration_MerchantCategoryCodes_Hierarchy_ProfilesByCard { get; set; }
		public void NavigateTo_Administration_MerchantCategoryCodes_Hierarchy_ProfilesByCard()
		{
			NavigateToMenuItem(_administration_MerchantCategoryCodes_Hierarchy_ProfilesByCard);
		}

		
		private void NavigateToMenuItem(IWebElement element)
		{
			Driver.Url = element.GetAttribute("href");
		}
		#endregion

		public Hierarchy(GlobalSettings settings) : base(settings) { }
	}  
}
