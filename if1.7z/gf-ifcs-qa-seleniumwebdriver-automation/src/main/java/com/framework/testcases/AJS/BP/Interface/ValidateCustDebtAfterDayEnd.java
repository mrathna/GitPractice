package com.framework.testcases.AJS.BP.Interface;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.common.Common;
import com.framework.pages.AJS.common.CommonInterfacePage;
import com.framework.pages.AJS.common.IFCSCommonPage;

public class ValidateCustDebtAfterDayEnd extends BaseTest{
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "Smoke" })
	public void validateUploadCustomerPricing(@Optional("AU") String clientCountry,
			@Optional("BP") String clientName) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  CustDebt", "Verify CustDebt in RM_GSD_0178/RM_GSD_0179 file");
		// creating object for the Pages
		IFCSCommonPage ifcsCommonPage = new IFCSCommonPage(driver, test);
		CommonInterfacePage commonInterfacePage = new CommonInterfacePage(driver, test);
		Common common = new Common(driver, test);
		String fileName ;
		if(clientCountry.equals("AU")) {
		 fileName = commonInterfacePage.getRecentProcessedFileNames(clientName, clientCountry, "RM_GSD_0178");
		}else if (clientCountry.equals("NZ")) {
			fileName = commonInterfacePage.getRecentProcessedFileNames(clientName, clientCountry, "RM_GSD_0179");
		}else {
			fileName ="";
			common.logFail("Client country doesn't exists");
		}
		System.out.println("fileName:"+ fileName);
		ifcsCommonPage.establishThePuttyConnection("unzip", "PUTTY_HOST", "PUTTY_USERNAME", "PUTTY_PASSWORD",
				"IFCS_OUTPUT_FILE_FOLDER_CUSTDEBT", fileName);
		String expectedAccountNumber[] = {"0115619594","2116316299","0185581776"};
		String localFolder = System.getProperty("user.home") + "\\Documents\\" + (fileName.replace(".zip", ".xml"));
		ifcsCommonPage.validateIncomingXMLFile(localFolder,expectedAccountNumber , "ifcs:Customer",
				"core:CustomerNumber");	
	}
}
