package com.framework.pages.CHEV;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.ExtentTest;
import com.framework.basepage.BasePage;
import com.framework.repo.Locator;

public class CHBulkCardUpdatePage extends BasePage {
	
	@FindBy(how = How.XPATH, using = Locator.ADHOC_REPORTS_TITLE)
	public WebElement cardListPageTitle;
	
	@FindBy(how = How.ID, using = Locator.DOWNLOAD_CARDS_TO_EXCEL)
	public WebElement downloadBtn;

	@FindBy(how = How.ID, using = Locator.CH_BULK_CARD_UPDATE_UPLOAD_BTN)
	public WebElement uploadBtn;
	
	public CHBulkCardUpdatePage(WebDriver driver, ExtentTest test) {
		super(driver, test);
		PageFactory.initElements(driver, this);
	}

	public void verifyBulkUpdatePageTitle() {
		sleep(3);
		isDisplayed(cardListPageTitle, "Bulk Update page");
		logPass("Redirected to the Bulk Update");

	}
	
	public void verifyDownloadButton() {
		if (downloadBtn.isDisplayed()) {
			logPass("Download Button present");
		} else {
			logFail("Download Button not present");
		}

	}

	public void verifyUploadButton() {
		if (uploadBtn.isDisplayed()) {
			logPass("Upload Button present");
		} else {
			logFail("Upload Button not present");
		}

	}

	public void verifyExportButton() {
		if (uploadBtn.isDisplayed()) {
			logPass("Upload Button is visible");
		} else {
			logFail("Upload Button is not visible");
		}

	}

}
