﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Flurl;
using System.Text;
using System.Threading.Tasks;
using Common.Utility;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Support.UI;
using NFluent;
using Common;
using EnCompass.Testing.Source.Utility;
using TestStack.White.UIItems.WindowItems;
using System.Windows.Forms;
using TestStack.White;
using TestStack.White.UIItems.Finders;
using Button = TestStack.White.UIItems.Button;
using TextBox = TestStack.White.UIItems.TextBox;
using System.Threading;

namespace EnCompass.Testing.Source.PageObjects.Organization.Admin.FileUpload
{
    public partial class UploadFile
    {
		public override string PageIdentifierXPath_Override => @"//li[contains(@class, 'breadcrumb-item active')][text() = 'Upload Purchase Log File' or text() = 'Upload Accounts Payable File' or text() = 'Upload New Cards File' or text() = 'Upload Card Update File' or text() = 'Upload Notifications File' or text() = 'Upload Users File' or text() = 'Upload User Update File' or text() = 'Upload Financial Codes File' or text() = 'Upload Workflow Hierarchy File']";

        #region XPath page Elements

        private readonly string _browseLocationXPath = @"//input[@type='file']";
        private readonly string _uploadFileBtnXPath = @"//input[@type='button' and contains(@id, 'uploadFile')]";
        private readonly string _uploadTypeXPath = @"//select[contains(@id, 'FileTypes')]";
        private readonly string _replaceCodesXPath = @"//select[contains(@id, 'ReplaceCodes')]";
        // "File has been successfully uploaded for processing. When processing is complete an email will be sent to the email address recorded in your user account record.
        //  Detailed information will be available via the Upload History Page"
        private readonly string _successMessageXPath = ".//div[contains(@id,'divMessage')]";
        private readonly string _errorMessageXPath = ".//div[contains(@id,'ValidationSummary')]/ul/li";
        private readonly string _fileUploadHistoryPageLinkXPath = ".//a[text()='History']";
        private readonly string _fileUploadTextXPath = ".//caption[normalize-space(text())= 'File Upload History']";

        #endregion


        #region IWEbElements Props

        public IWebElement _browseLocation
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_browseLocationXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_browseLocation element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _uploadFileBtn
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_uploadFileBtnXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_uploadFileBtn element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _uploadType
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_uploadTypeXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_uploadType element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _replaceCodes
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_replaceCodesXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_replaceCodes element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _successMessage
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_successMessageXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_successMessage element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _errorMessage
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_errorMessageXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_errorMessage element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _fileUploadHistoryPageLink
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_fileUploadHistoryPageLinkXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_fileUploadHistoryPageLink element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        #endregion

        public string BrowseLocation
        {
            get
            {
                return _browseLocation.GetAttribute("value");
            }
            set
            {
                _browseLocation.SendKeys(value);
            }
        }

        public void UploadFileClick()
        {
            _uploadFileBtn.JSClickWithFocus(Driver);
			Settings.EnCompassExtentTest.Info("Clicked on Upload Button");
		}

        public void SetUploadTypeByText(string whichText)
        {
            var selectElement = new SelectElement(_uploadType);
            selectElement.SelectByText(whichText);
            Settings.EnCompassExtentTest.Info("Select to upload the value " + whichText);
        }

		public void SetReplaceCodesByText(string whichText)
		{
			var selectElement = new SelectElement(_replaceCodes);
			selectElement.SelectByText(whichText);
		}

		public void UploadFileSuccessfully(string fileAbsolutePath)
        {
            _browseLocation.SendKeys(fileAbsolutePath);
            UploadFileClick();
            this.WaitForLoad();
            Settings.EnCompassExtentTest.Info("File Uploaded :" + fileAbsolutePath);
            Settings.EnCompassWebDriver.WaitForVisible(By.XPath(".//div[contains(@id,'divMessage')]"));
            this.RefreshModel();
            
           
        }

        public void UploadFileFailure(string fileAbsolutePath)
        {
            _browseLocation.SendKeys(fileAbsolutePath);
            UploadFileClick();
			Settings.EnCompassExtentTest.Info("File Uploaded :" + fileAbsolutePath);
			Settings.EnCompassWebDriver.WaitForVisible(By.XPath(".//div[contains(@id,'ValidationSummary')]/ul/li"));
            this.RefreshModel();
        }
		
        public string FileUploadedSuccessMessage
        {
            get
            {
                _successMessage.WaitUntilElementIsInteractable();
                return _successMessage.Text.Trim();
            }
        }

        public string FileUploadedErrorMessage
        {
            get
            {
                return _errorMessage.Text.Trim();
            }
        }

        public void GoToUploadHistory()
        {
            _fileUploadHistoryPageLink.JSClickWithFocus(Driver);
            Settings.EnCompassWebDriver.WaitForVisible(By.XPath(".//caption[normalize-space(text())= 'File Upload History']"));
            this.RefreshModel();
        }        

        public void InvoiceFileNumberChange(string dirPath, string fileName)
        {
            string fullFilePath = Path.Combine(dirPath, fileName);
            if (!File.Exists(fullFilePath))
            {
                throw new FileNotFoundException("The file doesn't exist at the specified location.");
            }

            string fileContents = File.ReadAllText(fullFilePath);
            Random rand = new Random();
            string newFileNumber = rand.Next(1, 999999).ToString().PadLeft(6, '0');
            Console.WriteLine($"The nw file number is: {newFileNumber}");
            StringBuilder sb = new StringBuilder(fileContents);
            sb.Remove(31, 6);
            sb.Insert(31, newFileNumber);
            File.WriteAllText(fullFilePath, sb.ToString()); //The file contents are now replaced.
        }

        /// <summary>
		/// Delete a File from the Directory specified, it expects the file to be present already,
		/// If File is not found it throws exception.
		/// </summary>
        public void DeleteFile(string dirPath, string fileName)
        {
			if (String.IsNullOrEmpty(dirPath) || String.IsNullOrEmpty(fileName))
			{
				Settings.EnCompassExtentTest.Warning("DeleteFile called with empty or null paramters");
			}
			else
			{
				string fullFilePath = Path.Combine(dirPath, fileName);
				if (!File.Exists(fullFilePath))
				{

					Settings.EnCompassExtentTest.Info("The file doesn't exist at the specified location -" + fullFilePath);
					throw new Exception("File deletion failed");
				}

				File.Delete(fullFilePath);
				Settings.EnCompassExtentTest.Info("Successfully Deleted File : " + fileName + " from " + dirPath);
				// Once file is deleted, we do not need it to stay in the Scenario Context, thus freeing up space.
				// if anyone tries to delete later on, it should trigger either a warning or Argument Exception based
				// on the usage of these values before passing them as input params to this method.
				Settings.Scenario["FileAbsPath"] = String.Empty;
				Settings.Scenario["NewFileName"] = String.Empty;
			}
		}

        public string TodaysDateUntilSeconds()
        {
            return System.DateTime.Now.ToString("yyyy-MM-dd-hhmmss");
        }

        public void NavigateToAPFiles()
        {
            var fullUrl = Url.Combine(Driver.GetRootUrl(), @"/admin/FileUpload/UploadFile.aspx?Type=AP");
            Driver.Url = fullUrl;
            WaitForLoad();
        }
    }
}
