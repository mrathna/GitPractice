package com.framework.repo;

public class Locator {

	// Login Page
	public static final String EXXON_LOGO_IMG = "//img[@alt='ExxonMobil Universal Online Home']";
	public static final String CLIENT_LOGO_IMG = "//*[@id='headerForm:customerCommandLnk']|//*[@id='headerForm:merchantCommandLnk']";
	public static final String USERNAME = "j_username"; // id
	//public static final String USERNAME = "//input[@id='j_username']";
	public static final String PASSWORD = "j_password"; // id
	public static final String SIGNIN = "btn_login"; // id
	public static final String FORGOT_PASSWORD = "emailPassword"; // id
	public static final String CONTACT_US = "contactUs"; // id
	public static final String REQUEST_LOGON = "requestALogon"; // id
	public static final String LEGAL_NOTICE = "footerWexForm:footer_linkLegal_notice"; // id
	public static final String PRIVACY_STATEMENT = "footerWexForm:footer_linkPrivacy_statement"; // id
	public static final String COPY_RIGHT = "footerFormThree"; // id

	// Login Page Element - BP Client Specific
	public static final String BP_LOGO_IMG = "//*[@id='headerForm:auCommandLnk'] |//*[@id='headerForm:nzCommandLnk'] "; // XPATH

	// OnlineUserAction Page
	public static final String QUESTION = "//label[@for='askedQuestionResponse']";
	public static final String APPLYBUTTON = "//button[contains(text(),'Apply')]";
	public static final String CANCELBUTTON = "//a[contains(text(),'Cancel')]";
	public static final String ONLINEUSERACTIONTEXT = "//div[contains(text(),'Online User Action Required')]";
	public static final String ANSWER = "askedQuestionResponse"; // id

	// Home Page
	public static final String FLEETMANAGER_MENU = "//header//a[@class='dropdown-toggle' and contains(text(),'Fleet Manager')]";
	public static final String RESOURCETOOLS_MENU = "//header//a[@class='dropdown-toggle' and contains(text(),'Resource Tools')]";
	public static final String ADMINISTRATION_MENU = "//header//a[@class='dropdown-toggle' and contains(text(),'Administration')]";
	public static final String USERMENU = ".//*[@id='status-bar']//span[@class='monogram']";
	public static final String HELP = "Help"; // linktext
	public static final String MYPREFERENCES = "My Preferences"; // linktext

	// Nithya - 27-04-2018
	public static final String ACCOUNTS_DROPDOWN = "accountProfileSelectMemberForm:accountProfileSelectMember"; // id
	public static final String PAGETITLE_FINDANDUPDATE = "lform:contentFormWrapper"; // id
	public static final String PAGETITLE_MANAGEREISSUE_REQUEST = "//h1[contains(text(),'Manage Reissue Requests')]";
	public static final String CLIENT_WELCOME_TEXT = "//*[@id='welcome_CTA']/h1";
	public static final String HOME_MENU = "//*[@id='menu_form:levelOneHome']";
	public static final String ACCOUNTS_MENU = "levelOneAccount"; // id "//*[@id='levelOneAccount']"; //XPATH
	public static final String CARDS_MENU = "levelOneCards";// id "//*[@id='levelOneCards']"; //XPATH
	public static final String TRANSACTIONS_MENU = "levelOneTransactions"; // "//*[@id='levelOneTransactions']"; //XPATH
	public static final String REPORTS_MENU = "levelOneReports"; // "//*[@id='levelOneReports']"; //XPATH
	public static final String SUPPORT_MENU = "levelOneSupport"; // "//*[@id='levelOneSupport']"; //XPATH
	public static final String ADMIN_MENU = "levelOneAdmin"; // "//*[@id='levelOneAdmin']"; //XPATH
	public static final String HELP_REF = "//*[@id='accountProfile_online_user_guideLnk']";
	public static final String LOGOUT = "logoff"; //id
	public static final String STATUS_MENU = "levelTwoAccSel"; // "//*[@id='levelTwoAccSel']";
	public static final String ACCOUNT_MAINTENANCE_MENU = "levelTwoCustMaint"; // "//*[@id='levelTwoCustMaint']";//XPATH
	public static final String CONTACTS_MENU = "//*[@id='menu_form:levelTwoContactsList']";
	public static final String DRIVERS_MENU = "levelTwoDriversList"; // "//*[@id='levelTwoDriversList']"; //XPATH
	public static final String VEHICLES_MENU = "levelTwoVehicles"; // "//*[@id='levelTwoVehicles']"; //XPATH
	public static final String COST_CENTERS_MENU = "levelTwoCcList"; // "//*[@id='levelTwoCcList']"; //XPATH
	public static final String QUICK_LINKS = "quicklinks"; // id
	public static final String CUSTOMER_NAME_COMBO = "//*[@id='lform:selectMember']"; // XPATH.
	public static final String CUSTOMER_NAME_LABEL = "//*[@id='accountProfile']/div[1]/label"; // XPATH
	public static final String ACCOUNT_STATUS = "//*[@id='table_selectAccountDetails']/tbody/tr[1]/td[2]/span";
	public static final String CREDIT_LIMIT = "//*[@id='table_selectAccountDetails']/tbody/tr[2]/td[2]/span";
	public static final String ACTUAL_BALANCE = "//*[@id='table_selectAccountDetails']/tbody/tr[3]/td[2]/span";
	public static final String AVAILABLE_BALANCE = "//*[@id='table_selectAccountDetails']/tbody/tr[5]/td[2]/h3/span";
	public static final String LAST_BILL_DATE = "//*[@id='table_selectAccountDetails']/tbody/tr[7]/td[2]";
	public static final String LAST_PAYMENT_RECIEVED = "//*[@id='table_selectAccountDetails']/tbody/tr[8]/td[2]";
	public static final String LAST_PAYMENT_AMOUNT = "//*[@id='table_selectAccountDetails']/tbody/tr[8]/td[3]/span";

	// BP Homepage - BP Specific elements..
	public static final String BP_WELCOME_TEXT = "//*[@id='welcome_CTA']/h1"; // BP SpecificLogo

	// Add Address Page
	public static final String ADD_ADDRESS_LINK = "Add Address"; // linktext
	public static final String ADDRESSINFORMATIONLABEL = "//h2[contains(text(),'Address Information')]";
	public static final String ADDR1 = "street1"; // id
	public static final String ADDR2 = "street2";// id
	public static final String CITY = "city";// id
	public static final String STATE = "state";// id
	public static final String ZIPCODE = "postalCode";// id
	public static final String PRIMARYADDRTYPE = "//label[contains(text(),'Primary')]/input[1]";
	public static final String BILLINGADDRTYPE = "//label[contains(text(),'Billing')]/input[1]";
	public static final String NEXTBUTTON = "//button[contains(text(),'Next')]";
	public static final String SUCCESSMESSAGE = "errorContentText"; // id

	// Add Contact Page
	public static final String ADD_CONTACT_LINK = "Add Contact"; // linktext
	public static final String CONTACTINFORMATIONLABEL = "//h2[contains(text(),'Contact Information')]";
	public static final String PHONE = "phoneNumber"; // id
	public static final String MIDDLENAME = "middleName"; // id
	public static final String EMAILADDRESS = "emailAddress"; // id
	public static final String FAXNUMBER = "faxNumber"; // id
	public static final String MOBILEPHONE = "cellularPhone"; // id
	public static final String PRIMARYADDRTYPECHK = "addressTypeList1"; // id

	// Added by MS
	public static final String VIEW_AND_EDIT_CONTACT_LINK = "customerView_levelTwoContactsList"; // id
	public static final String VIEW_AND_EDIT_CONTACT_PAGE = "View and Edit Contacts"; // linktext
	public static final String VIEW_AND_EDIT_CONTACTS_PAGE = "//h1[contains(text(),'View and Edit Contacts')]";
	public static final String ADD_CONTACT_BUTTON = "lform:contactList_add_contact"; // id
	public static final String ADD_CONTACT_PAGE_HEADER = "lform:contactsMaint_contact_name_top"; // id
	public static final String VIEW_AND_EDIT_COST_CENTRE_LINK = "customerView_costCentreMenu"; // id
	public static final String VIEW_AND_EDIT_COST_CENTRE_PAGE = "//h1[contains(text(),'View and Edit Cost Centre')]"; // xpath
	public static final String ADD_COST_CENTRE_BUTTON = "lform:costCentreList_add_contact"; // id
	public static final String CREATE_NEW_COST_CENTRE_HEADER = "//h1[contains(text(),'Create a new Cost Centre')]"; // xpath
	public static final String COST_CENTRE_FIELD = "lform:customer_cost_centre_code"; // id
	// public static final String COST_CENTRE_DESC_FIELD = "lform:description"; //
	// id
	public static final String COST_CENTRE_SHORT_DESC_FIELD = "lform:short_description"; // id
	public static final String CREATE_COST_CENTRE_BUTTON = "lform:costCentreMaint_btnSave"; // id
	public static final String CREATE_SUCCESS_MESSAGE = "div.successGreenDot"; // CSS
	public static final String ACCOUNT_AT_FIND_COST_CENTRE = "lform:cost_centre_accounts"; // id
	public static final String ACCOUNT_DROP_DOWN_LIST_AT_FIND_COST_CENTRE = "select[id='lform:cost_centre_accounts'] option"; // CSS
	public static final String SEARCH_FOR_COST_CENTRE_BUTTON = "span[id='lform:cost_centre_search_btn']"; // CSS
	public static final String COST_CENTRE_RECORDS = "lform:tableCostCentreList"; // id
	public static final String COST_CENTRE_NAME_IN_FIND_COST_CENTRE = "lform:customer_cost_centre_codeInput"; // id
	// public static final String COST_CENTRE_DESC_IN_FIND_COST_CENTRE =
	// "lform:description"; // id
	public static final String RETURN_TO_COST_CENTRE_BUTTON = "lform:back_to_costCentre_listfullAccess"; // id
	public static final String TABLE_COST_CENTRE_LIST = "tr[id='lform:tableCostCentreList:0'] td p[class='wrapedTableCell'] a"; // CSS
	public static final String EDIT_DETAILS_LINK_BUTTON = "a[id='lform:tableCostCentreList:0:mnuVie']"; // CSS
	public static final String EDIT_COST_CENTRE_PAGE = "//*[@id='lform:contentFormWrapperLeft_details']/div[1]/h3"; // Xpath
	public static final String SAVE_CHANGES_BUTTON = "lform:costCentreMaint_btnSave"; // id

	// Add Cards Page
	public static final String ADD_CARDS_LINK = "Add Vehicle/Asset Card"; // linktext
	public static final String VEHICLEASSETINFOLABEL = "//h2[contains(text(),'Vehicle/Asset Information')]";
	public static final String ASSETID = "vehicle.vehicleNumber"; // id

	// Add Driver Page
	public static final String ADD_DRIVER_LINK = "Add Driver"; // linktext
	public static final String DRIVERINFOLABEL = "//h2[contains(text(),'Driver Information')]";
	public static final String LASTNAME = "lastName"; // id
	public static final String FIRSTNAME = "firstName"; // id
	public static final String DRIVER_PROMPT_ID = "driverPrompt"; // id
	public static final String ADDBUTTON = "//button[contains(text(),'Add')]";

	/*
	 * Ayub Khan
	 */

	// View Account Details Page
	public static final String VIEW_ACCT_DETAILS_LINK = "View Account Details"; // linktext
	public static final String EDITACCOUNTDETAILS = "lform:customerView_editAccount"; // id
	public static final String ACCTINFOLABEL = "//h2[contains(text(),'Account Detail')]";
	public static final String ACCTNAME = "//div[contains(text(),'Account Name')]/../following-sibling::div";
	public static final String ACCTNO = "//div[contains(text(),'Account Number')]/../following-sibling::div";
	public static final String UPDATECREDITLIMITLINK = "lform:customerView_updateCreditLimit";
	public static final String ACCOUNTCURRENTBALANCE="accountProfile_Form:accountProfile_currentBalance";
	public static final String ACCOUNTCREDITLIMIT="lform:account_credit_limit";
	public static final String CREDITLIMIT_EMAILADDRESS="lform:creditLimitAlertContactVODoTemail_address";
	public static final String PHONE_NUMBER_FIELD="lform:phone_business";
	public static final String EMAIL_ADDRESS_FIELD="//input[@id='lform:email_address']";
	public static final String ACCOUNT_TRADING_NAME="lform:custMaintenance_trading_name_top";
	public static final String ACCOUNT_MEMBER_NUMBER="lform:custMaintenance_member_number_top";

	/*
	 * Ayub Khan
	 */
	// Edit Account Details Page
	public static final String ACCOUNTDETAILSNAME = "lform:custMaintenance_trading_name_top"; // id
	public static final String ACCOUNTDETAILSNUMBER = "lform:custMaintenance_member_number_top";
	public static final String ACCOUNTLEVELPIN = "//input[@id='lform:pin_offset']";
	public static final String CONFIRMACCOUNTLEVELPIN = "lform:confirmPin";
	public static final String SAVECHANGESBUTTON = "lform:custMaint_btnSave";
	public static final String CONFIRMATIONMESSAGE = "successMsg";
	public static final String ALERTTHRESHOLD = "lform:alert_limit";
	public static final String RETURNTOACCOUNTDETAILBUTTON = "lform:custMaint_btn_return";

	// Card Confirmation Page
	public static final String CARDNUMBER = ".//*[@id='body']/main/div[1]/div/table/tbody/tr/td[2]/a";

	// Common locators
	public static final String PAGE_TITLE_DP = "//*[@class='content_top_header']";

	// BP OLS Login Page
	public static final String BPUSERNAME = "j_username";
	public static final String BPPASSWORD = "j_password";
	public static final String LOGINBUTTON = "btn_login";
	public static final String BPLOGO = "headerForm:auCommandLnk";
	public static final String FORGETEMAILPWD = "emailPassword";
	public static final String CONTACTUS = "contactUs";
	public static final String REQALOGON = "requestALogon";
	public static final String LOGINERR = "//ul[@id='loginErrors']/li";

	// BP OLS Details Page

	public static final String LOGOFF = "logoff";
	public static final String HELPC = "accountProfile_online_user_guideLnk";
	public static final String HOME_MENU_BP = "menu_form:levelOneHome";
	// public static final String CARDS_MENU="levelOneCards";
	// public static final String TRANSACTIONS_MENU="levelOneTransactions";
	public static final String REPORTS_MENU_BP = "levelOneReports";
	public static final String PAYMENTS_MENU = "levelOnePayment";
	// public static final String SUPPORT_MENU="levelOneSupport";
	public static final String TOPUSERDD = "userdrop";
	public static final String ACCTDETAIL_LEFT_HEADER = "accountprofileForm:accountProfileAccountDetailLnk";
	public static final String INTRO_TEXT = "//div[@id='intro']/div/h1";
	public static final String INTRO_MESSAGE = "homePagelform:homepage_welcome_msg";
	public static final String FOOTER_HOME_LINK = "footerWexForm:footer_homeLnk";
	public static final String FOOTER_CONTACTUS = "footerWexForm:footer_linkContactUs";
	public static final String FOOTER_USERGUIDE = "footerWexForm:footer_online_user_guideLnk";
	public static final String FOOTER_LEG_NOTICE = "footerWexForm:footer_linkLegal_notice";
	public static final String FOOTER_LEG_NOTICE_UPDATED = "//a[@id='footerWexForm:footer_linkLegal_notice1']";
	public static final String FOOTER_PRIV_STATEMENT = "footerWexForm:footer_linkPrivacy_statement";
	public static final String FOOTER_PRIV_STATEMENT_UPDATED = "//a[@id='footerWexForm:footer_linkPrivacy_statement1']";
	public static final String COPYRIGHT_FOOTER = "footerFormThree";
	public static final String FINDANDUPDATECARDSHM = "homePagelform:homepage_levelTwoCardList";
	public static final String ORDERCARDHM = "homePagelform:homepage_levelTwoCardNew";
	public static final String MANAGERRESISSUECARDS = "homePagelform:homepage_bulkReissueListMenu";
	public static final String BULKORDERANDUPDATECARDS = "homePagelform:homepage_levelTwoBulkCardOrder";
	public static final String RUN_REPORT_HM = "homePagelform:homepage_levelTwoRepAdHocView";
	public static final String MGE_RECURRING_REPORT_HM = "homePagelform:homepage_levelTwoRecurringReports";
	public static final String PAST_REPORTS_HM = "homePagelform:homepage_levelTwoRepRePrint";
	public static final String FIND_EXPORT_TRANSC_HM = "homePagelform:homepage_levelTwoAccTransList";
	public static final String ACCOUNT_DETAILS_HM = "homePagelform:homePageAccountDetailLnk";
	public static final String PASSWORD_HM = "homePagelform:homepageChangePasswordLnk";
	public static final String LOGONS_HM = "homePagelform:homepageRequestLogonLnk";
	public static final String SET_CREDIT_LIM = "homePagelform:homepageUpdateAccountSetCreditLimit";
	public static final String VIEW_EDIT_CONTACT_HM = "homepage_levelTwoContactsList";
	public static final String VIEW_EDIT_COST_CENTRE_HM = "homepage_costCentreMenu";
	public static final String VIEW_EDIT_VEHICLES = "homepage_vehiclesMenu";
	public static final String MAKE_PAYMENT = "homePagelform:homepage_homepagePaymentAMake";
	public static final String UPDATE_PAYMENT = "homePagelform:homepage_homePagePaymentDetailsUpdate";
	public static final String SET_UP_AUTO_TOP_UP = "homePagelform:homepage_homePagePaymentAutoTopUp";
	public static final String MANAGE_AUTO_PMNTS = "homePagelform:homepage_homePagePaymentAutoPayment";
	public static final String CONTACT_US_GS = "homePagelform:homepage_homePagePaymentAutoPayment";
	public static final String FAQ_GS = "homepage_levelTwoBPFaqs";
	public static final String ORDER_MERCHANDISE = "homepage_levelTwoOrderMerchandise";

	// Find and Update Cards
	public static final String FIND_UPDATE_CARD_TITLE = "//div[@id='lform:contentFormWrapper']/h1";
	public static final String FINDANDUPDATECARDS = "menu_form:levelTwoCardList";
	public static final String RETURN_TO_CARDS = "lform:btn_returnfull"; //id Added by Suganthi 27/08/2018
	public static final String MULTIFIELD_SEARCH = "lform:multipleFieldsSearch";
	public static final String BULK_CARD_STATUS_SUB_MENU = "levelTwoCardBulkStatus";
	//public static final String ACCOUNT_LIST = "lform:customer_mid_menu"; -- this id is not working 
	public static final String ACCOUNT_LIST = "lform:customer_mid"; // Added by Suganthi 08/10/2018
	public static final String ACCOUNT_LIST_BOX = "//select[contains(@id,'lform:customer_mid')]";
	public static final String CHANGE_CARD_STATUS = "//select[contains(@id,'card_status')]"; //
	public static final String CARD_STATUS = "lform:card_status_oid";
	public static final String ADVANCED_SEARCH = "//div[@class='separator_green']";
	public static final String ADV_CARD_TYPE = "//input[contains(@id,'lform:card_type_cid')]";
	public static final String CARDTYPE_BOTH = "lform:card_type_cid:0";
	public static final String CARDTYPE_DRIVER = "lform:card_type_cid:1";
	public static final String CARDTYPE_VEHICLE = "lform:card_type_cid:2";
	public static final String COST_CENTRE = "lform:customer_cost_centre_codeInput";
	public static final String VEHICLE_DESC = "lform:vehicle_description";
	public static final String REF_NUM = "lform:reference_number";
	public static final String SEARCH_CARDS = "lform:btn_search";
	public static final String RESEND_PIN = "//div[@class='rich-table-menu'][@style='display: block;']//a[contains(@id,'mnuResendPin')]";
	public static final String CHANGE_PIN = "//div[@class='rich-table-menu'][@style='display: block;']//a[contains(@id,'mnuChangePINCommandLink')]";
	public static final String CARD_FOUND_HEADER = "//*[@id='lform:searchresults']/div/h3";
	// public static final String REISSUE_CARD =
	// "lform:tableCardList:36:mnuReplaceCardCommandLink";
	public static final String ACTIVECARDS_WITHPIN = "//tbody[@id='lform:tableCardList:tb']/tr[descendant::td[1]//a[contains(@id,'mnuResendPin')]][descendant::td[3]//span[text()='Active']]/td[1]/div//a/span";
	public static final String ACTIVECARDS_WITHCHANGEPIN = "//tbody[@id='lform:tableCardList:tb']/tr[descendant::td[1]//a[contains(@id,'mnuChangePINCommandLink')]][descendant::td[3]//span[text()='Active']]/td[1]/div//a/span";

	public static final String RESENDPINPOPUPOK = "lform:btn_confirm_confirm";
	public static final String RESENDPINPOPUPCANCEL = "lform:btn_confirm_cancel";
	public static final String PINREQUESTSENTMESSAGE = "lform:resend_pin_popup_panel_message_text";
	public static final String REQUESTSENTPOPUPOK = "lform:btn_confirm_ok";
	public static final String REPORT_DELIVERY_FULLERRORMSG = "//div[contains(@id,'errorMsg')]//li";
	public static final String PAGE_TITLE1 = "//form[@id='lform']/h1";
	public static final String MANAGE_REISSUE_REQUESTS = "menu_form:bulkReissueListMenu";
	public static final String COMMON_TITLE_SEC = "//div[@id='lform:contentFormWrapper']/h1";
	public static final String FIRSTCARD_FROM_CARDSLIST = "//tbody[contains(@id,'lform:tableCardList:tb')]//tr[1]/td[1]//p/a";
	public static final String CHANGESTATUS = "//div[@class='rich-table-menu'][@style='display: block;']//a[contains(@id,'mnuCancelChangeStatusCommandLink')]";
	public static final String EXPORT_CARD_TOEXCEL = "lform:tableCardList_xls";

	// Re-issue card * Ayub khan - 03-05-2018
	// public static final String REISSUE_CARD =
	// "lform:tableCardList:36:mnuReplaceCardCommandLink";
	public static final String REISSUE_CARD = "//div[@class='rich-table-menu'][@style='display: block;']//a[contains(@id,'mnuReplaceCardCommandLink')]";
	//public static final String ENTER_ANOTHER_ADDRESS = "lform:address_radio_opt_r:j_idt261"; id is not working for BP Prepaid
	public static final String ENTER_ANOTHER_ADDRESS = "//input[contains(@name,'lform:address_radio_opt_r')][@value='AnotherAddress']";
	//public static final String DELIVER_CARD_TO_THIS_ADDRESS = "lform:bpReplaceCardMgrAddressChange:j_idt268"; id is not working for BP Prepaid
	public static final String DELIVER_CARD_TO_THIS_ADDRESS = "//input[contains(@name,'lform:bpReplaceCardMgrAddressChange')][@value='addressChangeTemp']";
	public static final String DELIVER_TITLE = "lform:cardContactVODoTcontact_title";
	public static final String DELIVER_CONTACT_NAME = "lform:cardContactVODoTcontact_name";
	public static final String DELIVER_ADDRESS = "lform:cardContactVODoTstreetAddressVODoTaddress_line";
	public static final String DELIVER_SUBURB = "lform:cardContactVODoTstreetAddressVODoTsuburb";
	public static final String DELIVER_POSTCODE = "lform:cardContactVODoTstreetAddressVODoTpostal_code";
	public static final String DELIVER_STATE = "lform:cardContactVODoTstreetAddressVODoTstate_oid";
	public static final String DELIVER_CONFIRM_AND_REISSUE = "lform:btn_orderCardFullAccess";

	// Manage Reissue Requests
	public static final String Manage_Reissue_Requests = "menu_form:bulkReissueListMenu";

	// Bulk Order and Update Cards
	public static final String BULKORDER_UPDATECARDS = "menu_form:levelTwoBulkCardOrder";
	// Bulk Card Order
	public static final String BULK_CARD_ORDER = "lform:bulkCardOperation:j_idt237";
	public static final String BULKCARD_ORDER_DOWNLOAD = "lform:bulkCardsOrder_download_btn";
	// public static final String UPLOAD_BULKCARD_ORDER = "lform:j_idt264"; //id is
	// not working for BP Prepaid
	public static final String UPLOAD_BULKCARD_ORDER = "//a[text()='Upload Bulk Card Order']"; // xpath
   //Bulk card close EMAP
	//public static final String  BULK_CARD_CLOSE="lform:modalPanelUploadUformCommandLink";//id
	//public static final String  BULK_CARD_CLOSE="lform:j_idt333";//input
	public static final String  BULK_CARD_CLOSE="lform:hidelink1";//"//div[@id='formSubmit']/input[@value='Close']";
	public static final String BULK_CARD_REQUEST_MESSAGE="Bulk Card Update Request Message";
	public static final String  LOCATION_EMPTY_CARDNUMBER="lform:tableTransList:0:c1";
	public static final String  TRANSACTION_SUNDRY_DETAIL="//form[@id='lform']/h1/span";
	public static final String  UPDATE_REQUEST_MESSAGE_POPUP="lform:modalPanelMessage_shadow";
	// Bulk Card Update
	public static final String BULK_CARD_UPDATE = "lform:bulkCardOperation:j_idt239";
	public static final String BCU_UPLOAD_EXCEL_FILE = "lform:uploadUpdateCardsModal_btn";
	public static final String BCU_MULTI_FIELD_SEARCH = "lform:multipleFieldsSearch"; // BCU-Bulk Card Update
	public static final String BCU_ACCOUNT_LIST = "lform:customer_mid";
	public static final String BCU_CARD_STATUS = "lform:card_status_oid";
	public static final String BCU_ADVANCED_SEARCH = "//div[@class='separator_green']";
	public static final String BCU_REFERNCE = "lform:external_ref";
	public static final String BCU_CARDTYPE_BOTH = "lform:card_type_cid:0";
	public static final String BCU_CARDTYPE_DRIVER = "lform:card_type_cid:1";
	public static final String BCU_CARDTYPE_VEHICLE = "lform:card_type_cid:2";
	public static final String BCU_COST_CENTRE = "lform:customer_cost_centre_codeInput";
	public static final String BCU_CARD_PURCHASES_SINCE_DATE = "lform:last_transaction_onInputDate";
	public static final String BCU_EXPIRING_TO_DATE = "lform:expires_onInputDate";
	public static final String BCU_SEARCH = "//span[contains(text(),'Search')]";
	public static final String BULK_CARD_UPDATE_FILE_FIELD = "updateFileField";
	public static final String UPLOAD_BULK_CARD_UPDATE = "//span[text()='Upload Bulk Card Update']";
	public static final String UPLOAD_BULK_CARD_UPLOAD = "//span[text()='Upload']";
	public static final String BULK_CARD_UPDATE_SUCCESSMESSAGE = "//h1[contains(text(),'Bulk Card Update Completed')]";
	// Bulk Card Status
	public static final String BULK_CARD_STATUS = "lform:bulkCardOperation:j_idt241";
	public static final String BCS_MULTI_FILD_FILE = "lform:keyVODoTmultipleFieldsSearch"; // BCS - Bulk Card Status
	public static final String BCS_ACCOUNT_LIST = "lform:keyVODoTcustomer_mid";
	public static final String BCS_CARD_STATUS = "lform:keyVODoTcard_status_oid";
	public static final String BCS_CARD_STATUS_VALUE = "(//tr/td/p/span)[position()=3]"; // xpath Added by Suganthi 
	public static final String BCS_CARD_UPDATE_STATUS = "lform:card_status_oid"; //Added by Suganthi 14/08/2018
	public static final String BCS_ADVANCED_SEARCH = "//div[@class='separator_green']"; //xpath
	public static final String BCS_REFERNCE = "lform:keyVODoTexternal_ref";
	public static final String BCS_UPDATE_CARDTYPE = "//input[contains(@id,'lform:card_type_cid')]"; //xpath Added by Suganthi 16/08/2018
	public static final String BCS_CARDTYPE = "//input[contains(@id,'lform:keyVODoTcard_type_cid')]"; //xpath Added by Suganthi 20/08/2018
	public static final String BCS_CARDTYPE_BOTH = "lform:keyVODoTcard_type_cid:0";
	public static final String BCS_CARDTYPE_DRIVER = "lform:keyVODoTcard_type_cid:1";
	public static final String BCS_CARDTYPE_VEHICLE = "lform:keyVODoTcard_type_cid:2";
	public static final String BCS_PURCHASES_SINCE_DATE = "lform:keyVODoTlast_transaction_onInputDate";
	public static final String BCS_EXPAIRING_BEFORE_DATE = "lform:keyVODoTexpiringToInputDate";
	public static final String BCS_EXPAIRING_AFTER_DATE = "lform:keyVODoTexpiringFromInputDate";
	// public static final String BCS_SEARCH = "//span[contains(text(),'Search')]";

	// Find and Export Transactions
	public static final String FIND_EXPORT_TRANSC = "menu_form:levelTwoAccTransList";
	public static final String CONTENT_TITLLE = "//h1[contains(text(),'Find and Export Transactions')]";
	public static final String CARD_OR_DRIVER_OR_VEH_DETAILS = "lform:transList_cardNo_driver_rego";
	public static final String ACCOUNT_SEL = "lform:accounts";
	public static final String FROM_DATE = "lform:effective_date_fromInputDate";
	public static final String TO_DATE = "lform:effective_date_toInputDate";
	public static final String DATE_RANGE = "lform:dateRange";
	public static final String ADV_SEARCH_LINK = "transSearchAdvOpt";
	public static final String RECEIPT_NUM = "lform:transaction_reference";
	public static final String COST_CENTRE_TB = "lform:cost_centreInput";
	public static final String PRD_SEL = "lform:product_oid";
	public static final String SEARCH_BTN = "lform:btn_searchfullAccess";
	public static final String SETTLEMENT_LIST = "//tbody/tr/td[1][contains(@id,'lform:tableSettLementsList')]";
	public static final String SETTLEMENT_LIST_NOITEM = "lform:tableSettLementsListout";
	public static final String BACK_TO_SETTLEMENT_LIST = "lform:bnt_backfullAccess";
	public static final String FULL_TRA_SEARCH = "//span[@id='lform:transList_AboutFind']/div";
	public static final String TRA_SEARCH_HEADING = "//h3[@class='infoHelpHeader markIcon']";
	public static final String TRA_SEARCH_BODY = "//div[@class='infoHelpHeaderBlock']";
	public static final String FULL_TRA_RESULTS = "lform:searchResultsGroup";
	public static final String TRA_RES_INSTRUCTIONS = "//p[@class='instructions']";
	public static final String TRA_MATCH = "//div[@class='span2']/h4";
	public static final String EXPORT_TRA_TOP = "lform:tabletransListxls";
	public static final String EXPORT_TRA_BOTTOM = "lform:tabletransListxls_bottom";
	public static final String TRA_DETAILS_TBL = "lform:tabletransList";
	// Added by Nithya - 21-05-2018
	public static final String TRANSACTION_TABLE_CONTENT = "//td[contains(@id,'lform:tabletransList:')][contains(@id,'c1')]";
	public static final String TRANSACTION_TABLE_ROWS = "tbody tr[id*='lform:tabletransList:']";
	public static final String VIEW_TRANSACTION = "//div[@class='rich-table-menu'][@style='display: block;']//a[contains(@id,'tool_viewfullAccess')]";
	public static final String GO_TO_CARD = "//div[@class='rich-table-menu'][@style='display: block;']//a[contains(@id,'tool_viewCard')]";
	public static final String RETURN_TO_TRANSACTION_LIST = "//a[@id='lform:BbBackTransactionListfullAccess']|//a[@id='lform:TransDetailBack']";

	//public static final String CARD_NUMBER = "lform:card_number";
	public static final String CHV_TRANSACTION_TABLE = "lform:tableTransList:tb";
	// Run Reports
	public static final String RUN_REPORT = "menu_form:levelTwoRepAdHocView";
	public static final String PAGE_TITLE = "lform:pageHeader"; // WE can use for multiple page Header Validation
	public static final String REP_INSTRUCTIONS = "//p[@class='instructions left']";
	public static final String REPORT_TYPE_SEL = "lform:runReportreport_group_did";
	public static final String REPORT_DETAIL_SEL = "lform:report_type_oid";
	public static final String CUS_NUM = "lform:customer_no";
	//public static final String SEL_MULTI_CUS = "lform:selectMultipleAccountsLink";
	public static final String MULTIPLE_ACCT_POPUP = "lform:selectMultipleAccountsPopup_container";
	public static final String TITLE_POPUP = "//h1[contains(text(),'Select Multiple Accounts')]";
	//public static final String CLOSE_POPUP = "lform:j_idt225"; id is not working for BP Prepaid
	public static final String CLOSE_POPUP = "//a[@title='Close']";
	public static final String SELECT_LAST = "//tr[last()]//td//p//input[contains(@name,'lform:selectMultipleAccountsTable')]"; //xpath Added by SUganthi 30/08/2018
	public static final String SELECT_ALL = "lform:j_idt232";
	public static final String DESELECT_ALL = "lform:j_idt235";
	public static final String SECLECT_ALL_BOTTOM = "lform:j_idt254";
	public static final String DESELECT_ALL_BOTTOM = "lform:j_idt257";
	public static final String CANCEL_BUTTON = "lform:btn_confirm_cancel";
	//public static final String SELECT_ACCTS = "lform:j_idt265"; id is not working for BP Prepaid
	public static final String SELECT_ACCTS = "//span[contains(text(),'Select Accounts')]"; //xpath
	public static final String REPORT_SCHEDULING = "//input[@name='lform:report_mode']"; //xpath Added by Suganthi 29/08/2018
	public static final String RUN_ONE_TIME_RB = "lform:report_mode:0";
	public static final String RECURRING_REPORT_RB = "lform:report_mode:1";
	public static final String REPORT_DELIVERY = "//tr//td//input[@name='lform:report_contact_options']"; // xpath  Added by Suganthi 29/08/2018
	public static final String DOWNLOAD_DISPLAY_RB = "lform:report_contact_options:report_contact_options_download";
	public static final String SEND_EMAIL_RB = "lform:report_contact_options:report_contact_options_select";
	public static final String SELECT_CONTACT = "lform:runReport_contactEmail";
	public static final String SEND_EMAIL_TEXT_RB = "lform:report_contact_options:report_contact_options_email";
	public static final String CONTACT_TEXT = "lform:input_email_address";
	public static final String COMPRESS_EMAIL_ATT = "lform:is_attachment_compressed";
	public static final String RUN_REPORT_BUTTON = "lform:btn_submit";
	public static final String DOWNLOAD_A_REPORT_BUTTON = "//a[contains(@id,'lform:btn_submit')]/span[1]";
	public static final String REPORT_DELIVERY_ERRORMSG = "fieldErrorMsgForemail_address";
	public static final String APPLY_DATE_RANGE = "lform:dateRangeSelect"; //id Added by Suganthi 29/08/2018
	public static final String EMAIL_FULL_REPORT = "lform:delivery_type_cid:0"; //id Added by Suganthi 29/08/2018
	public static final String DATE_TO = "//input[@id='lform:date_range_toInputDate']";  //Added by Suganthi 29/08/2018
	public static final String DATE_FROM = "//input[@id='lform:date_range_fromInputDate']";  //Added by Suganthi 29/08/2018
 
	// Manage Recurring reports
	public static final String MGE_RECURRING_REPORT = "menu_form:levelTwoRecurringReports";
	public static final String REPORT_CONTENTS = "lform:contentFormWrapperCategoryItem";
	public static final String CREATE_RECURR_REP = "//a[@title='Create a new Recurring Report']";

	// Past Reports
	public static final String PAST_REPORTS = "menu_form:levelTwoRepRePrint";
	public static final String REPORTS_GEN = "lform:contentFormWrapperCategoryItemGenReports";
	public static final String RECURR_REP_GEN = "lform:contentFormWrapperCategoryItemRecReports";
	public static final String ACTIVE_RB = "lform:display_filter:display_filter_active";
	public static final String ONHOLD_RB = "lform:display_filter:display_filter_onhold";
	public static final String ALL_RB = "lform:display_filter:display_filter_all";
	// Added by Nithya 22-05-2018
	public static final String VIEW_ALL_IN_GENERATE_REPORT_TABLE = "//a[contains(@id,'lform:genRepTable:')][contains(@id,'viewAllLink')]";
	public static final String DOWNLOAD_LISTED_REPORTS_AS_ZIP = "lform:btn_downloadZippedReports";
	public static final String ERR_MSG = "//div[contains(@id,'errorMsg-')]";
	public static final String VIEW_ALL_IN_RECURRING_REPORT_TABLE = "//a[contains(@id,'lform:scheduleRepoList')][contains(@id,':viewRecReportLink')]";
	public static final String STORED_REPORTS_TABLE = "lform:storedReportsTable";
	// Added by Nithya 23-05-2018
	public static final String FILTER_BTN = "lform:btn_filter";
	// Added by Nithya 24-05-2018
	public static final String CLEAR_FILTER_AND_SHOW_ALL = "lform:lnk_clearFilters";
	public static final String REPORT_COUNT = "//div[@id='reports']//h4";

	//Invoice Reports
	public static final String Invoice_REPORTS = "levelTwoRepInvoices";
	/*
	 * Change Card Status page 03-05-2018
	 */
	public static final String CURRENT_CARD_STATUS = "lform:cardVODoTcard_status_oid";
	public static final String CURRENT_CARD_TYPE = "lform:cardVODoTcard_type_cid";
	public static final String CURRENT_CARD_NUMBER = "lform:card_no";
	public static final String CURRENT_VEHICLE_INFO = "lform:changeCardStatusVehicleInfo";
	public static final String CURRENT_VEHICLE_DESC = "lform:changeCardStatus_VehicleDesc";
	public static final String CARD_STATUS_GROUP = "contentFormWrapperCategoryItem_1Group";
	public static final String CARD_STATUS_LIST = "//input[contains(@id,'lform:cardVODoTnew_card_status_oidFullAccess')]";
	public static final String RETURNTO_CARD_FOUNDLIST = "lform:bnt_backOrderCardFullAccess";
//	public static final String CARDSTATUSCHANGE_POPUP_YESBUTTON = "lform:saveStatusAndReissueCardBnt";
	public static final String CARDSTATUSCHANGE_POPUP_NOBUTTON = "lform:saveCardStatusBtnFullAccess";
	public static final String CARDSTATUSCHANGE_CONFIRM_POPUP_NOBUTTON = "//input[contains(@id,'lform:saveCardStatusBtn')]";
	public static final String CARDSTATUSCHANGE_POPUP_CLOSEBUTTON = "lform:requestOrReplacePopupCloseformCommandLink";
	public static final String CARDSTATUSCHANGE_POPUP_TEXT = "label.text";
	public static final String CONFIRMANDREISSUE_BUTTON = "lform:btn_orderCardFullAccessStep2";
	public static final String ADDRESSDELIVERY_OPTIONS = "//input[contains(@id,'lform:address_radio_opt_r:')]";
	public static final String VIEWFULLCARDDETAILS_BUTTON = "lform:btn_returnfullStep3";
	public static final String FULLCARD_DETAILS = "div.summaryElementStatic";
	public static final String RETURNTOCARD_FOUNDLIST_BUTTON = "lformCardView:btn_returnfull";
	public static final String SAVE_CHANGES = "//a[@id='lform:btn_orderCardFullAccess']"; //xpath Added by Suganthi 24/08/2018
	public static final String STATUS_EFFECTIVE = "//input[contains(@name,'lform:new_card_status_at')][@value='Now']";  //xpath Added by Suganthi 24/08/2018
	public static final String CHANGE_STATUS_TO = "//input[contains(@id,'lform:cardVODoTnew_card_status_oidFullAccess')]"; //xpath Added by Suganthi 24/08/2018
	public static final String VIEW_CARD_DETAILS = "//a[@title='View Full Card Details']"; //xpath
	

	// Order A Card
	public static final String ORDER_A_CARD = "menu_form:levelTwoCardNew";
	public static final String CARD_OFFER = "//select[@id='lform:cardProductVODoTcard_offer_oid']";
	public static final String CH_ORDER_A_CARD_PAGE_TITLE = "//*[@id='tableListForm']/h1/span";

	// Added by Meenakshi
	public static final String ORDER_A_CARD_PAGE_TITLE = "tr[id='nav_steps'] td[class='content_top_header']"; // CSS
	public static final String AN_EXISTING_CARD_BUTTON = "open_cardListModal"; // id
	public static final String EXISTING_CARD_POPUP_TITLE = "lform:cardListModal_header_content"; // id
	public static final String ACCOUNT_FIELD_IN_EXISTING_CARD_POPUP = "lform:customer_mid"; // id
	public static final String CARD_STATUS_FIELD_IN_EXISTING_CARD_POPUP = "lform:card_status_oid"; // id
	public static final String CARD_NUMBER_FROM_EXISING_CARD_SEARCH_RECORD = "//a[contains(@id,'lform:tableCardList:0:j_idt')]";
	public static final String VIEW_CARD_POPUP_HEADER = "lform:cardNewCardViewModal_header_content";
	public static final String VIEW_CARD_CLOSE_BUTTON = "//div[@id='lform:cardNewCardViewModal_header_controls']/a[contains(@id,'lform:j_idt')]";
	public static final String RADIO_BUTTON_FROM_SEARCH_RECORDS = "//input[contains(@id,'lform:tableCardList:0:j_idt')]";
	public static final String APPLY_TO_NEW_CARD_ORDER_BUTTON = "lform:cardNewCardSearchApplyToNewCard";
	public static final String CARD_NUMBER_FROM_SEARCH_TABLE = "tbody[id='lform:tableCardList:tb'] a";
	public static final String ORDER_CARD_PAGE = "//*[@id='nav_steps']/td[1]";
	public static final String VEHICLE_DESCRIPTION_FIELD = "lform:vehicleVODoTdescription";
	public static final String REGO_NUMBER_FIELD = "lform:vehicleVODoTlicense_plate";
	public static final String CONTINUE_BUTTON = "lform:btn_orderCard";
	public static final String NEWCARD_NUMBER = "lform:cardVODoTemboss_line_1";
	public static final String UNUSUAL_ACTIVITY_LIMITS_HEADER = "//h3[@class='categoryHeader unusualActivityLimitesIcon']";
	public static final String DELIVERY_ADDRESS_HEADER = "//h3[@class='categoryHeader envelopeIcon']";
	public static final String PLACE_ORDER_PAGE_HEADER = "//div[@class='nav_opt_menu_desc'][contains(text(),'Place Order')]";
	public static final String ORDER_CARD_BUTTON = "//input[contains(@id,'orderCard')]"; // updated by RM
	public static final String ORDER_CARD_SUCCESS_MSG = "//div[@class='successGreenDot']";
	// public static final String CARD_ORDERED_NUMBER_CREATED = "lform:j_idt1285";
	public static final String SUCCESS_MESSAGE = "//div[@class='successGreenDot']";
	public static final String SUCCESS_MESSAGE_CARD_NUMBER = "//*[contains(@id,'lform:j_idt')]";
	public static final String SAVE_CONFIGURATION_AS_PROFILE_BUTTON = "lform:cardNewSetp5_save_as_profile_btn";
	public static final String SAVE_CONFIGURATION_AS_PROFILE_POPUP = "//h1[@class='smaller']"; // Xpath
	public static final String CARD_CONFIGURATION_PROFILE_NAME_FIELD = "lform:name";
	public static final String CARD_CONFIGURATION_PROFILE_SAVE_BTN = "lform:btn_saveProfile";
	public static final String CONFIG_PROFILE_CLOSE_BUTTON = "//span[@id='lform:saveProfileModal_controls']/a";
	public static final String LIST_OF_CARD_NUMBER = "//tbody/tr/td[1][contains(@id,'cardNumber')]/div/p/a/span";
    public static final String LIST_OF_DRIVER_NAME="//tbody/tr/td[contains(@id,'driver_namel')]/p/span";
    public static final String LIST_OF_REG_NUMBER="//tbody/tr/td[contains(@id,'license_plateL')]/p/span";
	public static final String NEXT_PAGE = "lform:pagination_cardList_ds_next";
	public static final String VEHICLE_RADIO_BUTTON = "lform:cardVODoTcard_type_cid:1";
	public static final String TRANSACTION_LIST_TABLE = "//table[@id='lform:tableTransList']";
	public static final String TRANSACTION_LIST_ACCOUNT = "lform:accounts"; // id Added by Suganthi 11/09/2018
	public static final String TRANSACTION_LIST_SELECT_ROW = "lform:tableTransList:0:c1";
	public static final String TRANSACTION_DETAILS_BUTTON = "lform:tableTransList:0:tool_viewfullAccess";
	// 1 Enter Card Details
	public static final String AN_EXISTING_CARD = "open_cardListModal";
	public static final String AN_EXISTING_MULTICARD_SEARCH = "lform:multipleFieldsSearch";
	public static final String AN_EXISTING_ACCOUNT_LIST = "lform:customer_mid";
	public static final String AN_EXISTING_CARD_STATUS = "lform:card_status_oid";
	public static final String AN_EXISTING_ADVANCE_SEARCH = "searchAdvOpt";
	public static final String AN_EXISTING_CARDTYPE_BOTH = "lform:card_type_cid:0";
	public static final String AN_EXISTING_CARDTYPE_DRIVER = "lform:card_type_cid:1";
	public static final String AN_EXISTING_CARDTYPE_VEHICLE = "lform:card_type_cid:2";
	public static final String AN_EXISTING_CARDTYPE_COSTCENTER = "lform:customer_cost_centre_codeInput";
	public static final String AN_EXISTING_CARDTYPE_VEHICLEDECS = "lform:vehicle_description";
	public static final String AN_EXISTING_CARDTYPE_REFRENCE_NUMBER = "lform:reference_number";
	public static final String AN_EXISTING_CARDTYPE_SEARCH = "lform:btn_search";
	public static final String AN_EXISTING_CARDTYPE_CLOSE = "lform:cardListModal_header_controls";
	// SAVE A PROFILE
	public static final String SAVE_A_PROFILE = "open_cardNewSavedProfileModal";
	public static final String SAVE_A_PROFILE_TEXT = "//h1[contains(text(),'Get Details from Previous Profiles')]";
	public static final String SAVE_A_PROFILE_CLOSE = "lform:cardNewSavedProfileModal_header_controls";
	public static final String SAVE_A_PROFILE_APPLYANDCLOSE = "lform:cardNewSavedProfileApplyToNewCard";
	public static final String SELECT_PROFILE = "lform:tableCardProfile:0:profileToCloneTempSelectOneRadio"; //Added by Suganthi 03/09/2018
	// Order A Card / Card information
	public static final String CARD_INFORMATION_DRIVER = "lform:cardVODoTcard_type_cid:0";
	public static final String CARD_INFORMATION_VEHICLE = "lform:cardVODoTcard_type_cid:1";
	public static final String CARD_INFORMATION_DRIVER_NAME = "lform:driverVODoTdriver_name";
	public static final String CARD_INFORMATION_DRIVER_ID_TEXTBOX = "lform:driverVODoTdriver_id";
	public static final String CARD_INFORMATION_VEHICLE_DESCRIPTION = "lform:vehicleVODoTdescription";
	public static final String CARD_INFORMATION_VEHICLE_REGO_NUMBER = "lform:vehicleVODoTlicense_plate";
	public static final String CARD_INFORMATION_EXPIRE_DATE = "lform:cardVODoTexpires_onInputDate";
	public static final String CARD_INFORMATION_COST_CENTRE = "lform:costCentreCodeInput";
	public static final String CARD_INFORMATION_EMBOSSING_NAME = "lform:cardVODoTembossing_name";
	public static final String CARD_INFORMATION_REFERENCE_NUMBER = "lform:cardVODoTexternal_ref";
	public static final String CARD_INFORMATION_PIN = "lform:cardVODoTis_pin_req";
	public static final String CARD_INFORMATION_SIGNATURE = "lform:cardVODoTis_signature_req";
	public static final String CARD_INFORMATION_ODOMETER = "lform:cardControlProfileVOsDoTcardControlVODoTis_odometer_req";
	public static final String CARD_INFORMATION_PIN_TEXTBOX = "lform:cardVODoTpin_offset";
	public static final String CARD_INFORMATION_CONFIRM_PIN = "lform:cardVODoTconfirm_pin_offset";
	public static final String CARD_INFORMATION_SAVECHANGES = "lform:btnSave";
	public static final String CARD_INFORMATION_DRIVER_ID = "lform:cardControlProfileVOsDoTcardControlVODoTis_driver_id_req";
	public static final String CARD_INFORMATION_VEHICLE_ID = "lform:cardControlProfileVOsDoTcardControlVODoTis_vehicle_id_req";
	public static final String CARD_INFORMATION_FLEET_ID = "lform:cardControlProfileVOsDoTcardControlVODoTis_fleet_id_req";
	public static final String CARD_INFORMATION_ORDER_NUMBER = "lform:cardControlProfileVOsDoTcardControlVODoTis_order_number_req";
	public static final String CARD_INFORMATION_REPORT_EMAIL = "lform:cardVODoTreport_email_address";
	public static final String BULK_CARD_ORDER_UPDATE = "lform:bulkCardOperation:j_idt236"; 
	public static final String BROWSER_POP_UP_ORDER = "//div[@id='orderBulkCardsFileUpload']//span//div[@id='browserVisible']";
	public static final String BROWSER_POP_UP_UPDATE = "//div[@id='updateBulkCardsFileUpload']//span//div[@id='updateBrowserVisible']";
	 public static final String CLOSE_POP_UP = "//div[@id='lform:uploadOrderCardsModal_header_controls']";
	 public static final String BULK_ORDER_CARD_SUCCESS = "lform:successWrapper";
	 public static final String BULK_UPDATE_CARD_SUCCESS = "lform:successUpdateBulkWrapper";
	// Order A Card / Purchase Restrictions
	public static final String CARD_PURCHASE_RESTRICTIONS_NO_RESTRICTIONS = "lform:cardVODoTpump_control_oid:0";
	public static final String CARD_PURCHASE_RESTRICTIONS_NO_UNMANNED_SITE = "lform:cardVODoTpump_control_oid:1";
	public static final String CARD_PURCHASE_RESEAL_ALL_PROCUTD = "lform:j_idt441";
	public static final String CARD_PURCHASE_TRANS_VALUME_LIM = "lform:cardControlProfileVOsDoTcardControlVODoTvelocityAssignmentVODoTvelocity_type_value_2_oid";
	public static final String CARD_PURCHASE_TRANS_COST_LIMILTS = "lform:cardControlProfileVOsDoTcardControlVODoTvelocityAssignmentVODoTvelocity_type_value_1_oid";
	public static final String CARD_PURCHASE_PRODUCTS_ALL = "lform:firstRowOID:0:titleVO:0:itemVO:0:productItem";
	public static final String CARD_PURCHASE_PRODUCTS_REGULER = "lform:firstRowOID:0:titleVO:0:itemVO:1:productItem";
	public static final String CARD_PURCHASE_PRODUCTS_ALL_UNLEDEAD = "lform:firstRowOID:0:titleVO:0:itemVO:2:productItem";
	public static final String CARD_PURCHASE_PRODUCTS_DIESEL = "lform:firstRowOID:0:titleVO:0:itemVO:3:productItem";
	public static final String CARD_PURCHASE_PRODUCTS_LPG = "lform:firstRowOID:0:titleVO:0:itemVO:4:productItem";
	public static final String CARD_PURCHASE_PRODUCTS_REGULER_UNLEADED_LPG = "lform:firstRowOID:0:titleVO:0:itemVO:5:productItem";
	public static final String CARD_PURCHASE_PRODUCTS_REGULER_UNLEADED_LPG_DIESEL = "lform:firstRowOID:0:titleVO:0:itemVO:6:productItem";
	public static final String CARD_PURCHASE_PRODUCTS_REGULER_UNLEADED_DIESEL = "lform:firstRowOID:0:titleVO:0:itemVO:7:productItem";
	public static final String CARD_PURCHASE_PRODUCTS_NO_FUEL = "lform:firstRowOID:0:titleVO:0:itemVO:8:productItem";
	public static final String CARD_PURCHASE_PRODUCTS_DURING_TIME = "lform:cardControlProfileVOsDoTcardControlVODoTtime_limit_oid";
	public static final String CARD_PURCHASE_LUBRICATION_YES = "//input[contains(@id,'lform:firstRowOID')][@data-summary-value ='Yes']";
	public static final String CARD_PURCHASE_LUBRICATION_NO = "//input[contains(@id,'lform:firstRowOID')][@data-summary-value ='No']";
	public static final String CARD_PURCHASE_NON_FUEL_ALL_NON_FUEL = "//input[contains(@id,'lform:firstRowOID')][@data-summary-value ='No non-fuels']";
	public static final String CARD_PURCHASE_NON_FUEL_MDC = "lform:firstRowOID:2:titleVO:11:itemVO:12:productItem"; // MDC-Maintenance,
	// Diner
	// and
	// Carwash
	public static final String CARD_PURCHASE_NON_FUEL_MD = "lform:firstRowOID:2:titleVO:11:itemVO:13:productItem";// MD-Maintenance
	// and
	// Diner
	public static final String CARD_PURCHASE_NON_FUEL_DSC = "lform:firstRowOID:2:titleVO:11:itemVO:14:productItem"; // DSC-Diner,
	// Shop
	// and
	// Carwash
	public static final String CARD_PURCHASE_NON_FUEL_CARWASH = "lform:firstRowOID:2:titleVO:11:itemVO:15:productItem";
	public static final String CARD_PURCHASE_NON_FUEL_DINER = "lform:firstRowOID:2:titleVO:11:itemVO:16:productItem";
	public static final String CARD_PURCHASE_NON_FUEL_NO_NONFUEL = "lform:firstRowOID:2:titleVO:11:itemVO:17:productItem";
	public static final String CARD_PURCHASE_NON_FUEL_CONTTINUE = "lform:btn_orderCard";

	// Order A Card - 2 Set Unusual Activity Limits
	public static final String UAL_FUEL_TRANSACTION_COST_OVER = "lform:cardControlProfileVOsDoTcardControlVODoTvelocityAssignmentVODoTvelocity_type_value_3_oid"; // UAL-Unusual
	// Activity
	// Limits
	public static final String UAL_FUEL_TRANSACTION_VOLUME_OVER = "lform:cardControlProfileVOsDoTcardControlVODoTvelocityAssignmentVODoTvelocity_type_value_4_oid";
	public static final String UAL_NON_FUEL_TRANSACTION_COST_OVER = "lform:cardControlProfileVOsDoTcardControlVODoTvelocityAssignmentVODoTvelocity_type_value_5_oid";
	public static final String UAL_FUEL_DAILY_VOLUME_OVER = "lform:cardControlProfileVOsDoTcardControlVODoTvelocityAssignmentVODoTvelocity_type_value_6_oid";
	public static final String UAL_NUMBER_TRANSACTION_DAILY_OVER = "lform:cardControlProfileVOsDoTcardControlVODoTvelocityAssignmentVODoTvelocity_type_value_7_oid";
	public static final String UAL_FUEL_MONTHLY_OVER = "lform:cardControlProfileVOsDoTcardControlVODoTvelocityAssignmentVODoTvelocity_type_value_8_oid";
	public static final String UAL_RETURNTO_CARDDETAILS = "lform:btn_return";
	public static final String UAL_CONTTINUE = "lform:btn_orderCard";
	public static final String TRANSACTION_MONTHLY_LIMIT="//span[contains(text(),'Transaction Monthly Limit')]//parent::label//parent::div//select";
	public static final String TRANSACTION_PURCHASE_LIMIT="//span[contains(text(),'Transaction Purchase Limit')]//parent::label//parent::div//select";
	public static final String DAILY_TRANSACTION_LIMIT = "//span[contains(text(),'Daily Transaction Limit')]//parent::label//parent::div//select";
	public static final String WEEKLY_TRANSACTION_LIMIT = "//span[contains(text(),'Weekly Transaction Limit')]//parent::label//parent::div//select";
	public static final String MONTHLY_VALUE_LIMIT = "//span[contains(text(),'Monthly Value Limit')]//parent::label//parent::div//select";

	// Order A Card - 3 Confirm Delivery Address
	public static final String CDA_DELIVERY_ADDRESS_TEXT = "//h3[contains(text(),'Delivery Address')]"; // CDA- Confirm
	// Delivery
	// Address
	public static final String CDA_ACCOUNT_ADDRESS = "lform:address_radio_opt_1:j_idt923";
	// This address instead
	public static final String CDA_ADDRESS_INSTEAD = "lform:address_radio_opt_1:j_idt939";
	public static final String CDA_ALWAYS_DELIVERY_ADDRESS = "lform:addressDeliveryType:0";
	public static final String CDA_DELIVERY_BELOW_ADDRESS = "lform:addressDeliveryType:1";
	public static final String CDA_TITLE = "lform:permCardContactVODoTcontact_title";
	public static final String CDA_CONTACT_NAME = "lform:permCardContactVODoTcontact_name";
	public static final String CDA_CONTACT_ADDRESS = "lform:permCardContactVODoTstreetAddressVODoTaddress_line";
	public static final String CDA_SUBURB = "lform:permCardContactVODoTstreetAddressVODoTsuburb";
	public static final String CDA_POSTCOAD = "lform:permCardContactVODoTstreetAddressVODoTpostal_code";
	public static final String CDA_SATE = "//select[@id='lform:permCardContactVODoTstreetAddressVODoTstate_oid']";
	public static final String CDA_RETURNTO_UNUSUAL_ACTIVITY_LIMITS = "lform:btn_return";
	public static final String CDA_CONTTINUE = "llform:btn_orderCard";
	public static final String CDA_COUNTRY ="//select[@id='lform:permCardContactVODoTstreetAddressVODoTcountry_oid']";

	// Order A Card - 4 Place Order
	public static final String PLACE_ORDER_CARDTYPE_EDIT = "lform:btn_edit_1";
	public static final String PLACE_ORDER_PURCHASE_RESTRICTIONS_EDIT = "lform:btn_edit_2";
	public static final String PLACE_ORDER_UNUSUAL_ACTIVITY_EDIT = "lform:btn_edit_3";
	public static final String PLACE_ORDER_DELIVERY_ADDRESS_EDIT = "lform:btn_edit_4";
	public static final String PLACE_ORDER_CARD = "lform:btn_orderCardConfirm";
	public static final String PLACE_ORDER_SUCCESS = "orderSuccess";
	public static final String ORDERED_CARD_NUMBER = "orderedCardNo";
	//Added by Suganthi 31/08/2018
	public static final String CARD_DETAILS = "//div[@class='categoryGroup cardPreview']";
	public static final String PURCHASE_RESTRICTIONS = "//div[contains(text(),'Purchase Restrictions')]"; 
	public static final String ACTIVITY_LIMITS = "//div[@class='separator_grey'][contains(text(),'Unusual Activity Limits')]";
	public static final String DELIVERY_ADDRESS = "//div[@class='separator_grey'][contains(text(),'Delivery Address')]";
	public static final String ORDER_ANOTHER_CARD = "//a[text()='Order another Card']";

	// Payments - Make a Payment
	public static final String PAYMENT_MAKE_A_PAYMENT = "menu_form:levelTwoMakePayment";
	public static final String PAYMENT_MAKE_A_PAYMENT_TEXT = "//h1[contains(text(),'Make a Payment')]";
	public static final String PAYMENT_MAKE_A_PAYMENT_AMOUNT = "lform:temp_amount";
	public static final String PAYMENT_MAKE_A_PAYMENT_METHOD_YOUR_BANK_ACCOUNT = "lform:payment_method:payment_method_businessAcc";
	public static final String PAYMENT_MAKE_A_PAYMENT_METHOD_CREADIT_CARD = "//input[@id='lform:payment_method:payment_method_card']";
	public static final String PAYMENT_MAKE_A_PAYMENT_CONFIRM_AND_PAY_NOW = "//a[@id=submitButton]|//a[@id='lform:confirmBankAcc']";
	
	// Payments - Update Payment
	public static final String PAYMENT_UPDATE_PAYMENT_METHOD = "menu_form:levelTwoPaymentUpdate";
	public static final String PAYMENT_UPDATE_PAYMENT_METHOD_TEXT = "//h1[contains(text(),'Update Payment Method')";
	public static final String PAYMENT_UPDATE_PAYMENT_CREADIT_CARD = "lform:details_update_payment_method:details_update_payment_method_card";
	public static final String PAYMENT_UPDATE_PAYMENT_BANK_ACCOUNT = "lform:details_update_payment_method:details_update_payment_method_businessAcc";
	public static final String PAYMENT_UPDATE_PAYMENT_ACCOUNT_LIST = "lform:customer_mid";
	public static final String PAYMENT_UPDATE_PAYMENT_DOWNLOAD_DIRECT_DEBIT = "downloadDirectDebitForm";
	// Payments - Set Up Auto Top Up
	public static final String PAYMENT_SETUP_AND_TOPUP = "menu_form:levelTwoSetUpAutoTopUp";
	public static final String PAYMENT_SETUP_AND_TOPUP_TEXT = "//h1[contains(text(),'Set Up Auto Top Up')]";
	public static final String PAYMENT_SETUP_AND_TOPUP_AUTO_TOPUP = "lform:autoTopUp_Enable";
	public static final String PAYMENT_SETUP_AND_TOPUP_AUTO_TOPUP_DD = "lform:customer_mid";
	public static final String PAYMENT_SETUP_AND_TOPUP_THRESHOLD_AMOUNT = "lform:threshold_amount";
	public static final String PAYMENT_SETUP_AND_TOPUP_AMOUNT = "lform:topup_amount";
	public static final String PAYMENT_SETUP_AND_TOPUP_NOTFICATION_EMAIL = "lform:email_addresses";
	public static final String PAYMENT_SETUP_AND_TOPUP_NOTFICATION_SMS = "lform:sms_numbers";
	public static final String PAYMENT_SETUP_AND_TOPUP_NOTFICATION_CONFIRM_AUTOPUP = "lform:btnSave_autoTopUp";
	// Manage Auto Payments
	public static final String PAYMENT_MANAGE_AUTO_PAYMENTS = "menu_form:levelTwoManageAutoPayment";
	public static final String PAYMENT_MANAGE_AUTO_PAYMENTS_TEXT = "//h1[contains(text(),'Manage Auto Top Up')]";

	// support - contact us
	public static final String CONTACT_US_SUPPORT = "levelTwoContactUs";
	public static final String ORDER_MERCHANDISE_SUPPORT = "levelTwoOrderMerchandise";
	public static final String USER_GUIDE_SUPPORT = "levelTwoUserHelpGuide";
	public static final String MESSAGE_ABOUT_SEL = "lform:contact_us_selectedQueryType";
	public static final String CONTACT_ACC_NUM_TB = "lform:contact_us_accountNumber";
	public static final String CONTACT_ACC_NAME_TB = "lform:contact_us_accountName";
	public static final String CONTACT_MESSAGE_TA = "lform:contact_us_comment";
	public static final String CONTACT_US_NAME = "lform:contact_us_contactName";
	public static final String CONTACT_US_EMAIL = "//input[@id='lform:contact_us_email']";
	public static final String CONTACT_US_PH = "lform:contact_us_phoneNumber";
	public static final String RESPOND_EMAIL_RB = "lform:contact_us_selectedPreferedContact:0";
	public static final String RESPOND_PHONE_RB = "lform:contact_us_selectedPreferedContact:1";
	public static final String RESPONSE_NOT_REQ = "lform:contact_us_selectedPreferedContact:2";
	public static final String BP_SUBSCRIBE = "lform:subscribe";
	public static final String UPLOAD_BUTTON = "lform:contact_us_uploadDocument";
	public static final String SEND_MESSAGE = "lform:contactUs_btnSend";
	public static final String UPLOAD_CONTAINER = "lform:modalPanelUpload_container";
	public static final String CLOSE_UPLOAD = "lform:modalPanelUploadformCommandLink";
	public static final String BROWSE_FILE_UP = "//input[@class='rf-fu-inp']";

	// Added By Nithya - 30-04-2018
	public static final String CONTACT_SAVE_BUTTON = "lform:contactsMaint_btnSave"; // id
	// Added by Nithya - 02-05-2018 - Contact Page
	public static final String CONTACTS_LIST = "//tbody[@id='lform:tableContactList:tb']//tr/td[1][contains(@id,'contactsList_col_1')]/div/p/a"; // xpath
	public static final String VIEW_AND_EDIT_CONTACT_DETAILS = "//a[contains(@id,'mnuView')]"; // xpath
	public static final String DELETE_CONTACT_BUTTON = "lform:contactsMaint_btnDelete"; // id
	public static final String EXPORT_CONTACT_LIST = "lform:tableContactList_xls_top"; // id
	public static final String CONTACT_TYPES = "//tbody[@id='lform:tableContactList:tb']//tr/td[2]"; // xpath
	public static final String CONTACT_TYPES_DROP_DOWN = "//select[contains(@id,'lform:contact_type_oid')]/option"; // xpath

	// Added by Nithya - 03-05-2018 - Find And Update Card Page
	public static final String ALL_LISTED_CARDS = "//tbody/tr/td[1][contains(@id,'cardNumber')]"; // xpath
	public static final String VIEW_CARD_TRANSACTION = "//div[@class='rich-table-menu'][@style='display: block;']//a[contains(@id,'mnuCardTransactionsList')]"; // xpath
	public static final String VIEW_CARD = "//div[@class='rich-table-menu'][@style='display: block;']//a[contains(@id,'mnuView')]"; // xpath
	public static final String VIEW_CARD_OPTIONS_DROPDOWN = "lformCardView:cardViewInclude_selectNavigation"; // id
	public static final String GO_IN_VIEW_CARD = "lformCardView:btn_orderCardConfirm"; // id
	public static final String CARDNO_TRANSACTION = "lform:transList_cardNo_driver_rego"; // id
	public static final String CARDNO_VIEW_CARD = "//div[@class='summaryElementStatic']/div[1]"; // xpath
	public static final String CARDNO_IN_VIEW_CARD = "//div/div[1]/strong"; //xpath Added 24/08/2018
	public static final String CARDNO_CHANGE_STATUS = "lform:card_no"; // id
	public static final String CARDNO_CHANGE_PIN = "//div[@id='contentFormWrapperCategoryItem_1Group']/div/div[2]"; // xpath
	public static final String CARDNO_EDIT_CARD = "//div[@id='lform:contentFormWrapperCategoryItem_1Group']/div[@class='formCol_B']/div[@class='formRow']"; // xpath
	public static final String RESENDPOPUPMSG = "lformCardView:resend_pin_popup_panel_message_text"; // id
	public static final String CANCEL_RESEND_REQUEST = "lformCardView:btn_confirm_cancel"; // id
	public static final String CARDSFOUND_ASCENDING = "lform:tableCardList:j_idt294";

	// Added by Nithya - 04-05-2018
	public static final String PAGE_TITLE_REISSUECARD = "//h1/span | //div[@id='content']/form/h1"; // xpath
	public static final String BULK_CARD_ACTIONS = "//input[contains(@id,'lform:bulkCardOperation:')]"; // xpath
	public static final String VIEW_CARD_SEARCH_RESULTS = "lform:uploadUpdateListCardsModal_btn_show"; // id
	public static final String VIEW_CARD_RESUTLS_POPUP = "lform:uploadUpdateListCardsModal_content_scroller"; // id
	//public static final String VIEW_CARD_RESUTLS_POPUP_CLOSE = "lform:j_idt506"; // id is not working for BP Prepaid
	public static final String VIEW_CARD_RESUTLS_POPUP_CLOSE = "//div[@id='lform:uploadUpdateListCardsModal_header_controls']"; //xpath
	public static final String BULK_CARD_ORDER_POPUP = "lform:uploadOrderCardsModal_content_scroller"; // id  
	//public static final String BULK_CARD_ORDER_POPUP_CANCEL = "lform:j_idt274"; //id is not working for BP Prepaid
	public static final String BULK_CARD_ORDER_POPUP_CANCEL = "//span[contains(@class,'buttonTextSpan')][text()='Close']"; // xpath 
	public static final String BULK_CARD_UPDATE_POPUP = "lform:uploadUpdateCardsModal_content_scroller"; // id
	//public static final String BULK_CARD_UPDATE_POPUP_CANCEL = "lform:j_idt551"; // id is not working for BP Prepaid
	public static final String BULK_CARD_UPDATE_POPUP_CANCEL = "//div[@id='lform:uploadUpdateCardsModal_header_controls']"; //xpath
	public static final String DOWNLOAD_CARDS_TO_EXCEL = "lform:hiddenLink"; // id

	// Added by Nithya - 07-05-2018
	//public static final String BULKCARD_STATUS_SELECT_ALL = "lform:j_idt668"; // id is not working for BP Prepaid 
	public static final String BULKCARD_STATUS_SELECT_ALL = "//a[text()='Select All']"; //xpath 
	//public static final String BULKCARD_STATUS_DESELECT_ALL = "lform:j_idt670"; // id is not working for BP Prepaid
	public static final String BULKCARD_STATUS_DESELECT_ALL = "//a[text()='Deselect All']"; //xpath
	public static final String BCS_LIST_CARDS_TABLE = "lform:change_status_tableCardList"; // id
	public static final String BCS_SEARCH = "lform:keyVODoTbtn_search"; // id
	public static final String BCS_SEARCH_RESULT = "//h4[normalize-space(contains(text(),'Cards found'))]"; // xpath
	public static final String BCS_SELECT_CARD_CHECKBOX = "//tbody[@id='lform:change_status_tableCardList:tb']/tr/td[1]/input"; // xpath
	public static final String BCS_NEW_STATUS_DROPDOWN = "lform:keyVODoTnew_card_status_oid"; // id
	public static final String BCS_SAVE_NEW_CARD_STATUS = "lform:bulkCardsChangeStatusPreview_btn_save"; // id
	public static final String BCS_PRINT_THIS_PAGE = "//*[text()='Print this page']"; // xpath
	public static final String BCS_RETURN_TO_BULK_CARD_SEARCH = "lform:bulkCardsChangeStatusStep3_Return_btn"; // id

	// Added by Nithya - 08-05-2018
	public static final String MERCORLOC_CONTACT_TITLE = "//div[@id='hdr_tableList']//h2"; // xpath
	public static final String CONTACT_TYPES_FOR_MERCORLOC = "//tbody[@id='lform:tableContactList:tb']//tr/td[1]"; // xpath
	public static final String CONTACT_LIST_IN_MERCORLOC = "//tbody[@id='lform:tableContactList:tb']//tr/td[3]/p/span"; // xpath

	// Added by Nithya - 14-05-2018
	public static final String RETURN_TO_CONTACT = "lform:contactsMaint_btn_return";
	// Added by Nithya - 15-05-2018
	public static final String REISSUE_CARD_POPUP = "lform:resend_pin_popup_content";
	// ***** BP Merchant Online *****//
	// Public (OR) Common locators
	public static final String PHYSICAL_ADDRESS = "lform:streetAddressVODoTaddress_line";
	public static final String PHYSICAL_SUBURB = "lform:streetAddressVODoTsuburb";
	public static final String POSTALCODE = "lform:streetAddressVODoTpostal_code";
	public static final String STATE_PHY = "lform:streetAddressVODoTstate_oid";
	public static final String MERCHANT_POSTAL_CONTACT_MAILING_ADDRESS = "lform:postalAddressVODoTaddress_line";
	public static final String MERCHANT_POSTAL_CONTACT_MAILING_SUBURB = "lform:postalAddressVODoTsuburb";
	public static final String MERCHANT_POSTAL_CONTACT_MAILING_POSTALCODE = "lform:postalAddressVODoTpostal_code";
	public static final String MERCHANT_POSTAL_CONTACT_MAILING_SATE = "lform:postalAddressVODoTstate_oid";
	public static final String CONTACT_NAME = "lform:contact_name";
	public static final String EMAIL_FIELD = "lform:email_address";
	public static final String JOBTITLE_FIELD = "lform:contact_title";
	public static final String PHONE_FIELD = "lform:phone_business";
	public static final String MOBILE_FIELD = "lform:phone_mobile_1";
	public static final String FAX_FIELD = "lform:phone_fax";
	public static final String REPORTS_CREATED_FROM = "lform:created_on_fromInputDate";
	public static final String REPORTS_CREATED_TO = "lform:created_on_toInputDate";
	public static final String REPORTS_FILENAME = "lform:file_name";
	public static final String REPORTS_SEARCH = "lform:btn_searchfullAccess";
	// Account - Merchant
	public static final String MERCHANT = "menu_form:levelTwoMerchantMaint";
	public static final String MERCHANT_PHYSICAL_COUNTRY = "lform:streetAddressVODoTcountry_oid";
	public static final String MERCHANT_POSTAL_COUNTRY = "lform:postalAddressVODoTcountry_oid";
	public static final String MERCHANT_CONTACT_INFORMATION_SAVE = "lform:btnSave_merchMaintenance";

	// Ayub Khan 07-05-1018
	public static final String MERCHANT_DETAILS = "lform:BandHdDetail";
	public static final String MERCHANT_ADDRESS = "lform:formSectionAddress_line";
	public static final String MERCHANT_CONTACT_INFO = "lform:formSectionContact_info";
	public static final String MERCHANT_CONTACT_LIST = "hdr_tableList";
	// Account - Contacts
	public static final String CONTACT = "menu_form:levelTwoContactsList";
	public static final String CONTACT_ADD_A_CONTACT = "lform:btn_addNewItem";
	public static final String CONTACT_ADD_A_CONTACT_BACK_CONTACTLIST = "lform:back_to_contacts_listfullAccess";
	// public static final String CONTACT_ADD_CONTACT_TEXT =
	// "//span[@class='highlighter'][contains(text(),'Add\A0Contact')]";
	public static final String CONTACT_CD_CONTACT_TYPE = "lform:contact_type_oid"; // CD-CONTACT DETAILS
	public static final String CONTACT_CD_CONTACT_DEFAULT = "lform:is_default";
	// Address
	public static final String CONTACT_SAVE = "lform:btn_add";
	public static final String CONTACT_EXPORT = "lform:tableContactList_xls";
	// Reports - Adhoc Reports
	public static final String ADHOC_REPORTS = "menu_form:levelTwoRepAdHocView";
	public static final String ADHOC_REPORTS_TITLE = "//*[@id='content']/h1/span";
	// public static final String ADHOC_REPORTS_TITLE = "//h1[contains(text(),'Ad
	// Hoc Report List ')]";
	public static final String ADHOC_REPORTS_EXPORT = "lform:avaliableReport_xls";
	// Reports - Stored Reports
	public static final String STORED_REPORTS = "menu_form:levelTwoRepRePrint";
	public static final String STORED_REPORTS_TITLE = "//h1[contains(text(),'Stored Reports')]";
	public static final String STORED_REPORTS_TYPE = "lform:report_type_oid";
	public static final String STORED_REPORTS_EXPORT = "//a[contains(@id,'lform:tableVehicleList_xls')]";//
	// Reports - Invoice Reports
	public static final String INVOICE_REPORTS = "repInvoicesMenu";
	public static final String INVOICE_REPORTS_EXPORT = "//a[contains(@id,'lform:tableVehicleList_xls')]";
	// Reports - Statements Reports
	public static final String STATEMENTS_REPORTS = "levelTwoRepStatments";
	public static final String STATEMENTS_REPORTS_TITLE = "//h1[contains(text(),'Statements Reports')]";
	public static final String STATEMENT_REPORTS_EXPORT = "lform:tableVehicleList_xlsfullAccess";

	public static final String REPORTS_TITLE_HEADER = "//span[@class='highlighter']";
	// Merchant-Transactions-Manual Batches

	public static final String MENU_MANUAL_BATCHES = "menu_form:levelTwoManualTransactionList";
	public static final String MANUAL_BATCHES_TITLE = "//span[@class='highlighter']";
	public static final String BATCH_REF_NUM = "lform:reference";
	public static final String CREATE_DATE_FROM = "lform:created_on_fromInputDate";
	public static final String CREATE_DATE_TO = "lform:created_on_toInputDate";
	public static final String BATCH_STATUS = "lform:batch_status_cid";
	public static final String SEARCH_ALL_PAGE = "lform:btn_searchfullAccess";
	public static final String SEARCH = "//input[@id='lform:btn_search']";
	public static final String ADD_MANUAL_BATCH = "lform:btn_addNewItem";
	public static final String EXPORT_BATCHES = "lform:tableTransList_xls";
	public static final String FULL_RESULT_GRID = "lform:manBatchTrans_result_grid";
	public static final String RESULT_TABLE = "lform:tableManBatchTransList";
	public static final String TABLE_EMPTY = "//div[@class='tableEmpty']";

	// Merchant-Transactions-Settlements
	public static final String SETTLEMENTS_MENU = "menu_form:levelTwoSettlements";
	public static final String PAGETITLE_SETTLEMENT = "//span[@class='highlighter']";
	public static final String ENQUIRY_START_DATE = "lform:enquiry_start_dateInputDate";
	public static final String SET_LOCATION_NUM = "lform:location_no";
	public static final String EXPORT_TO_EXCEL_SETT = "lform:tableSettLementsList_xls";
	public static final String FULL_RES_GRID_SETT = "lform:gridGroup";
	public static final String RES_TABLE_SETT = "lform:tableSettLementsList";

	// **** BP Location AU ****

	// Home page:

	// public static final String QUICK_LINKS="quicklinks";
	public static final String TRANSACTION_LINKS = "locationTransactionListQuickLink";
	public static final String LOC_TRANSACTION_LINKS = "locationTransactionListQuickLink";
	public static final String MERC_TRANSACTION_LINKS = "//div[@id='quicklinks']//child::a[text()='Export Transactions' or text()='export transactions']";
	public static final String EXPORT_TRANSACTION_LINKS = "//div[@id='quicklinks']//child::a[text()='Export Transactions' or text()='export transactions']";
	public static final String SESPENDED_TRANSACTION_LINKS = "lform:MrchSusTxCSV";
	// Account

	public static final String AU_LOCATION = "menu_form:levelTwoLocationMaint";
	public static final String AU_SAVE = "lform:btn_save";
	public static final String LOCATION_MAIN_TITLE = "//span[contains(text(),'Location Maintenance')]";

	// Transactions -> Find and Export Transactions

	public static final String TRANSACTION_TYPE = "lform:transaction_type_oidlform:btn_save";
	public static final String REFERNCE_NUMBER = "lform:transaction_reference";
	public static final String LEGALTITLENW = 	"//*[@id='footerWexForm:footer_linkLegal_notice']";							// "//h1[contains(text(),'Legal')]"
	public static final String USERGUIDETITLENW = "//h1[contains(text(),'BP Plus user help guide')]|//h1[contains(text(),'BP Plus User Help Guide')]";
	public static final String PRIVACYTITLENW = "//h1[contains(text(),'Privacy')]";
	public static final String USERGUIDENZTITLE = "//h1[contains(text(),'Using BP Fuelcard online')]";

	// Added by Meenakshi 09.05.18
	public static final String REPORT_TABLE_LIST = "//tbody[@id='lform:avaliableReport:tb']/tr/td[1]/p";
	public static final String ADHOC_REPORT_RUN_PAGE_HEADER = "//span[@class='highlighter'][contains(text(),'Ad Hoc Report Run')]";
	public static final String BACK_TO_ADHOC_REPORT_LINK = "lform:BbBackTransactionListfullAccess";
	public static final String SCHEDULED_REPORT_SUB_MENU = "menu_form:levelTwoRepSchRep";
	public static final String ADD_SCHEDULE_REPORT_BUTTON = "lform:btn_addNewItem";
	public static final String SCHEDULE_REPORT_MAINTENANCE_PAGE = "//*[@id='lform']/h1/span";
	public static final String SCHEDULE_REPORT_TYPE = "lform:report_type_oid1";
	public static final String SCHEDULE_REPORT_TYPE_DROPDOWN = "//select[@id='lform:report_type_oid1']";
	public static final String SCHEDULE_FREQUENCY_DROPDOWN = "//select[@id='lform:frequency_oid']";
	public static final String SCHEDULE_DELIVERY_TYPE = "//select[@id='lform:delivery_type_cid']";
	public static final String SCHEDULE_CONTACT_RANKING_TYPE = "//select[@id='lform:contact_hierarchy_cid']";
	public static final String SCHEDULE_SAVE_BUTTON = "lform:cmdSave";
	public static final String BACK_TO_SCHEDULE_REPORT_LINK = "lform:BbBackScheduledReportsListfullAccess";
	public static final String SCHEDULED_REPORT_RUN_PAGE_HEADER = "//span[@class='highlighter'][contains(text(),'Scheduled Report')]";
	public static final String SELECT_REPORT_TYPE_FROM_SCHEDULED_REPORT_PAGE = "//select[@id='lform:scheduleReportreport_type_oid']";
	public static final String SELECT_FREQUENCY_FROM_SCHEDULED_REPORT_PAGE = "//select[@id='lform:scheduleReportfrequency_oid']";
	public static final String EMAIL_FIELD_FROM_SCHEDULED_REPORT_PAGE = "lform:scheduleReportemail_address";
	public static final String CHECK_ENABLE_CHECKBOX = "lform:scheduleReportis_enabled";
	public static final String SEARCH_RESULT_DISPLAYED = "lform:scheduleRepoList:tb";
	public static final String SCHEDULE_REPORT_EXPORT_BUTTON = "lform:avaliableReport_xls";
	public static final String STORED_REPORT_TYPE_DROPDOWN = "//select[@id='lform:report_type_oid']";
	public static final String DATE_PICKER_CREATED_FROM_CALENDAR_BUTTON = "lform:created_on_fromPopupButton";
	public static final String DATE_PICKER_CREATED_TO_CALENDAR_BUTTON = "lform:created_on_toPopupButton";
	public static final String CALENDAR_HANDLE_DIALOG_BOX_FROM = "table[id='lform:created_on_fromContent']";
	public static final String CALENDAR_HANDLE_DIALOG_BOX_TO = "table[id='lform:created_on_toContent']";
	public static final String STORED_REPORT_HEADER = "//*[@id='hdr_tableList']/h2";
	public static final String TRANSACTION_PAGE_TITLE = "//form[@id='lform']/h1/span";
	public static final String TRANSACTION_LINE_ITEM_PAGE_TITLE = "lform:dataTableMerchantBreak:tb";
	public static final String TRANSACTION_LINE_ITEM_FIRSTROW = "lform:dataTableMerchantBreak:0";
	public static final String SEARCH_RESULTS = "tbody[class='rf-dt-b']";

	// Added by Anton 03.05.18 Account Details Page

	public static final String VIEW_EDIT_ACC_DETAILS = "//li[@id='customerView_levelTwoVehicles']/a";
	public static final String VIEW_EDIT_ACC_DET_TITLE = "//span[text()='View and Edit Vehicles']";
	public static final String VEHICLES_TABLE = "lform:tableVehicleList";
	public static final String RESULT_COUNT = "//*[@id='lform:hdr_tableListfullAccess']/div[2]/div[1]/h4";
	public static final String FIRST_UPDATEODAMETER = "lform:tableVehicleList:0:mnuUpdateOdomCommandLink";
	public static final String FIRST_GO_TO_CARD = "lform:tableVehicleList:0:mnuGoToCardCommandLink";
	public static final String UPDATE_ODA_METER_TB = "lform:current_odo_reading";
	public static final String UPDATE_CHANGES = "lform:btn_update";
	public static final String BACK_VEHICLEPAGE = "lform:back_to_vehicle_listfullAccess";
	public static final String DESCRIPTION_COMMON = "lform:description";

	// Added by Anton 07.05.2018 Location Maintenance Page.

	public static final String BPLOGO_LOC_MERCH = "headerForm:merchantCommandLnk";
	public static final String LOC_ACC_NAME = "lform:name";

	/**
	 * Added by Anton 08.05.2018 and 09.05.2018
	 * 
	 * 
	 * 
	 */

	// public static final String BATCHNO_TEXT="lform:batch_reference";
	public static final String CONTROL_COUNT = "lform:control_count";
	// public static final String ACTUAL_COUNT="lform:actual_count";
	// public static final String ACTUAL_AMOUNT="lform:actual_amount";
	public static final String CREATED_ON = "lform:created_onInputDate";
	public static final String CONTROL_AMOUNT = "lform:control_amount";

	public static final String ADD_TRANSC_M_BATCH = "lform:btn_addManualTrans";
	public static final String MANUAL_TRANSAC_TABLE = "lform:manTrans";
	public static final String MANUAL_TRANSC_POPUP = "//div[@id='lform:modalPanelAddManTrans']/div[contains(@class,'cntr')]";
	public static final String LOCATION_LABEL = "lform:manTransDoTlocation_midL";
	public static final String LOCATION_SELECT_BOX = "lform:manTransDoTlocation_mid";

	public static final String REFERENCE_TB = "lform:manTransDoTreference";
	public static final String REFERENCE_LABEL = "lform:manTransDoTreferenceL";

	public static final String TRANS_AMT_LABEL = "lform:manTransDoTeffective_atL";
	public static final String TRANS_AMT_TB = "lform:manTransDoToriginal_amount";

	public static final String EFF_DATE_TB = "lform:manTransDoTeffective_atInputDate";
	public static final String EFF_DATE_LABEL = "lform:manTransDoTeffective_atL";

	public static final String CARD_NUM_TB = "lform:manTransDoTcard_no";
	public static final String CARD_NUM_LABEL = "lform:manTransDoTcard_noL";

	public static final String UPLOAD_VOUCHER = "lform:btn_modalPanelUpload";
	public static final String ADD_PROD = "lform:btn_addProduct";

	public static final String PROD_SELECT_BOX = "//select[contains(@name,'lform:lineItemTable')]";
	public static final String PROD_VALUE = "//input[contains(@name,'lform:lineItemTable')]";

	public static final String CANCEL_BTN_MAN_TRANS_POPUP = "lform:btn_cancel";
	public static final String SAVE_BTN_MAN_TRANS_POPUP = "lform:btn_done";

	// Added by Anton 21.05.2018

	public static final String RECURRING_REPORT_TABLE = "lform:scheduleRepoList";
	public static final String FIRST_EDIT_RECURRING_REPORT_BUTTON = "lform:scheduleRepoList:0:editReportLink";
	public static final String FIRST_VIEW_ALL = "lform:scheduleRepoList:0:viewRecReportLink";
	public static final String RETURN_PAST_REPORT_BUTTON = "btn_returnToPastReports";
	public static final String EDIT_RECURRING_REPORTS_DTLS = "//a[@title='Edit Recurring Reports Details']";

	// Added by Nithya 24.05.2018
	public static final String DOWNLOAD_LATEST_COPY_OF_REPORT = "//div[@class='rich-table-menu menubox'][@style='display: block;']//a[contains(@id,'mnuDownload')]";
	public static final String EDIT_OPTION_OF_REPORT = "//div[@class='rich-table-menu menubox'][@style='display: block;']//a[contains(@id,'mnuEdit')]";
	public static final String RECURRING_REPORTS = "td[id^='lform:scheduleRepoList:'][id$='c1']";
	public static final String RADIO_BUTTON_FILTER_IN_RECURRING_REPORTS = "input[id^='lform:display_filter:display_filter']";

	// Added by Ayub
	public static final String REPORT_TYPE_LINK = "//td[@id='lform:genRepTable:0:c1']//div[@class='menu-popup']";
	public static final String DOWNLOAD_GENREPORT = "lform:genRepTable:0:mnuDownloadGenReport";
	public static final String EDIT_CARD = "//div[@class='rich-table-menu'][@style='display: block;']//a[contains(@id,'mnuEditCommandLink')]";
	public static final String GEN_REPORTS_TABLE = "lform:genRepTable";

	// Added by Nithya 25.05.2018
	public static final String SELECTED_POS_VALUES = "input[id*='cardControlProfileVOsDoTcardControlVODoTis'][checked='checked']";
	public static final String POS_VALUES = "input[id*='cardControlProfileVOsDoTcardControlVODoTis']";
	public static final String SELECT_FUEL_TRANSACTION_COST = "select[id*='cardControlProfileVOsDoTcardControlVODoTvelocityAssignmentVODoTvelocity_type_value_3_oid']";
	public static final String SUCCESS_MSG_AFTER_EDIT_CARD = "lform:orderSuccess";
	public static final String POS_PROMPT = "lform:cardControlProfileVO:1:cardControlProfileVOsDoTcardControlVODoTis_driver_id_req";
	public static final String VOLUME_LIMIT = "lform:purchaseControlsGroup:1:lform:purchaseControlsGroup:1:cardControlProfileVOsDoTcardControlVODoTvelocityAssignmentVODoTvelocity_type_value_2_oid";
	public static final String COST_LIMIT = "lform:purchaseControlsGroup:1:cardControlProfileVOsDoTcardControlVODoTvelocityAssignmentVODoTvelocity_type_value_1_oid";

	// Added by Nithya 29.05.2018
	public static final String LATER_ON_THIS_DATE = "input[id*='lform:new_card_status_at:j_idt']";
	public static final String LATER_ON_THIS_DATE_FIELD = "lform:cardVODoTnew_card_status_atInputDate";

	// Added by Anton 30.05.2018
	public static final String DELETE_REPORT_POPUP = "//div[contains(@id,'confirmationPopup')]";
	public static final String DELETE_BUTTON = "lform:confirmationPopupconfirmBtn1";
	//Added by Rathna
	public static final String BUTTON_UPDATE ="//input[@value='Update']";
	
	// Added By Ayub 30.05.2018
	public static final String PRINT_THIS_PAGE = "Print this page";

	// Added by Nithya 30.05.2018 - Updated 05/06/2018 FOR AU
	public static final String TRANSACTION_LIMITS_DROPDOWN = "select[id^='lform:contentFormWrapperCategoryItem_2Group']";

	public static final String ADDRESS_RADIO = "input[id*='lform:address_radio_opt_']";

	// Added by Ayub 31.05.2018
	public static final String CONFIGURE_ROAD_USER = "/html[1]/body[1]/div[1]/div[3]/div[1]/form[1]/div[1]/div[2]/div[1]/div[2]/div[2]/a[1]";
	public static final String CARD_INFORMATION = "lform:rucDetailsCardsInfoGroup";
	public static final String ROAD_USER_CHARGE = "lform:formSectionBandHdRoadUserCharges";
	public static final String RUC_CUSTOMER_NUMBER = "lform:rucCustomerNumber";
	public static final String RUC_CUSTOMER_NAME = "lform:rucCustomerName";
	public static final String PRIMARY_VEHICLE_REG = "lform:primaryVehicleReg";
	public static final String PRIMARY_VEHICLE_LICENCE_GROSS = "lform:primaryVehicleLicenceGross";
	public static final String PRIMARY_VEHICLE_DISTACNE = "lform:primaryVehicleDistanceMultiples";
	public static final String SECONDARY_VEHICLE_REG = "lform:secondaryVehicleReg";
	public static final String SECONDARY_VEHICLE_LICENCE_GROSS = "lform:secondaryVehicleLicenceGross";
	public static final String SECONDARY_VEHICLE_DISTACNE = "lform:secondaryVehicleDistanceMultiples";
	public static final String TERTIARY_VEHICLE_REG = "lform:tertiaryVehicleReg";
	public static final String TERTIARY_VEHICLE_LICENCE_GROSS = "lform:tertiaryVehicleLicenceGross";
	public static final String TERTIARY_VEHICLE_DISTACNE = "lform:tertiaryVehicleDistanceMultiples";
	public static final String RETURN_TO_PREVIOUS_PAGE = "lform:bnt_backEditCardfullAccess";

	// Added by Nithya 06.06.2018 - EMAP
	public static final String EMAP_LOGO_IMG = "headerForm:customerCommandLnk"; // Id
	public static final String TERMS_AND_CONDITION = "//a[contains(text(),'Terms & Conditions')]";// css
	public static final String PRIVACY_STATEMENT_2 = "//*[@id='footerWexForm:footer_linkPrivacyPolicy2']|//*[@id='footerWexForm:footer_linkPrivacyPolicy3']"; // id
	public static final String COPY_RIGHT_LINK = "footerWexForm:footer_linkCopyright1"; // id
	public static final String COPY_RIGHT_TEXT = "copyrightStaticPage"; // id
	public static final String BACKTO_PREVIOUS_PAGE = "//div[@id='previousPage']//a"; // id
	public static final String APPLICATION_DOWNLOAD_DROPDOWN = "lform:selectForm"; // id
	public static final String LOGOUT_EMAP = "logout"; // linktext
	// Added by Nithya 07.06.2018 - EMAP
	public static final String CARD_LIST_TABLE = "lform:tableCardList"; // id
	public static final String LICENSE_PLATE_FILTER_FIELD = "lform:license_plate"; // id
	public static final String DRIVER_NAME_FILTER_FIELD = "lform:driver_name"; // id
	public static final String CARD_OFFER_FILTER_FIELD = "lform:card_offer_oid"; // id
	public static final String VEHICLE_DESC_FILTER_FIELD = "lform:vehicleDesc"; // id
	public static final String CARDS_IN_CARDLIST = "//td[contains(@id,'cardNumber_col_1')]/span"; // xpath
	public static final String VIEW_CARD_MENU_OPTION = "//div[contains(@id,'lform:tableCardList:')][contains(@id,'_list')][not(contains(@style,'display:none;'))]//div[contains(@id,'mnuViewfullAccess')]"; // xpath
	// public static final String SUB_CATEGORIES_ON_VIEW_CARD =
	// "div[id^='subCategoryItem_'] h2";
	public static final String SUB_CATEGORIES_ON_VIEW_CARD = "div.subCategoryItem h2";

	// View Card Page - View Only
	public static final String CARD_NUMBER_FIELD = "lform:cardVODoTcard_no";
	public static final String CARD_STATUS_FIELD = "lform:cardVODoTcard_status_oid";
	public static final String CARD_COST_CENTER = "lform:costCentreCode";
	public static final String CARD_EXPIRES_ON = "lform:cardVODoTexpires_on";
	// public static final String ODOMETER_OPTION =
	// "//div[@id='lform:posPromptGroup']//input[not(contains(@style,'display:none'))]";
	public static final String ODOMETER_OPTION = "lform:cardControlProfileVOsDoTcardControlVODoTis_odometer_req_nofullaccess";
	public static final String CARD_PURCHASE_CONTROL_RESTRICTION = "lform:purchaseControlsGroup:0:cardControlProfileVOsDoTcardControlVODoTproduct_restriction_oid";
	public static final String CARD_TIME_LIMIT = "//*[contains(@id,'cardControlProfileVOsDoTcardControlVODoTtime_limit_oid')][2]";

	public static final String DAILY_LIMIT_AMOUNT_FUEL = "//*[contains(@id,'cardControlProfileVOsDoTcardControlVODoTvelocityAssignmentVODoTvelocity_type_value')][2]";
	public static final String DAILY_LIMIT_AMOUNT_NON_FUEL = "//*[contains(@id,'cardControlProfileVOsDoTcardControlVODoTvelocityAssignmentVODoTvelocity_type_value')][2]";
	public static final String MONTHLY_LIMIT_AMOUNT_NON_FUEL = "//*[contains(@id,'cardControlProfileVOsDoTcardControlVODoTvelocityAssignmentVODoTvelocity_type_value')][2]";
	public static final String DAILY_LIMIT_NO_OF_TRX = "//*[contains(@id,'cardControlProfileVOsDoTcardControlVODoTvelocityAssignmentVODoTvelocity_type_value_')][2]";
	public static final String MONTHLY_LIMIT_AMOUNT_TOTAL = "//*[contains(@id,'cardControlProfileVOsDoTcardControlVODoTvelocityAssignmentVODoTvelocity_type_value_')][2]";
	public static final String TRX_LIMIT_AMOUNT_FUEL = "//*[contains(@id,'cardControlProfileVOsDoTcardControlVODoTvelocityAssignmentVODoTvelocity_type_value')][2]";
	public static final String TRX_LIMIT_AMOUNT_NON_FUEL = "//*[contains(@id,'cardControlProfileVOsDoTcardControlVODoTvelocityAssignmentVODoTvelocity_type_value_')][2]";
	public static final String MONTHLY_LIMIT_AMOUNT_FUEL = "//*[contains(@id,'cardControlProfileVOsDoTcardControlVODoTvelocityAssignmentVODoTvelocity_type_value_')][2]";

	// Added by Nithya 08.06.2018
	public static final String QUICK_LINK_CARD_LIST = "cardListQuickLink";
	public static final String QUICK_LINK_TRANSACTION_LIST = "customerTransactionListQuickLink";
	public static final String QUICK_LINK_EXPORT_TRANSACTIONS = "lform:exportTransactionQuickLinkHomePage";
	public static final String ACCOUNT_INFO_SECTION = "accountInfoWrapper";
	public static final String ADDRESS_INFO = "lform:address_lineGroupformSection";
	public static final String FINANCE_INFORMATION = "lform:financeInformationGroup";
	//public static final String CONTACT_INFORMATION = "lform:contact_infoGroupformSection";
	public static final String CONTACT_INFORMATION = "//*[@id='lform:contact_infoGroupformSection']|//*[@id='lform:formSectioncontact_info']";
	public static final String CONTACT_LIST_TABLE = "lform:tableContactList";
	public static final String TRANSACTION_TABLE = "lform:tableTransList";

	// Added by Nithya 11.06.2018
	public static final String CARD_NO_IN_TRANSACTION_FILTER = "lform:card_number";
	public static final String COST_CENTER_IN_TRANSACTION_FILTER = "lform:cost_centre";
	public static final String LISTED_TRANSACTIONS = "//tbody/tr/td[1]//span[contains(@id,'cardNumber')]";
	public static final String LISTED_TRANSACTIONS_WITH_CARD = "//tbody/tr/td[1]//span[contains(@id,'cardNumber')][string-length(text())>1]";
	public static final String DETAILS_MENU_OPTION = "//div[contains(@id,'lform:tableTransList:')][contains(@id,'_list')][not(contains(@style,'display:none;'))]//div[contains(@id,'tool_viewfullAccess')]";

	// Transaction Detail
	public static final String AUTHORISATION_NO = "lform:authorisation_noL";
	public static final String CAPTURE_TYPE_IN_TRANS = "lform:trans_captureType";
	public static final String COST_CENTER_IN_TRANS = "lform:trans_costCenL";
	public static final String DRIVER_ID_IN_TRANS = "lform:trans_driver_idL";
	public static final String GST_TOTAL_IN_TRANS = "//span[@id='lform:customer_tax_amount']|//span[@id='lform:trans_gst_total']";
	public static final String LOCATION_IN_TRANS = "lform:trans_loc";
	public static final String ODOMETER_IN_TRANS = "lform:trans_odometer";
	public static final String ORDER_NO_IN_TRANS = "lform:order_noL";
	public static final String PROCESSED_DATE_IN_TRANS = "lform:trans_processTime";
	public static final String REF_NUMBER_IN_TRANS = "lform:trans_ref_no";
	public static final String TERMINAL_ID_IN_TRANS = "lform:trans_terminalId";
	public static final String TOTAL_FEES_IN_TRANS = "lform:trans_total_fees";
	public static final String TOTAL_IN_TRANS = "lform:trans_total";
	public static final String DATE_TIME_IN_TRANS = "lform:trans_time";
	public static final String TRANSACTION_STATUS = "//span[@id='lform:status']|//span[@id='lform:trans_veh']";
	public static final String TRANSACTION_TYPE_DETAIL = "lform:trans_type";
	public static final String VEHICLE_CHECK_IN_TRANS = "lform:fleet_idL";
	public static final String VEHICLE_ID = "lform:trans_vehL";
	public static final String STORED_REPORTS_EXPORT_OPTION = "lform:tableVehicleList_xls";
	public static final String REPORTS_TABLE = "lform:tableStoredRepList";

	public static final String CHANGE_PASSWORD = "levelTwoAdminSecurity";
	public static final String CONTACT_US_SUBMENU = "menu_form:levelTwoContactUs";

	public static final String PASSWORD_FIELD = "lform:password";
	public static final String NEW_PASSWORD = "lform:new_password";
	public static final String CONFIRM_PASSWORD = "lform:confirm_password";
	public static final String EXXON_MOBIL_LOGO = "footerWexForm:footer_linkExxonLogo1";
	public static final String ESSO_LOGO = "footerWexForm:footer_linkEssoLogo1";
	public static final String MOBIL_LOGO = "footerWexForm:footer_linkMobilLogo";
	public static final String DOWNLOAD_FORM = "btn_downloadForm";
	public static final String AGREE_AND_CONTINUE = "lform:btn_tnc_agree";
	public static final String ADHOC_REPORT_TABLE = "lform:avaliableReport";

	public static final String CONTACT_US_IN_FOOTER = "footerWexForm:footer_linkContactUs1";

	public static final String ORDER_NEW_CARD_QUICK_LINK = "cardNewQuicklink";
	public static final String CHANGE_CARD_STATUS_QUICK_LINK = "changeCardStatusQuickLink";
	public static final String ADHOC_REPORTS_SUBMENU = "levelTwoRepAdHocView";

	// Added by Nithya 12.06.2018
	public static final String BACK_TO_CARD_LIST = "//*[@id='lform:BbBackCardListfullAccess']|//*[@id='lform:bnt_backfullAccess']";
	public static final String EDIT_CARD_MENU_OPTION = "//div[contains(@id,'lform:tableCardList:')][contains(@id,'_list')][not(contains(@style,'display:none;'))]//div[contains(@id,'mnuEditCommandLinkfullAccess')]"; // xpath
	public static final String VELOCITY_CONTROL_LIST_PDF = "//div[@id='lform:velocity_control_links']//li[1]/a";
	public static final String VELOCITY_CONTROL_LIST_XLS = "//div[@id='lform:velocity_control_links']//li[2]/a";
	public static final String CHANGE_CARD_STATUS_MENU_OPTION = "//div[contains(@id,'lform:tableCardList:')][contains(@id,'_list')][not(contains(@style,'display:none;'))]//div[contains(@id,'mnuCancelChangeStatusCommandLinkfullAccess')]"; // xpath
	public static final String BULK_CARD_ORDER_SUBMENU = "menu_form:levelTwoBulkCardOrder";
	public static final String DOWNLOAD_BULK_CARD_ORDER_TEMPLATE = "lform:btn_download";
	public static final String UPLOAD_BULK_CARD_ORDER_TEMPLATE = "//input[@class='btnRight btnSubmit'][@value='Upload']";
	public static final String UPLOAD_BULK_CARD_UPDATE_TEMPLATE = "//input[@class='btnLeft btnSubmit'][@value='Upload']";

	public static final String CONTACT_TABLE_PHONE_LABEL = "//form[@id='lform']/table/tbody/tr[1]/td[1]";
	public static final String CONTACT_TABLE_PHONE = "//form[@id='lform']/table/tbody/tr[1]/td[2]";

	public static final String CONTACT_TABLE_FAX_LABEL = "//form[@id='lform']/table/tbody/tr[2]/td[1]";
	public static final String CONTACT_TABLE_FAX = "//form[@id='lform']/table/tbody/tr[2]/td[2]";
	public static final String CONTACT_US_QUERY_SUBMIT = "lform:btn_contactUs";

	// Added by Nithya 13.06.2018
	public static final String USERID_SUBMIT_FOR_FORGOT_PASSWORD = "lform:cmdEmailfullAccess";
	public static final String REQUEST_LOGON_TYPE_CUSTOMER = "lform:request_a_logon_contactVODoTmember_type_cid:0";
	public static final String REQUEST_LOGON_ADDRESS = "lform:request_a_logon_contactVODoTstreetAddressVODoTaddress_line";
	public static final String REQUEST_LOGON_SUBURB = "lform:request_a_logon_contactVODoTstreetAddressVODoTsuburb";
	public static final String REQUEST_LOGON_POSTAL_CODE = "lform:request_a_logon_contactVODoTstreetAddressVODoTpostal_code";
	public static final String REQUEST_LOGON_FIRST_NAME = "lform:request_a_logon_first_name";
	public static final String REQUEST_LOGON_LAST_NAME = "lform:request_a_logon_last_name";
	public static final String REQUEST_LOGON_EMAIL = "lform:request_a_logon_contactVODoTemail_address";
	public static final String REQUEST_LOGON_PHONE = "lform:request_a_logon_contactVODoTphone_business";
	public static final String REQUEST_LOGON_SUBMIT = "lform:btn_requestLogon";
	public static final String REQUEST_LOGON_ACCOUNT_NUMBER = "lform:request_a_logon_account_no";
	public static final String CONTACT_US_SM = "//*[@class='levelTwo']//li/a[text()='contact us']";

	// Added by Nithya 14.06.2018
	public static final String EXPORT_TRANSACTION = "menu_form:exportTransactionQuickLink";
	// Added by Nithya 15.06.2018
	public static final String FOOTER_LINK_EXXON_CORPORATION = "footerWexForm:footer_linkCorporation"; // id
	public static final String COPY_RIGHT_LINK_HOME_PAGE = "footerWexForm:footer_linkCopyright"; // id
	public static final String PRIVACY_POLICY_IN_HOME_PAGE_FOOTER = "//a[@id='footerWexForm:footer_linkPrivacyPolicy0'] | //a[@id='footerWexForm:footer_linkPrivacyPolicy1']"; // id
	public static final String EXXON_MOBIL_LOGO_IN_HOME_PAGE = "footerWexForm:footer_linkExxonLogo"; // id
	public static final String ESSO_LOGO_IN_HOME_PAGE = "footerWexForm:footer_linkEssoLogo"; // id
	public static final String MOBIL_LOGO_IN_HOME_PAGE = "footerWexForm:footer_linkEssoLogo3"; // id
	public static final String SCHEDULED_REPORT = "levelTwoRepSchRep";

	// Added by Nithya 16.06.2018
	public static final String TRADING_NAME = "//span[@id='lform:trading_name']";
	public static final String ACCOUNT_DETAILS = "table_selectAccountDetails";
	public static final String CHANGE_PWD_IN_HELLO_UN_LINK = "accountProfileChangePasswordLnk";
	public static final String DISAGREE_TO_TERMS_AND_CONDITION = "btn_tnc_disagree";
	public static final String MERCHANT_CLIENT_LOGO_IMG = "//*[@id='headerForm:merchantCommandLnk']";

	// Added by Nithya 20.06.2018
	public static final String ACCOUNT_NAME_IN_HOME_PAGE = "//div[@id='selectAccountDetails']/h2";

	// Added by Nithya 21.06.2018
	public static final String REPORTS_LIST = "//tr[contains(@id,'lform:tableStoredRepList:')]";
	public static final String REPORT_PARAM_ACCT_NO = "//select[@id='lform:account_no'] | //select[@id='lform:customer_no']";
	public static final String REPORT_PARAM_CARD_STATUS = "lform:card_status";
	public static final String REPORT_PARAM_DATE_ISSUED = "lform:date_issuedInputDate";
	public static final String REPORT_PARAM_DATE = "lform:DateInputDate";
	public static final String REPORT_PARAM_DATE_INPUT = "//input[@id='lform:date_issuedInputDate']|//input[@id='lform:DateInputDate']";
	public static final String REPORT_PARAM_EMAIL_ADDRESS = "lform:delivery_email_address";
	public static final String ADHOC_REPORT_TYPE = "lform:text_report_type_oid";
	public static final String REPORT_PARAM_SORT_ORDER = "lform:Sort_order";

	// Added by Nithya 22.06.2018
	public static final String REPORT_GENERATE = "lform:cmdGeneratefullAccess";
	public static final String SCHEDULED_REPORT_PREVIOUS_REPORTED_DATE = "lform:previous_reported_onInputDate";
	public static final String SCHEDULED_REPORT_LAST_REPORTED_DATE = "lform:last_reported_onInputDate";
	public static final String SCHEDULED_REPORT_NAME = "lform:description";

	// Added by Nithya 25.06.2018
	public static final String PRODUCT_RESTRICTION = "lform:cardControlProfileVOsDoTcardControlVODoTproduct_restriction_oid";
	public static final String BULK_CARD_UPDATE_SM = "menu_form:levelTwoBulkCardUpdate";
	public static final String LICENSE_PLATE_IN_CARDLIST = "//td[contains(@id,'license_plateL')]//span"; // xpath

	// Added by Nithya 28.06.2018
	public static final String REPLACE_CARD_POPUP = "lform:requestOrReplacePopup_container";
	public static final String CHANGE_PIN_MENU_OPTION = "//div[contains(@id,'lform:tableCardList:')][contains(@id,'_list')][not(contains(@style,'display:none;'))]//div[contains(@id,'mnuChangePINCommandLinkfullAccess')]"; // xpath
	public static final String CHANGE_PIN_WITH_CARDS = "//div[contains(@id,'lform:tableCardList:')][contains(@id,'_list')][not(contains(@style,'display:none;'))]//div[contains(@id,'mnuChangePINCommandLinkfullAccess')]"; // xpath

	// Added by Anton 07.06.2018 - SHELL
	public static final String SHELL_LOGO_IMG = "//*[@id='headerForm:customerCommandLnk'] |//*[@id='headerForm:merchantCommandLnk']"; // Xpath
	public static final String LEGAL_NOTICE_SHELL = "footerWexForm:footer_linkLegal_notice1";
	public static final String PRIVACY_STATEMENT_SHELL = "footerWexForm:footer_linkPrivacy_statement1";
	public static final String LANGUAGE_DROPDOWN_SHELL = "//select";
	public static final String ACCTSPROFILELINK = "//span[contains(text(),'Accounts Profile')]";

	// Added by Meenakshi 08.06.2018 - SHELL
	public static final String USER_LIST = "menu_form:levelTwoUserList";
	public static final String PAGETITLE = "//span[@class='highlighter']";
	public static final String PAGE_HEADER = "//form[@id='lform']/h1/span";
	public static final String SEARCH_BUTTON = "lform:userList_saveBtn";
	public static final String USER_ID ="//*[@id='lform:logon_id']";//*[@id='userdrop']/a[@class='name']";
	public static final String SHELL_CHANGE_PASSWORD = "//input[@id='lform:password']";
	public static final String CHANGE_NEW_PASSWORD = "//input[@id='lform:new_password']";
	public static final String CHANGE_CONFIRM_PASSWORD = "//input[@id='lform:confirm_password']";
	public static final String CHANGE_PASSWORD_ERROR_MESSAGE = "//div[contains(@id,'errorMsg')]";
	public static final String CHANGE_PASSWORD_SUCCESS_MESSAGE = "//div[@id='successMsg']";
	public static final String USER_ID_INPUT = "//input[@id='lform:logon_id']";
	public static final String USERS_LIST_TABLE = "lform:tableList"; /* "//table[@id='lform:tableList']" */;
	public static final String LIST_OF_DISPLAY_NAME = "//tbody[@id='lform:tableList:tb']//tr//td[1]";
	public static final String EDIT_PROFILE = "lform:tableList:1:mnuEditProfilefullAccess";
	public static final String DISPLAY_LANGUAGE = "//select[contains(@id,'languageForm:j_idt')]";
	public static final String CHANGE_ROLE = "//div[contains(@id,'lform:tableList:')][contains(@id,'_list')][not(contains(@style,'display:none;'))]//div[contains(@id,'mnuChangeRolefullAccess')]";
	public static final String CHANGE_ROLE_SAVE_BUTTON = "lform:userChangeRole_saveBtn";
	public static final String CARDS_OFFER_DROPDOWN = "lform:keyVODoTcard_offer_mid";
	public static final String PURCHASE_ON_DATE_FIELD = "lform:keyVODoTpurchaseSinceInputDate";
	public static final String BULK_CARD_TABLE = "lform:databulkStatus";
	public static final String CARD_NUMBER_LIST = "//td[contains(@id,'j_idt260')]/p";
	public static final String CARD_LIST_CHECK_BOX = "//td[contains(@id,'j_idt256')]/p/input";
	public static final String SHELL_ACCOUNT_DROPDOWN = "lform:selectMember";
	public static final String ACCOUNT_NAME_DISPLAYED = "//span[contains(@style,'font-weight: bold')]";
	public static final String ACCOUNT_STATUS_DROPDOWN = "//select[@id='lform:accountVODoTaccount_status_oid']";
	public static final String ACCOUNT_DROPDOWN = "lform:member_no";
	public static final String FIRST_USER_FROM_LIST = "lform:tableList:1:col_1";
	public static final String EXPORT_BUTTON = "lform:tableList_xls";
	public static final String BULK_CARD_EXPORT_BUTTON = "lform:databulkStatus_xls";
	public static final String CUSTOMER_NUMBER_LIST = "//tbody[@id='lform:tableCardList:tb']//td[1]";
	public static final String EDIT_CARD_BUTTON = "//div[contains(@id,'mnuEditCommandLinkfullAccess')]";
//	lform:tableCardList:16:mnuEditCommandLinkfullAccess
	public static final String UPDATE_BUTTON = "lform:btn_validateCardChanges";
	public static final String CARD_STATUS_BUTTON = "div[contains(@id,'mnuCancelChangeStatusCommandLinkfullAccess')]";
	public static final String REPLACE_POPUP_CONTENT = "lform:requestOrReplacePopup_content";
	
	// Added by Anton 08.06.2018 - SHELL
	public static final String HELP_SHELL = "accountProfile_online_user_guideLnk2";
	public static final String SHELL_SUPPORT="//li[@class='menuParentItem']/a[@id='levelOneSupport']";
	public static final String ROLE ="//select[@id='lform:access_group_oid']";//"lform:access_group_oid";
	public static final String SAVE_BUTTON="lform:userNew_saveBtn";

	// Added by Ayub 08.06.2018 - SHELL
	public static final String PROFILE = "menu_form:levelTwoUserEditProfile";
	public static final String SAVE_BT = "lform:userEditProfile_saveBtn";
	public static final String LANGUAGE_FORM ="languageForm:j_idt44";//"lform:language_oid";
	
	//Added by Anton 15.06.18
	public static final String TRANSFER_TYPE = "lform:transfer_type_cid";
	public static final String FROM_ACCOUNT = "lform:from_account_no";
	public static final String TO_ACCOUNT= "lform:to_account_no";
	public static final String AMOUNT="lform:amount";
	public static final String SUBMIT_BTN ="lform:btn_submitfullAccess";
	public static final String ACCOUNT_SUMMARY ="lform:from_account_summary";
	
	//added by Anton 19.06.2018
	public static final String EMAIL_RADIO = "//input[@id='lform:contact_us_selectedPreferedContact_cid:0']";
	public static final String PHONE_RADIO="//input[@id='lform:contact_us_selectedPreferedContact_cid:1']";
	public static final String NONE_RADIO="//input[@id='lform:contact_us_selectedPreferedContact_cid:2']";
		
	
	// Added by Ayub 19.06.2o18 -SHELL
	public static final String SEARCH_LINK = "lform:lnk_search";
	public static final String EXPORT_DIRVER_LIST = "lform:tableDriverList_xls";
	public static final String ALL_DRIVER_ACCOUNT = "lform:driver_accounts";
	public static final String DRIVER_TABLE ="lform:tableDriverList";
	public static final String EXPORT_VEHICLE_LIST = "lform:tableVehicleList_xls";
	public static final String CLOSE_ACCOUNT = "levelTwoCloseAccount";
	public static final String COMMENT_BOX = "lform:close_acc_comment";
	public static final String CLOSE_ACCOUNT_SUBMIT_BT = "lform:btn_closeAcc";
	
	
	// Added by Ayub 20.06.2018 - SHELL
	public static final String FROM_CARD = "lform:from_card_noInput";
	public static final String TO_CARD = "lform:to_card_noInput";
	public static final String TO_CARD_NOITEMS = "//div[@id='lform:to_card_noItems']/div";
	public static final String CLOSE_UPLOAD_POPUP = "lform:modalPanelUploadformCommandLink";//lform:hidelink";
	public static final String CLOSE_IMAGE = "lform:hidelink1";
	
	//Added by Anton 
	public static final String VIEW_CARD_CL = "//span[contains(text(),'View Card')]";
	public static final String CUSTOMER_REFERENCE="lform:cardControlProfileVOsDoTcardControlVODoTis_fleet_id_reqL";
	
	// Added by Ayub 21.06.2018 - SHELL
	public static final String VIEW_CARD_MENU = "//div[contains(@id,'lform:tableCardList:')][contains(@id,'_list')][not(contains(@style,'display:none;'))]//div[contains(@id,':mnuViewfullAccess')]";
	public static final String CHANGE_STATUS = "//div[contains(@style,'display: block;')]//div[contains(@id,'lform:tableCardList:')][contains(@id,'mnuCancelChangeStatusCommandLinkfullAccess')]";
	public static final String NEW_CARD_STATUS ="lform:cardVODoTnew_card_status_oidFullAccess"; 
	public static final String LATER_ON_END_DATE_FIELD = "lform:cardVODoTnew_card_status_toInputDate";
	public static final String SHELL_EDIT_CARD = "//div[contains(@style,'display: block;')]//div[contains(@id,'lform:tableCardList:')][contains(@id,'mnuEditCommandLinkfullAccess')]";
	public static final String EDIT_NEW_CARD_STATUS ="lform:cardVODoTnew_card_status_oid"; 
	
	
	public static final String PREFERRED_LANGUAGE_DD= "lform:custMaintenance_preffered_language";
	public static final String ALERT_THRESHOLD_AMOUNT="lform:accountVODoTcard_balance_alert_threshold";
	public static final String CUR_AVL_BALANCE="lform:account_balance";

	// Added By Ayub 22.06.2018 - SHELL
	
	//public static final String CARD_OFFER= "lform:cardProductVODoTcard_offer_oid";
	public static final String CARD_NUMBER= "lform:cardNo";
	public static final String CARD_PRODUCT= "lform:cardVODoTcard_product_oid";
	public static final String CHANGE_STATUS_START_DATE  ="lform:cardVODoTnew_card_status_atPopupButton";
	public static final String CHANGE_STATUS_START_DATE_TABLE  ="lform:cardVODoTnew_card_status_atContent";
	
	
	// Added By Ayub 25.06.2018 - SHELL
	
	public static final String REPLACE_CARD = "//div[contains(@style,'display: block;')]//div[contains(@id,'lform:tableCardList:')][contains(@id,'mnuReplaceCardCommandLinkfullAccess')]";
	public static final String REPORTS_AND_INVOICE ="levelOneReports";
	public static final String ADHOC_AVALIABLE_REPORT="//td[contains(@id,'lform:avaliableReport')]/p[contains(text(),'Card Group List')]";
	public static final String SEARCH_BULK_CARD = "lform:cmdfindfullAccess";
	public static final String SELECT_ALL_CB="lform:keyVODoTselectAllFlag";
	public static final String BULK_CARD_UPDATE_TABLE="lform:bulkOrderCardtable";
	public static final String CARD_HISTORY_TBL = "lform:tableCardStatusHistoryList";
	
	// Added By Meenakshi 28.06.2018 - SHELL 
	public static final String ACCOUNT_STATUS_HOME_PAGE = "//table[@id='table_selectAccountDetails']//tr[1]/td[2]/span";
	public static final String EXPORT_ACCOUNT_HIERARCHY = "lform:btn_generate_auth_level_rpt_PDF";
	public static final String BULK_REISSUE_TABLE = "lform:dataBulkReissue";
	public static final String REISSUE_EXPORT_BUTTON = "lform:dataBulkReissue_xls";
	public static final String TRANSACTION_TABLE_ACC_NUMBER_LIST = "//tbody//td[@id='lform:tableTransList:0:c2']";
	public static final String DISPLAYED_LOGON_ID = "//span[@id='lform:logon_id']";
	public static final String REQUEST_STATUS = "lform:bulk_reissue_status_cid"; // Added by Suganthi 25/09/2018
	// Added By Meenakshi 02.07.2018 - SHELL
	public static final String REISSUE_REQUEST = "lform:dataBulkReissue:0:detail";
	public static final String REISSUE_REQUEST_EXPORT_BUTTON = "lform:btn_export_to_xls";
	public static final String REISSUE_EXPIRES_ON_FROM_DATE = "lform:from_expires_on";
	public static final String REISSUE_NEW_EXPIRES_ON = "lform:new_expires_on";
	public static final String REISSUE_ON_DATE = "lform:reissue_on";
	public static final String REISSUE_EXPIRES_ON_TO_DATE = "lform:to_expires_on";
	public static final String REISSUE_CONFIRM_ON_DATE = "lform:confirm_on";
	
	
	// Added By Ayub 28.06.2018 - SHELL
	public static final String SHELL_INVOICES = "levelTwoRepInvoices";
	public static final String CLICK_HERE_INVOICE_LINK = "atos_link";
	
	//Added by Anton29.06.2018
	public static final String YES_REPLACEMENT_BTN="lform:saveStatusAndReissueCardBnt";
	
	// Added By Ayub 29.06.2018 - SHELL 
	public static final String BROWSE_FOR_FILE = "browserVisible";
	public static final String CLEAR_ALL = "//span[@class='rf-fu-btn-clr']";
	public static final String SHELL_UPLOAD_FILE = "//span[@class='rf-fu-btn-upl']";
	
	//Added by Anton 02.07.18
	public static final String EXCLUDE_CHECKBOX ="//input[@type='checkbox']";
	public static final String SAVE_REISSUE_BTN="lform:btn_cmdSave";
	public static final String REISSUE_PIN="lform:tableCardList:8:mnuReissuePINCommandLinkfullAccess";
	public static final String SELECTALL_CB="lform:tableList:selectAllFlag";
	
	// Added by Ayub 05.07.2018 - SHELL 
	public static final String ACCOUNT_NUMBER_DROPDOWN = "lform:vehicle_accounts";
	public static final String VEHICLE_TABLE = "lform:tableVehicleList";
	// Added by Ayub 10.07.2018 - SHELL 
	public static final String SHELL_REPLACE_CARD = "//div[contains(@id,'lform:tableCardList:')][contains(@id,'_list')][not(contains(@style,'display:none;'))]//div[contains(@id,'mnuReplaceCardCommandLinkfullAccess')]";
	// Added by Ayub 12.07.2018 - SHELL 
	public static final String BROWSE_FILE = "browserVisible";	
	// Added by Nithya 12.07.2018
	public static final String BULK_CARD_UPDATE_UPLOAD = "//div[@style='display:block;']/input[@value='Upload']";
	public static final String BROWSE_UPLOAD_FILE = "lform:uploadBulkUpdateCard";

	public static final String UPLOAD_FILE = "//span[@style='display: inline-block;']//span[@class='rf-fu-btn-cnt-upl']";
	public static final String BULK_UPDATE_FILE_UPLOADED_POPUP = "lform:modalPanelMessage_content_scroller";
//	public static final String BULK_UPDATE_POPUP_CLOSE = "//input[@class='btnSubmit']";
	public static final String BULK_UPDATE_POPUP_CLOSE="lform:modalPanelUploadUformCommandLink";
	//public static final String REISSUE_PIN_SMENU = "//div[contains(@id,'lform:tableCardList:')][contains(@id,'_list')][not(contains(@style,'display:none;'))]//div[contains(@id,'mnuReissuePINCommandLinkfullAccess')]";
	
	public static final String REISSUE_PIN_SMENU = "//div[contains(@id,'lform:tableCardList:')][contains(@id,'_list')][not(contains(@style,'display:none;'))]//div[contains(@id,'mnuReissuePINCommandLinkfullAccess')]";
	public static final String REISSUE_PIN_SMENU_OPTIONS = "//div[contains(@id,'lform:tableCardList:')][contains(@id,'_list')]//div[contains(@id,'mnuReissuePINCommandLinkfullAccess')]";

	public static final String EDIT_PROFILE_SMENU = "//div[contains(@id,'lform:tableList:')][contains(@id,'_list')][not(contains(@style,'display:none;'))]//div[contains(@id,'mnuEditProfilefullAccess')]";
	// Added by Nithya 17.07.2018
	public static final String CARD_PRODUCT_DROPDOWN = "lform:card_product_oid";
	
	// Added by Nithya 23.07.2018
	public static final String RESEND_PIN_MENU_OPTION = "//div[contains(@id,'lform:tableCardList:')][contains(@id,'_list')][not(contains(@style,'display:none;'))]//div[contains(@id,'mnuChangePINCommandLinkfullAccess')]"; // xpath
	
	public static final String ACCOUNTS_PROFILE_USER = "//div[contains(@id,'lform:tableList:')][contains(@id,'_list')][not(contains(@style,'display:none;'))]//div[contains(@id,'mnuAccountsProfilefullAccess')]"; //xpath
	
	
	public static final String CARDS_WITHPIN_IN_CARDLIST = "//td[contains(@id,'cardNumber_col_1')]/span";
	// Added by Meenakshi 26.07.2018
	public static final String ADD_NEW_CARD_GROUP = "lform:btn_addNewItemfullAccess";
	public static final String BACK_TO_CARD_GROUP_LIST = "lform:back_to_cost_centre_listfullAccess";
	public static final String UPLOAD_POPUP_PANEL = "lform:modalPanelUpload_content";
	public static final String BROWSE_FILE_BUTTON = "div#browserVisible input.btnRight.btnSubmit.btnBrowse";

	// Added by Nithya 01.08.2018
	public static final String CARD_STATUS_TABLE = "lform:tableCardStatusHistoryList";
	// Added by Aravind
	public static final String CH_FIRSTCARD_FROM_CARDSLIST = "//tbody[contains(@id,'lform:tableCardList:tb')]//tr[1]/td[1]/span";
	public static final String CH_SECONDCARD_FROM_CARDSLIST = "//tbody[contains(@id,'lform:tableCardList:tb')]//tr[2]/td[1]/span";
	public static final String CH_CHANGE_STATUS = "//div[contains(@id,'lform:tableCardList:1:mnuCancelChangeStatusCommandLinkfullAccess')]/span[2]";
	public static final String CH_CHANGE_STATUS_PAGE_COUNTRY = "lform:cardContactVODoTstreetAddressVODoTcountry_oid";
	public static final String CH_CHANGE_STATUS_PAGE_DATE = "lform:cardVODoTnew_card_status_atInputDate";
	public static final String CH_CHANGE_STATUS_ERROR_MSG ="//html[1]/body[1]/div[1]/div[3]/form[1]/div[3]/ul[1]/li[1]/a[1]"; //"errorFull";//h4[contains(text(),'Validation failed')]";///html[1]/body[1]/div[1]/div[3]/form[1]/div[3]/ul[1]/li[1]/a[1]
	public static final String CH_CHANGE_STATUS_CARD_STATUS_DROPDOWN ="//select[@id='lform:cardVODoTnew_card_status_oidFullAccess']|//select[@id='lform:cardVODoTnew_card_status_oid']";//"lform:cardVODoTnew_card_status_oidFullAccess";// lform:cardVODoTnew_card_status_oidFullAccess;//lform:cardVODoTnew_card_status_oid
	public static final String CH_CHANGE_STATUS_ACCOUNT_NUMBER = "//tbody[contains(@id,'lform:tableCardList:tb')]//tr[1]/td[7]/p/span";
	public static final String CH_CHANGE_STATUS_SUCCESS_MSG_2 ="//*[@id='successMsg']";  //*[@id='successMsg']/strong";//*[@id='successMsg']/p/span";//"successMsg";// "//*[@id='successMsg']/p/span";//*[@id='successMsg']/strong
	public static final String CH_CHANGE_STATUS_SUCCESS_MSG = "//*[@id='successMsg']/p/span";
	public static final String CH_BACK_TO_CARD_LIST = "lform:bnt_backfullAccess";
	public static final String CH_BACK_TO_CARD_LIST_CARD_REPLACE_PAGE = "lform:backCommandLinkfullAccess";
	public static final String CH_EDIT_CARD_STATUS = "//div[contains(@id,'lform:tableCardList:1:mnuEditCommandLinkfullAccess')]/span[2]";
	public static final String CH_NEW_CARD_STATUS_DROPDOWN = "//select[@id='lform:cardVODoTnew_card_status_oidFullAccess']|//select[@id='lform:cardVODoTnew_card_status_oid']";//"lform:cardVODoTnew_card_status_oid";
	public static final String CH_EDIT_CARD_UPDATE_BTN = "lform:btn_validateCardChanges";
	public static final String CH_POPUP_ACCEPT_BTN = "lform:confirmationPopupconfirmBtn1";
	public static final String CH_POPUP_CANCEL_BTN = "lform:confirmationPopupCancelBtn";
	public static final String CH_POPUP_MESSAGE = "//*[@id='lform:confirmationPopup_content']/div[1]/div[1]/span";
	public static final String CH_REPLACE_CARD_POPUP_TITLE = "lform:requestOrReplacePopupHeader";
	public static final String CH_REPLACE_CARD_POPUP_REPLACE_BTN = "lform:saveStatusAndReissueCardBnt";
	public static final String CH_REPLACE_CARD_POPUP_DONOT_REPLACE_BTN = "lform:saveCardStatusBtn";
	public static final String CH_RELPACE_CONFIRM_ERROR_MESSAGE = "//*[@class='errorFull']/h4";
	public static final String CH_CONFIRMATION_POPUP_MESSAGE = "//*[@id='lform:requestOrReplacePopup_content']/div[1]/div[1]/span";
	public static final String CH_EDIT_CARD_TITLE = "//*[@id='tableListForm']/h1/span";

	// Quick Links on HomePage
	public static final String CH_ORDER_CARD_QUICK_LINK = "cardNewQuicklink";
	public static final String CH_CARD_STATUS_QUICK_LINK = "changeCardStatusQuickLink";
	public static final String CH_CARDS_QUICK_LINK = "cardListQuickLink";
	public static final String CH_TRANSACTION_QUICK_LINK = "customerTransactionListQuickLink";
	public static final String CH_EXPORT_TRANSACTION_QUICK_LINK = "lform:exportTransactionQuickLinkHomePage";
	public static final String CH_HOME_PAGE_USERNAME = "//*[@id='userdrop']/a";

	public static final String CH_ACCOUNT_MAINTENANCE_STREET_ADDRESS = "streetAddress";
	public static final String CH_ACCOUNT_MAINTENANCE_POSTAL_ADDRESS = "postalAddress";
	public static final String CH_TRANSACTION_LIST_TITLE = "//*[@id='lform']/h1/span";

	public static final String CH_TRANSACTION_TABLE_CARD_NUMBER_COLUMN = "lform:tableTransList:j_idt235";
	public static final String CH_TRANSACTION_TABLE_ACCOUNT_NUMBER_COLUMN = "lform:tableTransList:j_idt240";
	public static final String CH_TRANSACTION_TABLE_REFERENCE_NUMBER_COLUMN = "lform:tableTransList:j_idt245";
	public static final String CH_TRANSACTION_TABLE_LOCATION_COLUMN = "lform:tableTransList:j_idt250";
	public static final String CH_TRANSACTION_TABLE_PRODUCT_COLUMN = "lform:tableTransList:j_idt255";
	public static final String CH_TRANSACTION_TABLE_DATE_TIME_COLUMN = "lform:tableTransList:j_idt260";
	public static final String CH_TRANSACTION_TABLE_ODOMETER_COLUMN = "lform:tableTransList:j_idt265";
	public static final String CH_TRANSACTION_TABLE_CUST_AMOUNT_COLUMN = "lform:tableTransList:j_idt270";
	public static final String CH_TRANSACTION_TABLE_STATUS_COLUMN = "lform:tableTransList:j_idt276";
	public static final String CH_REPORTS_TABLE_REPORT_TYPE_COLUMN = "lform:tableStoredRepList:j_idt229";
	public static final String CH_REPORTS_TABLE_CREATED_COLUMN = "lform:tableStoredRepList:j_idt234";
	public static final String CH_REPORTS_TABLE_FILE_NAME_COLUMN = "lform:tableStoredRepList:j_idt239";
	public static final String CH_REPORTS_EXPORT_BTN = "lform:tableVehicleList_xls";

	public static final String CH_REPORTS_REPORT_TYPE_FIELD = "lform:report_type_oidL";
	public static final String CH_REPORTS_CREATED_FROM_FIELD = "lform:created_on_fromL";
	public static final String CH_REPORTS_CREATED_TO_FIELD = "lform:created_on_toL";
	public static final String CH_REPORTS_FILENAME_FIELD = "lform:file_nameL";
	public static final String CH_REPORTS_CHANGE_PWD = "levelTwoAdminSecurity";
	public static final String CH_REPORTS_USER_ID = "lform:logon_idL";
	public static final String CH_REPORTS_OLD_PWD_FIELD = "lform:passwordLT";
	public static final String CH_REPORTS_NEW_PWD_FIELD = "lform:new_passwordLT";
	public static final String CH_REPORTS_CONFIRM_PWD_FIELD = "lform:confirm_passwordLT";
	public static final String CH_SUPPORT_CONTACT_US_LINK = "//*[@id='menu_form:levelTwoContactUs']/li/a";
	public static final String CH_SUPPORT_PRIVACY_STATEMENT = "footerWexForm:footer_linkPrivacy_statement2";
	public static final String CH_PRIVACY_STATEMENT_INTRODUCTION = "/html/body/div[1]/section/main/div/div[2]/div/div/div/div/div/h2[1]";
	public static final String CH_PRIVACY_STATEMENT_DATA_COLLECTION = "/html/body/div[1]/section/main/div/div[2]/div/div/div/div/div/h2[2]";

	public static final String CH_CARD_LIST_ACC_NO_TITLE = "lform:customer_midL";
	public static final String CH_CARD_LIST_CARD_NO_TITLE = "lform:card_noL";
	public static final String CH_CARD_LIST_REG_NO_TITLE = "lform:license_plateL";
	public static final String CH_CARD_LIST_CARD_STATUS_TITLE = "lform:card_status_oidL";
	public static final String CH_CARD_LIST_CARD_OFFER_TITLE = "lform:card_offer_oidL";
	public static final String CH_CARD_LIST_VEHICLE_DESC_TITLE = "lform:vehicleDescL";
	public static final String CH_CARD_LIST_COST_CENTRE_TITLE = "lform:customer_cost_centre_codeL";
	public static final String CH_CARD_LIST_DRIVER_TITLE = "lform:driver_nameL";
	public static final String CH_CARD_LIST_REF_NUM_TITLE = "lform:reference_numberL";

	public static final String CH_CARD_LIST_CARD_DETAILS = "//*[@id='lform:tableCardList:0:mnuViewfullAccess']/span[2]";
	public static final String CH_CARD_LIST_VERIFY_PIN = "//*[@id='lform:tableCardList:0:mnuReissuePINCommandLinkfullAccess']/span[2]";
	public static final String CH_CARD_LIST_CHANGE_STATUS = "//*[@id='lform:tableCardList:0:mnuCancelChangeStatusCommandLinkfullAccess']/span[2]";
	public static final String CH_CARD_LIST_EDIT = "//*[@id='lform:tableCardList:0:mnuEditCommandLinkfullAccess']/span[2]";
	public static final String CH_CARD_LIST_RE_ISSUE_PIN = "//*[@id='lform:tableCardList:0:mnuReissuePINCommandLinkfullAccess']";
	public static final String CH_CARD_LIST_REPLACE_CARD = "//*[@id='lform:tableCardList:0:mnuReplaceCardCommandLinkfullAccess']/span[2]";

	public static final String CH_VIEW_CARD_NUMBER_TITLE = "lform:cardVODoTcard_noL";
	public static final String CH_VIEW_CARD_CARD_STATUS_TITLE = "lform:cardVODoTcard_status_oidL";
	public static final String CH_VIEW_CARD_CARD_TYPE_TITLE = "lform:cardVODoTcard_type_cidL";
	public static final String CH_VIEW_CARD_CARD_EXPIRY_TITLE = "lform:cardVODoTexpires_onL";
	public static final String CH_VIEW_CARD_POS_PROMPTS_TITLE = "//*[@id='lform:posPromptGroup']/label";
	public static final String CH_VIEW_CARD_PIN_TITLE = "lform:cardVODoTis_pin_reqL";
	//public static final String CH_VIEW_CARD_ODOMETER_TITLE = "//span[contains(@id,'lform:cardControlProfileVOsDoTcardControlVODoTis_odometer_req')]";
	public static final String CH_VIEW_CARD_ODOMETER_TITLE = "//label[contains(@id,'lform:cardControlProfileVOsDoTcardControlVODoTis_odometer_req')]"; //Updated
	public static final String CH_VIEW_CARD_PURCHASE_CONTROLS_TITLE = "//span[contains(@id,'purchaseControlsGroupDiv')]";
	public static final String CH_VIEW_CARD_TIME_LIMIT_TITLE = "//span[contains(@id,'cardControlProfileVOsDoTcardControlVODoTtime_limit_oid')]";
	public static final String CH_VIEW_CARD_VEHICLE_DESC_TITLE = "lform:vehicleVODoTdescriptionL";
	public static final String CH_VIEW_LICENSE_NO_TITLE = "lform:vehicleVODoTlicense_plateL";

	public static final String CH_VIEW_DRIVER_NAME_TITLE = "lform:driverVODoTdriver_nameL";
	public static final String CH_VIEW_CARD_CENTRE_TITLE = "lform:costCentreCodeL";
	public static final String CH_VIEW_CARD_OFFER_TITLE = "lform:cardVODoTcard_offer_oidL";
	public static final String CH_VIEW_CARD_PRODUCT_TITLE = "lform:cardVODoTcard_product_oidL";
	
	public static final String CH_VIEW_CARD_MONTHLY_DOLLAR_LIMIT = "//span[contains(@id,'cardControlProfileVOsDoTcardControlVODoTvelocityAssignmentVODoTvelocity_type_value_1_oid')]";
	public static final String CH_VIEW_CARD_DAILY_TRANS_LIMIT = "//span[contains(@id,'cardControlProfileVOsDoTcardControlVODoTvelocityAssignmentVODoTvelocity_type_value_2_oid')]";
	public static final String CH_VIEW_CARD_DAILY_DOLLAR_LIMIT = "//span[contains(@id,'cardControlProfileVOsDoTcardControlVODoTvelocityAssignmentVODoTvelocity_type_value_3_oid')]";
	public static final String CH_VIEW_CARD_MONTHLY_VOLUME_LIMIT = "//span[contains(@id,'cardControlProfileVOsDoTcardControlVODoTvelocityAssignmentVODoTvelocity_type_value_4_oid')]";
	public static final String CH_VIEW_CARD_DAILY_VOLUME_LIMIT = "//span[contains(@id,'cardControlProfileVOsDoTcardControlVODoTvelocityAssignmentVODoTvelocity_type_value_5_oid')]";
	public static final String CH_VIEW_CARD_TRANS_VOLUME_LIMIT = "//span[contains(@id,'cardControlProfileVOsDoTcardControlVODoTvelocityAssignmentVODoTvelocity_type_value_6_oid')]";
	public static final String CH_VIEW_CARD_TRANS_DOLLAR_LIMIT = "//span[contains(@id,'cardControlProfileVOsDoTcardControlVODoTvelocityAssignmentVODoTvelocity_type_value_7_oid')]";
	public static final String CH_VIEW_CARD_BACK_BUTTON = "lform:BbBackCardListfullAccess";

	public static final String CH_BULK_CARD_DOWNLOAD_BTN = "lform:btn_download";
	public static final String CH_BULK_CARD_UPLOAD_BTN = "lform:j_idt211";
	public static final String CH_BULK_UPDATE = "menu_form:levelTwoBulkCardUpdate";
	public static final String CH_BULK_CARD_UPDATE_UPLOAD_BTN = "lform:j_idt316";

	public static final String CH_LEGAL_NOTICE = "footerWexForm:footer_linkLegal_notice1"; // id
	public static final String CH_PRIVACY_STATEMENT = "footerWexForm:footer_linkPrivacy_statement1"; // id
	public static final String CH_CONTACT_US = "//*[@id='footerWexForm:footer_linkContactUs1']|//*[@id='footerWexForm:footer_linkContactUs']";
	public static final String CH_SUBMIT_BTN = "lform:btn_contactUs";

	public static final String CH_ENQUIRY_TYPE_DROP_DOWN = "lform:contact_us_selectedQueryType";
	public static final String CH_COMMENTS_DROP_DOWN = "lform:contact_us_comment";
	public static final String CH_CONTACT_NAME = "lform:contact_us_contactName";
	public static final String CH_PHONE_NO = "lform:contact_us_phoneNumber";
	public static final String CH_EMAIL = "lform:contact_us_email";
	public static final String CH_CONTACT_NO = "//*[@id='lform']/text()[1]";
	public static final String CH_CONFIRMATION_MSG = "//*[@id='successMsg']";
	public static final String CH_FORGOT_PWD_SUBMIT_BTN = "lform:cmdEmailfullAccess";
	public static final String CH_FORGOT_PWD_INSTRUCTIONS = "//*[@id='lform']/p";
	public static final String CH_INVALID_LOGON_ATTEMPT = "//*[@id='loginErrors']/li";
	public static final String CH_REQ_LOGON_ACC_NO = "lform:request_a_logon_account_no";
	public static final String CH_REQ_LOGON_ADDR = "lform:request_a_logon_contactVODoTstreetAddressVODoTaddress_line";
	public static final String CH_REQ_LOGON_POSTAL_CODE = "lform:request_a_logon_contactVODoTstreetAddressVODoTpostal_code";
	public static final String CH_REQ_LOGON_FIRST_NAME = "lform:request_a_logon_first_name";
	public static final String CH_REQ_LOGON_LAST_NAME = "lform:request_a_logon_last_name";
	public static final String CH_REQ_LOGON_EMAIL = "lform:request_a_logon_contactVODoTemail_address";
	public static final String CH_REQ_LOGON_PHONE = "lform:request_a_logon_contactVODoTphone_business";
	public static final String CH_REQ_LOGON_SUBMIT_BTN = "lform:btn_requestLogon";

	// Merchant site for Chevron
	public static final String CH_MERCHANT_LOCATION_NAME = "//*[@id='accountInfo']/dt[1]";
	public static final String CH_MERCHANT_PHY_ADDR = "//*[@id='streetAddress']/h3";
	public static final String CH_MERCHANT_POSTAL_ADDR = "hdr_postalAddress";
	public static final String CH_MERCHANT_CONTACT_TYPE_TABLE = "lform:tableContactList:j_idt277";
	public static final String CH_MERCHANT_DEFAULT_CONTACT_TYPE_TABLE = "lform:tableContactList:j_idt281";
	public static final String CH_MERCHANT_CONTACT_NAME_TABLE = "lform:tableContactList:col_3";
	public static final String CH_MERCHANT_CONTACT_PHONE_TABLE = "lform:tableContactList:col_4";
	public static final String CH_MERCHANT_CONTACT_EMAIL_TABLE = "lform:tableContactList:col_5";

	/*public static final String CH_MERCHANT_CONTACT_LIST_CONTACT_TYPE_TABLE = "lform:tableContactList:j_idt212";
	public static final String CH_MERCHANT_CONTACT_LIST_DEFAULT_CONTACT_TYPE_TABLE = "lform:tableContactList:j_idt218";
	public static final String CH_MERCHANT_CONTACT_LIST_CONTACT_NAME_TABLE = "lform:tableContactList:j_idt223";
	public static final String CH_MERCHANT_CONTACT_LIST_CONTACT_PHONE_TABLE = "lform:tableContactList:j_idt228";
	public static final String CH_MERCHANT_CONTACT_LIST_CONTACT_EMAIL_TABLE = "lform:tableContactList:j_idt233";*/
	public static final String CH_MERCHANT_CONTACT_LIST_CONTACT_TYPE_TABLE = "//table//a[text()='Contact Type']";
	public static final String CH_MERCHANT_CONTACT_LIST_DEFAULT_CONTACT_TYPE_TABLE = "//table//a[text()='Default']";
	public static final String CH_MERCHANT_CONTACT_LIST_CONTACT_NAME_TABLE = "//table//a[text()='Name']";
	public static final String CH_MERCHANT_CONTACT_LIST_CONTACT_PHONE_TABLE = "//table//a[text()='Phone']";
	public static final String CH_MERCHANT_CONTACT_LIST_CONTACT_EMAIL_TABLE = "//table//a[text()='Email']";	

	public static final String CH_MERCHANT_TRANS_TYPE ="//*[@id='lform:transactionEnquiryFilterVODoTtransaction_type_oid']| //*[@id='lform:transaction_type_oid']";//= "lform:transaction_type_oid";
	public static final String CH_MERCHANT_TRANS_REF_NO="//*[@id='lform:transactionEnquiryFilterVODoTref_no']|//*[@id='lform:transaction_reference']"; //= "lform:transaction_reference";
	public static final String CH_MERCHANT_TRANS_FROM_DATE = "lform:effective_date_fromInputDate";
	public static final String CH_MERCHANT_TRANS_LOC_NO = "//*[@id='lform:location_noL']|//*[@id='lform:transactionEnquiryFilterVODoTlocation_no']";
	public static final String CH_MERCHANT_TRANSS_LOC_NO ="//*[@id='lform:location_noL']|//*[@id='lform:transactionEnquiryFilterVODoTlocation_no']";
	public static final String CH_MERCHANT_TRANS_PRODUCT = "lform:product_oid";
	public static final String CH_MERCHANT_TRANS_TO_DATE = "lform:effective_date_toInputDate";
	
	public static final String CH_MERCHANTL_TRANS_TYPE ="lform:transaction_type_oidL";//"lform:transactionEnquiryFilterVODoTtransaction_type_oid" ;  //= "lform:transaction_type_oid";
	public static final String CH_MERCHANTL_TRANS_REF_NO="lform:transaction_referenceL"; //= "lform:transaction_reference";//lform:transactionEnquiryFilterVODoTref_no
	public static final String CH_MERCHANTL_TRANS_FROM_DATE = "lform:effective_date_fromL";
	public static final String CH_MERCHANTL_TRANSS_LOC_NO = "lform:location_noL";
	public static final String CH_MERCHANTL_TRANS_PRODUCT = "lform:product_oidL";
	public static final String CH_MERCHANTL_TRANS_TO_DATE = "lform:effective_date_toL";

	public static final String CH_MERCHANT_TRANS_CARD_NO_TABLE = "lform:tableTransList:j_idt233";
	public static final String CH_MERCHANT_TRANS_TYPE_TABLE = "lform:tableTransList:j_idt237";
	public static final String CH_MERCHANT_REF_NO_TABLE = "lform:tableTransList:j_idt241";
	public static final String CH_MERCHANT_LOC_NAME_TABLE = "lform:tableTransList:j_idt245";
	public static final String CH_MERCHANT_PRODUCT_TABLE = "lform:tableTransList:j_idt249";
	public static final String CH_MERCHANT_TRANS_DATE_TABLE = "lform:tableTransList:j_idt253";
	public static final String CH_MERCHANT_TOTAL_TABLE = "lform:tableTransList:j_idt257";

	public static final String CH_MERCHANT_EXPORT_TRANS_SUB_MENU = "menu_form:exportTransactionQuickLink";

	public static final String CH_MERCHANT_EXPORT_TRANS_PROCESSED_TABLE_HEADER = "lform:tableSettLementsList:j_idt217";
	public static final String CH_MERCHANT_EXPORT_TRANS_DATE_TABLE_HEADER = "lform:tableSettLementsList:j_idt221";
	public static final String CH_MERCHANT_EXPORT_TRANS_LOC_NO_TABLE_HEADER = "lform:tableSettLementsList:j_idt225";
	public static final String CH_MERCHANT_EXPORT_TRANS_DETAIL_TABLE_HEADER = "lform:tableSettLementsList:j_idt229";
	public static final String CH_MERCHANT_EXPORT_TRANS_STATUS_TABLE_HEADER = "lform:tableSettLementsList:j_idt233";
	public static final String CH_MERCHANT_EXPORT_TRANS_GROSS_AMT_TABLE_HEADER = "lform:tableSettLementsList:j_idt237";
	public static final String CH_MERCHANT_EXPORT_TRANS_CONTRIB_TABLE_HEADER = "lform:tableSettLementsList:j_idt241";
	public static final String CH_MERCHANT_EXPORT_TRANS_VARIANCE_TABLE_HEADER = "lform:tableSettLementsList:j_idt245";
	public static final String CH_MERCHANT_EXPORT_TRANS_NET_AMT_TABLE_HEADER = "lform:tableSettLementsList:j_idt249";
	public static final String CH_MERCHANT_CHANGE_PWD_LINK = "accountProfileChangePasswordLnk";

	public static final String CH_MERCHANT_HOME_CURRENT_BAL = "//*[@id='table_selectAccountDetails']/tbody/tr[1]/td[3]";
	public static final String CH_MERCHANT_HOME_LAST_BILL_AMOUNT = "//*[@id='table_selectAccountDetails']/tbody/tr[2]/td[2]";
	public static final String CH_MERCHANT_HOME_LAST_BILL_DATE = "//*[@id='table_selectAccountDetails']/tbody/tr[3]/td[2]";
	public static final String CH_MERCHANT_HOME_LAST_PAYMENT_RECV = "//*[@id='table_selectAccountDetails']/tbody/tr[4]/td[2]";
	public static final String CH_MERCHANT_HOME_LAST_PAYMENT_AMOUNT = "//*[@id='table_selectAccountDetails']/tbody/tr[2]/td[2]";

	public static final String CH_MERCHANT_CHANGE_PWD_OLD_PWD_FIELD = "lform:password";
	public static final String CH_MERCHANT_CHANGE_PWD_NEW_PWD_FIELD = "lform:new_password";
	public static final String CH_MERCHANT_CHANGE_PWD_CONFIRM_PWD_FIELD = "lform:confirm_password";

	public static final String CH_ORDER_CARD_DETAILS_SECTION = "//*[@id='orderCardForm']/div[1]/h2";
	public static final String CH_VELOCITY_LIMITS_SECTION = "//*[@id='subCategoryItem_2']/h2";
	public static final String CH_ORDER_CARD_DELIVERY_ADDR_SECTION = "//*[@id='subCategoryItem_3']/h2";

	public static final String CH_CARD_LIST_SEARCH_RES_CARD_NO = "//th[@id='lform:tableCardList:cardNumber_col_1']/a";
	public static final String CH_CARD_LIST_SEARCH_RES_CURR_CARD_STATUS = "//th[@id='lform:tableCardList:cardList_th_ols_card_status_description']/a";
	public static final String CH_CARD_LIST_SEARCH_RES_CARD_OFFER = "//th[@id='lform:tableCardList:cardList_th_card_offer_oid']/a";
	public static final String CH_CARD_LIST_SEARCH_RES_REGO_NO = "//th[@id='lform:tableCardList:license_plateL']/a";
	public static final String CH_CARD_LIST_SEARCH_RES_DRIVER = "//th[@id='lform:tableCardList:driver_nameL']/a";
	public static final String CH_CARD_LIST_SEARCH_RES_COST_CENTRE = "//th[@id='lform:tableCardList:cardList_th_customer_cost_centre_code']/a";
	public static final String CH_CARD_LIST_SEARCH_RES_ACC_NO = "//th[@id='lform:tableCardList:cardList_th_customer_no']/a";
	public static final String CH_CARD_LIST_SEARCH_RES_AVA_BAL = "//th[@id='lform:tableCardList:cardList_th_balance']/a";
	public static final String CH_CONFIRM_CARD_TITLE = "//*[@id='lform:confirmOrderCardForm']/h2";

	public static final String CH_TRANS_DETAILS_TITLE = "//*[@id='lform']/h1";
	public static final String CH_CARD_LIST_TABLE = "//*[@id='lform:databulkStatus']";
	public static final String CH_CARD_LIST_TABLE_FIRST_ROW = "//*[@id='lform:databulkStatus']/tbody/tr";
	
	public static final String CH_REISSUE_CONTROL = "menu_form:levelTwoBulkReissueList";
	public static final String CH_REISSUE_CONTROL_UPLOAD = "lform:j_idt245";
	
	
	
	
	//Added by Anton 
	public static final String DETAILSUBMENU = "//div[contains(@id,'lform:tableTransList')][contains(@id,'_list')][not(contains(@style,'display:none;'))]//div[contains(@id,'tool_viewfullAccess')]";
	public static final String CHV_CARDTABLEDATA ="//table[@id='lform:tableCardList']/tbody[@id='lform:tableCardList:tb']/tr";
	
	//Added by Anton 04.10.2018
	public static final String FULL_NAME_CONTACTUS="full-name";
	public static final String INQUIRY_SUMMARY_CONTACTUS="inquiry-summary";
	public static final String EMAIL_FIELD_CONTACUS="email";
	public static final String CUSTOMER_RADIO_BUTTON="//label[@for='radio-2']/span";
	public static final String BUTTON_CUS="btnSubmit";
	public static final String MERCHANT_RADIO_BUTTON = "//label[@for='radio-1']/span";
	
	//Added by Suganthi 10/05/2018 
	public static final String CONTACT_US_PAGE = "//*[@id='tab-star-card']//h2";
	public static final String CONTACT_US_CC = "//a[@title='Chevron Corporation']";
	public static final String CONTACT_US_TERMS_OF_USE = "//a[@title='Terms Of Use']";
	public static final String CONTACT_US_STATEMENT = "//a[@title='Privacy Statement']";
	public static final String CONTACT_US_COPY_RIGHTS = "//p[@class='coppy-right']";
	public static final String FULL_NAME = "//label[text()='Full Name']";
	public static final String INQUIRY_SUMMARY = "//label[text()='Inquiry Summary']";
	public static final String EMAIL_ADDRESS = "//label[text()='Email address']";
	public static final String CONTACT_NUMBER = "//label[contains(text(),'Contact number')]";
	public static final String USER_TYPE = "//label[text()='Are you a'] ";
	public static final String HELP_OPTION = "//label[contains(text(),'What can we help you with?')]";
	public static final String SUBMIT_OPTION = "//input[@id='btnSubmit']";
	public static final String ERROR_MESSAGE = "//p[@class='error-mess error']";
	public static final String ACCOUNT_NUMBER = "acct-num";
	public static final String CUSTOMER_OPTION = "//label[@for='customer']//span";
	public static final String USER_TYPE_DROPDOWN_LIST = "//button[contains(text(),'Select one')]";//"//div[contains(@class,'dropdown custom-dropdown size-4')]";
	public static final String USER_TYPE_DROPDOWN = "//label[contains(text(),'Country')]";
	public static final String USER_TYPE_OPTION = "//li[@data-value='Read Only Access']";
	public static final String DRIVER_DETAILS = "/html[1]/body[1]/div[1]/div[3]/form[1]/div[1]/div[3]/div[2]/div[3]/h3[1]";
	
	//ZEnergy 
	public static final String Z_LOGO_IMG = "headerForm:customerCommandLnk"; // Id
	public static final String Z_HOME = "footerWexForm:footer_homeLnk"; //ID
	public static final String Z_CONTACT_US = "footerWexForm:footer_linkContactUs1"; //ID
	public static final String Z_LEGAL_NOTICE = "footerWexForm:footer_linkLegal_notice1"; //ID
	public static final String Z_PRIVACY_POLICY = "footerWexForm:footer_linkPrivacy_statement1"; //ID
	public static final String Z_USER_GUIDE = "cardUGQuickLink"; //ID
	public static final String TRANSACTION_DATE_FROM = "//input[contains(@id,'lform:effective_date_fromInputDate')]";
	public static final String ALL_LISTED_TRANSACTIONS = "//tbody/tr[1]/td[1] [contains(@id,'TransList')]//span[contains(@id,'TransList')]";
	public static final String TRANSACTION_DETAIL = "//div[contains(@id,'TransList:0:')]//span[contains(text(),'Detail')]";
	
    //Added by Ayub 17/01/2019
	public static final String Z_REPORT_NAME = "//tr[1]//td[contains(@id,'lform:avaliableReport')][contains(@id,'c1')]/p"; //Xpath
	public static final String Z_CLONE_CARD = "//div[contains(@id,'lform:tableCardList:')][contains(@id,'_list')][not(contains(@style,'display:none;'))]//div[contains(@id,':mnuCloneCardCommandLinkFullAccess')]"; // Xpath
	public static final String Z_CONTACT_TYPE = "//tr[contains(@id,'lform:tableContactList')][1]//td[1]"; // Xpath
	
	// Added by Ayub 24/01/2019	
	/*public static final String Z_CUSTOMER_NAME = "lform:request_a_logon_reference_no"; // Xpath
	public static final String Z_CONNECT_TO_XERO = "levelTwoXfList"; // Id
	*/

	//	public static final String Z_Cards_Page = "// Xpath//span[@class='highlighter'][contains(text(),'Cards')]" ;// Xpath 
	//	public static final String Z_Cards_Page = "// span[@class='assistText'][text()='Search Filters']" ;// Xpath
	//	public static final String Z_Cards_Page = "// h2[contains(text(),'Search Results')]" ;// Xpath

	public static final String Z_CARD_NUM = "//*[@id=\"uniqueToken\"]";
	//Added by Sasi 29/01/2019
	public static final String Z_CARD_NUMBER = "//input[@id='lform:card_no']";// Xpath
	//public static final String Z_REGO_NUMBER = "//input[@id='lform:vehicleVODoTlicense_plate']";// Xpath
	//public static final String Z_DRIVER_NAME = "//input[@id='lform:driverVODoTdriver_name']";// Xpath
	public static final String Z_REGO_NUMBER = "//input[@name='lform:vehicleVODoTlicense_plate']";// Xpath
	public static final String Z_DRIVER_NAME = "//input[@name='lform:driverVODoTdriver_name']";// Xpath
	public static final String Z_REFERENCE_NUMBER = "//input[@id='lform:reference_number']";// Xpath 
	public static final String Z_VEHICLE_DISCRIPTION = "//input[@id='lform:vehicleDesc']";// Xpath //input[@id='lform:driverVODoTdriver_mobile']
	public static final String Z_COSTCENTRE_CODE = "//select[@name='lform:customer_cost_centre_oid']";// Xpath
	public static final String Z_TABLES_LIST = "//div[@class='formCol_A']";// Xpath
	public static final String CARD_PURCHASE_PRODUCTS_LOCATION_RESTRICTION = "//select[@name='lform:cardControlProfileVOsDoTcardControlVODoTlocation_restriction_oid']";// Xpath
	public static final String CARD_PURCHASE_PRODUCTS_PRODUCT_RESTRICTION = "//select[@id='lform:cardControlProfileVOsDoTcardControlVODoTproduct_restriction_oid']";// Xpath
	
	// Added by Ayub 24/01/2019	
	public static final String Z_CUSTOMER_NAME = "lform:request_a_logon_reference_no"; // Xpath
	public static final String Z_CONNECT_TO_XERO = "levelTwoXfList"; // Id
	public static final String Z_FLEET_ID = "lform:cardVODoTadditional_emboss_data";
	public static final String Z_CARD_NO = "lform:cardNo";
	public static final String Z_COST_CENTER = "lform:orderCardVODoTcostCentreVODoTcustomer_cost_centre_oid";
	public static final String Z_PERMANENT_ADDRESS = "//h3[normalize-space(text())='Permanent Address']";
	public static final String Z_PURCHASE_CONTROLS = "//h3[normalize-space(text())='Purchase Controls']";
	public static final String Z_CARD_LIMITS = "/h2[normalize-space(text())='Card Limits']";
	public static final String Z_TEMPORARY_ADDRESS = "//h3[normalize-space(text())='Temporary Address']";
	public static final String PRODUCT_RESTRICTION_OID = "lform:cardControlProfileVOsDoTcardControlVODoTproduct_restriction_oid";
	public static final String CARD_OFFER_TITLE = "lform:cardVODoTcard_offer_oid";
	public static final String CARD_CONFIRM_PRODUCTS_LOCATION_RESTRICTION ="lform:cardControlProfileVOsDoTcardControlVODoTlocation_restriction_oid";
	public static final String CARDSTATUSCHANGE_POPUP_REISSUEBUTTON = "lform:saveCardStatusAndReissueCardBtnFullAccess";
	public static final String FUTURE_CARDRADIO_BUTTON = "table[id*=tableCardStatusHistoryList]input:nth-of-type(1)"; // css
	public static final String USERID = "j_userid";
	public static final String Z_WELCOME_TEXT = "//span[contains(text(),'Welcome to Z Business Online')]";
public static final String CARD_LIMITS_MONTHLY_DOLLAR = "//select[@id='lform:cardControlProfileVOsDoTcardControlVODoTvelocityAssignmentVODoTvelocity_type_value_1_oid']";// Xpath
	public static final String CARD_LIMITS_TRANSACTION_DOLLAR_LIMIT = "//select[@id='lform:cardControlProfileVOsDoTcardControlVODoTvelocityAssignmentVODoTvelocity_type_value_2_oid']";// Xpath
	public static final String CARD_LIMITS_DAILY_DOLLAR = "//select[@id='lform:cardControlProfileVOsDoTcardControlVODoTvelocityAssignmentVODoTvelocity_type_value_3_oid']";// Xpath
	public static final String CARD_LIMITS_TRANSACTION_LIMIT = "//select[@id='lform:cardControlProfileVOsDoTcardControlVODoTvelocityAssignmentVODoTvelocity_type_value_4_oid']";// Xpath
	public static final String UPLOAD_BULK_CARD_UPDATE_CLEAR_TEMPLATE = "//input[@id='lform:clearFilter']";// Xpath
//	public static final String ACCOUNT_NAME_IN_HEADER="//*[@id='accountProfile']/div[1]/label";
	public static final String ACCOUNT_NAME_IN_HEADER="//*[@id='accountProfile']//label";

//Added by Sasi 04/02/2019
	public static final String Z_ACCOUNT_STATUS = "//td[contains(text(),'Account Status')]";// Xpath
	public static final String Z_CREDIT_LIMIT = "//td[contains(text(),'Credit Limit')]";// Xpath
	public static final String Z_AVAILABLE_BALANCE = "//h3[contains(text(),'Available Balance')]";// Xpath
	public static final String Z_LAST_INVOICE_DATE = "//td[contains(text(),'Last Invoice Date')]";// Xpath
	public static final String Z_NEXT_INVOICE_DATE = "//td[contains(text(),'Next Invoice Date')]";// Xpath
	public static final String Z_DELIVERY_ADDRESS = "//input[@name='lform:delivery_email_address']";// Xpath
	public static final String Z_DELIVERY_SUCCESS_MSG = "//span[contains(text(),'Success!')]";// Xpath
	public static final String Z_EDIT_CARD_VALIDATION_FAILED = "//h4[contains(text(),'Validation failed')]";// Xpath
	public static final String Z_SHEDULED_REPORTS = "//span[@class='highlighter'][contains(text(),'Scheduled Reports for')]";
	public static final String Z_SUCCESS_MSG = "successMsg";



//Added by Sasi 05/02/2019
	
	public static final String CARD_SEARCH_QUICK_LINK = "//a[@title='Card search']";// Xpath
	public static final String TRANSACTION_SEARCH_QUICK_LINK = "//a[@id='customerTransactionListQuickLink']";// Xpath
	public static final String INVOICE_QUICK_LINK = "//a[@id='invoiceReportQuickLink']";// Xpath
	public static final String RUN_REPORT_QUICK_LINK = "//a[@title='Run a report']";// Xpath
	public static final String XERO_QUICK_LINK = "//a[@id='xeroFeedQuickLink']";// Xpath
	public static final String Z_QUICK_LINK = "//a[@id='zWebSiteQuickLink']";// Xpath
	public static final String CALTEX_QUICK_LINK = "//a[@id='caltexWebSiteQuickLink']";// Xpath
	public static final String LOCATION_SITE_QUICK_LINK = "//a[@title='Location/Site finder']";// Xpath
	public static final String TC_QUICK_LINK = "//a[@id='cardTCQuickLink']";// Xpath
	public static final String EDIT_CARD_QUICK_LINK = "//a[@id='changeCardStatusQuickLink']";// 
	public static final String XERO_TC_QUICK_LINK = "//a[@id='cardXTCQuickLink']";// Xpath 
	public static final String Z_FOOTER_QUICK_LINK = "//a[@title='Login to Z Card Online']";// Xpath
	public static final String Z_CARD_TABLE_STATUS_HEADER = "//a[@id='lform:tableCardList:j_idt253']";// Xpath
	public static final String Z_MANAGE_LOYALITY_QUICK_LINK = "//a[@title='Manage your loyalty']";
	public static final String Z_CARD_SEARCH_BOX = "lform:card_no";
	
	public static final String REPORT_TYPE = "//select[@id='lform:report_type_oid']";
	public static final String FROM_VALUE = "lform:created_on_fromInputDate";
	public static final String TO_VALUE = "lform:created_on_toInputDate";
	public static final String REPORT_SEARCH = "lform:btn_search";
	public static final String REPORT_FILENAME = "//td[@id='lform:tableStoredRepList:1:c3']//p";
	public static final String FOUND_ROWSIZE = "//span[@id='lform:gridGroup']";
	public static final String NO_REPORTS = "//div[@class='tableEmpty']";
	public static final String GET_STOREDREPORT = "//td[@id='lform:tableStoredRepList:1:c3']//a";
	public static final String GET_CONTACTREPORT = "//td[@id='lform:tableContactList:1:c3']//a";
	public static final String STORED_EXPORT_BTN = "lform:tableVehicleList_xls";
	public static final String STATEMENTS_SUBMENU = "levelTwoRepStatments";
	public static final String STATEMENT_REPORTFILE = "//td[@id='lform:tableStoredRepList:0:c3']//p";
	public static final String STATEMENT_REPORTTYPE = "//td[@id='lform:tableStoredRepList:0:linkDiv/p']/div";
	public static final String GET_STATEMENTREPORT = "//td[@id='lform:tableStoredRepList:0:c3']//a";
	
	//Transactions
	public static final String CHV_TABLE_LIST_IN_TRANSACTION="//table[@id='lform:tableTransList']";
	
	public static final String REFERENCE_TABLE_VAL ="//*[@id='lform:tableTransList:0:c3']//span";
	public static final String ACCOUNT_NAME_IN_TRANSACTIONPAGE="//*[@id='accountProfile']/div[1]/label";
	public static final String CHV_CALENDER_FROM_BUTTON="lform:effective_date_fromPopupButton";
	public static final String CHV_CALENDAR_FROM_DIALOGBOX="lform:effective_date_fromContent";
	public static final String CHV_CARDS_TABLE="lform:tableCardList";	
	public static final String CHV_CARDS_NO="lform:card_no";	
	public static final String CHV_REG_NO="//*[@id='lform:tableCardList:0:license_plateL']//span";
	public static final String CHV_CARD_TABLE="lform:tableCardList:0:cardNumberCol1";
	public static final String CHV_CARD_TABLE_POPUP="lform:tableCardList:0:j_idt250_list";
	public static final String CHV_CARD_EDIT_TABLE_POPUP="//*[@id='lform:tableCardList:0:mnuEditCommandLinkfullAccess']";
	public static final String CHV_CARD_DETAIL_TABLE_POPUP="//div[@id='lform:tableCardList:0:mnuViewfullAccess']";
	public static final String CHV_CARD_SUCCESS_MSG="//div[@id='successMsg']//span";
	public static final String CHV_CARD_PAGE_TITLE="//div[@id='content']/h1/span";
	public static final String CHV_CARD_BACK_TO_CARD="lform:BbBackCardListfullAccess";
	public static final String CHV_VIEW_CARD_TITLE="//form[@id='lform']/h1/span";
	public static final String CHV_DELIVERY_ADDRESS="//*[@id='lform:cardContactVODoTstreetAddressVODoTaddress_linePanel']/tbody/tr[2]/td/p";
	public static final String CHV_DELIVERY_NAME_TITLE="//table[@id='lform:cardContactVODoTstreetAddressVODoTaddress_linePanel']/tbody/tr[1]/td/p";
	public static final String CHV_DELIVERY_COUNTRY_STATE="//table[@id='lform:cardContactVODoTstreetAddressVODoTaddress_linePanel']/tbody/tr[5]/td/p";
	public static final String PICK_ACCOUNT_FROM_DROPDOWN = "lform:selectMember";
	public static final String CH_CONTACT = "footerWexForm:footer_linkContactUs1";
public static final String LANGUAGE_DROP = "//select[contains(@id,'language_oid')]";
	
	public static final String RUSSIAN_USERNAME_LABEL="//label[contains(text(),'Идентификатор пользователя')]";
	public static final String  RUSSIAN_PASSWORD_LABEL="//label[contains(text(),'Пароль')]";
	public static final String  MALAYSIA_USERNAME_LABEL="//label[contains(text(),'User ID')]";
	public static final String  MALAYSIA_PASSWORD_LABEL="//label[contains(text(),'Password')]";
	
	
//	public static final String  SUCCESS_MSG_ORDERED_CARD = "//div[@id='successMsg']//p//span";
	// Added by Sasi 17-04-2019
	public static final String RESULT_FOUND = "//h4[contains(text(),'found')]";
	public static final String ACCOUNT_NAME_DROPDOWN_IN_HOME_PAGE = "//select[@id='accountProfileSelectMemberForm:accountProfileSelectMember']/option[1]";
	public static final String EFFECTIVE_FROM_DATE_IN_TRANSACTIONS_PAGE = "//input[contains(@id,'effective_date_fromInputDate')]";	
	public static final String TRANSACTION_TABLE_EXCLUDING_HEADER = "//tbody[@id='lform:tableTransList:tb']";
	public static final String TABLE_PAGINATION = "//a[contains(@class,'rf-ds-nmb-btn')]";
	public static final String BACK_BUTTON = "//input[@id='lform:bnt_backfullAccess']";
	public static final String CUSTOMER_CARD_NUMBER="//span[@id='lform:cardVODoTemboss_line_1']";	
	public static final String SUCCESS_MSG_ORDERED_CARD = "//p//span[contains(text(),'Success!')]";
	public static final String ACCOUNT_NUMBER_IN_HOME_PAGE = "//div[@id='accountProfile']/div/dl/span";
	//Added by sowmiya
		//public static final String EXPIRY_DATE_IN_EDITCARD="lform:cardVODoTexpires_onInputDate";//id
		
		public static final String EXPIRY_DATE_CALENDER_IN_EDITCARD="lform:cardVODoTexpires_onPopupButton";
		public static final String EXPIRY_DATE_CALENDERDIALOGBOX="lform:cardVODoTexpires_onContent";
		public static final String MESSAGE_IN_POPUP="//div[@id='lform:requestOrReplacePopup_content']//span";
		public static final String CARDSTATUSCHANGE_POPUP_YESBUTTON = "lform:saveCardStatusAndReissueCardBtnFullAccess";
		//OTI
		public static final String OTI_LOGO="headerForm:customerCommandLnk";// id
		public static final String POSPROMPT_ODOMETER="//*[@id='lform:cardControlProfileVOsDoTcardControlVODoTis_odometer_req'] ";// xpath
		
		public static final String CARD_TYPE="lform:cardVODoTcard_type_cid";
		//public static final String PRODUCT_RESTRICTION="lform:cardControlProfileVOsDoTcardControlVODoTproduct_restriction_oid";
		public static final String PURCHASE_LOCATION_RESTRICTION="lform:cardControlProfileVOsDoTcardControlVODoTlocation_restriction_oid";
		public static final String PURCHASE_TIME_LIMIT="lform:cardControlProfileVOsDoTcardControlVODoTtime_limit_oid";
		public static final String ORDER_CARD_OFFER="//*[@id='lform:cardProductVODoTcard_offer_oid']";//xpath
		public static final String ORDER_CARD_PRODUCT="lform:cardVODoTcard_product_oid";
		public static final String DRIVER_NAME="//*[@id='lform:driverVODoTdriver_name']";//xpath
		public static final String TRANSACTION_VOLUME_LIMIT="//span[contains(text(),'Transaction Volume Limit')]//parent::label//parent::div//select";
		public static final String DAILY_VOLUME_LIMIT="//span[contains(text(),'Daily Volume Limit')]//parent::label//parent::div//select";
		public static final String MONTHLY_VOLUME_LIMIT="//span[contains(text(),'Monthly Volume Limit')]//parent::label//parent::div//select";
		public static final String ORDERCARD_BUTTON="lform:btn_orderCard";
		
		// Added by Ayub  
		public static final String CRUISE_USERNAME = "userName"; // id
		public static final String CRUISE_PASSWORD = "password"; 
		public static final String CRUISE_SIGNIN = "//input[@name='login']"; // Xpath
		public static final String CRUISE_LOGO = "logo";
		
		//Reports 
		public static final String REPORTS_RUNAREPORT="//select[@id='lform:runReportreport_group_did']/option";//xpath
		public static final String REPORTDETAILS_RUNAREPORT="//select[@id='lform:report_type_oid']/option";//xpath
	    
	    public static final String LI_EXISTING_CARD_NUMBER = "(//div[@class='menu-popup']/p/a/span)[1]";
	    public static final String GO_TO_CARD_BUTTON = "(//a[contains(text(),'Go to Card')])[1]";
	    public static final String MERCHANT_RECONCILIATION_REPORT = "//td[@id='lform:avaliableReport:1:c1']/p";
	    public static final String EMAIL_OR_PHONENO_TEXT_BOX = "identifierId";
	    public static final String NEXT_BUTTON_GMAIL = "//span[text()='Next']";
	    public static final String USER_NAME_GMAIL = "username";
	    public static final String PASS_WORD_GMAIL = "password";
	    public static final String SIGN_IN_BUTTON_GMAIL = "okta-signin-submit";
	    public static final String DRIVER_NAME_OF_A_CARD = "td[id='lform:tableCardList:0:driver_nameL']>p>span";

	    
	 
	    //Added by NK for BP
	    public static final String PAYMENTS_CARD_NO = "//input[@id='card_number']";
	    public static final String PAYMENTS_EXPIRY_MONTH = "//select[@name='card_expiry_month']";
	    public static final String PAYMENTS_EXPIRY_YEAR = "//select[@name='card_expiry_year']";
	    public static final String PAYMENTS_CVN_NO = "//input[@id='card_cvn']";
	    public static final String PAYMENTS_PAY_BTN = "//input[@name='commit']";
	    public static final String PAYMENTS_SUCCESS_MSG = "//form[@id='lform']/h1";
	    
	    public static final String SELECT_ALL_LINK = "(//div[@class='row small-bottom-margin']/div/a[1])[1]";
		public static final String SELECT_ACCOUNTS_BUTTON = "(//a[@class='btnRight greenButton'])[1]";
	    public static final String SEL_MULTI_CUS = "//a[@id='lform:selectMultipleAccountsLink']";
	    public static final String ERROR_MESSAGE_REPORTS = "div[class='errorFull']>h4";
	    public static final String CARD_SEARCH = "input[id='lform:multipleFieldsSearch']";
	    public static final String ACCOUNT_DROP_DOWN = "lform:customer_mid";
	    public static final String TRANSACTION_COUNT = "tbody[id='lform:tabletransList:tb']>tr";
	   
//Added by NK for SHELL
	    public static final String CONTACT_NUM = "//input[@id='lform:phone_business']";
	    public static final String SHELL_CONTACT_NAME = "//input[@id='lform:contact_name']";
	    
	    //Added by Nithya 13/05/2020
	    public static final String LOGIN_FORM="//form[contains(@action,'login.xhtml')]";
}

