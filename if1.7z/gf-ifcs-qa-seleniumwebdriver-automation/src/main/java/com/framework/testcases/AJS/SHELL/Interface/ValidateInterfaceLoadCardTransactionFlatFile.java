package com.framework.testcases.AJS.SHELL.Interface;

import java.util.ArrayList;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.common.Common;
import com.framework.pages.AJS.common.IFCSCommonPage;
import com.framework.pages.AJS.common.IFCSHomePage;
import com.framework.pages.AJS.common.IFCSLoginPage;
import com.framework.pages.AJS.common.InterfacePage;

//import com.framework.pages.IFCS.common.CommonInterfacePage;

public class ValidateInterfaceLoadCardTransactionFlatFile extends BaseTest{
	
	@Parameters({ "clientCountry", "clientName" })	
	@Test(groups = { "Smoke" })	
	public void validateLoadCardTransactionFlatFromIE(@Optional("CZ") String clientCountry, @Optional("SHELL") String clientName)   {
		test = extent.createTest(clientName+ ":" +clientCountry+"  Load card transaction test case", "Load card transaction SHELL CZ");
	
        InterfacePage interfacePage = new InterfacePage(driver,test);
        IFCSLoginPage ifcsloginPage = new IFCSLoginPage(driver, test);
	    IFCSCommonPage ifcsCommonPage = new IFCSCommonPage(driver, test);
		IFCSHomePage ifcsHomePage = new IFCSHomePage(driver, test);		 
		Common common = new Common(driver, test);
		ArrayList<String> refNumberUpdated = new ArrayList<String>();
		
		refNumberUpdated = interfacePage.updateOrValidateFlatFile(loadcardflatconfigProp, "OutgoingFile", "IE_INPUTFILE_FOLDER_LOADCARDTRANSACTIONS","", clientName, clientCountry, "A01.CZ2.A40_20180803_101230.txt"); //"SHELL Czech Republic");
		
		if(!refNumberUpdated.contains("")) {
			String folderName = ifcsCommonPage.getControlMFolder(clientName, clientCountry, "jobS_TransProc");
			
			String jobsInOrder =  ifcsCommonPage.getJobsOfFolderInOrder("jobS_TransProc");
		   
			interfacePage.establishAndExecuteControlMJobs("ControlM_AWS_UAT","ContorlM_AWS_userName","ContorlM_AWS_password",folderName, jobsInOrder);
	
			 // Calling Functions
			ifcsloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");
		 	
			ifcsHomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);
			
			ifcsHomePage.gotoTansactionsAndClickManageTransaction();
			
			ifcsHomePage.chooseSubMenuFromLeftPanel("Client Transactions", "Transactions");
		    
		    ifcsHomePage.enterValueInTextBox("Transaction Filter Fields", "Reference No", refNumberUpdated.get(0));
		    
		    common.searchListTorch();
		    
		    common.validateSearchTable("Ref", refNumberUpdated.get(0), true);
		}
		else
		{
			System.out.println("Interface is not updated correctly");
		}
	 
	}

}
