﻿using Common;
using Common.Utility;
using NFluent;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Support.UI;
using System;

namespace EnCompass.Testing.Source.PageObjects.Organization.Payables.MerchantPayments
{
    [PageModel(@"/payables/merchantPayments/EditMerchant.aspx")]
    public partial class EditMerchant : EnCompassOrgPageModel
    {
        public override string RelativeUrl => @"/payables/merchantPayments/EditMerchant.aspx";
        public override string PageIdentifierXPath_Override => @"//li[@class='breadcrumb-item active'][normalize-space(text())='Edit Merchant' or normalize-space(text())='Create Merchant']";

        #region XPath page Elements
        private const string _merchantNameXPath = @"//input[contains(@id,'MerchantName')]";
        private const string _uniqueIDXPath = @"//input[contains(@name,'ltUniqueId')]";
        private const string _merchantCodeXPath = @"//input[contains(@id,'MerchantCode')]";
        private const string _phoneNumberXPath = @"//select[contains(@id,'PhoneNumber')]";
        private const string _phoneNumberTxtXPath = @"//input[contains(@id,'ctlPhoneNumber')]";
        private const string _countryXPath = @"//select[contains(@id,'ctlAddress_ctlCountry')]";
        private const string _addressLine1XPath = @"//input[contains(@id,'AddressLine1')]";
        private const string _addressLine2XPath = @"//input[contains(@id,'AddressLine2')]";
        private const string _cityXPath = @"//input[contains(@id,'City')]";
        private const string _emailXPath = @"//label[contains(@id,'lblEmailAddress')]//following-sibling::textarea[contains(@id,'contents_txtEmail')]";
        private const string _stateXPath = @"//select[contains(@id,'State')]";
        private const string _zipXPath = @"//input[contains(@id,'Zip')]";
        private const string _saveXPath = @"//input[contains(@id,'btnSubmit')]";
        private const string _taxPayerIdXPath = @"//input[contains(@id,'TaxPayerId')]";
        #endregion

        #region Page Elements
        private IWebElement _merchantName
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_merchantNameXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_merchantName element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _uniqueID
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_uniqueIDXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_uniqueID element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _merchantCode
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_merchantCodeXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_merchantCode element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _phoneNumber
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_phoneNumberXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_phoneNumber element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _phoneNumberTxt
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_phoneNumberTxtXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_phoneNumberTxt element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _country
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_countryXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_country element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _addressLine1
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_addressLine1XPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_addressLine1 element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _addressLine2
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_addressLine2XPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_addressLine2 element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _city
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_cityXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_city element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _email
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_emailXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_email element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _state
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_stateXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_state element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _zip
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_zipXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_zip element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _save
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_saveXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_save element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _taxPayerId
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_taxPayerIdXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_taxPayerId element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        #endregion

        public string TaxPayerID
        {
            get
            {
                return _taxPayerId.GetAttribute("value");
            }
        }

        public string MerchantName
        {
			get { return _merchantName.GetAttribute("value"); }
            set
            {
                _merchantName.Clear();
                _merchantName.JSSendKeys(Driver,value);
                Settings.EnCompassExtentTest.Info("Merchant Name: " + value);
            }
        }

        public string UniqueID
        {
            get
            {
                return _uniqueID.GetAttribute("value").Replace("\"","");
            }
        }

		public bool IsLastPaymentDateLabelPresent()
		{
			if(Driver.TryFindElement(By.XPath("//label[contains(@for, 'LastPaymentDate')][contains(text(), 'Last payment date')]"), out IWebElement element))
			{
				return true;
			}
			else
			{
				return false;
			}
		}

		public string LastPaymentDateValue()
		{
			if (Driver.TryFindElement(By.XPath("//input[contains(@id, 'LastPaymentDate')]"), out IWebElement element))
			{
				return element.GetAttribute("value");
			}
			else
			{
				return null;
			}
		}
        public string MerchantCode
        {
            get
            {
                return _merchantCode.GetAttribute("value");
            }
            set
            {
                _merchantCode.Clear();
                _merchantCode.SendKeys(value);
                Settings.EnCompassExtentTest.Info("Merchant Code: " + value);
            }
        }
        public string TaxPayerId
        {
            get
            {
                return _taxPayerId.GetAttribute("value");
            }
            set
            {
                _taxPayerId.Clear();
                _taxPayerId.SendKeys(value);
                Settings.EnCompassExtentTest.Info("TaxPyer Id: " + value);
            }
        }

        private const string _phoneNoDDLXpath = "//select[contains(@id,'ctlPhoneNumber_ddlCountry')]";
        public void PhoneNumberExt(string whichText)
        {   
			_phoneNumber.SetListboxByText(whichText, SelectTextOptions.Exact, Driver, Settings, _phoneNoDDLXpath);
			Settings.EnCompassExtentTest.Info("Selected PhoneNumber :" + whichText);
        }

        public string PhoneNumberTxt
        {
            set
            {
                _phoneNumberTxt.Clear();
                _phoneNumberTxt.SendKeys(value);
                Settings.EnCompassExtentTest.Info("Phone Number: " + value);
            }
        }
        
        public void Country(string whichText)
        {
            var selectElement = new SelectElement(_country);

            // Mobile specific change
            if (GlobalSettings.DeviceType.Equals(GlobalSettings.Device.MOBILE.ToString()))
                Driver.SelectDDLOptionByTextViaJS(Settings, _countryXPath, whichText);
            else
                selectElement.SelectByText(whichText);

            this.WaitForLoad();
            Settings.EnCompassExtentTest.Info("Selected Country :" + whichText);
        }

        public string AddressLine1
        {
            get { return _addressLine1.GetAttribute("value"); }

            set
            {
                _addressLine1.Clear();
                _addressLine1.JSSendKeys(Driver, value);
				Settings.EnCompassExtentTest.Info("Add Line 1 set to:" + value);
			}
        }

		public string AddressLine2
		{
			set
			{
				_addressLine2.Clear();
				_addressLine2.SendKeys(value);
				Settings.EnCompassExtentTest.Info("Add Line 2 set to:" + value);
			}
		}

		public string EmailAddress
		{
			get { return _email.GetAttribute("value"); }
			set
			{
				_email.Clear();
                //Email is entering wrong in IE so repplacing with js sendkeys
				_email.JSSendKeys(Driver,value);
				Settings.EnCompassExtentTest.Info("Email set to:" + value);
				Settings.Scenario["MerchantEmail"] = value;
				Settings.EnCompassExtentTest.Info("Storing MerchantEmail as:" + value);
			}
		}

        public string EditEmailAddress
        {
            get { return _email.GetAttribute("value"); }
            set
            {
                _email.SendKeys(value + ";");
                Settings.EnCompassExtentTest.Info("Email set to:" + value);
            }
        }

        public string City
        {
            get { return _city.GetAttribute("value"); }
            set
            {
                _city.ForceDocumentLoadOnSendKeys(value, Driver);
                Settings.EnCompassExtentTest.Info("City: " + value);
            }
        }

        public void State(string whichText)
        {
            var selectElement = new SelectElement(_state);

            // Mobile specific change
            if (GlobalSettings.DeviceType.Equals(GlobalSettings.Device.MOBILE.ToString()))
                Driver.SelectDDLOptionByTextViaJS(Settings, _stateXPath, whichText);
            else
                selectElement.SelectByText(whichText);

            Settings.EnCompassExtentTest.Info("State: " + selectElement.ToString());
        }

        public string StateProvinceOrTerritory
        {
            get => new SelectElement(_state).SelectedOption.Text;
            set => this.State(value);
        }

        public string Zip
        {
            get { return _zip.GetAttribute("value"); }
            set
            {
                this.RefreshModel();
                _zip.Clear();
                _zip.SendKeys(value);
				Settings.EnCompassExtentTest.Info("Zip set to:" + value);
			}
        }

        public void Save()
        {
            _save.JSClickWithFocus(Driver);
            Settings.EnCompassExtentTest.Info("Clicked on Save button");
			this.AttachOnDemandScreenShot();
		}
        public new string GetErrorMessages
        {
            get
            {
                return Settings.EnCompassWebDriver.WaitForVisible(By.XPath("//div[contains(@id,'_upValidationSummary')]//div[contains(@id,'ValidationSummary')]")).Text.Trim();
            }
        }

        public void GoToManagePaymentMethod()
        {            
            Settings.EnCompassWebDriver.WaitForVisible(By.XPath("//a[contains(@id,'_hlPaymentMethod')]")).JSClickWithFocus(Driver);
            Settings.EnCompassExtentTest.Info("Clicked on Payment Method button");
        }

		/// <summary>
		/// The values used below are used else where as well (File uploads etc)
		/// Please refrain from modifying them unless absolutely necessary
		/// </summary>
		public void EnterDefaultValuesOnCreateMerchantForm()
		{
			MerchantName = "Test_Merchant";
			Settings.Scenario["Merchant_Name"] = "Test_Merchant";
			Settings.Scenario["Merchant_Code"] = MerchantCode =  "00001";
            Settings.Scenario["Merchant_NameWithCode"] = "Test_Merchant (00001)";
            Settings.Scenario["Merchant_UniqueID"] = UniqueID;
            Settings.EnCompassExtentTest.Info("Saved Merchant Name/Code as : " + Settings.Scenario["Merchant_NameWithCode"].ToString());
			PhoneNumberExt("United States/Canada +1");
			PhoneNumberTxt = "1234567890";
			AddressLine1 = "123 Darling Ave";
			City = "South Portland";
			Country("United States");
			State("Maine");
			Zip = "04106";
		}

        public void EnterDefaultValuesOnCreateMerchantFormWhemMultipleMerchantsAreCreated(int i)
        {
            MerchantName = "Test_Merchant" + i;
            Settings.EnCompassExtentTest.Info("Created merchant with name: " + "Test_Merchant" + i);
            Settings.Scenario["Merchant_Name" + i] = "Test_Merchant" + i;
            MerchantCode = "0000" + i;
			Settings.Scenario["Merchant_Code" + i] = MerchantCode;
            Settings.Scenario["Merchant_NameWithCode" + i] = Settings.Scenario["Merchant_Name" + i].ToString() + " (" + Settings.Scenario["Merchant_Code" + i] .ToString() + ")";
            Settings.Scenario["Merchant_UniqueID" + i] = UniqueID;
            PhoneNumberExt("United States/Canada +1");
            PhoneNumberTxt = "1234567890";
            Country("United States");
            AddressLine1 = "123 Darling Ave";
            City = "South Portland";
            State("Maine");
            Zip = "04106";
            TaxPayerId = "123456789";
        }

        public void EnterValuesOnCreateMerchantForm(string merchantName, int i)
        {
            MerchantName = merchantName + "_Merchant";
            Settings.EnCompassExtentTest.Info("Set Merchant Name");
            MerchantCode = "0000" + i;
            Settings.EnCompassExtentTest.Info("Set Merchant Cod");
			PhoneNumberExt("United States/Canada +1");
			Settings.EnCompassExtentTest.Info("Set Merchant Phone Number");
            PhoneNumberTxt = "1234567890";
            Settings.EnCompassExtentTest.Info("Set Merchant Phone Number txt");
            Country("United States");
            Settings.EnCompassExtentTest.Info("Set Merchant Country");
            AddressLine1 = "123 Darling Ave";
            Settings.EnCompassExtentTest.Info("Set Merchant Address");
            City = "South Portland";
            Settings.EnCompassExtentTest.Info("Set Merchant City");
            State("Maine");
            Settings.EnCompassExtentTest.Info("Set Merchant State");
            Zip = "04106";
            Settings.EnCompassExtentTest.Info("Set Merchant Zip");
        }

        public void EnterMultipleDefaultValuesOnCreateMerchantPayMeSUGA(int i)
        {
            MerchantName = "PayMeSuga" + i;
            Settings.Scenario["Merchant_Name" + i] = "PayMeSuga" + i;
            MerchantCode = "PayMeSuga" + i;
            Settings.Scenario["Merchant_Code" + i] = MerchantCode;
            PhoneNumberExt("United States/Canada +1");
            PhoneNumberTxt = "1234567890";
            Country("United States");
            AddressLine1 = "123 Darling Ave";
            City = "South Portland";
            State("Maine");
            Zip = "04106";
        }
        public EditMerchant(GlobalSettings Settings) : base(Settings) { }
    }
}
