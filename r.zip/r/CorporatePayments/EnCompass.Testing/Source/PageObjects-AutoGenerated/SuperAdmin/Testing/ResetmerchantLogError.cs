using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using Common;
using Common.PageObjects;
using Common.ScenarioConfigurations;
using Common.Utility;

namespace EnCompass.Testing.Source.PageObjects.SuperAdmin.Testing 
{
	/// <summary>
	/// Auto-generated Page Model Class
	/// Navigation Paths: 
		/// [Organization Home]->General->Testing->Reset Merchant Log Error
		/// </summary>
	[PageModel(@"/superAdmin/testing/ResetmerchantLogError.aspx")]
	public partial class ResetmerchantLogError : EnCompassSuperPageModel 
	{
		public override string RelativeUrl => @"/superAdmin/testing/ResetmerchantLogError.aspx";
		public override string PageIdentifierXPath_Generated => @"//li[contains(@class, 'breadcrumb-item active')][text() = 'Reset Merchant Log Error']";

		#region Navigation
				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Create Organization']")]
		private IWebElement _general_Testing_ResetMerchantLogError_CreateOrganization { get; set; }
		public void NavigateTo_General_Testing_ResetMerchantLogError_CreateOrganization()
		{
			NavigateToMenuItem(_general_Testing_ResetMerchantLogError_CreateOrganization);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Create Organization Profile']")]
		private IWebElement _general_Testing_ResetMerchantLogError_CreateOrganizationProfile { get; set; }
		public void NavigateTo_General_Testing_ResetMerchantLogError_CreateOrganizationProfile()
		{
			NavigateToMenuItem(_general_Testing_ResetMerchantLogError_CreateOrganizationProfile);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Delete Test Organization']")]
		private IWebElement _general_Testing_ResetMerchantLogError_DeleteTestOrganization { get; set; }
		public void NavigateTo_General_Testing_ResetMerchantLogError_DeleteTestOrganization()
		{
			NavigateToMenuItem(_general_Testing_ResetMerchantLogError_DeleteTestOrganization);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Create Test Company']")]
		private IWebElement _general_Testing_ResetMerchantLogError_CreateTestCompany { get; set; }
		public void NavigateTo_General_Testing_ResetMerchantLogError_CreateTestCompany()
		{
			NavigateToMenuItem(_general_Testing_ResetMerchantLogError_CreateTestCompany);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Corporate Credit Limit']")]
		private IWebElement _general_Testing_ResetMerchantLogError_CorporateCreditLimit { get; set; }
		public void NavigateTo_General_Testing_ResetMerchantLogError_CorporateCreditLimit()
		{
			NavigateToMenuItem(_general_Testing_ResetMerchantLogError_CorporateCreditLimit);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Create Bounce Notification']")]
		private IWebElement _general_Testing_ResetMerchantLogError_CreateBounceNotification { get; set; }
		public void NavigateTo_General_Testing_ResetMerchantLogError_CreateBounceNotification()
		{
			NavigateToMenuItem(_general_Testing_ResetMerchantLogError_CreateBounceNotification);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Reset Merchant Log Error']")]
		private IWebElement _general_Testing_ResetMerchantLogError_ResetMerchantLogError { get; set; }
		public void NavigateTo_General_Testing_ResetMerchantLogError_ResetMerchantLogError()
		{
			NavigateToMenuItem(_general_Testing_ResetMerchantLogError_ResetMerchantLogError);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Performance']")]
		private IWebElement _general_Testing_ResetMerchantLogError_Performance { get; set; }
		public void NavigateTo_General_Testing_ResetMerchantLogError_Performance()
		{
			NavigateToMenuItem(_general_Testing_ResetMerchantLogError_Performance);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='AP Non-Card Payments Testing']")]
		private IWebElement _general_Testing_ResetMerchantLogError_ApNonCardPaymentsTesting { get; set; }
		public void NavigateTo_General_Testing_ResetMerchantLogError_ApNonCardPaymentsTesting()
		{
			NavigateToMenuItem(_general_Testing_ResetMerchantLogError_ApNonCardPaymentsTesting);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Modify Merchant Log']")]
		private IWebElement _general_Testing_ResetMerchantLogError_ModifyMerchantLog { get; set; }
		public void NavigateTo_General_Testing_ResetMerchantLogError_ModifyMerchantLog()
		{
			NavigateToMenuItem(_general_Testing_ResetMerchantLogError_ModifyMerchantLog);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Test Templates']")]
		private IWebElement _general_Testing_ResetMerchantLogError_TestTemplates { get; set; }
		public void NavigateTo_General_Testing_ResetMerchantLogError_TestTemplates()
		{
			NavigateToMenuItem(_general_Testing_ResetMerchantLogError_TestTemplates);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Create Test Statements']")]
		private IWebElement _general_Testing_ResetMerchantLogError_CreateTestStatements { get; set; }
		public void NavigateTo_General_Testing_ResetMerchantLogError_CreateTestStatements()
		{
			NavigateToMenuItem(_general_Testing_ResetMerchantLogError_CreateTestStatements);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Contact Us']")]
		private IWebElement _general_Testing_ResetMerchantLogError_ContactUs { get; set; }
		public void NavigateTo_General_Testing_ResetMerchantLogError_ContactUs()
		{
			NavigateToMenuItem(_general_Testing_ResetMerchantLogError_ContactUs);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Dispute Transaction']")]
		private IWebElement _general_Testing_ResetMerchantLogError_DisputeTransaction { get; set; }
		public void NavigateTo_General_Testing_ResetMerchantLogError_DisputeTransaction()
		{
			NavigateToMenuItem(_general_Testing_ResetMerchantLogError_DisputeTransaction);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Terms and Conditions']")]
		private IWebElement _general_Testing_ResetMerchantLogError_TermsAndConditions { get; set; }
		public void NavigateTo_General_Testing_ResetMerchantLogError_TermsAndConditions()
		{
			NavigateToMenuItem(_general_Testing_ResetMerchantLogError_TermsAndConditions);
		}

		
		private void NavigateToMenuItem(IWebElement element)
		{
			Driver.Url = element.GetAttribute("href");
		}
		#endregion

		public ResetmerchantLogError(GlobalSettings settings) : base(settings) { }
	}  
}
