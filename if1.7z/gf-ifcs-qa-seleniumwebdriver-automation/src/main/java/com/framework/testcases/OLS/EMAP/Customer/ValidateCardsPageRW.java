package com.framework.testcases.OLS.EMAP.Customer;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.EMAP.EMAPCardsPage;
import com.framework.pages.EMAP.EMAPHomePage;
import com.framework.pages.OLS.common.CommonPage;
import com.framework.pages.OLS.common.FindAndUpdateCardPage;
import com.framework.pages.OLS.common.LoginPage;

public class ValidateCardsPageRW extends BaseTest {
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "Regression" })
	public void validateCardsMenuOrderViewAndEditCard(@Optional("SP") String clientCountry,
			@Optional("EMAP") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  TST-SC-79-OLS - cards menu,TST-SC-99-OLS-Bulk Card Upload,TST-SC-98-OLS-Bulk Card Download,TST-SC-93-OLS-Card List-Edit Card,TST-SC-92-OLS-Card List-View Card",
				"Login to EMAP Customer - Read Write - Order, View and Edit Card");
		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		loginPage.Login("EMAP_URL", "EMAP_UN_ReadWrite_Customer_" + clientCountry,
				"EMAP_PWD_ReadWrite_Customer_" + clientCountry, clientName);
		EMAPHomePage emapHomePage = new EMAPHomePage(driver, test);
		EMAPCardsPage emapCardsPage = new EMAPCardsPage(driver, test);
		CommonPage commonPage = new CommonPage(driver, test);
		emapHomePage.validateEMAPCustomerLogo();
		emapHomePage.validateCustomerWelcomeText();

		emapCardsPage.checkThePresenceOfSubmenuItemsInCardsMenu("Read-Write");

		// Order Card - WBPT - 21226
		emapHomePage.clickOrderCardAndValidatePage();
		emapCardsPage.verifySubCategoriesOnViewCardPage("Order Card");
		 emapCardsPage.enterAllMandotoryFieldsForOrderingCard(); ////- No Card Offer for
		// MACAU
		 emapCardsPage.clickOrderCardAndValidateSuccessMsg(); //- WBPT - 21226

		// Card List
		emapHomePage.clickCardListAndValidatePage();
		emapCardsPage.checkThePresenceOfExportCardOption();
		emapCardsPage.checkThePresenceOfSearchCardButton();
		commonPage.selectAllAccountOptionFromAccountDropdown();
		commonPage.clickSearchButton();
		emapCardsPage.verifyTheListOfCardsFoundTableColumn(clientCountry);
		emapCardsPage.checkThePresenceOfCardFilterCriteria(clientCountry);

		// Context menu options - View Card
		emapHomePage.clickCardListAndValidatePage();
		commonPage.selectAllAccountOptionFromAccountDropdown();
		if (clientCountry.equals("MO")) {
			emapCardsPage.selectFleetCardFromCardProduct();
		}
		commonPage.clickSearchButton();
		if (emapCardsPage.isCardsPresent()) {
			emapCardsPage.selectACardFromCardListTable(true);
			emapCardsPage.clickContextMenuOptionAndVerifyCardNumberInNavigatedPage("View Card");
			emapCardsPage.verifySubCategoriesOnViewCardPage("View Card");
			emapCardsPage.verifyTheCardDetailsAreInViewMode(clientCountry);
			emapCardsPage.verifyTheVelocityControlFieldValues();

			emapCardsPage.validateBackToCardListPageLink();
		}
		// Context menu options - Edit Card
		emapHomePage.clickCardListAndValidatePage();
		commonPage.selectAllAccountOptionFromAccountDropdown();
		if (clientCountry.equals("MO")) {
			emapCardsPage.selectFleetCardFromCardProduct();
		}
		emapCardsPage.selectACardStatus("Active");
		commonPage.clickSearchButton();
		if (emapCardsPage.isCardsPresent()) {
			emapCardsPage.selectACardFromCardListTable(true);

			emapCardsPage.clickContextMenuOptionAndVerifyCardNumberInNavigatedPage("Edit Card");
			emapCardsPage.verifySubCategoriesOnViewCardPage("Edit Card");
			emapCardsPage.checkThePresenceOfVelocityControlListPDFAndXLS();

			emapCardsPage.validateBackToCardListPageLink();
		}

		/*// Bulk Card Order
		emapHomePage.clickBulkCardOrderAndValidatePage();
		emapCardsPage.checkThePresenceOfBulkCardOrderDownloadAndUpload("Read-Write");

		// Bulk Card Update
		emapHomePage.clickBulkCardUpdateAndValidatePage();
		emapCardsPage.checkThePresenceOfBulkCardUpdateDownloadAndUpload();*/

		loginPage.Logout();
	}

	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "Regression" }, enabled = true)
	public void validateCardsMenuChangeCardPINAndStatusAndResendPIN(@Optional("SP") String clientCountry,
			@Optional("EMAP") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  TST-SC-95-OLS-Card List-Change Pin,TST-SC-94-OLS-Card List-Change Status",
				"Login to EMAP Customer - Read Write -  Change Card Status, Change PIN and Resend PIN");
		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		loginPage.Login("EMAP_URL", "EMAP_UN_ReadWrite_Customer_" + clientCountry,
				"EMAP_PWD_ReadWrite_Customer_" + clientCountry, clientName);
		EMAPHomePage emapHomePage = new EMAPHomePage(driver, test);
		EMAPCardsPage emapCardsPage = new EMAPCardsPage(driver, test);
		FindAndUpdateCardPage findCardPage = new FindAndUpdateCardPage(driver, test);
		CommonPage commonPage = new CommonPage(driver, test);
		emapHomePage.validateEMAPCustomerLogo();
		emapHomePage.validateCustomerWelcomeText();

		emapCardsPage.checkThePresenceOfSubmenuItemsInCardsMenu("Read-Write");

		emapHomePage.clickCardListAndValidatePage();
		commonPage.selectAllAccountOptionFromAccountDropdown();
		// Context menu options - Change Status - Past begin date
		emapCardsPage.selectACardStatus("Active");
		commonPage.clickSearchButton();
		if (emapCardsPage.isCardsPresent())

		{
			emapCardsPage.selectACardFromCardListTable(true);
			emapCardsPage.clickContextMenuOptionAndVerifyCardNumberInNavigatedPage("Change Card Status");
			emapCardsPage.chooseANewCardStatus("Lost");
	        emapCardsPage.enterADateValueInStatusBeginDateField("Past", clientName + clientCountry);
			emapCardsPage.clickSaveStatusChange();
			emapCardsPage.verifyErrorMessageForInvalidBeginDate();
			emapCardsPage.validateBackToCardListPageLink();
		}

		emapHomePage.clickCardListAndValidatePage();
		commonPage.selectAllAccountOptionFromAccountDropdown();
		// Context menu options - Change Status - Future begin date
		emapCardsPage.selectACardStatus("Active");
		commonPage.clickSearchButton();
		if (emapCardsPage.isCardsPresent()) {
			emapCardsPage.selectACardFromCardListTable(true);
			emapCardsPage.clickContextMenuOptionAndVerifyCardNumberInNavigatedPage("Change Card Status");
			emapCardsPage.chooseANewCardStatus("Lost");
			emapCardsPage.checkStatusHistoryTable();
			emapCardsPage.enterADateValueInStatusBeginDateField("Future", clientName + clientCountry);
			emapCardsPage.clickSaveStatusChange();
			emapCardsPage.checkReplaceCardPopupContent("Lost");
			emapCardsPage.verifyCardStatusChangedSuccessMessage("Lost");
			emapCardsPage.validateBackToCardListPageLink();
		}
		// Context menu options - Change Status - Future begin date
		emapHomePage.clickCardListAndValidatePage();
		commonPage.selectAllAccountOptionFromAccountDropdown();
		emapCardsPage.selectACardStatus("Active");
		commonPage.clickSearchButton();
		if (emapCardsPage.isCardsPresent()) {
			emapCardsPage.selectACardFromCardListTable(true);
			emapCardsPage.clickContextMenuOptionAndVerifyCardNumberInNavigatedPage("Change Card Status");
			emapCardsPage.chooseANewCardStatus("Stolen");
			emapCardsPage.checkStatusHistoryTable();
			emapCardsPage.enterADateValueInStatusBeginDateField("Current", clientName + clientCountry);
			emapCardsPage.clickSaveStatusChange();
			emapCardsPage.checkReplaceCardPopupContent("Stolen");
			emapCardsPage.verifyCardStatusChangedSuccessMessage("Stolen");
			emapCardsPage.validateBackToCardListPageLink();
		}

		// Change PIN - WBPT - 21227
		// Context menu options - ChangePin
		emapHomePage.clickCardListAndValidatePage();
		commonPage.selectAllAccountOptionFromAccountDropdown();
		emapCardsPage.selectACardStatus("Active");
		if (clientCountry.equals("MO")) {
			// emapCardsPage.selectFleetCardFromCardProduct();
		}
		commonPage.clickSearchButton();
		if (emapCardsPage.isCardsPresent()) {
			// Select Card with PIN - card number chosen
			String cardNumberChoosen = emapCardsPage.selectACardWithPINFromCardListTable("Change PIN");
			findCardPage.getPINValuesFromDB(cardNumberChoosen);
			commonPage.typeNewPin();
			commonPage.typeconfirmPIN();
			// Save Change Button
			emapCardsPage.clickSaveNewPIN();
			findCardPage.comparePINValues("Change PIN", cardNumberChoosen);
		}

		// Resend PIN
		// Context menu options - Resend PIN
		emapHomePage.clickCardListAndValidatePage();
		commonPage.selectAllAccountOptionFromAccountDropdown();
		emapCardsPage.selectACardStatus("Active");
		commonPage.clickSearchButton();
		if (emapCardsPage.isCardsPresent()) {
			emapCardsPage.selectACardWithPINFromCardListTable("Resend PIN");
			emapCardsPage.validateBackToCardListPageLink();
		//}
		loginPage.Logout();
	}

}
}
