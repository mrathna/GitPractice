package com.framework.testcases.OLS.BP.Customer;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.BP.BPHomePage;
import com.framework.pages.OLS.HomePage;
import com.framework.pages.OLS.common.LoginPage;

public class ValidateHomePageHeaderFooter extends BaseTest {
	@Parameters({"clientCountry","clientName"})
	@Test( groups = { "Smoke", "Regression" })
	public void Login_HomePage_Validate_Header_Footer(@Optional("AU") String clientCountry, @Optional("BP") String clientName)  {
		test = extent.createTest(clientName+ ":" +clientCountry+"  16 Home Page & Header and Footer Validations",
				"Logging in to BP Online, validate header and footer and Log Out from Homepage");

        //Creating Objects for the Pages
        LoginPage loginPage = new LoginPage(driver, test);
        BPHomePage bpHomePage = new BPHomePage(driver, test);
        HomePage homePage = new HomePage(driver, test);

		// Calling Functions
		loginPage.Login("BP_URL", "BP_UN_Customer_" + clientCountry, "BP_PWD_Customer_" + clientCountry, clientName);
		bpHomePage.ValidateBPCustomerLogo();
		bpHomePage.ValidateCustomerWelcomeText();
		homePage.ValidateLogoutLink();
		homePage.ValidateHelpLink();
		homePage.HomePageValidation();
		homePage.ValidateCardsMenu();
		bpHomePage.clickAccountsDetailsAndValidate();
		if(clientCountry.equals("AU"))
		{
			bpHomePage.ValidatePaymentsMenu();
		}
		bpHomePage.ValidationOfHomePageMenusNavigation(clientCountry);
		bpHomePage.validateFooterLinksNavigation(clientCountry);
		bpHomePage.clickFooterHomeandValidate();
		
		loginPage.Logout();
		
		}
}
