using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using Common;
using Common.PageObjects;
using Common.ScenarioConfigurations;
using Common.Utility;

namespace EnCompass.Testing.Source.PageObjects.Organization.ExpenseManager.Transactions 
{
	/// <summary>
	/// Auto-generated Page Model Class
	/// Navigation Paths: 
		/// [Organization Home]->Transactions->Statements
		/// </summary>
	[PageModel(@"/expenseManager/transactions/selectCard.aspx")]
	public partial class SelectCard : EnCompassOrgPageModel 
	{
		public override string RelativeUrl => @"/expenseManager/transactions/selectCard.aspx";
		public override string PageIdentifierXPath_Generated => @"//li[contains(@class, 'breadcrumb-item active')][text() = 'Statements']";

		#region Navigation
		
		private void NavigateToMenuItem(IWebElement element)
		{
			Driver.Url = element.GetAttribute("href");
		}
		#endregion

		public SelectCard(GlobalSettings settings) : base(settings) { }
	}  
}
