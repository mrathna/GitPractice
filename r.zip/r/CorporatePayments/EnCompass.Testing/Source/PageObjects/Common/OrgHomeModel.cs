﻿using Common;
using Common.Utility;
using EnCompass.Testing.Source.PageObjects.Organization;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using TechTalk.SpecFlow;
using System.Text.RegularExpressions;
using OpenQA.Selenium.Support.Extensions;
using NFluent;
using EnCompass.Testing.Source.PageObjects.Controls;

namespace EnCompass.Testing.Source.PageObjects.Common
{
	[PageModel(@"/startup.aspx")]
	public class OrgHomeModel : EnCompassOrgPageModel
	{
        #region Page Objects xpath

        public override string RelativeUrl => "/startup.aspx";
        public override string PageIdentifierXPath_Override => "(//div[contains(@id,'WidgetUpdatePanel')])[1]"; // Checking the Announcements widget.

        private const string _securityMenuXPath = @"//*[@id='securityManagerMenuHref']";
        private const string _securityPolicyMenuXPath = @"//a[contains(@id,'SecurityPolicy')]";
        private const string _accountDropDownXPath = @"//a[contains(@id,'accountDropdown')]";
        private const string _inboxMailboxDropDownXPath = @"//a[contains(@id,'lnkInbox')]";
        private const string _inboxItemMailboxXPath = @"//a[normalize-space(text())='Messages']//span";
        private const string _transactionWorkflowLinkXPath = @"//a[contains(@id, 'transactionWorkflowLink')]";
        private const string _summaryXPath = @"//caption[normalize-space(text()) ='Summary']";
        private const string _creditLineWidgetXPath = @"//div[contains(@class,'bx-content')]//span[text()='Credit Line']";
        private const string _creditLineHeaderLabelXPath = @"//span[contains(@id,'TitleText')][text()='Credit Line']";
        private const string _summaryGroupXPath = @"//th[contains(text(),'Summary')]/../../..";
        private const string _currentSpendGroupXPath = @"//caption[normalize-space(text()) ='Current Spend']";
        private const string _lastUpdatedTextXPath = @"//span[contains(@id,'LabelDate')]";
        private const string _refreshLinkXPath = @"//a[contains(@id,'LinkButtonRefresh')]";
        private const string _refreshGifXPath = @"//div[contains(@style,' loader.gif')]";
        private const string _gcmListBoxXPath = @"//select[contains(@id,'GroupDropDownList')]";
        private const string _creditLimitSummaryXPath = @"//tbody/tr/th[normalize-space(text()) = 'Credit Limit']//following-sibling::td";
        private const string _avaCreditSummaryXPath = @"//tbody/tr/th[normalize-space(text()) = 'Available Credit']//following-sibling::td";
        private const string _precentAvaSummaryXPath = @"//tbody/tr/th[normalize-space(text()) = 'Percent Available']//following-sibling::td";
        private const string _loadingOverLayXPath = @"//div[@class='loadingoverlay']";
        private const string _adminToolsXPath = @"//span[normalize-space(text())='Admin Tools']";
        private const string _passwordExpirationNOXPath = @"//input[contains(@id, 'passwordExpR_btnNo')]";
        private const string _quickLinksWidgetXPath = @".//h2[contains(@class,'card-title') and normalize-space(text())='Quick Links']//..//..//..";
        private const string _transactionsXPath = @".//h2[contains(@class,'card-title') and normalize-space(text())='Quick Links']//..//following-sibling::div[1]//ul[@id='QuickLinksWidgetMain']//a[contains(@id,'ManageMyTransactions')]";
        private const string _unreviewedTransactionsXPath = @".//h2[contains(@class,'card-title') and normalize-space(text())='Quick Links']//..//following-sibling::div[1]//ul[@id='QuickLinksWidgetMain']//a[contains(@id,'UnreviewedTransactionsLink')]";
        private const string _createTransactionEnvelopeXPath = @".//h2[contains(@class,'card-title') and normalize-space(text())='Quick Links']//..//following-sibling::div[1]//ul[@id='QuickLinksWidgetMain']//a[contains(@id,'TransactionEnvelope')]";
        private const string _viewStatementsXPath = @".//h2[contains(@class,'card-title') and normalize-space(text())='Quick Links']//..//following-sibling::div[1]//ul[@id='QuickLinksWidgetMain']//a[contains(@id,'Statement')]";
        private const string _recentActivityXPath = @".//h2[contains(@class,'card-title') and normalize-space(text())='Quick Links']//..//following-sibling::div[1]//ul[@id='QuickLinksWidgetMain']//a[contains(@id,'RecentActivity')]";
        private const string _purchaseLogsXPath = @".//h2[contains(@class,'card-title') and normalize-space(text())='Quick Links']//..//following-sibling::div[1]//ul[@id='QuickLinksWidgetMain']//a[contains(@id,'ManagePurchaseLogs')]";
        private const string _loginCredentialsXPath = @".//h2[contains(@class,'card-title') and normalize-space(text())='Quick Links']//..//following-sibling::div[1]//ul[@id='QuickLinksWidgetMain']//a[contains(@id,'ChangePassword')]";
        private const string _widgetBodyInfoDiv2 = @"//div[contains(@id, 'widgetBody_infoDiv')]/table[2]/tbody/tr/td/..";
        private const string _widgetBodyInfoDiv3 = @"//div[contains(@id, 'widgetBody_infoDiv')]/table[3]/tbody/tr/td/..";
        private const string _createAnnouncementBtnXPath = "//a[contains(@id,'manageLink')][contains(text(),'Create')]";
        private const string _announcementsXPath = "//p[text()='There are no announcements.']";
        #endregion

        #region IwebElements Props

        public IWebElement _securityMenu
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_securityMenuXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Debug("Found _securityMenu");
                return element;
            }
        }

        public IWebElement _securityPolicyMenu
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_securityPolicyMenuXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Debug("Found _securityPolicyMenu");
                return element;
            }
        }

        public IWebElement _creditLineWidget
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_creditLineWidgetXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Debug("Found _creditLineWidget");
                return element;
            }
        }

        public IWebElement _creditLineHeaderLabel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_creditLineHeaderLabelXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Debug("Found _creditLineHeaderLabel");
                return element;
            }
        }

        public IWebElement _summaryGroup
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_summaryGroupXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Debug("Found _summaryGroup");
                return element;
            }
        }

        public IWebElement _currentSpendGroup
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_currentSpendGroupXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Debug("Found _currentSpendGroup");
                return element;
            }
        }

        public IWebElement _lastUpdatedText
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_lastUpdatedTextXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Debug("Found _lastUpdatedText");
                return element;
            }
        }

        public IWebElement _refreshLink
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_refreshLinkXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Debug("Found _refreshLink");
                return element;
            }
        }

        public IWebElement _refreshGif
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_refreshGifXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Debug("Found _refreshGif");
                return element;
            }
        }

        public IWebElement _gcmListBox
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_gcmListBoxXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Debug("Found _gcmListBox");
                return element;
            }
        }

        public IWebElement _creditLimitSummary
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_creditLimitSummaryXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Debug("Found _creditLimitSummary");
                return element;
            }
        }

        public IWebElement _avaCreditSummary
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_avaCreditSummaryXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Debug("Found _avaCreditSummary");
                return element;
            }
        }

        public IWebElement _precentAvaSummary
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_precentAvaSummaryXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Debug("Found _precentAvaSummary");
                return element;
            }
        }

        public IWebElement _loadingOverLay
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_loadingOverLayXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Debug("Found _loadingOverLay");
                return element;
            }
        }

        public IWebElement _adminTools
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_adminToolsXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Debug("Found _adminTools");
                return element;
            }
        }

        public IWebElement _accountDropDown
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_accountDropDownXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Debug("Found _accountDropDown");
                return element;
            }
        }

        public IWebElement _inboxMailboxDropDown
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_inboxMailboxDropDownXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Debug("Found _inboxMailboxDropDown");
                return element;
            }
        }

        public IWebElement _inboxItemMailbox
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_inboxItemMailboxXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Debug("Found _inboxItemMailbox");
                return element;
            }
        }

        public IWebElement _transactionWorkflowLink
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_transactionWorkflowLinkXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Debug("Found _transactionWorkflowLink");
                return element;
            }
        }

        public IWebElement _quickLinksWidget
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_quickLinksWidgetXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Debug("Found _quickLinksWidget");
                return element;
            }
        }

        public IWebElement _transactions
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_transactionsXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Debug("Found _transactions");
                return element;
            }
        }

        public IWebElement _unreviewedTransactions
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_unreviewedTransactionsXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Debug("Found _unreviewedTransactions");
                return element;
            }
        }

        public IWebElement _createTransactionEnvelope
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_createTransactionEnvelopeXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Debug("Found _createTransactionEnvelope");
                return element;
            }
        }

        public IWebElement _viewStatements
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_viewStatementsXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Debug("Found _viewStatements");
                return element;
            }
        }

        public IWebElement _recentActivity
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_recentActivityXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Debug("Found _recentActivity");
                return element;
            }
        }

        public IWebElement _purchaseLogs
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_purchaseLogsXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Debug("Found _purchaseLogs");
                return element;
            }
        }

        public IWebElement _loginCredentials
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_loginCredentialsXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Debug("Found _loginCredentials");
                return element;
            }
        }

        public IWebElement _passwordExpirationNO
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_passwordExpirationNOXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Debug("Found _passwordExpirationNO");
                return element;
            }
        }

        private IWebElement _createAnnouncementBtn
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_createAnnouncementBtnXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_createAnnouncementBtn element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        #endregion

        public string LastUpdatedText => _lastUpdatedText.Text;


		#region All Widgets

		private static string _accPayableWidgetTitleXpath = ".//h2[contains(@class,'card-title') and normalize-space(text())='Accounts Payable']";
		public string AccountPayableWidgetTitleText
		{
			get
			{
				Check.That(Driver.TryWaitForElementToBeVisible(By.XPath(_accPayableWidgetTitleXpath), out IWebElement accPayableWidTitle)).IsTrue();
				return accPayableWidTitle.Text;
			}
		}

		private string _apWidgetShowMoreXpath = _accPayableWidgetTitleXpath + "//..//following-sibling::div/a";
		private string _apWidgetTileDecks = _accPayableWidgetTitleXpath + "//..//following-sibling::div//div[contains(@class,'card-deck tile-deck')]";
		public void VerifyAPWidget()
		{
			Check.That(Driver.TryWaitForElementToBeVisible(By.XPath(_apWidgetShowMoreXpath), out IWebElement apWidgetShowMore)).IsTrue();
			apWidgetShowMore.JSClickWithFocus(Driver);
			Settings.EnCompassExtentTest.Info("Clicked on Show More link of AP widget");
			this.WaitForFormLoadingOverlay();
			// Verify there are 4 card tiles under AP
			Check.That(Driver.WaitForElementsToBeVisible(By.XPath(_apWidgetTileDecks)).Count()).IsStrictlyGreaterThan(1);
			Settings.EnCompassExtentTest.Info("Verified AP Widget has loaded properly");
		}

		private static string _plogWidgetTitleXpath = ".//h2[contains(@class,'card-title') and normalize-space(text())='Purchase Log']";
		public string PLogWidgetTitleText
		{
			get
			{
				Check.That(Driver.TryWaitForElementToBeVisible(By.XPath(_plogWidgetTitleXpath), out IWebElement plogWidTitle)).IsTrue();
				return plogWidTitle.Text;
			}
		}

		private string _plogWidgetShowMoreXpath = _plogWidgetTitleXpath + "//..//following-sibling::div/a";
		private string _plogWidgetTileDecks = _plogWidgetTitleXpath + "//..//following-sibling::div//div[contains(@class,'card-deck tile-deck')]";
		public void VerifyPLogWidget()
		{
			Check.That(Driver.TryWaitForElementToBeVisible(By.XPath(_plogWidgetShowMoreXpath), out IWebElement plogWidgetShowMore)).IsTrue();
			plogWidgetShowMore.JSClickWithFocus(Driver);
			Settings.EnCompassExtentTest.Info("Clicked on Show More link of PLog widget");
			this.WaitForFormLoadingOverlay();
			// Verify there are 2 card tiles under Plog
			Check.That(Driver.WaitForElementsToBeVisible(By.XPath(_plogWidgetTileDecks)).Count()).IsStrictlyGreaterThan(1);
			Settings.EnCompassExtentTest.Info("Verified Plog Widget has loaded properly");
		}

		private string _creditLineWidgetTitleXpath = ".//h2[contains(@class,'card-title') and normalize-space(text())='Credit Line']";
		public string CreditLineWidgetTitleText
		{
			get
			{
				Check.That(Driver.TryWaitForElementToBeVisible(By.XPath(_creditLineWidgetTitleXpath), out IWebElement cdtLineWidTitle)).IsTrue();
				return cdtLineWidTitle.Text;
			}
		}

		private static string _cardholderWidgetTitleXpath = ".//h2[contains(@class,'card-title') and normalize-space(text())='Cardholder']";
		public string CardholderWidgetTitleText
		{
			get
			{
				Check.That(Driver.TryWaitForElementToBeVisible(By.XPath(_cardholderWidgetTitleXpath), out IWebElement crdHolderWidTitle)).IsTrue();
				return crdHolderWidTitle.Text;
			}
		}

		public GridControl TransactionsGrid
		{
			get
			{
				// Mark here - we cannot use Wait FOr Grid for this table as the header row xpath 
				// does not work due to thead element absent in this table
				return new GridControl("gridTransactions", Settings.EnCompassWebDriver);
			}
		}

        private static string _cardholderWidgetShowMoreXpath = _cardholderWidgetTitleXpath + "//..//following-sibling::div//a[text()='Show More']";
        private string _cardholderWidgetTileDecks = _cardholderWidgetTitleXpath + "//..//following-sibling::div//div[contains(@class,'card-deck tile-deck')]";
        public void VerifyCardholderWidget()
		{
			Check.That(Driver.TryWaitForElementToBeVisible(By.XPath(_cardholderWidgetShowMoreXpath), out IWebElement cholderWidgetShowMore)).IsTrue();
			cholderWidgetShowMore.JSClickWithFocus(Driver);
			Settings.EnCompassExtentTest.Info("Clicked on Show More link of Cardholder widget");
			this.WaitForFormLoadingOverlay();
            bool isElementPresent = Driver.TryWaitForElements(By.XPath(_cardholderWidgetTileDecks),out IList<IWebElement> elements);
            Check.That(isElementPresent).IsTrue();
            Check.That(elements.Count()).IsStrictlyGreaterThan(0);
            Settings.EnCompassExtentTest.Info("Verified Cardholder Widget has > 0 Tile Decks");
			Settings.EnCompassExtentTest.Info("Verified Cardholder Widget has loaded properly");
		}

		#endregion

		#region Announcement Widget

        public bool IsNoAnnouncementSectionPresent()
        {
            Driver.TryWaitForElementToBeVisible(By.XPath(_announcementsXPath), out IWebElement element);
            return element.Displayed;
        }
        public void ClickCreateAnnouncement()
        {
            _createAnnouncementBtn.JSClickWithFocus(Driver);
            Settings.EnCompassExtentTest.Info("Clicked create button");
        }

        private string _widgetPanel = "//div[contains(@id,'WidgetUpdatePanel')]//div[@class='card-body']//div[contains(@id,'newAnnouncementPanel')]/div";
        public string GetAnnouncementTitle(int i)
        {
            return Driver.FindElement(By.XPath(_widgetPanel + "[" + i + "]/h3")).Text;
        }

		private string _allAccouncementsWidgetPanel = "//div[contains(@id,'WidgetUpdatePanel')]//div[@class='card-body']//div[contains(@id,'newAnnouncementPanel') and contains(@aria-labelledby,'newAnnouncementPanel_Tab')]";
		public string GetAllAnnouncementsTitleAndBody()
		{
            Driver.TryWaitForElementToBeVisible(By.XPath(_allAccouncementsWidgetPanel), out IWebElement element);

			return element.Text;
		}

		public bool IsTitlePresent(int index, string titlename)
        {
            try
            {
                bool titlepresence = Driver.IsElementPresent(By.XPath(_widgetPanel + "[" + index + "]/h3[contains(text(),'" + titlename + "')]"));
                return titlepresence;
            }
            catch(Exception)
            {
                return false;
            }            
        }

        public string GetAnnouncementBody(int i)
        {
            return Driver.FindElement(By.XPath(_widgetPanel + "[" + i + "]/div/p")).Text;
        }

        public bool ExclamationSymbol(int i)
        {
            return Driver.FindElement(By.XPath(_widgetPanel + "[" + i + "]//i[contains(@class,'text-danger')]")).Displayed;
        }
        #endregion

		public void SelectApproveWorkflowTransaction()
        {
            _transactionWorkflowLink.WaitUntilElementIsInteractable();
            _transactionWorkflowLink.JSClickWithFocus(Driver);
        }

		public string InboxItemMailbox
		{
			get
			{
				return _inboxItemMailbox.GetAttribute("textContent");
			}
		}

		public void ClickTransactions()
		{
			_transactions.JSClickWithFocus(Driver);
			Settings.EnCompassExtentTest.Info("Clicked on Transaction Quick Link");
		}

		public void ClickUnreviewedTransactions()
		{
			_unreviewedTransactions.JSClickWithFocus(Driver);
			Settings.EnCompassExtentTest.Info("Clicked on UnreviewedTransactions Quick Link");
		}

		public void ClickCreateTransactionEnvelope()
		{
			_createTransactionEnvelope.JSClickWithFocus(Driver);
			Settings.EnCompassExtentTest.Info("Clicked on CreateTransactionEnvelope Quick Link");
		}

		public void ClickViewStatements()
		{
			_viewStatements.JSClickWithFocus(Driver);
			Settings.EnCompassExtentTest.Info("Clicked on ViewStatements Quick Link");
		}

		public void ClickRecentActivity()
		{
			_recentActivity.JSClickWithFocus(Driver);
			Settings.EnCompassExtentTest.Info("Clicked on RecentActivity Quick Link");
		}

		public void ClickPurchaseLogs()
		{
			_purchaseLogs.JSClickWithFocus(Driver);
			Settings.EnCompassExtentTest.Info("Clicked on PurchaseLogs Quick Link");
		}


		public void ClickLoginCredentials()
		{
			_loginCredentials.JSClickWithFocus(Driver);
			Settings.EnCompassExtentTest.Info("Clicked on LoginCredentials Quick Link");
		}


		public string CreditLimitSummary()
        {
            Driver.WaitForVisible((By.XPath(_creditLimitSummaryXPath)));
            return new Regex(@"[^0-9\.]").Replace(_creditLimitSummary.Text, string.Empty);
        }

        public string AvailableCreditSummary()
        {
            Driver.WaitForVisible(By.XPath(_avaCreditSummaryXPath));
            return new Regex(@"[^0-9\.]").Replace(_avaCreditSummary.Text, string.Empty);
        }

        public string PercentAvailableSummary()
        {
            Driver.WaitForVisible(By.XPath(_precentAvaSummaryXPath));
            return new Regex(@"[^0-9\.]").Replace(_precentAvaSummary.Text, string.Empty);
        }

        public void RefreshCreditLineWidget()
		{
			string lastUpdated1 = LastUpdatedText;
			string lastUpdated2 = null;

			Refresh();

			do
			{
				Thread.Sleep(TimeSpan.FromSeconds(1)); // Static sleep is needed because of the time the widget needs to be refreshed with new data.
				lastUpdated2 = LastUpdatedText;
			}
			while (lastUpdated1 == lastUpdated2);
		}

        public bool IsSecurityPolicyLinkPresent
        {
            get
            {
                if (Driver.TryFindElement(By.XPath(@"//a[contains(@id,'SecurityPolicy')]"), out IWebElement element))
                {
                    return element.Displayed;
                }
                else
                    return false;
            }
        }
        public bool IsCreditLineWidgetPresent
		{
			get
			{
				if (Driver.TryFindElement(By.XPath(@"//div[contains(@class,'bx-content')]//span[text()='Credit Line']"), out IWebElement element))
				{
					return element.Displayed;
				}
				else
					return false;
			}
		}

		public bool IsCLWSummaryGroupPresent
		{
			get
			{
				if (Driver.TryFindElement(By.XPath(@"//caption[normalize-space(text()) ='Summary']"), out IWebElement element))
				{
					return element.Displayed;
				}
				else
					return false;
			}
		}

		public bool IsCLWCurrentSpendGroupPresent
		{
			get { return _currentSpendGroup.Displayed; }
		}

		public bool IsRefreshLinkPresent
		{
			get
			{
				if (Driver.TryFindElement(By.XPath(@"//a[contains(@id,'LinkButtonRefresh')]"), out IWebElement element))
				{
					return element.Displayed;
				}
				else
					return false;
			}
		}

		public void GoToSecurityPolicy()
		{
			_securityMenu.JSClickWithFocus(Driver);
			_securityPolicyMenu.JSClickWithFocus(Driver);

		}

        public Dictionary<string, string> GetCLWInfoByOrg(string currency, string orgName)
        {
            Driver.WaitForDocumentLoadToComplete();
            bool currencyFound = false;
            GlobalTransforms gT = new GlobalTransforms(Settings);
            string orgGroupName = gT.LookupInExternalDatasource("[%SCXT:OrgGroupName%]");

            for (int i = 0; i < 30; i++)
            {
                var currencyAvaliable = Driver.IsElementPresent(By.XPath($"//td[contains(text(), '{orgName}')]/following-sibling::td[contains(text(), '{currency}')]"));
                if (!currencyAvaliable)
                {
                    Thread.Sleep(10000);
                    _refreshLink.BootstrapClick();
                }
                else
                {
                    currencyFound = true;
                    break;
                }
            }

            if (currencyFound)
            {
                var clwInfo = new Dictionary<string, string>();
                //var currencyName = Driver.FindElement(By.XPath($"//div[@id='ctl00_ctl00_content_contents_ctl10_widgetBody_infoDiv']//td[normalize-space(text()) = '{currency}']"));
                var currencyName = Driver.FindElement(By.XPath($"//td[contains(text(), '{orgName}')]/following-sibling::td[contains(text(), '{currency}')]"));
                var precentUsed = currencyName.FindElement(By.XPath("./preceding-sibling::td[1]")).Text.Replace(",", "");
                clwInfo.Add("PercentUsed", precentUsed);
                var spend = currencyName.FindElement(By.XPath("./preceding-sibling::td[2]")).Text.Replace(",", "");
                clwInfo.Add("Spend", spend);
                var cl = currencyName.FindElement(By.XPath("./preceding-sibling::td[3]")).Text.Replace(",", "");
                clwInfo.Add("CreditLimit", cl);
                return clwInfo;
            }
            else
            {
                throw new Exception($"Could not locate company with currency {currency}");
            }
        }

        public Dictionary<string, string> GetCLWInfoByCurrency(string currency)
        {
			Driver.WaitForDocumentLoadToComplete();
			//var wait = Driver.WaitForVisible(By.XPath($"//div[@id='ctl00_ctl00_content_contents_ctl10_widgetBody_infoDiv']/table/tbody/tr/td[normalize-space(text()) = '{currency}']"));
			bool currencyFound = false;
			GlobalTransforms gT = new GlobalTransforms(Settings);

			string orgName = gT.LookupInExternalDatasource("[%SCXT:RandomOrgName%]");

			for (int i = 0; i < 30; i++)
			{
				//var currencyAvaliable = Driver.IsElementPresent(By.XPath($"//div[@id='ctl00_ctl00_content_contents_ctl10_widgetBody_infoDiv']//td[normalize-space(text()) = '{currency}']")); // Original code by CW.
				var currencyAvaliable = Driver.IsElementPresent(By.XPath($"//td[contains(text(), '{orgName}')]/following-sibling::td[contains(text(), '{currency}')]"));
				if (!currencyAvaliable)
				{
					Thread.Sleep(10000);
					_refreshLink.JSClickWithFocus(Driver);
					
				}

				else
				{
					currencyFound = true;
					break;
				}
			}

			if (currencyFound)
            {
                var clwInfo = new Dictionary<string, string>();
                //var currencyName = Driver.FindElement(By.XPath($"//div[@id='ctl00_ctl00_content_contents_ctl10_widgetBody_infoDiv']//td[normalize-space(text()) = '{currency}']"));
                var currencyName = Driver.FindElement(By.XPath($"//td[contains(text(), '{orgName}')]/following-sibling::td[contains(text(), '{currency}')]"));
                var precentUsed = currencyName.FindElement(By.XPath("./preceding-sibling::td[1]")).Text.Replace(",", "");
                clwInfo.Add("PercentUsed", precentUsed);
                var spend = currencyName.FindElement(By.XPath("./preceding-sibling::td[2]")).Text.Replace(",", "");
                clwInfo.Add("Spend", spend);
                var cl = currencyName.FindElement(By.XPath("./preceding-sibling::td[3]")).Text.Replace(",", "");
                clwInfo.Add("CreditLimit", cl);
                return clwInfo;
            }
            else
            {
                throw new Exception($"Could not locate company with currency {currency}");
            }
        }

        public void Refresh()
		{
			Actions act = new Actions(Driver);
			act.MoveToElement(_refreshLink).Perform();
			_refreshLink.JSClickWithFocus(Driver);
            WaitForFormLoadingOverlay(TimeSpan.FromSeconds(60));
            var loading = Driver.IsElementPresent(By.XPath(_loadingOverLayXPath));
            if (loading)
            {
            	Driver.WaitForAbsence(By.XPath(_loadingOverLayXPath), TimeSpan.FromSeconds(60));
            }

            WaitForLoad();
		}

		public string GCMAuthority
		{
			get { return new SelectElement(_gcmListBox).SelectedOption.Text; }
			set
			{
				var selElement = new SelectElement(_gcmListBox);
				var selOption = selElement.Options.FirstOrDefault(o => o.Text.StartsWith(value));

				if (selOption != null)
				{
					selElement.SelectByText(selOption.Text);
                    WaitForFormLoadingOverlay();
                }
				else
				{
					throw new Exception($"Select Option not present in the list.");
				}
			}
		}

		public bool IsGCMAuthorityListboxPresent
		{
			get
			{
				if (Driver.TryFindElement(By.XPath(@"//select[contains(@id,'widgetBody_DropDownListGCMOrgs')]"), out IWebElement element))
				{
					return element.Displayed;
				}
				else
				{
					return false;
				}
			}
		}

		public OrgHomeModel(GlobalSettings settings) : base(settings) { }

		

		public void Dismiss()
		{
			if (_passwordExpirationNO.Displayed)
			{
				_passwordExpirationNO.JSClickWithFocus(Driver);
			}
		}

		public IEnumerable<CLWSpendGroup> GetSpendGroups()
		{
			var rowElements = !IsGCMAuthorityListboxPresent 
								? Settings.EnCompassWebDriver.FindElements(By.XPath($@"//div[contains(@id, 'widgetBody_infoDiv')]/table[2]/tbody/tr/td/..")) 
								: Settings.EnCompassWebDriver.FindElements(By.XPath($@"//div[contains(@id, 'widgetBody_infoDiv')]/table[3]/tbody/tr/td/.."));

			var spendGroups = rowElements.Select(r => r.FindElements(By.TagName("td")).Select(t => t.Text).ToArray())
				.Select(d => new CLWSpendGroup()
				{
					Company = d[0],
					CreditLimit = d[1],
					Spend = d[2],
					PercentUsed = d[3],
					BillingCurrency = d[4]
				});
			return spendGroups;
		}
	}

	public class CLWSpendGroup
	{
		public string Company { get; set; }
		public string CreditLimit { get; set; }
		public string Spend { get; set; }
		public string PercentUsed { get; set; }
		public string BillingCurrency { get; set; }

		public override bool Equals(object obj)
		{
			// If comparing object is NULL or not of the type which we can compare then return False.
			if (obj == null || !(obj is CLWSpendGroup))
			{
				return false;
			}

			//Cast the comparing object to the actual Class object.
			var toCompare = obj as CLWSpendGroup;

			//Check each element's string value to be equal to the comparing element.
			var isEqual = this.Company.Trim().Equals(toCompare.Company.Trim(), StringComparison.InvariantCultureIgnoreCase);
			isEqual &= this.CreditLimit.Trim().Equals(toCompare.CreditLimit.Trim(), StringComparison.InvariantCultureIgnoreCase);
			isEqual &= this.Spend.Trim().Equals(toCompare.Spend.Trim(), StringComparison.InvariantCultureIgnoreCase);
			isEqual &= this.PercentUsed.Trim().Equals(toCompare.PercentUsed.Trim(), StringComparison.InvariantCultureIgnoreCase);
			isEqual &= this.BillingCurrency.Trim().Equals(toCompare.BillingCurrency.Trim(), StringComparison.InvariantCultureIgnoreCase);

			return isEqual;
		}

		public override int GetHashCode()
		{
			return $"{Company}{CreditLimit}{Spend}{PercentUsed}{BillingCurrency}".GetHashCode();
		}
	}

	public class CLWSpendGroupComparer : IEqualityComparer<CLWSpendGroup>
	{
		public bool Equals(CLWSpendGroup x, CLWSpendGroup y)
		{
			if (x == null || y == null)
			{
				return x == y;
			}
			bool same = x.Equals(y);
			return same;
		}

		public int GetHashCode(CLWSpendGroup obj)
		{
			return obj.GetHashCode();
		}
	}
}
