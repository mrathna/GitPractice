package com.framework.pages.EMAP;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.ExtentTest;
import com.framework.basepage.BasePage;
import com.framework.pages.OLS.common.CommonPage;
import com.framework.repo.Locator;

public class EMAPReportsPage extends BasePage {

	public EMAPReportsPage(WebDriver driver, ExtentTest test) {
		super(driver, test);
		PageFactory.initElements(driver, this);
	}

	@FindBy(how = How.ID, using = Locator.STORED_REPORTS_TYPE)
	public WebElement storedReportsType;

	@FindBy(how = How.ID, using = Locator.REPORTS_CREATED_FROM)
	public WebElement reportsCreatedFrom;

	@FindBy(how = How.ID, using = Locator.REPORTS_CREATED_TO)
	public WebElement reportsCreatedTo;

	@FindBy(how = How.ID, using = Locator.REPORTS_FILENAME)
	public WebElement reportsFileName;

	@FindBy(how = How.ID, using = Locator.STORED_REPORTS_EXPORT_OPTION)
	public WebElement exportStoredReprots;

	@FindBy(how = How.ID, using = Locator.SEARCH_CARDS)
	public WebElement searchCards;

	@FindBy(how = How.ID, using = Locator.REPORTS_TABLE)
	public WebElement reportsTable;

	@FindBy(how = How.ID, using = Locator.ADHOC_REPORTS_EXPORT)
	public WebElement adhocReportExport;

	@FindBy(how = How.ID, using = Locator.ADHOC_REPORT_TABLE)
	public WebElement adhocReportTable;

	@FindBy(how = How.ID, using = Locator.SEARCH_CARDS)
	public WebElement searchButton;

	@FindBy(how = How.XPATH, using = Locator.REPORTS_LIST)
	public List<WebElement> reportsList;

	@FindBy(how = How.XPATH, using = Locator.REPORT_TABLE_LIST)
	public List<WebElement> reportTableList;

	@FindBy(how = How.XPATH, using = Locator.REPORT_PARAM_ACCT_NO)
	public WebElement reportParamAcctNo;

	@FindBy(how = How.ID, using = Locator.REPORT_PARAM_CARD_STATUS)
	public WebElement reportParamCardStatus;

	@FindBy(how = How.ID, using = Locator.REPORT_PARAM_DATE_ISSUED)
	public WebElement reportParamDateIssued;

	@FindBy(how = How.ID, using = Locator.REPORT_PARAM_DATE)
	public WebElement reportParamDate;
	
	@FindBy(how = How.XPATH, using = Locator.REPORT_PARAM_DATE_INPUT)
	public WebElement reportParamDateInput;

	@FindBy(how = How.ID, using = Locator.REPORT_PARAM_EMAIL_ADDRESS)
	public WebElement reportParamEmailAddress;

	@FindBy(how = How.ID, using = Locator.ADHOC_REPORT_TYPE)
	public WebElement adhocReportType;

	@FindBy(how = How.ID, using = Locator.REPORT_PARAM_SORT_ORDER)
	public WebElement reportParamSortOrder;

	@FindBy(how = How.ID, using = Locator.REPORT_GENERATE)
	public WebElement reportGenerate;

	@FindBy(how = How.ID, using = Locator.CONFIRMATIONMESSAGE)
	public WebElement successMsg;

	@FindBy(how = How.ID, using = Locator.SCHEDULE_REPORT_TYPE)
	public WebElement scheduleReportType;

	@FindBy(id = Locator.ADD_SCHEDULE_REPORT_BUTTON)
	public WebElement addScheduledReportBtn;

	@FindBy(how = How.XPATH, using = Locator.PAGE_TITLE_REISSUECARD)
	public WebElement pageTitle;

	@FindBy(id = Locator.CREATED_ON)
	public WebElement createdOn;

	@FindBy(id = Locator.SCHEDULED_REPORT_PREVIOUS_REPORTED_DATE)
	public WebElement scheduledReportPreviousReportedDate;

	@FindBy(id = Locator.CREATED_ON)
	public WebElement scheduledReportLatReportedDate;

	@FindBy(id = Locator.SCHEDULED_REPORT_NAME)
	public WebElement scheduledReportName;

	@FindBy(xpath = Locator.SCHEDULE_DELIVERY_TYPE)
	public WebElement scheduledReportDeliveryType;

	@FindBy(xpath = Locator.SCHEDULE_FREQUENCY_DROPDOWN)
	public WebElement scheduledReportFrequency;

	@FindBy(id = Locator.SCHEDULE_SAVE_BUTTON)
	public WebElement scheduleSaveBtn;

	@FindBy(id = Locator.EMAIL_FIELD)
	public WebElement scheduleReportEmail;

	@FindBy(id = Locator.STORED_REPORTS_TYPE)
	public WebElement storedReportType;

	@FindBy(xpath = Locator.CHANGE_PASSWORD_ERROR_MESSAGE)
	public WebElement reportErrorMessage;

	public void validateTheReportsPageFilterOptions() {
		isDisplayed(storedReportsType, "Report type");
		isDisplayed(reportsCreatedFrom, "Reports created from");
		isDisplayed(reportsCreatedTo, "Reports created to");
		isDisplayed(reportsFileName, "Report file name");
	}

	public void checkThePresenceOfExportAndSearchOptions() {
		isDisplayed(searchCards, "Search Cards");
		isDisplayed(exportStoredReprots, "Export Reports");
	}

	public void validateTheReportsTableColumns() {
		String[] columnValuesExpected = new String[] { "Report Type", "Created", "File Name" };
		commonPage.validateTheTableHeaderTitles(reportsTable, 3, columnValuesExpected);
	}

	public void checkThePresenceOfOptionToExportAdhocReport() {
		isDisplayed(adhocReportExport, "Adhoc Report Export Option");
	}

	public void validateTheAdhocReportsTableHeaderColumns(String clientCountry) {
		String[] columnValuesExpected = new String[] { "Description", "Report Member Type" };
		commonPage.validateTheTableHeaderTitles(adhocReportTable, 2, columnValuesExpected);
		System.out.println("Table Rows Count:" + getRowSize(adhocReportTable));
		if (clientCountry.contains("MO")) {
			if (!(getRowSize(adhocReportTable) == 4)) {
				logFail("Adhoc Report Table not having 2 rows");
			}
		} else if ((getRowSize(adhocReportTable) >= 4)) {
			logPass("Adhoc Report Table not having 3 rows");
		}
	}

	public void validateAdhocReportsTable() {
		setCellDataFromTable(adhocReportTable, 2, true);
		String[] reportNamesExpected = new String[] { "Card Export List - CSV", "Card Export List - PDF",
				"Vehicle Odometer Report" };
		for (int i = 1; i < 3; i++) {
			if (reportNamesExpected[i - 1].contains(getCellDataFromTable(i, 0, true))) {
				logPass("Expected Report type" + reportNamesExpected[i] + " is present");
			} else {
				logFail("Expected Report type" + reportNamesExpected[i] + " is not present");
			}
		}
	}

	public void selectAStoredReportAndVerify() {
		// selectDropDownByVisibleText(storedReportType, reportType);
		selectDropDownOptionsRandomly(storedReportType, "Stored Report");
		String reportType = selectedStringFrmDropDown(storedReportType);
		sleep(2);
		isDisplayedThenClick(searchButton, "Search Reports");
		sleep(3);
		setCellDataFromTable(reportsTable, 3, true);
		int rowSize = getRowSize(reportsTable);
		int randomNumber;
		if (rowSize > 3) {
			logInfo("Reports table have reports");
			if (rowSize == 4) {
				randomNumber = 1;
			} else {
				randomNumber = getRandomNumber(1, rowSize - 3);
			}
			isDisplayedThenClick(reportsList.get(randomNumber), "Report list item");
			sleep(5);
			try {
				if (reportErrorMessage.isDisplayed()) {
					if (getText(reportErrorMessage).contains("Stored report file could not be accessed")) {
						logInfo(getText(reportErrorMessage));
					} else {
						logFail(getText(reportErrorMessage));
					}
				}
			} catch (Exception ex) {
				logInfo(ex.getMessage());
				commonPage.isFileDownloaded(reportType.replaceAll(" ", "_"));
			}
		} else {
			logInfo("No Stored Reports for the selected report type");
		}
	}

	
	public void selectInvoiceReport(String reportType) {
		
		selectDropDownByVisibleText(storedReportType,reportType);
		isDisplayedThenClick(searchButton, "Search Button");
			}

	
	public void selectAReportType() {
		int randomNo = getRandomNumber(0, reportTableList.size());
		isDisplayed(reportTableList.get(randomNo), "Report");
		isDisplayedThenActionClick(reportTableList.get(randomNo), "Report Table List");
		sleep(5);
	}

	public void verifyReportParameters() {
		String reportType = getText(adhocReportType);
		isDisplayed(reportParamAcctNo, "Default Account in Account - Report Parameter");
		if (reportType.equals("Card Export List - CSV")) {
			String selectedString = selectedStringFrmDropDown(reportParamCardStatus);
			if (!selectedString.equals("Active Cards Only")) {
				logFail("Active Cards Only option not selected in default");
			}
			isDisplayed(reportParamDateInput, "Date Issued - Report Parameter");
		}
		if (reportType.equals("Vehicle Odometer Report")) {
			isDisplayed(reportParamDateInput, "Date Issued - Report Parameter");
			isDisplayed(reportParamSortOrder, "Sort Order - Report Parameter");
		}
		isDisplayed(reportParamEmailAddress, "Email Address - Report Parameter");
	}

	public void generateAReportWithValidRequestParameters() {
		isDisplayed(reportParamEmailAddress, "Email Address - Report Parameter");
		isDisplayedThenEnterText(reportParamEmailAddress, "Email Address - Report Parameter",
				fakerAPI().internet().emailAddress());
		isDisplayedThenClick(reportGenerate, "Generate Reprot");
		sleep(3);
		verifyText(successMsg, "Success!  Email has been submitted.");
	}

	public void selectAddAScheduledReport() {
		isDisplayedThenClick(addScheduledReportBtn, "Add a scheduled report");
		verifyText(pageTitle, "Scheduled Reports Maintenance");
	}

	public void checkFieldsInScheduledReportsManitenancePage() {
		checkAnElementIsDisabled(createdOn, "Scheduled Report - Created On");
		checkAnElementIsDisabled(scheduledReportPreviousReportedDate, "Scheduled Report - Previous Reported On");
		checkAnElementIsDisabled(scheduledReportLatReportedDate, "Scheduled Report - Last Reported On");
	}

	CommonPage commonPage = new CommonPage(driver, test);

	public void checkAdhocReportsTableSorting() {
		String[] columnValuesExpected = new String[] { "Description", "Report Member Type" };
		for (int i = 0; i < columnValuesExpected.length; i++) {
			commonPage.clickColumnHeaderAndVerifySorting(adhocReportTable, columnValuesExpected[i]);
		}
	}

	public void createAScheduledReportWithValidValues() {

		isDisplayedThenClick(addScheduledReportBtn, "Add a Scheduled Report");

		sleep(3);

		selectDropDownByVisibleText(scheduleReportType, "Card Export List - CSV");

		sleep(3);

		isDisplayedThenEnterText(scheduledReportName, "Scheduled Report Name", fakerAPI().name().title());

		sleep(2);

		selectDropDownByVisibleText(scheduledReportFrequency, "Report End of Day");

		sleep(2);

		selectDropDownByVisibleText(scheduledReportDeliveryType, "Local Email");

		sleep(2);

		selectDropDownByVisibleText(reportParamCardStatus, "All Cards");

		sleep(2);

		isDisplayedThenEnterText(scheduleReportEmail, "Email", fakerAPI().internet().emailAddress());

		isDisplayedThenClick(scheduleSaveBtn, "Save Button");

		sleep(7);

		verifyText(successMsg, "Congratulations. Your Scheduled Report has been created.");
	}
}
