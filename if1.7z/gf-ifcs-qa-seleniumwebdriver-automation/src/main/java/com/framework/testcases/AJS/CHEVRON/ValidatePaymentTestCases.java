package com.framework.testcases.AJS.CHEVRON;

import java.util.Map;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.CardMaintenancePage;
import com.framework.pages.AJS.SearchPage;
import com.framework.pages.AJS.common.Common;
import com.framework.pages.AJS.common.IFCSCommonPage;
import com.framework.pages.AJS.common.IFCSHomePage;
import com.framework.pages.AJS.common.IFCSLoginPage;
import com.framework.pages.BusinessFlow.TransactionComponentPage;
import com.framework.pages.BusinessFlow.WFECommon;


public class ValidatePaymentTestCases extends BaseTest {
	
	/**
	 * Implemented by Nithya
	 * 
	 * @param clientCountry
	 * @param clientName    Business Flow ID:BF-102
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow" })
	public void postManualPaymentFromIFCS(@Optional("TH") String clientCountry, @Optional("CHEVRON") String clientName) {

		test = extent.createTest(clientName + ":" + clientCountry + "TC_01_EMAP_Payments_Cheque_Payment",
				"RQ-144 Customer is paying using cheque payment");
		IFCSLoginPage ifcsLoginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage ifcsHomePage = new IFCSHomePage(driver, test);
		IFCSCommonPage ifcsCommonPage = new IFCSCommonPage(driver, test);
		Common common = new Common(driver, test);
		ifcsLoginPage.login("IFCS_URL_CHEVRON", "IFCS_CHEVRON_USERNAME", "IFCS_CHEVRON_PASSWORD");
	      // ifcsHomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);
		ifcsLoginPage.setClientCountryCardTypeDetails(clientName, clientCountry, " ");
		// Selecting client from Application Menu
		ifcsHomePage.gotoApplicationAndClickApplicationMenu();
		ifcsHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);
		String customerNumber = common.getActiveOrTemporaryBlockCustomerNoHavingCardsAndRowIndex(1, "Active");
		//ifcsCommonPage.postManualPayments(customerNumber, "Other Payments", clientName + "_" + clientCountry);
		ifcsCommonPage.postManualPayments(customerNumber, "Chq Payment JPM2", clientName + "_" + clientCountry);

		ifcsHomePage.exitIFCS();
	}
	


	/**
	 * Implemented by Nithya
	 * 
	 * @param clientCountry
	 * @param clientName    Business Flow ID:BF-102
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow" })
	public void postManualPaymentUsingDD(@Optional("TH") String clientCountry, @Optional("CHEVRON") String clientName) {

		test = extent.createTest(clientName + ":" + clientCountry + "TC01_CHEV_Payments_DD_Payment_Post Manual Direct Deposit Payment",
				"Customer payment using DD (DD Outbound files)");
		IFCSLoginPage ifcsLoginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage ifcsHomePage = new IFCSHomePage(driver, test);
		IFCSCommonPage ifcsCommonPage = new IFCSCommonPage(driver, test);
		Common common = new Common(driver, test);
		ifcsLoginPage.login("IFCS_URL_CHEVRON", "IFCS_CHEVRON_USERNAME", "IFCS_CHEVRON_PASSWORD");
	      // ifcsHomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);
		ifcsLoginPage.setClientCountryCardTypeDetails(clientName, clientCountry, " ");
		// Selecting client from Application Menu
		ifcsHomePage.gotoApplicationAndClickApplicationMenu();
		ifcsHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);
		String customerNumber = common.getActiveOrTemporaryBlockCustomerNoHavingCardsAndRowIndex(1, "Active");
		//ifcsCommonPage.postManualPayments(customerNumber, "Other Payments", clientName + "_" + clientCountry);
		ifcsCommonPage.postManualPaymentsByDD(customerNumber, "", clientName + "_" + clientCountry);

		ifcsHomePage.exitIFCS();
	}
	
	/**
	 * Implemented by Venkata Davu
	 * 
	 * @param clientCountry
	 * @param clientName    Business Flow ID:BF-014
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "BusinessFlow" })
	public void validateDisputeTransaction(@Optional("TH") String clientCountry, @Optional("CHEVRON") String clientName) {
		test = extent.createTest(clientName + ":" + clientCountry + " TC-1762 TC01_Dispute_Txn_Unable",
				" Verify whether dispute is applied if the customer is willing to reverse a transaction");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		CardMaintenancePage cardMaintenancePage = new CardMaintenancePage(driver, test);
		TransactionComponentPage transactionComponentPage = new TransactionComponentPage(driver, test);
		Common common = new Common(driver, test);
		WFECommon wfecommon = new WFECommon(driver, test);
		IFCSloginPage.login("IFCS_URL_CHEVRON", "IFCS_CHEVRON_USERNAME", "IFCS_CHEVRON_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, " ");

		Map<String,String> cardNo = wfecommon.getCardNumberfromPOSTransactions(clientName +"_"+ clientCountry);

		IFCSloginPage.logInfo("Customer number from DB" + cardNo);

		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		cardMaintenancePage.chooseAndSearchCardNo(cardNo.get("CARD_NO"));
		transactionComponentPage.disputeTransaction(cardNo.get("PROCESSED_AT"));

		IFCSHomePage.exitIFCS();

	}
	
}
