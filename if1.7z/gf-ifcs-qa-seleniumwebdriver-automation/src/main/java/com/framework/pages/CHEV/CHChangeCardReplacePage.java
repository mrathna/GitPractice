package com.framework.pages.CHEV;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.ExtentTest;
import com.framework.basepage.BasePage;
import com.framework.repo.Locator;

public class CHChangeCardReplacePage extends BasePage {

	@FindBy(how = How.XPATH, using = Locator.SCHEDULE_REPORT_MAINTENANCE_PAGE)
	public WebElement cardChangeStatusPage;

	@FindBy(how = How.ID, using = Locator.CH_BACK_TO_CARD_LIST_CARD_REPLACE_PAGE)
	public WebElement backToCardList;
	
	public CHChangeCardReplacePage(WebDriver driver, ExtentTest test) {
		super(driver, test);
		// TODO Auto-generated constructor stub
		PageFactory.initElements(driver, this);
	}

	public void verifyReplaceCardStatusPage() {
		sleep(3);
		isDisplayed(cardChangeStatusPage, "Replace Card");
		logPass("Redirected to the Replace Card Status Page");

	}
	
	public void navigateBacktoCardList() {
		if(backToCardList.isDisplayed()) {
			actionClick(backToCardList);
		}
		sleep(3);
	}
	
	
}
