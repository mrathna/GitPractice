using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using Common;
using Common.PageObjects;
using Common.ScenarioConfigurations;
using Common.Utility;

namespace EnCompass.Testing.Source.PageObjects.Organization 
{
	/// <summary>
	/// Auto-generated Page Model Class
	/// Navigation Paths: 
		/// [Organization Home]->
		/// </summary>
	[PageModel(@"")]
	public partial class EnCompassOrgPageModel : EnCompassPageModel 
	{
		public override string RelativeUrl => @"";
		public override string PageIdentifierXPath_Generated => @"";

		#region Navigation
				[FindsBy(How = How.XPath, Using = @"//li[contains(@id, 'announcements')]/a")]
		private IWebElement _administration_Announcements { get; set; }
		public void NavigateTo_Administration_Announcements()
		{
			NavigateToMenuItem(_administration_Announcements);
		}

				[FindsBy(How = How.XPath, Using = @"//li[contains(@id, 'accountChangeCodes')]/a")]
		private IWebElement _administration_AccountChangeCodes { get; set; }
		public void NavigateTo_Administration_AccountChangeCodes()
		{
			NavigateToMenuItem(_administration_AccountChangeCodes);
		}

				[FindsBy(How = How.XPath, Using = @"//li[contains(@id, 'accountTermination')]/a")]
		private IWebElement _administration_CreditRatingTermination { get; set; }
		public void NavigateTo_Administration_CreditRatingTermination()
		{
			NavigateToMenuItem(_administration_CreditRatingTermination);
		}

				[FindsBy(How = How.XPath, Using = @"//li[contains(@id, 'cardHierarchy')]/a")]
		private IWebElement _administration_CardHierarchy { get; set; }
		public void NavigateTo_Administration_CardHierarchy()
		{
			NavigateToMenuItem(_administration_CardHierarchy);
		}

				[FindsBy(How = How.XPath, Using = @"//li[contains(@id, 'mccs')]/a")]
		private IWebElement _administration_MerchantCategoryCodes { get; set; }
		public void NavigateTo_Administration_MerchantCategoryCodes()
		{
			NavigateToMenuItem(_administration_MerchantCategoryCodes);
		}

				[FindsBy(How = How.XPath, Using = @"//li[contains(@id, 'proxy')]/a")]
		private IWebElement _administration_Proxies { get; set; }
		public void NavigateTo_Administration_Proxies()
		{
			NavigateToMenuItem(_administration_Proxies);
		}

				[FindsBy(How = How.XPath, Using = @"//li[contains(@id, 'fileUpload')]/a")]
		private IWebElement _administration_FileUploads { get; set; }
		public void NavigateTo_Administration_FileUploads()
		{
			NavigateToMenuItem(_administration_FileUploads);
		}

				[FindsBy(How = How.XPath, Using = @"//li[contains(@id, 'liCurrencyConversionRates')]/a")]
		private IWebElement _administration_ConversionRates { get; set; }
		public void NavigateTo_Administration_ConversionRates()
		{
			NavigateToMenuItem(_administration_ConversionRates);
		}

				[FindsBy(How = How.XPath, Using = @"//li[contains(@id, 'transactionEnvelopeFields')]/a")]
		private IWebElement _administration_TransactionEnvelopes { get; set; }
		public void NavigateTo_Administration_TransactionEnvelopes()
		{
			NavigateToMenuItem(_administration_TransactionEnvelopes);
		}

				[FindsBy(How = How.XPath, Using = @"//li[contains(@id, 'acctMgmt')]/a")]
		private IWebElement _security_Users { get; set; }
		public void NavigateTo_Security_Users()
		{
			NavigateToMenuItem(_security_Users);
		}

				[FindsBy(How = How.XPath, Using = @"//li[contains(@id, 'securityPolicy')]/a")]
		private IWebElement _security_SecurityPolicy { get; set; }
		public void NavigateTo_Security_SecurityPolicy()
		{
			NavigateToMenuItem(_security_SecurityPolicy);
		}

				[FindsBy(How = How.XPath, Using = @"//li[contains(@id, 'workFlow')]/a")]
		private IWebElement _security_WorkflowHierarchy { get; set; }
		public void NavigateTo_Security_WorkflowHierarchy()
		{
			NavigateToMenuItem(_security_WorkflowHierarchy);
		}

				[FindsBy(How = How.XPath, Using = @"//li[contains(@id, 'alerts')]/a")]
		private IWebElement _security_AlertsAndNotifications { get; set; }
		public void NavigateTo_Security_AlertsAndNotifications()
		{
			NavigateToMenuItem(_security_AlertsAndNotifications);
		}

				[FindsBy(How = How.XPath, Using = @"//li[contains(@id, 'purchaseLog')]/a")]
		private IWebElement _payables_PurchaseLog { get; set; }
		public void NavigateTo_Payables_PurchaseLog()
		{
			NavigateToMenuItem(_payables_PurchaseLog);
		}

				[FindsBy(How = How.XPath, Using = @"//li[contains(@id, 'map')]/a")]
		private IWebElement _payables_AccountsPayable { get; set; }
		public void NavigateTo_Payables_AccountsPayable()
		{
			NavigateToMenuItem(_payables_AccountsPayable);
		}

				[FindsBy(How = How.XPath, Using = @"//li[contains(@id, 'myReports')]/a")]
		private IWebElement _reports_MyReports { get; set; }
		public void NavigateTo_Reports_MyReports()
		{
			NavigateToMenuItem(_reports_MyReports);
		}

				[FindsBy(How = How.XPath, Using = @"//li[contains(@id, 'companyReports')]/a")]
		private IWebElement _reports_CompanyReports { get; set; }
		public void NavigateTo_Reports_CompanyReports()
		{
			NavigateToMenuItem(_reports_CompanyReports);
		}

				[FindsBy(How = How.XPath, Using = @"//li[contains(@id, 'standardReports')]/a")]
		private IWebElement _reports_StandardReports { get; set; }
		public void NavigateTo_Reports_StandardReports()
		{
			NavigateToMenuItem(_reports_StandardReports);
		}

				[FindsBy(How = How.XPath, Using = @"//li[contains(@id, 'scheduledReports')]/a")]
		private IWebElement _reports_ScheduledReports { get; set; }
		public void NavigateTo_Reports_ScheduledReports()
		{
			NavigateToMenuItem(_reports_ScheduledReports);
		}

				[FindsBy(How = How.XPath, Using = @"//li[contains(@id, 'organizationScheduledReports')]/a")]
		private IWebElement _reports_OrganizationScheduledReports { get; set; }
		public void NavigateTo_Reports_OrganizationScheduledReports()
		{
			NavigateToMenuItem(_reports_OrganizationScheduledReports);
		}

				[FindsBy(How = How.XPath, Using = @"//li[contains(@id, 'downloadReports')]/a")]
		private IWebElement _reports_DownloadReports { get; set; }
		public void NavigateTo_Reports_DownloadReports()
		{
			NavigateToMenuItem(_reports_DownloadReports);
		}

				[FindsBy(How = How.XPath, Using = @"//li[contains(@id, 'reportWizardAwesome')]/a")]
		private IWebElement _reports_ReportWizard { get; set; }
		public void NavigateTo_Reports_ReportWizard()
		{
			NavigateToMenuItem(_reports_ReportWizard);
		}

				[FindsBy(How = How.XPath, Using = @"//li[contains(@id, 'accountMaintenance')]/a")]
		private IWebElement _cards_CardMaintenance { get; set; }
		public void NavigateTo_Cards_CardMaintenance()
		{
			NavigateToMenuItem(_cards_CardMaintenance);
		}

				[FindsBy(How = How.XPath, Using = @"//li[contains(@id, 'RecentActivity')]/a")]
		private IWebElement _cards_RecentActivity { get; set; }
		public void NavigateTo_Cards_RecentActivity()
		{
			NavigateToMenuItem(_cards_RecentActivity);
		}

				[FindsBy(How = How.XPath, Using = @"//li[contains(@id, 'statement')]/a")]
		private IWebElement _transactions_Statements { get; set; }
		public void NavigateTo_Transactions_Statements()
		{
			NavigateToMenuItem(_transactions_Statements);
		}

				[FindsBy(How = How.XPath, Using = @"//li[contains(@id, 'makeStatementPayments')]/a")]
		private IWebElement _transactions_PayStatements { get; set; }
		public void NavigateTo_Transactions_PayStatements()
		{
			NavigateToMenuItem(_transactions_PayStatements);
		}

				[FindsBy(How = How.XPath, Using = @"//li[contains(@id, 'transactionTopActions')]/a")]
		private IWebElement _transactions_TransactionManagement { get; set; }
		public void NavigateTo_Transactions_TransactionManagement()
		{
			NavigateToMenuItem(_transactions_TransactionManagement);
		}

				[FindsBy(How = How.XPath, Using = @"//li[contains(@id, 'transactionEnvelope')]/a")]
		private IWebElement _transactions_TransactionEnvelopes { get; set; }
		public void NavigateTo_Transactions_TransactionEnvelopes()
		{
			NavigateToMenuItem(_transactions_TransactionEnvelopes);
		}

				[FindsBy(How = How.XPath, Using = @"//li[contains(@id, 'transactionDisputeManagement')]/a")]
		private IWebElement _transactions_Disputes { get; set; }
		public void NavigateTo_Transactions_Disputes()
		{
			NavigateToMenuItem(_transactions_Disputes);
		}

				[FindsBy(How = How.XPath, Using = @"//li[contains(@id, 'glCalendar')]/a")]
		private IWebElement _transactions_FiscalCalendar { get; set; }
		public void NavigateTo_Transactions_FiscalCalendar()
		{
			NavigateToMenuItem(_transactions_FiscalCalendar);
		}

				[FindsBy(How = How.XPath, Using = @"//li[contains(@id, 'priorities')]/a")]
		private IWebElement _transactions_FinancialCodes { get; set; }
		public void NavigateTo_Transactions_FinancialCodes()
		{
			NavigateToMenuItem(_transactions_FinancialCodes);
		}

		// TODO - Inbox link got wrongly generated as User Account.

		/*		[FindsBy(How = How.XPath, Using = @"//a[contains(@class, 'dropdown-item')][contains(@id, 'lnkInbox')]")]
		private IWebElement _useraccount_ { get; set; }
		public void NavigateTo_Useraccount_()
		{
			NavigateToMenuItem(_useraccount_);
		}*/

		[FindsBy(How = How.XPath, Using = @"//a[contains(@class, 'dropdown-item')][contains(@id, 'lnkUserAccount')]")]
		private IWebElement _useraccount_ { get; set; }
		public void NavigateTo_Useraccount_()
		{
			NavigateToMenuItem(_useraccount_);
		}

		
		private void NavigateToMenuItem(IWebElement element)
		{
			Driver.Url = element.GetAttribute("href");
		}
		#endregion

		public EnCompassOrgPageModel(GlobalSettings settings) : base(settings) { }
	}  
}
