package com.framework.testcases.OLS.EMAP.Customer;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.EMAP.EMAPAccountsPage;
import com.framework.pages.EMAP.EMAPHomePage;
import com.framework.pages.EMAP.EMAPReportsPage;
import com.framework.pages.EMAP.EMAPSupportPage;
import com.framework.pages.EMAP.EMAPTransactionsPage;
import com.framework.pages.OLS.common.CommonPage;
import com.framework.pages.OLS.common.LoginPage;

public class ValidateAllPageNavigations extends BaseTest {
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "Regression" })
	public void validateAllPageNavigations(@Optional("SP") String clientCountry, @Optional("EMAP") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  TST-SC-68-OLS - All pages except cards menu,TST-SC-102-OLS-Verify the Ad-hoc Reports,TST-SC-103-OLS - Verify the Scheduled Reports,TST-SC-100-OLS-Verify Card Profile Changes,TST-SC-78-OLS - Verify menu items and log out",
				"Login to EMAP Customer - Read Only and check the page navigations and menu items");
		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		loginPage.Login("EMAP_URL", "EMAP_UN_ReadOnly_Customer_" + clientCountry,
				"EMAP_PWD_ReadOnly_Customer_" + clientCountry, clientName);
		EMAPHomePage emapHomePage = new EMAPHomePage(driver, test);
		EMAPAccountsPage accountPage = new EMAPAccountsPage(driver, test);
		EMAPTransactionsPage transactionListsPage = new EMAPTransactionsPage(driver, test);
		CommonPage commonPage = new CommonPage(driver, test);
		EMAPReportsPage reportsPage = new EMAPReportsPage(driver, test);
		EMAPSupportPage supportPage = new EMAPSupportPage(driver, test);
		emapHomePage.validateEMAPCustomerLogo();
		emapHomePage.validateCustomerWelcomeText();
		emapHomePage.checkThePresenceOfQuickLinksOnHomePage("Read-Only");
		emapHomePage.checkThePresenceOfLoginUserNameAndLogoutLink();

	//	emapHomePage.verifyCustomerNumberInHomePage();
		emapHomePage.selectAccountAndCheckSelectedAccountOnContext();

		emapHomePage.clickSelectAccountAndValidatePage();
		emapHomePage.clickAccountMaintenanceAndValidatePage();
		accountPage.validateTheAccountMaintenancePageFields(clientCountry);

		emapHomePage.clickContactsAndValidatePage();
		accountPage.validateTheContactsTableFields();

		emapHomePage.clickTransactionListAndValidatePage();
		transactionListsPage.selectAllAccountsInTrasactionSearchFilter();
		transactionListsPage.validateTheTransactionsTableFields("Customer");

		boolean isTransactionPresent = transactionListsPage.getACardNumberWithTransaction();
		if (isTransactionPresent) {
			transactionListsPage.enterACardNumberInSearchFilter();
			commonPage.clickSearchButton();
			transactionListsPage.validateSearchResultsAndClickViewTransactionsOption(true);
			transactionListsPage.verifyTransactionDetailsHeaderTitle();
			transactionListsPage.validateTransactionPageFields("Customer");
		}
		emapHomePage.clickStoredReportsAndValidatePage();
		reportsPage.validateTheReportsPageFilterOptions();
		reportsPage.checkThePresenceOfExportAndSearchOptions();
		reportsPage.validateTheReportsTableColumns();

		reportsPage.selectAStoredReportAndVerify();

		emapHomePage.clickChangePasswordAndValidatePage();
		supportPage.validateThePasswordMaintenanceFields();

		if (!(clientCountry.equals("MO"))) {
			emapHomePage.clickContactUsAndValidatePage();
		} else {
			emapHomePage.clickContactUsMOAndValidatePage();
		}

		supportPage.checkClientLogo();
		loginPage.Logout();
	}
}
