package com.framework.testcases.OLS.BP.Location;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.BP.BPHomePage;
import com.framework.pages.OLS.common.LoginPage;

public class ValidateLocationQuickLinksAndAccountSection extends BaseTest {

	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "Regression" })
	public void validateLocationAccountDropDown(@Optional("AU") String clientCountry,
			@Optional("BP") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  BP Location Home Page Account", "Validation Location Account Dropdown");

		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		BPHomePage bpHomePage = new BPHomePage(driver, test);
		loginPage.Login("BP_URL", "BP_UN_Location_" + clientCountry, "BP_PWD_Location_" + clientCountry, clientName);
		bpHomePage.ValidateMerchantLogo();

		// Select the Account from Drop down
		bpHomePage.selectAccountsFromDropDown();

		// Logout
		loginPage.Logout();

	}

	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "Regression" })
	public void validateLocationQuickLinkTransactionList(@Optional("AU") String clientCountry,
			@Optional("BP") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  BP Location Home Page Quick Links", "Validation Location Quick links Transaction List");

		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		BPHomePage bpHomePage = new BPHomePage(driver, test);
		loginPage.Login("BP_URL", "BP_UN_Location_" + clientCountry, "BP_PWD_Location_" + clientCountry, clientName);
		bpHomePage.ValidateMerchantLogo();

		// Select the Transaction list quick links
		bpHomePage.clickTransactionListQuickLinksAndValidate("Location");

		// Logout
		loginPage.Logout();
	}

}
