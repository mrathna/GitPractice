using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using Common;
using Common.PageObjects;
using Common.ScenarioConfigurations;
using Common.Utility;

namespace EnCompass.Testing.Source.PageObjects.SuperAdmin.Testing 
{
	/// <summary>
	/// Auto-generated Page Model Class
	/// Navigation Paths: 
		/// [Organization Home]->General->Testing->AP Non-Card Payments Testing
		/// </summary>
	[PageModel(@"/superAdmin/testing/APNonCardTesting.aspx")]
	public partial class ApnonCardTesting : EnCompassSuperPageModel 
	{
		public override string RelativeUrl => @"/superAdmin/testing/APNonCardTesting.aspx";
		public override string PageIdentifierXPath_Generated => @"//li[contains(@class, 'breadcrumb-item active')][text() = 'AP Non-Card Payments Testing']";

		#region Navigation
				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Create Organization']")]
		private IWebElement _general_Testing_ApNonCardPaymentsTesting_CreateOrganization { get; set; }
		public void NavigateTo_General_Testing_ApNonCardPaymentsTesting_CreateOrganization()
		{
			NavigateToMenuItem(_general_Testing_ApNonCardPaymentsTesting_CreateOrganization);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Create Organization Profile']")]
		private IWebElement _general_Testing_ApNonCardPaymentsTesting_CreateOrganizationProfile { get; set; }
		public void NavigateTo_General_Testing_ApNonCardPaymentsTesting_CreateOrganizationProfile()
		{
			NavigateToMenuItem(_general_Testing_ApNonCardPaymentsTesting_CreateOrganizationProfile);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Delete Test Organization']")]
		private IWebElement _general_Testing_ApNonCardPaymentsTesting_DeleteTestOrganization { get; set; }
		public void NavigateTo_General_Testing_ApNonCardPaymentsTesting_DeleteTestOrganization()
		{
			NavigateToMenuItem(_general_Testing_ApNonCardPaymentsTesting_DeleteTestOrganization);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Create Test Company']")]
		private IWebElement _general_Testing_ApNonCardPaymentsTesting_CreateTestCompany { get; set; }
		public void NavigateTo_General_Testing_ApNonCardPaymentsTesting_CreateTestCompany()
		{
			NavigateToMenuItem(_general_Testing_ApNonCardPaymentsTesting_CreateTestCompany);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Corporate Credit Limit']")]
		private IWebElement _general_Testing_ApNonCardPaymentsTesting_CorporateCreditLimit { get; set; }
		public void NavigateTo_General_Testing_ApNonCardPaymentsTesting_CorporateCreditLimit()
		{
			NavigateToMenuItem(_general_Testing_ApNonCardPaymentsTesting_CorporateCreditLimit);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Create Bounce Notification']")]
		private IWebElement _general_Testing_ApNonCardPaymentsTesting_CreateBounceNotification { get; set; }
		public void NavigateTo_General_Testing_ApNonCardPaymentsTesting_CreateBounceNotification()
		{
			NavigateToMenuItem(_general_Testing_ApNonCardPaymentsTesting_CreateBounceNotification);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Reset Merchant Log Error']")]
		private IWebElement _general_Testing_ApNonCardPaymentsTesting_ResetMerchantLogError { get; set; }
		public void NavigateTo_General_Testing_ApNonCardPaymentsTesting_ResetMerchantLogError()
		{
			NavigateToMenuItem(_general_Testing_ApNonCardPaymentsTesting_ResetMerchantLogError);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Performance']")]
		private IWebElement _general_Testing_ApNonCardPaymentsTesting_Performance { get; set; }
		public void NavigateTo_General_Testing_ApNonCardPaymentsTesting_Performance()
		{
			NavigateToMenuItem(_general_Testing_ApNonCardPaymentsTesting_Performance);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='AP Non-Card Payments Testing']")]
		private IWebElement _general_Testing_ApNonCardPaymentsTesting_ApNonCardPaymentsTesting { get; set; }
		public void NavigateTo_General_Testing_ApNonCardPaymentsTesting_ApNonCardPaymentsTesting()
		{
			NavigateToMenuItem(_general_Testing_ApNonCardPaymentsTesting_ApNonCardPaymentsTesting);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Modify Merchant Log']")]
		private IWebElement _general_Testing_ApNonCardPaymentsTesting_ModifyMerchantLog { get; set; }
		public void NavigateTo_General_Testing_ApNonCardPaymentsTesting_ModifyMerchantLog()
		{
			NavigateToMenuItem(_general_Testing_ApNonCardPaymentsTesting_ModifyMerchantLog);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Test Templates']")]
		private IWebElement _general_Testing_ApNonCardPaymentsTesting_TestTemplates { get; set; }
		public void NavigateTo_General_Testing_ApNonCardPaymentsTesting_TestTemplates()
		{
			NavigateToMenuItem(_general_Testing_ApNonCardPaymentsTesting_TestTemplates);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Create Test Statements']")]
		private IWebElement _general_Testing_ApNonCardPaymentsTesting_CreateTestStatements { get; set; }
		public void NavigateTo_General_Testing_ApNonCardPaymentsTesting_CreateTestStatements()
		{
			NavigateToMenuItem(_general_Testing_ApNonCardPaymentsTesting_CreateTestStatements);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Contact Us']")]
		private IWebElement _general_Testing_ApNonCardPaymentsTesting_ContactUs { get; set; }
		public void NavigateTo_General_Testing_ApNonCardPaymentsTesting_ContactUs()
		{
			NavigateToMenuItem(_general_Testing_ApNonCardPaymentsTesting_ContactUs);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Dispute Transaction']")]
		private IWebElement _general_Testing_ApNonCardPaymentsTesting_DisputeTransaction { get; set; }
		public void NavigateTo_General_Testing_ApNonCardPaymentsTesting_DisputeTransaction()
		{
			NavigateToMenuItem(_general_Testing_ApNonCardPaymentsTesting_DisputeTransaction);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Terms and Conditions']")]
		private IWebElement _general_Testing_ApNonCardPaymentsTesting_TermsAndConditions { get; set; }
		public void NavigateTo_General_Testing_ApNonCardPaymentsTesting_TermsAndConditions()
		{
			NavigateToMenuItem(_general_Testing_ApNonCardPaymentsTesting_TermsAndConditions);
		}

		
		private void NavigateToMenuItem(IWebElement element)
		{
			Driver.Url = element.GetAttribute("href");
		}
		#endregion

		public ApnonCardTesting(GlobalSettings settings) : base(settings) { }
	}  
}
