using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using Common;
using Common.PageObjects;
using Common.ScenarioConfigurations;
using Common.Utility;

namespace EnCompass.Testing.Source.PageObjects.Organization.SecurityManager.UserAccount 
{
	/// <summary>
	/// Auto-generated Page Model Class
	/// Navigation Paths: 
		/// [Organization Home]->UserAccount->->Challenge Questions
		/// </summary>
	[PageModel(@"/securityManager/userAccount/EditChallengeQuestions.aspx")]
	public partial class EditChallengeQuestions : EnCompassOrgPageModel 
	{
		public override string RelativeUrl => @"/securityManager/userAccount/EditChallengeQuestions.aspx";
		public override string PageIdentifierXPath_Generated => @"//li[contains(@class, 'breadcrumb-item active')][text() = 'Challenge Questions']";

		#region Navigation
				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Contact Information']")]
		private IWebElement _useraccount__ChallengeQuestions_ContactInformation { get; set; }
		public void NavigateTo_Useraccount__ChallengeQuestions_ContactInformation()
		{
			NavigateToMenuItem(_useraccount__ChallengeQuestions_ContactInformation);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Login Credentials']")]
		private IWebElement _useraccount__ChallengeQuestions_LoginCredentials { get; set; }
		public void NavigateTo_Useraccount__ChallengeQuestions_LoginCredentials()
		{
			NavigateToMenuItem(_useraccount__ChallengeQuestions_LoginCredentials);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Challenge Questions']")]
		private IWebElement _useraccount__ChallengeQuestions_ChallengeQuestions { get; set; }
		public void NavigateTo_Useraccount__ChallengeQuestions_ChallengeQuestions()
		{
			NavigateToMenuItem(_useraccount__ChallengeQuestions_ChallengeQuestions);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Preferences']")]
		private IWebElement _useraccount__ChallengeQuestions_Preferences { get; set; }
		public void NavigateTo_Useraccount__ChallengeQuestions_Preferences()
		{
			NavigateToMenuItem(_useraccount__ChallengeQuestions_Preferences);
		}

		
		private void NavigateToMenuItem(IWebElement element)
		{
			Driver.Url = element.GetAttribute("href");
		}
		#endregion

		public EditChallengeQuestions(GlobalSettings settings) : base(settings) { }
	}  
}
