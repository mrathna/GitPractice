package com.framework.testcases.AJS.BP;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.AdminPage;
import com.framework.pages.AJS.common.IFCSHomePage;
import com.framework.pages.AJS.common.IFCSLoginPage;
import com.github.javafaker.Faker;

public class ValidateAndCreateNewIFCSUserTestCases extends BaseTest {
	/*
	 * Updated by Davu - 13/05/2020
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "Regression", "BusinessFlow" })
	public void validateToCreateNewIFCSUserwithCustomerAssigned(@Optional("AU") String clientCountry,
			@Optional("BP") String clientName) {

		test = extent.createTest(clientName + ":" + clientCountry + " Verify Sys_AU_003_Create new customer IFCS User",
				"Sys_AU_003_Create new customer IFCS user");

		// creating object for the Pages
		IFCSLoginPage ifcsLoginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage ifcsHomePage = new IFCSHomePage(driver, test);

		AdminPage ifcsAdminPage = new AdminPage(driver, test);

		ifcsLoginPage.login("IFCS_URL_BP", "IFCS_BP_USERNAME", "IFCS_BP_PASSWORD");
		ifcsLoginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		
		ifcsHomePage.gotoAdminMenuAndChooseClientGroup();
		Faker fakerN = new Faker();
		String testName1 = fakerN.name().firstName() + "_" + fakerN.name().lastName() + fakerN.number().digits(2);
		String testPwd = "Password" + fakerN.number().digits(2);
		// Select Desktop user
		ifcsAdminPage.chooseDesktopMenuFromSecurityMenu();
		// Create
		ifcsAdminPage.validateAndCreateIFCSNewUsersEnterDetails(testName1, testPwd, clientName);
		ifcsAdminPage.validateAndEnterUserLimites();
		ifcsAdminPage.clickSaveButtonAndValidate();
		ifcsHomePage.exitIFCS();
		ifcsLoginPage.loginWithNewUser("IFCS_URL_BP", testName1, testPwd);
		ifcsLoginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		ifcsHomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);
		ifcsHomePage.exitIFCS();
	}

}
