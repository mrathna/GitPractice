﻿using Common;
using Common.Utility;
using EnCompass.Testing.Source.PageObjects.Controls;
using EnCompass.Testing.Source.Utility;
using NFluent;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Support.UI;
using System;

namespace EnCompass.Testing.Source.PageObjects.Organization.Admin.AccountProfiles
{
    [PageModel(@"/admin/accountProfiles/editUserProfile.aspx")]
	public class EditUserProfile : EnCompassOrgPageModel
	{
		public override string RelativeUrl => @"/admin/accountProfiles/editUserProfile.aspx";
        public override string PageIdentifierXPath_Override => @"//h1[contains(@id,'title')]";

        #region Navigation

        private void NavigateToMenuItem(IWebElement element)
		{
			Driver.Url = element.GetAttribute("href");
		}
        #endregion

        #region XPath page Elements

        private const string _addNewUserProfileXPath = @"//a[@href='editUserProfile.aspx']";
        private const string _descriptionTextBoxXPath = @"//input[contains(@id,'descriptionTextBox')]";
        private const string _roleDropdownXPath = @"//select[contains(@id,'roleDropdown')]";
        private const string _statusDropdownXPath = @"//select[contains(@id,'statusDropdown')]";
        private const string _hierarchyLinkXPath = @"//a[contains(@id, 'hierarchyExplorer')]";
        private const string _addNewWorkflowHierarchyXPath = @"//input[contains(@id,'addNewButton')]";
        private const string _selectXPath = @"//a[contains(@id,'select')]";
        private const string _typeUserAssignXPath = @"//select[contains(@id,'ddlSelectUserType')]";
        private const string _thresholdValueXPath = @"//input[contains(@id,'thresholdValue')]";
        private const string _saveXPath = @"//input[contains(@id,'saveButton')]";
        private const string _errorMessageXPath = @"//div[contains(@id,'ValidationSummary')]";
        private const string workFlowHierarchy_Xpath = "//select[contains(@id,'ddlSelectWorkflow')]";
        private const string NameTextBox_Xpath = "//input[contains(@id,'nameTextBox')]";
        private const string _nextXpath = @"//input[contains(@id,'nextButton')]";
        private const string _successMessageXPath = @"//div[contains(@id,'SuccessMessage')]";
        #endregion

        #region Page Elements
        private IWebElement _addNewUserProfile
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_addNewUserProfileXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Info("Found _addNewUserProfile");
                return element;
            }
        }

        private IWebElement _descriptionTextBox
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_descriptionTextBoxXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Info("Found _descriptionTextBox");
                return element;
            }
        }

        private IWebElement _roleDropdown
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_roleDropdownXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Info("Found _roleDropdown");
                return element;
            }
        }

        private IWebElement _statusDropdown
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_statusDropdownXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Info("Found _statusDropdown");
                return element;
            }
        }

        IWebElement _hierarchyLink
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_hierarchyLinkXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Info("Found _hierarchyLink");
                return element;
            }
        }

        private IWebElement _addNewWorkflowHierarchy
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_addNewWorkflowHierarchyXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Info("Found _addNewWorkflowHierarchy");
                return element;
            }
        }

        private IWebElement _select
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_selectXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Info("Found _select");
                return element;
            }
        }

        private IWebElement _typeUserAssign
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_typeUserAssignXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Info("Found _typeUserAssign");
                return element;
            }
        }

        private IWebElement _thresholdValue
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_thresholdValueXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Info("Found _thresholdValue");
                return element;
            }
        }

        private IWebElement _save
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_saveXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Info("Found _save");
                return element;
            }
        }

        private IWebElement _errorMessage
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_errorMessageXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Info("Found _errorMessage");
                return element;
            }
        }
        #endregion

        public void AddNewUserProfile()
        {
            _addNewUserProfile.JSClickWithFocus(Driver);
            WaitForLoad();
        }

        public void WaitForSuccessMsg()
        {
            WebDriverWait wait = new WebDriverWait(Driver, TimeSpan.FromSeconds(20));
            wait.Until(ExpectedConditions.ElementIsVisible(By.XPath(@"//div[contains(@id,'SuccessMessage')]")));
        }

        public string NameTextBox
        {
            set
            {
                Driver.TryWaitForElementToBeVisible(By.XPath(NameTextBox_Xpath), out IWebElement _nameTextBox);
                _nameTextBox.Clear();
                _nameTextBox.SendKeys(value);
            }
        }

        public string getNameTextBox
        {
            get
            {
                Driver.TryWaitForElementToBeVisible(By.XPath(NameTextBox_Xpath), out IWebElement _nameTextBox);
                return _nameTextBox.Text;
            }
        }

        public string DescriptionTextBox
        {
            set
            {
                _descriptionTextBox.Clear();
                _descriptionTextBox.SendKeys(value);
            }
        }

        public string getDescriptionTextBox
        {
            get
            {
                return _descriptionTextBox.Text;
            }
        }

		/// <summary>
		/// Sets user Role based on rolename and modify flag
		/// </summary>
		/// <param name="whichText">rolename</param>
		/// <param name="modify">if True then ensure rolename is made unique. if False, use the input value</param>
		public void SetUserRole(string whichText, bool modify = true)
        {
			var selectElement = new SelectElement(_roleDropdown);
			if (modify)
			{
				//The Organization Id is being concatenated in order to ensure the uniqueness of the role.
				// get the actual role name
				string newRoleName = RoleHelper.Instance.GetNewRoleName(whichText, Settings.CeatedOrgId);				
				selectElement.SelectByText(newRoleName);
			}
			else
				selectElement.SelectByText(whichText);
		}

        public void SetUserStatus(string whichText)
        {
            var selectElement = new SelectElement(_statusDropdown);
            selectElement.SelectByText(whichText);
        }

        public void SetWorkflowHierarchy(string whichText)
        {
            Driver.TryWaitForElementToBeVisible(By.XPath(workFlowHierarchy_Xpath), out IWebElement _workflowHierarchy);
            var selectElement = new SelectElement(_workflowHierarchy);
            selectElement.SelectByText(whichText);
        }

        //Accessing OrgHierarchy object which has the common functionality of Choosing the TOP Org as its Hierarchy Option.
        private OrgHierarchy _hierarchy;
        public OrgHierarchy Hierarchy
        {
            get
            {
                return _hierarchy ?? (_hierarchy = new OrgHierarchy(_hierarchyLink, Driver, Settings));
            }
        }

        public void PressNext()
        {
            ScrollToXPATH(_nextXpath);

            Driver.TryWaitForElementToBeVisible(By.XPath(_nextXpath), out IWebElement _next);
            _next.JSClickWithFocus(Driver, _nextXpath,Settings);
            Settings.EnCompassExtentTest.Info("Button next clicked");
        }

        public void PressAddWorkflowHierarchy()
        {
            Driver.TryWaitForElementToBeVisible(By.XPath(_addNewWorkflowHierarchyXPath), out IWebElement addNewworkflowHierarchy);
            addNewworkflowHierarchy.JSClickWithFocus(Driver);
        }

        public void PressSelect()
        {
            _select.JSClickWithFocus(Driver);
        }

        public void SetTypeUserAssign(string whichText)
        {
            var selectElement = new SelectElement(_typeUserAssign);
            selectElement.SelectByText(whichText);
        }

        public string Threshold
        {
            get
            {
                return _thresholdValue.Text;
            }
            set
            {
                _thresholdValue.Clear();
                _thresholdValue.SendKeys(value);
            }
        }

        public void PressSave()
        {
            _save.JSClickWithFocus(Driver);
			this.AttachOnDemandScreenShot();
		}

        public string ErrorMessage
        {
            get
            {
                return _errorMessage.Text;
            }
        }

        public void ErrorMessageDescription()
        {
            Check.That(ErrorMessage.Contains("Description is a required value.")).IsTrue();
        }

        public void ErrorMessageName()
        {
            Check.That(ErrorMessage.Contains("Name is a required value.")).IsTrue();
        }

        public EditUserProfile(GlobalSettings settings) : base(settings) { }
	}
}