﻿
using AventStack.ExtentReports;
using NFluent;
using OpenQA.Selenium;
using OpenQA.Selenium.Appium.Android;
using OpenQA.Selenium.Appium.iOS;
using OpenQA.Selenium.Appium.Windows;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Internal;
using OpenQA.Selenium.Remote;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;

namespace Common.Utility
{
    public enum SelectTextOptions { Exact, StartsWith, EndsWith, Contains }

    public static class SeleniumExtensions
    {

		#region IWebDriver Extensions

		#region Windows Element

		/// <summary>
		/// Find Windows Element using dynamic wait (fluent wait)
		/// </summary>
		public static RemoteWebElement FindWindowsElement(this WindowsDriver<RemoteWebElement> _winDriver, By by, ExtentTest test,
			int timeout = 30, int poll = 1)
		{
			DefaultWait<WindowsDriver<RemoteWebElement>> wait = new DefaultWait<WindowsDriver<RemoteWebElement>>(_winDriver)
			{
				Timeout = TimeSpan.FromSeconds(timeout),
				PollingInterval = TimeSpan.FromSeconds(poll)
			};
			wait.IgnoreExceptionTypes(typeof(WebDriverException));

			try
			{
				test.Debug("Dynamic Fluent Wait to find element : "+ by.ToString());
				return wait.Until(d => d.FindElement(by));
			}catch(Exception ex)
			{
				test.Error("Exception thrown while Fluent Wait was in progress for Windows Driver");
				test.Debug("Inner Exception Type : " + ex.InnerException);
				test.Debug("Exception Message : " + ex.Message);
				throw ex;
			}
		}

		#endregion

		public static bool TrySwitchToIframeWithChild(this IWebDriver driver, By childBy, out IWebElement element, By framePath = null, TimeSpan? tSpan = null)
        {
            try
            {
                IReadOnlyCollection<IWebElement> frames = (framePath == null) ? driver.FindElements(By.TagName("iframe")) : driver.WaitForElements(framePath, TimeSpan.FromSeconds(5));
                if (!frames.All(d => d.TagName.Equals("iframe", StringComparison.InvariantCultureIgnoreCase)))
                {
                    element = null;
                    return false;
                }

                foreach (var frame in frames)
                {
                    try
                    {
                        driver.SwitchTo().Frame(frame);
                        bool isFound = (framePath == null) ? TryFindElement(driver, childBy, out element) : TryWaitForElement(driver, childBy, out element, tSpan);

                        if (isFound)
                        {
                            return true;
                        }
                        else
                            continue;
                    }
                    catch (StaleElementReferenceException)
                    {
                        continue;
                    }
                }
            }
            catch (Exception) { }

            driver.SwitchTo().DefaultContent();
            element = null;
            return false;
        }

        public static bool TrySwitchToIframeWithChilds(this IWebDriver driver, By childBy, out IReadOnlyCollection<IWebElement> elements, By framePath = null)
        {
            IReadOnlyCollection<IWebElement> frames = (framePath == null) ? driver.FindElements(By.TagName("iframe")) : driver.WaitForElements(framePath, TimeSpan.FromSeconds(5));
            if (!frames.All(d => d.TagName.Equals("iframe", StringComparison.InvariantCultureIgnoreCase)))
            {
                elements = null;
                return false;
            }
            elements = null;
            foreach (var frame in frames)
            {
                try
                {
                    driver.SwitchTo().Frame(frame);
                    elements = (framePath == null) ? driver.FindElements(childBy) : driver.WaitForElements(childBy);
                    bool isFound = (elements.Count > 0) ? true : false;
                    if (isFound)
                    {
                        return true;
                    }
                    else
                        continue;
                }
                catch (StaleElementReferenceException)
                {
                    continue;
                }
            }

            driver.SwitchTo().DefaultContent();
            elements = null;
            return false;
        }

        /// <summary>
        /// Checks if the frame is loaded by ensuring visibility of modal body
        /// </summary>
        public static bool IsFrameLoaded(this IWebDriver _driver, ExtentTest test)
        {
            string _frameBodyXpath = ".//body[@class='iframe-modal']//div[contains(@class,'modal-body')]";
            bool flag =  _driver.TryWaitForElementToBeVisible(By.XPath(_frameBodyXpath), out IWebElement _frameBody);
            test.Debug("Waited for IsFrameLoaded with xpath : "+ _frameBodyXpath + "  yielded :" + flag);
            return flag;
        }


        public static bool IsElementPresent(this IWebDriver driver, By by)
        {
            try
            {
                driver.WaitForVisible(by, TimeSpan.FromSeconds(1));
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        public static IWebElement WaitFor(this IWebDriver driver, By by, TimeSpan? tSpan = null)
        {
            WebDriverWait wait = new WebDriverWait(driver, tSpan ?? TimeSpan.FromSeconds(20));
            wait.Until(ExpectedConditions.ElementExists(by));

            return driver.FindElement(by);
        }

        public static IReadOnlyCollection<IWebElement> WaitForElements(this IWebDriver driver, By by, TimeSpan? tSpan = null)
        {
            WebDriverWait wait = new WebDriverWait(driver, tSpan ?? TimeSpan.FromSeconds(20));
            return wait.Until(ExpectedConditions.PresenceOfAllElementsLocatedBy(by));
        }

        public static IReadOnlyCollection<IWebElement> WaitForElementsToBeVisible(this IWebDriver driver, By by, TimeSpan? tSpan = null)
        {
            WebDriverWait wait = new WebDriverWait(driver, tSpan ?? TimeSpan.FromSeconds(20));
            return wait.Until(ExpectedConditions.VisibilityOfAllElementsLocatedBy(by));
        }


		public static IWebElement WaitForVisible(this IWebDriver driver, By by, TimeSpan? tSpan = null)
		{
			WebDriverWait wait = new WebDriverWait(driver, tSpan ?? TimeSpan.FromSeconds(20));
			return wait.Until(ExpectedConditions.ElementIsVisible(by));	
		}

        public static void WaitForAbsence(this IWebDriver driver, By by, TimeSpan? tSpan = null)
        {
            WebDriverWait wait = new WebDriverWait(driver, tSpan ?? TimeSpan.FromSeconds(20));
            wait.Until(ExpectedConditions.InvisibilityOfElementLocated(by));
        }

        public static string GetRootUrl(this IWebDriver driver,string currentURL = null)
        {
			string url = null;
			try
			{
				if (string.IsNullOrWhiteSpace(driver.Url))
				{
					return null;
				}
				else
					url = driver.Url;
			}catch(Exception)
			{
				// IE specific change
				IJavaScriptExecutor js = (IJavaScriptExecutor)driver;
				url = (String)js.ExecuteScript("return window.location.href.toString()");
			}

            var uri = new Uri(url);
            return $"{uri.Scheme}://{uri.Authority}";
        }

        // Returns if the Element has Focus or not.
        public static bool ElementHasFocus(this IWebDriver driver, By by, TimeSpan? tSpan = null)
        {
            WebDriverWait wait = new WebDriverWait(driver, tSpan ?? TimeSpan.FromSeconds(20));
            return driver.SwitchTo().ActiveElement().Selected;
        }

        public static string GetRelativeUrl(this IWebDriver driver)
        {
            if (string.IsNullOrWhiteSpace(driver.Url))
            {
                return null;
            }

            var uri = new Uri(driver.Url);
            return $"{uri.AbsolutePath}";
        }

		/// <summary>
		/// Waits default 10 secs for an alert to appear and returns true or false.
		/// </summary>
		public static bool IsAlertPresent(this IWebDriver driver, TimeSpan? tSpan = null)
		{
			bool _alertFound = false;
			try
			{
				WebDriverWait wait = new WebDriverWait(driver, tSpan ?? TimeSpan.FromSeconds(10));
				wait.Until(ExpectedConditions.AlertIsPresent());				
				_alertFound = true;
			}
			catch (Exception) { 
				// If alert is not present then do nothing as False will be returned
			}

            return _alertFound;
        }

        public static void AcceptAlert(this IWebDriver driver)
        {
            try
            {
                IAlert alert = driver.SwitchTo().Alert();
                alert.Accept();
            }
            catch { throw new Exception("No Alert was found."); }
            finally { driver.SwitchTo().DefaultContent(); }
        }

        public static void DismissAlert(this IWebDriver driver)
        {
            try
            {
                IAlert alert = driver.SwitchTo().Alert();
                alert.Dismiss();
            }
            catch { throw new Exception("No Alert was found."); }
            finally { driver.SwitchTo().DefaultContent(); }
        }

        public static void WriteToAlert(this IWebDriver driver, string textToWrite)
        {
            try
            {
                IAlert alert = driver.SwitchTo().Alert();
                alert.SendKeys(textToWrite);
            }
            catch { throw new Exception("No Alert was found."); }
            finally { driver.SwitchTo().DefaultContent(); }
        }

        public static string ReadAlert(this IWebDriver driver)
        {
            try
            {
                IAlert alert = driver.SwitchTo().Alert();
                return alert.Text;
            }
            catch { throw new Exception("No Alert was found."); }
            finally { driver.SwitchTo().DefaultContent(); }
        }

		public static void ExpandAll(this IWebDriver driver)
		{
			var element = driver.FindElement(By.XPath("//button[@data-accordion-expand-text='Expand All'][1]"));
			var data = driver.FindElement(By.XPath("//button[@data-accordion-expand-text='Expand All'][1]")).GetAttribute("data-action");
			if (data == "collapse")
			{
				element.JSClickWithFocus(driver);
				WebDriverWait wait = new WebDriverWait(driver, System.TimeSpan.FromSeconds(20));
				wait.Until(ExpectedConditions.TextToBePresentInElement(element, "Expand All"));
				element.JSClickWithFocus(driver);
				wait.Until(ExpectedConditions.TextToBePresentInElement(element, "Collapse All"));
			}

			if (data == "expand")
			{
				element.JSClickWithFocus(driver);
				WebDriverWait wait = new WebDriverWait(driver, System.TimeSpan.FromSeconds(20));
				wait.Until(ExpectedConditions.TextToBePresentInElement(element, "Collapse All"));
			}
		}

        // overloaded method for TryFindElement using the other extension method to wait for element dynamically
        public static bool TryWaitForElement(this IWebDriver driver, By by, out IWebElement el, TimeSpan? tSpan = null)
        {
            try
            {
                //el = driver.WaitForVisible(by, tSpan);
                //for UX, Selenium visibility is determined by 'for' label. Hence, it overlays the input tag and waitforvisible doesn't work for UX.
                el = driver.WaitFor(by, tSpan);
            }

            catch (Exception)
            {
                el = null;

                return false;
            }

            return true;
        }

        // overloaded method for TryFindElement using the other extension method to wait for element dynamically
        public static bool TryWaitForElements(this IWebDriver driver, By by, out IReadOnlyCollection<IWebElement> el, TimeSpan? tSpan = null)
        {
            try
            {
                el = driver.WaitForElements(by, tSpan);
            }

            catch (Exception)
            {
                el = null;
                return false;
            }

            return true;
        }

        /// <summary>
		/// overloaded method for TryFindElements using the other extension method to wait for elements dynamically
		/// </summary>
        public static bool TryWaitForElements(this IWebDriver driver, By by, out IList<IWebElement> el, TimeSpan? tSpan = null)
        {
            try
            {
                //for UX, Selenium visibility is determined by 'for' label. Hence, it overlays the input tag and waitforvisible doesn't work for UX.
                el = driver.WaitForElements(by, tSpan).ToList();
            }

            catch (Exception)
            {
                el = null;

                return false;
            }

            return true;
        }

        /// <summary>
        /// Used existing extensiom method "WaitForVisible" to identify the IwebElement and returns true if found else false
        /// </summary>
        public static bool TryWaitForElementToBeVisible(this IWebDriver driver, By by, out IWebElement el, TimeSpan? tSpan = null)
        {
            try
            {
                el = driver.WaitForVisible(by, tSpan);
				el.JsScrollToElement(driver);
            }
            catch (Exception)
            {
                el = null;

                return false;
            }

            return true;
        }

		/// <summary>
		/// Waits until the specific attribute does not indicate the value specified for the attribute
		/// and returns a bool value along with the IWebElement as out parameter
		/// </summary>
		public static bool WaitForElementAttributeToChange(this IWebDriver driver, string elementXpath, string attributeName,
			string attrValue, int tspan = 10)
		{
			try
			{
				
				WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(tspan));
				wait.Until(d => d.WaitFor(By.XPath(elementXpath)).GetAttribute(attributeName).ToLowerInvariant().Trim().Contains(attrValue.ToLowerInvariant().Trim()));
				return true;
			} catch(WebDriverTimeoutException)
			{
				// This would mean the timeout expired and the attribute value did not match
				return false;
			}
			catch(WebDriverException ex)
			{
				// rethrow, since it would probably mean the GetAttribute call failed due to multiple reasons
				// like attribute not present.
				throw ex;
			}
		}

        /// <summary>
        /// Used existing extensiom method "WaitForElementsToBeVisible" to identify the list of IwebElements and returns true if found else false
        /// </summary>
        public static bool TryWaitForElementsToBeVisible(this IWebDriver driver, By by, out IList<IWebElement> elements, TimeSpan? tSpan = null)
        {
            try
            {
                elements = driver.WaitForElementsToBeVisible(by).ToList();
            }
            catch (Exception)
            {
                elements = null;
                return false;
            }

            return true;
        }

        /// <summary>
        /// This checks if the page has loaded completly and is in ready state.
        /// It uses javascript to check for this
        /// </summary>
        public static void WaitForDocumentLoadToComplete(this IWebDriver driver, string _initialPageSource = null, ExtentTest test = null)
		{
			// If initial page source is not provided, then grab the current page source as initial source
			_initialPageSource = (_initialPageSource != null) ? _initialPageSource : driver.PageSource.ToString();
			WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(20));

            // Wait for document to be in ready state
            try
            {
                wait.Until(d => ((IJavaScriptExecutor)d).ExecuteScript("return document.readyState").ToString().Equals("complete"));              
            }
            catch (WebDriverTimeoutException ex)
            {
                if (test != null)
                {
                    test.Debug("Exception StackTrace: " + ex.StackTrace);
                    test.Debug("Exception Message: " + ex.Message);
                }
                throw ex;
            }
            catch (Exception e)
            {
                // Retry Logic: Forced wait for 2 secs needed as there is no good way to stop 
                // System.Collections.ListDictionaryInternal Message is:TypeError: curContainer.frame.document.documentElement is null 
                if (test != null)
                {
                    test.Debug("\"return document.readyState\" Javascript execution failed on Driver, Retrying with a 2 secs wait!");
                    test.Debug("Exception StackTrace: " + e.StackTrace);
                    test.Debug("Exception Message: " + e.Message);
                }
                if (!GlobalSettings.Browser.Equals(GlobalSettings.Browsers.IE.ToString()))
                {
                    System.Threading.Thread.Sleep(2000);
                    wait.Until(d => ((IJavaScriptExecutor)d).ExecuteScript("return document.readyState").ToString().Equals("complete"));
                }
			}
		}

        public static void WaitElementBeClickable(this IWebDriver driver, string xpath, TimeSpan? waitTime = null)
        {
            WebDriverWait wait = new WebDriverWait(driver, waitTime ?? TimeSpan.FromSeconds(20));
            wait.Until(ExpectedConditions.ElementToBeClickable(By.XPath(xpath)));
            driver.WaitForDocumentLoadToComplete();
        }

        //Method Scroll for finding the element on the page
        public static void ScrollToXPATH(this IWebDriver driver, string xpath)
        {
            IWebElement element = driver.WaitFor(By.XPath(xpath), TimeSpan.FromSeconds(20));
			// Use Javascript to scroll as this is most reliable.
			((IJavaScriptExecutor)driver).ExecuteScript("arguments[0].focus();", element);
            ((IJavaScriptExecutor)driver).ExecuteScript("arguments[0].scrollIntoView(true);", element);
            //Actions actions = new Actions(driver);
            //actions.MoveToElement(element);
            //actions.Perform();
        }

        //Method Scroll to the Bottom of the page
        public static void JsScrollToBottom(this IWebDriver driver)
        {
            ((IJavaScriptExecutor)driver).ExecuteScript("window.scrollTo(0,document.body.scrollHeight);");
        }

		//Javascript Scroll to the Top of the page
		public static void JsScrollToTop(this IWebDriver driver)
		{
			((IJavaScriptExecutor)driver).ExecuteScript("window.scrollTo(0,0);");			
		}

		/// <summary>
		/// In Mobile devices Select class do not work, esp with Safari, hence we need to inject Javascript
		/// to fire off the change event post selection of the item
		/// </summary>
		public static void SelectDDLOptionByTextViaJS(this IWebDriver driver, GlobalSettings settings, string ddlXpath,
            string ddlOptionText, bool isOnIframe = false, SelectTextOptions option = SelectTextOptions.Exact)
        {
            settings.EnCompassExtentTest.Info("Need to use Javascript to select DDL option as this is mobile device");

            // verify input params are not null or empty
            settings.EnCompassExtentTest.Info("Checking Global Setting object is not null");
            Check.That(settings).IsNotNull();
            settings.EnCompassExtentTest.Info("Checking ddlXpath is not null or empty");
            Check.That(String.IsNullOrEmpty(ddlXpath)).IsFalse();
            settings.EnCompassExtentTest.Info("Checking ddlOptionText object is not null or empty");
            Check.That(String.IsNullOrEmpty(ddlOptionText)).IsFalse();

            IJavaScriptExecutor executor = (IJavaScriptExecutor)driver;

            // IF it is on an IFRAME then we need a different JS to interact within it
            String dropdownScript = (isOnIframe) ? "var iframe = document.getElementsByTagName('iframe')[0];" +
                //"var iframe = document.evaluate(\".//iframe[contains(@id,'IFrameModal_')]\", document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null ).singleNodeValue;" +
                "var innerDoc = iframe.contentDocument || iframe.contentWindow.document; " +
                "var select = document.evaluate(\"" + ddlXpath + "\", innerDoc.body, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null ).singleNodeValue;"
                    :
                "var select = document.evaluate(\"" + ddlXpath + "\", document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null ).singleNodeValue;";					

            // Append the common JS script to iterate over the Select options and select the value
            dropdownScript += "for(var i = 0; i < select.options.length; i++)" +
                       "{if (select.options[i].text{ReplaceOption})" +
                        "{ select.options[i].selected = true; } }" +
                    "var ev = document.createEvent('Event');" +
                    "ev.initEvent('change', true, true);" +
                    "select.dispatchEvent(ev);";

			// As per the Select Text Option set the function in the JS
			switch (option)
			{
				case SelectTextOptions.StartsWith:
					dropdownScript = dropdownScript.Replace("{ReplaceOption}", ".startsWith('" + ddlOptionText +"')");
					break;
				case SelectTextOptions.Contains:
					dropdownScript = dropdownScript.Replace("{ReplaceOption}", ".includes('" + ddlOptionText + "')");
					break;
				case SelectTextOptions.EndsWith:
					dropdownScript = dropdownScript.Replace("{ReplaceOption}", ".endsWith('" + ddlOptionText + "')");
					break;
				case SelectTextOptions.Exact:
					dropdownScript = dropdownScript.Replace("{ReplaceOption}", "=='" + ddlOptionText + "'");
					break;
			}

					settings.EnCompassExtentTest.Debug("Java script to be executed : " + dropdownScript);

            if (isOnIframe)
            {
                driver.SwitchTo().DefaultContent();
                settings.EnCompassExtentTest.Debug("Driver Switched to Default window from Iframe");
            }
            executor.ExecuteScript(dropdownScript);
            settings.EnCompassExtentTest.Debug("Java script executed !!");

            if (isOnIframe)
            {
                IWebElement iframe = driver.FindElement(By.XPath(".//iframe[contains(@id,'IFrameModal_')]"));
                settings.EnCompassExtentTest.Debug("Got Iframe as WebElement !!");
                driver.SwitchTo().Frame(iframe);
                settings.EnCompassExtentTest.Debug("Driver Switched back to Iframe");
            }
        }

        /// <summary>
		/// In Mobile devices Select class do not work, esp with Safari, hence we need to inject Javascript
		/// to fire off the change event post selection of the item
		/// </summary>
		public static void SelectDDLOptionByIndexViaJS(this IWebDriver driver, GlobalSettings settings, string ddlXpath,
            string index, bool isOnIframe = false)
        {
            // verify input params are not null
            Check.That(settings).IsNotNull();
            Check.That(! String.IsNullOrEmpty(ddlXpath)).IsTrue();
            Check.That(! String.IsNullOrEmpty(index)).IsTrue();

            IJavaScriptExecutor executor = (IJavaScriptExecutor)driver;

            // IF it is on an IFRAME then we need a different JS to interact within it
            String dropdownScript = (isOnIframe) ? "var iframe = document.getElementsByTagName('iframe')[0];" +
                "var innerDoc = iframe.contentDocument || iframe.contentWindow.document; " +
                "var select = document.evaluate(\"" + ddlXpath + "\", innerDoc.body, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null ).singleNodeValue;"
                    :
                "var select = document.evaluate(\"" + ddlXpath + "\", document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null ).singleNodeValue;";

            // Append the common JS script to iterate over the Select options and select the value
            dropdownScript += "select.options[" + index + "].selected = true;" +
                    "var ev = document.createEvent('Event');" +
                    "ev.initEvent('change', true, true);" +
                    "select.dispatchEvent(ev);";

            settings.EnCompassExtentTest.Debug("Java script to be executed : " + dropdownScript);
            
            if (isOnIframe)
            {
                driver.SwitchTo().DefaultContent();
                settings.EnCompassExtentTest.Debug("Driver Switched to Default window from Iframe");
            }
            executor.ExecuteScript(dropdownScript);
            settings.EnCompassExtentTest.Debug("Java script executed !!");

            if (isOnIframe)
            {
                IWebElement iframe = driver.FindElement(By.XPath(".//iframe[contains(@id,'IFrameModal_')]"));
                settings.EnCompassExtentTest.Debug("Got Iframe as WebElement !!");
                driver.SwitchTo().Frame(iframe);
                settings.EnCompassExtentTest.Debug("Driver Switched back to Iframe");
            }
        }

        /// <summary>
        /// Hack to handle unwanted popups on mobile browsers refer - https://www.browserstack.com/automate/handle-popups-alerts-prompts-in-automated-tests
        /// Note the below doesn't work, its just a placeholder for future
        /// </summary>
        public static void AllowPopUpsOnMobileBrowsersOnActualDevices(this IWebDriver driver, ExtentTest test)
		{
			if (GlobalSettings.MobileOS.Equals(GlobalSettings.MobileOSList.ANDROID.ToString()))
			{
				(driver as AndroidDriver<IWebElement>).Context = ("NATIVE_APP");
				IWebElement _androidPopupContinueButton = driver.FindElement(By.XPath(".//android.widget.Button[@text='Continue']"));
				test.Info("Got _androidPopupContinueButton" + _androidPopupContinueButton.Text);
				_androidPopupContinueButton.JSClickWithFocus(driver);
				test.Info("Clicked on Continue button to handle unwanted popup on Android device");
			}
			else
			{
				(driver as IOSDriver<IWebElement>).Context = ("NATIVE_APP");
				IWebElement _iOSPopupAllowButton = driver.FindElement(By.Id("Allow"));
				test.Info("Got _iOSPopupAllowButton" + _iOSPopupAllowButton.Text);
				_iOSPopupAllowButton.JSClickWithFocus(driver);
				test.Info("Clicked on Allow button to handle unwanted popup on iOS device");
			}
		}

        #endregion

        #region ISearchContext Extensions

        public static bool TryFindElement(this ISearchContext ctx, By by, out IWebElement el)
        {
            try
            {
                el = ctx.FindElement(by);
            }
            catch (Exception)
            {
                el = null;

                return false;
            }

            return true;
        }

		#endregion

		#region IWebElement Extensions

        /// <summary>
        /// Windows Driver Screenshot utility
        /// </summary>
        public static void TakeWinDriverScreenshot(this RemoteWebElement element, GlobalSettings _settings)
        {
            ScreenshotHelper.OnDemandWinDriverScreenshot(element.GetScreenshot(), _settings);
        }
		
		/// <summary>
		/// Scroll to an IWebElement using JavaScript
		/// </summary>
		public static IReadOnlyCollection<IWebElement> WaitForElements(this IWebElement element, IWebDriver driver, By by, TimeSpan? tSpan = null)
		{
			IReadOnlyCollection<IWebElement> elements = null;
			WebDriverWait wait = new WebDriverWait(driver, tSpan ?? TimeSpan.FromSeconds(20));
			wait.Until(d => (elements = d.FindElements(by)).Count > 0);
			return elements;
		}

		/// <summary>
		/// Focus on an IWebElement using JavaScript
		/// </summary>
		public static void JsFocusOnElement(this IWebElement element, IWebDriver driver)
		{
			((IJavaScriptExecutor)driver).ExecuteScript("arguments[0].focus();", element);
		}

		/// <summary>
		///  Method Scroll for finding the element on the page using JavaScript
		/// </summary>
		public static void JsScrollToElement(this IWebElement element, IWebDriver driver)
        {
            ((IJavaScriptExecutor)driver).ExecuteScript("arguments[0].scrollIntoView(true);", element);
			((IJavaScriptExecutor)driver).ExecuteScript("arguments[0].focus();", element);
		}

        /// <summary>
        /// On Bootstrap UI we're observing that normal webdriver click often misfires and it needs multiple attempts
        /// Thus trying a new way to submit or cancel a form using SendKeys
        /// </summary>
        /// <param name="element"></param>
        /// Added a Try/Catch if sendkeys not work
        public static void BootstrapClick(this IWebElement element)
		{
            try
            {				
				element.WaitUntilElementIsInteractable();
				element.Click();
			}
            catch (Exception)
			{
				// Keys.Return will work  for Firefox https://github.com/seleniumhq/selenium-google-code-issue-archive/issues/2079 
				element.SendKeys(Keys.Return);
            }			
		}
		
        /// <summary>
        /// This serves 2 purposes - 
        /// 1. It explicitly forces JS focus on the element before interacting with it
        /// 2. It clicks on the element but uses JS injection again.
		/// 3. For Mobile devices, if element Xpath is specified, it finds the element using Evaluate and 
		///    forces onClick() event to be fired on the element internally.
		///  NOTE -  if the click happens on an IFRAME, then the mobile specific JS will not work. We need to make adjustments
		///          to the JS to identify the frame first and then do the click. Refer to implementation done for SelectDDL
        /// </summary>
        public static void JSClickWithFocus(this IWebElement element, IWebDriver driver, string elementXpath = null,
			GlobalSettings settings = null, bool isIFrame = false)
        {
            element.WaitUntilElementIsInteractable();
			if (settings != null)
				settings.EnCompassExtentTest.Debug("IwebElement in interactable");

            element.JsScrollToElement(driver);
			if (settings != null)
				settings.EnCompassExtentTest.Debug("Scrolled to IWebElement");
          
            // Finds the element using Evaluate and OnClick event to be fired on the element in safari based on XPath, OS-iOS and Browser-Safari
            if (elementXpath != null && GlobalSettings.MobileOS.Equals(GlobalSettings.MobileOSList.IOS.ToString()))
            {
				Check.That(settings).IsNotNull();
				// Force OnClick event to be fired on the element if 
				// element xpath is provided
				string js = "var ele = document.evaluate(\"" + elementXpath + "\", document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null ).singleNodeValue;"
					+ "var ev = document.createEvent('Event');ev.initEvent('click', true, true);ele.dispatchEvent(ev);";
				settings.EnCompassExtentTest.Debug("Javascript to be executed: " + js);
				((IJavaScriptExecutor)driver).ExecuteScript(js);
			}
			else
				((IJavaScriptExecutor)driver).ExecuteScript("arguments[0].click();", element);

			if (settings != null)
				settings.EnCompassExtentTest.Debug("Javascript is executed.");
		}

		/// <summary>
		/// We've observed at times SendKeys enters incomplete values or no values.
		/// It appears this happend only when the document load is not complete and the 
		/// UI rendering is incomplete (such as to make WaitForLoad() call a pass)
		/// </summary>
		public static void ForceDocumentLoadOnSendKeys(this IWebElement element, string value, IWebDriver driver,ExtentTest test = null)
		{
			driver.WaitForDocumentLoadToComplete();            
			element.WaitUntilTextBoxIsInteractable();
            element.Clear();
            element.SendKeys(value);
		}

		/// <summary>
		/// Execute JS to find and input values on a particualt WebElement
		/// </summary>
		public static void JSSendKeys(this IWebElement element,IWebDriver driver, string value, string elementXpath = null)
		{
            IJavaScriptExecutor js = (IJavaScriptExecutor)driver;
            if (elementXpath == null)
            {
                element.JsScrollToElement(driver);
                element.Clear();
                js.ExecuteScript("arguments[0].value='" + value + "';", element);
            }
            else
            {
                //In chrome Desktop,for some textbox set value fails with jssendkeys hence finding and setting the text via js
                string script = "var element = document.evaluate(\"" + elementXpath + "\",document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null ).singleNodeValue;" + "element.value=\"" + value + "\";";
                js.ExecuteScript(script);
            }
            
		}

        /// <summary>
        /// Only for Text boxes elements to be interactable (Displayed + Enabled). We've observed selenium exception rarely complainig about - 
        /// "System.Reflection.TargetInvocationException : Exception has been thrown by the target of an invocation. 
        /// OpenQA.Selenium.InvalidElementStateException : invalid element state: Element is not currently interactable and may not be manipulated"
        /// More details on this at - https://github.com/SeleniumHQ/selenium/issues/4314
        /// </summary>
        private static void WaitUntilTextBoxIsInteractable(this IWebElement element)
        {
            string ss = element.GetAttribute("nodeName").ToLowerInvariant();            
            Check.That(element.GetAttribute("nodeName").ToLowerInvariant()).IsOneOfThese("input", "textarea");
            ss = element.GetAttribute("type").ToLowerInvariant();
            Check.That(element.GetAttribute("type").ToLowerInvariant()).IsOneOfThese("text", "password", "textarea", "email", "number", "tel", "currency");
            bool elementIsInteractable = false;
            int counter = 0;
            do
            {
                counter++;
                if (element.Enabled)
                {
                    if (element.Displayed)
                        elementIsInteractable = true;
                }
                // Sleep for 100ms and then try again for a max of 5 secs (50 iterations)
                Thread.Sleep(100);
            } while ((!elementIsInteractable) && counter < 50);
        }

		/// <summary>
		/// Wait till Element is Displayed and Enabled
		/// </summary>
        public static void WaitUntilElementIsInteractable(this IWebElement element)
        {
            bool elementIsInteractable = false;
            int counter = 0;
            do
            {
                counter++;
                if (element.Enabled)
                {
                    if (element.Displayed)
                        elementIsInteractable = true;
                }
                // Sleep for 100ms and then try again for a max of 3 secs (30 iterations)
                Thread.Sleep(100);
            } while ((!elementIsInteractable) && counter < 30);
        }

        public static void SetCheckboxState(this IWebElement element, bool checkStatus)
        {
            if (!(element.TagName.Equals("input", StringComparison.InvariantCultureIgnoreCase) &&
                   element.GetAttribute("type").Equals("checkbox", StringComparison.InvariantCultureIgnoreCase)
                 )
              )
            {
                throw new Exception($"Element is either not an input tag or of type checkbox.");
            }

            bool isChecked = element.Selected;
            if (isChecked != checkStatus)
            {
                element.BootstrapClick();
            }
        }

		/// <summary>
		/// This one takes Checkboxes whose labels needs to be clicked to turn it on or off
		/// </summary>
		public static void SetCheckboxStateWithLabel(this IWebElement element, IWebElement labelToClick, bool checkStatus,IWebDriver driver = null)
		{
            if (labelToClick != null && driver != null)
                labelToClick.JsScrollToElement(driver);

			if (!(element.TagName.Equals("input", StringComparison.InvariantCultureIgnoreCase) &&
				   element.GetAttribute("type").Equals("checkbox", StringComparison.InvariantCultureIgnoreCase)
				 )
			  )
			{
				throw new Exception($"Element is either not an input tag or of type checkbox.");
			}
           
            bool isChecked = element.Selected;
            if (isChecked != checkStatus)
			{
				if (labelToClick == null)
				{
                    // Never change this to Bootstrapclick.  There are some instances where we need to click in input
                    // elemenet rather than label.
                    try
                    {
                        element.WaitUntilElementIsInteractable();
                        element.SendKeys(Keys.Space);
                    }
                    catch (Exception ex)
                    {
                        //Sometimes sendkeys fails in IE hence trying with js sendkeys
                        element.JSSendKeys(driver,Keys.Space);
                    }
				}
				else
				{
                    if (GlobalSettings.DeviceType.Equals(GlobalSettings.Device.MOBILE.ToString()) && driver != null)
                        element.JSClickCheckBox(driver);
                    else
                        element.ClickCheckBox();
                }
			}
		}

		/// <summary>
		/// This one takes Checkboxes whose labels needs to be clicked to turn it on or off
		/// using JavaScript injection to scroll to label and then click
		/// </summary>
		public static void SetCheckboxStateWithLabelJS(this IWebElement element, IWebDriver driver, bool checkStatus)
		{
			if (!(element.TagName.Equals("input", StringComparison.InvariantCultureIgnoreCase) &&
				   element.GetAttribute("type").Equals("checkbox", StringComparison.InvariantCultureIgnoreCase)
				 )
			  )
			{
				throw new Exception($"Element is either not an input tag or of type checkbox.");
			}

			bool isChecked = element.Selected;
			if (isChecked != checkStatus)
			{
				IWebElement label = element.FindElement(By.XPath("./following-sibling::label"));
				label.WaitUntilElementIsInteractable();
				label.JSClickWithFocus(driver);
			}
		}

        /// <summary>
        /// This one takes RatdioButtons whose labels needs to be clicked to turn it on or off
        /// using JavaScript injection to scroll to label and then click
        /// </summary>
        public static void SetRadioButtonStateWithLabelJS(this IWebElement element, IWebDriver driver, bool checkStatus)
        {
            if (!(element.TagName.Equals("input", StringComparison.InvariantCultureIgnoreCase) &&
                   element.GetAttribute("type").Equals("radio", StringComparison.InvariantCultureIgnoreCase)
                 )
              )
            {
                throw new Exception($"Element is either not an input tag or of type Radio button.");
            }

            bool isChecked = element.Selected;
            if (isChecked != checkStatus)
            {
                IWebElement label = element.FindElement(By.XPath("./following-sibling::label"));
                label.WaitUntilElementIsInteractable();
                label.JSClickWithFocus(driver);
            }
        }

        public static void ClickCheckBox(this IWebElement element)
        {
            IWebElement label = element.FindElement(By.XPath("./following-sibling::label"));
            label.WaitUntilElementIsInteractable();

            label.BootstrapClick();
        }

        public static void JSClickCheckBox(this IWebElement element, IWebDriver driver)
        {
            IWebElement label = element.FindElement(By.XPath("./following-sibling::label"));
            label.WaitUntilElementIsInteractable();

            label.JSClickWithFocus(driver);
        }

        public static void SetRadioButtonState(this IWebElement element, bool checkStatus)
        {
            if (!(element.TagName.Equals("input", StringComparison.InvariantCultureIgnoreCase) ||
                   element.GetAttribute("type").Equals("radio", StringComparison.InvariantCultureIgnoreCase))
                )
            {
                throw new Exception($"Element is either not an input tag or of type radio button.");
            }
            bool isChecked = element.Selected;
            if (isChecked != checkStatus)
            {
                element.ClickCheckBox();  //JSClickWithFocus(Driver);
            }
        }

        public static void SetRadioButtonStateWithLabel(this IWebElement element, IWebElement labelToClick, bool checkStatus, IWebDriver driver = null, ExtentTest test = null)
        {
            if (!(element.TagName.Equals("input", StringComparison.InvariantCultureIgnoreCase) ||
                   element.GetAttribute("type").Equals("radio", StringComparison.InvariantCultureIgnoreCase)
                   ||
                   element.TagName.Equals("label", StringComparison.InvariantCultureIgnoreCase))
                )
            {
                throw new Exception($"Element is either not an input tag or of type radio button.");
            }
            if(test!=null)
                test.Info("check for status");
            bool isChecked = element.Selected;
            if (test != null)
                test.Info("Element status " +isChecked);
            if (isChecked != checkStatus)
            {
                if (labelToClick == null)
                {
                    element.SendKeys(Keys.Space);
                }
                else
                {
                    labelToClick.WaitUntilElementIsInteractable();
                    if (driver != null)
                        labelToClick.JSClickWithFocus(driver);
                    else
                        labelToClick.BootstrapClick();
                }
            }

        }


        /// <summary>
        /// This method sets the List box value by passed Text. The option param can be any of: StartsWith, EndsWith, Contains, Exact.
        /// </summary>
        /// <param name="element"></param>
        /// <param name="whichText"></param>
        /// <param name="option"></param>
        public static void SetListboxByText(this IWebElement element, string whichText, SelectTextOptions option = SelectTextOptions.Exact,
            IWebDriver driver = null, GlobalSettings settings = null, string ddlXpath = null, bool isIFrame = false)
        {
            if (!element.TagName.Equals("select", StringComparison.InvariantCultureIgnoreCase))
            {
                throw new Exception($"Element is not a select tag.");
            }

            SelectElement selectElement = new SelectElement(element);
            switch (option)
            {
                case SelectTextOptions.StartsWith:
                    whichText = whichText.Trim().ToUpperInvariant();
                    var startsWithOption = selectElement.Options.FirstOrDefault(o => o.Text.Trim().ToUpperInvariant().StartsWith(whichText));
                    if (startsWithOption != null)
                    {
                        string optionValue = startsWithOption.Text;
                        if (GlobalSettings.DeviceType.Equals(GlobalSettings.Device.MOBILE.ToString()))
                        {
                            driver.SelectDDLOptionByTextViaJS(settings, ddlXpath, optionValue, isIFrame, option);
                            settings.EnCompassExtentTest.Info("Selected option :" + optionValue);
                        }
                        else
                            selectElement.SelectByText(optionValue);
                    }
                    else
                    {
                        throw new Exception($"Unable to select option starting with this text, '{whichText}'");
                    }
                    break;
                case SelectTextOptions.EndsWith:
                    whichText = whichText.Trim().ToUpperInvariant();
                    var endsWithOption = selectElement.Options.FirstOrDefault(o => o.Text.Trim().ToUpperInvariant().EndsWith(whichText));
                    if (endsWithOption != null)
                    {
                        string optionValue = endsWithOption.Text;
                        if (GlobalSettings.DeviceType.Equals(GlobalSettings.Device.MOBILE.ToString()))
                        { 
                            driver.SelectDDLOptionByTextViaJS(settings, ddlXpath, optionValue, isIFrame, option);
                            settings.EnCompassExtentTest.Info("Selected option :" + optionValue);
                        }
                        else
                            selectElement.SelectByText(optionValue);
                    }
                    else
                    {
                        throw new Exception($"Unable to select option ending with this text, '{whichText}'");
                    }
                    break;
                case SelectTextOptions.Contains:
                    whichText = whichText.Trim().ToUpperInvariant();
                    var containsOption = selectElement.Options.FirstOrDefault(o => o.Text.Trim().ToUpperInvariant().Contains(whichText));
                    if (containsOption != null)
                    {
                        string optionValue = containsOption.Text;
                        if (GlobalSettings.DeviceType.Equals(GlobalSettings.Device.MOBILE.ToString()))
                        { 
                            driver.SelectDDLOptionByTextViaJS(settings, ddlXpath, optionValue, isIFrame, option);
                            settings.EnCompassExtentTest.Info("Selected option :" + optionValue);
                        }
                        else
                            selectElement.SelectByText(optionValue);
                    }
                    else
                    {
                        throw new Exception($"Unable to select option containing this text, '{whichText}'");
                    }
                    break;
                default:
                case SelectTextOptions.Exact:
                    if (GlobalSettings.DeviceType.Equals(GlobalSettings.Device.MOBILE.ToString()))
                    { 
                        driver.SelectDDLOptionByTextViaJS(settings, ddlXpath, whichText, isIFrame, option);
                        settings.EnCompassExtentTest.Info("Selected option :" + whichText);
                    }
                    else
                        selectElement.SelectByText(whichText);
                    break;
            }
        }

        public static void SetListboxByValue(this IWebElement element, string whichValue)
        {
            if (!element.TagName.Equals("select", StringComparison.InvariantCultureIgnoreCase))
            {
                throw new Exception($"Element is not a select tag.");
            }
            var selectElement = new SelectElement(element);
            selectElement.SelectByValue(whichValue);
        }

        public static void SetListboxByIndex(this IWebElement element, int whichIndex,
            IWebDriver driver = null, GlobalSettings settings = null, string ddlXpath = null, bool isIFrame = false)
        {
            if (!element.TagName.Equals("select", StringComparison.InvariantCultureIgnoreCase))
            {
                throw new Exception($"Element is not a select tag.");
            }

            var selectElement = new SelectElement(element);
            if (GlobalSettings.DeviceType.Equals(GlobalSettings.Device.MOBILE.ToString()))
            {
                driver.SelectDDLOptionByIndexViaJS(settings, ddlXpath, whichIndex.ToString(), isIFrame);
                settings.EnCompassExtentTest.Info("Selected option at Index :" + whichIndex);
            }
            else
                selectElement.SelectByIndex(whichIndex);
        }

        public static void SetTextboxValue(this IWebElement element, string whichText)
        {
            //if(!element.TagName.Equals("input", StringComparison.InvariantCultureIgnoreCase) || !element.TagName.Equals("textarea", StringComparison.InvariantCultureIgnoreCase))
            //{
            //	throw new Exception($"Element is neither input nor a textarea");
            //}
            element.Clear();
            element.SendKeys(whichText);
        }

        /// <summary>
        /// Get Webdriver from WebElement (only elements found via FindElement(s) call)
        /// NOTE - If you use PageFactory to get the Driver it will not work (https://github.com/seleniumhq/selenium/issues/1490)
        /// </summary>
        public static IWebDriver GetWebDriver(this IWebElement element)
        {
            var realElement = element.GetType() == typeof(RemoteWebElement)
                ? element
                : (element as IWrapsElement)?.WrappedElement;
            if (realElement == null)
            {
                throw new Exception($"Unable to get WebDriver from IWebElement");
            }
            return ((IWrapsDriver)realElement).WrappedDriver;
        }

        /// <summary>
        /// This method goes FORWARD 1 step in the browser history.
        /// </summary>
        /// <param name="driver"></param>
        public static void BrowserGoForward(this IWebDriver driver)
        {
            driver.Navigate().Forward();
        }

        /// <summary>
        /// This method goes BACK 1 step in the browser history.
        /// </summary>
        /// <param name="driver"></param>
        public static void BrowserGoBack(this IWebDriver driver)
        {
            driver.Navigate().Back();
        }

		/// <summary>
		/// This method Refreshes the current page.
		/// </summary>
		/// <param name="driver"></param>
		public static void BrowserRefresh(this IWebDriver driver,ExtentTest test)
		{
			driver.Navigate().Refresh();
			if (GlobalSettings.Browser.Equals("FIREFOX"))
			{
				if (driver.IsAlertPresent())
				{
					driver.AcceptAlert();
					test.Info("Accepted Alert after Refresh.");
				}
			}
			test.Info("Browser Refreshed");
		}

        public static bool IsCurrentPage(this IWebDriver driver, string relativeUrl, string pageIdentifierXPath)
        {
            if (!string.IsNullOrWhiteSpace(relativeUrl))
            {
                return driver.GetRelativeUrl().Equals(relativeUrl, StringComparison.InvariantCultureIgnoreCase);
            }
            return driver.IsElementPresent(By.XPath(pageIdentifierXPath));
        }

        /// <summary>
		/// This method calls the backspace a number of times to clear the placeholder value (default is 10).
		/// </summary>
		/// <param name="element"></param>
        public static void ClearWithBackspace(this IWebElement element, int sendKeysTimes = 10)
        {
            int counter = 0;
            do
            {
                counter++;
                element.SendKeys(Keys.Backspace);
            } while (counter < sendKeysTimes);
        }
        #endregion

        #region Open Page in new Tab
        /// <summary>
		/// Method which takes care of reading the new page from the input IWebElement, 
		/// opening a new tab and navigate to the new tab i.e last tab
		/// </summary>
		public static void OpenLinkInNewTab(this IWebDriver driver, IWebElement linkToOpen, int _expWindowCount, GlobalSettings settings,string windowName)
		{
			// read the Url from PO
			string _urlToGo = linkToOpen.GetAttribute("href");
            settings.EnCompassExtentTest.Info("Got the href details on UI - " + _urlToGo);

            // Open a new tab in the browser
            IJavaScriptExecutor js = (IJavaScriptExecutor)driver;
            //if (GlobalSettings.DeviceType.Equals(GlobalSettings.Device.MOBILE.ToString()))
            //{
            //    // Mobile specific change				
            //    //driver.AllowPopUpsOnMobileBrowsersOnActualDevices(settings.EnCompassExtentTest);
            //    //driver.OpenNewTabUsingJSInMobileSafari(settings, _urlToGo);
            //    linkToOpen.JSClickWithFocus(driver);
            //    settings.EnCompassExtentTest.Info("Clicked on the link using Javascript");
            //    List<string> contextList = (driver as IOSDriver<IWebElement>).Contexts.ToList();
            //    Check.That(contextList.Count).IsEqualTo(_expWindowCount);
            //    settings.EnCompassExtentTest.Info("Verified total window handles matched expected count of : " + _expWindowCount);

            //    // Switch to new Tab (i.e 2nd tab) and navigate to url stored
            //    (driver as IOSDriver<IWebElement>).Context = contextList.ElementAt(_expWindowCount - 1);
            //    //driver.SwitchTo().Window(contextList.ElementAt(_expWindowCount - 1));
            //    settings.Scenario[windowName] = (driver as IOSDriver<IWebElement>).Context;//driver.CurrentWindowHandle;
            //    settings.EnCompassExtentTest.Info("Switched to the new window handle");
            //}
            //else
            //{
                js.ExecuteScript("window.open();");
                settings.EnCompassExtentTest.Info("Executed Javascript to open a new tab/window");

			    // Get the list of window handles
			    List<string> windows = driver.WindowHandles.ToList();
			    Check.That(windows.Count).IsEqualTo(_expWindowCount);
			    settings.EnCompassExtentTest.Info("Verified total window handles matched expected count of : " + _expWindowCount);

			    // Switch to new Tab (i.e 2nd tab) and navigate to url stored
			    driver.SwitchTo().Window(windows.ElementAt(_expWindowCount - 1));
			    settings.Scenario[windowName] = driver.CurrentWindowHandle;
			    settings.EnCompassExtentTest.Info("Switched to the new window handle");

			    // Cannot use Navigate call as this is not a encompass page
			    driver.Url = _urlToGo;
			    settings.EnCompassExtentTest.Info("Navigating to Url : " + _urlToGo);
            //}

        }

        /// <summary>
        /// This DOESN't Work on actual mobile devices
        /// </summary>
		public static void OpenNewTabUsingJSInMobileSafari(this IWebDriver driver, GlobalSettings settings, string urlToOpen)
		{
			// Create link in memory
			string _openLinkInNewTabViaJS = "var a = window.document.createElement('a');" +
				"a.target = '_blank'; " +
				"a.href = '" + urlToOpen + "';" +
	 			" var e = window.document.createEvent('MouseEvents'); " +
				"e.initMouseEvent('click', true, true, window, 0, 0, 0, 0, 0, false, false, false, false, 0, null);" +
				"a.dispatchEvent(e);";
			settings.EnCompassExtentTest.Debug("Javascript = " + "\n" + _openLinkInNewTabViaJS);
			IJavaScriptExecutor js = (IJavaScriptExecutor)driver;
			js.ExecuteScript(_openLinkInNewTabViaJS);
			settings.EnCompassExtentTest.Info("Executed Javascript to open a new tab/window and navigate " +
				"to the url for a mobile device.");
		}


		#endregion
	}
}
