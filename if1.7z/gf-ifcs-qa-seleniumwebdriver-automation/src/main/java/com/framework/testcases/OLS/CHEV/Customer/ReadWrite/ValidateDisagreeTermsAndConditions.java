package com.framework.testcases.OLS.CHEV.Customer.ReadWrite;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.ClientConfigPage;
import com.framework.pages.AJS.common.Common;
import com.framework.pages.AJS.common.IFCSHomePage;
import com.framework.pages.AJS.common.IFCSLoginPage;
import com.framework.pages.OLS.common.LoginPage;
import com.github.javafaker.Faker;

public class ValidateDisagreeTermsAndConditions extends BaseTest {
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "Regression" })
	public void validateDisagreeTermsAndConditions(@Optional("SG") String clientCountry,
			@Optional("CHEVRON") String clientName){
		

		test = extent.createTest(clientName+ ":" +clientCountry+"  OLS - Disagree Terms and Conditions", "OLS - Disagree Terms and Conditions");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCShomePage = new IFCSHomePage(driver, test);
		LoginPage loginPage = new LoginPage(driver, test);
		Common common = new Common(driver, test);
		ClientConfigPage clientConfigPage = new ClientConfigPage(driver, test);
	
		IFCSloginPage.login("IFCS_URL_CHEVRON", "IFCS_CHEVRON_USERNAME", "IFCS_CHEVRON_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		IFCShomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);
		//IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);
		//IFCShomePage.gotoAdminMenuAndChooseClientGroup();
		String initialMandatoryFrequencyValue=clientConfigPage.goToOLSMandatoryPage();
		if(initialMandatoryFrequencyValue.equalsIgnoreCase("First Time")||initialMandatoryFrequencyValue.equalsIgnoreCase("Every Single Login")) {
			IFCShomePage.gotoAdminMenuAndChooseClientGroup();
			common.goToOnlineUsers();
			Faker fakerN = new Faker();
			String testName = fakerN.name().firstName()+"_"+fakerN.name().lastName()+fakerN.number().digits(2);
			String testPwd = "Password"+fakerN.number().digits(2);
			System.out.println(testName);
			String merchantNo = common.getMerchantNoFromDB();
			IFCShomePage.createNewOlsMerchantOrCustomerUser(testName,testPwd,"Merchant Read Only",merchantNo,"Merchant"," ");
		
			IFCShomePage.exitIFCS();
			// Login to the OLS Application
			loginPage.validateLoginPageFooterLinks(clientName, "CHV_URL");
			loginPage.loginAndValidateDisagree(testName, testName);
			loginPage.Logout();
		}else {
			common.logInfo(clientName+"Client Config is not setup for this client");
		}
		IFCShomePage.exitIFCS();
	}

}
