package com.framework.testcases.AJS.SHELL;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.MaintainAccountPage;
import com.framework.pages.AJS.MaintainCustomerPage;
import com.framework.pages.AJS.common.Common;
import com.framework.pages.AJS.common.IFCSHomePage;
import com.framework.pages.AJS.common.IFCSLoginPage;

public class ValidateAccountTestCases extends BaseTest {

	@Parameters({ "clientCountry", "clientName", "cardType" }) 
	@Test( groups = { "Regression" })
	public void orderNewCardWithInvalidAccountSubStatus(@Optional("RU") String clientCountry,
			@Optional("SHELL") String clientName, @Optional("APA") String cardType) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  SHELL IFCS Order New Card - Invalid Account Sub-Status",
				"17 Maintain Customer -  Card Details -  Order New Card - Invalid  Account Sub-Status");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test); 
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		Common common = new Common(driver, test);
		MaintainCustomerPage maintainCustomerPage = new MaintainCustomerPage(driver, test);

		IFCSloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, cardType);

		// Getting Customer No With AccountSubStatus as Payment Pending From DB
		String customerNoWithSubStatusAsPaymentPending = common.getCustomerNoWithAccountSubStatusAsPaymentPending();

		if (customerNoWithSubStatusAsPaymentPending.equals("")) {

			common.logForNoDataFound(this.getClass().getSimpleName(),
					"Need to Create A Customer with Account SubStatus as Payment Pending and rerun");
		} else {
			// Verify the customer Account details
			IFCSHomePage.gotoAccountAndClickAccountDetails();
			common.chooseCustomerNoAndSearch(customerNoWithSubStatusAsPaymentPending);
			maintainCustomerPage.checkAccountSubStatusAsPaymentPending();

			// Order a new card
			IFCSHomePage.gotoCustomerMenuCustomerDetails();
			maintainCustomerPage.validateSubStatusDoesNotPermitMessage(clientName, clientCountry);
		}
		IFCSHomePage.exitIFCS();

	}

	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test( groups = { "Regression" })
	public void createASundryCreditAdjustment(@Optional("RU") String clientCountry,
			@Optional("SHELL") String clientName, @Optional("APA") String cardType) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  Maintain Account-Sundry Adjustment", "Sundry Credit Adjustment");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		Common common = new Common(driver, test);
		MaintainAccountPage maintainAccountPage = new MaintainAccountPage(driver, test);
		IFCSloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, cardType);
		IFCSHomePage.gotoAccountAndClickAccountDetails();
		String customerNo = common.getActiveCustomerNoUsingCardType();
		if (customerNo.equals("")) {

			common.logForNoDataFound(this.getClass().getSimpleName(),
					"Need to Create A Customer with Card Type and rerun");
		} else {
		IFCSHomePage.gotoAccountAndClickAccountDetails();
		common.chooseCustomerNoAndSearch(customerNo);
		// common.chooseCardNoAndSearch("RUA0000019");
		String currentIFCSDateforEffAt = common.getCurrentIFCSDateFromDB(clientName + clientCountry);
		String effDate = common.enterADateValueInStatusBeginDateField("Current", currentIFCSDateforEffAt);

		maintainAccountPage.validateSundryAdjustment(customerNo, effDate);
		IFCSHomePage.gotoTransactionAndClickManageTransaction();
		maintainAccountPage.verifySundryCreditTransaction();
		}
		IFCSHomePage.exitIFCS();
	}

	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test( groups = { "Regression" })
	public void maintainAccountFeesAttachAFeeProfile(@Optional("RU") String clientCountry,
			@Optional("SHELL") String clientName, @Optional("APA") String cardType) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  SHELL IFCS Maintain Account - Account Profiles -Account Fees - Attach a Fee Profile",
				"15 Maintain Account - Account Profiles -Account Fees - Attach a Fee Profile");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		Common common = new Common(driver, test);
		MaintainAccountPage maintainAccountPage = new MaintainAccountPage(driver, test);

		IFCSloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, cardType);

		// Getting Active Customer No From DB
		String customerNoUsingCardType = common.getActiveCustomerNoUsingCardType();

		// Attach A Fee Profile for Account Fees
		IFCSHomePage.gotoAccountAndClickAccountDetails();
		common.chooseCustomerNoAndSearch(customerNoUsingCardType);
		maintainAccountPage.attachAFeeProfile();
		maintainAccountPage.validateDateAssignedOnUpdate();

		IFCSHomePage.exitIFCS();

	}

	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test( groups = { "Regression" })
	public void maintainAccountFeesCreateAPrivateFeeProfile(@Optional("RU") String clientCountry,
			@Optional("SHELL") String clientName, @Optional("APA") String cardType) {
		test = extent.createTest(
				"SHELL IFCS Maintain Account -Account Profiles-Account Fees-Create a Private Fee Profile",
				"16 Maintain Account -Account Profiles-Account Fees-Create a Private Fee Profile");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		Common common = new Common(driver, test);
		MaintainAccountPage maintainAccountPage = new MaintainAccountPage(driver, test);

		IFCSloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, cardType);

		// Getting Active Customer No From DB
		String customerNoUsingCardType = common.getActiveCustomerNoUsingCardType();

		// Create A Private fee Profile For Account Fees
		IFCSHomePage.gotoAccountAndClickAccountDetails();
		common.chooseCustomerNoAndSearch(customerNoUsingCardType);
		maintainAccountPage.createAPrivateFeeProfile();
		maintainAccountPage.enterDetailsToCreatePrivateFeeProfile();
		IFCSHomePage.exitIFCS();

	}
}
