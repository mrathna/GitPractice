package com.framework.pages.SHELL;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.ExtentTest;
import com.framework.basepage.BasePage;
import com.framework.repo.Locator;

public class SHELLSupportPage extends BasePage{
	
	
	@FindBy(id = Locator.LEGAL_NOTICE_SHELL)
	public WebElement legalNoticeFooterLink;
	
	@FindBy(id=Locator.CONTACT_ACC_NUM_TB)
	public WebElement contactAccNumber;
	
	@FindBy(id=Locator.CONTACT_ACC_NAME_TB)
	public WebElement contactAccName;
	
	@FindBy(id=Locator.MESSAGE_ABOUT_SEL)
	public WebElement selectQueryType;
	
	@FindBy(id=Locator.CONTACT_MESSAGE_TA)
	public WebElement comments;
	
	@FindBy(id=Locator.CONTACT_US_NAME)
	public WebElement contactName;
	
	@FindBy(id=Locator.CONTACT_US_PH)
	public WebElement contactUsPhone;
	
	@FindBy(xpath=Locator.CONTACT_US_EMAIL)
	public WebElement contactUsEmail;
	
	@FindBy(xpath=Locator.EMAIL_RADIO)
	public WebElement emailRadioBTN;
	
	@FindBy(xpath=Locator.PHONE_RADIO)
	public WebElement phoneRadioBTN;
	
	@FindBy(xpath=Locator.NONE_RADIO)
	public WebElement noneRadioBTN;
	
	@FindBy(id=Locator.CONTACT_US_QUERY_SUBMIT)
	public WebElement contactUsSubmit;
	
	@FindBy(id=Locator.EMAIL_FIELD)
	public WebElement emailTBFromProfile;

	// Added by Ayub  on 20.06.2018 
	
	@FindBy(id = Locator.CLOSE_ACCOUNT)
	public WebElement closeAccount;
	
	@FindBy(id = Locator.COMMENT_BOX)
	public WebElement commentBox;	
	
	@FindBy(id = Locator.CLOSE_ACCOUNT_SUBMIT_BT)
	public WebElement closeAccountSubmitBT;
	
	@FindBy(id = Locator.UPLOAD_BUTTON)
	public WebElement uploadButton;
	
	@FindBy(id = Locator.UPLOAD_POPUP_PANEL)
	public WebElement uploadPopup;
	
	@FindBy(css = Locator.BROWSE_FILE_BUTTON)
	public WebElement browseFile;
	
	@FindBy(xpath = Locator.UPLOAD_FILE)
	public WebElement uploadFile;
	
	public SHELLSupportPage(WebDriver driver, ExtentTest test) {
		super(driver, test);
		PageFactory.initElements(driver, this);
	}

	public void validateContactUsPageFooterLinks() {
		sleep(5);
//		checkTextInPageAndValidate("Contact Us", 30);
//		scrollDownPage();
		isDisplayed(legalNoticeFooterLink, "Legal Notice Footer Link is displayed");
	}
	
	public void clickAndValidatePageRedirectingToNewTab() {
		String getLink = legalNoticeFooterLink.getAttribute("href").split(":")[1];
		System.out.println("getLinkgetLink-----:"+getLink);
		validateClickableLinkRedirection(legalNoticeFooterLink, getLink);
	}
	
	public void clickAndValidatePageRedirectingToNewTabContains() {
		String getLink = legalNoticeFooterLink.getAttribute("href").split(":")[1];
		System.out.println("getLinkgetLink-----:"+getLink);
		validateClickableLinkRedirectionContains(legalNoticeFooterLink, "shell");
	}

	/*
	 * validateTheContactUsPage
	 * Added by Anton
	 */
	
	public void validateTheContactUsPageFields() {
		// TODO Auto-generated method stub
		
		checkTextInPageAndValidate("Account Number", 30);
		checkTextInPageAndValidate("Account Name", 30);
		checkTextInPageAndValidate("Select Query Type", 30);
		checkTextInPageAndValidate("Comments", 30);
		checkTextInPageAndValidate("Contact Name", 30);
		checkTextInPageAndValidate("Phone Number", 30);
		checkTextInPageAndValidate("Email", 30);
		
		isDisplayed(contactAccNumber, "Account Number in Contact Us");
		isDisplayed(contactAccName, "Account Name in Contact Us"); 
		
		isDisplayed(contactName, "Contact Name in Contact Us");
		isDisplayed(contactUsPhone, "Phone Number in Contact Us");
		isDisplayed(contactUsEmail, "Email in Contact Us"); 
		
	}
	
	/*
	 * Validate The Contact us Page functions by changing the contact preferences.
	 * Added by Anton 19/06/2018
	 */
	public void validateTheContactUsPageFunctionality()
	{		 
		isDisplayed(selectQueryType, "Select Query Type in Contact Us");
		
		selectDropDownOptionsRandomly(selectQueryType, "Select QueryType Dropdown");
		
		isDisplayedThenEnterText(comments, "Comments in Contact Us",fakerAPI().internet().slug());
		
		checkTextInPageAndValidate("Contact Preference", 30);
		
		validateTheBlankEmailWithEmailPreference();
		
		validateTheBlankPhoneWithPhonePreference();
		
		validateTheNoneContactPreference();
		
		validateWithRandomEmailForContactPreference();
		
		validateWithRandomPhoneForContactPreference();
		
	}
	/*
	 * Verify the validateTheContactPreferences
	 * 
	 */
	public void validateTheBlankEmailWithEmailPreference()
	{			
		verifyContactPreferenceWithorWithoutBlankValues(emailRadioBTN, "Email", contactUsEmail, contactUsSubmit, "Email Required", true);
	}
	
	public void validateTheBlankPhoneWithPhonePreference()
	{
		verifyContactPreferenceWithorWithoutBlankValues(phoneRadioBTN, "Phone", contactUsPhone, contactUsSubmit, "Phone Number required", true);
	}
	
	public void validateTheNoneContactPreference()
	{
		String successMsg = "Email was sent successfully";
		
		isDisplayedThenActionClick(noneRadioBTN, "NONE Radio button");
		
		if(noneRadioBTN.isSelected())
		{
			
			isDisplayedThenClick(contactUsSubmit, "Submit With none option selected");
			
			sleep(3);
			
			checkTextInPageAndValidate(successMsg, 20);
		}
	}
	
	
	public void validateWithRandomEmailForContactPreference()	
	{
		verifyContactPreferenceWithorWithoutBlankValues(emailRadioBTN, "Email", contactUsEmail, contactUsSubmit, "Email Required", false);
	}
	
	public void validateWithRandomPhoneForContactPreference()	
	{
		verifyContactPreferenceWithorWithoutBlankValues(phoneRadioBTN, "Phone", contactUsPhone, contactUsSubmit, "Phone Number required", false);
	}
	
	
	/*
	 * 
	 * Common method for Phone and Email
	 */
	
	public void verifyContactPreferenceWithorWithoutBlankValues(WebElement radioButton, String type, WebElement contactTB, WebElement submitBTN, String verifyMsg, boolean isBlank)
	{
		isDisplayedThenClickRadioBTN(radioButton, type+" radio button");
		
		String inputVal="";
		
		if(radioButton.isSelected())
		{
			if(isBlank)
			{
				isDisplayedThenClearText(contactTB, type+" text box in Contact us");
			}
			
			else
			{
				if(type.equals("Email"))
				{
					inputVal = fakerAPI().internet().emailAddress();
				}
				else if(type.equals("Phone"))
				{
					inputVal = fakerAPI().phoneNumber().cellPhone();
				}
				else {
					//if required for any feature update
				}
				isDisplayedThenEnterText(contactTB, type+" text box in Contact us", inputVal);
			}
			
			isDisplayedThenClick(submitBTN, "Submit the Button");
			
			sleep(5);
			
			if(isBlank)
			{
				checkTextInPageAndValidate(verifyMsg, 20);
			}
			else
			{
				sleep(5);
				
				checkTextInPageAndValidate("Email was sent successfully", 20);
			}
		}
	}

	public void typeCommentAndSubmit() {
		isDisplayedThenEnterText(commentBox, "Make comment ", fakerAPI().name().username().toString());
		isDisplayedThenClick(closeAccountSubmitBT, "Submit the comment");
		sleep(2);
		checkTextInPageAndValidate("Email was sent successfully", 20);
	}
	
 
	
	public String getDefaultEmailAddress()
	{
		String emailAddress="";
		
		isDisplayed(emailTBFromProfile, "Email from Profile");
		
		emailAddress = emailTBFromProfile.getAttribute("value");
		
		return emailAddress;
	}
	
	public void validateContactUsPage() {
		checkTextInPageAndValidate("CONTACT US", 20);
	}
	 
	public void clickUploadButtonAndValidate() {
		isDisplayedThenActionClick(uploadButton, "Click Upload Button");
		sleep(3);
		isDisplayed(uploadPopup, "Upload Popup Displayed");
		
	}
	
	public void validateBrowseFileFromLocal() {			
		isDisplayedThenActionClick(browseFile, "Click Browse File");
		sleep(3);
		uploadTheExcelSheetFromTheLocal("ShellLogo");
	}
	
	public void clickUploadFileButtonFromPopup() {
		sleep(3);
		isDisplayedThenActionClick(uploadFile, "Click upload file button");
		sleep(5);
	}
	// Added by Ayub on 06-08-2018
	
	public boolean verifyCloseAccountDetailsareAvailable()
	{
		boolean isCloseAccount = false;
		
		isCloseAccount = waitForTextToAppear("You cannot close any Account", 30);		
		
		return isCloseAccount;
	}
	
	public void printNoAccountDetailsDataPresent() {
		logInfo("No Account Details are present");	
		sleep(3);
	}
}
