package com.framework.testcases.OLS.BP.Customer;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.BP.BPAccountPage;
import com.framework.pages.BP.BPHomePage;
import com.framework.pages.OLS.common.BPCommonPage;
import com.framework.pages.OLS.common.CostCentrePage;
import com.framework.pages.OLS.common.LoginPage;
import com.framework.pages.OLS.common.ViewAndEditCostCentrePage;

public class ValidateCustomerCostCentrePage extends BaseTest {
	@Parameters({ "clientCountry", "clientName" })

	@Test( groups = { "Smoke", "Regression" })
	public void checkCustomerCostCentrePage(@Optional("AU") String clientCountry, @Optional("BP") String clientName)
	 {
		test = extent.createTest(clientName+ ":" +clientCountry+"  20 - Customers Cost Centre Page", "Customer CostCentre Page");

		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		BPHomePage bpHomePage = new BPHomePage(driver, test);
		BPAccountPage bpAccountPage = new BPAccountPage(driver, test);
		BPCommonPage bpCommonPage = new BPCommonPage(driver, test);
		ViewAndEditCostCentrePage viewAndEditCostCentrePage = new ViewAndEditCostCentrePage(driver, test);
		CostCentrePage CostCentrePage = new CostCentrePage(driver, test);

		// Calling Functions for Login
		loginPage.Login("BP_URL", "BP_UN_WEXSalesCustomer_" + clientCountry, "BP_PWD_WEXSalesCustomer_" + clientCountry,
				clientName);
		bpHomePage.ValidateBPCustomerLogo();

		// Choose a Account
		String accountName = bpCommonPage.selectAccount();

		// Enter into the Account details
		bpHomePage.clickAccountDetailsLink();

		// Enter into the View Edit CostCentre Page
		bpAccountPage.clickViewAndEditCostCentreLink();
		viewAndEditCostCentrePage.validateViewEditCostCentrePage();

		// Click on Add CostCentre button
		viewAndEditCostCentrePage.clickAddCostCentreButton();
		CostCentrePage.validateCreateNewCostCentreHeader();

		// Enter all fields to Create CostCentre Page
		String costCenterName = CostCentrePage.enterCostCentreName();
		CostCentrePage.enterCostCentreDescription();
		CostCentrePage.enterCostCentreShortDescription();
		CostCentrePage.clickCreateCostCentreButton();

		// Verify the success message
		CostCentrePage.validateCreatedCostCentreSuccessMsg();

		// Click Return to CostCentres
		CostCentrePage.clickReturnToCostCentreButton();

		// Select the Account and validate
		viewAndEditCostCentrePage.selectAccountFromFindCostCentre(accountName);

		viewAndEditCostCentrePage.clickSearchForCostCentreButton();
		viewAndEditCostCentrePage.validateCostCentreRecordsDisplayed();

		// Select the Account and search with the name

		viewAndEditCostCentrePage.enterCostCentreNameEditPage(costCenterName);

		viewAndEditCostCentrePage.clickSearchForCostCentreButton();
		viewAndEditCostCentrePage.validateCostCentreRecordsDisplayed();

		// Clear the CostCentre name and search
		viewAndEditCostCentrePage.clearCostCentreName();
		viewAndEditCostCentrePage.clickSearchForCostCentreButton();
		System.out.println("completed upto clear costcentre");
		// Select the first row from the table
		viewAndEditCostCentrePage.selectFirstRowFromFindCostCentreTable();
		viewAndEditCostCentrePage.clickEditDetails();
		viewAndEditCostCentrePage.validateEditCostCentrePage();

		// Edit all fields in Edit CostCentre Page
		CostCentrePage.enterCostCentreName();
		CostCentrePage.enterCostCentreDescription();
		CostCentrePage.enterCostCentreShortDescription();

		// Click Save Changes Button
		CostCentrePage.clickSaveChangesButton();

		// Click Return to CostCentres Button
		CostCentrePage.clickReturnToCostCentreButton();

		loginPage.Logout();

	}

}
