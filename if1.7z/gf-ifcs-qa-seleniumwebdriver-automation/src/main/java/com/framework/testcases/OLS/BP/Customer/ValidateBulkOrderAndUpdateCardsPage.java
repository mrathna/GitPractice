package com.framework.testcases.OLS.BP.Customer;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.BP.BPHomePage;
import com.framework.pages.OLS.common.BPCommonPage;
import com.framework.pages.OLS.common.BulkOrderAndUpdatePage;
import com.framework.pages.OLS.common.CommonPage;
import com.framework.pages.OLS.common.LoginPage;

public class ValidateBulkOrderAndUpdateCardsPage extends BaseTest {
	@Parameters({"clientCountry","clientName"})
	@Test( groups = { "Smoke", "Regression" })
	public void Validate_Bulk_Card_Order(@Optional("AU") String clientCountry, @Optional("BP") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  BP Bulk Card Order/Update/Status Validation", "Validate the Bulk Card Operation");
		LoginPage loginPage = new LoginPage(driver, test);
		BPHomePage bpHomePage = new BPHomePage(driver, test);
		if(clientName.equals("BP")) {
			loginPage.Login("BP_URL", "BP_UN_Customer_" + clientCountry, "BP_PWD_Customer_" + clientCountry, clientName);
		} else {
			loginPage.Login("BPPREPAID_URL", "BPPREPAID_UN_Customer_" + clientCountry, "BPPREPAID_PWD_Customer_" + clientCountry, clientName);
		}
		bpHomePage.ValidateBPCustomerLogo();
        CommonPage commonPage = new CommonPage(driver,test);
		BPCommonPage bpCommonPage = new BPCommonPage(driver, test);
		BulkOrderAndUpdatePage bulkOrdeAndUpdatePage = new BulkOrderAndUpdatePage(driver, test);
		
		// ** Bulk Card Order
		// Choose a Account
		bpCommonPage.selectAccount();

		// Load Bulk Order and Update Page
		bpHomePage.loadBulkOrderAndUpdateCardPage();

		// Select Bulk Card Order radio button
		bulkOrdeAndUpdatePage.selectBulkCardOperation("Bulk Card Order");

		// Check Download link is available
		bulkOrdeAndUpdatePage.checkBulkCardOrderDownloadLink();

		// Click Download Bulk Card Template
		bulkOrdeAndUpdatePage.clickOnDownloadCardsToExcel("Download the Bulk Card Order template");

		// Click upload bulk order and check popup
		bulkOrdeAndUpdatePage.clickUploadBulkCardOrder();

		// Click close in Upload Option and check popup
		bulkOrdeAndUpdatePage.clickCloseInBulkOrderUpload(); 

		// ** Bulk Card Update
		// Choose a Account
		bpCommonPage.selectAccount();

		// Load Bulk Order and Update Page
		bpHomePage.loadBulkOrderAndUpdateCardPage();

		// Select Bulk Card Order radio button
		bulkOrdeAndUpdatePage.selectBulkCardOperation("Bulk Card Update");

		// Click Upload Option
		bulkOrdeAndUpdatePage.clickUploadBulkUpdate();

		// Click Upload Option and check popup
		bulkOrdeAndUpdatePage.clickCloseInBulkCardUpdatePopup(); 

		bulkOrdeAndUpdatePage.selectAllAccountFromBulkCardOperation("Update");

		bulkOrdeAndUpdatePage.clickAdvancedSearchOption();

		bulkOrdeAndUpdatePage.bulkCardUpdateSearch();

		// ** Below commented Actions are covered in bulkCardUpdateSearch()

		bulkOrdeAndUpdatePage.selectBulkCardStatus("Bulk Card Update","Active");

		// Search Cards
		bulkOrdeAndUpdatePage.clickSearchCard("Bulk Card Update");


		// Click View Card Results and check popup
		bulkOrdeAndUpdatePage.clickViewCardSearchResults();

		// Click view card results and check popup
		bulkOrdeAndUpdatePage.clickCloseInViewCardResultsPopup();

		// Check cards to excel option
		bulkOrdeAndUpdatePage.checkCardsToExcelDownloadLink(); 

		//Download Cards To Excel
		bulkOrdeAndUpdatePage.clickOnDownloadCardsToExcel("Download Cards to Excel");  

		// ** Bulk Card Status
		// Choose a account
		bpCommonPage.selectAccount();

		// Load bulk order and update page
		bpHomePage.loadBulkOrderAndUpdateCardPage();

		// Select bulk card status radio button
		bulkOrdeAndUpdatePage.selectBulkCardOperation("Bulk Card Status");
		
		//Select All Account 
		bulkOrdeAndUpdatePage.selectAllAccountFromBulkCardOperation("Status");

		//Bulk Card Status Change 
		bulkOrdeAndUpdatePage.bulkCardChangeStatus("Deleted");
		bulkOrdeAndUpdatePage.bulkCardChangeStatus("Lost");
		bulkOrdeAndUpdatePage.bulkCardChangeStatus("Stolen");
		bulkOrdeAndUpdatePage.bulkCardChangeStatus("Temp");  

		//Bulk Card Status - Search 
		bulkOrdeAndUpdatePage.bulkCardStatusSearch();

		bulkOrdeAndUpdatePage.bulkCardAdvanceSearch();

		// ** Below commented Actions are covered in bulkCardStatusSearch() and bulkCardChangeStatus("Deleted")

		/* // Select temp cards alone in drop down
		//bulkOrdeAndUpdatePage.selectBulkCardStatus("Active");
		//bulkOrdeAndUpdatePage.selectBulkCardStatus("Bulk Card Status","Deleted");

		//bulkOrdeAndUpdatePage.selectAllAccountFromBulkCardOperation("Status");

		// Search cards
		//bulkOrdeAndUpdatePage.clickSearchCard("Bulk Card Status"); */

		// Click select all option and check all cards selected
		/*	bulkOrdeAndUpdatePage.clickSelectAllOptionAndCheckAllCardsSelected();

		// Click deselect all option and check all cards selected
		bulkOrdeAndUpdatePage.clickDeselectAllOptionAndCheckAllCardsDeselected();

		// Select first three checkBoxes
		bulkOrdeAndUpdatePage.selectACardFromList(0);
		bulkOrdeAndUpdatePage.selectACardFromList(1);
		// bulkOrdeAndUpdatePage.selectACardFromList(2);

		// Deselect second and third card
		// bulkOrdeAndUpdatePage.selectACardFromList(2);
		bulkOrdeAndUpdatePage.selectACardFromList(1);

		// Choose a new status
		bulkOrdeAndUpdatePage.selectNewStatus("Active");

		// Review Changes
		bulkOrdeAndUpdatePage.clickReviewChanges();

		// Save New Changes
		bulkOrdeAndUpdatePage.clickSaveNewCardStatus();

		// Yes
		// bulkOrdeAndUpdatePage.clickYesOnCardStatusChange();

		// Check print this page link
		bulkOrdeAndUpdatePage.checkPrintThisPageLinkText();

		// Return to bulk card search
		//bulkOrdeAndUpdatePage.returnToBulkCardSearchAndCheckTitle(); */
		//Bulk Card Update -Added by Anton
		// Choose a account
		bpCommonPage.selectAccount();
		
		// Load Bulk Order and Update Page
		bpHomePage.loadBulkOrderAndUpdateCardPage();
		
		// Select Bulk Card Order radio button
		bulkOrdeAndUpdatePage.selectBulkCardOperation("Bulk Card Update");
		
		//Select All accounts Option
		bulkOrdeAndUpdatePage.selectAllAccountFromBulkCardOperation("Bulk Card Update");
		
		// Search Cards
		bulkOrdeAndUpdatePage.clickSearchCard("Bulk Card Update");
		
		if(!(bulkOrdeAndUpdatePage.checkNoCardMessage())) {
		// Check cards to excel option
		bulkOrdeAndUpdatePage.checkCardsToExcelDownloadLink();

		//Download Cards To Excel
		bulkOrdeAndUpdatePage.clickOnDownloadCardsToExcel("Download Cards to Excel");
		
		// Click Upload Option
				bulkOrdeAndUpdatePage.clickUploadBulkUpdate();

				//Click On browse
				bulkOrdeAndUpdatePage.clickOnBrowseButtonToUploadTheExcelFile();

				//Upload The File From the Local
				commonPage.uploadTheExcelSheetFromTheLocal("Bulk_Update");


				//Click On Upload Bulk Card Update
				bulkOrdeAndUpdatePage.clickOnUploadBulkCardUpdate();

				//Check the Bulk Card Update Success Message
				bulkOrdeAndUpdatePage.bulkCardUpdateSuccessInfo(); 

		}
		

		loginPage.Logout();

	}
}
