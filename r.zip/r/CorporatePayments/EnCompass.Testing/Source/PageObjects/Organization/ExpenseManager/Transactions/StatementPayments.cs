﻿using Common;
using Common.Utility;
using EnCompass.Testing.Source.PageObjects.Controls;
using NFluent;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EnCompass.Testing.Source.PageObjects.Organization.ExpenseManager.Transactions
{
	//[PageModel(@"/expenseManager/transactions/statementPayments.aspx")]
	public partial class StatementPayments
	{
        //public override string PageIdentifierXPath_Override => @"//div[@class='crumb_selected_content'][text() = 'Pay Statements']";

        #region XPath page Elements
        private const string _searchTermListXPath = @"//div[contains(@id, 'SearchOutput')]/select[1]";
        private const string _searchButtonXPath = @"//input[contains(@id, 'btnSearch')]";
        private const string _viewTransationsXPath = @"//a[contains(@id, 'dgAccounts_rowButtons')][text()='Transactions']";
        #endregion

        #region Page Elements
        private IWebElement _searchTermList
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_searchTermListXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_searchTermList element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _searchButton
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_searchButtonXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_searchButton element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _viewTransations
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_viewTransationsXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_viewTransations element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            } 
        }
        #endregion


        public string SearchTermValues
		{
			get
			{
				return _searchTermList.Text;
			}
		}
         public void Search()
        {
            _searchButton.JSClickWithFocus(Driver);
        }
        //New Method
        private GridControl _statmentsCardsGrid;
        public GridControl StatmentsCardsGrid
        {
            get
            {
                _statmentsCardsGrid = new GridControl("dgAccounts", Driver);
                _statmentsCardsGrid.WaitForGrid();

                return _statmentsCardsGrid;
            }
        }

        public void SelectFirstRowStatementCard()
        {
            StatmentsCardsGrid.SelectFirstRow();
        }

        public void SelectViewTransactions()
        {
            Settings.EnCompassWebDriver.WaitForVisible(By.XPath("//a[contains(@id, 'dgAccounts_rowButtons')][text()='Transactions']"));
            _viewTransations.JSClickWithFocus(Driver);
        }        
	}
}
