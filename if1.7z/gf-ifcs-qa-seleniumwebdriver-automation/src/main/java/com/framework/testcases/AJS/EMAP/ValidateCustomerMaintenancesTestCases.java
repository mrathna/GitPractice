package com.framework.testcases.AJS.EMAP;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.CardMaintenancePage;
import com.framework.pages.AJS.CustomerReportAssignmentPage;
import com.framework.pages.AJS.common.Common;
import com.framework.pages.AJS.common.IFCSHomePage;
import com.framework.pages.AJS.common.IFCSLoginPage;


/**
 * @author Sasikumar M
 *
 */
public class ValidateCustomerMaintenancesTestCases extends BaseTest {

	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "Regression" })
	public void validateMaintainCustomerAssigningReportsToCustomers(@Optional("SG") String clientCountry,
			@Optional("EMAP") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  TST-SC-14-Assign Customer Reports", "EMAP IFCS Assign Reports to customers");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		CardMaintenancePage cardMaintenancePage = new CardMaintenancePage(driver, test);
		CustomerReportAssignmentPage customerReportAssignmentPage = new CustomerReportAssignmentPage(driver, test);
		Common common = new Common(driver, test);
		//ClientConfigPage clientConfigPage = new ClientConfigPage(driver, test);
		IFCSloginPage.login("IFCS_URL_EMAP", "IFCS_EMAP_USERNAME", "IFCS_EMAP_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, " ");

		/*//Checking the report presence
		IFCSHomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);
		clientConfigPage.verfyingThePresenceOfReport();*/
		
		// Setting client and navigate cus
		IFCSHomePage.gotoApplicationAndClickApplicationMenu();
		IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);
		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		String standAloneCustomerNumber = common.getCustomerNoHavingCardsUsingCardType();
		String parentCustomerNumber = common.getActiveParentCustomerNoInHierarcyBasedOnClient();
		
		if (standAloneCustomerNumber.equals("") && parentCustomerNumber.equals("")) {
			// need to call method to logfail
			common.logForNoDataFound(this.getClass().getSimpleName(), "Need to Create Customer With Cards and rerun");
		} else {
			// Calling Functions
			cardMaintenancePage.chooseAndSearchCustomerNo(standAloneCustomerNumber);
			common.validateSearchTable("Customer No", standAloneCustomerNumber, true);
			// Adding Report for StandAloneCustomer
			customerReportAssignmentPage.addIndividualReports();
			if(clientCountry.equals("MO")) {
				customerReportAssignmentPage.assigningIndividualReportsForMO();
			}else if(clientCountry.equals("SG")) {	
				customerReportAssignmentPage.assigningIndividualReportsForSG();
			}else if(clientCountry.equals("GU")) {	
				customerReportAssignmentPage.assigningIndividualReportsForGU();
			}else if(clientCountry.equals("SP")) {	
				customerReportAssignmentPage.assigningIndividualReportsForSP();
			}else if(clientCountry.equals("HK")) {	
				customerReportAssignmentPage.assigningIndividualReportsForHK();
			}
			// Assigning Reports parent
			cardMaintenancePage.chooseAndSearchCustomerNo(parentCustomerNumber);
			common.validateSearchTable("Customer No", parentCustomerNumber, true);
			// Adding Report Hier for parent
			customerReportAssignmentPage.addReportHier();
			
			if(clientCountry.equals("MO")) {
					customerReportAssignmentPage.assigningHierReportsForMO();
			}else if(clientCountry.equals("SG")) {	
					customerReportAssignmentPage.assigningHierReportsForSG();
			}else if(clientCountry.equals("GU")) {	
					customerReportAssignmentPage.assigningHierReportsForGU();
			}else if(clientCountry.equals("SP")) {	
					customerReportAssignmentPage.assigningHierReportsForSP();
			}else if(clientCountry.equals("HK")) {	
					customerReportAssignmentPage.assigningHierReportsForHK();
			}
			
		}

		IFCSHomePage.exitIFCS();
	}
}
