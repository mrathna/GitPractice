package com.framework.util;

/*******************************************************************************
 * Name : FileUtils Description : Maintains the Project Resources names and
 * paths
 *******************************************************************************/
public interface Constants {

	public static final String NEW_LINE = System.getProperty("line.separator");
	public static final String FILE_SEPARATOR = System.getProperty("file.separator");

	// Getting the current Project Directory
	public static final String USER_DIR = System.getProperty("user.dir");

	// Folders names
	public static final String RESOURCES_FOLDER_NAME = "Resources";
	public static final String DRIVER_FOLDER_NAME = "Drivers";
	public static final String CONFIG_FOLDER_NAME = "Configuration";
	public static final String RESULTS_FOLDER_NAME = "Reports";
	public static final String LOG_FOLDER_NAME = "Logs";
	public static final String SCREENSHOT_FOLDER_NAME = "ScreenShots";
	public static final String SCREEN_NAVIGATION_REPORTS = "ScreenNavigationReports";
	public static final String INPUTFILE_FOLDER_NAME="InputFileTemplate";
	public static final String WHITELISTFILE_FOLDER_NAME = "WhiteListFile";
	public static final String IDEMIA_FOLDER_NAME = "Idemia";

	// Directories absolute paths
	public static final String RESOURCES_DIR = USER_DIR + FILE_SEPARATOR + RESOURCES_FOLDER_NAME + FILE_SEPARATOR;
	public static final String DRIVER_DIR = RESOURCES_DIR + DRIVER_FOLDER_NAME + FILE_SEPARATOR;
	public static final String CONFIG_DIR = RESOURCES_DIR + CONFIG_FOLDER_NAME + FILE_SEPARATOR;
	public static final String REPORTS_DIR = RESOURCES_DIR + RESULTS_FOLDER_NAME + FILE_SEPARATOR;
	public static final String LOG_DIR = RESOURCES_DIR + LOG_FOLDER_NAME + FILE_SEPARATOR;
	public static final String SCREENSHOT_DIR = RESOURCES_DIR + SCREENSHOT_FOLDER_NAME + FILE_SEPARATOR;
	public static final String SCREEN_NAVIGATION_DIR = RESOURCES_DIR + SCREEN_NAVIGATION_REPORTS + FILE_SEPARATOR;
	public static final String INPUTFILE_DIR = RESOURCES_DIR+INPUTFILE_FOLDER_NAME+FILE_SEPARATOR;
	public static final String WHITELISTFILE_DIR = RESOURCES_DIR+WHITELISTFILE_FOLDER_NAME+FILE_SEPARATOR;
	public static final String IDEMIA_DIR = RESOURCES_DIR+IDEMIA_FOLDER_NAME+FILE_SEPARATOR;
	// Files names of Configuration
	public static final String CONFIG_FILE_NAME = "config.properties";
	public static final String EMBOSSIDEMIA_FILE_NAME = "EmbossIdemiaValidation.properties";
	public static final String APACINT_CONFIG_FILE_NAME = "apacint.properties";
	public static final String APACDEV4_CONFIG_FILE_NAME = "apacdev4.properties";
	public static final String APACAUTO_CONFIG_FILE_NAME = "apacauto.properties";
	public static final String APACPERF_CONFIG_FILE_NAME = "apacperf.properties";
	public static final String APACDEV6_CONFIG_FILE_NAME = "apacdev6.properties";
	public static final String APACDEV2_CONFIG_FILE_NAME = "apacdev2.properties";
	public static final String AWSEMEAUAT_CONFIG_FILENAME= "awsemeauat.properties";
	public static final String AWSAPACUAT_CONFIG_FILENAME= "awsapacuat.properties";
	public static final String CAF_CONFIG_FILENAME = "caffile.properties";
	public static final String EUA_CONFIG_FILENAME = "EUA08.properties";
	public static final String PUTTY_CONFIG_FILENAME = "puttyconfigdetails.properties";
	public static final String LOADCARD_CONFIG_FILENAME = "LoadCardTransactionXML.properties";
	public static final String LOADCARD_CONFIG_FLATFILENAME = "LoadCardTransactionFlatFile.properties";
	public static final String BATCH_JOB_ALL_CLIENTS = "batchjobs-all-clients.properties";
	public static final String CARD_EMBOSSING_FILENAME = "cardEmboss.properties";
	public static final String EMAP_CARD_EMBOSSING_FILENAME = "emapcardEmboss.properties";
	public static final String HK_PPS_PAYMENT = "PPSPayment.properties";
	public static final String CMD_AC2_FILENAME = "CMD_AC2.properties";
	public static final String CMD_ACC_FILENAME = "CMD_ACC.properties";
	public static final String GSD_FILENAME = "GSDXMLFile.properties";
	public static final String PVV_FILENAME = "PVVTextFile.properties";
	public static final String FINSTA_FILENAME = "FINSTA.properties";
	public static final String VINCII_FILENAME = "VINCII.properties";
	public static final String SALESFORCESYNC_FILENAME = "SalesForceSync.properties";
	public static final String EMAP_LOADCARD_CONFIG_FLATFILENAME_ONLY_SG = "emapLoadCardTransactionFlatFileOnlySG.properties";
	public static final String EMAP_LOADCARD_CONFIG_FLATFILENAME_ALL_CLIENTS = "emapLoadCardTransactionFlatFileAllClients.properties";
	public static final String WESUAT_CONFIG_FILENAME= "wesuat.properties";
	public static final String CA10_FILENAME = "LocationCA10.properties";
	public static final String CUSTPAYMENT_FILENAME = "CustomerPaymentXML.properties";
	public static final String CALLSHEET_EXCEL_INPUT_VALUES = "callSheetExcelInputValues.properties";
	public static final String EXCEL_INPUT_VALUES = "BulkCardOrderInputValues.properties";
	public static final String R3_REPORTS = "DayEndProcessR3Reports.properties";
	public static final String DAILY_FREQUENCY="emapdailyfrequencyreports.properties";
	public static final String DAYEND_REPORTS="1stOfTheDayend.properties";
	public static final String BP_DAYEND_REPORTS_AU = "BPDayEndReportsAU.properties";
	public static final String CUSTOMERPAYMENT_CONFIG_FILENAME= "CustomerPaymentXML.properties";
	public static final String COMMON_API_FILENAME = "CommonAPIConfig.properties";
	public static final String CUSTOMER_NUMBER_FILE = "CustomerNumber.properties";
	
	// File names of screen navigation reports
	public static final String Z_ENERGY_SCREEN_NAVIGATION_REPORT_NAME = "Z_NavigationTimingMeasurement_TimerData.xlsx";
	public static final String CHEVRON_SCREEN_NAVIGATION_REPORT = "";
	public static final String SHELL_SCREEN_NAVIGATION_REPORT = "";
	public static final String EMAP_SCREEN_NAVIGATION_REPORT = "";

	// Files names of ScreenShots
	public static final String FILEName_INPUTPATH = SCREENSHOT_DIR + FILE_SEPARATOR + "FileName1.png";
	public static final String OPEN = SCREENSHOT_DIR + FILE_SEPARATOR + "Open1.png";
	public static final String DOWNLOADS_PATH = SCREENSHOT_DIR + FILE_SEPARATOR + "DownloadsIcon.png";
	// public static final String EDIT = SCREENSHOT_DIR+FILE_SEPARATOR+"Edit.png";
	public static final String LOCATIONName_INPUTPATH = SCREENSHOT_DIR + FILE_SEPARATOR + "Location1.png";
	public static final String OPENICON = SCREENSHOT_DIR + FILE_SEPARATOR + "Open3.png";
	
	//Raxsana
	public static final String FILEName_INPUTPATH_PDF = SCREENSHOT_DIR + FILE_SEPARATOR + "pdfFileName.png";
	public static final String SAVEICON = SCREENSHOT_DIR + FILE_SEPARATOR + "Save.png";
	public static final String DOWNLOAD_PDF = SCREENSHOT_DIR + FILE_SEPARATOR + "downloadbutton.png";
	public static final String FILENameUpload_INPUTPATH = SCREENSHOT_DIR + FILE_SEPARATOR + "fileNameUpload.png";
	public static final String CHEVRON_ENDTOEND_TEMP_FILE = "chevronEndToEndTemplateFile.Properties";
	public static final String DUPLICATE_TEMP_FILE = "DuplicateFile.txt";
	
	//Meenakshi
	public static final String BAFF_FILES = "BAFFFile.properties";
	
	//Sasi
	public static final String VELOCITY_TEMP_FILENAME = "VelocityTemp.Properties";
	
	public static final String CHEVRON_ENDTOEND_TEMPLATE_FILE ="chevronEndToEndTemplateFile.properties";
	public static final String LORDCARDTRANSACTION_PURCHASE ="LoadCardTransactionPurchase.properties";
	public static final String CARD_ORDERED ="CardOrdered.properties";
	public static final String SALESFORCEVALIDATION ="SalesForceValidation.properties";
	public static final String CARD_FOR_WHITELIST_FILE = "CardForWhitelistFile.properties";
	public static final String TRANSACTION_TEMP_FILE = "TransactionTempFile.properties";
	public static final String BULK_REISSUE_TEMP_FILE = "BulkReissueTempFile.properties";
	public static final String IDEMIA = "IdemiaFile.101";
	
	
}
