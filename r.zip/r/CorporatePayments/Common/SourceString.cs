﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Common
{
	public class SourceString
	{
		public string InputValue { get; set; }
		public string ResultValue { get; set; }
		private string FinalValue { get { return ResultValue ?? InputValue; } }

		public SourceString(string originalValue, string resultValue)
		{
			InputValue = originalValue;
			ResultValue = resultValue;
		}

		// User-defined conversion from SourceString to string
		public static implicit operator string(SourceString source)
		{
			return source.FinalValue;
		}

		public static bool operator ==(SourceString obj1, string obj2)
		{
			return obj1.Equals(obj2);
		}

		public static bool operator !=(SourceString obj1, string obj2)
		{
			return !obj1.Equals(obj2);
		}

		public static bool operator ==(string obj1, SourceString obj2)
		{
			return obj1.Equals(obj2);
		}

		public static bool operator !=(string obj1, SourceString obj2)
		{
			return !obj1.Equals(obj2);
		}

		public static bool operator ==(SourceString obj1, SourceString obj2)
		{
			return obj1.Equals(obj2);
		}

		public static bool operator !=(SourceString obj1, SourceString obj2)
		{
			return !obj1.Equals(obj2);
		}

		public override string ToString()
		{
			return this;
		}

		public override bool Equals(object obj)
		{
			var canEqual = obj is SourceString || obj is string;

			if (!canEqual)
			{
				return false;
			}

			return this.FinalValue.Equals((obj as SourceString)?.ToString() ?? (obj as string));
		}

		public override int GetHashCode()
		{
			return this.FinalValue.GetHashCode();
		}
	}


	public static class StringExtensions
	{
		public static SourceString ToSourceString(this string source)
		{
			return new SourceString(source, source);
		}
	}
}
