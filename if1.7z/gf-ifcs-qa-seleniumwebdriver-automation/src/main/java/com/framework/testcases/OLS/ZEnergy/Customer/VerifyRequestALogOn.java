package com.framework.testcases.OLS.ZEnergy.Customer;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.OLS.common.LoginPage;
import com.framework.pages.Z.ZHomePage;
import com.framework.pages.Z.ZLoginPage;

public class VerifyRequestALogOn extends BaseTest {

	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "Smoke" })
	public void verifyRequestALogOnPage(@Optional("Z") String clientCountry, @Optional("ZEnergy") String clientName) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  Request a log on page", "Verifying the request a log on page details");

		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);

		// Login and get account number - Only If not running in APAC_AUTO
		String validAccountNumber = "";
		loginPage.Login("ZEnergy_URL", "ZEnergy_UN_Customer_" + clientCountry, "ZEnergy_PWD_Customer_" + clientCountry,
				clientName);
		ZHomePage zHomePage = new ZHomePage(driver, test);
		validAccountNumber = zHomePage.setAccountNumberChoosen();
		loginPage.Logout();

		ZLoginPage zLoginPage = new ZLoginPage(driver, test);
		zLoginPage.validateClientLogo();
		zLoginPage.clickRequestALogonAndValidateTitle();
		zLoginPage.clickRequestLogonSubmitWithEmptyFieldAndValidate();
		zLoginPage.validateRequestALogoFieldsPresence();
		zLoginPage.enterRequestLogonDetails(validAccountNumber);
		zLoginPage.clickRequestALogonSubmit();

	}

}
