package com.framework.pages.CHEV;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.ExtentTest;
import com.framework.basepage.BasePage;
import com.framework.repo.Locator;

public class CHBulkCardStatusChangePage extends BasePage {

	@FindBy(how = How.XPATH, using = Locator.ADHOC_REPORTS_TITLE)
	public WebElement cardListPageTitle;

	@FindBy(how = How.ID, using = Locator.DOWNLOAD_CARDS_TO_EXCEL)
	public WebElement downloadBtn;

	@FindBy(how = How.ID, using = Locator.CH_BULK_CARD_UPDATE_UPLOAD_BTN)
	public WebElement uploadBtn;

	@FindBy(how = How.ID, using = Locator.SEARCH_CARDS)
	public WebElement searchBtn;

	@FindBy(how = How.ID, using = Locator.BCS_NEW_STATUS_DROPDOWN)
	public WebElement changeStatusDropDown;

	@FindBy(how = How.ID, using = Locator.AU_SAVE)
	public WebElement saveButton;

	@FindBy(how = How.XPATH, using = Locator.CH_CARD_LIST_TABLE)
	public WebElement cardListTable;

	@FindBy(how = How.XPATH, using = Locator.CH_CARD_LIST_TABLE_FIRST_ROW)
	public WebElement cardListTableFirstRow;

	public CHBulkCardStatusChangePage(WebDriver driver, ExtentTest test) {
		super(driver, test);
		PageFactory.initElements(driver, this);
	}

	public void verifyBulkUpdatePageTitle() {
		sleep(3);
		isDisplayed(cardListPageTitle, "Bulk Status Updates");
		logPass("Redirected to the Bulk Status Updates");

	}

	public void verifyDownloadButton() {
		if (downloadBtn.isDisplayed()) {
			logPass("Download Button is visible");
		} else {
			logFail("Download Button is not visible");
		}

	}

	public void verifyUploadButton() {
		if (uploadBtn.isDisplayed()) {
			logPass("Upload Button is visible");
		} else {
			logFail("Upload Button is not visible");
		}

	}

	public void verifyExportButton() {
		if (uploadBtn.isDisplayed()) {
			logPass("Upload Button is visible");
		} else {
			logFail("Upload Button is not visible");
		}

	}

	public void changeCardStatusBackToActive(String cardNumber) {

		actionClick(searchBtn);
		sleep(5);
		List<WebElement> TotalRowCount = cardListTable.findElements(By.tagName("tr"));
		scrollDownPage();
		selectDropDownByVisibleText(changeStatusDropDown, "Active");
		int RowIndex = 1;
		boolean found = false;
		for (WebElement rowElement : TotalRowCount) {
			List<WebElement> TotalColumnCount = rowElement.findElements(By.tagName("td"));
			int ColumnIndex = 1;
			for (WebElement colElement : TotalColumnCount) {
				if (ColumnIndex == 2 && colElement.getText().equals(cardNumber)) {
					System.out.println("Found cardnumber");
					found = true;
					actionClick(TotalColumnCount.get(ColumnIndex - 2));
				}
				ColumnIndex = ColumnIndex + 1;
			}
			RowIndex = RowIndex + 1;
		}
		if (!found) {
			System.out.println("Card not found to change status");
		}
		actionClick(saveButton);
		sleep(10);

	}
}
