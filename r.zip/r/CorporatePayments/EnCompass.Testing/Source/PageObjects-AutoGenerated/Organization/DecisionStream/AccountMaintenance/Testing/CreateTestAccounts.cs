using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using Common;
using Common.PageObjects;
using Common.ScenarioConfigurations;
using Common.Utility;

namespace EnCompass.Testing.Source.PageObjects.Organization.DecisionStream.AccountMaintenance.Testing 
{
	/// <summary>
	/// Auto-generated Page Model Class
	/// Navigation Paths: 
		/// [Organization Home]->Cards->Card Maintenance->Create Test Cards
		/// </summary>
	[PageModel(@"/decisionStream/accountMaintenance/Testing/CreateTestAccounts.aspx")]
	public partial class CreateTestAccounts : EnCompassOrgPageModel 
	{
		public override string RelativeUrl => @"/decisionStream/accountMaintenance/Testing/CreateTestAccounts.aspx";
		public override string PageIdentifierXPath_Generated => @"//li[contains(@class, 'breadcrumb-item active')][text() = 'Cards']";

		#region Navigation
				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Cards']")]
		private IWebElement _cards_CardMaintenance_CreateTestCards_Cards { get; set; }
		public void NavigateTo_Cards_CardMaintenance_CreateTestCards_Cards()
		{
			NavigateToMenuItem(_cards_CardMaintenance_CreateTestCards_Cards);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='History']")]
		private IWebElement _cards_CardMaintenance_CreateTestCards_History { get; set; }
		public void NavigateTo_Cards_CardMaintenance_CreateTestCards_History()
		{
			NavigateToMenuItem(_cards_CardMaintenance_CreateTestCards_History);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Activate Cards']")]
		private IWebElement _cards_CardMaintenance_CreateTestCards_ActivateCards { get; set; }
		public void NavigateTo_Cards_CardMaintenance_CreateTestCards_ActivateCards()
		{
			NavigateToMenuItem(_cards_CardMaintenance_CreateTestCards_ActivateCards);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Review Card Edits']")]
		private IWebElement _cards_CardMaintenance_CreateTestCards_ReviewCardEdits { get; set; }
		public void NavigateTo_Cards_CardMaintenance_CreateTestCards_ReviewCardEdits()
		{
			NavigateToMenuItem(_cards_CardMaintenance_CreateTestCards_ReviewCardEdits);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Create Test Cards']")]
		private IWebElement _cards_CardMaintenance_CreateTestCards_CreateTestCards { get; set; }
		public void NavigateTo_Cards_CardMaintenance_CreateTestCards_CreateTestCards()
		{
			NavigateToMenuItem(_cards_CardMaintenance_CreateTestCards_CreateTestCards);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Create Test Transactions']")]
		private IWebElement _cards_CardMaintenance_CreateTestCards_CreateTestTransactions { get; set; }
		public void NavigateTo_Cards_CardMaintenance_CreateTestCards_CreateTestTransactions()
		{
			NavigateToMenuItem(_cards_CardMaintenance_CreateTestCards_CreateTestTransactions);
		}

		
		private void NavigateToMenuItem(IWebElement element)
		{
			Driver.Url = element.GetAttribute("href");
		}
		#endregion

		public CreateTestAccounts(GlobalSettings settings) : base(settings) { }
	}  
}
