package com.framework.testcases.OLS.CHEV.Customer.ReadWrite;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.CHEV.CHLogonPage;
import com.framework.pages.OLS.common.LoginPage;

public class ValidateOLSAllLinksLogonPage extends BaseTest {

	@Parameters({ "clientCountry", "clientName" })
	@Test(priority = 1)
	public void testCustomerReadWriteOLSAllLinksLogonPage(@Optional("PH") String clientCountry, @Optional("CHV") String clientName) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  Read or Write OLS - All Links in Logon Page", "Chevron Customer Screens Read or Write");

		// TODO A lot differed from Test case Missing download button and Test case
		// looks for Mobil logo

		LoginPage loginPage = new LoginPage(driver, test);
		CHLogonPage chLogonPage = new CHLogonPage(driver, test);
		if (clientCountry.equals("SG")||clientCountry.equals("MY")||clientCountry.equals("HK")) {
			loginPage.Login("CHV_URL", "CHV_Customer_UN_RW_ONLY_"+clientCountry, "CHV_Customer_PWD_RW_ONLY_"+clientCountry, "CHV");
		} else if (clientCountry.equals("TH")) {
			loginPage.Login("CHV_URL", "CHV_Customer_UN_"+clientCountry, "CHV_Customer_PWD_"+clientCountry, "CHV");
		} else if (clientCountry.equals("PH")) {
			loginPage.Login("CHV_URL", "CHV_Customer_UN_"+clientCountry, "CHV_Customer_PWD_"+clientCountry, "CHV");
		}

		loginPage.Logout();
		chLogonPage.clickOnPrivacyPolicyAndVerifyTitle();
		chLogonPage.clickOnTOCAndVerifyTitle();
		chLogonPage.verifyLogo(); 		
	}
}
 
