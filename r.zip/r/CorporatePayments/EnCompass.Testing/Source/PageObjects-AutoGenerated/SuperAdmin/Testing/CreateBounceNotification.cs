using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using Common;
using Common.PageObjects;
using Common.ScenarioConfigurations;
using Common.Utility;

namespace EnCompass.Testing.Source.PageObjects.SuperAdmin.Testing 
{
	/// <summary>
	/// Auto-generated Page Model Class
	/// Navigation Paths: 
		/// [Organization Home]->General->Testing->Create Bounce Notification
		/// </summary>
	[PageModel(@"/superAdmin/testing/CreateBounceNotification.aspx")]
	public partial class CreateBounceNotification : EnCompassSuperPageModel 
	{
		public override string RelativeUrl => @"/superAdmin/testing/CreateBounceNotification.aspx";
		public override string PageIdentifierXPath_Generated => @"//li[contains(@class, 'breadcrumb-item active')][text() = 'Create Bounce Notification']";

		#region Navigation
				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Create Organization']")]
		private IWebElement _general_Testing_CreateBounceNotification_CreateOrganization { get; set; }
		public void NavigateTo_General_Testing_CreateBounceNotification_CreateOrganization()
		{
			NavigateToMenuItem(_general_Testing_CreateBounceNotification_CreateOrganization);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Create Organization Profile']")]
		private IWebElement _general_Testing_CreateBounceNotification_CreateOrganizationProfile { get; set; }
		public void NavigateTo_General_Testing_CreateBounceNotification_CreateOrganizationProfile()
		{
			NavigateToMenuItem(_general_Testing_CreateBounceNotification_CreateOrganizationProfile);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Delete Test Organization']")]
		private IWebElement _general_Testing_CreateBounceNotification_DeleteTestOrganization { get; set; }
		public void NavigateTo_General_Testing_CreateBounceNotification_DeleteTestOrganization()
		{
			NavigateToMenuItem(_general_Testing_CreateBounceNotification_DeleteTestOrganization);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Create Test Company']")]
		private IWebElement _general_Testing_CreateBounceNotification_CreateTestCompany { get; set; }
		public void NavigateTo_General_Testing_CreateBounceNotification_CreateTestCompany()
		{
			NavigateToMenuItem(_general_Testing_CreateBounceNotification_CreateTestCompany);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Corporate Credit Limit']")]
		private IWebElement _general_Testing_CreateBounceNotification_CorporateCreditLimit { get; set; }
		public void NavigateTo_General_Testing_CreateBounceNotification_CorporateCreditLimit()
		{
			NavigateToMenuItem(_general_Testing_CreateBounceNotification_CorporateCreditLimit);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Create Bounce Notification']")]
		private IWebElement _general_Testing_CreateBounceNotification_CreateBounceNotification { get; set; }
		public void NavigateTo_General_Testing_CreateBounceNotification_CreateBounceNotification()
		{
			NavigateToMenuItem(_general_Testing_CreateBounceNotification_CreateBounceNotification);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Reset Merchant Log Error']")]
		private IWebElement _general_Testing_CreateBounceNotification_ResetMerchantLogError { get; set; }
		public void NavigateTo_General_Testing_CreateBounceNotification_ResetMerchantLogError()
		{
			NavigateToMenuItem(_general_Testing_CreateBounceNotification_ResetMerchantLogError);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Performance']")]
		private IWebElement _general_Testing_CreateBounceNotification_Performance { get; set; }
		public void NavigateTo_General_Testing_CreateBounceNotification_Performance()
		{
			NavigateToMenuItem(_general_Testing_CreateBounceNotification_Performance);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='AP Non-Card Payments Testing']")]
		private IWebElement _general_Testing_CreateBounceNotification_ApNonCardPaymentsTesting { get; set; }
		public void NavigateTo_General_Testing_CreateBounceNotification_ApNonCardPaymentsTesting()
		{
			NavigateToMenuItem(_general_Testing_CreateBounceNotification_ApNonCardPaymentsTesting);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Modify Merchant Log']")]
		private IWebElement _general_Testing_CreateBounceNotification_ModifyMerchantLog { get; set; }
		public void NavigateTo_General_Testing_CreateBounceNotification_ModifyMerchantLog()
		{
			NavigateToMenuItem(_general_Testing_CreateBounceNotification_ModifyMerchantLog);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Test Templates']")]
		private IWebElement _general_Testing_CreateBounceNotification_TestTemplates { get; set; }
		public void NavigateTo_General_Testing_CreateBounceNotification_TestTemplates()
		{
			NavigateToMenuItem(_general_Testing_CreateBounceNotification_TestTemplates);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Create Test Statements']")]
		private IWebElement _general_Testing_CreateBounceNotification_CreateTestStatements { get; set; }
		public void NavigateTo_General_Testing_CreateBounceNotification_CreateTestStatements()
		{
			NavigateToMenuItem(_general_Testing_CreateBounceNotification_CreateTestStatements);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Contact Us']")]
		private IWebElement _general_Testing_CreateBounceNotification_ContactUs { get; set; }
		public void NavigateTo_General_Testing_CreateBounceNotification_ContactUs()
		{
			NavigateToMenuItem(_general_Testing_CreateBounceNotification_ContactUs);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Dispute Transaction']")]
		private IWebElement _general_Testing_CreateBounceNotification_DisputeTransaction { get; set; }
		public void NavigateTo_General_Testing_CreateBounceNotification_DisputeTransaction()
		{
			NavigateToMenuItem(_general_Testing_CreateBounceNotification_DisputeTransaction);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Terms and Conditions']")]
		private IWebElement _general_Testing_CreateBounceNotification_TermsAndConditions { get; set; }
		public void NavigateTo_General_Testing_CreateBounceNotification_TermsAndConditions()
		{
			NavigateToMenuItem(_general_Testing_CreateBounceNotification_TermsAndConditions);
		}

		
		private void NavigateToMenuItem(IWebElement element)
		{
			Driver.Url = element.GetAttribute("href");
		}
		#endregion

		public CreateBounceNotification(GlobalSettings settings) : base(settings) { }
	}  
}
