package com.framework.pages.OTI;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.ExtentTest;
import com.framework.basepage.BasePage;
import com.framework.repo.Locator;

public class OTICardPage extends BasePage {

	
	@FindBy(xpath = Locator.ACCOUNT_LIST_BOX)
	public WebElement accountList;
	@FindBy(id = Locator.CARD_STATUS)
	public WebElement filterCardStatus;
	@FindBy(id = Locator.SEARCH_BTN)
	public WebElement searchButton;
	@FindBy(id = Locator.SHELL_ACCOUNT_DROPDOWN)
	public WebElement accountDropdown;
	@FindBy(how = How.ID, using = Locator.OTI_LOGO)
	public WebElement otiLogo;
	@FindBy(id = Locator.CARD_INFORMATION_EMBOSSING_NAME)
	public WebElement cardEmbossName;
	@FindBy(how = How.XPATH, using = Locator.POSPROMPT_ODOMETER)
	public WebElement posPromptOdometerCheckbox;
	@FindBy(how = How.ID, using = Locator.CARD_TYPE)
	public WebElement cardType;
	@FindBy(how = How.ID, using = Locator.PRODUCT_RESTRICTION)
	public WebElement productRestriction;
	
	@FindBy(how = How.ID, using = Locator.PURCHASE_LOCATION_RESTRICTION)
	public WebElement purchaseLocationRestriction;
	@FindBy(how = How.ID, using = Locator.PURCHASE_TIME_LIMIT)
	public WebElement purchaseTimeLimit ;
	@FindBy(how = How.XPATH, using = Locator.ORDER_CARD_OFFER)
	public WebElement orderCardOffer ;
	@FindBy(how = How.ID, using = Locator.ORDER_CARD_PRODUCT)
	public WebElement orderCardProduct ;
	@FindBy(how = How.ID, using = Locator.DRIVER_NAME)
	public WebElement orderCarddriverName ;
	@FindBy(how = How.ID, using = Locator.TRANSACTION_PURCHASE_LIMIT)
	public WebElement transactionPurchaseLimit  ;
	@FindBy(how = How.ID, using = Locator.DAILY_TRANSACTION_LIMIT)
	public WebElement  dailyPurchaseLimit ;
	@FindBy(how = How.ID, using = Locator.TRANSACTION_VOLUME_LIMIT)
	public WebElement  transactionvolumeLimit  ;
	@FindBy(how = How.ID, using = Locator.DAILY_VOLUME_LIMIT)
	public WebElement dailyVolumeLimit   ;
	@FindBy(how = How.ID, using = Locator.MONTHLY_VOLUME_LIMIT)
	public WebElement  monthlyVolumeLimit ;
	@FindBy(how = How.ID, using = Locator.ORDERCARD_BUTTON)
	public WebElement orderCardButton  ;
	
	
	public OTICardPage(WebDriver driver, ExtentTest test) {

		super(driver, test);
		PageFactory.initElements(driver, this);

	}
	public void goToCardMenuCardList() { 
		mouseHoverClickMenuAndSubMenu("Cards", "Card List");
	}
	public void goToCardMenuOrderCard() {
		mouseHoverClickMenuAndSubMenu("Cards", "Order Card");
	}
	public void verifyCardListPage() {

		checkTextInPageAndValidate("Card List", 10);
	}
	public void selectAllAccountsAndActiveCard() {

		selectDropDownByVisibleText(accountList, "All Accounts");
		sleep(2);
		selectDropDownByVisibleText(filterCardStatus, "Active");

		sleep(2);
		isDisplayedThenClick(searchButton, "Search button");
		sleep(2);
	}
	public void selectAccountFromDropdownAndValidate() {
		
		isDisplayed(accountDropdown, "Account Drop down in home page");
		
		int size = getDropdownSize(accountDropdown);
		
		if(size > 1)
		{
			String accountName = selectedStringFrmDropDown(accountDropdown);
			System.out.println("accountNAme ---- "+accountName);
			sleep(5);
			selectDifferentValueInsteadOfDefault(accountDropdown, accountName, "");
			sleep(3);
			String accname2 = selectedStringFrmDropDown(accountDropdown);
			sleep(5);
			if(!accountName.contains(accname2)) {
				logInfo("Account 1 = "+accountName+" Different Account selected ---="+accname2);
				logPass("Different Account Selected");
			} 
			
			else
			{
				logInfo("Account 1 = "+accountName+" Different Account selected ---="+accname2);
				logFail("Different Account is not selected");
			}
		}
		else
		{
			logInfo("accountDropdown in home page has only one option");
		}
	}
	public void backToHomePage() {

		isDisplayedThenClick(otiLogo,"OTI Logo");
		sleep(3);
}
	public void enterNewCardDetailsInOrderCardPage() {
		selectDropDownByIndex(orderCardOffer,1);
		isDisplayed(orderCardProduct,"Card Product");
		isDisplayed(cardType,"Card Type drop down");
		isDisplayedThenClearText(cardEmbossName,"Embossing text field is clear");
		String embossName = fakerAPI().name().fullName();
		isDisplayedThenEnterText(cardEmbossName,"Emboss name", embossName);
		isDisplayedThenActionClick(posPromptOdometerCheckbox, "Checked the check box");
		//String driverName = fakerAPI().name().fullName();
		//isDisplayedThenEnterText(orderCarddriverName,"Driver Name",driverName);
		isDisplayed(productRestriction,"Purchase  controls in Product restriction");
		isDisplayed(purchaseTimeLimit,"Purchase  controls in Time Limit");
		selectDropDownByIndex(transactionPurchaseLimit,1);
		selectDropDownByIndex(dailyPurchaseLimit,1);
		selectDropDownByIndex(transactionvolumeLimit,1);
		selectDropDownByIndex(dailyVolumeLimit,1);
		selectDropDownByIndex(monthlyVolumeLimit,1);
		isDisplayedThenActionClick(orderCardButton,"Order Card Button");
		
		
	}

	}
