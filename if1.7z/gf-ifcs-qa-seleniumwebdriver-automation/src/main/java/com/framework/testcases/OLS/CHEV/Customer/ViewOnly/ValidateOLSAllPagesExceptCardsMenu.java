package com.framework.testcases.OLS.CHEV.Customer.ViewOnly;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.CHEV.CHAccountMaintenancePage;
import com.framework.pages.CHEV.CHCardListPage;
import com.framework.pages.CHEV.CHHomePage;
import com.framework.pages.CHEV.CHPasswordMaintenancePage;
import com.framework.pages.CHEV.CHStoredReportsPage;
import com.framework.pages.CHEV.CHTransactionPage;
import com.framework.pages.EMAP.EMAPTransactionsPage;
import com.framework.pages.OLS.common.CommonPage;
import com.framework.pages.OLS.common.LoginPage;

public class ValidateOLSAllPagesExceptCardsMenu extends BaseTest {
	@Parameters({ "clientCountry", "clientName", "cardNumberStr" })
	@Test
	public void testCustomerViewOnlyOLSAllPagesExceptCardsMenu(@Optional("PH") String clientCountry,
			@Optional("CHV") String clientName, @Optional("CHV_PH_CARD_MENU_CREDIT_CARD") String cardNumberStr) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  View Only OLS - All Pages except cards menu", "Chevron Customer Screens View Only");

		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		CHHomePage chHomePage = new CHHomePage(driver, test);
		CHCardListPage cardListPage = new CHCardListPage(driver, test);
		// CHOrderCardPage orderCardPage = new CHOrderCardPage(driver, test);
		CHTransactionPage chTransactionPage = new CHTransactionPage(driver, test);
		CHAccountMaintenancePage accountMaintenancePage = new CHAccountMaintenancePage(driver, test);
		// CHTransactionSummaryPage chTransactionSummaryPage = new
		// CHTransactionSummaryPage(driver, test);
		CHStoredReportsPage chStoredReportsPage = new CHStoredReportsPage(driver, test);
		CHPasswordMaintenancePage chPasswordMaintenancePage = new CHPasswordMaintenancePage(driver, test);
//		CHContactUsPage chContactUsPage = new CHContactUsPage(driver, test);
		EMAPTransactionsPage transactionListsPage = new EMAPTransactionsPage(driver, test);
		CommonPage commonPage = new CommonPage(driver, test);

		if (clientCountry.equals("SG")||clientCountry.equals("MY")||clientCountry.equals("HK")) {
			loginPage.Login("CHV_URL", "CHV_Customer_UN_VIEW_ONLY_"+clientCountry, "CHV_Customer_PWD_VIEW_ONLY_"+clientCountry, "CHV");
		} else if (clientCountry.equals("TH")) {
			loginPage.Login("CHV_URL", "CHV_Customer_UN_"+clientCountry, "CHV_Customer_PWD_"+clientCountry, "CHV");
		} else if (clientCountry.equals("PH")) {
			loginPage.Login("CHV_URL", "CHV_Customer_UN_"+clientCountry, "CHV_Customer_PWD_"+clientCountry, "CHV");
		}
		chHomePage.verifyHelpLinkandClick();

		// TODO Remove this for read only
		// chHomePage.loadFindAndClickOnOrderCard();

		chHomePage.clickOnHome();

		// chHomePage.findAndClickOrderCardQuickLink();
		// orderCardPage.verifyOrderCardPageTitle();
		// chHomePage.clickOnHome();

		// chHomePage.findAndClickCardStatusQuickLink();
		// cardListPage.verifyCardPageTitle();
		// chHomePage.clickOnHome();

		chHomePage.findAndClickCardsQuickLink();
		cardListPage.verifyCardPageTitle();
		chHomePage.clickOnHome();

		chHomePage.findAndClickTransactionQuickLink();
		chTransactionPage.verifyTransactionPage();
		chHomePage.clickOnHome();

		chHomePage.findAndClickExportTransactionQuickLink();
//		chHomePage.checkForFileDownload(1);
		
		String checkFileDate=chHomePage.validateDateInDownloadedFile();
		commonPage.isFileDownloaded(checkFileDate);

		// Invalid Steps - Updated by Nithya - 28-09-2018
		// if (clientCountry.equals("TH")) {
		// loginPage.Login("CHV_URL", "CHV_TH_Customer_UN", "CHV_TH_Customer_PWD",
		// "CHV");
		// } else if (clientCountry.equals("PH")) {
		// loginPage.Login("CHV_URL", "CHV_PH_Customer_UN", "CHV_PH_Customer_PWD",
		// "CHV");
		// }
		//
		chHomePage.verifyUserNameAndLogoutLink();
		chHomePage.verifyExportAccountLink();
		chHomePage.loadFindAndUpdateAccountmaintenancePage();

		accountMaintenancePage.verifyIfFieldsAreEditable();

		accountMaintenancePage.verifyAddressTitles();
		chHomePage.loadFindAndTransactionsPage();
		chTransactionPage.verifySearchButtons();
		chTransactionPage.verifyExportButtons();

		// String cardNumber = PropUtils.getPropValue(configProp, cardNumberStr);
		//chTransactionPage.enterCardNumberAndSearch();
		chTransactionPage.verifyTransactionListHeaders();

		// Add Transaction Details Page Steps
		// Transaction - Transaction List
		commonPage.selectAllAccountInTransactionFilterSearch();
		boolean isTransactionPresent = transactionListsPage.getACardNumberWithTransaction();
		if (isTransactionPresent) {
			transactionListsPage.enterACardNumberInSearchFilter();
			commonPage.clickSearchButton();
			transactionListsPage.validateSearchResultsAndClickViewTransactionsOption(true);
			transactionListsPage.verifyTransactionDetailsHeaderTitle();
			transactionListsPage.validateTransactionPageFields("Customer");
		}
		// chTransactionPage.clickOnCreditCardNumber();
		//
		// chTransactionSummaryPage.verifyPageTitle();

		chHomePage.loadFindAndUpdateStoredReportsPage();
		chStoredReportsPage.verifyPageTitle();
		chStoredReportsPage.verifyPageSubTitles();
		chStoredReportsPage.searchResultsTableHeaders();
		chStoredReportsPage.verifySearchButtons();
		chStoredReportsPage.verifyExportButtons();
		chHomePage.loadFindAndFindPasswordPage();
		chPasswordMaintenancePage.verifyPageSubtitles();
		
		/*chHomePage.loadFindAndContactUsPage();
		chHomePage.gotoLastPage();
//		chContactUsPage.verifySubscribeBtn();
//		chHomePage.verifyCloseAccountMenu();
		String parentWindow = driver.getWindowHandle();
		chHomePage.clickOnPrivacyStatement();
		chHomePage.verifyWindows();

		// TODO Switching window has to be removed when the privacy statement doesn't
		// open new window and also check pdf values when site is updated
		// TODO Two lines below can be removed if the privacy statement doesn't open a
		// new window
		chHomePage.switchToNewWindow(parentWindow, driver.getWindowHandles());
		// chHomePage.closeChildWindowAndswitchToParent(driver.getWindowHandle(),
		// driver.getWindowHandles());
		chHomePage.closeChildAndMoveToParent(parentWindow);*/

		loginPage.Logout();

	}

}
