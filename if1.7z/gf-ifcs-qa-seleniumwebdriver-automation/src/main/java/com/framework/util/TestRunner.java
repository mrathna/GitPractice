package com.framework.util;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;

public class TestRunner  {
	public static void main(String[] argv) throws Exception {
		
		System.setProperty("webdriver.gecko.driver", "D:\\eclipse-workspace\\SeleniumWebDriverAutomationFramework\\Resources\\Drivers\\GeckoDriver\\geckodriver.exe");
		
		FirefoxOptions options = new FirefoxOptions();
        options.setBinary("C:\\Program Files\\Mozilla Firefox\\firefox.exe"); //This is the location where you have installed Firefox on your machine

		
		WebDriver driver = new FirefoxDriver(options);
		driver.get("https://apac-int-bp.dev.emea.wexinc.co.uk/IFCSWeb-bp/faces/secure/home/homepage.xhtml");
		List<WebElement> elements = driver.findElements(By.xpath(".//*"));
		
		System.out.println("No. of Elements : " +  Integer.toString(elements.size()));
		for(WebElement el:elements)
		{
			if(!el.getText().equals(""))
			{
				System.out.println(el.getTagName() + " : " + el.getText() + " Atraibute : " + el.getAttribute("Id"));		
			}
		}
		System.out.println("Printing Complete");
		driver.quit();
		
	//String Qry = "";
	
		
	/*String Qry = "KEY MARINE & ENGINEERING SERVICES PL (0200226853)";
	System.out.println(Qry.substring(0,Qry.indexOf(" (")));
	System.out.println(Qry.substring(Qry.indexOf(" (")+2,Qry.indexOf(")")));
	System.out.println(Qry.indexOf(")"));*/
	/*
	String Qry = "Select drv.* from ttpa_user drv " + "join TTPA_ACCT acct on ACCT.ACCTID=DRV.ROOTACCTID "
			+ "where DRV.PRIVATEID='' and ACCT.SPNRACCTID='' and ACCT.ACCTNM=''";	
	System.out.println("SQL Query for DriveId : " + Qry + "\n");
	*/
	}	
}
