package com.framework.pages.AJS.common;

import java.io.File;
import java.io.FileInputStream;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.TimeZone;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;
import com.framework.basepage.BasePage;
import com.framework.pages.SHELL.SHELLCardsPage;
import com.framework.pages.SHELL.SHELLHomePage;
import com.framework.util.PdfUtils;
import com.framework.util.PropUtils;

public class CommonInterfacePage extends BasePage {
	public CommonInterfacePage(WebDriver driver, ExtentTest test) {
		super(driver, test);
		// TODO Auto-generated constructor stub
	}

	private String getDBDetailsFromProperties = "";
	private String versionNumber = null;
	private String sequenceNumber = null;
	private String sequenceNumberCaf = "";
	private String incomingFileName = "";
	private String filler = "";
	private String loadCardIFCSClientMid = "";
	private String loadCardIFCSSeqNo = "";
	private String loadCardIESeqNo = "";
	private String loadCardIFCSStartDate = "";
	private String loadCardIFCSCustomerNo = "";
	private boolean isValueUpdated = false;
	private String tempSeqNum = "";
	private String changedFormat = "";
	private boolean isDateUpdated = false;
	private boolean isTimeUpdated = false;
	private String refNumber = "";
	private String clienthhMMss = "";
	private String clientShortName = "";
	private String result = "";
	private String currentDateandTime = "";
	private String locationNoIFCS = "";

	// BasePage basePage = new BasePage(driver, test);
	// Fetch the Version number of the Card from the DB
	public String funcFetchVersionNumberOfTheCard(Properties properties, String cardNumber) {
		System.out.println("method got invoked");

		getDBDetailsFromProperties = PropUtils.getPropValue(properties, "sqlODSServerName");

		String queryToGetVersionNumber = "select c.VERSION_NUMBER from cards c, accounts a where c.account_oid=a.account_oid and Card_no="
				+ cardNumber;
		versionNumber = connectDBAndGetValue(queryToGetVersionNumber, getDBDetailsFromProperties);

		System.out.println("Version Number  from DB:- " + versionNumber + "Card number Is" + cardNumber);

		return versionNumber;

	}

	public String funcSeqNoFromIEForAC2File(Properties properties, String clientName) {

		int seqNo;

		if (!isValueUpdated) {
			if (clientName.equals("SHELL Czech Republic")) {
				clientShortName = "SH CZ";
			}

			else if (clientName.equalsIgnoreCase("SHELL Russia")) {
				clientShortName = "SH RU";
			}
			String queryToGetSeqNo;
			getDBDetailsFromProperties = PropUtils.getPropValue(properties, "ieServerName");

			queryToGetSeqNo = "select sequence_number_last_processed from incoming_file_sequences where INTERFACE_CATALOGUE = (select id from interface_catalogue where interface_catalogue_id like '%ACC2%') and client_code = '"
					+ clientShortName + "'";

			loadCardIESeqNo = connectIEDBAndGetValue(queryToGetSeqNo, getDBDetailsFromProperties);

			System.out.println("---- Sequence Number ---- " + loadCardIESeqNo);

			seqNo = Integer.parseInt(loadCardIESeqNo);

			seqNo = seqNo + 1;

			loadCardIESeqNo = Integer.toString(seqNo);

			int count = loadCardIESeqNo.length();

			if (count == 1 || count == 2) {
				tempSeqNum = String.format("%03d", seqNo);
			} else {
				tempSeqNum = String.valueOf(seqNo);
			}

			System.out.println("The updated sequence Number ----- :: " + tempSeqNum);

			if (!tempSeqNum.equals("")) {
				isValueUpdated = true;
			}
		}

		else {
			System.out.println("The method already executed, the  sequence Number is ----- :: " + tempSeqNum);
		}

		return tempSeqNum;
	}

	public String funcSeqNoFromIEForACCFile(Properties properties, String clientName) {

		int seqNo;
		if (!isValueUpdated) {
			if (clientName.equals("SHELL Czech Republic")) {
				clientShortName = "SH CZ";
			}

			else if (clientName.equals("ООО Шелл Нефть")) {
				clientShortName = "SH RU";
			}

			getDBDetailsFromProperties = PropUtils.getPropValue(properties, "ieServerName");

			String queryToGetSeqNo = "select sequence_number_last_processed from incoming_file_sequences where INTERFACE_CATALOGUE = (select id from interface_catalogue where interface_catalogue_id like '%ACCT%') and client_code = '"
					+ clientShortName + "'";

			loadCardIESeqNo = connectIEDBAndGetValue(queryToGetSeqNo, getDBDetailsFromProperties);

			System.out.println("---- Sequence Number ---- " + loadCardIESeqNo);

			seqNo = Integer.parseInt(loadCardIESeqNo);

			seqNo = seqNo + 1;

			loadCardIESeqNo = Integer.toString(seqNo);

			int count = loadCardIESeqNo.length();

			if (count == 1 || count == 2) {
				tempSeqNum = String.format("%03d", seqNo);
			} else {
				tempSeqNum = String.valueOf(seqNo);
			}

			System.out.println("The updated sequence Number ----- :: " + tempSeqNum);

			if (!tempSeqNum.equals("")) {
				isValueUpdated = true;
			}
		}

		else {
			System.out.println("The method already executed, the  sequence Number is ----- :: " + tempSeqNum);
		}

		return tempSeqNum;
	}

	public String funcSeqNoFromIE(Properties properties, String clientName) {

		int seqNo;
		String queryToGetSeqNo = "";

		if (!isValueUpdated) {
			if (clientName.contains("SHELL")) {
				if (clientName.equals("SHELL Czech Republic")) {
					clientShortName = "SH CZ";
				}

				else if (clientName.equals("SHELL Russia")) {
					clientShortName = "SH RU";
				}

				getDBDetailsFromProperties = PropUtils.getPropValue(properties, "ieServerName");

				queryToGetSeqNo = "select sequence_number_last_processed from incoming_file_sequences where client_code ='"
						+ clientShortName + "' and interface_catalogue=22";

			} else if (clientName.contains("EMAP")) {
				getDBDetailsFromProperties = PropUtils.getPropValue(properties, "ieServerName");

				String clientCountry = PropUtils.getPropValue(configProp, "clientCountry");

				queryToGetSeqNo = "select sequence_number_last_processed from incoming_file_sequences where client_code ='EX "
						+ clientCountry + "' and interface_catalogue=21";
			}

			loadCardIESeqNo = connectIEDBAndGetValue(queryToGetSeqNo, getDBDetailsFromProperties);

			System.out.println("---- Sequence Number ---- " + loadCardIESeqNo);

			seqNo = Integer.parseInt(loadCardIESeqNo);

			seqNo = seqNo + 1;

			loadCardIESeqNo = Integer.toString(seqNo);

			int count = loadCardIESeqNo.length();

			if (count == 1 || count == 2) {
				tempSeqNum = String.format("%03d", seqNo);
			} else {
				tempSeqNum = String.valueOf(seqNo);
			}

			System.out.println("The updated sequence Number ----- :: " + tempSeqNum);

			if (!tempSeqNum.equals("")) {
				isValueUpdated = true;
			}
		}

		else {
			System.out.println("The method already executed, the  sequence Number is ----- :: " + tempSeqNum);
		}

		return tempSeqNum;
	}

	public String funcDate(Properties properties, String clientCountry) {

		System.out.println("---- comes in funcDate --- ");
		String queryToGetStartDate = null;
		SimpleDateFormat format2;
		String clientCountryName = PropUtils.getPropValue(configProp, "clientCountry");
		String clientName = PropUtils.getPropValue(configProp, "clientName");
		if (!isDateUpdated) {

			getDBDetailsFromProperties = PropUtils.getPropValue(properties, "sqlODSServerName");

			if (clientCountry.contains("SHELL")) {
				queryToGetStartDate = "select processing_date from m_clients where IE_client_id = 'SH "
						+ clientCountryName + "'";
			} else if (clientCountry.contains("EMAP")) {
				queryToGetStartDate = "select processing_date from m_clients where IE_client_id = 'EX "
						+ clientCountryName + "'";
			} 
			else if (clientName.contains("WFE")) {
				queryToGetStartDate =  "SELECT PROCESSING_DATE from M_CLIENTS where Name ='" + PropUtils.getPropValue(configProp, clientName + "_" + clientCountryName) + "'";
			}
			else {
				queryToGetStartDate = "select processing_date from m_clients where name like '" + clientCountry + "'";
			}
			loadCardIFCSStartDate = connectDBAndGetValue(queryToGetStartDate, getDBDetailsFromProperties);
			System.out.println("Load Card Func date::::::" + loadCardIFCSStartDate);

			SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

			Date date = null;
			try {
				date = format1.parse(loadCardIFCSStartDate);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			if (clientCountry.contains("EMAP")) {
				Date newDate;
				Calendar cal = Calendar.getInstance();
				try {
					cal.setTime(format1.parse(loadCardIFCSStartDate));
					cal.add(Calendar.MONTH, -1);
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				newDate = cal.getTime();
				format2 = new SimpleDateFormat("yyyyMMdd");
				changedFormat = format2.format(newDate);
			} else if (clientCountry.contains("Chevron")) {
				format2 = new SimpleDateFormat("yyyyMMdd");
				changedFormat = format2.format(date);
			} 
			
			else if (clientName.equals("WFE")) {
				format2 = new SimpleDateFormat("yyyyMMdd");
				changedFormat = format2.format(date);
				
			}
			
			else {
				format2 = new SimpleDateFormat("yyMMdd");
				changedFormat = format2.format(date);
			}

			if (!changedFormat.equals("")) {
				isDateUpdated = true;
			}

			System.out.println("------ IF changedFormat -----" + changedFormat);
		}

		else {
			System.out.println("------ Else changedFormat -----" + changedFormat);
		}

		return changedFormat;
	}
	
	
	/**Added by Nithya - Vincii Card Badge number*/

	public String funcBatchNo(String cardNumber) {
	String query ="select badgenumber from card where cardnumber = '"+cardNumber+"'";
	String batchNo =  connectICPDBAndGetValue(query, PropUtils.getPropValue(configProp, "icpServerName"));
	
	

	int count = batchNo.length();

	if (count == 1) {
		batchNo = batchNo+"      ";
	} else if (count == 2) {
		batchNo = batchNo+"     ";
	} else if (count == 3) {
		batchNo = batchNo+"    ";
	} else if (count == 4) {
		batchNo = batchNo+"   ";
	} else if (count == 5) {
		batchNo = batchNo+"  ";
	} else if (count == 6) {
		batchNo = batchNo+" ";
	}

	return batchNo;
	
	
	}
	
	/**Added by Nithya - Vincii - Sequence Number*/

	public String getSequenceNoForVinciiTransFromICPDB() {
	String query ="select ts.filesequencenumber + 1 as expectedVinciTrxSequenceNumber \r\n" +
	"from icpms_wfe_uat_2.transferfileseq ts where ts.type = 'V01T' and ts.sourcesystem = 'VINCIMAP'";
	sequenceNumber =  connectICPDBAndGetValue(query, PropUtils.getPropValue(configProp, "icpServerName"));
	
	
	int count = sequenceNumber.length();

	if (count == 1) {
		sequenceNumber = "000" + sequenceNumber;
	} else if (count == 2) {
		sequenceNumber = "00" + sequenceNumber;
	} else if (count == 3) {
		sequenceNumber = "0" + sequenceNumber;
	}

	return sequenceNumber;
	}
	
	public String getBadgeNumbersForNoOfCardFromICPDB(int noOfCards, String withStatus) {
		Common common=new Common(driver,test);
		String query = "select cardnumber from card where badgenumber is not NULL";
		String[] returnedValues = connectICPDBAndGetDBResults(query, 50,
		PropUtils.getPropValue(configProp, "icpServerName"));
		String valuesNeeded = null ;
		int count = 0;
		for (int i = 0; i < returnedValues.length - 1; i++) {
		//System.out.println("Length:" + valuesNeeded);
		if (common.getCardStatus(returnedValues[i]).contains(withStatus)) {
		if (count < noOfCards) {
		valuesNeeded = valuesNeeded+","+funcBatchNo(returnedValues[i]);
		count++;
		System.out.println("Cards:" + valuesNeeded);
		} else {
		break;
		}
		}
		}

		return valuesNeeded;
		}

	
	public String getTimeBasedOnTimeZone()
	{
		String clientCountryName = PropUtils.getPropValue(configProp, "clientCountry");
		String clientName = PropUtils.getPropValue(configProp, "clientName");
		
		String getTime="select description from timezones where timezone_oid=(select timezone_oid from m_clients where name='" + PropUtils.getPropValue(configProp, clientName + "_" + clientCountryName)+ "')";
		 
		String time = connectDBAndGetValue(getTime ,getDBDetailsFromProperties);
		SimpleDateFormat df = new SimpleDateFormat("HHmmss");
		df.setTimeZone(TimeZone.getTimeZone(time));
		Date now = Calendar.getInstance(TimeZone.getTimeZone(time)).getTime();
		System.out.println("Time:"+df.format(now));
		return df.format(now);
		
		
		 
	}

	// Fetch the Sequence Number for the CAF File from the IEDB

	public String fetchSequenceNumber(Properties properties, String targetFileName) {

		getDBDetailsFromProperties = PropUtils.getPropValue(properties, "ieServerName");

		String queryToGetSequenceNumber = "select sequence_number_in_use as seq_num from outgoing_file_sequences where id =(select max(id) from outgoing_file_sequences where sequence_name like '"
				+ targetFileName + "' and status = 1)";

		sequenceNumber = connectIEDBAndGetValue(queryToGetSequenceNumber, getDBDetailsFromProperties);

		System.out.println("Version Number  from DB:- " + sequenceNumber);

		return sequenceNumber;

	}

	/*
	 * Fetch Customer number from DB and add by one
	 * 
	 * @author Meenakshi Sundaram
	 * 
	 */
	public String funcFetchCustomerNumber(Properties properties, String clientCountry) {

		String customerNumber = null;
		String queryToGetSequenceNumber = null;

		getDBDetailsFromProperties = PropUtils.getPropValue(properties, "sqlODSServerName");
		if (clientCountry.equals("SHELL Russia")) {
			queryToGetSequenceNumber = "SELECT CUSTOMER_NO FROM M_CUSTOMERS WHERE CLIENT_MID = (select client_mid from m_clients where SHORT_NAME = 'Shell RU') ORDER BY CUSTOMER_NO DESC FETCH FIRST ROW ONLY";
		} else {
			queryToGetSequenceNumber = "SELECT CUSTOMER_NO FROM M_CUSTOMERS WHERE CLIENT_MID = (select client_mid from m_clients where name = '"
					+ clientCountry + "') ORDER BY CUSTOMER_NO DESC FETCH FIRST ROW ONLY";
		}
		System.out.println("---- Query for Customer Number ----- " + queryToGetSequenceNumber);

		customerNumber = connectDBAndGetValue(queryToGetSequenceNumber, getDBDetailsFromProperties);

		// Split the string and integer using Regular Expression
		String splitString[] = customerNumber.split("(?<=\\D)(?=\\d)");
		System.out.println("Alphabet--" + splitString[0] + "Numbers--" + splitString[1]);
		String alphabetValue = splitString[0];
		String numString = splitString[1];

		// Parsing the string to integer for adding the one
		long numValue = Integer.parseInt(numString);
		numValue = numValue + 1;
		numString = Long.toString(numValue);

		int letterCount = alphabetValue.length();
		int numberCount = numString.length();
		int zeroCount = 10 - (letterCount + numberCount);

		// calculate zero's length for appending to the string CZ00000289
		if (zeroCount != 0 && zeroCount > 0) {
			String fomattedValue = String.format("%0" + zeroCount + "d%s", 0, numString);
			customerNumber = alphabetValue + fomattedValue;
		} else {
			customerNumber = alphabetValue + numString;
		}

		System.out.println("customerNumber--" + customerNumber);

		return customerNumber;
	}

	// Create FileNameFormat for CAF
	public String createFileNameFormatforCAF(Properties properties) {
		result = fetchSequenceNumber(properties, "CHEVSG_PositiveCardChangesSeq");
		if (result.length() == 1) {
			sequenceNumberCaf = "000" + result;
		} else if (result.length() == 2) {
			sequenceNumberCaf = "00" + result;
		}

		else if (result.length() == 3) {
			sequenceNumberCaf = "0" + result;
		} else {
			sequenceNumberCaf = result;
		}
		incomingFileName = "PVSI" + sequenceNumberCaf + ".XMT";
		return incomingFileName;
	}

	// Create FileNameFormat for CMD AC2 SHELL-32-H3-AC2-000005.dat
	public String createFileNameFormatforAC2(String clientName) {
		result = funcSeqNoFromIEForAC2File(configProp, clientName);
		incomingFileName = "SHELL-32-H3-AC2-000" + result + ".dat";
		return incomingFileName;
	}

	// Create FileNameFormat for CMD ACC SHELL-32-H3-ACC-000005.dat
	public String createFileNameFormatforACC(String clientName) {
		result = funcSeqNoFromIEForACCFile(configProp, clientName);
		incomingFileName = "SHELL-32-H3-ACC-000" + result + ".dat";
		return incomingFileName;
	}

	// CAF_CZ_2019_02_000001.csv
	public String createFileNameFormatforCAFShell(Properties properties, String clientCountry) {
		currentDateandTime = getCurrentDateAndTime("yyyy_MM_");
		String seqNumberForCAF = fetchSequenceNumber(properties, "SHRU_POSITIVECARDCHANGESSEQ");

		int count = seqNumberForCAF.length();

		if (count == 1) {
			seqNumberForCAF = "00000" + seqNumberForCAF;
		} else if (count == 2) {
			seqNumberForCAF = "0000" + seqNumberForCAF;
		} else if (count == 3) {
			seqNumberForCAF = "000" + seqNumberForCAF;
		}
		incomingFileName = "caf_" + clientCountry + "_" + currentDateandTime + seqNumberForCAF + ".csv";
		return incomingFileName;
	}

	// GSD.APAPC_TIME.xml
	public String createFileNameFormatforGSDShell(String clientCountry) {
		currentDateandTime = getCurrentDateAndTime("yyyyMMdd_HHmmss");
		incomingFileName = "GSD.APAPC_" + currentDateandTime + ".xml";
		return incomingFileName;
	}

	private String createFileNameFormatForCardEmboss(String fileName, String fileFormat) {
		incomingFileName = fileName + "." + fileFormat; // Need to update the last processed number based on the file
														// name
		System.out.println("Incoming file Name ::" + incomingFileName);
		return incomingFileName;
	}

	// Filler Creation
	public String fillerCreation(int numberOfSpaces) {
		System.out.println("Method got Invoked");
		System.out.println("Spaces are " + numberOfSpaces);
		String padded = String.format("%-" + numberOfSpaces + "s", filler);
		System.out.println("Padded string is" + padded);
		return padded;
	}

	// Prakalpha tried for Russia
	public String funcFetchLoadCardTransClientMidFromIFCSDB(Properties properties) {

		getDBDetailsFromProperties = PropUtils.getPropValue(properties, "sqlODSServerName");

		String clientName = PropUtils.getPropValue(configProp, "clientName");
		String clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		String queryToGetClientMid = "select client_mid from m_clients where name='"
				+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountry).replaceAll("\"", "") + "'";

		System.out.println("clientCountry::" + queryToGetClientMid);

		loadCardIFCSClientMid = connectDBAndGetValue(queryToGetClientMid, getDBDetailsFromProperties);

		return loadCardIFCSClientMid;
	}

	public String funcFetchLoadCardTransClientMidFromDB(Properties properties, String clientName,
			String clientCountry) {

		getDBDetailsFromProperties = PropUtils.getPropValue(properties, "sqlODSServerName");

		// String clientName = PropUtils.getPropValue(configProp, "clientName");
		// String clientCountry=PropUtils.getPropValue(configProp, "clientCountry");
		String queryToGetClientMid = "select client_mid from m_clients where name='"
				+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountry).replaceAll("\"", "") + "'";

		System.out.println("clientCountry::" + queryToGetClientMid);

		loadCardIFCSClientMid = connectDBAndGetValue(queryToGetClientMid, getDBDetailsFromProperties);

		return loadCardIFCSClientMid;
	}

	// OTI
	public String funcFetchCardNegativeSyncClientMidfromIFCSDB(Properties properties, String clientName,
			String clientCountry) {
		String clientMid;
		getDBDetailsFromProperties = PropUtils.getPropValue(properties, "sqlODSServerName");
		String queryToGetClientMid = "select client_mid from m_clients where name='"
				+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountry) + "'";

		clientMid = connectDBAndGetValue(queryToGetClientMid, getDBDetailsFromProperties);
		System.out.println("Country mid" + clientMid);
		return clientMid;
	}

	public String funcFetchLoadCardTransSeqNoFromIFCSDB(Properties properties, String clientCountry) {
		int seqNo;
		getDBDetailsFromProperties = PropUtils.getPropValue(properties, "sqlODSServerName");

		String queryToGetSeqNo = "select LAST_SEQUENCE_NUMBER from interface_files_incoming where interface_file_incoming_id = 'LoadCardTransactions' and client_mid = (select client_mid from m_clients where name like '"
				+ clientCountry + "')";

		loadCardIFCSSeqNo = connectDBAndGetValue(queryToGetSeqNo, getDBDetailsFromProperties);

		seqNo = Integer.parseInt(loadCardIFCSSeqNo);
		seqNo = seqNo + 1;
		loadCardIFCSSeqNo = Integer.toString(seqNo);

		int count = loadCardIFCSSeqNo.length();

		if (count == 1) {
			loadCardIFCSSeqNo = "00000" + loadCardIFCSSeqNo;
		} else if (count == 2) {
			loadCardIFCSSeqNo = "0000" + loadCardIFCSSeqNo;
		} else if (count == 3) {
			loadCardIFCSSeqNo = "000" + loadCardIFCSSeqNo;
		}

		return loadCardIFCSSeqNo;
	}

	public String funcFetchLoadCardTransStartDateFromIFCSDB(Properties properties, String clientCountry) {
		String queryToGetStartDate;
		getDBDetailsFromProperties = PropUtils.getPropValue(properties, "sqlODSServerName");
		System.out.println("clientCountry::" + clientCountry);
		if (clientCountry.contains("Russia")) {
			queryToGetStartDate = "select processing_date from m_clients where SHORT_NAME like 'Shell RU'";
		} else {
			queryToGetStartDate = "select processing_date from m_clients where name like '" + clientCountry + "'";
		}
		loadCardIFCSStartDate = connectDBAndGetValue(queryToGetStartDate, getDBDetailsFromProperties);

		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		try {
			Date date = dateFormat.parse(loadCardIFCSStartDate);
			loadCardIFCSStartDate = dateFormat.format(date);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			logFail(e.getMessage());
		}
		String getTime = "select description from timezones where timezone_oid=(select timezone_oid from m_clients where name like '"
				+ clientCountry + "')";
		String time = connectDBAndGetValue(getTime, getDBDetailsFromProperties);
		SimpleDateFormat df = new SimpleDateFormat("HH:mm:ss");
		df.setTimeZone(TimeZone.getTimeZone(time));
		Date now = Calendar.getInstance(TimeZone.getTimeZone(time)).getTime();
		System.out.println("Time:" + df.format(now));

		return loadCardIFCSStartDate + " " + (df.format(now));
	}

	public String funcFetchLoadCardTransCustomerNoFromIFCSDB(Properties properties, String clientCountry) {

		getDBDetailsFromProperties = PropUtils.getPropValue(properties, "sqlODSServerName");

		String queryToGetCustomerNo = "Select c.card_no from m_customers MC inner join cards C on c.customer_mid = mc.customer_mid inner join card_status CS on c.card_status_oid=cs.card_status_oid inner join m_clients MCS on mc.client_mid = MCS.CLIENT_MID where cs.description like '%Active%' and mcs.name like'"
				+ clientCountry + "'and C.EXPIRES_ON > MCS.PROCESSING_DATE  and rownum = 1 order by c.expires_on asc";

		loadCardIFCSCustomerNo = connectDBAndGetValue(queryToGetCustomerNo, getDBDetailsFromProperties);

		System.out.println("----- loadCardIFCSCustomerNo -------" + loadCardIFCSCustomerNo);

		return loadCardIFCSCustomerNo;
	}

	public String funcFetchLocationNoFromIFCSDB(Properties properties, String clientCountry, String clientName) {
		int locNo;
		String queryToGetLocationNo;
		getDBDetailsFromProperties = PropUtils.getPropValue(properties, "sqlODSServerName");
		if (clientCountry.equals("Russia")) {

			queryToGetLocationNo = "select LOCATION_NO from m_locations where client_mid = (select client_mid from m_clients where SHORT_NAME = 'Shell RU') ORDER BY LOCATION_NO DESC FETCH FIRST ROW ONLY";
			System.out.println("queryToGetLocationNo====" + queryToGetLocationNo);
		} else {
			queryToGetLocationNo = "select LOCATION_NO from m_locations where client_mid = (select client_mid from m_clients where SHORT_NAME = '"
					+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountry).replaceAll("\"", "")
					+ "') ORDER BY LOCATION_NO DESC FETCH FIRST ROW ONLY";
		}
		locationNoIFCS = connectDBAndGetValue(queryToGetLocationNo, getDBDetailsFromProperties);

		locNo = Integer.parseInt(locationNoIFCS);
		locNo = locNo + 1;
		locationNoIFCS = Integer.toString(locNo);

		if (locationNoIFCS.length() < 8) {
			System.out.println("if inside");
			int zeroCount = 8 - locationNoIFCS.length();
			locationNoIFCS = String.format("%0" + zeroCount + "d%s", 0, locationNoIFCS);
		}

		System.out.println("----- locationNoIFCS -------" + locationNoIFCS);

		return locationNoIFCS;
	}

	public String funcRefNo(Properties properties, String clientCountry) {

		String randomDigit = "";

		if (clientCountry.contains("EMAP")) {
			randomDigit = fakerAPI().number().digits(2);
		} else
			randomDigit = fakerAPI().number().digits(3);

		String clientMid = funcFetchLoadCardTransClientMidFromIFCSDB(properties);

		String midNumber = String.format("%1$" + 3 + "s", clientMid).replace(' ', '0');

		// refNumber = midNumber+randomDigit;

		if (clientCountry.contains("EMAP")) {
			refNumber = "E" + midNumber + randomDigit;
		} else
			refNumber = midNumber + randomDigit;

		System.out.println("----- TEST  ----- Reference Number ---- " + refNumber);

		return refNumber;
	}

	public String funcTimeOfClient(Properties properties, String clientCountry) {

		if (!isTimeUpdated) {
			getDBDetailsFromProperties = PropUtils.getPropValue(properties, "sqlODSServerName");

			String midNumber = funcFetchLoadCardTransClientMidFromIFCSDB(properties);

			String queryTimeZone = "Select description from m_clients MC inner join TIMEZONES TZ on TZ.timezone_oid = mc.timezone_oid where MC.client_mid="
					+ midNumber;

			String timzone = connectDBAndGetValue(queryTimeZone, getDBDetailsFromProperties);

			TimeZone tz = TimeZone.getTimeZone(timzone);
			Calendar c = Calendar.getInstance(tz);

			int hourValue = c.get(Calendar.HOUR_OF_DAY);

			c.add(Calendar.MINUTE, 1);

			int minuteValue = c.get(Calendar.MINUTE);

			int secondValue = c.get(Calendar.SECOND);

			String hour = String.valueOf(hourValue);

			String minutes = String.valueOf(minuteValue);

			String seconds = String.valueOf(secondValue);

			if (hour.length() == 1) {
				hour = String.format("%02d", hourValue);
			}

			if (minutes.length() == 1) {
				minutes = String.format("%02d", minuteValue);
			}

			if (seconds.length() == 1) {
				seconds = String.format("%02d", secondValue);
			}

			clienthhMMss = hour + minutes + seconds;

			if (!clienthhMMss.equals("")) {
				isTimeUpdated = true;
			}

			System.out.println("---- IF Part -----" + clienthhMMss);
		} else {
			System.out.println("---- Else Part -----" + clienthhMMss);
		}

		return clienthhMMss;
	}

	// Prakalpha-->Emap
	public String funcEmbossCardsFetchSeqNoFromIEDB(Properties properties, String clientName, String countryName,
			String fileType) {
		String clientShort = getShortClientName(clientName);
		System.out.println(clientShort);
		String queryToGetSeqNo = "";

		String shortName = clientShort + countryName;
		System.out.println(shortName);
		getDBDetailsFromProperties = PropUtils.getPropValue(properties, "ieServerName");
		System.out.println(getDBDetailsFromProperties + "::+::+getDBDetailsFromProperties::+::+");

		if (fileType.equalsIgnoreCase("EmbossCards")) {
			queryToGetSeqNo = "select max(sequence_number_in_use) from outgoing_file_sequences where Sequence_name = '"
					+ shortName + "_EmbossCardSequence'";
		} else if (fileType.equalsIgnoreCase("PinMailer")) {
			queryToGetSeqNo = "select max(sequence_number_in_use) from outgoing_file_sequences where Sequence_name = '"
					+ shortName + "_PinMailerSequence'";
		} else if (fileType.equalsIgnoreCase("CAF")) {
			queryToGetSeqNo = "select max(sequence_number_in_use) from outgoing_file_sequences where Sequence_name = '"
					+ shortName + "_PositiveCardChangesSeq'";
		}
		System.out.println(queryToGetSeqNo + "::+::+queryToGetSeqNo::+::+");
		String IESeqNo = connectIEDBAndGetValue(queryToGetSeqNo, getDBDetailsFromProperties);

		System.out.println("seq No::" + IESeqNo);
		int count = IESeqNo.length();
		System.out.println(count);

		if (count == 1) {
			IESeqNo = "00000" + IESeqNo;
		} else if (count == 2) {
			IESeqNo = "0000" + IESeqNo;
		} else if (count == 3) {
			IESeqNo = "000" + IESeqNo;
		}

		return IESeqNo;
	}

	/*
	 * Prakalpha -->06/24/2019 EMAP to get CAF file sequence number
	 */
	public String funcCardCAFFetchSeqNoFromIEDB(Properties properties, String clientName, String countryName,
			String fileType) {
		String clientShort = getShortClientName(clientName);
		System.out.println(clientShort);
		String queryToGetSeqNo = "";

		String shortName = clientShort + countryName;
		System.out.println(shortName);
		getDBDetailsFromProperties = PropUtils.getPropValue(properties, "ieServerName");
		System.out.println(getDBDetailsFromProperties + "::+::+getDBDetailsFromProperties::+::+");

		if (fileType.equalsIgnoreCase("CAF")) {
			queryToGetSeqNo = "select max(sequence_number_in_use) from outgoing_file_sequences where Sequence_name = '"
					+ shortName + "_PositiveCardChangesSeq'";
		}
		System.out.println(queryToGetSeqNo + "::+::+queryToGetSeqNo::+::+");
		String IESeqNo = connectIEDBAndGetValue(queryToGetSeqNo, getDBDetailsFromProperties);

		System.out.println("seq No::" + IESeqNo);
		int count = IESeqNo.length();
		System.out.println(count);

		if (count == 1) {
			IESeqNo = "00" + IESeqNo;
		} else if (count == 2) {
			IESeqNo = "0" + IESeqNo;
		}

		return IESeqNo;
	}

	/*
	 * This is to generate the file Name for the CAF file processing
	 * 
	 * @author Anton
	 * 
	 */

	public String getRecentProcessedFileName(Properties properties, String clientName, String clientCountry, long count,
			String fileType) {
		String recentProcessedFile = null, tempStr = null;

		/*
		 * client= getClientFullName(clientName, clientCountry);
		 * System.out.println("client::" +client); String midNumber =
		 * funcFetchLoadCardTransClientMidFromIFCSDB(properties, client) ;
		 */
		String midNumber = funcFetchLoadCardTransClientMidFromIFCSDB(properties);
		System.out.println("---- midNumber ---- " + midNumber);

		getDBDetailsFromProperties = PropUtils.getPropValue(properties, "ieServerName");

		String queryToRecProcessNumber = "Select MAX(TARGET_FILENAME) from output_files ofile inner join transformation_run TR on TR.ID = ofile.transformation_run_id where TR.source_filename like '%"
				+ fileType + "_" + midNumber + "%'";

		recentProcessedFile = connectIEDBAndGetValue(queryToRecProcessNumber, getDBDetailsFromProperties);
		System.out.println("DBrecentProcessedFile::" + recentProcessedFile);

		tempStr = recentProcessedFile.substring(1);

		long recentFile = Long.parseLong(tempStr) + count;

		recentProcessedFile = "x" + String.valueOf(recentFile);

		if (fileType.equalsIgnoreCase("EmbossCards")) {
			recentProcessedFile = createFileNameFormatForCardEmboss(recentProcessedFile, "cra");
		} else if (fileType.equalsIgnoreCase("PinMailer")) {
			recentProcessedFile = createFileNameFormatForCardEmboss(recentProcessedFile, "pma");
		} else {
			logInfo("File type in not present");
		}

		return recentProcessedFile;
	}

	/* Prakalpha-->EMAP */

	public String getEMAPRecentProcessedFileName(Properties properties, String clientName, String clientCountry,
			String fileType) {
		String recentProcessedFile = null;
		String queryToRecProcessNumber = "";
		String seqNumber = "";
		if (fileType.equalsIgnoreCase("EmbossCards") || fileType.equalsIgnoreCase("PinMailer")) {
			seqNumber = funcEmbossCardsFetchSeqNoFromIEDB(properties, clientName, clientCountry, fileType);
		} else if (fileType.equalsIgnoreCase("CAF")) {
			seqNumber = funcCardCAFFetchSeqNoFromIEDB(properties, clientName, clientCountry, fileType);
		}
		if (clientCountry.equals("MO")) {
			clientCountry = "MC";
		}
		System.out.println("----Client Country ---- " + clientCountry);
		System.out.println("---- Sequences Number ---- " + seqNumber);

		getDBDetailsFromProperties = PropUtils.getPropValue(properties, "ieServerName");
		if (fileType.equalsIgnoreCase("EmbossCards")) {
			queryToRecProcessNumber = "select target_Filename from output_files where Target_filename like 'EMA1_"
					+ clientCountry + "_" + seqNumber + "%'";
		} else if (fileType.equalsIgnoreCase("PinMailer")) {
			queryToRecProcessNumber = "select target_Filename from output_files where Target_filename like 'EMA1PINMAILER_"
					+ clientCountry + "_" + seqNumber + "%'";
		} else if (fileType.equalsIgnoreCase("CAF")) {
			if (clientCountry.equals("GU")) {
				clientCountry = "GM";
			}
			queryToRecProcessNumber = "select target_Filename from output_files where Target_filename like '"
					+ clientCountry + "CFU_" + seqNumber + "%'";
		}
		recentProcessedFile = connectIEDBAndGetValue(queryToRecProcessNumber, getDBDetailsFromProperties);
		System.out.println("DBrecentProcessedFile::" + recentProcessedFile);
		if (recentProcessedFile.contains("cardrenewal")) {
			int seq = Integer.parseInt(seqNumber) - 1;
			System.out.println("Seq no::" + seq);
			String sequences = String.valueOf(seq);
			int count = sequences.length();
			System.out.println(count);

			if (count == 1) {
				sequences = "00000" + sequences;
			} else if (count == 2) {
				sequences = "0000" + sequences;
			} else if (count == 3) {
				sequences = "000" + sequences;
			}

			queryToRecProcessNumber = "select target_Filename from output_files where Target_filename like 'EMA1_"
					+ clientCountry + "_" + sequences + "%'";
			recentProcessedFile = connectIEDBAndGetValue(queryToRecProcessNumber, getDBDetailsFromProperties);
			System.out.println("DBrecentProcessedFile::" + recentProcessedFile);
		}

		if (fileType.equalsIgnoreCase("EmbossCards")) {
			recentProcessedFile = createFileNameFormatForCardEmboss(recentProcessedFile, "txt");
			logPass(recentProcessedFile + "is generated");

		} else if (fileType.equalsIgnoreCase("PinMailer")) {

			logPass(recentProcessedFile + "is generated");

		} else if (fileType.equalsIgnoreCase("CAF")) {

			logPass(recentProcessedFile + "is generated");

		} else {
			logInfo("File type in not present");
		}

		return recentProcessedFile;
	}

	// OTI
	public String getOTIRecentProcessedFileName(Properties properties, String clientName, String clientCountry) {
		String recentProcessedFile = null;
		String midNumber = funcFetchCardNegativeSyncClientMidfromIFCSDB(properties, clientName, clientCountry);
		System.out.println("---- midNumber ---- " + midNumber);
		String queryTorecentProcessedFile = "select OUTPUT_FILE_PATH from INTERFACE_FILE_LOGS where INTERFACE_FILE_OID = (select interface_file_oid from interface_files where client_mid= '"
				+ midNumber + "' and interface_file_id='RM_G1_0199')  ORDER BY LAST_UPDATED_AT DESC";
		recentProcessedFile = connectDBAndGetValue(queryTorecentProcessedFile,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		System.out.println("Recent Processed file is " + recentProcessedFile);
		return recentProcessedFile;
	}

	public String getOTIFileName(String pathName) {
		Path path = Paths.get(pathName);
		String fileName = path.getFileName().toString();
		System.out.println("File Name is" + fileName);

		String processedFileName = fileName.split("\\.")[0];
		System.out.println("Processed file name is " + processedFileName);

		String newGeneratedFileName = processedFileName.split("(?<=\\D)(?=\\d)")[0];
		System.out.println("Country File Name is " + newGeneratedFileName);

		String sequenceNoAndClientmid = processedFileName.split("(?<=\\D)(?=\\d)")[1];
		System.out.println("Sequence Number and client mid is " + sequenceNoAndClientmid);

		int sequenceNo = Integer.parseInt(sequenceNoAndClientmid);
		int incrementedSequenceNo = sequenceNo + 1;
		System.out.println("Increamented Sequence Number is " + incrementedSequenceNo);
		// Convert Integer to String
		sequenceNoAndClientmid = Integer.toString(incrementedSequenceNo);
		newGeneratedFileName = newGeneratedFileName + sequenceNoAndClientmid + ".zip";
		System.out.println("Generated file Name is " + newGeneratedFileName);

		return newGeneratedFileName;
	}

	public String getOTIFolderName(String pathName, String clientCountry) {

		// String folderName = path.getParent().toString();
		String folderName = pathName.split(clientCountry)[0];
		System.out.println("Folder Name is" + folderName);
		return folderName;
	}

	/*
	 * This is to generate the file Name for the PVV file
	 * 
	 * @author Meenakshi Sundaram
	 * 
	 */
	public String getPVVFileName(String clientCountry) {

		clientCountry = clientCountry.split(" ")[1];
		clientCountry = getShortCountryName(clientCountry).toLowerCase();
		incomingFileName = clientCountry + "j09.txt";
		return incomingFileName;
	}

	public String cardGenerationWithCardEmbossing(String card) {
		String orderCardAndEmbossName = null;
		SHELLHomePage shellHomePage = new SHELLHomePage(driver, test);
		SHELLCardsPage shellCardsPage = new SHELLCardsPage(driver, test);
		// Go to Card List
		if (card.equals("order card")) {

			shellHomePage.goToCardMenuOrderCard();
			// Fill details of Order Card
			orderCardAndEmbossName = shellCardsPage.validateFillDetailsOfOrderCard();

		} else if (card.equals("Edit card")) {
			// In Progress
			// Go to Card List
			shellHomePage.goToCardMenuCardList();
			shellCardsPage.verifyCardListPage();

			// select all accounts and Active cards
			shellCardsPage.selectAllAccountsAndActiveCard();

			shellCardsPage.clickSearchButtonAndValidate();
			boolean isNoCardsPresent = shellCardsPage.waitForTextToAppear("No Cards found.", 30);
			if (!isNoCardsPresent) {

				shellCardsPage.clickEditCardFromCardListAndValidate();
				shellCardsPage.enterVRNInEditCard();
			}
		} else if (card.equals("Reissue card")) {

			// Go to Card List
			shellHomePage.goToCardMenuCardList();
			shellCardsPage.verifyCardListPage();

			// select all accounts and Active cards
			shellCardsPage.selectAllAccountsAndActiveCard();

			shellCardsPage.clickSearchButtonAndValidate();
			boolean isNoCardsPresent = shellCardsPage.waitForTextToAppear("No Cards found.", 30);
			if (!isNoCardsPresent) {
				shellCardsPage.clickEditCardFromCardListAndValidate();
				shellCardsPage.enterExpiryDateInEditCard("29/08/2022",
						"Please Confirm The Card Re-Issue. Note: The Card Number Remains The Same.");

			}

		} else if (card.equals("Replace card")) {
			String changeStatusTo = "Stolen";
			// Go to Card List
			shellHomePage.goToCardMenuCardList();
			shellCardsPage.verifyCardListPage();

			// select all accounts and Active cards
			shellCardsPage.selectAllAccountsAndActiveCard();

			shellCardsPage.clickSearchButtonAndValidate();

			boolean isNoCardsPresent = shellCardsPage.waitForTextToAppear("No Cards found.", 30);

			if (!isNoCardsPresent) {

				String selectedBalanceAllowedCard = shellCardsPage.clickBalanceAllowedCardListForAuthorityAt();

				if (!selectedBalanceAllowedCard.equals("")) {

					shellCardsPage.changeCardStatusAsNewStatus(changeStatusTo);

					// Click Save Button
					shellCardsPage.clickSaveButton();

					// Click Yes Button

					shellCardsPage.validateReplaceContentPopupYesOrNobutton("Yes");

					// Click Back to card list button
					shellCardsPage.clickBackToCardList();

					// select Card based on the search
					shellCardsPage.selectCardNewlyUpdatedAndViewCardValidate(changeStatusTo,
							selectedBalanceAllowedCard);
				}
			}

		}
		return orderCardAndEmbossName;

	}

	// Added by Ayub 17/05/2019
	public String getRecentProcessedFileNames(String clientName, String clientCountry, String fileType) {
		String recentProcessedFile = null, processedFileName = null, processedFileNameQuery = null;
		String createdFile = null;
		String midNumber = funcFetchLoadCardTransClientMidFromIFCSDB(configProp);
		System.out.println("---- midNumber ---- " + midNumber);
		String queryToRecProcessNumber = "select LAST_SEQUENCE_USED FROM INTERFACE_FILES WHERE INTERFACE_FILE_ID = '"
				+ fileType + "' and client_mid = " + "(select Client_mid from m_clients where name ='"
				+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountry) + "')";

		recentProcessedFile = connectDBAndGetValue(queryToRecProcessNumber,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));

		processedFileNameQuery = "select OUTPUT_FILE_NAME_TEMPLATE FROM INTERFACE_FILES WHERE INTERFACE_FILE_ID = '"
				+ fileType + "' \r\n" + "and client_mid = (select Client_mid from m_clients where name ='"
				+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountry) + "')";
		processedFileName = connectDBAndGetValue(processedFileNameQuery,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));

		if (fileType.contains("MailControl")) {
			/*
			 * int seq= Integer.parseInt(seqNumber)-1; System.out.println("Seq no::" +seq);
			 * String sequences=String.valueOf(seq);
			 */
			int count = recentProcessedFile.length();
			System.out.println(count);

			if (count == 1) {
				recentProcessedFile = "00000" + recentProcessedFile;
			} else if (count == 2) {
				recentProcessedFile = "0000" + recentProcessedFile;
			} else if (count == 3) {
				recentProcessedFile = "000" + recentProcessedFile;
			} else if (count == 4) {
				recentProcessedFile = "00" + recentProcessedFile;
			} else if (count == 5) {
				recentProcessedFile = "0" + recentProcessedFile;
			}
		}
		if (fileType.equalsIgnoreCase("RM_G1_0236_BPFUEL")) {
			createdFile = createFileNameFormatForCardEmboss(
					"CardEmbossNormalBPFuel" + "_" + clientCountry + "_" + recentProcessedFile, "zip");
		} else if (fileType.equalsIgnoreCase("RM_G1_0236_BPPLUS")) {
			createdFile = createFileNameFormatForCardEmboss(
					"CardEmbossNormalBPPlus" + "_" + clientCountry + "_" + recentProcessedFile, "zip");
		} else if (fileType.equalsIgnoreCase("RM_GSD_0021")) {
			createdFile = createFileNameFormatForCardEmboss(
					"GPCardSalesAggExtract" + "_" + clientCountry + "_" + recentProcessedFile, "zip");
		} else if (fileType.equalsIgnoreCase("RM_G1_0236_BPPLUS_BR")) {
			createdFile = createFileNameFormatForCardEmboss(
					"CardEmbossBulkReissBPPlus" + "_" + clientCountry + "_" + recentProcessedFile, "zip");
		} else if (fileType.equalsIgnoreCase("RM_G1_0237")) {
			createdFile = createFileNameFormatForCardEmboss(
					"PINMailer" + "_" + clientCountry + "_" + recentProcessedFile, "zip");
		} else if (fileType.equalsIgnoreCase("MerchantPostalMailControl")) {
			createdFile = createFileNameFormatForCardEmboss(
					"MerchantPostalMailControl" + "_" + midNumber + "_" + recentProcessedFile, "zip");
		} else if (fileType.equalsIgnoreCase("CustomerPostalMailControl")) {
			createdFile = createFileNameFormatForCardEmboss(
					"CustomerPostalMailControl" + "_" + midNumber + "_" + recentProcessedFile, "xml");
		} else {
			createdFile = createFileNameFormatForCardEmboss(
					processedFileName.split("_")[0] + "_" + clientCountry + "_" + recentProcessedFile, "zip");
			logInfo("File type in not present");
		}

		return createdFile;
	}

	// Added by Sasi 30/05/2019 --> EMAP_LoadCardTransactions_fileFormat
	public String createFileNameFormatforLoadCardTransaction(String fileName, Properties properties,
			String clientCountryFullName) {

		String formatedFileName = "";
		String clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		String ifcsDate = funcDate(configProp, clientCountryFullName);
		if (clientCountry.equals("MO")) {
			formatedFileName = "MC" + fileName + "_" + ifcsDate;
		} else if (clientCountry.equals("GU")) {
			formatedFileName = "GM" + fileName + "_" + ifcsDate;
		} else
			formatedFileName = clientCountry + fileName + "_" + ifcsDate;

		System.out.println("formatedFileName : " + formatedFileName);
		return formatedFileName;
	}

	// Added by Sasi 30/05/2019 --> EMAP_LoadCardTransactions_fileFormat
	public String funcLocationNo(Properties properties, String clientCountry) {
		Common common = new Common(driver, test);
		System.out.println("---- comes in funcLocationNo --- ");
		String locationNo = common.getLocationNoUsingProductCodeFromDB("SYNERGY DIESEL");

		return locationNo;
	}

	// added by rax 19/06/19
	public String getNameFromFaker(Properties properties, String expectedPropertyKey) {
		String fakerData = null;
		if (expectedPropertyKey.equals("DriverName")) {
			fakerData = fakerAPI().name().firstName() + " " + "D";
		} else if (expectedPropertyKey.equals("VehicleDescription")) {
			fakerData = fakerAPI().name().firstName() + " " + "V";
		} else if (expectedPropertyKey.equals("EmbossName")) {
			fakerData = fakerAPI().name().firstName() + " " + "E";
		}
		return fakerData;

	}

	// Added by Sasi 19/06/2019 --> EMAP_LoadCardTransactions_fileFormat
	public String funcProductDes(Properties properties, String clientCountry) {
		System.out.println("---- comes in funcProductDes --- ");
		String productDes = "";
		String CountryShortName = PropUtils.getPropValue(configProp, "clientCountry");
		// String CountryShortName = "HK";
		if (CountryShortName.equals("HK")) {
			// productDes = String.format("%-1$" + 30 + "s", "SYNERGY DIESEL");
			productDes = String.format("%-30s", "SYNERGY DIESEL");
		} else
			// productDes = String.format("%-1$" + 30 + "s", "ULSDiesel");
			productDes = String.format("%-30s", "ULSDiesel");

		return productDes;
	}

	/*
	 * Prakalpha 27/08/2019 Convert Date in Report Format(dot)
	 */
	public String getreportDateFormat(String processingDate) {
		String expectedformat = "";
		try {
			Date date = null;
			System.out.println("Processing Date::" + processingDate);
			SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			date = format1.parse(processingDate);
			String currentDate;
			SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
			currentDate = formatter.format(date);
			expectedformat = currentDate.replaceAll("/", ".");

		} catch (Exception e) {
			logFail(e.getMessage());
		}
		return expectedformat;
	}

	/*
	 * Prakalpha -->08/27/2019 get recently Processed filename with extension from
	 * IFCS DB
	 */
	public String getRecentProcessedReport(String fileName) {
		getDBDetailsFromProperties = PropUtils.getPropValue(configProp, "sqlODSServerName");
		String recentProcessedFile = null;
		String queryToReport = "";
		String generatedFile = "";
		queryToReport = "select file_name from stored_reports where file_name like '%" + fileName + "%'";
		recentProcessedFile = connectDBAndGetValue(queryToReport, getDBDetailsFromProperties);
		if (recentProcessedFile.equals(" ")) {
			logFail("No file found in the DB");
		} else {
			System.out.println("DBrecentProcessedFile::" + recentProcessedFile);
			String[] splittedFileName = recentProcessedFile.split("/");
			for (int i = 0; i <= splittedFileName.length - 1; i++) {
				System.out.println("splittedFileName::" + splittedFileName[i]);
			}
			generatedFile = splittedFileName[splittedFileName.length - 1];
		}
		return generatedFile;
	}

	/*
	 * Prakalpha get Recent Processed Reports
	 */
	public String getRecentProcessedReportFiles(String clientName, String clientCountry, String expectedFileName,
			String expectedNumber) {
		String createdFileFormat = "";
		String fileName = "";
		try {
			createdFileFormat = getCreatedFileFormattedName(configProp, clientName, clientCountry, expectedFileName,
					expectedNumber);
			System.out.println("createdFileFormat::" + createdFileFormat);
			fileName = getRecentProcessedReport(createdFileFormat);
			System.out.println("fileName::" + fileName);

		} catch (Exception e) {
			logFail(e.getMessage());
		}
		return fileName;
	}

	/*
	 * Prakalpha get Recent DayEnd and MonthEnd Processed Reports-10/24/2019
	 */
	public List<String> createClientReportFileFormatByDateAppend(String clientCountry, Properties reportPropertyFile,
			String dateValue) {

		CommonInterfacePage commonInterfacePage = new CommonInterfacePage(driver, test);
		List<String> fileCreatedFormat = new ArrayList<String>();
		String value = "";
		String fileName = "";
		Set<Object> keys = reportPropertyFile.keySet();

		System.out.println("Keys---->" + keys);
		List<String> notGeneratedReports = new ArrayList<String>();
		for (Object k : keys) {
			String key = String.valueOf(k);
			System.out.println("Key-->" + key);
			value = PropUtils.getPropValue(reportPropertyFile, key);
			String midNumber = commonInterfacePage.funcFetchLoadCardTransClientMidFromIFCSDB(configProp);
			value = "" + midNumber + "-" + value + " " + dateValue + "";
			fileName = commonInterfacePage.getRecentProcessedReport(value);
			System.out.println("fileName::" + fileName);

			if (fileName.equals("")) {

				notGeneratedReports.add(value);
				// System.out.println(fileName);
			} else {
				fileCreatedFormat.add(fileName);
			}
			if (notGeneratedReports.isEmpty()) {
				logPass("Given Reports are generated");
			} else {
				System.out.println("Not Generated Reports List are : " + notGeneratedReports);
				logFail(notGeneratedReports + " Given reports are not generated");
				logInfo("Some reports are generate based on adding the report in Application");
			}

		}
		return fileCreatedFormat;

	}

	/*
	 * Prakalpha -->08/27/2019 Pass the filename as a argument it will create a
	 * desired file format and get the created File Format
	 */
	public String getCreatedFileFormattedName(Properties properties, String clientName, String clientCountry,
			String fileName, String cusNo) {
		Common common = new Common(driver, test);
		String filenameformat = "";
		String fileNameSpecific = "";
		String midNumber = funcFetchLoadCardTransClientMidFromIFCSDB(properties);
		System.out.println("---- midNumber ---- " + midNumber);
		String dateIFCS = common.getCurrentIFCSDateFromDB(clientName + clientCountry);
		String dbProcessingDate = getreportDateFormat(dateIFCS);
		if (fileName.contains("Customer Statement")) {
			if (clientCountry.equals("SG")) {
				fileNameSpecific = "Customer Statement(Standard)";
			} else if (clientCountry.equals("HK")) {
				fileNameSpecific = "Customer Statement (Standard)";
			} else if (clientCountry.equals("GU") || clientCountry.equals("SP")) {
				fileNameSpecific = "Customer Statement";
			}
			filenameformat = "" + midNumber + "-" + fileNameSpecific + " " + dbProcessingDate + "-Account " + cusNo
					+ "";
			System.out.println("FileName is Created " + filenameformat);
		} else if (fileName.equals("Merchant Statement") || fileName.equals("Card Transaction Invoice Report")
				|| fileName.equals("Card Listing Report") || fileName.equals("CV Sales Transaction Report")
				|| fileName.equals("Fleet Card Transaction Report") || fileName.equals("Consolidated Invoice report")
				|| fileName.equals("Card Export List - CSV") || fileName.equals("Tax Invoice Detail")
				|| fileName.equals("Card Management Report") || fileName.equals("Fleet Control Report (82a)")
				|| fileName.equals("Merchant RCTI")) {

			filenameformat = "" + midNumber + "-" + fileName + " " + dbProcessingDate + "-Account " + cusNo + "";
			System.out.println("FileName Format is Created " + filenameformat);
		} else if (fileName.equals("Daily Reconciliation Report")) {
			filenameformat = "" + midNumber + "-" + fileName + " " + dbProcessingDate + "";
			System.out.println("FileName Format is Created " + filenameformat);
		} else {
			logFail("Mismatch in Files Creation Format,Please provide Correct Filename");
		}
		return filenameformat;
	}

	/*
	 * Prakalpha -->28/08/2019 get Complete reports Folder path in WINSCP using
	 * previous processing date
	 *
	 */public String getFolderPathUsingPreviousProcessingDate(String clientName, String clientCountry,
			String remotedir) {
		Common common = new Common(driver, test);
		String folderPath = "";
		String changedFolderDate;
		try {
			String processingDate = common.getCurrentIFCSDateFromDB(clientName + clientCountry);
			SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			Calendar cal = Calendar.getInstance();
			cal.setTime(format1.parse(processingDate));
			// manipulate date
			cal.add(Calendar.DATE, -1);
			Date currentDateMinusOne = cal.getTime();
			String currentDate;
			SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yyyy");
			currentDate = formatter.format(currentDateMinusOne);
			changedFolderDate = currentDate.replaceAll("-", "");
			remotedir = PropUtils.getPropValue(configProp, remotedir);
			folderPath = remotedir + changedFolderDate;
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return folderPath;
	}

	/*
	 * Prakalpha -->28/08/2019 get Complete reports Folder path in WINSCP using
	 * current system Date or previous system date
	 *
	 */
	public String getFolderPathUsingCurrentSystemDate(String clientName, String clientCountry, String remotedir) {
		String changedFolderDate = getDateInFormat(new Date(), "yyyyMMdd");
		SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yyyy");
		changedFolderDate = formatter.format(changedFolderDate);
		System.out.println("Current system date::" + changedFolderDate);

		/*
		 * Calendar cal = Calendar.getInstance(); cal.add(Calendar.DATE, -1); Date
		 * currentDateMinusOne = cal.getTime(); SimpleDateFormat formatter = new
		 * SimpleDateFormat("dd-MMM-yyyy"); String changedFolderDate =
		 * formatter.format(currentDateMinusOne);
		 */

		changedFolderDate = changedFolderDate.replaceAll("-", "");
		System.out.println("Date format:: " + changedFolderDate);
		remotedir = PropUtils.getPropValue(configProp, remotedir);
		String folderPath = remotedir + changedFolderDate;
		return folderPath;
	}

	public void getR3xmlFileAndValidate(String clientName, String clientCountry) {
		IFCSCommonPage ifcsCommonPage = new IFCSCommonPage(driver, test);
		String folderNames = PropUtils.getPropValue(r3ReportsPropertyFileConfigProp, "folderNames");
		String[] fileType = folderNames.split(",");
		String queryToRecProcessNumber, queryToRecFileName, expNodetag, tagNames, expvalues, recentProcessedFile,
				toRecFileName, r3FilePathLocal, createdFile;
		String[] eleTagNames, eleExpValues, fileName;
		for (String fileTypeValue : fileType) {
			queryToRecProcessNumber = "select LAST_SEQUENCE_USED FROM INTERFACE_FILES WHERE INTERFACE_FILE_ID = '"
					+ fileTypeValue + "' and client_mid = " + "(select Client_mid from m_clients where name ='"
					+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountry) + "')";
			recentProcessedFile = connectDBAndGetValue(queryToRecProcessNumber,
					PropUtils.getPropValue(configProp, "sqlODSServerName"));
			queryToRecFileName = "select OUTPUT_FILE_NAME_TEMPLATE FROM INTERFACE_FILES WHERE INTERFACE_FILE_ID = '"
					+ fileTypeValue + "' and client_mid = " + "(select Client_mid from m_clients where name ='"
					+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountry) + "')";
			toRecFileName = connectDBAndGetValue(queryToRecFileName,
					PropUtils.getPropValue(configProp, "sqlODSServerName"));
			logInfo(toRecFileName + recentProcessedFile);
			fileName = toRecFileName.split("_");
			createdFile = createFileNameFormatForCardEmboss(
					fileName[0] + "_" + clientCountry + "_" + recentProcessedFile, "zip");
			logInfo(createdFile);
			ifcsCommonPage.establishThePuttyConnection("unzip file to xml", "PUTTY_HOST", "PUTTY_USERNAME",
					"PUTTY_PASSWORD", "IFCS_OUTPUTFILE_FOLDER", createdFile);
			createdFile = createdFile.split("\\.")[0];
			logInfo(createdFile);
			r3FilePathLocal = System.getProperty("user.home") + System.getProperty("file.separator") + "Documents"
					+ System.getProperty("file.separator") + createdFile + ".xml";
			logInfo(r3FilePathLocal);
			expNodetag = PropUtils.getPropValue(r3ReportsPropertyFileConfigProp, fileName[0] + "_NodeTag");
			tagNames = PropUtils.getPropValue(r3ReportsPropertyFileConfigProp, fileName[0] + "_TagNames");
			eleTagNames = tagNames.split(",");
			expvalues = PropUtils.getPropValue(r3ReportsPropertyFileConfigProp, fileName[0] + "_Values");
			eleExpValues = expvalues.split(",");
			ifcsCommonPage.validateXMLFileAndValue(r3FilePathLocal, eleExpValues, expNodetag, eleTagNames);

		}
	}

	public void getCT13xmlFileAndValidate(String clientName, String clientCountry) {
		IFCSCommonPage ifcsCommonPage = new IFCSCommonPage(driver, test);

		String[] eletagname = { "core:ExternalDeliveryReference", "core:ExternalProductCode", "core:Quantity" };
		String locationMid, findLocationMid, totalQuantity, queryToRecProcessNumber, fileCT13PathLocal, Nodetag,
				recentProcessedFile, createdFile, Location_No, start_Date, end_Date, product_code, TotalQ;
		queryToRecProcessNumber = "select LAST_SEQUENCE_USED FROM INTERFACE_FILES WHERE INTERFACE_FILE_ID = 'RM_GSD_0083' and client_mid = "
				+ "(select Client_mid from m_clients where name ='"
				+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountry) + "')";
		recentProcessedFile = connectDBAndGetValue(queryToRecProcessNumber,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		createdFile = createFileNameFormatForCardEmboss(
				"ProductSalesVol_" + "_" + clientCountry + "_" + recentProcessedFile, "zip");
		logInfo(createdFile);
		ifcsCommonPage.establishThePuttyConnection("unzip file to xml", "PUTTY_HOST", "PUTTY_USERNAME",
				"PUTTY_PASSWORD", "IFCS_OUTPUTFILE_FOLDER", createdFile);
		createdFile = createdFile.split("\\.")[0];
		logInfo(createdFile);
		fileCT13PathLocal = System.getProperty("user.home") + System.getProperty("file.separator") + "Documents"
				+ System.getProperty("file.separator") + createdFile + ".xml";
		logInfo(fileCT13PathLocal);
		Nodetag = PropUtils.getPropValue(r3ReportsPropertyFileConfigProp, "ProductSalesVol_Node" + "_NodeTag");
		Location_No = PropUtils.getPropValue(r3ReportsPropertyFileConfigProp, "ProductSalesVol_Location");
		product_code = PropUtils.getPropValue(r3ReportsPropertyFileConfigProp, "ProductSalesVol_product_code");
		start_Date = PropUtils.getPropValue(r3ReportsPropertyFileConfigProp, "ProductSalesVol_start_Date");
		end_Date = PropUtils.getPropValue(r3ReportsPropertyFileConfigProp, "ProductSalesVol_end_Date");
		// To find Location_MID
		findLocationMid = "Select LOCATION_MID from M_LOCATIONS where (client_mid = '"
				+ "(select Client_mid from m_clients where name ='"
				+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountry) + "')' and LOCATION_NO ='"
				+ Location_No + "')";
		locationMid = connectDBAndGetValue(findLocationMid, PropUtils.getPropValue(configProp, "sqlODSServerName"));

		// To find Location_External_Code
		String findExternal_Location_Code = "Select EXTERNAL_CODE from M_LOCATIONS where (client_mid = '"
				+ "(select Client_mid from m_clients where name ='"
				+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountry) + "')' and LOCATION_NO ='"
				+ Location_No + "')";
		String external_Location_Code = connectDBAndGetValue(findExternal_Location_Code,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		// TO find Product_Oid
		// String ProductOid = "select PRODUCT_OID from PRODUCT_TRANSLATIONS where
		// EXTERNAL_CODE='100000188'";
		// Query for sum of quantity of location product
		TotalQ = "select sum(Quantity) from TRANSACTION_LINE_ITEMS where PRODUCT_CODE='" + product_code
				+ "' and TRANSACTION_OID in (select TRANSACTION_OID from TRANSACTIONS where PROCESSED_AT BETWEEN '"
				+ start_Date + " 12.00.00.000000000 AM' and '" + end_Date + " 12.00.00.000000000 AM' and LOCATION_MID='"
				+ locationMid + "')";
		totalQuantity = connectDBAndGetValue(TotalQ, PropUtils.getPropValue(configProp, "sqlODSServerName"));
		String[] eleExpValues = new String[] { external_Location_Code, product_code };
		ifcsCommonPage.validateXMLFileForOneValue(fileCT13PathLocal, eletagname, eleExpValues, Nodetag, totalQuantity);
	}

	public String getCustomerAmountFromPeriodRebates(String customerNumber) {

		String clientName, clientCountry;
		clientName = PropUtils.getPropValue(configProp, "clientName");
		clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		String customerAmount = "select CUSTOMER_AMOUNT from transactions where Posted_By ='Period Rebates' And customer_mid=(select customer_mid from m_customers where customer_no='"
				+ customerNumber + "' and client_mid=(select Client_mid from m_clients where name ='"
				+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountry)
				+ "')) order by LAST_UPDATED_AT Desc";
		String customerAmountFromTransactions = connectDBAndGetValue(customerAmount,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		System.out.println("Period Rebates Customer Amount from dB is" + customerAmountFromTransactions);
		return customerAmountFromTransactions;

	}

	public String getCustomerTotalTransactionsAmountFromDB(String customerNumber, String externalCode,
			String currentIFCSDate, String transactionMonthStartingDate) {
		String clientName, clientCountry;
		clientName = PropUtils.getPropValue(configProp, "clientName");

		clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		String rebateOriginalValue = "select sum(original_value) from TRANSACTION_LINE_ITEMS where product_code='"
				+ externalCode + "' " + " and TRANSACTION_OID in (select TRANSACTION_OID from TRANSACTIONS"
				+ " where PROCESSED_AT BETWEEN '" + currentIFCSDate + " 12.00.00.000000000 AM' and '"
				+ transactionMonthStartingDate + " 12.00.00.000000000 AM'"
				+ " and customer_mid=(select customer_mid from m_customers where customer_no='" + customerNumber
				+ "' and" + " client_mid=(select Client_mid from m_clients where name ='"
				+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountry) + "')))";

		String customerRebateTransactionValues = connectDBAndGetValue(rebateOriginalValue,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		System.out.println("Rebate Transaction amount from DB is " + customerRebateTransactionValues);

		return customerRebateTransactionValues;
	}

	public String getRateValueFromDB(String cusNumber, String rebateprofiletype, String totaltransactions) {
		String clientName, clientCountry;
		clientName = PropUtils.getPropValue(configProp, "clientName");

		clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		String rebateRate = "SELECT rv.rate FROM" + "rebates             r"
				+ "INNER JOIN rebate_profiles     rp ON rp.rebate_profile_oid = r.rebate_profile_oid"
				+ "INNER JOIN rebate_categories   rc ON r.rebate_category_oid = rc.rebate_category_oid"
				+ "INNER JOIN m_customers         mc ON rp.customer_mid = mc.customer_mid"
				+ "INNER JOIN m_clients           cl ON mc.client_mid = cl.client_mid"
				+ "INNER JOIN rebate_values       rv ON r.rebate_oid = rv.rebate_oid"
				+ "LEFT JOIN products            p ON r.product_oid = p.product_oid"
				+ "LEFT JOIN product_groups      pg ON r.product_group_oid = pg.product_group_oid"
				+ "INNER JOIN constants           pp ON rp.profile_category_cid = pp.constant_oid"
				+ "WHERE cl.processing_date BETWEEN r.effective_on AND r.expires_on " + "and rp.PROFILE_CATEGORY_CID='"
				+ rebateprofiletype + "' AND mc.customer_no='" + cusNumber + "' "
				+ "AND mc.client_mid=(select Client_mid from m_clients where name ='"
				+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountry) + "')"
				+ "and rc.rebate_type_cid='3502' and rp.rebate_profile_oid NOT IN"
				+ "(SELECT rebate_profile_oid FROM rebate_out_options WHERE customer_mid = mc.customer_mid)";

		/*
		 * "select rate from rebate_values where rebate_oid=(select Rebate_oid from rebates "
		 * +
		 * " where (rebate_profile_oid=(select rebate_profile_oid from rebate_profiles"
		 * +
		 * " where customer_mid=(select customer_mid from m_customers where customer_no='"
		 * + cusNumber + "' " +
		 * " and client_mid=(select Client_mid from m_clients where name ='" +
		 * PropUtils.getPropValue(configProp, clientName + "_" + clientCountry) + "'))"
		 * + " and  description='" + rebateProfileDescription + " ') and DESCRIPTION='"
		 * + rebateDescription + "'))"
		 */;
		String rebateRateValue = connectDBAndGetValue(rebateRate,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));

		System.out.println("Rate Value from DB is " + rebateRateValue);

		int rate = Integer.parseInt(rebateRateValue);

		int totalTransactionAmount = Integer.parseInt(totaltransactions);

		int rebatePercentage = -((rate * totalTransactionAmount) / 100);

		String rebateCustomerAmountCalculation = String.valueOf(rebatePercentage);

		return rebateCustomerAmountCalculation;
	}

	public String getTransactionMonthStartingDate(String beginDate, String currentIFCSDate) {

		try {
			DateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
			dateFormatter.parse(currentIFCSDate);
			Date newDate;
			Calendar cal = Calendar.getInstance();
			cal.setTime(dateFormatter.parse(currentIFCSDate));

			if (beginDate.equals("Past")) {
				cal.add(Calendar.MONTH, -1);

			} else if (beginDate.equals("current")) {
				newDate = cal.getTime();
			}

			newDate = cal.getTime();
			DateFormat df = new SimpleDateFormat("dd-MMM-yy");
			beginDate = df.format(newDate);

		} catch (Exception e) {
			logFail(e.getMessage());
		}
		return beginDate;

	}

	/*
	 * Create File format for the SAP* file "IFIP1775_20190828.DAT20190828094506"
	 * IFIS1775_20190828.DAT20190828094506 REPORT_FIN02_1775_20190828094506.csv
	 * REPORT_MERC_1775_20190828094506.csv
	 * 
	 * @author Meenakshi Sundaram
	 * 
	 */
	public String getGeneratedSAPFile(String clientCountry, String fileType) {

		String fileNameFormatForSAP = "";
		String countrySpecificCode = "";
		String dateFormat = "";
		String recentProcessedFile = null;
		String queryTogetFile = "";

		try {
			dateFormat = getDateInFormat(new Date(), "yyyyMMdd");

			/*
			 * Calendar cal = Calendar.getInstance(); cal.add(Calendar.DATE, -1); Date
			 * currentDateMinusOne = cal.getTime(); SimpleDateFormat formatter = new
			 * SimpleDateFormat("yyyyMMdd"); dateFormat =
			 * formatter.format(currentDateMinusOne) ;
			 */
			System.out.println("Date format:: " + dateFormat);
			if (clientCountry.equals("SG")) {
				countrySpecificCode = "1775";
			} else if (clientCountry.equals("HK")) {
				countrySpecificCode = "1142";
			} else if (clientCountry.equals("GM")) {
				countrySpecificCode = "3847";
			} else if (clientCountry.equals("SP")) {
				countrySpecificCode = "1442";
			}
			if (fileType.equalsIgnoreCase("IFIP") || fileType.equalsIgnoreCase("IFIS")) {
				fileNameFormatForSAP = fileType + countrySpecificCode + "_" + dateFormat + ".DAT" + dateFormat;
			} else if (fileType.equalsIgnoreCase("FIN02") || fileType.equalsIgnoreCase("MERC")) {
				fileNameFormatForSAP = "REPORT_" + fileType + countrySpecificCode + "_" + dateFormat;
			}
			System.out.println("fileformatSAP:: " + fileNameFormatForSAP);
			getDBDetailsFromProperties = PropUtils.getPropValue(configProp, "ieServerName");

			queryTogetFile = "select target_Filename from output_files where Target_filename like '%"
					+ fileNameFormatForSAP + "%'";
			recentProcessedFile = connectIEDBAndGetValue(queryTogetFile, getDBDetailsFromProperties);
			System.out.println("DBrecentProcessedFile::" + recentProcessedFile);
		} catch (Exception e) {
			logFail(e.getMessage());

		}
		return recentProcessedFile;
	}
	/*
	 * Raxsana To validate values present in expected Columns
	 */

	public void validateValuesIsPresentInExcel(String fileName, String sheetName, String[] columnHeaders,
			ArrayList<String> columnValues, int columnHeaderIndex) {
		HSSFSheet workSheet = null;
		HSSFRow row = null;
		HSSFWorkbook workBook = null;
		HSSFCell cell = null;

		String filePath = System.getProperty("user.home") + "\\Documents\\" + fileName;
		System.out.println("File Name :" + filePath);
		try {
			FileInputStream inputStream = new FileInputStream(new File(filePath));
			workBook = new HSSFWorkbook(inputStream);
			workSheet = workBook.getSheet(sheetName);
		} catch (Exception e) {

			e.printStackTrace();
		}
		String colvalues;

		int col_num = getColumnNoFromExcel(columnHeaders[0], workSheet, columnHeaderIndex);
		// System.out.println("Column_number::"+col_num);

		int rowStart = columnHeaderIndex + 1;
		// System.out.println("RowStarts::"+rowStart);
		int flag = 1;
		for (int rowIndex = rowStart; rowIndex <= workSheet.getLastRowNum(); rowIndex++) {
			row = workSheet.getRow(rowIndex);

			cell = row.getCell(col_num);
			if (cell.getStringCellValue().trim().equals(columnValues.get(0))) {

				if (columnValues.size() >= 2) {
					for (int i = 1; i < columnValues.size(); i++) {

						int col_numbers = getColumnNoFromExcel(columnHeaders[i], workSheet, columnHeaderIndex);
						System.out.println("col_numbers::" + col_numbers);
						cell = row.getCell(col_numbers);
						if (cell.getCellType() == 0) {
							double value = cell.getNumericCellValue();
							colvalues = Double.toString(value);
						} else {
							colvalues = cell.getStringCellValue();
						}
						if (colvalues.equals(columnValues.get(i))) {
							logPass("Expected CardNo " + columnValues.get(0) + " and Expected ReferenceNo "
									+ columnValues.get(i) + " Present in the Sheet");
							// break;
							flag++;
						}
					}
					if (flag == columnValues.size()) {
						break;
					}
				}
			}
			if (rowIndex == workSheet.getLastRowNum()) {
				logFail("Expected value is Not Present in Sheet");
			}
		}
	}

	/*
	 * Prakalpha Get Expected column numbers from excel
	 */

	public int getColumnNoFromExcel(String expectedHeader, HSSFSheet workSheet, int columnHeaderIndex) {
		HSSFRow row = null;
		row = workSheet.getRow(columnHeaderIndex);

		int col_num = -1;
		for (int i = 0; i < row.getLastCellNum(); i++) {
			if (row.getCell(i).getStringCellValue().trim().equals(expectedHeader)) {
				col_num = i;
				// System.out.println("col_num::" + col_num);
			}

		}
		return col_num;
	}

	// Sowmiya

	public void validateTextFromPDF(String fileName, String referenceNo, String textFromDB, int fromPage, int toPage) {
		Common common = new Common(driver, test);
		int count = 0;
		String textValueFromDB = "";

		String pdfFileFromDocument = System.getProperty("user.home") + "\\Documents\\" + fileName;
		System.out.println("PDF File from document " + pdfFileFromDocument);

		Map<String, String> customerTransactionDetails = common.getCustomerTransactions(referenceNo);

		textValueFromDB = customerTransactionDetails.get(textFromDB).toString();

		System.out.println("Value from DB is " + textValueFromDB);

		List<String> textFromPDF = new ArrayList<String>();
		textFromPDF = PdfUtils.getTextPageWise(pdfFileFromDocument, fromPage, toPage);
		int expectedReportPageSize = textFromPDF.size();
		for (int i = 0; i < expectedReportPageSize; i++) {
			String textFromEachPDFPage = textFromPDF.get(i);

			System.out.print("To get Text from each PDF page " + textFromEachPDFPage);
			if (!textFromEachPDFPage.isEmpty()) {
				if (textFromEachPDFPage.contains(textValueFromDB)) {
					logPass("Value is found in generated PDF Report Page");
					System.out.print("Value is found in generated PDF Report Page");
				} else {
					logInfo("Value is not found in  generated  PDF Report Page");
					System.out.print("Value is not found in  generated  PDF Report Page");
				}

			} else {
				count++;
				System.out.println("Count is " + count);
				if (count == expectedReportPageSize)
					logFail("Generated report Page  has no datas");
			}
		}
	}

	/*
	 * @author Meenakshi Sundaram TEST_VISIBLE_NONUTF_wrightex_BAFFSG20190916133819
	 * fileNameFormatForBAFF
	 */
	public String createFileNameFormatForBAFF(Properties properties, String clientCountry) {
		String fileNameFormatForBAFF = "";
		String recentProcessedFile = null;
		String queryTogetFile = "";
		String countryName = PropUtils.getPropValue(configProp, "clientCountry");
		String dateFormat = "";
		dateFormat = getDateInFormat(new Date(), "yyyyMMdd");
		fileNameFormatForBAFF = "TEST_VISIBLE_NONUTF_wrightex_BAFF" + countryName + dateFormat;

		getDBDetailsFromProperties = PropUtils.getPropValue(configProp, "ieServerName");

		queryTogetFile = "select target_Filename from output_files where Target_filename like '" + fileNameFormatForBAFF
				+ "%'";
		recentProcessedFile = connectIEDBAndGetValue(queryTogetFile, getDBDetailsFromProperties);
		System.out.println("DBrecentProcessedFile::" + recentProcessedFile);
		return fileNameFormatForBAFF;
	}

	public String funcFetchPaymentSeqNoFromIFCSDB(Properties properties, String clientCountry,
			String Incominginterfaceid) {
		int seqNo;
		getDBDetailsFromProperties = PropUtils.getPropValue(properties, "sqlODSServerName");

		String queryToGetSeqNo = "select LAST_SEQUENCE_NUMBER from interface_files_incoming\r\n"
				+ "where interface_file_incoming_id = '" + Incominginterfaceid + "'and\r\n"
				+ "client_mid = (select client_mid from m_clients where name like '" + clientCountry + "')";

		loadCardIFCSSeqNo = connectDBAndGetValue(queryToGetSeqNo, getDBDetailsFromProperties);

		seqNo = Integer.parseInt(loadCardIFCSSeqNo);
		seqNo = seqNo + 1;
		loadCardIFCSSeqNo = Integer.toString(seqNo);

		int count = loadCardIFCSSeqNo.length();

		if (count == 1) {
			loadCardIFCSSeqNo = "000" + loadCardIFCSSeqNo;
		} else if (count == 2) {
			loadCardIFCSSeqNo = "00" + loadCardIFCSSeqNo;
		} else if (count == 3) {
			loadCardIFCSSeqNo = "0" + loadCardIFCSSeqNo;
		}

		return loadCardIFCSSeqNo;
	}

	public String funcFetchPaymentCustomerNoFromIFCSDB(Properties properties, String clientCountry) {
		String prepaidPaymentIFCSCustomerNo;

		getDBDetailsFromProperties = PropUtils.getPropValue(properties, "sqlODSServerName");

		String queryToGetCustomerNo = "Select MC.customer_no from m_customers MC "
				+ "inner join accounts a on a.customer_mid = MC.customer_mid "
				+ "inner join card_programs cp on cp.card_program_oid=MC.card_program_oid "
				+ "where a.account_status_oid=1 and cp.card_program_oid = "
				+ "(select card_program_oid from card_programs where description != 'BP PrePay Cards' and client_mid = "
				+ "(select client_mid from m_clients where name = '" + clientCountry + "') and rownum=1)and rownum=1";
		System.out.println(queryToGetCustomerNo);
		prepaidPaymentIFCSCustomerNo = connectDBAndGetValue(queryToGetCustomerNo, getDBDetailsFromProperties);

		System.out.println("----- loadCardIFCSCustomerNo -------" + loadCardIFCSCustomerNo);

		return prepaidPaymentIFCSCustomerNo;
	}

	public String funcFetchCustomerNoFromIFCSDBForBP(Properties properties, String clientCountry) {
		String BPIFCSCustomerNo;
		String queryToGetCustomerNo = null;
		
		System.out.println("client country name"+clientCountry);
		
		getDBDetailsFromProperties = PropUtils.getPropValue(properties, "sqlODSServerName");
		if (clientCountry.equals("BP Australia Pty Ltd")) {
			queryToGetCustomerNo = "Select MC.customer_no from m_customers MC "
					+ "inner join accounts a on a.customer_mid = MC.customer_mid "
					+ "inner join card_programs cp on cp.card_program_oid=MC.card_program_oid "
					+ "where a.account_status_oid=1 and cp.card_program_oid = "
					+ "(select card_program_oid from card_programs where description != 'BP PrePay Cards' and client_mid = "
					+ "(select client_mid from m_clients where name = '" + clientCountry
					+ "') and rownum=1)and rownum=1";
			System.out.println(queryToGetCustomerNo);
		} else {
			queryToGetCustomerNo = "Select MC.customer_no from m_customers MC "
					+ "inner join accounts a on a.customer_mid = MC.customer_mid "
					+ "inner join card_programs cp on cp.card_program_oid=MC.card_program_oid "
					+ "where a.account_status_oid=21 and cp.card_program_oid = "
					+ "(select card_program_oid from card_programs where description != 'BP PrePay Cards' and client_mid = "
					+ "(select client_mid from m_clients where name = '" + clientCountry
					+ "') and rownum=1)and rownum=1";
			System.out.println(queryToGetCustomerNo);
		}

		BPIFCSCustomerNo = connectDBAndGetValue(queryToGetCustomerNo, getDBDetailsFromProperties);

		System.out.println("----- loadCardIFCSCustomerNo -------" + loadCardIFCSCustomerNo);

		return BPIFCSCustomerNo;
	}

	public String createFileNameFormatforCHVCAF(Properties properties, String Country) {
		result = fetchSequenceNumber(properties, "CHEV" + Country + "_PositiveCardChangesSeq");
		if (result.length() == 1) {
			sequenceNumberCaf = "000" + result;
		} else if (result.length() == 2) {
			sequenceNumberCaf = "00" + result;
		}

		else if (result.length() == 3) {
			sequenceNumberCaf = "0" + result;
		} else {
			sequenceNumberCaf = result;
		}
		if (Country.equalsIgnoreCase("SG")) {
			incomingFileName = "PVSI" + sequenceNumberCaf + ".XMT";
		} else if (Country.equalsIgnoreCase("PH")) {
			incomingFileName = "PVPI" + sequenceNumberCaf + ".XMT";
		} else {
			incomingFileName = "PV" + Country + sequenceNumberCaf + ".XMT";
		}

		return incomingFileName;
	}

	public String createFileNameFormatforMYCHVCAF(Properties properties, String Country) {
		result = fetchSequenceNumber(properties, "CHEV" + Country + "_PositiveCardChangesSeq");
		if (result.length() == 1) {
			sequenceNumberCaf = "000" + result;
		} else if (result.length() == 2) {
			sequenceNumberCaf = "00" + result;
		}

		else if (result.length() == 3) {
			sequenceNumberCaf = "0" + result;
		} else {
			sequenceNumberCaf = result;
		}
		if (Country.equalsIgnoreCase("SG")) {
			incomingFileName = "PVSI" + sequenceNumberCaf + ".XMT";
		} else if (Country.equalsIgnoreCase("PH")) {
			incomingFileName = "PVPI" + sequenceNumberCaf + ".XMT";
		} else {
			incomingFileName = "PV" + Country + sequenceNumberCaf + ".XMT";
		}

		return incomingFileName;
	}

	// Added by Nk
	public String dateFormatConversion(String currentProcessingDate, String neededDateFormat) {
		String processDate = currentProcessingDate.split("\\s+")[0];
		String resultDateFormat;
		try {
			resultDateFormat = dateFormatChange(processDate, neededDateFormat);
		} catch (ParseException e) {
			resultDateFormat = " ";
			// TODO Auto-generated catch block
			logFail("Failure: " + e.getMessage());
		}
		return resultDateFormat;
	}

	public String funcGetAccountHavingActualBalance() {
		String clientName = PropUtils.getPropValue(configProp, "clientName");
		String clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		String queryToGetAccountNo = "select account_no from accounts acc\r\n"
				+ "inner join calc_avail_bal_account_view av on acc.customer_mid=av.customer_mid \r\n"
				+ "where acc.account_status_oid in \r\n"
				+ "(select account_status_oid from account_status where description like '%Active%' or description like '%ACTIVE%') \r\n"
				+ "and acc.customer_mid in (select customer_mid from m_customers where client_mid = \r\n"
				+ "(select client_mid from m_clients where name = '"
				+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountry).replaceAll("\"", "") + "'))\r\n"
				+ "and acc.actual_balance = 0 and av.calculated_available_balance >=1000";
		return connectDBAndGetValue(queryToGetAccountNo, PropUtils.getPropValue(configProp, "sqlODSServerName"));
	}

	public Map<String, String> fetchLoadCardTransSeqNoandPrefix(Properties properties, String clientCountry,
			String Incominginterfaceid) {
		int seqNo;
		Map<String, String> result;
		getDBDetailsFromProperties = PropUtils.getPropValue(properties, "sqlODSServerName");

		String queryToGetSeqNo = "select input_file_name_prefix, LAST_SEQUENCE_NUMBER from interface_files_incoming\r\n"
				+ "where interface_file_incoming_id = '" + Incominginterfaceid + "'and\r\n"
				+ "client_mid = (select client_mid from m_clients where name like '" + clientCountry + "')";
		System.out.println(queryToGetSeqNo);
		result = connectDBAndGetDBEntireRowValues(queryToGetSeqNo, getDBDetailsFromProperties);
		System.out.println("test" + result);
		// loadCardIFCSSeqNo = connectDBAndGetValue(queryToGetSeqNo
		// ,getDBDetailsFromProperties);
		loadCardIFCSSeqNo = result.get("LAST_SEQUENCE_NUMBER");
		seqNo = Integer.parseInt(loadCardIFCSSeqNo);
		seqNo = seqNo + 1;
		loadCardIFCSSeqNo = Integer.toString(seqNo);

		int count = loadCardIFCSSeqNo.length();

		if (count == 1) {
			loadCardIFCSSeqNo = "000" + loadCardIFCSSeqNo;
		} else if (count == 2) {
			loadCardIFCSSeqNo = "00" + loadCardIFCSSeqNo;
		} else if (count == 3) {
			loadCardIFCSSeqNo = "0" + loadCardIFCSSeqNo;
		}
		result.put("lastSequenceNumber", loadCardIFCSSeqNo);
		return result;
	}

	public Map<String, String> getTransactionLineItem(Properties properties, String cardNumber, String clientName,
			String clientCountry) {
		// int seqNo;
		Map<String, String> result;
		String productCode, unitPrice, volume;
		String clientNameInProp = PropUtils.getPropValue(configProp, clientName + "_" + clientCountry);
		getDBDetailsFromProperties = PropUtils.getPropValue(properties, "sqlODSServerName");

		String queryToGetprdcode;
		if (clientName.equalsIgnoreCase("OTI")) {
			queryToGetprdcode = "select tp.external_code,pt.MINIMUM_UNIT_PRICE,pt.MINIMUM_VOLUME\r\n"
					+ "from cards c\r\n" + "inner join m_customers cus on cus.customer_mid = c.customer_mid\r\n"
					+ "inner join card_programs cp on cp.card_program_oid=c.card_program_oid\r\n"
					+ "inner join card_control_profiles ccp on ccp.card_control_profile_oid = c.card_control_profile_oid\r\n"
					+ "inner join card_controls cc on cc.card_control_profile_oid=ccp.card_control_profile_oid\r\n"
					+ "inner join product_restrictions pr on pr.product_restriction_oid=cc.product_restriction_oid\r\n"
					+ "inner join PRODUCT_RESTRICT_PRODS rp on rp.product_restriction_oid=pr.product_restriction_oid\r\n"
					+ "inner join PRODUCT_THRESHOLDS pt on pt.product_oid=rp.product_oid\r\n"
					+ "inner join PRODUCT_TRANSLATIONS tp on tp.product_oid=pt.product_oid "
					+ "inner join products p on p.product_oid = tp.product_oid "
					+ "where  c.card_no='"
					+ cardNumber + "' and p.is_fuel='Y' and pt.client_mid=(select client_mid from m_clients where name ='"
					+ clientNameInProp + "') and tp.external_code like ('%B%') and ROWNUM = 1";

		} else {
			queryToGetprdcode = "select tp.external_code,pt.MINIMUM_UNIT_PRICE,pt.MINIMUM_VOLUME\r\n"
					+ "from cards c\r\n" + "inner join m_customers cus on cus.customer_mid = c.customer_mid\r\n"
					+ "inner join card_programs cp on cp.card_program_oid=c.card_program_oid\r\n"
					+ "inner join card_control_profiles ccp on ccp.card_control_profile_oid = c.card_control_profile_oid\r\n"
					+ "inner join card_controls cc on cc.card_control_profile_oid=ccp.card_control_profile_oid\r\n"
					+ "inner join product_restrictions pr on pr.product_restriction_oid=cc.product_restriction_oid\r\n"
					+ "inner join PRODUCT_RESTRICT_PRODS rp on rp.product_restriction_oid=pr.product_restriction_oid\r\n"
					+ "inner join PRODUCT_THRESHOLDS pt on pt.product_oid=rp.product_oid\r\n"
					+ "inner join PRODUCT_TRANSLATIONS tp on tp.product_oid=pt.product_oid "
					+ "inner join products p on p.product_oid = tp.product_oid "
					+ "where  c.card_no='"
					+ cardNumber + "' and p.is_fuel='Y' and pt.client_mid=(select client_mid from m_clients where name ='"
					+ clientNameInProp + "') and ROWNUM = 1";
		}
		// System.out.println(queryToGetprdcode);
		result = connectDBAndGetDBEntireRowValues(queryToGetprdcode, getDBDetailsFromProperties);
		// System.out.println("test" + result);
		productCode = result.get("EXTERNAL_CODE");
		unitPrice = result.get("MINIMUM_UNIT_PRICE");
		volume = result.get("MINIMUM_VOLUME");
		result.put("productCode", productCode);
		// result.put("unitPrice", String.valueOf(Float.parseFloat(unitPrice))+"00");
		int volu = (int) Math.round(Float.parseFloat(volume));

		int unitprice = (int) Math.round(Float.parseFloat(unitPrice));
		System.out.println("inside uSp::" + unitprice);
		if (volu > 1) {
			result.put("volume", String.valueOf(volu) + "00");
		} else {
			result.put("volume", "10000");
		}
		if (unitprice > 1) {
			System.out.println("inside up11::" + String.valueOf(unitprice) + "00");
			result.put("unitPrice", String.valueOf(unitprice) + "00");
		} else {
			result.put("unitPrice", "10000");
		}

		return result;
	}

	public String getExternalSupplier(String clientName, String clientCountry) {
		String externalSupplier = null;
		IFCSCommonPage ifcsCommonPage = new IFCSCommonPage(driver, test);
		if (clientName.equalsIgnoreCase("BP") || clientName.equalsIgnoreCase("EMAP")) {
			externalSupplier = ifcsCommonPage.getShortClientName(clientName) + " " + clientCountry;
		} else if (clientName.equalsIgnoreCase("CHEVRON")) {
			externalSupplier = "CHEV" + "_" + clientCountry;
		} else if (clientName.equalsIgnoreCase("OTI")) {
			externalSupplier = "OTI PUMA BOTSWANA";
		} else if (clientName.equalsIgnoreCase("ZEnergy")) {
			externalSupplier = "ZE NZ";
		} else if (clientName.equalsIgnoreCase("SHELL") && clientCountry.equalsIgnoreCase("RU")) {
			externalSupplier = "036";
		} else if (clientName.equalsIgnoreCase("SHELL") && clientCountry.equalsIgnoreCase("MY")) {
			externalSupplier = "084";
		} else if (clientName.equalsIgnoreCase("SHELL") && clientCountry.equalsIgnoreCase("PH")) {
			externalSupplier = "086";
		} else {
			logFail("Unable to find externalSupplier");
		}

		return externalSupplier;
	}

	public String getfolderid(String clientName, String clientCountry) {
		String getfolderid = null;
		if (clientName.equalsIgnoreCase("BP") && clientCountry.equalsIgnoreCase("AU")) {
			getfolderid = "RM_G1_0200_FD";
		} else if (clientName.equalsIgnoreCase("BP") && clientCountry.equalsIgnoreCase("NZ")) {
			getfolderid = "RM_G1_0200_TX";
		} else if (clientName.equalsIgnoreCase("OTI")) {
			getfolderid = "RM_G1_0200_OTI";
		} else {
			getfolderid = "LoadCardTransactions";
		}

		return getfolderid;
	}

	public Map<String, String> fetchLoadCardTransSeqNoandPrefix(Properties properties, String clientName,
			String clientCountry, String Incominginterfaceid) {
		int seqNo;
		Map<String, String> result;
		String prefixName;
		String clientNameInProp = PropUtils.getPropValue(configProp, clientName + "_" + clientCountry);
		getDBDetailsFromProperties = PropUtils.getPropValue(properties, "sqlODSServerName");

		String queryToGetSeqNo = "select input_file_name_prefix, LAST_SEQUENCE_NUMBER, client_mid from interface_files_incoming\r\n"
				+ "where interface_file_incoming_id = '" + Incominginterfaceid + "'and\r\n"
				+ "client_mid = (select client_mid from m_clients where name like '" + clientNameInProp + "')";
		System.out.println(queryToGetSeqNo);
		result = connectDBAndGetDBEntireRowValues(queryToGetSeqNo, getDBDetailsFromProperties);
		System.out.println("test" + result);
		// loadCardIFCSSeqNo = connectDBAndGetValue(queryToGetSeqNo
		// ,getDBDetailsFromProperties);
		loadCardIFCSSeqNo = result.get("LAST_SEQUENCE_NUMBER");
		seqNo = Integer.parseInt(loadCardIFCSSeqNo);
		seqNo = seqNo + 1;
		loadCardIFCSSeqNo = Integer.toString(seqNo);

		int count = loadCardIFCSSeqNo.length();

		if (clientName.equalsIgnoreCase("BP")) {
			prefixName = result.get("INPUT_FILE_NAME_PREFIX") + "_" + clientCountry + "_";
			System.out.println(prefixName);
			if (count == 1) {
				loadCardIFCSSeqNo = "000" + loadCardIFCSSeqNo;
			} else if (count == 2) {
				loadCardIFCSSeqNo = "00" + loadCardIFCSSeqNo;
			} else if (count == 3) {
				loadCardIFCSSeqNo = "0" + loadCardIFCSSeqNo;
			}
			result.put("lastSequenceNumber", loadCardIFCSSeqNo);
		} else if (clientName.equalsIgnoreCase("OTI")) {
			prefixName = result.get("INPUT_FILE_NAME_PREFIX") + "_" + result.get("CLIENT_MID") + "_";
			System.out.println(prefixName);
			if (count == 1) {
				loadCardIFCSSeqNo = "000" + loadCardIFCSSeqNo;
			} else if (count == 2) {
				loadCardIFCSSeqNo = "00" + loadCardIFCSSeqNo;
			} else if (count == 3) {
				loadCardIFCSSeqNo = "0" + loadCardIFCSSeqNo;
			}
			result.put("lastSequenceNumber", loadCardIFCSSeqNo);
		} else if (clientName.equalsIgnoreCase("EMAP") && clientCountry.equalsIgnoreCase("HK")
				|| clientName.equalsIgnoreCase("EMAP") && clientCountry.equalsIgnoreCase("SG")) {
			prefixName = result.get("INPUT_FILE_NAME_PREFIX") + "_" + result.get("CLIENT_MID") + "_";
			System.out.println(prefixName);
			if (count == 1) {
				loadCardIFCSSeqNo = "00" + loadCardIFCSSeqNo;
			} else if (count == 2) {
				loadCardIFCSSeqNo = "0" + loadCardIFCSSeqNo;
			}
			result.put("lastSequenceNumber", loadCardIFCSSeqNo);
		} else {
			prefixName = result.get("INPUT_FILE_NAME_PREFIX") + "_" + result.get("CLIENT_MID") + "_";
			System.out.println(prefixName);
			if (count == 1) {
				loadCardIFCSSeqNo = "00000" + loadCardIFCSSeqNo;
			} else if (count == 2) {
				loadCardIFCSSeqNo = "0000" + loadCardIFCSSeqNo;
			} else if (count == 3) {
				loadCardIFCSSeqNo = "000" + loadCardIFCSSeqNo;
			} else if (count == 4) {
				loadCardIFCSSeqNo = "00" + loadCardIFCSSeqNo;
			} else if (count == 5) {
				loadCardIFCSSeqNo = "0" + loadCardIFCSSeqNo;
			}
			result.put("lastSequenceNumber", loadCardIFCSSeqNo);
		}
		result.put("prefixvalue", prefixName);

		return result;
	}

	public String getTransactionAmount(String reference) {
		String queryToGetOriginalAmount = "select original_value from transaction_line_items"
				+ " where transaction_oid=(select transaction_oid from transactions where reference='" + reference
				+ "')";
		return connectDBAndGetValue(queryToGetOriginalAmount, PropUtils.getPropValue(configProp, "sqlODSServerName"));
	}

}
