package com.framework.testcases.OLS.EMAP.Merchant;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.EMAP.EMAPHomePage;
import com.framework.pages.EMAP.EMAPSupportPage;
import com.framework.pages.OLS.common.LoginPage;
import com.framework.util.PropUtils;

public class ValidateLoginPage extends BaseTest {
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "Regression" })
	public void validateHomePage(@Optional("SP") String clientCountry, @Optional("EMAP") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  TST-SC-87-OLS Login Page - Validations",
				"Login to EMAP Merchant - Read Only User and check the login page");
		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		EMAPHomePage emapHomePage = new EMAPHomePage(driver, test);
		EMAPSupportPage supportPage = new EMAPSupportPage(driver, test);

		loginPage.validateLoginPageFooterLinks(clientName, "EMAP_URL");

		// Empty user name and password
		loginPage.loginWithUsernameAndPwd(" ", " ");
		loginPage.validateErrorMsgEmptyUsernameAndPassword();

		// // Valid user name and wrong password
		loginPage.loginWithUsernameAndPwd(
				PropUtils.getPropValue(configProp, "EMAP_UN_ReadOnly_Merchant_" + clientCountry), " ");
		loginPage.validateErrorMsgValidUsernameAndWrongPassword();

		// Invalid user name and valid password
		loginPage.loginWithUsernameAndPwd("test!2305457889", "EMAP_PWD_ReadOnly_Merchant_" + clientCountry);
		loginPage.validateErrorMsgValidUsernameAndWrongPassword();

		// LoginAndDisagree
		loginPage.loginAndDisagree("EMAP_UN_ReadOnly_Merchant_" + clientCountry,
				"EMAP_PWD_ReadOnly_Merchant_" + clientCountry);

		loginPage.Login("EMAP_URL", "EMAP_UN_ReadOnly_Merchant_" + clientCountry,
				"EMAP_PWD_ReadOnly_Merchant_" + clientCountry, clientName);

		if (!(clientCountry.equals("MO"))) {
			emapHomePage.clickContactUsAndValidatePage();
		} else {
			emapHomePage.clickContactUsMOAndValidatePage();
		}
		supportPage.checkMerchantClientLogo();
		supportPage.checkTheContactInfo(clientCountry);

		// Empty Query Type
		supportPage.enterCommentInContactUsField("Texting at comment field");
		supportPage.enterAContactName();
		supportPage.enterAContactPhone();
		supportPage.enterAContactEmail();
		supportPage.submitTheContactQuery();
		supportPage.validateTheErrorMessage("query");

		// Empty Comment
		supportPage.selectAQueryType();
		supportPage.enterCommentInContactUsField(" ");
		supportPage.enterAContactName();
		supportPage.enterAContactPhone();
		supportPage.enterAContactEmail();
		supportPage.submitTheContactQuery();
		supportPage.validateTheErrorMessage("comment");

		// Empty Contact name
		supportPage.selectAQueryType();
		supportPage.enterCommentInContactUsField("Texting at comment field");
		supportPage.enterAContactPhone();
		supportPage.clearContactName();
		supportPage.enterAContactEmail();
		supportPage.submitTheContactQuery();
		supportPage.validateTheErrorMessage("name");

		// Empty Phone
		supportPage.selectAQueryType();
		supportPage.enterCommentInContactUsField("Texting at comment field");
		supportPage.clearPhoneField();
		supportPage.enterAContactName();
		supportPage.enterAContactEmail();
		supportPage.submitTheContactQuery();
		supportPage.validateTheErrorMessage("phone");

		// // // Empty Email
		// supportPage.selectAQueryType();
		// supportPage.enterCommentInContactUsField("Texting at comment field");
		// supportPage.enterAContactName();
		// supportPage.enterAContactPhone();
		// supportPage.submitTheContactQuery();
		// supportPage.enterAEmptyContactEmail();
		// supportPage.validateTheErrorMessage("email");

		// Invalid Email
		supportPage.selectAQueryType();
		supportPage.enterCommentInContactUsField("Texting at comment field");
		supportPage.enterAContactName();
		supportPage.enterAContactPhone();
		supportPage.enterAInvalidEmail();
		supportPage.submitTheContactQuery();
		supportPage.validateTheErrorMessage("invalidemail");

		// Valid Entry
		supportPage.selectAQueryType();
		supportPage.enterCommentInContactUsField("Texting at comment field");
		supportPage.enterAContactName();
		supportPage.enterAContactPhone();
		supportPage.enterAContactEmail();
		supportPage.submitTheContactQuery();
		supportPage.validateTheConfirmationMessage();

		// Logout
		loginPage.Logout();
	}
}
