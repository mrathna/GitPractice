package com.framework.testcases.OLS.SHELL.Customer;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.ClientGroupPage;
import com.framework.pages.AJS.MaintainCustomerPage;
import com.framework.pages.AJS.common.Common;
import com.framework.pages.AJS.common.IFCSHomePage;
import com.framework.pages.AJS.common.IFCSLoginPage;
import com.framework.pages.OLS.HomePage;
import com.framework.pages.OLS.common.LoginPage;
import com.framework.pages.SHELL.SHELLCardsPage;
import com.framework.pages.SHELL.SHELLHomePage;

public class ValidateCardTestCases extends BaseTest {

	@Parameters({"clientCountry","clientName", "cardType"})
	@Test(groups = { "Regression" })
	public void validateBulkCardStatusChange(@Optional("AT") String clientCountry, @Optional("SHELL") String clientName, @Optional("APA") String cardType)  {
		
		test = extent.createTest(clientName+ ":" +clientCountry+"  12 Bulk Card Status Change", "Change Status for Bulk Card");

		//Creating Objects for the Pages
        LoginPage loginPage = new LoginPage(driver, test);
        HomePage homePage = new HomePage(driver, test);
        SHELLHomePage shellHomePage = new SHELLHomePage(driver, test);
        SHELLCardsPage shellCardsPage = new SHELLCardsPage(driver, test); 
        
        // Calling Login Functions And Validate
        if(cardType.equals("PC"))
        {
        	loginPage.Login("SHLPC_URL", "SHLPC_UN_Customer_Admin_" + clientCountry, "SHLPC_PWD_Customer_Admin_" + clientCountry, clientName);
        }
        else if(cardType.equals("APA"))
        {
        	loginPage.Login("SHLAPA_URL", "SHLAPA_UN_Customer_Admin_" + clientCountry, "SHLAPA_PWD_Customer_Admin_" + clientCountry, clientName);
        }
        	
		homePage.ValidateLogoutLink();
		homePage.ValidateHelpShellLink();
		homePage.ValidateWelcomeText(clientName+"#"+cardType);
		homePage.ValidateQuickLinks();
		shellHomePage.ValidateHeaderMenus("Admin");
		shellHomePage.ValidateFooterMenus();
		
		// Go to Bulk card
		shellHomePage.goToCardMenuBulkCardStatus();
		
		// Filter and Search
		
		shellCardsPage.selectCardStatusAllFilterOptions();
		
		// Click Search Button
		shellCardsPage.clickCardStatusSearchButton();
		
		boolean isReissueDataPresentorNot =  shellCardsPage.verifyBulkCardStatusListDataIsAvailable();
		
		if(isReissueDataPresentorNot)
		{
			shellCardsPage.printNoBulkCardDataPresent();
		} else {
		
		// Select Card to Change Card status 
		shellCardsPage.selectCardNumberToChangeStatus();
		
		// Change new status and save 
		shellCardsPage.changeCardStatusFromNewCardStatus();
		
		shellCardsPage.clickSaveButtonAndValidate();
		
		shellCardsPage.clickChangeCardPopupNoButton();
		}
		// logout
		loginPage.Logout();
		
	}
	
	@Parameters({"clientCountry","clientName", "cardType"})
	@Test(groups = { "Regression" })
	public void validateBulkCardStatusPage(@Optional("AT") String clientCountry, @Optional("SHELL") String clientName, @Optional("APA") String cardType)  {
		
		test = extent.createTest(clientName+ ":" +clientCountry+"  01 Verify details on Bulk Card status page", "Bulk Card status Page");

		//Creating Objects for the Pages
        LoginPage loginPage = new LoginPage(driver, test);
        HomePage homePage = new HomePage(driver, test);
        SHELLHomePage shellHomePage = new SHELLHomePage(driver, test);
        SHELLCardsPage shellCardsPage = new SHELLCardsPage(driver, test); 
        
        // Calling Login Functions And Validate
        if(cardType.equals("PC"))
        {
        	loginPage.Login("SHLPC_URL", "SHLPC_UN_Customer_Admin_" + clientCountry, "SHLPC_PWD_Customer_Admin_" + clientCountry, clientName);
        }
        else if(cardType.equals("APA"))
        {
        	loginPage.Login("SHLAPA_URL", "SHLAPA_UN_Customer_Admin_" + clientCountry, "SHLAPA_PWD_Customer_Admin_" + clientCountry, clientName);
        }
		homePage.ValidateLogoutLink();
		homePage.ValidateHelpShellLink();
		homePage.ValidateWelcomeText(clientName+"#"+cardType);
		homePage.ValidateQuickLinks();
		shellHomePage.ValidateHeaderMenus("Admin");
		shellHomePage.ValidateFooterMenus();
		
		// Go to Bulk card 
		
		shellHomePage.goToCardMenuBulkCardStatus();
		
		// Filter and Search
		shellCardsPage.selectCardStatusAllFilterOptions();
		
		// Click Search Button
		shellCardsPage.clickCardStatusSearchButton();
		boolean isReissueDataPresentorNot =  shellCardsPage.verifyBulkCardStatusListDataIsAvailable();
		
		if(isReissueDataPresentorNot)
		{
			shellCardsPage.printNoBulkCardDataPresent();
		} else {
//		shellCardsPage.clickExportButtonAndValidate();
		
		// Select Card to Change Card status 
		String cardNumber = shellCardsPage.selectCardNumberToChangeStatus();
		
		// Change new status and save 
		shellCardsPage.changeCardStatusFromNewCardStatus();
		shellCardsPage.clickSaveButtonAndValidate();
		
		shellCardsPage.clickChangeCardPopupNoButton();
		
		shellCardsPage.verifyCardNumberAndCardStatus(cardNumber);
		}
		// logout
		loginPage.Logout();
		
	}
	
	@Parameters({"clientCountry","clientName", "cardType"})
	@Test(groups = { "Regression" })
	public void validateCardListFromCardMenu(@Optional("AT") String clientCountry, @Optional("SHELL") String clientName, @Optional("APA") String cardType)  {
		
		test = extent.createTest(clientName+ ":" +clientCountry+"  01 Card List Sub Menu", "Validate Card list sub menu");

		//Creating Objects for the Pages
        LoginPage loginPage = new LoginPage(driver, test);
        HomePage homePage = new HomePage(driver, test);
        SHELLHomePage shellHomePage = new SHELLHomePage(driver, test);
        SHELLCardsPage shellCardsPage = new SHELLCardsPage(driver, test); 
        
        // Calling Login Functions And Validate
        if(cardType.equals("PC"))
        {
        	loginPage.Login("SHLPC_URL", "SHLPC_UN_Customer_Admin_" + clientCountry, "SHLPC_PWD_Customer_Admin_" + clientCountry, clientName);
        }
        else if(cardType.equals("APA"))
        {
        	loginPage.Login("SHLAPA_URL", "SHLAPA_UN_Customer_Admin_" + clientCountry, "SHLAPA_PWD_Customer_Admin_" + clientCountry, clientName);
        }
		homePage.ValidateLogoutLink();
		homePage.ValidateHelpShellLink();
		homePage.ValidateWelcomeText(clientName+"#"+cardType);
		homePage.ValidateQuickLinks();
		shellHomePage.ValidateHeaderMenus("Admin");
		shellHomePage.ValidateFooterMenus();
		
		// Go to Card List
		shellHomePage.goToCardMenuCardList();

		shellCardsPage.verifyCardListPage();
		
		shellCardsPage.selectAllAccountsAndActiveCard();
		shellCardsPage.clickSearchButtonAndValidate();
		
		shellCardsPage.cardNumberFilterSearch();
		
		// Click Search Button
		shellCardsPage.clickSearchButtonAndValidate();
		
		boolean isNoCardsPresent = shellCardsPage.waitForTextToAppear("No Cards found.", 30);
		
		if(!isNoCardsPresent)
		{			
		
		// Click Export Button
		//shellCardsPage.clickCarListExportButtonAndValidate();
		}
		// logout
		loginPage.Logout();
	}	
	
	@Parameters({"clientCountry","clientName", "cardType"})
	@Test(groups = { "Regression" })
	public void validateCardListForBalanceAllowed(@Optional("AT") String clientCountry, @Optional("SHELL") String clientName, @Optional("APA") String cardType)  {
		// Covered two test cases due to same scenario 
		test = extent.createTest(clientName+ ":" +clientCountry+"  02 Card List - Balance allowed/03 Card List - Balance not allowed", "Validate Card list for Balance Allowed");

		//Creating Objects for the Pages
        LoginPage loginPage = new LoginPage(driver, test);
        HomePage homePage = new HomePage(driver, test);
        SHELLHomePage shellHomePage = new SHELLHomePage(driver, test);
        SHELLCardsPage shellCardsPage = new SHELLCardsPage(driver, test); 
        
        // Calling Login Functions And Validate
        if(cardType.equals("PC"))
        {
        	loginPage.Login("SHLPC_URL", "SHLPC_UN_Customer_Admin_" + clientCountry, "SHLPC_PWD_Customer_Admin_" + clientCountry, clientName);
        }
        else if(cardType.equals("APA"))
        {
        	loginPage.Login("SHLAPA_URL", "SHLAPA_UN_Customer_Admin_" + clientCountry, "SHLAPA_PWD_Customer_Admin_" + clientCountry, clientName);
        }
		homePage.ValidateLogoutLink();
		homePage.ValidateHelpShellLink();
		homePage.ValidateWelcomeText(clientName+"#"+cardType);
		homePage.ValidateQuickLinks();
		shellHomePage.ValidateHeaderMenus("Admin");
		shellHomePage.ValidateFooterMenus();
		
		// Go to Card List
		shellHomePage.goToCardMenuCardList();

		shellCardsPage.verifyCardListPage();

		shellCardsPage.selectAllAccountsAndActiveCard();
		
		shellCardsPage.clickSearchButtonAndValidate();
		boolean isNoCardsPresent = shellCardsPage.waitForTextToAppear("No Cards found.", 30);
		if(!isNoCardsPresent)
		{			
		
		shellCardsPage.checkBalancedAllowedCardListForCardAccNo();
		}
		// logout
		loginPage.Logout();
		
		
	}
	
	@Parameters({"clientCountry","clientName", "cardType"})
	@Test(groups = { "Regression" })
	public void validateCardListForAuthorisedAtCardLevelAndAccount(@Optional("AT") String clientCountry, @Optional("SHELL") String clientName, @Optional("APA") String cardType)  {
		
		test = extent.createTest(clientName+ ":" +clientCountry+"  04 Card List - Authorised At  for Card Level/ 05 Card List - Authorised At  for Account", "Validate Card list for Authorised At Card");

		//Creating Objects for the Pages
        LoginPage loginPage = new LoginPage(driver, test);
        HomePage homePage = new HomePage(driver, test);
        SHELLHomePage shellHomePage = new SHELLHomePage(driver, test);
        SHELLCardsPage shellCardsPage = new SHELLCardsPage(driver, test); 
        
        // Calling Login Functions And Validate
        if(cardType.equals("PC"))
        {
        	loginPage.Login("SHLPC_URL", "SHLPC_UN_Customer_Admin_" + clientCountry, "SHLPC_PWD_Customer_Admin_" + clientCountry, clientName);
        }
        else if(cardType.equals("APA"))
        {
        	loginPage.Login("SHLAPA_URL", "SHLAPA_UN_Customer_Admin_" + clientCountry, "SHLAPA_PWD_Customer_Admin_" + clientCountry, clientName);
        }
		homePage.ValidateLogoutLink();
		homePage.ValidateHelpShellLink();
		homePage.ValidateWelcomeText(clientName+"#"+cardType);
		homePage.ValidateQuickLinks();
		shellHomePage.ValidateHeaderMenus("Admin");
		shellHomePage.ValidateFooterMenus();
		
		// Go to Card List
		shellHomePage.goToCardMenuCardList();

		shellCardsPage.verifyCardListPage();
		
		shellCardsPage.selectAllAccountsAndActiveCard();
		shellCardsPage.clickSearchButtonAndValidate();
		boolean isNoCardsPresent = shellCardsPage.waitForTextToAppear("No Cards found.", 30);
		if(!isNoCardsPresent)
		{	
		shellCardsPage.checkBalancedOrNotBalanceAllowedCardListForAuthorityAt();
		}
		// logout
		loginPage.Logout();
		
	}	
	
	@Parameters({"clientCountry","clientName", "cardType"})
	@Test(groups = { "Regression" })
	public void validateCardListForAuthorisedAtHierarchyParent(@Optional("AT") String clientCountry, @Optional("SHELL") String clientName, @Optional("APA") String cardType)  {
		// Covered two test cases its also Parent Account
		test = extent.createTest(clientName+ ":" +clientCountry+"  06 Card List - Authorised At  for Hierarchy Parent", "Validate Card list for Authorised At Account");

		//Creating Objects for the Pages
        LoginPage loginPage = new LoginPage(driver, test);
        HomePage homePage = new HomePage(driver, test);
        SHELLHomePage shellHomePage = new SHELLHomePage(driver, test);
        SHELLCardsPage shellCardsPage = new SHELLCardsPage(driver, test); 
        
        // Calling Login Functions And Validate
        if(cardType.equals("PC"))
        {
        	loginPage.Login("SHLPC_URL", "SHLPC_UN_Customer_Admin_" + clientCountry, "SHLPC_PWD_Customer_Admin_" + clientCountry, clientName);
        }
        else if(cardType.equals("APA"))
        {
        	loginPage.Login("SHLAPA_URL", "SHLAPA_UN_Customer_Admin_" + clientCountry, "SHLAPA_PWD_Customer_Admin_" + clientCountry, clientName);
        }
		homePage.ValidateLogoutLink();
		homePage.ValidateHelpShellLink();
		homePage.ValidateWelcomeText(clientName+"#"+cardType);
		homePage.ValidateQuickLinks();
		shellHomePage.ValidateHeaderMenus("Admin");
		shellHomePage.ValidateFooterMenus();
		
		// Go to Card List
		shellHomePage.goToCardMenuCardList();

		shellCardsPage.verifyCardListPage();
		
		shellCardsPage.clickSearchButtonAndValidate();
		boolean isNoCardsPresent = shellCardsPage.waitForTextToAppear("No Cards found.", 30);
		if(!isNoCardsPresent)
		{
		shellCardsPage.checkBalancedOrNotBalanceAllowedCardListForAuthorityAt();
		}
		// logout
		loginPage.Logout();
		
	}	
	 // Added by Ayub 20.06.2018
	
	@Parameters({"clientCountry","clientName", "cardType"})
	@Test(groups = { "Regression" })
	public void validateDownloadBulkCardOrderTemplate(@Optional("AT") String clientCountry, @Optional("SHELL") String clientName, @Optional("APA") String cardType)  {
		
		test = extent.createTest(clientName+ ":" +clientCountry+"  Download the Bulk Card Order template", "Bulk Card Order Template");

		//Creating Objects for the Pages
        LoginPage loginPage = new LoginPage(driver, test);
        HomePage homePage = new HomePage(driver, test);
        SHELLHomePage shellHomePage = new SHELLHomePage(driver, test);
        SHELLCardsPage shellCardsPage = new SHELLCardsPage(driver, test); 
        
        // Calling Login Functions And Validate
        if(cardType.equals("PC"))
        {
        	loginPage.Login("SHLPC_URL", "SHLPC_UN_Customer_Admin_" + clientCountry, "SHLPC_PWD_Customer_Admin_" + clientCountry, clientName);
        }
        else if(cardType.equals("APA"))
        {
        	loginPage.Login("SHLAPA_URL", "SHLAPA_UN_Customer_Admin_" + clientCountry, "SHLAPA_PWD_Customer_Admin_" + clientCountry, clientName);
        }
		homePage.ValidateLogoutLink();
		homePage.ValidateHelpShellLink();
		homePage.ValidateWelcomeText(clientName+"#"+cardType);
		homePage.ValidateQuickLinks();
		shellHomePage.ValidateHeaderMenus("Admin");
		shellHomePage.ValidateFooterMenus();
		
		// Go to Bulk card 
		
		shellHomePage.goToCardMenuBulkCardOrder();
		
		shellCardsPage.validateBulkCardOrderPage();		
		
		shellCardsPage.dowloadBulkCard();
		
		// logout
		loginPage.Logout();
		
	}
	
	 // Added by Ayub 20.06.2018
	
		@Parameters({"clientCountry","clientName", "cardType"})
		@Test(groups = { "Regression" })
		public void validateUploadBulkCard(@Optional("AT") String clientCountry, @Optional("SHELL") String clientName, @Optional("APA") String cardType)  {
			
			test = extent.createTest(clientName+ ":" +clientCountry+"  04 Upload Bulk Order", " Upload Bulk Card Order");

			//Creating Objects for the Pages
	        LoginPage loginPage = new LoginPage(driver, test);
	        HomePage homePage = new HomePage(driver, test);
	        SHELLHomePage shellHomePage = new SHELLHomePage(driver, test);
	        SHELLCardsPage shellCardsPage = new SHELLCardsPage(driver, test); 
	        
	        // Calling Login Functions And Validate
	        if(cardType.equals("PC"))
	        {
	        	loginPage.Login("SHLPC_URL", "SHLPC_UN_Customer_Admin_" + clientCountry, "SHLPC_PWD_Customer_Admin_" + clientCountry, clientName);
	        }
	        else if(cardType.equals("APA"))
	        {
	        	loginPage.Login("SHLAPA_URL", "SHLAPA_UN_Customer_Admin_" + clientCountry, "SHLAPA_PWD_Customer_Admin_" + clientCountry, clientName);
	        }
			homePage.ValidateLogoutLink();
			homePage.ValidateHelpShellLink();
			homePage.ValidateWelcomeText(clientName+"#"+cardType);
			homePage.ValidateQuickLinks();
			shellHomePage.ValidateHeaderMenus("Admin");
			shellHomePage.ValidateFooterMenus();
			
			// Go to Bulk card 			
			shellHomePage.goToCardMenuBulkCardOrder();
			
			// Validate the bulk card page
			shellCardsPage.validateBulkCardOrderPage();		
			
			// Upload the bulk order
			shellCardsPage.uploadBulkOrder("Bulk_Order");
			
			// logout
			loginPage.Logout();
			
		}
		
		@Parameters({"clientCountry","clientName", "cardType"})
		@Test(groups = { "Regression" })
		public void validateCardMenuCardListChildAccountInContext(@Optional("AT") String clientCountry, @Optional("SHELL") String clientName, @Optional("APA") String cardType)  {
			//*Covered three test cases its also Parent Account
			test = extent.createTest(clientName+ ":" +clientCountry+"  01 Card Menu-Child Account in context/01 Search Active cards/03 Verify No PIN field is on Edit screen", "Validate Card list for three scenarios");

			//Creating Objects for the Pages
	        LoginPage loginPage = new LoginPage(driver, test);
	        HomePage homePage = new HomePage(driver, test);
	        SHELLHomePage shellHomePage = new SHELLHomePage(driver, test);
	        SHELLCardsPage shellCardsPage = new SHELLCardsPage(driver, test); 
	        
	        // Calling Login Functions And Validate
	        if(cardType.equals("PC"))
	        {
	        	loginPage.Login("SHLPC_URL", "SHLPC_UN_Customer_Admin_" + clientCountry, "SHLPC_PWD_Customer_Admin_" + clientCountry, clientName);
	        }
	        else if(cardType.equals("APA"))
	        {
	        	loginPage.Login("SHLAPA_URL", "SHLAPA_UN_Customer_Admin_" + clientCountry, "SHLAPA_PWD_Customer_Admin_" + clientCountry, clientName);
	        }
			homePage.ValidateLogoutLink();
			homePage.ValidateHelpShellLink();
			homePage.ValidateWelcomeText(clientName+"#"+cardType);
			homePage.ValidateQuickLinks();
			shellHomePage.ValidateHeaderMenus("Admin");
			shellHomePage.ValidateFooterMenus();
			shellHomePage.selectAccountFromDropdownAndValidate();
			
			// Go to Card List
			shellHomePage.goToCardMenuCardList();
			shellCardsPage.verifyCardListPage();
			
			// Search filter for Card status
			// Continuing next Test cases 01 Search Active cards
			// select all accounts and Active cards
			shellCardsPage.selectAllAccountsAndActiveCard();
//			shellCardsPage.cardStatusFilterSearch();
			shellCardsPage.clickSearchButtonAndValidate();
			shellCardsPage.clickEditCardFromCardListAndValidate();
			// Validate PIN field disabled
			// Continuing next Test cases 03 Verify No PIN field is on Edit screen
			shellCardsPage.verifyPINFieldDisabled();
			
			// click logout
			loginPage.Logout();
			
			// Continuing next Test cases 02 Edit a card
//			shellCardsPage.clickEditCardFromCardListAndValidate();
		
		}	
		
		@Parameters({"clientCountry","clientName", "cardType"})
		@Test( groups = { "Regression" })
		public void validateCardListEditCard(@Optional("AT") String clientCountry, @Optional("SHELL") String clientName, @Optional("APA") String cardType)  {
			
			test = extent.createTest(clientName+ ":" +clientCountry+"  02 Edit a card", "Validate Card list Edit Card");

			//Creating Objects for the Pages
	        LoginPage loginPage = new LoginPage(driver, test);
	        HomePage homePage = new HomePage(driver, test);
	        SHELLHomePage shellHomePage = new SHELLHomePage(driver, test);
	        SHELLCardsPage shellCardsPage = new SHELLCardsPage(driver, test); 
	        
	        // Calling Login Functions And Validate
	        if(cardType.equals("PC"))
	        {
	        	loginPage.Login("SHLPC_URL", "SHLPC_UN_Customer_Admin_" + clientCountry, "SHLPC_PWD_Customer_Admin_" + clientCountry, clientName);
	        }
	        else if(cardType.equals("APA"))
	        {
	        	loginPage.Login("SHLAPA_URL", "SHLAPA_UN_Customer_Admin_" + clientCountry, "SHLAPA_PWD_Customer_Admin_" + clientCountry, clientName);
	        }
			homePage.ValidateLogoutLink();
			homePage.ValidateHelpShellLink();
			homePage.ValidateWelcomeText(clientName+"#"+cardType);
			homePage.ValidateQuickLinks();
			shellHomePage.ValidateHeaderMenus("Admin");
			shellHomePage.ValidateFooterMenus();
			
			// Go to Card List
			shellHomePage.goToCardMenuCardList();
			shellCardsPage.verifyCardListPage();
			
			// select all accounts and Active cards
			shellCardsPage.selectAllAccountsAndActiveCard();
			
			shellCardsPage.clickSearchButtonAndValidate();
			boolean isNoCardsPresent = shellCardsPage.waitForTextToAppear("No Cards found.", 10);
			
			if(!isNoCardsPresent)
			{
			// Continuing next Test cases 02 Edit a card
			shellCardsPage.clickEditCardFromCardListAndValidate();
			shellCardsPage.validateProtectedFieldsAndUpdateEditable();
		
			shellCardsPage.clickUpdateButton();

			// Validate The Edit Card 		
			shellCardsPage.validateTheEditCard();
			}
			// click logout
			loginPage.Logout();
		
		}
		
		//Added by Anton 21.06.2018
		
		@Parameters({"clientCountry","clientName", "cardType"})
		@Test( groups = { "Regression" })
		public void validateViewCardsPageDetailsFromCardList(@Optional("AT") String clientCountry, @Optional("SHELL") String clientName, @Optional("APA") String cardType)  {
			
			test = extent.createTest(clientName+ ":" +clientCountry+"  01 Verify details on View Card page", "Validate the details of View Card Page");

			//Creating Objects for the Pages
	        LoginPage loginPage = new LoginPage(driver, test);
	        HomePage homePage = new HomePage(driver, test);
	        SHELLHomePage shellHomePage = new SHELLHomePage(driver, test);
	        SHELLCardsPage shellCardsPage = new SHELLCardsPage(driver, test); 
	        
	        // Calling Login Functions And Validate
	        if(cardType.equals("PC"))
	        {
	        	loginPage.Login("SHLPC_URL", "SHLPC_UN_Customer_Admin_" + clientCountry, "SHLPC_PWD_Customer_Admin_" + clientCountry, clientName);
	        }
	        else if(cardType.equals("APA"))
	        {
	        	loginPage.Login("SHLAPA_URL", "SHLAPA_UN_Customer_Admin_" + clientCountry, "SHLAPA_PWD_Customer_Admin_" + clientCountry, clientName);
	        }
			homePage.ValidateLogoutLink();
			homePage.ValidateHelpShellLink();
			homePage.ValidateWelcomeText(clientName+"#"+cardType);
			homePage.ValidateQuickLinks();
			shellHomePage.ValidateHeaderMenus("Admin");
			shellHomePage.ValidateFooterMenus();
			
			// Go to Card List
			shellHomePage.goToCardMenuCardList();

			shellCardsPage.verifyCardListPage();
			
			shellCardsPage.selectAllAccountsAndActiveCard();
			
			shellCardsPage.clickSearchButtonAndValidate();
			
			boolean isNoCardsPresent = shellCardsPage.waitForTextToAppear("No Cards found.", 30);
			
			if(!isNoCardsPresent)
			{			
				shellCardsPage.clickViewCardGoToViewCardPageAndValidate(); 
			}
			
			// logout
			loginPage.Logout();
			
			
		}
		// Added by Ayub on 21.06.2018
 	
 	@Parameters({ "clientCountry", "clientName", "cardType"})
	@Test( groups = { "Regression" })
	public void validateChangeCardStatusRollUP(@Optional("AT") String clientCountry,
			@Optional("SHELL") String clientName, @Optional("APA") String cardType) {
		// Covered two test cases its also Parent Account
		test = extent.createTest(clientName+ ":" +clientCountry+"  03 Change Card Status page - Roll up", "Change Card Status Page-RollUp");

		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		HomePage homePage = new HomePage(driver, test);
		SHELLHomePage shellHomePage = new SHELLHomePage(driver, test);
		SHELLCardsPage shellCardsPage = new SHELLCardsPage(driver, test);
		Common common = new Common(driver, test);
		String currentDate = common.getCurrentIFCSDateFromDB(clientName+clientCountry);
		// Get the IFCS current date
		String ifcsCurrentDate = common.enterADateValueInStatusBeginDateField("Current", currentDate);
        String expiryDate = common.enterADateValueInStatusBeginDateField("WayFuture", currentDate);
		// Calling Login Functions And Validate
		 if(cardType.equals("PC"))
	        {
	        	loginPage.Login("SHLPC_URL", "SHLPC_UN_Customer_Admin_" + clientCountry, "SHLPC_PWD_Customer_Admin_" + clientCountry, clientName);
	        }
	        else if(cardType.equals("APA"))
	        {
	        	loginPage.Login("SHLAPA_URL", "SHLAPA_UN_Customer_Admin_" + clientCountry, "SHLAPA_PWD_Customer_Admin_" + clientCountry, clientName);
	        }
		homePage.ValidateLogoutLink();
		homePage.ValidateHelpShellLink();
		homePage.ValidateWelcomeText(clientName+"#"+cardType);
		homePage.ValidateQuickLinks();
		shellHomePage.ValidateHeaderMenus("Admin");
		shellHomePage.ValidateFooterMenus();

		// Go to Card List
		shellHomePage.goToCardMenuCardList();

		shellCardsPage.verifyCardListPage();
		// select all accounts and Active cards
		shellCardsPage.selectAllAccountsAndActiveCard();
		
		boolean isNoCardsPresent = shellCardsPage.waitForTextToAppear("No Cards found.", 30);
		
		if(!isNoCardsPresent)
		{	
		// Select the Change status page
		shellCardsPage.clickActiveCardAndSelectChangeStatus();
		// Validate expire date
		shellCardsPage.verifyChangeStatusPageAndValidateExpireDate(ifcsCurrentDate,expiryDate);
		// verify the Change status,Stolen and Balance of stolen card functionality
		shellCardsPage.checkCardStatusAndBalanceofStolencard();
		}
		loginPage.Logout();
	}

	// Added by Ayub on 21.06.2018

	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test( groups = { "Regression" })
	public void validateChangeCardStatusNoLongerRequired(@Optional("AT") String clientCountry,
			@Optional("SHELL") String clientName, @Optional("APA") String cardType) {
		// Covered two test cases its also Parent Account
		test = extent.createTest(clientName+ ":" +clientCountry+"  Change Card Status Page-NoLongerRequired", "Change Card Status Page-NoLongerRequired");

		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		HomePage homePage = new HomePage(driver, test);
		SHELLHomePage shellHomePage = new SHELLHomePage(driver, test);
		SHELLCardsPage shellCardsPage = new SHELLCardsPage(driver, test);

		// Calling Login Functions And Validate
		 if(cardType.equals("PC"))
	        {
	        	loginPage.Login("SHLPC_URL", "SHLPC_UN_Customer_Admin_" + clientCountry, "SHLPC_PWD_Customer_Admin_" + clientCountry, clientName);
	        }
	        else if(cardType.equals("APA"))
	        {
	        	loginPage.Login("SHLAPA_URL", "SHLAPA_UN_Customer_Admin_" + clientCountry, "SHLAPA_PWD_Customer_Admin_" + clientCountry, clientName);
	        }
		homePage.ValidateLogoutLink();
		homePage.ValidateHelpShellLink();
		homePage.ValidateWelcomeText(clientName+"#"+cardType);
		homePage.ValidateQuickLinks();
		shellHomePage.ValidateHeaderMenus("Admin");
		shellHomePage.ValidateFooterMenus();

		// Go to Card List
		shellHomePage.goToCardMenuCardList();
		shellCardsPage.verifyCardListPage();
		// select all accounts and Active cards
		shellCardsPage.selectAllAccountsAndActiveCard();
		
		boolean isNoCardsPresent = shellCardsPage.waitForTextToAppear("No Cards found.", 30);
		
		if(!isNoCardsPresent)
		{
		// Select the Change status page and Validate & verify the Balance of No Longer Required card
		shellCardsPage.checkCardStatusAndBalanceOfNoLongerRequired();
		}
		loginPage.Logout();
	}
	
	@Parameters({"clientCountry","clientName", "cardType"})
	@Test( groups = {"Regression"})
	public void validateEditCardChangeStatusAsReissue(@Optional("AT") String clientCountry, @Optional("SHELL") String clientName, @Optional("APA") String cardType)  {
		
		test = extent.createTest(clientName+ ":" +clientCountry+"  07 Edit Card status-StolenReissued", "Validate Edit Card Change Status");

		//Creating Objects for the Pages
        LoginPage loginPage = new LoginPage(driver, test);
        HomePage homePage = new HomePage(driver, test);
        SHELLHomePage shellHomePage = new SHELLHomePage(driver, test);
        SHELLCardsPage shellCardsPage = new SHELLCardsPage(driver, test); 
        
        // Calling Login Functions And Validate
        if(cardType.equals("PC"))
        {
        	loginPage.Login("SHLPC_URL", "SHLPC_UN_Customer_Admin_" + clientCountry, "SHLPC_PWD_Customer_Admin_" + clientCountry, clientName);
        }
        else if(cardType.equals("APA"))
        {
        	loginPage.Login("SHLAPA_URL", "SHLAPA_UN_Customer_Admin_" + clientCountry, "SHLAPA_PWD_Customer_Admin_" + clientCountry, clientName);
        }      
		homePage.ValidateLogoutLink();
		homePage.ValidateHelpShellLink();
		homePage.ValidateWelcomeText(clientName+"#"+cardType);
		homePage.ValidateQuickLinks();
		shellHomePage.ValidateHeaderMenus("Admin");
		shellHomePage.ValidateFooterMenus();
		
		
		// Go to Card List
		shellHomePage.goToCardMenuCardList();
		shellCardsPage.verifyCardListPage();
		
		shellCardsPage.selectAllAccountsAndActiveCard();
		
		shellCardsPage.clickSearchButtonAndValidate();
				
		boolean isNoCardsPresent = shellCardsPage.waitForTextToAppear("No Cards found.", 30);
		
		if(!isNoCardsPresent)
		{
		boolean cardHasAvailableBalance = shellCardsPage.goToEditCardPageAfterCheckAvailableBalance();
		
		if(cardHasAvailableBalance) {
		shellCardsPage.changeCardStatusAsNewStatusInEditCard("Lost");
		
		// Click Update Button
		shellCardsPage.clickUpdateButton();
		
		// Validate The Edit Card Reissued or Not		
		shellCardsPage.validateTheEditCardAndReIssue("Lost");
		}
		}
		// Click Logout
		loginPage.Logout();
	}
	
	@Parameters({"clientCountry","clientName", "cardType"})
	@Test( groups = { "Regression" })
	public void validateEditCardChangeStatusNotReissued(@Optional("AT") String clientCountry, @Optional("SHELL") String clientName, @Optional("APA") String cardType)  {
		
		test = extent.createTest(clientName+ ":" +clientCountry+"  09 Edit Card status-Stolen  Not Reissued", "Validate Edit Card Change Status");

		//Creating Objects for the Pages
        LoginPage loginPage = new LoginPage(driver, test);
        HomePage homePage = new HomePage(driver, test);
        SHELLHomePage shellHomePage = new SHELLHomePage(driver, test);
        SHELLCardsPage shellCardsPage = new SHELLCardsPage(driver, test); 
        
        // Calling Login Functions And Validate
        if(cardType.equals("PC"))
        {
        	loginPage.Login("SHLPC_URL", "SHLPC_UN_Customer_Admin_" + clientCountry, "SHLPC_PWD_Customer_Admin_" + clientCountry, clientName);
        }
        else if(cardType.equals("APA"))
        {
        	loginPage.Login("SHLAPA_URL", "SHLAPA_UN_Customer_Admin_" + clientCountry, "SHLAPA_PWD_Customer_Admin_" + clientCountry, clientName);
        }
		homePage.ValidateLogoutLink();
		homePage.ValidateHelpShellLink();
		homePage.ValidateWelcomeText(clientName+"#"+cardType);
		homePage.ValidateQuickLinks();
		shellHomePage.ValidateHeaderMenus("Admin");
		shellHomePage.ValidateFooterMenus();
		
		// Go to Card List
		shellHomePage.goToCardMenuCardList();
		shellCardsPage.verifyCardListPage();
		
		shellCardsPage.selectAllAccountsAndActiveCard();
		
		shellCardsPage.clickSearchButtonAndValidate();
				
		boolean isNoCardsPresent = shellCardsPage.waitForTextToAppear("No Cards found.", 30);
		
		if(!isNoCardsPresent)
		{
		boolean cardHasAvailableBalance = shellCardsPage.goToEditCardPageAfterCheckAvailableBalance();
		if(cardHasAvailableBalance) {
		shellCardsPage.changeCardStatusAsNewStatusInEditCard("Lost");
		
		// Click Update Button
		shellCardsPage.clickUpdateButton();
		
		// Validate The Edit Card Reissued or Not		
		shellCardsPage.validateTheEditCardAndNotReIssue("Lost");
		}
		}
		loginPage.Logout();
	}

	// Added by Ayub on 26.06.2018
	
	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test( groups = { "Regression" })
	public void validateChangeCardStatusFutureCardStatus(@Optional("AT") String clientCountry,
			@Optional("SHELL") String clientName, @Optional("APA") String cardType) {
		// Covered two test cases its also Parent Account
		test = extent.createTest(clientName+ ":" +clientCountry+"  Change Card Status FutureCardStatus", "Change Card Status FutureCardStatus");

		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		HomePage homePage = new HomePage(driver, test);
		SHELLHomePage shellHomePage = new SHELLHomePage(driver, test);
		SHELLCardsPage shellCardsPage = new SHELLCardsPage(driver, test);

		// Calling Login Functions And Validate
		 if(cardType.equals("PC"))
	     {
	       loginPage.Login("SHLPC_URL", "SHLPC_UN_Customer_Admin_" + clientCountry, "SHLPC_PWD_Customer_Admin_" + clientCountry, clientName);
	     }
	     else if(cardType.equals("APA"))
	     {
	        	loginPage.Login("SHLAPA_URL", "SHLAPA_UN_Customer_Admin_" + clientCountry, "SHLAPA_PWD_Customer_Admin_" + clientCountry, clientName);
	     }
		homePage.ValidateLogoutLink();
		homePage.ValidateHelpShellLink();
		homePage.ValidateWelcomeText(clientName+"#"+cardType);
		homePage.ValidateQuickLinks();
		shellHomePage.ValidateHeaderMenus("Admin");
		shellHomePage.ValidateFooterMenus();

		// Go to Card List
		shellHomePage.goToCardMenuCardList();
		shellCardsPage.verifyCardListPage();
		// select all accounts and Active cards
		shellCardsPage.selectAllAccountsAndActiveCard();

		boolean isNoCardsPresent = shellCardsPage.waitForTextToAppear("No Cards found.", 30);
	
		if(!isNoCardsPresent)
		{
		// Select the Change status page
		shellCardsPage.clickActiveCardAndSelectChangeStatus();
		shellCardsPage.changeStatusPageAndValidateFutureCardStatus();
		}
		loginPage.Logout();
	}
 
	// Added by Ayub on 22.06.2018
	
@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test( groups = { "Regression" })
	public void validateOrderCardPage(@Optional("AT") String clientCountry,
			@Optional("SHELL") String clientName, @Optional("APA") String cardType) {
		// Covered two test cases its also Parent Account
		test = extent.createTest(clientName+ ":" +clientCountry+"  Check 01 Order card Page", "01 Order card Page");

		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		HomePage homePage = new HomePage(driver, test);
		SHELLHomePage shellHomePage = new SHELLHomePage(driver, test);
		SHELLCardsPage shellCardsPage = new SHELLCardsPage(driver, test);

		// Calling Login Functions And Validate
		 if(cardType.equals("PC"))
	     {
	       loginPage.Login("SHLPC_URL", "SHLPC_UN_Customer_Admin_" + clientCountry, "SHLPC_PWD_Customer_Admin_" + clientCountry, clientName);
	     }
	     else if(cardType.equals("APA"))
	     {
	       loginPage.Login("SHLAPA_URL", "SHLAPA_UN_Customer_Admin_" + clientCountry, "SHLAPA_PWD_Customer_Admin_" + clientCountry, clientName);
	     } 
	     
		homePage.ValidateLogoutLink();
		homePage.ValidateHelpShellLink();
		homePage.ValidateWelcomeText(clientName+"#"+cardType);
		homePage.ValidateQuickLinks();
		shellHomePage.ValidateHeaderMenus("Admin");
		shellHomePage.ValidateFooterMenus();

		// Go to Card List
		shellHomePage.goToCardMenuOrderCard();
		// Need to get the order card number
		shellCardsPage.validatetheOrderCardPage();
		loginPage.Logout();
		
	}
	
	// Added by Ayub on 22.06.2018 
	
	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test( groups = { "Regression" })
	public void validateFillDetailsofOrderCardPage(@Optional("AT") String clientCountry,
			@Optional("SHELL") String clientName, @Optional("APA") String cardType) {
		// Covered two test cases its also Parent Account
		test = extent.createTest(clientName+ ":" +clientCountry+"  Check 02 Fill Details of Order CardPage", "OrderCardPage");

		String orderCardNumber; 
		//embossName;
		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		HomePage homePage = new HomePage(driver, test);
		SHELLHomePage shellHomePage = new SHELLHomePage(driver, test);
		SHELLCardsPage shellCardsPage = new SHELLCardsPage(driver, test);
		//OrderCardPage orderCardPage = new OrderCardPage(driver, test);

		// Calling Login Functions And Validate
		 if(cardType.equals("PC"))
	     {
	       loginPage.Login("SHLPC_URL", "SHLPC_UN_Customer_Admin_" + clientCountry, "SHLPC_PWD_Customer_Admin_" + clientCountry, clientName);
	     }
	     else if(cardType.equals("APA"))
	     {
	       loginPage.Login("SHLAPA_URL", "SHLAPA_UN_Customer_Admin_" + clientCountry, "SHLAPA_PWD_Customer_Admin_" + clientCountry, clientName);
	     }
		homePage.ValidateLogoutLink();
		homePage.ValidateHelpShellLink();
		homePage.ValidateWelcomeText(clientName+"#"+cardType);
		homePage.ValidateQuickLinks();
		shellHomePage.ValidateHeaderMenus("Admin");
		shellHomePage.ValidateFooterMenus();

		// Go to Card List
		String customerNumberFromOLS = shellHomePage.getCustomerNumber();
		shellHomePage.goToCardMenuOrderCard();
		//Fill details of Order Card
		orderCardNumber = shellCardsPage.validateFillDetailsOfOrderCard();

//		loginPage.Logout();		
		
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		Common common = new Common(driver, test);
		MaintainCustomerPage maintainCustomerPage = new MaintainCustomerPage(driver, test);
		
		IFCSloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, cardType);
		
		// selecting customer details
		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		common.chooseCustomerNoAndSearch(customerNumberFromOLS);
		
		
		maintainCustomerPage.chooseCardDetailsMenuCardMaintenanceAndEmbossHistory();
		common.chooseCardNoAndSearch(orderCardNumber);
		
		
		IFCSHomePage.exitIFCS();
		
	}
	
	@Parameters({"clientCountry","clientName", "cardType"})
	@Test( groups = { "Regression" })
	public void validateChangeCardStatusNonBillingNode(@Optional("AT") String clientCountry, @Optional("SHELL") String clientName, @Optional("APA") String cardType)  {
	
	test = extent.createTest(clientName+ ":" +clientCountry+"  06 Change Card status - Stolen - non Billing Node", "Validate Change Card Status to Stolen");

	String changeStatusTo = "Stolen";
	
	//Creating Objects for the Pages
    LoginPage loginPage = new LoginPage(driver, test);
    HomePage homePage = new HomePage(driver, test);
    SHELLHomePage shellHomePage = new SHELLHomePage(driver, test);
    SHELLCardsPage shellCardsPage = new SHELLCardsPage(driver, test); 
    
    // Calling Login Functions And Validate
    if(cardType.equals("PC"))
    {
    	loginPage.Login("SHLPC_URL", "SHLPC_UN_Customer_Admin_" + clientCountry, "SHLPC_PWD_Customer_Admin_" + clientCountry, clientName);
    }
    else if(cardType.equals("APA"))
    {
    	loginPage.Login("SHLAPA_URL", "SHLAPA_UN_Customer_Admin_" + clientCountry, "SHLAPA_PWD_Customer_Admin_" + clientCountry, clientName);
    }
	homePage.ValidateLogoutLink();
	homePage.ValidateHelpShellLink();
	homePage.ValidateWelcomeText(clientName+"#"+cardType);
	homePage.ValidateQuickLinks();
	shellHomePage.ValidateHeaderMenus("Admin");
	shellHomePage.ValidateFooterMenus();
	
	// Go to Card List
	shellHomePage.goToCardMenuCardList();
	shellCardsPage.verifyCardListPage();
	
	// select all accounts and Active cards
	shellCardsPage.selectAllAccountsAndActiveCard();
	
	shellCardsPage.clickSearchButtonAndValidate();
			
	boolean cardHasBalance = shellCardsPage.goToChangeStatusAfterCheckAvailableBalance();
	if(cardHasBalance) {
	// Active card should have Balance Amount
	shellCardsPage.changeCardStatusAsNewStatus(changeStatusTo);
	
	// Click Save Button
	shellCardsPage.clickSaveButton();
	
	// Click Yes Button 
	shellCardsPage.validateReplaceContentPopupYesOrNobutton("Yes");
	
	String selectedCardNo = shellCardsPage.clickNotBalancedAllowedCardListForAuthorityAt();
	
	if(!selectedCardNo.equals(""))
	{
		shellCardsPage.changeCardStatusAsNewStatus(changeStatusTo);
		
		// Click Save Button
		shellCardsPage.clickSaveButton();
		
		// Click No Button 	
		
		shellCardsPage.validateReplaceContentPopupYesOrNobutton("No");
		
		// Click Back to card list button
		shellCardsPage.clickBackToCardList();
		
		// select Card based on the search
		shellCardsPage.selectCardNewlyUpdatedAndViewCardValidate(changeStatusTo, selectedCardNo);
	}
	}
	// Click Logout
	loginPage.Logout();
	}
	
	 // Added by Ayub on 25.06.2016
	
	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test( groups = { "Regression" })
	public void validateDetailsonReplaceCardPage(@Optional("AT") String clientCountry,
			@Optional("SHELL") String clientName, @Optional("APA") String cardType) {
		// Covered two test cases its also Parent Account
		test = extent.createTest(clientName+ ":" +clientCountry+"  Details on Replace CardPage", "Checking DetailsonRepaceCardPage");

		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		HomePage homePage = new HomePage(driver, test);
		SHELLHomePage shellHomePage = new SHELLHomePage(driver, test);
		SHELLCardsPage shellCardsPage = new SHELLCardsPage(driver, test);

		// Calling Login Functions And Validate
		 if(cardType.equals("PC"))
	     {
	       loginPage.Login("SHLPC_URL", "SHLPC_UN_Customer_Admin_" + clientCountry, "SHLPC_PWD_Customer_Admin_" + clientCountry, clientName);
	     }
	     else if(cardType.equals("APA"))
	     {
	       loginPage.Login("SHLAPA_URL", "SHLAPA_UN_Customer_Admin_" + clientCountry, "SHLAPA_PWD_Customer_Admin_" + clientCountry, clientName);
	     }
		homePage.ValidateLogoutLink();
		homePage.ValidateHelpShellLink();
		homePage.ValidateWelcomeText(clientName+"#"+cardType);
		homePage.ValidateQuickLinks();
		shellHomePage.ValidateHeaderMenus("Admin");
		shellHomePage.ValidateFooterMenus();

		// Go to Card List
		shellHomePage.goToCardMenuCardList();

		shellCardsPage.verifyCardListPage();
		// select all accounts and Active cards
		shellCardsPage.selectAllAccountsAndActiveCard();
		
		boolean isNoCardsPresent = shellCardsPage.waitForTextToAppear("No Cards found.", 30);
		
		if(!isNoCardsPresent)
		{
		//Select the Replace Card page
		shellCardsPage.clickReplaceCardAndGoToReplaceCardPage();
		// Validate the Replace card Page
		shellCardsPage.validateReplaceCardPage();
		}
		loginPage.Logout();
	}

	@Parameters({"clientCountry","clientName", "cardType"})
	@Test( groups = { "Regression" })
	public void validateChangeCardStatusAsLostBalanceAllowed(@Optional("AT") String clientCountry, @Optional("SHELL") String clientName, @Optional("APA") String cardType)  {
	
	test = extent.createTest(clientName+ ":" +clientCountry+"  13 Change Card status - Lost - Not Bal Allowed - No Replace", "Validate Change Card Status to Lost with Not Balance Allowed");
    String changeStatusTo = "Lost";
	//Creating Objects for the Pages
    LoginPage loginPage = new LoginPage(driver, test);
    HomePage homePage = new HomePage(driver, test);
    SHELLHomePage shellHomePage = new SHELLHomePage(driver, test);
    SHELLCardsPage shellCardsPage = new SHELLCardsPage(driver, test); 
    
    // Calling Login Functions And Validate
    if(cardType.equals("PC"))
    {
    	loginPage.Login("SHLPC_URL", "SHLPC_UN_Customer_Admin_" + clientCountry, "SHLPC_PWD_Customer_Admin_" + clientCountry, clientName);
    }
    else if(cardType.equals("APA"))
    {
    	loginPage.Login("SHLAPA_URL", "SHLAPA_UN_Customer_Admin_" + clientCountry, "SHLAPA_PWD_Customer_Admin_" + clientCountry, clientName);
    }
	homePage.ValidateLogoutLink();
	homePage.ValidateHelpShellLink();
	homePage.ValidateWelcomeText(clientName+"#"+cardType);
	homePage.ValidateQuickLinks();
	shellHomePage.ValidateHeaderMenus("Admin");
	shellHomePage.ValidateFooterMenus();
	
	// Go to Card List
	shellHomePage.goToCardMenuCardList();
	shellCardsPage.verifyCardListPage();
	
	// select all accounts and Active cards
	shellCardsPage.selectAllAccountsAndActiveCard();
	
	shellCardsPage.clickSearchButtonAndValidate();
	
	boolean isNoCardsPresent = shellCardsPage.waitForTextToAppear("No Cards found.", 30);
	
	if(!isNoCardsPresent)
	{
			
	String selectedCardNo = shellCardsPage.clickNotBalancedAllowedCardListForAuthorityAt();
	
	if(!selectedCardNo.equals(""))
	{
	shellCardsPage.changeCardStatusAsNewStatus(changeStatusTo);
	
	// Click Save Button
	shellCardsPage.clickSaveButton();
		
	// Click Yes Button 
	shellCardsPage.validateReplaceContentPopupYesOrNobutton("No");
	// Click Back to card list button
	shellCardsPage.clickBackToCardList();
	
	// select Card based on the search
	shellCardsPage.selectCardNewlyUpdatedAndViewCardValidate(changeStatusTo, selectedCardNo);
	}
	}
	loginPage.Logout();
	
	}
	
	@Parameters({"clientCountry","clientName", "cardType"})
	@Test( groups = { "Regression" })
	public void validateChangeCardStatusAsDamagedNotBalanceAllowedReplace(@Optional("AT") String clientCountry, @Optional("SHELL") String clientName, @Optional("APA") String cardType)  {
	
	test = extent.createTest(clientName+ ":" +clientCountry+"  14 Change Card status-Damaged-Not Bal Allowed-Replace", "Validate Change Card Status to Damaged with Not Balance Allowed");

	String changeStatusTo = "Damaged";
	//Creating Objects for the Pages
    LoginPage loginPage = new LoginPage(driver, test);
    HomePage homePage = new HomePage(driver, test);
    SHELLHomePage shellHomePage = new SHELLHomePage(driver, test);
    SHELLCardsPage shellCardsPage = new SHELLCardsPage(driver, test); 
    
    // Calling Login Functions And Validate
    if(cardType.equals("PC"))
    {
    	loginPage.Login("SHLPC_URL", "SHLPC_UN_Customer_Admin_" + clientCountry, "SHLPC_PWD_Customer_Admin_" + clientCountry, clientName);
    }
    else if(cardType.equals("APA"))
    {
    	loginPage.Login("SHLAPA_URL", "SHLAPA_UN_Customer_Admin_" + clientCountry, "SHLAPA_PWD_Customer_Admin_" + clientCountry, clientName);
    }
	homePage.ValidateLogoutLink();
	homePage.ValidateHelpShellLink();
	homePage.ValidateWelcomeText(clientName+"#"+cardType);
	homePage.ValidateQuickLinks();
	shellHomePage.ValidateHeaderMenus("Admin");
	shellHomePage.ValidateFooterMenus();
	
	// Go to Card List
	shellHomePage.goToCardMenuCardList();
	shellCardsPage.verifyCardListPage();
	
	// select all accounts and Active cards
	shellCardsPage.selectAllAccountsAndActiveCard();
	
	shellCardsPage.clickSearchButtonAndValidate();
	
    boolean isNoCardsPresent = shellCardsPage.waitForTextToAppear("No Cards found.", 30);
	
	if(!isNoCardsPresent)
	{
			
	String selectedCardNo = shellCardsPage.clickNotBalancedAllowedCardListForAuthorityAt();
	
	if(!selectedCardNo.equals(""))
	{
		shellCardsPage.changeCardStatusAsNewStatus(changeStatusTo);
		
		// Click Save Button
		shellCardsPage.clickSaveButton();
				
		// Click Yes Button 
		shellCardsPage.validateReplaceContentPopupYesOrNobutton("Yes");	
		
		// Click Back to card list button
		shellCardsPage.clickBackToCardList();
		
		// select Card based on the search
		shellCardsPage.selectCardNewlyUpdatedAndViewCardValidate(changeStatusTo, selectedCardNo);
		}
		}
		loginPage.Logout();
		
	}
	
	@Parameters({"clientCountry","clientName", "cardType"})
	@Test( groups = { "Regression" })
	public void validateChangeCardStatusAsDamagedNotBalanceAllowedNoReplace(@Optional("AT") String clientCountry, @Optional("SHELL") String clientName, @Optional("APA") String cardType)  {
	
	test = extent.createTest(clientName+ ":" +clientCountry+"  15 Change Card status-Damaged-Not Bal Allowed-No Replace", "Validate Change Card Status to Damaged with Not Balance Allowed no replace");

	String changeStatusTo = "Damaged";
	//Creating Objects for the Pages
    LoginPage loginPage = new LoginPage(driver, test);
    HomePage homePage = new HomePage(driver, test);
    SHELLHomePage shellHomePage = new SHELLHomePage(driver, test);
    SHELLCardsPage shellCardsPage = new SHELLCardsPage(driver, test); 
    
    // Calling Login Functions And Validate
    if(cardType.equals("PC"))
    {
    	loginPage.Login("SHLPC_URL", "SHLPC_UN_Customer_Admin_" + clientCountry, "SHLPC_PWD_Customer_Admin_" + clientCountry, clientName);
    }
    else if(cardType.equals("APA"))
    {
    	loginPage.Login("SHLAPA_URL", "SHLAPA_UN_Customer_Admin_" + clientCountry, "SHLAPA_PWD_Customer_Admin_" + clientCountry, clientName);
    }
	homePage.ValidateLogoutLink();
	homePage.ValidateHelpShellLink();
	homePage.ValidateWelcomeText(clientName+"#"+cardType);
	homePage.ValidateQuickLinks();
	shellHomePage.ValidateHeaderMenus("Admin");
	shellHomePage.ValidateFooterMenus();
	
	// Go to Card List
	shellHomePage.goToCardMenuCardList();
	shellCardsPage.verifyCardListPage();
	
	// select all accounts and Active cards
	shellCardsPage.selectAllAccountsAndActiveCard();
	
	shellCardsPage.clickSearchButtonAndValidate();
	
	boolean isNoCardsPresent = shellCardsPage.waitForTextToAppear("No Cards found.", 30);
	
	if(!isNoCardsPresent)
	{
			
	String selectedCardNo = shellCardsPage.clickNotBalancedAllowedCardListForAuthorityAt();
	if(!selectedCardNo.equals(""))
	{
	shellCardsPage.changeCardStatusAsNewStatus(changeStatusTo);
	
	// Click Save Button
	shellCardsPage.clickSaveButton();
				
	// Click No Button 
	shellCardsPage.validateReplaceContentPopupYesOrNobutton("No");	
	
	// Click Back to card list button
	shellCardsPage.clickBackToCardList();
	
	// select Card based on the search
	shellCardsPage.selectCardNewlyUpdatedAndViewCardValidate(changeStatusTo, selectedCardNo);
	}
	}
	loginPage.Logout();
	
	}
	
	@Parameters({"clientCountry","clientName", "cardType"})
	@Test( groups = { "Regression" })
	public void validateChangeCardStatusAsDamagedBalanceAllowedWithReplace(@Optional("AT") String clientCountry, @Optional("SHELL") String clientName, @Optional("APA") String cardType)  {
	
	test = extent.createTest(clientName+ ":" +clientCountry+"  16 Change Card status-Damaged-Bal Allowed-Replace", "Validate Change Card Status to Damaged with Balance Allowed Replace");

	String changeStatusTo = "Damaged";
	//Creating Objects for the Pages
    LoginPage loginPage = new LoginPage(driver, test);
    HomePage homePage = new HomePage(driver, test);
    SHELLHomePage shellHomePage = new SHELLHomePage(driver, test);
    SHELLCardsPage shellCardsPage = new SHELLCardsPage(driver, test); 
    
    // Calling Login Functions And Validate
    if(cardType.equals("PC"))
    {
    	loginPage.Login("SHLPC_URL", "SHLPC_UN_Customer_Admin_" + clientCountry, "SHLPC_PWD_Customer_Admin_" + clientCountry, clientName);
    }
    else if(cardType.equals("APA"))
    {
    	loginPage.Login("SHLAPA_URL", "SHLAPA_UN_Customer_Admin_" + clientCountry, "SHLAPA_PWD_Customer_Admin_" + clientCountry, clientName);
    }
	homePage.ValidateLogoutLink();
	homePage.ValidateHelpShellLink();
	homePage.ValidateWelcomeText(clientName+"#"+cardType);
	homePage.ValidateQuickLinks();
	shellHomePage.ValidateHeaderMenus("Admin");
	shellHomePage.ValidateFooterMenus();
	
	// Go to Card List
	shellHomePage.goToCardMenuCardList();
	shellCardsPage.verifyCardListPage();
	
	// select all accounts and Active cards
	shellCardsPage.selectAllAccountsAndActiveCard();
	
	shellCardsPage.clickSearchButtonAndValidate();
	
	boolean isNoCardsPresent = shellCardsPage.waitForTextToAppear("No Cards found.", 30);
	
	if(!isNoCardsPresent)
	{
			
	String selectedBalanceAllowedCard = shellCardsPage.clickBalanceAllowedCardListForAuthorityAt();
	
	if(!selectedBalanceAllowedCard.equals(""))
	{
	shellCardsPage.changeCardStatusAsNewStatus(changeStatusTo);
	
	// Click Save Button
	shellCardsPage.clickSaveButton();
					
	// Click No Button 
	shellCardsPage.validateReplaceContentPopupYesOrNobutton("Yes");	
		
	
	// Click Back to card list button
	shellCardsPage.clickBackToCardList();
	
	// select Card based on the search
	shellCardsPage.selectCardNewlyUpdatedAndViewCardValidate(changeStatusTo, selectedBalanceAllowedCard);
	}
	}
	loginPage.Logout();
	
	}
	
	@Parameters({"clientCountry","clientName", "cardType"})
	@Test( groups = { "Regression" })
	public void validateBulkUpdateCardDownloadAndUploadFeature(@Optional("AT") String clientCountry, @Optional("SHELL") String clientName, @Optional("PC") String cardType)  {
		
		test = extent.createTest(clientName+ ":" +clientCountry+"  09 Bulk update cards, 14 Bulk Card update - Download Template - Exclude from Update", "Validate the Bulk Update Card Feature");

		//Creating Objects for the Pages
        LoginPage loginPage = new LoginPage(driver, test);
        HomePage homePage = new HomePage(driver, test);
        SHELLHomePage shellHomePage = new SHELLHomePage(driver, test);
        SHELLCardsPage shellCardsPage = new SHELLCardsPage(driver, test); 
        
        // Calling Login Functions And Validate
        if(cardType.equals("PC"))
        {
        	loginPage.Login("SHLPC_URL", "SHLPC_UN_Customer_Admin_" + clientCountry, "SHLPC_PWD_Customer_Admin_" + clientCountry, clientName);
        }
        else if(cardType.equals("APA"))
        {
        	loginPage.Login("SHLAPA_URL", "SHLAPA_UN_Customer_Admin_" + clientCountry, "SHLAPA_PWD_Customer_Admin_" + clientCountry, clientName);
        }
		homePage.ValidateLogoutLink();
		homePage.ValidateHelpShellLink();
		homePage.ValidateWelcomeText(clientName+"#"+cardType);
		homePage.ValidateQuickLinks();
		shellHomePage.ValidateHeaderMenus("Admin");
		shellHomePage.ValidateFooterMenus();
		
		// Go to Bulk card Update
		
		shellHomePage.goToCardMenuBulkCardUpdate();
		
		shellCardsPage.validateBuldCardUpdatePage();
		
		// Filter and Search
		
		shellCardsPage.verifyAllRequiredFieldsBulkCardUpdate();
		
		// Click Search Button
		shellCardsPage.clickBulkCardUpdateSearch();
		
		// Uncheck all the Customers
		shellCardsPage.UnCheckSelectALL();
		
		 //Select First customer and Download
		shellCardsPage.selectOneAccountAndDownload(); 
		
		//shellCardsPage.UploadTheCustomerAndVerify();//Not implemented yet
		
		// logout
		loginPage.Logout();
		
	}
	

	// Added by Anton on 26.06.2018	
	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test( groups = { "Regression" })
	public void validateChangeCardStatusCurrentSystemDate(@Optional("AT") String clientCountry,
			@Optional("SHELL") String clientName, @Optional("APA") String cardType) {
		// Covered two test cases its also Parent Account
		test = extent.createTest(clientName+ ":" +clientCountry+"  02 Change Card Status page on Current System Date", "Change Card Status page on Current System Date");

		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		HomePage homePage = new HomePage(driver, test);
		SHELLHomePage shellHomePage = new SHELLHomePage(driver, test);
		SHELLCardsPage shellCardsPage = new SHELLCardsPage(driver, test);

		// Calling Login Functions And Validate
		 if(cardType.equals("PC"))
	     {
	       loginPage.Login("SHLPC_URL", "SHLPC_UN_Customer_Admin_" + clientCountry, "SHLPC_PWD_Customer_Admin_" + clientCountry, clientName);
	     }
	     else if(cardType.equals("APA"))
	     {
	       loginPage.Login("SHLAPA_URL", "SHLAPA_UN_Customer_Admin_" + clientCountry, "SHLAPA_PWD_Customer_Admin_" + clientCountry, clientName);
	     }
		homePage.ValidateLogoutLink();
		homePage.ValidateHelpShellLink();
		homePage.ValidateWelcomeText(clientName+"#"+cardType);
		homePage.ValidateQuickLinks();
		shellHomePage.ValidateHeaderMenus("Admin");
		shellHomePage.ValidateFooterMenus();

		// Go to Card List
		shellHomePage.goToCardMenuCardList();
		shellCardsPage.verifyCardListPage();
		// select all accounts and Active cards
		shellCardsPage.selectAllAccountsAndActiveCard();
		
		boolean isNoCardsPresent = shellCardsPage.waitForTextToAppear("No Cards found.", 30);
		
		if(!isNoCardsPresent)
		{
			// Select the Change status page
			shellCardsPage.clickActiveCardAndSelectChangeStatus();
			shellCardsPage.changeStatusPageAndValidateCurrentSystemDate();
			shellCardsPage.checkCardStatusAndBalanceofTemporaryBlock();	
		}
		
		loginPage.Logout();
	}
	
	@Parameters({"clientCountry","clientName", "cardType"})
	@Test( groups = { "Regression" })
	public void validateChangeCardStatusAsStolenNotBalanceAllowedWithReplace(@Optional("AT") String clientCountry, @Optional("SHELL") String clientName, @Optional("APA") String cardType)  {
	
	test = extent.createTest(clientName+ ":" +clientCountry+"  09 Change Card status Stolen Not Bal Allowed Replace", "Validate Change Card Status to Stolen and View Card");
	String changeStatusTo = "Stolen";
	//Creating Objects for the Pages
    LoginPage loginPage = new LoginPage(driver, test);
    HomePage homePage = new HomePage(driver, test);
    SHELLHomePage shellHomePage = new SHELLHomePage(driver, test);
    SHELLCardsPage shellCardsPage = new SHELLCardsPage(driver, test); 
    
    // Calling Login Functions And Validate
    if(cardType.equals("PC"))
    {
    	loginPage.Login("SHLPC_URL", "SHLPC_UN_Customer_Admin_" + clientCountry, "SHLPC_PWD_Customer_Admin_" + clientCountry, clientName);
    }
    else if(cardType.equals("APA"))
    {
    	loginPage.Login("SHLAPA_URL", "SHLAPA_UN_Customer_Admin_" + clientCountry, "SHLAPA_PWD_Customer_Admin_" + clientCountry, clientName);
    }
	homePage.ValidateLogoutLink();
	homePage.ValidateHelpShellLink();
	homePage.ValidateWelcomeText(clientName+"#"+cardType);
	homePage.ValidateQuickLinks();
	shellHomePage.ValidateHeaderMenus("Admin");
	shellHomePage.ValidateFooterMenus();
	
	// Go to Card List
	shellHomePage.goToCardMenuCardList();
	shellCardsPage.verifyCardListPage();
	
	// select all accounts and Active cards
	shellCardsPage.selectAllAccountsAndActiveCard();
		
	shellCardsPage.clickSearchButtonAndValidate();
	
	boolean isNoCardsPresent = shellCardsPage.waitForTextToAppear("No Cards found.", 30);
	
	if(!isNoCardsPresent)
	{
								
	// Change Card Status with Not balance Allowed
	String selectedCardNo = shellCardsPage.clickNotBalancedAllowedCardListForAuthorityAt();
	
		if(!selectedCardNo.equals(""))
		{
			shellCardsPage.changeCardStatusAsNewStatus(changeStatusTo);

			// Click Save Button
			shellCardsPage.clickSaveButton();

			// Click Yes Button
			shellCardsPage.validateReplaceContentPopupYesOrNobutton("Yes");

			// Click Back to card list button
			shellCardsPage.clickBackToCardList();

			// select Card based on the search
			shellCardsPage.selectCardNewlyUpdatedAndViewCardValidate(changeStatusTo, selectedCardNo);

		}

		}
		loginPage.Logout();
}
	
	@Parameters({"clientCountry","clientName", "cardType"})
	@Test( groups = { "Regression" })
	public void validateChangeCardStatusAsStolenNotBalanceAllowedNoReplace(@Optional("BE") String clientCountry, @Optional("SHELL") String clientName, @Optional("APA") String cardType)  {
	
	test = extent.createTest(clientName+ ":" +clientCountry+"  10 Change Card status - Stolen - Not Bal Allowed - No Replace", "Validate Change Card Status to Stolen with Not Balance Allowed no replace");

	String changeStatusTo = "Stolen";
	//Creating Objects for the Pages
    LoginPage loginPage = new LoginPage(driver, test);
    HomePage homePage = new HomePage(driver, test);
    SHELLHomePage shellHomePage = new SHELLHomePage(driver, test);
    SHELLCardsPage shellCardsPage = new SHELLCardsPage(driver, test); 
    
    // Calling Login Functions And Validate
    if(cardType.equals("PC"))
    {
    	loginPage.Login("SHLPC_URL", "SHLPC_UN_Customer_Admin_" + clientCountry, "SHLPC_PWD_Customer_Admin_" + clientCountry, clientName);
    }
    else if(cardType.equals("APA"))
    {
    	loginPage.Login("SHLAPA_URL", "SHLAPA_UN_Customer_Admin_" + clientCountry, "SHLAPA_PWD_Customer_Admin_" + clientCountry, clientName);
    }
	homePage.ValidateLogoutLink();
	homePage.ValidateHelpShellLink();
	homePage.ValidateWelcomeText(clientName+"#"+cardType);
	homePage.ValidateQuickLinks();
	shellHomePage.ValidateHeaderMenus("Admin");
	shellHomePage.ValidateFooterMenus();
	
	// Go to Card List
	shellHomePage.goToCardMenuCardList();
	shellCardsPage.verifyCardListPage();
	// select all accounts and Active cards
	shellCardsPage.selectAllAccountsAndActiveCard();	
	shellCardsPage.clickSearchButtonAndValidate();
	
	boolean isNoCardsPresent = shellCardsPage.waitForTextToAppear("No Cards found.", 30);
	
	if(!isNoCardsPresent)
	{
			
	String selectedCardNo = shellCardsPage.clickNotBalancedAllowedCardListForAuthorityAt();
	
	if(!selectedCardNo.equals(""))
	{
		shellCardsPage.changeCardStatusAsNewStatus(changeStatusTo);
		
		// Click Save Button
		shellCardsPage.clickSaveButton();
		
		// Click No Button 	
		
		shellCardsPage.validateReplaceContentPopupYesOrNobutton("No");
		
		// Click Back to card list button
		shellCardsPage.clickBackToCardList();
		
		// select Card based on the search
		shellCardsPage.selectCardNewlyUpdatedAndViewCardValidate(changeStatusTo, selectedCardNo);
	}
	}
	loginPage.Logout();
	
	}
	
	@Parameters({"clientCountry","clientName", "cardType"})
	@Test( groups = { "Regression" })
	public void validateChangeCardStatusAsStolenBalanceAllowedWithReplace(@Optional("AT") String clientCountry, @Optional("SHELL") String clientName, @Optional("APA") String cardType)  {
	
	test = extent.createTest(clientName+ ":" +clientCountry+"  11 Change Card status - Stolen - Bal Allowed - Replace", "Validate Change Card Status to Stolen with Balance Allowed Replace");

	String changeStatusTo = "Stolen";
	//Creating Objects for the Pages
    LoginPage loginPage = new LoginPage(driver, test);
    HomePage homePage = new HomePage(driver, test);
    SHELLHomePage shellHomePage = new SHELLHomePage(driver, test);
    SHELLCardsPage shellCardsPage = new SHELLCardsPage(driver, test); 
    
    // Calling Login Functions And Validate
    if(cardType.equals("PC"))
    {
    	loginPage.Login("SHLPC_URL", "SHLPC_UN_Customer_Admin_" + clientCountry, "SHLPC_PWD_Customer_Admin_" + clientCountry, clientName);
    }
    else if(cardType.equals("APA"))
    {
    	loginPage.Login("SHLAPA_URL", "SHLAPA_UN_Customer_Admin_" + clientCountry, "SHLAPA_PWD_Customer_Admin_" + clientCountry, clientName);
    }
	homePage.ValidateLogoutLink();
	homePage.ValidateHelpShellLink();
	homePage.ValidateWelcomeText(clientName+"#"+cardType);
	homePage.ValidateQuickLinks();
	shellHomePage.ValidateHeaderMenus("Admin");
	shellHomePage.ValidateFooterMenus();
	
	// Go to Card List
	shellHomePage.goToCardMenuCardList();
	shellCardsPage.verifyCardListPage();
	
	// select all accounts and Active cards
	shellCardsPage.selectAllAccountsAndActiveCard();	
	
	shellCardsPage.clickSearchButtonAndValidate();
	
	boolean isNoCardsPresent = shellCardsPage.waitForTextToAppear("No Cards found.", 30);
	
	if(!isNoCardsPresent)
	{
			
	String selectedBalanceAllowedCard = shellCardsPage.clickBalanceAllowedCardListForAuthorityAt();
	
	if(!selectedBalanceAllowedCard.equals(""))
	{
	
		shellCardsPage.changeCardStatusAsNewStatus(changeStatusTo);
		
		// Click Save Button
		shellCardsPage.clickSaveButton();
		
		// Click Yes Button 
		
		shellCardsPage.validateReplaceContentPopupYesOrNobutton("Yes");
		
		// Click Back to card list button
		shellCardsPage.clickBackToCardList();
		
		// select Card based on the search
		shellCardsPage.selectCardNewlyUpdatedAndViewCardValidate(changeStatusTo, selectedBalanceAllowedCard);
	}
	}
	loginPage.Logout();
	
	}
	
	
	
	@Parameters({"clientCountry","clientName", "cardType"})
	@Test( groups = { "Regression" })
	public void validateChangeCardStatusAsStolenBalanceAllowedNoReplace(@Optional("AT") String clientCountry, @Optional("SHELL") String clientName, @Optional("APA") String cardType)  {
	
	test = extent.createTest(clientName+ ":" +clientCountry+"  12 Change Card status - Stolen - Bal Allowed - No Replace", "Validate Change Card Status to Stolen with Not Balance Allowed no replace");

	String changeStatusTo = "Stolen";
	//Creating Objects for the Pages
    LoginPage loginPage = new LoginPage(driver, test);
    HomePage homePage = new HomePage(driver, test);
    SHELLHomePage shellHomePage = new SHELLHomePage(driver, test);
    SHELLCardsPage shellCardsPage = new SHELLCardsPage(driver, test); 
    
    // Calling Login Functions And Validate
    if(cardType.equals("PC"))
    {
    	loginPage.Login("SHLPC_URL", "SHLPC_UN_Customer_Admin_" + clientCountry, "SHLPC_PWD_Customer_Admin_" + clientCountry, clientName);
    }
    else if(cardType.equals("APA"))
    {
    	loginPage.Login("SHLAPA_URL", "SHLAPA_UN_Customer_Admin_" + clientCountry, "SHLAPA_PWD_Customer_Admin_" + clientCountry, clientName);
    }
	homePage.ValidateLogoutLink();
	homePage.ValidateHelpShellLink();
	homePage.ValidateWelcomeText(clientName+"#"+cardType);
	homePage.ValidateQuickLinks();
	shellHomePage.ValidateHeaderMenus("Admin");
	shellHomePage.ValidateFooterMenus();
	
	// Go to Card List
	shellHomePage.goToCardMenuCardList();
	shellCardsPage.verifyCardListPage();
	// select all accounts and Active cards
	shellCardsPage.selectAllAccountsAndActiveCard();
	shellCardsPage.clickSearchButtonAndValidate();
	
	boolean isNoCardsPresent = shellCardsPage.waitForTextToAppear("No Cards found.", 30);
	
	if(!isNoCardsPresent)
	{
			
	String selectedBalanceAllowedCard = shellCardsPage.clickBalanceAllowedCardListForAuthorityAt();
	
	if(!selectedBalanceAllowedCard.equals(""))
	{
	
		shellCardsPage.changeCardStatusAsNewStatus(changeStatusTo);
		
		// Click Save Button
		shellCardsPage.clickSaveButton();
		
		// Click No Button 	
		
		shellCardsPage.validateReplaceContentPopupYesOrNobutton("No");
		
		// Click Back to card list button
		shellCardsPage.clickBackToCardList();
		
		// select Card based on the search
		shellCardsPage.selectCardNewlyUpdatedAndViewCardValidate(changeStatusTo, selectedBalanceAllowedCard);
	}
	}
	loginPage.Logout();
	
	}
	
	@Parameters({"clientCountry","clientName", "cardType"})
	@Test( groups = { "Regression" })
	public void validateChangeCardStatusAsLostBalanceAllowedWithReplace(@Optional("AT") String clientCountry, @Optional("SHELL") String clientName, @Optional("APA") String cardType)  {
	
	test = extent.createTest(clientName+ ":" +clientCountry+"  16 Change Card status - Lost - Bal Allowed - Replace", "Validate Change Card Status to Lost with Balance Allowed Replace");

	String changeStatusTo = "Lost";
	//Creating Objects for the Pages
    LoginPage loginPage = new LoginPage(driver, test);
    HomePage homePage = new HomePage(driver, test);
    SHELLHomePage shellHomePage = new SHELLHomePage(driver, test);
    SHELLCardsPage shellCardsPage = new SHELLCardsPage(driver, test); 
    
    // Calling Login Functions And Validate
    if(cardType.equals("PC"))
    {
    	loginPage.Login("SHLPC_URL", "SHLPC_UN_Customer_Admin_" + clientCountry, "SHLPC_PWD_Customer_Admin_" + clientCountry, clientName);
    }
    else if(cardType.equals("APA"))
    {
    	loginPage.Login("SHLAPA_URL", "SHLAPA_UN_Customer_Admin_" + clientCountry, "SHLAPA_PWD_Customer_Admin_" + clientCountry, clientName);
    }
	homePage.ValidateLogoutLink();
	homePage.ValidateHelpShellLink();
	homePage.ValidateWelcomeText(clientName+"#"+cardType);
	homePage.ValidateQuickLinks();
	shellHomePage.ValidateHeaderMenus("Admin");
	shellHomePage.ValidateFooterMenus();
	
	// Go to Card List
	shellHomePage.goToCardMenuCardList();
	shellCardsPage.verifyCardListPage();
	// select all accounts and Active cards
	shellCardsPage.selectAllAccountsAndActiveCard();
	shellCardsPage.clickSearchButtonAndValidate();
	
	boolean isNoCardsPresent = shellCardsPage.waitForTextToAppear("No Cards found.", 30);
	
	if(!isNoCardsPresent)
	{
			
	String selectedBalanceAllowedCard = shellCardsPage.clickBalanceAllowedCardListForAuthorityAt();
	
	if(!selectedBalanceAllowedCard.equals(""))
	{
		shellCardsPage.changeCardStatusAsNewStatus(changeStatusTo);
		
		// Click Update Button
		shellCardsPage.clickSaveButton();
		
		// Click Yes Button 	
		
		shellCardsPage.validateReplaceContentPopupYesOrNobutton("Yes");
		
		// Click Back to card list button
		shellCardsPage.clickBackToCardList();
		
		// select Card based on the search
		shellCardsPage.selectCardNewlyUpdatedAndViewCardValidate(changeStatusTo, selectedBalanceAllowedCard);
	}
	}
	loginPage.Logout();
	
	}

	@Parameters({"clientCountry","clientName", "cardType"})
	@Test( groups = { "Regression" })
	public void validateChangeCardStatusAsLostBalanceAllowedWithNoReplace(@Optional("AT") String clientCountry, @Optional("SHELL") String clientName, @Optional("APA") String cardType)  {
	
	test = extent.createTest(clientName+ ":" +clientCountry+"  17 Change Card status - Lost - Bal Allowed - No Replace", "Validate Change Card Status to Lost with Balance Allowed Replace");

	String changeStatusTo = "Lost";
	//Creating Objects for the Pages
    LoginPage loginPage = new LoginPage(driver, test);
    HomePage homePage = new HomePage(driver, test);
    SHELLHomePage shellHomePage = new SHELLHomePage(driver, test);
    SHELLCardsPage shellCardsPage = new SHELLCardsPage(driver, test); 
    
    // Calling Login Functions And Validate
    if(cardType.equals("PC"))
    {
    	loginPage.Login("SHLPC_URL", "SHLPC_UN_Customer_Admin_" + clientCountry, "SHLPC_PWD_Customer_Admin_" + clientCountry, clientName);
    }
    else if(cardType.equals("APA"))
    {
    	loginPage.Login("SHLAPA_URL", "SHLAPA_UN_Customer_Admin_" + clientCountry, "SHLAPA_PWD_Customer_Admin_" + clientCountry, clientName);
    }
	homePage.ValidateLogoutLink();
	homePage.ValidateHelpShellLink();
	homePage.ValidateWelcomeText(clientName+"#"+cardType);
	homePage.ValidateQuickLinks();
	shellHomePage.ValidateHeaderMenus("Admin");
	shellHomePage.ValidateFooterMenus();
	
	// Go to Card List
	shellHomePage.goToCardMenuCardList();
	
	shellCardsPage.verifyCardListPage();
	
	// select all accounts and Active cards
	shellCardsPage.selectAllAccountsAndActiveCard();
	
	shellCardsPage.clickSearchButtonAndValidate();
	
	boolean isNoCardsPresent = shellCardsPage.waitForTextToAppear("No Cards found.", 30);
	
	if(!isNoCardsPresent)
	{
			
	String selectedBalanceAllowedCard = shellCardsPage.clickBalanceAllowedCardListForAuthorityAt();
	
	if(!selectedBalanceAllowedCard.equals(""))
	{
		shellCardsPage.changeCardStatusAsNewStatus(changeStatusTo);
		
		// Click Update Button
		shellCardsPage.clickSaveButton();
			
		// Click Yes Button 
		
		shellCardsPage.validateReplaceContentPopupYesOrNobutton("No");
		
		// Click Back to card list button
		shellCardsPage.clickBackToCardList();
		
		// select Card based on the search
		shellCardsPage.selectCardNewlyUpdatedAndViewCardValidate(changeStatusTo, selectedBalanceAllowedCard);
	}
	}
	loginPage.Logout();
	
	}

	@Parameters({"clientCountry","clientName", "cardType"})
	@Test( groups = { "Regression" })
	public void validateChangeCardStatusAsLostNotBalanceAllowedWithReplace(@Optional("AT") String clientCountry, @Optional("SHELL") String clientName, @Optional("APA") String cardType)  {
	
	test = extent.createTest(clientName+ ":" +clientCountry+"  14 Change Card status-Lost-Not Bal Allowed-Replace", "Validate Change Card Status to Lost with Not Balance Allowed Replace");

	String changeStatusTo = "Lost";
	//Creating Objects for the Pages
    LoginPage loginPage = new LoginPage(driver, test);
    HomePage homePage = new HomePage(driver, test);
    SHELLHomePage shellHomePage = new SHELLHomePage(driver, test);
    SHELLCardsPage shellCardsPage = new SHELLCardsPage(driver, test); 
    
    // Calling Login Functions And Validate
    if(cardType.equals("PC"))
    {
    	loginPage.Login("SHLPC_URL", "SHLPC_UN_Customer_Admin_" + clientCountry, "SHLPC_PWD_Customer_Admin_" + clientCountry, clientName);
    }
    else if(cardType.equals("APA"))
    {
    	loginPage.Login("SHLAPA_URL", "SHLAPA_UN_Customer_Admin_" + clientCountry, "SHLAPA_PWD_Customer_Admin_" + clientCountry, clientName);
    }
	homePage.ValidateLogoutLink();
	homePage.ValidateHelpShellLink();
	homePage.ValidateWelcomeText(clientName+"#"+cardType);
	homePage.ValidateQuickLinks();
	shellHomePage.ValidateHeaderMenus("Admin");
	shellHomePage.ValidateFooterMenus();
	
	// Go to Card List
	shellHomePage.goToCardMenuCardList();
	shellCardsPage.verifyCardListPage();
	
	// select all accounts and Active cards
	shellCardsPage.selectAllAccountsAndActiveCard();
	
	shellCardsPage.clickSearchButtonAndValidate();
	
	boolean isNoCardsPresent = shellCardsPage.waitForTextToAppear("No Cards found.", 30);
	
	if(!isNoCardsPresent)
	{
			
	String selectedBalanceAllowedCard = shellCardsPage.clickBalanceAllowedCardListForAuthorityAt();
	
	if(!selectedBalanceAllowedCard.equals(""))
	{
	shellCardsPage.changeCardStatusAsNewStatus(changeStatusTo);
	
	// Click Save Button
	shellCardsPage.clickSaveButton();
						
	// Click No Button 
	shellCardsPage.validateReplaceContentPopupYesOrNobutton("Yes");	
	
	// Click Back to card list button
	shellCardsPage.clickBackToCardList();
	
	// select Card based on the search
	shellCardsPage.selectCardNewlyUpdatedAndViewCardValidate(changeStatusTo, selectedBalanceAllowedCard);
	}
	}
	loginPage.Logout();
	
	}
	
	@Parameters({"clientCountry","clientName", "cardType"})
	@Test( groups = { "Regression" })
	public void validateChangeCardStatusAsLostNotBalanceAllowedWithNoReplace(@Optional("AT") String clientCountry, @Optional("SHELL") String clientName, @Optional("APA") String cardType)  {
	
	test = extent.createTest(clientName+ ":" +clientCountry+"  15 Change Card status-Lost Not BalAllowed-No Replace", "Validate Change Card Status to Lost with Not Balance Allowed NoReplace");

	String changeStatusTo = "Lost";
	//Creating Objects for the Pages
    LoginPage loginPage = new LoginPage(driver, test);
    HomePage homePage = new HomePage(driver, test);
    SHELLHomePage shellHomePage = new SHELLHomePage(driver, test);
    SHELLCardsPage shellCardsPage = new SHELLCardsPage(driver, test); 
    
    // Calling Login Functions And Validate
    if(cardType.equals("PC"))
    {
    	loginPage.Login("SHLPC_URL", "SHLPC_UN_Customer_Admin_" + clientCountry, "SHLPC_PWD_Customer_Admin_" + clientCountry, clientName);
    }
    else if(cardType.equals("APA"))
    {
    	loginPage.Login("SHLAPA_URL", "SHLAPA_UN_Customer_Admin_" + clientCountry, "SHLAPA_PWD_Customer_Admin_" + clientCountry, clientName);
    }
	homePage.ValidateLogoutLink();
	homePage.ValidateHelpShellLink();
	homePage.ValidateWelcomeText(clientName+"#"+cardType);
	homePage.ValidateQuickLinks();
	shellHomePage.ValidateHeaderMenus("Admin");
	shellHomePage.ValidateFooterMenus();
	
	// Go to Card List
	shellHomePage.goToCardMenuCardList();
	shellCardsPage.verifyCardListPage();
	
	// select all accounts and Active cards
	shellCardsPage.selectAllAccountsAndActiveCard();
	
	shellCardsPage.clickSearchButtonAndValidate();
	
	boolean isNoCardsPresent = shellCardsPage.waitForTextToAppear("No Cards found.", 30);
	
	if(!isNoCardsPresent)
	{
			
	String selectedBalanceAllowedCard = shellCardsPage.clickBalanceAllowedCardListForAuthorityAt();
	
	if(!selectedBalanceAllowedCard.equals(""))
	{
	
	shellCardsPage.changeCardStatusAsNewStatus(changeStatusTo);
	
	// Click Save Button
	shellCardsPage.clickSaveButton();
						
	// Click No Button 
	shellCardsPage.validateReplaceContentPopupYesOrNobutton("No");	
	
	// Click Back to card list button
	shellCardsPage.clickBackToCardList();
	
	// select Card based on the search
	shellCardsPage.selectCardNewlyUpdatedAndViewCardValidate(changeStatusTo, selectedBalanceAllowedCard);
	}
	}
	loginPage.Logout();
	
	}
	
	@Parameters({"clientCountry","clientName", "cardType"})
	@Test( groups = { "Regression" })
	public void validateReissueCardWithStolenStatus(@Optional("AT") String clientCountry, @Optional("SHELL") String clientName, @Optional("APA") String cardType)  {
		
		test = extent.createTest(clientName+ ":" +clientCountry+"  11 Reissue a card with Stolen Status, 07 Edit Card status-StolenReissued", "Validate Edit Card Change Status");

		//Creating Objects for the Pages
        LoginPage loginPage = new LoginPage(driver, test);
        HomePage homePage = new HomePage(driver, test);
        SHELLHomePage shellHomePage = new SHELLHomePage(driver, test);
        SHELLCardsPage shellCardsPage = new SHELLCardsPage(driver, test); 
        
        // Calling Login Functions And Validate
        if(cardType.equals("PC"))
        {
        	loginPage.Login("SHLPC_URL", "SHLPC_UN_Customer_Admin_" + clientCountry, "SHLPC_PWD_Customer_Admin_" + clientCountry, clientName);
        }
        else if(cardType.equals("APA"))
        {
        	loginPage.Login("SHLAPA_URL", "SHLAPA_UN_Customer_Admin_" + clientCountry, "SHLAPA_PWD_Customer_Admin_" + clientCountry, clientName);
        }
		homePage.ValidateLogoutLink();
		homePage.ValidateHelpShellLink();
		homePage.ValidateWelcomeText(clientName+"#"+cardType);
		homePage.ValidateQuickLinks();
		shellHomePage.ValidateHeaderMenus("Admin");
		shellHomePage.ValidateFooterMenus();
		
		String accountStatus = shellHomePage.getAccountStatus();
		
		String accountName = shellHomePage.getDisplayedAccountName();
		
		String trimAccName = shellHomePage.trimAccountName(accountName);
		
		// Go to Card List
		shellHomePage.goToCardMenuCardList();
		
		shellCardsPage.verifyCardListPage();
		
		shellCardsPage.selectOneAccountAndActiveCard(trimAccName);
		
		shellCardsPage.clickSearchButtonAndValidate();
		
		boolean isNoCardsPresent = shellCardsPage.waitForTextToAppear("No Cards found.", 30);
		
		if(!isNoCardsPresent)
		{				
			boolean isAvailableBalanceCard = shellCardsPage.goToEditCardPageAfterCheckAvailableBalance();
			
			if(isAvailableBalanceCard)
			{
				shellCardsPage.changeCardStatusAsNewStatusInEditCard("Stolen");
			
				// Click Update Button
				shellCardsPage.clickUpdateButton();
			
				// Validate The Edit Card Reissued or Not		
				shellCardsPage.validateTheEditCardAndReIssue(accountStatus);
			}
		}
		
		// Click Logout
		loginPage.Logout();
	}
	
	@Parameters({"clientCountry","clientName", "cardType"})
	@Test( groups = { "Regression" })
	public void validateReissueCardWithDamagedStatus(@Optional("AT") String clientCountry, @Optional("SHELL") String clientName, @Optional("APA") String cardType)  {
		
		test = extent.createTest(clientName+ ":" +clientCountry+"  12  Reissue a card with Damaged status", "Validate Edit Card Change Status to Damaged");

		//Creating Objects for the Pages
        LoginPage loginPage = new LoginPage(driver, test);
        HomePage homePage = new HomePage(driver, test);
        SHELLHomePage shellHomePage = new SHELLHomePage(driver, test);
        SHELLCardsPage shellCardsPage = new SHELLCardsPage(driver, test); 
        
        // Calling Login Functions And Validate
        if(cardType.equals("PC"))
        {
        	loginPage.Login("SHLPC_URL", "SHLPC_UN_Customer_Admin_" + clientCountry, "SHLPC_PWD_Customer_Admin_" + clientCountry, clientName);
        }
        else if(cardType.equals("APA"))
        {
        	loginPage.Login("SHLAPA_URL", "SHLAPA_UN_Customer_Admin_" + clientCountry, "SHLAPA_PWD_Customer_Admin_" + clientCountry, clientName);
        }
		homePage.ValidateLogoutLink();
		homePage.ValidateHelpShellLink();
		homePage.ValidateWelcomeText(clientName+"#"+cardType);
		homePage.ValidateQuickLinks();
		shellHomePage.ValidateHeaderMenus("Admin");
		shellHomePage.ValidateFooterMenus();
		
		String accountStatus = shellHomePage.getAccountStatus();
		
		String accountName = shellHomePage.getDisplayedAccountName();
		
		String trimAccName = shellHomePage.trimAccountName(accountName);
		
		// Go to Card List
		shellHomePage.goToCardMenuCardList();
		
		shellCardsPage.verifyCardListPage();
		
		shellCardsPage.selectOneAccountAndActiveCard(trimAccName);
		
		shellCardsPage.clickSearchButtonAndValidate();
		
		boolean isNoCardsPresent = shellCardsPage.waitForTextToAppear("No Cards found.", 30);
		
		if(!isNoCardsPresent)
		{	
				
			boolean isAvailableBalanceCard = shellCardsPage.goToEditCardPageAfterCheckAvailableBalance();
			
			if(isAvailableBalanceCard)
			{		
				shellCardsPage.changeCardStatusAsNewStatusInEditCard("Damaged");
		
				// Click Update Button
				shellCardsPage.clickUpdateButton();
		
				// Validate The Edit Card Reissued or Not		
				shellCardsPage.validateTheEditCardAndReIssue(accountStatus);
			}
		}
		
		// Click Logout
		loginPage.Logout();
	}
	
	@Parameters({"clientCountry","clientName", "cardType"})
	@Test( groups = { "Regression" })
	public void validateReissueCardWithTempBlockStatus(@Optional("AT") String clientCountry, @Optional("SHELL") String clientName, @Optional("APA") String cardType)  {
		
		test = extent.createTest(clientName+ ":" +clientCountry+"  13  Resissue a card with Temp Block Status", "Validate Edit Card Change Status to Temp Block");

		//Creating Objects for the Pages
        LoginPage loginPage = new LoginPage(driver, test);
        HomePage homePage = new HomePage(driver, test);
        SHELLHomePage shellHomePage = new SHELLHomePage(driver, test);
        SHELLCardsPage shellCardsPage = new SHELLCardsPage(driver, test); 
        
        // Calling Login Functions And Validate
        if(cardType.equals("PC"))
        {
        	loginPage.Login("SHLPC_URL", "SHLPC_UN_Customer_Admin_" + clientCountry, "SHLPC_PWD_Customer_Admin_" + clientCountry, clientName);
        }
        else if(cardType.equals("APA"))
        {
        	loginPage.Login("SHLAPA_URL", "SHLAPA_UN_Customer_Admin_" + clientCountry, "SHLAPA_PWD_Customer_Admin_" + clientCountry, clientName);
        }
		homePage.ValidateLogoutLink();
		homePage.ValidateHelpShellLink();
		homePage.ValidateWelcomeText(clientName+"#"+cardType);
		homePage.ValidateQuickLinks();
		shellHomePage.ValidateHeaderMenus("Admin");
		shellHomePage.ValidateFooterMenus();
		
		String accountStatus = shellHomePage.getAccountStatus();
		
		String accountName = shellHomePage.getDisplayedAccountName();
		
		String trimAccName = shellHomePage.trimAccountName(accountName);
		
		// Go to Card List
		shellHomePage.goToCardMenuCardList();
		
		shellCardsPage.verifyCardListPage();
		
		shellCardsPage.selectOneAccountAndActiveCard(trimAccName);
		
		shellCardsPage.clickSearchButtonAndValidate();
		
		boolean isNoCardsPresent = shellCardsPage.waitForTextToAppear("No Cards found.", 30);
		
		if(!isNoCardsPresent)
		{				
			boolean isAvailableBalanceCard = shellCardsPage.goToEditCardPageAfterCheckAvailableBalance();
			
			if(isAvailableBalanceCard)
			{
			
				shellCardsPage.changeCardStatusAsNewStatusInEditCard("Temporary Block");
				
				// Click Update Button
				shellCardsPage.clickUpdateButton();
				
				// Validate The Edit Card Reissued or Not		
				shellCardsPage.validateTheEditCardAndReIssue(accountStatus);
			}
		}
		
		// Click Logout
		loginPage.Logout();
	}

	@Parameters({"clientCountry","clientName", "cardType"})
	@Test( groups = { "Regression" })
	public void validateCardMenuReissueControl(@Optional("AT") String clientCountry, @Optional("SHELL") String clientName, @Optional("APA") String cardType)  {
	
	test = extent.createTest(clientName+ ":" +clientCountry+"  01 Verify details on Reissue control page", "Validate Card menu reissue control page");

	//Creating Objects for the Pages
    LoginPage loginPage = new LoginPage(driver, test);
    HomePage homePage = new HomePage(driver, test);
    SHELLHomePage shellHomePage = new SHELLHomePage(driver, test);
    SHELLCardsPage shellCardsPage = new SHELLCardsPage(driver, test); 
    
    // Calling Login Functions And Validate
    if(cardType.equals("PC"))
    {
    	loginPage.Login("SHLPC_URL", "SHLPC_UN_Customer_Admin_" + clientCountry, "SHLPC_PWD_Customer_Admin_" + clientCountry, clientName);
    }
    else if(cardType.equals("APA"))
    {
    	loginPage.Login("SHLAPA_URL", "SHLAPA_UN_Customer_Admin_" + clientCountry, "SHLAPA_PWD_Customer_Admin_" + clientCountry, clientName);
    }
	homePage.ValidateLogoutLink();
	homePage.ValidateHelpShellLink();
	homePage.ValidateWelcomeText(clientName+"#"+cardType);
	homePage.ValidateQuickLinks();
	shellHomePage.ValidateHeaderMenus("Admin");
	shellHomePage.ValidateFooterMenus();
	
	// Go to Card List
	shellHomePage.goToCardMenuReissueControl();
	shellCardsPage.verifyReissueControlPage();

	boolean isReissueDataPresentorNot =  shellCardsPage.verifyBulkReIssueListDataIsAvailable();
	
	if(isReissueDataPresentorNot)
	{
		shellCardsPage.printNoReissueDataPresent();
	} else {
	// Click Export Button 
	shellCardsPage.clickExportButton();
	}
	
	takeScreenshot();
	// Click Logout
	loginPage.Logout();
	
	}
	
	@Parameters({"clientCountry","clientName", "cardType"})
	@Test( groups = { "Regression" })
	public void validateReturnToBulkReissueListFromReissueControl(@Optional("AT") String clientCountry, @Optional("SHELL") String clientName, @Optional("APA") String cardType)  {
	
	test = extent.createTest(clientName+ ":" +clientCountry+"  02 Return to Reissue List, 02 Exclude a card from the Reissue", "Validate the return to  reissue control page");

	//Creating Objects for the Pages
    LoginPage loginPage = new LoginPage(driver, test);
    HomePage homePage = new HomePage(driver, test);
    SHELLHomePage shellHomePage = new SHELLHomePage(driver, test);
    SHELLCardsPage shellCardsPage = new SHELLCardsPage(driver, test); 
    
    // Calling Login Functions And Validate
    if(cardType.equals("PC"))
    {
    	loginPage.Login("SHLPC_URL", "SHLPC_UN_Customer_Admin_" + clientCountry, "SHLPC_PWD_Customer_Admin_" + clientCountry, clientName);
    }
    else if(cardType.equals("APA"))
    {
    	loginPage.Login("SHLAPA_URL", "SHLAPA_UN_Customer_Admin_" + clientCountry, "SHLAPA_PWD_Customer_Admin_" + clientCountry, clientName);
    }
	homePage.ValidateLogoutLink();
	homePage.ValidateHelpShellLink();
	homePage.ValidateWelcomeText(clientName+"#"+cardType);
	homePage.ValidateQuickLinks();
	shellHomePage.ValidateHeaderMenus("Admin");
	shellHomePage.ValidateFooterMenus();
	
	// Go to Card List
	shellHomePage.goToCardMenuReissueControl();
	
	shellCardsPage.verifyReissueControlPage();
	
	boolean isReissueDataPresentorNot =  shellCardsPage.verifyBulkReIssueListDataIsAvailable();
	
	if(isReissueDataPresentorNot)
	{
		shellCardsPage.printNoReissueDataPresent();
	}
	
	else
	{
		shellCardsPage.goToReissueDetailsPage();
		shellCardsPage.verifyReissueDetailsPageIsLoaded();
		shellCardsPage.verifyReissueStatusAndProceed();		
	}	
	
	//takeScreenshot();

	loginPage.Logout();
	
	}
	
	@Parameters({"clientCountry","clientName", "cardType"})
	@Test( groups = { "Regression" })
	public void validateReissueControlDetailsFromCardMenu(@Optional("AT") String clientCountry, @Optional("SHELL") String clientName, @Optional("APA") String cardType)  {
	
	test = extent.createTest(clientName+ ":" +clientCountry+"  02 Drill down to details on Reissue control page", "Validate Card menu details reissue control page");

	//Creating Objects for the Pages
    LoginPage loginPage = new LoginPage(driver, test);
    HomePage homePage = new HomePage(driver, test);
    SHELLHomePage shellHomePage = new SHELLHomePage(driver, test);
    SHELLCardsPage shellCardsPage = new SHELLCardsPage(driver, test); 
    
    // Calling Login Functions And Validate
    if(cardType.equals("PC"))
    {
    	loginPage.Login("SHLPC_URL", "SHLPC_UN_Customer_Admin_" + clientCountry, "SHLPC_PWD_Customer_Admin_" + clientCountry, clientName);
    }
    else if(cardType.equals("APA"))
    {
    	loginPage.Login("SHLAPA_URL", "SHLAPA_UN_Customer_Admin_" + clientCountry, "SHLAPA_PWD_Customer_Admin_" + clientCountry, clientName);
    }
	homePage.ValidateLogoutLink();
	homePage.ValidateHelpShellLink();
	homePage.ValidateWelcomeText(clientName+"#"+cardType);
	homePage.ValidateQuickLinks();
	shellHomePage.ValidateHeaderMenus("Admin");
	shellHomePage.ValidateFooterMenus();
	
	// Go to Card List
	shellHomePage.goToCardMenuReissueControl();
	shellCardsPage.verifyReissueControlPage();

	boolean isReissueDataPresentorNot =  shellCardsPage.verifyBulkReIssueListDataIsAvailable();
	
	if(isReissueDataPresentorNot)
	{
		shellCardsPage.printNoReissueDataPresent();
	} else {
	// Reissue Request and Validate
	shellCardsPage.clickReissueRequestAndValidate();
	shellCardsPage.clickReissueRequestExportBtn();
	shellCardsPage.validateDateAndOptionsFields();
	}
	// Click Logout
	loginPage.Logout();
	
	}
// Added by Ayub on 02.07.2018

	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test( groups = { "Regression" })
	public void validateOrderNewCardforBlockedAccountWithAdminLogin(@Optional("AT") String clientCountry,
			@Optional("SHELL") String clientName, @Optional("APA") String cardType) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  14 Card creation for subaccount", "Validate Card creation for subaccount");

		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		HomePage homePage = new HomePage(driver, test);
		SHELLHomePage shellHomePage = new SHELLHomePage(driver, test);
		SHELLCardsPage shellCardsPage = new SHELLCardsPage(driver, test);

		// Calling Login Functions And Validate
		 if(cardType.equals("PC"))
	        {
	        	loginPage.Login("SHLPC_URL", "SHLPC_UN_Customer_Admin_" + clientCountry, "SHLPC_PWD_Customer_Admin_" + clientCountry, clientName);
	        }
	        else if(cardType.equals("APA"))
	        {
	        	loginPage.Login("SHLAPA_URL", "SHLAPA_UN_Customer_Admin_" + clientCountry, "SHLAPA_PWD_Customer_Admin_" + clientCountry, clientName);
	        }
		homePage.ValidateLogoutLink();
		homePage.ValidateHelpShellLink();
		homePage.ValidateWelcomeText(clientName+"#"+cardType);
		homePage.ValidateQuickLinks();
		shellHomePage.ValidateHeaderMenus("Admin");
		shellHomePage.ValidateFooterMenus();

		String accountStatus = shellHomePage.getAccountStatus();
     	//String accountName = shellHomePage.getDisplayedAccountName();
		// Go to Card menu and validate the Order New Card 
		shellCardsPage.goToCardMenuAndValidateOrderNewCard(accountStatus);
		// Click Logout
		loginPage.Logout();
	
	}
	
	//Added by Nithya on 12.04.2019
	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test( groups = { "Regression" })
	public void verifyRolePermissionsForCustomerAdministrator(@Optional("RU") String clientCountry,
			@Optional("SHELL") String clientName, @Optional("APA") String cardType) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  Reissue PIN - 01 Verify details on Reissue control page",
				"01 Verify details on Reissue control page");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCShomePage = new IFCSHomePage(driver, test);
		ClientGroupPage clientGroupPage = new ClientGroupPage(driver, test);

		IFCSloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");

		IFCShomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);

		IFCShomePage.gotoAdminMenuAndChooseClientGroup();

		clientGroupPage.gotoOnlineRolePermissionsMenu();

		// Customer Administrator - Role
		clientGroupPage.verifyRoleAndAccess("Reissue Card Pin", "Customer Administrator", "Full Access");
		clientGroupPage.verifyRoleAndAccess("Change Card Pin", "Customer Administrator", "No Access");

		IFCShomePage.exitIFCS();

	}
	//Added by Nithya on 12.04.2019
	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test( groups = { "Regression" })
	public void verifyRolePermissionsForCustomerUser(@Optional("RU") String clientCountry,
			@Optional("SHELL") String clientName, @Optional("APA") String cardType) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  Reissue PIN - 02 Verify the Role Permissions for Customer User",
				"02 Verify the Role Permissions for Customer User");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCShomePage = new IFCSHomePage(driver, test);
		ClientGroupPage clientGroupPage = new ClientGroupPage(driver, test);

		IFCSloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");

		IFCShomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);

		IFCShomePage.gotoAdminMenuAndChooseClientGroup();

		clientGroupPage.gotoOnlineRolePermissionsMenu();

		// Customer User - Role
		clientGroupPage.verifyRoleAndAccess("Reissue Card Pin", "Customer User", "Full Access");
		clientGroupPage.verifyRoleAndAccess("Change Card Pin", "Customer User", "No Access");

		IFCShomePage.exitIFCS();

	}
	//Added by Nithya on 13.04.2019 - In Progress
	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test( groups = { "Regression" })
	public void verifyReissuePINOnOLSCustomerAdmin(@Optional("RU") String clientCountry,
			@Optional("SHELL") String clientName, @Optional("APA") String cardType) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  Reissue PIN - 03 Verify Resisue PIN menu on OLS  - Customer Admin",
				"03 Verify Resisue PIN menu on OLS  - Customer Admin");
		
		//Creating Objects for the Pages
        LoginPage loginPage = new LoginPage(driver, test);
        HomePage homePage = new HomePage(driver, test);
        SHELLHomePage shellHomePage = new SHELLHomePage(driver, test);
        SHELLCardsPage shellCardsPage = new SHELLCardsPage(driver, test); 
        
        // Calling Login Functions And Validate
        if(cardType.equals("PC"))
        {
        	loginPage.Login("SHLPC_URL", "SHLPC_UN_Customer_Admin_" + clientCountry, "SHLPC_PWD_Customer_Admin_" + clientCountry, clientName);
        }
        else if(cardType.equals("APA"))
        {
        	loginPage.Login("SHLAPA_URL", "SHLAPA_UN_Customer_Admin_" + clientCountry, "SHLAPA_PWD_Customer_Admin_" + clientCountry, clientName);
        }
		homePage.ValidateLogoutLink();
		homePage.ValidateHelpShellLink();
		homePage.ValidateWelcomeText(clientName+"#"+cardType);
		homePage.ValidateQuickLinks();
		shellHomePage.ValidateHeaderMenus("Admin");
		shellHomePage.ValidateFooterMenus();
		
		
		// Go to Card List
		shellHomePage.goToCardMenuCardList();
		
		shellCardsPage.verifyCardListPage();
		
		shellCardsPage.selectAllAccountsAndActiveCard();		
		
		shellCardsPage.clickSearchButtonAndValidate();
		
		boolean isNoCardsPresent = shellCardsPage.waitForTextToAppear("No Cards found.", 30);
		
		if(!isNoCardsPresent)
		{		
			 shellCardsPage.getANonReplacedCardAndCheckReissePIN();	 	
		}
		// Click Logout		
		loginPage.Logout();


	}
	
	//Added By Anton
	@Parameters({"clientCountry","clientName", "cardType"})
	@Test( groups = { "Regression" })
	public void verifyReissuePINOnActiveCard(@Optional("AT") String clientCountry, @Optional("SHELL") String clientName, @Optional("APA") String cardType)  {
		
		test = extent.createTest(clientName+ ":" +clientCountry+"  05 Verify Reissue PIN menu on OLS  - Customer Admin - Active Card", "Verify Reissue pin on active cards");

		//Creating Objects for the Pages
        LoginPage loginPage = new LoginPage(driver, test);
        HomePage homePage = new HomePage(driver, test);
        SHELLHomePage shellHomePage = new SHELLHomePage(driver, test);
        SHELLCardsPage shellCardsPage = new SHELLCardsPage(driver, test); 
        
        // Calling Login Functions And Validate
        if(cardType.equals("PC"))
        {
        	loginPage.Login("SHLPC_URL", "SHLPC_UN_Customer_Admin_" + clientCountry, "SHLPC_PWD_Customer_Admin_" + clientCountry, clientName);
        }
        else if(cardType.equals("APA"))
        {
        	loginPage.Login("SHLAPA_URL", "SHLAPA_UN_Customer_Admin_" + clientCountry, "SHLAPA_PWD_Customer_Admin_" + clientCountry, clientName);
        }
		homePage.ValidateLogoutLink();
		homePage.ValidateHelpShellLink();
		homePage.ValidateWelcomeText(clientName+"#"+cardType);
		homePage.ValidateQuickLinks();
		shellHomePage.ValidateHeaderMenus("Admin");
		shellHomePage.ValidateFooterMenus();
		
		//String accountStatus = shellHomePage.getAccountStatus();
		
		//String accountName = shellHomePage.getDisplayedAccountName();
		
		// Go to Card List
		shellHomePage.goToCardMenuCardList();
		
		shellCardsPage.verifyCardListPage();
		
		shellCardsPage.selectAllAccountsAndActiveCard();		
		
		shellCardsPage.clickSearchButtonAndValidate();
		
		boolean isNoCardsPresent = shellCardsPage.waitForTextToAppear("No Cards found.", 30);
		
		if(!isNoCardsPresent)
		{		
				
			 shellCardsPage.goToReissuePINForAnyActiveCardAndValidate();	 	
		
		}
		// Click Logout		
		loginPage.Logout();
	}

	@Parameters({"clientCountry", "clientName", "cardType"})
	@Test( groups = { "Regression" })
	public void validateOrderNewCardforBlockedAccountWithCustomerUserLogin(@Optional("AT") String clientCountry,
			@Optional("SHELL") String clientName, @Optional("APA") String cardType) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  10  Card creation for a sub account Customer", "Validate Card creation for subaccount customer");

		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		HomePage homePage = new HomePage(driver, test);
		SHELLHomePage shellHomePage = new SHELLHomePage(driver, test);
		SHELLCardsPage shellCardsPage = new SHELLCardsPage(driver, test);

		// Calling Login Functions And Validate
		 if(cardType.equals("PC"))
	        {
	        	loginPage.Login("SHLPC_URL", "SHLPC_UN_Customer_User_" + clientCountry, "SHLPC_PWD_Customer_User_" + clientCountry, clientName);
	        }
	        else if(cardType.equals("APA"))
	        {
	        	loginPage.Login("SHLAPA_URL", "SHLAPA_UN_Customer_User_" + clientCountry, "SHLAPA_PWD_Customer_User_" + clientCountry, clientName);
	        }
			homePage.ValidateLogoutLink();
			homePage.ValidateHelpShellLink();
			homePage.ValidateWelcomeText(clientName+"#"+cardType);
			homePage.ValidateQuickLinks();
			shellHomePage.ValidateHeaderMenus("customer user");
			shellHomePage.ValidateFooterMenus();

		String accountStatus = shellHomePage.getAccountStatus();
     	
		shellCardsPage.goToCardMenuAndValidateOrderNewCard(accountStatus);
		// Click Logout
		loginPage.Logout();
	
	}
	
	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test( groups = { "Regression" })
	public void validateCardMenuBlockedAccount(@Optional("AT") String clientCountry,
			@Optional("SHELL") String clientName,  @Optional("APA") String cardType) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  01 Card Menu - Blocked Account in context", "Validate Card creation for blocked subaccount");

		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		HomePage homePage = new HomePage(driver, test);
		SHELLHomePage shellHomePage = new SHELLHomePage(driver, test);
		SHELLCardsPage shellCardsPage = new SHELLCardsPage(driver, test);

		// Calling Login Functions And Validate
		if(cardType.equals("PC"))
        {
        	loginPage.Login("SHLPC_URL", "SHLPC_UN_Customer_Admin_" + clientCountry, "SHLPC_PWD_Customer_Admin_" + clientCountry, clientName);
        }
        else if(cardType.equals("APA"))
        {
        	loginPage.Login("SHLAPA_URL", "SHLAPA_UN_Customer_Admin_" + clientCountry, "SHLAPA_PWD_Customer_Admin_" + clientCountry, clientName);
        }
		homePage.ValidateLogoutLink();
		homePage.ValidateHelpShellLink();
		homePage.ValidateWelcomeText(clientName+"#"+cardType);
		homePage.ValidateQuickLinks();
		shellHomePage.ValidateHeaderMenus("Admin");
		shellHomePage.ValidateFooterMenus();

		String accountStatus = shellHomePage.getAccountStatus();
     	
		shellCardsPage.goToCardMenuAndValidateOrderNewCard(accountStatus);
		
		// Validate quick links
		shellCardsPage.validateOrderCardQuickLinksDisabled(accountStatus);
		
		// Click Logout
		loginPage.Logout();
	
	}
	
	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test( groups = { "Regression" })
	public void validateCardMenuChildAccount(@Optional("AT") String clientCountry,
			@Optional("SHELL") String clientName, @Optional("APA") String cardType) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  02 Card Menu - Child Account in context", "Validate Card creation for subaccount customer");

		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		HomePage homePage = new HomePage(driver, test);
		SHELLHomePage shellHomePage = new SHELLHomePage(driver, test);
		SHELLCardsPage shellCardsPage = new SHELLCardsPage(driver, test);

		// Calling Login Functions And Validate
		if(cardType.equals("PC"))
        {
        	loginPage.Login("SHLPC_URL", "SHLPC_UN_Customer_User_" + clientCountry, "SHLPC_PWD_Customer_User_" + clientCountry, clientName);
        }
        else if(cardType.equals("APA"))
        {
        	loginPage.Login("SHLAPA_URL", "SHLAPA_UN_Customer_User_" + clientCountry, "SHLAPA_PWD_Customer_User_" + clientCountry, clientName);
        }
		homePage.ValidateLogoutLink();
		homePage.ValidateHelpShellLink();
		homePage.ValidateWelcomeText(clientName+"#"+cardType);
		homePage.ValidateQuickLinks();
//		shellHomePage.ValidateHeaderMenus("Admin");
		shellHomePage.ValidateFooterMenus();

		shellHomePage.selectAccountFromDropdownAndValidate();
		
		String accountStatus = shellHomePage.getAccountStatus();
     	
		shellCardsPage.goToCardMenuAndValidateOrderNewCard(accountStatus);
		
		// Validate quick links
		shellCardsPage.validateOrderCardQuickLinksDisabled(accountStatus);
		
		// Click Logout
		loginPage.Logout();
	
	}
	
	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test( groups = { "Regression" })
	public void validateErrorMsgOnEnteringVRNInOrderCardPage(@Optional("AT") String clientCountry,
			@Optional("SHELL") String clientName, @Optional("APA") String cardType) {
		// Covered two test cases its also Parent Account
		test = extent.createTest(clientName+ ":" +clientCountry+"  05 Error Validation VRN is blank along with Driver Name", "VRN in OrderCardPage");

		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		HomePage homePage = new HomePage(driver, test);
		SHELLHomePage shellHomePage = new SHELLHomePage(driver, test);
		SHELLCardsPage shellCardsPage = new SHELLCardsPage(driver, test);

		// Calling Login Functions And Validate
		 if(cardType.equals("PC"))
	     {
	       loginPage.Login("SHLPC_URL", "SHLPC_UN_Customer_Admin_" + clientCountry, "SHLPC_PWD_Customer_Admin_" + clientCountry, clientName);
	     }
	     else if(cardType.equals("APA"))
	     {
	       loginPage.Login("SHLAPA_URL", "SHLAPA_UN_Customer_Admin_" + clientCountry, "SHLAPA_PWD_Customer_Admin_" + clientCountry, clientName);
	     }
		homePage.ValidateLogoutLink();
		homePage.ValidateHelpShellLink();
		homePage.ValidateWelcomeText(clientName+"#"+cardType);
		homePage.ValidateQuickLinks();
		shellHomePage.ValidateHeaderMenus("Admin");
		shellHomePage.ValidateFooterMenus();

		// Go to Card List
		
		shellHomePage.goToCardMenuOrderCard();
		//Fill details of Order Card
		shellCardsPage.enterVRNWronglyAndValidateErrorMsg();
		
		loginPage.Logout();			
	
	}

	
}
