using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using Common;
using Common.PageObjects;
using Common.ScenarioConfigurations;
using Common.Utility;

namespace EnCompass.Testing.Source.PageObjects.SuperAdmin.FiManagement 
{
	/// <summary>
	/// Auto-generated Page Model Class
	/// Navigation Paths: 
		/// [Organization Home]->General->Products
		/// </summary>
	[PageModel(@"/superAdmin/fiManagement/productSubProduct.aspx")]
	public partial class ProductSubProduct : EnCompassSuperPageModel 
	{
		public override string RelativeUrl => @"/superAdmin/fiManagement/productSubProduct.aspx";
		public override string PageIdentifierXPath_Generated => @"//li[contains(@class, 'breadcrumb-item active')][text() = 'Products']";

		#region Navigation
		
		private void NavigateToMenuItem(IWebElement element)
		{
			Driver.Url = element.GetAttribute("href");
		}
		#endregion

		public ProductSubProduct(GlobalSettings settings) : base(settings) { }
	}  
}
