package com.framework.pages.OLS.common;

import java.util.Properties;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.ExtentTest;
import com.framework.basepage.BasePage;
import com.framework.repo.Locator;
import com.framework.util.PropUtils;

public class LoginPage extends BasePage {

	@FindBy(how = How.XPATH, using = Locator.CLIENT_LOGO_IMG)
	public WebElement ChevronLogo;

	@FindBy(how = How.XPATH, using = Locator.BP_LOGO_IMG)
	public WebElement BPLogo;

	@FindBy(how = How.ID, using = Locator.EMAP_LOGO_IMG)
	public WebElement EMAPLogo;

	@FindBy(how = How.XPATH, using = Locator.SHELL_LOGO_IMG)
	public WebElement ShellLogo;
	
	@FindBy(how = How.ID, using = Locator.Z_LOGO_IMG)
	public WebElement ZLogo;

	public WebElement ClientLogo;

	@FindBy(how = How.ID, using = Locator.USERNAME)
	public WebElement username;
	
	/*@FindBy(how = How.XPATH, using = Locator.USERNAME)
	public WebElement username;*/

	@FindBy(how = How.ID, using = Locator.PASSWORD)
	public WebElement password;

	@FindBy(how = How.ID, using = Locator.SIGNIN)
	public WebElement signin;

	@FindBy(how = How.ID, using = Locator.LOGOUT)
	public WebElement logoff;

	@FindBy(how = How.ID, using = Locator.FORGOT_PASSWORD)
	public WebElement ForgotPassword;

	@FindBy(how = How.ID, using = Locator.CONTACT_US)
	public WebElement ContactUs;

	@FindBy(how = How.ID, using = Locator.REQUEST_LOGON)
	public WebElement RequestLogon;

	@FindBy(how = How.ID, using = Locator.LEGAL_NOTICE)
	public WebElement LegalNotice;

	@FindBy(how = How.XPATH, using = Locator.TERMS_AND_CONDITION)
	public WebElement termsAndCondition;

	@FindBy(how = How.ID, using = Locator.PRIVACY_STATEMENT)
	public WebElement PrivacyStatement;

	@FindBy(how = How.XPATH, using = Locator.PRIVACY_STATEMENT_2)
	public WebElement PrivacyStatement2;

	@FindBy(how = How.ID, using = Locator.CH_PRIVACY_STATEMENT)
	public WebElement ChvPrivacyStatement;

	@FindBy(how = How.ID, using = Locator.COPY_RIGHT)
	public WebElement CopyRight;

	@FindBy(how = How.ID, using = Locator.COPY_RIGHT_LINK)
	public WebElement CopyRightLink;

	@FindBy(how = How.ID, using = Locator.COPY_RIGHT_TEXT)
	public WebElement CopyRightText;

	@FindBy(how = How.XPATH, using = Locator.BACKTO_PREVIOUS_PAGE)
	public WebElement backToPreviousPage;

	@FindBy(how = How.ID, using = Locator.APPLICATION_DOWNLOAD_DROPDOWN)
	public WebElement applicationDownloadDropdown;

	@FindBy(how = How.ID, using = Locator.LEGAL_NOTICE_SHELL)
	public WebElement LegalNoticeShell;

	@FindBy(how = How.ID, using = Locator.PRIVACY_STATEMENT_SHELL)
	public WebElement pvcyStatementShell;

	@FindBy(xpath = Locator.LANGUAGE_DROPDOWN_SHELL)
	public WebElement languageDD;

	@FindBy(id = Locator.FOOTER_HOME_LINK)
	public WebElement homeLink;

	@FindBy(id = Locator.DOWNLOAD_FORM)
	public WebElement downloadForm;

	@FindBy(how = How.XPATH, using = Locator.PAGE_TITLE1)
	public WebElement pageTitle;

	@FindBy(how = How.ID, using = Locator.EXXON_MOBIL_LOGO)
	public WebElement exxonLogo;

	@FindBy(how = How.ID, using = Locator.ESSO_LOGO)
	public WebElement essoLogo;

	@FindBy(how = How.ID, using = Locator.MOBIL_LOGO)
	public WebElement mobilLogo;

	@FindBy(how = How.ID, using = Locator.CONTACT_US_IN_FOOTER)
	public WebElement contactUsInFooter;

	@FindBy(how = How.ID, using = Locator.AGREE_AND_CONTINUE)
	public WebElement agreeAndContinue;

	@FindBy(how = How.ID, using = Locator.DISAGREE_TO_TERMS_AND_CONDITION)
	public WebElement disagreeToTermsAndCondition;

	@FindBy(how = How.XPATH, using = Locator.LOGINERR)
	public WebElement loginError;
	
	@FindBy(how = How.ID, using = Locator.CH_LEGAL_NOTICE)
	public WebElement legalNotice;
	
	@FindBy(how = How.ID, using = Locator.Z_LEGAL_NOTICE)
	public WebElement onlineUserGuide;
	
	@FindBy(how = How.ID, using = Locator.Z_PRIVACY_POLICY)
	public WebElement privacyPolicy;
	
	@FindBy(how = How.ID, using = Locator.Z_HOME)
	public WebElement zHome;
	
	@FindBy(how = How.ID, using = Locator.Z_CONTACT_US)
	public WebElement zContactUs;
	
	@FindBy(how = How.ID, using = Locator.USERID)
	public WebElement userID;
	
	public Properties pointPropertiesfile = null;
	//public String clientName;
	
	@FindBy(how = How.ID, using = Locator.AGREE_AND_CONTINUE)
	public WebElement agreeToTermsAndCondition;
	
	@FindBy(how = How.ID, using = Locator.TOPUSERDD)
	public WebElement userdropdown;

	private String clientCountry,clientName;

	//String cardType;
	
	@FindBy(how = How.ID, using = Locator.ACCOUNTS_DROPDOWN)
	public WebElement accountsDropDown;	
	
	@FindBy(how = How.ID, using = Locator.OTI_LOGO)
	public WebElement otiLogo;

	//private String clientCountry;
	// private String titleExp = "", cpyRightExp = "", userNameLog = "",
	// passwordLog
	// = "";

	public LoginPage(WebDriver driver, ExtentTest test) {
		super(driver, test);
		PageFactory.initElements(driver, this);
	}

	public void OpenOLSApplicationWithoutLogin(String url) {
		//driver.get(PropUtils.getPropValue(configProp, url));
		getURL(PropUtils.getPropValue(configProp, url));
		sleep(5);
		logPass("URL Loaded : " + driver.getTitle());
	}

	public void Login(String url, String uname, String Pwd, String ClientName) {
		// Initialize Elements

		System.out.println("------- url ------------" + url);
		System.out.println("------- uname ------------" + uname);
		System.out.println("------- Pwd ------------" + Pwd);
		System.out.println("------- ClientName ------------" + ClientName);

		try {
			clientName = ClientName;
			clientCountry = splitClientCountryFromUsername(uname);
			System.out.println("PROP URL VALUE ------ " + PropUtils.getPropValue(configProp, url));

			//driver.get(PropUtils.getPropValue(configProp, url));
			logInfo(PropUtils.getPropValue(configProp, url));
			getURL(PropUtils.getPropValue(configProp, url));
			driver.navigate().refresh(); // Added as work around for handling Timeout Renderer Issue
			//((JavascriptExecutor) driver).executeScript("return document.readyState").toString().equals("complete");
			PropUtils.setProps(configProp, "Client_Name", ClientName);

			// Uncomment the below if you see any IE certificate exceptions
			/*
			 * if(getBrowserDetails().contains("INTERNET")) {
			 * driver.navigate().to
			 * ("javascript:document.getElementById('overridelink').click()"); }
			 */

			PageFactory.initElements(driver, this);
			logInfo("Client Name: "+clientName+" Client Country:"+clientCountry);
			/*if (ClientName.equals("BP") || (ClientName.equals("BPPREPAID"))) {
				ClientLogo = BPLogo;
			} else if (ClientName.equals("EMAP")) {
				ClientLogo = EMAPLogo;
			} else if (ClientName.equals("SHELL")) {
				ClientLogo = ShellLogo;
			} else if (ClientName.equals("ZEnergy")) {
				ClientLogo = ZLogo; 
			} else if (ClientName.equals("OTI")) {
				ClientLogo = otiLogo; 
			} 
			else  {
				ClientLogo = ChevronLogo;
			}
			
			isDisplayed(ClientLogo, "Client Logo");
		//	System.out.println("New Logo Title : " + PropUtils.getPropValue(configProp, ClientName + "_Title"));

			if (ClientName.equals("BP") || (ClientName.equals("BPPREPAID"))) {
				if (ClientLogo.getText().equals(PropUtils.getPropValue(configProp, ClientName + "_Title")) || ClientLogo
						.getText().equals(PropUtils.getPropValue(configProp, ClientName + "_Title_FuelCard"))) {
					logPass("Logo Title Verification Passed : " + ClientLogo.getText());
				} else {
					logFail("Logo Title Verification Failed : " + ClientLogo.getText());
				}
			} else if (ClientName.equals("EMAP")) {
				if (ClientLogo.getText().equals(PropUtils.getPropValue(configProp, ClientName + "_Title")) || ClientLogo
						.getText().equals(PropUtils.getPropValue(configProp, ClientName + "_Title_FuelCard"))) {
					logPass("Logo Title Verification Passed : " + ClientLogo.getText());
				} else {
					logFail("Logo Title Verification Failed : " + ClientLogo.getText());
				}
			}

			else if (ClientName.equals("SHELL") || ClientName.equals("ZEnergy")) {

				logInfo("Logo title is not present");
			}

			else if (ClientName.equals("CHV")){
				isDisplayed(ChevronLogo, "Chevron Logo is displayed");
				// Write Chevron Loginc here
			}

			isDisplayed(ForgotPassword, "Forgot Password Link");

			if (ClientName.equals("BP") || ClientName.equals("EMAP") || (ClientName.equals("BPPREPAID")) || ClientName.equals("ZEnergy")) {
				isDisplayed(ContactUs, "Contact Us Link");

			//	isDisplayed(RequestLogon, "Request Logon Link");
			}

			if (ClientName.equals("EMAP")) {
				isDisplayed(termsAndCondition, "Terms and Condition");
				isDisplayed(PrivacyStatement2, "Privacy Statement");

				// Copyright
				//isDisplayedThenClick(CopyRightLink, "Copy Right Link");
			     JSClick(CopyRightLink, "Copy Right Link");
				sleep(3);
				if (CopyRightText.getText().contains(PropUtils.getPropValue(configProp, ClientName + "_CopyRight"))) {
					logPass("Copy Right Text Verification Passed : " + CopyRight.getText());
				} else {
					logFail("Copy Right Text Verification Failed : " + CopyRight.getText());
				}
				sleep(3);
				//isDisplayedThenClick(backToPreviousPage, "Back to previous page");
				JSClick(backToPreviousPage, "Back to previous page");
				sleep(4);

				// Application Form Dropdown
				isDisplayed(applicationDownloadDropdown, "Application download dropdown");
				isDisplayed(downloadForm, "Download Form");
				String selectedDropdownValue = selectedStringFrmDropDown(applicationDownloadDropdown);
				if (!(selectedDropdownValue.equals("Customer Application Form"))) {
					logFail("Customer Application form option not hcoosen as default");
				}

				// Contact us
				//isDisplayedThenActionClick(contactUsInFooter, "Contact us");
				sleep(4);
				JSClick(contactUsInFooter, "Contact us");
				sleep(2);
				verifyText(pageTitle, "Contact us");
				//isDisplayedThenClick(ClientLogo, "Back to login");
				JSClick(ClientLogo, "Back to login");

			} else if (ClientName.equals("BP") || (ClientName.equals("BPPREPAID"))) {
				isDisplayed(LegalNotice, "Legal Notice Link");
				isDisplayed(PrivacyStatement, "Privacy Statement Link");
				isDisplayed(CopyRight, "Copy Right Link");
				if (CopyRight.getText().contains(PropUtils.getPropValue(configProp, ClientName + "_CopyRight"))) {
					logPass("Copy Right Text Verification Passed : " + CopyRight.getText());
				} else {
					logFail("BP Copy Right Text Verification Failed : " + CopyRight.getText());
				}
			}

			else if (ClientName.equals("SHELL")) {
				isDisplayed(LegalNoticeShell, "Legal Notice Link - SHELL");
				isDisplayed(pvcyStatementShell, "Privacy Statement Link- SHELL");
				isDisplayed(homeLink, "Home Link- SHELL");
				isDisplayed(languageDD, "Language Drop down");
				selectOptionByVisibleText(languageDD, "English (Malaysia)"); // Need
																				// to
																				// update
																				// this
																				// logic
																				// based
																				// on
																				// the
																				// country.
				sleep(2);
			} else if (ClientName.equals("ZEnergy")) {
				isDisplayed(zHome,"Home Link");
				isDisplayed(zContactUs,"Contact Us");
				//isDisplayed(onlineUserGuide, "Online User Guide Link");
				isDisplayed(privacyPolicy, "Privacy Policy Link");
				isDisplayed(CopyRight, "Copy Right Link");
				if (CopyRight.getText().contains(PropUtils.getPropValue(configProp, ClientName + "_CopyRight"))) {
					logPass("Copy Right Text Verification Passed : " + CopyRight.getText());
				} else {
					logFail("Z Copy Right Text Verification Failed : " + CopyRight.getText());
				}
			}
			
			else if	(ClientName.equals("OTI")) {
				isDisplayed(zHome,"Home Link");
				isDisplayed(zContactUs,"Contact Us");
				isDisplayed(LegalNoticeShell, "Legal Notice Link");
				isDisplayed(privacyPolicy, "Privacy Policy Link");
				isDisplayed(CopyRight, "Copy Right Link");
			}

			// validateDisplayed(, "");
*/
			if (username.isDisplayed()) {
				username.clear();
				username.sendKeys(PropUtils.getPropValue(configProp, uname));
				System.out.println(PropUtils.getPropValue(configProp, uname));
				logInfo("User Name " + PropUtils.getPropValue(configProp, uname) + " is Entered");
			} else {
				logFail("User Name Field is Not Displayed");
			}

			if (password.isDisplayed()) {
				password.clear();
				password.sendKeys(PropUtils.getPropValue(configProp, Pwd));
				// PropUtils.getPropValue(configProp, "PWD")
				System.out.println(PropUtils.getPropValue(configProp, Pwd));
				logInfo("password " + Pwd + " is Entered");
			} else {
				logFail("Password Field is Not Displayed");
			}

			if (signin.isDisplayed()) {
				signin.click();
				logInfo("Clicked on Login");
			} else {
				logFail("Login button is Not Displayed");
			}

			if (ClientName.equals("EMAP")) {
				try {
					Thread.sleep(5000);
					if (pageTitle.getText().contains("Terms and Conditions")) {
						agreeAndContinue.click();
					}
				} catch (Exception ex) {
					logInfo("Agree to terms page not came");
				}
			}
		} catch (Exception e) {
			logFail(e.getMessage());
		}

	}

	public void validateLoginPageFooterLinks(String clientName, String url) {
		/*try {
			System.out.println("PROP URL VALUE ------ " + PropUtils.getPropValue(configProp, url));
*/
			/*//driver.get(PropUtils.getPropValue(configProp, url));
			getURL(PropUtils.getPropValue(configProp, url));
			PageFactory.initElements(driver, this);

			if (clientName.equals("BP")) {
				ClientLogo = BPLogo;
			} else if (clientName.equals("EMAP")) {
				ClientLogo = EMAPLogo;
			} else if (clientName.equals("SHELL")) {
				ClientLogo = ShellLogo;
			} else {
				ClientLogo = ChevronLogo;
			}

			sleep(5);

			isDisplayed(ClientLogo, "Client Logo");
			if (clientName.equals("EMAP")) {
				// Application Form Dropdown
				isDisplayed(applicationDownloadDropdown, "Application download dropdown");
				isDisplayed(downloadForm, "Download Form");
				String selectedDropdownValue = selectedStringFrmDropDown(applicationDownloadDropdown);
				if (!(selectedDropdownValue.equals("Customer Application Form"))) {
					logFail("Customer Application form option not hcoosen as default");
				}
				scrollDownPage();

				// Contact us
			//	isDisplayedThenClick(contactUsInFooter, "Contact us");
				JSClick(contactUsInFooter, "Contact us");
		        sleep(2);
				verifyText(pageTitle, "Contact us");
				  sleep(2);
				//scrollUpPage();
				isDisplayedThenClick(ClientLogo, "Back to login");
				//JSClick(ClientLogo, "Back to login");
				sleep(5);
				// Client Logo
				isDisplayedThenClick(exxonLogo, "Exxon Logo");
				sleep(2);
				if (!(driver.getCurrentUrl().contains("corporate.exxonmobil.com"))) {
					logFail("Exxon mobil site not redirecting");
				}
				driver.navigate().back();

				isDisplayedThenClick(essoLogo, "ESSO Logo");
				sleep(2);
			//	if (!(driver.getCurrentUrl().contains("esso.com.sg"))) {
				//	logFail("ESSO site not redirecting");
				//}
				driver.navigate().back();

				isDisplayedThenClick(mobilLogo, "Mobil Logo");
				sleep(2);
				if (!(driver.getCurrentUrl().contains("mobil.com"))) {
					logFail("Mobil site not redirecting");
				}
				driver.navigate().back();
				sleep(2);*/
/*
			}
		} catch (Exception e) {
			logFail(e.getMessage());
		}*/
	}

	public void validateErrorMessage(String expectedErrorMsg) {
		//System.out.println(getText(loginError));
		if (getText(loginError).equals(expectedErrorMsg)) {
			logPass("Expected error message displayed");
		} else {
			logFail("Expected error message not displayed");
		}
	}

	public void loginWithUsernameAndPwd(String uname, String pwd) {
		isDisplayedThenEnterText(username, "User name", uname);
		System.out.println("Username: " + uname);
		isDisplayedThenEnterText(password, "Password", pwd);
		System.out.println("Password: " + pwd);
		sleep(5);
		isDisplayedThenClick(signin, "Login");
		// isDisplayedThenClick(signin, "Login");
		sleep(5);
	}

	public void validateErrorMsgEmptyUsernameAndPassword() {
		isDisplayedThenClick(signin, "Login");
		validateErrorMessage("Invalid entry User ID: must not be blank.");
	}

	public void validateErrorMsgValidUsernameAndWrongPassword() {
		validateErrorMessage("Validation failed User ID: must not be blank.");
	}
	public void validateErrorMsgWrongUsernameAndValidPassword() {
		validateErrorMessage("Invalid Online User ID");
		
	}
	

	public void validateErrorMsgValidUsernameAndWrongPasswordAccountLock() {
		validateErrorMessage("Invalid logon attempt. Userid is now temporarily locked.");
	}

	public void validateErrorMsgAccountLock() {
		validateErrorMessage("User is temporarily locked");
	}

	public void verifyHyperlinkPresent() {
		sleep(3);
		isDisplayed(ForgotPassword, "Forgot Password Hyperlink is present");
		isDisplayed(ContactUs, "Contact Us Hyperlink is present");
		isDisplayed(RequestLogon, "Request Logon Hyper link is present");
	}
	
	public void verifyFooterHyperlinkPresent() {
		sleep(3);
		isDisplayed(contactUsInFooter, "contactUs Footer Hyperlink is present");
		isDisplayed(legalNotice, "legal Notice terms Hyperlink is present");
		isDisplayed(ChvPrivacyStatement, "Chv Privacy Statement Hyper link is present");
	}
	
	public void loginAndDisagree(String uname, String pwd) {
		try {
			//driver.navigate().back(); //Back to login page added by senthil 24/02/2020  //RM commented
		//	waitUntilElementDisplayed(username);
			isDisplayedThenEnterText(username, "User name", PropUtils.getPropValue(configProp, uname));
			isDisplayedThenEnterText(password, "Password", PropUtils.getPropValue(configProp, pwd));
			isDisplayedThenClick(signin, "Login");
			if (pageTitle.getText().contains("Terms and Conditions")) {
				disagreeToTermsAndCondition.click();
			}
		} catch (Exception ex) {
			logInfo("Dissgree to terms page not arrived");
		}
		sleep(5);
		//isDisplayed(username, "Username");
	}

	private String splitClientCountryFromUsername(String username) {
		// TODO Auto-generated method stub
		
		String clientCountry=null;
	    clientCountry=username.substring(username.length()-2);
		
	    return clientCountry;
	}


	public void Logout() {

		System.out.println("comes inside Logout");
		
		// Initialize Elements
		PageFactory.initElements(driver, this);
		
		System.out.println(clientName+" ----- is ------");
		System.out.println(clientCountry+"---------------is Client Country ------------");
		sleep(5);

		// MouseHover(usermenu);
//		isDisplayedThenClick(logoff, "Logout");
		JavascriptExecutor executor = (JavascriptExecutor) driver;
		executor.executeScript("arguments[0].click();", logoff);
		
		System.out.println(clientName+" ----- is ------");

		if (clientCountry.equals("AU") && clientName.equals("BP")) {
			System.out.println("------");
			sleep(5);
			System.out.println("---- driver.getCurrentUrl() ----- "+driver.getCurrentUrl());
			/*if ((!driver.getCurrentUrl().contains("bp.com")) && (!(driver.getCurrentUrl().contains("/products-services/bp-plus-card.html")))) {
				logFail("BP - User account not logged out");
			}
		} else {
			isDisplayed(username, "Redirected to Login, Logout");
		}

		/*
		 * if (username.isDisplayed()) { logPass("Logout Successful"); } else {
		 * logFail("Logout Failed"); }
		 */
		//isDisplayed(username, "Redirected to Login, Logout");
		
		driver.navigate().refresh();
	}
	}
	public void LogoutSession() {

		System.out.println("comes inside Logout");
		
		// Initialize Elements
		PageFactory.initElements(driver, this);
		
		System.out.println(clientName+" ----- is ------");
		System.out.println(clientCountry+"---------------is Client Country ------------");
		sleep(5);

		// MouseHover(usermenu);
		//isDisplayedThenClick(logoff, "Logout");
		try {
			if (logoff.isDisplayed()) {
				logoff.click();
				logPass( " Log off Displayed and Clicked on it.");
			} else {
				logInfo( "Log off  is Not Displayed");
			}	
		}catch(NoSuchElementException ex) {
			logInfo( "Log off  is Not Displayed");
		}catch(WebDriverException ex) {
			System.out.println("Click using javascript");
			logPass( " Log off Displayed and Clicked on it.");
			((JavascriptExecutor) driver).executeScript("arguments[0].click();", logoff);
		}
		
		
		System.out.println(clientName+" ----- is ------");

		if (clientCountry.equals("AU") && clientName.equals("BP")) {
			System.out.println("------");
			//sleep(5);
			System.out.println("---- driver.getCurrentUrl() ----- "+driver.getCurrentUrl());
			/*if ((!driver.getCurrentUrl().contains("bp.com")) && (!(driver.getCurrentUrl().contains("/products-services/bp-plus-card.html")))) {
				logFail("BP - User account not logged out");
			}
		} else {
			isDisplayed(username, "Redirected to Login, Logout");
		}*/
		}

		/*
		 * if (username.isDisplayed()) { logPass("Logout Successful"); } else {
		 * logFail("Logout Failed"); }
		 */
		//isDisplayed(username, "Redirected to Login, Logout");
		
		driver.navigate().refresh();
	
	}
	
	public void validateLoginPage()
	{
		checkTextInPageAndValidate("Login", 30);
		sleep(3);
		isDisplayed(username, "Redirected to Login Page, User Name Text box is present");
		isDisplayed(password, "Password Text box is present");
		isDisplayed(signin, "Signin button is present");
		
	}
	
	private String getDBDetailsFromProperties = "";

	public void resetLogonCountAsZeroForUser(String lockedUser) {
		getDBDetailsFromProperties = PropUtils.getPropValue(configProp, "sqlODSServerName");
		String queryToResetLogonCount = "UPDATE INTERNET_USERS SET FAILED_LOGON_COUNT='0', LOGON_STATUS_CID = '2505' WHERE LOGON_ID = '"
				+ lockedUser + "'";
		executeQueryAndCommit(queryToResetLogonCount, getDBDetailsFromProperties);
	}
	
	public void SuperUserLogin(String url,String SuperUserId, String uname, String Pwd, String ClientName) {
		// Initialize Elements

		System.out.println("------- url ------------" + url);
		System.out.println("------- uname ------------" + SuperUserId);
		System.out.println("------- uname ------------" + uname);
		System.out.println("------- Pwd ------------" + Pwd);
		System.out.println("------- ClientName ------------" + ClientName);

		try {
			clientName = ClientName;
			clientCountry = splitClientCountryFromUsername(uname);
			System.out.println("PROP URL VALUE ------ " + PropUtils.getPropValue(configProp, url));

			
			driver.get(PropUtils.getPropValue(configProp, url));
			PropUtils.setProps(configProp, "Client_Name", ClientName);

			
			PageFactory.initElements(driver, this);

			if (ClientName.equals("ZEnergy")) {
				ClientLogo = ZLogo; 
			} else {
				ClientLogo = ChevronLogo;
			}

			isDisplayed(ForgotPassword, "Forgot Password Link");

			if (ClientName.equals("ZEnergy")) {
				isDisplayed(ContactUs, "Contact Us Link");

				isDisplayed(RequestLogon, "Request Logon Link");
			}

			if (ClientName.equals("ZEnergy")) {
				isDisplayed(zHome,"Home Link");
				isDisplayed(zContactUs,"Contact Us");
				//isDisplayed(onlineUserGuide, "Online User Guide Link");
				isDisplayed(privacyPolicy, "Privacy Policy Link");
				isDisplayed(CopyRight, "Copy Right Link");
				if (CopyRight.getText().contains(PropUtils.getPropValue(configProp, ClientName + "_CopyRight"))) {
					logPass("Copy Right Text Verification Passed : " + CopyRight.getText());
				} else {
					logFail("Z Copy Right Text Verification Failed : " + CopyRight.getText());
				}
			}

			// validateDisplayed(, "");

			if (username.isDisplayed()) {
				username.clear();
				username.sendKeys(PropUtils.getPropValue(configProp, SuperUserId));
				logPass("User Name " + PropUtils.getPropValue(configProp, SuperUserId) + " is Entered");
			} else {
				logFail("User Name Field is Not Displayed");
			}

			if (password.isDisplayed()) {
				password.clear();
				password.sendKeys(PropUtils.getPropValue(configProp, Pwd));
				// PropUtils.getPropValue(configProp, "PWD")
				logPass("password " + Pwd + " is Entered");
			} else {
				logFail("Password Field is Not Displayed");
			}
			
			if (userID.isDisplayed()) {
				userID.clear();
				userID.sendKeys(PropUtils.getPropValue(configProp, uname));
				logPass("user ID " + PropUtils.getPropValue(configProp, uname) + " is Entered");
			} else {
				logFail("user ID Field is Not Displayed");
			}			
			

			if (signin.isDisplayed()) {
				signin.click();
				logInfo("Clicked on Login");
			} else {
				logFail("Login button is Not Displayed");
			}

			if (ClientName.equals("EMAP")) {
				try {
					if (pageTitle.getText().contains("Terms and Conditions")) {
						//agreeAndContinue.click();
						JSClick(agreeAndContinue,"Terms and Conditions");
					}
				} catch (Exception ex) {
					logInfo("Agree to terms page not came");
				}
			}
		} catch (Exception e) {
			logFail(e.getMessage());
		}

	}
	
	// Added by Ayub 06-02-2019
	
	public void loginWithSuperUserIdAndUserIdAndPwd(String SuperUserId, String uname, String Pwd) {
		isDisplayedThenEnterText(username, "User name", SuperUserId);
		System.out.println("Username: " + SuperUserId);
		isDisplayedThenEnterText(password, "Password", Pwd);
		System.out.println("Password: " + Pwd);
		isDisplayedThenEnterText(userID, "User Id", uname);
		System.out.println("Password: " + uname);
		sleep(5);
		isDisplayedThenClick(signin, "Login");
		// isDisplayedThenClick(signin, "Login");
		sleep(5);
	}
	
	public void validateErrorMsgValidSuperUserIdAndUserIdAndEmptyPassword() {
		validateErrorMessage("Validation failedPassword: must not be blank.");
	}
	
	public void validateErrorMsgValidSuperUserIdAndUserIdAndInvalidPassword() {
		validateErrorMessage("Validation failedPassword:Please enter correct existing password");
	}
	
	public void validateErrorMsgValidSuperUserIdAndInvalidUserIdAndPassword() {
		validateErrorMessage("Validation failedUser ID:Invalid online user ID");
	}	

	public void loginAndAgree(String uname, String pwd) {
		try {
			isDisplayedThenEnterText(username, "User name", PropUtils.getPropValue(configProp, uname));
			isDisplayedThenEnterText(password, "Password", PropUtils.getPropValue(configProp, pwd));
			isDisplayedThenClick(signin, "Login");
			if (pageTitle.getText().contains("Terms and Conditions")) {
				//agreeToTermsAndCondition.click();
			}
		} catch (Exception ex) {
			logInfo("Agree to terms page not arrived");
		}
		sleep(5);
		//isDisplayed(userdropdown, "Username");
		
	}
	
	public void loginAndValidateDisagree(String uname, String pwd) {
		try {
			isDisplayedThenEnterText(username, "User name", uname);
			System.out.println("Username: " + uname);
			isDisplayedThenEnterText(password, "Password", pwd);
			System.out.println("Password: " + pwd);
			if (pageTitle.getText().contains("Terms and Conditions")) {
				disagreeToTermsAndCondition.click();
			}
		} catch (Exception ex) {
			logInfo("Dissgree to terms page not arrived");
		}
		sleep(5);
		isDisplayed(username, "Username");
	}
	
public void validateAgreeAndLogonUser(String merchantNo) {
	
	clientName 	    = PropUtils.getPropValue(configProp, "clientName");
	clientCountry   = PropUtils.getPropValue(configProp, "clientCountry");
		
		if (pageTitle.getText().contains("Terms and Conditions")) {
			isDisplayedThenClick(agreeToTermsAndCondition, "agreeToTermsAndCondition");
//			agreeToTermsAndCondition.click();
		}
		
		String dropDownValue = selectedStringFrmDropDown(accountsDropDown);
		System.out.println("********::"+dropDownValue+"**********************"+merchantNo);
		if(dropDownValue.contains(merchantNo)) {
			logPass("Successfully login with the valid newly created user"+merchantNo+dropDownValue);
		}else {
			logFail("Login with differnt user");
		}
	}

public void validateOlsLogonUser(String merchantNo) {
		
		clientName    = PropUtils.getPropValue(configProp, "clientName");
		clientCountry   = PropUtils.getPropValue(configProp, "clientCountry");
		
		String dropDownValue = selectedStringFrmDropDown(accountsDropDown);
		System.out.println("********::"+dropDownValue+"**********************"+merchantNo);
		if(dropDownValue.contains(merchantNo)) {
			logPass("Successfully login with the valid newly created user"+merchantNo+dropDownValue);
		}else {
			logFail("Login with differnt user");
		}
	}



}
