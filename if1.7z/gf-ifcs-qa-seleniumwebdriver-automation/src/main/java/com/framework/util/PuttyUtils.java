package com.framework.util;



import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.Vector;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpATTRS;
import com.jcraft.jsch.SftpException;

public class PuttyUtils {
	
    static String localDir = System.getProperty("user.home")+System.getProperty("file.separator")+"Documents"+System.getProperty("file.separator");
    //Establish the Putty Connection 
	public static void puttyConnection(String fileAccess,String host,String user,String password,String remoteDir,String file) {
		String zipFileName;
	System.out.println("Remote Directory Path"+remoteDir+"\\"+file);
    System.out.println("localDir::" +localDir);
	try 
	{
	Properties config = new Properties();
	config.put("StrictHostKeyChecking", "no");
	JSch jsch = new JSch();
	// Create a JSch session to connect to the server
	Session session = jsch.getSession(user, host, 22);

	session.setPassword(password);
	session.setConfig(config);
	session.setConfig("PreferredAuthentications", "publickey,keyboard-interactive,password");
	// Establish the connection
	session.connect();
	System.out.println("Connected...");
	ChannelSftp sftpChannel = (ChannelSftp) session.openChannel("sftp");
	sftpChannel.connect();
	System.out.println("Remote Dir is"+remoteDir);
	System.out.println("Local Directory is"+localDir);
	sftpChannel.cd(remoteDir);
//	sftpChannel.lcd(localDir);
	if(fileAccess.equals("incomingFile")) {
		//System.out.println("Inside if Statement");
		sftpChannel.get(file,localDir);//Dynamic process
//		sftpChannel.get("PVSI0070.XMT",localDir);//For Development we didnot run the ControlM Jobs,so we have hardcoded  here
	}  else if(fileAccess.contains("XML") || fileAccess.contains("Zip")) {
		String splitName = file.split("\\.")[0];
		zipFileName = splitName+".zip";
		zipFile(localDir+file, localDir+zipFileName);
		sftpChannel.put(localDir+zipFileName,remoteDir);
		Thread.sleep(10);

		}  else if(fileAccess.contains("unzip")) {
		System.out.println("******************** INSIDE UNZIP ***************");
		String zipFilePath = remoteDir + file;
		System.out.println("******************** INSIDE UNZIP *************zipFilePath::"+zipFilePath);
		sftpChannel.get(file,localDir);
		String localFilePath = localDir + file;
		unzip(localFilePath, localDir);
		Thread.sleep(10);
	}
	else {
		//System.out.println("Inside put statement");
		System.out.println("RemoteDirectory is "+remoteDir);
		System.out.println("File is "+file);
		sftpChannel.put(file,remoteDir);
		
	}
	sftpChannel.exit();
	session.disconnect();

	System.out.println("DONE MOVING FILE TO LOCATION!!!");
	} catch (Exception e) {
	e.printStackTrace();
	}
	
	}
	
	public static boolean puttyConnectionAndCheckFilePresence(String host,String user,String password,String remoteDir,String filePattern) {
		boolean fileFound=false;
		System.out.println("Remote Directory Path"+remoteDir+"\\");
	    System.out.println("localDir::" +localDir);
		try 
		{
		Properties config = new Properties();
		config.put("StrictHostKeyChecking", "no");
		JSch jsch = new JSch();
		// Create a JSch session to connect to the server
		Session session = jsch.getSession(user, host, 22);

		session.setPassword(password);
		session.setConfig(config);
		session.setConfig("PreferredAuthentications", "publickey,keyboard-interactive,password");
		// Establish the connection
		session.connect();
		System.out.println("Connected...");
		ChannelSftp sftpChannel = (ChannelSftp) session.openChannel("sftp");
		sftpChannel.connect();
		System.out.println("Remote Dir is"+remoteDir);
		System.out.println("Local Directory is"+localDir);
		sftpChannel.cd(remoteDir);
//		sftpChannel.lcd(localDir);
		
		try {
			sftpChannel.lstat(filePattern);
		} catch (SftpException e){
		    if(e.id == ChannelSftp.SSH_FX_NO_SUCH_FILE){
		    	fileFound=true;
		    } else {
		    	fileFound=false;
		    }
		}
		sftpChannel.exit();
		session.disconnect();

		
		} catch (Exception e) {
		e.printStackTrace();
		}
		return fileFound;
		}
	

	
	public static String puttyConnectionAndGetLastProcessedFileName(String host,String user,String password,String remoteDir,String filePattern) {
		
	System.out.println("Remote Directory Path"+remoteDir);
    System.out.println("localDir::" +localDir);
    String fileName="";
	try 
	{
	Properties config = new Properties();
	config.put("StrictHostKeyChecking", "no");
	JSch jsch = new JSch();
	// Create a JSch session to connect to the server
	Session session = jsch.getSession(user, host, 22);

	session.setPassword(password);
	session.setConfig(config);
	session.setConfig("PreferredAuthentications", "publickey,keyboard-interactive,password");
	// Establish the connection
	session.connect();
	System.out.println("Connected...");
	ChannelSftp sftpChannel = (ChannelSftp) session.openChannel("sftp");
	sftpChannel.connect();
	System.out.println("Remote Dir is"+remoteDir);
	System.out.println("Local Directory is"+localDir);
	sftpChannel.cd(remoteDir+"//Archive");
	fileName=latestFileFullPath(sftpChannel,filePattern);
		
	
	sftpChannel.exit();
	session.disconnect();

	
	} catch (Exception e) {
	e.printStackTrace();
	}
	//System.out.println("File Path is "+fileName);
	return fileName;
	}
	
	public static String latestFile(ChannelSftp chanSftp,String filePattern) {
	    Vector<?> list = null;
	    int currentOldestTime;
	    int nextTime = 2140000000;
	    ChannelSftp.LsEntry lsEntry = null;
	    SftpATTRS attrs = null;
	    String nextName = null;
	    String newestFile = "";
	    try {
	        list = chanSftp.ls("*");
	        if (list.isEmpty()) {
	    	            System.out.println("File Not Found");
	        }
	        else {
	            lsEntry = (ChannelSftp.LsEntry) list.firstElement();
	            newestFile = lsEntry.getFilename();
	            attrs = lsEntry.getAttrs();
	            currentOldestTime = attrs.getMTime();
	            for (Object sftpFile : list) {
	                lsEntry = (ChannelSftp.LsEntry) sftpFile;
	                nextName = lsEntry.getFilename();
	                attrs = lsEntry.getAttrs();
	                nextTime = attrs.getMTime();
	                if (nextTime > currentOldestTime) {
	                	newestFile = nextName;
	                    currentOldestTime = nextTime;
	                }
	            }
	            if(!newestFile.contains(filePattern)) {
	            	 System.out.println("Its a Dir"+newestFile);
	            	chanSftp.cd(newestFile);
	            	newestFile = latestFile(chanSftp,filePattern);
	            }else {
	            	return newestFile;
	            }	
	          
	            
            }
	        
	    } catch (Exception ex) {ex.printStackTrace();}
	    return newestFile;
	}
	
	public static String latestFileFullPath(ChannelSftp chanSftp,String filePattern) {
	    Vector<?> list = null;
	    int currentOldestTime;
	    int nextTime = 2140000000;
	    ChannelSftp.LsEntry lsEntry = null;
	    SftpATTRS attrs = null;
	    String nextName = null;
	    String newestFile = "";
	    try {
	        list = chanSftp.ls("*");
	        if (list.isEmpty()) {
	    	            System.out.println("File Not Found");
	        }
	        else {
	            lsEntry = (ChannelSftp.LsEntry) list.firstElement();
	            newestFile = lsEntry.getFilename();
	            attrs = lsEntry.getAttrs();
	            currentOldestTime = attrs.getMTime();
	            for (Object sftpFile : list) {
	                lsEntry = (ChannelSftp.LsEntry) sftpFile;
	                nextName = lsEntry.getFilename();
	                attrs = lsEntry.getAttrs();
	                nextTime = attrs.getMTime();
	                if (nextTime > currentOldestTime) {
	                	newestFile = nextName;
	                    currentOldestTime = nextTime;
	                }
	            }
	            if(!newestFile.contains(filePattern)) {
	            	chanSftp.cd(newestFile);
	            	newestFile = latestFileFullPath(chanSftp,filePattern);
	            }else {
	            	return chanSftp.pwd()+"/"+newestFile;
	            }	
	          
	            
            }
	        
	    } catch (Exception ex) {ex.printStackTrace();}
	    return newestFile;
	}
	
	private static void zipFile(String filePath, String zipName) {
        
    	//System.out.println("Getting into Zip method");
    	System.out.println("FilePath ---"+filePath);
    	System.out.println("ZipName ---"+zipName);
    	
    	byte[] buffer = new byte[1024];
    	
    	try{
    		
    		File archievefile = new File(filePath);
    		
    		String archieveFileName = archievefile.getName();
    		
    		FileOutputStream fos = new FileOutputStream(zipName);
    		ZipOutputStream zos = new ZipOutputStream(fos);
    		ZipEntry ze= new ZipEntry(archieveFileName);
    		zos.putNextEntry(ze);
    		FileInputStream in = new FileInputStream(filePath);
   	   
    		int len;
    		while ((len = in.read(buffer)) > 0) {
    			zos.write(buffer, 0, len);
    		}

    		in.close();
    		zos.closeEntry();
           
    		//remember close it
    		zos.close();
          
    		//System.out.println("Done");

    	}catch(IOException ex){
    	 ex.printStackTrace();
    	}
        
	}
	
	private static void unzip(String zipFilePath, String destDir) {
        File dir = new File(destDir);
        // create output directory if it doesn't exist
        if(!dir.exists()) dir.mkdirs();
        FileInputStream fis;
        //buffer for read and write data to file
        byte[] buffer = new byte[1024];
        try {
            fis = new FileInputStream(zipFilePath);
            ZipInputStream zis = new ZipInputStream(fis);
            ZipEntry ze = zis.getNextEntry();
            while(ze != null){
                String fileName = ze.getName();
                File newFile = new File(destDir + File.separator + fileName);
                System.out.println("Unzipping to "+newFile.getAbsolutePath());
                //create directories for sub directories in zip
                new File(newFile.getParent()).mkdirs();
                FileOutputStream fos = new FileOutputStream(newFile);
                int len;
                while ((len = zis.read(buffer)) > 0) {
                fos.write(buffer, 0, len);
                }
                fos.close();
                //close this ZipEntry
                zis.closeEntry();
                ze = zis.getNextEntry();
            }
            //close last ZipEntry
            zis.closeEntry();
            zis.close();
            fis.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        
    }
}
