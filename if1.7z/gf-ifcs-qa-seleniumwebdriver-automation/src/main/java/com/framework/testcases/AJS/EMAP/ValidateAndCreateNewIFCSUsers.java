package com.framework.testcases.AJS.EMAP;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.AdminPage;
import com.framework.pages.AJS.MaintainCustomerPage;
import com.framework.pages.AJS.common.Common;
import com.framework.pages.AJS.common.IFCSHomePage;
import com.framework.pages.AJS.common.IFCSLoginPage;

public class ValidateAndCreateNewIFCSUsers extends BaseTest{
	
	/**
	 * Updated by Davu - 01/04/2020
	 *
	 */

	@Parameters({ "clientCountry", "clientName"})
	@Test( groups = { "Regression" })
	public void validateAndCreateNewIFCSDesktopUser(@Optional("SG") String clientCountry, @Optional("EMAP") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  01 Create a new IFCS Desktop user", "Validate and create 01 Create a new IFCS Desktop user");
		// creating object for the Pages
		IFCSLoginPage ifcsloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage ifcsHomePage = new IFCSHomePage(driver, test);
		AdminPage ifcsAdminPage = new AdminPage(driver, test);
		Common common = new Common(driver, test);
		
		ifcsloginPage.login("IFCS_URL_EMAP", "IFCS_EMAP_USERNAME", "IFCS_EMAP_PASSWORD");
		ifcsloginPage.setClientCountryCardTypeDetails(clientName, clientCountry," ");
		ifcsHomePage.gotoAdminMenuAndChooseClient(clientName+"_"+clientCountry);
		ifcsHomePage.gotoApplicationAndClickApplicationMenu();
		
		// Selecting client from Application Menu
		ifcsHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);
		
		common.searchListTorch();
		
		common.selectFirstRowNumberInSearchList();
		
		common.validateHeaderLabel("Maintain Application");
		
		ifcsHomePage.gotoAdminMenuAndChooseClientGroup();
		
		ifcsAdminPage.chooseDesktopMenuFromSecurityMenu();
		
		String userName = ifcsAdminPage.validateAndCreateNewUsersEnterDetails();
		
		ifcsHomePage.exitIFCS();
		
		ifcsloginPage.loginWithNewUser("IFCS_URL_EMAP",userName, "Password01");
		
		ifcsHomePage.exitIFCS();
		
	}
	
	@Parameters({ "clientCountry", "clientName"})
	@Test( groups = { "Regression" })
	public void validateAndAddCardControlProfile(@Optional("SG") String clientCountry, @Optional("EMAP") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  01 Setup a new client level card control profile for HK", "Validate Setup a new client level card control profile");
		// creating object for the Pages
		IFCSLoginPage ifcsloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage ifcsHomePage = new IFCSHomePage(driver, test);
		MaintainCustomerPage maintainCustomerPage = new MaintainCustomerPage(driver, test);

		ifcsloginPage.login("IFCS_URL_EMAP", "IFCS_EMAP_USERNAME", "IFCS_EMAP_PASSWORD");
		ifcsloginPage.setClientCountryCardTypeDetails(clientName, clientCountry," ");
		ifcsHomePage.gotoAdminMenuAndChooseClient(clientName+"_"+clientCountry);
		ifcsHomePage.gotoClientConfigAndChooseCardControl();
		
		// Need to add card Control profile
		maintainCustomerPage.createMaintainCardControlsProfile(clientCountry);
		
		
	}
}
