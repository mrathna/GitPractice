using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using Common;
using Common.PageObjects;
using Common.ScenarioConfigurations;
using Common.Utility;

namespace EnCompass.Testing.Source.PageObjects.SuperAdmin.Apmanagement 
{
	/// <summary>
	/// Auto-generated Page Model Class
	/// Navigation Paths: 
		/// [Organization Home]->Payables->Accounts Payable->Prefund Solution Payments
		/// </summary>
	[PageModel(@"/superAdmin/APManagement/ACHPayments.aspx")]
	public partial class Achpayments : EnCompassSuperPageModel 
	{
		public override string RelativeUrl => @"/superAdmin/APManagement/ACHPayments.aspx";
		public override string PageIdentifierXPath_Generated => @"//li[contains(@class, 'breadcrumb-item active')][text() = 'Prefunds Payments']";

		#region Navigation
				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Organizations']")]
		private IWebElement _payables_AccountsPayable_PrefundSolutionPayments_Organizations { get; set; }
		public void NavigateTo_Payables_AccountsPayable_PrefundSolutionPayments_Organizations()
		{
			NavigateToMenuItem(_payables_AccountsPayable_PrefundSolutionPayments_Organizations);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Prefund Solution Final Close']")]
		private IWebElement _payables_AccountsPayable_PrefundSolutionPayments_PrefundSolutionFinalClose { get; set; }
		public void NavigateTo_Payables_AccountsPayable_PrefundSolutionPayments_PrefundSolutionFinalClose()
		{
			NavigateToMenuItem(_payables_AccountsPayable_PrefundSolutionPayments_PrefundSolutionFinalClose);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Prefund Solution Payments']")]
		private IWebElement _payables_AccountsPayable_PrefundSolutionPayments_PrefundSolutionPayments { get; set; }
		public void NavigateTo_Payables_AccountsPayable_PrefundSolutionPayments_PrefundSolutionPayments()
		{
			NavigateToMenuItem(_payables_AccountsPayable_PrefundSolutionPayments_PrefundSolutionPayments);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='AP Non-Card Payments']")]
		private IWebElement _payables_AccountsPayable_PrefundSolutionPayments_ApNonCardPayments { get; set; }
		public void NavigateTo_Payables_AccountsPayable_PrefundSolutionPayments_ApNonCardPayments()
		{
			NavigateToMenuItem(_payables_AccountsPayable_PrefundSolutionPayments_ApNonCardPayments);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='EnCircle Enrollment']")]
		private IWebElement _payables_AccountsPayable_PrefundSolutionPayments_EncircleEnrollment { get; set; }
		public void NavigateTo_Payables_AccountsPayable_PrefundSolutionPayments_EncircleEnrollment()
		{
			NavigateToMenuItem(_payables_AccountsPayable_PrefundSolutionPayments_EncircleEnrollment);
		}

		
		private void NavigateToMenuItem(IWebElement element)
		{
			Driver.Url = element.GetAttribute("href");
		}
		#endregion

		public Achpayments(GlobalSettings settings) : base(settings) { }
	}  
}
