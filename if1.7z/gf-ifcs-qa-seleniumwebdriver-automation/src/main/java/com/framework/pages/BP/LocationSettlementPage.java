package com.framework.pages.BP;

import java.util.List;

import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.ExtentTest;
import com.framework.basepage.BasePage;
import com.framework.pages.OLS.common.BPCommonPage;
import com.framework.repo.Locator;

public class LocationSettlementPage extends BasePage {

	public LocationSettlementPage(WebDriver driver, ExtentTest test) {
		super(driver, test);
		// TODO Auto-generated constructor stub
		PageFactory.initElements(driver, this);
	}

	boolean flag;
	boolean isDisplayed;

	@FindBy(id = Locator.ENQUIRY_START_DATE)
	public WebElement startDate;
	@FindBy(id = Locator.SET_LOCATION_NUM)
	public WebElement locationNumber;
	@FindBy(id = Locator.SEARCH_BTN)
	public WebElement searchButton;

	@FindBy(how = How.XPATH, using = Locator.SETTLEMENT_LIST)
	public List<WebElement> settlementList;

	@FindBy(id = Locator.SETTLEMENT_LIST_NOITEM)
	public WebElement noItem;
	@FindBy(id = Locator.BACK_TO_SETTLEMENT_LIST)
	public WebElement backToSettlementList;
	@FindBy(id = Locator.EXPORT_TO_EXCEL_SETT)
	public WebElement exportExcel;
	BPHomePage bpHomePage = new BPHomePage(driver, test);
	BPCommonPage bpCommonPage = new BPCommonPage(driver, test);

	public void findsettlementDetailsForLocation(String clientCountry) {
		if (clientCountry.equals("AU")) {
//			bpHomePage.selectInputFromAccountDropdown("BP Kewdale Terminal T/S  (00002498)");
			bpCommonPage.selectAccount();
			sleep(5);
			isDisplayedThenEnterText(startDate, "Start Date", "08/07/2012");
			isDisplayedThenEnterText(locationNumber, "Location Number", "00002498");
			isDisplayedThenClick(searchButton, "Search Button");
			sleep(5);
		} else if (clientCountry.equals("NZ")) {
			//bpHomePage.selectInputFromAccountDropdown("ACE TYRES LTD  (00009245)");
			bpCommonPage.selectAccount();
			sleep(5);
			isDisplayedThenEnterText(startDate, "Start Date", "31/05/2012");
			isDisplayedThenEnterText(locationNumber, "Location Number", "00009245");
			isDisplayedThenClick(searchButton, "Search Button");
			sleep(5);
		}
	}

	/*
	 * Select a settlement List and View Transactions - Added by Ayub 08-05-2018
	 */
	public void clicksettlementList() {
		int randomNo;
		try {
			if (settlementList.size() > 0) {
				System.out.println("settlemet  size --> " + settlementList.size());
				randomNo = getRandomNumber(0, settlementList.size() - 1);
				actionClick(settlementList.get(randomNo));
				isDisplayed = true;
				sleep(5);
			}
		} catch (NoSuchElementException ex) {
			isDisplayed = false;
			logInfo("No items found");
		}
		
		catch(Exception e)
		{
			logFail(e.getMessage());
		}
		

	}

	public void clickBackToSettlementList() {
		if (isDisplayed) {
			isDisplayedThenClick(backToSettlementList, "Back to Settlement Link");	

		} else {
			logInfo("No Rows are found in Settlment Link, So can't able to find Settlement Link");
		}
	}

	public void clickExportExcel(String text) {
		isDisplayedThenClick(exportExcel, "exportExcel");
		sleep(5);
		verifyTheDownloadedFile(text);
	}
}
