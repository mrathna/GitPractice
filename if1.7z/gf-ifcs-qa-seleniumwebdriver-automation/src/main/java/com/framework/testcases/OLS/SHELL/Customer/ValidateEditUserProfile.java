package com.framework.testcases.OLS.SHELL.Customer;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.OLS.HomePage;
import com.framework.pages.OLS.common.LoginPage;
import com.framework.pages.SHELL.EditUserProfile;
import com.framework.pages.SHELL.SHELLHomePage;

public class ValidateEditUserProfile extends BaseTest  {
	
	@Parameters({"clientCountry","clientName", "cardType"})
	@Test(groups = { "Regression" })
	public void validateEdituserProfile(@Optional("AT") String clientCountry, @Optional("SHELL") String clientName, @Optional("APA") String cardType)  {
		
		test = extent.createTest(clientName+ ":" +clientCountry+"  03 Edit the User profile", "Checking Customer Edit profile page");

        //Creating Objects for the Pages
        LoginPage loginPage = new LoginPage(driver, test);
        HomePage homePage = new HomePage(driver, test);
        SHELLHomePage shellHomePage = new SHELLHomePage(driver, test);
        EditUserProfile editUserProfile = new EditUserProfile(driver, test);
      
		// Calling Functions
        if(cardType.equals("PC"))
        {
        	loginPage.Login("SHLPC_URL", "SHLPC_UN_Customer_User_" + clientCountry, "SHLPC_PWD_Customer_User_" + clientCountry, clientName);
        }
        else if(cardType.equals("APA"))
        {
        	loginPage.Login("SHLAPA_URL", "SHLAPA_UN_Customer_User_" + clientCountry, "SHLAPA_PWD_Customer_User_" + clientCountry, clientName);
        }
		homePage.ValidateLogoutLink();
		homePage.ValidateHelpShellLink();
		homePage.ValidateWelcomeText(clientName+"#"+cardType);
		homePage.ValidateQuickLinks();
		shellHomePage.ValidateHeaderMenus("customer user");
		shellHomePage.ValidateFooterMenus();
		shellHomePage.goToUserProfile(); 
		editUserProfile.verifyUserProfilePage();
		editUserProfile.editProfileAndValidate();
		loginPage.Logout();
      
	}
	
	@Parameters({"clientCountry","clientName", "cardType"})
	@Test(groups = { "Regression" })
	public void validateEditAdminuserProfile(@Optional("AT") String clientCountry, @Optional("SHELL") String clientName, @Optional("APA") String cardType)  {
		
		test = extent.createTest(clientName+ ":" +clientCountry+"  07 Edit a Users profile", "Checking Customer Edit profile page for Admin");

        //Creating Objects for the Pages
        LoginPage loginPage = new LoginPage(driver, test);
        HomePage homePage = new HomePage(driver, test);
        SHELLHomePage shellHomePage = new SHELLHomePage(driver, test);
        EditUserProfile editUserProfile = new EditUserProfile(driver, test);
      
		// Calling Functions
        if(cardType.equals("PC"))
        {
        	loginPage.Login("SHLPC_URL", "SHLPC_UN_Customer_Admin_" + clientCountry, "SHLPC_PWD_Customer_Admin_" + clientCountry, clientName);
        }
        else if(cardType.equals("APA"))
        {
        	loginPage.Login("SHLAPA_URL", "SHLAPA_UN_Customer_Admin_" + clientCountry, "SHLAPA_PWD_Customer_Admin_" + clientCountry, clientName);
        }
		homePage.ValidateLogoutLink();
		homePage.ValidateHelpShellLink();
		homePage.ValidateWelcomeText(clientName+"#"+cardType);
		homePage.ValidateQuickLinks();
		shellHomePage.ValidateHeaderMenus("Admin");
		shellHomePage.ValidateFooterMenus();
		shellHomePage.goToUserProfile(); 
		editUserProfile.verifyUserProfilePage();
		editUserProfile.editProfileAndValidate();
		loginPage.Logout();
      
	}
	
	@Parameters({"clientCountry","clientName", "cardType"})
	@Test(priority =3, groups = { "Regression" })
	public void validateProfileDetailsPage(@Optional("AT") String clientCountry, @Optional("SHELL") String clientName, @Optional("APA") String cardType)  {
		
		test = extent.createTest(clientName+ ":" +clientCountry+"  06 View a Users profile for a customer Admin", "Checking Customer Edit profile page");

        //Creating Objects for the Pages
        LoginPage loginPage = new LoginPage(driver, test);
        HomePage homePage = new HomePage(driver, test);
        SHELLHomePage shellHomePage = new SHELLHomePage(driver, test);
        EditUserProfile editUserProfile = new EditUserProfile(driver, test);
      
		// Calling Functions
        if(cardType.equals("PC"))
        {
        	loginPage.Login("SHLPC_URL", "SHLPC_UN_Customer_Admin_" + clientCountry, "SHLPC_PWD_Customer_Admin_" + clientCountry, clientName);
        }
        else if(cardType.equals("APA"))
        {
        	loginPage.Login("SHLAPA_URL", "SHLAPA_UN_Customer_Admin_" + clientCountry, "SHLAPA_PWD_Customer_Admin_" + clientCountry, clientName);
        }
		homePage.ValidateLogoutLink();
		homePage.ValidateHelpShellLink();
		homePage.ValidateWelcomeText(clientName+"#"+cardType);
		homePage.ValidateQuickLinks();
		shellHomePage.ValidateHeaderMenus("Admin");
		shellHomePage.ValidateFooterMenus();
		shellHomePage.goToUserProfile(); 
		editUserProfile.verifyUserProfilePage();
		editUserProfile.ProfileDetailsPage();
		shellHomePage.goToUserProfile(); 
		loginPage.Logout();
	}	
	
	
	
	// Added by Ayub on 17-07-2018		
	@Parameters({"clientCountry","clientName", "cardType"})
	@Test(groups = { "Regression" })
	public void validateUserProfileDetailsPage(@Optional("BE") String clientCountry, @Optional("SHELL") String clientName, @Optional("APA") String cardType)  {
			
			test = extent.createTest(clientName+ ":" +clientCountry+"  04 Profile Details, 02 View the User profile for a customer user", "Checking User Profile Details");

	        //Creating Objects for the Pages
	        LoginPage loginPage = new LoginPage(driver, test);
	        HomePage homePage = new HomePage(driver, test);
	        SHELLHomePage shellHomePage = new SHELLHomePage(driver, test);
	        EditUserProfile editUserProfile = new EditUserProfile(driver, test);
	      
			// Calling Functions
	        if(cardType.equals("PC"))
	        {
	        	loginPage.Login("SHLPC_URL", "SHLPC_UN_Customer_User_" + clientCountry, "SHLPC_PWD_Customer_User_" + clientCountry, clientName);
	        }
	        else if(cardType.equals("APA"))
	        {
	        	loginPage.Login("SHLAPA_URL", "SHLAPA_UN_Customer_User_" + clientCountry, "SHLAPA_PWD_Customer_User_" + clientCountry, clientName);
	        }
	        
			homePage.ValidateLogoutLink();
			homePage.ValidateHelpShellLink();
			homePage.ValidateWelcomeText(clientName+"#"+cardType);
			homePage.ValidateQuickLinks();
			shellHomePage.ValidateHeaderMenus("customer user");
			shellHomePage.ValidateFooterMenus();
			shellHomePage.goToUserProfile(); 
			editUserProfile.verifyUserProfilePage();
			editUserProfile.ProfileDetailsPage();
			shellHomePage.goToUserProfile(); 
			loginPage.Logout();
		}
    
	@Parameters({"clientCountry","clientName", "cardType"})
	@Test(groups = { "Regression" })
	public void validateEditAdminProfile(@Optional("AT") String clientCountry, @Optional("SHELL") String clientName, @Optional("APA") String cardType)  {
		
		test = extent.createTest(clientName+ ":" +clientCountry+"  04 Edit a Users profile for a customer Admin", "Checking Customer Edit profile page for Admin");

        //Creating Objects for the Pages
        LoginPage loginPage = new LoginPage(driver, test);
        HomePage homePage = new HomePage(driver, test);
        SHELLHomePage shellHomePage = new SHELLHomePage(driver, test);
        EditUserProfile editUserProfile = new EditUserProfile(driver, test);
      
		// Calling Functions
        if(cardType.equals("PC"))
        {
        	loginPage.Login("SHLPC_URL", "SHLPC_UN_Customer_Admin_" + clientCountry, "SHLPC_PWD_Customer_Admin_" + clientCountry, clientName);
        }
        else if(cardType.equals("APA"))
        {
        	loginPage.Login("SHLAPA_URL", "SHLAPA_UN_Customer_Admin_" + clientCountry, "SHLAPA_PWD_Customer_Admin_" + clientCountry, clientName);
        }
		homePage.ValidateLogoutLink();
		homePage.ValidateHelpShellLink();
		homePage.ValidateWelcomeText(clientName+"#"+cardType);
		homePage.ValidateQuickLinks();
		shellHomePage.ValidateHeaderMenus("Admin");
		shellHomePage.ValidateFooterMenus();
		shellHomePage.goToUserProfile(); 
		editUserProfile.verifyUserProfilePage();
		editUserProfile.editProfileAndValidate();
		loginPage.Logout();
      
	}
	
}
