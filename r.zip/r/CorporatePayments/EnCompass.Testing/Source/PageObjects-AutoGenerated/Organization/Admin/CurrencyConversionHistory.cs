using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using Common;
using Common.PageObjects;
using Common.ScenarioConfigurations;
using Common.Utility;

namespace EnCompass.Testing.Source.PageObjects.Organization.Admin 
{
	/// <summary>
	/// Auto-generated Page Model Class
	/// Navigation Paths: 
		/// [Organization Home]->Administration->Conversion Rates
		/// </summary>
	[PageModel(@"/admin/CurrencyConversionHistory.aspx")]
	public partial class CurrencyConversionHistory : EnCompassOrgPageModel 
	{
		public override string RelativeUrl => @"/admin/CurrencyConversionHistory.aspx";
		public override string PageIdentifierXPath_Generated => @"//li[contains(@class, 'breadcrumb-item active')][text() = 'Conversion Rates']";

		#region Navigation
		
		private void NavigateToMenuItem(IWebElement element)
		{
			Driver.Url = element.GetAttribute("href");
		}
		#endregion

		public CurrencyConversionHistory(GlobalSettings settings) : base(settings) { }
	}  
}
