package com.framework.testcases.OLS.SHELL.Customer;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.OLS.HomePage;
import com.framework.pages.OLS.common.LoginPage;
import com.framework.pages.SHELL.EditUserProfile;
import com.framework.pages.SHELL.SHELLAdminPages;
import com.framework.pages.SHELL.SHELLHomePage;
import com.framework.pages.SHELL.SHELLSupportPage;

public class ValidateAdminTestCases extends BaseTest  {
	
	
	//Added By Anton	
	@Parameters({"clientCountry","clientName", "cardType"})
	@Test(groups = { "Regression" })//Bug Locked
	public void validateTheNewCustomerUserFromAdminLogin(@Optional("AT") String clientCountry, @Optional("SHELL") String clientName, @Optional("APA") String cardType)  {
		
		test = extent.createTest(clientName+ ":" +clientCountry+"  07 Add a Customer User", "Create New Customer User from Admin");
		String role ="Partner User";
        //Creating Objects for the Pages
        LoginPage loginPage = new LoginPage(driver, test);
        HomePage homePage = new HomePage(driver, test);
        SHELLHomePage shellHomePage = new SHELLHomePage(driver, test);
        SHELLAdminPages adminPage = new SHELLAdminPages(driver, test);
      
		// Calling Functions
        if(cardType.equals("PC"))
        {
        	loginPage.Login("SHLPC_URL", "SHLPC_UN_Customer_Admin_" + clientCountry, "SHLPC_PWD_Customer_Admin_" + clientCountry, clientName);
        }
        else if(cardType.equals("APA"))
        {
        	loginPage.Login("SHLAPA_URL", "SHLAPA_UN_Customer_Admin_" + clientCountry, "SHLAPA_PWD_Customer_Admin_" + clientCountry, clientName);
        }
		homePage.ValidateLogoutLink();
		homePage.ValidateHelpShellLink();
		homePage.ValidateWelcomeText(clientName+"#"+cardType);
		homePage.ValidateQuickLinks();
		shellHomePage.ValidateHeaderMenus("Admin");
		shellHomePage.ValidateFooterMenus();
		shellHomePage.goToAdminNewUser(); 
		adminPage.verifyNewUserPageIsLoaded();
		adminPage.createNewUser(clientName,role);
		loginPage.Logout();
     
	}
	

	@Parameters({"clientCountry","clientName", "cardType"})
	@Test(groups = { "Regression" })
	public void validateTheNewCustomerAdminUserFromAdminLogin(@Optional("AT") String clientCountry, @Optional("SHELL") String clientName, @Optional("APA") String cardType)  {
		
		test = extent.createTest(clientName+ ":" +clientCountry+"  08 Add a Customer Admin User", "Create New Customer Admin User from Admin");
		String role ="Partner Administrator";
        //Creating Objects for the Pages
        LoginPage loginPage = new LoginPage(driver, test);
        HomePage homePage = new HomePage(driver, test);
        SHELLHomePage shellHomePage = new SHELLHomePage(driver, test);
        SHELLAdminPages adminPage = new SHELLAdminPages(driver, test);
      
		// Calling Functions
        if(cardType.equals("PC"))
        {
        	loginPage.Login("SHLPC_URL", "SHLPC_UN_Customer_Admin_" + clientCountry, "SHLPC_PWD_Customer_Admin_" + clientCountry, clientName);
        }
        else if(cardType.equals("APA"))
        {
        	loginPage.Login("SHLAPA_URL", "SHLAPA_UN_Customer_Admin_" + clientCountry, "SHLAPA_PWD_Customer_Admin_" + clientCountry, clientName);
        }
		homePage.ValidateLogoutLink();
		homePage.ValidateHelpShellLink();
		homePage.ValidateWelcomeText(clientName+"#"+cardType);
		homePage.ValidateQuickLinks();
		shellHomePage.ValidateHeaderMenus("Admin");
		shellHomePage.ValidateFooterMenus();
		shellHomePage.goToAdminNewUser(); 
		adminPage.verifyNewUserPageIsLoaded();
		adminPage.createNewUser(clientName,role);
		loginPage.Logout();
      
	}
	 
	@Parameters({"clientCountry","clientName", "cardType"})
	@Test(groups = { "Regression" })
	public void validateTheNewCustomerAdminUserFromSuperAdminLogin(@Optional("AT") String clientCountry, @Optional("SHELL") String clientName, @Optional("APA") String cardType)  {
		
		test = extent.createTest(clientName+ ":" +clientCountry+"  10 SuperUser-Admin user Add a Customer User", "Login As Super user and create New user");

		String role = "Partner Administrator";
        //Creating Objects for the Pages
        LoginPage loginPage = new LoginPage(driver, test);
        HomePage homePage = new HomePage(driver, test);
        SHELLHomePage shellHomePage = new SHELLHomePage(driver, test);
        SHELLAdminPages adminPage = new SHELLAdminPages(driver, test);
      
		// Calling Functions
        if(cardType.equals("PC"))
        {
        	loginPage.Login("SHLPC_URL", "SHLPC_UN_Customer_Admin_" + clientCountry, "SHLPC_PWD_Customer_Admin_" + clientCountry, clientName);
        }
        else if(cardType.equals("APA"))
        {
        	loginPage.Login("SHLAPA_URL", "SHLAPA_UN_Customer_Admin_" + clientCountry, "SHLAPA_PWD_Customer_Admin_" + clientCountry, clientName);
        }
		homePage.ValidateLogoutLink();
		homePage.ValidateHelpShellLink();
		homePage.ValidateWelcomeText(clientName+"#"+cardType);
		homePage.ValidateQuickLinks();
		shellHomePage.ValidateHeaderMenus("Admin");
		shellHomePage.ValidateFooterMenus();
		shellHomePage.goToAdminNewUser(); 
		adminPage.verifyNewUserPageIsLoaded();
		adminPage.createNewUser(clientName, role);
		loginPage.Logout();
      
	}
	
	@Parameters({"clientCountry","clientName", "cardType"})
	@Test(groups = { "Regression" })
	public void validateTheNewCustomerUserFromSuperAdminLogin(@Optional("AT") String clientCountry, @Optional("SHELL") String clientName, @Optional("APA") String cardType)  {
		
		test = extent.createTest(clientName+ ":" +clientCountry+"  11  SuperUser-Admin user Add a Customer Admin User", "Login As Super user and create New Admin user");

		String role = "Partner User";
        //Creating Objects for the Pages
        LoginPage loginPage = new LoginPage(driver, test);
        HomePage homePage = new HomePage(driver, test);
        SHELLHomePage shellHomePage = new SHELLHomePage(driver, test);
        SHELLAdminPages adminPage = new SHELLAdminPages(driver, test);
      
		// Calling Functions
        if(cardType.equals("PC"))
        {
        	loginPage.Login("SHLPC_URL", "SHLPC_UN_Customer_Admin_" + clientCountry, "SHLPC_PWD_Customer_Admin_" + clientCountry, clientName);
        }
        else if(cardType.equals("APA"))
        {
        	loginPage.Login("SHLAPA_URL", "SHLAPA_UN_Customer_Admin_" + clientCountry, "SHLAPA_PWD_Customer_Admin_" + clientCountry, clientName);
        }
		homePage.ValidateLogoutLink();
		homePage.ValidateHelpShellLink();
		homePage.ValidateWelcomeText(clientName+"#"+cardType);
		homePage.ValidateQuickLinks();
		shellHomePage.ValidateHeaderMenus("Admin");
		shellHomePage.ValidateFooterMenus();
		shellHomePage.goToAdminNewUser(); 
		adminPage.verifyNewUserPageIsLoaded();
		adminPage.createNewUser(clientName, role);
		loginPage.Logout();
      
	}
	
	
	@Parameters({"clientCountry","clientName", "cardType"})
	@Test(groups = { "Regression" })
	public void validateTheNavigationOfAccountProfile(@Optional("AT") String clientCountry, @Optional("SHELL") String clientName, @Optional("APA") String cardType)  {
		
		test = extent.createTest(clientName+ ":" +clientCountry+"  11 View another account profile", "Navigate the Account profile and validate");
		 
        //Creating Objects for the Pages
        LoginPage loginPage = new LoginPage(driver, test);
        HomePage homePage = new HomePage(driver, test);
        SHELLHomePage shellHomePage = new SHELLHomePage(driver, test);
        SHELLAdminPages adminPage = new SHELLAdminPages(driver, test);
      
		// Calling Functions
        if(cardType.equals("PC"))
        {
        	loginPage.Login("SHLPC_URL", "SHLPC_UN_Customer_Admin_" + clientCountry, "SHLPC_PWD_Customer_Admin_" + clientCountry, clientName);
        }
        else if(cardType.equals("APA"))
        {
        	loginPage.Login("SHLAPA_URL", "SHLAPA_UN_Customer_Admin_" + clientCountry, "SHLAPA_PWD_Customer_Admin_" + clientCountry, clientName);
        }
		homePage.ValidateLogoutLink();
		homePage.ValidateHelpShellLink();
		homePage.ValidateWelcomeText(clientName+"#"+cardType);
		homePage.ValidateQuickLinks();
		shellHomePage.ValidateHeaderMenus("Admin");
		shellHomePage.ValidateFooterMenus();
		shellHomePage.goToAdminMenuUserList(); 
		adminPage.validateUserListPage();
		if(cardType.equals("PC"))
        {
			adminPage.clickSearchButtonAndValidate("SHLPC_UN_Customer_Admin_" + clientCountry);
        }
		else if(cardType.equals("APA"))
        {
			adminPage.clickSearchButtonAndValidate("SHLAPA_UN_Customer_Admin_" + clientCountry);
        }
		adminPage.selectUserAndGotoUserProfile();
		adminPage.clickBackToUserList();
		loginPage.Logout();
      
	}
	
	@Parameters({"clientCountry","clientName", "cardType"})
	@Test(groups = { "Regression" })
	public void validateTheDisplayedUsersPartnerCards(@Optional("AT") String clientCountry, @Optional("SHELL") String clientName, @Optional("APA") String cardType)  {
		
		test = extent.createTest(clientName+ ":" +clientCountry+"  21 check that only PartnerCard users displayed", "Navigate to the User List and verify all are partner cards");
		 
        //Creating Objects for the Pages
        LoginPage loginPage = new LoginPage(driver, test);
        HomePage homePage = new HomePage(driver, test);
        SHELLHomePage shellHomePage = new SHELLHomePage(driver, test);
        SHELLAdminPages adminPage = new SHELLAdminPages(driver, test);
      
		// Calling Functions
        if(cardType.equals("PC"))
        {
        	loginPage.Login("SHLPC_URL", "SHLPC_UN_Customer_Admin_" + clientCountry, "SHLPC_PWD_Customer_Admin_" + clientCountry, clientName);
        }
        else if(cardType.equals("APA"))
        {
        	loginPage.Login("SHLAPA_URL", "SHLAPA_UN_Customer_Admin_" + clientCountry, "SHLAPA_PWD_Customer_Admin_" + clientCountry, clientName);
        }
		homePage.ValidateLogoutLink();
		homePage.ValidateHelpShellLink();
		homePage.ValidateWelcomeText(clientName+"#"+cardType);
		homePage.ValidateQuickLinks();
		shellHomePage.ValidateHeaderMenus("Admin");
		shellHomePage.ValidateFooterMenus();
		if(!clientCountry.equals("BE"))
		{ 
			shellHomePage.goToAdminMenuUserList(); 
			adminPage.validateUserListPage();
			if(cardType.equals("PC"))
	        {
				adminPage.clickSearchButtonAndValidate("SHLPC_UN_Customer_Admin_" + clientCountry);
				adminPage.verifyOtherCardCustomersNotPresent("SHLAPA_UN_Customer_Admin_" + clientCountry);
	        }
			else if(cardType.equals("APA"))
	        {
				adminPage.clickSearchButtonAndValidate("SHLAPA_UN_Customer_Admin_" + clientCountry);
				adminPage.verifyOtherCardCustomersNotPresent("SHLPC_UN_Customer_Admin_" + clientCountry);
	        }
		}
		 
		loginPage.Logout();      
	}
	
	 @Parameters({ "clientCountry", "clientName", "cardType" })
	 @Test(groups = { "Regression" }) 
	 public void validatePromoteCustomerUserToCustomerAdministrator(@Optional("AT") String clientCountry, @Optional("SHELL") String clientName, @Optional("APA") String cardType) {
	  
	  test = extent.createTest(clientName+ ":" +clientCountry+"  05 Promote a Customer User to Customer Admin", "Promote Customer User to Customer Administrator");
	  String role = "Customer Administrator";
	  String roleToBePromoted = "Customer User";
	  // Creating Objects for the Pages 
	  LoginPage loginPage = new LoginPage(driver,test); 
	  HomePage homePage = new HomePage(driver, test); 
	  SHELLHomePage shellHomePage = new SHELLHomePage(driver, test); 
	  SHELLAdminPages shellAdminPages = new SHELLAdminPages(driver, test);
	  
	  // Calling Functions 
	  if(cardType.equals("PC"))
      {
      	loginPage.Login("SHLPC_URL", "SHLPC_UN_Customer_Admin_" + clientCountry, "SHLPC_PWD_Customer_Admin_" + clientCountry, clientName);
      }
      else if(cardType.equals("APA"))
      {
      	loginPage.Login("SHLAPA_URL", "SHLAPA_UN_Customer_Admin_" + clientCountry, "SHLAPA_PWD_Customer_Admin_" + clientCountry, clientName);
      }
	  homePage.ValidateHelpShellLink(); 
	  homePage.ValidateWelcomeText(clientName+"#"+cardType);
	  homePage.ValidateQuickLinks(); 
	  shellHomePage.ValidateHeaderMenus("Admin");
	  shellHomePage.ValidateFooterMenus();
	  
	  // Selecting the UserList from Admin Tab
	  shellHomePage.goToAdminMenuUserList();
	  shellAdminPages.validateUserListPage();
	  boolean isUserSelected = false;
	  if(cardType.equals("PC"))
      {
	  // Click Search Button 
	  shellAdminPages.clickSearchButtonAndValidate("SHLPC_UN_Customer_Admin_" + clientCountry);
	  
	  // Select one User
	  isUserSelected = shellAdminPages.selectUserFromUserList(clientCountry, roleToBePromoted);
      } else if(cardType.equals("APA")) {
      // Click Search Button 
      shellAdminPages.clickSearchButtonAndValidate("SHLAPA_UN_Customer_Admin_" + clientCountry);
    	  
      // Select one User
       isUserSelected = shellAdminPages.selectUserFromUserList(clientCountry, roleToBePromoted);
      }
	  if(isUserSelected) {
	  shellAdminPages.validateChangeUserRolePage();
	  
	  shellAdminPages.selectRoleForCustomer(role);
	  
	  shellAdminPages.clickBackToUserList();
	  if(cardType.equals("PC")) {
	  // Verify the updated Customer Role
	  shellAdminPages.validateCustomerRoleUpdated("SHLPC_UN_Customer_Admin_" + clientCountry, role);
	  } else if(cardType.equals("APA")) {
		shellAdminPages.validateCustomerRoleUpdated("SHLAPA_UN_Customer_Admin_" + clientCountry, role);  
	  }
	  }
	  loginPage.Logout();
	  
	  }
	 
	 @Parameters({ "clientCountry", "clientName", "cardType" })
	 @Test(groups = { "Regression" }) 
	 public void validateDemoteCustomerAdministratorToCustomerUser(@Optional("AT") String clientCountry, @Optional("SHELL") String clientName, @Optional("APA") String cardType) {
	  
	  test = extent.createTest(clientName+ ":" +clientCountry+"  10 Demote an Admin user to Customer User", "Promote Customer User to Customer Administrator");
	  String role = "Customer User";
	  String roleToBeDemoted = "Customer Administrator";
	  // Creating Objects for the Pages 
	  LoginPage loginPage = new LoginPage(driver,test); 
	  HomePage homePage = new HomePage(driver, test); 
	  SHELLHomePage shellHomePage = new SHELLHomePage(driver, test); 
	  SHELLAdminPages shellAdminPages = new SHELLAdminPages(driver, test);
	  
	  // Calling Functions 
	  if(cardType.equals("PC"))
      {
      	loginPage.Login("SHLPC_URL", "SHLPC_UN_Customer_Admin_" + clientCountry, "SHLPC_PWD_Customer_Admin_" + clientCountry, clientName);
      }
      else if(cardType.equals("APA"))
      {
      	loginPage.Login("SHLAPA_URL", "SHLAPA_UN_Customer_Admin_" + clientCountry, "SHLAPA_PWD_Customer_Admin_" + clientCountry, clientName);
      }
	  homePage.ValidateHelpShellLink(); 
	  homePage.ValidateWelcomeText(clientName+"#"+cardType);
	  homePage.ValidateQuickLinks(); 
	  shellHomePage.ValidateHeaderMenus("Admin");
	  shellHomePage.ValidateFooterMenus();
	  boolean isUserSelected = false;
	  // Selecting the UserList from Admin Tab
	  shellHomePage.goToAdminMenuUserList();
	  shellAdminPages.validateUserListPage();
	  
	  if(cardType.equals("PC"))
      {
	  // Click Search Button 
	  shellAdminPages.clickSearchButtonAndValidate("SHLPC_UN_Customer_Admin_" + clientCountry);
	  
	  // Select one User
	  isUserSelected = shellAdminPages.selectUserFromUserList(clientCountry, roleToBeDemoted);
      } else if(cardType.equals("APA")) {
      // Click Search Button 
      shellAdminPages.clickSearchButtonAndValidate("SHLAPA_UN_Customer_Admin_" + clientCountry);
    	  
      // Select one User
      isUserSelected = shellAdminPages.selectUserFromUserList(clientCountry, roleToBeDemoted);
      }
	  if(isUserSelected) {
	  shellAdminPages.validateChangeUserRolePage();
	  
	  shellAdminPages.selectRoleForCustomer(role);
	  
	  shellAdminPages.clickBackToUserList();
	  
	  if(cardType.equals("PC")) {
		  // Verify the updated Customer Role
		  shellAdminPages.validateCustomerRoleUpdated("SHLPC_UN_Customer_Admin_" + clientCountry, role);
		  } else if(cardType.equals("APA")) {
			shellAdminPages.validateCustomerRoleUpdated("SHLAPA_UN_Customer_Admin_" + clientCountry, role);  
		  }
	  }
	  loginPage.Logout();
	  
	  }
	 

	@Parameters({ "clientCountry", "clientName", "cardType"})
	@Test(groups = { "Regression" })
	public void validateAPACustomerUserlogin(@Optional("AT") String clientCountry,
			@Optional("SHELL") String clientName, @Optional("APA") String cardType) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  20 Check that only APA users displayed", "Verify APA user list displayed");

		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		HomePage homePage = new HomePage(driver, test);
		SHELLHomePage shellHomePage = new SHELLHomePage(driver, test);
		SHELLAdminPages shellAdminPages = new SHELLAdminPages(driver, test);

		// Calling Functions
		if(cardType.equals("PC"))
	      {
	      	loginPage.Login("SHLPC_URL", "SHLPC_UN_Customer_Admin_" + clientCountry, "SHLPC_PWD_Customer_Admin_" + clientCountry, clientName);
	      }
	      else if(cardType.equals("APA"))
	      {
	      	loginPage.Login("SHLAPA_URL", "SHLAPA_UN_Customer_Admin_" + clientCountry, "SHLAPA_PWD_Customer_Admin_" + clientCountry, clientName);
	      }
		//
		homePage.ValidateLogoutLink();
		homePage.ValidateHelpShellLink();
		
		  //homePage.ValidateWelcomeText(clientName+"#"+cardType); homePage.ValidateQuickLinks();
		 // shellHomePage.ValidateHeaderMenus("Admin");
		  //shellHomePage.ValidateFooterMenus();
		 

		// Selecting the UserList from Admin Tab
		shellHomePage.goToAdminMenuUserList();
		shellAdminPages.validateUserListPage();
		if(cardType.equals("PC"))
	      {
			// Click Search Button
			shellAdminPages.clickSearchButtonAndValidate("SHLPC_UN_Customer_Admin_" + clientCountry);

			// Validate All PC Users
			shellAdminPages.validateAllAPAUsers("SHLPC_UN_Customer_Admin_" + clientCountry);

	      }
		else if(cardType.equals("APA")) {
			// Click Search Button
			shellAdminPages.clickSearchButtonAndValidate("SHLAPA_UN_Customer_Admin_" + clientCountry);

			// Validate All APA Users
			shellAdminPages.validateAllAPAUsers("SHLAPA_UN_Customer_Admin_" + clientCountry);

	      }
		
		loginPage.Logout();

	}

	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test( groups = { "Regression" })
	public void validateUpdateLanguageAdminUser(@Optional("AT") String clientCountry, @Optional("SHELL") String clientName, @Optional("APA") String cardType) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  06 Update Language", "Verify language updated ");
		String role = "Customer Administrator";
		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		HomePage homePage = new HomePage(driver, test);
		SHELLHomePage shellHomePage = new SHELLHomePage(driver, test);
		SHELLAdminPages shellAdminPages = new SHELLAdminPages(driver, test);

		// Calling Login Functions
		 if(cardType.equals("PC"))
	        {
	        	loginPage.Login("SHLPC_URL", "SHLPC_UN_Customer_Admin_" + clientCountry, "SHLPC_PWD_Customer_Admin_" + clientCountry, clientName);
	        }
	        else if(cardType.equals("APA"))
	        {
	        	loginPage.Login("SHLAPA_URL", "SHLAPA_UN_Customer_Admin_" + clientCountry, "SHLAPA_PWD_Customer_Admin_" + clientCountry, clientName);
	        }
		
		// Shell Home page validation
		homePage.ValidateLogoutLink();
		homePage.ValidateHelpShellLink();
		homePage.ValidateWelcomeText(clientName+"#"+cardType);
		homePage.ValidateQuickLinks();
		shellHomePage.ValidateHeaderMenus("Admin");
		shellHomePage.ValidateFooterMenus();

		// Selecting the UserList from Admin Tab
		shellHomePage.goToAdminMenuUserList();
		shellAdminPages.validateUserListPage();
		
		if(cardType.equals("PC")) {
		// Click Search Button
		shellAdminPages.clickSearchButtonAndValidate("SHLPC_UN_Customer_Admin_" + clientCountry);

		// Select one User Click Edit profile
		shellAdminPages.selectUserFromUserListAndEditProfile("SHLPC_UN_Customer_Admin_" + clientCountry, role);

		shellAdminPages.verifyUserId("SHLPC_UN_Customer_Admin_" + clientCountry);
		} else if(cardType.equals("APA")) {
			// Click Search Button
			shellAdminPages.clickSearchButtonAndValidate("SHLAPA_UN_Customer_Admin_" + clientCountry);

			// Select one User Click Edit profile
			shellAdminPages.selectUserFromUserListAndEditProfile("SHLAPA_UN_Customer_Admin_" + clientCountry, role);

			shellAdminPages.verifyUserId("SHLAPA_UN_Customer_Admin_" + clientCountry);
		}
		String changedLanguage = shellAdminPages.validateChangeLanguage();
		
		// Logout & Login
		loginPage.Logout();
		// Logout Page is redirecting
		// Calling Functions
		if(cardType.equals("PC"))
	      {
	      	loginPage.Login("SHLPC_URL", "SHLPC_UN_Customer_Admin_" + clientCountry, "SHLPC_PWD_Customer_Admin_" + clientCountry, clientName);
	      }
	      else if(cardType.equals("APA"))
	      {
	      	loginPage.Login("SHLAPA_URL", "SHLAPA_UN_Customer_Admin_" + clientCountry, "SHLAPA_PWD_Customer_Admin_" + clientCountry, clientName);
	      }
		
		shellAdminPages.validateUpdatedLanguage(changedLanguage);
		
		loginPage.Logout();
		  
	}
	
	 @Parameters({ "clientCountry", "clientName", "cardType"})
	 @Test( groups = { "Regression" }) 
	 public void validateLoginAsCustomerUser(@Optional("AT") String clientCountry, @Optional("SHELL") String clientName, @Optional("APA") String cardType) {
	  
	  test = extent.createTest(clientName+ ":" +clientCountry+"  05 Verify Admin menu not displayed", "Customer User login and Check Admin Tab");
	  
	  // Creating Objects for the Pages 
	  LoginPage loginPage = new LoginPage(driver,test); 
	  HomePage homePage = new HomePage(driver, test); 
	  SHELLHomePage shellHomePage = new SHELLHomePage(driver, test); 
	  
	  // Calling Functions 
	  if(cardType.equals("PC"))
      {
      	loginPage.Login("SHLPC_URL", "SHLPC_UN_Customer_User_" + clientCountry, "SHLPC_PWD_Customer_User_" + clientCountry, clientName);
      }
      else if(cardType.equals("APA"))
      {
      	loginPage.Login("SHLAPA_URL", "SHLAPA_UN_Customer_User_" + clientCountry, "SHLAPA_PWD_Customer_User_" + clientCountry, clientName);
      }
	  homePage.ValidateHelpShellLink(); 
	  homePage.ValidateWelcomeText(clientName+"#"+cardType);
	  homePage.ValidateQuickLinks(); 
	  shellHomePage.ValidateFooterMenus();
	  
	  // Admin Tab is Not Displayed
	  shellHomePage.validateAdminTabNotDisplayed();
	  
	  loginPage.Logout();
	  
	  
	}
	
	@Parameters({ "clientCountry", "clientName", "cardType"})
	@Test( groups = { "Regression" }) 
	public void validateAdminUserPromoteCustomerUserToCustomerAdmin(@Optional("AT") String clientCountry, @Optional("SHELL") String clientName, @Optional("APA") String cardType) {
	 
	 test = extent.createTest(clientName+ ":" +clientCountry+"  Shell AT Promote Customer Role", "Admin user Promote a Customer User to Customer Admin");
	 String role = "Partner Administrator";
	 String roleToBePromoted = "Customer User";
	 // Creating Objects for the Pages 
	 LoginPage loginPage = new LoginPage(driver,test); 
	 HomePage homePage = new HomePage(driver, test); 
	 SHELLHomePage shellHomePage = new SHELLHomePage(driver, test); 
	 SHELLAdminPages shellAdminPages = new SHELLAdminPages(driver, test);
	 
	 // Calling Functions 
	 if(cardType.equals("PC"))
     {
     	loginPage.Login("SHLPC_URL", "SHLPC_UN_Customer_Admin_" + clientCountry, "SHLPC_PWD_Customer_Admin_" + clientCountry, clientName);
     }
     else if(cardType.equals("APA"))
     {
     	loginPage.Login("SHLAPA_URL", "SHLAPA_UN_Customer_Admin_" + clientCountry, "SHLAPA_PWD_Customer_Admin_" + clientCountry, clientName);
     }
	 homePage.ValidateHelpShellLink(); 
	  homePage.ValidateWelcomeText(clientName+"#"+cardType);
	  homePage.ValidateQuickLinks(); 
	  shellHomePage.ValidateHeaderMenus("Admin");
	  shellHomePage.ValidateFooterMenus();
	  
	// Selecting the UserList from Admin Tab
		  shellHomePage.goToAdminMenuUserList();
		  shellAdminPages.validateUserListPage();
		  
		  if(cardType.equals("PC"))
	      {
		  // Click Search Button 
		  shellAdminPages.clickSearchButtonAndValidate("SHLPC_UN_Customer_Admin_" + clientCountry);
		  
		  // Select one User
		  shellAdminPages.selectUserFromUserList(clientCountry, roleToBePromoted);
	      } else if(cardType.equals("APA")) {
	      // Click Search Button 
	      shellAdminPages.clickSearchButtonAndValidate("SHLAPA_UN_Customer_Admin_" + clientCountry);
	    	  
	      // Select one User
	      shellAdminPages.selectUserFromUserList(clientCountry, roleToBePromoted);
	      }
		  
		  shellAdminPages.validateChangeUserRolePage();
		  
		  shellAdminPages.selectRoleForCustomer(role);
		  
		  shellAdminPages.clickBackToUserList();
		  
		 
		  if(cardType.equals("PC")) {
			  // Verify the updated Customer Role
			  shellAdminPages.validateCustomerRoleUpdated("SHLPC_UN_Customer_Admin_" + clientCountry, role);
			  } else if(cardType.equals("APA")) {
				shellAdminPages.validateCustomerRoleUpdated("SHLAPA_UN_Customer_Admin_" + clientCountry, role);  
			  }
		  loginPage.Logout();
		 	  
	  }
	

	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test( groups = { "Regression" }) 
	public void validateAdminMenuUserList(@Optional("AT") String clientCountry, @Optional("SHELL") String clientName, @Optional("APA") String cardType) {
	 
	 String role = "Partner Administrator";
	 test = extent.createTest(clientName+ ":" +clientCountry+"  07 Admin Menu. User List", "Admin user Promote a Customer User to Customer Admin");
	 // Creating Objects for the Pages 
	 LoginPage loginPage = new LoginPage(driver,test); 
	 HomePage homePage = new HomePage(driver, test); 
	 SHELLHomePage shellHomePage = new SHELLHomePage(driver, test); 
	 SHELLAdminPages shellAdminPages = new SHELLAdminPages(driver, test);
	 
	 // Calling Functions 
	 if(cardType.equals("PC"))
     {
     	loginPage.Login("SHLPC_URL", "SHLPC_UN_Customer_Admin_" + clientCountry, "SHLPC_PWD_Customer_Admin_" + clientCountry, clientName);
     }
     else if(cardType.equals("APA"))
     {
     	loginPage.Login("SHLAPA_URL", "SHLAPA_UN_Customer_Admin_" + clientCountry, "SHLAPA_PWD_Customer_Admin_" + clientCountry, clientName);
     }
	 homePage.ValidateHelpShellLink(); 
	  homePage.ValidateWelcomeText(clientName+"#"+cardType);
	  homePage.ValidateQuickLinks(); 
	  shellHomePage.ValidateHeaderMenus("Admin");
	  shellHomePage.ValidateFooterMenus();
	  
	  // Selecting the UserList from Admin Tab
	  shellHomePage.goToAdminMenuUserList();
	  shellAdminPages.validateUserListPage();
	  
	  if(cardType.equals("PC")) {
		  
	  shellAdminPages.searchWithUserIDRoleAndAccountNumber("SHLPC_UN_Customer_Admin_" + clientCountry, role);
	  
	  // Click Search Button
	  shellAdminPages.clickSearchButtonAndValidate("SHLPC_UN_Customer_Admin_" + clientCountry);
	  
	  } else if(cardType.equals("APA")) {
		  shellAdminPages.searchWithUserIDRoleAndAccountNumber("SHLAPA_UN_Customer_Admin_" + clientCountry, role);
		  
		  // Click Search Button
		  shellAdminPages.clickSearchButtonAndValidate("SHLAPA_UN_Customer_Admin_" + clientCountry);
		    
	  }
		  
	  // Select First User from list
	  shellAdminPages.selectUserAndGotoEditProfile();
	  
	  // Update Phone No and Save changes
	  shellAdminPages.updatePhoneNoAndSaveAndValidate();
	  shellAdminPages.clickBackToUserList();
	  
	  // Rest of the steps covered in above test cases
	  loginPage.Logout();
	  
	}
	
	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test( groups = { "Regression" }) 
	public void validateNewAdminUser(@Optional("AT") String clientCountry, @Optional("SHELL") String clientName, @Optional("APA") String cardType) {	 
		test = extent.createTest(clientName+ ":" +clientCountry+"  06 Admin Menu New User", "Going to user profile, with the email Id create new Admin New User ");
		//String role = "Partner User";
	 // Creating Objects for the Pages 
		 LoginPage loginPage = new LoginPage(driver,test); 
		 HomePage homePage = new HomePage(driver, test); 
		 SHELLHomePage shellHomePage = new SHELLHomePage(driver, test); 
		 //SHELLAdminPages shellAdminPages = new SHELLAdminPages(driver, test);
		 SHELLSupportPage shellSupportPage = new SHELLSupportPage(driver, test);
		 EditUserProfile editUserProfile = new EditUserProfile(driver, test);
		 
		 // Calling Functions 
		 if(cardType.equals("PC"))
	     {
	     	loginPage.Login("SHLPC_URL", "SHLPC_UN_Customer_Admin_" + clientCountry, "SHLPC_PWD_Customer_Admin_" + clientCountry, clientName);
	     }
	     else if(cardType.equals("APA"))
	     {
	     	loginPage.Login("SHLAPA_URL", "SHLAPA_UN_Customer_Admin_" + clientCountry, "SHLAPA_PWD_Customer_Admin_" + clientCountry, clientName);
	     } 
		 homePage.ValidateLogoutLink();
		 homePage.ValidateHelpShellLink(); 
		 homePage.ValidateWelcomeText(clientName+"#"+cardType);
		 homePage.ValidateQuickLinks(); 
		 shellHomePage.ValidateHeaderMenus("Admin");
		 shellHomePage.ValidateFooterMenus();
		 
		 //Get Default Email from Support Profile
		 shellHomePage.goToSupportMenuProfile();
		 
		 editUserProfile.verifyUserProfilePage();
		
		 String emailAddress = shellSupportPage.getDefaultEmailAddress();	 
		 
		 System.out.println("----- emailAddress ----- "+emailAddress);
		  
		 // Selecting the UserList from Admin Tab
		 shellHomePage.goToAdminNewUser();
		 
		 //shellAdminPages.fillFieldsWithExistingEmailAndValidate(emailAddress,clientName,role);
		  
		 // Click Logout
		 loginPage.Logout();
	  
	}
	

}
