using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using Common;
using Common.PageObjects;
using Common.ScenarioConfigurations;
using Common.Utility;

namespace EnCompass.Testing.Source.PageObjects.SuperAdmin.AocsuperTools.JobTestAutomation 
{
	/// <summary>
	/// Auto-generated Page Model Class
	/// Navigation Paths: 
		/// [Organization Home]->Super Admin Tools->Job Test Automation
		/// [Organization Home]->Super Admin Tools->Job Test Automation->Test Results
		/// </summary>
	[PageModel(@"/SuperAdmin/AOCSuperTools/JobTestAutomation/ViewTestResults.aspx")]
	public partial class ViewTestResults : EnCompassSuperPageModel 
	{
		public override string RelativeUrl => @"/SuperAdmin/AOCSuperTools/JobTestAutomation/ViewTestResults.aspx";
		public override string PageIdentifierXPath_Generated => @"//li[contains(@class, 'breadcrumb-item active')][text() = 'Test Results']";

		#region Navigation
				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Test Results']")]
		private IWebElement _superAdminTools_JobTestAutomation_TestResults { get; set; }
		public void NavigateTo_SuperAdminTools_JobTestAutomation_TestResults()
		{
			NavigateToMenuItem(_superAdminTools_JobTestAutomation_TestResults);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Run Test']")]
		private IWebElement _superAdminTools_JobTestAutomation_RunTest { get; set; }
		public void NavigateTo_SuperAdminTools_JobTestAutomation_RunTest()
		{
			NavigateToMenuItem(_superAdminTools_JobTestAutomation_RunTest);
		}

		
		private void NavigateToMenuItem(IWebElement element)
		{
			Driver.Url = element.GetAttribute("href");
		}
		#endregion

		public ViewTestResults(GlobalSettings settings) : base(settings) { }
	}  
}
