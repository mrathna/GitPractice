using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using Common;
using Common.PageObjects;
using Common.ScenarioConfigurations;
using Common.Utility;

namespace EnCompass.Testing.Source.PageObjects.SuperAdmin.PurchaseLog 
{
	/// <summary>
	/// Auto-generated Page Model Class
	/// Navigation Paths: 
		/// [Organization Home]->Payables->Inventory
		/// </summary>
	[PageModel(@"/superAdmin/PurchaseLog/ManageSugaPool.aspx")]
	public partial class ManageSugaPool : EnCompassSuperPageModel 
	{
		public override string RelativeUrl => @"/superAdmin/PurchaseLog/ManageSugaPool.aspx";
		public override string PageIdentifierXPath_Generated => @"//li[contains(@class, 'breadcrumb-item active')][text() = 'Inventory']";

		#region Navigation
		
		private void NavigateToMenuItem(IWebElement element)
		{
			Driver.Url = element.GetAttribute("href");
		}
		#endregion

		public ManageSugaPool(GlobalSettings settings) : base(settings) { }
	}  
}
