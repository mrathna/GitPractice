package com.framework.pages.AJS;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

import com.aventstack.extentreports.ExtentTest;
import com.framework.basepage.BasePage;
import com.framework.pages.AJS.common.Common;
import com.framework.repo.Locator_IFCS;
import com.framework.util.PropUtils;
import com.framework.util.SeleniumWrappers;

public class AdminPage  extends BasePage {

	@FindBy(xpath = Locator_IFCS.ADMIN_DESKTOP_USER_LIST)
	public WebElement desktopUsersTableList;
	
	@FindBy(xpath = Locator_IFCS.ADMIN_MENU)
	public WebElement adminMenu;

	@FindBy(xpath = Locator_IFCS.CLIENT_SUBMENU)
	public WebElement clientMenu;
	@FindBy(xpath = Locator_IFCS.USER_OVERRIDE)
	public WebElement userOverRide;
	@FindBy(xpath = Locator_IFCS.CARDS_TABLE_HEADER)
	public List<WebElement> cardsTableHeaders;
	@FindBy(xpath = Locator_IFCS.SEARCH_RESULTS_TABLE)
	public List<WebElement> cardsTable;

	
	Common common=new Common(driver,test);
	public AdminPage(WebDriver driver, ExtentTest test) {
		super(driver, test);
		
		PageFactory.initElements(new AjaxElementLocatorFactory(driver, 15), this);
		
	}
	
	
	public void chooseDesktopMenuFromSecurityMenu() {
		Common common=new Common(driver,test);
		chooseSubMenuFromLeftPanel("Security", "Desktop");
		validateHeaderLabel("Desktop");
		chooseSubMenuFromLeftPanel("Desktop", "Users");
		validateHeaderLabel("Users");
		
		sleep(3);
		common.rightClick(desktopUsersTableList);
		common.addIteminPopup();
		sleep(3);
		
		validatePopupHeaderText("Users");
			
	}
	
	/**
	 * Updated by Davu - 01/04/2020
	 *
	 */
	
	public String validateAndCreateNewUsersEnterDetails() {
		Common common=new Common(driver,test);
		String userName = fakerAPI().name().username();
		common.enterValueInTextBox("Details", "Logon Id", userName);
		sleep(3);
		common.enterValueInTextBox("Details", "Name", userName);
		sleep(3);
		common.enterValueInTextBox("Details", "New Password", "Password01");
		sleep(3);
		common.enterValueInTextBox("Details", "Confirm Password", "Password01");
		
		common.clickOkButton();
		sleep(3);
		common.clickSaveIcon();
		sleep(3);
		return userName;
		// common.validateSearchTable("Logon Id", userName, true);
	}
	
	
	public void validateOLSMandatoryPageDisplay() {
		Common common=new Common(driver,test);
		isDisplayedThenClick(adminMenu, "AdminMenu");
		isDisplayedThenClick(clientMenu, "ClientSubMenu");
		chooseSubMenuFromLeftPanel("Client Config","");
		common.validateHeaderLabel("Client Config");
		switchTabDetails("OLS Mandatory Page");
		chooseOptionFromDropdown("Initial Mandatory Page display frequency","First Time");
		common.clickSaveIcon();
		verifyValidationResult("Record saved OK");
		
	}
	
	/*updated by raxsana 30/06/2020
	 * 
	 */
	
	public void validateAndEnterUserLimites() {
		Common common=new Common(driver,test);
		String clientNameInProp;
		String f_value = fakerAPI().number().digits(3);
		rightClick(userOverRide);
		common.addIteminPopup();
		validatePopupHeaderText("User Limits");
		String clientName=PropUtils.getPropValue(configProp, "clientName");
		String clientcountry=PropUtils.getPropValue(configProp, "clientCountry");
		clientNameInProp = PropUtils.getPropValue(configProp, clientName + "_" + clientcountry).trim().toString();
		chooseOptionFromDropdown("Client", clientNameInProp);
		sleep(2);
		enterValueInTextBox("Sundry Adjustments", "Maximum Sundry Adj Entry Amount", f_value);
		sleep(2);
		enterValueInTextBox("Sundry Adjustments", "Maximum Sundry Adj Auth Approval Amount", f_value);
		sleep(2);
		common.clickOkButton();
		sleep(3);
		common.clickSaveIcon();
		verifyValidationResult("Record saved OK");
	}
	
public void clickSaveButtonAndValidate() {
	Common common=new Common(driver,test);
	common.clickSaveIcon();
	sleep(2);
	//verifyText(bottomLeftText, "Record saved OK");
}

	/*
	 * Updated by Davu - 13/05/2020
	 */
	//need to make sure the partially completed cases is replaced with faker mail id
public void validateAndCreateIFCSNewUsersEnterDetails(String userName,String password, String clientName) {
	Common common=new Common(driver,test);
	
		enterValueInTextBox("Details", "Logon Id", userName);
		enterValueInTextBox("Details", "Name", userName);
		sleep(2);
		enterValueInTextBox("Details", "New Password", password);
		enterValueInTextBox("Details", "Confirm Password", password);
		enterValueInTextBox("Details", "Email Address", "Ayub.Khan@wexinc.com");
		
		
		if(clientName.equals("BP")) {
			chooseOptionFromDropdown("Access Group","10 BP Support");
		}
		else if(clientName.equals("WFE")){
			chooseOptionFromDropdown("Access Group","WFE Support");// updated by rathna
			
		}
		
		else {
			chooseOptionFromDropdown("Access Group","09 WEX Support");
		}
		sleep(2);
		common.clickOkButton();
		sleep(2);
		
	}

// Client Report Assignments
public List<String> getClientReportAssignments(String reportType) {
	chooseSubMenuFromLeftPanel("Client Config", "Report Assignments");
	List<WebElement> reportTableHeaders = driver.findElements(
			By.xpath("//div[@class='JViewport']/div[@class='JTableHeader']//div[@class='HeaderRenderer']"));
	List<String> reportTitles = new ArrayList<String>();
	int columnNoReportType = SeleniumWrappers.getColumnNoForColumnHeader("Report Type", reportTableHeaders);
	int columnNoFrequency = SeleniumWrappers.getColumnNoForColumnHeader("Frequency", reportTableHeaders);
	List<WebElement> list = driver
			.findElements(By.xpath("//div[@class='FALTableCellEditor_StrikeThruField JTextComponent']"));
	List<Integer> reportRows = SeleniumWrappers.getMatchedTableRowsWithExpectedValues(columnNoFrequency, list, reportType, driver);
	for(int i : reportRows) {
		reportTitles.add(SeleniumWrappers.getTableDataWithRowAndColumnNumber(columnNoReportType, i, driver));
	}
	return reportTitles;
}



//Prakalpha--->08/19/2019
	
public void validateMaxLengthForAllCardProducts(String colName) {
	
	try {
	int colIndex = SeleniumWrappers.getColumnNoForColumnHeader(colName, cardsTableHeaders);
	System.out.println("colIndex :" + colIndex);
	int size = SeleniumWrappers.getTotalNumberOfRows(cardsTable, driver);
	System.out.println("Row Size::" +size);
	for (int i = 0; i <= size;i++) {
		WebElement cellElement=SeleniumWrappers.getTableDataWithCellElement(i, colIndex,driver);
		System.out.println("Table Element::"+cellElement);
		String colValue = SeleniumWrappers.getTableDataWithRowAndColumnNumber(colIndex, i, driver);
		System.out.println("Table cell Value::"+colValue);
		doubleClick(cellElement);
		sleep(2);
		switchTabDetails("Embossing"); 
		sleep(5);
		verifyValueInTextBox("Embossing Details","Version Number Max Length","3");
		validateTextFieldIsEditable("Version Number Max Length");
		sleep(2);
		common.clickOkButton();	
		
}
 	
}	 catch (Exception ex) {
	logFail(ex.getMessage());
}
	
}
}

