package com.framework.testcases.OLS.CHEV.Customer;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.common.Common;
import com.framework.pages.CHEV.CHCardListPage;
import com.framework.pages.CHEV.CHEditCardPage;
import com.framework.pages.CHEV.CHHomePage;
import com.framework.pages.OLS.common.LoginPage;

public class ValidateChangeCardStatusDamagedNonBilling extends BaseTest {
	@Parameters({ "clientCountry", "clientName" })
	@Test(priority = 2)
	public void validateChnageCardStatusForDamagedNonBilling(@Optional("SG") String clientCountry,
			@Optional("CHV") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  07 Change Card status - Damaged - non Billing Node","Chevron Change Card Status damaged Non Billing");

		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		CHHomePage chHomePage = new CHHomePage(driver, test);
		CHCardListPage cardStatusPage = new CHCardListPage(driver, test);
		CHEditCardPage editCardPage = new CHEditCardPage(driver, test);
		Common common =new Common(driver,test);
		loginPage.Login("CHV_URL", "CHV_Customer_UN_" + clientCountry, "CHV_Customer_PWD_" + clientCountry, clientName);

		chHomePage.loadFindAndUpdateCardPage();

		cardStatusPage.verifyCardPageTitle();
		cardStatusPage.selectAllAccount();
		String cusNo=common.getCustomerNoForOLSUser("CHV_Customer_UN_" + clientCountry);
		String cardNumber=common.getCardNumberForOLSUser(cusNo,"Normal Service");
		//String cardNumber = cardStatusPage.getActiveCardNumber();
		if (cardNumber != "") {
			cardStatusPage.enterCardNumber(cardNumber);

			// Clicking the search card button
			cardStatusPage.clickSearchCard();

			// checking the account number
			cardStatusPage.checkAccountNumber();

			// Selecting the first card from the list
			cardStatusPage.clickFirstCardNumberFromCardsList();

			// Selecting the Change status open
			cardStatusPage.pickEditStatusOption();

			editCardPage.verifyPageTitle("Edit Card");
			editCardPage.changeCardStatus("Damaged");
			editCardPage.verifyEditCardStatusPopupMessage();
			editCardPage.clickOnAcceptButtonIneditStatusPopup();
			editCardPage.verifyEditCardStatusReplacePopupMessage();
			editCardPage.clickOnDonotReplaceButtonIneditStatusReplacePopup();

			String expectedMessage = "Damaged";
			editCardPage.verifySuccessConfirmationMessage(expectedMessage);

		} else {
			System.out.println("No Active Card");
		}

		// TODO Not Necessary as per TC

		/*
		 * editCardPage.changeCardStatus("Lost");
		 * editCardPage.verifyEditCardStatusPopupMessage();
		 * editCardPage.clickOnAcceptButtonIneditStatusPopup();
		 * editCardPage.clickOnDonotReplaceButtonIneditStatusReplacePopup();
		 * 
		 * chHomePage.loadAndFindBulkStatusChange(); CHBulkCardStatusChangePage
		 * bulkCardStatusChangePage = new CHBulkCardStatusChangePage(driver, test);
		 * bulkCardStatusChangePage.changeCardStatusBackToActive(cardNumber);
		 */

		// TODO Not Necessary as per TC

		loginPage.Logout();

	}

}
