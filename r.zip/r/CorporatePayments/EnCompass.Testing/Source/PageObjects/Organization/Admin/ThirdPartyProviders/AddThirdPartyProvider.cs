﻿using Common;
using Common.Utility;
using EnCompass.Testing.Source.PageObjects.Controls;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;

namespace EnCompass.Testing.Source.PageObjects.Organization.Admin.ThirdPartyProviders
{
    [PageModel(@"/admin/thirdPartyProviders/AddThirdPartyProvider.aspx")]
	public partial class AddThirdPartyProvider : EnCompassPageModel
	{

		public override string RelativeUrl => @"/admin/thirdPartyProviders/AddThirdPartyProvider.aspx";
		public override string PageIdentifierXPath_Override => @"//li[contains(@class, 'active')][contains(@class, 'breadcrumb-item')][contains(text(), 'Add Third-Party Provider')]";

        private readonly string _searchTerm = @"//select[contains(@id,'searchTermSelect')]";
        private readonly string _searchOutputValue = @"//div[contains(@id,'searchTermValueInputGroup')]//input[contains(@id,'txt')]";
        private readonly string _addFilterButton = @"//input[contains(@id,'addSingleValue')]";
        private readonly string _clearButton = @"//button[contains(text(),'Clear') and contains(@onclick, 'clearSearchTerms') and @type='button']";
        private readonly string _searchButton = @"//input[contains(@id,'btnSearch')]";
        private readonly string _pageLabel = @"//h2[@class='caption']";
        private readonly string _pageText = @"//h2[@class='caption']//following-sibling::p";
        private readonly string _backButton = @"//input[contains(@id,'btnBack')]";
        private readonly string _grantButton = @"//button[text()='Grant']";

        public string SelectSearchTerm
        {
            get
            {
                Driver.TryWaitForElementToBeVisible(By.XPath(_searchTerm), out IWebElement searchTerm);
                return new SelectElement(searchTerm).SelectedOption.Text;
            }
            set
            {
                Driver.TryWaitForElementToBeVisible(By.XPath(_searchTerm), out IWebElement searchTerm);
                new SelectElement(searchTerm).SelectByText(value);
                Settings.EnCompassExtentTest.Info($"Select value Category: {value}.");
            }
        }

        public string SetOutputValue
        {
            get
            {
                Driver.TryWaitForElementToBeVisible(By.XPath(_searchOutputValue), out IWebElement searchOutputValue);
                return searchOutputValue.Text;
            }

            set
            {
                Driver.TryWaitForElementToBeVisible(By.XPath(_searchOutputValue), out IWebElement searchOutputValue);
                searchOutputValue.Clear();
                searchOutputValue.SendKeys(value);
                Settings.EnCompassExtentTest.Info($"Search term set to: {value}.");
            }
        }

        public void ClickAddFilterButton()
        {
            Driver.TryWaitForElementToBeVisible(By.XPath(_addFilterButton), out IWebElement addFilterButton);
            addFilterButton.BootstrapClick();
            Settings.EnCompassExtentTest.Info("Clicked on Add filters Button.");
        }

        public void ClickClearButton()
        {
            Driver.TryWaitForElementToBeVisible(By.XPath(_clearButton), out IWebElement clearButton);
            clearButton.BootstrapClick();
            Settings.EnCompassExtentTest.Info("Clicked on Clear Button.");
        }

        public void ClickGrantButton()
        {
            Driver.TryWaitForElementToBeVisible(By.XPath(_grantButton), out IWebElement grantButton);
            grantButton.BootstrapClick();
            Settings.EnCompassExtentTest.Info("Clicked on Grant Button.");
        }

        public void ClickSearchButton()
        {
            Driver.TryWaitForElementToBeVisible(By.XPath(_searchButton), out IWebElement searchButton);
            searchButton.BootstrapClick();
            Settings.EnCompassExtentTest.Info("Clicked on Search Button.");
        }

        public void SearchThirdPartyProvider(string outputValue)
        {
            ClickClearButton();
            SelectSearchTerm = "Name";
            SetOutputValue = outputValue;
            ClickAddFilterButton();
            ClickSearchButton();
            WaitForLoad();
        }
        
        private NewGridControl _addThirdPartyGrid;
        public NewGridControl AddThirdPartyGrid
        {
            get
            {
                NewGridControl grid = _addThirdPartyGrid ?? (_addThirdPartyGrid = new NewGridControl("etAddTPPList", Driver, Settings));
                grid.WaitForGrid();
                return grid;
            }
        }

        public string GetPageLabeled 
        {
            get
            {
                return Settings.EnCompassWebDriver.WaitForVisible(By.XPath(_pageLabel)).Text;
            }
        }

        public string GetPageText
        {
            get
            {
                return Settings.EnCompassWebDriver.WaitForVisible(By.XPath(_pageText)).Text;
            }
        }

        public bool IsbackButtonVisible()
        {
            return Driver.IsElementPresent(By.XPath(_backButton));
        }

        #region modalGrandAccess
        public const string _grandAccessModal = @"//div[contains(@id,'Modal_') and @data-focus='true']";

        public void WaitForGrandAccessModal()
        {
            Driver.WaitForVisible(By.XPath(_grandAccessModal));
        }

        public GrandAccessModal GetGrandAccessModalModal
        {
            get
            {
                using (FrameHelper helper = new FrameHelper(Settings.EnCompassWebDriver, By.XPath(_grandAccessModal)))
                {
                    return new GrandAccessModal(helper, Settings);
                }
            }
        }

        /// <summary>
        /// Adding a seperate class for Each Iframe embedded within this Page Object model
        /// </summary>
        public class GrandAccessModal : AddThirdPartyProvider
        {
            FrameHelper _helper;
            public const string _cancelButtonModal = @"//button[text()='Cancel']";
            public const string _grantButtonModal = @"//button[text()='Grant' and contains(@class,'primary')]";

            public void CancelButtonModal()
            {
                _helper.FindElement(By.XPath(_cancelButtonModal)).BootstrapClick();
                Settings.EnCompassExtentTest.Info("Clicked on Cancel Button in modal.");
            }

            public void GrantButtonModal()
            {
                _helper.FindElement(By.XPath(_grantButtonModal)).BootstrapClick();
                Settings.EnCompassExtentTest.Info("Clicked on Grant Button in modal.");
            }

            public GrandAccessModal(FrameHelper helper, GlobalSettings settings) : base(settings)
            { _helper = helper; }
        }
        #endregion

        public AddThirdPartyProvider(GlobalSettings settings) : base(settings) { }
	}
}
