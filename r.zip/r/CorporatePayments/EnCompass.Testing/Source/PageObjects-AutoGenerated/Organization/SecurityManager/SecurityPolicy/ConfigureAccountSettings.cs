using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using Common;
using Common.PageObjects;
using Common.ScenarioConfigurations;
using Common.Utility;

namespace EnCompass.Testing.Source.PageObjects.Organization.SecurityManager.SecurityPolicy 
{
	/// <summary>
	/// Auto-generated Page Model Class
	/// Navigation Paths: 
		/// [Organization Home]->Security->Security Policy
		/// [Organization Home]->Security->Security Policy->User Settings
		/// </summary>
	[PageModel(@"/securityManager/securityPolicy/configureAccountSettings.aspx")]
	public partial class ConfigureAccountSettings : EnCompassOrgPageModel 
	{
		public override string RelativeUrl => @"/securityManager/securityPolicy/configureAccountSettings.aspx";
		public override string PageIdentifierXPath_Generated => @"//li[contains(@class, 'breadcrumb-item active')][text() = 'User Settings']";

		#region Navigation
				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='User Settings']")]
		private IWebElement _security_SecurityPolicy_UserSettings { get; set; }
		public void NavigateTo_Security_SecurityPolicy_UserSettings()
		{
			NavigateToMenuItem(_security_SecurityPolicy_UserSettings);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='User Roles']")]
		private IWebElement _security_SecurityPolicy_UserRoles { get; set; }
		public void NavigateTo_Security_SecurityPolicy_UserRoles()
		{
			NavigateToMenuItem(_security_SecurityPolicy_UserRoles);
		}

		
		private void NavigateToMenuItem(IWebElement element)
		{
			Driver.Url = element.GetAttribute("href");
		}
		#endregion

		public ConfigureAccountSettings(GlobalSettings settings) : base(settings) { }
	}  
}
