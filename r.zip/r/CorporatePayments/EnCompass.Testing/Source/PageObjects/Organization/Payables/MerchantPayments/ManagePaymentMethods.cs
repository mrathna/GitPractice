﻿using Common;
using Common.Utility;
using EnCompass.Testing.Source.PageObjects.Controls;
using NFluent;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EnCompass.Testing.Source.PageObjects.Organization.Payables.MerchantPayments
{
    [PageModel(@"/payables/merchantPayments/ManagePaymentMethods.aspx")]
    public partial class ManagePaymentMethods : EnCompassOrgPageModel
    {
        public override string RelativeUrl => @"/payables/merchantPayments/ManagePaymentMethods.aspx";
        public override string PageIdentifierXPath_Override => @"//li[contains(normalize-space(text()),'Payment Method')]";

        private const string _closeXPath = @"//input[contains(@id,'Close')]";

        private IWebElement _close
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_closeXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_close element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        
		public string GetPaymentMethodCreatedMessage
        {
            get { return SuccessMessage; }
        }
        
        public void Close()
        {
            _close.JSClickWithFocus(Driver);
        }

        private GridControl _pGrid;
        public GridControl PaymentMethodGrid
        {
            get
            {
                GridControl grid = _pGrid ?? (_pGrid = new GridControl("dgPaymentMethods", Driver));
                grid.WaitForGrid();
                return grid;
            }
        }

        public ManagePaymentMethods(GlobalSettings Settings) : base(Settings) { }
    }
}
