package com.framework.testcases.OLS.CHEV.Customer;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.CHEV.CHCardListPage;
import com.framework.pages.CHEV.CHEditCardPage;
import com.framework.pages.CHEV.CHHomePage;
import com.framework.pages.OLS.common.LoginPage;

public class ValidateChangeCardStatusDamagedWithBalanceNotReplace extends BaseTest {
	@Parameters({ "clientCountry", "clientName"})
	@Test(priority=4)
	public void validateChangeCardStatusForDamagedBalAllowedNoReplace(@Optional("SG") String clientCountry, @Optional("CHV") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  21 Change Card status - Damaged - Bal Allowed - No Replace","Chevron Change Card Status Page for Damaged balance allowed no Replace");

		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		CHHomePage chHomePage = new CHHomePage(driver, test);		
		CHCardListPage cardStatusPage = new CHCardListPage(driver, test);
		CHEditCardPage editCardPage = new CHEditCardPage(driver, test);
		loginPage.Login("CHV_URL", "CHV_Customer_UN_"+clientCountry, "CHV_Customer_PWD_"+clientCountry,clientName);
		
		chHomePage.loadFindAndUpdateCardPage();
		cardStatusPage.verifyCardPageTitle();
		cardStatusPage.selectAllAccount();
		String cardNumber = cardStatusPage.getActiveCardNumber();
		if(cardNumber!=null) {
			cardStatusPage.enterCardNumber(cardNumber);

			// Clicking the search card button
			cardStatusPage.clickSearchCard();

			// checking the account number
			cardStatusPage.checkAccountNumber();

			// Selecting the first card from the list
			cardStatusPage.clickFirstCardNumberFromCardsList();

			// Selecting the Change status open
			cardStatusPage.pickEditStatusOption();

			editCardPage.verifyPageTitle("Edit Card");
			editCardPage.changeCardStatus("Damaged");
			editCardPage.verifyEditCardStatusPopupMessage();
			editCardPage.clickOnAcceptButtonIneditStatusPopup();
			editCardPage.verifyEditCardStatusReplacePopupMessage();
			editCardPage.clickOnDonotReplaceButtonIneditStatusReplacePopup();

			String expectedMessage = "Damaged";
			editCardPage.verifySuccessConfirmationMessage(expectedMessage);

		} else {
			System.out.println("No Active Card");
		}
		
		// TODO Not Necessary as per TC

	/*	editCardPage.changeCardStatus("Lost");
		editCardPage.verifyEditCardStatusPopupMessage();
		editCardPage.clickOnAcceptButtonIneditStatusPopup();
		editCardPage.clickOnDonotReplaceButtonIneditStatusReplacePopup();

		chHomePage.loadAndFindBulkStatusChange();
		CHBulkCardStatusChangePage bulkCardStatusChangePage = new CHBulkCardStatusChangePage(driver, test);
		bulkCardStatusChangePage.changeCardStatusBackToActive(cardNumber); */

		// TODO Not Necessary as per TC

		loginPage.Logout();

	}

}
