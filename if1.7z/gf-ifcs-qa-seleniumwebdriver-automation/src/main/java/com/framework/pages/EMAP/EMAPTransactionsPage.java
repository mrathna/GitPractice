package com.framework.pages.EMAP;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.ExtentTest;
import com.framework.basepage.BasePage;
import com.framework.pages.OLS.common.CommonPage;
import com.framework.repo.Locator;

public class EMAPTransactionsPage extends BasePage {

	public EMAPTransactionsPage(WebDriver driver, ExtentTest test) {
		super(driver, test);
		PageFactory.initElements(driver, this);
	}

	@FindBy(how = How.ID, using = Locator.EXPORT_BATCHES)
	public WebElement exportBatches;

	@FindBy(how = How.ID, using = Locator.SEARCH_BTN)
	public WebElement searchButton;

	@FindBy(how = How.ID, using = Locator.SHELL_ACCOUNT_DROPDOWN)
	public WebElement accountDropDown;

	@FindBy(how = How.ID, using = Locator.TRANSACTION_TABLE)
	public WebElement transactionDetailsTable;

	@FindBy(id = Locator.ACCOUNT_SEL)
	public WebElement accountList;

	@FindBy(id = Locator.CARD_NO_IN_TRANSACTION_FILTER)
	public WebElement cardNoInTransactionFilter;

	@FindBy(id = Locator.COST_CENTER_IN_TRANSACTION_FILTER)
	public WebElement costCenterInTransactionFilter;

	@FindBy(id = Locator.RECEIPT_NUM)
	public WebElement receiptNo;

	@FindBy(id = Locator.FROM_DATE)
	public WebElement fromDate;

	@FindBy(id = Locator.TO_DATE)
	public WebElement toDate;

	@FindBy(id = Locator.PRD_SEL)
	public WebElement productList;

	@FindBy(id = Locator.DRIVER_NAME_FILTER_FIELD)
	public WebElement driverNameField;

	@FindBy(id = Locator.LICENSE_PLATE_FILTER_FIELD)
	public WebElement licensePlateField;

	@FindBy(xpath = Locator.DETAILS_MENU_OPTION)
	public WebElement detailsMenuOption;

	@FindBy(xpath = Locator.LISTED_TRANSACTIONS)
	public List<WebElement> listedTransaction;

	@FindBy(xpath = Locator.LISTED_TRANSACTIONS_WITH_CARD)
	public List<WebElement> listedTransactionWithCard;

	@FindBy(how = How.XPATH, using = Locator.PAGE_TITLE1)
	public WebElement pageTitle;

	@FindBy(id = Locator.AUTHORISATION_NO)
	public WebElement authorisationNo;

	@FindBy(id = Locator.CAPTURE_TYPE_IN_TRANS)
	public WebElement captureType;

	@FindBy(id = Locator.COST_CENTER_IN_TRANS)
	public WebElement costCenter;

	@FindBy(id = Locator.DRIVER_ID_IN_TRANS)
	public WebElement driverId;

	@FindBy(xpath = Locator.GST_TOTAL_IN_TRANS)
	public WebElement gstTotal;

	@FindBy(id = Locator.LOCATION_IN_TRANS)
	public WebElement location;

	@FindBy(id = Locator.ODOMETER_IN_TRANS)
	public WebElement odometer;

	@FindBy(id = Locator.ORDER_NO_IN_TRANS)
	public WebElement orderNo;

	@FindBy(id = Locator.PROCESSED_DATE_IN_TRANS)
	public WebElement processedDate;

	@FindBy(id = Locator.REF_NUMBER_IN_TRANS)
	public WebElement refNo;

	@FindBy(id = Locator.TERMINAL_ID_IN_TRANS)
	public WebElement terminalId;

	@FindBy(id = Locator.TOTAL_FEES_IN_TRANS)
	public WebElement totalFees;

	@FindBy(id = Locator.TOTAL_IN_TRANS)
	public WebElement totalInTransaction;

	@FindBy(id = Locator.DATE_TIME_IN_TRANS)
	public WebElement dateTime;

	@FindBy(xpath = Locator.TRANSACTION_STATUS)
	public WebElement transactionStatus;

	@FindBy(id = Locator.TRANSACTION_TYPE_DETAIL)
	public WebElement transactionType;

	@FindBy(id = Locator.VEHICLE_CHECK_IN_TRANS)
	public WebElement vehicleCheck;

	@FindBy(id = Locator.VEHICLE_ID)
	public WebElement vehicleId;

	@FindBy(id = Locator.CURRENT_CARD_NUMBER)
	public WebElement cardNumber;

	@FindBy(id = Locator.EXPORT_TO_EXCEL_SETT)
	public WebElement exportToExcel;

	@FindBy(id = Locator.SEARCH_CARDS)
	public WebElement searchTransactionSettlement;

	@FindBy(id = Locator.SEARCH_BTN)
	public WebElement searchTransactionSettlementMerc;

	@FindBy(id = Locator.ENQUIRY_START_DATE)
	public WebElement enquiryStartDate;

	@FindBy(id = Locator.SET_LOCATION_NUM)
	public WebElement locationNumber;

	@FindBy(id = Locator.RES_TABLE_SETT)
	public WebElement settlementTable;
	@FindBy(id = Locator.LOCATION_EMPTY_CARDNUMBER)
	public WebElement  locationEmptyCardNumber;
	@FindBy(how = How.XPATH, using = Locator.TRANSACTION_SUNDRY_DETAIL)
	public WebElement transactionSundryDetail;

	String dateGenerated, dateTo, cardNumberChoosen;
	public String transactionWithoutCardNumber = "";
	CommonPage commonPage = new CommonPage(driver, test);

	// Transaction Page
	public void validateTheTransactionsTableFields(String customerOrMerc) {
		isDisplayed(exportBatches, "Export option for transactions");
		isDisplayed(searchButton, "Search button");
		String[] columnValuesExpected;
		int noOfCols;
		if (customerOrMerc.equals("Merc") || customerOrMerc.equals("Loc")) {
			columnValuesExpected = new String[] { "Card Number", "Transaction Type", "Reference No", "Location Name",
					"Product", "Transaction Date", "Merchant Total" };
			noOfCols = 7;
		} else {
			columnValuesExpected = new String[] { "Card Number", "Acct Number", "Reference", "Location", "Product",
					"Date/Time", "Odometer", "Cust Amt", "Status" };
			noOfCols = 9;
		}
		commonPage.validateTheTableHeaderTitles(transactionDetailsTable, noOfCols, columnValuesExpected);
	}

	public void validateTheTransactionFilterCriteriaOptions() {
		isDisplayed(accountList, "Account List in transaction filter");
		isDisplayed(cardNoInTransactionFilter, "Card no in transaction filter");
		isDisplayed(costCenterInTransactionFilter, "Cost center in transaction filter");
		isDisplayed(receiptNo, "Receipt Number in transaction filter");
		isDisplayed(fromDate, "From Date in transaction filter");
		isDisplayed(toDate, "To Date in transaction filter");
		isDisplayed(productList, "Product List in transaction filter");
		isDisplayed(driverNameField, "Driver Name in transaction filter");
		isDisplayed(licensePlateField, "License Plate in transaction filter");
	}

	public void getTheCurrentDate() {
		dateGenerated = getAttribute(fromDate, "value");
	}
	public void selectATransactionWithoutCardAndVerify() {
		if(transactionWithoutCardNumber.equals("present")) {
			isDisplayedThenClick(locationEmptyCardNumber,"Empty Card Number" );
			isDisplayed(transactionSundryDetail,"Transaction Sundry Detail");
			
		}
	}

	public void generateADateBeforeThreeMonths() {
		try {
			Date dateGen = new SimpleDateFormat("dd/MM/yyyy").parse(dateGenerated);
			Date newDate;
			Calendar cal = Calendar.getInstance();
			cal.setTime(dateGen);
			cal.add(Calendar.MONTH, -3);
			newDate = cal.getTime();
			DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
			dateTo = df.format(newDate);
			fromDate.clear();
			isDisplayedThenEnterText(fromDate, "From date", dateTo);
		} catch (Exception e) {
			logFail(e.getMessage());
		}
	}

	public void selectAllAccountsInTrasactionSearchFilter() {
		selectDropDownByVisibleText(accountList, "All Accounts");
	}

	public void selectProductListFromDropDown() {
		
		//selectDropDownByVisibleText(productList, "SYNERGY DIESEL");
		selectDropDownOptionsRandomly(productList,"Transaction Product List");
		
	}
	public boolean getACardNumberWithTransaction() {
		sleep(5);
		getTheCurrentDate();
		generateADateBeforeThreeMonths();
		isDisplayedThenClick(searchButton, "Search button");
		int randomNo = 0;
		boolean isTransactionPresent = true;
		sleep(10);
		if (getRowSize(transactionDetailsTable) > 3) {
			setCellDataFromTable(transactionDetailsTable, 9, true);
			int cardWithTransaction = listedTransactionWithCard.size();
			logInfo("Listed Card Transaction:" + cardWithTransaction);
			if (cardWithTransaction > 1) {
				randomNo = getRandomNumber(0, listedTransactionWithCard.size() - 1);
			}
			cardNumberChoosen = getText(listedTransactionWithCard.get(randomNo));
		} else {
			logInfo("No Transactions present");
			isTransactionPresent = false;
		}
		return isTransactionPresent;
	}

	public void enterACardNumberInSearchFilter() {
		isDisplayedThenEnterText(cardNoInTransactionFilter, "Card number", cardNumberChoosen);
	}

	public void validateSearchResultsAndClickViewTransactionsOption(boolean checkCardResults) {
		sleep(5);
		if (checkCardResults) {
			logInfo("Card Number Choosen::" + cardNumberChoosen);
			if (listedTransaction.size() >= 1) {
				for (int i = 0; i < listedTransactionWithCard.size(); i++) {
					if (!(getText(listedTransactionWithCard.get(i)).equals(cardNumberChoosen))) {
						logFail("Expected Transaction search result doesn't match with the card number given in filter");
					}
				}
			} else {
				logFail("Expected card transaction not present in table");
			}
		}
		int randomNo = 0;
		if (listedTransactionWithCard.size() > 1) {
			randomNo = getRandomNumber(0, listedTransaction.size() - 1);
		}
		isDisplayedThenClick(listedTransactionWithCard.get(randomNo), "Card Number");
		sleep(1);
		isDisplayedThenClick(detailsMenuOption, "Details Menu Option");
		sleep(7);
	}

	public void verifyTransactionDetailsHeaderTitle() {
		verifyText(pageTitle, "Transaction Detail");
	}

	public void validateTransactionPageFields(String customerOrMerc) {
		//isDisplayed(captureType, "Capture Type");
		// isDisplayed(gstTotal, "GST Total");
		isDisplayed(location, "Location");
		isDisplayed(refNo, "Reference Number");
		//isDisplayed(terminalId, "Terminal Id");
		isDisplayed(dateTime, "Date Time");
		sleep(3);
	//	 isDisplayed(transactionStatus, "Transaction Status");
	//	isDisplayed(transactionType, "Transaction Type");
		isDisplayed(cardNumber, "Card Number");
		if (customerOrMerc.equals("Customer")) {
			isDisplayed(authorisationNo, "Authorisation Number");
			isDisplayed(costCenter, "Cost Center");
			isDisplayed(driverId, "Driver Id");
			//isDisplayed(odometer, "Odometer reading");
			isDisplayed(orderNo, "Order Number");
			isDisplayed(totalFees, "Total Fees");
			isDisplayed(totalInTransaction, "Total In transaction");
			isDisplayed(vehicleCheck, "Vehicle Check");
			isDisplayed(vehicleId, "Vehicle Id");
		}
	}

	public void checkPresenceOfExportSettlementOption() {
		isDisplayed(exportToExcel, "Export Settlements to excel");
	}

	public void checkPresenceOfSearchSettlementOption(String locOrMerc) {
//		if (locOrMerc.contains("Loc")) {
//			isDisplayed(searchTransactionSettlement, "Search settlement option");
//		} else {
			isDisplayed(searchTransactionSettlementMerc, "Search settlement option");
		//}
	}

	public void checkPresenceOfSettlementSearchFilterFields() {
		isDisplayed(enquiryStartDate, "Enquiry Start Date");
		isDisplayed(locationNumber, "Location Number");
	}

	public void validateTheSettlementsTableFields() {
		String[] columnValuesExpected = new String[] { "Processed", "Date/Batch", "Location No", "Detail", "Status",
				"Gross Amt", "Contrib.", "Variance", "Net Amount" };
		commonPage.validateTheTableHeaderTitles(settlementTable, 9, columnValuesExpected);
	}

	EMAPHomePage emapHomePage = new EMAPHomePage(driver, test);

	public boolean checkLoginHaveTransactionDetails(String locOrMerc) {
		emapHomePage.clickHomeMenuAndValidatePage(locOrMerc);
		sleep(10);
		int numberOfAccountOnThisUser = getDropdownSize(accountDropDown);
		boolean isTransactionFound = false;
		int i = 0;
		while (i < numberOfAccountOnThisUser && !isTransactionFound) {
			selectDropDownByIndex(accountDropDown, i);
			emapHomePage.clickTransactionListAndValidatePage();
			getTheCurrentDate();
			generateADateBeforeThreeMonths();
			commonPage.clickSearchButton();
			sleep(10);
			validateTheTransactionsTableFields(locOrMerc);
			if (isAnyTransactionDetailPresent()) {
				isTransactionFound = true;
				break;
			} else {
				if (i == numberOfAccountOnThisUser - 1) {
					logFail("No accounts on this " + locOrMerc
							+ " user login have transactions posted on past 92 days. So transaction table contents can't be tested.");
				}
				emapHomePage.clickHomeMenuAndValidatePage(locOrMerc);
			}
			i++;
		}
		return isTransactionFound;
	}

	public boolean isAnyTransactionDetailPresent() {
		if (getRowSize(transactionDetailsTable) > 3) {
			return true;
		} else {
			return false;
		}
	}
}
