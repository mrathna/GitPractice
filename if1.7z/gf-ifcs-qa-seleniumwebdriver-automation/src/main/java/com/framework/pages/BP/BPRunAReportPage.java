package com.framework.pages.BP;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.aventstack.extentreports.ExtentTest;
import com.framework.basepage.BasePage;
import com.framework.pages.AJS.common.Common;
import com.framework.pages.OLS.common.FindAndUpdateCardPage;
import com.framework.repo.Locator;

public class BPRunAReportPage extends BasePage {
	@FindBy(how = How.ID, using = Locator.REPORT_TYPE_SEL)
	public WebElement selectReportTypeDropdown;
	@FindBy(how = How.ID, using = Locator.REPORT_DETAIL_SEL)
	public WebElement selectReportDetailDropdown;
	@FindBy(how = How.ID, using = Locator.RUN_REPORT_BUTTON)
	public WebElement clickReportButton;
	@FindBy(how = How.ID, using = Locator.CARD_STATUS)
	public WebElement cardStatus;
	@FindBy(how = How.XPATH, using = Locator.DOWNLOAD_A_REPORT_BUTTON)
	public WebElement downloadReportButton;

	@FindBy(how = How.ID, using = Locator.STORED_REPORTS_TYPE)
	public WebElement reportDetailDropdown;
	@FindBy(how = How.ID, using = Locator.CUS_NUM)
	public WebElement accountListDropdown;
	@FindBy(how = How.ID, using = Locator.RUN_ONE_TIME_RB)
	public WebElement runReportOnce;
	@FindBy(how = How.ID, using = Locator.RECURRING_REPORT_RB)
	public WebElement runRecurringReport;
	@FindBy(how = How.ID, using = Locator.SEND_EMAIL_RB)
	public WebElement contactEmailRadioButton;
	@FindBy(how = How.ID, using = Locator.SELECT_CONTACT)
	public WebElement contactEmailDropdown;
	@FindBy(how = How.ID, using = Locator.DOWNLOAD_DISPLAY_RB)
	public WebElement downloadReportRadioButton;
	@FindBy(how = How.ID, using = Locator.SEND_EMAIL_TEXT_RB)
	public WebElement sendEmailOther;
	@FindBy(how = How.ID, using = Locator.CONTACT_TEXT)
	public WebElement sendEmailOtherField;
	@FindBy(how = How.ID, using = Locator.REPORT_DELIVERY_ERRORMSG)
	public WebElement reportDeliveryErrorMsg;
	@FindBy(how = How.XPATH, using = Locator.REPORT_DELIVERY_FULLERRORMSG)
	public WebElement reportDeliveryFullErrorMsg;
	@FindBy(how = How.ID, using = Locator.APPLY_DATE_RANGE)
	public WebElement dateRange;
	@FindBy(how = How.XPATH, using = Locator.REPORT_DELIVERY)
	public List<WebElement> reportDelivery;
	@FindBy(how = How.XPATH, using = Locator.REPORT_SCHEDULING)
	public List<WebElement> reportSchedule;
	@FindBy(how = How.ID, using = Locator.DESCRIPTION_COMMON)
	public WebElement reportName;  
	@FindBy(how = How.ID, using = Locator.EMAIL_FULL_REPORT)
	public WebElement emailReport;
	@FindBy(how = How.ID, xpath=Locator.SCHEDULE_FREQUENCY_DROPDOWN)
	public WebElement scheduleFreqDD; 
	@FindBy(how = How.XPATH, using = Locator.SEL_MULTI_CUS)
	public WebElement multipleAccount; 
	@FindBy(how = How.XPATH, using = Locator.SELECT_LAST)
	public WebElement lastAccount;
	@FindBy(how = How.XPATH, using = Locator.CLOSE_POPUP)
	public WebElement closePopup;
	@FindBy(how = How.XPATH, using = Locator.SELECT_ACCTS)
	public WebElement selectAccount;
	@FindBy(how = How.ID, using = Locator.COMPRESS_EMAIL_ATT)
	public WebElement compressEmail; 
	@FindBy(how = How.XPATH, using = Locator.DATE_TO)
	public WebElement dateTO;
	@FindBy(how = How.XPATH, using = Locator.DATE_FROM)
	public WebElement dateFrom;

	@FindBy(how = How.XPATH, using = Locator.REPORTS_RUNAREPORT)
	public List<WebElement> reports;

	@FindBy(how = How.XPATH, using = Locator.REPORTDETAILS_RUNAREPORT)
	public List<WebElement> reportsDetail;
	
	@FindBy(how = How.NAME, using = Locator.REPORT_DETAIL_SEL)
    public WebElement reportDetailDropDownValue;
    @FindBy(how = How.ID, using = Locator.REPORT_TYPE_SEL)
    public WebElement reportTypeDropDown;
    @FindBy(how = How.NAME, using = Locator.APPLY_DATE_RANGE)
    public WebElement dateRangeDropDown;
    
    @FindBy(xpath = Locator.SELECT_ALL_LINK)
    public WebElement selectAllLink;

    @FindBy(xpath = Locator.SELECT_ACCOUNTS_BUTTON)
    public WebElement selectAccountsButton;

    @FindBy(how = How.XPATH, using = Locator.CHV_REG_NO)
    public WebElement regNoTable;

    @FindBy(css = Locator.ERROR_MESSAGE_REPORTS)
    public WebElement errorMessageInReports;

	public BPRunAReportPage(WebDriver driver, ExtentTest test) {
		super(driver, test);
		PageFactory.initElements(driver, this);
	}

	public void verifyRunReportPageFields() {
		isDisplayed(selectReportTypeDropdown, "Report Type Dropdown");
		isDisplayed(reportDetailDropdown, "Report Detail Dropdown");
		isDisplayed(accountListDropdown, "Account List Dropdown");
		isDisplayed(runReportOnce, "Run this report just once Radiobutton");
		isDisplayed(runRecurringReport, "Schedule new recurring report Radiobutton");
		isDisplayed(contactEmailRadioButton, "Send Contact Email option");
		isDisplayed(contactEmailDropdown, "Contact Email dropdown");
		isDisplayed(downloadReportRadioButton, "Download report Radiobutton");
		isDisplayed(sendEmailOther, "Send Email to other RadioButton");
		isDisplayed(sendEmailOtherField, "Send Email text field");
		isDisplayed(clickReportButton, "Run Report Button");
	}

	public void selectInputFromAccountTypeDropdown() {
		isDisplayed(selectReportTypeDropdown, "Select input from dropdown");
		selectInputFromDropdown(selectReportTypeDropdown, 1);
		sleep(3);
	}

	public void clickOnRunReportButton() {
		mouseHover(clickReportButton);
		isDisplayedThenActionClick(clickReportButton, "Run Report Button");
	}

	public void verifyReportDetailValidationMsg() {
		mouseHover(reportDeliveryErrorMsg);
		isDisplayed(reportDeliveryFullErrorMsg, "Report Delivery validation mesage");
		verifyText(reportDeliveryFullErrorMsg, getText(reportDeliveryErrorMsg) + "  must not be blank.");
	}

	public void clickAndVerifyanchorTag() {
		try {
			if (reportDeliveryErrorMsg.isDisplayed()) {
				String currentTagName = getTagNameForLocators(reportDeliveryErrorMsg);
				if (currentTagName.contains("a")) {
					logPass("Anchor Tag is displayed");
					actionClick(reportDeliveryErrorMsg);
					String errorRedFlag = getAttribute(contactEmailDropdown, "class");
					if (errorRedFlag.equals("errorRed")) {
						logPass("Contact Email dropdown field is highlighted");
					} else {
						logFail("Contact Email dropdown field is not highlighted");
					}
				} else {
					logFail("Anchor Tag is not displayed");
				}
			}
		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
	}
	
	public String enterValuesCreateRecurringReportAndValidate(HashSet<String> hSet)
	{	
		if(hSet!= null)
		{
			HashSet<String> reportTypeSet = getDataFromSet(hSet, 0);		
			HashSet<String> reportDetailSet=getDataFromSet(hSet, 1);		
			
			isDisplayed(selectReportTypeDropdown, "Report Type Dropdown");
			selectDifferentOptionInsteadOfAlreadyCreated(selectReportTypeDropdown, reportTypeSet,"");
			sleep(3);
			isDisplayed(reportDetailDropdown, "Report Detail Dropdown");
			selectDifferentOptionInsteadOfAlreadyCreated(reportDetailDropdown, reportDetailSet,"");		
			
			
		}
		
		else
		{
			isDisplayed(selectReportTypeDropdown, "Report Type Dropdown");
			String retportTypeDef = selectedStringFrmDropDown(selectReportTypeDropdown);
			selectDifferentValueInsteadOfDefault(selectReportTypeDropdown,retportTypeDef, "");
			sleep(3);
			isDisplayed(reportDetailDropdown, "Report Detail Dropdown");
			String reportDetailDefault = selectedStringFrmDropDown(reportDetailDropdown);
			selectDifferentValueInsteadOfDefault(reportDetailDropdown,reportDetailDefault, "");	
		}
		
			sleep(5);
		
			isDisplayed(accountListDropdown, "Account List Dropdown");
			String defaultAccount = selectedStringFrmDropDown(accountListDropdown);
			selectDifferentValueInsteadOfDefault(accountListDropdown, defaultAccount, "");		
			String reportType = selectedStringFrmDropDown(selectReportTypeDropdown);		
			String reportDetail = selectedStringFrmDropDown(reportDetailDropdown);
			
			System.out.println("---- reportType ---------"+reportType+"------ reportDetail ------- "+reportDetail);
			
			String createdreportData = reportType+"::"+reportDetail;
						
			isDisplayed(runReportOnce, "Run this report just once Radiobutton");		
			sleep(5);		
			isDisplayedThenClickRadioBTN(runRecurringReport, "Schedule new recurring report Radio button");
			sleep(10);
			scrollDownPage();
			isDisplayed(scheduleFreqDD, "Frequency");
			selectDifferentValueInsteadOfDefault(scheduleFreqDD, "(Select frequency)", "(Select frequency)");		
			isDisplayedThenClickRadioBTN(sendEmailOther, "Send Email to other RadioButton");
			sleep(3);
			isDisplayedThenEnterText(sendEmailOtherField, "Send Email text field","Anton.Joseph@wexinc.com");	
			//sleep(3);
			isDisplayedThenClick(clickReportButton, "Run Report Button");		
			sleep(3);		
			scrollUpPage();		
			checkTextInPageAndValidate("Congratulations!  Your report has been successfully setup", 15); 
			
			return createdreportData;
	}

/*
	 * get the ReportTypeDetail
	 */

	public void getReportTypeAndDetailInRunAReport() {
		System.out.println("Reports Count:" + reports.size());
		System.out.println("Reports Details Count:" + reportsDetail.size());
		String report, reportDetail;
		int startCount, afterCount;
		for (int i = 0; i < reports.size(); i++) {
			report = getText(reports.get(i));
			isDisplayedThenClick(reports.get(i), "Report Choosen"+ report);
			sleep(10);
			for (int j = 0; j < reportsDetail.size(); j++) {
				reportDetail = getText(reportsDetail.get(j));
				
				isDisplayedThenClick(reportsDetail.get(j), "Report Choosen"+reportDetail);
				sleep(10);
				try {
					if(driver.findElement(By.id("lform:dateRangeSelect")).isDisplayed()) {
						Select dateRange = new Select(driver.findElement(By.id("lform:dateRangeSelect")));
						dateRange.selectByVisibleText("Last 31 days");
						logInfo(reportDetail +" choosen with 'Last 31 days' date range");
					}
				}catch(NoSuchElementException ex){
					logInfo( reportDetail +" choosen without date range");
				}
				try {
					if(driver.findElement(By.xpath("//select[@id='lform:frequency_oid']")).isDisplayed()) {
						Select frequency = new Select(driver.findElement(By.xpath("//select[@id='lform:frequency_oid']")));
						frequency.selectByVisibleText("Report Immediate");
						logInfo(reportDetail +" choosen with 'Report Immediate' Frequency");
					}
				}catch(NoSuchElementException ex){
					logInfo( reportDetail +" choosen without frequency");
				}
				startCount = getCurrentDirFileCount("Downloads");
				scrollDownPage();
				sleep(2);
				if(!report.equals("Cards Activity - Bulk")) {
					isDisplayedThenClick(downloadReportRadioButton, "Download Report");
				}
				sleep(2);
				isDisplayedThenClick(downloadReportButton, "Run Report Button");
				sleep(2);
				try {
				if(driver.findElement(By.className("errorFull")).isDisplayed())
					logInfo(getText(driver.findElement(By.xpath("//div[@class='errorFull']/*[text()][1]"))));
				}catch(NoSuchElementException ex){
					afterCount = getCurrentDirFileCount("Downloads");
					if(afterCount == startCount+1) {
						logPass("Report downloaded successfully");
					}else {
						logFail("Report not downloaded successfully");
					}
					verifyReportFilePresenceUsingRegex();
				}
			}		
		}
	}

	public String downloadTheReportsOnRunReport(HashSet<String> hSet) {
		if (hSet != null) {
			System.out.println("Hash Set Of Reports:" + hSet);
			HashSet<String> reportTypeSet = getDataFromSet(hSet, 0);
			HashSet<String> reportDetailSet = getDataFromSet(hSet, 1);

			isDisplayed(selectReportTypeDropdown, "Report Type Dropdown");
			selectDifferentOptionInsteadOfAlreadyCreated(selectReportTypeDropdown, reportTypeSet, "");
			sleep(3);
			isDisplayed(reportDetailDropdown, "Report Detail Dropdown");
			selectDifferentOptionInsteadOfAlreadyCreated(reportDetailDropdown, reportDetailSet, "");
		}
		else {
			isDisplayed(selectReportTypeDropdown, "Report Type Dropdown");
			String retportTypeDef = selectedStringFrmDropDown(selectReportTypeDropdown);
			selectDifferentValueInsteadOfDefault(selectReportTypeDropdown, retportTypeDef, "");
			sleep(3);
			isDisplayed(reportDetailDropdown, "Report Detail Dropdown");
			String reportDetailDefault = selectedStringFrmDropDown(reportDetailDropdown);
			selectDifferentValueInsteadOfDefault(reportDetailDropdown, reportDetailDefault, "");
		}

		sleep(5);

		isDisplayed(accountListDropdown, "Account List Dropdown");
		String defaultAccount = selectedStringFrmDropDown(accountListDropdown);
		selectDifferentValueInsteadOfDefault(accountListDropdown, defaultAccount, "");
		String reportType = selectedStringFrmDropDown(selectReportTypeDropdown);
		String reportDetail = selectedStringFrmDropDown(reportDetailDropdown);

		System.out.println("---- reportType ---------" + reportType + "------ reportDetail ------- " + reportDetail);

		String createdreportData = reportType + "::" + reportDetail;

		isDisplayedThenClickRadioBTN(runReportOnce, "Run this report just once Radiobutton");
		sleep(5);
		// isDisplayedThenClickRadioBTN(runRecurringReport, "Schedule new recurring
		// report Radio button");
		sleep(10);
		scrollDownPage();
		// isDisplayed(scheduleFreqDD, "Frequency");
		// selectDifferentValueInsteadOfDefault(scheduleFreqDD, "(Select frequency)",
		// "(Select frequency)");
		isDisplayedThenClick(downloadReportRadioButton, "Download Report");
		isDisplayedThenClick(clickReportButton, "Run Report Button");
		sleep(3);
		scrollUpPage();

		return createdreportData;
	}

	
	
	

	/**
	 * Selecting Report Filter
	 */
	public void reportFilter() {
		logInfo("Report Filters - Selecting Account");
		if(accountListDropdown.isDisplayed()) {
			selectDropDownByIndex(accountListDropdown, 0);
			sleep(2);
		} else {
			logInfo("Account Details not present");
		}
		logInfo("Selecting Mulitple Accounts");
		multipleAccount.click();
		sleep(2);
		lastAccount.click();
		selectAccount.click();
		sleep(2);
		logInfo("Selecting Date Range");
		if(dateRange.isDisplayed()) {
			sleep(2);
			selectDropDownByVisibleText(dateRange,"Last 12 calendar months");
			sleep(1);
		} else {
			logInfo("Date range Option not present");
		}
	}

	/**
	 * Report Scheduling
	 * @param reportOption
	 * @param schedulingType
	 */
	public void reportScheduling(String reportOption,String schedulingType) {
		if(schedulingType.equals("Run this report just once")) {
			sleep(5);
			runReportOnce.click();
			sleep(5);
			reportDelivery();
		} else {
			runRecurringReport.click();
			sleep(2);
			String reportDetailText = reportName.getAttribute("value");
			if(reportOption.equals(reportDetailText)) {
				logInfo("Selected Report is displaying in Report Scheduling "+reportDetailText);
			} else {
				logInfo("Selected Report is not displaying in Report Scheduling");
			}
			emailReport.click();
			selectDropDownByVisibleText(scheduleFreqDD,"Calendar Month");
			sleep(2);	
			reportDelivery();
		}

	}

	/**
	 * Selecting - Report Delivery
	 */
	public void reportDelivery() {
		int reportDeliverySize = reportDelivery.size();
		if(reportDeliverySize>0) {
			for(WebElement reportDeliveryType:reportDelivery) {
				if(reportDeliveryType.getAttribute("data-summary-value").equals("Send to contact email:")) {
					reportDeliveryType.click();
					sleep(2);
					if(contactEmailDropdown.isDisplayed()) {
						selectInputFromDropdown(contactEmailDropdown, 1);
						selectDropDownByVisibleText(contactEmailDropdown,"(Select Contact)");
					} else {
						logInfo("No Contact Email is listed in Send to Contact Dropdown");
					}
				} else if(reportDeliveryType.getAttribute("data-summary-value").equals("Download and display")) {
					reportDeliveryType.click();
					sleep(2);
				} else {
					reportDeliveryType.click();
					// Executing person's mail id can be added here
					if(sendEmailOtherField.isDisplayed()) {
						enterText(sendEmailOtherField,"karuppasamy.pandi@wexinc.com");
						sleep(2);
						if(compressEmail.isSelected()) {
							logInfo("Already Option Checked");
						} else {
							isDisplayedThenClick(compressEmail, "Click Compress email attachment");
							sleep(3);
						}							
						runReport();
					} else {
						logInfo("No Email is entered");
					}
				}
			}
		}
	}

	/**
	 * Report Generation - Run Report
	 */
	public void runReport() {
		clickReportButton.click();
		sleep(2);
		boolean successStatus = waitToCheckElementIsDisplayed(By.xpath("//div[@id='successMsg']"),60); 
		if(successStatus) {
			logPass("Reported Generation Successfully");
		} else {
			logInfo("Reported Not Generated");
		}
	}



	/**
	 * Run Report Type - Transactions 
	 * @param reportDetailOption
	 */
	public void runTransactionReport(String reportDetailOption) {
		logInfo("Report Type - Selecting Report type");
		if(selectReportTypeDropdown.isDisplayed()) {
			selectDropDownByVisibleText(selectReportTypeDropdown,"Transactions");
			sleep(2);
		} else {
			logInfo("Report Type Option is not present");
		}
		logInfo("Selecting Report Detail");
		if(selectReportDetailDropdown.isDisplayed()) {
			List<WebElement> reportDetailValues= selectDropdownOptionValues(selectReportDetailDropdown);
			if(reportDetailValues.size()>0) {
				for(WebElement reportDetailValue:reportDetailValues) {
					if(reportDetailValue.getText().equals(reportDetailOption)) {
						reportDetailValue.click();
						reportFilter();
						reportScheduling(reportDetailOption,"Run this report just once");
						reportScheduling(reportDetailOption,"Schedule this as a new Recurring Report");			
						break;
					} else {
						logInfo("Current Option "+reportDetailValue.getText()+" Skips");
					}
				}
			} else {
				logInfo("Report Details options are not present");
			}

		}	else {
			logInfo("Report Details is not present");
		}
	}

public void selectReportType(String reportTypeName){
        Select reportType = new Select(reportTypeDropDown);
        reportType.selectByVisibleText(reportTypeName);
        sleep(3);
    }
    public void selectReportDetailValue(String reportDetailName) {
       
       selectDifferentValueInsteadOfDefault(reportDetailDropDownValue,"Customised Fleet Control Report","");
      /* Select reportDetail = new Select(reportDetailDropDownValue);
        reportDetail.selectByVisibleText(reportDetailName);*/
    }
    public void selectReportDateRange(String dateRangeValue){
        Select dateRange = new Select(dateRangeDropDown);
        dateRange.selectByVisibleText(dateRangeValue);
    }
	public void selectDownloadAndDisplayRadioButton(){
	    scrollDownPage();
        sleep(2);
//        waitForPageLoad(5);
        isDisplayedThenClickRadioBTN(downloadReportRadioButton, "Download Report");
    }
	/*
    Click on RunReport button
     */
    public void clickRunReportButton(){
	    sleep(2);
	    isDisplayedThenClick(downloadReportButton, "RunReport Button");
	    sleep(5);
	    try{
	    	errorMessageInReports.isDisplayed();
	       // isDisplayed(errorMessageInReports,"verify error message is displayed or not");
	        logFail("Report is not generated");
        }catch(Exception e){
	        logPass("report generated successfully");
        }
    }
	
    /*
    Validate specific column value based on row value
     */
    public void validateDriverNameOfEachAccountNumberInGeneratedReport(){
        Common common = new Common(driver,test);
        String downloadedFileName = getLatestDownloadedFileFromDir("ExportTransactionFiles").getName();
        String name = StringUtils.substringBefore(downloadedFileName, ".");
        String excelFilePath = common.convertCsvToXLSWithFilepath(name,System.getProperty("user.home") + "\\Downloads\\");
        
        System.out.println("Name of the downloaded file :::::"+ downloadedFileName);
        System.out.println("Name of the file :::::"+ name);
        
        System.out.println("excel file path::::"+excelFilePath);
    //    ExcelUtils eu = new ExcelUtils();
    //    HSSFSheet sheet = eu.readExcel(excelFilePath,"Transactions");
        //String accNumber = eu.getCellValueUsingRowIndexAndColumnName(sheet,0,1,"Customer Number");
      //  String driverName = eu.getCellValueUsingRowIndexAndColumnName(sheet,1,1,"Driver Name");
        
       // System.out.println("Account number from file : "+accNumber);
        //System.out.println("Driver Name from file : "+driverName);

        List<String> accNumber = common.getExcelDataInListByColName(excelFilePath,"Customer Number"); 
        
        System.out.println("Driver Name from file : "+accNumber);
        List<String> driverNames = common.getExcelDataInListByColName(excelFilePath,"Driver Name");
        
        BPHomePage bpHomePage = new BPHomePage(driver,test);
        bpHomePage.loadFindAndUpdateCardPage();
        FindAndUpdateCardPage findAndUpdateCardPage = new FindAndUpdateCardPage(driver,test);
		
		  Iterator<String> itr1 = accNumber.iterator(); 
		  Iterator<String> itr2 = driverNames.iterator(); 
		  Map<String, String> map = new HashMap<>();
		  while(itr1.hasNext() || itr2.hasNext())
			  map.put(itr1.next(), itr2.next());
		  
		  selectDropDownByVisibleText(findAndUpdateCardPage.accountListDropdown,"All Accounts");
		  selectDropDownByVisibleText(findAndUpdateCardPage.cardStatus,"--Select All--");
		  
		  String expDriverName = null;
		  String actDriverName = null;
		  for(Map.Entry<String, String> entry : map.entrySet()){
			  
			  if(!entry.getValue().equals("Driver Name") )
			  {
			  sleep(10);
		  enterText(findAndUpdateCardPage.multiCardSearch, entry.getValue()); 
		  
		  System.out.println("Expected Driver name :::::"+entry.getValue());
		  sleep(2);
		  findAndUpdateCardPage.clickSearchCard(); 
		   expDriverName = entry.getValue(); 
		   actDriverName = findAndUpdateCardPage.driverNameOfACard.getText();
		  
			  }
		  if(expDriverName.equals(actDriverName)) {
		  logPass("Driver Name Correctly added in Report"); }
		  
		  else {
		  logFail("Driver Name Not Correctly added in Report"); }
		  }
		 
        
      //  common.deleteFileFromSpecificLocation(excelFilePath);
       // common.deleteFileFromSpecificLocation(System.getProperty("user.home") + "\\Downloads\\"+downloadedFileName);
    }
    
    public void selectAllAccounts(){
	    scrollDownPage();
	    sleep(1);
        isDisplayedThenClick(multipleAccount,"Clicking on selectMultipleAccounts link");
        sleep(4);
        isDisplayedThenClick(selectAllLink,"clicking on selectAll link");
        JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;
        String zoomInJS = "document.body.style.zoom='80%'";
        jsExecutor.executeScript(zoomInJS);
        sleep(3);
        jsExecutor.executeScript("arguments[0].click();", selectAccountsButton);
        jsExecutor.executeScript("document.body.style.zoom='100%'");
    }
}

