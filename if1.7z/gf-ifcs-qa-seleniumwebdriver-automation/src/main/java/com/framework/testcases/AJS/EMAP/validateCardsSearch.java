package com.framework.testcases.AJS.EMAP;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.SearchPage;
import com.framework.pages.AJS.common.Common;
import com.framework.pages.AJS.common.IFCSHomePage;
import com.framework.pages.AJS.common.IFCSLoginPage;

public class validateCardsSearch extends BaseTest{
		@Parameters({ "clientCountry", "clientName", "cardType" })
		@Test( groups = { "Regression" })
		public void validateSearchCards(@Optional("HK") String clientCountry, @Optional("EMAP") String clientName,
				@Optional("Vehicle") String cardType) {
			test = extent.createTest(clientName+ ":" +clientCountry+"  Verify Search Cards", "Verifying Search cards");
			// creating object for the Pages
			IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
			IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
			SearchPage searchInputs = new SearchPage(driver, test);
			Common common = new Common(driver, test);
			IFCSloginPage.login("IFCS_URL_EMAP", "IFCS_EMAP_USERNAME", "IFCS_EMAP_PASSWORD");
			IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, cardType);
			IFCSHomePage.gotoSearchAndClickCards();
			common.performBlankSearchAndValidate();
			// Select client from dropdown and validate
			searchInputs.selectClientInDropDownAndSearch("Client", clientName + "_" + clientCountry);
			// Search customer number
			searchInputs.enterCustomerNumberAndSearch(clientName + "_" + clientCountry);
			// Enter a Driver Name and select the Search button
			//common.searchDriverNameAndValidate("Full");
			// Enter a Part Driver Name and use the Wildcard (*) symbol and select the
			// Search button
			//common.searchDriverNameAndValidate("Partial");
			// Enter a Card Number and select the Search button
			common.searchCardnumberAndValidate("Full", "Filter By");
			// Enter a Card Number and use the Wildcard (*) symbol and select the Search
			// button
			common.searchCardnumberAndValidate("Partial", "Filter By");
			// Enter a Cost Centre and select the Search button and validate
			//common.searchCostCentreValueAndValidate("Full");
			// Enter a Part Cost Centre and use the Wildcard (*) symbol and select the
			// Search button and validate
			//common.searchCostCentreValueAndValidate("Partial");
			// Enter a VRN and select the Search button and validate
			//common.searchVRNValueAndValidate("Full");
			// Enter a Part VRN and use the Wildcard (*) symbol and select the Search button
			// and validate
			//common.searchVRNValueAndValidate("Partial");
			// Enter a Vehicle Description and select the Search button and validate
			//common.searchVehicleDescriptionAndValidate("Full");
//			// Enter a Part Vehicle Description and use the Wildcard (*) symbol and select
//			// the Search button and validate
			//common.searchVehicleDescriptionAndValidate("Partial");
			// Enter a Vehicle Id and select the Search button and validate
			//common.searchVehicleIdAndValidate("Full");
			// Enter a Part Driver Id and use the Wildcard (*) symbol and select the Search
			// button and validate
			//common.searchVehicleIdAndValidate("Partial");
			// Enter a Driver Id and select the Search button and validate
		//	common.searchDriverIdAndValidate("Full");
			// Enter a Part Driver Id and use the Wildcard (*) symbol and select the Search
			// button and validate
		//	common.searchDriverIdAndValidate("Partial");
			// Enter does not exist driver name and validate
			searchInputs.enterUnknownDriverNameAndSearch();
			IFCSHomePage.exitIFCS();
		}

}
