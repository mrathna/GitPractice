﻿using AventStack.ExtentReports;
using AventStack.ExtentReports.Reporter;
using BoDi;
using Common;
using Common.ScenarioConfigurations;
using Common.Utility;
using NUnit.Framework;
//using Microsoft.Expression.Encoder.ScreenCapture;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.IE;
//using OpenQA.Selenium.PhantomJS;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Reflection;
using System.Text;
using System.Xml.Linq;
using TechTalk.SpecFlow;

namespace Common
{
    [Binding]
    public class GlobalHooks : BaseHooks
    {
        public GlobalHooks(ScenarioContext scenarioContext, FeatureContext featureContext, IObjectContainer container, GlobalSettings settings) : base(scenarioContext, featureContext, container, settings) { }

        private string _videoPath;

        [BeforeTestRun]
        public static void InitializeLogger()
        {
            Logger.CreateInstance("EncompassLogger");

            // Initialize Extent Reports for UI
            _uiExtent = new ExtentReports();
            string extentReportPath = GlobalSettings.UiReportPath;
            string reportPath = Path.Combine(extentReportPath, $"{DateTime.Now.ToString("yyyyMMdd_hhmmss")}.html");
            _uiHtmlReporter = new ExtentV3HtmlReporter(reportPath);
            string extentConfig = GlobalSettings.ReportConfigPath;
            _uiHtmlReporter.LoadConfig(extentConfig);
            _uiExtent.AttachReporter(_uiHtmlReporter);
            _uiExtent.AddSystemInfo("Environment", GlobalSettings.Environment.ToUpper());
            _uiExtent.AddSystemInfo("FI", GlobalSettings.FI);
            _uiExtent.AddSystemInfo("Browser to Run: ", GlobalSettings.Browser);

            // Initialize Extent Reports for API
            _apiExtent = new ExtentReports();
            extentReportPath = GlobalSettings.ApiReportPath;
            string apiExtentReportPath = Path.Combine(extentReportPath, $"{DateTime.Now.ToString("yyyyMMdd_hhmmss")}.html");
            _apiHtmlReporter = new ExtentV3HtmlReporter(apiExtentReportPath);
            _apiHtmlReporter.LoadConfig(extentConfig);
            _apiExtent.AttachReporter(_apiHtmlReporter);
            _apiExtent.AddSystemInfo("Environment", GlobalSettings.Environment.ToUpper());
            _apiExtent.AddSystemInfo("FI", GlobalSettings.FI);

            Console.WriteLine("BeforeTestRun \"InitializeLogger\"-> done.");
        }

        [BeforeStep(Order = 0)]
        public void StepInitialization(ScenarioContext scenarioContext)
        {
            scenarioContext.StepContext.Add(STEP_IDENTIFIER_KEY, Guid.NewGuid());
        }

        #region ApiHooks        

        [BeforeScenario("API")]
        public void BeforeApiScenario()
        {
            try
            {
                _apiTest = _apiExtent.CreateTest(_scenarioContext.ScenarioInfo.Title);
                _settings.EnCompassExtentTest = _apiTest;
                Logger.StartScenarioLog(this._scenarioContext.ScenarioInfo.Title);
				// RUpam :  Debug code for Parallel Execution
				var id = Guid.NewGuid().ToString();
				_settings.Scenario.Add("ID", id);
				_settings.EnCompassExtentTest.Debug("Before API Scenario");
			}
            catch (Exception ex)
            {
                Logger.LogError("Exception Caught in hooks BeforeApiScenario:" + ex.Message);
                throw ex;
            }
        }

        [AfterScenario("API")]
        public void AfterApiScenario()
        {
            String title = this._scenarioContext.ScenarioInfo.Title;
            Logger.EndScenarioLog(this._scenarioContext.ScenarioInfo.Title);
            
			// RUpam :  Debug code for Parallel Execution
			_settings.EnCompassExtentTest.Debug("After Step API, ScenarioCtxID: " + _settings.Scenario["ID"].ToString());
		}

        [BeforeStep("API")]
        public void LogStepStartForApi()
        {
            Logger.StartStepLog(this._scenarioContext.StepContext.StepInfo.Text);
			// RUpam :  Debug code for Parallel Execution
			_settings.EnCompassExtentTest.Debug("Before Step API, ScenarioCtxID: " + _settings.Scenario["ID"].ToString());
		}

        [AfterStep("API")]
        public void LogStepResult()
        {
            LogStepResult(_settings.Scenario , false);
			// RUpam :  Debug code for Parallel Execution
			_settings.EnCompassExtentTest.Debug("After Step API, ScenarioCtxID: " + _settings.Scenario["ID"].ToString());			
        }

        #endregion

        #region UiHooks

		[BeforeScenario("UX", Order = 0)]
        [BeforeScenario("UXScrumRegression", Order = 0)]
        [BeforeScenario("Prod", Order = 0)]
        [BeforeScenario("HighLevel", Order = 0)]
        [BeforeScenario("ExchangeNet")] 
		[BeforeScenario("CardOrdering", Order = 0)]
        [BeforeScenario("PreFunds", Order = 0)]
        [BeforeScenario("SecureFunds", Order = 0)]
		[BeforeScenario("CreateSuperUsers", Order = 0)]
        [BeforeScenario("GFMIntegrationTest", Order = 0)]
        [BeforeScenario("MQLive", Order = 0)]
        public void PrepScenarioLogging()
        {
            Logger.StartScenarioLog(_scenarioContext.ScenarioInfo.Title);
            _uiTest = _uiExtent.CreateTest(_scenarioContext.ScenarioInfo.Title);
            if (!String.IsNullOrWhiteSpace(GlobalSettings.FI))
                _uiTest.Info("FI is:" + GlobalSettings.FI);
            _settings.EnCompassExtentTest = _uiTest;
            _settings.EnCompassExtentTest.Info("Before Scenario \"PrepScenarioLogging\"-> done.");

            // Get the Days before org is scheduled to delete and store in scenario config
            _settings.Scenario["DaysToStoreBeforeOrgDeletion"] = GlobalSettings.DaysBeforeOrgDeletion;
            _settings.EnCompassExtentTest.Info("Stored the value of DaysBeforeOrgDeletion in Scenario Context as " + _settings.Scenario["DaysToStoreBeforeOrgDeletion"].ToString());
        }

        private bool _isVideoRecordingRequired = false;

		[BeforeScenario("UX")]
        [BeforeScenario("UXScrumRegression")]
        [BeforeScenario("Prod")]
        [BeforeScenario("HighLevel")]
        [BeforeScenario("ExchangeNet")]
		[BeforeScenario("CardOrdering")]
        [BeforeScenario("PreFunds")]
        [BeforeScenario("SecureFunds")]
		[BeforeScenario("CreateSuperUsers")]
        [BeforeScenario("GFMIntegrationTest")]
        [BeforeScenario("MQLive")]
        public void LoadWebDriver()
        {
			// Do the Video recording only if its a High Level test for now 
			// Temporary hack - until we get the disc space issue resolved for video storage
			/*_isVideoRecordingRequired = (_scenarioContext.ScenarioInfo.Tags.Contains("HighLevel") || _featureContext.FeatureInfo.Tags.Contains("HighLevel"));
			// start the video recording
			if (_isVideoRecordingRequired)
			{
				_videoPath = "./Screenshots/" + ScreenshotHelper.StartScreenCapture(_scenarioContext.ScenarioInfo.Title, _scenarioContext);
				_uiTest.Info("Started Video Capture.");
			}*/

			try
	{
				Console.WriteLine("Before Scenario \"LoadWebDriver\"-> Starting.");
				List<string> scenarioTags = _settings.Scenario.ScenarioInfo.Tags.ToList().Select(s => s.ToUpperInvariant().Trim()).ToList();
				bool browserFlag = false;

				if (!scenarioTags.Select(s => s.ToUpperInvariant()).Contains(GlobalSettings.Browser))
				{
					// Chrome is the only browser that is not explicity set at scenario level
					if (GlobalSettings.Browser.Equals(GlobalSettings.Browsers.CHROME.ToString()))
						browserFlag = true;
				}
				else
					browserFlag = true;


				if (browserFlag)
				{
					_settings.EnCompassWebDriver = GetSeleniumDriver(TimeSpan.FromMinutes(3));
					_settings.EnCompassExtentTest.Info("Maximized WebDriver instance");
					_settings.EnCompassWebDriver.Manage().Timeouts().PageLoad = TimeSpan.FromMinutes(3);
					_settings.EnCompassExtentTest.Info("PageLoad timeout set to 3 mins.");
					_settings.EnCompassWebDriver.Manage().Timeouts().AsynchronousJavaScript = TimeSpan.FromMinutes(3);
					_settings.EnCompassExtentTest.Info("Asynchronous JS timeout set to 3 mins.");
					if (!_browserDetailsSet)
					{
						_uiExtent.AddSystemInfo("Device Type : ", GlobalSettings.DeviceType);
						_uiExtent.AddSystemInfo("Browser Running : ", _BrowserName);
						_uiExtent.AddSystemInfo("Browser Version : ", _BrowserVersion);
						_uiExtent.AddSystemInfo("Platform : ", _BrowserPlatform);
						_uiExtent.AddSystemInfo("Browser is JS Enabled : ", _BrowserJSEnabled);
						_uiExtent.AddSystemInfo("Browser is Mob Emulation Enabled : ", _BrowserMobEmulEnabled);
						_uiExtent.AddSystemInfo("Mobile Device Name : ", _MobileDeviceName);
                        _uiExtent.AddSystemInfo("Mobile OS : ", _MobileOS);
                        _uiExtent.AddSystemInfo("Mobile OS Version : ", _MobileOSVersion);
						_browserDetailsSet = true;
					}
				}
				else
				{
					_settings.EnCompassExtentTest.Skip("The target browser: " + GlobalSettings.Browser
					   + " is not valid for the scenario:" + _settings.Scenario.ScenarioInfo.Title);
					throw new InvalidOperationException("Invalid Browser");
				}

				Console.WriteLine("Before Scenario \"LoadWebDriver\"-> done.");
			}
			catch (InvalidOperationException ex)
			{
				throw ex;
			}
			catch (Exception ex)
			{
				_settings.EnCompassExtentTest.Fatal("Unable to instantiate WebDriver. Exception in LoadWebDriver");
				_settings.EnCompassExtentTest.Info("Exception Details:");
				_settings.EnCompassExtentTest.Info("Exception Message : " + ex.Message);
				_settings.EnCompassExtentTest.Info("Exception StackTrace : " + ex.StackTrace);
				_settings.EnCompassExtentTest.Info("Exception Source : " + ex.Source);
				// If exception is thrown in Before Scenario then After Scenario does not get executed
				// Kill browser / webdriver process if at all any was spinned up
				//WebDriverTearDown();
				//KillAllProcess();
				throw ex;
			}
        }

        [BeforeScenario("TACO")]
        public void LoadData()
        {
            var tacoSource = new TacoScenarioConfiguration();
            var testTag = _scenarioContext.ScenarioInfo.Tags.FirstOrDefault(t => t.StartsWith("Test:"));
            var groupTag = _scenarioContext.ScenarioInfo.Tags.FirstOrDefault(t => t.StartsWith("Group:"));

            if (!string.IsNullOrWhiteSpace(testTag))
            {
                tacoSource.TestName = testTag.Replace("Test:", string.Empty);
                tacoSource.TestName = tacoSource.TestName
                    .Replace('\'', ' ')
                    .Replace('=', '-'); // Added this to satisfy NUnits Category Attribute to not have -'s (hyphen) in it. So all -'s will be replaced with = while querying.
            }
            if (!string.IsNullOrWhiteSpace(groupTag))
            {
                tacoSource.GroupName = groupTag.Replace("Group:", string.Empty); ;
                tacoSource.GroupName = tacoSource.GroupName
                    .Replace('\'', ' ')
                    .Replace('=', '-'); // Added this to satisfy NUnits Category Attribute to not have -'s (hyphen) in it. So all -'s will be replaced with = while querying.
            }

            tacoSource.LoadData();
            _settings.ScenarioConfiguration = tacoSource;
        }

		[AfterScenario("UX")]
        [AfterScenario("UXScrumRegression")]
        [AfterScenario("Prod")]
        [AfterScenario("HighLevel")]
        [AfterScenario("ExchangeNet")]
		[AfterScenario("CardOrdering")]
        [AfterScenario("PreFunds")]
        [AfterScenario("SecureFunds")]
		[AfterScenario("CreateSuperUsers")]
		[AfterScenario("GFMIntegrationTest")]
        [AfterScenario("MQLive")]
        public void AfterScenarioUI()
        {
            /*
			//stop video recording if ScreenCaptureJob object was initialized
			if (_scenarioContext.TryGetValue("ScreenCaptureObject", out ScreenCaptureJob scj))
			{
				scj.Stop();
				_settings.EnCompassExtentTest.Info("Stopped Video Capture");
					//"Video Recording of Scenario:  ", MediaEntityBuilder.CreateScreenCaptureFromPath("file:///" + scj.OutputScreenCaptureFileName).Build());
				//_settings.EnCompassExtentTest.Log(Status.Info, "Vide Recording of Scenario: " + _settings.EnCompassExtentTest.AddScreencast(_videoName));
			} */

            WebDriverTearDown();
            KillAllProcess();
			_settings.ScenarioConfiguration = new StandardScenarioConfiguration();
            _settings.EnCompassExtentTest.Info("After Scenario \"AfterScenarioUI\"-> done.");
        }
		
        [AfterScenario(Order = int.MaxValue)]
        public void AfterScenario()
        {
			_settings.EnCompassExtentTest.Info("After Scenario \"AfterScenario\"-> starting.");
			_settings.EnCompassExtentTest.Debug("Scenario Error Count: " + _settings.ScenarioErrors.Count().ToString());

			if (GlobalSettings.DeviceType.Equals(GlobalSettings.Device.MOBILE.ToString()))
            {
                // If its running in Browser Stack (i.e Sessionid !Null) then
                // send a PUT call to set the session id status to "Failed" in Browser Stack Console
                if (_settings.Scenario.ContainsKey("SessionId"))
				{
                    if (_settings.Scenario["SessionId"] != null)
                    {
                        string reqString = null;

                        if (_settings.ScenarioErrors.Any())
                            reqString = "{\"status\":\"failed\", \"reason\":\"From Bamboo\"}";
                        else
                            reqString = "{\"status\":\"passed\", \"reason\":\"From Bamboo\"}";

                        byte[] requestData = Encoding.UTF8.GetBytes(reqString);
                        Uri myUri = new Uri(string.Format(GlobalSettings.BrowserStackAPIUrl + "/sessions/" + _settings.Scenario["SessionId"].ToString() + ".json"));
                        _settings.EnCompassExtentTest.Debug("Browser Stack API Url :" + myUri.AbsoluteUri);
                        WebRequest myWebRequest = HttpWebRequest.Create(myUri);
                        HttpWebRequest myHttpWebRequest = (HttpWebRequest)myWebRequest;
                        _settings.EnCompassExtentTest.Debug("HttpWebRequest object created");
                        myWebRequest.ContentType = "application/json";
                        myWebRequest.Method = "PUT";
                        myWebRequest.ContentLength = requestData.Length;
                        using (Stream st = myWebRequest.GetRequestStream()) st.Write(requestData, 0, requestData.Length);

                        NetworkCredential myNetworkCredential = new NetworkCredential(GlobalSettings.BrowserStackUser, GlobalSettings.BrowserStackKey);
                        _settings.EnCompassExtentTest.Debug("NetworkCredential object created");
                        CredentialCache myCredentialCache = new CredentialCache();
                        myCredentialCache.Add(myUri, "Basic", myNetworkCredential);
                        myHttpWebRequest.PreAuthenticate = true;
                        myHttpWebRequest.Credentials = myCredentialCache;
                        _settings.EnCompassExtentTest.Debug("Credential Cache object added to HttpWebRequest");
                        WebResponse response = myWebRequest.GetResponse();
                        _settings.EnCompassExtentTest.Debug("WebRequest successfully executed, got Response object");
                        _settings.EnCompassExtentTest.Debug(response.GetResponseStream().ToString());
                        response.Close();
                        _settings.EnCompassExtentTest.Debug("WebResponse closed");
                    }
				}

				if (_settings.ScenarioErrors.Any())
					throw new AggregateException(_settings.ScenarioErrors.Select(e => e.Error));
			}

            _settings.EnCompassExtentTest.Info("After Scenario \"AfterScenario\"-> done.");
        }

		[BeforeStep("UX")]
        [BeforeStep("UXScrumRegression")]
        [BeforeStep("Prod")]
        [BeforeStep("HighLevel")]
        [BeforeStep("ExchangeNet")]
		[BeforeStep("CardOrdering")]
        [BeforeStep("PreFunds")]
        [BeforeStep("SecureFunds")]
		[BeforeStep("CreateSuperUsers")]
		[BeforeStep("GFMIntegrationTest")]
        [BeforeStep("MQLive")]
        public void LogStepStart()
        {
            Logger.StartStepLog(_scenarioContext.StepContext.StepInfo.Text);
            _settings.EnCompassExtentTest.Info("Before Step \"LogStepStart\"-> done.");
        }

		[AfterStep("UX")]
        [AfterStep("UXScrumRegression")]
        [AfterStep("Prod")]
        [AfterStep("HighLevel")]
        [AfterStep("ExchangeNet")]
		[AfterStep("CardOrdering")]
        [AfterStep("PreFunds")]
        [AfterStep("SecureFunds")]
		[AfterStep("CreateSuperUsers")]
		[AfterStep("GFMIntegrationTest")]
        [AfterStep("MQLive")]
        public void LogStepResultWithScrnshot()
		{
			Console.WriteLine("After Step \"LogStepResultWithScrnshot\"-> starting.");
			// include a screenshot if this is a UI test
			bool includeScreenshot =    _scenarioContext.ScenarioInfo.Tags.Any(t => t.Equals("UX", StringComparison.InvariantCultureIgnoreCase)) ||
                                        _scenarioContext.ScenarioInfo.Tags.Any(t => t.Equals("UXScrumRegression", StringComparison.InvariantCultureIgnoreCase)) ||
                                        _scenarioContext.ScenarioInfo.Tags.Any(t => t.Equals("Prod", StringComparison.InvariantCultureIgnoreCase)) ||
                                        _scenarioContext.ScenarioInfo.Tags.Any(t => t.Equals("GFMIntegrationTest", StringComparison.InvariantCultureIgnoreCase)) ||
                                        _scenarioContext.ScenarioInfo.Tags.Any(t => t.Equals("HighLevel", StringComparison.InvariantCultureIgnoreCase)) ||
                                        _featureContext.FeatureInfo.Tags.Any(t => t.Equals("UX", StringComparison.InvariantCultureIgnoreCase)) ||
                                        _featureContext.FeatureInfo.Tags.Any(t => t.Equals("UXScrumRegression", StringComparison.InvariantCultureIgnoreCase)) ||
                                        _featureContext.FeatureInfo.Tags.Any(t => t.Equals("GFMIntegrationTest", StringComparison.InvariantCultureIgnoreCase)) ||
                                        _featureContext.FeatureInfo.Tags.Any(t => t.Equals("Prod", StringComparison.InvariantCultureIgnoreCase)) ||
                                        _featureContext.FeatureInfo.Tags.Any(t => t.Equals("CardOrdering", StringComparison.InvariantCultureIgnoreCase));

            LogStepResult(_scenarioContext, includeScreenshot);
            _settings.EnCompassExtentTest.Info("After Step \"LogStepResultWithScrnshot\"-> done.");
        }

        #endregion

        [AfterTestRun]
        public static void FlushExtentReport()
        {
            try
            {
                Console.WriteLine("AfterTestRun \"FlushExtentReport\" -> starting ");
                //KillAllProcess();
                _uiExtent.Flush();
                _apiExtent.Flush();
                Console.WriteLine("After Test Run \"FlushExtentReport\"-> done.");
            }
            catch (DirectoryNotFoundException e)
            {
                Logger.LogError("Could not find the directory to flush Extent Reports : " + e.Message);
                Console.WriteLine("Could not find the directory to flush Extent Reports : " + e.Message);
            }
            catch (Exception ex)
            {
                Logger.LogError("Unable to flush Extent Reports : " + ex.Message);
                Console.WriteLine("Unable to flush Extent Reports : " + ex.Message);
            }
        }


        #region Private Methods

        private void WebDriverTearDown()
        {
            if (_settings.EnCompassWebDriver != null)
            {
                try
                {
                    _settings.EnCompassExtentTest.Info("Inside WebDriverTearDown method");
                    _settings.EnCompassWebDriver.Dispose();
                    _settings.EnCompassExtentTest.Info("Disposed webdriver");
                }
                catch (Exception) { _settings.EnCompassExtentTest.Error("Problem while Disposing webdriver"); }				
			}
        }

        private static List<string> _processKillList = new List<string>
        {
            "chromedriver",
            "geckodriver",
            "IEDriverServer",
            "chrome",
            "firefox",
            "iexplore",
            "phantomjs",
            "EXCEL",
			"WinAppDriver"
        };

        private void KillAllProcess()
        {
            try
            {
                _settings.EnCompassExtentTest.Info("Inside KillAllProcess method");
                List<System.Diagnostics.Process> _pList = System.Diagnostics.Process.GetProcesses().ToList();
                // Kill all hanging process if any provided the setting is turned on. Its turned 'ON' by default
                // turn it off in app settings for local executions or driver it via bamboo variable
                if (GlobalSettings.KillProcessPostExecution)
                {
                    _settings.EnCompassExtentTest.Info("GlobalSettings.KillProcessPostExecution is set to ON");
                    _pList.ForEach(p =>
                    {
                        if (_processKillList.Contains(p.ProcessName))
                        {
                            try
                            {
                                p.Kill();
                                _settings.EnCompassExtentTest.Info("Killed Process : " + p.ProcessName);
                                Console.WriteLine("Killed Process : " + p.ProcessName);
                            }
                            catch (Exception e)
                            {
                                _settings.EnCompassExtentTest.Info("Exception thrown while trying to kill the Process : " + p.ProcessName);
                                Console.WriteLine("Exception thrown while trying to kill the Process : " + p.ProcessName);
                                _settings.EnCompassExtentTest.Info("Exception message : " + e.Message);
                                Console.WriteLine("Exception message : " + e.Message);
                            }
                        }
                        else
                        {
                            Console.WriteLine("Could not find Process : " + p.ProcessName + " in process list :" + string.Join(",", _processKillList.ToArray()));
                        }
                    });
                }
                else
                    _settings.EnCompassExtentTest.Info("Kill Process Post Execution turned Off");
            }
            catch (Exception e)
            {
                _settings.EnCompassExtentTest.Info("Exception thrown while Killing Processes for browser and webdriver after scenario.");
                throw e;
            }
        }
    }

    #endregion


}