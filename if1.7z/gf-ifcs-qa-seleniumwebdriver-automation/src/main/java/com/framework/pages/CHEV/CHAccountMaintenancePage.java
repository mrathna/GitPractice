package com.framework.pages.CHEV;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.ExtentTest;
import com.framework.basepage.BasePage;
import com.framework.repo.Locator;

public class CHAccountMaintenancePage extends BasePage {

	@FindBy(how = How.XPATH, using = Locator.SCHEDULE_REPORT_MAINTENANCE_PAGE)
	public WebElement accountMaintenanceTitle;

	@FindBy(how = How.ID, using = Locator.CH_ACCOUNT_MAINTENANCE_STREET_ADDRESS)
	public WebElement physicalAddressTitle;

	@FindBy(how = How.ID, using = Locator.CH_ACCOUNT_MAINTENANCE_POSTAL_ADDRESS)
	public WebElement postalAddressTitle;

	@FindBy(how = How.ID, using = Locator.PHYSICAL_ADDRESS)
	public WebElement physicalAddress;

	@FindBy(how = How.ID, using = Locator.POSTALCODE)
	public WebElement physicalPostalCode;

	@FindBy(how = How.ID, using = Locator.STATE_PHY)
	public WebElement physicalState;

	@FindBy(how = How.ID, using = Locator.MERCHANT_PHYSICAL_COUNTRY)
	public WebElement physicalCountry;

	@FindBy(how = How.ID, using = Locator.MERCHANT_POSTAL_CONTACT_MAILING_ADDRESS)
	public WebElement postalMailingAddress;

	@FindBy(how = How.ID, using = Locator.MERCHANT_POSTAL_CONTACT_MAILING_POSTALCODE)
	public WebElement postalZipCode;

	@FindBy(how = How.ID, using = Locator.MERCHANT_POSTAL_CONTACT_MAILING_SATE)
	public WebElement postalState;

	@FindBy(how = How.ID, using = Locator.MERCHANT_POSTAL_COUNTRY)
	public WebElement postalCountry;

	@FindBy(how = How.ID, using = Locator.CONTACT_NAME)
	public WebElement contactName;

	@FindBy(how = How.ID, using = Locator.EMAIL_FIELD)
	public WebElement emailField;

	@FindBy(how = How.ID, using = Locator.JOBTITLE_FIELD)
	public WebElement jobTitleField;

	@FindBy(how = How.ID, using = Locator.PHONE_FIELD)
	public WebElement phoneField;

	@FindBy(how = How.ID, using = Locator.MOBILE_FIELD)
	public WebElement mobileField;

	@FindBy(how = How.ID, using = Locator.FAX_FIELD)
	public WebElement faxField;

	@FindBy(how = How.ID, using = Locator.AU_SAVE)
	public WebElement saveButton;
	
	@FindBy(how = How.ID, using = Locator.CH_MERCHANT_CONTACT_TYPE_TABLE)
	public WebElement contactTypeColumn;
	
	@FindBy(how = How.ID, using = Locator.CH_MERCHANT_DEFAULT_CONTACT_TYPE_TABLE)
	public WebElement defaultContactTypeColumn;
	
	@FindBy(how = How.ID, using = Locator.CH_MERCHANT_CONTACT_NAME_TABLE)
	public WebElement contactNameColumn;
	
	@FindBy(how = How.ID, using = Locator.CH_MERCHANT_CONTACT_PHONE_TABLE)
	public WebElement contactPhoneColumn;
	
	@FindBy(how = How.ID, using = Locator.CH_MERCHANT_CONTACT_EMAIL_TABLE)
	public WebElement contactEmailColumn;
	

	public CHAccountMaintenancePage(WebDriver driver, ExtentTest test) {
		super(driver, test);
		PageFactory.initElements(driver, this); 
	}

	public void verifyAccountMaintenancePage() {
		sleep(3);
		isDisplayed(accountMaintenanceTitle, "Account maintenance");
		logPass("Redirected to the Transaction Status Page");
	}

	public void verifyContactTableColumns() {
		verifyText(contactTypeColumn, "Contact Type");
		verifyText(contactEmailColumn, "Email");
		verifyText(defaultContactTypeColumn, "Default for This Contact Type");
		verifyText(contactNameColumn, "Name");
		verifyText(contactPhoneColumn, "Phone");
	}
	
	public void verifyLocationMaintenancePage() {
		sleep(3);
		isDisplayed(accountMaintenanceTitle, "Location maintenance");
		logPass("Redirected to the Location Maintenance Page"); 
	}

	public void verifyAddressTitles() {
		isDisplayed(physicalAddressTitle, "Physical Address is displayed");
		isDisplayed(postalAddressTitle, "Postal Address is displayed");
	}

	public void verifyIfSaveIsEnabled() {
		if (saveButton.isEnabled()) {
			logInfo("Save button is enabled");
		} else {
			logPass("Save button is not enabled");
		}
	} 

	public void verifyIfFieldsAreEditable() {
		checkAnElementIsDisabled(physicalAddress, "Physical Address");
		checkAnElementIsDisabled(physicalPostalCode, "Physical Postal Code");
		checkAnElementIsDisabled(physicalState, "Physical State");
		checkAnElementIsDisabled(physicalCountry, "Physical Country");
		checkAnElementIsDisabled(postalMailingAddress, "Postal Mail Address");
		checkAnElementIsDisabled(postalZipCode, "Postal Zip code");
		checkAnElementIsDisabled(postalState, "Postal State");
		checkAnElementIsDisabled(contactName, "Contact Name");
		checkAnElementIsDisabled(emailField, "Contact Email");
		checkAnElementIsDisabled(jobTitleField, "Contact Job Title");
		checkAnElementIsDisabled(phoneField, "Contact phone");
		checkAnElementIsDisabled(mobileField, "Contact mobile");
		checkAnElementIsDisabled(faxField, "Contact Fax field");
	}

}
