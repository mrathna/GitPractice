﻿using AventStack.ExtentReports;
using Common;
using Common.Utility;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using NFluent;

namespace EnCompass.Testing.Source.PageObjects.Organization.ExpenseManager.AllocationManagement
{
	public class AllocationCodeEdit : EnCompassOrgPageModel
	{
		public AllocationCodeEdit(GlobalSettings settings) : base(settings) { }

		public override string RelativeUrl => @"/expenseManager/allocationManagement/AllocationCodeEdit.aspx";
		public override string PageIdentifierXPath_Generated => @"//h1[normalize-space(text())='Create' or text() = 'Edit']";

        #region XPath page Elements
        private const string _financialCodeGroupXpath = @"//select[contains(@id, 'FinancialCodeGroups')]";
        private const string _financialCodeValueXpath = @"//input[contains(@id, 'FinancialCodeValue')]";
        private const string _descriptionXpath = @"//textarea[contains(@id, 'Description')]";
        private const string _enabledCheckboxXpath = @"//input[contains(@id, 'cbEnabled')]";
        private const string _enabledCheckboxLabelXpath = @"//label[contains(@for, 'cbEnabled')]";
        private const string _approverDropdownXpath = @"//select[contains(@id, 'ddlApprovers')]";
        private const string _thresholdTextBoxXpath = @"//input[contains(@id, 'thresholdValue')]";
        private const string _saveBtnXpath = @"//input[@type='submit']";
        private const string _cancelBtnXpath = @"//input[contains(@id, 'btnCancel')]";
        private const string APPROVER_FIELD = "//select[contains(@id, 'ddlApprovers')]";
        private const string THRESHOLD_FIELD = "//input[contains(@id, 'thresholdValue')]";
        #endregion

        #region Page Elements
        private IWebElement _financialCodeGroup
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_financialCodeGroupXpath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Info("Found _view");
                return element;
            }
        }

        private IWebElement _financialCodeValue
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_financialCodeValueXpath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Info("Found _view");
                return element;
            }
        }

        private IWebElement _description
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_descriptionXpath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Info("Found _view");
                return element;
            }
        }

        private IWebElement _enabledCheckbox
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_enabledCheckboxXpath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Info("Found _view");
                return element;
            }
        }

        private IWebElement _enabledCheckboxLabel

        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_enabledCheckboxLabelXpath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Info("Found _view");
                return element;
            }
        }

        private IWebElement _approverDropdown
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_approverDropdownXpath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Info("Found _view");
                return element;
            }
        }

        private IWebElement _thresholdTextBox
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_thresholdTextBoxXpath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Info("Found _view");
                return element;
            }
        }

        private IWebElement _saveBtn
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_saveBtnXpath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Info("Found _view");
                return element;
            }
        }

        private IWebElement _cancelBtn
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_cancelBtnXpath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Info("Found _view");
                return element;
            }
        }
        #endregion

        public void SelectFinancialCodeGroupByText(string whichText)
		{
			// Mobile specific change
			_financialCodeGroup.SetListboxByText(whichText, SelectTextOptions.Exact, Driver, Settings, _financialCodeGroupXpath);
			this.WaitForLoad();
		}

		/// <summary>
		/// Create Button 
		/// </summary>
		public void Create()
		{
			_saveBtn.JSClickWithFocus(Driver);
			this.AttachOnDemandScreenShot();
			Settings.EnCompassExtentTest.Debug("Clicked on Create Button");
		}

		public void PressCancel()
		{
			_cancelBtn.JSClickWithFocus(Driver);
		}

		/// <summary>
		/// Enable Fin Codes
		/// </summary>
		public bool Enable
		{
			set
			{
				_enabledCheckbox.SetCheckboxStateWithLabel(_enabledCheckboxLabel, value);
				Settings.EnCompassExtentTest.Info("Enable set to :" + value);
			}
		}

		/// <summary>
		/// Set Fin Code Value
		/// </summary>
		public string FinancialCodeValue
		{
			get { return _financialCodeValue.GetAttribute("value"); }
			set
			{
				_financialCodeValue.ForceDocumentLoadOnSendKeys(value, Settings.EnCompassWebDriver);
				Settings.EnCompassExtentTest.Info("Fin Code set to :" + value);
			}
		}

		/// <summary>
		/// Set Fin Code Description
		/// </summary>
		public string Description
		{
			get { return _description.GetAttribute("value"); }
			set
			{
				_description.ForceDocumentLoadOnSendKeys(value, Settings.EnCompassWebDriver);
				Settings.EnCompassExtentTest.Info("Fin Code Description set to :" + value);
			}
		}

		public string Threshold
		{
			get { return _thresholdTextBox.GetAttribute("value"); }
			set { _thresholdTextBox.ForceDocumentLoadOnSendKeys(value, Settings.EnCompassWebDriver); }
		}

		public void SelectApprover(string whichText)
		{
			var selectElement = new SelectElement(_approverDropdown);
			selectElement.SelectByText(whichText);
		}

        public void VerifyApproverThresholdDisplay()
        {
            Settings.EnCompassWebDriver.WaitForVisible(By.XPath(APPROVER_FIELD));
            Settings.EnCompassWebDriver.WaitForVisible(By.XPath(THRESHOLD_FIELD));
        }

        public void VerifyApproverThresholdUnavailable()
        {
            Settings.EnCompassWebDriver.WaitForAbsence(By.XPath(APPROVER_FIELD));
            Settings.EnCompassWebDriver.WaitForAbsence(By.XPath(THRESHOLD_FIELD));
        }

        public void EditFinancialCode(string approver, string threshold, ExtentTest test)
        {
            SelectApprover(approver);
            test.Info("Select approver to edit");
            Threshold = threshold;
            test.Info("Edit threshold value");
            Create();
            test.Info("Click save button");
        }

    }
}
