﻿using Common;
using EnCompass.Testing.Source.PageObjects.Controls;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EnCompass.Testing.Source.PageObjects.Organization.SecurityManager.AccountManagement
{
	[PageModel(@"/securityManager/accountManagement/accountHistory.aspx")]
	public partial class AccountHistory : EnCompassOrgPageModel
	{
		public override string RelativeUrl => @"/securityManager/accountManagement/accountHistory.aspx";
		public override string PageIdentifierXPath_Override => @"//li[@class='breadcrumb-item active'][text() = 'Create User Account' or text() = 'User History']";

		private GridControl _userHistory;
		public GridControl UserHistory
		{
			get
			{
                GridControl grid = _userHistory ?? (_userHistory = new GridControl("dgUserHistory", Driver));
                grid.WaitForGrid();
                return grid;
			}
		}

		public AccountHistory(GlobalSettings settings) : base(settings) { }
	}
}
