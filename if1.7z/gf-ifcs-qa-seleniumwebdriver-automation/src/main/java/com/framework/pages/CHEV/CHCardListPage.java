package com.framework.pages.CHEV;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.ExtentTest;
import com.framework.basepage.BasePage;
import com.framework.repo.Locator;

public class CHCardListPage extends BasePage {

	@FindBy(how = How.ID, using = Locator.SEARCH_BTN)
	public WebElement searchCards;

	@FindBy(how = How.XPATH, using = Locator.ADHOC_REPORTS_TITLE)
	public WebElement cardListPageTitle;

	@FindBy(how = How.XPATH, using = Locator.CH_FIRSTCARD_FROM_CARDSLIST)
	public WebElement firstCardsNumberFromCardsList;
	
	@FindBy(how = How.XPATH, using = Locator.CH_SECONDCARD_FROM_CARDSLIST)
	public WebElement secondCardsNumberFromCardsList;

	@FindBy(how = How.XPATH, using = Locator.CH_CHANGE_STATUS)
	public WebElement changeCardStatus;

	@FindBy(how = How.XPATH, using = Locator.CH_CHANGE_STATUS_ACCOUNT_NUMBER)
	public WebElement accountNumber;

	@FindBy(how = How.XPATH, using = Locator.CH_EDIT_CARD_STATUS)
	public WebElement editCardStatus;

	@FindBy(how = How.ID, using = Locator.EXPORT_CARD_TOEXCEL)
	public WebElement exportButton;

	@FindBy(how = How.ID, using = Locator.CH_CARD_LIST_ACC_NO_TITLE)
	public WebElement accNoSubTitle;

	@FindBy(how = How.ID, using = Locator.CH_CARD_LIST_CARD_NO_TITLE)
	public WebElement cardNoSubTitle;

	@FindBy(how = How.ID, using = Locator.CH_CARD_LIST_REG_NO_TITLE)
	public WebElement licenseSubTitle;

	@FindBy(how = How.ID, using = Locator.CH_CARD_LIST_CARD_STATUS_TITLE)
	public WebElement cardStatusSubTitle;

	@FindBy(how = How.ID, using = Locator.CH_CARD_LIST_CARD_OFFER_TITLE)
	public WebElement cardOfferSubTitle;

	@FindBy(how = How.ID, using = Locator.CH_CARD_LIST_VEHICLE_DESC_TITLE)
	public WebElement vehicleDescSubTitle;

	@FindBy(how = How.ID, using = Locator.CH_CARD_LIST_COST_CENTRE_TITLE)
	public WebElement costCenterSubTitle;

	@FindBy(how = How.ID, using = Locator.CH_CARD_LIST_DRIVER_TITLE)
	public WebElement driverSubTitle;

	@FindBy(how = How.ID, using = Locator.CH_CARD_LIST_REF_NUM_TITLE)
	public WebElement refNoSubTitle;

	@FindBy(how = How.ID, using = Locator.CURRENT_CARD_NUMBER)
	public WebElement cardNumberTextBox;

	@FindBy(how = How.XPATH, using = Locator.CH_CARD_LIST_CARD_DETAILS)
	public WebElement cardDetailsMenu;

	@FindBy(how = How.XPATH, using = Locator.VIEW_CARD_CL)
	public WebElement cardPageTitle;


	@FindBy(how = How.XPATH, using = Locator.CH_CARD_LIST_VERIFY_PIN)
	public WebElement verifyPinMenu;

	@FindBy(how = How.XPATH, using = Locator.CH_CARD_LIST_SEARCH_RES_CARD_NO)
	public WebElement cardListSearchCardNumber;

	@FindBy(how = How.XPATH, using = Locator.CH_CARD_LIST_SEARCH_RES_CURR_CARD_STATUS)
	public WebElement cardListSearchCardStatus;

	@FindBy(how = How.XPATH, using = Locator.CH_CARD_LIST_SEARCH_RES_CARD_OFFER)
	public WebElement cardListSearchCardOffer;

	@FindBy(how = How.XPATH, using = Locator.CH_CARD_LIST_SEARCH_RES_REGO_NO)
	public WebElement cardListSearchRegisteredNo;

	@FindBy(how = How.XPATH, using = Locator.CH_CARD_LIST_SEARCH_RES_DRIVER)
	public WebElement cardListSearchDriverName;

	@FindBy(how = How.XPATH, using = Locator.CH_CARD_LIST_SEARCH_RES_COST_CENTRE)
	public WebElement cardListSearchCostCentre;

	@FindBy(how = How.XPATH, using = Locator.CH_CARD_LIST_SEARCH_RES_ACC_NO)
	public WebElement cardListSearchAccountNo;

	@FindBy(how = How.XPATH, using = Locator.CH_CARD_LIST_SEARCH_RES_AVA_BAL)
	public WebElement cardListSearchAvailBal;

	@FindBy(how = How.XPATH, using = Locator.CH_CARD_LIST_CHANGE_STATUS)
	public WebElement cardListChangeStatusContextMenu;

	@FindBy(how = How.XPATH, using = Locator.CH_CARD_LIST_EDIT)
	public WebElement cardListEditContextMenu;

	@FindBy(how = How.XPATH, using = Locator.CH_CARD_LIST_RE_ISSUE_PIN)
	public WebElement cardListReIssuePinContextMenu;

	@FindBy(how = How.XPATH, using = Locator.CH_CARD_LIST_REPLACE_CARD)
	public WebElement cardListReplaceCardContextMenu;

	@FindBy(how = How.ID, using = Locator.CARD_STATUS)
	public WebElement cardStatusDropDown;

	@FindBy(how = How.ID, using = Locator.CH_VIEW_CARD_NUMBER_TITLE)
	public WebElement cardNumberTitle;

	@FindBy(how = How.ID, using = Locator.CH_VIEW_CARD_CARD_STATUS_TITLE)
	public WebElement cardStatusTitle;

	@FindBy(how = How.ID, using = Locator.CH_VIEW_CARD_OFFER_TITLE)
	public WebElement cardOfferTitle;

	@FindBy(how = How.ID, using = Locator.CH_VIEW_CARD_PRODUCT_TITLE)
	public WebElement cardProductTitle;

	@FindBy(how = How.ID, using = Locator.CH_VIEW_CARD_CARD_TYPE_TITLE)
	public WebElement cardTypeTitle;

	@FindBy(how = How.ID, using = Locator.CH_VIEW_CARD_CARD_EXPIRY_TITLE)
	public WebElement cardExpiryTitle;

	@FindBy(how = How.ID, using = Locator.CH_REISSUE_CONTROL_UPLOAD)
	public WebElement reissueUpload;

	@FindBy(how = How.ID, using = Locator.SEARCH_CARDS)
	public WebElement searchButton;
	
	@FindBy(how = How.ID, using = Locator.ACCOUNT_LIST)
	public WebElement accountOption;
	
	@FindBy(xpath=Locator.CHV_CARDTABLEDATA)
	public List<WebElement> cardTableData;
	

	public CHCardListPage(WebDriver driver, ExtentTest test) {
		super(driver, test);
		PageFactory.initElements(driver, this);
	}

	public void verifyCardPageTitle() {
		sleep(3);
		isDisplayed(cardListPageTitle, "Cards page");
		logPass("Redirected to the Cards Page");

	}

	public void enterCardNumber(String cardNumber) {
		sleep(3);
		if (cardNumberTextBox.isDisplayed()) {
			enterText(cardNumberTextBox, cardNumber);
		} else {
			logFail("Couldnot enter card number.");
		}
	}

	public void verifySearchButton() {

		if (searchCards.isDisplayed()) {
			logPass("Search Cards Button is displayed");
		} else {
			logFail("Search Cards Button is not displayed");
		}
	}

	public void clickSearchCard() {
		isDisplayedThenActionClick(searchCards, "Search Cards");
		sleep(7);
		scrollDownPage();
	}

	public void verifyPageSubTitles() {

		verifyText(accNoSubTitle, "Account Number");
		verifyText(cardNoSubTitle, "Card Number");
		// TODO This should be License Plate acc to test case
		verifyText(licenseSubTitle, "Rego No");
		verifyText(cardStatusSubTitle, "Card Status");
		verifyText(cardOfferSubTitle, "Card Offer");
		verifyText(vehicleDescSubTitle, "Vehicle Description");
		verifyText(costCenterSubTitle, "Cost Centre Code");
		verifyText(driverSubTitle, "Driver");
		verifyText(refNoSubTitle, "Reference Number");
	}

	public void verifyCardlistSearchtableHeaders() {

		verifyText(cardListSearchCardNumber, "Card Number");

		verifyText(cardListSearchCardOffer, "Card Offer");

		verifyText(cardListSearchCardStatus, "Current Card Status");

		verifyText(cardListSearchRegisteredNo, "Rego No");

		verifyText(cardListSearchDriverName, "Driver");

		verifyText(cardListSearchCostCentre, "Cost Centre");

		verifyText(cardListSearchAccountNo, "Account No");

		verifyText(cardListSearchAvailBal, "Avail Bal");
	}
	
	public void selectAllAccount() {
		selectDropDownByVisibleText(accountOption, "All Accounts");
		sleep(2);
	}

	public String getActiveCardNumber() {
		String cardNumber = null;
		selectAllAccount();
		selectDropDownByVisibleText(cardStatusDropDown, "Ready for use");
		sleep(2);
		clickSearchCard();
		boolean cardResult = waitForTextToAppear("No Cards found.",30); 
		if(!cardResult) {
			cardNumber = firstCardsNumberFromCardsList.getText();			
		} else {
		//	logInfo("No Search Result found");
			logInfo("No Active Card found");
		}

		return cardNumber;
	}
	
	public String getNextActiveCardNumber() {
		// TODO Auto-generated method stub
		String nextCardNumber=null;
		nextCardNumber = secondCardsNumberFromCardsList.getText();
		return nextCardNumber;
		
		
	}
	
	
	public void searchActiveCards() {
		 
		selectDropDownByVisibleText(cardStatusDropDown, "Active");
		sleep(2);
		searchCards.click();
		 
	}

	public void checkAccountNumber() {
		if (accountNumber.isDisplayed()) {
			logPass("Account number is displayed");
		} else {
			logFail("Account number is not displayed");
		}
	}

	/*
	 * Click First Card Number in Cards Table. The XPATh changed for the Chevron
	 * site
	 */
	public void clickFirstCardNumberFromCardsList() {
		sleep(3);
		if (firstCardsNumberFromCardsList.isDisplayed()) {
			actionClick(firstCardsNumberFromCardsList);
			logPass("Select first cards from Cards List");
		} else {
			logFail("Can't able to select the first cards from cards list");
		}
	}
	
	
	public void clickSecondCardNumberFromCardsList() {
		sleep(3);
		if (secondCardsNumberFromCardsList.isDisplayed()) {
			actionClick(secondCardsNumberFromCardsList);
			logPass("Select Second cards from Cards List");
		} else {
			logFail("Can't able to select the second cards from cards list");
		}
	}
	

	/*
	 * Click Change Status Option.
	 */
	public void pickChangeStatusOption() {
		sleep(3);
		mouseHover(changeCardStatus);
		if (changeCardStatus.isDisplayed()) {
			actionClick(changeCardStatus);
			logPass("Select Change status options successfully");
		} else {
			logFail("Can't able to select the change status options");
		}
	}

	/*
	 * Click Change Status Option.
	 */
	public void pickEditStatusOption() {
		sleep(3);
		mouseHover(cardListEditContextMenu);
		if (cardListEditContextMenu.isDisplayed()) {
			actionClick(cardListEditContextMenu);
			logPass("Select Edit Card status options successfully");
		} else {
			logFail("Can't able to select the edit status options");
		}
	}

	public void pickPinReIssueOption() {
		sleep(3);
		mouseHover(cardListReIssuePinContextMenu);
		if (cardListReIssuePinContextMenu.isDisplayed()) {
			actionClick(cardListReIssuePinContextMenu);
			logPass("Select Re Issue status options successfully");
		} else {
			logFail("Can't able to select the Re Issuue options");
		}
	}

	public void pickChangeStatusContextMenu() {
		sleep(3);
		mouseHover(cardListChangeStatusContextMenu);
		if (cardListChangeStatusContextMenu.isDisplayed()) {
			actionClick(cardListChangeStatusContextMenu);
			logPass("Select Change status options successfully");
		} else {
			logFail("Can't able to select the change status options");
		}
	}

	/*
	 * Click Change Status Option.
	 */
	public void pickCardDetailsOption() {
		sleep(3);
		mouseHover(cardDetailsMenu);
		if (cardDetailsMenu.isDisplayed()) {
			actionClick(cardDetailsMenu);
			logPass("Select Card details options successfully");
		} else {
			logFail("Can't able to select the card details options");
		}
	}

	public void verifyViewCardPage() {
		sleep(3);
		verifyText(cardPageTitle,"View Card");
		verifyText(cardNumberTitle,"Card Number");
		verifyText(cardStatusTitle,"Card Status");
		verifyText(cardOfferTitle,"Card Offer");
		verifyText(cardProductTitle,"Card Product");
		verifyText(cardTypeTitle,"Card Type");
		verifyText(cardExpiryTitle,"EXPIRY DATE");
	}

	public void pickReplaceCardOption() {
		sleep(3);
		mouseHover(cardListReplaceCardContextMenu);
		if (cardListReplaceCardContextMenu.isDisplayed()) {
			actionClick(cardListReplaceCardContextMenu);
			logPass("Replace Card details options successfully");
		} else {
			logFail("Can't able to select the replace card details options");
		}
	}

	public void verifyExportButton() {
		if (exportButton.isDisplayed()) {
			logPass("Export Button is displayed");
		} else {
			logFail("Export is not displayed");
		}

	}

	public void validateCardNumber(String cardNumber) {
		if (firstCardsNumberFromCardsList.isDisplayed()) {
			if (firstCardsNumberFromCardsList.getText().trim().equals(cardNumber)) {
				logPass("Card Number Matches");
			} else {
				logFail("Card Number not Matches");
			}
		} else {
			logFail("Search Results are empty");
		}

	}

	public void verifyContextMenu() {
		sleep(5);

		verifyText(cardDetailsMenu, "Card Details");

		logInfo("Change Pin expected but foung Verify Pin");

		verifyText(cardListChangeStatusContextMenu, "Change Status");

		verifyText(cardListEditContextMenu, "Edit");

		verifyText(cardListReIssuePinContextMenu, "Reissue PIN");

		verifyText(cardListReplaceCardContextMenu, "Replace Card");
	}
	public void verifyReissueUpload() {
		if(reissueUpload.isDisplayed()) {
			logPass("Upload Button present");
		} else {
			logFail("Upload Button not present");
		}
	}
	
	public void verifyBulkStatusChangeUpload() {
		if(searchButton.isDisplayed()) {
			logPass("Search present");
		} else {
			logFail("Search not present");
		}
	}

	public int getNumberOfActiveCards() {
		// TODO Auto-generated method stub
		sleep(4);
		return cardTableData.size();
		
	}

	public void clearActiveNumberInTextBox() {
		// TODO Auto-generated method stub
		
		if (cardNumberTextBox.isDisplayed()) {
			cardNumberTextBox.clear();
		} else {
			logFail("Couldnot clear card number.");
		}
		
	}

	
}
