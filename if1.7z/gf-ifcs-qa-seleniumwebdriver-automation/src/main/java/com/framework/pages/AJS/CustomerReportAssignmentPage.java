package com.framework.pages.AJS;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

import com.aventstack.extentreports.ExtentTest;
import com.framework.basepage.BasePage;
import com.framework.pages.AJS.common.Common;
import com.framework.repo.Locator_IFCS;

public class CustomerReportAssignmentPage extends BasePage{

	@FindBy(xpath=Locator_IFCS.REPORT_TYPE_POPUP)
	public WebElement reportTypePopUp;
	
	@FindBy(xpath=Locator_IFCS.SELECT_ADD)
	public WebElement reportsSelectAdd;
	
	//Added by Sasi on 10-04-19	
	@FindBy(xpath=Locator_IFCS.SELECT_ADD_REPORT_HIER)
	public WebElement reportHierarchySelectAdd;
		
	@FindBy(xpath=Locator_IFCS.SELECT_CHILD_ACCOUNT_IN_HIER)
	public WebElement selectChildAccountInHier;
		
	public CustomerReportAssignmentPage(WebDriver driver, ExtentTest test) {
		super(driver, test);
		PageFactory.initElements(new AjaxElementLocatorFactory(driver, 15), this);
	}

	CardMaintenancePage cardMaintenancePage = new CardMaintenancePage(driver, test);
	Common common = new Common(driver, test);
	MaintainCustomerPage maintainCustomerPage = new MaintainCustomerPage(driver, test);

	public void addIndividualReports() {
		// TODO Auto-generated method stub
		chooseSubMenuFromLeftPanel("Customer Reporting","Individual Reports");
	}
	
	public void addReportHier() {
		// TODO Auto-generated method stub
		chooseSubMenuFromLeftPanel("Hierarchies","Report Hierarchy");
		
	}
	
	public void addReportFinancialHier() {
		// TODO Auto-generated method stub
		chooseSubMenuFromLeftPanel("Hierarchies","Financial Hierarchy");
		
	}
	
	public void clickingChildCusInHier() {
		// TODO Auto-generated method stub
		Click(selectChildAccountInHier, "clicking child account");
		sleep(2);
		
	}
	
	public void chooseReportTypeFrequencyAndSaveTheReport(String reportName,String frequency,String reportAssignment) {
		Common common = new Common(driver, test);
		
		if(reportAssignment.equals("Report Hierarchy")) {		
		rightClick(reportHierarchySelectAdd);
				
		}else if(reportAssignment.equals("Financial Hierarchy")) {
		rightClick(reportHierarchySelectAdd);
		
		}else if(reportAssignment.equals("Individual Reports")) {
		rightClick(reportsSelectAdd);
		}
		
		sleep(5);
		// Add to Report
		common.addIteminPopup();
		
		// Handle message pop up
		common.clickOkButtonIfMsgPopupAppears();
		
		isDisplayed(reportTypePopUp, "Pop up");

		chooseOptionFromDropdown("Report Type",reportName);
		
		if(frequency.equals("")) 
			common.chooseARandomDropdownOption("Frequency");	
		else
			chooseOptionFromDropdown("Frequency",frequency);
		
		common.clickOkButton();
		sleep(3);
		
		common.clickSaveIcon();
		logInfo(reportName+" is assigned to the customer");
		
	}

	public void assigningIndividualReportsForMO() {

		chooseReportTypeFrequencyAndSaveTheReport("Bulk Card Order", "",
				"Individual Reports");
		chooseReportTypeFrequencyAndSaveTheReport("Bulk Card Order Exception", "",
				"Individual Reports");
		chooseReportTypeFrequencyAndSaveTheReport("Customer Bulk Reissue Card Report", "",
				"Individual Reports");
		chooseReportTypeFrequencyAndSaveTheReport("Bulk Card Update", "",
				"Individual Reports");
		chooseReportTypeFrequencyAndSaveTheReport("Bulk Card Update Exception", "",
				"Individual Reports");
		
		
	}
	
	public void assigningIndividualReportsForSG() {
		
		chooseReportTypeFrequencyAndSaveTheReport("Cer C Weekly Report", "",
				"Individual Reports");
		chooseReportTypeFrequencyAndSaveTheReport("Customer Statement(Standard)",
				"Report 7th,14th,21st,28th and EOM", "Individual Reports");
		chooseReportTypeFrequencyAndSaveTheReport("Vehicle Fleet Analysis",
				"Report End of Month", "Individual Reports");
		chooseReportTypeFrequencyAndSaveTheReport("CV Sales Transaction Report",
				"Report End of Month", "Individual Reports");
		chooseReportTypeFrequencyAndSaveTheReport("Card Transaction Invoice Report", "",
				"Individual Reports");
		chooseReportTypeFrequencyAndSaveTheReport("Customer Statement(Excl Duty)", "",
				"Individual Reports");
		chooseReportTypeFrequencyAndSaveTheReport("Ministry of Defence eInvoice",
				"Report End of Month", "Individual Reports");
		chooseReportTypeFrequencyAndSaveTheReport("Ministry of Defence Statement of Accounts",
				"Report End of Month", "Individual Reports");
		chooseReportTypeFrequencyAndSaveTheReport("Ministry of Defence Summary (By Amount)",
				"Report End of Month", "Individual Reports");
		chooseReportTypeFrequencyAndSaveTheReport("Ministry of Defence Summary (By Volume)",
				"Report End of Month", "Individual Reports");
		chooseReportTypeFrequencyAndSaveTheReport("Fleet Invoice Summary By Department",
				"Report End of Month", "Individual Reports");
		chooseReportTypeFrequencyAndSaveTheReport("Fleet Invoice Summary by Product (Fuels)",
				"Report End of Month", "Individual Reports");
		chooseReportTypeFrequencyAndSaveTheReport("SingTel Autopay Report",
				"Report End of Month", "Individual Reports");
		chooseReportTypeFrequencyAndSaveTheReport("SingTel Monthly Report",
				"Report End of Month", "Individual Reports");
		
	}

	public void assigningIndividualReportsForGU() {
		
		chooseReportTypeFrequencyAndSaveTheReport("Cer C Weekly Report", "",
				"Individual Reports");
		chooseReportTypeFrequencyAndSaveTheReport("Customer Statement(Standard)",
				"Report 7th,14th,21st,28th and EOM", "Individual Reports");
		chooseReportTypeFrequencyAndSaveTheReport("Vehicle Fleet Analysis",
				"Report End of Month", "Individual Reports");
		chooseReportTypeFrequencyAndSaveTheReport("CV Sales Transaction Report",
				"Report End of Month", "Individual Reports");
		chooseReportTypeFrequencyAndSaveTheReport("Card Transaction Invoice Report", "",
				"Individual Reports");
		chooseReportTypeFrequencyAndSaveTheReport("Customer Statement(Excl Duty)", "",
				"Individual Reports");
		chooseReportTypeFrequencyAndSaveTheReport("Ministry of Defence eInvoice",
				"Report End of Month", "Individual Reports");
		chooseReportTypeFrequencyAndSaveTheReport("Ministry of Defence Statement of Accounts",
				"Report End of Month", "Individual Reports");
		chooseReportTypeFrequencyAndSaveTheReport("Ministry of Defence Summary (By Amount)",
				"Report End of Month", "Individual Reports");
		chooseReportTypeFrequencyAndSaveTheReport("Ministry of Defence Summary (By Volume)",
				"Report End of Month", "Individual Reports");
		chooseReportTypeFrequencyAndSaveTheReport("Fleet Invoice Summary By Department",
				"Report End of Month", "Individual Reports");
		chooseReportTypeFrequencyAndSaveTheReport("Fleet Invoice Summary by Product (Fuels)",
				"Report End of Month", "Individual Reports");
		chooseReportTypeFrequencyAndSaveTheReport("SingTel Autopay Report",
				"Report End of Month", "Individual Reports");
		chooseReportTypeFrequencyAndSaveTheReport("SingTel Monthly Report",
				"Report End of Month", "Individual Reports");		
	}

	public void assigningIndividualReportsForSP() {
		
		chooseReportTypeFrequencyAndSaveTheReport("Customer Statement",
				"Report End of Month", "Individual Reports");
		chooseReportTypeFrequencyAndSaveTheReport("Vehicle Analysis Report - MPG",
				"Report End of Month", "Individual Reports");
		chooseReportTypeFrequencyAndSaveTheReport("CV Sales Transaction Report",
				"Report End of Month", "Individual Reports");
		chooseReportTypeFrequencyAndSaveTheReport("Card Transaction Invoice Report", "",
				"Individual Reports");
	}

	public void assigningIndividualReportsForHK() {

		chooseReportTypeFrequencyAndSaveTheReport("Customer Statement (Standard)",
				"Report 10th, 20th and EOM", "Individual Reports");
		chooseReportTypeFrequencyAndSaveTheReport("Vehicle Fleet Analysis",
				"Report 10th, 20th and EOM", "Individual Reports");
		chooseReportTypeFrequencyAndSaveTheReport("CV Sales Transaction Report",
				"Report End of Month", "Individual Reports");
		chooseReportTypeFrequencyAndSaveTheReport("Card Transaction Invoice Report", 
				"Report 10th, 20th and EOM","Individual Reports");
		chooseReportTypeFrequencyAndSaveTheReport("Customer Statement (Excl Duty)", 
				"Report 10th, 20th and EOM","Individual Reports");
		
	}

	public void assigningHierReportsForMO() {
		chooseReportTypeFrequencyAndSaveTheReport("Bulk Card Order", "",
				"Report Hierarchy");
		chooseReportTypeFrequencyAndSaveTheReport("Bulk Card Order Exception", "",
				"Report Hierarchy");
		chooseReportTypeFrequencyAndSaveTheReport("Customer Bulk Reissue Card Report", "",
				"Report Hierarchy");
		chooseReportTypeFrequencyAndSaveTheReport("Bulk Card Update", "",
				"Report Hierarchy");
		chooseReportTypeFrequencyAndSaveTheReport("Bulk Card Update Exception", "",
				"Report Hierarchy");	
	
		// Adding Report Hier for child
		clickingChildCusInHier();
		chooseReportTypeFrequencyAndSaveTheReport("Bulk Card Order", "",
				"Report Hierarchy");
	
	}

	public void assigningHierReportsForSG() {
		chooseReportTypeFrequencyAndSaveTheReport("Consolidated Invoice report",
				"", "Report Hierarchy");//Report Immediate
		chooseReportTypeFrequencyAndSaveTheReport("Card Transaction Invoice Report",
				"", "Report Hierarchy");
		chooseReportTypeFrequencyAndSaveTheReport("Consolidated Invoice report",
				"", "Report Hierarchy");
		chooseReportTypeFrequencyAndSaveTheReport("Card Transaction Invoice Report",
				"", "Report Hierarchy");
		chooseReportTypeFrequencyAndSaveTheReport("Consolidated Invoice report",
				"", "Report Hierarchy");
		
		// Adding Report Hier for child
		clickingChildCusInHier();
		chooseReportTypeFrequencyAndSaveTheReport("Card Transaction Invoice Report",
				"", "Report Hierarchy");
		clickingChildCusInHier();
		chooseReportTypeFrequencyAndSaveTheReport("CustomerStatement (Standard)",
				"","Report Hierarchy");
		clickingChildCusInHier();
		chooseReportTypeFrequencyAndSaveTheReport("Fleet Card Transaction Report",
				"", "Report Hierarchy");

		// Adding Report Financial Hier for parent
		addReportFinancialHier();
		// adding reports
		chooseReportTypeFrequencyAndSaveTheReport("Customer Statement (Standard)",
				"Report End of Month", "Financial Hierarchy");
	}

	public void assigningHierReportsForGU() {
		chooseReportTypeFrequencyAndSaveTheReport("Consolidated Invoice report",
				"Report Immediate", "Report Hierarchy");
		chooseReportTypeFrequencyAndSaveTheReport("Card Transaction Invoice Report",
				"Report Immediate", "Report Hierarchy");
		
		// Adding Report Hier for child
		clickingChildCusInHier();
		chooseReportTypeFrequencyAndSaveTheReport("Card Transaction Invoice Report",
				"Report Immediate", "Report Hierarchy");
		clickingChildCusInHier();
		chooseReportTypeFrequencyAndSaveTheReport("CustomerStatement (Standard)",
				"Report Immediate","Report Hierarchy");
		clickingChildCusInHier();
		chooseReportTypeFrequencyAndSaveTheReport("Fleet Card Transaction Report",
				"Report Immediate", "Report Hierarchy");

		// Adding Report Financial Hier for parent
		addReportFinancialHier();
		// adding reports
		chooseReportTypeFrequencyAndSaveTheReport("Customer Statement (Standard)",
				"Report End of Month", "Financial Hierarchy");
	}

	public void assigningHierReportsForSP() {
		chooseReportTypeFrequencyAndSaveTheReport("Consolidated Invoice report",
				"Report End of Month", "Report Hierarchy");
		
		// Adding Report Hier for child
		clickingChildCusInHier();
		chooseReportTypeFrequencyAndSaveTheReport("Card Transaction Invoice Report",
				"Report End of Month", "Report Hierarchy");
		clickingChildCusInHier();
		chooseReportTypeFrequencyAndSaveTheReport("Fleet Card Transaction Report",
				"Report End of Month", "Report Hierarchy");

		// Adding Report Financial Hier for parent
		addReportFinancialHier();
		// adding reports
		chooseReportTypeFrequencyAndSaveTheReport("Customer Statement",
				 "Report End of Month", "Financial Hierarchy");
	}

	public void assigningHierReportsForHK() {
		chooseReportTypeFrequencyAndSaveTheReport("Consolidated Invoice report",
				"Report 10th, 20th and EOM", "Report Hierarchy");
		chooseReportTypeFrequencyAndSaveTheReport("Card Transaction Invoice Report",
				"Report 10th, 20th and EOM", "Report Hierarchy");
		
		// Adding Report Hier for child
				clickingChildCusInHier();
				chooseReportTypeFrequencyAndSaveTheReport("Card Transaction Invoice Report",
						"Report 10th, 20th and EOM", "Report Hierarchy");
				clickingChildCusInHier();
				chooseReportTypeFrequencyAndSaveTheReport("Fleet Card Transaction Report",
						"Report 10th, 20th and EOM", "Report Hierarchy");

				// Adding Report Financial Hier for parent
				addReportFinancialHier();
				// adding reports
				chooseReportTypeFrequencyAndSaveTheReport("Customer Statement (Standard)",
						"Report 10th, 20th and EOM", "Financial Hierarchy");
	}
		
		


	
}


