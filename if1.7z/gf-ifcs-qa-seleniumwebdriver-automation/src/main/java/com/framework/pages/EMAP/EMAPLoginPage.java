package com.framework.pages.EMAP;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.ExtentTest;
import com.framework.basepage.BasePage;
import com.framework.repo.Locator;
import com.framework.util.PropUtils;

public class EMAPLoginPage extends BasePage {

	public EMAPLoginPage(WebDriver driver, ExtentTest test) {
		super(driver, test);
		PageFactory.initElements(driver, this);
	}

	@FindBy(how = How.XPATH, using = Locator.CLIENT_LOGO_IMG)
	public WebElement clientLogo;

	@FindBy(how = How.XPATH, using = Locator.PAGE_TITLE1)
	public WebElement accountPageTitle;

	@FindBy(how = How.XPATH, using = Locator.USER_ID_INPUT)
	public WebElement userIdInput;

	@FindBy(how = How.ID, using = Locator.USERID_SUBMIT_FOR_FORGOT_PASSWORD)
	public WebElement submitUserId;

	@FindBy(how = How.ID, using = Locator.CONFIRMATIONMESSAGE)
	public WebElement successMessage;

	@FindBy(how = How.ID, using = Locator.FORGOT_PASSWORD)
	public WebElement forgotPassword;

	@FindBy(how = How.ID, using = Locator.REQUEST_LOGON)
	public WebElement requestALogon;

	@FindBy(how = How.ID, using = Locator.REQUEST_LOGON_TYPE_CUSTOMER)
	public WebElement requestLogonTypeCustomer;

	@FindBy(how = How.ID, using = Locator.REQUEST_LOGON_ADDRESS)
	public WebElement requestLogonAddress;

	@FindBy(how = How.ID, using = Locator.REQUEST_LOGON_SUBURB)
	public WebElement requestLogonSuburb;

	@FindBy(how = How.ID, using = Locator.REQUEST_LOGON_POSTAL_CODE)
	public WebElement requestLogonPostalCode;

	@FindBy(how = How.ID, using = Locator.REQUEST_LOGON_FIRST_NAME)
	public WebElement requestLogonFirstName;

	@FindBy(how = How.ID, using = Locator.REQUEST_LOGON_LAST_NAME)
	public WebElement requestLogonLastName;

	@FindBy(how = How.ID, using = Locator.REQUEST_LOGON_EMAIL)
	public WebElement requestLogonEmail;

	@FindBy(how = How.ID, using = Locator.REQUEST_LOGON_PHONE)
	public WebElement requestLogonPhone;

	@FindBy(how = How.ID, using = Locator.REQUEST_LOGON_SUBMIT)
	public WebElement requestLogonSubmit;

	@FindBy(how = How.ID, using = Locator.REQUEST_LOGON_ACCOUNT_NUMBER)
	public WebElement requestLogonAccountNumber;

	@FindBy(how = How.ID, using = Locator.USERNAME)
	public WebElement userName;

	String firstName, lastName, parentWindow;

	public void clickForgotPasswordAndValidateTitle() {
		driver.navigate().back();
		clickAndSwitchToNewWindow(forgotPassword);
		verifyForgotPasswordTitleText();
	}

	public void clickRequestALogonAndValidateTitle() {
		//driver.navigate().back();
		parentWindow = clickAndSwitchToNewWindow(requestALogon);
		verifyRequestALogonTitleText();
	}

	public void validateClientLogo() {
		isDisplayed(clientLogo, "Client logo");
	}

	public void verifyForgotPasswordTitleText() {
		if (!(getText(accountPageTitle).equals("Forgotten Password"))) {
			logFail("Expected forgot password page title was not present");
		}
	}

	public void verifyRequestALogonTitleText() {
		if (!(getText(accountPageTitle).equals("Request a logon"))) {
			logFail("Expected request a logon page title was not present");
		}
	}

	public void enterForgotPasswordUserId() {
		isDisplayedThenEnterText(userIdInput, "User Id", "testfp");
		sleep(1);
	}

	public void clickSubmitInForgotPassword() {
		isDisplayedThenClick(submitUserId, "Submit User Id");
	}

	public void verifyTheSuccessMessage() {
		if (getText(successMessage).equals("Password has been sent")) {
			logPass("New password sent message was present");
		} else {
			logFail("New password sent message was not present");
		}
	}

	public void checkCustomerRequestLogonTypeIsChoosenByDefault() {
		if (Boolean.parseBoolean(getAttribute(requestLogonTypeCustomer, "checked"))) {
			logPass("Request a Logon Type : Customer choosen by default");
		} else {
			logFail("Request a Logon Type : Customer not choosen by default");
		}
	}

	public void enterRequestLogonDetails(String validAccountNumber) {
		isDisplayedThenEnterText(requestLogonAccountNumber, "Request a logon account number", "12345");
		isDisplayedThenEnterText(requestLogonAddress, "Request a logon address", fakerAPI().address().streetName());
		// APAC_AUTO - Suburb field missing
		try {
			if (requestLogonSuburb.isDisplayed()) {
				isDisplayedThenEnterText(requestLogonSuburb, "Request a logon suburb", fakerAPI().address().cityName());
			}
		} catch (Exception ex) {
			logInfo("Suburb field not present");
		}
		isDisplayedThenEnterText(requestLogonPostalCode, "Request a logon postal code", fakerAPI().address().zipCode());
		firstName = fakerAPI().address().firstName();
		isDisplayedThenEnterText(requestLogonFirstName, "Request a logon first name", firstName);
		lastName = fakerAPI().address().lastName();
		isDisplayedThenEnterText(requestLogonLastName, "Request a logon last name", lastName);
		isDisplayedThenEnterText(requestLogonEmail, "Request a logon email", fakerAPI().internet().emailAddress());
		isDisplayedThenEnterText(requestLogonPhone, "Request a logon phone", fakerAPI().phoneNumber().cellPhone());
	}

	public void clickRequestALogonSubmit() {
		isDisplayedThenClick(requestLogonSubmit, "Submit request a logon form");
		sleep(5);
	}

	public void checkTheConfirmationMessage() {
		if (getText(successMessage).equals(
				"Congratulations. Your request for a new EXXON Fuelcard Online logon has been successfully submitted. "
						+ firstName + " " + lastName + " can expect to be notified of their logon details shortly.")) {
			logPass("Success message displayed as expected");
		} else {
			logFail("Success message not displayed as expected");
		}
	}

	public void closeTheRequestLogonTab() {
		closeChildAndMoveToParent(parentWindow);
	}

	private String getDBDetailsFromProperties = "";

	public void resetLogonCountAsZeroForUser(String lockedUser) {
		getDBDetailsFromProperties = PropUtils.getPropValue(configProp, "sqlODSServerName");
		String queryToResetLogonCount = "UPDATE INTERNET_USERS SET FAILED_LOGON_COUNT='0', LOGON_STATUS_CID = '2505' WHERE LOGON_ID = '"
				+ lockedUser + "'";
		executeQueryAndCommit(queryToResetLogonCount, getDBDetailsFromProperties);
	}

	public void validateUsernameAndPasswordFields() {
		//driver.navigate().back(); //Back to login page added by senthil 24/02/2020
		waitUntilElementDisplayed(userName);
		isDisplayedThenEnterText(userName, "UN with numbers", "1234");
		if (getText(userName).equals("1234")) {
			logPass("Username accepts numbers");
		}
		isDisplayedThenEnterText(userName, "UN with special characters", "@#$%");
		if (getText(userName).equals("@#$%")) {
			logPass("Username accepts special characters");
		}
		isDisplayedThenEnterText(userName, "UN with characters", "asbc");
		if (getText(userName).equals("asbc")) {
			logPass("Username accepts characters");
		}
	}

}
