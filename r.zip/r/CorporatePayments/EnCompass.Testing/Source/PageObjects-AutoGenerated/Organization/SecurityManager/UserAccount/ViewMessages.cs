using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using Common;
using Common.PageObjects;
using Common.ScenarioConfigurations;
using Common.Utility;

namespace EnCompass.Testing.Source.PageObjects.Organization.SecurityManager.UserAccount 
{
	/// <summary>
	/// Auto-generated Page Model Class
	/// Navigation Paths: 
		/// [Organization Home]->UserAccount->->Messages
		/// </summary>
	[PageModel(@"/securityManager/userAccount/viewMessages.aspx")]
	public partial class ViewMessages : EnCompassOrgPageModel 
	{
		public override string RelativeUrl => @"/securityManager/userAccount/viewMessages.aspx";
		public override string PageIdentifierXPath_Generated => @"//li[contains(@class, 'breadcrumb-item active')][text() = 'Messages']";

		#region Navigation
				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Workflow Items']")]
		private IWebElement _useraccount__Messages_WorkflowItems { get; set; }
		public void NavigateTo_Useraccount__Messages_WorkflowItems()
		{
			NavigateToMenuItem(_useraccount__Messages_WorkflowItems);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Messages']")]
		private IWebElement _useraccount__Messages_Messages { get; set; }
		public void NavigateTo_Useraccount__Messages_Messages()
		{
			NavigateToMenuItem(_useraccount__Messages_Messages);
		}

		
		private void NavigateToMenuItem(IWebElement element)
		{
			Driver.Url = element.GetAttribute("href");
		}
		#endregion

		public ViewMessages(GlobalSettings settings) : base(settings) { }
	}  
}
