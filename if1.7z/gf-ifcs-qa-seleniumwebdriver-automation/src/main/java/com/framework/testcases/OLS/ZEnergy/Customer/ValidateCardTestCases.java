//package com.framework.testcases.OLS.ZEnergy.Customer;
package com.framework.testcases.OLS.ZEnergy.Customer;

import java.util.ArrayList;
import java.util.HashMap;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.common.Common;
import com.framework.pages.AJS.common.IFCSHomePage;
import com.framework.pages.AJS.common.IFCSLoginPage;
import com.framework.pages.OLS.common.CardsPage;
import com.framework.pages.OLS.common.LoginPage;
import com.framework.pages.Z.ZCardsPage;
import com.framework.pages.Z.ZHomePage;

public class ValidateCardTestCases extends BaseTest {

	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "Smoke" })
	public void VerifyAllQuickLinksPresents(@Optional("Z") String clientCountry,
			@Optional("Z Energy Limited") String clientName) {

		test = extent.createTest(
				"Verifying that all quick links are display as expected, clicking quick links will navigate to expected page",
				"Verifying that all quick links are display as expected");

		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		// ZCardsPage cardPage = new ZCardsPage(driver, test);
		ZHomePage zHomePage = new ZHomePage(driver, test);

		loginPage.Login("ZEnergy_URL", "ZEnergy_UN_Customer_" + clientCountry, "ZEnergy_PWD_Customer_" + clientCountry,
				clientName);
		
//	  check the quick link presence
	 
		zHomePage.checkQuickLinksPresents();
		
//	  verifying individual quick links
	 
		zHomePage.clickCardSearchQuickLink();
		zHomePage.clickOrderACard();
		zHomePage.clickEditCardQuickLink();
		zHomePage.clickTransactionSearchQuickLink();
		zHomePage.clickUrInvoicesAndReportsQuickLink();	
		zHomePage.clickRunAReportsQuickLink();
		zHomePage.clickConnectToZeroQuickLink();
		
		zHomePage.clickManageUrLoyalityQuickLink();

		zHomePage.clickZQuickLink();

		zHomePage.clickCaltexQuickLink();

		zHomePage.clickLocationAndSiteFinderQuickLink();	
		
//		terms and conditions works only in production
//		zHomePage.clickTermsAndConditionsQuickLink();
		
		loginPage.Logout();
	} 
	 

	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "Smoke" })
	public void validateViewCardsPageDetailsFromCardList(@Optional("Z") String clientCountry,
			@Optional("Z Energy Limited") String clientName) {

		test = extent.createTest(
				"Verifing that view option will display in dropdown while right clicking a card, Able to view the existing card information ",
				"Validate the details of View Card Page");

		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		ZCardsPage cardPage = new ZCardsPage(driver, test);
		CardsPage cardsCommonPage = new CardsPage(driver, test);
		ZHomePage zHomePage = new ZHomePage(driver, test);

		loginPage.Login("ZEnergy_URL", "ZEnergy_UN_Customer_" + clientCountry, "ZEnergy_PWD_Customer_" + clientCountry,
				clientName);

		// Go to Card List
		zHomePage.goToCardMenuCardList();

		zHomePage.verifyCardListPage();

		cardsCommonPage.selectAllAccountsAndActiveCard();

		cardsCommonPage.clickSearchButtonAndValidate();

		boolean isNoCardsPresent = cardPage.waitForTextToAppear("No Cards found.", 30);

		if (!isNoCardsPresent) {
			cardsCommonPage.clickViewCardGoToViewCardPageAndValidate("ZEnergy");
			cardPage.validateViewCardPage();
		}

		// logout
		loginPage.Logout();

	} 

		

	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "Smoke" })
	public void validateCardListEditCard(@Optional("Z") String clientCountry,
			@Optional("Z Energy Limited") String clientName) {

		test = extent.createTest(
				"Verifing that edit option will display  in popup while right clicking a card,Able to update the existing card information and save,Able to update default purchase and card limits and save",
				"Validate the details of Edit Card Page");

		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		ZCardsPage cardPage = new ZCardsPage(driver, test);
		CardsPage cardsCommonPage = new CardsPage(driver, test);
		ZHomePage zHomePage = new ZHomePage(driver, test);

		loginPage.Login("ZEnergy_URL", "ZEnergy_UN_Customer_" + clientCountry, "ZEnergy_PWD_Customer_" + clientCountry,
				clientName);

		// Go to Card List
		zHomePage.goToCardMenuCardList();

		zHomePage.verifyCardListPage();

		cardsCommonPage.selectAllAccountsAlone();

		cardsCommonPage.clickSearchButtonAndValidate();

		boolean isNoCardsPresent = cardPage.waitForTextToAppear("No Cards found.", 10);

		if (!isNoCardsPresent) {
			// Continuing next Test cases 02 Edit a card
			cardPage.clickEditCardFromCardListAndValidate();
			cardPage.validateProtectedFieldsAndUpdateEditable();

			cardsCommonPage.clickUpdateButton();

			// Validate The Edit Card
			cardsCommonPage.validateTheEditCard();
		}
		// click logout
		loginPage.Logout();

	}

	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "Smoke" })
	public void validateBulkOrderCardDownloadAndUploadFeature(@Optional("Z") String clientCountry,
			@Optional("Z Energy Limited") String clientName) {

		test = extent.createTest(
				"Verifing that user able to download Bulk Order Template, Verify that when Uploading the Bulk Order spreadsheet, the Browse button offers the opportunity to select the spreadsheet to be uploaded",
				"Validate bulk card template download");

		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		ZCardsPage cardPage = new ZCardsPage(driver, test);
		CardsPage cardsCommonPage = new CardsPage(driver, test);
		ZHomePage zHomePage = new ZHomePage(driver, test);
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		Common common=new Common(driver, test);
		
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");

		loginPage.Login("ZEnergy_URL", "ZEnergy_UN_Customer_" + clientCountry, "ZEnergy_PWD_Customer_" + clientCountry,
				clientName);

		// Go to Bulk card
		zHomePage.goToCardMenuBulkCardOrder();

		// Validate the bulk card page
		cardPage.validateBulkCardOrderPage();
		
//		String accountNumber = cardPage.getAccountNumber();
		
		String accountNumber ="70000842";

		// Upload the bulk order
//		cardsCommonPage.uploadBulkOrderAndUpdate("Bulk_Order", "bulkOrder");
		cardsCommonPage.downloadBulkTemplate("Bulk_Order", "bulkOrder");
		HashMap<String, String> driverKeysAndValues=cardPage.bulkCardOrderUsingExcelSheetTemplate("Bulk_Order",accountNumber,"Driver",2);
		HashMap<String, String> vehicleKeysAndValues=cardPage.bulkCardOrderUsingExcelSheetTemplate("Bulk_Order",accountNumber,"Vehicle",2);
		System.out.println("driverKeysAndValues::"+driverKeysAndValues);
		System.out.println("vehicleKeysAndValues::"+vehicleKeysAndValues);
		cardsCommonPage.uploadBulkTemplate("Bulk_Order", "bulkOrder");
		// logout
		loginPage.Logout();
		
		IFCSloginPage.login("IFCS_URL_ZENERGY", "IFCS_ZENERGY_USERNAME", "IFCS_ZENERGY_PASSWORD");
		IFCSHomePage.sleep(5);

		IFCSHomePage.gotoAdminBatchMenuAndChooseClient(clientName,clientCountry);
		common.batchJobExecution("Card Processing", "Online Card Management Request",
				"Online Card Ordering Request Processor");
//		common.batchJobExecution("Card Processing", "Card Emboss Catalog", "Card Emboss Catalog");
		
		common.batchJobExecution("Card Processing", "Online Card Management Request", "Online Card Ordering Request Processor");
		//Online Card Management Request
		//Online Card Ordering Request Processor
		//Online Card Detail Update Request Processor
		IFCSHomePage.sleep(5);
		ArrayList<String> driverCardNos = cardPage.getBulkCardNumberForCardType(driverKeysAndValues);
		
		ArrayList<String> vehicleCardNos = cardPage.getBulkCardNumberForCardType(vehicleKeysAndValues);
		
		common.validateBulkOrderedCardNumbersInIFCS(driverCardNos);
		common.validateBulkOrderedCardNumbersInIFCS(vehicleCardNos);
		
		IFCSHomePage.exitIFCS();
		
		/*ArrayList<String> driverCardNos = new ArrayList<>();
		driverCardNos.add("7080591000880274");
		driverCardNos.add("7080591000880225");
		driverCardNos.add("7080591000872");
		driverCardNos.add("7080591000880209");
		driverCardNos.add("7080591000878");
		driverCardNos.add("7080591000878252");
		driverCardNos.add("7080591002");*/
		
		loginPage.Login("ZEnergy_URL", "ZEnergy_UN_Customer_" + clientCountry, "ZEnergy_PWD_Customer_" + clientCountry,clientName);
		
		cardPage.searchOrderedCardsInOLS(driverCardNos);
		
		cardPage.searchOrderedCardsInOLS(vehicleCardNos);
		
		

		// logout
		loginPage.Logout();
	} 

	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "Smoke" },enabled=false)
	public void validateBulkUpdateCardDownloadAndUploadFeature(@Optional("Z") String clientCountry,
			@Optional("Z Energy Limited") String clientName) {

		test = extent.createTest(
				"Verifing that user able to download Bulk Update Template, Verify that when Uploading the Bulk Update spreadsheet, the Browse button offers the opportunity to select the spreadsheet to be uploaded",
				"Validate bulk card template download");

		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		// ZCardsPage cardPage = new ZCardsPage(driver, test);
		CardsPage cardsCommonPage = new CardsPage(driver, test);
		ZHomePage zHomePage = new ZHomePage(driver, test);

		loginPage.Login("ZEnergy_URL", "ZEnergy_UN_Customer_" + clientCountry, "ZEnergy_PWD_Customer_" + clientCountry,
				clientName);

		// Go to Bulk card Update

		zHomePage.goToCardMenuBulkCardUpdate();

		cardsCommonPage.validateBuldCardUpdatePage("ZEnergy");
		System.out.println("1");

		// Filter and Search

		cardsCommonPage.verifyAllRequiredFieldsBulkCardUpdate("ZENERGY");

		// Click Search Button
		cardsCommonPage.clickBulkCardUpdateSearch();

		// Uncheck all the Customers
		cardsCommonPage.UnCheckSelectALL();

		// Upload the bulk order
		cardsCommonPage.uploadBulkOrderAndUpdate("Bulk_Update", "bulkUpdate");

		// logout
		loginPage.Logout();

	}

	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "Smoke" })
	public void validateCardMenuReissueControl(@Optional("Z") String clientCountry,
			@Optional("Z Energy Limited") String clientName) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  01 Verify details on Reissue control page",
				"Validate Card menu reissue control page");

		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		ZCardsPage zCardPage = new ZCardsPage(driver, test);
		CardsPage cardsPage = new CardsPage(driver, test);
		// ZHomePage zHomePage = new ZHomePage(driver, test);

		loginPage.Login("ZEnergy_URL", "ZEnergy_UN_Customer_" + clientCountry, "ZEnergy_PWD_Customer_" + clientCountry,
				clientName);

		// Go to Bulk card Update

		// Go to Card List
		cardsPage.goToCardMenuReissueControl();
		zCardPage.verifyReissueControlPage();

		boolean isReissueDataPresentorNot = zCardPage.verifyBulkReIssueListDataIsAvailable();

		if (isReissueDataPresentorNot) {
			cardsPage.printNoReissueDataPresent();
		} else {
			// Click Export Button
			cardsPage.clickExportButton();
		}

		takeScreenshot();
		// logout
		loginPage.Logout();

	}
	

	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "Smoke" })
	public void validateSearchCardsPageDetailsFromCardList(@Optional("Z") String clientCountry,
			@Optional("Z Energy Limited") String clientName) throws InterruptedException {

		test = extent.createTest(
				"Verify if user is able to search a list of cards based each of the following filter criteria and verify if the search result displayed is correct, Able to sort the searched result by clicking header of any coloumn ",
				"Validate the details of Search Card Page");

		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		ZCardsPage zCardPage = new ZCardsPage(driver, test);
		CardsPage cardsPage = new CardsPage(driver, test);
		ZHomePage zHomePage = new ZHomePage(driver, test);
		// CommonPage commonPage = new CommonPage(driver, test);

		loginPage.Login("ZEnergy_URL", "ZEnergy_UN_Customer_" + clientCountry, "ZEnergy_PWD_Customer_" + clientCountry,
				clientName);

		// Go to Card List
		zHomePage.goToCardMenuCardList();

		zHomePage.verifyCardListPage();

		cardsPage.selectAllAccountsAlone();

		cardsPage.clickSearchButtonAndValidate();

		boolean isNoCardsPresent = zCardPage.waitForTextToAppear("No Cards found.", 10);

		if (!isNoCardsPresent) {
			zCardPage.checkCardListTableSorting();

		}

		// logout
		loginPage.Logout();

	} 

}
