package com.framework.testcases.AJS.ZEnergy;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.MerchantLocationPage;
import com.framework.pages.AJS.common.Common;
import com.framework.pages.AJS.common.IFCSHomePage;
import com.framework.pages.AJS.common.IFCSLoginPage;
import com.github.javafaker.Faker;

public class ValidateMerchantTestcases extends BaseTest {
	
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "Regression" })
	public void createAndValidateNewMerchant(@Optional("NZ") String clientCountry,
			@Optional("ZEnergy") String clientName) {
		
		test = extent.createTest(clientName+ ":" +clientCountry+"  Merchant  Creation ",
				"Create new merchant for Z Energy");
		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		
		Common common = new Common(driver, test);
		
		MerchantLocationPage merchantLocation = new MerchantLocationPage(driver, test);
		IFCSloginPage.login("IFCS_URL_ZEnergy", "IFCS_ZEnergy_USERNAME", "IFCS_ZEnergy_PASSWORD");
		
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		IFCSHomePage.gotoApplicationAndClickApplicationMenu();
		IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);
		IFCSHomePage.gotoMerchantAndClickMerchantDetails();

		// Get Merchant Num and Location Num from DB
		String merchant = common.getMerchantNoFromDB();
		

		// create Merchant
		common.chooseMerchantNoAndSearch(merchant);
		Faker fakerMerchantNo = new Faker();
		String f_merchantNo = fakerMerchantNo.number().digits(6);
		System.out.println("f_merchantNo" + f_merchantNo);
		merchantLocation.createNewMerchant(f_merchantNo);

		
	}
	
	/*
	 * Added by Davu - 30/04/2020
	 * 
	 */
	
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "Regression" })
	public void createAndValidateNewLocation(@Optional("NZ") String clientCountry,
			@Optional("ZEnergy") String clientName) {
		
		test = extent.createTest(clientName+ ":" +clientCountry+"  Location  Creation ",
				"Create new Location for Z Energy");
		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		
		Common common = new Common(driver, test);
		
		MerchantLocationPage merchantLocation = new MerchantLocationPage(driver, test);
		IFCSloginPage.login("IFCS_URL_ZEnergy", "IFCS_ZEnergy_USERNAME", "IFCS_ZEnergy_PASSWORD");
		
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		IFCSHomePage.gotoApplicationAndClickApplicationMenu();
		IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);
		IFCSHomePage.gotoMerchantAndClickMerchantDetails();

		// Get Location Num from DB
		String locationNoFromDB = common.getLocationNoFromDB();
		

		// create location
				merchantLocation.chooseLocationNoFromListAndDoubleClick(locationNoFromDB);
				
				Faker fakerLocationNo = new Faker();
				String f_locationNo = fakerLocationNo.number().digits(6);
				System.out.println("f_locationNo" + f_locationNo);
				merchantLocation.createNewLocation(f_locationNo);
		
	}
	
	/*
	 * Added by Davu - 30/04/2020
	 * 
	 */
	
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "Regression" })
	public void updateAndValidateMerchant(@Optional("NZ") String clientCountry,
			@Optional("ZEnergy") String clientName) {
		
		test = extent.createTest(clientName+ ":" +clientCountry+"   Update Merchant   ",
				"Update merchant for Z Energy");
		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		
		Common common = new Common(driver, test);
		
		MerchantLocationPage merchantLocation = new MerchantLocationPage(driver, test);
		IFCSloginPage.login("IFCS_URL_ZEnergy", "IFCS_ZEnergy_USERNAME", "IFCS_ZEnergy_PASSWORD");
		
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		IFCSHomePage.gotoApplicationAndClickApplicationMenu();
		IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);
		IFCSHomePage.gotoMerchantAndClickMerchantDetails();

		// Get Merchant Num and Location Num from DB
		String merchant = common.getMerchantNoFromDB();
		

		// create Merchant
		common.chooseMerchantNoAndSearch(merchant);
		
		
		merchantLocation.updateMerchant();

		
	}



}
