package com.framework.testcases.BusinessFlow;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.MaintainCustomerPage;
import com.framework.pages.AJS.common.IFCSHomePage;
import com.framework.pages.AJS.common.IFCSLoginPage;

public class ValidateHierarchyBusinessFlows2 extends BaseTest {

	/**
	 * Added by Nithya
	 * 
	 * @param clientCountry
	 * @param clientName    Busienss Flow ID:RQ-804
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "BusinessFlow" })
	public void expireCustomerHierarchy(@Optional("AU") String clientCountry, @Optional("BP") String clientName) {
		test = extent.createTest(
				clientName + ":" + clientCountry
						+ " RQ-804	TC-754 TC04_CustMgmt_Hier_Expire Financial, Report and Rebate Hierarchy",
				"Expire the customer Hierarchy");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		MaintainCustomerPage customerPage = new MaintainCustomerPage(driver, test);

		IFCSloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		IFCSHomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);
		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		customerPage.expireHierarchyWithChild();
		IFCSHomePage.exitIFCS();
	}


	/**
	 * Added by Nithya
	 * 
	 * @param clientCountry
	 * @param clientName    Busienss Flow ID:RQ-803
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "BusinessFlow" })
	public void createFinancialHierarchy(@Optional("AU") String clientCountry, @Optional("BP") String clientName) {
		test = extent.createTest(clientName + ":" + clientCountry
				+ "RQ-803 - TC-751 TC01_CustMgmt_Hier_Create Financial Hierarchy, TC-752 TC03_CustMgmt_Hier_Create Report Hierarchy\r\n" + 
				"TC-753 TC02_CustMgmt_Hier_Create Rebate Hierarchy",
				"Create new financial,report,rabate hierarchy for a customer");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		MaintainCustomerPage customerPage = new MaintainCustomerPage(driver, test);

		IFCSloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");

		IFCSHomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);
		IFCSHomePage.gotoCustomerMenuCustomerDetails();

		customerPage.createHierarchyWithChild();

		IFCSHomePage.exitIFCS();
	}

}
