package com.framework.testcases.OLS.EMAP.Customer;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.EMAP.EMAPCardsPage;
import com.framework.pages.EMAP.EMAPHomePage;
import com.framework.pages.OLS.common.CommonPage;
import com.framework.pages.OLS.common.LoginPage;

public class ValidateCardListSearchCardFilter extends BaseTest {
	
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "Regression" })
	public void validateCardListSearchCardFilterRO(@Optional("SP") String clientCountry,
			@Optional("EMAP") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  TST-SC-91-OLS-Card List-Search For Cards", "Check search filter in EMAP - Read Only Customer");
		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		EMAPCardsPage emapCardsPage = new EMAPCardsPage(driver, test);
		CommonPage commonPage = new CommonPage(driver, test);
		EMAPHomePage emapHomePage = new EMAPHomePage(driver, test);

		// Read-Only
		loginPage.Login("EMAP_URL", "EMAP_UN_ReadOnly_Customer_" + clientCountry,
				"EMAP_PWD_ReadOnly_Customer_" + clientCountry, clientName);
		// Card options check
		emapHomePage.clickCardListAndValidatePage();
		commonPage.selectAllAccountOptionFromAccountDropdown();
		commonPage.clickSearchButton();
		if (emapCardsPage.isCardsPresent()) {
			// Filter with Card Number
			emapCardsPage.selectACardFromCardListTable(false);
			emapCardsPage.selectAValidLicensePlateFromCardListTable();
			emapCardsPage.enterSelectedCardNumberInCardNumberFilter();
			commonPage.clickSearchButton();
			emapCardsPage.verifyTheCardListTableWithCardNumber();

			// Filter with Card Status
			emapHomePage.clickCardListAndValidatePage();
			commonPage.selectAllAccountOptionFromAccountDropdown();
			emapCardsPage.selectACardStatus();
			commonPage.clickSearchButton();
			emapCardsPage.verifyTheCardListTableWithCardStatus();

			if (clientCountry.equals("HK") || clientCountry.equals("MO")) {
				// Filter with Card Product
				emapHomePage.clickCardListAndValidatePage();
				commonPage.selectAllAccountOptionFromAccountDropdown();
				emapCardsPage.selectACardProduct();
				commonPage.clickSearchButton();
				emapCardsPage.verifyTheCardListTableWithCardProduct();
			} else {
				// Filter with Card Offer
				emapHomePage.clickCardListAndValidatePage();
				commonPage.selectAllAccountOptionFromAccountDropdown();
				emapCardsPage.selectACardOffer();
				commonPage.clickSearchButton();
				emapCardsPage.verifyTheCardListTableWithCardOffer();
			}

			// Filter with License Plate
			emapHomePage.clickCardListAndValidatePage();
			commonPage.selectAllAccountOptionFromAccountDropdown();
			emapCardsPage.enterALicensePlate();
			commonPage.clickSearchButton();
			emapCardsPage.verifyTheCardListTableWithLicensePlate();

			// Filter with Vehicle Description
			emapHomePage.clickCardListAndValidatePage();
			commonPage.selectAllAccountOptionFromAccountDropdown();
			emapCardsPage.enterVehicleDescription("T*");
			commonPage.clickSearchButton();
			emapCardsPage.verifyTheCardListTableWithVehicleDescription();
		}
		loginPage.Logout();
	}

	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "Regression" })
	public void validateCardListSearchCardFilterRW(@Optional("SP") String clientCountry,
			@Optional("EMAP") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  TST-SC-91-OLS-Card List-Search For Cards", "Check search filter in EMAP - Read/Write");
		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		EMAPCardsPage emapCardsPage = new EMAPCardsPage(driver, test);
		CommonPage commonPage = new CommonPage(driver, test);
		EMAPHomePage emapHomePage = new EMAPHomePage(driver, test);
		// Read-Write
		loginPage.Login("EMAP_URL", "EMAP_UN_ReadWrite_Customer_" + clientCountry,
				"EMAP_PWD_ReadWrite_Customer_" + clientCountry, clientName);
		// Card options check
		emapHomePage.clickCardListAndValidatePage();
		commonPage.selectAllAccountOptionFromAccountDropdown();
		commonPage.clickSearchButton();

		if (emapCardsPage.isCardsPresent()) {
			// Filter with Card Number
			emapCardsPage.selectACardFromCardListTable(false);
			emapCardsPage.selectAValidLicensePlateFromCardListTable();
			emapCardsPage.enterSelectedCardNumberInCardNumberFilter();
			commonPage.clickSearchButton();
			emapCardsPage.verifyTheCardListTableWithCardNumber();

			// Filter with Card Status
			emapHomePage.clickCardListAndValidatePage();
			commonPage.selectAllAccountOptionFromAccountDropdown();
			emapCardsPage.selectACardStatus();
			commonPage.clickSearchButton();
			emapCardsPage.verifyTheCardListTableWithCardStatus();

			if (clientCountry.equals("HK") || clientCountry.equals("MO")) {
				// Filter with Card Product
				emapHomePage.clickCardListAndValidatePage();
				commonPage.selectAllAccountOptionFromAccountDropdown();
				emapCardsPage.selectACardProduct();
				commonPage.clickSearchButton();
				emapCardsPage.verifyTheCardListTableWithCardProduct();
			} else {
				// Filter with Card Offer
				emapHomePage.clickCardListAndValidatePage();
				commonPage.selectAllAccountOptionFromAccountDropdown();
				emapCardsPage.selectACardOffer();
				commonPage.clickSearchButton();
				emapCardsPage.verifyTheCardListTableWithCardOffer();
			}

			// Filter with License Plate
			emapHomePage.clickCardListAndValidatePage();
			commonPage.selectAllAccountOptionFromAccountDropdown();
			emapCardsPage.enterALicensePlate();
			commonPage.clickSearchButton();
			emapCardsPage.verifyTheCardListTableWithLicensePlate();

			// Filter with Vehicle Description
			emapHomePage.clickCardListAndValidatePage();
			commonPage.selectAllAccountOptionFromAccountDropdown();
			emapCardsPage.enterVehicleDescription("T*");
			commonPage.clickSearchButton();
			emapCardsPage.verifyTheCardListTableWithVehicleDescription();
		}
		loginPage.Logout();
	}  

	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "Regression" })
	public void validateCardListSearchCardFilterVO(@Optional("SP") String clientCountry,
			@Optional("EMAP") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  TST-SC-91-OLS-Card List-Search For Cards", "Check search filter in EMAP - ViewOnly/Status Change");
		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		EMAPCardsPage emapCardsPage = new EMAPCardsPage(driver, test);
		CommonPage commonPage = new CommonPage(driver, test);
		EMAPHomePage emapHomePage = new EMAPHomePage(driver, test);
		// View Only
		loginPage.Login("EMAP_URL", "EMAP_UN_ViewOnly_Customer_" + clientCountry,
				"EMAP_PWD_ViewOnly_Customer_" + clientCountry, clientName);
		// Card options check
		emapHomePage.clickCardListAndValidatePage();
		commonPage.selectAllAccountOptionFromAccountDropdown();
		commonPage.clickSearchButton();

		if (emapCardsPage.isCardsPresent())

		{
			// Filter with Card Number
			emapCardsPage.selectACardFromCardListTable(false);
			emapCardsPage.selectAValidLicensePlateFromCardListTable();
			emapCardsPage.enterSelectedCardNumberInCardNumberFilter();
			commonPage.clickSearchButton();
			emapCardsPage.verifyTheCardListTableWithCardNumber();

			// Filter with Card Status
			emapHomePage.clickCardListAndValidatePage();
			commonPage.selectAllAccountOptionFromAccountDropdown();
			emapCardsPage.selectACardStatus();
			commonPage.clickSearchButton();
			emapCardsPage.verifyTheCardListTableWithCardStatus();

			if (clientCountry.equals("HK") || clientCountry.equals("MO")) {
				// Filter with Card Product
				emapHomePage.clickCardListAndValidatePage();
				commonPage.selectAllAccountOptionFromAccountDropdown();
				emapCardsPage.selectACardProduct();
				commonPage.clickSearchButton();
				emapCardsPage.verifyTheCardListTableWithCardProduct();
			} else {
				// Filter with Card Offer
				emapHomePage.clickCardListAndValidatePage();
				commonPage.selectAllAccountOptionFromAccountDropdown();
				emapCardsPage.selectACardOffer();
				commonPage.clickSearchButton();
				emapCardsPage.verifyTheCardListTableWithCardOffer();
			}

			// Filter with License Plate
			emapHomePage.clickCardListAndValidatePage();
			commonPage.selectAllAccountOptionFromAccountDropdown();
			emapCardsPage.enterALicensePlate();
			commonPage.clickSearchButton();
			emapCardsPage.verifyTheCardListTableWithLicensePlate();
		}

		loginPage.Logout();
	}
}
