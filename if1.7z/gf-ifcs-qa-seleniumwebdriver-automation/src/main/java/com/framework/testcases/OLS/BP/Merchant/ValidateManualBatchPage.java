package com.framework.testcases.OLS.BP.Merchant;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.BP.BPHomePage;
import com.framework.pages.BP.BPManualBatchPage;
import com.framework.pages.OLS.HomePage;
import com.framework.pages.OLS.common.LoginPage;

public class ValidateManualBatchPage extends BaseTest {

	@Parameters({"clientCountry", "clientName"})
	@Test( groups = { "Smoke", "Regression" })
	public void validate_Add_Manual_Batch_And_View_Manual_Batch(@Optional("AU") String clientCountry, @Optional("AU") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  Validate Manual Batch Test cases",
				"Logging in to BP Online, Validate Manual Batch page test cases");
		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		BPHomePage bpHomePage = new BPHomePage(driver, test);
		HomePage homePage = new HomePage(driver, test);
		BPManualBatchPage manualPage = new BPManualBatchPage(driver, test);

		// Calling Functions
		// loginPage.Login("BP_URL",
		// "BP_AU_WEXExtMechantMGR_UN","BP_AU_WEXExtMechantMGR_PWD", "BP");
		loginPage.Login("BP_URL", "BP_UN_WEXExtMechantMGR_" + clientCountry, "BP_PWD_WEXExtMechantMGR_" + clientCountry, clientName);
		bpHomePage.ValidateBPLocOrMerchantLogo(clientCountry);
		bpHomePage.ValidateMerchantLocWelcomeText(clientCountry);
		homePage.HomePageValidation();
		manualPage.clickManualBatchSubMenuAndValidatePage();
		manualPage.clickAddManualBatchAndVerify();
		manualPage.enterBatchDetailsAddTransactionAndValidate();
		manualPage.clickTheBlankTransactionCheckDetailsAndValidate();

		// Go back to Manual Batches and Verify Manual Batches Page.

		manualPage.clickManualBatchSubMenuAndValidatePage();
		manualPage.searchAndVerifyManualBatches();
		
		loginPage.Logout();
	
	}
	
}
