﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Common.Utility
{
	public class PathHelper
	{
		private static string _basePath;

		// Gets absolute path of the project(i.e Encompass)
		public static String GetAbsolutePathRelativeToProjectPath(String relativePath)
		{
			if (Path.IsPathRooted(relativePath))
			{
				return relativePath;
			}

			return Path.Combine(GetAppBasePath(), relativePath);
		}

		/*
		 * Helper method to retireve the Application's base path (i.e the path to the .csproj of the assembly being run)
		 */
		private static String GetAppBasePath()
		{
			if (string.IsNullOrWhiteSpace(_basePath))
			{
				String assemblyDirPath = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
				_basePath = Directory.GetParent(assemblyDirPath).Parent.FullName;
			}
			return _basePath;
		}

        /*
         * Helper method to retireve the path to the specified browser
         */
        public static String GetBrowserAbsolutePath(string browser)
        {
            string _relativePath = null;
            switch (browser.ToUpperInvariant())
            {
                case "CHROME":
				case "MOBILECHROMELOCAL":
					_relativePath = GlobalSettings.ChromeBinaryPath;
                    break;
                case "FIREFOX":
                    _relativePath = GlobalSettings.FirefoxBinaryPath;
                    break;
                default: break;
            }
            return Path.Combine(GetSolutionDirectoryPath(), _relativePath);
        }

        /// <summary>
        /// Helper method to retrieve the path to the winApp driver
        /// </summary>
        /// <returns></returns>
        public static String GetWinAppDriverAbsolutePath()
        {
            string _relativePath = null;
            _relativePath = GlobalSettings.WinAppDriverPath;
            return Path.Combine(GetSolutionDirectoryPath(), _relativePath);
        }

        /*
         * Helper method to retireve the path to the Solution Directory (CorporatePayments)
         */
        public static String GetSolutionDirectoryPath()
        {
            String assemblyDirPath = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
            String _basePath = Directory.GetParent(assemblyDirPath).Parent.Parent.FullName;
            return _basePath;
        }
    }
}
