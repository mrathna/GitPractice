package com.framework.pages.BP;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
//import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Select;

import com.aventstack.extentreports.ExtentTest;
import com.framework.basepage.BasePage;
import com.framework.repo.Locator;

public class BPHomePage extends BasePage {

	@FindBy(how = How.XPATH, using = Locator.BP_LOGO_IMG)
	public WebElement BPLogo;

	@FindBy(how = How.ID, using = Locator.BPLOGO_LOC_MERCH)
	public WebElement BPLogoLoc;

	/*
	 * @FindBy(how = How.XPATH, using = Locator.INTRO_MESSAGE) public WebElement
	 * BPIntroMessage;
	 */

	@FindBy(id = Locator.PAYMENTS_MENU)
	public WebElement bpPaymentsMenu;
	
	
	@FindBy(id = Locator.REF_NUM)
	public WebElement bpPaymentRefNumber;
	
	@FindBy(css = Locator.CREATE_SUCCESS_MESSAGE)
	public WebElement bpPaymentSuccess;
	
	@FindBy(id = Locator.PAYMENT_MAKE_A_PAYMENT_AMOUNT)
	public WebElement bpPaymentAmount;
	
	@FindBy(id = Locator.PAYMENT_MAKE_A_PAYMENT_METHOD_YOUR_BANK_ACCOUNT)
	public WebElement bpPaymentWithYourCreditCard;
	
	@FindBy(xpath = Locator.PAYMENT_MAKE_A_PAYMENT_METHOD_CREADIT_CARD)
	public WebElement bpPaymentWithNewCreditCard;
	
	@FindBy(xpath = Locator.PAYMENT_MAKE_A_PAYMENT_CONFIRM_AND_PAY_NOW)
	public WebElement bpPaymentConfirmAndPay;
			
	@FindBy(id = Locator.CARDS_MENU)
	public WebElement bpCardsMenu;

	@FindBy(id = Locator.FINDANDUPDATECARDSHM)
	public WebElement findUpdateCardsSM;

	@FindBy(how = How.ID, using = Locator.FINDANDUPDATECARDS)
	public WebElement findAndUpdateCardSubMenu;

	@FindBy(how = How.ID, using = Locator.PAGETITLE_FINDANDUPDATE)
	public WebElement pageTitleFindAndUpdate;

	@FindBy(id = Locator.FIND_UPDATE_CARD_TITLE)
	public WebElement findUpdateCardsDP;

	@FindBy(id = Locator.ORDER_A_CARD)
	public WebElement orderCardSM;

	@FindBy(id = Locator.MANAGERRESISSUECARDS)
	public WebElement MgeReIssueCard;

	@FindBy(id = Locator.BULKORDER_UPDATECARDS)
	public WebElement bulkOrderUpdateSM;

	@FindBy(id = Locator.TRANSACTIONS_MENU)
	public WebElement transactionsMenus;

	@FindBy(id = Locator.FIND_EXPORT_TRANSC)
	public WebElement findExportSM;

	@FindBy(id = Locator.REPORTS_MENU_BP)
	public WebElement reportsMenu;

	@FindBy(id = Locator.RUN_REPORT)
	public WebElement runReportSM;

	@FindBy(id = Locator.MGE_RECURRING_REPORT)
	public WebElement mgeRecurringRePort;

	@FindBy(id = Locator.PAST_REPORTS)
	public WebElement pastReportsSM;

	@FindBy(id = Locator.PAYMENT_MAKE_A_PAYMENT)
	public WebElement makePmtSM;

	@FindBy(id = Locator.PAYMENT_UPDATE_PAYMENT_METHOD)
	public WebElement updatePMMethodsSM;

	@FindBy(id = Locator.PAYMENT_SETUP_AND_TOPUP)
	public WebElement autoTopupSM;

	@FindBy(id = Locator.PAYMENT_MANAGE_AUTO_PAYMENTS)
	public WebElement mgeAutoPmtsSM;

	@FindBy(id = Locator.SUPPORT_MENU)
	public WebElement support;

	@FindBy(id = Locator.CONTACT_US_SUPPORT)
	public WebElement contactUs;

	@FindBy(id = Locator.ORDER_MERCHANDISE_SUPPORT)
	public WebElement orderMerchandise;

	@FindBy(id = Locator.USER_GUIDE_SUPPORT)
	public WebElement helpGuide;

	@FindBy(how = How.ID, using = Locator.ACCTDETAIL_LEFT_HEADER)
	public WebElement accountDetailLink;

	@FindBy(xpath = Locator.COMMON_TITLE_SEC)
	public WebElement commonTitleSec;

	@FindBy(xpath = Locator.PAGE_TITLE_DP)
	public WebElement commonTitle;

	@FindBy(id = Locator.MANAGE_REISSUE_REQUESTS)
	public WebElement MgeReIssueCardFrmOC;

	@FindBy(id = Locator.PAGE_TITLE)
	public WebElement commonTitleThird;

	@FindBy(xpath = Locator.PAGE_TITLE1)
	public WebElement commonTitleFour;

	@FindBy(id = Locator.ACCOUNTS_DROPDOWN)
	public WebElement allListedAccounts;

	// Added By Nithya - 08-05-2018
	@FindBy(xpath = Locator.CONTACTS_MENU)
	public WebElement contactsMenu;

	@FindBy(how = How.XPATH, using = Locator.MERCORLOC_CONTACT_TITLE)
	public WebElement mercOrLocContactPageTitle;

	/*
	 * 02-05-2018 Ayub khan
	 */
	@FindBy(id = Locator.MANAGE_REISSUE_REQUESTS)
	public WebElement manageReissueRequests;
	@FindBy(how = How.XPATH, using = Locator.PAGETITLE_MANAGEREISSUE_REQUEST)
	public WebElement pageTitleManageReissueRequest;

	@FindBy(how = How.ID, using = Locator.REPORTS_MENU)
	public WebElement selectReportMenu;
	@FindBy(how = How.ID, using = Locator.RUN_REPORT_HM)
	public WebElement selectRunAReportSubMenu;
	@FindBy(how = How.ID, using = Locator.PAGE_TITLE)
	public WebElement pageTitleText;
	@FindBy(xpath = Locator.PAYMENT_MANAGE_AUTO_PAYMENTS_TEXT)
	public WebElement autoPaymentTitle;
	
	@FindBy(xpath = Locator.PAYMENT_MAKE_A_PAYMENT_TEXT)
	public WebElement paymentPageTitle;
	

	@FindBy(xpath = Locator.LEGALTITLENW)
	public WebElement legalTitleNW;

	@FindBy(xpath = Locator.PRIVACYTITLENW)
	public WebElement privacyTitleNW;

	@FindBy(xpath = Locator.USERGUIDETITLENW)
	public WebElement userGuideTitleNW;

	@FindBy(xpath = Locator.USERGUIDENZTITLE)
	public WebElement userGuideTitleNZUG;

	@FindBy(id = Locator.ACCTDETAIL_LEFT_HEADER)
	public WebElement acctDetailsHeader;

	@FindBy(id = Locator.FOOTER_HOME_LINK)
	public WebElement footerHomeLink;

	@FindBy(id = Locator.FOOTER_USERGUIDE)
	public WebElement footerUserGuide;

	@FindBy(id = Locator.FOOTER_LEG_NOTICE)
	public WebElement footerLegNotice;

	@FindBy(id = Locator.FOOTER_CONTACTUS)
	public WebElement footerContactUs;

	@FindBy(id = Locator.FOOTER_PRIV_STATEMENT)
	public WebElement footerPriStmt;

	@FindBy(id = Locator.LOC_TRANSACTION_LINKS)
	public WebElement locTransactionQuickLinks;

	@FindBy(id = Locator.MERC_TRANSACTION_LINKS)
	public WebElement mercTransactionLinks;

	@FindBy(xpath = Locator.TRANSACTION_PAGE_TITLE)
	public WebElement transactionListPageTitle;

	// Ayub Khan 07-05-2018
	@FindBy(id = Locator.TRANSACTIONS_MENU)
	public WebElement transactionsMenu;
	@FindBy(id = Locator.SETTLEMENTS_MENU)
	public WebElement settlementMenu;
	@FindBy(how = How.XPATH, using = Locator.PAGETITLE_SETTLEMENT)
	public WebElement pageTitleSettlement;
	@FindBy(how = How.ID, using = Locator.BPLOGO_LOC_MERCH)
	public WebElement MerchantLogo;
	@FindBy(how = How.ID, using = Locator.ACCOUNTS_MENU)
	public WebElement accountMenu;
	@FindBy(how = How.ID, using = Locator.MERCHANT)
	public WebElement merchant;
	
	@FindBy(xpath=Locator.ACCOUNT_NAME_DROPDOWN_IN_HOME_PAGE)
	public WebElement accountNameDropDownInHomePage;
	
	@FindBy(xpath=Locator.EFFECTIVE_FROM_DATE_IN_TRANSACTIONS_PAGE)
	public WebElement effectiveFromDate;
	
	@FindBy(xpath=Locator.PAYMENTS_CARD_NO)
	public WebElement paymentsCardNo;
	
	@FindBy(xpath=Locator.PAYMENTS_EXPIRY_MONTH)
	public WebElement paymentsExpMonth;
	
	@FindBy(xpath=Locator.PAYMENTS_EXPIRY_YEAR)
	public WebElement paymentsExpYear;
	
	@FindBy(xpath=Locator.PAYMENTS_CVN_NO)
	public WebElement paymentsCVN;
	
	@FindBy(xpath=Locator.PAYMENTS_PAY_BTN)
	public WebElement paymentsPayBtn;
	
	@FindBy(xpath=Locator.PAYMENTS_SUCCESS_MSG)
	public WebElement paymentsSuccessMsg;
	
	
	
	public BPHomePage(WebDriver driver, ExtentTest test) {
		super(driver, test);
		PageFactory.initElements(driver, this);
	}

	public void ValidateBPCustomerLogo() {
		isDisplayed(BPLogo, "BP Logo");
		// sleep(10);
	}

	public void ValidateBPLocOrMerchantLogo(String clientCountry) {

		try {
			if (clientCountry.equals("AU")) {
				isDisplayed(BPLogoLoc, "BP Logo");
			}

			else if (clientCountry.equals("NZ")) {
				boolean mgrTxtPresent = waitForTextToAppear("NZ Merchant Manager", 20);

				if (mgrTxtPresent) {
					ValidateBPCustomerLogo();
				}

				else {
					isDisplayed(BPLogoLoc, "BP Logo for Location or Merchant");
				}

			}
		}

		catch (Exception e) {
			logFail(e.getMessage());
		}
	}

	public void ValidateCustomerWelcomeText() {
		try {
			if (BPLogo.isDisplayed()) {

				// verifyText(WelcomeText, "Welcome to StarCard Online");

				String temp = getText(BPLogo).trim();
				System.out.println("Welcome Text : '" + temp + "'");
				if (temp.contains("BP Plus Online")) {
					logPass("Welcome text is Displayed correctly as " + temp);
				}

				else if (temp.contains("BP Fuelcard Online")) {
					logPass("Welcome text is Displayed correctly as " + temp);
				} else {
					logFail("Welcome text is Displayed incorrectly as " + temp);
				}
			} else {
				logFail("Welcome Text is Not Displayed");
			}
		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
	}

	public void ValidateMerchantLocWelcomeText(String clientCountry) {

		try {
			if (clientCountry.equals("AU")) {
				isDisplayed(BPLogoLoc, "Welcome Text");
				if (BPLogoLoc.isDisplayed()) {
					String temp = getText(BPLogoLoc).trim();
					System.out.println("Welcome Text : '" + temp + "'");
					if (temp.contains("BP Merchant Online")) {
						logPass("Welcome text is Displayed correctly as " + temp);
					} else {
						logFail("Welcome text is Displayed incorrectly as " + temp);
					}
				} else {
					logFail("Welcome Text is Not Displayed");
				}
			}

			else if (clientCountry.equals("NZ")) {
				boolean mgrTxtPresent = waitForTextToAppear("NZ Merchant Manager", 20);

				if (mgrTxtPresent) {
					ValidateCustomerWelcomeText();
				}

				else {
					isDisplayed(BPLogoLoc, "Welcome Text");
					if (BPLogoLoc.isDisplayed()) {
						String temp = getText(BPLogoLoc).trim();
						System.out.println("Welcome Text : '" + temp + "'");
						if (temp.contains("BP Merchant Online")) {
							logPass("Welcome text is Displayed correctly as " + temp);
						} else {
							logFail("Welcome text is Displayed incorrectly as " + temp);
						}
					} else {
						logFail("Welcome Text is Not Displayed");
					}
				}

			}
		}

		catch (Exception e) {
			logFail(e.getMessage());
		}

	}

	public void ValidatePaymentsMenu() {
		isDisplayed(bpPaymentsMenu, "Menu Item Payments");
	}

	/*
	 * 02-05-2018 Ayub khan
	 */
	public void clickOnRunAReportSubMenu() {
		clickSubMenuAndValidate(selectReportMenu, selectRunAReportSubMenu, pageTitleText);
	}
	
	/*
	 * 07-11-2019 Nithya
	 */
	public void clickOnMakePaymentSubMenu() {
		clickSubMenuAndValidate(bpPaymentsMenu,makePmtSM , paymentPageTitle);
	}

	// Created by Anton 02.05.2018
	public void ValidationOfHomePageMenusNavigation(String clientCountry) {
		clickSubMenuAndValidate(bpCardsMenu, findAndUpdateCardSubMenu, commonTitleSec);
		clickSubMenuAndValidate(bpCardsMenu, orderCardSM, commonTitle);
		clickSubMenuAndValidate(bpCardsMenu, MgeReIssueCardFrmOC, commonTitleSec);
		clickSubMenuAndValidate(bpCardsMenu, bulkOrderUpdateSM, commonTitle);

		clickSubMenuAndValidate(transactionsMenus, findExportSM, commonTitle);

		clickSubMenuAndValidate(reportsMenu, runReportSM, commonTitleThird);
		clickSubMenuAndValidate(reportsMenu, mgeRecurringRePort, commonTitleThird);
		clickSubMenuAndValidate(reportsMenu, pastReportsSM, commonTitleThird);

		if (clientCountry.equals("AU")) {
			clickSubMenuAndValidate(bpPaymentsMenu, makePmtSM, commonTitleFour);
			clickSubMenuAndValidate(bpPaymentsMenu, updatePMMethodsSM, commonTitleFour);
			clickSubMenuAndValidate(bpPaymentsMenu, autoTopupSM, commonTitleFour);
			clickSubMenuAndValidate(bpPaymentsMenu, mgeAutoPmtsSM, autoPaymentTitle);
			clickSubMenuAndValidate(support, orderMerchandise, commonTitleFour);
		}

		clickSubMenuAndValidate(support, contactUs, commonTitleFour);

		/*if (clientCountry.equals("AU")) { - Fix Needed For BP Env Isue
			sleep(5);
				
			clickSubMenuAndValidate(support, helpGuide, userGuideTitleNW);
		} else {
			sleep(5);
			clickSubMenuAndValidate(support, helpGuide, userGuideTitleNZUG);

		}*/

	}

	public void clickAccountsDetailsAndValidate() {
		clickLinkAndValidateNavigation(acctDetailsHeader, commonTitleFour);
	}

	public void validateFooterLinksNavigation(String clientCountry) {

		// Home alone is pending
		clickLinkAndValidateNavigation(footerHomeLink, footerHomeLink);
		clickLinkAndValidateNavigation(footerContactUs, commonTitleFour);
		//clickLinkAndValidateNavigation(footerPriStmt, privacyTitleNW); BP Fix Needed Env Issue
		/*if (clientCountry.equals("AU"))
			clickLinkAndValidateNavigation(footerUserGuide, userGuideTitleNW);
		else
			clickLinkAndValidateNavigation(footerUserGuide, userGuideTitleNZUG);*/

		//clickLinkAndValidateNavigation(footerLegNotice, legalTitleNW);

	}

	public void clickFooterHomeandValidate() {
		try {
			if (footerHomeLink.isDisplayed()) {
				footerHomeLink.click();
				logInfo("Footer Home link is clicked");
				ValidateBPCustomerLogo();
				ValidateCustomerWelcomeText();
			}
		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
	}

	/*
	 * public void ValidateLogoutLink() throws Exception {
	 * //PageFactory.initElements(driver, this);
	 * 
	 * }
	 */

	public void clickAccountDetailsLink() {
		isDisplayedThenActionClick(accountDetailLink, "Account Detail Link");
	}

	public void loadAccountContactMenu() {
		clickSubMenuAndValidate(accountMenu, contactsMenu, mercOrLocContactPageTitle);
	}

	public void loadFindAndUpdateCardPage() {
		clickSubMenuAndValidate(bpCardsMenu, findAndUpdateCardSubMenu, pageTitleFindAndUpdate);
	}

	public void loadBulkOrderAndUpdateCardPage() {
		clickSubMenuAndValidate(bpCardsMenu, bulkOrderUpdateSM, commonTitle);
	}

	public void loadFindAndExportTransactionsPage() {
		clickSubMenuAndValidate(transactionsMenu, findExportSM, commonTitle);
	}

	public void loadPastReportsPage() {
		clickSubMenuAndValidate(reportsMenu, pastReportsSM, commonTitle);
		sleep(5);
	}

	/*
	 * 04-05-2018 Ayub khan
	 */
	public void manageReissueRequestsPage() {

		actionClick(bpCardsMenu);
		actionClick(manageReissueRequests);
		isDisplayed(pageTitleManageReissueRequest, "Manage Reissue Reqest page");
	}

	/*
	 * 07-05-2018 Ayub khan
	 */
	public void ValidateMerchantLogo() {
		isDisplayed(MerchantLogo, "BP Merchant Logo");
	}

	public void clickSettlementSubMenuAndValidatePage() {

		clickSubMenuAndValidate(transactionsMenu, settlementMenu, pageTitleSettlement);

	}

	public void accountMenuPage() {
		clickSubMenuAndValidate(accountMenu, merchant, pageTitleSettlement);

	}

	// 08-05-2018 Ayub Khan
	public void selectInputFromAccountDropdown(String selectdata) {
		isDisplayed(allListedAccounts, "Selected input from Account dropdown");
		selectDropDownByVisibleText(allListedAccounts, selectdata);

		sleep(3);
	}

	// 23.05.2018 added by Meenakshi
	public void clickTransactionListQuickLinksAndValidate(String merchantOrLocation) {
		if (merchantOrLocation.equalsIgnoreCase("Merchant")) {
			isDisplayedThenActionClick(mercTransactionLinks, "Click Transaction Quick Links");
		} else if (merchantOrLocation.equalsIgnoreCase("Location")) {
			isDisplayedThenActionClick(locTransactionQuickLinks, "Click Transaction Quick Links");
		}
		sleep(3);
		verifyText(transactionListPageTitle, "Transaction List");
	}

	public void selectAccountsFromDropDown() {
		
		Select accountsDDInHomePage = new Select (allListedAccounts);
		
		int optionsSize = accountsDDInHomePage.getOptions().size();
				
		if(optionsSize > 1)
		{

			String getBeforeAccount = selectedStringFrmDropDown(allListedAccounts);
			selectDifferentValueInsteadOfDefault(allListedAccounts, getBeforeAccount, "");
			sleep(3);
			String getAfterAccount = selectedStringFrmDropDown(allListedAccounts);
			if (getBeforeAccount.equals(getAfterAccount)) {
				logFail("Failed on selecting different Account");
			} else {
				logPass("Succesfully selected the different Account");
			}
		}
		
		else
		{
			logPass("We have only one Account or No account present");
		}

	}

	// 21.05.2018 added by Anton

	public void validateTheNavOfRecurringReportSubMenu() {
		clickSubMenuAndValidate(selectReportMenu, mgeRecurringRePort, pageTitleText);
	}
	
	public String getCustomerNumberFromDropDown()
	{
		isDisplayed(accountNameDropDownInHomePage, "Account Name In home page");
		String customerNumber = getAttribute(accountNameDropDownInHomePage, "value");
		return customerNumber;
	}
	
	public String getEffectiveFromDate()
	{
		isDisplayed(effectiveFromDate, "Effective from date in transactions");
		String fromDate = getAttribute(effectiveFromDate, "value");
		return fromDate;
	}
	@FindBy(id = Locator.TO_DATE)
	public WebElement dateRangeToDate;
	public String getEffectiveToDate()
	{
		isDisplayed(dateRangeToDate, "Effective from date in transactions");
		String fromDate = getAttribute(dateRangeToDate, "value");
		return fromDate;
	}
	
	public void selectPaymentMethod(String paymentMethod) {
		if(paymentMethod.equalsIgnoreCase("Saved card")) {
		isDisplayedThenClickRadioBTN(bpPaymentWithYourCreditCard, "Payment with you credit card");
		}
		else {
			isDisplayedThenClickRadioBTN(bpPaymentWithNewCreditCard, "Payment with new card details");	
		}
	}

	public void selectPaymentAmountAndConfirm(String paymentAmount) {
		isDisplayedThenEnterText(bpPaymentAmount, "Payment Amount", paymentAmount);
		isDisplayedThenClick(bpPaymentConfirmAndPay, "Confirm Payment");
	}
	
	public void confirmPaymentAndValidateSuccessMessage() {
		isDisplayedThenClick(bpPaymentConfirmAndPay, "Confirm Payment");
		waitForPageLoad(5);
		isDisplayed(bpPaymentSuccess, "Success Message");
		isDisplayed(bpPaymentRefNumber, "Reference Number");
		logInfo("Payment Reference Number : "+getText(bpPaymentRefNumber));
	}
	
	public void paymentDetailsFillUp(String cardType) {
		try {
		sleep(3);
		WebElement cardTypeSelect = driver.findElement(By.xpath("//ol[@id='card_type_selection']//li[1]//label"));
		
		if(cardTypeSelect.getText().equals("Visa")) {
			WebElement cardTypeBtnVisa = driver.findElement(
					By.xpath("//ol[@id='card_type_selection']//input[@id='card_type_001']"));
			isDisplayedThenClickRadioBTN(cardTypeBtnVisa, "Card Type");
			isDisplayedThenEnterText(paymentsCardNo, "Card Number", "4111111111111111");
			sleep(2);
			selectDropDownByVisibleTextUsingValue(paymentsExpMonth, "10");
			selectDropDownByVisibleTextUsingValue(paymentsExpYear, "2022");
			isDisplayedThenEnterText(paymentsCVN, "CVN", fakerAPI().number().digits(3));
			
			
		}
		else if(cardTypeSelect.getText().equals("Master Card")){
			WebElement cardTypeBtnMC = driver.findElement(
					By.xpath("//ol[@id='card_type_selection']//input[@id='card_type_002']"));
			isDisplayedThenClickRadioBTN(cardTypeBtnMC, "Card Type");
			isDisplayedThenEnterText(paymentsCardNo, "Card Number", "5555555555554444");
			selectDropDownByVisibleTextUsingValue(paymentsExpMonth, "10");
			selectDropDownByVisibleTextUsingValue(paymentsExpYear, "2022");
			isDisplayedThenEnterText(paymentsCVN, "CVN", fakerAPI().number().digits(3));
			}
		else {
			WebElement cardTypeBtnAMX = driver.findElement(
					By.xpath("//ol[@id='card_type_selection']//input[@id='card_type_003']"));
			isDisplayedThenClickRadioBTN(cardTypeBtnAMX, "Card Type");
			isDisplayedThenEnterText(paymentsCardNo, "Card Number", "378282246310005");
			selectDropDownByVisibleTextUsingValue(paymentsExpMonth, "10");
			selectDropDownByVisibleTextUsingValue(paymentsExpYear, "2022");
			isDisplayedThenEnterText(paymentsCVN, "CVN", fakerAPI().number().digits(3));
			}
		isDisplayedThenClick(paymentsPayBtn, "Pay Button");
		}catch(Exception e) {
			e.getMessage();
			//driver.navigate().back();
		}
	}
	
	public void validatePaymentSuccess(String msg) {
		sleep(20);
		checkTextInPageAndValidate(msg, 10);
		/*String a = paymentsSuccessMsg.getText();
		System.out.println(a);
		if(paymentsSuccessMsg.getText().equals(msg)) {
			logPass(msg);
		}else {
			logFail(msg);
		}*/
	}
}
