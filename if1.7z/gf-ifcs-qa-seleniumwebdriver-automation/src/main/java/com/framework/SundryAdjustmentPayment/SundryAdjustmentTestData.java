package com.framework.SundryAdjustmentPayment;

import org.testng.annotations.DataProvider;
public class SundryAdjustmentTestData {
	
	@DataProvider(name = "Sundry Adjustment Payments")
	public String [][] getDataForSundryAdjustmentPayment() {
	System.out.println("director:"+System.getProperty("user.dir")+"\\Resources\\Testdata.xlsx");
	ExcelReader readExcelData = new ExcelReader(System.getProperty("user.dir")+"\\Resources\\Testdata.xlsx", "Sheet1");
	return ExcelReader.getExcelData(readExcelData);
	}
}
