using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using Common;
using Common.PageObjects;
using Common.ScenarioConfigurations;
using Common.Utility;

namespace EnCompass.Testing.Source.PageObjects.SuperAdmin.SuperUserManagement 
{
	/// <summary>
	/// Auto-generated Page Model Class
	/// Navigation Paths: 
		/// [Organization Home]->Users and Organizations->Admin Users
		/// </summary>
	[PageModel(@"/SuperAdmin/SuperUserManagement/ManageSupers.aspx")]
	public partial class ManageSupers : EnCompassSuperPageModel 
	{
		public override string RelativeUrl => @"/SuperAdmin/SuperUserManagement/ManageSupers.aspx";
		public override string PageIdentifierXPath_Generated => @"//li[contains(@class, 'breadcrumb-item active')][text() = 'Admin Users']";

		#region Navigation
		
		private void NavigateToMenuItem(IWebElement element)
		{
			Driver.Url = element.GetAttribute("href");
		}
		#endregion

		public ManageSupers(GlobalSettings settings) : base(settings) { }
	}  
}
