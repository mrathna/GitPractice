﻿using Common.StepDefinitions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;

namespace Common
{
	public class StepException
	{
		public Guid StepId { get; set; }

		public Exception Error { get; set; }

		public StepException(ScenarioStepContext stepContext, Exception error)
		{
			StepId = BaseHooks.GetStepId(stepContext);
			Error = error;
		}

		public StepException(StepDefinition step, Exception error)
		{
			StepId = BaseHooks.GetStepId(step.StepContext);
			Error = error;
		}

        public StepException(Exception error)
        {
            //StepId = BaseHooks.GetStepId(step.StepContext);
            Error = error;
        }
	}
}
