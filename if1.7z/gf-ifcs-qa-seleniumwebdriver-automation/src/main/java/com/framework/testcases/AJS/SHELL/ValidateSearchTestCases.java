package com.framework.testcases.AJS.SHELL;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.SearchPage;
import com.framework.pages.AJS.common.Common;
import com.framework.pages.AJS.common.IFCSHomePage;
import com.framework.pages.AJS.common.IFCSLoginPage;

public class ValidateSearchTestCases extends BaseTest {
	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test( groups = { "Regression" })
	public void validateSearchCards(@Optional("RU") String clientCountry, @Optional("SHELL") String clientName,
			@Optional("APA") String cardType) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  Verify Search Cards", "Verifying Search cards");
		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		SearchPage searchInputs = new SearchPage(driver, test);
		Common common = new Common(driver, test);
		IFCSloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, cardType);
		IFCSHomePage.gotoSearchAndClickCards();
		common.performBlankSearchAndValidate();
		// Select client from dropdown and validate
		searchInputs.selectClientInDropDownAndSearch("Client", clientName + "_" + clientCountry);
		// Search customer number
		searchInputs.enterCustomerNumberAndSearch(clientName + "_" + clientCountry);
		// Enter a Driver Name and select the Search button
		common.searchDriverNameAndValidate("Full");
		// Enter a Part Driver Name and use the Wildcard (*) symbol and select the
		// Search button
		common.searchDriverNameAndValidate("Partial");
		// Enter a Card Number and select the Search button
		common.searchCardnumberAndValidate("Full", "Filter By");
		// Enter a Card Number and use the Wildcard (*) symbol and select the Search
		// button
		common.searchCardnumberAndValidate("Partial", "Filter By");
		// Enter a Cost Centre and select the Search button and validate
		common.searchCostCentreValueAndValidate("Full");
		// Enter a Part Cost Centre and use the Wildcard (*) symbol and select the
		// Search button and validate
		common.searchCostCentreValueAndValidate("Partial");
		// Enter a VRN and select the Search button and validate
		common.searchVRNValueAndValidate("Full");
		// Enter a Part VRN and use the Wildcard (*) symbol and select the Search button
		// and validate
		common.searchVRNValueAndValidate("Partial");
		// Enter a Vehicle Description and select the Search button and validate
		common.searchVehicleDescriptionAndValidate("Full");
//		// Enter a Part Vehicle Description and use the Wildcard (*) symbol and select
//		// the Search button and validate
		common.searchVehicleDescriptionAndValidate("Partial");
		// Enter a Vehicle Id and select the Search button and validate
		common.searchVehicleIdAndValidate("Full");
		// Enter a Part Driver Id and use the Wildcard (*) symbol and select the Search
		// button and validate
		common.searchVehicleIdAndValidate("Partial");
		// Enter a Driver Id and select the Search button and validate
		common.searchDriverIdAndValidate("Full");
		// Enter a Part Driver Id and use the Wildcard (*) symbol and select the Search
		// button and validate
		common.searchDriverIdAndValidate("Partial");
		// Enter does not exist driver name and validate
		searchInputs.enterUnknownDriverNameAndSearch();
		IFCSHomePage.exitIFCS();
	}

	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test( groups = { "Regression" })
	public void validateSearchVehicles(@Optional("RU") String clientCountry, @Optional("SHELL") String clientName,
			@Optional("APA") String cardType) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  Verify Search Vehicles", "Verifying Search Vehicles");
		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		SearchPage searchInputs = new SearchPage(driver, test);
		Common common = new Common(driver, test);
		IFCSloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, cardType);
		IFCSHomePage.gotoSearchAndClickVehicles();
		common.performBlankSearchAndValidate();
		searchInputs.selectClientInDropDownAndSearch("Client", clientName + "_" + clientCountry);
		// Search customer number
		searchInputs.enterCustomerNumberAndSearch(clientName + "_" + clientCountry);
		// Enter a Card Number and select the Search button
		// common.searchCardnumberAndValidate("Full","Filter By");
		// Enter a Card Number and use the Wildcard (*) symbol and select the Search
		// button
		common.searchCardnumberAndValidate("Partial", "Filter By");
		// Enter a VRN and select the Search button and validate
		common.searchVRNValueAndValidate("Full");
		// Enter a Part VRN and use the Wildcard (*) symbol and select the Search button
		// and validate
		// common.searchVRNValueAndValidate("Partial");
		// Enter a Vehicle Description and select the Search button and validate
		common.searchDescriptionAndValidate("Full");
		// Enter a Part Vehicle Description and use the Wildcard (*) symbol and select
		// the Search button and validate
		common.searchDescriptionAndValidate("Partial");
		// Enter a Vehicle Id and select the Search button and validate
		common.searchVehicleIdAndValidate("Full");
		// Enter a Part Driver Id and use the Wildcard (*) symbol and select the Search
		// button and validate
		common.searchVehicleIdAndValidate("Partial");
		// Enter does not exist VRN and validate
		searchInputs.enterUnknownVRNeAndSearch();
		IFCSHomePage.exitIFCS();

	}

	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test( groups = { "Regression" })
	public void validateSearchDrivers(@Optional("RU") String clientCountry, @Optional("SHELL") String clientName,
			@Optional("APA") String cardType) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  Verify 03 Search Drivers", "Verifying 03 Search Drivers");
		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		SearchPage searchInputs = new SearchPage(driver, test);
		Common common = new Common(driver, test);

		IFCSloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, cardType);
		IFCSHomePage.gotoSearchAndClickDrivers();
		common.performBlankSearchAndValidate();
		searchInputs.selectClientInDropDownAndSearch("Client", clientName + "_" + clientCountry);
		// Search customer number
		searchInputs.enterCustomerNumberAndSearch(clientName + "_" + clientCountry);
		// Enter a Driver Name and select the Search button
		common.searchDriverNameAndValidate("Full");
		// Enter a Part Driver Name and use the Wildcard (*) symbol and select the
		// Search button
		common.searchDriverNameAndValidate("Partial");
		// Enter a Card Number and select the Search button
		common.searchCardnumberAndValidate("Full", "Filter By");
		// Enter a Card Number and use the Wildcard (*) symbol and select the Search
		// button
		common.searchCardnumberAndValidate("Partial", "Filter By");
		// Enter a Driver Id and select the Search button and validate
		common.searchDriverIdAndValidate("Full");
		// Enter a Part Driver Id and use the Wildcard (*) symbol and select the Search
		// button and validate
		common.searchDriverIdAndValidate("Partial");
		// Enter does not exist driver name and validate
		searchInputs.enterUnknownDriverNameAndSearch();
		IFCSHomePage.exitIFCS();
	}

	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test( groups = { "Regression" })
	public void validateSearchTransactions(@Optional("RU") String clientCountry, @Optional("SHELL") String clientName,
			@Optional("APA") String cardType) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  Verify Search Transactions", "Verifying Search Transactions");
		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		SearchPage searchInputs = new SearchPage(driver, test);
		Common common = new Common(driver, test);

		IFCSloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, cardType);
		IFCSHomePage.gotoSearchAndClickTransactions();
		common.performBlankSearchAndValidate();
		searchInputs.selectClientInDropDownAndSearch("Customer Client", clientName + "_" + clientCountry);

		// Search customer number
		searchInputs.enterCustomerNoHasTransactionAndSearch(clientName + "_" + clientCountry);
		// Search Loaction Number
		searchInputs.enterLocationNoHasTransactionAndSearch(clientName + "_" + clientCountry);
		// Enter a Card Number and select the Search button
		common.searchCardnumberAndValidate("Full", "Transaction Filter Fields");
		// Enter a Card Number and use the Wildcard (*) symbol and select the Search
		// button
		common.searchCardnumberAndValidate("Partial", "Transaction Filter Fields");
		// Enter a Reference No and select the Search button and validate
		common.searchReferenceValueAndValidate("Full");
		// Enter a Part Reference No and use the Wildcard (*) symbol and select the
		// Search button and validate
		common.searchReferenceValueAndValidate("Partial");
		// From the Dropdown select a Process From Date and select the Search Button and
		// validate
		searchInputs.enterProcessDateAndSearch("Process Date From", clientName + "_" + clientCountry);
		// From the Dropdown select a Process From Date and select the Search Button
		searchInputs.enterProcessDateAndSearch("Process Date To", clientName + "_" + clientCountry);
		// From the Dropdown select an Effective From Date and select the Search Button
		searchInputs.enterProcessDateAndSearch("Effective Date From", clientName + "_" + clientCountry);
		// From the Dropdown select an Effective To Date and select the Search Button
		searchInputs.enterProcessDateAndSearch("Effective Date To", clientName + "_" + clientCountry);
		// Select a Process Date From and a Part Reference No using the Wildcard symbol
		// and select the Search button and validate
		searchInputs.enterProcessDateFromAndPartReferenceNoAndSearch("Process Date From",
				clientName + "_" + clientCountry);
		// Select an Effective Date to and a Part Card No using the Wildcard symbol and
		// select the Search button and validate
		searchInputs.enterProcessDateAndPartialCardSearch("Process Date From", clientName + "_" + clientCountry);
		// From the Dropdown select a Process From Date that is in the Future and select
		// the Search Button
		searchInputs.enterFutureDateAndSearch(clientName + clientCountry);
		// Enter a Reference No that does not exist and select the Search button
		searchInputs.enterUnknownReferenceNoAndSearch();
		// Select Location client
		searchInputs.selectClientInDropDownAndSearch("Location Client", clientName + "_" + clientCountry);
		IFCSHomePage.exitIFCS();
	}

	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test( groups = { "Regression" })
	public void validateSearchCustomerInvoices(@Optional("RU") String clientCountry,
			@Optional("SHELL") String clientName, @Optional("APA") String cardType) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  Verify Search Customer Invoices", "Verifying Search Customer Invoices");
		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		SearchPage searchInputs = new SearchPage(driver, test);

		Common common = new Common(driver, test);

		IFCSloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, cardType);
		IFCSHomePage.gotoSearchAndClickCustomerInvoices();
		common.performBlankSearchAndValidate();
		searchInputs.selectClientInDropDownAndSearch("Client", clientName + "_" + clientCountry);
		/*
		 * common.searchCustomerNumberHasInvoicesAndValidate("Full");
		 * common.searchCustomerNumberHasInvoicesAndValidate("Partial");
		 * common.searchRemittanceIDHasInvoicesAndValidate("Full");
		 * common.searchRemittanceIDHasInvoicesAndValidate("Partial");
		 */
		// From the Dropdown select a Created From Date and select the Search Button
		searchInputs.enterInvoicesDateAndSearch("Created From", clientName + "_" + clientCountry);
		// From the Dropdown select a Created To Date and select the Search Button
		searchInputs.enterInvoicesDateAndSearch("Created To", clientName + "_" + clientCountry);
		// From the Dropdown select a Create From Date that is in the Future and select
		// the Search Button
		searchInputs.enterInvoicesFutureDateAndSearch(clientName + clientCountry);
		// Select a Created Date From and a Part Remittance ID using the Wildcard symbol
		// and select the Search button
		searchInputs.enterInvoicesDateAndPartRemittanceIDSearch("Created From", clientName + "_" + clientCountry);
		// Select a Customer Number and a Part Remittance ID using the Wildcard symbol
		// and select the Search button
		common.searchCustomerNumberAndPartRemittanceIDdValidate("Full");
		searchInputs.enterUnknownRemittanceIDAndSearch();
		IFCSHomePage.exitIFCS();

	}

}
