package com.framework.testcases.OLS.EMAP.Customer;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.EMAP.EMAPCardsPage;
import com.framework.pages.EMAP.EMAPHomePage;
import com.framework.pages.OLS.common.CommonPage;
import com.framework.pages.OLS.common.LoginPage;

public class ValidateReplaceCard extends BaseTest {
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "Regression" })
	public void validateReplaceCardRW(@Optional("SP") String clientCountry, @Optional("EMAP") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  TST-SC-12-OLS - Card List - Replace Card",
				"Validate replace card for read-only, read/write and view-only");
		LoginPage loginPage = new LoginPage(driver, test);

		// Read-Write //
		loginPage.Login("EMAP_URL", "EMAP_UN_ReadWrite_Customer_" + clientCountry,
				"EMAP_PWD_ReadWrite_Customer_" + clientCountry, clientName);
		EMAPHomePage emapHomePage = new EMAPHomePage(driver, test);
		EMAPCardsPage emapCardsPage = new EMAPCardsPage(driver, test);
		CommonPage commonPage = new CommonPage(driver, test);

		emapHomePage.clickCardListAndValidatePage();
		commonPage.selectAllAccountOptionFromAccountDropdown();
		emapCardsPage.selectACardStatus("Active");
		commonPage.clickSearchButton();
		emapCardsPage.selectACardFromCardListTable(true);
		emapCardsPage.clickContextMenuOptionAndVerifyCardNumberInNavigatedPage("Change Card Status");
		emapCardsPage.chooseANewCardStatus("Lost");
		emapCardsPage.enterADateValueInStatusBeginDateField("Current", clientName + clientCountry);
		emapCardsPage.clickSaveStatusChange();
		emapCardsPage.checkReplaceCardPopupContent("Lost");
		emapCardsPage.verifyCardStatusChangedSuccessMessage("Lost");
		emapCardsPage.validateBackToCardListPageLink();

		loginPage.Logout();
	}

	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "Regression" })
	public void validateReplaceCardRO(@Optional("SP") String clientCountry, @Optional("EMAP") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  Customer - EMAP Replace Card-RO",
				"Validate replace card for read-only, read/write and view-only");
		LoginPage loginPage = new LoginPage(driver, test);
		EMAPHomePage emapHomePage = new EMAPHomePage(driver, test);
		EMAPCardsPage emapCardsPage = new EMAPCardsPage(driver, test);
		CommonPage commonPage = new CommonPage(driver, test);
		// Read - Only //
		loginPage.Login("EMAP_URL", "EMAP_UN_ReadOnly_Customer_" + clientCountry,
				"EMAP_PWD_ReadOnly_Customer_" + clientCountry, clientName);

		emapHomePage.clickCardListAndValidatePage();
		commonPage.selectAllAccountOptionFromAccountDropdown();
		emapCardsPage.selectACardStatus("Active");
		commonPage.clickSearchButton();
		emapCardsPage.selectACardFromCardListTable(true);
		emapCardsPage.checkContextMenuNotPresent("Change Card Status");
		loginPage.Logout();
	}

	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "Regression" })
	public void validateReplaceCardVO(@Optional("SP") String clientCountry, @Optional("EMAP") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  Customer - EMAP Replace Card-VO",
				"Validate replace card for read-only, read/write and view-only");
		LoginPage loginPage = new LoginPage(driver, test);
		// View-Only //
		loginPage.Login("EMAP_URL", "EMAP_UN_ViewOnly_Customer_" + clientCountry,
				"EMAP_PWD_ViewOnly_Customer_" + clientCountry, clientName);
		EMAPHomePage emapHomePage = new EMAPHomePage(driver, test);
		EMAPCardsPage emapCardsPage = new EMAPCardsPage(driver, test);
		CommonPage commonPage = new CommonPage(driver, test);

		emapHomePage.clickCardListAndValidatePage();
		commonPage.selectAllAccountOptionFromAccountDropdown();
		emapCardsPage.selectACardStatus("Active");
		commonPage.clickSearchButton();
		emapCardsPage.selectACardFromCardListTable(true);
		emapCardsPage.clickContextMenuOptionAndVerifyCardNumberInNavigatedPage("Change Card Status");
		emapCardsPage.chooseANewCardStatus("Lost");
		emapCardsPage.enterADateValueInStatusBeginDateField("Current", clientName + clientCountry);
		emapCardsPage.clickSaveStatusChange();
		emapCardsPage.checkReplaceCardPopupContent("Lost");
		emapCardsPage.verifyCardStatusChangedSuccessMessage("Lost");
		emapCardsPage.validateBackToCardListPageLink();
		loginPage.Logout();
	}
}
