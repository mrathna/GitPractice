﻿using Common.Utility;
using EnCompass.Testing.Source.PageObjects.Controls;
using NFluent;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EnCompass.Testing.Source.PageObjects.Organization.ExpenseManager.Transactions
{
	public partial class FinancialCodeProfileAssigntoNodes
	{
        #region XPATH

        private const string _selectAssignedProfilesXPath = @"//select[contains(@id, 'From')]" + @"//*[normalize-space(text())='PROFILE1']";
        private const string _ddlApplyRecursiveXPath = @"//select[contains(@id,'ddlApplyRecursive')]";
        private const string _saveXPath = @"//input[contains(@id,'btnsave')]";
        private const string _assignAllProfileAvailableXPath = @"//button[contains(@id,'AddAll')]";
        private const string _availableAllProfileAssignedXPath = @"//button[contains(@id,'RemoveAll')]";
        private const string _addProfileAvailableXPath = @"//button[contains(@id,'ThisToThat1')]";
        private const string _removeProfileAssignedXPath = @"//button[contains(@id,'Remove') and @title='Move selected to available']";
        private const string _hierarchyExplorerXPath = @"//a[contains(@id,'hierarchyExplorer')]";
        private const string _overrideDescendantNodesXPath = @"//input[contains(@id,'chbOverrideDescendantNodes')]";
        private const string _checkProxyOwnersCheckboxLabelXPath = @"//label[contains(@for,'chbOverrideDescendantNodes')]";

        #endregion

        #region IWebElements Props

        public IWebElement _selectAssignedProfiles
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_selectAssignedProfilesXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_selectAssignedProfiles element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _ddlApplyRecursive
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_ddlApplyRecursiveXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_ddlApplyRecursive element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _save
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_saveXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_save element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _assignAllProfileAvailable
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_assignAllProfileAvailableXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_assignAllProfileAvailable element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _availableAllProfileAssigned
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_availableAllProfileAssignedXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_availableAllProfileAssigned element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _addProfileAvailable
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_addProfileAvailableXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_addProfileAvailable element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _removeProfileAssigned
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_removeProfileAssignedXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_removeProfileAssigned element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _hierarchyExplorer
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_hierarchyExplorerXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_hierarchyExplorer element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _overrideDescendantNodes
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_overrideDescendantNodesXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_overrideDescendantNodes element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _checkProxyOwnersCheckboxLabel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_checkProxyOwnersCheckboxLabelXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_checkProxyOwnersCheckboxLabel element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        #endregion
        
        public void SelectAssignedProfiles()
		{
			_selectAssignedProfiles.JSClickWithFocus(Driver);
		}

		public void SelectAssignedProfiles(string profileName)
		{
			Settings.EnCompassWebDriver.FindElement(By.XPath(@"//select[contains(@id, 'From')]" + $@"//*[normalize-space(text())='{profileName}']")).JSClickWithFocus(Driver);
		}

		public void SetRecursivelyDropDown(string whichText)
		{
            Settings.EnCompassWebDriver.SelectDDLOptionByTextViaJS(Settings, _ddlApplyRecursiveXPath, whichText);
		}

		public void Save()
		{
            _save.JSClickWithFocus(Driver,null, Settings);
            Logger.LogInfo("Clicked Save button using JSClick");
            this.AttachOnDemandScreenShot();
		}

        public bool VerifyMessage(string msg)
        {
            try
            {
                Driver.TryWaitForElementToBeVisible(By.XPath(@"//div[contains(@id,'ValidationAlertMessages')]"), out IWebElement msgContainer);
                Check.That(msgContainer.Text.Equals(msg)).IsTrue();
                return true;
            }
            catch (Exception)
            {
                return false;
            }
            
        }

		public void OverrideDescendantNodes()
		{
            _overrideDescendantNodes.SetCheckboxStateWithLabel(_checkProxyOwnersCheckboxLabel, true);
		}

		public void AssignAllProfileAvailable()
		{
			_assignAllProfileAvailable.JSClickWithFocus(Driver);
		}

		public void AvailableAllProfileAssigned()
		{
			_availableAllProfileAssigned.JSClickWithFocus(Driver);
		}

		public void AddProfileAvailable()
		{
			_addProfileAvailable.JSClickWithFocus(Driver);
		}

		public void RemoveProfileAssigned()
		{
			_removeProfileAssigned.JSClickWithFocus(Driver);
		}

		public void AssignProfileAvailable(List<string> CodeProfilesList)
		{
			foreach (string profileName in CodeProfilesList)
			{
				Settings.EnCompassWebDriver.FindElement(By.XPath(@"//select[contains(@id, 'From')]" + $@"//*[normalize-space(text())='{profileName}']")).JSClickWithFocus(Driver);
			}
			AddProfileAvailable();
		}

		public void AvailableProfileAssigned(string CodeProfiles)
		{
			SelectElement selectElement = new SelectElement(Settings.EnCompassWebDriver.FindElement(By.XPath(@"//select[contains(@id, '_To')]")));
			selectElement.DeselectAll();
			Settings.EnCompassWebDriver.FindElement(By.XPath(@"//select[contains(@id, '_To')]" + $@"//*[normalize-space(text())='{CodeProfiles}']")).JSClickWithFocus(Driver);
			RemoveProfileAssigned();
		}

		//Accessing OrgHierarchy object which has the common functionality of Choosing the Hierarchy Option
		private OrgHierarchy _hierarchy;
		public OrgHierarchy Hierarchy
		{
			get
			{
				return _hierarchy ?? (_hierarchy = new OrgHierarchy(_hierarchyExplorer, Driver, Settings));
			}
		}

		public bool ValidateEmptyAssignedProfiles()
		{
			return Settings.EnCompassWebDriver.FindElement(By.XPath(@"//select[contains(@id,'ThisToThat1_To')]")).GetAttribute("childElementCount").Equals("0") ? true : false;
		}

		public bool ValidateAssignedProfiles(string financialCodeProfile)
		{
			return Settings.EnCompassWebDriver.FindElement(By.XPath(@"//select[contains(@id, 'ThisToThat1_To')]")).GetAttribute("textContent").Contains(financialCodeProfile) ? true : false;
		}

		public bool ValidateEmptyProfileInherited()
		{
			return Driver.IsElementPresent(By.XPath(@"//p[contains(text(),'Profiles inherited')]"));
		}

		public bool ValidateProfileInherited(List<string> profilesInherited)
		{
			bool element = true;
			int i = 0;
			while (element == true && i<profilesInherited.Count)
			{
				string profile = profilesInherited[i];
				element = Settings.EnCompassWebDriver.FindElement(By.XPath(@"//*[contains(text(),'Profiles Inherited for the Selected Hierarchy')]//following::ul")).GetAttribute("innerText").Contains(profile);
				i++;
			}
			return element;
		}
	}
}
