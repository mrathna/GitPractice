using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using Common;
using Common.PageObjects;
using Common.ScenarioConfigurations;
using Common.Utility;

namespace EnCompass.Testing.Source.PageObjects.Organization.Payables.MerchantPayments 
{
	/// <summary>
	/// Auto-generated Page Model Class
	/// Navigation Paths: 
		/// [Organization Home]->Payables->Accounts Payable->Create Merchant Log
		/// </summary>
	[PageModel(@"/payables/merchantPayments/MerchantLogEdit.aspx")]
	public partial class MerchantLogEdit : EnCompassOrgPageModel 
	{
		public override string RelativeUrl => @"/payables/merchantPayments/MerchantLogEdit.aspx";
		public override string PageIdentifierXPath_Generated => @"//li[contains(@class, 'breadcrumb-item active')][text() = 'Create Merchant Log']";

		#region Navigation
				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Merchant Logs']")]
		private IWebElement _payables_AccountsPayable_CreateMerchantLog_MerchantLogs { get; set; }
		public void NavigateTo_Payables_AccountsPayable_CreateMerchantLog_MerchantLogs()
		{
			NavigateToMenuItem(_payables_AccountsPayable_CreateMerchantLog_MerchantLogs);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Create Merchant Log']")]
		private IWebElement _payables_AccountsPayable_CreateMerchantLog_CreateMerchantLog { get; set; }
		public void NavigateTo_Payables_AccountsPayable_CreateMerchantLog_CreateMerchantLog()
		{
			NavigateToMenuItem(_payables_AccountsPayable_CreateMerchantLog_CreateMerchantLog);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Merchant Log Reconciliation']")]
		private IWebElement _payables_AccountsPayable_CreateMerchantLog_MerchantLogReconciliation { get; set; }
		public void NavigateTo_Payables_AccountsPayable_CreateMerchantLog_MerchantLogReconciliation()
		{
			NavigateToMenuItem(_payables_AccountsPayable_CreateMerchantLog_MerchantLogReconciliation);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Merchant Log Settings']")]
		private IWebElement _payables_AccountsPayable_CreateMerchantLog_MerchantLogSettings { get; set; }
		public void NavigateTo_Payables_AccountsPayable_CreateMerchantLog_MerchantLogSettings()
		{
			NavigateToMenuItem(_payables_AccountsPayable_CreateMerchantLog_MerchantLogSettings);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Manage Disputes']")]
		private IWebElement _payables_AccountsPayable_CreateMerchantLog_ManageDisputes { get; set; }
		public void NavigateTo_Payables_AccountsPayable_CreateMerchantLog_ManageDisputes()
		{
			NavigateToMenuItem(_payables_AccountsPayable_CreateMerchantLog_ManageDisputes);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Merchants']")]
		private IWebElement _payables_AccountsPayable_CreateMerchantLog_Merchants { get; set; }
		public void NavigateTo_Payables_AccountsPayable_CreateMerchantLog_Merchants()
		{
			NavigateToMenuItem(_payables_AccountsPayable_CreateMerchantLog_Merchants);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Merchant Enrollment Status']")]
		private IWebElement _payables_AccountsPayable_CreateMerchantLog_MerchantEnrollmentStatus { get; set; }
		public void NavigateTo_Payables_AccountsPayable_CreateMerchantLog_MerchantEnrollmentStatus()
		{
			NavigateToMenuItem(_payables_AccountsPayable_CreateMerchantLog_MerchantEnrollmentStatus);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Manage EnCircle Enrollment']")]
		private IWebElement _payables_AccountsPayable_CreateMerchantLog_ManageEncircleEnrollment { get; set; }
		public void NavigateTo_Payables_AccountsPayable_CreateMerchantLog_ManageEncircleEnrollment()
		{
			NavigateToMenuItem(_payables_AccountsPayable_CreateMerchantLog_ManageEncircleEnrollment);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='AR-Exchange Invoices']")]
		private IWebElement _payables_AccountsPayable_CreateMerchantLog_ArExchangeInvoices { get; set; }
		public void NavigateTo_Payables_AccountsPayable_CreateMerchantLog_ArExchangeInvoices()
		{
			NavigateToMenuItem(_payables_AccountsPayable_CreateMerchantLog_ArExchangeInvoices);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Create Test Cards']")]
		private IWebElement _payables_AccountsPayable_CreateMerchantLog_CreateTestCards { get; set; }
		public void NavigateTo_Payables_AccountsPayable_CreateMerchantLog_CreateTestCards()
		{
			NavigateToMenuItem(_payables_AccountsPayable_CreateMerchantLog_CreateTestCards);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Create Test Transactions']")]
		private IWebElement _payables_AccountsPayable_CreateMerchantLog_CreateTestTransactions { get; set; }
		public void NavigateTo_Payables_AccountsPayable_CreateMerchantLog_CreateTestTransactions()
        {
			NavigateToMenuItem(_payables_AccountsPayable_CreateMerchantLog_CreateTestTransactions);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Start CLU or ECLU']")]
		private IWebElement _payables_AccountsPayable_CreateMerchantLog_StartCluOrEclu { get; set; }
		public void NavigateTo_Payables_AccountsPayable_CreateMerchantLog_StartCluOrEclu()
		{
			NavigateToMenuItem(_payables_AccountsPayable_CreateMerchantLog_StartCluOrEclu);
		}

		
		private void NavigateToMenuItem(IWebElement element)
		{
			Driver.Url = element.GetAttribute("href");
		}
		#endregion

		public MerchantLogEdit(GlobalSettings settings) : base(settings) { }
	}  
}
