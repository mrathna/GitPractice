﻿using AventStack.ExtentReports;
using Common;
using Common.Utility;
using EnCompass.Testing.Source.PageObjects.Controls;
using EnCompass.Testing.Source.Utility;
using NFluent;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;

namespace EnCompass.Testing.Source.PageObjects.Organization.SecurityManager.AccountManagement
{
    [PageModel(@"/securityManager/accountManagement/accountEdit.aspx")]
    public partial class AccountEdit : EnCompassOrgPageModel, IMobilePhone
    {
        private PhoneControl _mobilePhone;
        
        #region XPATH

        public override string RelativeUrl => @"/securityManager/accountManagement/accountEdit.aspx";
        public override string PageIdentifierXPath_Override => @"//li[text()='Create User' or contains(text(),'Edit')]";
        private const string AccountNodeHierarchyExplorer = @"//a[contains(@id, 'userAccountNodeHierarchyExplorer')]";
        private static string _approvalLimitXpath = @"//input[contains(@id,'AppLimit')]";
        private static string _instantApprovalLimitXpath = @"//input[contains(@id,'curInstantApprovalLimit')]";
        private static string _velocityLimitXpath = "//input[contains(@id,'VelocityLimit')]";

        private const string _userNameXPath = "//input[contains(@id,'txtUserName')]";
        private const string _passwordXPath = "//input[contains(@id,'txtPassword')]";
        private const string _passwordConfirmXPath = "//input[contains(@id,'txtPasswordConfirm')]";
        private const string _passwordComplexityXPath = "//div[contains(@id,'pswd_info')]";
        public const string _expirePasswordXPath = "//input[contains(@id,'ExpirePassword') and @type='checkbox']";
        public const string _expirePasswordLabelXPath = "//label[contains(@for,'chkExpirePassword')]";
        public const string _generateRandomPasswordXPath = "//input[contains(@id,'GenerateRandomPassword') and @type='checkbox']";
        public const string _generateRandomPasswordLabelXPath = "//label[contains(@for,'chkGenerateRandomPassword')]";
        private const string _firstNameXPath = "//input[contains(@id,'txtFirstName')]";
        private const string _lastNameXPath = "//input[contains(@id,'txtLastName')]";
        private const string _primaryPhoneTxtXPath = "//input[contains(@id,'ipnPrimaryPhone')]";
        private const string _mobilePhoneTxtXPath = "//input[contains(@id,'ipnMobilePhone')]";
        private const string _emailXPath = "//input[contains(@id,'txtEmail')]";
        private const string _cancelXPath = "//input[contains(@id,'btnCancel')]";
        private const string _NoCardsGridMessageXPath = "//table[contains(@id, 'dgCardsAssigned')]//td[contains(@class, 'gridNoRecordsMessage')]";
        private const string _assignCardsBtnXPath = "//input[contains(@id, 'btnDispCAPanel')]";
        private const string _searchBtnXPath = "//input[contains(@id, 'btnSearch')]";
        private const string _assignFirstCardChecboxXPath = "//input[contains(@id,'dgAccounts_ctl03_chkSelection')]";
        private const string _assignFirstCardCheckboxLabelXPath = "//label[contains(@for,'dgAccounts_ctl03_chkSelection')]";
        private const string _assignAllCardCheckboxXPath = "//input[contains(@id,'CheckboxColumnBoxActual')]";
        private const string _assignAllCardCheckboxLabelXPath = "//label[contains(@for,'CheckboxColumnBoxActual')]";
        private const string _unassignedCardsbtnXPath = "//input[contains(@id,'rbUnassigned')]";
        private const string _searchTermXPath = "//select[contains(@id,'searchTermSelect')]";
        private const string _searchValueXPath = "//div[contains(@id,'searchTermValueInputGroup')]//input[contains(@id, 'SearchOutput_txt')]";
        private const string _searchCriteriaAddBtnXPath = "//div[contains(@class,'append')]//input[@type='button' and @value='Add']";
        private const string _newPasswordXPath = "//input[contains(@id,'txtPassword')]";
        private const string _confirmPasswordXPath = "//input[contains(@id,'txtPasswordConfirm')]";
        private const string _errorMessageXPath = "//div[contains(@id,'ValidationSummary') and @role='alert']";
        private const string _roleSelectXPath = "//select[contains(@name,'ddlRole')]";
        private const string _ssnXPath = "//input[contains(@id,'txtUniqueId')]";
        private const string _confirmSSNXPath = "//input[contains(@id,'txtConfirmUniqueId')]";
        private const string _MiddleNameXPath = "//input[contains(@id,'txtMiddleName')]";
        private const string _userStatusXPath = "//select[contains(@id,'UserStatus')]";
        private const string _profileDropdownXPath = "//select[contains(@name,'profileDropdown')]";
        private const string _searchCriteriaSearchTermXPath = "//select[contains(@id, 'searchTermSelect')]";
        private const string _searchCriteriaTextSearchValueXPath = "//div[contains(@id, 'SearchOutput')]/input[1]";
        private const string _assignBothCardsXPath = "//input[contains(@id,'CheckboxColumnBoxActual')]";
        private const string _assignBothCardsLabelXPath = "//label[contains(@for,'CheckboxColumnBoxActual')]";
        private const string _manageProxyXPath = "//input[contains(@id,'cmdManageProxy')]";
        private const string _ddlApproversXPath = "//select[contains(@id,'ddlApprovers')]";
        private const string _btnResetXPath = "//input[contains(@value,'Reset')][@type='button']";
        private const string _hierarchyExplorerXPath = "//a[contains(@id, 'hierarchyExplorer')]";
        private const string _btnEditPasswordXPath = "//button[contains(@id,'btnEditPassword')]";


        #endregion

        #region IWebElements Props

        private IWebElement _userName
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_userNameXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_userName element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _password
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_passwordXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_password element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _passwordConfirm
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_passwordConfirmXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_passwordConfirm element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _passwordComplexity
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_passwordComplexityXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_passwordComplexity element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        public IWebElement _expirePassword
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_expirePasswordXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_expirePassword element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        public IWebElement _expirePasswordLabel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_expirePasswordLabelXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_expirePasswordLabel element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _generateRandomPassword
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_generateRandomPasswordXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_generateRandomPassword element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _generateRandomPasswordLabel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_generateRandomPasswordLabelXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_generateRandomPasswordLabel element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _firstName
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_firstNameXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_firstName element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _lastName
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_lastNameXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_lastName element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _primaryPhoneTxt
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_primaryPhoneTxtXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_primaryPhoneTxt element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _mobilePhoneTxt
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_mobilePhoneTxtXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_mobilePhoneTxt element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _email
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_emailXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_email element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _cancel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_cancelXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_cancel element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _NoCardsGridMessage
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_NoCardsGridMessageXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_NoCardsGridMessage element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _assignCardsBtn
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_assignCardsBtnXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_assignCardsBtn element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _searchBtn
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_searchBtnXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_searchBtn element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _assignFirstCardChecbox
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_assignFirstCardChecboxXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_assignFirstCardChecbox element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _assignFirstCardCheckboxLabel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_assignFirstCardCheckboxLabelXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_assignFirstCardCheckboxLabel element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _assignAllCardCheckbox
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_assignAllCardCheckboxXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_assignAllCardCheckbox element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _assignAllCardCheckboxLabel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_assignAllCardCheckboxLabelXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_assignAllCardCheckboxLabel element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _unassignedCardsbtn
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_unassignedCardsbtnXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_unassignedCardsbtn element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _searchTerm
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_searchTermXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_searchTerm element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _searchValue
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_searchValueXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_searchValue element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _searchCriteriaAddBtn
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_searchCriteriaAddBtnXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_searchCriteriaAddBtn element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _newPassword
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_newPasswordXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_newPassword element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _confirmPassword
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_confirmPasswordXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_confirmPassword element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _errorMessage
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_errorMessageXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_errorMessage element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _roleSelect
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_roleSelectXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_roleSelect element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _ssn
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_ssnXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_ssn element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _confirmSSN
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_confirmSSNXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_confirmSSN element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _MiddleName
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_MiddleNameXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_MiddleName element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _userStatus
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_userStatusXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_userStatus element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _profileDropdown
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_profileDropdownXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_profileDropdown element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _searchCriteriaSearchTerm
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_searchCriteriaSearchTermXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_searchCriteriaSearchTerm element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _searchCriteriaTextSearchValue
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_searchCriteriaTextSearchValueXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_searchCriteriaTextSearchValue element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _assignBothCards
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_assignBothCardsXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_assignBothCards element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _assignBothCardsLabel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_assignBothCardsLabelXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_assignBothCardsLabel element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _manageProxy
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_manageProxyXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_manageProxy element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _ddlApprovers
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_ddlApproversXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_ddlApprovers element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _btnReset
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_btnResetXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_btnReset element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _hierarchyExplorer
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_hierarchyExplorerXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_hierarchyExplorer element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _btnEditPassword
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_btnEditPasswordXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_btnEditPassword element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _hierarchyLink
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(AccountNodeHierarchyExplorer), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_hierarchyLink element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _selectElement
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_roleSelectXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_selectElement element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        #endregion

        #region Navigation

        private void NavigateToMenuItem(IWebElement element)
        {
            Driver.Url = element.GetAttribute("href");
        }
        #endregion

        [FindsBy(How = How.XPath, Using = @"//input[@value='View Assigned Privileges']")]
        private IWebElement _linkViewAssignedPrivileges { get; set; }

        [FindsBy(How = How.XPath, Using = @"//button[@value='Close']")]
        private IWebElement _btnClose { get; set; }

        #region Expand Elements
        private const string AC_MAIN = "content_contents_acMain";
        private const string AP_CREDS_PRIVS = "apCredsAndPrivs";
        private const string AP_USER_INFO = "apUserInfo";
        private const string AP_PROXY = "proxyAssignment";
        #endregion

        public void LinkViewAssignedPrivileges()
        {
            _linkViewAssignedPrivileges.BootstrapClick();
            Driver.WaitFor(By.XPath("//div[@id='allPrivilegesBody']"));
            string isDisable = Driver.WaitFor(By.XPath("//input[contains(@id,'ChangeThatId')]")).GetAttribute("disabled");
            if (isDisable.Equals("true"))
                _btnClose.BootstrapClick();
            else
                throw new Exception("Error - the checkbox should be disabled");
        }

        public void HierarchyExplorer()
        {
            _hierarchyExplorer.JSClickWithFocus(Driver);
        }

        public PhoneControl MobilePhone
        {
            get
            {
                return _mobilePhone ?? (_mobilePhone = new PhoneControl("ipnMobilePhone", Driver));
            }
        }

		public void ExpandCredentialsPrivileges()
		{
            //Changed to the generic method
            ExpandCardHeader(AC_MAIN, AP_CREDS_PRIVS);
            Settings.EnCompassExtentTest.Info("Expanded Section: CredentialsPrivilege");
		}

        public void ExpandUserInformation()
		{
            //Changed to the generic method
            ExpandCardHeader(AC_MAIN, AP_USER_INFO);
            Settings.EnCompassExtentTest.Info("Expanded Section: UserInformation");
		}

        public void ExpandAssignCards()
		{
            //Changed to the generic method
            ExpandCardHeader(AC_MAIN, AP_PROXY);
            Settings.EnCompassExtentTest.Info("Expanded Section: AssignCards");
		}

        public string UserName
        {
            get
            {
                return _userName.GetAttribute("value");
            }
            set
            {
                _userName.ForceDocumentLoadOnSendKeys(value, Settings.EnCompassWebDriver);
				Settings.EnCompassExtentTest.Info("Username Set to :" + value);
			}
        }
        public string SSN
        {
            set
            {
                _ssn.ForceDocumentLoadOnSendKeys(value, Settings.EnCompassWebDriver);
				Settings.EnCompassExtentTest.Info("SSN Set to :" + value);
			}
        }
        public string ConfirmSSN
        {
            set
            {
                _confirmSSN.ForceDocumentLoadOnSendKeys(value, Settings.EnCompassWebDriver);
				Settings.EnCompassExtentTest.Info("ConfirmSSN Set to :" + value);
			}
        }
        public string PassWord
        {
            set
            {
                _password.ForceDocumentLoadOnSendKeys(value, Settings.EnCompassWebDriver);
				Settings.EnCompassExtentTest.Info("Password Set to :" + value);
			}
        }
        public string ConfirmPassWord
        {
            set
            {
                _passwordConfirm.ForceDocumentLoadOnSendKeys(value, Settings.EnCompassWebDriver);
				Settings.EnCompassExtentTest.Info("Confirm Pwd Set to :" + value);
			}
        }

        public string FirstName
        {
            get
            {
                return _firstName.Text;
            }
            set
            {
                _firstName.ForceDocumentLoadOnSendKeys(value, Settings.EnCompassWebDriver);
				Settings.EnCompassExtentTest.Info("FirstName Set to :" + value);
			}
        }
        public string MiddleName
        {
            set
            {
                _MiddleName.ForceDocumentLoadOnSendKeys(value, Settings.EnCompassWebDriver);
				Settings.EnCompassExtentTest.Info("MiddleName Set to :" + value);
			}
        }
        public string LastName
        {
            get
            {
                return _lastName.Text;
            }
            set
            {
                _lastName.ForceDocumentLoadOnSendKeys(value, Settings.EnCompassWebDriver);
				Settings.EnCompassExtentTest.Info("LastName Set to :" + value);
			}
        }

        public string SearchValue
        {
            set
            {
                _searchValue.ForceDocumentLoadOnSendKeys(value, Settings.EnCompassWebDriver);
				Settings.EnCompassExtentTest.Info("Search Value Set to :" + value);
			}
        }

        public void SearchCriteriaAddBtn()
        {
            _searchCriteriaAddBtn.JSClickWithFocus(Driver);
			Settings.EnCompassExtentTest.Info("Clicked on ADD button");
		}
		
		public string PrimaryPhone
		{
			get
			{
				return _primaryPhoneTxt.GetAttribute("value");
			}
			set
			{
                _primaryPhoneTxt.ForceDocumentLoadOnSendKeys(value, Settings.EnCompassWebDriver);
				Settings.EnCompassExtentTest.Info("Primary Phone Set to :" + value);
			}

		}

		public string MobilePhoneTxt
        {
            get
            {
				_mobilePhoneTxt.WaitUntilElementIsInteractable();
                return _mobilePhoneTxt.GetAttribute("value");
            }
            set
            {
                _mobilePhoneTxt.ForceDocumentLoadOnSendKeys(value, Settings.EnCompassWebDriver);
				Settings.EnCompassExtentTest.Info("Mobile Phone No Set to :" + value);
			}

        }

		/// <summary>
		/// TODO :  The Try Catch block is a temporary measure to make tests proceed even if it fails to set the value.
		/// This is mainly due to the immense disconnect between FI specific behavior in QA Vs UAT.
		/// This should be removed in future once the bugs associated are fixed
		/// </summary>
        public string VelocityLimitTxt
        {
            get
            {
                Driver.TryWaitForElementToBeVisible(By.XPath(_velocityLimitXpath), out IWebElement _velocityLimit);
                return _velocityLimit.GetAttribute("value");
            }
            set
            {
				try
				{
                    Driver.TryWaitForElementToBeVisible(By.XPath(_velocityLimitXpath), out IWebElement _velocityLimit);
                    _velocityLimit.ForceDocumentLoadOnSendKeys(value, Settings.EnCompassWebDriver);
					Settings.EnCompassExtentTest.Info("Velocity Limit Set to :" + value);
				}
				catch
				{
					Settings.EnCompassExtentTest.Warning("Attempt to set Velocity Limit failed!!");
                    this.AttachOnDemandScreenShot();
                }
			}

        }

		public bool VelocityLimitRequired()
		{
			return Driver.TryWaitForElementToBeVisible(By.XPath(_velocityLimitXpath), out IWebElement _velocityLimit);
        }

		public bool ApprovalLimitRequired()
		{            
            return Driver.TryWaitForElementToBeVisible(By.XPath(_approvalLimitXpath), out IWebElement _approvalLimit);
        }

		/// <summary>
		/// TODO :  The Try Catch block is a temporary measure to make tests proceed even if it fails to set the value.
		/// This is mainly due to the immense disconnect between FI specific behavior in QA Vs UAT.
		/// This should be removed in future once the bugs associated are fixed
		/// </summary>
		public string ApprovalLimitTxt
        {
            get
            {
                Driver.TryWaitForElementToBeVisible(By.XPath(_approvalLimitXpath), out IWebElement _approvalLimit);
                return _approvalLimit.GetAttribute("value");
            }

            set
            {
				try
				{
                    Driver.TryWaitForElementToBeVisible(By.XPath(_approvalLimitXpath), out IWebElement _approvalLimit);
                    _approvalLimit.ForceDocumentLoadOnSendKeys(value, Settings.EnCompassWebDriver);
					Settings.EnCompassExtentTest.Info("Approval Limit Set to :" + value);
				}
				catch
				{
					Settings.EnCompassExtentTest.Warning("Attempt to set Approval Limit failed!!");
                    this.AttachOnDemandScreenShot();
                }
			}
        }
		
		public string InstantApprovalLimitTxt
		{
			get
			{
                Driver.TryWaitForElementToBeVisible(By.XPath(_instantApprovalLimitXpath), out IWebElement _instantApprovalLimit);
				return _instantApprovalLimit.GetAttribute("value");
			}
			set
			{
                try
                {
                    Driver.TryWaitForElementToBeVisible(By.XPath(_instantApprovalLimitXpath), out IWebElement _instantApprovalLimit);
                    _instantApprovalLimit.ForceDocumentLoadOnSendKeys(value, Settings.EnCompassWebDriver);
					Settings.EnCompassExtentTest.Info("Instant Approval Limit Set to :" + value);
				}
                catch
                {
                    Settings.EnCompassExtentTest.Warning("Attempt to set Instant approval Limit failed!!");
                    this.AttachOnDemandScreenShot();
                }
			}

		}

		public string Email
        {
            get
            {
				_email.WaitUntilElementIsInteractable();
                return _email.GetAttribute("value");
            }
            set
            {
                _email.ForceDocumentLoadOnSendKeys(value, Settings.EnCompassWebDriver);
			}
        }

        //Accessing OrgHierarchy object which has the common functionality of Choosing the TOP Org as its Hierarchy Option.
        private OrgHierarchy _hierarchy;
        public OrgHierarchy Hierarchy
        {
            get
            {
                Driver.WaitFor(By.XPath(AccountNodeHierarchyExplorer));
                return _hierarchy ?? (_hierarchy = new OrgHierarchy(_hierarchyLink, Driver, Settings));
            }
        }

        private GridControl _cardsAssigned;
        public GridControl CardsAssigned
        {
            get
            {
                GridControl grid = _cardsAssigned ?? (_cardsAssigned = new GridControl("dgCardsAssigned", Driver));
                grid.WaitForGrid();
                return grid;
            }
        }

        private GridControl _cardsavailable;
        public GridControl Cardsavailable
        {
            get
            {
				_cardsavailable = _cardsavailable ?? (_cardsavailable = new GridControl("dgAccounts", Driver));
				_cardsavailable.WaitForGrid();
				return _cardsavailable;
			}
        }

		private string saveBtnXpath = "//input[contains(@id,'btnSave')]";

		public void Save()
        {
			bool flag = Driver.TryWaitForElementToBeVisible(By.XPath(saveBtnXpath), out IWebElement _save);
			if (flag)
			{
				_save.JSClickWithFocus(Driver);
				this.AttachOnDemandScreenShot();
				Settings.EnCompassExtentTest.Info("Clicked on Save Button");
			}
			else
			{
				Settings.EnCompassExtentTest.Info("Save button is not visible");
				throw new Exception("Save button is not visible");
			}
		}

        public void PressEditPassword()
        {
            _btnEditPassword.JSClickWithFocus(Driver);
            Settings.EnCompassWebDriver.WaitForVisible(By.XPath("//input[contains(@id,'txtPassword')]"));
            this.AttachOnDemandScreenShot();
        }

		public bool IsEditPasswordVisible()
		{
			return Driver.IsElementPresent(By.XPath(_btnEditPasswordXPath));
		}


		public void Cancel()
        {
            _cancel.JSClickWithFocus(Driver);
        }

        public void ResetSearchCriteria()
        {
            _btnReset.JSClickWithFocus(Driver);
			Settings.EnCompassExtentTest.Info("Reset of Search filter done");
		}
        public string CellPolicyToolTip => MobilePhone.CellPolicyToolTip;

        public string CellPolicyHeader => MobilePhone.CellPolicyHeader;

        public string CellPolicyBody => MobilePhone.CellPolicyBody;

        public bool IsCellPolicyVisible => MobilePhone.IsCellPolicyVisible;

        public void ShowCellPolicy()
        {
			Driver.WaitForDocumentLoadToComplete();
			MobilePhone.ShowCellPolicy();
			//Driver.WaitFor(By.XPath(@"//body[@class = 'iframe-modal']//div[@class = 'modal-body']"));
			WaitForModalLoadingOverlay();
		}

        public void HideCellPolicy()
        {
            MobilePhone.HideCellPolicy();
        }

        public bool NoCardsGridMessage()
        {

            try
            {
                var isDisplayed = _NoCardsGridMessage.Displayed;
                return isDisplayed || true;
            }
            catch { return false; }

        }

        public void SetSearchTermByValue(string whichText)
        {
            var selectElement = new SelectElement(_searchTerm);
            selectElement.SelectByText(whichText);
        }

        public void AssignCards()
        {
            ScrollToXPATH("//input[contains(@id,'btnDispCAPanel')]");
            Settings.EnCompassWebDriver.WaitForVisible(By.XPath("//input[contains(@id,'btnDispCAPanel')]")).JSClickWithFocus(Driver);
        }

        //Search and Assign two cards to the user
        public void SearchAndSelectCard(string searchTerm, string searchVal)
		{
			SearchCard(searchTerm, searchVal);
            AssignBothCardRow();
		}

		public void AssignBothCardRow()
		{
            Driver.WaitFor(By.XPath("//label[contains(@for,'CheckboxColumnBoxActual')]"));
            //Scroll to bottom is added because scroll to specific element getting failed in Firefox
            Driver.JsScrollToBottom();
            _assignBothCards.SetCheckboxStateWithLabel(_assignBothCardsLabel, true);
		}

		public void SearchCard(string searchTerm, string searchVal)
		{
			// You cannot do Reset search on this panel
			SetSearchCriteriaSearchTerm(searchTerm);
			RefreshModel();
			SearchCriteriaTextSearchValue = searchVal;
			SearchCriteriaAddBtn();
			SearchBtn();
			RefreshModel();
			this.AttachOnDemandScreenShot();
		}

		public string SearchCriteriaTextSearchValue
		{
			set
			{
				_searchCriteriaTextSearchValue.SendKeys(value);
				Settings.EnCompassExtentTest.Info("Search Criteria value to:" + value);
			}
		}

		public void SetSearchCriteriaSearchTerm(string whichText)
		{
            _searchCriteriaSearchTerm.JsScrollToElement(Driver);
            var selectElement = new SelectElement(_searchCriteriaSearchTerm);
			selectElement.SelectByText(whichText);
			Settings.EnCompassExtentTest.Info("Search Criteria SearchTerm set to:" + whichText);
		}

		public void SearchBtn()
        {
            Settings.EnCompassWebDriver.WaitForVisible(By.XPath("//input[contains(@id, 'btnSearch')]"));
            _searchBtn.JSClickWithFocus(Driver);
			Settings.EnCompassExtentTest.Info("CLicked on Search button");
		}

        public void AssignFirstCard()
        {
			_assignFirstCardChecbox.SetCheckboxStateWithLabel(null, true);
		}

        public void AssignAllCard()
        {
           
			_assignAllCardCheckbox.SetCheckboxStateWithLabel(_assignAllCardCheckboxLabel, true);
        }

        public void UnassignedCardsBtn()
        {
			_unassignedCardsbtn.WaitUntilElementIsInteractable();
			_unassignedCardsbtn.ClickCheckBox();
        }

        public string AssignedCardNumber
        {
            get
            {
                return CardsAssigned.GetColumnText("Card Number").First();
            }
        }

        public string CardNumberToBeAssigned
        {
            get
            {
                return Cardsavailable.GetColumnText("Card Number").First();
            }
        }

        public void PressSaveAndWaitForSuccessMsg()
        {
			try
            {
				Save();
				WaitForSuccessMsg();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
				Save();

			}
			finally { this.AttachOnDemandScreenShot(); }
        }

        public string NewPassword
        {
            set
            {
                _newPassword.ForceDocumentLoadOnSendKeys(value, Settings.EnCompassWebDriver);
				Settings.EnCompassExtentTest.Info("New Password Set to :" + value);
			}
        }

        public string ConfirmPassword
        {
            set
            {
                _confirmPassword.ForceDocumentLoadOnSendKeys(value, Settings.EnCompassWebDriver);
				Settings.EnCompassExtentTest.Info("Confirm Password Set to :" + value);
			}
        }

        public string ErrorMessage
        {
            get
            {
                return _errorMessage.Text;
            }
        }

        //This method validate all the policies for new password
        public void validatePasswordWithAllPoliciesSet(String newPassword)
        {
            ExtentTest test = Settings.EnCompassExtentTest;
            Logger.StartStepLog(Settings.Scenario.StepContext.StepInfo.Text);

            foreach (var element in PasswordPolicyHelper.GetPolicyDictionaryWithAllPoliciesSet())
            {
                String policyName = element.Key;
                bool policyValue = element.Value;

                if (policyValue == true)
                {
                    PressEditPassword();
                    test.Info("Clicked on Edit Password Button");
                    NewPassword = newPassword;
                    test.Info("New password entered On Change Credentials Page");
                    ConfirmPassword = newPassword;
                    test.Info("New confirm password entered On Change Credentials Page");
                    Save();
                    test.Info("Clicked on Save Button On Change Credentials Page");
                    PasswordPolicyHelper.ValidatePolicy(policyName, ErrorMessage);
                    test.Info("Password Policy validation done On Change Credentials Page!!");
                }
            }
        }

        //This method validate all the policies for new password with Lower Uppe rOff 
        public void validatePasswordWithLowerUpperOff(String newPassword)
        {
            ExtentTest test = Settings.EnCompassExtentTest;
            Logger.StartStepLog(Settings.Scenario.StepContext.StepInfo.Text);

            foreach (var element in PasswordPolicyHelper.GetPolicyDictionaryWithUpperLowerCaseOff())
            {
                String policyName = element.Key;
                bool policyValue = element.Value;

                if (policyValue == true)
                {
                    PressEditPassword();
                    test.Info("Clicked on Edit Password Button On Account Edit Page");
                    PassWord = newPassword;
                    test.Info("New password entered");
                    ConfirmPassWord = newPassword;
                    test.Info("New confirm password entered");
                    Save();
                    test.Info("Clicked on Save Button");
                    PasswordPolicyHelper.ValidatePolicy(policyName, ErrorMessage);
                    test.Info("Password Policy validation done!!");
                }
            }
        }

        public void WaitForSuccessMsg()
        {
            WebDriverWait wait = new WebDriverWait(Driver, TimeSpan.FromSeconds(20));
            wait.Until(ExpectedConditions.ElementIsVisible(By.XPath(@"//div[contains(@id,'SuccessMessage')]")));
        }

        public void SetExpiredPasswordNextLogin()
        {
            _expirePassword.SetCheckboxStateWithLabel(_expirePasswordLabel, true);
        }

        public void SetSystemgeneratedTempPass(bool status)
        {
            _generateRandomPassword.SetCheckboxStateWithLabelJS(Driver, status);
			Settings.EnCompassExtentTest.Info("generate Random Password set to " + status.ToString());
        }

		public bool IsSystemGeneratedPasswordEnabled()
		{
			return _generateRandomPassword.Selected;
		}

        public bool GetSystemgeneratedTempPass()
        {
            return _generateRandomPassword.Selected;
        }

		private string _ddlRoleXpath = "//select[contains(@name,'ddlRole')]";
		/// <summary>
		/// Sets user Role based on rolename and modify flag
		/// </summary>
		/// <param name="nameRole">rolename</param>
		/// <param name="modify">if True then ensure rolename is made unique. if False, use the input value</param>
		public void SetRole(string nameRole, bool modify = true)
        {
            bool _isRoleXpathPresent = Driver.TryWaitForElement(By.XPath(_ddlRoleXpath), out IWebElement _roleSelect);
            Settings.EnCompassExtentTest.Info("_roleXpathPresent found is " +_isRoleXpathPresent);
            SelectElement ddlRole = new SelectElement(_roleSelect);
			if (modify)
			{
				//The Organization Id is being concatenated in order to ensure the uniqueness of the role.
				string newRoleName = RoleHelper.Instance.GetNewRoleName(nameRole, Settings.Scenario["OrganizationID"].ToString());
				try
				{
					// Mobile specific change
					// If its running on a mobile device then use the JS injection else fall back to use Select class
					if (GlobalSettings.DeviceType.Equals(GlobalSettings.Device.MOBILE.ToString()))
					{
                        Settings.EnCompassExtentTest.Info("Need to use Javascript to select Role : " + newRoleName + " as this is mobile device.");
                        Driver.SelectDDLOptionByTextViaJS(Settings, _ddlRoleXpath, newRoleName);
						Settings.EnCompassExtentTest.Info("Used Javascript to select Role");
					}
					else
					    _roleSelect.SetListboxByText(newRoleName);

                    this.WaitForFormLoadingOverlay();
					Settings.EnCompassExtentTest.Info("Selected Role with name :" + newRoleName);
				}
				catch (Exception)
				{
					Settings.EnCompassExtentTest.Info("Failed to select the Role with name :" + newRoleName + " attempting to select :" + nameRole);
					ddlRole.SelectByText(nameRole);
					this.WaitForFormLoadingOverlay();
					Settings.EnCompassExtentTest.Info("Selected Role with name :" + nameRole);
				}
			}
			else
			{
				if (GlobalSettings.DeviceType.Equals(GlobalSettings.Device.MOBILE.ToString()))
					Driver.SelectDDLOptionByTextViaJS(Settings, _ddlRoleXpath, nameRole);
				else
					ddlRole.SelectByText(nameRole);
				this.WaitForFormLoadingOverlay();
				Settings.EnCompassExtentTest.Info("Selected Role with name :" + nameRole);
			}
		}

		public void SetRoleByName(string roleName)
		{
			var SelectElement = new SelectElement(_roleSelect);
			SelectElement.SelectByText(roleName);
		}

        public IEnumerable<IWebElement> GetRoles()
        {
            var selectElement = new SelectElement(_selectElement);
            return selectElement.Options;
        }

        public string GetSelectedRole()
        {
            var selectElement = new SelectElement(_selectElement);
            return selectElement.SelectedOption.Text;
        }

        public void UserStatus(string option)
        {
            var selectElement = new SelectElement(_userStatus);
            selectElement.SelectByText(option);
        }

        public void SelectProfile(string option)
        {
            var selectElement = new SelectElement(_profileDropdown);
            selectElement.SelectByText(option);
        }

        public string GetRoleValue()
        {
            return Settings.EnCompassWebDriver.WaitForVisible(By.XPath("//option[contains(@selected,'selected') and text()='default everything profile - "+ Settings.CeatedOrgId  +"']"), TimeSpan.FromSeconds(10)).GetAttribute("innerText");
        }
        public string GetHierarchyValue()
        {
            return Settings.EnCompassWebDriver.WaitForVisible(By.XPath("//input[contains(@id,'lblHierarchy')]"), TimeSpan.FromSeconds(10)).GetAttribute("value");
        }

        public string GetStatusValue()
        {
            return Settings.EnCompassWebDriver.WaitForVisible(By.XPath("//option[contains(@selected,'selected') and text()='Active']"), TimeSpan.FromSeconds(10)).GetAttribute("innerText");
        }

		public void CreateUserToAssignRole(string userName, string nameRole)
		{
            if (GetSystemgeneratedTempPass())
            {
                SetSystemgeneratedTempPass(false);
                Settings.EnCompassExtentTest.Info("Disable the option of Generate Temporary Password by Email");
            }
            PassWord = Settings.OrgLevelUserPwd = "1234_ATencompass";
			ConfirmPassWord = "1234_ATencompass";
            ExpandUserInformation();
            FirstName = "firstUser";
			LastName = "lastUser";
            Settings.Scenario["Username"] = "firstUser" + " " + "lastUser";
            Settings.Scenario["OrgUserEmail"] = Email = $"{Settings.Scenario["OrganizationID"].ToString()}@encompass.com";
			ExpandCredentialsPrivileges();
			SetRole(nameRole);
			Settings.EnCompassExtentTest.Info("User Role set to :" + nameRole);
            RefreshModel();
			if (nameRole.ToLowerInvariant().Equals(StringKeys.ROLE.manageroptionrole.ToString(),StringComparison.CurrentCultureIgnoreCase))
			{
				VelocityLimitTxt = "10";
				ApprovalLimitTxt = "10";
			}		
		}

		public void ManageProxy()
        {
            Settings.EnCompassWebDriver.WaitForVisible(By.XPath(_manageProxyXPath));
            _manageProxy.JSClickWithFocus(Driver);
        }

		public string GetApproverMessage()
		{
			Settings.EnCompassWebDriver.WaitForVisible(By.XPath("//div[contains(@id,'divDisableApproverPop')]"));
			return Settings.EnCompassWebDriver.FindElement(By.XPath("//div[contains(@id,'divDisableApproverPop')]//div[@class='modal-body']/p")).Text;
		}

		public void PressContinueApprover()
		{
			Settings.EnCompassWebDriver.FindElement(By.XPath("//input[contains(@id,'btnApproverContinue')]")).JSClickWithFocus(Driver);
		}

		public void PressTransferApprover()
		{
			Settings.EnCompassWebDriver.FindElement(By.XPath("//input[contains(@id,'btnApproverTransfer')]")).JSClickWithFocus(Driver);
		}

		public void SelectApprovers(int index)
		{
			var selectElement = new SelectElement(_ddlApprovers);
			selectElement.SelectByIndex(index);
		}

		public void PressContinueContentApprover()
		{
			Settings.EnCompassWebDriver.FindElement(By.XPath("//input[contains(@id,'btnApproverContentContinue')]")).JSClickWithFocus(Driver);
		}

        public void CardsAssignedSelectFirstRow()
        {
            CardsAssigned.SelectFirstRow();
        }

		public bool HasInstantApproval 
		{
			get
			{
                return Driver.TryWaitForElementToBeVisible(By.XPath(_instantApprovalLimitXpath), out IWebElement _instantApprovalLimit);				
			}
		}

		public bool InstantApprovalEnabled
		{
			get
			{
                Driver.TryWaitForElementToBeVisible(By.XPath(_instantApprovalLimitXpath), out IWebElement _instantApprovalLimit);
                return _instantApprovalLimit.Enabled;
			}
		}
		/// <summary>
		/// Verifies that Password, Confirm Password, and the Password Complexity Requirements are displaying
		/// </summary>
		public bool AllEditPasswordOptionsDisplayed()
		{

			var password = Driver.IsElementPresent(By.XPath(_passwordXPath));
			Settings.EnCompassExtentTest.Info("Password is visable:" + password);
			var passwordConfirm = Driver.IsElementPresent(By.XPath(_passwordConfirmXPath));
			Settings.EnCompassExtentTest.Info("Password Confirm is visable:" + passwordConfirm);
			var passwordComplexity = Driver.IsElementPresent(By.XPath(_passwordComplexityXPath));
			Settings.EnCompassExtentTest.Info("Password Complexity is visable:" + passwordComplexity);

			if (password && passwordConfirm && passwordConfirm)
			{
				return true;
			}

			else
			{
				return false;
			}
		}

		public AccountEdit(GlobalSettings Settings) : base(Settings) { }
	}
}