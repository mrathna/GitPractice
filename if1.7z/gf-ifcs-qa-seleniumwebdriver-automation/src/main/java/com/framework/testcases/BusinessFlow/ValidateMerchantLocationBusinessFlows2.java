package com.framework.testcases.BusinessFlow;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.AdminPage;
import com.framework.pages.AJS.MaintainCustomerPage;
import com.framework.pages.AJS.MerchantLocationPage;
import com.framework.pages.AJS.common.Common;
import com.framework.pages.AJS.common.IFCSHomePage;
import com.framework.pages.AJS.common.IFCSLoginPage;
import com.framework.pages.BusinessFlow.WFECommon;
import com.github.javafaker.Faker;

public class ValidateMerchantLocationBusinessFlows2 extends BaseTest {

	/**
	 * Implemented by Rathna
	 * 
	 * @param clientCountry
	 * @param clientName    Business Flow ID:BF-114
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow" })
	public void createMerchantAgreementForMultipleLocations(@Optional("BE") String clientCountry,
			@Optional("WFE") String clientName) {

		test = extent.createTest(clientName + ":" + clientCountry + " ID:BF-114 Merchant Maintenance",
				"Able to create agreement to merchant with multiple locations");
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		MerchantLocationPage merchantLocation = new MerchantLocationPage(driver, test);
		Common common = new Common(driver, test);
		IFCSloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, " ");

		for (int location = 1; location <= 2; location++) {
			IFCSHomePage.gotoMerchantAndClickMerchantDetails();
			String merchant = common.getMerchantNoFromDB();
			common.chooseMerchantNoAndSearch(merchant);
			merchantLocation.validateMaintainAgreementInMerchant(clientName, clientCountry);
		}

		IFCSHomePage.exitIFCS();
	}

	/**
	 * Implemented by Rathna
	 * 
	 * @param clientCountry
	 * @param clientName    Business Flow ID:BF-108
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow" })
	public void validateLocationGroup(@Optional("BE") String clientCountry, @Optional("WFE") String clientName) {

		test = extent.createTest(
				clientName + ":" + clientCountry + " ID:BF-108 Location Maintenance - Add Location Group",
				"Locations can be grouped from IFCS");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCShomePage = new IFCSHomePage(driver, test);
		MerchantLocationPage merchantLocationPage = new MerchantLocationPage(driver, test);

		IFCSloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		IFCShomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);
		IFCShomePage.gotoMerchantAndClickMerchantDetails();
		// merchantLocationPage.selectMaintainLocationGroup();
		merchantLocationPage.selectLocationGroupsAndGotoMaintainLocationGroup();
		merchantLocationPage.addLocationToNewLocationGroup(clientName + "_" + clientCountry,
				"IFCS_" + clientName + "_USERNAME");
		IFCShomePage.exitIFCS();
	}

	/**
	 * Implemented by Rathna
	 * 
	 * @param clientCountry
	 * @param clientName    Business Flow ID:109
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow" })
	public void validateUpdateExistingLocation(@Optional("BE") String clientCountry,
			@Optional("WFE") String clientName) {

		test = extent.createTest(clientName + ":" + clientCountry + " TC-1717 TC01_MercLoc_Update Locations_IFCS",
				"RQ-918 : Update existing location");
		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);

		Common common = new Common(driver, test);

		MerchantLocationPage merchantLocation = new MerchantLocationPage(driver, test);
		IFCSloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		IFCSHomePage.gotoApplicationAndClickApplicationMenu();
		IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);
		IFCSHomePage.gotoMerchantAndClickMerchantDetails();

		// Get Location Num from DB
		String locationNoFromDB = common.getLocationNoFromDB();

		// create location
		merchantLocation.chooseLocationNoFromListAndDoubleClick(locationNoFromDB);
		Faker fakerLocationNo = new Faker();
		String f_locationNo = fakerLocationNo.number().digits(6);
		System.out.println("f_locationNo" + f_locationNo);
		// merchantLocation.createNewLocation(f_locationNo);
		merchantLocation.updateLocation();
		IFCSHomePage.exitIFCS();

	}

	/**
	 * Added by Rathna
	 * 
	 * @param clientCountry
	 * @param clientName    Business Flow ID:BF-188
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "BusinessFlow" })
	public void createIFCSUserWithAssingedCustomer(@Optional("BE") String clientCountry,
			@Optional("WFE") String clientName) {

		test = extent.createTest(clientName + ":" + clientCountry + " ID:BF-188 createIFCSUserWithAssingedCustomer",
				"createIFCSUserWithAssingedCustomer");

		// creating object for the Pages
		IFCSLoginPage ifcsLoginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage ifcsHomePage = new IFCSHomePage(driver, test);

		AdminPage ifcsAdminPage = new AdminPage(driver, test);

		ifcsLoginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		ifcsLoginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		// ifcsHomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);
		ifcsHomePage.gotoAdminMenuAndChooseClientGroup();
		Faker fakerN = new Faker();
		String testName1 = fakerN.name().firstName() + "_" + fakerN.name().lastName() + fakerN.number().digits(2);
		String testPwd = "Password" + fakerN.number().digits(2);
		// Select Desktop user
		ifcsAdminPage.chooseDesktopMenuFromSecurityMenu();
		// Create
		ifcsAdminPage.validateAndCreateIFCSNewUsersEnterDetails(testName1, testPwd, clientName);
		ifcsAdminPage.validateAndEnterUserLimites();
		ifcsAdminPage.clickSaveButtonAndValidate();
		ifcsHomePage.exitIFCS();
		ifcsLoginPage.loginWithNewUser("IFCS_URL_" + clientName, testName1, testPwd);
		ifcsLoginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		ifcsHomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);
		ifcsHomePage.exitIFCS();
	}

	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow" })
	public void validateMaintainCustomerAddAndDeleteContacts(@Optional("BE") String clientCountry,
			@Optional("WFE") String clientName) {
		test = extent.createTest(
				clientName + ":" + clientCountry + " TC-702 TC05_CustMgmt_CustMaint_SecContInfo_Delete",
				"RQ-785: Delete Contact");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		MaintainCustomerPage maintainCustomerPage = new MaintainCustomerPage(driver, test);
		Common common = new Common(driver, test);
		IFCSloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, " ");
		// Add a Cost Centre
		IFCSHomePage.gotoApplicationAndClickApplicationMenu();
		IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);

		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		common.chooseCustomerNumberFromCustomerList();
		maintainCustomerPage.chooseSubMenuFromLeftPanel("Maintain Customer", "Contacts");
		if (maintainCustomerPage.getContactsCount() == 0)
			maintainCustomerPage.addcontact();
		maintainCustomerPage.deleteContact();
		IFCSHomePage.exitIFCS();
	}

	/**
	 * Implemented by Rathna
	 * 
	 * @param clientCountry
	 * @param clientName    Business Flow ID:BF-107
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow" })
	public void createMerchantAgreement(@Optional("BE") String clientCountry, @Optional("WFE") String clientName) {

		test = extent.createTest(clientName + ":" + clientCountry + " TC-1714 TC01_MercLoc_Agreement Creation_IFCS",
				"RQ-919:Create new merchant and location agreement");
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		MerchantLocationPage merchantLocation = new MerchantLocationPage(driver, test);
		Common common = new Common(driver, test);
		IFCSloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, " ");
		IFCSHomePage.gotoMerchantAndClickMerchantDetails();
		String merchant = common.getMerchantNoFromDB();
		common.chooseMerchantNoAndSearch(merchant);
		Faker fakerNumber = new Faker();
		String f_merchantNo = fakerNumber.number().digits(6);
		merchantLocation.createNewMerchant(f_merchantNo);
		merchantLocation.validateMaintainAgreementInMerchant(clientName, clientCountry);
		IFCSHomePage.exitIFCS();
	}



	/**
	 * Implemented by Rathna
	 * 
	 * @param clientCountry
	 * @param clientName    Business Flow ID:BF-115
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "BusinessFlow" })
	public void validateExistingPricingProfileUpdate(@Optional("BE") String clientCountry,
			@Optional("WFE") String clientName) {

		test = extent.createTest(clientName + ":" + clientCountry + " ID:BF-115 validateExistingPricingProfileUpdate",
				"validateExistingPricingProfileUpdate");
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		MerchantLocationPage merchantLocation = new MerchantLocationPage(driver, test);
		Common common = new Common(driver, test);
		IFCSloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, " ");
		IFCSHomePage.gotoMerchantAndClickMerchantDetails();
		String merchant = common.getMerchantNoFromDB();
		common.chooseMerchantNoAndSearch(merchant);
		merchantLocation.updateExistingMerchantPricingProfile(clientName, clientCountry);
		IFCSHomePage.exitIFCS();
	}

	/**
	 * Implemented by Venkata Davu
	 * 
	 * @param clientCountry
	 * @param clientName    Business Flow ID:BF-105
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow" })
	public void createAndValidateNewMerchant(@Optional("HK") String clientCountry,
			@Optional("CHEVRON") String clientName) {

		test = extent.createTest(clientName + ":" + clientCountry + " TC-1712 TC01_MercLoc_Create Merchant_IFCS",
				"A new Merchant is created from IFCS");
		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);

		Common common = new Common(driver, test);

		MerchantLocationPage merchantLocation = new MerchantLocationPage(driver, test);
		IFCSloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		IFCSHomePage.gotoApplicationAndClickApplicationMenu();
		IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);
		IFCSHomePage.gotoMerchantAndClickMerchantDetails();

		String merchant = common.getMerchantNoFromDB();

		// create Merchant
		common.chooseMerchantNoAndSearch(merchant);
		Faker fakerMerchantNo = new Faker();
		String f_merchantNo = fakerMerchantNo.number().digits(6);
		System.out.println("f_merchantNo" + f_merchantNo);
		merchantLocation.createNewMerchant(f_merchantNo);
		IFCSHomePage.exitIFCS();

	}

	/**
	 * Implemented by Venkata Davu
	 * 
	 * @param clientCountry
	 * @param clientName    Business Flow ID:BF-106
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow" })
	public void createAndValidateNewLocation(@Optional("BE") String clientCountry, @Optional("WFE") String clientName) {

		test = extent.createTest(clientName + ":" + clientCountry + " TC-1713 TC01_MercLoc_Create Locations_IFCS ",
				"A new Location is created from IFCS");
		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);

		Common common = new Common(driver, test);

		MerchantLocationPage merchantLocation = new MerchantLocationPage(driver, test);
		IFCSloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		IFCSHomePage.gotoApplicationAndClickApplicationMenu();
		IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);
		IFCSHomePage.gotoMerchantAndClickMerchantDetails();

		// Get Location Num from DB
		String locationNoFromDB = common.getLocationNoFromDB();

		// create location
		merchantLocation.chooseLocationNoFromListAndDoubleClick(locationNoFromDB);
		Faker fakerLocationNo = new Faker();
		String f_locationNo = fakerLocationNo.number().digits(6);
		System.out.println("f_locationNo" + f_locationNo);
		merchantLocation.createNewLocation(f_locationNo);
		IFCSHomePage.exitIFCS();

	}

	/**
	 * Implemented by Karuppsamy
	 * 
	 * @param clientCountry
	 * @param clientName    RQ-916
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "Regression" })
	public void updateAndValidateMerchant(@Optional("HK") String clientCountry,
			@Optional("CHEVRON") String clientName) {

		test = extent.createTest(clientName + ":" + clientCountry + " TC-1716 TC01_MercLoc_Update Merchants_IFCS ",
				"RQ-916 Merchant details are updated in IFCS");
		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);

		Common common = new Common(driver, test);

		MerchantLocationPage merchantLocation = new MerchantLocationPage(driver, test);
		IFCSloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		IFCSHomePage.gotoApplicationAndClickApplicationMenu();
		IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);
		IFCSHomePage.gotoMerchantAndClickMerchantDetails();

		// Get Merchant Num and Location Num from DB
		String merchant = common.getMerchantNoFromDB();

		// create Merchant
		common.chooseMerchantNoAndSearch(merchant);

		merchantLocation.updateMerchant();
		IFCSHomePage.exitIFCS();
	}

	/**
	 * Implemented by Rathna Updated by raxsana 09/10/2020
	 * 
	 * @param clientCountry
	 * @param clientName    Business Flow ID:BF-117
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "BusinessFlow" })
	public void updateExistingActiveMerchantAndLocationAgreement(@Optional("BE") String clientCountry,
			@Optional("WFE") String clientName) {

		test = extent.createTest(clientName + ":" + clientCountry + " TC-1718 TC01_MercLoc_Agreement Updation_IFCS",
				"EQ:920 - Update existing active merchant and location agreementt");
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		MerchantLocationPage merchantLocation = new MerchantLocationPage(driver, test);
		Common common = new Common(driver, test);
		IFCSloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, " ");
		IFCSHomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);
		IFCSHomePage.gotoMerchantAndClickMerchantDetails();
		//String merchantNo = common.getLocationNoFromDB();
		String locationNo=common.getLocationNoWithMerchantAgreementFromIFCSDB();
		String merchantNum = locationNo;
		merchantLocation.updateAgreement(clientName, clientCountry, merchantNum);// newly added this method//need to add
																					// pricing also

		IFCSHomePage.exitIFCS();
	}



	/**
	 * Implemented by Raxsana Babu
	 * 
	 * @param clientCountry
	 * @param clientName    RQ-921
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "BusinessFlow" })
	public void validateActiveMerchantLocationAgreementExpiryAndCreateWithFutureDate(
			@Optional("BE") String clientCountry, @Optional("WFE") String clientName) {

		test = extent.createTest(
				clientName + ":" + clientCountry
						+ " TC-1719 TC01_MercLoc_Expire Agreement_Add new Merchant Location Agreement_IFCS",
				"RQ-921 Expiry the active merchant location agreement and changing the new agreement with furture date");
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		MerchantLocationPage merchantLocation = new MerchantLocationPage(driver, test);
		WFECommon wfeCommon=new WFECommon(driver,test);
		Common common = new Common(driver, test);
		IFCSloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, " ");
		IFCSHomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);
		IFCSHomePage.gotoMerchantAndClickMerchantDetails();

		String merchantNo=wfeCommon.getMerchantNoWithLocationHierarchy(clientName, clientCountry);
		common.chooseMerchantNoAndSearch(merchantNo);
		merchantLocation.expiryAgreementFromMerchant(clientName, clientCountry, merchantNo);

		IFCSHomePage.exitIFCS();
	}
	
	
	
	
	
}
