package com.framework.pages.OLS;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.aventstack.extentreports.ExtentTest;
import com.framework.basepage.BasePage;
import com.framework.repo.Locator;
import com.framework.util.PropUtils;

public class HomePage extends BasePage {

	@FindBy(how = How.XPATH, using = Locator.CLIENT_WELCOME_TEXT)
	public WebElement WelcomeText;

	@FindBy(how = How.XPATH, using = Locator.BP_WELCOME_TEXT)
	public WebElement BP_WelcomeText;

	@FindBy(how = How.XPATH, using = Locator.CLIENT_LOGO_IMG)
	public WebElement ClientLogo;

	@FindBy(how = How.XPATH, using = Locator.BP_LOGO_IMG)
	public WebElement BPLogo;

	@FindBy(how = How.XPATH, using = Locator.HOME_MENU)
	public WebElement HomeMenu;

	@FindBy(how = How.ID, using = Locator.ACCOUNTS_MENU)
	public WebElement Accounts;

	@FindBy(how = How.ID, using = Locator.CARDS_MENU)
	public WebElement Cards;

	@FindBy(how = How.ID, using = Locator.TRANSACTIONS_MENU)
	public WebElement Transactions;

	@FindBy(how = How.ID, using = Locator.REPORTS_MENU)
	public WebElement Reports;

	@FindBy(how = How.ID, using = Locator.SUPPORT_MENU)
	public WebElement Support;

	@FindBy(how = How.ID, using = Locator.ADMIN_MENU)
	public WebElement Admin;

	@FindBy(how = How.XPATH, using = Locator.HELP_REF)
	public WebElement help;

	@FindBy(how = How.ID, using = Locator.LOGOUT)
	public WebElement logoff;

	@FindBy(how = How.ID, using = Locator.STATUS_MENU)
	public WebElement Status;

	@FindBy(how = How.ID, using = Locator.ACCOUNT_MAINTENANCE_MENU)
	public WebElement AccountMaintenance;

	@FindBy(how = How.XPATH, using = Locator.CONTACTS_MENU)
	public WebElement Contacts;

	@FindBy(how = How.ID, using = Locator.DRIVERS_MENU)
	public WebElement Drivers;

	@FindBy(how = How.ID, using = Locator.VEHICLES_MENU)
	public WebElement Vehicles;

	@FindBy(how = How.ID, using = Locator.COST_CENTERS_MENU)
	public WebElement CostCenters;

	@FindBy(how = How.ID, using = Locator.QUICK_LINKS)
	public WebElement QuickLinks;

	@FindBy(how = How.XPATH, using = Locator.CUSTOMER_NAME_COMBO)
	public WebElement CustomerNameCombo;

	@FindBy(how = How.XPATH, using = Locator.CUSTOMER_NAME_LABEL)
	public WebElement CustomerNameLabel;

	@FindBy(how = How.XPATH, using = Locator.EXXON_LOGO_IMG)
	public WebElement ExxonMobilLogo;

	@FindBy(how = How.XPATH, using = Locator.FLEETMANAGER_MENU)
	public WebElement FleetManager;

	@FindBy(how = How.XPATH, using = Locator.RESOURCETOOLS_MENU)
	public WebElement ResourceTools;

	@FindBy(how = How.XPATH, using = Locator.ADMINISTRATION_MENU)
	public WebElement Administration;
	
	@FindBy(id=Locator.HELP_SHELL)
	public WebElement helpShell;
	
	@FindBy(xpath = Locator.SHELL_CHANGE_PASSWORD)
	public WebElement adminChangePassword;

	@FindBy(xpath = Locator.CHANGE_NEW_PASSWORD)
	public WebElement adminChangeNewPassword;

	@FindBy(xpath = Locator.CHANGE_CONFIRM_PASSWORD)
	public WebElement adminChangeConfirmPassword;
	
	@FindBy(id = Locator.CARD_INFORMATION_SAVECHANGES)
	public WebElement saveBtn;
	@FindBy(how = How.XPATH, using = Locator.PAGE_TITLE1)
	public WebElement pageTitle;
	
	@FindBy(how = How.ID, using = Locator.AGREE_AND_CONTINUE)
	public WebElement agreeToTermsAndCondition;
	
	@FindBy(how = How.ID, using = Locator.SHELL_ACCOUNT_DROPDOWN)
	public WebElement accountDropDown;
	
	@FindBy(how = How.ID, using = Locator.ACCOUNTS_DROPDOWN)
	public WebElement accountsDropDown;
	
	
	
	@FindBy(how = How.ID, using = Locator.PASSWORD_FIELD)
	public WebElement passwordField;
	
	@FindBy(how = How.ID, using = Locator.NEW_PASSWORD)
	public WebElement newPasswordField;
	
	@FindBy(how = How.ID, using = Locator.CONFIRM_PASSWORD)
	public WebElement confirmPasswordField;
	
	@FindBy(how = How.ID, using = Locator.CARD_INFORMATION_SAVECHANGES)
	public WebElement saveButton;
	
	@FindBy(how = How.ID, using = Locator.CONFIRMATIONMESSAGE)
	public WebElement successMsg;
	
	@FindBy(how = How.XPATH, using = Locator.PAGETITLE)
	public WebElement pageHeaderText;
	
	

	public HomePage(WebDriver driver, ExtentTest test) {
		super(driver, test);
		PageFactory.initElements(driver, this);
	}

	public void ValidateLogo() throws Exception {

		if (PropUtils.getPropValue(configProp, "Client_Name").equals("BP")) {
			ClientLogo = BPLogo;
		}
		isDisplayed(ClientLogo, "Client Logo");

	}

	public void ValidateWelcomeText(String clientName) {

		if (clientName.equals("BP")) {
			WelcomeText = BP_WelcomeText;
			isDisplayed(WelcomeText, "Welcome Text");
			verifyText(WelcomeText, "Welcome, Geetha Goli");
		}
		/**
		 *Updating the SHELL
		 * 
		 */
		
		else if(clientName.contains("SHELL"))
		{
			
			//String clientNameValue = clientName.split("#")[0];
			String cardType = clientName.split("#")[1];
			
			WelcomeText = BP_WelcomeText;
			isDisplayed(WelcomeText, "Welcome Text");
			if(cardType.equals("PC"))
			{
				verifyText(WelcomeText, "Welcome to Shell Partner Card Online");
			}
			else if(cardType.equals("APA"))
			{
				verifyText(WelcomeText, "Welcome to Shell Pre-Paid Online");
			}
		}
		
		// verifyText(WelcomeText, "Welcome to StarCard Online");
		/*String temp = getText(WelcomeText).trim();
		System.out.println("Welcome Text : '" + temp + "'");*/
		/*
		 * if (temp.contains("Welcome to StarCard Online")) {
		 * logPass("Welcome text is Displayed correctly as " + temp); } else {
		 * logFail("Welcome text is Displayed incorrectly as " + temp); }
		 */

	}

	public void ValidateLogoutLink() {
		isDisplayed(logoff, "Logout");
	}

	public void ValidateQuickLinks() {
		isDisplayed(QuickLinks, "Quick Links");
	}

	public void ValidateHelpLink() {
		isDisplayed(help, "Help Link Shell");
	}

	public void ValidateAccountsMenu() {
		isDisplayed(Accounts, "Menu Item Accounts");

		mouseHover(Accounts);

		isDisplayed(Status, "Sub Menu Item Status");
		isDisplayed(AccountMaintenance, "Sub Menu Item AccountMaintenance");
		isDisplayed(Contacts, "Sub Menu Item Contacts");
		isDisplayed(Drivers, "Sub Menu Item Drivers");
		isDisplayed(Vehicles, "Sub Menu Item Vehicles");
		isDisplayed(CostCenters, "Sub Menu Item CostCenters");
	}

	/*
	 * public void ValidateLogoutLink() throws Exception {
	 * //PageFactory.initElements(driver, this);
	 * 
	 * }
	 */
	public void HomePageValidation() {
		isDisplayed(HomeMenu, "Menu Item Home");
		isDisplayed(Transactions, "Menu Item Transactions");
		isDisplayed(Reports, "Menu Item Reports");
		isDisplayed(Support, "Menu Item Support");
	}

	public void ValidateCardsMenu() {
		isDisplayed(Cards, "Menu Item Cards");
	}

	public void ValidateAdminMenu() throws Exception {
		isDisplayed(Admin, "Menu Item Admin");
	}

	public void ValidateCustomerName() throws Exception {

		Select drpCustName = new Select(CustomerNameCombo);
		if (CustomerNameCombo.isDisplayed()) {
			logPass("Customer Name Combo is Displayed");
			System.out.println("Customer Name from Select *** : " + drpCustName.getFirstSelectedOption());
		} else {
			logFail("Customer Name Combo is Not Displayed");
		}
		System.out.println("Customer Name: " + CustomerNameCombo.getText());
	}

	public void ValidateCustomerNameLabel() throws Exception {

		if (CustomerNameLabel.isDisplayed()) {
			System.out.println("Customer Name Label : " + CustomerNameLabel.getText());
			logPass("Customer Name Label is Displayed" + CustomerNameLabel.getText());
			String lblCust = getText(CustomerNameLabel);
			PropUtils.setProps(configProp, "AccountName", lblCust.substring(0, lblCust.indexOf(" (")));
			System.out.println("Customer Name : " + PropUtils.getPropValue(configProp, "AccountName"));
			logInfo("Customer Name : " + PropUtils.getPropValue(configProp, "AccountName"));
			PropUtils.setProps(configProp, "AccountNumber",
					lblCust.substring(lblCust.indexOf(" (") + 2, lblCust.indexOf(")")));
			System.out.println("Account Number : " + PropUtils.getPropValue(configProp, "AccountNumber"));
			logInfo("Account Number : " + PropUtils.getPropValue(configProp, "AccountNumber"));
		} else {
			logFail("Customer Name Label is Not Displayed");
		}

	}
	
	public void ValidateHelpShellLink() {
		isDisplayed(helpShell, "Help Link Shell");
	}
	
	
	public void changePassword(String password, String newPassword) {

		System.out.println("change pwd 1");
		isDisplayedThenEnterText(adminChangePassword, "Enter Existing Password", password);
		System.out.println("change pwd 2");
		isDisplayedThenEnterText(adminChangeNewPassword, "Enter New Password", newPassword);
		isDisplayedThenEnterText(adminChangeConfirmPassword, "Enter Confirm Password", newPassword);
		isDisplayedThenActionClick(saveBtn, "click save Btn");
		sleep(3);

	}
	
public void validateAgreeAndLogonUser(String merchantNo) {
		
		if (pageTitle.getText().contains("Terms and Conditions")) {
			agreeToTermsAndCondition.click();
		}
		
		String dropDownValue = selectedStringFrmDropDown(accountDropDown);
		System.out.println("********::"+dropDownValue+"**********************"+merchantNo);
		if(dropDownValue.contains(merchantNo)) {
			logPass("Successfully login with the valid newly created user"+merchantNo+dropDownValue);
		}else {
			logFail("Login with differnt user");
		}
	}


public void validatePasswordMaintenancePage(String oldPassword, String newPassword, String confirmPassword) {
	verifyTitle("Password maintenance");
	isDisplayedThenEnterText(passwordField, "Password Field", oldPassword);
	isDisplayedThenEnterText(newPasswordField, "New Password Field", newPassword);
	isDisplayedThenEnterText(confirmPasswordField, "Confirm Password Field", confirmPassword);
	isDisplayedThenActionClick(saveButton, "Save Button");
	sleep(2);
	verifyText(successMsg, "success Msg");		
	
}
public void validateOlsLogonUser(String merchantNo) {
	
	
	String dropDownValue = selectedStringFrmDropDown(accountDropDown);
	System.out.println("********::"+dropDownValue+"**********************"+merchantNo);
	if(dropDownValue.contains(merchantNo)) {
		logPass("Successfully login with the valid newly created user"+merchantNo+dropDownValue);
	}else {
		logFail("Login with differnt user");
	}
}

}
