using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using Common;
using Common.PageObjects;
using Common.ScenarioConfigurations;
using Common.Utility;

namespace EnCompass.Testing.Source.PageObjects.SuperAdmin.Branding 
{
	/// <summary>
	/// Auto-generated Page Model Class
	/// Navigation Paths: 
		/// [Organization Home]->General->Branding
		/// </summary>
	[PageModel(@"/superAdmin/Branding/ViewBrands.aspx")]
	public partial class ViewBrands : EnCompassSuperPageModel 
	{
		public override string RelativeUrl => @"/superAdmin/Branding/ViewBrands.aspx";
		public override string PageIdentifierXPath_Generated => @"//li[contains(@class, 'breadcrumb-item active')][text() = 'Branding']";

		#region Navigation
		
		private void NavigateToMenuItem(IWebElement element)
		{
			Driver.Url = element.GetAttribute("href");
		}
		#endregion

		public ViewBrands(GlobalSettings settings) : base(settings) { }
	}  
}
