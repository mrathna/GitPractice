/**
 * 
 */
package com.framework.testcases.BusinessFlow;

import java.util.HashMap;
import java.util.Map;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.CardMaintenancePage;
import com.framework.pages.AJS.MaintainCustomerPage;
import com.framework.pages.AJS.OrderCardPage;
import com.framework.pages.AJS.common.Common;
import com.framework.pages.AJS.common.IFCSHomePage;
import com.framework.pages.AJS.common.IFCSLoginPage;
import com.framework.pages.AJS.common.InterfacePage;
import com.framework.pages.AJS.common.SalesForceLoginPage;
import com.framework.pages.API.common.CardAPIMethods;
import com.framework.pages.BusinessFlow.SalesForceCommon;
import com.framework.util.PropUtils;
import com.github.javafaker.Faker;


import com.framework.pages.AJS.ChangeCardStatus;
import com.framework.pages.AJS.TransactionListPage;
import com.framework.pages.AJS.common.IFCSCommonPage;
public class ValidateSalesForceBusinessFlows extends BaseTest {


	
	/**
	 * Added by Nithya
	 * 
	 * @param clientCountry
	 * @param clientName    Business Flow ID:BF-078
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow" })
	public void orderCardWithCostCenterAndVerifyInSalesForce(@Optional("BE") String clientCountry,
			@Optional("WFE") String clientName) {
		test = extent.createTest(
				clientName + ":" + clientCountry + "ID:BF-078 Order cards with cost centre and synced to SF");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCShomePage = new IFCSHomePage(driver, test);
		Common common = new Common(driver, test);

		IFCSloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, " ");
		OrderCardPage orderCardpage = new OrderCardPage(driver, test);
		IFCShomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);
		String clientNameInProp = PropUtils.getPropValue(configProp, clientName + "_" + clientCountry);
		String customerNumber = common.getCustomerNoHasTransaction(clientNameInProp);
		IFCShomePage.gotoCustomerMenuCustomerDetails();
		common.chooseCustomerNoAndSearch(customerNumber);
		String orderedCardNumber = orderCardpage.orderNewCardWithMonthlyFeeWFE();
		common.updatePropFile("Card_Number_CostCenter" + clientName + "_" + clientCountry, orderedCardNumber,
				"SalesForceValidation.properties");
		IFCSloginPage.logPass("Newly ordered card:: :: " + orderedCardNumber);
		IFCShomePage.exitIFCS();

	}

	/**
	 * Added by Nithya
	 * 
	 * @param clientCountry
	 * @param clientName    Business Flow ID:BF-071
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow" })
	public void orderCardInIFCSAndVerifyInSalesForce(@Optional("BE") String clientCountry,
			@Optional("WFE") String clientName) {
		test = extent.createTest(clientName + ":" + clientCountry + "ID:BF-071 Order cards and synced to SF");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCShomePage = new IFCSHomePage(driver, test);
		Common common = new Common(driver, test);

		IFCSloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, " ");
		OrderCardPage orderCardpage = new OrderCardPage(driver, test);
		IFCShomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);
		String clientNameInProp = PropUtils.getPropValue(configProp, clientName + "_" + clientCountry);
		String customerNumber = common.getCustomerNoHasTransaction(clientNameInProp);
		IFCShomePage.gotoCustomerMenuCustomerDetails();
		common.chooseCustomerNoAndSearch(customerNumber);
		String orderedCardNumber = orderCardpage.orderNewCardWithMonthlyFeeWFE();
		common.updatePropFile("Card_Number_" + clientName + "_" + clientCountry, orderedCardNumber,
				"SalesForceValidation.properties");
		IFCSloginPage.logPass("Newly ordered card:: :: " + orderedCardNumber);
		IFCShomePage.exitIFCS();

	}

	/**
	 * Added by Nithya
	 * 
	 * @param clientCountry
	 * @param clientName    Business Flow ID:BF-050
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow" })
	public void updateExistingContactTypesInIFCS(@Optional("BE") String clientCountry,
			@Optional("WFE") String clientName) {
		test = extent.createTest(clientName + ":" + clientCountry
				+ "ID:BF-050 Update existing contact types in IFCS and changes synced to SF");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCShomePage = new IFCSHomePage(driver, test);
		Common common = new Common(driver, test);
		MaintainCustomerPage maintainCustomerPage = new MaintainCustomerPage(driver, test);
		IFCSloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, " ");
		IFCShomePage.gotoApplicationAndClickApplicationMenu();
		IFCShomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);

		String customerNo = common.getCustomerWithContactType(clientName + "_" + clientCountry);

		System.out.println("Customer number from DB" + customerNo);

		IFCShomePage.gotoCustomerMenuCustomerDetails();
		common.chooseCustomerNoAndSearch(customerNo);
		String Name = maintainCustomerPage.updateContact();
		common.updatePropFile("Updated_Contact_" + clientName + "_" + clientCountry, Name + ":" + customerNo,
				"SalesForceValidation.properties");
		IFCSloginPage.logPass("Updated Contact:: :: " + Name + ":" + customerNo);
		IFCShomePage.exitIFCS();

	}

	/**
	 * Added by Nithya
	 * 
	 * @param clientCountry
	 * @param clientName    Business Flow ID:BF-071
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow" })
	public void verifyInSalesForceForOrderedCard(@Optional("BE") String clientCountry,
			@Optional("WFE") String clientName) {
		test = extent.createTest(clientName + ":" + clientCountry
				+ "ID:BF-071 Card ordered in IFCS should be synced to SF - Verification");

		SalesForceLoginPage salesForce = new SalesForceLoginPage(driver, test);
		SalesForceCommon salesForceCommon = new SalesForceCommon(driver, test);
		salesForce.login("SALESFORCE_URL", "SALESFORCE_USERNAME", "SALESFORCE_PASSWORD");
		salesForceCommon.searchAndVerifyCardPresence("Card_Number_" + clientName + "_" + clientCountry);
		salesForceCommon.logOutSalesForce();

	}

	/**
	 * Added by Nithya
	 * 
	 * @param clientCountry
	 * @param clientName    Business Flow ID:BF-078
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow" })
	public void verifyInSalesForceForOrderedCardWithCostCenter(@Optional("BE") String clientCountry,
			@Optional("WFE") String clientName) {
		test = extent.createTest(clientName + ":" + clientCountry
				+ "ID:BF-078 Card ordered in IFCS with cost center should be synced to SF - Verification");

		SalesForceLoginPage salesForce = new SalesForceLoginPage(driver, test);
		SalesForceCommon salesForceCommon = new SalesForceCommon(driver, test);
		salesForce.login("SALESFORCE_URL", "SALESFORCE_USERNAME", "SALESFORCE_PASSWORD");
		salesForceCommon.searchAndVerifyCardPresence("Card_Number_CostCenter" + clientName + "_" + clientCountry);
		salesForceCommon.logOutSalesForce();

	}

	/**
	 * Added by Nithya
	 * 
	 * @param clientCountry
	 * @param clientName    Business Flow ID:BF-050
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow" })
	public void verifyInSalesForceForUpdatedContacts(@Optional("BE") String clientCountry,
			@Optional("WFE") String clientName) {
		test = extent.createTest(clientName + ":" + clientCountry
				+ "ID:BF-050 Update existing contact types in IFCS and changes synced to SF - Verification");

		SalesForceLoginPage salesForce = new SalesForceLoginPage(driver, test);
		SalesForceCommon salesForceCommon = new SalesForceCommon(driver, test);
		salesForce.login("SALESFORCE_URL", "SALESFORCE_USERNAME", "SALESFORCE_PASSWORD");
		// salesForceCommon.searchAndVerifyUpdatedContact("Updated_Contact_" +
		// clientName + "_" + clientCountry);
		salesForceCommon.searchAndVerifyUpdatedContact("Updated_Contact_" + clientName + "_" + clientCountry);
		salesForceCommon.logOutSalesForce();

	}

	/**
	 * Added by Raxsana Babu
	 * 
	 * @param clientCountry
	 * @param clientName    RQ-788
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "BusinessFlow" })
	public void updateExistingCardWithCostCentre(@Optional("BE") String clientCountry,
			@Optional("WFE") String clientName) {

		test = extent.createTest(
				clientName + ":" + clientCountry + " TC-795 TC03_CustMgmt_CostCentre_ExtCard_Department_Upd",
				"RQ-788 Update the cost centre details and synced to SF");
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		MaintainCustomerPage maintainCustomerPage = new MaintainCustomerPage(driver, test);
		CardMaintenancePage cardMaintenancePage = new CardMaintenancePage(driver, test);
		Common common = new Common(driver, test);

		IFCSloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");

		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");

		// getting Card No from DB/
		String cardNo = common.getCardNumberhavingNoCostCentreFromDB();
		String costCenterCode = Faker.instance().number().digits(4);
		if (cardNo.equals(" ")) {
			common.logForNoDataFound(this.getClass().getSimpleName(),
					"Need to Create A Customer with Card Type and rerun");
		} else {

			IFCSHomePage.gotoCustomerMenuCustomerDetails();
			cardMaintenancePage.chooseAndSearchCardNo(cardNo);
			maintainCustomerPage.chooseCostCentre();

			maintainCustomerPage.addCostCentreAndValidate(costCenterCode);
		}

		cardMaintenancePage.chooseAndSearchCardNo(cardNo);

		cardMaintenancePage.updateCostCentreForCard(costCenterCode);

		IFCSHomePage.exitIFCS();

	}

	/**
	 * Implemented by Raxsana
	 * 
	 * @param clientCountry
	 * @param clientName    RQ-781
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow" })
	public void validateMaintainCustomerToCreateContacts(@Optional("NL") String clientCountry,
			@Optional("WFE") String clientName) {
		test = extent.createTest(
				clientName + ":" + clientCountry + " TC-699 TC01_CustMgmt_CustMaint_PrimaryContactInfo_Add",
				"RQ-781 Add Contact in Customer Maintainance and synced to SF");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		MaintainCustomerPage maintainCustomerPage = new MaintainCustomerPage(driver, test);
		Common common = new Common(driver, test);
		IFCSloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, " ");

		IFCSHomePage.gotoApplicationAndClickApplicationMenu();
		IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);

		String customerNo = common.getCustomerWithOutContactType(clientName + "_" + clientCountry);

		System.out.println("Customer number from DB" + customerNo);

		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		common.chooseCustomerNoAndSearch(customerNo);
		maintainCustomerPage.ValidateAddContacts();
		String contactName = maintainCustomerPage.addContactType("Cards Address");
		System.out.println("Contact name" + contactName);
		IFCSHomePage.exitIFCS();

		// validation need to add in separate method
		/*SalesForceLoginPage sfLoginPage = new SalesForceLoginPage(driver, test);
		SalesForceCommon sfCommon = new SalesForceCommon(driver, test);
		sfLoginPage.login("SF_URL_" + clientName, "SF_" + clientName + "_USERNAME", "SF_" + clientName + "_PASSWORD");
		sfCommon.searchAccountInSalesForce(customerNo);
		sfCommon.validateAccountContacts(customerNo, contactName);
		sfCommon.logOutSalesForce();*/
	}

	/**
	 * Implemented by Davu
	 * 
	 * 
	 */

	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow" })
	public void validateManualAccountTempBlock(@Optional("BE") String clientCountry,
			@Optional("WFE") String clientName) {
		test = extent.createTest(clientName + ":" + clientCountry + "  Manual account lock",
				"Change the Active Account to Temp Lock");
		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCShomePage = new IFCSHomePage(driver, test);
		Common common = new Common(driver, test);
		ChangeCardStatus changeCardStatus = new ChangeCardStatus(driver, test);
		IFCSCommonPage ifcsCommonPage = new IFCSCommonPage(driver, test);
		InterfacePage interfacePage = new InterfacePage(driver, test);
		// Calling Functions

		IFCSloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, " ");
		String customerNumber = common.getActiveOrTemporaryBlockCustomerNoHavingCardsAndRowIndex(1, "Active");
		IFCShomePage.gotoCustomerMenuCustomerDetails();
		common.chooseCustomerNoAndSearch(customerNumber);
		IFCShomePage.gotoAccountAndClickAccountDetails();

		// Change CustomerAccount Status
		changeCardStatus.changeCustomerAccountStatus("Temp Blocked");

		Map<String, String> mapData = new HashMap<String, String>();
		mapData.put("Customer_Number" + "_" + clientCountry, customerNumber);
		mapData.put("IFCS_Account_Status" + "_" + clientCountry, "Temp Blocked");
		System.out
				.println("Created Customer Stored in Properties : " + customerNumber + "-->MerchantNumber.properties");
		PropUtils.creatingTempPropFile("SalesForceSync.properties", mapData);
	}

	/**
	 * Implemented by Davu
	 * 
	 * 
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow" })
	public void validateAccountStatusInSalesForce(@Optional("BE") String clientCountry,
			@Optional("WFE") String clientName) {
		test = extent.createTest(clientName + ":" + clientCountry + "  Manual account lock",
				"Change the Active Account to Temp Lock");

		IFCSLoginPage ifcsloginPage = new IFCSLoginPage(driver, test);
		SalesForceLoginPage salesforceloginPage = new SalesForceLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		TransactionListPage transactionListPage = new TransactionListPage(driver, test);
		SalesForceCommon salesforcecommon = new SalesForceCommon(driver, test);
		Common common = new Common(driver, test);
		ifcsloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");

		String customerNo = PropUtils.getPropValue(salesForceSyncConfigProp, "Customer_Number" + "_" + clientCountry);
		String IFCSAccountStatus = PropUtils.getPropValue(salesForceSyncConfigProp,
				"IFCS_Account_Status" + "_" + clientCountry);

		System.out.println("Sttaus " + customerNo + "and" + IFCSAccountStatus);

		salesforceloginPage.login("SALESFORCE_URL_" + clientName, "SALESFORCE_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");

		salesforcecommon.GlobalSearchInSalesForce(customerNo);

		salesforcecommon.validateSalesForceAccountStatus(customerNo, IFCSAccountStatus);

	}

	/**
	 * Implemented by Davu
	 * 
	 * 
	 */

	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "Regression" })
	public void ValidateChangecardStatus(@Optional("BE") String clientCountry, @Optional("WFE") String clientName) {

		test = extent.createTest(clientName + ":" + clientCountry + "  Change Card status", "Change card Status");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		ChangeCardStatus changeCardStatus = new ChangeCardStatus(driver, test);
		CardMaintenancePage cardMaintenancePage = new CardMaintenancePage(driver, test);

		IFCSloginPage.login("IFCS_URL_WFE", "IFCS_WFE_USERNAME", "IFCS_WFE_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		// Click search cards
		IFCSHomePage.gotoSearchAndClickCards();
		Common common = new Common(driver, test);
		String cardNo = common.getActiveCardNumberFromDBWFE(clientName, clientCountry);
		if (cardNo.equals(" ")) {
			common.logForNoDataFound(this.getClass().getSimpleName(),
					"Need to Create A Customer with No Balance or with Balance and rerun");
		} else {

			IFCSHomePage.gotoCustomerMenuCustomerDetails();
			cardMaintenancePage.chooseAndSearchCardNo(cardNo);
			changeCardStatus.changeCardStatusAndClickNoAndValidate("Card Stolen");

			Map<String, String> mapData = new HashMap<String, String>();
			mapData.put("Card_Number" + "_" + clientCountry, cardNo);
			mapData.put("IFCS_Card_Status" + "_" + clientCountry, "Temp Blocked");
			System.out.println("Created Customer Stored in Properties : " + cardNo + "-->MerchantNumber.properties");
			PropUtils.creatingTempPropFile("SalesForceSync.properties", mapData);
		}
		IFCSHomePage.exitIFCS();

	}

	/**
	 * Implemented by Davu
	 * 
	 * 
	 */

	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow" })
	public void validateCardStatusInSalesForce(@Optional("BE") String clientCountry,
			@Optional("WFE") String clientName) {
		test = extent.createTest(clientName + ":" + clientCountry + "  Validate the card status in Sales force",
				"Validate the card status in Sales force");

		IFCSLoginPage ifcsloginPage = new IFCSLoginPage(driver, test);
		SalesForceLoginPage salesforceloginPage = new SalesForceLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		TransactionListPage transactionListPage = new TransactionListPage(driver, test);
		SalesForceCommon salesforcecommon = new SalesForceCommon(driver, test);
		Common common = new Common(driver, test);
		ifcsloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");

		String cardNo = PropUtils.getPropValue(salesForceSyncConfigProp, "Card_Number" + "_" + clientCountry);
		String IFCSCardStatus = PropUtils.getPropValue(salesForceSyncConfigProp,
				"IFCS_Card_Status" + "_" + clientCountry);

		salesforceloginPage.login("SALESFORCE_URL_" + clientName, "SALESFORCE_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");

		salesforcecommon.GlobalSearchInSalesForce(cardNo);
		
		salesforcecommon.validateSalesForceCardStatus(cardNo,IFCSCardStatus);
		
		
		
	}


	/**
	 * Added by Nithya
	 * 
	 * @param clientCountry
	 * @param clientName    Business Flow ID:RQ-764
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow" })
	public void verifyInSalesForceForNewCustomer(@Optional("BE") String clientCountry,
			@Optional("WFE") String clientName) {
		test = extent.createTest(
				clientName + ":" + clientCountry + "ID:TC02_CustMgmt_CustOnbd_App_Approved validation in Sales Force");

		SalesForceLoginPage salesForce = new SalesForceLoginPage(driver, test);
		SalesForceCommon salesForceCommon = new SalesForceCommon(driver, test);
		salesForce.login("SALESFORCE_URL", "SALESFORCE_USERNAME", "SALESFORCE_PASSWORD");
		salesForceCommon.searchAndVerifyCustomerPresence("Customer_Number_" + clientName + "_" + clientCountry);
		salesForceCommon.logOutSalesForce();
		
	}


}
