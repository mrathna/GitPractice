﻿using Common;
using Common.Utility;
using EnCompass.Testing.Source.PageObjects.Controls;
using NFluent;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EnCompass.Testing.Source.PageObjects.Organization.ExpenseManager.PurchaseLog
{
    public partial class PlogManage
    {
        public override string PageIdentifierXPath_Override => @"//h1[normalize-space(text()) = 'Purchase Logs' or text() = 'Buyers Logs' or text() = 'Manage Purchase Logs' or text() = 'Manage OTO Pay Logs' or text() = 'Manage Buyers Logs' or text()='ActivePay Purchase Logs' or text() = 'OTO Pay Logs']";

        private const string _cardInfoInformationIframe = @"//iframe[contains(@src,'CardInfo')]";

        #region XPATH

        private const string _searchTermXPath = ".//select[contains(@id, 'searchTermSelect')]";
        private const string _filterTypeListXPath = ".//select[contains(@id, 'searchTermFilter')]";
        private const string _filterValueLowerLimitTextXPath = ".//input[contains(@id, 'SearchOutput_txtLower')]";
        private const string _filterValueHigherLimitTextXPath = ".//input[contains(@id, 'SearchOutput_txtUpper')]";
        private const string _filterValueTextXPath = ".//input[contains(@id, 'SearchOutput_txt')][not(contains(@style, 'display: none'))]";
        private const string _addBtnXPath = ".//input[@type='button'][@value='Add']";
        private const string _resetBtnXPath = ".//button[@type='button'][text()='Clear']";
        private const string _searchBtnXPath = ".//input[@type='submit'][contains(@id, 'btnSearch')]";
        private const string _updateBtnXPath = ".//input[@type='submit'][contains(@id, 'UpdateButton')]";
        private const string _orgListXPath = ".//select[contains(@id, 'ddlOrgList')]";

        #endregion

        #region IWebElements Props

        private IWebElement _searchTerm
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_searchTermXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_searchTerm element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _filterTypeList
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_filterTypeListXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_filterTypeList element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _filterValueLowerLimitText
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_filterValueLowerLimitTextXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_filterValueLowerLimitText element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _filterValueHigherLimitText
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_filterValueHigherLimitTextXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_filterValueHigherLimitText element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _filterValueText
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_filterValueTextXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_filterValueText element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _addBtn
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_addBtnXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_addBtn element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _resetBtn
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_resetBtnXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_resetBtn element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _searchBtn
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_searchBtnXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_searchBtn element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _updateBtn
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_updateBtnXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_updateBtn element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        // This element is shown only when you are in am Organization Group.
        private IWebElement _orgList
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_orgListXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_orgList element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        #endregion


        public string SetSearchTerm
		{
			get { return new SelectElement(_searchTerm).SelectedOption.Text; }
			set { new SelectElement(_searchTerm).SelectByText(value); }
		}

        public IEnumerable<string> SearchTermsCollection => new SelectElement(_searchTerm).Options.Select(n => n.Text);

		public string SetFilterType
		{
			get { return new SelectElement(_filterTypeList).SelectedOption.Text; }
			set { new SelectElement(_filterTypeList).SelectByText(value); }
		}

        public string SetOrgList
        {
            get { return new SelectElement(_orgList).SelectedOption.Text; }
            set { new SelectElement(_orgList).SelectByText(value); }
        }

        public string SetFilterValueLowerLimit
		{
			set { _filterValueLowerLimitText.Clear(); _filterValueLowerLimitText.SendKeys(value); }
		}

		public string SetFilterValueHigherLimit
		{
			set { _filterValueHigherLimitText.Clear(); _filterValueHigherLimitText.SendKeys(value); }
		}

        public string SetFilterValueTEXT
        {
            set
            {
                _filterValueText.WaitUntilElementIsInteractable();
                _filterValueText.Clear();
                _filterValueText.SendKeys(value);
            }

        }

		public void Add()
		{
			_addBtn.JSClickWithFocus(Driver);
		}

		public void Reset()
		{
			_resetBtn.JSClickWithFocus(Driver);
		}

		public void Search()
		{
			_searchBtn.JSClickWithFocus(Driver);
		}

		public void Update()
		{
			_updateBtn.JSClickWithFocus(Driver);
		}

        private GridControl _plogGrid;
        public GridControl PLogsGrid
        {
            get
            {
                GridControl grid = _plogGrid ?? (_plogGrid = new GridControl("PlogGrid", Driver));
                grid.WaitForGrid();
                return grid;
            }
        }

        public bool NoPLogsFoundMessagePresent
        {
            get
            {
                if (Driver.TryFindElement(By.XPath(@"//*[text()='No matching records were found.']"), out IWebElement element) || Driver.TryFindElement(By.XPath(@"//*[text()='No Purchase Logs found.']"), out IWebElement element1))
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }

        public void SelectRowContainingAmmount(string ammount)
        {
            PLogsGrid.WaitForGrid();
            PLogsGrid.GetRowContaining(ammount).JSClickWithFocus(Driver);
        }

        public void SelectActionByText(string action)
        {
            PLogsGrid.PerformActionByText(action);
        }

        public void SetPlogStatus(string amount, string status)
        {
            var row = PLogsGrid.GetRowContaining(amount);
            var DDLStatus = row.FindElement(By.XPath("./td[3]/div/select"));
            DDLStatus.JsScrollToElement(Driver);
            new SelectElement(DDLStatus).SelectByText(status);
        }

        public CardInfoIframe GetCardInfoIframe
        {
            get
            {
                using (FrameHelper helper = new FrameHelper(Settings.EnCompassWebDriver, By.XPath(_cardInfoInformationIframe)))
                {
                    return new CardInfoIframe(helper, Settings);
                }
            }
        }
    }

    public class CardInfoIframe : PlogManage
    {
        FrameHelper _helper;
        public const string _cardNumber = "//span[contains(@id,'CardNumber')]";
        public const string _continueButton = "//input[contains(@id,'ContinueButton')]";

        public void GetandCompareCardNumber()
        {
            var cardShown = _helper.FindElement(By.XPath(_cardNumber)).Text;
            Settings.EnCompassExtentTest.Info($"Check That: Card number on the modal: {cardShown}. Plog card number: {Settings.Scenario["PlogCardNumber"].ToString()}.");
            Check.That(cardShown).Equals(Settings.Scenario["PlogCardNumber"].ToString());
        }

        public void WaitCardInfoNumberToAppear()
        {
            Settings.EnCompassExtentTest.Info("Wait for Card Info to appear.");
            _helper.FindElement(By.XPath(_cardNumber));
            Settings.EnCompassWebDriver.WaitForVisible(By.XPath(_cardNumber));
            Settings.EnCompassExtentTest.Info("Card Info appeared.");
        }

        public void WaitCardInfoNumberToDisappear()
        {
            Settings.EnCompassExtentTest.Info("Wait for Card Info to disappear.");
            _helper.FindElement(By.XPath(_cardNumber));
            Settings.EnCompassWebDriver.WaitForAbsence(By.XPath(_cardNumber));
            Settings.EnCompassExtentTest.Info("Card Info disappeared.");
        }

        public void Continue()
        {
            _helper.FindElement(By.XPath(_continueButton)).JSClickWithFocus(Driver);
        }

        public CardInfoIframe(FrameHelper helper, GlobalSettings Settings) : base(Settings)
		{ _helper = helper; }
    }

}
