package com.framework.testcases.OLS.CHEV.Customer.ReadWrite;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.CHEV.CHBulkCardOrderPage;
import com.framework.pages.CHEV.CHBulkCardUpdatePage;
import com.framework.pages.CHEV.CHCardListPage;
import com.framework.pages.CHEV.CHChangeCardReplacePage;
import com.framework.pages.CHEV.CHChangeCardStatusPage;
import com.framework.pages.CHEV.CHHomePage;
import com.framework.pages.CHEV.CHOrderCardPage;
import com.framework.pages.CHEV.CHViewCardPage;
import com.framework.pages.OLS.common.LoginPage;

public class ValidateOLSMenuItems extends BaseTest {
	@Parameters({ "clientCountry", "clientName" })
	@Test
	public void testCustomerReadWriteOLSMenuItems(@Optional("PH") String clientCountry, @Optional("CHV") String clientName) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  OLS - Verify menu items and log out", "Chevron Customer Screens Read/Write");

		LoginPage loginPage = new LoginPage(driver, test);
		if (clientCountry.equals("SG")||clientCountry.equals("MY")||clientCountry.equals("HK")) {
			loginPage.Login("CHV_URL", "CHV_Customer_UN_RW_ONLY_"+clientCountry, "CHV_Customer_PWD_RW_ONLY_"+clientCountry, "CHV");
		} else if (clientCountry.equals("TH")) {
			loginPage.Login("CHV_URL", "CHV_Customer_UN_"+clientCountry, "CHV_Customer_PWD_"+clientCountry, "CHV");
		} else if (clientCountry.equals("PH")) {
			loginPage.Login("CHV_URL", "CHV_Customer_UN_"+clientCountry, "CHV_Customer_PWD_"+clientCountry, "CHV");
		}
		CHHomePage chHomePage = new CHHomePage(driver, test);
		CHOrderCardPage chOrderCardPage = new CHOrderCardPage(driver, test);
		CHCardListPage chCardListPage = new CHCardListPage(driver, test);
		CHViewCardPage chViewCardPage = new CHViewCardPage(driver, test);
		CHChangeCardStatusPage chCardStatusPage = new CHChangeCardStatusPage(driver, test);
		CHChangeCardReplacePage chCardReplacePage = new CHChangeCardReplacePage(driver, test);
		CHBulkCardOrderPage chBulkCardOrderPage = new CHBulkCardOrderPage(driver, test);
		CHBulkCardUpdatePage chBulkCardUpdatePage = new CHBulkCardUpdatePage(driver, test);

		chHomePage.loadFindAndClickOnOrderCard();
		chOrderCardPage.verifyOrderCardSubSections();

		chHomePage.loadFindAndUpdateCardPage();
		chCardListPage.verifySearchButton();
		chCardListPage.verifyExportButton();
		chCardListPage.verifyCardlistSearchtableHeaders();
		chCardListPage.verifyPageSubTitles();
		
		
		String cardNumber = chCardListPage.getActiveCardNumber();
		if(!cardNumber.equals("")) {
		chCardListPage.enterCardNumber(cardNumber);
		chCardListPage.clickSearchCard();

		chCardListPage.validateCardNumber(cardNumber);
		chCardListPage.clickFirstCardNumberFromCardsList();
		chCardListPage.verifyContextMenu();
		chCardListPage.pickCardDetailsOption();

		chViewCardPage.verifyCardPageTitle();
		chViewCardPage.verifySubTitles();
		chViewCardPage.verifyReadOnlyMode();

		chViewCardPage.navigateBacktoCardList();
		chCardListPage.clickFirstCardNumberFromCardsList();
		chCardListPage.pickChangeStatusContextMenu();
		chCardStatusPage.verifyChangeCardStatusPage();

		// TODO The card number that I am using is a card with no pin required. Change
		// the card number in settings file once test data is given
		// chCardStatusPage.navigateBacktoCardList();
		// chCardListPage.clickFirstCardNumberFromCardsList();
		// chCardListPage.pickPinReIssueOption();

		chCardStatusPage.navigateBacktoCardList();
		chCardListPage.clickFirstCardNumberFromCardsList();
		chCardListPage.pickReplaceCardOption();

		chCardReplacePage.verifyReplaceCardStatusPage();
		chCardReplacePage.navigateBacktoCardList();
		

		chHomePage.loadFindAndBulkOrderPage();
		chBulkCardOrderPage.verifyDownloadButton();
		chBulkCardOrderPage.verifyUploadButton();

		chHomePage.loadFindAndBulkUpdatePage();
		chBulkCardUpdatePage.verifyBulkUpdatePageTitle();
		chBulkCardUpdatePage.verifyDownloadButton();
		chBulkCardUpdatePage.verifyExportButton();
		chBulkCardUpdatePage.verifyExportButton();

		chHomePage.clickOnHome();
		}
		else {
			chBulkCardUpdatePage.logInfo("No Cards Found");
		}

		loginPage.Logout();

	}
}
