using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using Common;
using Common.PageObjects;
using Common.ScenarioConfigurations;
using Common.Utility;

namespace EnCompass.Testing.Source.PageObjects.Organization.SecurityManager.UserAccount 
{
	/// <summary>
	/// Auto-generated Page Model Class
	/// Navigation Paths: 
		/// [Organization Home]->UserAccount->
		/// [Organization Home]->UserAccount->->Contact Information
		/// </summary>
	[PageModel(@"/securityManager/userAccount/userAccountUpdate.aspx")]
	public partial class UserAccountUpdate : EnCompassOrgPageModel 
	{
		public override string RelativeUrl => @"/securityManager/userAccount/userAccountUpdate.aspx";
		public override string PageIdentifierXPath_Generated => @"//li[contains(@class, 'breadcrumb-item active')][text() = 'Contact Information']";

		#region Navigation
				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Contact Information']")]
		private IWebElement _useraccount__ContactInformation { get; set; }
		public void NavigateTo_Useraccount__ContactInformation()
		{
			NavigateToMenuItem(_useraccount__ContactInformation);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Login Credentials']")]
		private IWebElement _useraccount__LoginCredentials { get; set; }
		public void NavigateTo_Useraccount__LoginCredentials()
		{
			NavigateToMenuItem(_useraccount__LoginCredentials);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Challenge Questions']")]
		private IWebElement _useraccount__ChallengeQuestions { get; set; }
		public void NavigateTo_Useraccount__ChallengeQuestions()
		{
			NavigateToMenuItem(_useraccount__ChallengeQuestions);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Preferences']")]
		private IWebElement _useraccount__Preferences { get; set; }
		public void NavigateTo_Useraccount__Preferences()
		{
			NavigateToMenuItem(_useraccount__Preferences);
		}

		
		private void NavigateToMenuItem(IWebElement element)
		{
			Driver.Url = element.GetAttribute("href");
		}
		#endregion

		public UserAccountUpdate(GlobalSettings settings) : base(settings) { }
	}  
}
