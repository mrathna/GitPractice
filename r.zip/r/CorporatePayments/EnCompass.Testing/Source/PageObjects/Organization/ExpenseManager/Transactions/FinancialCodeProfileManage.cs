﻿using Common.Utility;
using EnCompass.Testing.Source.PageObjects.Controls;
using NFluent;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Support.UI;
using System.Collections.Generic;

namespace EnCompass.Testing.Source.PageObjects.Organization.ExpenseManager.Transactions
{
    public partial class FinancialCodeProfileManage
    {
        #region XPath page Elements

        private const string _addNewCodeProfileXPath = @"//a[contains(@role,'button')][contains(@href,'FinancialCodeProfileEdit')]";
        private const string _searchCriteriaTextSearchValueXPath = @"//input[contains(@id,'txtProfileName')]";
        private const string _searchXPath = @"//input[contains(@id,'btnSearch')]";
        private const string _massAssignActionXPath = @"//select[contains(@id,'ddlMassAssignAction')]";
        private const string _massAssignGroupsXPath = @"//select[contains(@id,'ddlMassAssignGroups')]";
        private const string _massAssignGoXPath = @"//input[contains(@id,'btnMassAssignGo')]";
        private const string _buttonConfirmXPath = @"//button[text()='Confirm']";
        private const string _buttonDeleteConfirmXPath = @"//button[text()='Delete']";
        private const string _buttonDeleteCancelXPath = @"//button[text()='Cancel']";
        private const string _financialCodeProfileNotFoundXPath = @"//td[contains(@class,'NoRecordsMessage')]";
        private const string _massAssignmentsXPath = "//a[contains(@href, '#massAssignments')]";
        private const string _profileXPath = "//h1[contains(text(),'Profile')]";
        private const string _divMessageXPath = "//div[contains(@id,'divMessage')]";
        #endregion

        #region Page Elements

        private IWebElement _addNewCodeProfile
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_addNewCodeProfileXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_addNewCodeProfile element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _searchCriteriaTextSearchValue
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_searchCriteriaTextSearchValueXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_searchCriteriaTextSearchValue element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _search
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_searchXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_search element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _massAssignAction
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_massAssignActionXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_massAssignAction element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _massAssignGroups
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_massAssignGroupsXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_massAssignGroups element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _massAssignGo
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_massAssignGoXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_massAssignGo element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _buttonConfirm
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_buttonConfirmXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_buttonConfirm element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _buttonDeleteConfirm
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_buttonDeleteConfirmXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_buttonDeleteConfirm element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _buttonDeleteCancel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_buttonDeleteCancelXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_buttonDeleteCancel element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _financialCodeProfileNotFound
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_financialCodeProfileNotFoundXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_financialCodeProfileNotFound element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        #endregion

        public string SearchCriteriaTextSearchValue
        {
            set
            {
                _searchCriteriaTextSearchValue.Clear();
                _searchCriteriaTextSearchValue.SendKeys(value);
            }
        }

        public void AddNewCodeProfile()
        {
            _addNewCodeProfile.JSClickWithFocus(Driver);
        }

        public void PressMassAssignGo()
        {
			_massAssignGo.JSClickWithFocus(Driver);
			Settings.EnCompassExtentTest.Info("Clicked on Mass Assigment GO button");
            _buttonConfirm.JSClickWithFocus(Driver);
			Settings.EnCompassExtentTest.Info("Clicked on Mass Assigment Confirm button");
			this.AttachOnDemandScreenShot();
		}

        public void Search()
        {
            _search.JSClickWithFocus(Driver);
        }

        public void ClickMassAssignment()
        {
            Driver.ScrollToXPATH(_massAssignmentsXPath);
			Driver.TryWaitForElementToBeVisible(By.XPath(_massAssignmentsXPath), out IWebElement _clickMassAssignment);
			_clickMassAssignment.JSClickWithFocus(Driver);
			Settings.EnCompassExtentTest.Info("Clicked on Mass Assigment Button");
			Driver.WaitForVisible(By.XPath(_profileXPath));
			this.AttachOnDemandScreenShot();
        }

        public void SearchAndEditCodeProfile(string searchVal)
        {
            SearchCodeProfile(searchVal);
            FinancialCodeProfileListGrid.SelectFirstRow();
            FinancialCodeProfileListGrid.PerformActionByText("Edit");
            Driver.WaitForVisible(By.XPath(_profileXPath));
        }

        public void SearchAndDeleteCodeProfile(string searchVal)
        {
            SearchCodeProfile(searchVal);
            FinancialCodeProfileListGrid.SelectFirstRow();
            FinancialCodeProfileListGrid.PerformActionByText("Delete");
            _buttonDeleteConfirm.WaitUntilElementIsInteractable();
            _buttonDeleteConfirm.JSClickWithFocus(Driver);
            _financialCodeProfileNotFound.WaitUntilElementIsInteractable();
            Check.That(GetNoFinancialCodeProfilesFound).IsNotNull().Equals("No Financial Code Profiles found.");
        }

        public void SearchAndAbortDeleteCodeProfile(string searchVal)
        {
            SearchCodeProfile(searchVal);
            FinancialCodeProfileListGrid.SelectFirstRow();
            FinancialCodeProfileListGrid.PerformActionByText("Delete");
            _buttonDeleteCancel.WaitUntilElementIsInteractable();
            _buttonDeleteCancel.JSClickWithFocus(Driver);
            IWebElement log = FinancialCodeProfileListGrid.GetRowContaining(searchVal);
            log.WaitUntilElementIsInteractable();
            Check.That(log.Text.Contains(searchVal)).IsTrue();

        }

        public void SearchCodeProfile(string searchVal)
        {
            SearchCriteriaTextSearchValue = searchVal;
            Search();
            WaitForFormLoadingOverlay();
            RefreshModel();
			Settings.EnCompassExtentTest.Info("Searched for Fin Code Profile: " + searchVal);
        }

        private GridControl _mGrid;
        public GridControl FinancialCodeProfileListGrid
        {
            get
            {
                _mGrid = _mGrid ?? new GridControl("dgProfiles", Driver);
                _mGrid.WaitForGrid();
                return _mGrid;
            }
        }

        public void VerifyValuesGridFinancialCodeProfiles(List<string> financialCodeProfilesList)
        {
            for (int i = 0; i < financialCodeProfilesList.Count(); i++)
            {
                IWebElement firstRow = FinancialCodeProfileListGrid.GetRow(i);
                Check.That((firstRow.Text).Contains(financialCodeProfilesList.ToString()));
            }
        }

        public void SetMassAssignAction(string whichText)
        {
            var selectElement = new SelectElement(_massAssignAction);
            selectElement.SelectByText(whichText);
        }

        public void SetMassAssignGroups(string whichText)
        {
            var selectElement = new SelectElement(_massAssignGroups);
            selectElement.SelectByText(whichText);
        }

        public string GetNoFinancialCodeProfilesFound
        {
            get { return _financialCodeProfileNotFound.Text; }
        }


		public void WaitForSuccessMsg()
		{
			Driver.WaitForVisible(By.XPath(_divMessageXPath));
		}
	}
}
