package com.framework.pages.CHEV;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.ExtentTest;
import com.framework.basepage.BasePage;
import com.framework.repo.Locator;

public class CHTransactionSummaryPage extends BasePage {

	@FindBy(how = How.XPATH, using = Locator.CH_TRANS_DETAILS_TITLE)
	public WebElement transactionPageTitle;

	public CHTransactionSummaryPage(WebDriver driver, ExtentTest test) {
		super(driver, test);
		PageFactory.initElements(driver, this);
	}

	public void verifyPageTitle() {
		sleep(10);
		if (transactionPageTitle.isDisplayed()) {
			logPass("Transaction Details is displayed");
		} else {
			logFail("Transaction Details is not displayed");
		}
	}
}