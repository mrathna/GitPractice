package com.framework.testcases.AJS.SHELL;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.MerchantLocationPage;
import com.framework.pages.AJS.common.IFCSHomePage;
import com.framework.pages.AJS.common.IFCSLoginPage;

public class ValidateMaintainLocation extends BaseTest {
	
	/**
	 * Updated by Davu - 27/04/2020
	 *
	 */
	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test( groups = { "Regression" })
	public void validateMaintainLocationAddANewGroup(@Optional("RU") String clientCountry,
			@Optional("SHELL") String clientName, @Optional("APA") String cardType) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  Maintain Location", "Add a new group");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);

		MerchantLocationPage merchantLocationPage = new MerchantLocationPage(driver, test);

		IFCSloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");

		IFCSHomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);

		IFCSHomePage.gotoMerchantAndClickMerchantDetails();

		//merchantLocationPage.selectMaintainLocationGroup();
		
		merchantLocationPage.selectLocationGroupsAndGotoMaintainLocationGroup();

		merchantLocationPage.addLocationToNewLocationGroup(clientName + "_" + clientCountry, "IFCS_SHELL_USERNAME");
		
		IFCSHomePage.exitIFCS();

	}
}
