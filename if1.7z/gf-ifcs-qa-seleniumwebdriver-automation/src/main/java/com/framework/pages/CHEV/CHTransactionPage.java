package com.framework.pages.CHEV;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.monte.media.ParseException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.ExtentTest;
import com.framework.basepage.BasePage;
import com.framework.repo.Locator;
import com.framework.util.PropUtils;

public class CHTransactionPage extends BasePage {

	@FindBy(how = How.XPATH, using = Locator.SCHEDULE_REPORT_MAINTENANCE_PAGE)
	public WebElement transactionPageTitle;

	@FindBy(how = How.ID, using = Locator.CARD_NUMBER)
	public WebElement cardNumber;

	@FindBy(how = How.ID, using = Locator.CARD_NO_IN_TRANSACTION_FILTER)
	public WebElement cardNumberTrans;
	
	@FindBy(how = How.ID, using = Locator.REPORTS_SEARCH)
	public WebElement searchBtn;

	@FindBy(how = How.ID, using = Locator.EXPORT_BATCHES)
	public WebElement exportBtn;

	@FindBy(how = How.ID, using = Locator.CH_TRANSACTION_TABLE_CARD_NUMBER_COLUMN)
	public WebElement transactionTableCardNumber;

	@FindBy(how = How.ID, using = Locator.CH_TRANSACTION_TABLE_ACCOUNT_NUMBER_COLUMN)
	public WebElement transactionTableAccountNumber;

	@FindBy(how = How.ID, using = Locator.CH_TRANSACTION_TABLE_REFERENCE_NUMBER_COLUMN)
	public WebElement transactionTableReferenceNumber;

	@FindBy(how = How.ID, using = Locator.CH_TRANSACTION_TABLE_LOCATION_COLUMN)
	public WebElement transactionTableLocation;

	@FindBy(how = How.ID, using = Locator.CH_TRANSACTION_TABLE_PRODUCT_COLUMN)
	public WebElement transactionTableProduct;

	@FindBy(how = How.ID, using = Locator.CH_TRANSACTION_TABLE_DATE_TIME_COLUMN)
	public WebElement transactionTableDateTime;

	@FindBy(how = How.ID, using = Locator.CH_TRANSACTION_TABLE_ODOMETER_COLUMN)
	public WebElement transactionTableOdometer;

	@FindBy(how = How.ID, using = Locator.CH_TRANSACTION_TABLE_CUST_AMOUNT_COLUMN)
	public WebElement transactionTableCustAmount;

	@FindBy(how = How.ID, using = Locator.CH_TRANSACTION_TABLE_STATUS_COLUMN)
	public WebElement transactionTableStatusAmount;

	@FindBy(how = How.ID, using = Locator.TRANSACTION_LIST_SELECT_ROW)
	public WebElement cardNumberLink;

	@FindBy(how = How.XPATH, using = Locator.CH_MERCHANT_TRANS_TYPE)
	public WebElement transTypeHeader;

	@FindBy(how = How.XPATH, using = Locator.CH_MERCHANT_TRANS_REF_NO)
	public WebElement refNoHeader;

	@FindBy(how = How.ID, using = Locator.CH_MERCHANT_TRANS_FROM_DATE)
	public WebElement transFormDateHeader;

	@FindBy(how = How.XPATH, using = Locator.CH_MERCHANT_TRANSS_LOC_NO)
	public WebElement locNoHeader;
//	@FindBy(how = How.ID, using = Locator.CH_MERCHANT_TRANS_LOC_NO)
//	public WebElement locNo;

	@FindBy(how = How.ID, using = Locator.CH_MERCHANT_TRANS_PRODUCT)
	public WebElement transProductheader;

	@FindBy(how = How.ID, using = Locator.CH_MERCHANT_TRANS_TO_DATE)
	public WebElement transToDateheader;

	@FindBy(how = How.ID, using = Locator.CH_MERCHANT_TRANS_CARD_NO_TABLE)
	public WebElement merctrantableCardNoHeader;

	@FindBy(how = How.ID, using = Locator.CH_MERCHANT_TRANS_TYPE_TABLE)
	public WebElement merctrantableTransTypeHeader;

	@FindBy(how = How.ID, using = Locator.CH_MERCHANT_REF_NO_TABLE)
	public WebElement merctrantableRefNoHeader;

	@FindBy(how = How.ID, using = Locator.CH_MERCHANT_LOC_NAME_TABLE)
	public WebElement merctrantableLocNameHeader;

	@FindBy(how = How.ID, using = Locator.CH_MERCHANT_PRODUCT_TABLE)
	public WebElement merctrantableProductNameHeader;

	@FindBy(how = How.ID, using = Locator.CH_MERCHANT_TRANS_DATE_TABLE)
	public WebElement merctrantableTransDateHeader;

	@FindBy(how = How.ID, using = Locator.CH_MERCHANT_TOTAL_TABLE)
	public WebElement merctrantableTransTotalHeader;

	@FindBy(how = How.ID, using = Locator.ENQUIRY_START_DATE)
	public WebElement merchTransStartDate;
	
	@FindBy(how = How.ID, using = Locator.SET_LOCATION_NUM)
	public WebElement merchTransLocNo;	
	
	@FindBy(how = How.ID, using = Locator.ACCOUNT_SEL)
	public WebElement accountTransactionSel;
	
	@FindBy(how = How.ID, using = Locator.SEARCH_BTN)
	public WebElement searchButton;
	
	@FindBy(how = How.XPATH, using = Locator.TRANSACTION_TABLE_CONTENT)
	public WebElement transactionTableContent;
	
	@FindBy(how = How.XPATH, using = Locator.REFERENCE_TABLE_VAL)
	public WebElement referenceTableContent;
	
	@FindBy(how = How.ID, using = Locator.REFERNCE_NUMBER)
	public WebElement referenceNo;
	
	@FindBy(how = How.XPATH, using= Locator.ACCOUNT_NAME_IN_TRANSACTIONPAGE)
	public WebElement accountNameInTransactionPage;
	
	@FindBy(how = How.ID, using= Locator.FROM_DATE)
	public WebElement dateSender;
	
	@FindBy(how = How.ID, using= Locator.CHV_CALENDER_FROM_BUTTON)
	public WebElement datePickerIcon;
	
	@FindBy(how = How.ID, using= Locator.CHV_CALENDAR_FROM_DIALOGBOX)
	public WebElement datePickerInDialogBox;
	
	@FindBy(how = How.ID, using= Locator.PRD_SEL)
	public WebElement productSelect;
	
	@FindBy(how = How.XPATH, using= Locator.TRANSACTION_LIST_TABLE)
	public WebElement tableListInTransact;
	
	@FindBy(how = How.XPATH, using= Locator.LISTED_TRANSACTIONS_WITH_CARD)
	public List<WebElement> cardNumPresent;
	
	@FindBy(how = How.ID, using = Locator.CH_MERCHANTL_TRANS_TYPE)
	public WebElement transTypeHeaderL;

	@FindBy(how = How.ID, using = Locator.CH_MERCHANTL_TRANS_REF_NO)
	public WebElement refNoHeaderL;

	@FindBy(how = How.ID, using = Locator.CH_MERCHANTL_TRANS_FROM_DATE)
	public WebElement transFormDateHeaderL;

	@FindBy(how = How.ID, using = Locator.CH_MERCHANTL_TRANSS_LOC_NO)
	public WebElement locNoHeaderL;
	/*@FindBy(how = How.ID, using = Locator.CH_MERCHANTL_TRANS_LOC_NO)
	public WebElement locNoL;*/

	@FindBy(how = How.ID, using = Locator.CH_MERCHANTL_TRANS_PRODUCT)
	public WebElement transProductheaderL;

	@FindBy(how = How.ID, using = Locator.CH_MERCHANTL_TRANS_TO_DATE)
	public WebElement transToDateheaderL;
	
	
	String CardNumberChoose;
	String transactionDatefrom;
	String queryToGetTransactionDate;
	int cardWithTransaction;
	
	
	
	public CHTransactionPage(WebDriver driver, ExtentTest test) {
		super(driver, test);
		PageFactory.initElements(driver, this);
	}

	public void verifyTransactionPage() {
		sleep(3);
		isDisplayed(transactionPageTitle, "Transactions");
		logPass("Redirected to the Transaction Status Page");

	}

	public void verifySearchButtons() {
		isDisplayedThenActionClick(searchBtn, "Search button");
		sleep(3);

	}

	public void verifyExportButtons() {
		if (exportBtn.isDisplayed()) {
			logPass("exportBtn is displayed");
		} else {
			logFail("exportBtn is not displayed");
		}

	}

	public void verifyTransactionListHeaders() {

		sleep(10);
		verifyText(transactionTableCardNumber, "Card Number");
		verifyText(transactionTableAccountNumber, "Account No");
		verifyText(transactionTableReferenceNumber, "Reference #");
		verifyText(transactionTableLocation, "Location");
		verifyText(transactionTableProduct, "Product");
		verifyText(transactionTableDateTime, "Date/Time");
		verifyText(transactionTableOdometer, "Odometer");
		verifyText(transactionTableCustAmount, "Cust Amount");
		verifyText(transactionTableStatusAmount, "Status");
	}
	

	public void verifyMerchantTransListHeaders() {
		isDisplayed(transTypeHeader, "Transaction Type");

		isDisplayed(refNoHeader, "Reference No");

		isDisplayed(transFormDateHeader, "Trasaction Date From");

		isDisplayed(locNoHeader, "Location No");//Merchant
	//	isDisplayed(locNo, "Location No");
		isDisplayed(transProductheader, "Product");

		isDisplayed(transToDateheader, "Transaction Date To");
	}

	public void verifyLocationTransListHeaders() {
		isDisplayed(transTypeHeaderL, "Transaction Type");

		isDisplayed(refNoHeaderL, "Reference #");

		isDisplayed(transFormDateHeaderL, "Trasaction Date From");

		isDisplayed(locNoHeaderL, "Location No");//Location
	//	isDisplayed(locNo, "Location No");
		isDisplayed(transProductheaderL, "Product");

		isDisplayed(transToDateheaderL, "Transaction Date To");
	}
	public void verifyMerchantTransTableHeaders() {

		checkTextInPageAndValidate("Card Number", 30); 

		checkTextInPageAndValidate("Transaction Type", 30);

		checkTextInPageAndValidate("Reference No", 30);

		checkTextInPageAndValidate("Location Name", 30);

		checkTextInPageAndValidate("Product", 30);

		checkTextInPageAndValidate("Transaction Date", 30);

		checkTextInPageAndValidate("Merchant Total", 30);

	}

	public void clickOnCreditCardNumber() {
		if (cardNumberLink.isDisplayed()) {
			actionClick(cardNumberLink);
			logInfo("Card Number is clicked");
		} else {
			logFail("Card Number is not found");
		}
	}
	
	/*public void enterCardNumberAndSearch(String cardNumber) {
		enterText(this.cardNumberTrans, cardNumber);
		if (searchBtn.isDisplayed()) {
			actionClick(searchBtn);
			logPass("Search Button is clicked");
		} else {
			logFail("Search Button is not clicked");
		}
		sleep(3);
	}*/
	

	public boolean getACardNumberFromTable() {
		int randomNo = 0;
		boolean isTablePresent = true;
		sleep(10);
		if (getRowSize(tableListInTransact) > 1) {
			setCellDataFromTable(tableListInTransact, 9, true);
			cardWithTransaction = cardNumPresent.size();
			logInfo("Listed Card:" + cardWithTransaction);
			if (cardWithTransaction > 1) {
				randomNo = getRandomNumber(0, cardNumPresent.size() - 1);
			}
			CardNumberChoose = getText(cardNumPresent.get(randomNo));
		} else {
			logInfo("No Transactions present");
			isTablePresent = false;
		}
		return isTablePresent;
	}

		public void getTransactionDateFromTheDBForTheCurrentInternetUser(String userName,String clientName) {
		
		try {
			
			String getDBDetailsFromProperties = PropUtils.getPropValue(configProp, "sqlODSServerName");
			// clientNameForDBConnection = clientName;
			String userId = PropUtils.getPropValue(configProp, userName);
			System.out.println("userId : "+userId);

			if(userName.contains("SG")) {
				
			queryToGetTransactionDate = "Select tr.processed_at from transactions tr inner join m_customers mcu on mcu.customer_mid = tr.customer_mid inner join m_clients mcl on mcu.client_mid = mcl.client_mid inner join accounts a on mcu.customer_mid = a.customer_mid inner join internet_users iu on mcl.client_group_mid = iu.client_group_mid where mcu.client_mid =(Select client_mid from m_clients where name ='Chevron Singapore Pte. Ltd.') and iu.logon_id = '"+userId+"' and rownum = 1";
			
			} else if(userName.contains("PH")) {
				
				queryToGetTransactionDate = "Select tr.processed_at from transactions tr inner join m_customers mcu on mcu.customer_mid = tr.customer_mid inner join m_clients mcl on mcu.client_mid = mcl.client_mid inner join accounts a on mcu.customer_mid = a.customer_mid inner join internet_users iu on mcl.client_group_mid = iu.client_group_mid where mcu.client_mid =(Select client_mid from m_clients where name ='Chevron Philippines, Inc.') and iu.logon_id = '"+userId+"' and rownum = 1";
			}
			 else if(userName.contains("TH")) {
					
//					queryToGetTransactionDate = "Select tr.processed_at from transactions tr inner join m_customers mcu on mcu.customer_mid = tr.customer_mid inner join m_clients mcl on mcu.client_mid = mcl.client_mid inner join accounts a on mcu.customer_mid = a.customer_mid inner join internet_users iu on mcl.client_group_mid = iu.client_group_mid where mcu.client_mid =(Select client_mid from m_clients where name ='Chevron (Thailand) Limited') and iu.logon_id = 'CVX_THmerchant' and rownum = 1";
				 
				 queryToGetTransactionDate = "Select tr.processed_at from transactions tr inner join m_customers mcu on mcu.customer_mid = tr.customer_mid inner join m_clients mcl on mcu.client_mid = mcl.client_mid inner join accounts a on mcu.customer_mid = a.customer_mid inner join internet_users iu on mcl.client_group_mid = iu.client_group_mid where mcu.client_mid =(Select client_mid from m_clients where name ='Chevron (Thailand) Limited') and iu.logon_id = '"+userId+"' and rownum = 1";
				}
			if(queryToGetTransactionDate!=null) {
			transactionDatefrom = connectDBAndGetValue(queryToGetTransactionDate, getDBDetailsFromProperties);
			logInfo("Transaction Date From: " + transactionDatefrom);
			transactionDatefrom = transactionDatefrom.substring(0, 10);

			DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd"); 
			
			System.out.println("Transaction Date is very first time"+transactionDatefrom);
						 
			Date date = (Date)formatter.parse(transactionDatefrom);
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy");
			transactionDatefrom = simpleDateFormat.format(date);
			transactionDatefrom = transactionDatefrom.replaceAll("-","/");
			
			System.out.println(transactionDatefrom);
			
		}
			else
				logInfo("Date is not present");
		}
		

		catch (Exception e) {
			logFail(e.getMessage());
		}
	}
		
	public void passFromDateInTransaction()
	{
		transactionDatefrom="08/08/2024";
		isDisplayedThenEnterText(transFormDateHeader, "FromDate",transactionDatefrom);
	}

	/*public void enterCardNumberAndSearch() {
		for(int i=1;i<=cardWithTransaction;i++)
		{
			String CardNo=getCellDataFromTable(i,0,true);
			
			if(CardNo.isEmpty()) {
				logInfo("Card Not Present");
			}
			else  {
				logInfo("Selected Acc no:"+CardNo);
				enterText(cardNumberTrans,CardNo);
				break;
			}
		}
	}*/
	
	/*public void enterCardNumberAndSearch() {
		
		String cardNumber=getText(cardNumberLink);
		enterText(this.cardNumberTrans, cardNumber);
		isDisplayed(searchBtn,"Search Button");
		sleep(3);
	}*/
	
	public void selectAccountFromDropdownAndValidate() {

		isDisplayed(accountTransactionSel, "Account Drop down in Transaction page");

		int size = getDropdownSize(accountTransactionSel);

		if (size > 1) {
			String accountName = selectedStringFrmDropDown(accountTransactionSel);
			System.out.println("accountNAme ---- " + accountName);
			sleep(5);
			selectDifferentValueInsteadOfDefault(accountTransactionSel, accountName, "");
			sleep(3);
			String accname2 = selectedStringFrmDropDown(accountTransactionSel);
			sleep(5);
			if (!accountName.contains(accname2)) {
				logInfo("Account 1 = " + accountName + " Different Account selected ---=" + accname2);
				logPass("Different Account Selected");
			}

			else {
				logInfo("Account 1 = " + accountName + " Different Account selected ---=" + accname2);
				logFail("Different Account is not selected");
			}
		} else {
			logInfo("accountDropdown in home page has only one option");
		}
	}
	
	public void selectProductFromDropdownAndValidate() {

		isDisplayed(productSelect, "Product Drop down in Transaction page");

		int size = getDropdownSize(productSelect);

		if (size > 1) {
			String accountName = selectedStringFrmDropDown(productSelect);
			System.out.println("accountNAme ---- " + accountName);
			sleep(5);
			selectDifferentValueInsteadOfDefault(productSelect, accountName, "");
			sleep(3);
			String accname2 = selectedStringFrmDropDown(productSelect);
			sleep(5);
			if (!accountName.contains(accname2)) {
				logInfo("Account 1 = " + accountName + " Different Account selected ---=" + accname2);
				logPass("Different Account Selected");
			}

			else {
				logInfo("Account 1 = " + accountName + " Different Account selected ---=" + accname2);
				logFail("Different Account is not selected");
			}
		} else {
			logInfo("accountDropdown in home page has only one option");
		}
	}
	
	
	public void clickTransactionListSearchButtonAndValidate() {
	
		isDisplayedThenActionClick(searchButton, "Click Search Button");
		sleep(3);
		isDisplayed(tableListInTransact, "Transaction Table");
	}
	
	
	
	
	public void enterReferenceAndSearch() {
		
			
		String refno=getText(referenceTableContent);
		enterText(referenceNo, refno);
		logInfo("Reference no is entered");
		isDisplayed(searchBtn,"Search Button");
		sleep(3);
		
	}
	
	public void verifyandClickExportButtons() {
		
		isDisplayedThenActionClick(exportBtn,"exportBtn");
		
	}
	
	public void verifyAccountNoForFileVerification() {
		String s = getText(accountNameInTransactionPage).split("\\(")[1];
		String store=s.split("\\)")[0];
		verifyTheDownloadedFile(store);
		}
	
	public void passTransactionDateFrom() 
	{
			selectDateFromCalendarControl(datePickerIcon, datePickerInDialogBox , "16/August/2016");
	}
	
	public void selectDateFromCalendarControl(WebElement datePicketButton, WebElement calenderDialogBox, String date) {
		try {
			DateFormat simpleDateFormat = new SimpleDateFormat("dd/MMMM/yyyy");
			Date selectDate = simpleDateFormat.parse(date);

			pickDate(selectDate, datePicketButton, calenderDialogBox);
			sleep(1);

		}

		catch (ParseException pe) {
			logFail(pe.getMessage());
		} catch (Exception e) {
			logFail(e.getMessage());
		}

	}
	
	

	
}
