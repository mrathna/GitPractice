package com.framework.testcases.AJS.OTI;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.ApplicationsPage;
import com.framework.pages.AJS.common.IFCSHomePage;
import com.framework.pages.AJS.common.IFCSLoginPage;

public class ValidateApplicationCreationTestCases extends BaseTest {
	
	@Parameters({ "clientCountry", "clientName" })
	@Test(enabled=false)
	public void  CreateApplicationWithCreditLimit(@Optional("BW") String clientCountry, @Optional("OTI") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  01 Create  Application and 03 Create Customer with credit limit","Create Application and set as credit limit");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCShomePage = new IFCSHomePage(driver, test);
		ApplicationsPage ifcsApplicationsPage = new ApplicationsPage(driver, test);
		IFCSloginPage.login("IFCS_URL_OTI", "IFCS_OTI_USERNAME", "IFCS_OTI_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		//IFCShomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);
//		Create New Application
		IFCShomePage.gotoApplicationAndClickApplicationMenu();
		IFCShomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);
		System.out.println("General"+  "("+clientCountry+")");
		ifcsApplicationsPage.applicationFilterOptions("General "+ "("+clientCountry+")", "Approved");
		ifcsApplicationsPage.clearExistingFormAndCreateNewApplicationWithMandatoryField("random");
		String customerNo=ifcsApplicationsPage.getCustomerNoAndSelectPricingProfile();
		//Validate Customer No in Customer Details
		IFCShomePage.gotoCustomerMenuCustomerDetails();
		ifcsApplicationsPage.validateCustomerNoInCustomerDetails(customerNo);
		
		IFCShomePage.exitIFCS();

	}
	
	@Parameters({ "clientCountry", "clientName" })
	@Test(priority = 2)
	public void CreateApplicationWithNoCreditLimit(@Optional("BW") String clientCountry, @Optional("OTI") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  02 Create Customer with no credit Limit","Create Application with no credit limit");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCShomePage = new IFCSHomePage(driver, test);
		ApplicationsPage ifcsApplicationsPage = new ApplicationsPage(driver, test);
		IFCSloginPage.login("IFCS_URL_OTI", "IFCS_OTI_USERNAME", "IFCS_OTI_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		//IFCShomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);
		//Create New Application
		IFCShomePage.gotoApplicationAndClickApplicationMenu();
		IFCShomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);
		ifcsApplicationsPage.applicationFilterOptions("General "+ "("+clientCountry+")", "Approved");
		//common.selectFirstRowNumberInSearchList();
		ifcsApplicationsPage.clearExistingFormAndCreateNewApplicationWithMandatoryField("Zero");
		String customerNo=ifcsApplicationsPage.getCustomerNoAndSelectPricingProfile();
		//Validate Customer No in Customer Details
		IFCShomePage.gotoCustomerMenuCustomerDetails();
		ifcsApplicationsPage.validateCustomerNoInCustomerDetails(customerNo);
		
		IFCShomePage.exitIFCS();

	}
}
