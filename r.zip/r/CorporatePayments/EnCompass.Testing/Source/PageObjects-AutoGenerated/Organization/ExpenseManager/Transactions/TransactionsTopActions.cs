using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using Common;
using Common.PageObjects;
using Common.ScenarioConfigurations;
using Common.Utility;

namespace EnCompass.Testing.Source.PageObjects.Organization.ExpenseManager.Transactions 
{
	/// <summary>
	/// Auto-generated Page Model Class
	/// Navigation Paths: 
		/// [Organization Home]->Transactions->Transaction Management
		/// </summary>
	[PageModel(@"/expenseManager/transactions/transactionsTopActions.aspx")]
	public partial class TransactionsTopActions : EnCompassOrgPageModel 
	{
		public override string RelativeUrl => @"/expenseManager/transactions/transactionsTopActions.aspx";
		public override string PageIdentifierXPath_Generated => @"//li[contains(@class, 'breadcrumb-item active')][text() = 'Transaction Management']";

		#region Navigation
		
		private void NavigateToMenuItem(IWebElement element)
		{
			Driver.Url = element.GetAttribute("href");
		}
		#endregion

		public TransactionsTopActions(GlobalSettings settings) : base(settings) { }
	}  
}
