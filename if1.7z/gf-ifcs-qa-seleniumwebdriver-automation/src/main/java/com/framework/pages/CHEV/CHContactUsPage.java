package com.framework.pages.CHEV;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.ExtentTest;
import com.framework.basepage.BasePage;
import com.framework.repo.Locator;

public class CHContactUsPage extends BasePage {

	@FindBy(how = How.XPATH, using = Locator.SCHEDULE_REPORT_MAINTENANCE_PAGE)
	public WebElement transactionPageTitle;

	@FindBy(how = How.XPATH, using = Locator.CH_CONFIRMATION_MSG)
	public WebElement confirmationMessage;

	@FindBy(how = How.ID, using = Locator.CH_ENQUIRY_TYPE_DROP_DOWN)
	public WebElement enquiryTypeDropDown;

	@FindBy(how = How.ID, using = Locator.CH_COMMENTS_DROP_DOWN)
	public WebElement commentBox;

	@FindBy(how = How.ID, using = Locator.CH_CONTACT_NAME)
	public WebElement contactName;

	@FindBy(how = How.ID, using = Locator.CH_PHONE_NO)
	public WebElement phoneNo;

	@FindBy(how = How.ID, using = Locator.CH_EMAIL)
	public WebElement email;

	@FindBy(how = How.ID, using = Locator.CH_CONTACT_NO)
	public WebElement contactNo;

	@FindBy(how = How.ID, using = Locator.CH_SUBMIT_BTN)
	public WebElement submitBtn;

	@FindBy(how = How.XPATH, using = Locator.CH_RELPACE_CONFIRM_ERROR_MESSAGE)
	public WebElement errorMessage;
	
	
	
	@FindBy(how = How.ID, using = Locator.FULL_NAME_CONTACTUS)
	public WebElement fullName;

	@FindBy(how = How.ID, using = Locator.INQUIRY_SUMMARY_CONTACTUS)
	public WebElement inquirySumm;

	@FindBy(how = How.ID, using = Locator.EMAIL_FIELD_CONTACUS)
	public WebElement emailField;

	@FindBy(how = How.XPATH, using = Locator.CUSTOMER_RADIO_BUTTON)
	public WebElement customerRadioBTN;
	
	@FindBy(how = How.XPATH, using = Locator.MERCHANT_RADIO_BUTTON)
	public WebElement merchantRadioBTN;
	
	@FindBy(how = How.ID, using = Locator.BUTTON_CUS)
	public WebElement btnSubmitCUS;
	
	@FindBy(how = How.XPATH, using = Locator.FULL_NAME)
	public WebElement fullNameLabel;
	
	@FindBy(how = How.XPATH, using = Locator.INQUIRY_SUMMARY)
	public WebElement inquiryLabel;
	
	@FindBy(how = How.XPATH, using = Locator.EMAIL_ADDRESS)
	public WebElement emailAddressLabel;
	
	@FindBy(how = How.XPATH, using = Locator.CONTACT_NUMBER)
	public WebElement contactNumberLabel;
	
	@FindBy(how = How.XPATH, using = Locator.USER_TYPE)
	public WebElement userTypeLabel;
	
	@FindBy(how = How.XPATH, using = Locator.HELP_OPTION)
	public WebElement helpOptionLabel;
	
	@FindBy(how = How.XPATH, using = Locator.SUBMIT_OPTION)
	public WebElement submitOption;
	
	
	public CHContactUsPage(WebDriver driver, ExtentTest test) {
		super(driver, test);
		PageFactory.initElements(driver, this);
	}

	public void verifyTransactionPage() {
		sleep(3);
		isDisplayed(transactionPageTitle, "Transactions");
		logPass("Redirected to the Transaction Status Page");
	}

	public void verifySubscribeBtn() {
		if (waitForTextToAppear("Subscribe Button", 10)) {
			logFail("Subscribe Button is visible");
		} else {
			logPass("Subscribe Button is not visible");
		}
	}
	
	public void enterRandomValuesAndValidate(String userType) {

		checkTextInPageAndValidate("Contact Us", 30);
		// clearFields();
		enterText(fullName, fakerAPI().name().fullName());
		enterText(inquirySumm, fakerAPI().harryPotter().quote());
		enterText(emailField, fakerAPI().internet().emailAddress());
		if (userType.equals("customer")) {
			isDisplayedThenActionClick(customerRadioBTN, "Customer Radio Button");
		} else {
			isDisplayedThenClick(merchantRadioBTN,"Merchant");
		}
		
		isDisplayedThenClick(btnSubmitCUS, "Submit Button of the Contact US");
		
		sleep(5);
		
		checkTextInPageAndValidate("Please fill captcha", 30); 
		
		gotoLastPage(); 
		//gotoLastPage();

	}

	public void enterRandomValues() {

		checkTextInPageAndValidate("Contact Us", 30);
		clearFields();
		enterText(commentBox, fakerAPI().harryPotter().quote());
		enterText(contactName, fakerAPI().name().fullName());
		enterText(phoneNo, fakerAPI().phoneNumber().cellPhone());
		enterText(email, fakerAPI().name().firstName() + "@gmail.com");
		selectDifferentValueInsteadOfDefault(enquiryTypeDropDown, "--Select One--", "--Select One--");

	}

	public void enterRandomValuesExceptEnquiryType() {
		clearFields();
		enterText(commentBox, fakerAPI().harryPotter().quote());
		enterText(contactName, fakerAPI().name().fullName());
		enterText(phoneNo, fakerAPI().phoneNumber().cellPhone());
		enterText(email, fakerAPI().name().firstName() + "@gmail.com");
	}

	public void enterRandomValuesExceptComments() {
		clearFields();
		selectDifferentValueInsteadOfDefault(enquiryTypeDropDown, "--Select One--", "--Select One--");
		enterText(contactName, fakerAPI().name().fullName());
		enterText(phoneNo, fakerAPI().phoneNumber().cellPhone());
		enterText(email, fakerAPI().name().firstName() + "@gmail.com");
	}

	public void enterRandomValuesExceptContactName() {
		clearFields();
		selectDifferentValueInsteadOfDefault(enquiryTypeDropDown, "--Select One--", "--Select One--");
		enterText(commentBox, fakerAPI().harryPotter().quote());
		enterText(phoneNo, fakerAPI().phoneNumber().cellPhone());
		enterText(email, fakerAPI().name().firstName() + "@gmail.com");

	}

	public void enterRandomValuesExceptPhoneNo() {
		clearFields();
		selectDifferentValueInsteadOfDefault(enquiryTypeDropDown, "--Select One--", "--Select One--");
		enterText(commentBox, fakerAPI().harryPotter().quote());
		enterText(contactName, fakerAPI().name().fullName());
		enterText(email, fakerAPI().name().firstName() + "@gmail.com");

	}

	public void enterRandomValuesExceptEmail() {
		clearFields();
		selectDifferentValueInsteadOfDefault(enquiryTypeDropDown, "--Select One--", "--Select One--");
		enterText(commentBox, fakerAPI().harryPotter().quote());
		enterText(contactName, fakerAPI().name().fullName());
		enterText(phoneNo, fakerAPI().phoneNumber().cellPhone());

	}

	public void enterRandomValuesWithIncorrectEmail() {
		clearFields();
		selectDifferentValueInsteadOfDefault(enquiryTypeDropDown, "--Select One--", "--Select One--");
		enterText(commentBox, fakerAPI().harryPotter().quote());
		enterText(contactName, fakerAPI().name().fullName());
		enterText(phoneNo, fakerAPI().phoneNumber().cellPhone());
		enterText(email, fakerAPI().name().firstName());
	}

	public void clickSubmitButton() {
		if (submitBtn.isDisplayed()) {
			actionClick(submitBtn);
		} else {
			logFail("Submit Button is not displayed");
		}
	}

	public void clearFields() {
		selectDropDownByVisibleText(enquiryTypeDropDown, "--Select One--");
		commentBox.clear();
		contactName.clear();
		phoneNo.clear();
		email.clear();
	}

	public void verifySubHeadings() {
		if (contactNo.isDisplayed()) {
			logPass("Contact No. is displayed");
		} else {
			logFail("Contact No. is not displayed");
		}
	}

	public void checkConfirmationMessage() {
		sleep(10);
		verifyText(confirmationMessage, "Email was sent successfully");
	}

	public void verifyErrorMessage(String expectedMsg) {
		sleep(20);
		if (errorMessage.isDisplayed() && errorMessage.getText().contains(expectedMsg)) {
			logPass(expectedMsg + " error message is displayed");
		} else {
			logFail(expectedMsg + " error message is not displayed");
		}
	}
	
	public void verifyContactUsFields() {
		isDisplayed(fullNameLabel,"Full Name");
		isDisplayed(inquiryLabel,"Inquiry Summary");
		isDisplayed(emailAddressLabel,"Email Address");
		isDisplayed(contactNumberLabel,"Contact Number");
		isDisplayed(userTypeLabel,"User Type");
		isDisplayed(helpOptionLabel,"Help Option");
		isDisplayed(submitOption,"Submit");
		
	}
		
}
