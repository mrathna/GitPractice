package com.framework.testcases.AJS.EMAP;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.ChangeCardStatus;
import com.framework.pages.AJS.common.Common;
import com.framework.pages.AJS.common.IFCSHomePage;
import com.framework.pages.AJS.common.IFCSLoginPage;


//Added by Ayub 29-03-2019

public class ValidateChangeCardStatus extends BaseTest {
	String cardNo;
	
	@Parameters({ "clientCountry", "clientName"})
	@Test(groups = { "Regression" })
	public void ValidateChangecardCancelledNotBalAllowedWithNoReplace(@Optional("SG") String clientCountry,
			@Optional("EMAP") String clientName) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  TST-SC-55-Change Card status - Active to Cancelled - Desktop - Allowed - No replace",
				"Active to Cancelled - Desktop - Allowed - No replace");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		ChangeCardStatus changeCardStatus = new ChangeCardStatus(driver, test);
		IFCSloginPage.login("IFCS_URL_EMAP", "IFCS_EMAP_USERNAME", "IFCS_EMAP_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry," ");
		// Click search cards
		IFCSHomePage.gotoSearchAndClickCards();

		cardNo = changeCardStatus.searchCardsWithNoBalanceOrWithBalanceAndsetInContext("withBalance","Active");

		changeCardStatus.verifyCardNumberAndDoubleClick(cardNo);
		changeCardStatus.changeCardStatusAndClickYesAndValidate("Cancelled");
		IFCSHomePage.exitIFCS();

	}
	
	@Parameters({ "clientCountry", "clientName"})
	@Test(groups = { "Regression" })
	public void ValidateChangecardDamageNotBalAllowedWithNoReplace(@Optional("SG") String clientCountry,
			@Optional("EMAP") String clientName) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  TST-SC-56-Change Card status - Active to Damaged - Desktop - replace & No Replace",
				"Active to Damaged - Desktop - replace & No Replace");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		ChangeCardStatus changeCardStatus = new ChangeCardStatus(driver, test);

		IFCSloginPage.login("IFCS_URL_EMAP", "IFCS_EMAP_USERNAME", "IFCS_EMAP_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry," ");
		// Click search cards
		IFCSHomePage.gotoSearchAndClickCards();
		
		cardNo = changeCardStatus.searchCardsWithNoBalanceOrWithBalanceAndsetInContext("withBalance","Active");

		changeCardStatus.verifyCardNumberAndDoubleClick(cardNo);
		changeCardStatus.changeCardStatusAndClickNoAndValidate("Damaged");
		
		IFCSHomePage.gotoSearchAndClickCards();
		
		cardNo = changeCardStatus.searchCardsWithNoBalanceOrWithBalanceAndsetInContext("withBalance","Active");

		changeCardStatus.verifyCardNumberAndDoubleClick(cardNo);
		changeCardStatus.changeCardStatusAndClickYesAndValidate("Damaged");
		IFCSHomePage.exitIFCS();
	}
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "Regression" })
	public void ValidateChangecardLostToCancelledAndInActiveToActive(@Optional("SG") String clientCountry,
			@Optional("EMAP") String clientName) {

		test = extent.createTest(
				"TST-SC-09 - Change Card status - Lost to cancelled- Desktop - Allowed -Inactive to Active- Desktop - Allowed,"
						+ "TST-SC-09 - Change Card status - Lost to cancelled- Desktop - Allowed -Inactive to Active- Desktop - Allowed");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		ChangeCardStatus changeCardStatus = new ChangeCardStatus(driver, test);
		Common common = new Common(driver, test);
		IFCSloginPage.login("IFCS_URL_EMAP", "IFCS_EMAP_USERNAME", "IFCS_EMAP_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, " ");
		// Click search cards
		IFCSHomePage.gotoSearchAndClickCards();
		cardNo = changeCardStatus.searchCardsWithNoBalanceOrWithBalanceAndsetInContext("withBalance", "Lost");

		if (cardNo.length() > 0) {
			changeCardStatus.verifyCardNumberAndDoubleClick(cardNo);
			changeCardStatus.changeCardStatusAndClickYesAndValidate("Cancelled");

		} else {
			common.logForNoDataFound(this.getClass().getName(), "No Lost cards in DB!!");
		}

		IFCSHomePage.gotoSearchAndClickCards();
		cardNo = changeCardStatus.searchCardsWithNoBalanceOrWithBalanceAndsetInContext("withBalance", "Inactive");
		if (cardNo.length() > 0) {
			changeCardStatus.verifyCardNumberAndDoubleClick(cardNo);
			changeCardStatus.changeCardStatusAndClickYesAndValidate("Active");
		} else {
			common.logForNoDataFound(this.getClass().getName(), "No Inactive cards in DB!!");
		}

		IFCSHomePage.exitIFCS();
	}

}
