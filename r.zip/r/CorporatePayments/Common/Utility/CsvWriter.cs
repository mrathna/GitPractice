﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Common.Utility
{
	public class CsvWriter
	{
		public void WriteFile<T>(List<T> records, string path)
		{
			var properties = typeof(T).GetProperties().Where(p=> p.CanRead);

			// get header line
			var headerNames = properties.Select(p =>
			{
				var fieldAttribute = p.GetCustomAttributes(true).OfType<CsvFieldAttribute>().SingleOrDefault();
				return fieldAttribute?.FieldName ?? p.Name;
			});

			List<string> lines = new List<string>();
			lines.Add(FormatLine(headerNames));

			foreach(var record in records)
			{
				var lineFields = new List<string>();
				foreach(var prop in properties)
				{
					lineFields.Add(prop.GetValue(record).ToString());
				}
				lines.Add(FormatLine(lineFields));
			}

			File.WriteAllLines(path, lines);
		}

		public void DeleteFile(string filepath)
		{
			System.IO.File.Delete(filepath);
		}

		private string FormatLine(IEnumerable<string> fields)
		{
			return string.Join(",", fields.Select(f => $"\"{f}\""));
		}
	}

	[AttributeUsage(AttributeTargets.Property, AllowMultiple = false, Inherited = false)]
	public class CsvFieldAttribute : Attribute
	{
		/// <summary>
		/// Relative URL for the page that this page model represents.
		/// Should not include URL query string parameters.
		/// </summary>
		public string FieldName { get; set; }

		public CsvFieldAttribute(string fieldName)
		{
			FieldName = fieldName;
		}
	}
}
