package com.framework.testcases.AJS.EMAP;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.SearchPage;
import com.framework.pages.AJS.common.Common;
import com.framework.pages.AJS.common.IFCSHomePage;
import com.framework.pages.AJS.common.IFCSLoginPage;

public class validateSearchCustomers extends BaseTest {
	
	@Parameters({ "clientCountry", "clientName"})
	@Test( groups = { "Regression" })
	public void validateSearchCustomer(@Optional("HK") String clientCountry, @Optional("EMAP") String clientName) {
		
		test = extent.createTest(clientName+ ":" +clientCountry+"  Verify Search customer", "Verifying Search customer");
		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		SearchPage searchInputs = new SearchPage(driver, test);
		Common common = new Common(driver, test);
		IFCSloginPage.login("IFCS_URL_EMAP", "IFCS_EMAP_USERNAME", "IFCS_EMAP_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		IFCSHomePage.gotoCustomerMenuCustomer();
		IFCSHomePage.gotoCustomersMenuAndChooseClient(clientName + "_" + clientCountry);
		common.performBlankSearchAndValidate();
		// Search customer number
		searchInputs.enterCustomerNumberAndSearch(clientName + "_" + clientCountry);
		IFCSHomePage.exitIFCS();
		
	}
}
