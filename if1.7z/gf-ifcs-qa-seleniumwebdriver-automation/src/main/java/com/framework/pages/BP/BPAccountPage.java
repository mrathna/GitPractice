package com.framework.pages.BP;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.ExtentTest;
import com.framework.basepage.BasePage;
import com.framework.repo.Locator;

public class BPAccountPage extends BasePage {

	@FindBy(how = How.ID, using = Locator.VIEW_AND_EDIT_CONTACT_LINK)
	public WebElement viewAndEditContactLink;
	@FindBy(how = How.ID, using = Locator.VIEW_AND_EDIT_COST_CENTRE_LINK)
	public WebElement viewAndEditCostCentreLink;

	public BPAccountPage(WebDriver driver, ExtentTest test) {
		super(driver, test);
		PageFactory.initElements(driver, this);
	}

	public void clickViewAndEditContactLink() {
		isDisplayedThenActionClick(viewAndEditContactLink, "View and Edit Contact Link");
	}

	public void clickViewAndEditCostCentreLink() {
		isDisplayedThenActionClick(viewAndEditCostCentreLink, "View and Edit CostCentre Link");
	}
}
