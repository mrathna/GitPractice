package com.framework.testcases.OLS.SHELL.Customer;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.OLS.HomePage;
import com.framework.pages.OLS.common.LoginPage;
import com.framework.pages.SHELL.SHELLAccountMaintenancePage;
import com.framework.pages.SHELL.SHELLAccountPage;
import com.framework.pages.SHELL.SHELLHomePage;

public class ValidateAccountTestCases extends BaseTest  {
	
	@Parameters({"clientCountry","clientName","cardType"})
	@Test(groups = { "Regression" })
	public void validateTheFundTransferAccountToAccount(@Optional("BE") String clientCountry, @Optional("SHELL") String clientName, @Optional("APA") String cardType) {
		
		test = extent.createTest(clientName+ ":" +clientCountry+"  10 Funds Transfer Account To Account not in heirarchy, 06 Funds Transfer Parent Account To Child Account", "Funds transfer account to account");
		
        //Creating Objects for the Pages
        LoginPage loginPage = new LoginPage(driver, test);
        HomePage homePage = new HomePage(driver, test);
        SHELLHomePage shellHomePage = new SHELLHomePage(driver, test);
        SHELLAccountPage accountPage = new SHELLAccountPage(driver, test);
      
	    // Calling Functions
        if(cardType.equals("PC"))
        {
        	loginPage.Login("SHLPC_URL", "SHLPC_UN_Customer_Admin_" + clientCountry, "SHLPC_PWD_Customer_Admin_" + clientCountry, clientName);
        }
        else if(cardType.equals("APA"))
        {
        	loginPage.Login("SHLAPA_URL", "SHLAPA_UN_Customer_Admin_" + clientCountry, "SHLAPA_PWD_Customer_Admin_" + clientCountry, clientName);
        }
        
		homePage.ValidateLogoutLink();
		homePage.ValidateHelpShellLink();
		homePage.ValidateWelcomeText(clientName+"#"+cardType);
		homePage.ValidateQuickLinks();
		shellHomePage.ValidateHeaderMenus("Admin");
		shellHomePage.ValidateFooterMenus();
		shellHomePage.goToAccountMenuFundTransfer(); 
		accountPage.verifyFundTransferPageIsLoaded();
		accountPage.selectTheAccounts();
		accountPage.enterAmountFundtransferAndValidate();
		loginPage.Logout();      
	}
	
	@Parameters({"clientCountry","clientName", "cardType"})
	@Test(groups = { "Regression" })
	public void validateTheFundTransferCardToAccount(@Optional("AT") String clientCountry, @Optional("SHELL") String clientName, @Optional("APA") String cardType)  {
		
		test = extent.createTest(clientName+ ":" +clientCountry+"  09 Funds Transfer Card To Account", "Funds transfer Card to Account");		
        //Creating Objects for the Pages
        LoginPage loginPage = new LoginPage(driver, test);
        HomePage homePage = new HomePage(driver, test);
        SHELLHomePage shellHomePage = new SHELLHomePage(driver, test);
        SHELLAccountPage accountPage = new SHELLAccountPage(driver, test);
        
        // Calling Functions
        
        if(cardType.equals("PC"))
        {
        	loginPage.Login("SHLPC_URL", "SHLPC_UN_Customer_Admin_" + clientCountry, "SHLPC_PWD_Customer_Admin_" + clientCountry, clientName);
        }
        else if(cardType.equals("APA"))
        {
        	loginPage.Login("SHLAPA_URL", "SHLAPA_UN_Customer_Admin_" + clientCountry, "SHLAPA_PWD_Customer_Admin_" + clientCountry, clientName);
        }
		homePage.ValidateLogoutLink();
		homePage.ValidateHelpShellLink();
		homePage.ValidateWelcomeText(clientName+"#"+cardType);
		homePage.ValidateQuickLinks();
		shellHomePage.ValidateHeaderMenus("Admin");
		shellHomePage.ValidateFooterMenus();
		shellHomePage.goToAccountMenuFundTransfer(); 
		accountPage.verifyFundTransferPageIsLoaded();		
		accountPage.verifyCardToAccountDetails();
		loginPage.Logout();
      
	}

	@Parameters({"clientCountry","clientName","cardType"})
	@Test(groups = { "Regression" })
	public void validateAccountStatusMainAccount(@Optional("AT") String clientCountry, @Optional("SHELL") String clientName, @Optional("APA") String cardType)  {
		
		test = extent.createTest(clientName+ ":" +clientCountry+"  22 Account Status Main Account", "Check the Status of Main Account");

		//Creating Objects for the Pages
        LoginPage loginPage = new LoginPage(driver, test);
        HomePage homePage = new HomePage(driver, test);
        SHELLHomePage shellHomePage = new SHELLHomePage(driver, test);
        SHELLAccountPage shellAccountPage = new SHELLAccountPage(driver, test);
        
        // Calling Login Functions And Validate
        if(cardType.equals("PC"))
        {
        	loginPage.Login("SHLPC_URL", "SHLPC_UN_Customer_Admin_" + clientCountry, "SHLPC_PWD_Customer_Admin_" + clientCountry, clientName);
        }
        else if(cardType.equals("APA"))
        {
        	loginPage.Login("SHLAPA_URL", "SHLAPA_UN_Customer_Admin_" + clientCountry, "SHLAPA_PWD_Customer_Admin_" + clientCountry, clientName);
        }
		homePage.ValidateLogoutLink();
		homePage.ValidateHelpShellLink();
		homePage.ValidateWelcomeText(clientName+"#"+cardType);
		homePage.ValidateQuickLinks();
		shellHomePage.ValidateHeaderMenus("Admin");
		shellHomePage.ValidateFooterMenus();
		
		// Select Account from Dropdown	
		shellHomePage.selectAccountFromDropdownAndValidate();
		
		// Select Customer Maintenance
		shellHomePage.goToAccountMenuCustomerMaintenance();
		shellAccountPage.validateCustomerMaintenancePage();
		
		// Check Account status is Disabled
		shellAccountPage.checkAccountStatusDisabledOrEnabled();
		loginPage.Logout();
	}
	
	@Parameters({"clientCountry","clientName", "cardType"})
	@Test(groups = { "Regression" })
	public void validateAccountStatusSubAccount(@Optional("AT") String clientCountry, @Optional("SHELL") String clientName, @Optional("APA") String cardType)  {
		
		test = extent.createTest(clientName+ ":" +clientCountry+"  23 Account Status Sub Account/ 24 Account Status Change sub Account ", "Check the Status of Sub Account");

		//Creating Objects for the Pages
        LoginPage loginPage = new LoginPage(driver, test);
        HomePage homePage = new HomePage(driver, test);
        SHELLHomePage shellHomePage = new SHELLHomePage(driver, test);
        SHELLAccountPage shellAccountPage = new SHELLAccountPage(driver, test);
        
        // Calling Login Functions And Validate
        if(cardType.equals("PC"))
        {
        	loginPage.Login("SHLPC_URL", "SHLPC_UN_Customer_Admin_" + clientCountry, "SHLPC_PWD_Customer_Admin_" + clientCountry, clientName);
        }
        else if(cardType.equals("APA"))
        {
        	loginPage.Login("SHLAPA_URL", "SHLAPA_UN_Customer_Admin_" + clientCountry, "SHLAPA_PWD_Customer_Admin_" + clientCountry, clientName);
        }
		homePage.ValidateLogoutLink();
		homePage.ValidateHelpShellLink();
		homePage.ValidateWelcomeText(clientName+"#"+cardType);
		homePage.ValidateQuickLinks();
		shellHomePage.ValidateHeaderMenus("Admin");
		shellHomePage.ValidateFooterMenus();
		
		// Select Account from Dropdown		
		shellHomePage.selectAccountFromDropdownAndValidate();
		
		// Select Customer Maintenance
		shellHomePage.goToAccountMenuCustomerMaintenance();
		shellAccountPage.validateCustomerMaintenancePage();
		
		// Check Account status is Disabled
		shellAccountPage.checkAccountStatusDisabledOrEnabled();
		
		// Next Test cases 24 Account Status Change sub Account
		shellAccountPage.selectAccountNameFromDropDown();
		
		// Need to add validations for the change status
		loginPage.Logout();
	}

	@Parameters({"clientCountry","clientName", "cardType"})
	@Test(groups = { "Regression" })
	public void validateContactsPage(@Optional("AT") String clientCountry, @Optional("SHELL") String clientName, @Optional("APA") String cardType)  {
		
		test = extent.createTest(clientName+ ":" +clientCountry+"  Shell AT Contacts Page", "Checking Contacts page");

		//String role = "Customer User";
        //Creating Objects for the Pages
        LoginPage loginPage = new LoginPage(driver, test);
        HomePage homePage = new HomePage(driver, test);
        SHELLHomePage shellHomePage = new SHELLHomePage(driver, test);
        SHELLAccountPage shellaccountPage = new SHELLAccountPage(driver, test);
      
		// Calling Functions
        if(cardType.equals("PC"))
        {
        	loginPage.Login("SHLPC_URL", "SHLPC_UN_Customer_Admin_" + clientCountry, "SHLPC_PWD_Customer_Admin_" + clientCountry, clientName);
        }
        else if(cardType.equals("APA"))
        {
        	loginPage.Login("SHLAPA_URL", "SHLAPA_UN_Customer_Admin_" + clientCountry, "SHLAPA_PWD_Customer_Admin_" + clientCountry, clientName);
        }
		homePage.ValidateLogoutLink();
		homePage.ValidateHelpShellLink();
		homePage.ValidateWelcomeText(clientName+"#"+cardType);
		homePage.ValidateQuickLinks();
		shellHomePage.ValidateHeaderMenus("Admin");
		shellHomePage.ValidateFooterMenus();
		shellHomePage.goToContactPage();
		shellaccountPage.exportContactList();
		shellaccountPage.invalidEmailValidation();
		shellaccountPage.validateBlankAddressPage();
		shellaccountPage.backtoContactList();
		if(clientCountry.equals("MY")) {
			shellaccountPage.clickAddContact();
			shellaccountPage.validatePhoneField();
		} else {
			shellaccountPage.clickAddContact();
		    shellaccountPage.addAndSaveContact();
		}
		loginPage.Logout();
	}

	@Parameters({"clientCountry","clientName", "cardType"})
	@Test(groups = { "Regression" })
	public void validateAccountMenuCardGroups(@Optional("AT") String clientCountry, @Optional("SHELL") String clientName,@Optional("APA") String cardType )  {
		
		test = extent.createTest(clientName+ ":" +clientCountry+"  05 Card Groups", "Check the Card Groups");

		//Creating Objects for the Pages
        LoginPage loginPage = new LoginPage(driver, test);
        HomePage homePage = new HomePage(driver, test);
        SHELLHomePage shellHomePage = new SHELLHomePage(driver, test);
        SHELLAccountPage shellAccountPage = new SHELLAccountPage(driver, test);
        
        // Calling Login Functions And Validate
        if(cardType.equals("PC"))
        {
        	loginPage.Login("SHLPC_URL", "SHLPC_UN_Customer_Admin_" + clientCountry, "SHLPC_PWD_Customer_Admin_" + clientCountry, clientName);
        }
        else if(cardType.equals("APA"))
        {
        	loginPage.Login("SHLAPA_URL", "SHLAPA_UN_Customer_Admin_" + clientCountry, "SHLAPA_PWD_Customer_Admin_" + clientCountry, clientName);
        }
		homePage.ValidateLogoutLink();
		homePage.ValidateHelpShellLink();
		homePage.ValidateWelcomeText(clientName+"#"+cardType);
		homePage.ValidateQuickLinks();
		shellHomePage.ValidateHeaderMenus("Admin");
		shellHomePage.ValidateFooterMenus();
		
		// Select Customer Maintenance
		shellHomePage.goToAccountMenuCardGroups();
		shellAccountPage.validateCardGroupsSearchPage();
		
		shellAccountPage.clickSearchBtn();
		boolean isNoCardsGroupPresent = shellAccountPage.waitForTextToAppear("No Card Groups found.", 30);
		if(!isNoCardsGroupPresent)
		{			
			String getCardNumber = shellAccountPage.clickAddCardGroupAndValidate();
			
			shellAccountPage.clickBackToCardGrpListAndValidate();
			
			shellAccountPage.clickSearchBtnAndValidateCardGrp(getCardNumber);
		}
		// Depend on IFCS based on environment need to configure	
		loginPage.Logout();
	}
	
	@Parameters({"clientCountry","clientName", "cardType"})
	@Test(groups = { "Regression" })
	public void validateTheFundTransferCardToCard(@Optional("AT") String clientCountry, @Optional("SHELL") String clientName, @Optional ("APA") String cardType)  {
		
		test = extent.createTest(clientName+ ":" +clientCountry+"  08 Funds Transfer Card To Card", "Funds transfer Card to Card");		
        //Creating Objects for the Pages
        LoginPage loginPage = new LoginPage(driver, test);
        HomePage homePage = new HomePage(driver, test);
        SHELLHomePage shellHomePage = new SHELLHomePage(driver, test);
        SHELLAccountPage accountPage = new SHELLAccountPage(driver, test);
      
		// Calling Functions
        if(cardType.equals("PC"))
        {
        	loginPage.Login("SHLPC_URL", "SHLPC_UN_Customer_Admin_" + clientCountry, "SHLPC_PWD_Customer_Admin_" + clientCountry, clientName);
        }
        else if(cardType.equals("APA"))
        {
        	loginPage.Login("SHLAPA_URL", "SHLAPA_UN_Customer_Admin_" + clientCountry, "SHLAPA_PWD_Customer_Admin_" + clientCountry, clientName);
        }
		homePage.ValidateLogoutLink();
		homePage.ValidateHelpShellLink();
		homePage.ValidateWelcomeText(clientName+"#"+cardType);
		homePage.ValidateQuickLinks();
		shellHomePage.ValidateHeaderMenus("Admin");
		shellHomePage.ValidateFooterMenus();
		shellHomePage.goToAccountMenuFundTransfer(); 
		accountPage.verifyFundTransferPageIsLoaded();		
		accountPage.verifyCardToCardDetails();
		loginPage.Logout();
      
	}
	
	@Parameters({"clientCountry","clientName", "cardType"})
	@Test(groups = { "Regression" })
	public void validateTheFundTransferAccountToCard(@Optional("AT") String clientCountry, @Optional("SHELL") String clientName, @Optional("APA") String cardType)  {
		
		test = extent.createTest(clientName+ ":" +clientCountry+"  07 Funds Transfer Parent Account To Child Card", "Funds transfer Account to Card");		
        //Creating Objects for the Pages
        LoginPage loginPage = new LoginPage(driver, test);
        HomePage homePage = new HomePage(driver, test);
        SHELLHomePage shellHomePage = new SHELLHomePage(driver, test);
        SHELLAccountPage accountPage = new SHELLAccountPage(driver, test);
      
		// Calling Functions
        if(cardType.equals("PC"))
        {
        	loginPage.Login("SHLPC_URL", "SHLPC_UN_Customer_Admin_" + clientCountry, "SHLPC_PWD_Customer_Admin_" + clientCountry, clientName);
        }
        else if(cardType.equals("APA"))
        {
        	loginPage.Login("SHLAPA_URL", "SHLAPA_UN_Customer_Admin_" + clientCountry, "SHLAPA_PWD_Customer_Admin_" + clientCountry, clientName);
        }
		homePage.ValidateLogoutLink();
		homePage.ValidateHelpShellLink();
		homePage.ValidateWelcomeText(clientName+"#"+cardType);
		homePage.ValidateQuickLinks();
		shellHomePage.ValidateHeaderMenus("Admin");
		shellHomePage.ValidateFooterMenus();
		shellHomePage.goToAccountMenuFundTransfer(); 
		accountPage.verifyFundTransferPageIsLoaded();		
		accountPage.verifyAccountToCardDetails();
		loginPage.Logout();
     
	}
	
	
	// Added by Ayub 19.06.2018		
	
	@Parameters({"clientCountry","clientName", "cardType"})
	@Test(groups = { "Regression" })
	public void validateAccountMenuDriver(@Optional("AT") String clientCountry, @Optional("SHELL") String clientName, @Optional ("APA") String cardType )  {
		
		test = extent.createTest(clientName+ ":" +clientCountry+"  03 Driver", "Check the Driver List");

		//Creating Objects for the Pages
        LoginPage loginPage = new LoginPage(driver, test);
        HomePage homePage = new HomePage(driver, test);
        SHELLHomePage shellHomePage = new SHELLHomePage(driver, test);
        SHELLAccountPage shellAccountPage = new SHELLAccountPage(driver, test);
        
        // Calling Login Functions And Validate
        if(cardType.equals("PC"))
        {
        	loginPage.Login("SHLPC_URL", "SHLPC_UN_Customer_Admin_" + clientCountry, "SHLPC_PWD_Customer_Admin_" + clientCountry, clientName);
        }
        else if(cardType.equals("APA"))
        {
        	loginPage.Login("SHLAPA_URL", "SHLAPA_UN_Customer_Admin_" + clientCountry, "SHLAPA_PWD_Customer_Admin_" + clientCountry, clientName);
        }
		homePage.ValidateLogoutLink();
		homePage.ValidateHelpShellLink();
		homePage.ValidateWelcomeText(clientName+"#"+cardType);
		homePage.ValidateQuickLinks();
		shellHomePage.ValidateHeaderMenus("Admin");
		shellHomePage.ValidateFooterMenus();
		
		// Select Customer Maintenance
		shellHomePage.goToAccountMenuDriversPage();
		shellAccountPage.validateDriversPage();
		shellAccountPage.selectAllAccountsAndValidate();
		boolean isDriverListPresentorNot =  shellAccountPage.verifyDriverListDataIsAvailable();
		if(isDriverListPresentorNot)
		{
			shellAccountPage.printNoDriverListPresent();
		} else {
			shellAccountPage.setCellDataFromDriverTable(6);
			shellAccountPage.serachCardAndExportDriverList();
		}
		
		loginPage.Logout();
	}
	
	// Added by Ayub 19.06.2018		
	
		@Parameters({"clientCountry","clientName", "cardType"})
		@Test( groups = { "Regression" })
		public void validateAccountMenuVehicle(@Optional("AT") String clientCountry, @Optional("SHELL") String clientName, @Optional("APA") String cardType)  {
			
			test = extent.createTest(clientName+ ":" +clientCountry+"  04 Vehicle", "Check the Vehicle List");

			//Creating Objects for the Pages
	        LoginPage loginPage = new LoginPage(driver, test);
	        HomePage homePage = new HomePage(driver, test);
	        SHELLHomePage shellHomePage = new SHELLHomePage(driver, test);
	        SHELLAccountPage shellAccountPage = new SHELLAccountPage(driver, test);
	        
	        // Calling Login Functions And Validate
	        if(cardType.equals("PC"))
	        {
	        	loginPage.Login("SHLPC_URL", "SHLPC_UN_Customer_Admin_" + clientCountry, "SHLPC_PWD_Customer_Admin_" + clientCountry, clientName);
	        }
	        else if(cardType.equals("APA"))
	        {
	        	loginPage.Login("SHLAPA_URL", "SHLAPA_UN_Customer_Admin_" + clientCountry, "SHLAPA_PWD_Customer_Admin_" + clientCountry, clientName);
	        }
			homePage.ValidateLogoutLink();
			homePage.ValidateHelpShellLink();
			homePage.ValidateWelcomeText(clientName+"#"+cardType);
			homePage.ValidateQuickLinks();
			shellHomePage.ValidateHeaderMenus("Admin");
			shellHomePage.ValidateFooterMenus();
			
			// Select Customer Maintenance
			shellHomePage.goToAccountMenusVechilesPage();
			shellAccountPage.validateVehiclesPage();
			shellAccountPage.selectAllAccountsFormAccontNumberDropdown();
			
			boolean isVehicleListPresentorNot =  shellAccountPage.verifyVehilceListDataIsAvailable();
			
			if(isVehicleListPresentorNot)
			{
				shellAccountPage.printNoVehilceListPresent();
			} else {
			shellAccountPage.setCellDataFromVehilceTable(6);
     		shellAccountPage.serachCardAndExportVehicleList();
			}
			
		loginPage.Logout();
		}
		// Added by Ayub 20.06.2018
		
		@Parameters({"clientCountry","clientName", "cardType"})
		@Test( groups = { "Regression" })
		public void validateTheFundTransferCardToCardAutoComplete(@Optional("AT") String clientCountry, @Optional("SHELL") String clientName, @Optional("APA") String cardType)  {
			
			test = extent.createTest(clientName+ ":" +clientCountry+"  Funds Transfer Card To Card Autocomplete", "Funds transfer Card to Card");		
	        //Creating Objects for the Pages
	        LoginPage loginPage = new LoginPage(driver, test);
	        HomePage homePage = new HomePage(driver, test);
	        SHELLHomePage shellHomePage = new SHELLHomePage(driver, test);
	        SHELLAccountPage accountPage = new SHELLAccountPage(driver, test);
	      
			// Calling Functions
	        if(cardType.equals("PC"))
	        {
	        	loginPage.Login("SHLPC_URL", "SHLPC_UN_Customer_Admin_" + clientCountry, "SHLPC_PWD_Customer_Admin_" + clientCountry, clientName);
	        }
	        else if(cardType.equals("APA"))
	        {
	        	loginPage.Login("SHLAPA_URL", "SHLAPA_UN_Customer_Admin_" + clientCountry, "SHLAPA_PWD_Customer_Admin_" + clientCountry, clientName);
	        }
			homePage.ValidateLogoutLink();
			homePage.ValidateHelpShellLink();
			homePage.ValidateWelcomeText(clientName+"#"+cardType);
			homePage.ValidateQuickLinks();
			shellHomePage.ValidateHeaderMenus("Admin");
			shellHomePage.ValidateFooterMenus();
			shellHomePage.goToAccountMenuFundTransfer(); 	
			
			// validate the Fund Transfer Page
			accountPage.verifyFundTransferPageIsLoaded();	
			// Select the Card to Card and validate the ToCard and FromCard
			accountPage.selectCardToCard();
			loginPage.Logout();
	      
		}
	
		@Parameters({"clientCountry","clientName", "cardType"})
		@Test( groups = { "Regression" })
		public void validateTheAccountCustomerMaintenance(@Optional("AT") String clientCountry, @Optional("SHELL") String clientName, @Optional("APA") String cardType)  {
			
			test = extent.createTest(clientName+ ":" +clientCountry+"  01 Account - CustomerMaintenance", "Validate the Account - Customer Maintenance");		
	        //Creating Objects for the Pages
	        LoginPage loginPage = new LoginPage(driver, test);
	        HomePage homePage = new HomePage(driver, test);
	        SHELLHomePage shellHomePage = new SHELLHomePage(driver, test);
	        SHELLAccountPage shellAccountPage = new SHELLAccountPage(driver, test);
	        SHELLAccountMaintenancePage shellCusMaintenancePage = new SHELLAccountMaintenancePage(driver, test);
	      
			// Calling Functions
	        if(cardType.equals("PC"))
	        {
	        	loginPage.Login("SHLPC_URL", "SHLPC_UN_Customer_Admin_" + clientCountry, "SHLPC_PWD_Customer_Admin_" + clientCountry, clientName);
	        }
	        else if(cardType.equals("APA"))
	        {
	        	loginPage.Login("SHLAPA_URL", "SHLAPA_UN_Customer_Admin_" + clientCountry, "SHLAPA_PWD_Customer_Admin_" + clientCountry, clientName);
	        }
	        
			homePage.ValidateLogoutLink();
			homePage.ValidateHelpShellLink();
			homePage.ValidateWelcomeText(clientName+"#"+cardType);
			homePage.ValidateQuickLinks();
			shellHomePage.ValidateHeaderMenus("Admin");
			shellHomePage.ValidateFooterMenus();
			//Get the Default customer name
			shellHomePage.verifyCustomerNameInHomePage();
			String customerName = shellHomePage.getCustomerName();
			shellHomePage.selectAccountFromDropdownAndValidate();			
			
			// Select Customer Maintenance
			shellHomePage.goToAccountMenuCustomerMaintenance();
			shellAccountPage.validateCustomerMaintenancePage();
			shellCusMaintenancePage.verifyTheAccountName(customerName);
			shellCusMaintenancePage.changeThePreferredLangAndValidate();
			shellCusMaintenancePage.validateTheFiledsAreDisabledOrNot();
			shellCusMaintenancePage.validateTheContactsList();
			
			loginPage.Logout();
	      
		}

	}
