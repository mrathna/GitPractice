package com.framework.testcases.API;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.common.IFCSLoginPage;
import com.framework.pages.API.common.LocationAPIMethods;
import com.framework.util.PropUtils;

public class ValidateCreateAndUpdateLocation extends BaseTest {

	@Parameters({ "clientCountry", "clientName", "locationNo", "locationType", "marketingTerritory" })
	@Test( groups = { "BusinessFlow" })
	public void createNewLocation(@Optional("AU") String clientCountry, @Optional("BP") String clientName,
			@Optional("random") String locationNo, @Optional("random") String locationType,
			@Optional("random") String marketingTerritory) {
		test = extent.createTest(clientName + ":" + clientCountry + "  Create Location ",
				"Create new location via API ");

		LocationAPIMethods locationAPIMethods = new LocationAPIMethods(driver, test);
		IFCSLoginPage ifcsLoginPage = new IFCSLoginPage(driver, test);

		ifcsLoginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");

		ifcsLoginPage.logInfo("Client country ::::" + clientCountry);
		ifcsLoginPage.logInfo("Client Name ::::" + clientName);

		locationAPIMethods.loginToAPIUser(
				PropUtils.getPropValue(configProp, "UserNameAPI" + "_" + clientName + "_" + clientCountry),
				PropUtils.getPropValue(configProp, "PassWordAPI" + "_" + clientName + "_" + clientCountry));
		locationAPIMethods.locationCreation(clientCountry, locationNo, locationType, marketingTerritory);
		locationAPIMethods.logoutAPIUser();

	}

	@Parameters({ "clientCountry", "clientName", "locationNo", "fieldName", "value", "interfaceType" })
	@Test( groups = { "BusinessFlow" })
	public void updateLocationComponent(@Optional("AU") String clientCountry, @Optional("BP") String clientName,
			@Optional("ramdom") String locationNo, @Optional("ramdom") String fieldName,
			@Optional("ramdom") String value, @Optional("API") String interfaceType) {

		test = extent.createTest(clientName + ":" + clientCountry + "  Update location",
				"Update location via API for " + "_" + locationNo);
		LocationAPIMethods locationAPIMethods = new LocationAPIMethods(driver, test);
		IFCSLoginPage ifcsLoginPage = new IFCSLoginPage(driver, test);
		ifcsLoginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		locationAPIMethods.loginToAPIUser(
				PropUtils.getPropValue(configProp, "UserNameAPI" + "_" + clientName + "_" + clientCountry),
				PropUtils.getPropValue(configProp, "PassWordAPI" + "_" + clientName + "_" + clientCountry));
		locationAPIMethods.updateLocation(locationNo, fieldName, value);
		locationAPIMethods.logoutAPIUser();
	}
}
