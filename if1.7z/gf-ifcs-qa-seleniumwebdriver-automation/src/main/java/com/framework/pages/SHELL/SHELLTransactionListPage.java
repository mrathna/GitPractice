package com.framework.pages.SHELL;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.ExtentTest;
import com.framework.basepage.BasePage;
import com.framework.repo.Locator;

public class SHELLTransactionListPage extends BasePage{
	
	
	@FindBy(id = Locator.EXPORT_BATCHES)
	public WebElement exportButton;	
	
	@FindBy(id=Locator.SEARCH_BTN)
	public WebElement searchButton;
	
	@FindBy(id=Locator.TRANSACTION_TABLE)
	public WebElement transactionTable;
	
	@FindBy(xpath = Locator.TRANSACTION_TABLE_CONTENT)
	public WebElement transactionTableContent;
	
	@FindBy(xpath = Locator.TRANSACTION_LIST_TABLE)
	public WebElement transactionListTable;	
	
	@FindBy(xpath = Locator.TRANSACTION_TABLE_ACC_NUMBER_LIST)
	public List<WebElement> transactionTableAccNumberList;	
	
	
	@FindBy(id=Locator.ACCOUNT_SEL)
	public WebElement accountTransactionSel;
	
	@FindBy(id=Locator.FROM_DATE)
	public WebElement fromDate;
	
	
	@FindBy(xpath=Locator.DETAILSUBMENU)
	public WebElement detailSubMenu;
	
	
	@FindBy(xpath=Locator.RETURN_TO_TRANSACTION_LIST)
	public WebElement backToTraList;
	
	private String getProduct = "";
	public SHELLTransactionListPage(WebDriver driver, ExtentTest test) {
		super(driver, test);
		PageFactory.initElements(driver, this);
	}

	

	/*
	 * validateTheTransactionListPage
	 * Added by Anton
	 */
	
	public void validateTheTransactionListPage() {
		// TODO Auto-generated method stub
		
		checkTextInPageAndValidate("Transaction List", 30);
		checkTextInPageAndValidate("Use filter fields to narrow search.", 30);
		isDisplayed(exportButton, "Export Button");
					
	}
	
	public boolean clickTheExport()
	{
		boolean isTransactionPresent = false; 
		
		//sleep(2);
		
		boolean istransactionsNotPresent = waitForTextToAppear("No Transactions found.", 20);
		
		if(istransactionsNotPresent)
		{ 
			
			isDisplayed(fromDate, "Transaction Date From in transaction List");
			
			String newDate = getNewDate(fromDate,3);
			
			isDisplayedThenEnterText(fromDate, "Transaction Date From", newDate);
			
			sleep(3);
			
			isDisplayedThenClick(searchButton, "Search Button");
			
			sleep(5);
			
			istransactionsNotPresent = waitForTextToAppear("No Transactions found.", 20);
			
			if(istransactionsNotPresent)
			{
			
				logInfo("There are no transactions present for the transaction Date from mentioned in your search.");
			}
			
			else
			{
				isTransactionPresent = true;
				
				isDisplayedThenClick(exportButton, "Export the transactions");
				
				sleep(10);
			}
		}
		
		else
		{
			isTransactionPresent = true;
			
			isDisplayedThenClick(exportButton, "Export the transactions");
			
			sleep(10);
		}
		
		return isTransactionPresent;
		
	}
	
	public void clickTransactionListSearchButtonAndValidate() {
		isDisplayedThenActionClick(searchButton, "Click Search Button");
		isDisplayed(transactionTableContent, "Check Transaction tabel is Present");
	}
	
/*	public void validateNonPurchaseTransaction() {
		setCellDataFromTable(transactionListTable, 9, false);
		List<WebElement> rowElements =  transactionListTable.findElements(By.xpath("./tbody[contains(@id,'lform:tableTransList:tb')]/tr"));
	    System.out.println("***Row Element Size**"+rowElements.size());
		//	int cardNumberListSize = transactionTableAccNumberList.size();
		for (int j = 0; j < rowElements.size(); j++) {		
			boolean searchResultEmepty = waitForTextToAppear("No Transactions found.",30);
			if(!searchResultEmepty) {
				getProduct = getCellDataFromTable(j+1, 5, false);
				System.out.println(getProduct);
				if ("".equals(getProduct)) {
					logPass("Product is Non Purchase Transaction");					
				} else {
					logInfo("Its Purchase Transaction");					
				}
			} else {
				logInfo("No Search Result");
				break;
			}
			
		}
	}*/
	
	
	public void validateNonPurchaseTransaction() 
	{
		sleep(5);
		setCellDataFromTable(transactionListTable, 9, false);
		List<WebElement> rowElements = transactionListTable
				.findElements(By.xpath("./tbody[contains(@id,'lform:tableTransList:tb')]/tr"));
		System.out.println("***Row Element Size**" + rowElements.size());
		// int cardNumberListSize = transactionTableAccNumberList.size();
		boolean searchResultEmepty = waitForTextToAppear("No Transactions found.", 20);
		if (!searchResultEmepty) 
		{
			for (int j = 0; j < rowElements.size(); j++) 
			{

				getProduct = getCellDataFromTable(j + 1, 5, false);
				System.out.println(getProduct);
				if ("".equals(getProduct)) {
					logPass("Product is Non Purchase Transaction");
				} else {
					logInfo("Its Purchase Transaction");
				}
			}
		} else {
			logInfo("No Search Result");
		
		}

	}

	
	
	
	// Added by Anton 23.07.2018

		public void selectAllAccountsAndSearch() {

			selectDropDownByVisibleText(accountTransactionSel, "All Accounts");
			
			sleep(2);
			
			isDisplayedThenClick(searchButton, "Search button");
			
			sleep(5);
			
		}
		
		
	//Added by anton 23.07.2018
		
	public void setTransactionsData() {
		
		isDisplayed(transactionTable, "Transactions table");
		sleep(5);
		setCellDataFromTable(transactionTable, 9, true);
		sleep(5);
	}
	
	public String getAccountNameFromTheTransactions()
	{
		String accName="";
		
		
		accName = getCellDataFromTable(1, 1, true);		
		
		
		System.out.println("------ accName -------"+accName);
		
		
		return accName;
	}

	
	/*
	 * From transaction go to Transaction Details Page
	 * Added by Anton
	 */

	public void goToTransactionDetailPageAndValidate() {
		// TODO Auto-generated method stub
		
		isDisplayed(transactionListTable, "Transaction List Table");	 
		
		selectFirstColumnAndChooseMenu(transactionListTable, detailSubMenu, "TRANSACTION DETAIL", true);
		
		sleep(3);
		
		/*checkTextInPageAndValidate("Account Name", 20);
		
		checkTextInPageAndValidate("Account Number", 20);
		*/
		checkTextInPageAndValidate("Card Number", 20);
		
		checkTextInPageAndValidate("Transaction Date", 20);
		
		checkTextInPageAndValidate("Total", 20);
		
		//checkTextInPageAndValidate("Reference", 20);
		
		checkTextInPageAndValidate("Transaction Type Description", 20);
		
		checkTextInPageAndValidate("Process Date", 20);
		
		checkTextInPageAndValidate("GST Total", 20);
		
		checkTextInPageAndValidate("Total Fees", 20);
		
		//checkTextInPageAndValidate("Transaction Notes", 20);
		
	}


	/*
	 * This method for the Back to Transaction List Page.
	 * 
	 */
	public void backToTransactionListPage() {
		 
		isDisplayedThenClick(backToTraList, "Back To Transaction List");
		
		sleep(3);
		
		checkTextInPageAndValidate("Transaction List", 30);
		
		checkTextInPageAndValidate("Use filter fields to narrow search.", 30);
	}
		
	
	
}
