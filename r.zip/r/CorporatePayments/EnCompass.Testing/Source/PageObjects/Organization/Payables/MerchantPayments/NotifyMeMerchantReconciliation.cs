﻿using Common.Utility;
using EnCompass.Testing.Source.PageObjects.Controls;
using NFluent;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EnCompass.Testing.Source.PageObjects.Organization.Payables.MerchantPayments
{
    public partial class NotifyMeMerchantReconciliation
    {
		//Had to change the Xpth Override to an index based value
        public override string PageIdentifierXPath_Override => @"//li[contains(@class, 'breadcrumb-item')][4]";

        #region XPath page Elements
        private const string _searchCategoryXPath = @"//select[contains(@id, 'searchTermSelect')]";
        private const string _searchTermFilterXPath = @"//select[contains(@id, 'searchTermFilter')]";
        private const string _searchCriteriaTermXPath = @"//div[contains(@id, 'SearchOutput')]/input[1]";
        private const string _searchCriteriaClearBtnXPath = @"//button[@type='button' and normalize-space(text())='Clear']";
        private const string _searchCriteriaAddBtnXPath = @"//input[@type='button' and @value='Add']";
        private const string _searchXPath = @"//input[contains(@id, 'btnSearch')]";
        #endregion

        #region Page Elements

        public IWebElement _searchCategory
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_searchCategoryXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_searchCategory element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _searchTermFilter
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_searchTermFilterXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_searchTermFilter element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _searchCriteriaTerm
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_searchCriteriaTermXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_searchCriteriaTerm element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _searchCriteriaClearBtn
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_searchCriteriaClearBtnXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_searchCriteriaClearBtn element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _searchCriteriaAddBtn
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_searchCriteriaAddBtnXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_searchCriteriaAddBtn element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _search
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_searchXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_search element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        #endregion


        public void ClearSearchFilter()
        {
            _searchCriteriaClearBtn.JSClickWithFocus(Driver);
        }
        public void Add()
        {
            _searchCriteriaAddBtn.JSClickWithFocus(Driver);
        }

        public void Search()
        {
            _search.JSClickWithFocus(Driver);
            WaitForLoad();
        }

        public void SetSearchCategory(string whichText)
        {
            var selectElement = new SelectElement(_searchCategory);
            selectElement.SelectByText(whichText);
        }

        public string SearchCriteriaTextSearchTerm
        {
            set
            {
                _searchCriteriaTerm.SendKeys(value);
            }
        }

        private GridControl _mGrid;
        public GridControl MerchantsGrid
        {
            get
            {
                GridControl grid = _mGrid ?? (_mGrid = new GridControl("gvMerchants", Driver));
                grid.WaitForGrid();
                return grid;
            }
        }

        private GridControl _mlGrid;
        public GridControl MLogGrid
        {
            get
            {
                GridControl grid = _mlGrid ?? (_mlGrid = new GridControl("gvMerchantLog", Driver));
                grid.WaitForGrid();
                return grid;
            }
        }

		private GridControl _umtGrid;
		public GridControl UnMatchedTransactionsGrid
		{
			get
			{
				GridControl grid = _umtGrid ?? (_umtGrid = new GridControl("gvCandidateTransactions", Driver));
				grid.WaitForGrid();
				return grid;
			}
		}


		public void ExpandMatchedSection()
		{
			IWebElement _nToggle = Driver.WaitFor(By.XPath(".//button[@data-toggle='collapse' and contains(@aria-controls,'phMatchedTransactions')]"));
			Boolean isExpanded = (_nToggle.GetAttribute("aria-expanded").Equals("true")) ? true : false;
			if (!isExpanded)
				_nToggle.JSClickWithFocus(Driver);
			this.RefreshModel();
		}

		private GridControl _mtGrid;
        public GridControl MatchedTransactionsGrid
        {
            get
            {
                GridControl grid = _mtGrid ?? (_mtGrid = new GridControl("gvMatchedTransactions", Driver));
                grid.WaitForGrid();
                return grid;
            }
        }

        public void SelectReconcileOnSave()
        {
            IWebElement reconcileOnSaveCheckbox = Driver.FindElement(By.XPath("//input[contains(@id,'chkReconcileOnSave')]"));
            reconcileOnSaveCheckbox.SetCheckboxStateWithLabel(null, true);

            Driver.FindElement(By.XPath("//input[contains(@id,'btnSave')]")).JSClickWithFocus(Driver);
        }

		public void SaveWithoutReconcileOnSave()
		{
			Settings.EnCompassWebDriver.WaitForVisible(By.XPath("//input[contains(@id,'btnSave')]")).JSClickWithFocus(Driver);
			this.AttachOnDemandScreenShot();
		}

		/// <summary>
		/// Search a specific MLog
		/// </summary>
		public void SearchMLog(string searchTerm, string searchVal)
        {
            ClearSearchFilter();
            SetSearchCategory(searchTerm);
            RefreshModel();
            SearchCriteriaTextSearchTerm = searchVal;
            Add();
            Search();
            RefreshModel();
        }        
    }
}
