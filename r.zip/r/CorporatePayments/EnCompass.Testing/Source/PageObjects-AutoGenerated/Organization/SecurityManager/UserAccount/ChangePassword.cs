using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using Common;
using Common.PageObjects;
using Common.ScenarioConfigurations;
using Common.Utility;

namespace EnCompass.Testing.Source.PageObjects.Organization.SecurityManager.UserAccount 
{
	/// <summary>
	/// Auto-generated Page Model Class
	/// Navigation Paths: 
		/// [Organization Home]->UserAccount->->Login Credentials
		/// </summary>
	[PageModel(@"/securityManager/userAccount/changePassword.aspx")]
	public partial class ChangePassword : EnCompassOrgPageModel 
	{
		public override string RelativeUrl => @"/securityManager/userAccount/changePassword.aspx";
		public override string PageIdentifierXPath_Generated => @"//li[contains(@class, 'breadcrumb-item active')][text() = 'Login Credentials']";

		#region Navigation
				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Contact Information']")]
		private IWebElement _useraccount__LoginCredentials_ContactInformation { get; set; }
		public void NavigateTo_Useraccount__LoginCredentials_ContactInformation()
		{
			NavigateToMenuItem(_useraccount__LoginCredentials_ContactInformation);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Login Credentials']")]
		private IWebElement _useraccount__LoginCredentials_LoginCredentials { get; set; }
		public void NavigateTo_Useraccount__LoginCredentials_LoginCredentials()
		{
			NavigateToMenuItem(_useraccount__LoginCredentials_LoginCredentials);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Challenge Questions']")]
		private IWebElement _useraccount__LoginCredentials_ChallengeQuestions { get; set; }
		public void NavigateTo_Useraccount__LoginCredentials_ChallengeQuestions()
		{
			NavigateToMenuItem(_useraccount__LoginCredentials_ChallengeQuestions);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Preferences']")]
		private IWebElement _useraccount__LoginCredentials_Preferences { get; set; }
		public void NavigateTo_Useraccount__LoginCredentials_Preferences()
		{
			NavigateToMenuItem(_useraccount__LoginCredentials_Preferences);
		}

		
		private void NavigateToMenuItem(IWebElement element)
		{
			Driver.Url = element.GetAttribute("href");
		}
		#endregion

		public ChangePassword(GlobalSettings settings) : base(settings) { }
	}  
}
