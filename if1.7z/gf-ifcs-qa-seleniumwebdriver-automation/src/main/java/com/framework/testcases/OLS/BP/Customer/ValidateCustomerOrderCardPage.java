package com.framework.testcases.OLS.BP.Customer;

import java.util.Map;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.ClientGroupPage;
import com.framework.pages.AJS.common.Common;
import com.framework.pages.AJS.common.IFCSHomePage;
import com.framework.pages.AJS.common.IFCSLoginPage;
import com.framework.pages.BP.BPHomePage;
import com.framework.pages.BP.BPOrderCard;
import com.framework.pages.OLS.common.BPCommonPage;
import com.framework.pages.OLS.common.FindAndUpdateCardPage;
import com.framework.pages.OLS.common.LoginPage;

public class ValidateCustomerOrderCardPage extends BaseTest {

	String cardNumber;
	
	LoginPage loginPage;
	BPHomePage bpHomePage ;
	BPOrderCard bpOrderCard;
	BPCommonPage bpCommonPage;

	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "Smoke", "Regression" })

	public void validateCustomerCardOrder(@Optional("AU") String clientCountry, @Optional("BP") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  BP Customer Order Card Page", "Order Card Page");

		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		BPHomePage bpHomePage = new BPHomePage(driver, test);
		BPOrderCard bpOrderCard = new BPOrderCard(driver, test);
		BPCommonPage bpCommonPage = new BPCommonPage(driver, test);
		FindAndUpdateCardPage findAndUpdateCardPage = new FindAndUpdateCardPage(driver, test);

		// Calling Functions for Login
		if(clientName.equals("BP")) {
			loginPage.Login("BP_URL", "BP_UN_Customer_" + clientCountry, "BP_PWD_Customer_" + clientCountry, clientName);
		} else {
			loginPage.Login("BPPREPAID_URL", "BPPREPAID_UN_Customer_" + clientCountry, "BPPREPAID_PWD_Customer_" + clientCountry, clientName);
		}
		bpHomePage.ValidateBPCustomerLogo();
        String accountName=bpCommonPage.selectAccount();
		// Order New Card
		bpOrderCard.clickOrderCardAndValidatePage();
		bpOrderCard.orderCard("Driver");
		bpOrderCard.clickOrderCardAndValidatePage();
		bpOrderCard.orderCard("Vehicle");

		// Click and Validate Order a card page
		bpOrderCard.clickOrderCardAndValidatePage();

		// Click An Existing Card and validate popup
		bpOrderCard.clickExistingCardButton();
		bpOrderCard.validateExistingCardPopupDisplayed();
		bpOrderCard.selectAccountFromTheExistingPopup(accountName);
		// Click Search Button
		bpOrderCard.clickSearchButton();

		// Select the account and card status from popup
		String cardNumber = bpOrderCard.selectCardNumberAndGetText();
		bpOrderCard.selectAccountAndCardNumberStatusFromExistingCardPopup(cardNumber);
		
		bpOrderCard.clickSearchButton();
        
		// Click Card number and validate view page
		bpOrderCard.clickCardNumberFromSearchRecords();
		bpOrderCard.validateViewCardPopupDisplayed();
		bpOrderCard.clickCloseButtonAtViewCardPopup();

		// Select Radio button and Apply to New Card order
		bpOrderCard.clickRadioButtonFromSearchRecords();
		bpOrderCard.clickApplyToNewCardOrderButton();
		bpOrderCard.validateOrderCardPageDisplayed();

		// Click Vehicle Radio Button and Enter the Mandatory Fields
		bpOrderCard.clickVehicleRadioButton();
		bpOrderCard.enterVehicleDescription();
		bpOrderCard.enterRegoNumber();
		bpOrderCard.enterEmbossname();
		//bpOrderCard.selectDifferentProductRestriction();
		bpOrderCard.clickContinueButton();

		// Validate the UnusualActivityLimits page
		bpOrderCard.validateUnusualActivityLimitsHeader();
		bpOrderCard.clickContinueButton();

		// Validate the DeliveryAddress page
		bpOrderCard.validateDeliveryAddressHeader();
		bpOrderCard.clickContinueButton();

		// Validate the Place order Page
		bpOrderCard.validatePlaceOrderSubPage();
		bpOrderCard.clickOrderCardButton();
		bpOrderCard.validateSuccessMsgWithCardNumber(cardNumber);

		// Click SaveAs Configuration Profile Button
		bpOrderCard.clickSaveAsConfigurationProfileButton();
		bpOrderCard.validateSaveAsConfigProfilePopup();

		// Enter values and validate
		bpOrderCard.enterCardConfigProfileName();
		bpOrderCard.enterCardConfigProfileDesc();

		bpOrderCard.clickConfigProfileSaveButton();
		bpOrderCard.validateSuccessMessage();
		bpOrderCard.clickConfigProfileCloseBtn();
		bpOrderCard.validateOrderCardPageDisplayed();
		bpOrderCard.clickHomeMenuTab();
		bpHomePage.loadFindAndUpdateCardPage();

		// Search in Find Update Card Page
		findAndUpdateCardPage.selectAccountFromFindUpdateCardPage();
		findAndUpdateCardPage.clickSearchButtonInFindUpdateCardPage();
		findAndUpdateCardPage.iterateAndCheckCardNumberIsPresent(cardNumber);

		// Order Card - Saved Profile
		bpOrderCard.clickSavedProfile();
		
		loginPage.Logout(); 

	}

	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "Regression" })

	public void Edit_Card(@Optional("AU") String clientCountry, @Optional("BP") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  BP Edit Card", "Checking Edit Card Feature");

		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		BPHomePage bpHomePage = new BPHomePage(driver, test);
		BPOrderCard bpOrderAndEditCard = new BPOrderCard(driver, test);
		// Call Function
		if(clientName.equals("BP")) {
			loginPage.Login("BP_URL", "BP_UN_Customer_" + clientCountry, "BP_PWD_Customer_" + clientCountry, clientName);
		} else {
			loginPage.Login("BPPREPAID_URL", "BPPREPAID_UN_Customer_" + clientCountry, "BPPREPAID_PWD_Customer_" + clientCountry, clientName);
		}
		bpHomePage.ValidateBPCustomerLogo();

		// Load Find And Update Card Page
		bpHomePage.loadFindAndUpdateCardPage();

		// Search Cards
		bpOrderAndEditCard.clickSearchButton();

		bpOrderAndEditCard.pickActiveCardAndEdit();

		bpOrderAndEditCard.verifyEditCardPageTitle("Edit Card");

		if (clientCountry.equals("AU")) {

			bpOrderAndEditCard.choosePOSValuesInEditCard();
		}

		bpOrderAndEditCard.clickContinueButton();

		bpOrderAndEditCard.verifyEditCardPageTitle("Edit Card");

		bpOrderAndEditCard.validateUnusualActivityLimitsHeader();

		bpOrderAndEditCard.selectFuelTransactionCostDropdown();

		bpOrderAndEditCard.clickContinueButton();

		bpOrderAndEditCard.verifyEditCardPageTitle("Edit Card");

		bpOrderAndEditCard.validateDeliveryAddressHeader();

		bpOrderAndEditCard.clickReturnToUnusualActivity();

		bpOrderAndEditCard.clickContinueButton();

		bpOrderAndEditCard.verifyEditCardPageTitle("Edit Card");

		bpOrderAndEditCard.clickContinueButton();

		bpOrderAndEditCard.verifyEditCardPageTitle("Edit Card");

		bpOrderAndEditCard.clickOrderCardButton();

		bpOrderAndEditCard.validateSuccessMessageAfterEditCard();

		// Load Find And Update Card Page
		bpHomePage.loadFindAndUpdateCardPage();

		bpOrderAndEditCard.enterCardNumberInSearchFilter();

		// Search Cards
		bpOrderAndEditCard.clickSearchButton();

		bpOrderAndEditCard.pickActiveCardAndEdit();

		if (clientCountry.equals("AU")) {
			bpOrderAndEditCard.validatePOSValueChoosen();
		}

		bpOrderAndEditCard.clickContinueButton();

		bpOrderAndEditCard.verifyEditCardPageTitle("Edit Card");

		bpOrderAndEditCard.validateFuelTransactionCostDropdownValueChoosen();

		loginPage.Logout();
	}

	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "Regression" })

	public void verifyEditCardPages(@Optional("AU") String clientCountry, @Optional("BP") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  BP Edit Card", "Checking Edit Card Pages");

		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		BPHomePage bpHomePage = new BPHomePage(driver, test);
		BPOrderCard bpOrderAndEditCard = new BPOrderCard(driver, test);
		// Call Function
		if(clientName.equals("BP")) {
			loginPage.Login("BP_URL", "BP_UN_Customer_" + clientCountry, "BP_PWD_Customer_" + clientCountry, clientName);
		} else {
			loginPage.Login("BPPREPAID_URL", "BPPREPAID_UN_Customer_" + clientCountry, "BPPREPAID_PWD_Customer_" + clientCountry, clientName);
		}
		bpHomePage.ValidateBPCustomerLogo();

		// Load Find And Update Card Page
		bpHomePage.loadFindAndUpdateCardPage();

		// Search Cards
		bpOrderAndEditCard.clickSearchButton();

		bpOrderAndEditCard.pickActiveCardAndEdit();

		bpOrderAndEditCard.verifyEditCardPageTitle("Edit Card");

		bpOrderAndEditCard.validateFieldsOnEditCardInformationPage();

		// Check 1st page fields presence

		bpOrderAndEditCard.clickContinueButton();

		bpOrderAndEditCard.verifyEditCardPageTitle("Edit Card");

		bpOrderAndEditCard.validateUnusualActivityLimitsHeader();

		if (clientCountry.equals("AU")) {
			bpOrderAndEditCard.validateFieldsOnEditCardUnusualActivityPage(6);
		} else {
			bpOrderAndEditCard.validateFieldsOnEditCardUnusualActivityPage(7);
		}

		// Check 2nd page fields presence

		bpOrderAndEditCard.clickContinueButton();

		bpOrderAndEditCard.verifyEditCardPageTitle("Edit Card");

		bpOrderAndEditCard.validateDeliveryAddressHeader();

		bpOrderAndEditCard.validateFieldsOnEditCardDeliveryAddressPage();

		// Check 3rd page fields presence

		bpOrderAndEditCard.clickContinueButton();

		bpOrderAndEditCard.verifyEditCardPageTitle("Edit Card");

		bpOrderAndEditCard.validateFieldsOnEditCardReviewChangesPage();

		// Check 4th page fields presence

		bpOrderAndEditCard.clickOrderCardButton();

		loginPage.Logout();
	}
	
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "Regression","SIP" })
	public void performTransactionSearchnavigatingviaViewCardscreen_SIP(@Optional("AU") String clientCountry, @Optional("BP") String clientName){
        test = extent.createTest(clientName+ ":" +clientCountry+"  performTransactionSearchnavigatingviaViewCardscreen_SIP", "Validating existing cards");
		IFCSLoginPage ifcsLoginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage ifcsHomePage = new IFCSHomePage(driver, test);
		Common common = new Common(driver, test);
        ClientGroupPage clientGroupPage = new ClientGroupPage(driver,test);
		Map<String,String> customerDetails = clientGroupPage.readCustomerDetailsFromDB();
		String noOfTransactions = clientGroupPage.getTransactionCountFromDB(customerDetails.get("CARD_NO"));
        // Login to OLS application
		ifcsLoginPage.login("IFCS_URL_BP", "IFCS_BP_USERNAME", "IFCS_BP_PASSWORD");
        ifcsLoginPage.setClientCountryCardTypeDetails(clientName,clientCountry,"");
        ifcsHomePage.gotoAdminMenuAndChooseClientGroup();
        common.goToOnlineUsers();
        common.clickDetailSearchIfFilterFieldsNotPresent();
        ifcsHomePage.addingMemberInOnlineUsersIfNotPresent(customerDetails.get("CUSTOMER_NO"),"BPAUCustomer");
        ifcsHomePage.exitIFCS();
        loginPage = new LoginPage(driver, test);
        bpHomePage = new BPHomePage(driver, test);
        bpOrderCard = new BPOrderCard(driver, test);
        bpCommonPage = new BPCommonPage(driver, test);
        FindAndUpdateCardPage findAndUpdateCardPage = new FindAndUpdateCardPage(driver ,test);
        /*
        Login to OLS application with valid username and password
         */
        if(clientName.equals("BP")) {
            loginPage.Login("BP_URL", "BP_UN_Customer_" + clientCountry, "BP_PWD_Customer_" + clientCountry, clientName);
        } else {
            loginPage.Login("BPPREPAID_URL", "BPPREPAID_UN_Customer_" + clientCountry, "BPPREPAID_PWD_Customer_" + clientCountry, clientName);
        }
        bpHomePage.ValidateBPCustomerLogo();
        bpHomePage.loadFindAndUpdateCardPage();
        findAndUpdateCardPage.enterSearchCriteriaAndClickSearchCards(customerDetails.get("CARD_NO"),"All Accounts","--Select All--");
        bpOrderCard.clickExistingCardNumber();
        bpOrderCard.clickGoToCardButtonFirstCard();
		findAndUpdateCardPage.clickGoButtonInViewCardPage();
        findAndUpdateCardPage.validateTransactionCount("All Accounts","Last 3 calendar months",noOfTransactions);
	}
}
