using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using Common;
using Common.PageObjects;
using Common.ScenarioConfigurations;
using Common.Utility;

namespace EnCompass.Testing.Source.PageObjects.Organization.DecisionStream.AccountManagement 
{
	/// <summary>
	/// Auto-generated Page Model Class
	/// Navigation Paths: 
		/// [Organization Home]->Cards->Card Maintenance
		/// [Organization Home]->Cards->Card Maintenance->Cards
		/// </summary>
	[PageModel(@"/decisionStream/accountManagement/Main.aspx")]
	public partial class Main : EnCompassOrgPageModel 
	{
		public override string RelativeUrl => @"/decisionStream/accountManagement/Main.aspx";
		public override string PageIdentifierXPath_Generated => @"//li[contains(@class, 'breadcrumb-item active')][text() = 'Cards']";

		#region Navigation
				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Cards']")]
		private IWebElement _cards_CardMaintenance_Cards { get; set; }
		public void NavigateTo_Cards_CardMaintenance_Cards()
		{
			NavigateToMenuItem(_cards_CardMaintenance_Cards);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='History']")]
		private IWebElement _cards_CardMaintenance_History { get; set; }
		public void NavigateTo_Cards_CardMaintenance_History()
		{
			NavigateToMenuItem(_cards_CardMaintenance_History);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Activate Cards']")]
		private IWebElement _cards_CardMaintenance_ActivateCards { get; set; }
		public void NavigateTo_Cards_CardMaintenance_ActivateCards()
		{
			NavigateToMenuItem(_cards_CardMaintenance_ActivateCards);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Review Card Edits']")]
		private IWebElement _cards_CardMaintenance_ReviewCardEdits { get; set; }
		public void NavigateTo_Cards_CardMaintenance_ReviewCardEdits()
		{
			NavigateToMenuItem(_cards_CardMaintenance_ReviewCardEdits);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Create Test Cards']")]
		private IWebElement _cards_CardMaintenance_CreateTestCards { get; set; }
		public void NavigateTo_Cards_CardMaintenance_CreateTestCards()
		{
			NavigateToMenuItem(_cards_CardMaintenance_CreateTestCards);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Create Test Transactions']")]
		private IWebElement _cards_CardMaintenance_CreateTestTransactions { get; set; }
		public void NavigateTo_Cards_CardMaintenance_CreateTestTransactions()
		{
			NavigateToMenuItem(_cards_CardMaintenance_CreateTestTransactions);
		}

		
		private void NavigateToMenuItem(IWebElement element)
		{
			Driver.Url = element.GetAttribute("href");
		}
		#endregion

		public Main(GlobalSettings settings) : base(settings) { }
	}  
}
