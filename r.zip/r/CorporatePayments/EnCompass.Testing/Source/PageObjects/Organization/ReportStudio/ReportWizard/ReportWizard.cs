﻿using Common;
using Common.Utility;
using EnCompass.Testing.Source.PageObjects.Controls;
using NFluent;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace EnCompass.Testing.Source.PageObjects.Organization.ReportStudio.ReportWizard
{
	public partial class ReportWizard
	{
		public ReportWizard(GlobalSettings settings, ScheduleReport scheduleReport) : base(settings) { ScheduleReport = scheduleReport; }

        #region XPath page Elements

        public string SCHEDULE_REPORT_TITLE { get; } = "//h2//a[@name = 'Schedule']";
        public const string _hierarchyExplorerXPath = @"//div[contains(@id, 'hierachyExplorer') and @role='dialog']";
        public string loading_spinnerXpath = "//div[@class='fas fa-circle-notch fa-spin']";
        private const string _btnSelectXPath = @"//a[contains(@id,'dgReportFocuses')]";
        private const string _setFieldCategoriesXPath = @"//select[contains(@ id, 'lbxCategories')]";
        private const string _setAvailableFieldsXPath = @"//select[contains(@ id, 'lbxAvailableFields')]";
        private const string _selectedFieldsXPath = @"//select[contains(@ id, 'lbxSelectedFields')]";
        private const string _addFieldsBtnXPath = @"//input[contains(@ id, 'btnAddSelectFields')]";
        private const string _removeFieldsBtnXPath = @"//input[contains(@ id, 'btnRemoveSelectFields')]";
        private const string _mobilePhoneSelectedFieldsXPath = @"//select[contains(@ id, 'lbxSelectedFields')]/option[text()= 'Cardholder mobile phone']";
        private const string _filterTypeValueXPath = @"//select[contains(@id, 'searchTermFilter')]";
        private const string _searchTermValueXPath = @"//input[@id = 'ctl00_ctl00_content_contents_apcWizardContainer_pnlStep4_Step4AdvancedSearch_SearchOutput_txt']";
        private const string _addFilterBtnXPath = @"//input[contains(@id, 'addSingleValue')]";
        private const string _ddlStep6PeriodXPath = @"//select[contains(@id,'drgStep6_ddlPeriod')]";
        private const string _ddlStep6OptionsXPath = @"//select[contains(@id,'drgStep6_ddlOptions')]";
        private const string _nextStepBtnXPath = @"//input[contains(@id, 'btnNextStep')]";
        private const string _previousStepBtnXPath = @"//input[contains(@ id, 'btnPreviousStep')]";
        private const string _includeNonCardMlogsCheckBoxXPath = @"//input[contains(@id, 'noNodeLogsFilter')]";
        private const string _includeNonCardMlogsCheckBoxLabelXPath = @"//label[contains(@for, 'noNodeLogsFilter')]";
        private const string _submitReportBtnXPath = @"//input[contains(@ id, 'btnSubmit')]";
        private const string _viewDetailBtnXPath = @"//a[contains(@ id, 'actionLink0')]";
        private const string _viewDetailBackBtnXPath = @"//input[contains(@id, 'lbBack')][2]";
        private const string _backToReportBtnXPath = @"//input[contains(@ id, 'lbBackToReport')]";
        private const string _searchTermValueDDLXPath = @"//select[contains(@ id, 'SearchOutput_values')]";
        private const string _noCardHolderFoundMsgXPath = @"//table[contains(@id, 'dgResults')]//td[.='No Record: Cardholder Found']";
        private const string _progressLockXPath = @"//div[contains(@ id, 'upProgress')]']";
        private const string _runCheckboxXPath = "//input[contains(@id,'cbExecute') and @type='checkbox']";
        private const string _runCheckboxLabelXPath = @"//label[contains(@for,'cbExecute')]";
        private const string _saveCheckboxXPath = "//input[contains(@id,'cbSave') and @type='checkbox']";
        private const string _saveCheckboxLabelXPath = @"//label[contains(@for,'cbSave')]";
        private const string _scheduleCheckboxXPath = "//input[contains(@id,'cbSchedule') and @type='checkbox']";
        private const string _scheduleCheckboxLabelXPath = @"//label[contains(@for,'cbSchedule')]";
        private const string _txtReportNameXPath = @"//input[contains(@id,'txtReportName')]";
        private const string _ddlSaveLocationXPath = @"//select[contains(@id,'ddlSaveLocation')]";
        private const string _btnExportGridTextXPath = @"//input[contains(@id,'btnExportGridText')]";
        private const string _validationSummaryXPath = @"//div[contains(@id, 'vs')]//li";
        private const string _step6ValidationSummaryXPath = @"//div[contains(@id, 'Step6ValidationSummary')]//li";
        private const string _ddlFilterXPath = @"//select[contains(@id, 'ddlStep6InrinsicFields')]";
        private const string _txtPageSizeXPath = @"//input[contains(@id, 'txtPageSize')]";
        private const string _txtReportDescriptionXPath = @"//textarea[contains(@id, 'txtReportDescription')]";
        private const string _ddlExportTypeXPath = @"//select[contains(@id, 'ddlExportType')]";
        private const string _searchTermStep4XPath = @"//select[contains(@id,'searchTermSelect')]";
        private const string _cbxAllowFilterChangeAtRuntimeXPath = @"//input[contains(@id, 'cbxAllowFilterChangeAtRuntime')]";
        private const string _ddlStep6SearchTermXPath = @"//select[contains(@id,'searchTermSelect')]";
        private const string _ddlStep6SearchFilterTypeXPath = @"//select[contains(@id,'searchTermFilter')]";
        private const string _txtStep6SearchFilterValueXPath = @"//div[contains(@id,'Step6_SearchOutput')]//input[contains(@id,'SearchOutput')]";
        private const string _btnStep6SearchFilterAddXPath = @"//input[contains(@id,'addSingleValue') and contains(@value,'Add')]";
        private const string _btnStep6SearchFilterResetXPath = @"//button[@type='button' and contains(@title,'Remove')]";
        private const string _searchCriteriaRowsXPath = @"//div[contains(@id,'apcWizardContainer')]/ul/li";
        private const string _removeReportConfirmModalBtnXPath = @"//button[text()= 'Confirm']";
        private const string _btnFindCardHierarchyXPath = @"//a[contains(@id, 'cardHierarchyExplorer')]";
        private const string _btnModalToggleSelectAllXPath = @"//button[@data-orggroupselectall= 'true']";
        private const string _topHierarchyCheckBoxXPath = @"//div[contains(@id, 'hierachyExplorer')]//input[contains(@class,'custom-control-input')][1]";
        private const string _topHierarchyCheckBoxLabelXPath = @"//div[contains(@id, 'hierachyExplorer')]//label[contains(@class,'custom-control-label')][1]";
        private const string _finishButtonXPath = (_hierarchyExplorerXPath + "//button[contains(@id, 'finish')]");
        private const string _orggroupselectallXPath = @"//button[@data-orggroupselectall = 'true']";
        private const string _ddlStep6InrinsicFieldsXPath = @"//select[contains(@id,'ddlStep6InrinsicFields')]";
        private const string _exportBtnXPath = @"//input[contains(@name,'btnExportGridText') and @type='submit']";
        private const string _loadingoverlayXPath = "//div[contains(@class, 'loadingoverlay')]";
        private const string _gridNoRecordsMessageXPath = ".//td[contains(@class,'gridNoRecordsMessage')]";
        private const string _txtPasswordConfirmXPath = @"//input[contains(@id,'txtPasswordConfirm')]";
        private const string _txtPasswordXPath = @"//input[contains(@id,'txtPassword')]";
        private static string reportStudioMenuXPath = "//a[@id = 'reportStudioMenuHref']";
        #endregion

        #region Page Elements

        public ScheduleReport ScheduleReport { get; set; }

		private IWebElement _btnSelect
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_btnSelectXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_btnSelect element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

		private IWebElement _setFieldCategories
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_setFieldCategoriesXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_setFieldCategories element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _setAvailableFields
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_setAvailableFieldsXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_setAvailableFields element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _selectedFields
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_selectedFieldsXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_selectedFields element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _addFieldsBtn
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_addFieldsBtnXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_addFieldsBtn element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _removeFieldsBtn
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_removeFieldsBtnXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_removeFieldsBtn element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _mobilePhoneSelectedFields
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_mobilePhoneSelectedFieldsXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_mobilePhoneSelectedFields element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _filterTypeValue
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_filterTypeValueXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_filterTypeValue element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

		private IWebElement _searchTermValue
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_searchTermValueXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_searchTermValue element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _addFilterBtn
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_addFilterBtnXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_addFilterBtn element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _ddlStep6Period
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_ddlStep6PeriodXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_ddlStep6Period element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _ddlStep6Options
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_ddlStep6OptionsXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_ddlStep6Options element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _nextStepBtn
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_nextStepBtnXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_nextStepBtn element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _previousStepBtn
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_previousStepBtnXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_previousStepBtn element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _includeNonCardMlogsCheckBox
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_includeNonCardMlogsCheckBoxXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_includeNonCardMlogsCheckBox element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _includeNonCardMlogsCheckBoxLabel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_includeNonCardMlogsCheckBoxLabelXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_includeNonCardMlogsCheckBoxLabel element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _submitReportBtn
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_submitReportBtnXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_submitReportBtn element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _viewDetailBtn
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_viewDetailBtnXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_viewDetailBtn element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

		private IWebElement _viewDetailBackBtn
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_viewDetailBackBtnXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_viewDetailBackBtn element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _backToReportBtn
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_backToReportBtnXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_backToReportBtn element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _searchTermValueDDL
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_searchTermValueDDLXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_searchTermValueDDL element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _noCardHolderFoundMsg
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_noCardHolderFoundMsgXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_noCardHolderFoundMsg element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _progressLock
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_progressLockXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_progressLock element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _runCheckbox
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_runCheckboxXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_runCheckbox element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _runCheckboxLabel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_runCheckboxLabelXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_runCheckboxLabel element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _saveCheckbox
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_saveCheckboxXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_saveCheckbox element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _saveCheckboxLabel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_saveCheckboxLabelXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_saveCheckboxLabel element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

		private IWebElement _scheduleCheckbox
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_scheduleCheckboxXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_scheduleCheckbox element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _scheduleCheckboxLabel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_scheduleCheckboxLabelXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_scheduleCheckboxLabel element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _txtReportName
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_txtReportNameXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_txtReportName element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _ddlSaveLocation
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_ddlSaveLocationXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_ddlSaveLocation element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

		private IWebElement _btnExportGridText
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_btnExportGridTextXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_btnExportGridText element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IList<IWebElement> _validationSummary
        {
            get
            {
                IList<IWebElement> element = Driver.WaitForElements(By.XPath(_validationSummaryXPath)).ToList();

                if (element != null)
                {
                    Settings.EnCompassExtentTest.Info($"_validationSummary element founded.");
                    return element;
                }
                else
                {
                    Settings.EnCompassExtentTest.Info($"_validationSummary element not founded.");
                    return null;
                }
            }
        }

        private IList<IWebElement> _step6ValidationSummary
        {
            get
            {
                IList<IWebElement> element = Driver.WaitForElements(By.XPath(_step6ValidationSummaryXPath)).ToList();

                if (element != null)
                {
                    Settings.EnCompassExtentTest.Info($"_reviewerCB element founded.");
                    return element;
                }
                else
                {
                    Settings.EnCompassExtentTest.Info($"_reviewerCB element not founded.");
                    return null;
                }
            }
        }

        private IWebElement _ddlFilter
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_ddlFilterXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_ddlFilter element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _txtPageSize
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_txtPageSizeXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_txtPageSize element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _txtReportDescription
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_txtReportDescriptionXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_txtReportDescription element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _ddlExportType
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_ddlExportTypeXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_ddlExportType element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

		private IWebElement _searchTermStep4
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_searchTermStep4XPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_searchTermStep4 element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _cbxAllowFilterChangeAtRuntime
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_cbxAllowFilterChangeAtRuntimeXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_cbxAllowFilterChangeAtRuntime element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _ddlStep6SearchTerm
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_ddlStep6SearchTermXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_ddlStep6SearchTerm element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _ddlStep6SearchFilterType
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_ddlStep6SearchFilterTypeXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_ddlStep6SearchFilterType element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _txtStep6SearchFilterValue
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_txtStep6SearchFilterValueXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_txtStep6SearchFilterValue element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _btnStep6SearchFilterAdd
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_btnStep6SearchFilterAddXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_btnStep6SearchFilterAdd element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _btnStep6SearchFilterReset
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_btnStep6SearchFilterResetXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_btnStep6SearchFilterReset element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IList<IWebElement> _searchCriteriaRows
        {
            get
            {
                bool found = Driver.TryWaitForElementsToBeVisible(By.XPath(_searchCriteriaRowsXPath), out IList<IWebElement> elements);

                if (found)
                {
                    Settings.EnCompassExtentTest.Info($"_searchCriteriaRows element founded.");
                    return elements;
                }
                else
                {
                    Settings.EnCompassExtentTest.Info($"_searchCriteriaRows element not founded.");
                    return null;
                }
            }
        }

        private IWebElement _removeReportConfirmModalBtn
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_removeReportConfirmModalBtnXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_removeReportConfirmModalBtn element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _btnFindCardHierarchy
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_btnFindCardHierarchyXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_btnFindCardHierarchy element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _btnModalToggleSelectAll
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_btnModalToggleSelectAllXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_btnModalToggleSelectAll element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _topHierarchyCheckBox
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_topHierarchyCheckBoxXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_topHierarchyCheckBox element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _topHierarchyCheckBoxLabel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_topHierarchyCheckBoxLabelXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_topHierarchyCheckBoxLabel element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _finishButton
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_finishButtonXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_finishButton element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _exportBtn
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_exportBtnXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_exportBtn element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        #endregion

        #region Expand Elements
        private const string REPORT_WIZARD = "apcWizardContainer";
        private const string SELECT_FOCUS = "pnlStep1";
        private const string SET_UP = "apSetUp";
        #endregion

        public void ClickFindCardHierarchyButton()
        {
            _btnFindCardHierarchy.JSClickWithFocus(Driver);
            Settings.EnCompassExtentTest.Info("Clicked on 'Find Hierarchy' button.");
        }

        public void SetIncludeNonCardMlogsState(bool state)
        {
            _includeNonCardMlogsCheckBox.SetCheckboxStateWithLabel(_includeNonCardMlogsCheckBoxLabel, state);
            Settings.EnCompassExtentTest.Info($"'Include Merchant Logs that aren't card-based' checkbox state to {state}.");
        }

        public void ClickFinishButtonOnModal()
        {
            _finishButton.JSClickWithFocus(Driver);
            Settings.EnCompassExtentTest.Info("Clicked on 'Finish' button.");
        }

        public void SetTopHierarchyCheckboxState(bool state)
        {
            _topHierarchyCheckBox.SetCheckboxStateWithLabel(_topHierarchyCheckBoxLabel, state);
            Settings.EnCompassExtentTest.Info($"Top Hierarchy checkbox state to {state}.");
        }

        public bool SetSelectAllHierarchiesState(bool state)
        {
            bool isElementPresent = Driver.TryFindElement(By.XPath(_orggroupselectallXPath), out IWebElement btn);

            if (isElementPresent)
            {
                string buttonText = _btnModalToggleSelectAll.Text;

                // If the button shows 'select all hierarchies', it means that the current state is false
                if (state)
                {
                    if (buttonText.ToLowerInvariant() == "select all hierarchies")
                    {
                        _btnModalToggleSelectAll.JSClickWithFocus(Driver);
                        Settings.EnCompassExtentTest.Info("Clicked on 'Select All Hierarchies' button");
                    }
                }
                // If the button shows 'deselect all hierarchies', it means that the current state is true
                else
                {
                    if (buttonText.ToLowerInvariant() == "deselect all hierarchies")
                    {
                        _btnModalToggleSelectAll.JSClickWithFocus(Driver);
                        Settings.EnCompassExtentTest.Info("Clicked on 'Deselect All Hierarchies' button");
                    }
                }

                
            }
            else
                Settings.EnCompassExtentTest.Warning("The Select All Hierarchies State button is not visible.");

            return isElementPresent;
        }

        /// <summary>
        /// Description: This method clicks on Find Hierarchy button, chooses the Top Most Card and then completes the selection.
        /// </summary>
        public void SelectTopHierarchy(bool checkboxValidation = false)
        {
            ClickFindCardHierarchyButton();
            WaitForModalToAppear();
            _topHierarchyCheckBoxLabel.WaitUntilElementIsInteractable();

            if (checkboxValidation)
            {
                //Individual checkbox.
                SetTopHierarchyCheckboxState(false);
                Check.That(_topHierarchyCheckBox.Selected).IsEqualTo(false);
                SetTopHierarchyCheckboxState(true);
                Check.That(_topHierarchyCheckBox.Selected).IsEqualTo(true);
                //(Des)Select All Button.
                if(SetSelectAllHierarchiesState(false))
                    Check.That(_topHierarchyCheckBox.Selected).IsEqualTo(false);
                if(SetSelectAllHierarchiesState(true))
                    Check.That(_topHierarchyCheckBox.Selected).IsEqualTo(true);
            }
            else
            {
                _topHierarchyCheckBox.SetCheckboxStateWithLabel(_topHierarchyCheckBoxLabel, true);
            }

            ClickFinishButtonOnModal();
            WaitForModalToDisappear();
        }

        public void ClickSelectButton()
		{
			_btnSelect.JSClickWithFocus(Driver);
            Settings.EnCompassExtentTest.Info("Clicked on 'Select' button.");
        }

        public IList<IWebElement> GetSearchCriteriaRows()
		{
			IList<IWebElement> searchCriteriaRows = new List<IWebElement>();
			searchCriteriaRows = _searchCriteriaRows;
			return searchCriteriaRows;
		}

		public void SetStep6SearchTerm(string value)
		{
			SelectElement ddl = new SelectElement(_ddlStep6SearchTerm);
			ddl.SelectByText(value);
		}
		public void SetStep6FilterType(string value)
		{
			SelectElement ddl = new SelectElement(_ddlStep6SearchFilterType);
			ddl.SelectByText(value);
		}
		public void SetStep6SearchFilterValue(string value)
		{
			_txtStep6SearchFilterValue.SendKeys(value);
		}
		public void BtnStep6SearchAdd()
		{
			_btnStep6SearchFilterAdd.JSClickWithFocus(Driver);
		}
		public void BtnStep6SearchReset()
		{
			_btnStep6SearchFilterReset.JSClickWithFocus(Driver);
		}

		public void setReportDescription(string value)
		{
			_txtReportDescription.Clear();
			_txtReportDescription.SendKeys(value);
		}

		public void setPageSize(int value)
		{
			_txtPageSize.Clear();
			_txtPageSize.SendKeys(value.ToString());
		}

		public void setFilterDropdown(string value)
		{
			Driver.WaitFor(By.XPath(_ddlStep6InrinsicFieldsXPath));
			SelectElement ddlFilter = new SelectElement(_ddlFilter);
			ddlFilter.SelectByText(value);
		}


		public bool ValidationMessage(string message, bool isExact)
		{
			return isExact ? _validationSummary.Any(v => v.Text.Equals(message)) :
				_validationSummary.Any(v => v.Text.Contains(message));
		}

		public bool Step6ValidationMessage(string message, bool isExact)
		{
			return isExact ? _step6ValidationSummary.Any(v => v.Text.Equals(message)) :
				_step6ValidationSummary.Any(v => v.Text.Contains(message));
		}

		public void SetExportTypeList(string whichText)
		{
			var selectElement = new SelectElement(_ddlExportType);
			selectElement.SelectByText(whichText);
		}

		public void BtnExportGridText()
		{
			_btnExportGridText.WaitUntilElementIsInteractable();
			_btnExportGridText.JSClickWithFocus(Driver);
            Settings.EnCompassExtentTest.Info("Clicked on Export button");
        }

		public void BtnExportGridTextWithDifferentFormat(string reportFormat)
		{
			SetExportTypeList(reportFormat);
			_btnExportGridText.JSClickWithFocus(Driver);
		}

		private GridControl _searchTermsGrid;
		public GridControl SearchTermsGrid
		{
			get
			{
				var grid = _searchTermsGrid ?? (_searchTermsGrid = new GridControl("dgSearchTermsGrid", Driver));
				grid.WaitForGrid();
				return grid;
			}
		}

		private GridControl _designLayoutGrid;
		public GridControl DesignLayoutGrid
		{
			get
			{
				var grid = _designLayoutGrid ?? (_designLayoutGrid = new GridControl("dgStep5", Driver));
				grid.WaitForGrid();
				return grid;
			}
		}

		private GridControl _step6dgReports;
		public GridControl WorkingReportsGrid
		{
			get
			{
				var grid = _step6dgReports ?? (_step6dgReports = new GridControl("dgReports", Driver));
				grid.WaitForGrid();
				return grid;
			}
		}


		public IWebElement GetListBoxFromField(string field)
		{
			WaitForUpdate();
			return Driver.FindElement(By.XPath(string.Format(@"//span[contains(text(), '{0}')]/../..//select[contains(@id,'ddlSort')]", field)));
		}

		public void GoToStep(int step)
		{
			WaitForUpdate();
			Driver.FindElement(By.XPath(string.Format(@"//a[contains(text(),'Step {0}')]", step))).JSClickWithFocus(Driver);
            WaitForFormLoadingOverlay();
        }

		public void ChechOnlySaveAndSelectFileReport(string fileReport)
		{
			WaitForUpdate();
			_saveCheckbox.SetCheckboxStateWithLabel(_saveCheckboxLabel, true);
			_runCheckbox.SetCheckboxStateWithLabel(_runCheckboxLabel, false);
			WaitForFormLoadingOverlay();
			SetSaveLocation(fileReport);
		}

		public void setReportName(string name)
		{
			Driver.WaitFor(By.XPath(@"//input[contains(@id,'txtReportName')]"));
			_txtReportName.ForceDocumentLoadOnSendKeys(name, Driver);
		}
		public void SetRunCheckboxState(bool value)
		{
			Driver.WaitFor(By.XPath(_runCheckboxXPath));
            _runCheckbox.JsScrollToElement(Driver);
			_runCheckbox.SetCheckboxStateWithLabel(_runCheckboxLabel, value);
            Settings.EnCompassExtentTest.Info($"Run Checkbox state to {value}.");

        }

        public void SetSaveCheckboxState(bool value)
		{
            Driver.WaitFor(By.XPath(_saveCheckboxXPath));
            _saveCheckbox.JsScrollToElement(Driver);
            _saveCheckbox.SetCheckboxStateWithLabel(_saveCheckboxLabel, value);
            Settings.EnCompassExtentTest.Info($"Save Checkbox state to {value}.");
        }

		public void SetScheduleCheckboxState(bool value)
		{
            Driver.WaitFor(By.XPath(_scheduleCheckboxXPath));
            _scheduleCheckbox.JsScrollToElement(Driver);
            _scheduleCheckbox.SetCheckboxStateWithLabel(_scheduleCheckboxLabel, value);
            Settings.EnCompassExtentTest.Info($"Schdule Checkbox state to {value}.");            
		}

		public bool GetScheduleCheckboxState()
		{
			return _scheduleCheckbox.Selected;
		}

		public void SetSaveLocation(string value)
		{
			SelectElement ddlLocation = new SelectElement(_ddlSaveLocation);
			ddlLocation.SelectByText(value);
		}

		public void SetStep6Period(string value)
		{
			Driver.WaitFor(By.XPath(_ddlStep6PeriodXPath));
			SelectElement ddlPeriod = new SelectElement(_ddlStep6Period);

			ddlPeriod.SelectByText(value);
		}

		public void SetStep6Options(string value)
		{
			Driver.WaitFor(By.XPath(_ddlStep6OptionsXPath));
			SelectElement ddlOptions = new SelectElement(_ddlStep6Options);

			ddlOptions.SelectByText(value);
		}
		private GridControl _reportFocusGrid;
		public GridControl ReportFocusGrid
		{
			get
			{
				var grid = _reportFocusGrid ?? (_reportFocusGrid = new GridControl("dgReportFocuses", Driver));
				grid.WaitForGrid();
				return grid;
			}
		}

		private GridControl _reportResultsGrid;
		public GridControl ReportResultsGrid
		{
			get
			{
				var grid = _reportResultsGrid ?? (_reportResultsGrid = new GridControl("dgResults", Driver));
				grid.WaitForGrid();
				return grid;
			}
		}

		public void AddFieldsBtn()
		{
			_addFieldsBtn.JSClickWithFocus(Driver);
			WaitForFieldsLoadingOverlay();
			RefreshModel();
		}

		public void RemoveFieldsBtn()
		{
			_removeFieldsBtn.JSClickWithFocus(Driver);
			WaitForUpdate();
			RefreshModel();
		}

		// UI_New
		public void SetFieldCategories(string whichText)
		{
			WaitForUpdate();
			var selectElement = new SelectElement(_setFieldCategories);
			selectElement.SelectByText(whichText);
			WaitForFieldsLoadingOverlay();
			RefreshModel();
		}

		// UI_New
		public void SetAvailableFields(string whichText)
		{
			//Driver.WaitElementBeClickable(@"//select[contains(@ id, 'lbxAvailableFields')]");
			_setAvailableFields.WaitUntilElementIsInteractable();
			var selectElement = new SelectElement(_setAvailableFields);
			selectElement.DeselectAll();
			selectElement.SelectByText(whichText);
		}

        public void SetSelectedAvailableFields(List<string> list)
        {
            _setAvailableFields.WaitUntilElementIsInteractable();
            var selectElement = new SelectElement(_setAvailableFields);

            selectElement.DeselectAll();
            foreach (string item in list)
            {
                selectElement.SelectByText(item);
                Settings.EnCompassExtentTest.Info("Selected the Available Field : " + item);
            }
        }

        public void WaitForFieldsLoadingOverlay(TimeSpan? tSpan = null)
		{
			try
			{
				Driver.WaitFor(By.XPath(_loadingoverlayXPath), tSpan ?? TimeSpan.FromSeconds(20));
			}
			catch (Exception) { }
			Driver.WaitForAbsence(By.XPath(_loadingoverlayXPath), tSpan ?? TimeSpan.FromSeconds(30));
		}

		// UI_New
		public void SetAllAvailableFields()
		{
            Driver.WaitElementBeClickable(_setAvailableFieldsXPath);
            var selectElement = new SelectElement(_setAvailableFields);
            List<string> listOptions = new List<string>();
            //Get select option text
            selectElement.Options.ToList().ForEach(ele =>
            listOptions.Add(ele.Text));

            //select each option and add
            listOptions.ForEach(optionText =>
            {
                //Each time when we add element from select DDL its needs to be intialised again else it throws exception.
                selectElement = new SelectElement(_setAvailableFields);
                selectElement.SelectByText(optionText);
                _addFieldsBtn.JSClickWithFocus(Driver);
                WaitForFieldsLoadingOverlay();
                RefreshModel();
            });
        }

		public void SelectedFields(string whichText)
		{
			WaitForUpdate();
			var selectElement = new SelectElement(_selectedFields);
			selectElement.SelectByText(whichText);
			RemoveFieldsBtn();
			WaitForUpdate();
			RefreshModel();
		}

		public List<IWebElement> GetAllSelectedFeilds()
		{
			WaitForUpdate();
			var selectElement = new SelectElement(_selectedFields);
			return selectElement.Options.ToList();
		}

		public void FilterTypeValue(string whichText)
		{
			WaitForUpdate();
			var selectElement = new SelectElement(_filterTypeValue);
			selectElement.SelectByText(whichText);
			WaitForUpdate();
			RefreshModel();

		}

		public string SearchTermValue
		{
			set
			{
				WaitForUpdate();
				_searchTermValue.Clear();
				_searchTermValue.SendKeys(value);
				WaitForUpdate();
				RefreshModel();
			}

		}

		public void SearchTermValueDDL(string whichText)
		{
			WaitForUpdate();
			var selectElement = new SelectElement(_searchTermValueDDL);
			selectElement.SelectByText(whichText);
			WaitForUpdate();
			RefreshModel();
		}

		public void AddFilterBtn()
		{
			WaitForUpdate();
			_addFilterBtn.JSClickWithFocus(Driver);
			WaitForUpdate();
			RefreshModel();
		}

		public void NextStepBtn()
		{
			_nextStepBtn.JSClickWithFocus(Driver);
			WaitForUpdate();
			RefreshModel();
		}

		public void GoToSelectFocusStep()
		{
			WaitForUpdate();
			/* Robert:Temporary Comment*/
			//_reportStudio_ReportWizard_Step1SelectYourFocus.JSClickWithFocus(Driver);
			WaitForUpdate();
			RefreshModel();
		}

		public void GoToApplyFiltersStep()
		{
			WaitForUpdate();
			_reports_ReportWizard_Step4ApplyFilters.JSClickWithFocus(Driver);// _reportStudio_ReportWizard_Step4ApplyFilters.JSClickWithFocus(Driver);
			WaitForUpdate();
			RefreshModel();
		}

		public void GoToRunReportStep()
		{
			WaitForUpdate();

			_reports_ReportWizard_Step6RunYourReport.JSClickWithFocus(Driver);
			WaitForUpdate();
			RefreshModel();
		}
		public void PreviousStepBtn()
		{
			WaitForUpdate();
			_previousStepBtn.JSClickWithFocus(Driver);
			WaitForUpdate();
			RefreshModel();
		}

		public void SubmitReportBtn()
		{
			WaitForUpdate();
			Driver.WaitForVisible(By.XPath(_submitReportBtnXPath));
            AttachOnDemandScreenShot();
            //ScroillToXPath() removed because the JSClickWithFocus() do scroll to XPath too
			_submitReportBtn.JSClickWithFocus(Driver);
			Settings.EnCompassExtentTest.Info("Clicked on 'Submit Report' button.");
            WaitForUpdate();
			RefreshModel();
            Driver.WaitForDocumentLoadToComplete();
            Driver.WaitForAbsence(By.XPath(loading_spinnerXpath));
		}

        public bool IsReportSubmitButtonExist()
        {
            try
            {
                bool b = _submitReportBtn.Displayed;
                return true;
            }
            catch (Exception e)
            {
                return false;
            }
        }

        public void ViewDetailBtn()
		{
			WaitForUpdate();
            //ScroillToXPath() removed because the JSClickWithFocus() do scroll to XPath too
			_viewDetailBtn.JSClickWithFocus(Driver);
			WaitForUpdate();
			RefreshModel();
			WaitForLoad();
		}

		public void ViewDetailBackBtn()
		{
			WaitForUpdate();
			_viewDetailBtn.JSClickWithFocus(Driver);
			WaitForUpdate();
			RefreshModel();
		}

		public void DetailBackBtn()
		{
			WaitForUpdate();
			_viewDetailBackBtn.JSClickWithFocus(Driver);
			WaitForUpdate();
			RefreshModel();
		}

		public void BackToReportBtn()
		{
			WaitForUpdate();
			Driver.TryWaitForElementToBeVisible(By.XPath(_mobilePhoneSelectedFieldsXPath), out IWebElement backButton);
			_backToReportBtn.WaitUntilElementIsInteractable();
			_backToReportBtn.JSClickWithFocus(Driver);
            Settings.EnCompassExtentTest.Info("Clicked on 'Back To Report' button.");
            WaitForFormLoadingOverlay();
            WaitForUpdate();
			RefreshModel();
		}

		public void WaitForUpdate()
		{
            Thread.Sleep(300);
            Driver.WaitForAbsence(By.XPath(_progressLockXPath));
            Thread.Sleep(300);
		}

        public void SetCheckboxGroupingAggregation(string row, string type)
        {
            string aggregateCheckbox = string.Format(@"//span[normalize-space(text()) = '{0}']//parent::td//parent::tr//td//input[contains(@id,'{1}')]", row, type);
            WaitForUpdate();
            Driver.FindElement(By.XPath(aggregateCheckbox)).SetCheckboxStateWithLabel(null, true);
            Settings.EnCompassExtentTest.Info(String.Format("Enabled {0} for {1} field",type,row));
        }

        public bool AreNoRecordsRetruned
		{
			get
			{
				return Driver.IsElementPresent(By.XPath(_noCardHolderFoundMsgXPath));
			}
		}

		public bool HasMobilePhone
		{
			get
			{
				return Driver.IsElementPresent(By.XPath(_mobilePhoneSelectedFieldsXPath));
			}
		}

		public string GetMessageRecordTransactionEnvelope
		{
			get
			{
				return Settings.EnCompassWebDriver.WaitForVisible(By.XPath(_gridNoRecordsMessageXPath), TimeSpan.FromSeconds(5)).GetAttribute("innerText");
			}
		}

		public bool HasViewDetailBackBtn
		{
			get
			{
				return Driver.IsElementPresent(By.XPath(_viewDetailBackBtnXPath));
			}
		}

		public void WaitForFieldCat()
		{
			Driver.WaitForVisible(By.XPath(_setFieldCategoriesXPath));
		}

		public void ExportReportBtn()
		{
			WaitForUpdate();
			_exportBtn.JSClickWithFocus(Driver);
			WaitForUpdate();
			RefreshModel();
		}
		public void SetConfirmPassword(string value)
		{
			IWebElement _confirmPassword = Driver.FindElement(By.XPath(_txtPasswordConfirmXPath));


			_confirmPassword.Clear();
			_confirmPassword.ForceDocumentLoadOnSendKeys(value, Driver);
		}

		public void SetSearchTermStep4(string value)
		{
			Driver.WaitFor(By.XPath(_searchTermStep4XPath));
			SelectElement ddlOptions = new SelectElement(_searchTermStep4);

			ddlOptions.SelectByText(value);
		}

		public void SearchTermStep4AndMarkCheck(String searchFilter, bool setCheckbox, string searchValue)
		{
			SetSearchTermStep4(searchFilter);
			FilterTypeValue("Equal To");
			SearchTermValue = string.IsNullOrEmpty(searchValue) ? Settings.Scenario["CompanyNumber"].ToString() : searchValue;
			AddFilterBtn();
			WaitForFormLoadingOverlay();
			_cbxAllowFilterChangeAtRuntime.SetCheckboxStateWithLabel(null, setCheckbox);
			//RefreshModel();
		}

		public void SetPassword(string value)
		{
			IWebElement _password = Driver.FindElement(By.XPath(_txtPasswordXPath));
			_password.Clear();
			_password.ForceDocumentLoadOnSendKeys(value, Driver);
		}
		/// <summary>
		/// When changing the grid size on the report focus page, this will make sure the focus that you are looking for is loaded.
		/// </summary>
		/// <param name="whichFocus"></param>
		public void WaitForReportFocusesToLoad(string whichFocus)
		{
			Driver.WaitForVisible(By.XPath($@"//tr[contains(@id, 'dgReportFocuses')]//a[text() = '{whichFocus}']"));
		}

		public void ExpandSelectFocus()
		{
            ExpandCardHeader(REPORT_WIZARD,SELECT_FOCUS);
			Settings.EnCompassExtentTest.Info("Select Focus expanded.");
		}

		public void ExpandSetUp()
		{
			ExpandCardHeader(REPORT_WIZARD,SET_UP);
            Settings.EnCompassExtentTest.Info("Set up expanded.");
        }

		public void NavigateToMyReports()
		{
			IWebElement reportStudioMenu = Driver.FindElement(By.XPath(reportStudioMenuXPath));

			Actions actions = new Actions(Driver);
			actions.MoveToElement(reportStudioMenu).Build().Perform();
			IWebElement myReportsMenu = Driver.WaitForVisible(By.XPath(@"//a[normalize-space(text())='My Reports']"));
			Actions new_actions = new Actions(Driver);
			new_actions.MoveToElement(myReportsMenu).Click().Build().Perform();
		}

		public void NavigateToCompanyReports()
		{
			IWebElement reportStudioMenu = Driver.FindElement(By.XPath(reportStudioMenuXPath));

			Actions actions = new Actions(Driver);
			actions.MoveToElement(reportStudioMenu).Build().Perform();
			IWebElement myReportsMenu = Driver.WaitForVisible(By.XPath(@"//a[normalize-space(text())='My Reports']"));
			Actions new_actions = new Actions(Driver);
			new_actions.MoveToElement(myReportsMenu).Click().Build().Perform();
		}

		public void NavigateToReportWizard()
		{
			IWebElement reportStudioMenu = Driver.FindElement(By.XPath(reportStudioMenuXPath));

			Actions actions = new Actions(Driver);
			actions.MoveToElement(reportStudioMenu).Build().Perform();
			IWebElement myReportsMenu = Driver.WaitForVisible(By.XPath(@"//a[normalize-space(text())='Report Wizard']"));
			Actions new_actions = new Actions(Driver);
			new_actions.MoveToElement(myReportsMenu).Click().Build().Perform();
		}

		public void RemoveAllReportsInProgress()
		{

			var count = WorkingReportsGrid.GetColumnText("Name").Count();

			for (int i = 0; i < count; i++)
			{
                //Passing i as row index value will throw exception 
                //Because each time after removing row from table, the index keep on changing
                WorkingReportsGrid.SelectRow(1);
				WorkingReportsGrid.PerformActionByText("Remove");
				RemoveReportConfirmModalBtn();
			}
		}

		public void RemoveReportConfirmModalBtn()
		{
			Driver.SwitchTo();
			_removeReportConfirmModalBtn.WaitUntilElementIsInteractable();
			_removeReportConfirmModalBtn.JSClickWithFocus(Driver);
			Driver.WaitForAbsence(By.XPath(_removeReportConfirmModalBtnXPath));
			WaitForFormLoadingOverlay();
		}
    }
}
