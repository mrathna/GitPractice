package com.framework.testcases.AJS.BP;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.MerchantLocationPage;
import com.framework.pages.AJS.common.Common;
import com.framework.pages.AJS.common.IFCSHomePage;
import com.framework.pages.AJS.common.IFCSLoginPage;
import com.github.javafaker.Faker;

public class ValidateMerchantLocationTestCases extends BaseTest {
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "Regression", "BusinessFlow" })
	public void validateToCreateMerchant(@Optional("AU") String clientCountry, @Optional("BP") String clientName) {

		test = extent.createTest(clientName + ":" + clientCountry + "  Merch_AU_002_Create merchant manually",
				"Merch_AU_002_Create merchant manually");
		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		Common common = new Common(driver, test);
		MerchantLocationPage merchantLocation = new MerchantLocationPage(driver, test);
		IFCSloginPage.login("IFCS_URL_BP", "IFCS_BP_USERNAME", "IFCS_BP_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		IFCSHomePage.gotoApplicationAndClickApplicationMenu();
		IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);
		IFCSHomePage.gotoMerchantAndClickMerchantDetails();
		String merchant = common.getMerchantNoFromDB();
		common.chooseMerchantNoAndSearch(merchant);
		Faker fakerNumber = new Faker();
		String f_merchantNo = fakerNumber.number().digits(6);
		merchantLocation.createNewMerchant(f_merchantNo);
		IFCSHomePage.exitIFCS();
	}

	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "Regression", "BusinessFlow" })
	public void createMerchantAgreement(@Optional("AU") String clientCountry, @Optional("BP") String clientName) {

		test = extent.createTest(clientName + ":" + clientCountry + "  Merch_AU_003_Create merchant agreement",
				"Merch_AU_003_Create merchant agreement");
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		MerchantLocationPage merchantLocation = new MerchantLocationPage(driver, test);
		Common common = new Common(driver, test);
		IFCSloginPage.login("IFCS_URL_BP", "IFCS_BP_USERNAME", "IFCS_BP_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, " ");
		IFCSHomePage.gotoMerchantAndClickMerchantDetails();
		String merchant = common.getMerchantNoFromDB();
		common.chooseMerchantNoAndSearch(merchant);
		Faker fakerNumber = new Faker();
		String f_merchantNo = fakerNumber.number().digits(6);
		merchantLocation.createNewMerchant(f_merchantNo);
		merchantLocation.validateMaintainAgreementInMerchant(clientName, clientCountry);
		IFCSHomePage.exitIFCS();
	}

	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "Regression", "BusinessFlow" })
	public void validateLocationGroup(@Optional("AU") String clientCountry, @Optional("BP") String clientName) {

		test = extent.createTest(clientName + ":" + clientCountry + "  Merch_AU_004_Location Group",
				"Merch_AU_004_Location Group");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCShomePage = new IFCSHomePage(driver, test);
		MerchantLocationPage merchantLocationPage = new MerchantLocationPage(driver, test);

		IFCSloginPage.login("IFCS_URL_BP", "IFCS_BP_USERNAME", "IFCS_BP_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		IFCShomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);

		IFCShomePage.gotoMerchantAndClickMerchantDetails();

		// merchantLocationPage.selectMaintainLocationGroup();
		merchantLocationPage.selectLocationGroupsAndGotoMaintainLocationGroup();

		merchantLocationPage.addLocationToNewLocationGroup(clientName + "_" + clientCountry, "IFCS_BP_USERNAME");

		IFCShomePage.exitIFCS();

	}

	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "Regression" })
	public void createAndValidateNewLocation(@Optional("NZ") String clientCountry, @Optional("BP") String clientName) {

		test = extent.createTest(clientName + ":" + clientCountry + "  Location  Creation ",
				"Create new Location for BP");
		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);

		Common common = new Common(driver, test);

		MerchantLocationPage merchantLocation = new MerchantLocationPage(driver, test);
		IFCSloginPage.login("IFCS_URL_BP", "IFCS_BP_USERNAME", "IFCS_BP_PASSWORD");
		// IFCSloginPage.login("IFCS_CHV_URL", "IFCS_CHV_UN", "IFCS_CHV_PWD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		IFCSHomePage.gotoApplicationAndClickApplicationMenu();
		IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);
		IFCSHomePage.gotoMerchantAndClickMerchantDetails();

		// Get Location Num from DB
		String locationNoFromDB = common.getLocationNoFromDB();

		// create location
		merchantLocation.chooseLocationNoFromListAndDoubleClick(locationNoFromDB);
		// common.chooseLocationNoAndSearch(location);
		Faker fakerLocationNo = new Faker();
		String f_locationNo = fakerLocationNo.number().digits(6);
		System.out.println("f_locationNo" + f_locationNo);
		merchantLocation.createNewLocation(f_locationNo);

	}

}
