package com.framework.pages.EMAP;

import java.util.regex.Pattern;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.ExtentTest;
import com.framework.basepage.BasePage;
import com.framework.pages.OLS.common.CommonPage;
import com.framework.repo.Locator;
import com.framework.util.PropUtils;

/*** Added by Nithya - 07.06.2018 ***/
public class EMAPHomePage extends BasePage {

	public EMAPHomePage(WebDriver driver, ExtentTest test) {
		super(driver, test);
		PageFactory.initElements(driver, this);
	}

	// Page Element Definition
	@FindBy(how = How.ID, using = Locator.EMAP_LOGO_IMG)
	public WebElement emapLogo;

	@FindBy(how = How.ID, using = Locator.CARDS_MENU)
	public WebElement cardMenu;

	@FindBy(how = How.ID, using = Locator.FINDANDUPDATECARDS)
	public WebElement cardList;

	@FindBy(how = How.XPATH, using = Locator.ADHOC_REPORTS_TITLE)
	public WebElement cardListPageTitle;

	@FindBy(how = How.ID, using = Locator.QUICK_LINK_CARD_LIST)
	public WebElement quickLinkCardList;

	@FindBy(how = How.ID, using = Locator.QUICK_LINK_TRANSACTION_LIST)
	public WebElement quickLinkTransactionList;

	@FindBy(how = How.ID, using = Locator.QUICK_LINK_EXPORT_TRANSACTIONS)
	public WebElement quickLinkExportTransactions;

	@FindBy(how = How.ID, using = Locator.LOGOUT)
	public WebElement logoutLink;

	@FindBy(how = How.ID, using = Locator.TOPUSERDD)
	public WebElement userNameInRightTopCorner;

	@FindBy(how = How.ID, using = Locator.ACCOUNTS_MENU)
	public WebElement accountMenu;

	@FindBy(how = How.ID, using = Locator.STATUS_MENU)
	public WebElement selectAccount;

	@FindBy(how = How.ID, using = Locator.ACCOUNT_MAINTENANCE_MENU)
	public WebElement accountMaintenance;

	@FindBy(how = How.XPATH, using = Locator.CLIENT_WELCOME_TEXT)
	public WebElement clientWelcomeText;

	@FindBy(how = How.XPATH, using = Locator.PAGE_TITLE1)
	public WebElement accountPageTitle;

	@FindBy(how = How.ID, using = Locator.REPORTS_MENU)
	public WebElement reportsMenu;

	@FindBy(how = How.ID, using = Locator.STORED_REPORTS)
	public WebElement storedReports;

	@FindBy(how = How.ID, using = Locator.CONTACT)
	public WebElement contactsMenu;

	@FindBy(how = How.ID, using = Locator.TRANSACTIONS_MENU)
	public WebElement transactionMenu;

	@FindBy(how = How.ID, using = Locator.FIND_EXPORT_TRANSC)
	public WebElement transactionList;

	@FindBy(how = How.ID, using = Locator.SUPPORT_MENU)
	public WebElement supportMenu;

	@FindBy(how = How.ID, using = Locator.CHANGE_PASSWORD)
	public WebElement changePassword;

	@FindBy(how = How.XPATH, using = Locator.CONTACT_US_SM)
	public WebElement contactUs;

	@FindBy(how = How.ID, using = Locator.FOOTER_CONTACTUS)
	public WebElement footerContactUs;

	@FindBy(how = How.ID, using = Locator.ORDER_NEW_CARD_QUICK_LINK)
	public WebElement orderNewCardQuickLink;

	@FindBy(how = How.ID, using = Locator.CHANGE_CARD_STATUS_QUICK_LINK)
	public WebElement changeCardStatusQuickLink;

	@FindBy(how = How.ID, using = Locator.ADHOC_REPORTS_SUBMENU)
	public WebElement adhocReportsSubmenu;

	@FindBy(how = How.XPATH, using = Locator.PAGE_TITLE_REISSUECARD)
	public WebElement pageTitle;

	@FindBy(how = How.ID, using = Locator.ORDER_A_CARD)
	public WebElement orderACard;

	@FindBy(how = How.ID, using = Locator.BULK_CARD_ORDER_SUBMENU)
	public WebElement bulkCardOrderSubmenu;

	@FindBy(how = How.XPATH, using = Locator.CUSTOMER_NAME_COMBO)
	public WebElement accountNumber;

	@FindBy(how = How.ID, using = Locator.HOME_MENU_BP)
	public WebElement homeMenu;

	@FindBy(how = How.ID, using = Locator.EXPORT_TRANSACTION)
	public WebElement exportTransaction;

	@FindBy(how = How.ID, using = Locator.FOOTER_LINK_EXXON_CORPORATION)
	public WebElement footerLinkExxonCorporation;

	@FindBy(how = How.ID, using = Locator.FOOTER_CONTACTUS)
	public WebElement contactUsInFooter;

	@FindBy(how = How.ID, using = Locator.COPY_RIGHT_LINK_HOME_PAGE)
	public WebElement copyRightLink;

	@FindBy(how = How.ID, using = Locator.COPY_RIGHT_TEXT)
	public WebElement copyRightText;

	@FindBy(how = How.XPATH, using = Locator.TERMS_AND_CONDITION)
	public WebElement termsAndCondition;

	@FindBy(how = How.XPATH, using = Locator.PRIVACY_POLICY_IN_HOME_PAGE_FOOTER)
	public WebElement privacyPolicyInHomePage;

	@FindBy(how = How.ID, using = Locator.EXXON_MOBIL_LOGO_IN_HOME_PAGE)
	public WebElement exxonMobilLogoInHomePage;

	@FindBy(how = How.ID, using = Locator.ESSO_LOGO_IN_HOME_PAGE)
	public WebElement essoLogoInHomePage;

	@FindBy(how = How.ID, using = Locator.MOBIL_LOGO_IN_HOME_PAGE)
	public WebElement mobilLogoInHomePage;

	@FindBy(how = How.ID, using = Locator.SCHEDULED_REPORT)
	public WebElement scheduledReportMenu;

	@FindBy(how = How.ID, using = Locator.SETTLEMENTS_MENU)
	public WebElement settlementsMenu;

	@FindBy(how = How.ID, using = Locator.AU_LOCATION)
	public WebElement locationMenu;

	@FindBy(id = Locator.ACCOUNT_DETAILS)
	public WebElement accountDetailsInHomePage;

	@FindBy(id = Locator.CHANGE_PWD_IN_HELLO_UN_LINK)
	public WebElement changePwdInHelloUNLink;

	@FindBy(id = Locator.LOC_TRANSACTION_LINKS)
	public WebElement locQuicklinkTransaction;

	@FindBy(xpath = Locator.EXPORT_TRANSACTION_LINKS)
	public WebElement locOrMercExportTransaction;

	@FindBy(xpath = Locator.MERC_TRANSACTION_LINKS)
	public WebElement mercQuicklinkTransaction;

	@FindBy(id = Locator.SHELL_ACCOUNT_DROPDOWN)
	public WebElement accountDropdown;

	@FindBy(xpath = Locator.ACCOUNT_NAME_IN_HOME_PAGE)
	public WebElement accountNameInHomePage;

	@FindBy(id = Locator.BULK_CARD_UPDATE_SM)
	public WebElement bulkCardUpdateSubmenu;

	@FindBy(how = How.XPATH, using = Locator.MERCHANT_CLIENT_LOGO_IMG)
	public WebElement merchantClientLogo;

	CommonPage commonPage = new CommonPage(driver, test);

	public void validateEMAPCustomerLogo() {
		isDisplayed(emapLogo, "EMAP Logo");
	}

	public void validateCustomerWelcomeText() {
		try {
			if (emapLogo.isDisplayed()) {
				String temp = getText(emapLogo).trim();
				logInfo("Welcome Text : '" + temp + "'");
				if (temp.contains("Mobil Fleet Card Online") || temp.contains("Esso Fleetcards Online")) {
					logPass("Welcome text is Displayed correctly as " + temp);
				} else {
					logFail("Welcome text is Displayed incorrectly as " + temp);
				}
			} else {
				logFail("Welcome Text is Not Displayed");
			}
		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
	}

	public void validateMerchantWelcomeText() {
		try {
			if (merchantClientLogo.isDisplayed()) {
				String temp = getText(merchantClientLogo).trim();
				logInfo("Welcome Text : '" + temp + "'");
				if (temp.contains("Mobil Merchant Online") || temp.contains("Esso Merchant Online")) {
					logPass("Welcome text is Displayed correctly as " + temp);
				} else {
					logFail("Welcome text is Displayed incorrectly as " + temp);
				}
			} else {
				logFail("Welcome Text is Not Displayed");
			}
		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
	}

	public void clickCardListAndValidatePage() {
		clickSubMenuAndValidate(cardMenu, cardList, cardListPageTitle);
		sleep(2);
	}

	public void checkThePresenceOfQuickLinksOnHomePage(String readOnlyOrReadWrite) {
		if (readOnlyOrReadWrite.contains("Loc") || readOnlyOrReadWrite.contains("Mer")) {
			if (readOnlyOrReadWrite.contains("Loc")) {
				isDisplayed(locQuicklinkTransaction, "Location - Quick Link Transaction List");
			} else {
				isDisplayed(mercQuicklinkTransaction, "Merchant - Quick Link Transaction List");
			}
			isDisplayed(locOrMercExportTransaction, "Location - Quick Link Export Transactions");
		} else {
			if (readOnlyOrReadWrite.equals("Read-Write")) {
				isDisplayed(orderNewCardQuickLink, "Order New Card");
				isDisplayed(changeCardStatusQuickLink, "Change Card Status");
			} else if (readOnlyOrReadWrite.equals("View-Only")) {
				isDisplayed(changeCardStatusQuickLink, "Change Card Status");
			}
			isDisplayed(quickLinkCardList, "Quick Link Card List");
			isDisplayed(quickLinkTransactionList, "Quick Link Transaction List");
			isDisplayed(quickLinkExportTransactions, "Quick Link Export Transactions");
		}
	}

	public void checkThePresenceOfLoginUserNameAndLogoutLink() {
		isDisplayed(userNameInRightTopCorner, "User Name In Top Right Corner");
		if (!getText(userNameInRightTopCorner).split("Hello,")[1].equals("")) {
			logPass("Username at top right corner present");
		} else {
			logFail("Username at top right corner not present");
		}
	}

	public void clickSelectAccountAndValidatePage() {
		clickSubMenuAndValidate(accountMenu, selectAccount, clientWelcomeText);
	}

	public void clickAccountMaintenanceAndValidatePage() {
		clickSubMenuAndValidate(accountMenu, accountMaintenance, accountPageTitle);
	}

	public void clickLocationAndValidatePage() {
		clickSubMenuAndValidate(accountMenu, locationMenu, accountPageTitle);
	}

	public void clickContactsAndValidatePage() {
		clickSubMenuAndValidate(accountMenu, contactsMenu, accountPageTitle);
	}

	public void clickTransactionListAndValidatePage() {
		clickSubMenuAndValidate(transactionMenu, transactionList, accountPageTitle);
		sleep(8);
	}

	public void clickExportTransactionListAndValidate() {
		isDisplayedThenClick(transactionMenu, "Transaction Menu");
		sleep(3);
		isDisplayedThenClick(exportTransaction, "Export Transaction");
	}

	public void clickStoredReportsAndValidatePage() {
		clickSubMenuAndValidate(reportsMenu, storedReports, accountPageTitle);
	}

	public void clickAdhocReportsAndValidatePage() {
		clickSubMenuAndValidate(reportsMenu, adhocReportsSubmenu, pageTitle);
	}

	public void clickChangePasswordAndValidatePage() {
		clickSubMenuAndValidate(supportMenu, changePassword, accountPageTitle);
	}

	public void clickContactUsAndValidatePage() {
		clickSubMenuAndValidate(supportMenu, contactUs, accountPageTitle);
		sleep(4);
	}

	public void clickContactUsMOAndValidatePage() {
		clickSubMenuAndValidate(supportMenu, footerContactUs, accountPageTitle);
		sleep(4);
	}

	public void clickOrderCardAndValidatePage() {
		clickSubMenuAndValidate(cardMenu, orderACard, pageTitle);
		sleep(2);
	}

	public void clickBulkCardOrderAndValidatePage() {
		clickSubMenuAndValidate(cardMenu, bulkCardOrderSubmenu, cardListPageTitle);
		sleep(2);
	}

	public void clickBulkCardUpdateAndValidatePage() {
		clickSubMenuAndValidate(cardMenu, bulkCardUpdateSubmenu, cardListPageTitle);
		sleep(2);
	}

	public void clickSettlementsAndValidatePage() {
		clickSubMenuAndValidate(transactionMenu, settlementsMenu, pageTitle);
		sleep(2);
	}

	public void clickScheduledReportsAndValidatePage(String uname) {
		clickSubMenuAndValidate(reportsMenu, scheduledReportMenu, pageTitle);
		if (!(pageTitle.getText().contains(PropUtils.getPropValue(configProp, uname)))) {
			logFail("Copy Right Text Verification Failed : " + copyRightText.getText());
		}
	}

	public void clickHomeMenuAndValidatePage(String customerOrMerc) {
		isDisplayedThenClick(homeMenu, "Home Menu");
		if (customerOrMerc.contains("Merc") || customerOrMerc.contains("Loc")) {
			validateMerchantWelcomeText();
		} else {
			validateCustomerWelcomeText();
		}

	}

	public String setAccountNumberChoosen() {
		String validAccountNumber = selectedStringFrmDropDown(accountNumber).split("  ")[1]
				.replace(Pattern.quote("//("), "").replace(Pattern.quote("//)"), "");
		return validAccountNumber;
	}

	public void clickExxonMobilCorporationInFooterAndValidatePage() {
		String parentWindow = clickAndSwitchToNewWindow(footerLinkExxonCorporation);
		if (!(driver.getCurrentUrl().contains("corporate.exxonmobil.com"))) {
			logFail("Exxon mobil site not redirecting");
		}
		closeChildAndMoveToParent(parentWindow);
	}

	public void clickContactUsInFooterAndValidatePage() {
		isDisplayedThenClick(contactUsInFooter, "Contact us");
		sleep(2);
		verifyText(pageTitle, "Contact us");
	}

	public void clickCopyRightAndValidatePage(String clientName) {
		isDisplayedThenClick(copyRightLink, "Copy Right Link");
		sleep(3);
		if (copyRightText.getText().contains(PropUtils.getPropValue(configProp, clientName + "_CopyRight"))) {
			logPass("Copy Right Text Verification Passed : " + copyRightText.getText());
		} else {
			logFail("Copy Right Text Verification Failed : " + copyRightText.getText());
		}
	}

	public void checkThePresenceOfTermsAndConditionInFooter() {
		isDisplayed(termsAndCondition, "Terms And Condition");
	}

	public void clickPrivacyPolicyAndValidatePage() {
		isDisplayedThenClick(privacyPolicyInHomePage, "Privacy Policy in footer");
		sleep(3);
		if (commonPage.isPrivacyStatementFileDownloaded("privacy_policy")) {
			logInfo("Privacy Policy downloaded");
		} else {
			verifyText(accountPageTitle, "Privacy Statement");
		}
	}

	public void clickExxonMobilLogoAndValidatePage() {
		isDisplayedThenClick(exxonMobilLogoInHomePage, "Exxon Logo");
		sleep(2);
		if (!(driver.getCurrentUrl().contains("corporate.exxonmobil.com"))) {
			logFail("Exxon mobil site not redirecting");
		}
		driver.navigate().back();
		sleep(2);
	}

	public void clickEssoLogoAndValidatePage() {
		isDisplayedThenClick(essoLogoInHomePage, "ESSO Logo");
		sleep(2);
		if (!(driver.getCurrentUrl().contains("esso.com.sg"))) {
			logFail("ESSO site not redirecting");
		}
		driver.navigate().back();
		sleep(2);
	}

	public void clickMobilLogoAndValidatePage() {
		isDisplayedThenClick(mobilLogoInHomePage, "Mobil Logo");
		sleep(2);
		if (!(driver.getCurrentUrl().contains("mobil.com"))) {
			logFail("Mobil site not redirecting");
		}
		driver.navigate().back();
		sleep(2);
	}

	public void checkThePresenceOfAccountInformationsOnHomePage() {
		setCellDataFromTable(accountDetailsInHomePage, 2, true);
		String[] rowValues = new String[] { "Last Bill Amount", "Last Bill Amount and Due Date",
				"Last Payment Received", "Last Payment Amount" };
		// Checks the presence of row values in order
		for (int i = 1; i <= rowValues.length; i++) {
			if (getCellDataFromTable(i, 0, true).trim().contains(rowValues[i - 1])) {
				logPass("Expected Account Details : " + rowValues[i - 1] + ": is present");
			} else {
				logFail("Expected Account Details : " + rowValues[i - 1] + ": is not present");
			}
		}
	}

	public void clickChangePasswordUsernameDropdown() {
		isDisplayedThenClick(userNameInRightTopCorner, "Hello Username");
		isDisplayedThenClick(changePwdInHelloUNLink, "Change Password");
		sleep(2);
		verifyText(pageTitle, "Password maintenance");
	}

	public void verifyCustomerNumberInHomePage() {
		String customerNameAndNo = selectedStringFrmDropDown(accountDropdown);
		if (customerNameAndNo.contains(getText(accountNameInHomePage))) {
			logPass("Same account name present in dropdown and details section");
		} else {
			logFail("Same account name not present in dropdown and details section");
		}
	}

	public void selectAccountAndCheckSelectedAccountOnContext() {
		String alreadySelectedAcct = selectedStringFrmDropDown(accountDropdown);
		selectDifferentValueInsteadOfDefault(accountDropdown, "", alreadySelectedAcct);
	}

}
