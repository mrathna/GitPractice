﻿using Common;
using Common.Utility;
using NFluent;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace EnCompass.Testing.Source.PageObjects.Organization.ReportStudio
{
    public class ScheduleReport : EnCompassPageModel
    {
        #region XPATH

        private const string ADD_NEW_SCHEDULE_INFORMATION_XPATH = @"//a[contains(@id,'lbAddNewSchedule')]";
        private const string _scheduleSaveXPath = @"//input[contains(@id,'StdReport_SaveSchedule')]";
        private const string _scheduleConfirmPasswordXPath = @"//input[contains(@id,'ReportScheduleEntry_confirmPassword') or contains(@id,'txtPasswordConfirm')]";
        private const string _schedulePasswordXPath = @"//input[contains(@id,'ReportScheduleEntry_password') or contains(@id,'txtPassword')]";
        private const string _scheduleDescriptionXPath = @"//input[contains(@id,'ReportScheduleEntry_description')]";
        private const string _scheduleNicknameXPath = @"//input[contains(@id,'txtNickname')]";
        private const string _scheduleStartDateXPath = @"//input[contains(@id,'ReportScheduleEntry_startDt') or contains(@id,'txtFrequency')]";
        private const string _scheduleSetXpathXPath = @"//input[contains(@id,'ReportScheduleEntry_alias')]";
        private const string _cyclePlusXDaysXPath = @"//input[contains(@id,'txtCyclePlusDays')]";
        private const string _frequencyListXPath = @"//select[contains(@id,'ddlFrequency')]";
        private const string _emailDeliveryXPath = @"//input[contains(@id,'email')]";
        private const string _scheduleOptionsButtonXPath = @".//a[contains(@id, 'StdReport_ScheduleToggleLink')]";

        #endregion

        #region IWebElement

        public IWebElement _scheduleSave
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_scheduleSaveXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_scheduleSave element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _scheduleConfirmPassword
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_scheduleConfirmPasswordXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_scheduleConfirmPassword element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _schedulePassword
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_schedulePasswordXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_schedulePassword element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _scheduleDescription
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_scheduleDescriptionXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_scheduleDescription element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _scheduleNickname
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_scheduleNicknameXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_scheduleNickname element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _scheduleStartDate
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_scheduleStartDateXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_scheduleStartDate element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _scheduleSet
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_scheduleSetXpathXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_scheduleSet element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _cyclePlusXDays
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_cyclePlusXDaysXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_cyclePlusXDays element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _frequencyList
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_frequencyListXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_frequencyList element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _emailDelivery
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_emailDeliveryXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_emailDelivery element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _btnAddNew
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(ADD_NEW_SCHEDULE_INFORMATION_XPATH), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_btnAddNew element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _scheduleOptionsButton
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_scheduleOptionsButtonXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_scheduleOptionsButton element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        #endregion

        private IWebDriver _driver;


        public ScheduleReport(IWebDriver driver, GlobalSettings settings) : base(settings)
        {
            _driver = driver;
        }

        public void SaveSchedule()
        {
            _scheduleSave.JSClickWithFocus(Driver);
		}

        public void SetScheduleConfirmPassword(string value)
        {
            _scheduleConfirmPassword.ForceDocumentLoadOnSendKeys(value, _driver);
        }

        public void SetSchedulePassword(string value)
        {
            WebDriverWait wait = new WebDriverWait(_driver, TimeSpan.FromSeconds(5));
            wait.Until(ExpectedConditions.ElementToBeClickable(By.XPath(_schedulePasswordXPath)));
            _schedulePassword.ForceDocumentLoadOnSendKeys(value, _driver);
        }

        public void SetScheduleDescription(string value)
        {
            _scheduleDescription.Clear();
            _scheduleDescription.ForceDocumentLoadOnSendKeys(value, _driver);
        }

        public void SetScheduleNickname(string value)
        {
            _scheduleNickname.ForceDocumentLoadOnSendKeys(value, _driver);
        }

        public void SetScheduleStartDate(string value)
        {
            _scheduleStartDate.ForceDocumentLoadOnSendKeys(value, _driver);
        }
        

        public void SetXpath(string value)
        {
            _scheduleSet.ForceDocumentLoadOnSendKeys(value, _driver);
        }

        public void SetCycleplusXdays(string value)
        {
            _cyclePlusXDays.ForceDocumentLoadOnSendKeys(value, _driver);
        }

        public void setFrequencyList(string whichText)
        {
            var selectElement = new SelectElement(_frequencyList);
            selectElement.SelectByText(whichText);
        }

        public void SetEmailDelivery(string value)
        {
            _emailDelivery.ForceDocumentLoadOnSendKeys(value, _driver);
            Settings.EnCompassExtentTest.Info($"EmailDelivery is set to " + value);
        }

        public void btnAddNewSchedule()
        {

            //Thread.Sleep(TimeSpan.FromSeconds(1));
            _driver.WaitElementBeClickable(ADD_NEW_SCHEDULE_INFORMATION_XPATH);
            try
            {
                _btnAddNew.JSClickWithFocus(Driver);
            }
            catch (Exception)
            {
                _btnAddNew.SendKeys(Keys.Enter);
            }
        }

        public void SetScheduleInformation(string frequencySchedule)
        {
            SetSchedulePassword("Abc.1234");
            SetScheduleConfirmPassword("Abc.1234");
        }

        public void ToggleScheduleOptionsClick(bool expandOnly = false)
        {
            if(expandOnly && _scheduleOptionsButton.Text != "Schedule Options")
                return;
            _scheduleOptionsButton.JSClickWithFocus(Driver);
            Settings.EnCompassExtentTest.Info("Schedule options section toggle button clicked.");
        }
    }
}
