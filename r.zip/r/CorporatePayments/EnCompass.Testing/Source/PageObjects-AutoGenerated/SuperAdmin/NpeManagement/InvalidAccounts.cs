using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using Common;
using Common.PageObjects;
using Common.ScenarioConfigurations;
using Common.Utility;

namespace EnCompass.Testing.Source.PageObjects.SuperAdmin.NpeManagement 
{
	/// <summary>
	/// Auto-generated Page Model Class
	/// Navigation Paths: 
		/// [Organization Home]->General->Non-Posted Exceptions
		/// </summary>
	[PageModel(@"/superAdmin/npeManagement/invalidAccounts.aspx")]
	public partial class InvalidAccounts : EnCompassSuperPageModel 
	{
		public override string RelativeUrl => @"/superAdmin/npeManagement/invalidAccounts.aspx";
		public override string PageIdentifierXPath_Generated => @"//li[contains(@class, 'breadcrumb-item active')][text() = 'Non-Posted Exceptions']";

		#region Navigation
		
		private void NavigateToMenuItem(IWebElement element)
		{
			Driver.Url = element.GetAttribute("href");
		}
		#endregion

		public InvalidAccounts(GlobalSettings settings) : base(settings) { }
	}  
}
