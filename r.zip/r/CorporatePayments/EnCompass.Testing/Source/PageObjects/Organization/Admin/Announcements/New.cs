﻿using Common;
using Common.Utility;
using NFluent;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace EnCompass.Testing.Source.PageObjects.Organization.Admin.Announcements
{
    [PageModel(@"/Announcements/new.aspx")]
    class New : EnCompassPageModel
    {
        #region XPath

        public override string RelativeUrl => @"/Announcements/new.aspx";
        public override string PageIdentifierXPath_Override => @"//li[contains(@class, 'breadcrumb-item active')][contains(text(), 'Create')]";

        private const string _titleXPath = "//input[contains(@name,'Title')]";
        private const string _bodyXPath = "//textarea[contains(@name,'editAnnouncement')]";
        private const string _edtEndDateXPath = @"//*[@id='ctl00_ctl00_content_contents_editAnnouncement_EndDate']";
        private const string _edtStartDateXPath = "//input[contains(@id,'editAnnouncement_StartDate')]";
        private const string _btnCancelXPath = "//input[contains(@id,'editAnnouncement_Cancel')]";
        private const string _confirmMsgXPath = "//p[contains(.,'Are you sure you want')]";
        private const string _btnConfirmXPath = "//button[contains(text(),'Confirm')]";
        private const string _btnArchiveXPath = "//input[contains(@id,'editAnnouncement_btnStop')]";
        private const string _btnUpdateXPath = "//input[contains(@id,'editAnnouncement_SubmitAnnouncement')]";
        private const string _btnCreateXPath = "//input[contains(@id,'dgCurrent_rowButtons_actionAddItem')]";
        private const string _postOnlyXPath = @"//label[normalize-space(@text())='Post only']";
        private const string _submitAnnouncementXpath = "//input[contains(@id,'SubmitAnnouncement')]";

        #endregion

        #region IWebElement Props

        public IWebElement _title
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_titleXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Debug("Found _title");
                return element;
            }
        }

        public IWebElement _body
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_bodyXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Debug("Found _body");
                return element;
            }
        }

        public IWebElement _edtEndDate
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_edtEndDateXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Debug("Found _edtEndDate");
                return element;
            }
        }

        public IWebElement _edtStartDate
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_edtStartDateXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Debug("Found _edtStartDate");
                return element;
            }
        }

        public IWebElement _btnCancel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_btnCancelXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Debug("Found _btnCancel");
                return element;
            }
        }

        public IWebElement _confirmMsg
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_confirmMsgXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Debug("Found _confirmMsg");
                return element;
            }
        }

        public IWebElement _btnConfirm
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_btnConfirmXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Debug("Found _btnConfirm");
                return element;
            }
        }

        public IWebElement _btnArchive
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_btnArchiveXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Debug("Found _btnArchive");
                return element;
            }
        }

        public IWebElement _btnUpdate
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_btnUpdateXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Debug("Found _btnUpdate");
                return element;
            }
        }

        public IWebElement _btnCreate
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_btnCreateXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Debug("Found _btnCreate");
                return element;
            }
        }

        public IWebElement _postOnly
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_postOnlyXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Debug("Found _postOnly");
                return element;
            }
        }

        public IWebElement _defaultPublishingPostAndEmailOption
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_defaultPublishingPostAndEmailOptionXpath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Debug("Found _defaultPublishingPostAndEmailOption");
                return element;
            }
        }

        public IWebElement _publishingPostAndEmailOption
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_publishingPostAndEmailOptionXpath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Debug("Found _publishingPostAndEmailOption");
                return element;
            }
        }

        public IWebElement _publishingPostOnlyOption
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_publishingPostOnlyOptionXpath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Debug("Found _publishingPostOnlyOption");
                return element;
            }
        }

        public IWebElement _publishingEmailOnlyOption
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_publishingEmailOnlyOptionXpath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Debug("Found _publishingEmailOnlyOption");
                return element;
            }
        }

        #endregion



        public string AnnouncementTitle
        {
            set
            {
                _title.Clear();
                _title.SendKeys(value);
                Settings.EnCompassExtentTest.Info("Announcement Title value" + value);
            }
            get
            {
                return _title.Text;
            }
        }

        public string AnnouncementBody
        {
            set
            {
                _body.Clear();
                _body.SendKeys(value);
                Settings.EnCompassExtentTest.Info("Announcement Body value" + value);
            }
            get
            {
                return _body.Text;
            }
        }

        public string StartDate
        {
            set
            {
                _edtStartDate.Clear();
                _edtStartDate.SendKeys(value);
                Settings.EnCompassExtentTest.Info("Entered start date is:-" + value);
            }
            get
            {
                return _edtStartDate.Text;
            }
        }

        public string EndDate
        {
            set
            {
                _edtEndDate.Clear();
                _edtEndDate.SendKeys(value);
                Settings.EnCompassExtentTest.Info("Entered end date is:-" + value);
            }
        }

        private const string _defaultPublishingPostAndEmailOptionXpath = "//input[contains(@id,'Broadcast')][@checked='checked']/following-sibling::label";
        private const string _publishingPostAndEmailOptionXpath = "//label[contains(@for,'doBroadcast')]";
        private const string _publishingPostOnlyOptionXpath = "//label[contains(@for,'dontBroadcast')]";
        private const string _publishingEmailOnlyOptionXpath = "//label[contains(@for,'onlyBroadcast')]";
        public string PublishingOptions
        {
            set
            {
                if (value.ToLowerInvariant().Equals("post and email"))
                   _publishingPostAndEmailOption.JSClickWithFocus(Driver);
                else if (value.ToLowerInvariant().Equals("post only"))
                    _publishingPostOnlyOption.JSClickWithFocus(Driver);
                else if (value.ToLowerInvariant().Equals("email only"))
                    _publishingEmailOnlyOption.JSClickWithFocus(Driver);

                Settings.EnCompassExtentTest.Info("Set Publishing options to " + PublishingOptions);
            }
            get
            {
                return Driver.FindElement(By.XPath(_defaultPublishingPostAndEmailOptionXpath)).GetAttribute("textContent");
            }
        }

        /**
         * Gets the default priority(High/Normal) of the checkbox 
         * Check if the default priority is the expected priority to be selected
         * if yes no action
         * if no select the expected prioity
         **/

        private string _defaultPriorityXpath = "//input[contains(@id,'Priority')][@checked='checked']";
        private string _highPriorityXpath = "//label[contains(@for,'editAnnouncement_rblPriority_1')]";
        private string _lowPriorityXpath = "//label[contains(@for,'editAnnouncement_rblPriority_0')]";
        public string SetPriority
        {
            set
            {
                String defaultPriority = Driver.FindElement(By.XPath(_defaultPriorityXpath)).GetAttribute("value");
                if (!defaultPriority.Equals(value.ToLower()))
                {
                    if (value.ToLowerInvariant().Equals("high"))
                        Driver.FindElement(By.XPath(_highPriorityXpath)).JSClickWithFocus(Driver);
                    else
                        Driver.FindElement(By.XPath(_lowPriorityXpath)).JSClickWithFocus(Driver);
                }
                Settings.EnCompassExtentTest.Info("Set announcement priority to " + defaultPriority);
            }
            get
            {
                return Driver.FindElement(By.XPath("//input[contains(@id,'Priority')][@checked='checked']")).GetAttribute("value");
            }
        }
        public bool IsPrioritySelected(string strPriority)
        {
            bool blnSelection;

            try
            {
                if (strPriority.ToLower().Equals("high"))
                {

                    blnSelection = Driver.FindElement(By.XPath(_highPriorityXpath)).Selected;
                    Settings.EnCompassExtentTest.Info("High priority has been selected");
                }
                else
                {
                    blnSelection = Driver.FindElement(By.XPath(_lowPriorityXpath)).Selected;
                    Settings.EnCompassExtentTest.Info("Normal priority has been selected");
                }
                return true;
            }
            catch (Exception)
            {
                return false;
            }

        }

        public void SubmitAnnouncement()
        {
			Driver.TryWaitForElementToBeVisible(By.XPath("//input[contains(@id,'SubmitAnnouncement')]"),
				out IWebElement _submitAnnouncement);
            _submitAnnouncement.JSClickWithFocus(Driver);
            Driver.WaitForDocumentLoadToComplete();
            Settings.EnCompassExtentTest.Info("Submited Announcement");
            this.AttachOnDemandScreenShot();
        }

        public void UnPublihedStartAndEndDate()
        {

            _edtStartDate.Clear();
            _edtStartDate.SendKeys(DateTime.Now.Date.AddDays(10).ToString());

            Settings.EnCompassExtentTest.Info("Start date for unpublished announcement" + DateTime.Now.Date.AddDays(10).ToString());

            _edtEndDate.Clear();
            _edtEndDate.SendKeys(DateTime.Now.Date.AddDays(20).ToString());
            Settings.EnCompassExtentTest.Info("End date for unpublished announcement" + DateTime.Now.Date.AddDays(20).ToString());

        }
        public void ClickOnCancel()
        {
            _btnCancel.JSClickWithFocus(Driver);
            Settings.EnCompassExtentTest.Info("Clicked Cancel button");
        }
        public bool IsConfirmExist()
        {
            try
            {
                bool b = _btnConfirm.Displayed;
                Settings.EnCompassExtentTest.Info("Confirm Button exists");
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }
        public string VerifyPopupMessage()
        {
            Settings.EnCompassExtentTest.Info("Text on window is :" + _confirmMsg.Text);
            return _confirmMsg.Text;
        }
        public void ClickOnConfirm()
        {
            _btnConfirm.JSClickWithFocus(Driver);
            Settings.EnCompassExtentTest.Info("Clicked Confirm button");
            this.AttachOnDemandScreenShot();
        }

        public bool IsCancelExist()
        {
            try
            {
                bool b = _btnCancel.Displayed;
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }
        public bool IsArchiveExist()
        {
            try
            {
                bool b = _btnArchive.Displayed;
                Settings.EnCompassExtentTest.Info("Archive Button exists");
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }
        public bool IsUpdateExist()
        {
            try
            {
                bool b = _btnUpdate.Displayed;
                Settings.EnCompassExtentTest.Info("Update Button exists");
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }
        public void ClickOnUpdate()
        {
            _btnUpdate.JSClickWithFocus(Driver);
            Settings.EnCompassExtentTest.Info("Clicked Update button");
        }

        public void ClickOnCreate()
        {

            _btnCreate.JSClickWithFocus(Driver);
            Settings.EnCompassExtentTest.Info("Clicked Create button");
        }

        public void SetPostOnly()
        {
            _postOnly.JSClickWithFocus(Driver);
            Settings.EnCompassExtentTest.Info("Enabled Post Only Option");
        }

        public void SelectUserRole(string role)
        {
            IWebElement _userRole = Driver.FindElement(By.XPath("//div[contains(@id,'editAnnouncement')]//label[contains(text(),'" + role + "')]"));
            _userRole.JSClickWithFocus(Driver);
            Settings.EnCompassExtentTest.Info("Enabled Annoncement for specific roles");
        }

        public New(GlobalSettings settings) : base(settings) { }
    }
}
