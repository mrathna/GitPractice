package com.framework.testcases.OLS.ZEnergy.Customer;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.OLS.common.LoginPage;
import com.framework.pages.Z.ZCardsPage;
import com.framework.pages.Z.ZHomePage;
import com.framework.util.PropUtils;

public class ValidateSuperUserTestCases extends BaseTest {

	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "Smoke" })
	public void verifyDesktopOLSSuperUserCanAbleToAccessOLS(@Optional("Z") String clientCountry,
			@Optional("ZEnergy") String clientName) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  Verify that Desktop OLS super user can able to access OLS",
				"Verify that Desktop OLS super user can able to access OLS");

		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		ZHomePage zHomePage = new ZHomePage(driver, test);
		loginPage.validateLoginPageFooterLinks(clientName, "ZEnergy_SU_URL");

		loginPage.SuperUserLogin("ZEnergy_SU_URL", "ZEnergy_SU_UID_" + clientCountry,
				"ZEnergy_SU_UN_Customer_" + clientCountry, "ZEnergy_SU_PWD_Customer_" + clientCountry, clientName);
		// validate selected User Account is Visible On Sub menu pages
		zHomePage.validateUserAccountShouldBeVisibleOnSubmenu();
		loginPage.Logout();
	}

	@Parameters({ "clientCountry", "clientName" })
	@Test(priority =37, groups = { "Smoke" })
	public void verifyOrderCardUsingSuperUserS(@Optional("Z") String clientCountry,
			@Optional("ZEnergy") String clientName) {

		test = extent.createTest(
				"Verify Able to Order card after clicking Confirm button and a success message will display",
				"Verify Able to Order card after clicking Confirm button and a success message will display");

		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);

		ZCardsPage zCardPage = new ZCardsPage(driver, test);
		loginPage.validateLoginPageFooterLinks(clientName, "ZEnergy_SU_URL");
		loginPage.SuperUserLogin("ZEnergy_SU_URL", "ZEnergy_SU_UID_" + clientCountry,
				"ZEnergy_SU_UN_Customer_" + clientCountry, "ZEnergy_SU_PWD_Customer_" + clientCountry, clientName);
		// go To Card Menu OrderCar page
		zCardPage.goToCardMenuOrderCard();
		// Order a card
		zCardPage.validateProtectedFieldsAndOderZBusinessCard();

		loginPage.Logout();
	}

	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "Smoke" })
	public void verifyInvalidLoginAttemptAndMandatoryfeildValidation(@Optional("Z") String clientCountry,
			@Optional("ZEnergy") String clientName) {

		test = extent.createTest(
				"Verify that validation error will occur when mandatory feilds are empty or invalid inputs",
				"Verify that validation error will occur when mandatory feilds are empty or invalid inputs");

		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		
		loginPage.validateLoginPageFooterLinks(clientName, "ZEnergy_SU_URL");

		/*// validate ErrorMsg Valid SuperUserId And UserId And EmptyPassword
		loginPage.loginWithSuperUserIdAndUserIdAndPwd(
				PropUtils.getPropValue(configProp, "ZEnergy_SU_UID_" + clientCountry),
				PropUtils.getPropValue(configProp, "ZEnergy_SU_UN_Customer_" + clientCountry), "");
		loginPage.validateErrorMsgValidSuperUserIdAndUserIdAndEmptyPassword();

		// validate ErrorMsg Valid Super UserId And UserId And InvalidPassword
		loginPage.loginWithSuperUserIdAndUserIdAndPwd(
				PropUtils.getPropValue(configProp, "ZEnergy_SU_UID_" + clientCountry),
				PropUtils.getPropValue(configProp, "ZEnergy_SU_UN_Customer_" + clientCountry), "invalidpwd");
		loginPage.validateErrorMsgValidSuperUserIdAndUserIdAndInvalidPassword();*/

		// validate ErrorMsg Valid SuperUserId And InvalidUserId And Password
		loginPage.loginWithSuperUserIdAndUserIdAndPwd(
				PropUtils.getPropValue(configProp, "ZEnergy_SU_UID_" + clientCountry), "InvalidUId",
				PropUtils.getPropValue(configProp, "ZEnergy_SU_PWD_Customer_" + clientCountry));
		loginPage.validateErrorMsgValidSuperUserIdAndInvalidUserIdAndPassword();

		// loginPage.Logout();
	}
}
