package com.framework.pages.CHEV;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.ExtentTest;
import com.framework.basepage.BasePage;
import com.framework.repo.Locator;

public class CHChangeCardStatusPage extends BasePage {

	@FindBy(how = How.XPATH, using = Locator.SCHEDULE_REPORT_MAINTENANCE_PAGE)
	public WebElement cardChangeStatusPage;

	@FindBy(how = How.ID, using = Locator.CH_CHANGE_STATUS_PAGE_COUNTRY)
	public WebElement countryDropdown;

	@FindBy(how = How.ID, using = Locator.CH_CHANGE_STATUS_PAGE_DATE)
	public WebElement dateField;

	@FindBy(how = How.ID, using = Locator.DELIVER_CONFIRM_AND_REISSUE)
	public WebElement saveButton;

	@FindBy(how = How.XPATH, using = Locator.CH_CHANGE_STATUS_ERROR_MSG)
	public WebElement errorMessage;

	@FindBy(how = How.XPATH, using = Locator.CH_CHANGE_STATUS_CARD_STATUS_DROPDOWN)
	public WebElement cardStatusDropDown;

	@FindBy(how = How.ID, using = Locator.CH_CHANGE_STATUS_ACCOUNT_NUMBER)
	public WebElement accountNumber;

	@FindBy(how = How.XPATH, using = Locator.CH_CHANGE_STATUS_SUCCESS_MSG)
	public WebElement successMessage;

	@FindBy(how = How.XPATH, using = Locator.CH_CHANGE_STATUS_SUCCESS_MSG_2)
	public WebElement statusChangeSuccessMessage;

	@FindBy(how = How.XPATH, using = Locator.BACK_TO_CARD_LIST)
	public WebElement backToCardList;

	@FindBy(how = How.ID, using = Locator.CH_REPLACE_CARD_POPUP_TITLE)
	public WebElement popUpMessageTitle;

	@FindBy(how = How.ID, using = Locator.CH_CONFIRMATION_POPUP_MESSAGE)
	public WebElement popUpMessageContent;

	@FindBy(how = How.ID, using = Locator.CARDSTATUSCHANGE_POPUP_YESBUTTON)
	public WebElement popUpReplaceButton;

	@FindBy(how = How.ID, using = Locator.CARDSTATUSCHANGE_POPUP_NOBUTTON)
	public WebElement popUpDontReplaceButton;

	@FindBy(how = How.XPATH, using = Locator.CH_RELPACE_CONFIRM_ERROR_MESSAGE)
	public WebElement replaceCardConfirmationErrorMessage;
	@FindBy(id = Locator.UPDATE_BUTTON)
	public WebElement updateButton;

	public CHChangeCardStatusPage(WebDriver driver, ExtentTest test) {
		super(driver, test);
		// TODO Auto-generated constructor stub
		PageFactory.initElements(driver, this);
	}

	public void verifyChangeCardStatusPage() {
		sleep(3);
		isDisplayed(cardChangeStatusPage, "Change Card Status");
		logPass("Redirected to the Change Card Status Page");
		sleep(5);

	}

	public void verifyCountryDropDown() {
		scrollDownPage();
		sleep(5);
		if (countryDropdown.isDisplayed()) {
			logPass("Country Drop down is displayed");
		} else {
			logFail("Country Drop down is not displayed");
		}

	}

	public void validateDateField(String date) {

		if (dateField.isDisplayed()) {
			dateField.sendKeys(date);
			logPass("Entered Invalid date to the date field");
		} else {
			logFail("Date Field is not displayed");
		}
		if (saveButton.isDisplayed()) {
			actionClick(saveButton);
			logInfo("Save Button is clicked");
		} else {
			logFail("Save Button is not displayed");
		}

		sleep(5);
		if (errorMessage.isDisplayed()) {
			logPass("Invalid Date error is displayed");
		} else {
			logFail("Invalid Date error is not displayed");
		}

	}

	public void checkAccountNumber() {

		if (accountNumber.isDisplayed()) {
			logPass("Account Number is displayed in the table");
		} else {
			logFail("Account Number is not displayed in the table");
		}
	}

	public void changeCardStatusAndSave(String optionValue) {
		selectDropDownByVisibleText(cardStatusDropDown, optionValue);
		
		sleep(5);
		if (saveButton.isDisplayed()) {
			actionClick(saveButton);
			System.out.println("save button is clicked");
			logInfo("Save Button is clicked");
		} else {
			logFail("Save Button is not displayed");
		}

	}
	public void clickUpdateButton() {
		String optionValue="Stolen";
		selectDropDownByVisibleText(cardStatusDropDown, optionValue);
		scrollDownPage();
		scrollDownPage();
		sleep(10);
		isDisplayedThenClick(updateButton, "Click Update Button");
		sleep(10);
		scrollToTopPage();
		scrollToTopPage();
	}

	public void verifyPopUpTitle(String message) {
		sleep(10);
		waitForElementTobeClickable(popUpDontReplaceButton, 10);
		if (popUpMessageTitle.isDisplayed()) {
			if (message.equals(popUpMessageTitle.getText())) {
				System.out.println(message + " is displayed");
				logPass(message + " is displayed");
			} else {
				logFail(message + "is not displayed");
			}
		} else {
			logFail(message + "is not displayed");
		}
	}

	public void clickPopUpReplaceBtn() {
		if (popUpReplaceButton.isDisplayed()) {
			actionClick(popUpReplaceButton);
			logInfo("Replace Pop up Button is clicked");
		} else {
			logFail("Replace pop btn not found");
		}
	}

	public void clickPopUpDontReplaceBtn() {
		if (popUpDontReplaceButton.isDisplayed()) {
			actionClick(popUpDontReplaceButton);
			logInfo("Replace Pop up Button is clicked");
		} else {
			logFail("Replace pop btn not found");
		}
	}

	public void checkStatusMessage(String actualValue) {
		sleep(15);
	//	String message = getText(successMessage);
		String message = getText(statusChangeSuccessMessage);
		System.out.println(message);
		if (message.contains(actualValue)) {
			System.out.println("message is displayed");
			logPass(message + "message is Displayed");
		} else {
			logFail(message + "message is not Displayed");
		}

	}

	public void navigateBacktoCardList() {
		if (backToCardList.isDisplayed()) {
			actionClick(backToCardList);
		}
		sleep(3);
	}

	public void verifyErrorConfirmationMessage(String message) {
		sleep(5);
		if (replaceCardConfirmationErrorMessage.isDisplayed()) {
			String actualText = replaceCardConfirmationErrorMessage.getText();
			if (actualText.equals(message)) {
				System.out.println(actualText);
				logPass(message + "is displayed");
			} else {
				logFail(message + "is not displayed");
			}
		} else {
			logFail(message + "is not displayed");
		}
	}

	public void verifySuccessConfirmationMessage() {
		sleep(5);
		if (statusChangeSuccessMessage.isDisplayed()) {
			logPass("Card Status Changed successfully");
		} else {
			logFail("Could not change card status after clicking replace button");
		}
	}

	public boolean verifyValuePresentInNewStatus(String actualValue) {
		// TODO Auto-generated method stub
		
		sleep(5);
		boolean isOptionPresent = isTextPresentInDropDown(cardStatusDropDown, actualValue);
		System.out.println(isOptionPresent);
		
		return isOptionPresent;
		
		
	}

	public boolean errorMessageHandle() {
		// TODO Auto-generated method stub
		boolean iserrorMessagePresent;
		
		iserrorMessagePresent = waitForTextToAppear("Invalid card status change combination", 30);		
		
		return iserrorMessagePresent;
		
	}

}
