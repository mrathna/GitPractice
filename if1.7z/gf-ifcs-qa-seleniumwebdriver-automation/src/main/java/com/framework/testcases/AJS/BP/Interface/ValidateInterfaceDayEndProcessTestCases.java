package com.framework.testcases.AJS.BP.Interface;


import java.util.Map;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.MaintainCustomerPage;

import com.framework.pages.AJS.common.Common;
import com.framework.pages.AJS.common.CommonInterfacePage;
import com.framework.pages.AJS.common.IFCSCommonPage;

import com.framework.pages.AJS.common.IFCSLoginPage;


public class ValidateInterfaceDayEndProcessTestCases extends BaseTest {

	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "Smoke" })
	public void validateAndApplyAllCardFeeProcess(@Optional("NZ") String clientCountry,
			@Optional("BP") String clientName) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  BP Interface Apply all card fees process via DayEnd",
				"BPNZ15_Cust_NZ_005_Apply all card fees process");
		/*
		 * //creating object for the Pages IFCSLoginPage ifcsloginPage = new
		 * IFCSLoginPage(driver, test); IFCSHomePage ifcsHomePage = new
		 * IFCSHomePage(driver, test); Common common = new Common(driver, test);
		 * MaintainCustomerPage maintainCustomerPage=new MaintainCustomerPage(driver,
		 * test);
		 * 
		 * ifcsloginPage.login("IFCS_URL_BP", "IFCS_BP_USERNAME", "IFCS_BP_PASSWORD");
		 * ifcsloginPage.setClientCountryCardTypeDetails(clientName, clientCountry," ");
		 * ifcsHomePage.gotoApplicationAndClickApplicationMenu();
		 * ifcsHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" +
		 * clientCountry); ifcsHomePage.gotoCustomerMenuCustomerDetails(); //get
		 * CustomerNo having more than 5 cards from DB String
		 * customer_No=common.getCustomerNoHavingMoreThan5ActiveCards();
		 * //common.chooseCustomerNoAndSearch("0110212054");
		 * common.chooseCustomerNoAndSearch(customer_No);
		 * maintainCustomerPage.chooseMaintainCardFeesFromCustomerProfile();
		 * //maintainCustomerPage.validateDefaultCardFeeProfileForAllCards(); String
		 * profileName=maintainCustomerPage.validateAndSetCardFeeProfileForCustomer();
		 * //****Need to Write DayEnd Process**** System.out.println(profileName);
		 * maintainCustomerPage.validateCardFeeProfileAppliedToAllCards("Card List"
		 * ,"Card Number","Profile Selection",profileName,"AfterDayEnd");
		 * 
		 * ifcsHomePage.exitIFCS();
		 */
		Common common = new Common(driver, test);
		MaintainCustomerPage maintainCustomerPage = new MaintainCustomerPage(driver, test);
		String cardFeeDescription = common.getCardFeeProfileDescription("0100008270");// static customer number added
		maintainCustomerPage.verifyCardFeeProfile(cardFeeDescription, "Premium no card admin fee"); // static card fee
																									// profile added

	}

	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "Smoke" })
	public void validateR3ReportFiles(@Optional("NZ") String clientCountry, @Optional("BP") String clientName) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  BPNZ59_Interface_NZ_002_R3 DataWarehouse",
				"BPNZ59_Interface_NZ_002_R3 DataWarehouse");
		// creating object for the Pages
		
		
		CommonInterfacePage commonInterfacePage = new CommonInterfacePage(driver, test);
		
		commonInterfacePage.getR3xmlFileAndValidate(clientName, clientCountry);

	}

	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "Smoke" })
	public void validateCT13ReportFiles(@Optional("NZ") String clientCountry, @Optional("BP") String clientName) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  Interface_001_CT13 ProductSalesVolumes", "Interface_001_CT13 ProductSalesVolumes");
		// creating object for the Pages
		
		CommonInterfacePage commonInterfacePage = new CommonInterfacePage(driver, test);
		
		commonInterfacePage.getCT13xmlFileAndValidate(clientName, clientCountry);
		// ifcsCommonPage.validateXMLFileAndValue(filePath, clientCountry)

	}

	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "Smoke" })
	public void cardSalesAggregateValidate(@Optional("NZ") String clientCountry, @Optional("BP") String clientName) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  BPNZ60_Interface_NZ_003_R4 Card Sales Aggregate",
				"BPNZ60_Interface_NZ_003_R4 Card Sales Aggregate");
		// creating object for the Pages
		
		CommonInterfacePage commonInterfacePage = new CommonInterfacePage(driver, test);
		
		commonInterfacePage.getCT13xmlFileAndValidate(clientName, clientCountry);
		// ifcsCommonPage.validateXMLFileAndValue(filePath, clientCountry)

	}

	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "Smoke" })
	public void validateAndVerifySuspensePosting(@Optional("NZ") String clientCountry,
	@Optional("BP") String clientName) {

	test = extent.createTest(clientName+ ":" +clientCountry+"  Trans_AU_003_Suspense posting", "Trans_AU_003_Suspense posting");
	// creating object for the Pages
	String refNo = "0911024";
	IFCSLoginPage ifcsloginPage = new IFCSLoginPage(driver, test);
	Common common = new Common(driver, test);
	IFCSCommonPage ifcsCommonPage = new IFCSCommonPage(driver, test);
	CommonInterfacePage commonInterfacePage = new CommonInterfacePage(driver, test);

	ifcsloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, " ");
	Map<String,String> transactionsDetails = common.getCustomerTransactions(refNo);
	/*System.out.println("Transaction details::"+transactionsDetails);
	System.out.println("transactions : " + transactionsDetails);*/
	String fileName=commonInterfacePage.getRecentProcessedReportFiles( clientName, clientCountry,
	"Day Trans List Detail","");
	String dayEndDatePath=commonInterfacePage.getFolderPathUsingPreviousProcessingDate(clientName, clientCountry,"IFCS_DAYEND_OUTPUTFILE_AU");
	System.out.println("dayEndDatePath::" +dayEndDatePath);
	ifcsCommonPage.establishThePuttyConnection("incomingFile", "PUTTY_HOST", "PUTTY_USERNAME", "PUTTY_PASSWORD", dayEndDatePath, fileName);	

	System.out.println("fileName::" + fileName);

	ifcsCommonPage.validateSuspensePostingReportForTransaction(fileName,transactionsDetails);
	}

}
