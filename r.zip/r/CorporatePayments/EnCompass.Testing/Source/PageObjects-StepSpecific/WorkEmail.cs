﻿using Common;
using Common.Utility;
using EnCompass.Testing.Source.PageObjects.Organization;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EnCompass.Testing.Source.PageObjects_StepSpecific
{
	public class WorkEmail : EnCompassOrgPageModel
	{

		[FindsBy(How = How.XPath, Using = @"//select[contains(@id, 'searchTermSelect')]")]
		private IWebElement _searchTermList { get; set; }

		[FindsBy(How = How.XPath, Using = @"//label[text()= 'Work email address']")]
		private IWebElement _workEmailLbl { get; set; }

		public const string EXPAND_ALL_XPATH = "//button[@data-accordion-expand-text='Expand All'][1]";


		public string SearchTermValues
		{
			get
			{
				return _searchTermList.Text;
			}
		}

		public string WorkEmailLbl
		{
			get
			{
				return _workEmailLbl.Text;
			}
		}

		public bool HasAccordion()
		{
			return Driver.IsElementPresent(By.XPath(EXPAND_ALL_XPATH));
		}

		public void ExpandAll()
		{
			var element = Driver.FindElement(By.XPath(EXPAND_ALL_XPATH));
			var data = Driver.FindElement(By.XPath(EXPAND_ALL_XPATH)).GetAttribute("data-action");
			if (data == "collapse")
			{
				element.JSClickWithFocus(Driver);
				WebDriverWait wait = new WebDriverWait(Driver, System.TimeSpan.FromSeconds(10));
				wait.Until(ExpectedConditions.TextToBePresentInElement(element, "Expand All"));
				element.JSClickWithFocus(Driver);
				wait.Until(ExpectedConditions.TextToBePresentInElement(element, "Collapse All"));
			}

			if (data == "expand")
			{
				element.JSClickWithFocus(Driver);
				WebDriverWait wait = new WebDriverWait(Driver, System.TimeSpan.FromSeconds(10));
				wait.Until(ExpectedConditions.TextToBePresentInElement(element, "Collapse All"));
			}
		}


		public WorkEmail(GlobalSettings settings) : base(settings) { }
	}
}
