using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using Common;
using Common.PageObjects;
using Common.ScenarioConfigurations;
using Common.Utility;

namespace EnCompass.Testing.Source.PageObjects.Organization.Admin.FileUpload 
{
	/// <summary>
	/// Auto-generated Page Model Class
	/// Navigation Paths: 
		/// [Organization Home]->Administration->File Uploads->Accounts Payable
		/// [Organization Home]->Administration->File Uploads->New Cards
		/// [Organization Home]->Administration->File Uploads->Card Update
		/// [Organization Home]->Administration->File Uploads->Notifications
		/// [Organization Home]->Administration->File Uploads->Users
		/// [Organization Home]->Administration->File Uploads->User Update
		/// [Organization Home]->Administration->File Uploads->Financial Codes
		/// [Organization Home]->Administration->File Uploads->Workflow Hierarchy
		/// </summary>
	[PageModel(@"/admin/FileUpload/UploadFile.aspx")]
	public partial class UploadFile : EnCompassOrgPageModel 
	{
		public override string RelativeUrl => @"/admin/FileUpload/UploadFile.aspx";
		public override string PageIdentifierXPath_Generated => @"//li[contains(@class, 'breadcrumb-item active')][text() = 'Upload Accounts Payable File' or text() = 'Upload New Cards File' or text() = 'Upload Card Update File' or text() = 'Upload Notifications File' or text() = 'Upload Users File' or text() = 'Upload User Update File' or text() = 'Upload Financial Codes File' or text() = 'Upload Workflow Hierarchy File']";

		#region Navigation
				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='History']")]
		private IWebElement _administration_FileUploads_AccountsPayable_History { get; set; }
		public void NavigateTo_Administration_FileUploads_AccountsPayable_History()
		{
			NavigateToMenuItem(_administration_FileUploads_AccountsPayable_History);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Accounts Payable']")]
		private IWebElement _administration_FileUploads_AccountsPayable_AccountsPayable { get; set; }
		public void NavigateTo_Administration_FileUploads_AccountsPayable_AccountsPayable()
		{
			NavigateToMenuItem(_administration_FileUploads_AccountsPayable_AccountsPayable);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='New Cards']")]
		private IWebElement _administration_FileUploads_AccountsPayable_NewCards { get; set; }
		public void NavigateTo_Administration_FileUploads_AccountsPayable_NewCards()
		{
			NavigateToMenuItem(_administration_FileUploads_AccountsPayable_NewCards);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Card Update']")]
		private IWebElement _administration_FileUploads_AccountsPayable_CardUpdate { get; set; }
		public void NavigateTo_Administration_FileUploads_AccountsPayable_CardUpdate()
		{
			NavigateToMenuItem(_administration_FileUploads_AccountsPayable_CardUpdate);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Notifications']")]
		private IWebElement _administration_FileUploads_AccountsPayable_Notifications { get; set; }
		public void NavigateTo_Administration_FileUploads_AccountsPayable_Notifications()
		{
			NavigateToMenuItem(_administration_FileUploads_AccountsPayable_Notifications);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Users']")]
		private IWebElement _administration_FileUploads_AccountsPayable_Users { get; set; }
		public void NavigateTo_Administration_FileUploads_AccountsPayable_Users()
		{
			NavigateToMenuItem(_administration_FileUploads_AccountsPayable_Users);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='User Update']")]
		private IWebElement _administration_FileUploads_AccountsPayable_UserUpdate { get; set; }
		public void NavigateTo_Administration_FileUploads_AccountsPayable_UserUpdate()
		{
			NavigateToMenuItem(_administration_FileUploads_AccountsPayable_UserUpdate);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Financial Codes']")]
		private IWebElement _administration_FileUploads_AccountsPayable_FinancialCodes { get; set; }
		public void NavigateTo_Administration_FileUploads_AccountsPayable_FinancialCodes()
		{
			NavigateToMenuItem(_administration_FileUploads_AccountsPayable_FinancialCodes);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Workflow Hierarchy']")]
		private IWebElement _administration_FileUploads_AccountsPayable_WorkflowHierarchy { get; set; }
		public void NavigateTo_Administration_FileUploads_AccountsPayable_WorkflowHierarchy()
		{
			NavigateToMenuItem(_administration_FileUploads_AccountsPayable_WorkflowHierarchy);
		}

		
		private void NavigateToMenuItem(IWebElement element)
		{
			Driver.Url = element.GetAttribute("href");
		}
		#endregion

		public UploadFile(GlobalSettings settings) : base(settings) { }
	}  
}
