/*
 * Ayub Khan
 */
package com.framework.testcases.OLS.BP.Customer;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.BP.BPAccountDetailsPage;
import com.framework.pages.BP.BPHomePage;
import com.framework.pages.OLS.common.LoginPage;

public class CheckRemoveAccountLevelPIN extends BaseTest {
	@Parameters({ "clientCountry", "clientName" })	
	@Test( groups = { "Smoke","BusinessFlow" })
	public void testRemovalAccountSteps(@Optional("AU") String clientCountry, @Optional("BP") String clientName)
			throws Exception {
		test = extent.createTest(clientName+ ":" +clientCountry+"  12 - Remove Account Level PIN", "Login to BP and Edit the Account Details Page");
		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		BPHomePage bpHomePage = new BPHomePage(driver, test);
		BPAccountDetailsPage bpAccountdetailsPage = new BPAccountDetailsPage(driver, test);
		// Calling Functions
		loginPage.Login("BP_URL", "BP_UN_WEXSalesCustomer_" + clientCountry, "BP_PWD_WEXSalesCustomer_" + clientCountry,
				clientName);
		bpHomePage.ValidateBPCustomerLogo();
		bpAccountdetailsPage.checkRemoveAccountLevelPINWithSelectDropDownAccount();
		loginPage.Logout();
	}
}
