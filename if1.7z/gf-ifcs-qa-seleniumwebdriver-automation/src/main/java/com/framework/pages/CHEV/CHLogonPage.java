package com.framework.pages.CHEV;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.ExtentTest;
import com.framework.basepage.BasePage;
import com.framework.repo.Locator;
import com.framework.util.PropUtils;

public class CHLogonPage extends BasePage {

	@FindBy(how = How.XPATH, using = Locator.CLIENT_LOGO_IMG)
	public WebElement clientLogo;

	@FindBy(how = How.ID, using = Locator.CH_LEGAL_NOTICE)
	public WebElement legalNoticeLink;

	@FindBy(how = How.ID, using = Locator.CH_PRIVACY_STATEMENT)
	public WebElement privacyStatementLink;

	@FindBy(how = How.XPATH, using = Locator.CH_CONTACT_US)
	public WebElement contactUs;

	@FindBy(how = How.ID, using = Locator.FORGETEMAILPWD)
	public WebElement forgotPassword;

	@FindBy(how = How.ID, using = Locator.REQALOGON)
	public WebElement reqALogOn;

	@FindBy(how = How.XPATH, using = Locator.CH_INVALID_LOGON_ATTEMPT)
	public WebElement invalidLogOnMessage;

	@FindBy(how = How.ID, using = Locator.USERNAME)
	public WebElement username;

	@FindBy(how = How.ID, using = Locator.PASSWORD)
	public WebElement password;

	@FindBy(how = How.ID, using = Locator.SIGNIN)
	public WebElement signin;

	public CHLogonPage(WebDriver driver, ExtentTest test) {
		super(driver, test);
		PageFactory.initElements(driver, this);
	}

	public void Login(String url, String uname, String pwd) {

		driver.get(PropUtils.getPropValue(configProp, url));
		if (username.isDisplayed()) {
			username.clear();
			username.sendKeys(PropUtils.getPropValue(configProp, uname));
			logPass("User Name " + PropUtils.getPropValue(configProp, uname) + " is Entered");
		} else {
			logFail("User Name Field is Not Displayed");
		}

		if (password.isDisplayed()) {
			password.clear();
			password.sendKeys(pwd);

		} else {
			logFail("Password Field is Not Displayed");
		}

		if (signin.isDisplayed()) {
			signin.click();
			logInfo("Clicked on Login");
		} else {
			logFail("Login button is Not Displayed");
		}
	}

	public void clickOnPrivacyPolicyAndVerifyTitle() {
		if (privacyStatementLink.isDisplayed()) {
			String parentWindow = driver.getWindowHandle();
			actionClick(privacyStatementLink);
			switchToNewWindow(parentWindow, driver.getWindowHandles());
			verifyPrivacyWindowTitle();
			sleep(2);
			closeChildAndMoveToParent(parentWindow);
		} else {
			logFail("Privacy Statement is not displayed");
		}
	}

	public void verifyPrivacyWindowTitle() {
		String pageTitle = driver.getTitle();
		if (pageTitle.contains("Privacy Statement | Caltex ")) {
			logPass(pageTitle + "is displayed");	
		} else {
			logFail(pageTitle + "is not displayed");
		}
	}

	public void verifyLegalNoticeWindowTitle() {
		String pageTitle = driver.getTitle();
		if (pageTitle.contains("Terms of Use | Caltex ")) {
			logPass(pageTitle + "is displayed");			
		} else {
			logFail(pageTitle + "is not displayed");
		}
	}

	public void clickOnTermsAndConditions() {
		if (legalNoticeLink.isDisplayed()) {
			actionClick(legalNoticeLink);
		} else {
			logFail("Legal Notice is not displayed");
		}
	}

	public void verifyLogo() {
		if (clientLogo.isEnabled()) {
			actionClick(clientLogo);
		} else {
			logFail("Client Logo is not clickable");
		}
	}

	public void clickOnTOCAndVerifyTitle() {
		if (legalNoticeLink.isDisplayed()) {
			String parentWindow = driver.getWindowHandle();
			actionClick(legalNoticeLink);
			switchToNewWindow(parentWindow, driver.getWindowHandles());
			verifyLegalNoticeWindowTitle();
			sleep(2);
			closeChildAndMoveToParent(parentWindow);
		} else {
			logFail("Legal Notice is not displayed");
		}
	}
	
	public void clickOnContactUs() {
		if (contactUs.isDisplayed()) {
			actionClick(contactUs);
			logPass("Contact Us is clicked");
		} else {
			logFail("Contact Us not found");
		}
	}

	public void clickOnForgotPwd() {
		if (forgotPassword.isDisplayed()) {
			String parentWindow = driver.getWindowHandle();
			actionClick(forgotPassword);
			switchToNewWindow(parentWindow, driver.getWindowHandles());
		} else {
			logFail("Forgot Password is not found");
		}
	}

	public void clickOnRequestLogOn() {
		if (reqALogOn.isDisplayed()) {
			sleep(5);
			String parentWindow = driver.getWindowHandle();
			actionClick(reqALogOn);
			switchToNewWindow(parentWindow, driver.getWindowHandles());
			sleep(5);
		} else {
			logFail("Request Log On is not found");
		}

	}

	public void verifyInvalidLogOnMessage() {
		if (invalidLogOnMessage.isDisplayed()) {
			if (invalidLogOnMessage.getText().contains("temporarily locked")) {
				logPass("User Id is temporarily locked");
			} else {
				logFail("User Id is not temporarily locked");
			}
		} else {
			logFail("Invalid Logon Failed");
		}
	}

}
