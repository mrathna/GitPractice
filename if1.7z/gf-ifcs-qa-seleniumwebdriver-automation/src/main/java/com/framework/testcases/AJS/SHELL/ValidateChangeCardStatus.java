package com.framework.testcases.AJS.SHELL;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.ChangeCardStatus;
import com.framework.pages.AJS.common.Common;
import com.framework.pages.AJS.common.IFCSHomePage;
import com.framework.pages.AJS.common.IFCSLoginPage;

public class ValidateChangeCardStatus extends BaseTest {

	String cardNo;
		// TODO Auto-generated method stub
	// Added by Ayub 19-02-2019
	
	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test( groups = { "Regression" })
	public void ValidateChangecardStolenNotBalAllowedWithReplace(@Optional("RU") String clientCountry,
			@Optional("SHELL") String clientName, @Optional("APA") String cardType) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  01 Change Card status - Stolen - Desktop - Not Bal Allowed - Replace",
				"Stolen And No Balance - Replace");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		ChangeCardStatus changeCardStatus = new ChangeCardStatus(driver, test);

		IFCSloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, cardType);
		// Click search cards
		IFCSHomePage.gotoSearchAndClickCards();
		Common common = new Common(driver, test);
		cardNo = changeCardStatus.searchCardsWithNoBalanceOrWithBalanceAndsetInContext("noBalance","Active");
		if (cardNo.equals(" ")) {
			common.logForNoDataFound(this.getClass().getSimpleName(),
					"Need to Create A Customer with No Balance or with Balance and rerun");
		} else {
			changeCardStatus.verifyCardNumberAndDoubleClick(cardNo);
			changeCardStatus.changeCardStatusAndClickYesAndValidate("Stolen");
		}
		IFCSHomePage.exitIFCS();

	}
		
		

	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test( groups = { "Regression" })
	public void ValidateChangecardStolenNoBalanceWithNoReplace(@Optional("RU") String clientCountry,
			@Optional("SHELL") String clientName, @Optional("APA") String cardType) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  02 Change Card status - Stolen - Desktop - Not Bal Allowed - No Replace",
				"Stolen And No Balance - No Replace");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		ChangeCardStatus changeCardStatus = new ChangeCardStatus(driver, test);

		IFCSloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, cardType);
		// Click search cards
		IFCSHomePage.gotoSearchAndClickCards();
		Common common = new Common(driver, test);
		cardNo = changeCardStatus.searchCardsWithNoBalanceOrWithBalanceAndsetInContext("noBalance","Active");
		if (cardNo.equals(" ")) {
			common.logForNoDataFound(this.getClass().getSimpleName(),
					"Need to Create A Customer with No Balance or with Balance and rerun");
		} else {

			changeCardStatus.verifyCardNumberAndDoubleClick(cardNo);
			changeCardStatus.changeCardStatusAndClickNoAndValidate("Stolen");
		}
			IFCSHomePage.exitIFCS();			
			
		} 
		
	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test( groups = { "Regression" })
	public void ValidateChangecardDamagedNoBalanceWithReplace(@Optional("RU") String clientCountry,
			@Optional("SHELL") String clientName, @Optional("APA") String cardType) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  10 Change Card status - Damaged - Desktop - Not Bal Allowed - Replace",
				" Damaged - Desktop - Not Bal Allowed - Replace");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		ChangeCardStatus changeCardStatus = new ChangeCardStatus(driver, test);
		Common common = new Common(driver, test);
		IFCSloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, cardType);
		// Click search cards
		IFCSHomePage.gotoSearchAndClickCards();

		cardNo = changeCardStatus.searchCardsWithNoBalanceOrWithBalanceAndsetInContext("noBalance","Active");
		if (cardNo.equals(" ")) {
			common.logForNoDataFound(this.getClass().getSimpleName(),
					"Need to Create A Customer with No Balance or with Balance and rerun");
		} else {

			changeCardStatus.verifyCardNumberAndDoubleClick(cardNo);
			changeCardStatus.changeCardStatusAndClickYesAndValidate("Damaged");
		}
		IFCSHomePage.exitIFCS();		
		
	}
		
		
	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test( groups = { "Regression" })
	public void ValidateChangecardDamagedNoBalanceWithNoReplace(@Optional("RU") String clientCountry,
			@Optional("SHELL") String clientName, @Optional("APA") String cardType) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  11  Change Card status - Damaged - Desktop - Not Bal Allowed - No Replace",
				"Damaged - Desktop - Not Bal Allowed - No Replace");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		ChangeCardStatus changeCardStatus = new ChangeCardStatus(driver, test);

		IFCSloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, cardType);
		// Click search cards
		IFCSHomePage.gotoSearchAndClickCards();
		Common common = new Common(driver, test);
		cardNo = changeCardStatus.searchCardsWithNoBalanceOrWithBalanceAndsetInContext("noBalance","Active");
		if (cardNo.equals(" ")) {
			common.logForNoDataFound(this.getClass().getSimpleName(),
					"Need to Create A Customer with No Balance or with Balance and rerun");
		} else {

			changeCardStatus.verifyCardNumberAndDoubleClick(cardNo);
			changeCardStatus.changeCardStatusAndClickNoAndValidate("Damaged");
		}
			
			IFCSHomePage.exitIFCS();	
			
		}
	
	
	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test( groups = { "Regression" })
	public void ValidateChangecardActiveToLostNoBalanceWithReplace(@Optional("RU") String clientCountry,
			@Optional("SHELL") String clientName, @Optional("APA") String cardType) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  06 Change Card status - Lost - Desktop - Not Bal Allowed - Replace",
				"Lost - Desktop - Not Bal Allowed - Replace");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		ChangeCardStatus changeCardStatus = new ChangeCardStatus(driver, test);
		Common common = new Common(driver, test);
		IFCSloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, cardType);
		// Click search cards
		IFCSHomePage.gotoSearchAndClickCards();

		cardNo = changeCardStatus.searchCardsWithNoBalanceOrWithBalanceAndsetInContext("noBalance","Active");
		if (cardNo.equals(" ")) {
			common.logForNoDataFound(this.getClass().getSimpleName(),
					"Need to Create A Customer with No Balance or with Balance and rerun");
		} else {
			changeCardStatus.verifyCardNumberAndDoubleClick(cardNo);
			changeCardStatus.changeCardStatusAndClickYesAndValidate("Lost");
		}
		IFCSHomePage.exitIFCS();

	}

	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test( groups = { "Regression" })
	public void ValidateChangecardActiveToLostNoBalanceWithNoReplace(@Optional("RU") String clientCountry,
			@Optional("SHELL") String clientName, @Optional("APA") String cardType) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  07 Change Card status - Lost - Desktop - Not Bal Allowed - No Replace ",
				"Lost - Desktop - Not Bal Allowed - No Replace ");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		ChangeCardStatus changeCardStatus = new ChangeCardStatus(driver, test);
		Common common = new Common(driver, test);
		IFCSloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, cardType);
		// Click search cards
		IFCSHomePage.gotoSearchAndClickCards();

		cardNo = changeCardStatus.searchCardsWithNoBalanceOrWithBalanceAndsetInContext("noBalance","Active");
		if (cardNo.equals(" ")) {
			common.logForNoDataFound(this.getClass().getSimpleName(),
					"Need to Create A Customer with No Balance or with Balance and rerun");
		} else {
			changeCardStatus.verifyCardNumberAndDoubleClick(cardNo);
			changeCardStatus.changeCardStatusAndClickNoAndValidate("Lost");
		}
			
			IFCSHomePage.exitIFCS();
			
		} 
		
// Added by Ayub 20-02-2019 - With Balance cards test cases 

	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test( groups = { "Regression" })
	public void ValidateChangecardStolenWithBalanceWithNoReplace(@Optional("RU") String clientCountry,
			@Optional("SHELL") String clientName, @Optional("APA") String cardType) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  03 Change Card status - Stolen - Desktop - Bal Allowed - No Replace",
				"Stolen And With Balance -No Replace");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		ChangeCardStatus changeCardStatus = new ChangeCardStatus(driver, test);
		Common common = new Common(driver, test);
		IFCSloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, cardType);
		// Click search cards
		IFCSHomePage.gotoSearchAndClickCards();
		// Search No Balance cards and set as context
		cardNo = changeCardStatus.searchCardsWithNoBalanceOrWithBalanceAndsetInContext("withBalance","Active");
		if (cardNo.equals(" ")) {
			common.logForNoDataFound(this.getClass().getSimpleName(),
					"Need to Create A Customer with No Balance or with Balance and rerun");
		} else {
			// Double click on card and set as context
			changeCardStatus.verifyBalanceCardNumberAndDoubleClick();
			// Get the card Available Balance
			changeCardStatus.getCardBalance();
			// Go to Account Details page
			IFCSHomePage.gotoAccountAndClickAccountDetails();
			// Get the Account Actual Balance
			String currentBalance = changeCardStatus.getAccountBalance();
			String cardBalance=changeCardStatus.getCardBalance();
			// Go to previous page
			IFCSHomePage.clickBackIcon();
			// Change cared status Active to Stolen
			changeCardStatus.changeCardStatusAndClickNoAndValidate("Stolen");

			// Go to Account Details page
			IFCSHomePage.gotoAccountAndClickAccountDetails();
			//
			String updatedtBalance = changeCardStatus.getAccountBalance();
			// Validate current available balance
			changeCardStatus.checkCurrentAvailableBalance(currentBalance, updatedtBalance,cardBalance, "Account");

		}
		IFCSHomePage.exitIFCS();

	} 

	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test( groups = { "Regression" })
	public void ValidateChangecardStolenWithBalanceWithReplace(@Optional("RU") String clientCountry,
			@Optional("SHELL") String clientName, @Optional("APA") String cardType) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  Verify 04 Change Card status - Stolen - Desktop - Bal Allowed - Replace",
				"Stolen And With Balance -Replace");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		ChangeCardStatus changeCardStatus = new ChangeCardStatus(driver, test);
		Common common = new Common(driver, test);
		IFCSloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, cardType);
		// Click search cards
		IFCSHomePage.gotoSearchAndClickCards();
		// Search No Balance cards and set as context
		cardNo = changeCardStatus.searchCardsWithNoBalanceOrWithBalanceAndsetInContext("withBalance","Active");
		if (cardNo.equals(" ")) {
			common.logForNoDataFound(this.getClass().getSimpleName(),
					"Need to Create A Customer with No Balance or with Balance and rerun");
		} else {
			// Double click on card and set as context
			changeCardStatus.verifyBalanceCardNumberAndDoubleClick();
			// Get the card before Available Balance
			String beforeBalance = changeCardStatus.getCardBalance();
			// Change card status Active to stolen and click Yes in the pop up
			changeCardStatus.changeCardStatusAndClickYesAndValidate("Stolen");
			// Go to previous page
			IFCSHomePage.clickBackIcon();
			// Get the card Available Balance
			String afterBalance = changeCardStatus.getCardBalance();
			changeCardStatus.checkCurrentAvailableBalance(beforeBalance, afterBalance," ", "Card");

		}
		IFCSHomePage.exitIFCS();
	} 
	
	
	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test( groups = { "Regression" })
	public void ValidateChangecardLostWithBalanceWithNoReplace(@Optional("RU") String clientCountry,
			@Optional("SHELL") String clientName, @Optional("APA") String cardType) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  08 Change Card status - Lost - Desktop - Bal Allowed - No Replace",
				"Lost And With Balance -No Replace");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		ChangeCardStatus changeCardStatus = new ChangeCardStatus(driver, test);
		Common common = new Common(driver, test);
		IFCSloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, cardType);
		//Click search cards
		IFCSHomePage.gotoSearchAndClickCards();
		// Search No Balance cards and set as context
		cardNo = changeCardStatus.searchCardsWithNoBalanceOrWithBalanceAndsetInContext("withBalance","Active");
		if (cardNo.equals(" ")) {
			common.logForNoDataFound(this.getClass().getSimpleName(),
					"Need to Create A Customer with No Balance or with Balance and rerun");
		} else {
			// Double click on card and set as context
			changeCardStatus.verifyBalanceCardNumberAndDoubleClick();
			// Get the card Available Balance
		//	changeCardStatus.getCardBalance();
			String cardBalance = changeCardStatus.getCardBalance();
			// Go to Account Details page
			IFCSHomePage.gotoAccountAndClickAccountDetails();
			// Get the Account Actual Balance
			String currentBalance = changeCardStatus.getAccountBalance();
			// Go to previous page
			IFCSHomePage.clickBackIcon();
			// Change cared status Active to Stolen
			changeCardStatus.changeCardStatusAndClickNoAndValidate("Lost");

			// Go to Account Details page
			IFCSHomePage.gotoAccountAndClickAccountDetails();
			// Get updated balance
			String updatedtBalance = changeCardStatus.getAccountBalance();
			// Validate current available balance
			changeCardStatus.checkCurrentAvailableBalance(currentBalance, updatedtBalance,cardBalance, "Account");

		}
		IFCSHomePage.exitIFCS();
		
	}

	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test( groups = { "Regression" })
	public void ValidateChangecardLostWithBalanceWithReplace(@Optional("RU") String clientCountry,
			@Optional("SHELL") String clientName, @Optional("APA") String cardType) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  05 Change Card status - Lost - Desktop - Bal Allowed - Replace",
				"Lost And With Balance -Replace");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		ChangeCardStatus changeCardStatus = new ChangeCardStatus(driver, test);
		Common common = new Common(driver, test);
		IFCSloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, cardType);
		// Click search cards
		IFCSHomePage.gotoSearchAndClickCards();
		// Search No Balance cards and set as context
		cardNo = changeCardStatus.searchCardsWithNoBalanceOrWithBalanceAndsetInContext("withBalance","Active");
		if (cardNo.equals(" ")) {
			common.logForNoDataFound(this.getClass().getSimpleName(),
					"Need to Create A Customer with No Balance or with Balance and rerun");
		} else {
			// Double click on card and set as context
			changeCardStatus.verifyBalanceCardNumberAndDoubleClick();
			// Get the card before Available Balance
			String beforeBalance = changeCardStatus.getCardBalance();
			// Change card status Active to stolen and click Yes in the pop up
			changeCardStatus.changeCardStatusAndClickYesAndValidate("Lost");
			// Go to previous page
			IFCSHomePage.clickBackIcon();
			// Get the card Available Balance
			String afterBalance = changeCardStatus.getCardBalance();
			// Validate current available balance
			changeCardStatus.checkCurrentAvailableBalance(beforeBalance, afterBalance," ", "Card");
		}
		IFCSHomePage.exitIFCS();

	}

	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test( groups = { "Regression" })
	public void ValidateChangecardDamagedtWithBalanceWithNoReplace(@Optional("RU") String clientCountry,
			@Optional("SHELL") String clientName, @Optional("APA") String cardType) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  12 Change Card status - Damaged - Desktop - Bal Allowed - No Replace",
				"Damaged And With Balance -No Replace");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		ChangeCardStatus changeCardStatus = new ChangeCardStatus(driver, test);
		Common common = new Common(driver, test);
		IFCSloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, cardType);
		// Click search cards
		IFCSHomePage.gotoSearchAndClickCards();
		// Search No Balance cards and set as context
		cardNo = changeCardStatus.searchCardsWithNoBalanceOrWithBalanceAndsetInContext("withBalance","Active");
		if (cardNo.equals(" ")) {
			common.logForNoDataFound(this.getClass().getSimpleName(),
					"Need to Create A Customer with No Balance or with Balance and rerun");
		} else {
			// Double click on card and set as context
			changeCardStatus.verifyBalanceCardNumberAndDoubleClick();
			// Get the card Available Balance
		//	changeCardStatus.getCardBalance();
			String beforeCardBalance= changeCardStatus.getCardBalance();
			// Go to Account Details page
			IFCSHomePage.gotoAccountAndClickAccountDetails();
			// Get the Account Actual Balance
			//String currentBalance = changeCardStatus.getAccountBalance();
			// Go to previous page
			IFCSHomePage.clickBackIcon();
			// Change cared status Active to Damaged
			changeCardStatus.changeCardStatusAndClickNoAndValidate("Damaged");

			// Go to Account Details page
			IFCSHomePage.gotoAccountAndClickAccountDetails();
			//
			//String updatedtBalance = changeCardStatus.getAccountBalance();
			String afterBalance = changeCardStatus.getCardBalance();
			// Validate current available balance
			changeCardStatus.checkCurrentAvailableBalance(beforeCardBalance, afterBalance," ", "DamagedNoReplace");
		}
		IFCSHomePage.exitIFCS();

	}

	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test( groups = { "Regression" })
	public void ValidateChangecardDamagedWithBalanceWithReplace(@Optional("RU") String clientCountry,
			@Optional("SHELL") String clientName, @Optional("APA") String cardType) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  09 Change Card status - Damaged - Desktop - Bal Allowed - Replace",
				"Damaged And With Balance -Replace");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		ChangeCardStatus changeCardStatus = new ChangeCardStatus(driver, test);
		Common common = new Common(driver, test);
		IFCSloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, cardType);
		// Click search cards
		IFCSHomePage.gotoSearchAndClickCards();
		// Search No Balance cards and set as context
		cardNo = changeCardStatus.searchCardsWithNoBalanceOrWithBalanceAndsetInContext("withBalance","Active");
		if (cardNo.equals(" ")) {
			common.logForNoDataFound(this.getClass().getSimpleName(),
					"Need to Create A Customer with No Balance or with Balance and rerun");
		} else {
			// Double click on card and set as context
			changeCardStatus.verifyBalanceCardNumberAndDoubleClick();
			// Get the card before Available Balance
			String beforeBalance = changeCardStatus.getCardBalance();
			// Change card status Active to stolen and click Yes in the pop up
			changeCardStatus.changeCardStatusAndClickYesAndValidate("Damaged");
			// Go to previous page
			IFCSHomePage.clickBackIcon();
			// Get the card Available Balance
			String afterBalance = changeCardStatus.getCardBalance();
			changeCardStatus.checkCurrentAvailableBalance(beforeBalance, afterBalance, " ", "Card");
		}
		IFCSHomePage.exitIFCS();
	} 

		
		


}
