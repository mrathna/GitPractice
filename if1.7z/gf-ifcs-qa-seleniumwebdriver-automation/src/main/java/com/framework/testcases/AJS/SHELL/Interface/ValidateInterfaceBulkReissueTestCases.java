package com.framework.testcases.AJS.SHELL.Interface;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.CardMaintenancePage;
import com.framework.pages.AJS.MaintainCustomerPage;
import com.framework.pages.AJS.common.Common;
import com.framework.pages.AJS.common.IFCSHomePage;
import com.framework.pages.AJS.common.IFCSLoginPage;

public class ValidateInterfaceBulkReissueTestCases extends BaseTest{


	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test(groups = { "Regression" })
	public void ValidateIndividualReportAssignment(@Optional("RU") String clientCountry,
			@Optional("SHELL") String clientName, @Optional("APA") String cardType) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  03 Report Assignment",
				"03 Report Assignment");
		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		CardMaintenancePage cardMaintenancePage = new CardMaintenancePage(driver, test);
		MaintainCustomerPage maintainCustomerPage = new MaintainCustomerPage(driver, test);
		Common common = new Common(driver, test);

		// Calling Functions
		IFCSloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, cardType);
		// selecting customer details
		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		String customerNumber = common.getActiveCustomerNoHavingActiveCardsWithNoBulkReissue();
		if (customerNumber.equals(" ")) {
			common.logForNoDataFound(this.getClass().getSimpleName(),
					"Need to Create A Customer with Card Type and rerun");
		} else {
			common.chooseCardNoAndSearch(customerNumber);

			// select Individual Reports from left panel
			cardMaintenancePage.getIndividualReport();
			//Report Type
			String reportType="Customer Bulk Reissue Card Excel Report";
			//Select Report type from drop down and validate report was saved or not
			maintainCustomerPage.selectIndividualReportsForCustomer(reportType);
			
			//Bulk Reissue
			String currentIFCSDate = common.getCurrentIFCSDateFromDB(clientName + clientCountry);
			String currentProcessingDate = common.enterADateValueInStatusBeginDateField("Current", currentIFCSDate);
			String futureIFCSDate = common.enterADateValueInStatusBeginDateField("Future", currentIFCSDate);
			String wayFutureIFCSDate = common.enterADateValueInStatusBeginDateField("WayFuture", currentIFCSDate);
			String nextDayIFCSDate = common.enterADateValueInStatusBeginDateField("NextDate", currentIFCSDate);
			
			cardMaintenancePage.chooseCardAndCreateBulkReissueRequest(currentProcessingDate ,futureIFCSDate,nextDayIFCSDate);
			cardMaintenancePage.bulkReissueRequestWithValidDate(wayFutureIFCSDate);
		
			
			//need to run 2 DayEnd jobs
			String fileProcessed=null;
			//Verify Stored Report
			maintainCustomerPage.getStoredReport();
			maintainCustomerPage.verifyStoredReportAfterJob(nextDayIFCSDate,reportType,fileProcessed);
		
		}
		
		// Exit IFCS
		IFCSHomePage.exitIFCS();
	}
	
	
	
	
	
	

}
