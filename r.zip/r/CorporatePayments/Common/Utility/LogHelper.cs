﻿using log4net;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Common.Utility
{
	public class Logger
	{
		private static ILog _log;

		public static void CreateInstance(String logName)
		{
			_log = LogManager.GetLogger(logName);
		}

		public static void StartStepLog(String name)
		{
			_log.Info("Start of step: " + name);
		}

		public static void EndStepLog(String name)
		{
			_log.Info("End of step: " + name);
		}

		public static void StartScenarioLog(String name)
		{
			_log.Info("Start of Scenario: " + name);
		}

		public static void EndScenarioLog(String name)
		{
			_log.Info("End of Scenario: " + name);
		}

		public static void LogInfo(String msg)
		{
			_log.Info(msg);
		}
		public static void LogError(String msg)
		{
			_log.Error(msg);
		}
		public static void LogDebug(String msg)
		{
			_log.Debug(msg);
		}
		public static void LogFatal(String msg)
		{
			_log.Fatal(msg);
		}
		public static void LogWarning(String msg)
		{
			_log.Warn(msg);
		}
	}
}
