﻿using AventStack.ExtentReports;
using Common.Utility;
using EnCompass.Testing.Source.PageObjects.Controls;
using NFluent;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using TechTalk.SpecFlow;

namespace EnCompass.Testing.Source.PageObjects.Organization.Payables.MerchantPayments
{
    public enum MerchantLogStatuses { Closed = 0, Open = 1, Reconciled = 2, Matched = 4 }
    public partial class MerchantLogSearch
    {
        public override string PageIdentifierXPath_Override => @"//h1[contains(@id, 'h1title')]";
        private const string HISTORY_BUTTON_XPATH = "//a[contains(text(),'History')]";
        private const string MLOG_COUNT_XPATH = @"//span[contains(@id, 'MerchantLogCount')]";
        private const string NOTE_INPUT_MODAL_XPATH = "//div[contains(@id, 'updateConfirmModalBody')]//input[contains(@id, 'contents_CloseNoteTextBox')]";
        private const string NOTE_SPAN_MODAL_XPATH = "//div[contains(@id, 'updateConfirmModalBody')]//span[contains(@id, 'contents_irfvCloseNote')]";
        private const string MLOG_UPDATE_MODAL_XPATH = "//div[contains(@id, 'updateConfirmModal') and @class = 'modal-content']";
        private const string MLOG_UPDATE_MODAL_SAVE_BUTTON_XPATH = "//div[@id='updateConfirmModalFooter']/input[@value='Save']";

      
        #region Page Objects xpath

        private const string _searchCategoryXPath = @"//select[contains(@id, 'searchTermSelect')]";
        private const string _searchConstraintXPath = @"//select[contains(@id, 'searchTermFilter')]";
        private const string _searchCriteriaTextSearchValueXPath = @"//div[contains(@id,'_SearchOutput_searchTermValueInputGroup')]//input[contains(@id, '_SearchOutput_txt')]";
        private const string _searchCriteriaListboxSearchValueXPath = @"//select[contains(@id, 'SearchOutput_values')]";
        private const string _searchCriteriaAddBtnXPath = @"//input[@type='button' and @value='Add']";
        private const string _searchXPath = @"//input[contains(@id, 'btnSearch')]";
        private const string _clearXPath = @"//button[normalize-space(text())='Clear']";
        private const string _updateXPath = @"//button[@id='btnUpdate']";
        private const string _noMlogsFoundTextXPath = @"//table[contains(@id, 'Mlog')]//td[@class = 'gridNoRecordsMessage']";
        private const string _pagingXPath =  @"//select[contains(@id, 'Top_pageSizesDropdown')]";
        private const string _showSummaryXPath = @"//input[contains(@id, 'btnSummary')]";
        private const string _mlogCountXPath = @"//span[contains(@id, 'MerchantLogCount')]";
        private const string _summaryCloseXPath = @"//div[contains(@id, 'ModalContent_mpMlogSummary')]//button[@type='button' and text()='Close']";
        private const string _saveUpdateXPath = @"//div[contains(@id, 'updateConfirmModalFooter_New')]//button[@id = 'btnSaveNew']";
        private const string _closeUpdateXPath = @"//div[contains(@id, 'updateConfirmModalFooter_New')]//button[@id = 'btnCloseNew']";
        private const string _selectStatusXPath = @"//select[contains(@id, 'Status')]";
        private const string _noMLogsFoundXPath = @"//td[contains(@class, 'gridNoRecordsMessage')]";
        private const string _stopPaymentPopUpXPath = @"//div[contains(@id, 'ModalContent_Modal')]";
        private const string _reissueCheckCancelXPath = @"//button[@type='button' and text()='Cancel']";
        private const string _reissueCheckYesXPath = @"//button[@type='button' and text()='Yes']";
        private const string _selectMLogFormatValueXPath = @"//select[contains(@id, 'ddlExportType')]";
        private const string _noteSpanXPath = @"//div[contains(@id, 'updateConfirmModalBody')]//span[contains(@id, 'contents_irfvCloseNote')]";
        private const string _btnExportGridTextXPath = @"//input[contains(@id, 'btnExportGridText')]";
        private const string _fullscreenBtnXPath = @"//button[@aria-label='Fullscreen']";
        private const string _columnsBtnXPath = @"//button[@aria-label='Columns']";
        private const string _exportBtnXPath = @"//button[@aria-label='Export type']";
        private const string _summaryBtnXPath = @"//input[contains(@id, 'btnNewSummary')]";
        private const string _linkCompareWithPreviousGridXPath = @"//input[contains(@id, 'btnNewSummary')]";
        private const string _saveBtnXPath = @"//button[@id = 'btnUpdate']";
        private const string _noteInputModalXPath = @"//div[contains(@id, 'updateConfirmModalBody')]//input[contains(@id, 'contents_CloseNoteTextBox')]";
        private const string _mlogUpateModalXPath = "//div[contains(@id, 'updateConfirmModal') and @class = 'modal-content']";
        private const string _mlogUpateModlSaveButtonXPath = "//div[@id='updateConfirmModalFooter']/input[@value='Save']";
        private const string _noMLogFoundTextXPath = "//tr[@class = 'no-records-found']//td";
        private const string _modalBaseStatusMerchantXPath = ".//div[contains(@id,'updateConfirmModal') and @data-focus='true']";
        private const string _modalButtonStatusMerchantSaveXPath = "//input[contains(@class,'btn-primary')]";

        private const string _modalSaveAsHeaderXPath = @".//h1[contains(@id, 'SaveAsModal')]";
        private const string _modalRenameHeaderXPath = @".//h1[contains(@id, 'RenameModal')]";
        private const string _gridToolbarProfilesButtonXPath = @".//button[@title = 'Profiles' and contains(@id, '_ProfilesMenuLink')]";
        private const string _gridToolbarProfilesOptionXpath = ".//div[contains(@class, 'profiles dropdown-menu')]/button";
        private const string _newProfileNameXPath = "//input[contains(@id,'SaveAsProfileName')]";
        private const string _setAsDefaultProfileCheckboxXPath = "//input[contains(@id,'SaveAsSetDefault')]";
        private const string _setAsDefaultProfileCheckboxLabelXPath = "//label[contains(@for,'SaveAsSetDefault')]";
        private const string _setOverwriteExistingProfileCheckboxXPath = "//input[contains(@id,'SaveAsOverwrite')]";
        private const string _setOverwriteExistingProfileCheckboxLabelXPath = "//label[contains(@for,'SaveAsOverwrite')]";
        private const string _gridToolbarProfilesNamesXpath = @".//div[contains(@class, 'profiles dropdown-menu')]/div[contains(@id, 'Profile')]/h4";
        private const string _errorRequiredNameMessageXPath = ".//span[contains(@id, 'SaveAsProfileName_Error')]";
        private const string _errorRequiredRenameMessageXPath = ".//span[contains(@id, 'RenameProfileName_Error')]";
        private const string _saveAsSaveButtonXPath = "//button[contains(@id,'SaveAsSave')]";
        private const string _saveAsCancelButtonXPath = "//button[contains(@id,'SaveAsCancel')]";
        private const string _rbSelectProfileXPath = @"//input[contains(@id,'ProfilesRadioContainer') and @data-profile-name ='{0}']";
        private const string _rbSelectProfileLabelXPath = @"//label[contains(@for,'ProfilesRadioContainer') and contains(text(), '{0}')]";
        private const string _rbSelectSetDefaultProfileXPath = @"//input[contains(@id,'ProfilesDefaultRadioContainer') and @data-profile-name ='{0}']";
        private const string _rbSelectSetDefaultProfileLabelXPath = @"//label[contains(@for,'ProfilesDefaultRadioContainer') and contains(text(), '{0}')]";

        private const string _profileSetDefaultCancelButtonXPath = "//button[contains(@id,'profileSetDefaultCancel')]";
        private const string _profileSetDefaultSaveButtonXPath = "//button[contains(@id,'profileSetDefaultSave')]";

        private const string _profileResetCancelXPath = "//button[contains(@id, 'profileResetCancel')]";
        private const string _profileResetXPath = "//button[contains(@id, 'profileReset') and text()='Reset']";

        private const string _profileDeleteCancelButtonXPath = "//button[contains(@id, '_profileDeleteCancel')]";
        private const string _deleteProfileNameXPath = "//button[contains(@id, '_profileDelete') and text()='Delete']";

        private const string _profileSetDefaultModalXPath = ".//div[contains(@id, 'profilesSetDefaultModal') and contains(@style,'block')]";
        private const string _profileSaveAsModalXPath = ".//div[contains(@id, 'profilesSaveAsModal') and contains(@style,'block')]";
        private const string _profileResetModalXPath = ".//div[contains(@id, 'profilesResetModal') and contains(@style,'block')]";
        private const string _profileDeleteModalXPath = ".//div[contains(@id, 'profilesDeleteModal') and contains(@style,'block')]";
        private const string _profileRenameModalXPath = ".//div[contains(@id, 'profilesRenameModal') and contains(@style,'block')]";

        private const string _profilesNameXPath = @".//div[contains(@class, 'profiles dropdown-menu')]//div[contains(@id, 'Profile')]/h4[contains(text(), '{0}')]";
        private const string _profileControlsXPath = "//following-sibling::div/button";

        private const string _renameProfileNameXPath = "//input[contains(@id,'RenameProfileName')]";
        private const string _profileRenameCancelButtonXPath = "//button[contains(@id,'profileRenameCancel')]";
        private const string _profileRenameSaveButtonXPath = "//button[contains(@id,'profileRenameSave')]";
        private const string _mlogUpateModalSaveButtonNewXPath = "//div[@id='updateConfirmModalFooter_New']/button[contains(@id, 'Save')]";
        #endregion

        #region IwebElements Props

        public IWebElement _searchCategory
         {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_searchCategoryXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_searchCategory element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
         }
        public IWebElement _modalBaseStatusMerchant
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_modalBaseStatusMerchantXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_modalBaseStatusMerchant element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        public IWebElement _modalButtonStatusMerchantSave
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_modalButtonStatusMerchantSaveXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_modalButtonStatusMerchantSave element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _mlogUpateModlSaveButton
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_mlogUpateModlSaveButtonXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_mlogUpateModlSaveButton element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _noMLogFoundTextX
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_noMLogFoundTextXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_noMLogFoundTextX element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _noteInputModal
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_noteInputModalXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_noteInputModal element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _mlogUpateModal
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_mlogUpateModalXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_mlogUpateModal element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }


        public IWebElement _searchConstraint
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_searchConstraintXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_searchConstraint element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _searchCriteriaTextSearchValue
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_searchCriteriaTextSearchValueXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_searchCriteriaTextSearchValue element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _searchCriteriaListboxSearchValue
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_searchCriteriaListboxSearchValueXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_searchCriteriaListboxSearchValue element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _searchCriteriaAddBtn
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_searchCriteriaAddBtnXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_searchCriteriaAddBtn element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _search
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_searchXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_search element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _clear
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_clearXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_clear element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _update
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_updateXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_update element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _noMlogsFoundText
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_noMlogsFoundTextXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_noMlogsFoundText element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _paging
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_pagingXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_paging element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _showSummary
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_showSummaryXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_showSummary element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _mlogCount
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_mlogCountXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_mlogCount element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _summaryClose
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_summaryCloseXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_summaryClose element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _saveUpdate
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_saveUpdateXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_saveUpdate element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _closeUpdate
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_closeUpdateXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_closeUpdate element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _selectStatus
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_selectStatusXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_selectStatus element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _noMLogsFound
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_noMLogsFoundXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_noMLogsFound element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _stopPaymentPopUp
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_stopPaymentPopUpXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_stopPaymentPopUp element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        
        public IWebElement _reissueCheckCancel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_reissueCheckCancelXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_reissueCheckCancel element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _reissueCheckYes
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_reissueCheckYesXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_reissueCheckYes element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _selectMLogFormatValue
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_selectMLogFormatValueXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_selectMLogFormatValue element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _noteSpan
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_noteSpanXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_noteSpan element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _btnExportGridText
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_btnExportGridTextXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_btnExportGridText element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _fullscreenBtn
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_fullscreenBtnXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_fullscreenBtn element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _columnsBtn
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_columnsBtnXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_columnsBtn element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _exportBtn
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_exportBtnXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_exportBtn element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _summaryBtn
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_summaryBtnXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_summaryBtn element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _linkCompareWithPreviousGrid
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_linkCompareWithPreviousGridXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_linkCompareWithPreviousGrid element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _saveBtn
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_saveBtnXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_saveBtn element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _gridToolbarProfilesButton
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_gridToolbarProfilesButtonXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_gridToolbarProfilesButton element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IList<IWebElement> _gridToolbarProfilesNames
        {
            get
            {
                bool found = Driver.TryWaitForElementsToBeVisible(By.XPath(_gridToolbarProfilesNamesXpath), out IList<IWebElement> element);
                Settings.EnCompassExtentTest.Info("_gridToolbarProfilesNames list exist is" + found);
                return element;
            }
        }

        private IWebElement _deleteProfileName
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_deleteProfileNameXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_deleteProfileName element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IList<IWebElement> _gridToolbarProfilesOption
        {
            get
            {
                bool found = Driver.TryWaitForElementsToBeVisible(By.XPath(_gridToolbarProfilesOptionXpath), out IList<IWebElement> element);
                Settings.EnCompassExtentTest.Info("_gridToolbarProfilesOption list exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _newProfileName
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_newProfileNameXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_newProfileName element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _modalSaveAsHeader
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_modalSaveAsHeaderXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_modalSaveAsHeader element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _errorRequiredNameMessage
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_errorRequiredNameMessageXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_errorRequiredNameMessage element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _saveAsCancelButton
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_saveAsCancelButtonXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_saveAsCancelButton element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _saveAsSaveButton
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_saveAsSaveButtonXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_saveAsSaveButton element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _setOverwriteExistingProfileCheckbox
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_setOverwriteExistingProfileCheckboxXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_setOverwriteExistingProfileCheckbox element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _setOverwriteExistingProfileCheckboxLabel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_setOverwriteExistingProfileCheckboxLabelXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_setOverwriteExistingProfileCheckboxLabel element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _setAsDefaultProfileCheckboxLabel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_setAsDefaultProfileCheckboxLabelXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_setAsDefaultProfileCheckboxLabel element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _setAsDefaultProfileCheckbox
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_setAsDefaultProfileCheckboxXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_setAsDefaultProfileCheckbox element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _profileSetDefaultCancelButton
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_profileSetDefaultCancelButtonXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_profileSetDefaultCancelButton element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _profileSetDefaultSaveButton
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_profileSetDefaultSaveButtonXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_profileSetDefaultSaveButton element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _profileResetCancel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_profileResetCancelXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_profileResetCancel element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _profileReset
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_profileResetXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_profileReset element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _profileRenameCancelButton
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_profileRenameCancelButtonXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_profileRenameCancelButton element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _renameProfileName
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_renameProfileNameXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_renameProfileName element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _modalRenameHeader
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_modalRenameHeaderXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_modalRenameHeader element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _errorRequiredRenameMessage
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_errorRequiredRenameMessageXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_errorRequiredrenameMessage element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _profileRenameSaveButton
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_profileRenameSaveButtonXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_profileRenameSaveButton element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _profileDeleteCancelButton
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_profileDeleteCancelButtonXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_renameProfileName element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        #endregion

        #region Expand Elements
        private const string AC_STEP1 = "content_contents_acStep1";
        private const string AP_LIMITS = "_apLimits";
        #endregion

        #region IFrameRelated
        public const string _stopPaymentIFrameXPath = @"//iframe[contains(@id, 'btnStopCheckPayment')]";
        public const string _stopPaymentReasonInIFrameXPath = @"//textarea[contains(@id, 'txtNote')]";
        public const string _stopPaymentSendNewCheckLabelXPath = @"//label[contains(@for, 'cbReissue')]";
        public const string _stopPaymentSendNewCheckCBXPath = @"//input[contains(@id, 'cbReissue')]";
        public const string _stopPaymentCancelBtnXPath = @"//input[contains(@id, 'btnCancel')]";
        public const string _stopPaymentSubmitBtnXPath = @"//input[contains(@id, 'btnSave')]";
        public const string _stopPaymentErrorMessageXPath = @"//span[contains(@id,'rfvNote')]";
        public const string _reissueMessageXPath = @"//div[contains(@id,'ModalContent_Modal')]//p";
        public const string _reissueModalXPath = @"//div[contains(@id,'ModalContent_Modal')]";
        public const string _reissueCheckYesButtonXPath = @"//button[@type='button' and text()='Yes']";
        #endregion

        public string IsStopPaymentErrorMessage
        {
            get
            {
                WaitForStopPaymentIFrame();

                using (var ifhelper = new FrameHelper(Driver, By.XPath(_stopPaymentIFrameXPath)))
                {
                    var element = ifhelper.FindElement(By.XPath(_stopPaymentErrorMessageXPath));
                    if (element != null)
                    {
                        return element.Text;
                    }
                    else
                    {
                        throw new Exception($"Could not locate the element.");
                    }
                }
            }
        }

		public void GridEditButton()
		{
			Settings.EnCompassWebDriver.WaitForVisible(By.XPath("//a[contains(@id,'MLogNewGrid')][@role='menuitem' and text()='Edit']")).SendKeys(Keys.Enter);
		}

		public bool IsStopPaymentPopUpDisplayed()
		{
			if (Driver.TryFindElement(By.XPath("//div[contains(@id, 'ModalContent_Modal')]"), out IWebElement element))
			{
				return element.Displayed;
			}
			else
			{
				return false;
			}
		}

        /// <summary>
        /// This method waits until the Stop Payment Popup is displayed.
        /// </summary>
        private void WaitForStopPaymentIFrame()
        {
            Driver.WaitForVisible(By.XPath(_stopPaymentIFrameXPath));
        }

        public string IsReissueMessage
        {
            get
            {
                WaitForReissueCheckModal();
                using (var ifhelper = new FrameHelper(Driver, By.XPath(_reissueModalXPath)))
                {
                    var element = ifhelper.FindElement(By.XPath(_reissueMessageXPath));
                    if (element != null)
                    {
                        return element.Text;
                    }
                    else
                    {
                        throw new Exception($"Could not locate the element.");
                    }
                }
            }
        }

        /// <summary>
        /// This method waits until the Reissue Check Popup is displayed.
        /// </summary>
        private void WaitForReissueCheckModal()
        {
            Driver.WaitForVisible(By.XPath(_reissueModalXPath));
        }

        public void IsReissueCheckYes()
        {
            WaitForReissueCheckModal();
            using (var ifhelper = new FrameHelper(Driver, By.XPath(_reissueModalXPath)))
            {
                var element = ifhelper.FindElement(By.XPath(_reissueCheckYesButtonXPath));
                if (element != null)
                {
                    element.Click();
                    AttachOnDemandScreenShot();
                    Settings.EnCompassExtentTest.Info("Reissue Check Yes button clicked");
                }
                else
                {
                    throw new Exception($"Could not locate the element.");
                }
            }
        }

        /// <summary>
        /// This method GETS/SETS 'Reason' field in Stop Payment popup.
        /// </summary>
        public string StopPaymentReason
        {
            get
            {
                WaitForStopPaymentIFrame();

				using (var ifhelper = new FrameHelper(Driver, By.XPath(_stopPaymentIFrameXPath)))
				{
					var element = ifhelper.FindElement(By.XPath(_stopPaymentReasonInIFrameXPath));
					if (element != null)
					{
						return element.Text;
					}
					else
					{
						throw new Exception($"Could not locate the element.");
					}
				}
			}

			set
			{
				WaitForStopPaymentIFrame();
				using (var ifhelper = new FrameHelper(Driver, By.XPath(_stopPaymentIFrameXPath)))
				{
					var element = ifhelper.FindElement(By.XPath(_stopPaymentReasonInIFrameXPath));
					if (element != null)
					{
						element.SendKeys(value);
					}
					else
					{
						throw new Exception($"Could not locate the element.");
					}
				}
			}
		}

		/// <summary>
		/// This method GETS/SETS the Checkbhox in Stop Payment popup.
		/// </summary>
		public bool StopPaymentSendNewCheck
		{
			get
			{
				WaitForStopPaymentIFrame();

				using (var ifhelper = new FrameHelper(Driver, By.XPath(_stopPaymentIFrameXPath)))
				{
					var element = ifhelper.FindElement(By.XPath(_stopPaymentSendNewCheckCBXPath));
					if (element != null)
					{
						return element.Displayed;
					}
					else
					{
						return false;
					}
				}
			}

			set
			{
				WaitForStopPaymentIFrame();
				using (var ifhelper = new FrameHelper(Driver, By.XPath(_stopPaymentIFrameXPath)))
				{
					var element = ifhelper.FindElement(By.XPath(_stopPaymentSendNewCheckCBXPath));
					if (element != null)
					{
						element.SetCheckboxStateWithLabel(ifhelper.FindElement(By.XPath(_stopPaymentSendNewCheckLabelXPath)), value);
					}
					else
					{
						throw new Exception($"Could not locate the element.");
					}
				}
			}
		}

		/// <summary>
		/// This method clicks on the CANCEL button in the Stop Payment pop up.
		/// </summary>
		public void StopPaymentCancel()
		{
			WaitForStopPaymentIFrame();
			using (var ifhelper = new FrameHelper(Driver, By.XPath(_stopPaymentIFrameXPath)))
			{
				var element = ifhelper.FindElement(By.XPath(_stopPaymentCancelBtnXPath));
				if (element != null)
				{
					element.Click();
				}
				else
				{
					throw new Exception($"Could not locate the element.");
				}
			}
		}

		/// <summary>
		/// This method clicks on the SUBMIT button in the Stop Payment pop up.
		/// </summary>
		public void StopPaymentSubmit()
		{
			WaitForStopPaymentIFrame();
			using (var ifhelper = new FrameHelper(Driver, By.XPath(_stopPaymentIFrameXPath)))
			{
				var element = ifhelper.FindElement(By.XPath(_stopPaymentSubmitBtnXPath));
				if (element != null)
				{
					element.Click();
				}
				else
				{
					throw new Exception($"Could not locate the element.");
				}
			}
		}

        /// <summary>
        /// Confirm Reissue Check
        /// </summary>
		public void ReissueCheckYes()
		{
			_reissueCheckYes.JSClickWithFocus(Driver);
		}

        /// <summary>
        /// Cancel Reissue Check
        /// </summary>
        public void ReissueCheckCancel()
		{
			_reissueCheckCancel.JSClickWithFocus(Driver);
		}

        /// <summary>
        /// Set the Status by text
        /// </summary>
        /// <param name="whichText"></param>
		public void SetStatus(string whichText)
		{
			var selectElement = new SelectElement(_selectStatus);
			selectElement.SelectByText(whichText);
            Settings.EnCompassExtentTest.Info($"Set status to merchant log to {whichText}.");

        }

        /// <summary>
        /// Set the search term text
        /// </summary>
        /// <param name="whichText"></param>
        public void SetSearchCriteriaSearchTerm(string whichText)
		{
            // first clear the existing search
            Clear();
            var selectElement = new SelectElement(_searchCategory);
            selectElement.SelectByText(whichText);
		}

        /// <summary>
        /// Check is the fullscreen button is visible
        /// </summary>
        /// <returns></returns>
		public bool IsFullscreenVisible()
		{
            // If element is not null, it means it's visible.
            bool visible = _fullscreenBtn != null;
            Settings.EnCompassExtentTest.Info($"Is Fullscreen button visible: {visible}.");
            return visible;
		}

        /// <summary>
        /// Perform the click for Full screnn button
        /// </summary>
        public void FullscreenBtn()
        {
            _fullscreenBtn.JSClickWithFocus(Driver);
            Settings.EnCompassExtentTest.Info("Clicked on Fullscreen button.");
        }

        /// <summary>
        /// Verify if the columns are visible
        /// </summary>
        /// <returns></returns>
        public bool IsColumnsVisible()
        {
            // If element is not null, it means it's visible.
            bool visible = _columnsBtn != null;
            Settings.EnCompassExtentTest.Info($"Is Columns button visible: {visible}.");
            return visible;
        }

        /// <summary>
        /// Peform the click in the column button
        /// </summary>
        public void ClickColumnsBtn()
        {
            _columnsBtn.JSClickWithFocus(Driver);
            Settings.EnCompassExtentTest.Info("Clicked on Columns button.");
        }

        /// <summary>
        /// Select the column by text
        /// </summary>
        /// <param name="text"></param>
        public void SelectColumnByText(string text)
        {
            var element = Driver.FindElement(By.XPath($@"(//div[contains(@class, 'dropdown-menu dropdown-menu')])[3]//div//input[contains(@data-field, '{text}')]"));
            element.ClickCheckBox();
        }

        /// <summary>
        /// Check if the Export button is visible
        /// </summary>
        /// <returns></returns>
        public bool IsExportVisible()
        {
            // If element is not null, it means it's visible.
            bool visible = _exportBtn != null;
            Settings.EnCompassExtentTest.Info($"Is Export button visible: {visible}.");
            return visible;
        }

        /// <summary>
        /// Check if the Summary button is visible
        /// </summary>
        public bool IsSummaryVisible()
        {
            var visible = _summaryBtn != null;
            Settings.EnCompassExtentTest.Info($"Is Summary button visible: {visible}.");
            return visible;
        }

        /// <summary>
        /// Used to validade the summay with the expected Summary items
        /// </summary>
        /// <param name="expectedSummaryItems"></param>
        public void ValidateSummary(List<string> expectedSummaryItems)
        {
            Thread.Sleep(500); //Trying to figure out why this is causing an exception in EnCompass. This is for debuging, it will be removed.
            _summaryBtn.JSClickWithFocus(Driver);
            Driver.SwitchTo();
            Driver.TryWaitForElementToBeVisible(By.XPath("//h1[contains(@id, 'mpMlogSummary')]"), out IWebElement mlogSummaryHeader);
            var listOfSummaryItems = Driver.FindElements(By.XPath("//div[contains(@id, 'mpMlogSummary_Body')]//li"));

            for (int i = 0; i < expectedSummaryItems.Count; i++)
            {
                var text = listOfSummaryItems[i].Text;
                if (text.Contains("\r\n"))
                {
                    text = text.Replace("\r\n", "");

                }

                text = text.Replace(".", "");
                var output = Regex.Replace(text, @"[\d-]", string.Empty).TrimEnd();
                Settings.EnCompassExtentTest.Info($"The summary displayed in EnCompass is {output}");

                Check.That(output.Equals(expectedSummaryItems[i])).IsTrue();
            }

            _summaryClose.JSClickWithFocus(Driver);

        }


        public string SetSearchTermFilterConstraint
        {
            get
            {
                return new SelectElement(_searchConstraint).SelectedOption.Text.Trim();
            }

            set
            {
                new SelectElement(_searchConstraint).SelectByText(value);
            }
        }

        public string SearchCategory
        {
            get => new SelectElement(_searchCategory).SelectedOption.Text;
            set => new SelectElement(_searchCategory).SelectByValue(value);
        }

        // This method below does basically the same thing that the get method above, but is 
        // kept here fore code compability.
        public void SetSearchCriteriaSearchTermByValue(string whichText)
        {
            var selectElement = new SelectElement(_searchCategory);
            selectElement.SelectByValue(whichText);
            Settings.EnCompassExtentTest.Info($"Set search criterion: {whichText}.");
        }

        public void SetConstraint(string whichText)
        {
            string category = SearchCategory.ToLower().Trim();
            var editableCategoriesConstraints = new string[] { "amount", "created date", "expiring days", "merchant Code", "merchant name" };

            // if the category selected on Category Drop Down is on the array above, assing the constraint send to this method
            // Otherwise, do nothing (many categories don't allow editing a constraint)
            for (int i = 0; i < editableCategoriesConstraints.Length; i++)
                if (editableCategoriesConstraints[i] == category)
                    new SelectElement(_searchConstraint).SelectByText(whichText);
        }

        public string NoMLogsFoundMessage
        {
            get
            {
                if (Driver.TryFindElement(By.XPath(@"//td[contains(@class, 'gridNoRecordsMessage')]"), out IWebElement element))
                {
                    return element.Text;
                }
                else
                    return null;
            }
        }

        public bool NoMLogsFoundMessagePresent
        {
            get
            {
                if (Driver.TryFindElement(By.XPath(@"//td[contains(@class, 'gridNoRecordsMessage')]"), out IWebElement element))
                {
                    return true;
                }
                else
                    return false;
            }
        }

        public string SearchCriteriaTextSearchValue
        {
            set
            {
                _searchCriteriaTextSearchValue.SendKeys(value);
            }
        }

        public void SetSearchCriteriaListboxSearchValue(string whichText)
        {
            var selectElement = new SelectElement(_searchCriteriaListboxSearchValue);
            selectElement.SelectByText(whichText);
            Settings.EnCompassExtentTest.Info($"Set search Value: {whichText}.");
        }

        public void Add()
        {
            _searchCriteriaAddBtn.JSClickWithFocus(Driver);
            Settings.EnCompassExtentTest.Info($"Clicked on Add Button.");
        }

        public void SelectMLogFormatValue(string whichText)
        {
            var selectElement = new SelectElement(_selectMLogFormatValue);
            selectElement.SelectByText(whichText);
        }

        public void ExportGridText()
        {
            _btnExportGridText.JSClickWithFocus(Driver);
            Settings.EnCompassExtentTest.Info("Clicked on Export button for Mlog");
        }

        public void Search()
        {
            _search.JSClickWithFocus(Driver);
            WaitForLoad();
        }

        public void Clear()
        {
            _clear.JSClickWithFocus(Driver);
            Settings.EnCompassExtentTest.Info("Clicked on Clear Button.");
        }

        public void UpdateClick()
        {
            _update.JSClickWithFocus(Driver);
            // WaitForLoad();
        }

        public void SaveUpdate()
        {
            _saveUpdate.JSClickWithFocus(Driver);
            // WaitForLoad();
            this.AttachOnDemandScreenShot();
        }

        public void SaveBtn()
        {
            _saveBtn.JSClickWithFocus(Driver);
        }

        public void UpdateMLogStatus()
        {
            _update.JSClickWithFocus(Driver);
            Settings.EnCompassExtentTest.Info("Clicked on Update button for Mlog");
            SaveMerchantLogUpdateModal();
        }

        public void UpdateMLogStatusWithNote(string note)
        {
            _saveBtn.JSClickWithFocus(Driver);
            Settings.EnCompassExtentTest.Info("Clicked on Update button for Mlog");
            SaveMerchantLogUpdateModalWithNote(note);
            Settings.EnCompassExtentTest.Info("Updated merchant log status.");

        }

        public bool NoMLogsFoundText()
        {
            return Driver.TryWaitForElementToBeVisible(By.XPath(_noMLogFoundTextXPath), out IWebElement noMLogFound);
        }

        //private GridControl _mLogGrid;
        //public GridControl MLogGrid
        //{
        //    get
        //    {
        //        CompareWithPrevious();
        //        GridControl grid = _mLogGrid ?? (_mLogGrid = new GridControl("Mlog", Driver));
        //        grid.WaitForGrid();
        //        return grid;
        //    }
        //}

        private NewGridControl _mLogNewGrid;
        public NewGridControl MLogNewGrid
        {
            get
            {
                NewGridControl grid = _mLogNewGrid ?? (_mLogNewGrid = new NewGridControl("etMLogs", Driver, Settings));
                grid.WaitForGrid();
                return grid;
            }
        }

        public void SetPaging(string size)
        {
            MLogNewGrid.SetPageSize(200);
        }

        /// <summary>
        /// This method clicks the respective button, and WAITS for the ASYNC REFRESH to show up a specific element.
        /// </summary>
        public void ShowSummaryClick()
        {
            _showSummary.JSClickWithFocus(Driver); // Click the Show Summary link
            Driver.WaitFor(GetBy(() => this._mlogCount)); // Wait for the MLog Count Text to show up.
            RefreshModel(); // Now that all the elements are there, Refresh the Model.
        }

        public void CloseSummaryModal()
        {
            _summaryClose.JSClickWithFocus(Driver);
        }

        public string ShowSummaryText => _showSummary.Text;
        public string MLogCountText => _mlogCount.Text;

        public void SetMLogStatus(MerchantLogStatuses status)
        {
            var rows = MLogNewGrid.GetRows();
            var statusElements = rows.Select(r => r.FindElement(By.XPath(".//select[contains(@id, 'Status')]")));
            foreach (var statusElement in statusElements)
            {
                var selectElement = new SelectElement(statusElement);
                selectElement.SelectByValue(((int)status).ToString());
                Settings.EnCompassExtentTest.Info("Mlog Status is set to :" + ((int)status).ToString());
            }
        }

        /// <summary>
        /// Method that handles Merchant Log Update Modal, saving operation.
        /// </summary>
        public bool SaveMerchantLogUpdateModal(int timeInSec = 30)
        {
            bool val = WaitForModalToAppear(_mlogUpateModlSaveButtonXPath, timeInSec);
            if (val)
            {
                Settings.EnCompassExtentTest.Info("Waiting for Save/Confirm button on Modal to be Clickable");
                Driver.WaitElementBeClickable(_mlogUpateModalSaveButtonNewXPath);
                Settings.EnCompassExtentTest.Info("Confirm button is clickable");
                AttachOnDemandScreenShot();
                Driver.TryWaitForElementToBeVisible(By.XPath(_mlogUpateModalSaveButtonNewXPath), out IWebElement _mlogUpateModalSaveButtonNew);
                _mlogUpateModalSaveButtonNew.JSClickWithFocus(Driver);
                Settings.EnCompassExtentTest.Info("Accepted Modal with default primary button click");
                // Verify if the modal is gone before proceeding
                WaitForModalToDisappear(_mlogUpateModalXPath, timeInSec);
            }
            else
                Settings.EnCompassExtentTest.Info("Could not confirm/accept the modal as modal did not appear.");

            return val;
        }

        /// <summary>
        /// Method that handles Merchant Log Update Modal, saving operation with Close Note.
        /// </summary>
        public bool SaveMerchantLogUpdateModalWithNote(string note, int timeInSec = 30)
        {
            bool val = WaitForModalToAppear(_mlogUpateModalSaveButtonNewXPath, timeInSec);
            if (val)
            {
                Settings.EnCompassExtentTest.Info("Waiting for alert message.");
                _noteSpan.WaitUntilElementIsInteractable();

                Check.That(_noteSpan.Text).Contains("Close note is a required value.");
                Settings.EnCompassExtentTest.Info("Typing note information on modal");

                _noteInputModal.SendKeys(note);
                AttachOnDemandScreenShot();

                Driver.TryWaitForElementToBeVisible(By.XPath(_mlogUpateModalSaveButtonNewXPath), out IWebElement _mlogUpateModalSaveButtonNew);
                _mlogUpateModalSaveButtonNew.JSClickWithFocus(Driver);
                Settings.EnCompassExtentTest.Info("Accepted Modal with default primary button click");
                // Verify if the modal is gone before proceeding
                WaitForModalToDisappear(_mlogUpateModalXPath, timeInSec);
            }
            else
                Settings.EnCompassExtentTest.Info("Could not confirm/accept the modal as modal did not appear.");

            return val;
        }

        /// <summary>
        /// Search a specific MLog
        /// </summary>
        public void SearchMLog(string searchTerm, string searchVal)
        {
            SetSearchCriteriaSearchTerm(searchTerm);
            RefreshModel();
            SetSearchTermFilterConstraint = "Equal To";
            SearchCriteriaTextSearchValue = searchVal;
            Add();
            Search();
            RefreshModel();
            Settings.EnCompassExtentTest.Info("Successfully searched Mlog with " + searchTerm + " = " + searchVal);
            MLogNewGrid.AddOrRemoveColumnsToGrid("Toggle all", Settings.EnCompassExtentTest);
        }

        /// <summary>
        /// Search a specific MLog
        /// </summary>
        public void SearchMLogWithFilter(string searchTerm, string constraint, string searchVal)
        {
            Clear();
            SetSearchCriteriaSearchTerm(searchTerm);
            RefreshModel();
            SetSearchTermFilterConstraint = constraint;
            SetSearchCriteriaListboxSearchValue(searchVal);
            Add();
            Search();
            Settings.EnCompassExtentTest.Info("Successfully searched Mlog with " + searchTerm + "  " + constraint + "  " + searchVal);
            MLogNewGrid.AddOrRemoveColumnsToGrid("Toggle all", Settings.EnCompassExtentTest);
        }

        /// <summary>
        /// Search a specific MLog which matches with merchant name and mlogid then returns that mlogid
        /// </summary>
        public string SearchMLogByMerchantNameAndID(NewGridControl mLogsGrid, string merchantName)
        {
            List<string> actMerchantNames = mLogsGrid.GetColumnText("Merchant").ToList();
            List<string> mLogIds = mLogsGrid.GetColumnText("Unique ID").ToList();
            string mLogId = "";
            for (int m = 0; m < actMerchantNames.Count(); m++)
            {
                if (actMerchantNames[m].Equals(merchantName))
                {
                    mLogId = mLogIds[m];
                    Settings.EnCompassExtentTest.Info($"Found the Merchant Name: {merchantName} in the MLog Grid.");
                    break;
                }
            }

            return mLogId;
        }

        public void RefreshMLogCreditLimit()
        {
            MLogNewGrid.PerformActionByText(null, "Refresh Credit Limit");
            ConfirmOnModal();
            MLogNewGrid.WaitForGrid();
            AttachOnDemandScreenShot();
        }

        /// <summary>
        /// Verify the success message after click on Refresh Credit Limit button
        /// </summary>
        public bool VerifyRefreshCreditLimitSuccessMessage(string msg)
        {
            // Check for the Success Message.
            if (HasSuccessMessage)
            {
                //string accountNumber = Regex.Match(SuccessMessage, @"\*(\d+)").Value;
                string accountNumber = Settings.Scenario["ACNUMLAST4DIGITS"].ToString();
                string mlogID = Settings.Scenario["MLogId"].ToString();
                msg = String.Format(msg, accountNumber, mlogID);

                // return the transaction ID
                Check.That(this.SuccessMessage.Equals(msg)).IsTrue();
                return true;
            }
            else
            {
                return false;
            }
        }

        public string GetStatus()
        {
            IWebElement statusElement = Driver.FindElement(By.XPath("//*[contains(@id,'ddlStatus') or contains(@id,'_StatusLabel')]"));

            if (statusElement.TagName.Equals("select"))
                return new SelectElement(statusElement).SelectedOption.Text;
            else
                return statusElement.Text;
        }

        public void ExpandLimits()
        {
            //Changed to the generic method
            ExpandCardHeader(AC_STEP1, AP_LIMITS);
            Settings.EnCompassExtentTest.Info("Expanded Limits Section");
        }

        // This clicks on the Confirm button on the modal for change status on Merchant
        public bool ConfirmOnModalStatusMerchant()
        {
            bool val = WaitForModalToAppear();
            if (val)
            {
               IWebElement _element=Driver.WaitForVisible(By.XPath(_modalBaseStatusMerchantXPath + _modalButtonStatusMerchantSaveXPath));
               _element.JSClickWithFocus(Driver);
                Settings.EnCompassExtentTest.Info("Accepted Modal with default primary button click");
                // Verify if the modal is gone before proceeding
                WaitForModalToDisappear();
            }
            else
                Settings.EnCompassExtentTest.Info("Could not confirm/accept the modal");

            return val;
        }

        private bool WaitForModalToAppear(double timeInSec = 30)
        {
            try
            {
                 Driver.WaitFor(By.XPath(_modalBaseStatusMerchantXPath), TimeSpan.FromSeconds(timeInSec));
                Settings.EnCompassExtentTest.Info("Modal appeared.");
                return true;
            }
            catch (WebDriverTimeoutException)
            {
                Settings.EnCompassExtentTest.Warning($"Modal did not appear within {timeInSec.ToString()} secs");
                return false;
            }
        }

        private void WaitForModalToDisappear(double timeInSec = 30)
        {
            try
            {
                Driver.WaitForAbsence(By.XPath(_modalBaseStatusMerchantXPath), TimeSpan.FromSeconds(timeInSec));
                Settings.EnCompassExtentTest.Info("Modal disappeared.");
            }
            catch (WebDriverTimeoutException ex)
            {
                Settings.EnCompassExtentTest.Warning($"Modal did not disappear within {timeInSec.ToString()} secs");
                throw ex;
            }
        }

        public void UpdateMerchantNote(string note)
        {
            Driver.SwitchTo();
            _noteInputModal.WaitUntilElementIsInteractable();
            _noteInputModal.Clear();
            _noteInputModal.SendKeys(note);
        }

        #region Profile

        /// <summary>
        /// This method is used to perform Click on Profiles dropdown
        /// </summary>
        public void clickGridToolbarProfilesButton()
        {
            _gridToolbarProfilesButton.JSClickWithFocus(Driver);
            Settings.EnCompassExtentTest.Info("Clicked on Profiles button.");
        }

        private List<string> GetAllProfileNames()
        {
            clickGridToolbarProfilesButton();
            IList<IWebElement> profileNames = _gridToolbarProfilesNames;
            if (profileNames == null)
                return null;

            List<string> names = new List<string>();
            foreach (var p in profileNames)
            {
                names.Add(p.Text.Replace(" (Default)", ""));
            }

            clickGridToolbarProfilesButton();
            return names;
        }

        /// <summary>
        /// This method is used to Delete all existing profiles 
        /// </summary>
        public void DeleteAllExistingProfiles(ExtentTest test)
        {
            List<string> profileNames = GetAllProfileNames();
            if (profileNames != null)
            {
                foreach (string p in profileNames)
                {
                    ClickAndHoldOption(p, "Delete", test);
                    WaitForModalToAppear(_profileDeleteModalXPath);
                    ProfileDelete();
                    WaitForModalToDisappear(_profileDeleteModalXPath);
                    WaitForFormLoadingOverlay(new TimeSpan(5));
                }
            }
        }

        /// <summary>
        /// This method is used to perform the hover action (click and hold) 
        /// </summary>
        public bool ClickAndHoldOption(string name, string option, ExtentTest test)
        {
            clickGridToolbarProfilesButton();

            string profileXPath = String.Format(_profilesNameXPath, name);
            ClickAndHold(profileXPath);

            profileXPath = profileXPath + _profileControlsXPath;
            Driver.TryWaitForElementsToBeVisible(By.XPath(profileXPath), out IList<IWebElement> profileControls);

            foreach (IWebElement c in profileControls)
            {
                if (c.Text.ToLowerInvariant().Equals(option.ToLowerInvariant()))
                {
                    c.JSClickWithFocus(Driver);
                    test.Info($"Clicked in {option} for {name} profile");
                    return true;
                }
            }

            test.Info($"{option} did not find for {name} profile");
            return false;
        }

        /// <summary>
        /// This method is used to perform Delete at the delete confirm modal for a existing profile
        /// </summary>
        public void ProfileDelete()
        {
            WaitForModalToAppear(_profileDeleteModalXPath);
            _deleteProfileName.JSClickWithFocus(Driver);
            WaitForModalToDisappear(_profileDeleteModalXPath);
            WaitForFormLoadingOverlay(new TimeSpan(5));
            Settings.EnCompassExtentTest.Info("Delete button clicked on modal");
        }

        /// <summary>
        /// This method is used to verify Profiles dropdown options
        /// </summary>
        public bool VerifyProfilesGridOptions(ExtentTest test)
        {
            clickGridToolbarProfilesButton();

            List<string> options = StringKeys.ProfilesOptions;
            for (int p = 0; p < options.Count(); p++)
            {
                if (!_gridToolbarProfilesOption[p].Text.Contains(options[p]))
                {
                    test.Info($"{options[p]} didn't matched with the Profile options.");
                    return false;
                }
            }
            test.Info("All of Profiles options verified.");

            return true;
        }

        /// <summary>
        /// This method is used to click on the profiles dropdown options
        /// </summary>
        public void ProfilesGrid(string option, ExtentTest test)
        {
            clickGridToolbarProfilesButton();

            Driver.TryWaitForElement(By.XPath(_gridToolbarProfilesOptionXpath + "[contains(text(), '" + option + "')]"), out IWebElement profileOption);

            string xpathModal = string.Empty;
            switch (option)
            {
                case "Save As":
                    xpathModal = _profileSaveAsModalXPath;
                    break;
                case "Set Default":
                    xpathModal = _profileSetDefaultModalXPath;
                    break;
                case "Reset":
                    xpathModal = _profileResetModalXPath;
                    break;
            }
            profileOption.JSClickWithFocus(Driver);
            test.Info("Clicked on Profile Option " + option);
            WaitForModalToAppear(xpathModal);
        }

        /// <summary>
        /// This method is used to set/get Profile Name
        /// </summary>
        public string NewProfileName
        {
            get { return _newProfileName.GetAttribute("value"); }
            set
            {
                _newProfileName.Clear();
                _newProfileName.SendKeys(value);
                Settings.EnCompassExtentTest.Info("Set New profile name with value: " + value);
            }
        }

        /// <summary>
        /// Method to unfocus textbox
        /// </summary>
        public void ModalHeaderClick()
        {
            _modalSaveAsHeader.BootstrapClick();//Cliked on header modal to take off focus from textbox
            Settings.EnCompassExtentTest.Info("Cliked on header modal.");
        }

        /// <summary>
        /// This method is used to error for Required name message
        /// </summary>
        public string GetErrorRequiredNameMessage
        {
            get
            {
                return _errorRequiredNameMessage.Text;
            }
        }

        /// <summary>
        /// This method is used to perform Cancel inside the profiles dropdown option SaveAs
        /// </summary>
        public void SaveAsCancel()
        {
            WaitForModalToAppear(_profileSaveAsModalXPath);
            _saveAsCancelButton.JSClickWithFocus(Driver);
            WaitForModalToDisappear(_profileSaveAsModalXPath);
            Settings.EnCompassExtentTest.Info("Cancel button clicked on modal");
            WaitForFormLoadingOverlay(new TimeSpan(5));
        }

        /// <summary>
        /// This method is used to set Overwrite Existing Profile checkbox inside the profiles dropdown option SaveAs
        /// </summary>
        public bool SetOverwriteExistingProfile
        {
            get { return _setOverwriteExistingProfileCheckbox.Selected; }
            set
            {
                _setOverwriteExistingProfileCheckbox.SetCheckboxStateWithLabel(_setOverwriteExistingProfileCheckboxLabel, value);
                Settings.EnCompassExtentTest.Info("Enable Overwrite existing profile: " + value);
            }
        }

        /// <summary>
        /// This method is used to select a existing profile radio option at Save As modal
        /// </summary>
        public void ChooseDefaultProfileOptionSaveAs(string name, ExtentTest test)
        {
            string xpath = String.Format(_rbSelectProfileXPath, name);
            Driver.TryWaitForElement(By.XPath(xpath), out IWebElement rbOption);
            xpath = String.Format(_rbSelectProfileLabelXPath, name);
            Driver.TryWaitForElement(By.XPath(xpath), out IWebElement label);

            rbOption.SetRadioButtonStateWithLabel(label, true);
            this.RefreshModel();
            test.Info($"The profile {name} selected.");
        }

        /// <summary>
        /// This method is used to check if Profile name field is Enabled
        /// </summary>
        public bool NewProfileNameIsEnabled()
        {
            bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_newProfileNameXPath), out IWebElement element);
            Settings.EnCompassExtentTest.Info("_newProfileName enable is" + found);
            return element.Enabled;
        }

        /// <summary>
        /// This method is used to set default checkbox inside the profiles dropdown option SaveAs
        /// </summary>
        public bool AsDefaultProfileCheckbox
        {
            get { return _setAsDefaultProfileCheckbox.Selected; }
            set
            {
                _setAsDefaultProfileCheckbox.SetCheckboxStateWithLabel(_setAsDefaultProfileCheckboxLabel, value);
                Settings.EnCompassExtentTest.Info("Set as default profile: " + value);
            }
        }

        /// <summary>
        /// This method is used to perform Save inside the profiles dropdown option SaveAs
        /// </summary>
        public void SaveAsSave()
        {
            WaitForModalToAppear(_profileSaveAsModalXPath);
            _saveAsSaveButton.JSClickWithFocus(Driver);
            WaitForModalToDisappear(_profileSaveAsModalXPath);
            Settings.EnCompassExtentTest.Info("Save as button clicked");
        }

        /// <summary>
        /// This method is used to verify the existing profiles at the Profiles dropdown 
        /// </summary>
        public bool VerifyProfilesGridName(List<string> nameProfile, ExtentTest test)
        {
            clickGridToolbarProfilesButton();

            IList<IWebElement> profileNames = _gridToolbarProfilesNames;
            bool allNamesChecked = false;
            for (int n = 0; n < nameProfile.Count(); n++)
            {
                foreach (IWebElement p in profileNames)
                {
                    if (p.Text.Contains(nameProfile[n]))
                    {
                        allNamesChecked = true;
                        test.Info($"Profile Name {nameProfile[n]} found.");
                        break;
                    }
                }
            }

            clickGridToolbarProfilesButton();

            return allNamesChecked;
        }

        /// <summary>
        /// This method is used to perform Cancel at the Set Default confirm modal for a existing profile
        /// </summary>
        public void CancelSetDefault()
        {
            WaitForModalToAppear(_profileSetDefaultModalXPath);
            _profileSetDefaultCancelButton.JSClickWithFocus(Driver);
            WaitForModalToDisappear(_profileSetDefaultModalXPath);
            Settings.EnCompassExtentTest.Info("Save as button clicked");
            WaitForFormLoadingOverlay(new TimeSpan(5));
        }

        /// <summary>
        /// This method is used to set default at Save As modal
        /// </summary>
        public void SetDefaultProfileOption(string name, ExtentTest test)
        {
            string xpath = String.Format(_rbSelectSetDefaultProfileXPath, name);
            Driver.TryWaitForElement(By.XPath(xpath), out IWebElement rbOption);
            xpath = String.Format(_rbSelectSetDefaultProfileLabelXPath, name);
            Driver.TryWaitForElement(By.XPath(xpath), out IWebElement label);

            rbOption.SetRadioButtonStateWithLabel(label, true);
            this.RefreshModel();
            test.Info($"The profile {name} selected.");
        }

        /// <summary>
        /// This method is used to perform Save at the Set Default confirm modal for a existing profile
        /// </summary>
        public void SaveSetDefault()
        {
            WaitForModalToAppear(_profileSetDefaultModalXPath);
            _profileSetDefaultSaveButton.JSClickWithFocus(Driver);
            WaitForModalToDisappear(_profileSetDefaultModalXPath);
            Settings.EnCompassExtentTest.Info("Cancel button clicked on modal");
            WaitForFormLoadingOverlay(new TimeSpan(5));
        }

        /// <summary>
        /// This method is used to perform Reset inside the profiles dropdown option Reset
        /// </summary>
        public void ProfileReset()
        {
            WaitForModalToAppear(_profileResetModalXPath);
            _profileReset.JSClickWithFocus(Driver);
            WaitForModalToDisappear(_profileResetModalXPath);
            Settings.EnCompassExtentTest.Info("Reset button clicked on modal");
            WaitForFormLoadingOverlay();
        }

        /// <summary>
        /// This method is used to perform Cancel inside the profiles dropdown option Reset
        /// </summary>
        public void ProfileResetCancel()
        {
            WaitForModalToAppear(_profileResetModalXPath);
            _profileResetCancel.JSClickWithFocus(Driver);
            WaitForModalToDisappear(_profileResetModalXPath);
            Settings.EnCompassExtentTest.Info("Cancel Reset button clicked on modal");
            WaitForFormLoadingOverlay(new TimeSpan(5));
        }

        /// <summary>
        /// This method is used to perform Cancel at the Rename confirm modal for a existing profile
        /// </summary>
        public void CancelRenameProfile()
        {
            WaitForModalToAppear(_profileRenameModalXPath);
            _profileRenameCancelButton.JSClickWithFocus(Driver);
            WaitForModalToDisappear(_profileRenameModalXPath);
            Settings.EnCompassExtentTest.Info("Profile Rename Save as button clicked");
            WaitForFormLoadingOverlay(new TimeSpan(5));
        }

        /// <summary>
        /// This method is usederror for Required Rename message
        /// </summary>
        public string RenameProfileName
        {
            get { return _newProfileName.GetAttribute("value"); }
            set
            {
                _renameProfileName.Clear();
                _renameProfileName.SendKeys(value);
                Settings.EnCompassExtentTest.Info("Rename profile name with value: " + value);
            }
        }

        /// <summary>
        /// Method to unfocus textbox
        /// </summary>
        public void ModalRenameHeaderClick()
        {
            _modalRenameHeader.BootstrapClick();//Cliked on header modal to take off focus from textbox
            Settings.EnCompassExtentTest.Info("Cliked on header modal.");
        }

        /// <summary>
        /// This method is used to error for Required Rename message
        /// </summary>
        public string GetErrorRequiredRenameMessage
        {
            get
            {
                return _errorRequiredRenameMessage.Text;
            }
        }

        /// <summary>
        /// This method is used to perform Save at the Rename confirm modal for a existing profile
        /// </summary>
        public void SaveRenameProfile()
        {
            WaitForModalToAppear(_profileRenameModalXPath);
            _profileRenameSaveButton.JSClickWithFocus(Driver);
            WaitForModalToDisappear(_profileRenameModalXPath);
            Settings.EnCompassExtentTest.Info("Profile Rename Cancel button clicked on modal");
            WaitForFormLoadingOverlay();
        }

        /// <summary>
        /// This method is used to check and return if Overwrite Existing Profile checkbox is enabled
        /// </summary>
        public bool SetOverwriteExistingProfileCheckboxEnable()
        {
            bool found = Driver.TryWaitForElement(By.XPath(_setOverwriteExistingProfileCheckboxXPath), out IWebElement element);
            Settings.EnCompassExtentTest.Info("_setOverwriteExistingProfileCheckbox enable is" + found);
            return element.Enabled;
        }

        /// <summary>
        /// This method is used to perform Cancel at the delete confirm modal for a existing profile
        /// </summary>
        public void ProfileDeleteCancel()
        {
            WaitForModalToAppear(_profileDeleteModalXPath);
            _profileDeleteCancelButton.JSClickWithFocus(Driver);
            Settings.EnCompassExtentTest.Info("Cancel Delete button clicked on modal");
            WaitForModalToDisappear(_profileDeleteModalXPath);
            WaitForFormLoadingOverlay(new TimeSpan(5));
        }
        #endregion
    }
}
