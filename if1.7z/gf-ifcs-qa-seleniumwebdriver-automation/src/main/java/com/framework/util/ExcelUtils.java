package com.framework.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;



public class ExcelUtils {

	static HSSFSheet hssfWorkSheet = null;
	static HSSFWorkbook hssfWorkBook = null;
	static HSSFRow row = null;
	static HSSFCell cell = null;

	public static HSSFSheet readExcel(String downloadedFilePath, String sheetName) {
		try {
			FileInputStream inputStream = new FileInputStream(new File(downloadedFilePath));
			hssfWorkBook = new HSSFWorkbook(inputStream);
			hssfWorkSheet = hssfWorkBook.getSheet(sheetName);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return hssfWorkSheet;
	}

	public static void writeExcel(String downloadedFilePath) {
		try {
			FileOutputStream outputStream = new FileOutputStream(downloadedFilePath);
			hssfWorkBook.write(outputStream);
			outputStream.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static ArrayList<String> readHeader(HSSFSheet hssfWorkSheet, int headerRowNum) {
		int noOfColumns = getNumberOfColumns(hssfWorkSheet, headerRowNum);
		ArrayList<String> columnHeaders = new ArrayList<String>();
		System.out.println("Number of columns is  " + noOfColumns);
		for (int j = 0; j < noOfColumns; j++) {
			columnHeaders.add(hssfWorkSheet.getRow(headerRowNum).getCell(j).getStringCellValue().replace(" ", ""));
			// System.out.println("Column headers " + columnHeaders);
		}
		System.out.println("Column headers " + columnHeaders);
		return columnHeaders;
	}

	public static int getNumberOfColumns(HSSFSheet hssfWorkSheet, int headerRowNum) {
		int noOfColumns = hssfWorkSheet.getRow(headerRowNum).getLastCellNum();
		return noOfColumns;
	}
	
	public static void cardUpdateInExcel(HSSFSheet hssfWorkSheet,String headerName,String expectedValue,int headerRowNum) {
		int noOfColumns = getNumberOfColumns(hssfWorkSheet,headerRowNum);
		ArrayList<String> columnHeaders=readHeader(hssfWorkSheet,headerRowNum);
		row = hssfWorkSheet.getRow(headerRowNum+1);
		for (int a = 0; a < noOfColumns; a++) {
			System.out.println("headers name-->" + columnHeaders.get(a));
			if (columnHeaders.get(a).equals(headerName)) {
						cell = row.getCell(a);
						cell.setCellValue(expectedValue);
			}
		}
	}
	public static ArrayList<String> readHeaderInList(HSSFSheet hssfWorkSheet, int headerRowNum) {
		int noOfColumns = getNumberOfColumns(hssfWorkSheet, headerRowNum);
		System.out.println("Number of columns is  " + noOfColumns);
		ArrayList<String> columnHeaders = new ArrayList<String>(noOfColumns);
		for (int j = 0; j < noOfColumns; j++) {
		String headers = hssfWorkSheet.getRow(headerRowNum).getCell(j).getStringCellValue();
		columnHeaders.add(headers.toLowerCase());
		//System.out.println("Column headers " + columnHeaders);
		}
		return columnHeaders;
		}
	public static String getCellValueUsingRowAndColIndex(HSSFSheet hssfWorkSheet,int rowIndex,int columnIndex) {
		String cellValue=hssfWorkSheet.getRow(rowIndex).getCell(columnIndex).getStringCellValue();
		return cellValue;		
	}
	public static ArrayList<String> columnValuesUsingColIndex(HSSFSheet hssfWorkSheet,int headerRowNum,int colIndex){
		int rowNum=hssfWorkSheet.getLastRowNum();
		ArrayList<String> columnValues = new ArrayList<String>(rowNum);
		for(int i=0; i < rowNum; i++) {
			columnValues.add(hssfWorkSheet.getRow(i).getCell(colIndex).getStringCellValue().toString());
		}
		return columnValues;
	}
	public static String getCellValueUsingRowIndexAndColumnName(HSSFSheet hssfWorkSheet,int headerRowNum,int rowIndex,String columnName) {
		int noOfColumns=getNumberOfColumns(hssfWorkSheet, headerRowNum);
		String cellValue=null;
		for(int i=0 ; i < noOfColumns ; i++) {
			if(hssfWorkSheet.getRow(headerRowNum).getCell(i).getStringCellValue().equalsIgnoreCase(columnName))
			{
				cellValue=hssfWorkSheet.getRow(rowIndex).getCell(i).getStringCellValue();
				
				//cellValue=hssfWorkSheet.getRow(rowIndex).getCell(i).getNumericCellValue();
			}
		}
		return cellValue;
	} 
}
