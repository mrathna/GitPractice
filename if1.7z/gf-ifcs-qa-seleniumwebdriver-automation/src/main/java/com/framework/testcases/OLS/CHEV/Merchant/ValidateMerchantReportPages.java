package com.framework.testcases.OLS.CHEV.Merchant;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;


import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.common.Common;
import com.framework.pages.BP.BPHomePage;
import com.framework.pages.CHEV.CHContactListPage;
import com.framework.pages.CHEV.CHHomePage;
import com.framework.pages.CHEV.CHStoredReportsPage;
import com.framework.pages.OLS.common.LoginPage;
import com.framework.pages.OLS.common.MerchantReportsPage;

public class ValidateMerchantReportPages extends BaseTest {
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "Smoke", "Regression","BusinessFlow" })
	public void validate_Invoice_Report_Page(@Optional("TH") String clientCountry, @Optional("CHV") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  CHEVRON  Invoice Report Page", "Checking the Invoice Report Pages");

		// Creating Objects for the Login Pages
		LoginPage loginPage = new LoginPage(driver, test);
		loginPage.Login("CHV_URL", "CHV_Customer_UN_" + clientCountry, "CHV_Customer_PWD_" + clientCountry, clientName);
		CHHomePage chHomePage = new CHHomePage(driver, test);
		CHStoredReportsPage chStoredReportsPage = new CHStoredReportsPage(driver, test);
		chHomePage.loadFindAndUpdateInvoiceReportsPage();
		chStoredReportsPage.verifyInvoicePageTitle();
		chStoredReportsPage.verifyInvoicePageSubTitles();
		chStoredReportsPage.enterfromtovalue();
		chStoredReportsPage.selectsearch();
		chStoredReportsPage.verifyexport();
		chStoredReportsPage.VerifystoreReports();
		
		chHomePage.clickOnHome();

		loginPage.Logout();
   	}
	
	
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "Smoke", "Regression","BusinessFlow" })
	public void validateContactsExport(@Optional("TH") String clientCountry, @Optional("CHV") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  CHEVRON  Invoice Report Page", "Checking the Invoice Report Pages");

		// Creating Objects for the Login Pages
		LoginPage loginPage = new LoginPage(driver, test);
		loginPage.Login("CHV_URL", "CHV_Customer_UN_" + clientCountry, "CHV_Customer_PWD_" + clientCountry, clientName);
		CHHomePage chHomePage = new CHHomePage(driver, test);
		CHContactListPage chContactListPage = new CHContactListPage(driver, test);
		CHStoredReportsPage chStoredReportsPage = new CHStoredReportsPage(driver, test);
		
		chHomePage.loadFindAndContactsPage();
		chContactListPage.verifyContactListPage();
		chContactListPage.verifyContactTableColumns();
		chContactListPage.verifyAddContactAndExportButton();
		chContactListPage.clickExportButton();
		
		//chStoredReportsPage.VerifystoreReports();
		
		chHomePage.clickOnHome();

		loginPage.Logout();
   	}
}
