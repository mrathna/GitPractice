package com.framework.testcases.AJS.BP;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.MaintainCustomerPage;
import com.framework.pages.AJS.SearchPage;
import com.framework.pages.AJS.common.Common;
import com.framework.pages.AJS.common.IFCSHomePage;
import com.framework.pages.AJS.common.IFCSLoginPage;

public class ValidateSearchTestCases extends BaseTest {
	
	@Parameters({ "clientCountry", "clientName"})
	@Test( groups = { "Regression" ,"BusinessFlow"})
	public void validateSearchCards(@Optional("NZ") String clientCountry, @Optional("BP") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  BPNZ50_Cust_NZ_017_Search Cards", "BPNZ50_Cust_NZ_017_Search Cards");
		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		SearchPage searchInputs = new SearchPage(driver, test);
		Common common = new Common(driver, test);
		IFCSloginPage.login("IFCS_URL_BP", "IFCS_BP_USERNAME", "IFCS_BP_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry," ");
		
		IFCSHomePage.gotoSearchAndClickCards();
		
		//common.performBlankSearchAndValidate();
		searchInputs.selectClientInDropDownAndSearch("Client", clientName + "_" + clientCountry);
		common.searchCardnumberAndValidate("Full", "Filter By");
		// Enter a Card Number and use the Wildcard (*) symbol and select the Search button
		common.searchCardnumberAndValidate("Partial", "Filter By");
		
		IFCSHomePage.exitIFCS();
	}
	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test(groups = { "Regression" ,"BusinessFlow"})
	public void validateSearchCustomer(@Optional("NZ") String clientCountry, @Optional("BP") String clientName,
			@Optional("APA") String cardType) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  Search Customer", "search Customer");
		// creating object for the Pages
		IFCSLoginPage ifcsloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage ifcsHomePage = new IFCSHomePage(driver, test);
		
		MaintainCustomerPage maintainCustomerPage = new MaintainCustomerPage(driver, test);
		Common common = new Common(driver, test);
		
		ifcsloginPage.login("IFCS_URL_BP", "IFCS_BP_USERNAME", "IFCS_BP_PASSWORD");
		ifcsHomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);
		ifcsloginPage.setClientCountryCardTypeDetails(clientName, clientCountry," ");
		ifcsHomePage.gotoCustomerMenuCustomerDetails();
		String customerNumber = common.getActiveCustomerNoUsingCardType();
		maintainCustomerPage.searchCustomerAndValidate(customerNumber);
		ifcsHomePage.exitIFCS();	
	}
	
}
