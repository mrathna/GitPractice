package com.framework.testcases.AJS.CHEVRON;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.ApplicationsPage;
import com.framework.pages.AJS.ClientConfigPage;
import com.framework.pages.AJS.MerchantLocationPage;
import com.framework.pages.AJS.OrderCardPage;
import com.framework.pages.AJS.common.Common;
import com.framework.pages.AJS.common.CommonInterfacePage;
import com.framework.pages.AJS.common.IFCSCommonPage;
import com.framework.pages.AJS.common.IFCSHomePage;
import com.framework.pages.AJS.common.IFCSLoginPage;
import com.framework.pages.AJS.common.InterfacePage;
import com.framework.util.PropUtils;
import com.github.javafaker.Faker;

public class DEDataCreationForE2EScenario extends BaseTest {

	@DataProvider(name = "Parameters")
	public static String[][] parameters() {
		String clientName = "CHEVRON";
		String clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		if (clientCountry.equals("MY")) {
			return new String[][] { { clientName, clientCountry, "StarCard - Staff" },
					{ clientName, clientCountry, "StarCard - Fleet" },
					{ clientName, clientCountry, "StarCash - Chevron" },
					{ clientName, clientCountry, "StarCash - Customer" },
					{ clientName, clientCountry, "Discount Card - Subsidy Petrol" },
					{ clientName, clientCountry, "Discount Card - Subsidy Diesel" } };
		} else if (clientCountry.equals("SG")) {
			return new String[][] { { clientName, clientCountry, "StarCard - Affinity" },
					{ clientName, clientCountry, "StarCard - Staff" },
					{ clientName, clientCountry, "StarCard - Fleet" },
					{ clientName, clientCountry, "Discount Card - Taxi" },
					{ clientName, clientCountry, "Discount Card - Bus" },
					{ clientName, clientCountry, "StarCard - Personal" } };
		} else if (clientCountry.equals("TH")) {
			return new String[][] { { clientName, clientCountry, "StarCard - Staff" },
					{ clientName, clientCountry, "StarCard - Fleet" } };
		} else if (clientCountry.equals("PH")) {
			return new String[][] { { clientName, clientCountry, "StarCard - Debit" },
					{ clientName, clientCountry, "StarCard - Staff" },
					{ clientName, clientCountry, "StarCard - Fleet" },
					{ clientName, clientCountry, "StarCash - Chevron" },
					{ clientName, clientCountry, "StarCash - Customer" } };
		} else {
			return new String[][] { { clientName, clientCountry, "StarCard - Fleet"},
					{ clientName, clientCountry, "Discount Card - CashCard - Prof Drvrs" },
					{ clientName, clientCountry, "Discount Card - CashCard - Hybrid Taxi" },
					{ clientName, clientCountry, "Discount Card - CashCard - Public Light Bus" },
					{ clientName, clientCountry, "Discount Card - Hanberg" },
					{ clientName, clientCountry, "Discount Card - CashCard - Site Card" },
					{ clientName, clientCountry, "Discount Card - Joyfuel" },
					{ clientName, clientCountry, "StarCard - Affinity" },
					{ clientName, clientCountry,  "Discount Card - CashCard - Diesel" } };
		}
	}

@Test(groups = { "Regression" }, dataProvider = "Parameters")
	public void createApplication(String clientName, String clientCountry, String applicationType) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  CVE_MY_Create the Application", "Create Application");
		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);

		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		ApplicationsPage IFCSApplicationsPage = new ApplicationsPage(driver, test);

		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		IFCSloginPage.login("IFCS_URL_CHEVRON", "IFCS_CHEVRON_USERNAME", "IFCS_CHEVRON_PASSWORD");

		IFCSHomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);

		IFCSHomePage.gotoApplicationAndClickApplicationMenu();
		IFCSApplicationsPage.createNewApplicationForChevron(clientCountry + " " + applicationType);
		IFCSApplicationsPage.createCardOffersInApplication(clientCountry + " " + applicationType);
		IFCSApplicationsPage.addPricingInApplication();
		IFCSApplicationsPage.addCardControlsInApplication();
		IFCSApplicationsPage.addCardReissueProfiles();
		IFCSApplicationsPage.validateAndCreateApplication(applicationType);
		IFCSHomePage.exitIFCS();
	}

	@Parameters({ "clientName","clientCountry"})
	@Test(groups = { "Regression" },enabled = false)
	public void runCusUpdatesCtrlmJobs(@Optional("CHEVRON") String clientName,@Optional("HK") String clientCountry) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  Running Customer Updates and Card Updates Jobs",
				" Running Customer Updates and Card Updates Jobs ");

		InterfacePage interfacePage = new InterfacePage(driver, test);
		IFCSLoginPage ifcsLoginPage = new IFCSLoginPage(driver, test);

		String clCountry = PropUtils.getPropValue(configProp, "clientCountry");

		ifcsLoginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");

		interfacePage.runCtrlmJobs("jobS_chv_CustUpdates");

		if (clCountry.equals("MY")) {
			interfacePage.runCtrlmJobs("jobs_chv_CardChanges_MY");
		} else {
			interfacePage.runCtrlmJobs("jobs_chv_CardChanges");
		}

	}

	@Parameters({ "clientCountry", "clientName"})
	@Test(groups = { "Regression" })
	public void createStarCardForSG(@Optional("HK") String clientCountry, @Optional("CHEVRON") String clientName) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  Chevron Card", "Creating Card ");
		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);

		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		IFCSCommonPage IFCSCommonPage = new IFCSCommonPage(driver, test);
		CommonInterfacePage CommonInterfacePage = new CommonInterfacePage(driver, test);
		Common common = new Common(driver, test);
		InterfacePage interfacePage = new InterfacePage(driver, test);
		IFCSLoginPage ifcsLoginPage = new IFCSLoginPage(driver, test);
		// Calling Functions
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, " ");
		IFCSloginPage.login("IFCS_URL_CHEVRON", "IFCS_CHEVRON_USERNAME", "IFCS_CHEVRON_PASSWORD");
		OrderCardPage chevronCardOrderPage = new OrderCardPage(driver, test);
		IFCSHomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);

		Map<String, String> appCust = new HashMap<String, String>();
		appCust = common.readDataFromPropertyFile("cusNo", chevronEndToEndTemplateFile);
		String fileName = null;

		Map<String, String> custCard = chevronCardOrderPage.orderNewCardChevron(appCust,
				clientName + "_" + clientCountry);

		System.out.println(custCard);
		ifcsLoginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		if (clientCountry.equalsIgnoreCase("MY")) {

			interfacePage.runCtrlmJobs("jobs_chv_CardChanges_MY");
			fileName = CommonInterfacePage.createFileNameFormatforMYCHVCAF(configProp, clientCountry);
			System.out.println("---fileNamRecent ::" + fileName);
		} else if (clientCountry.equalsIgnoreCase("HK")) {
			interfacePage.runCtrlmJobs("jobS_chv_emboss_HK");
			interfacePage.runCtrlmJobs("jobs_chv_CardChanges");
			fileName = CommonInterfacePage.createFileNameFormatforCHVCAF(configProp, clientCountry);
			System.out.println("---fileNamRecent ::" + fileName);
		}

		else {
			interfacePage.runCtrlmJobs("jobS_chv_emboss");
			interfacePage.runCtrlmJobs("jobs_chv_CardChanges");
			fileName = CommonInterfacePage.createFileNameFormatforCHVCAF(configProp, clientCountry);
			System.out.println("---fileNamRecent ::" + fileName);
		}

		IFCSCommonPage.establishThePuttyConnection("unzip file to xml", "PUTTY_HOST", "PUTTY_USERNAME",
				"PUTTY_PASSWORD", "IE_OUTPUTFILE_FOLDER_CHEVRONCAF", fileName);
		fileName = fileName.split("\\.")[0];
		String cardEmbossFilePathLocal = System.getProperty("user.home") + System.getProperty("file.separator")
				+ "Documents" + System.getProperty("file.separator") + fileName + ".XMT";
		IFCSCommonPage.validateCardsfromCAFCHV(clientCountry, cardEmbossFilePathLocal, custCard);

		IFCSHomePage.exitIFCS();
	}

	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "Regression" })
	public void ValidateMerchantLocationAgreementCreationCase(@Optional("HK") String clientCountry,
			@Optional("CHEVRON") String clientName) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  Merchant Location Creation And Merchant Agreement",
				"Create merchant, location and merchant agreement for CHV HK");
		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		IFCSCommonPage ifcsCommonPage = new IFCSCommonPage(driver, test);
		Common common = new Common(driver, test);
		CommonInterfacePage commonInterface = new CommonInterfacePage(driver, test);
		MerchantLocationPage merchantLocation = new MerchantLocationPage(driver, test);
		IFCSloginPage.login("IFCS_URL_CHEVRON", "IFCS_CHEVRON_USERNAME", "IFCS_CHEVRON_PASSWORD");
		//IFCSloginPage.login("IFCS_CHV_URL", "IFCS_CHV_UN", "IFCS_CHV_PWD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		IFCSHomePage.gotoApplicationAndClickApplicationMenu();
		IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);
		IFCSHomePage.gotoMerchantAndClickMerchantDetails();

		// Get Merchant Num and Location Num from DB
		String merchant = common.getMerchantNoFromDB();
		String locationNoFromDB = common.getLocationNoFromDB();

		// create Merchant
		common.chooseMerchantNoAndSearch(merchant);
		Faker fakerMerchantNo = new Faker();
		String f_merchantNo = fakerMerchantNo.number().digits(6);
		System.out.println("f_merchantNo" + f_merchantNo);
		merchantLocation.createNewMerchant(f_merchantNo);

		// create location
		merchantLocation.chooseLocationNoFromListAndDoubleClick(locationNoFromDB);
		// common.chooseLocationNoAndSearch(location);
		Faker fakerLocationNo = new Faker();
		String f_locationNo = fakerLocationNo.number().digits(6);
		System.out.println("f_locationNo" + f_locationNo);
		merchantLocation.createNewLocation(f_locationNo);

		// Merchant Agreement
		merchantLocation.validateMerchantAgreementForNewMerchantAndLocation(clientName, clientCountry, f_merchantNo,
				f_locationNo);
		Map<String, String> map = new HashMap<String, String>();
		map.put("Merchant_No", f_merchantNo);
		map.put("Location_No", f_locationNo);
		PropUtils.creatingTempPropFile("MerchantLocationNo.properties", map);

		// Searching PDF And Validate
		//String client_mid = commonInterface.funcFetchLoadCardTransClientMidFromIFCSDB(configProp);
		String processingDate = common.getCurrentIFCSDateFromDB(PropUtils.getPropValue(configProp, "clientName"));
		String IFCSDate = commonInterface.dateFormatConversion(processingDate, "dd.MM.yyyy");

		String fileName = commonInterface.getRecentProcessedReportFiles(clientName, clientCountry, "Merchant Statement",
				f_merchantNo);
		ArrayList<String> listFilePath = new ArrayList<String>();
		String dayEndDatePath = null;
		for (int i = 0; i < 1; i++) {
			if (clientCountry.equals("SG")) {
				dayEndDatePath = commonInterface.getFolderPathUsingCurrentSystemDate(clientName, clientCountry,
						"IFCS_DAYEND_OUTPUTFILE_CVSG_MERCHANT");
			} else if (clientCountry.equals("TH")) {
				dayEndDatePath = commonInterface.getFolderPathUsingCurrentSystemDate(clientName, clientCountry,
						"IFCS_DAYEND_OUTPUTFILE_CVTH_MERCHANT");
			} else if (clientCountry.equals("HK")) {
				dayEndDatePath = commonInterface.getFolderPathUsingCurrentSystemDate(clientName, clientCountry,
						"IFCS_DAYEND_OUTPUTFILE_CVHK_MERCHANT");
			} else if (clientCountry.equals("MY")) {
				dayEndDatePath = commonInterface.getFolderPathUsingCurrentSystemDate(clientName, clientCountry,
						"IFCS_DAYEND_OUTPUTFILE_CVMY_MERCHANT");
			} else if (clientCountry.equals("PH")) {
				dayEndDatePath = commonInterface.getFolderPathUsingCurrentSystemDate(clientName, clientCountry,
						"IFCS_DAYEND_OUTPUTFILE_CVPH_MERCHANT");
			}
			System.out.println("dayEndDatePath::" + dayEndDatePath);
			ifcsCommonPage.establishThePuttyConnection("incomingFile", "PUTTY_HOST", "PUTTY_USERNAME", "PUTTY_PASSWORD",
					dayEndDatePath, fileName);
			String localFolder = System.getProperty("user.home") + "\\Documents\\" + fileName;

			listFilePath.add(localFolder);
		}

		for (int i = 0; i < listFilePath.size(); i++) {
			if (listFilePath.get(i).contains("Merchant Statement")) {
				ifcsCommonPage.validateMerchantStatementReports(listFilePath.get(i), f_locationNo, IFCSDate);
			}
		}
	}

	@Parameters({ "clientName","clientCountry" })
	@Test(groups = { "Regression" })
	public void settingCalendarFrequencyForReports(@Optional("CHEVRON") String clientName,@Optional("HK") String clientCountry) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  Pre-requisite Chevron setting calendar frequency for reports ",
				"Chevron setting calendar frequency for reports ");
		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);

		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		ClientConfigPage clientConfigPage = new ClientConfigPage(driver, test);

		//String cliCountry = PropUtils.getPropValue(configProp, "clientCountry");

		// Calling Functions
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		IFCSloginPage.login("IFCS_URL_CHEVRON", "IFCS_CHEVRON_USERNAME", "IFCS_CHEVRON_PASSWORD");

		IFCSHomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);
		IFCSHomePage.clickingCalendarSubMenu();
		clientConfigPage.creatingCalendar("Frequency", "Merchant Statement Frequency");
		clientConfigPage.creatingCalendar("Frequency", "Merchant Reimbursement Day");
		IFCSHomePage.exitIFCS();

	}

	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "Regression" })
	public void ValidateAndUpdateXMLLoadCardTransactions(@Optional("MY") String clientCountry,
			@Optional("CHEVRON") String clientName) {

		test = extent.createTest(
				clientName + "_" + clientCountry
						+ "Update XML LoadCard Transactions",
				"Verify and Update XML Load Card Transactions");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage=new IFCSHomePage(driver,test);
		Common common = new Common(driver, test);
		IFCSCommonPage ifcsCommonPage = new IFCSCommonPage(driver, test);
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, " ");
		//calling methods
		String clientNameInProp = PropUtils.getPropValue(configProp, clientName + "_" + clientCountry);
		System.out.println("clientNameInProp::" + clientNameInProp);
		HashMap<String, String> RefNum=new HashMap<String, String>();
		Map<String, String> getcardNumbers = common.readDataFromPropertyFile("cardNo", chevronendtoendTemplatePropFile);
		Map<String, String> getLocationNo = common.readDataFromPropertyFile("Location_No", chevronendtoendTemplatePropFile);
		System.out.println("CardNumbers::"+getcardNumbers);
		if(clientCountry.equals("SG")) {
		   RefNum = ifcsCommonPage.updateValuesInLoadCardTransactionXMLForChevron_SG(getcardNumbers,getLocationNo,clientNameInProp,clientCountry);
		}else if(clientCountry.equals("PH")) {
		   RefNum = ifcsCommonPage.updateValuesInLoadCardTransactionXMLForChevron_PH(getcardNumbers,getLocationNo,clientNameInProp,clientCountry);
		}else if(clientCountry.equals("TH")) {
		   RefNum = ifcsCommonPage.updateValuesInLoadCardTransactionXMLForChevron_TH(getcardNumbers,getLocationNo,clientNameInProp,clientCountry);
		}else if(clientCountry.equals("MY")) {
	       RefNum = ifcsCommonPage.updateValuesInLoadCardTransactionXMLForChevron_MY(getcardNumbers,getLocationNo,clientNameInProp,clientCountry);
		}else {
		   RefNum = ifcsCommonPage.updateValuesInLoadCardTransactionXMLForChevron_HK(getcardNumbers,getLocationNo,clientNameInProp,clientCountry);	
		}
		System.out.println("Hash Map::"+RefNum);
		IFCSloginPage.login("IFCS_URL_CHEVRON", "IFCS_CHEVRON_USERNAME", "IFCS_CHEVRON_PASSWORD");
		
		IFCSHomePage.gotoAdminMenuAndChooseClient(clientName+"_"+clientCountry);
		  common.clientBatchJobExecution("LoadCardTransactions");
		  
		  IFCSHomePage.exitIFCS();
		 
	}

}
