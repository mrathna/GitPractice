using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using Common;
using Common.PageObjects;
using Common.ScenarioConfigurations;
using Common.Utility;

namespace EnCompass.Testing.Source.PageObjects.Organization.SecurityManager.Notifications 
{
	/// <summary>
	/// Auto-generated Page Model Class
	/// Navigation Paths: 
		/// [Organization Home]->Security->Alerts and Notifications->Notification Settings
		/// </summary>
	[PageModel(@"/securityManager/notifications/notificationSettings.aspx")]
	public partial class NotificationSettings : EnCompassOrgPageModel 
	{
		public override string RelativeUrl => @"/securityManager/notifications/notificationSettings.aspx";
		public override string PageIdentifierXPath_Generated => @"//li[contains(@class, 'breadcrumb-item active')][text() = 'Notification Settings']";

		#region Navigation
				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Alert Settings']")]
		private IWebElement _security_AlertsAndNotifications_NotificationSettings_AlertSettings { get; set; }
		public void NavigateTo_Security_AlertsAndNotifications_NotificationSettings_AlertSettings()
		{
			NavigateToMenuItem(_security_AlertsAndNotifications_NotificationSettings_AlertSettings);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Card Notifications']")]
		private IWebElement _security_AlertsAndNotifications_NotificationSettings_CardNotifications { get; set; }
		public void NavigateTo_Security_AlertsAndNotifications_NotificationSettings_CardNotifications()
		{
			NavigateToMenuItem(_security_AlertsAndNotifications_NotificationSettings_CardNotifications);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Notification Settings']")]
		private IWebElement _security_AlertsAndNotifications_NotificationSettings_NotificationSettings { get; set; }
		public void NavigateTo_Security_AlertsAndNotifications_NotificationSettings_NotificationSettings()
		{
			NavigateToMenuItem(_security_AlertsAndNotifications_NotificationSettings_NotificationSettings);
		}

		
		private void NavigateToMenuItem(IWebElement element)
		{
			Driver.Url = element.GetAttribute("href");
		}
		#endregion

		public NotificationSettings(GlobalSettings settings) : base(settings) { }
	}  
}
