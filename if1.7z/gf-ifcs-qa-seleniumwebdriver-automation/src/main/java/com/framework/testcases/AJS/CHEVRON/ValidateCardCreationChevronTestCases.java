package com.framework.testcases.AJS.CHEVRON;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.ApplicationsPage;
import com.framework.pages.AJS.MaintainCustomerPage;
import com.framework.pages.AJS.OrderCardPage;
import com.framework.pages.AJS.common.Common;
import com.framework.pages.AJS.common.IFCSHomePage;
import com.framework.pages.AJS.common.IFCSLoginPage;

public class ValidateCardCreationChevronTestCases  extends BaseTest {
	
	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test(groups = { "Regression" })
	public void orderNewStarCardFleetCustomerForChevron(@Optional("TH") String clientCountry,
			@Optional("CHEVRON") String clientName, @Optional("APA") String cardType) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  Chevron TH Order StarCard Fleet",
				"TC003 Order New Card StarCard Debit Customer");
		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);

		
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		ApplicationsPage IFCSApplicationsPage = new ApplicationsPage(driver, test);
		OrderCardPage ChevronCardOrderPage=new OrderCardPage(driver, test);

		// Calling Functions
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, cardType);
		IFCSloginPage.login("IFCS_URL_CHEVRON", "IFCS_CHEVRON_USERNAME", "IFCS_CHEVRON_PASSWORD");
		
		//IFCSHomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);
		
		IFCSHomePage.gotoApplicationAndClickApplicationMenu();
		IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);
		IFCSApplicationsPage.applicationFilterOptions(clientCountry+" StarCard - Fleet", "Approved");
		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		ChevronCardOrderPage.orderNewStarCardFleetChevron();
		IFCSHomePage.exitIFCS();
		
	}
	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test(groups = { "Regression" })
	public void orderNewStarCardStaffCustomerForChevron(@Optional("TH") String clientCountry,
			@Optional("CHEVRON") String clientName, @Optional("APA") String cardType) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  Chevron TH Order StarCard Staff",
				"TC004 Order New Card StarCard Staff Customer");
		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);

		
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		ApplicationsPage IFCSApplicationsPage = new ApplicationsPage(driver, test);
		OrderCardPage ChevronCardOrderPage=new OrderCardPage(driver, test);
		
	
		// Calling Functions
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, cardType);
		IFCSloginPage.login("IFCS_URL_CHEVRON", "IFCS_CHEVRON_USERNAME", "IFCS_CHEVRON_PASSWORD");
		
		//IFCSHomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);
		
		IFCSHomePage.gotoApplicationAndClickApplicationMenu();
		IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);
	
		IFCSApplicationsPage.applicationFilterOptions("TH StarCard - Staff", "Approved");
		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		ChevronCardOrderPage.orderNewStarCardStaffChevron();
		IFCSHomePage.exitIFCS();
	
	}
	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test(groups = { "Regression" })
	public void orderNewStarCardFleetPEZAForPH(@Optional("PH") String clientCountry,
			@Optional("CHEVRON") String clientName, @Optional("APA") String cardType) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  Order New Card StarCard Fleet for PH",
				"TC008 Order New Card StarCard Fleet for PH");
		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		ApplicationsPage IFCSApplicationsPage = new ApplicationsPage(driver, test);
		OrderCardPage ChevronCardOrderPage=new OrderCardPage(driver, test);

		// Calling Functions
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, cardType);
		IFCSloginPage.login("IFCS_URL_CHEVRON", "IFCS_CHEVRON_USERNAME", "IFCS_CHEVRON_PASSWORD");
		
		//IFCSHomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);
		
		IFCSHomePage.gotoApplicationAndClickApplicationMenu();
		IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);
		IFCSApplicationsPage.applicationFilterOptions("PH StarCard - Fleet", "Approved");
		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		ChevronCardOrderPage.orderNewStarCardFleetForPH();
		IFCSHomePage.exitIFCS();
		
	}
	
	/*
	 * Added by Davu -30/04/2020
	 */
	
	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test(groups = { "Regression" })
	public void orderNewCardWithInvalidDataAndValidate(@Optional("TH") String clientCountry,
			@Optional("CHEVRON") String clientName, @Optional("APA") String cardType) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  Chevron TH Order StarCard Fleet",
				"TC003 Order New Card with invalid Data and verify decline message");
		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);

		
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		ApplicationsPage IFCSApplicationsPage = new ApplicationsPage(driver, test);
		OrderCardPage ChevronCardOrderPage=new OrderCardPage(driver, test);

		// Calling Functions
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, cardType);
		IFCSloginPage.login("IFCS_URL_"+clientName, "IFCS_"+clientName+"_USERNAME", "IFCS_"+clientName+"_PASSWORD");
		
		//IFCSHomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);
		
		IFCSHomePage.gotoApplicationAndClickApplicationMenu();
		IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);
		IFCSApplicationsPage.applicationFilterOptions(clientCountry+" StarCard - Fleet", "Approved");
		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		ChevronCardOrderPage.orderNewCardWithInvalidDataChevron();
		IFCSHomePage.exitIFCS();
		
	}
	
	

	/**
	 * Added by Rathna
	 * 
	 * @param clientCountry
	 * @param clientName
	 *            
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "Regression" })
	public void  defaultPublicCardIssueFeeProfile(@Optional("TH") String clientCountry,
			@Optional("CHEVRON") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  BP IFCS Create New Profile for Card Reissue Profiles",
				"BP Maintain Customer -  Card  Profiles - Card Reissue Profiles  - Create New Profile");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		Common common = new Common(driver, test);
		MaintainCustomerPage maintainCustomerPage = new MaintainCustomerPage(driver, test);

		IFCSloginPage.login("IFCS_URL_"+clientName, "IFCS_"+clientName+"_USERNAME", "IFCS_"+clientName+"_PASSWORD");
		
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		String customerNo = common.getCustomerNoHavingCardsUsingCardType();
		if (customerNo.equals(" ")) {
			common.logForNoDataFound(this.getClass().getSimpleName(), "Need to Create A Customer with Cards and rerun");
		} else {
			common.chooseCustomerNoAndSearch(customerNo);
			maintainCustomerPage.chooseCardReissueProfileFromCustomerProfile();
			//maintainCustomerPage.createCardReissueProfile(); commented now
			maintainCustomerPage.setCardReissueProfileAsDefalt("Reissue");

		}
		IFCSHomePage.exitIFCS();
	}
	
	
	

}
