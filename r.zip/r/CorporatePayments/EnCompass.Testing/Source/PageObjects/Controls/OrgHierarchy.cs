﻿using AventStack.ExtentReports;
using Common.Utility;
using OpenQA.Selenium;
using Common;

namespace EnCompass.Testing.Source.PageObjects.Controls
{
    public class OrgHierarchy
    {
        private IWebElement _hierarchyLink;
        private IWebDriver _driver;
		private GlobalSettings _settings;

        private static string _topHierarchyCheck = @"//span[contains(text(),'{0}')]/parent::*/preceding-sibling::input";
        private static string _topHierarchyLabel = @"//div[contains(@id, 'hierachyExplorer')]//label[contains(@class,'custom-control-label')]//span[contains(text(),'{0}')]";

        public OrgHierarchy(IWebElement hierarchyLink, IWebDriver driver, GlobalSettings settings)
        {
            _hierarchyLink = hierarchyLink;
            _driver = driver;
			_settings = settings;

		}

        /// <summary>
        /// Description: This method clicks the Open Hierarchy link, chooses the Top Most org and then completes the selection.
        /// </summary>
        public void SelectTopHierarchy()
        {
            _hierarchyLink.WaitUntilElementIsInteractable();
            _hierarchyLink.JsScrollToElement(_driver);
            _hierarchyLink.JSClickWithFocus(_driver);
            string _hierarchyExplorerXPath = @"//div[contains(@id, 'hierachyExplorer')]";
			var _topHierarchyCheckBox = _driver.WaitFor(By.XPath("(//div[contains(@id, 'hierachyExplorer')]//input[contains(@class,'custom-control-input')])[1]"));
			var _topHierarchyCheckBoxLabel = _driver.WaitForVisible(By.XPath("(//div[contains(@id, 'hierachyExplorer')]//label[contains(@class,'custom-control-label')])[1]"));
			_topHierarchyCheckBoxLabel.WaitUntilElementIsInteractable();
            _topHierarchyCheckBox.SetCheckboxStateWithLabelJS(_driver,true);
			_settings.EnCompassExtentTest.Info("Clicked on Top Hierarchy CheckBox Label");

			var _finishButton = _driver.FindElement(By.XPath(_hierarchyExplorerXPath + @"//button[contains(@id, 'finish')]"));
            _finishButton.JSClickWithFocus(_driver);
			_settings.EnCompassExtentTest.Info("Clicked on Hierarchy Finish Button");
			_driver.WaitForAbsence(By.XPath(_hierarchyExplorerXPath));
			_settings.EnCompassExtentTest.Info("Waited For Hierarchy Explorer to disappear");
		}

		//This select Hierarchy doenst need to press the finish button, the modal close after select the hierarchy
		public void SelectTopHierarchyOthers()
        {
			_hierarchyLink.JSClickWithFocus(_driver);
			_settings.EnCompassExtentTest.Info("Clicked on Hierarchy Link");
			
			var _topHierarchyCheckBox = _driver.WaitFor(By.XPath(@"(//div[contains(@id, 'hierachyExplorer')]//label[contains(@class,'custom-control-label')])[1]"));
            _topHierarchyCheckBox.WaitUntilElementIsInteractable();
            _topHierarchyCheckBox.JSClickWithFocus(_driver);

        }
		/// <summary>
		/// Description: This method clicks the Open Hierarchy link, chooses the Second Level Org and then completes the selection.
		/// </summary>
		public void SelectSecondLevelHierarchy()
		{
			_hierarchyLink.JSClickWithFocus(_driver);
                
            var _secondLevelHierarchyCheckBox = _driver.WaitFor(By.XPath(@"(//div[contains(@id, 'hierachyExplorer')]//label[contains(@class,'custom-control-label')])[2]"));
            _secondLevelHierarchyCheckBox.WaitUntilElementIsInteractable();
            _secondLevelHierarchyCheckBox.JSClickWithFocus(_driver);
            _settings.EnCompassExtentTest.Info("Clicked on Second Hierarchy CheckBox Label");

        }

        /// <summary>
		/// Description: This method clicks the Open Hierarchy link, chooses Level Org passed by parameter and then completes the selection.
		/// </summary>
        public void SelectHierarchyLevel(int level, bool state)
        {
            _hierarchyLink.JSClickWithFocus(_driver);
            string _hierarchyExplorerXPath = @"//div[contains(@id, 'hierarchyExplorer')]";
            
            IWebElement hierarchy = _driver.WaitFor(By.XPath("(//input[@type='checkbox' and @class='nodeSelect'])["+level+"]"));

            hierarchy.SetCheckboxState(state);

            var _finishButton = _driver.FindElement(By.XPath(_hierarchyExplorerXPath + @"//button[contains(@id, 'finish')]"));
            _finishButton.JSClickWithFocus(_driver);

        }

        
        /// <summary>
        /// Description: This method clicks the Open Hierarchy link, chooses the Hierarchy by organization.
        /// </summary>
        public void SelectTopHierarchybyOrg(string orgName, ExtentTest test)
        {
            _hierarchyLink.WaitUntilElementIsInteractable();
            //_hierarchyLink.JSClickWithFocus (_driver);
            _hierarchyLink.JSClickWithFocus(_driver);
            test.Info("Hierarchy Link clicked");
            string _hierarchyExplorerXPath = @"//div[contains(@id, 'hierachyExplorer')]";

            var _topHierarchyCheckBox = _driver.WaitFor(By.XPath(string.Format(_topHierarchyCheck, orgName)));
            var _topHierarchyCheckBoxLabel = _driver.WaitForVisible(By.XPath(string.Format(_topHierarchyLabel, orgName)));
            _topHierarchyCheckBoxLabel.WaitUntilElementIsInteractable();
            _topHierarchyCheckBox.SetCheckboxStateWithLabel(_topHierarchyCheckBoxLabel, true);

            var _finishButton = _driver.FindElement(By.XPath(_hierarchyExplorerXPath + @"//button[contains(@id, 'finish')]"));
            _finishButton.JSClickWithFocus(_driver);
            _driver.WaitForAbsence(By.XPath(_hierarchyExplorerXPath));
        }


        public bool VerifyCheckedFirstLevelHierarchy()
        {
            return _driver.FindElement(By.XPath(@"//input[contains(@type='Checkbox')]/parent::div[contains[@class,'childnodes']")).GetAttribute("checked").Equals("true") ? true : false;
        }

    }
}
