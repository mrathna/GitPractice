package com.framework.testcases.OLS.CHEV.Location;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.CHEV.CHChangePasswordPage;
import com.framework.pages.CHEV.CHHomePage;
import com.framework.pages.OLS.common.LoginPage;

public class ValidateOLSMerchantLocationSiteHomePage extends BaseTest {
	@Parameters({ "clientCountry", "clientName" })
	@Test(priority = 1)
	public void testOLSMerchantLocationScreensHomePage(@Optional("SG") String clientCountry, @Optional("CHV") String clientName) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  OLS - All Location Site - Home Page",
				"Chevron Merchant Screens Location Site Read Only");

		LoginPage loginPage = new LoginPage(driver, test);
		CHHomePage chHomePage = new CHHomePage(driver, test);
		CHChangePasswordPage chChangePasswordPage = new CHChangePasswordPage(driver, test);
		if (clientCountry.equals("SG")||clientCountry.equals("MY")||clientCountry.equals("HK")) {
			loginPage.Login("CHV_URL", "CHV_Location_UN_"+clientCountry, "CHV_Location_PWD_"+clientCountry, clientName);			
			
		} else if (clientCountry.equals("TH")) {
			loginPage.Login("CHV_URL", "CHV_Merchant_UN_"+clientCountry, "CHV_Merchant_PWD_"+clientCountry, clientName);

		} else if (clientCountry.equals("PH")) {
			loginPage.Login("CHV_URL", "CHV_Merchant_UN_"+clientCountry, "CHV_Merchant_PWD_"+clientCountry, clientName);

		}

	//	chHomePage.verifyUserNameAndLogoutLink();
		// chHomePage.verifyMerchantAccountDetails();
		chHomePage.clickOnUsername();
		chHomePage.clickOnChangePwdLink();
		chChangePasswordPage.verifyPasswordMaintenancePage();

		chChangePasswordPage.enterRandomValuesExceptPasswordField();
		chChangePasswordPage.clickSubmitButton();
		chChangePasswordPage.verifyErrorMessage("Validation failed");

		
		if (clientCountry.equals("SG")) {
			chChangePasswordPage.enterRandomValuesExceptConfirmationPasswordField("CHV_Location_PWD_SG");
		}
		else if (clientCountry.equals("TH")) {
			chChangePasswordPage.enterRandomValuesExceptConfirmationPasswordField("CHV_Merchant_PWD_TH");
		}
		else if (clientCountry.equals("PH")) {
			chChangePasswordPage.enterRandomValuesExceptConfirmationPasswordField("CHV_Merchant_PWD_PH");
		}			
		
		chChangePasswordPage.clickSubmitButton();
		chChangePasswordPage.verifyErrorMessage("Validation failed");

		if (clientCountry.equals("SG")) {
			chChangePasswordPage.enterRandomValuesWithDiffNewAndConfirm("CHV_Location_PWD_SG");
		}
		else if (clientCountry.equals("TH")) {
			chChangePasswordPage.enterRandomValuesWithDiffNewAndConfirm("CHV_Merchant_PWD_TH");
		}
		else if(clientCountry.equals("PH"))
		{
			chChangePasswordPage.enterRandomValuesWithDiffNewAndConfirm("CHV_Merchant_PWD_PH");
		}
		chChangePasswordPage.clickSubmitButton();
		chChangePasswordPage.verifyErrorMessage("Validation failed");
		
		if (clientCountry.equals("SG")) {

			chChangePasswordPage.enterNewValues("CHV_Location_PWD_SG", "password03");
		}
		else if (clientCountry.equals("TH")) {
			chChangePasswordPage.enterNewValues("CHV_Merchant_PWD_TH", "password03");
		}
		else if (clientCountry.equals("PH")) {
			chChangePasswordPage.enterNewValues("CHV_Merchant_PWD_PH", "password03");
		}
		//chChangePasswordPage.clickSubmitButton();

		// TODO CHeck Confirmation Message Web Element if the TC is failing
		//chChangePasswordPage.checkConfirmationMessage();
		chChangePasswordPage.sleep(20);

		loginPage.Logout();
	}
}
