﻿using Common;
using Common.Utility;
using EnCompass.Testing.Source.PageObjects.Controls;
using NFluent;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EnCompass.Testing.Source.PageObjects.Organization.DecisionStream.AccountMaintenance
{
	//[PageModel(@"/decisionStream/AccountMaintenance/lastTransactions.aspx")]
	public partial class LastTransactions
	{
		//public LastTransactions(GlobalSettings settings) : base(settings) { }

		//public override string RelativeUrl => @"/decisionStream/AccountMaintenance/lastTransactions.aspx";
		public override string PageIdentifierXPath_Override => @"//li[@class='breadcrumb-item active'][text() = 'Recent Activity']";
		private GridControl _accountsGrid;

        public GridControl AccountsGrid
        {
            get
            {
                _accountsGrid = new GridControl("dgAccounts", Driver);
                _accountsGrid.WaitForGrid();
                return _accountsGrid;
            }
        }

        #region XPath page Elements

        private string _frameGenericXPath = @"//iframe[contains(@src,'/decisionStream/accountMaintenance/')]";
        private string _frameRecentActivityXPath = "//iframe[contains(@src,'RecentActivity.aspx')]";
        private string _frameMCCSummaryXPath = "//iframe[contains(@src,'MCCSummary.aspx')]";
        private string _frameCreateInstantApprovalBtn = "//input[contains(@id, 'btnInstantApproval')][@type='submit'][@value='Instant Approval'][not(contains(@id, 'Confirm'))]";
        private string _frameEditInstantApprovalBtn = "//input[contains(@id, 'EditInstantApproval')]";
        private string _instantApprovalAmount = "//input[contains(@id, 'InstantApprovalAmount')]";
        private string _instantApprovalExpiration = "//input[contains(@id, 'approvalHours')]";
        private string _instantApprovalNumTransAllowed = "//input[contains(@id, 'InstantApprovalNumber')]";

        private const string authOverrideSelectAllXPath = @"//input[contains(@id, 'reasonSelectAll')]";
        private const string authOverrideCVVXPath = @"//input[contains(@id, 'reasonCvv')]";
        private const string authOverrideCardholderLimitXPath = @"//input[contains(@id, 'reasonCardholderLimit')]";
        private const string authOverrideExpirationDateXPath = @"//input[contains(@id, 'reasonExpirationDate')]";
        private const string authOverrideCV2XPath = @"//input[contains(@id, 'reasonCV2')]";
        private const string authOverrideDailyTxnLimitXPath = @"//input[contains(@id, 'reasonDailyTransactionLimit')]";
        private const string authOverrideSingleTxnLimitXPath = @"//input[contains(@id, 'reasonSingleTransactionLimit')]";
        private const string authOverrideAccountStatusXPath = @"//input[contains(@id, 'reasonAccountStatus')]";
        private const string authOverrideFleetIDXPath = @"//input[contains(@id, 'reasonFleetId')]";
        private const string authOverridePINXPath = @"//input[contains(@id, 'reasonPin')]";
        private const string authOverrideMCCXPath = @"//input[contains(@id, 'reasonMCC')]";
        private const string authOverrideFraudCriteriaXPath = @"//input[contains(@id, 'reasonFraudCriteria')]";
        private const string authOverrideHierarchyLimitXPath = @"//input[contains(@id, 'reasonHierarchyLimit')]";
        private string authOverrideCorporateLimitXPath = "//input[contains(@id, 'reasonCorporateLimit')]";
        private const string authOverrideCentralBillLimitXPath = @"//input[contains(@id, 'reasonCentralBillLimit')]";
        private const string authOverrideDelinquencyXPath = @"//input[contains(@id, 'reasonDelinquency')]";
        private string _dialogDescriptionXPath = @"//p[contains(@id,'noChartPanel')]";
        private const string _btnSearchXPath = @"//input[contains(@id, 'btnSearch')]";
        private const string _btnCloseXPath = @"//input[contains(@id, 'btnClose')]";
        private const string _ddlSearchCategoryXPath = @"//select[contains(@id, 'searchTermSelect')]";
        private const string _firstSearchTermXPath = @"//div[contains(@id, 'SearchOutput')]/select[contains(@aria-label, 'Search Term')][1]";
        private const string _ddlFilterTypeXPath = @"//select[contains(@id, 'searchTermFilter')]";
        private const string _txtSearchOutputXPath = @"//input[contains(@id, 'SearchOutput_txt')]";
		private const string _ddlSearchOutputValuesXPath = @"//select[contains(@id, '_SearchOutput_values')]";
		private const string _btnAddXPath = @"//input[contains(@value, 'Add')]";
        private const string _btnResetXPath = @"//button[@type='button' and text()='Clear']";
        private const string _mccModalXPath = @"//div[contains(@id, 'mccChartModal')]";
        private const string _cancelBtnXPath = @"//button[contains(@id, 'ApprovalModalClose')]";
        private const string _instantApprovalBtnXPath = @"//input[contains(@id, 'InstantApprovalConfirm')]";
        private const string _editInstantApprovalBtnXPath = @"//input[contains(@id, 'EditInstantApproval')]";
        private const string _deleteInstantApprovalBtnXPath = @"//input[contains(@id, 'DeleteInstantApproval')]";
        private string _titleMerchantCategoryCodeSummary = "//div[contains(@id,'ModalContent')]/div/h1[text()='Merchant Category Code Summary']";
        private const string _modalSuccessMessageXPath = @"//div[contains(@id, 'SuccessMessage')]/p";
        private const string _modalValidationSummaryXPath = @"//div[contains(@id, '_ValidationSummary')]//li";
        private const string _modalcmdDeleteInstantApprovalXPath = @"//input[contains(@id, 'cmdDeleteInstantApproval')]";
        private const string _modalbtnInstantApprovalDeleteXPath = @"//input[contains(@id, 'btnInstantApprovalDelete')]";
        private const string _modalbtnInstantApprovalConfirmXPath = @"//input[contains(@id, 'btnInstantApprovalConfirm')]";
        #endregion

        #region Page Elements
        // The following are all the Authorization Rules to Override options.
		private IWebElement authOverrideSelectAll
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(authOverrideSelectAllXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"authOverrideSelectAll element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement authOverrideCVV
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(authOverrideCVVXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"authOverrideCVV element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement authOverrideCardholderLimit
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(authOverrideCardholderLimitXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"authOverrideCardholderLimit element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement authOverrideExpirationDate
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(authOverrideExpirationDateXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"authOverrideExpirationDate element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement authOverrideCV2
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(authOverrideCV2XPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"authOverrideCV2 element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement authOverrideDailyTxnLimit
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(authOverrideDailyTxnLimitXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"authOverrideDailyTxnLimit element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement authOverrideSingleTxnLimit
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(authOverrideSingleTxnLimitXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"authOverrideSingleTxnLimit element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement authOverrideAccountStatus
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(authOverrideAccountStatusXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"authOverrideAccountStatus element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement authOverrideFleetID
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(authOverrideFleetIDXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"authOverrideFleetID element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement authOverridePIN
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(authOverridePINXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"authOverridePIN element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement authOverrideMCC
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(authOverrideMCCXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"authOverrideMCC element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement authOverrideFraudCriteria
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(authOverrideFraudCriteriaXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"authOverrideFraudCriteria element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement authOverrideHierarchyLimit
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(authOverrideHierarchyLimitXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"authOverrideHierarchyLimit element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement authOverrideCentralBillLimit
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(authOverrideCentralBillLimitXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"authOverrideCentralBillLimit element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement authOverrideDelinquency
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(authOverrideDelinquencyXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"authOverrideDelinquency element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }


        private IWebElement _btnSearch
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_btnSearchXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_btnSearch element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _btnClose
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_btnCloseXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_btnClose element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _ddlSearchCategory
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_ddlSearchCategoryXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_ddlSearchCategory element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

		private IWebElement _ddlSearchOutputValues
		{
			get
			{
				bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_ddlSearchOutputValuesXPath), out IWebElement element);
				Settings.EnCompassExtentTest.Info($"_ddlSearchOutputValues element exist is {found}");
				Check.That(found).IsTrue();
				return element;
			}
		}


		private IWebElement _firstSearchTerm
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_firstSearchTermXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_firstSearchTerm element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _ddlFilterType
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_ddlFilterTypeXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_ddlFilterType element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _txtSearchOutput
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_txtSearchOutputXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_txtSearchOutput element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _btnAdd
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_btnAddXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_btnAdd element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _btnReset
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_btnResetXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_btnReset element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _mccModal
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_mccModalXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_mccModal element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _cancelBtn
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_cancelBtnXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_cancelBtn element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _instantApprovalBtn
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_instantApprovalBtnXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_instantApprovalBtn element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _editInstantApprovalBtn
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_editInstantApprovalBtnXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_editInstantApprovalBtn element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _deleteInstantApprovalBtn
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_deleteInstantApprovalBtnXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_deleteInstantApprovalBtn element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        #endregion

		/// <summary>
		/// Perform Filter on Recent Activity Page with Category, SearchTerm, SearchType and Reset.
		/// </summary>
        public void Filter(string category, string type, string searchTerm, bool reset)
		{
			if (reset)
				_btnReset.JSClickWithFocus(Driver);
			// Set the Search Category
			_ddlSearchCategory.SetListboxByText(category, SelectTextOptions.Exact, Driver, Settings, _ddlSearchCategoryXPath);
			// Set Search Type if its enabled
			if (_ddlFilterType.Enabled)
				_ddlFilterType.SetListboxByText(type, SelectTextOptions.Exact, Driver, Settings, _ddlFilterTypeXPath);

			// Set SEarch Categpry based on its a DDL or TextBox
			if (new List<string> { "Account Type", "Account Status", "Billing Currency" }.Contains(category))
			{
				_ddlSearchOutputValues.SetListboxByText(searchTerm, SelectTextOptions.Exact, Driver, Settings, _ddlSearchOutputValuesXPath);
			}
			else
			{
				_txtSearchOutput.Clear();
				_txtSearchOutput.SendKeys(searchTerm);
				Settings.EnCompassExtentTest.Info("Search Term Set to :" + searchTerm);
			}
			// Add and search
			_btnAdd.JSClickWithFocus(Driver);
			_btnSearch.JSClickWithFocus(Driver);
		}

		public void Search()
		{
			_btnSearch.JSClickWithFocus(Driver);
		}

		public void Reset()
		{
			_btnReset.JSClickWithFocus(Driver);
		}

		public string SetSearchTerm
		{
			get { return new SelectElement(_firstSearchTerm).SelectedOption.Text.Trim(); }
			set { _firstSearchTerm.SetListboxByText(value, SelectTextOptions.StartsWith); }
		}


		public void CloseModal()
		{
			using (FrameHelper modal = new FrameHelper(Driver, By.XPath(_frameGenericXPath)))
			{
                modal.FindElement(By.XPath(@"//*[contains(@onclick, 'Bridge.Close()')]")).WaitUntilElementIsInteractable();
                modal.FindElement(By.XPath(@"//*[contains(@onclick, 'Bridge.Close()')]")).JSClickWithFocus(Driver);
			}

		}

		public void CreateInstantApprovalButtonClick()
		{
			using (FrameHelper modal = new FrameHelper(Driver, By.XPath(_frameRecentActivityXPath)))
			{
				modal.FindElement(By.XPath(_frameCreateInstantApprovalBtn)).JSClickWithFocus(Driver);
				Driver.WaitForVisible(By.XPath(_instantApprovalAmount));
			}
		}

		public void CancelInstantApprovalDialog()
		{
			if (Driver.TryFindElement(By.XPath(@"//button[contains(@id, 'ApprovalModalClose')]"), out IWebElement element))
			{
				element.JSClickWithFocus(Driver);
			}
		}
		//public void CancelInstantApprovalDialog()
		//{
		//	using (FrameHelper modal = new FrameHelper(Driver, By.XPath(_frameRecentActivityXPath)))
		//	{
		//		modal.FindElement(By.XPath(@"//button[contains(@id, 'ApprovalModalClose')]"), TimeSpan.FromSeconds(5)).JSClickWithFocus(Driver);
		//	}
		//}

		public void InstantApprovalButtonClick()
		{
			using (FrameHelper modal = new FrameHelper(Driver, By.XPath(_frameRecentActivityXPath)))
			{
				modal.FindElement(By.XPath(@"//input[contains(@id, 'InstantApprovalConfirm')]")).JSClickWithFocus(Driver);
			}
		}

        public bool IsMerchantCategoryCodeSummaryVisible
        {
            get
            {
                if (Driver.TryFindElement(By.XPath(_titleMerchantCategoryCodeSummary), out IWebElement element))
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }

        public bool IsRecentAuthorizationsVisible
		{
			get
			{
				if (Driver.TryFindElement(By.XPath(@"//caption[contains(text(),'Recent Authorizations')]"), out IWebElement element))
				{
					return true;
				}
				else
				{
					return false;
				}
			}
		}

		//public bool IsRecentAuthorizationsVisible
		//{
		//	get
		//	{
		//		using (var helper = new FrameHelper(Driver, By.XPath(_frameRecentActivityXPath)))
		//		{
		//			var element = helper.FindElement(By.XPath(@"//caption[contains(text(),'Recent Authorizations')]"));
		//			return element != null;
		//		}
		//	}
		//}

		public bool IsCorporateLimitPresent
		{
			get
			{
				if (Driver.TryFindElement(By.XPath(authOverrideCorporateLimitXPath), out IWebElement element))
				{
					return element.Displayed;
				}
				else
				{
					return false;
				}
			}
		}

		public int TotalAuthorizations()
		{
			using (FrameHelper modal = new FrameHelper(Driver, By.XPath(_frameRecentActivityXPath)))
			{
				GridControl authGrid = new GridControl("AuthGrid", Driver);
				return authGrid.GetRows().Count();
			}
		}

		public int TotalTransactions()
		{
			using (FrameHelper modal = new FrameHelper(Driver, By.XPath(_frameMCCSummaryXPath)))
			{
                if (modal.FindElement(By.XPath(_dialogDescriptionXPath)).Text.Contains("No transactions"))
					return 0;
				else
				{
					GridControl authGrid = new GridControl("AuthGrid", Driver);
					return authGrid.GetRows().Count();
				}
			}
		}

		public void EditInstantApproval()
		{
			_editInstantApprovalBtn.JSClickWithFocus(Driver);
		}

		public void DeleteInstantApprovalNoModalClose(string messageType, string message)
		{
			using (FrameHelper modal = new FrameHelper(Driver, By.XPath(_frameGenericXPath)))
			{
				modal.FindElement(By.XPath(_modalcmdDeleteInstantApprovalXPath)).JSClickWithFocus(Driver);
				Driver.SwitchTo().ActiveElement();
				modal.FindElement(By.XPath(_modalbtnInstantApprovalDeleteXPath)).JSClickWithFocus(Driver);
				Driver.SwitchTo().ActiveElement();

				string msg = GetResultMessage(messageType);

				Check.That(msg.Equals(message));
			}
		}

		public void CreateInstantApproval(string messageType, string message)
		{
			using (FrameHelper modal = new FrameHelper(Driver, By.XPath(_frameGenericXPath)))
			{
				modal.FindElement(By.XPath(_modalbtnInstantApprovalConfirmXPath), TimeSpan.FromSeconds(10)).JSClickWithFocus(Driver); 

				Driver.AcceptAlert();
				Driver.SwitchTo().ActiveElement();

				string msg = GetResultMessage(messageType);

				Check.That(msg.Equals(message));
			}
		}

		public void DeleteInstantApproval(string messageType, string message)
		{
			using (FrameHelper modal = new FrameHelper(Driver, By.XPath(_frameGenericXPath)))
			{
				modal.FindElement(By.XPath(_modalcmdDeleteInstantApprovalXPath)).JSClickWithFocus(Driver); 
				Driver.SwitchTo().ActiveElement();
				modal.FindElement(By.XPath(_modalbtnInstantApprovalDeleteXPath)).JSClickWithFocus(Driver);
				Driver.SwitchTo().ActiveElement();

				string msg = GetResultMessage(messageType);

				Check.That(msg.Equals(message));
			}

			//CloseModal();
		}

		private string GetResultMessage(string messageType)
		{
			using (FrameHelper modal = new FrameHelper(Driver, By.XPath(_frameGenericXPath)))
			{
				if (messageType.ToLowerInvariant().Equals("success"))
				{
					return modal.FindElement(By.XPath(_modalSuccessMessageXPath)).Text;
				}
				else
				{
					return modal.FindElement(By.XPath(_modalValidationSummaryXPath)).Text;
				}
			}
		}

		/// <summary>
		/// Creating an instance of FrameHelper Class so that we can maintain just 1 instance of it rather than multiple.
		/// </summary>
		public RecentAuthorizationsIFrame GetRecentAuthorizationsIFrame
		{
			get
			{
				using (FrameHelper helper = new FrameHelper(Settings.EnCompassWebDriver, By.XPath(_frameRecentActivityXPath)))
				{
					return new RecentAuthorizationsIFrame(helper, Settings);
				}
			}
		}

		/// <summary>
		/// Separate Class to handle IFrame related Elements Identification. This uses a Singleton instance of FrameHelper class.
		/// </summary>
		public class RecentAuthorizationsIFrame : LastTransactions
		{
			FrameHelper helper;
			public RecentAuthorizationsIFrame(FrameHelper _helper, GlobalSettings settings) : base(settings) { helper = _helper; }


			#region InstantApprovalAmount
			public string InstantApprovalAmount
			{
				get
				{

					{
						if (helper.FindElement(By.XPath(_instantApprovalAmount)) != null)
						{
							return helper.FindElement(By.XPath(_instantApprovalAmount)).Text;
						}
						else
						{
							return "";
						}
					}
				}
				set
				{

					{
						if (helper.FindElement(By.XPath(_instantApprovalAmount)) != null)
						{
							helper.FindElement(By.XPath(_instantApprovalAmount)).Clear();
							helper.FindElement(By.XPath(_instantApprovalAmount)).SendKeys(value);
						}
					}
				}
			}
			#endregion

			#region ApprovalExpiration
			public string ApprovalExpiration
			{
				get
				{

					{
						if (helper.FindElement(By.XPath(_instantApprovalExpiration)) != null)
						{
							return helper.FindElement(By.XPath(_instantApprovalExpiration)).Text;
						}
						else
						{
							return "";
						}
					}
				}
				set
				{

					{
						if (helper.FindElement(By.XPath(_instantApprovalExpiration)) != null)
						{
							helper.FindElement(By.XPath(_instantApprovalExpiration)).Clear();
							helper.FindElement(By.XPath(_instantApprovalExpiration)).SendKeys(value);
						}
					}
				}
			}
			#endregion

			#region NumberOfTxnsAllowed
			public string NumberOfTransactionsAllowed
			{
				get
				{

					{
						if (helper.FindElement(By.XPath(_instantApprovalNumTransAllowed)) != null)
						{
							return helper.FindElement(By.XPath(_instantApprovalNumTransAllowed)).Text;
						}
						else
						{
							return "";
						}
					}
				}
				set
				{

					{
						if (helper.FindElement(By.XPath(_instantApprovalNumTransAllowed)) != null)
						{
							helper.FindElement(By.XPath(_instantApprovalNumTransAllowed)).Clear();
							helper.FindElement(By.XPath(_instantApprovalNumTransAllowed)).SendKeys(value);
						}
					}
				}
			}
			#endregion

			#region SelectAll
			public bool IsSelectAllPresent
			{
				get
				{

					{
						if (helper.FindElement(GetBy(() => this.authOverrideSelectAll)) != null)
						{
							return helper.FindElement(GetBy(() => this.authOverrideSelectAll)).Displayed;
						}
						else
						{
							return false;
						}
					}
				}
			}

			public bool SelectAll
			{
				get
				{

					{
						if (helper.FindElement(GetBy(() => this.authOverrideSelectAll)) != null)
						{
							return helper.FindElement(GetBy(() => this.authOverrideSelectAll)).Selected;
						}
						else
						{
							return false;
						}
					}
				}

				set
				{

					{
						if (helper.FindElement(GetBy(() => this.authOverrideSelectAll)) != null)
						{
							helper.FindElement(GetBy(() => this.authOverrideSelectAll)).SetCheckboxState(value);
						}
					}
				}
			}
			#endregion

			#region CVV
			public bool IsCVVPresent
			{
				get
				{

					{
						if (helper.FindElement(GetBy(() => this.authOverrideCVV)) != null)
						{
							return helper.FindElement(GetBy(() => this.authOverrideCVV)).Displayed;
						}
						else
						{
							return false;
						}
					}
				}
			}

			public bool CVV
			{
				get
				{

					{
						if (helper.FindElement(GetBy(() => this.authOverrideCVV)) != null)
						{
							return helper.FindElement(GetBy(() => this.authOverrideCVV)).Selected;
						}
						else
						{
							return false;
						}
					}
				}

				set
				{

					{
						if (helper.FindElement(GetBy(() => this.authOverrideCVV)) != null)
						{
							helper.FindElement(GetBy(() => this.authOverrideCVV)).SetCheckboxState(value);
						}
					}
				}
			}
			#endregion

			#region CardholderLimit
			public bool IsCardholderLimitPresent
			{
				get
				{

					{
						if (helper.FindElement(GetBy(() => this.authOverrideCardholderLimit)) != null)
						{
							return helper.FindElement(GetBy(() => this.authOverrideCardholderLimit)).Displayed;
						}
						else
						{
							return false;
						}
					}
				}
			}

			public bool CardholderLimit
			{
				get
				{

					{
						if (helper.FindElement(GetBy(() => this.authOverrideCardholderLimit)) != null)
						{
							return helper.FindElement(GetBy(() => this.authOverrideCardholderLimit)).Selected;
						}
						else
						{
							return false;
						}
					}
				}

				set
				{

					{
						if (helper.FindElement(GetBy(() => this.authOverrideCardholderLimit)) != null)
						{
							helper.FindElement(GetBy(() => this.authOverrideCardholderLimit)).SetCheckboxState(value);
						}
					}
				}
			}
			#endregion

			#region ExpirationDate
			public bool IsExpirationDatePresent
			{
				get
				{

					{
						if (helper.FindElement(GetBy(() => this.authOverrideExpirationDate)) != null)
						{
							return helper.FindElement(GetBy(() => this.authOverrideExpirationDate)).Displayed;
						}
						else
						{
							return false;
						}
					}
				}
			}

			public bool ExpirationDate
			{
				get
				{

					{
						if (helper.FindElement(GetBy(() => this.authOverrideExpirationDate)) != null)
						{
							return helper.FindElement(GetBy(() => this.authOverrideExpirationDate)).Selected;
						}
						else
						{
							return false;
						}
					}
				}

				set
				{

					{
						if (helper.FindElement(GetBy(() => this.authOverrideExpirationDate)) != null)
						{
							helper.FindElement(GetBy(() => this.authOverrideExpirationDate)).SetCheckboxState(value);
						}
					}
				}
			}
			#endregion

			#region CV2
			public bool IsCV2Present
			{
				get
				{

					{
						if (helper.FindElement(GetBy(() => this.authOverrideCV2)) != null)
						{
							return helper.FindElement(GetBy(() => this.authOverrideCV2)).Displayed;
						}
						else
						{
							return false;
						}
					}
				}
			}

			public bool CV2
			{
				get
				{

					{
						if (helper.FindElement(GetBy(() => this.authOverrideCV2)) != null)
						{
							return helper.FindElement(GetBy(() => this.authOverrideCV2)).Selected;
						}
						else
						{
							return false;
						}
					}
				}

				set
				{

					{
						if (helper.FindElement(GetBy(() => this.authOverrideCV2)) != null)
						{
							helper.FindElement(GetBy(() => this.authOverrideCV2)).SetCheckboxState(value);
						}
					}
				}
			}
			#endregion

			#region DailyTransactionLimit
			public bool IsDailyTransactionLimitPresent
			{
				get
				{

					{
						if (helper.FindElement(GetBy(() => this.authOverrideDailyTxnLimit)) != null)
						{
							return helper.FindElement(GetBy(() => this.authOverrideDailyTxnLimit)).Displayed;
						}
						else
						{
							return false;
						}
					}
				}
			}

			public bool DailyTransactionLimit
			{
				get
				{

					{
						if (helper.FindElement(GetBy(() => this.authOverrideDailyTxnLimit)) != null)
						{
							return helper.FindElement(GetBy(() => this.authOverrideDailyTxnLimit)).Selected;
						}
						else
						{
							return false;
						}
					}
				}

				set
				{

					{
						if (helper.FindElement(GetBy(() => this.authOverrideDailyTxnLimit)) != null)
						{
							helper.FindElement(GetBy(() => this.authOverrideDailyTxnLimit)).SetCheckboxState(value);
						}
					}
				}
			}
			#endregion

			#region SingleTransactionLimit
			public bool IsSingleTransactionLimitPresent
			{
				get
				{

					{
						if (helper.FindElement(GetBy(() => this.authOverrideSingleTxnLimit)) != null)
						{
							return helper.FindElement(GetBy(() => this.authOverrideSingleTxnLimit)).Displayed;
						}
						else
						{
							return false;
						}
					}
				}
			}

			public bool SingleTransactionLimit
			{
				get
				{

					{
						if (helper.FindElement(GetBy(() => this.authOverrideSingleTxnLimit)) != null)
						{
							return helper.FindElement(GetBy(() => this.authOverrideSingleTxnLimit)).Selected;
						}
						else
						{
							return false;
						}
					}
				}

				set
				{

					{
						if (helper.FindElement(GetBy(() => this.authOverrideSingleTxnLimit)) != null)
						{
							helper.FindElement(GetBy(() => this.authOverrideSingleTxnLimit)).SetCheckboxState(value);
						}
					}
				}
			}
			#endregion

			#region AccountStatus
			public bool IsAccountStatusPresent
			{
				get
				{

					{
						if (helper.FindElement(GetBy(() => this.authOverrideAccountStatus)) != null)
						{
							return helper.FindElement(GetBy(() => this.authOverrideAccountStatus)).Displayed;
						}
						else
						{
							return false;
						}
					}
				}
			}

			public bool AccountStatus
			{
				get
				{

					{
						if (helper.FindElement(GetBy(() => this.authOverrideAccountStatus)) != null)
						{
							return helper.FindElement(GetBy(() => this.authOverrideAccountStatus)).Selected;
						}
						else
						{
							return false;
						}
					}
				}

				set
				{

					{
						if (helper.FindElement(GetBy(() => this.authOverrideAccountStatus)) != null)
						{
							helper.FindElement(GetBy(() => this.authOverrideAccountStatus)).SetCheckboxState(value);
						}
					}
				}
			}
			#endregion

			#region FleetID
			public bool IsFleetIDPresent
			{
				get
				{

					{
						if (helper.FindElement(GetBy(() => this.authOverrideFleetID)) != null)
						{
							return helper.FindElement(GetBy(() => this.authOverrideFleetID)).Displayed;
						}
						else
						{
							return false;
						}
					}
				}
			}

			public bool FleetID
			{
				get
				{

					{
						if (helper.FindElement(GetBy(() => this.authOverrideFleetID)) != null)
						{
							return helper.FindElement(GetBy(() => this.authOverrideFleetID)).Selected;
						}
						else
						{
							return false;
						}
					}
				}

				set
				{

					{
						if (helper.FindElement(GetBy(() => this.authOverrideFleetID)) != null)
						{
							helper.FindElement(GetBy(() => this.authOverrideFleetID)).SetCheckboxState(value);
						}
					}
				}
			}
			#endregion

			#region PIN
			public bool IsPINPresent
			{
				get
				{

					{
						if (helper.FindElement(GetBy(() => this.authOverridePIN)) != null)
						{
							return helper.FindElement(GetBy(() => this.authOverridePIN)).Displayed;
						}
						else
						{
							return false;
						}
					}
				}
			}

			public bool PIN
			{
				get
				{

					{
						if (helper.FindElement(GetBy(() => this.authOverridePIN)) != null)
						{
							return helper.FindElement(GetBy(() => this.authOverridePIN)).Selected;
						}
						else
						{
							return false;
						}
					}
				}

				set
				{

					{
						if (helper.FindElement(GetBy(() => this.authOverridePIN)) != null)
						{
							helper.FindElement(GetBy(() => this.authOverridePIN)).SetCheckboxState(value);
						}
					}
				}
			}
			#endregion

			#region MCC
			public bool IsMCCPresent
			{
				get
				{

					{
						if (helper.FindElement(GetBy(() => this.authOverrideMCC)) != null)
						{
							return helper.FindElement(GetBy(() => this.authOverrideMCC)).Displayed;
						}
						else
						{
							return false;
						}
					}
				}
			}

			public bool MCC
			{
				get
				{

					{
						if (helper.FindElement(GetBy(() => this.authOverrideMCC)) != null)
						{
							return helper.FindElement(GetBy(() => this.authOverrideMCC)).Selected;
						}
						else
						{
							return false;
						}
					}
				}

				set
				{

					{
						if (helper.FindElement(GetBy(() => this.authOverrideMCC)) != null)
						{
							helper.FindElement(GetBy(() => this.authOverrideMCC)).SetCheckboxState(value);
						}
					}
				}
			}
			#endregion

			#region FraudCriteria
			public bool IsFraudCriteriaPresent
			{
				get
				{

					{
						if (helper.FindElement(GetBy(() => this.authOverrideFraudCriteria)) != null)
						{
							return helper.FindElement(GetBy(() => this.authOverrideFraudCriteria)).Displayed;
						}
						else
						{
							return false;
						}
					}
				}
			}

			public bool FraudCriteria
			{
				get
				{

					{
						if (helper.FindElement(GetBy(() => this.authOverrideFraudCriteria)) != null)
						{
							return helper.FindElement(GetBy(() => this.authOverrideFraudCriteria)).Selected;
						}
						else
						{
							return false;
						}
					}
				}

				set
				{

					{
						if (helper.FindElement(GetBy(() => this.authOverrideFraudCriteria)) != null)
						{
							helper.FindElement(GetBy(() => this.authOverrideFraudCriteria)).SetCheckboxState(value);
						}
					}
				}
			}
			#endregion

			#region HierarchyLimit
			public bool IsHierarchyLimitPresent
			{
				get
				{

					{
						if (helper.FindElement(GetBy(() => this.authOverrideHierarchyLimit)) != null)
						{
							return helper.FindElement(GetBy(() => this.authOverrideHierarchyLimit)).Displayed;
						}
						else
						{
							return false;
						}
					}
				}
			}

			public bool HierarchyLimit
			{
				get
				{

					{
						if (helper.FindElement(GetBy(() => this.authOverrideHierarchyLimit)) != null)
						{
							return helper.FindElement(GetBy(() => this.authOverrideHierarchyLimit)).Selected;
						}
						else
						{
							return false;
						}
					}
				}

				set
				{

					{
						if (helper.FindElement(GetBy(() => this.authOverrideHierarchyLimit)) != null)
						{
							helper.FindElement(GetBy(() => this.authOverrideHierarchyLimit)).SetCheckboxState(value);
						}
					}
				}
			}
			#endregion

			#region CorporateLimit
			//public bool IsCorporateLimitPresent
			//{
			//	get
			//	{
			//		{
			//			if (helper.FindElement(By.XPath(authOverrideCorporateLimit), TimeSpan.FromSeconds(5)) != null)
			//			{
			//				return helper.FindElement(By.XPath(authOverrideCorporateLimit), TimeSpan.FromSeconds(5)).Displayed;
			//			}
			//			else
			//			{
			//				return false;
			//			}
			//		}
			//	}
			//}

			public bool CorporateLimit
			{
				get
				{
					{
						if (helper.FindElement(By.XPath(authOverrideCorporateLimitXPath)) != null)
						{
							return helper.FindElement(By.XPath(authOverrideCorporateLimitXPath)).Selected;
						}
						else
						{
							return false;
						}
					}
				}

				set
				{
					{
						if (helper.FindElement(By.XPath(authOverrideCorporateLimitXPath)) != null)
						{
							helper.FindElement(By.XPath(authOverrideCorporateLimitXPath)).SetCheckboxState(value);
						}
					}
				}
			}
			#endregion

			#region CentralBillLimit
			public bool IsCentralBillLimitPresent
			{
				get
				{
					{
						if (helper.FindElement(GetBy(() => this.authOverrideCentralBillLimit)) != null)
						{
							return helper.FindElement(GetBy(() => this.authOverrideCentralBillLimit)).Displayed;
						}
						else
						{
							return false;
						}
					}
				}
			}

			public bool CentralBillLimit
			{
				get
				{
					{
						if (helper.FindElement(GetBy(() => this.authOverrideCentralBillLimit)) != null)
						{
							return helper.FindElement(GetBy(() => this.authOverrideCentralBillLimit)).Selected;
						}
						else
						{
							return false;
						}
					}
				}

				set
				{
					{
						if (helper.FindElement(GetBy(() => this.authOverrideCentralBillLimit)) != null)
						{
							helper.FindElement(GetBy(() => this.authOverrideCentralBillLimit)).SetCheckboxState(value);
						}
					}
				}
			}
			#endregion

			#region Delinquency
			public bool IsDelinquencyPresent
			{
				get
				{

					{
						if (helper.FindElement(GetBy(() => this.authOverrideDelinquency)) != null)
						{
							return helper.FindElement(GetBy(() => this.authOverrideDelinquency)).Displayed;
						}
						else
						{
							return false;
						}
					}
				}
			}

			public bool Delinquency
			{
				get
				{

					{
						if (helper.FindElement(GetBy(() => this.authOverrideDelinquency)) != null)
						{
							return helper.FindElement(GetBy(() => this.authOverrideDelinquency)).Selected;
						}
						else
						{
							return false;
						}
					}
				}

				set
				{

					{
						if (helper.FindElement(GetBy(() => this.authOverrideDelinquency)) != null)
						{
							helper.FindElement(GetBy(() => this.authOverrideDelinquency)).SetCheckboxState(value);
						}
					}
				}
			}
			#endregion
		}
	}
}
