﻿using AventStack.ExtentReports;
using OpenQA.Selenium;
using OpenQA.Selenium.Appium;
using OpenQA.Selenium.Appium.Windows;
using OpenQA.Selenium.Remote;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Common.Utility
{
	public class WinAppDriverHelper
	{
		static WindowsDriver<RemoteWebElement> _winDriver = null;
		static Process process = new Process();
		GlobalSettings _settings;

		public WinAppDriverHelper(GlobalSettings Settings)
		{
			_settings = Settings;
		}

		private static void StartWinAppDriverExe(ExtentTest test)
		{
			string absPathToWinAppDir = PathHelper.GetWinAppDriverAbsolutePath();
			process.StartInfo.FileName = absPathToWinAppDir;
			process.Start();
			test.Info("Started process : " + absPathToWinAppDir);
		}
		
		private static WindowsDriver<RemoteWebElement> createWindowsDriver(ExtentTest test)
		{
            try
            {
                StartWinAppDriverExe(test);
                AppiumOptions options = new AppiumOptions();
                options.AddAdditionalCapability("app", "Root");
                _winDriver = new WindowsDriver<RemoteWebElement>(new Uri("http://127.0.0.1:4723"), options);
                test.Info("Connected to Remote server:http://127.0.0.1:4723");
            }
            catch(Exception e)
            {
                test.Info("Failed to connect remote server:http://127.0.0.1:4723");
            }

            return _winDriver;
		}

		/// <summary>
		/// Returns instance of Windows Driver
		/// </summary>
		public WindowsDriver<RemoteWebElement> GetWindowsDriver(ExtentTest test)
		{
			_winDriver = (_winDriver == null) ? createWindowsDriver(test) : _winDriver;
			_settings.Scenario["WinDriver"] = _winDriver;
			return _winDriver;
		}	

	}
}
