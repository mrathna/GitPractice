﻿using Common;
using Common.Utility;
using NFluent;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EnCompass.Testing.Source.PageObjects.Organization.Admin.TransactionEnvelope
{
	[PageModel(@"/admin/transactionEnvelope/OrgGroupReimbursementSchedule.aspx")]
	public partial class OrgGroupReimbursementSchedule : EnCompassPageModel
	{

		public override string RelativeUrl => @"/admin/transactionEnvelope/OrgGroupReimbursementSchedule.aspx";
		public override string PageIdentifierXPath_Override => @"//li[contains(@class, 'breadcrumb-item active')][text() = 'Out of Pocket Reimbursement Schedule']";

		public OrgGroupReimbursementSchedule(GlobalSettings settings) : base(settings) { }

        #region XPath page Elements

        private const string _scheduledDatesXPath = @"//input[contains(@id,'txtNumberOfScheduledDates')]";
        private const string _toggleScheduledDatesXPath = @"//a[contains(@id, 'toggletxtNumberOfScheduledDates')]";
        private const string _generateTestScheduleBtnXPath = @"//input[contains(@id,'btnSubmit')]";
        #endregion

        #region Page Elements
        private IWebElement _scheduledDates
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_scheduledDatesXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_scheduledDates element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _toggleScheduledDates
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_toggleScheduledDatesXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_toggleScheduledDates element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _generateTestScheduleBtn
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_generateTestScheduleBtnXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_generateTestScheduleBtn element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        #endregion

        public string ScheduledDates
		{
			set
			{
				_toggleScheduledDates.JSClickWithFocus(Driver);
				_scheduledDates.Clear();
				_scheduledDates.SendKeys(value);
			}
		}

		public void GenerateTestScheduleBtn()
		{
			_generateTestScheduleBtn.JSClickWithFocus(Driver);
		}
	}
}
