package com.framework.pages.CHEV;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.ExtentTest;
import com.framework.basepage.BasePage;
import com.framework.repo.Locator;

public class CHOrderCardPage extends BasePage {

	@FindBy(how = How.XPATH, using = Locator.CH_EDIT_CARD_TITLE)
	public WebElement orderCardPageTitle;

	@FindBy(how = How.XPATH, using = Locator.CH_ORDER_CARD_DETAILS_SECTION)
	public WebElement cardDetailsSection;

	@FindBy(how = How.XPATH, using = Locator.CH_VELOCITY_LIMITS_SECTION)
	public WebElement velocityLimitSection;

	@FindBy(how = How.XPATH, using = Locator.CH_ORDER_CARD_DELIVERY_ADDR_SECTION)
	public WebElement cardDeliverySection;

	@FindBy(how = How.XPATH, using = Locator.CARD_OFFER)
	public WebElement cardOffer;
	
	@FindBy(how = How.XPATH, using = Locator.CARD_INFORMATION_DRIVER_NAME )
	public WebElement driverName;
	
	

	@FindBy(how = How.ID, using = Locator.CONTINUE_BUTTON)
	public WebElement orderCard;
	
	@FindBy(how = How.XPATH, using = Locator.CH_CONFIRM_CARD_TITLE)
	public WebElement confirmCardTitle;
	
	@FindBy(how = How.ID, using = Locator.NEWCARD_NUMBER)
	public WebElement cardNumberField;
	
	public CHOrderCardPage(WebDriver driver, ExtentTest test) {
		super(driver, test);
		PageFactory.initElements(driver, this);
	}

	public void verifyOrderCardPageTitle() {
		sleep(3);
		isDisplayed(orderCardPageTitle, "Order a Card");
		logPass("Redirected to the Order a Card Page");
	}

	public void verifyOrderCardSubSections() {
		isDisplayed(cardDetailsSection, "Card Details ");
		isDisplayed(velocityLimitSection, "Velocity Limits ");
		isDisplayed(cardDeliverySection, "Card Delivery ");
	}
	
	public String createANewCard() {
		sleep(5);
		selectDropDownByVisibleText(cardOffer, "StarCard");
		isDisplayedThenEnterText(driverName,"Driver Name","testDriver");
		sleep(5);
		scrollDownPage();
		actionClick(orderCard);
	//	verifyText(confirmCardTitle, "Confirm Card Details");
		actionClick(orderCard);
		sleep(5);
		String cardNumber = cardNumberField.getText().replaceAll("\\s", "");
		return cardNumber;
	}

}
