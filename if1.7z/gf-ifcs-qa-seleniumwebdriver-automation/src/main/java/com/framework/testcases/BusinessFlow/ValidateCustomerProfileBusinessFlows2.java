package com.framework.testcases.BusinessFlow;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.MaintainCustomerPage;
import com.framework.pages.AJS.common.Common;
import com.framework.pages.AJS.common.IFCSHomePage;
import com.framework.pages.AJS.common.IFCSLoginPage;

public class ValidateCustomerProfileBusinessFlows2 extends BaseTest {

	/**
	 * Implemented by Davu * @param clientCountry
	 * 
	 * @param clientName Busienss Flow ID:BF-037
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow" })
	public void createPrivateCustomerPricingProfile(@Optional("BE") String clientCountry,
			@Optional("WFE") String clientName) {

		test = extent.createTest(
				clientName + ":" + clientCountry + "RQ-792 - TC-1728 TC02_CustMgmt_Expire existing_create new Profile",
				"Able to create a private customer pricing  profile");

		// creating object for the Pages
		IFCSLoginPage ifcsloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		MaintainCustomerPage maintainCustomerPage = new MaintainCustomerPage(driver, test);
		Common common = new Common(driver, test);
		// Calling Functions
		ifcsloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		ifcsloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, " ");
		IFCSHomePage.gotoApplicationAndClickApplicationMenu();
		IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);

		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		String customerNumber = common.getActiveCustomerNoUsingCardType();
		common.chooseCustomerNoAndSearch(customerNumber);
		maintainCustomerPage.verifyCustomerPricingProfile();
		maintainCustomerPage.popupForPricingProfiles(clientName, clientCountry, "NewPrivateProfile");//"Lower of Pump & List");
		
		IFCSHomePage.exitIFCS();

	}
	
	/**
	 * Implemented by Davu * @param clientCountry
	 * 
	 * @param clientName
	 *            Busienss Flow ID:BF-036
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow" })
	public void createComplexCustomerPricingProfile(@Optional("BE") String clientCountry,
			@Optional("WFE") String clientName) {

		test = extent.createTest(clientName + ":" + clientCountry + "RQ-790 - TC-998 TC01_CustMgmt_Comp_Pricing Cross border",
				"create complex pricing profiles to support cross border");

		// creating object for the Pages
		IFCSLoginPage ifcsloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		MaintainCustomerPage maintainCustomerPage = new MaintainCustomerPage(driver, test);
		Common common = new Common(driver, test);
		// Calling Functions
		ifcsloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		ifcsloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, " ");
		IFCSHomePage.gotoApplicationAndClickApplicationMenu();
		IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);
		
		
		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		String customerNumber = common.getActiveCustomerNoUsingCardType();
		common.chooseCustomerNoAndSearch(customerNumber);
		maintainCustomerPage.verifyComplexCustomerPricingProfile();
		maintainCustomerPage.popupForComplexPricingProfiles(clientName, clientCountry);
		common.clickSaveIcon();
		common.verifyValidationResult("Record saved OK");
		IFCSHomePage.exitIFCS();
		
		
		
		
	}
	
	/**
	 * Implemented by Davu * @param clientCountry
	 * 
	 * @param clientName Busienss Flow ID:BF-041
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow" })
	public void updateCustomerRebateProfile(@Optional("BE") String clientCountry, @Optional("WFE") String clientName) {

		test = extent.createTest(
				clientName + ":" + clientCountry + "RQ-795 - TC-733 TC03_CustMgmt_Reb_Upd_rebate profile details",
				"Able to update the rebate profile details");

		// creating object for the Pages
		IFCSLoginPage ifcsloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		MaintainCustomerPage maintainCustomerPage = new MaintainCustomerPage(driver, test);
		Common common = new Common(driver, test);
		// Calling Functions
		ifcsloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		ifcsloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, " ");
		// IFCSHomePage.gotoApplicationAndClickApplicationMenu();
		// IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" +
		// clientCountry);

		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		String customerNumber = common.getCustomerNowithPrivateRebate(clientName, clientCountry);
		common.chooseCustomerNoAndSearch(customerNumber);
		maintainCustomerPage.updateRebateProfile();
		IFCSHomePage.exitIFCS();

	}

	/**
	 * Implemented by Davu * @param clientCountry
	 * 
	 * @param clientName Busienss Flow ID:BF-046
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow" })
	public void updateCustomerCardFeeProfile(@Optional("BE") String clientCountry, @Optional("WFE") String clientName) {

		test = extent.createTest(clientName + ":" + clientCountry + "TC-1735 TC06_CustMgmt_Upd_Card fee profiles",
				"Able to update the Monthly card fee profile");

		// creating object for the Pages
		IFCSLoginPage ifcsloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		MaintainCustomerPage maintainCustomerPage = new MaintainCustomerPage(driver, test);
		Common common = new Common(driver, test);
		// Calling Functions
		ifcsloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		ifcsloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, " ");
		// IFCSHomePage.gotoApplicationAndClickApplicationMenu();
		// IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" +
		// clientCountry);

		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		String customerNumber = common.getCustomerNowithPrivateCardFee(clientCountry);
		common.chooseCustomerNoAndSearch(customerNumber);
		maintainCustomerPage.updateCardFeeProfile();
		IFCSHomePage.exitIFCS();

	}

	/**
	 * Implemented by Davu * @param clientCountry
	 * 
	 * @param clientName Busienss Flow ID:BF-039
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow" })
	public void defaultCustomerRebateProfile(@Optional("BE") String clientCountry, @Optional("WFE") String clientName) {

		test = extent.createTest(
				clientName + ":" + clientCountry + " RQ-793 - TC-838 TC01_CustMgmt_Reb_Default Public Rebate Profile",
				"Able to default a public rebate profile");

		// creating object for the Pages
		IFCSLoginPage ifcsloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		MaintainCustomerPage maintainCustomerPage = new MaintainCustomerPage(driver, test);
		Common common = new Common(driver, test);
		// Calling Functions
		ifcsloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		ifcsloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, " ");
		// IFCSHomePage.gotoApplicationAndClickApplicationMenu();
		// IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" +
		// clientCountry);

		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		String customerNumber = common.getCustomerNowithPrivateRebate(clientName, clientCountry);
		common.chooseCustomerNoAndSearch(customerNumber);
		maintainCustomerPage.optInOutRebateProfile();
		IFCSHomePage.exitIFCS();

	}

}
