package com.framework.repo;

public class Locator_SalesForce {

	public static final String SALESFORCE_USERNAME = "//input[contains(@id,'username')]";
	public static final String SALESFORCE_PASSWORD = "//input[contains(@id,'password')]";
	public static final String SALESFORCE_LOGIN = "//input[contains(@id,'Login')]";
	public static final String SALESFORCE_ACCOUNTS = "//div//one-app-nav-bar-item-root[3]//a//span[contains(text(),'Accounts')]";
	public static final String SALESFORCE_SELECTED_VIEW ="//div[@class='triggerLinkTextAndIconWrapper slds-p-right--x-large']//span[@class='triggerLinkText selectedListView uiOutputText']";
	public static final String SALESFORCE_VIEWS_SEARCH ="//div//input[@class='slds-input default input uiInput uiInputTextForAutocomplete uiInput--default uiInput--input']";
	public static final String SALESFORCE_ALL_ACCOUNTS_VIEW ="//div[@class='listContent']//div//div//ul//li//a//span//mark[contains(text(), 'All accounts')]";
	public static final String SALESFORCE_SEARCH_TYPE ="//input[@id='input-5']";
	public static final String SALESFORCE_SEARCH_LIST_OPTION = "//input[@aria-activedescendant='input-5-0-5']";
	public static final String SALESFORCE_GLOBAL_SEARCH ="//input[@id='173:0;p']";
	public static final String SALESFORCE_SEARCH = "//div[@class='slds-icon_container']/lightning-icon";
	public static final String SALESFORCE_SEARCH_RESULT_ACCOUNT_NO = "//div//table//tbody//tr//td[2]//span//span";
	public static final String SALESFORCE_SEARCH_RESULT_ACCOUNT_STATUS = "//div//table//tbody//tr//td[3]//span//span";
	public static final String SALESFORCE_SEARCH_RESULT_ROW = "//th[@scope='row']";
	public static final String ACCOUNT_CARDS_QUICK_LINK = "//span[@title='Cards']";
	public static final String ACCOUNT_NUMBER ="//p[@title='Customer Number']/following::p[1]//lightning-formatted-text";
	public static final String CARD_HEADER_TITLE ="//h1[@title='Cards']";
	public static final String FILTER_SEARCH="//button[@title='Show quick filters']";
	public static final String FILTER_SEARCH_CARD_NUMBER="//lightning-input[descendant::label[text()='Card Number']]//input";
	public static final String FILTER_SEARCH_APPLY="//button[@title='Apply']";
	public static final String USER_PROFILE_ICON="//span[@data-aura-class='forceSocialPhoto']";
	public static final String LOGOUT_SALESFORCE="//div[@class='profile-card-toplinks']//a[contains(@href,'logout')]";
	public static final String TOOLTIP_FIRST_RESULT ="//li[contains(@class,'lookup__item ')][2]";
	public static final String SHOW_ALL ="//flexipage-aura-wrapper//div[@class='showPreview forceRelatedListQuickLinksContainer']//a[descendant::span[contains(text(),'Related List Quick Links')]]";
	public static final String ACCNT_ADDRESS ="//flexipage-aura-wrapper//div[@class='showPreview forceRelatedListQuickLinksContainer']//a[descendant::span[contains(text(),'Account Addresses Functionality')]]";

	//raxsana 
	public static final String SALESFORCE_ACCOUNT_NAME="//td//span[@class='slds-truncate uiOutputText']//preceding::span[@class='slds-grid slds-grid--align-spread']/a";
	public static final String SF_RELATED_TAB="//div[@class='slds-tabs_default']//li/a[contains(text(),'Related')]";
	public static final String SF_ACCOUNT_ADDRESSES_MENU="//div//span[@title='Account Addresses Functionality']";
	public static final String SALESFORCE_USER="//div/span[@class='uiImage']/img[@title='User']";
	public static final String SALESFORCE_LOGOUT="profile-link-label logout uiOutputURL";
	
	//public static final String SALESFORCE_SEARCH = "//input[contains(@title,'Search')]";
	public static final String SALESFORCE_SEARCHITEM = "//div[@class='listContent']/ul/li[1]";
	public static final String SALESFORCE_ACCOUNT_NUMBER = "//span[text()='Customer Number']/following::slot/lightning-formatted-text";
	public static final String SALESFORCE_BILLING_PLAN = "//span[text()='Billing Plan']/following::slot/lightning-formatted-text";
	
	public static final String SALESFORCE_ACCOUNTS_TABLE = "//table[contains(@class,' uiVirtualDataTable')]";
	public static final String SALESFORCE_SEARCH_AUTOCOMPLETE="//div[contains(@class,'uiAbstractList uiAutocompleteList')]";

	public static final String SALESFORCE_SEARCH_RESULT_CARD_NO = "//div/div/table/tbody/tr/th/span/a";
	public static final String SALESFORCE_SEARCH_RESULT_CARD_STATUS ="//div[@id='brandBand_2']//div//div//div[5]/div//div[2]//div//div//div//div//div//table//tbody//tr//td[6]//span//span";
	public static final String SALESFORCE_TRANSACTIONS="//span[@id='window']";
	public static final String SALESFORCE_FILTER="//body/div[4]/div[1]/section[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/div[1]/div[3]/div[1]/div[1]/div[1]/div[2]/div[2]/force-list-view-manager-button-bar[1]/div[1]/lightning-button-group[1]/slot[1]/lightning-button-icon-stateful[1]/button[1]/lightning-primitive-icon[1]";
    public static final String SALAESFORCE_STARTDATE="//*[@id=\"input-6424\"]";
    public static final String SALESFORCE_APPLY="/html/body/div[4]/div[1]/section/div[1]/div[2]/div[2]/div[1]/div/div/div/div[4]/div/div/div[2]/div/div[2]/lst-quick-filter-panel/form/div[3]/span/lightning-button/button";
    public static final String SALESFORCE_ENDDATE="//*[@id=\"input-118\"]";
}

