package com.framework.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

public class PropUtils {

	/*****************************************************************************
	 * Name : getPropFile Description : Gives the Relative path of Properties
	 * file, which is used as Object repository Input Content : name and path of
	 * the properties file
	 *****************************************************************************/
	public static File getPropFile(final String FILE_PATH, final String FILE_NAME) {
		// Returns the Properties File
		return new File(FILE_PATH, FILE_NAME);
	}

	/*****************************************************************************
	 * Name : getProps Description : Reads the Properties file Input Content :
	 * Instance of the properties file
	 *****************************************************************************/
	public static Properties getProps(final File file) {
		Properties properties = null;
		try {

			properties = new Properties();
			// Reading the properties file
			properties.load(new FileInputStream(file));
		} catch (FileNotFoundException fileNotFoundException) {
			System.err.println(fileNotFoundException);
		} catch (IOException ioException) {
			System.err.println(ioException);
		}
		return properties;
	}
	/*****************************************************************************
	 * Name : getProps Description : Reads the Properties file Input Content :
	 * Return : as Map
	 *****************************************************************************/
	public static Map<String,String> getPropsAsMap(final File file) {
		Properties properties = null;
		Map<String,String> values=new HashMap<String, String>();
		try {

			properties = new Properties();
			// Reading the properties file
			properties.load(new FileInputStream(file));
			Set<Object> set = properties.keySet();
			for (Object obj : set) {
				//System.out.println("CArds:"+obj.toString());
				if(!properties.getProperty(obj.toString()).contains("null")) {
				values.put(obj.toString(), properties.getProperty(obj.toString()));
				}
			}
			
			
		} catch (FileNotFoundException fileNotFoundException) {
			System.err.println(fileNotFoundException);
		} catch (IOException ioException) {
			System.err.println(ioException);
		}
		return values;
	}

	/*****************************************************************************
	 * Name : getPropValue Description : Returns the the Property value
	 * depending on the key Input Content : Properties Object, key of the
	 * required property
	 *****************************************************************************/
	public static String getPropValue(Properties properties, String key) {
		// Returning the Property value depends on Key
		return properties.getProperty(key);
	}

	/*****************************************************************************
	 * Name : setProps Description : Set the properties Instance Input Content :
	 * Properties Object
	 *****************************************************************************/
	public static void setProps(Properties properties, String key, String value) {
		// Setting the Properties Object
		properties.setProperty(key, value);
	}

	/*****************************************************************************
	 * Name : clearProps Description : Clearing the properties Instance Input
	 * Content : Properties Object
	 *****************************************************************************/
	public static void clearProps(Properties properties) {
		// Clearing the Properties Object
		properties.clear();
	}
	/*public static void setProps(String key, String value, String filePath) {
		PropertiesConfiguration props = null;
		try {
		props = new PropertiesConfiguration(filePath);
		props.setProperty(key,value);
		props.save();
		} catch (ConfigurationException ex) {
		ex.printStackTrace();
		}
		}

	*/

	
	/*****************************************************************************
	 * Name : creatingTempPropFile Description : Creating temporary property file
	 * Content : File name and contents with key, value pair
	 *****************************************************************************/
	public static void creatingTempPropFile(String fileName,Map<String,String> cardNos) {
		// Clearing the Properties Object
		OutputStream fos = null;
	    Properties prop = new Properties();

	    try {
	        fos = new FileOutputStream(Constants.CONFIG_DIR+fileName);
	        prop.putAll(cardNos);
	        prop.store(fos, "Dynamic Property File");
	    } catch (IOException e) {
	        e.printStackTrace();
	    }
	}
	
	/*public static void creatingTempPropFile(String fileName, Map<String, String> Data) {

		Properties prop = new Properties();  
		OutputStream output = null;
		try {
		        prop.putAll(Data);
		        output = new FileOutputStream(Constants.CONFIG_DIR + fileName +".properties");
		        prop.store(output, "Dynamic Property File for API");

		} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		}
		} */

}
