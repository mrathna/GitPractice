package com.framework.testcases.OLS.BP.Customer;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.BP.BPHomePage;
import com.framework.pages.BP.BPRecurringReportPage;
import com.framework.pages.OLS.HomePage;
import com.framework.pages.OLS.common.LoginPage;

public class ValidateReportsForDifferentAccounts extends BaseTest {
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "Regression" })
	public void validateReportsForAccountNotInContext(@Optional("AU") String clientCountry,
			@Optional("BP") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  Verify the Reports For Account Not In Context",
				"Verify the Reports For Account Not In Context");
	
		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		HomePage homePage = new HomePage(driver, test);
		BPHomePage bpHomePage = new BPHomePage(driver, test);
		BPRecurringReportPage bpRecurringReportPage = new BPRecurringReportPage(driver, test);

		// Calling Functions
		loginPage.Login("BP_URL", "BP_UN_Customer_" + clientCountry, "BP_PWD_Customer_" + clientCountry, clientName);
		bpHomePage.ValidateBPCustomerLogo();
		bpHomePage.ValidateCustomerWelcomeText();
		homePage.ValidateLogoutLink();
		homePage.ValidateHelpLink();
		bpRecurringReportPage.validateTheNavOfPastReportsSubMenu();
		
		boolean noRecurringReport = bpRecurringReportPage.checkRecurringReportPresentorNot();
		if(!noRecurringReport)
		{
			bpRecurringReportPage.selectAllAccountsFromDropown("Different");
			bpRecurringReportPage.validateThePastReportsPageButton();
		}
		loginPage.Logout();

	}

	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "Regression" })
	public void verifyReportsForMultipleAccounts(@Optional("AU") String clientCountry,
			@Optional("BP") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  Verify the Reports For Multiple Accounts",
				"Verify the Reports For Multiple Accounts");
		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		HomePage homePage = new HomePage(driver, test);
		BPHomePage bpHomePage = new BPHomePage(driver, test);
		BPRecurringReportPage bpRecurringReportPage = new BPRecurringReportPage(driver, test);
		// BPAccountDetailsPage bpAccDetailsPage = new BPAccountDetailsPage(driver,
		// test);
		// Calling Functions
		loginPage.Login("BP_URL", "BP_UN_Customer_" + clientCountry, "BP_PWD_Customer_" + clientCountry, clientName);
		bpHomePage.ValidateBPCustomerLogo();
		bpHomePage.ValidateCustomerWelcomeText();
		homePage.ValidateLogoutLink();
		homePage.ValidateHelpLink();
		bpRecurringReportPage.validateTheNavOfPastReportsSubMenu();
		bpRecurringReportPage.selectAllAccountsFromDropown("Same");		
		loginPage.Logout();
	}

	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "Regression" })
	public void verifyReportsForMultipleAccountsNotInContext(@Optional("AU") String clientCountry,
			@Optional("BP") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  Verify the Reports For Multiple Accounts Not In Context",
				"Verify theReports For Multiple Accounts Not In Context");
		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		HomePage homePage = new HomePage(driver, test);
		BPHomePage bpHomePage = new BPHomePage(driver, test);
		BPRecurringReportPage bpRecurringReportPage = new BPRecurringReportPage(driver, test);

		// Calling Functions
		loginPage.Login("BP_URL", "BP_UN_Customer_" + clientCountry, "BP_PWD_Customer_" + clientCountry, clientName);
		bpHomePage.ValidateBPCustomerLogo();
		bpHomePage.ValidateCustomerWelcomeText();
		homePage.ValidateLogoutLink();
		homePage.ValidateHelpLink();
		bpRecurringReportPage.validateTheNavOfPastReportsSubMenu();
		boolean noRecurringReport = bpRecurringReportPage.checkRecurringReportPresentorNot();
		if(!noRecurringReport)
		{
			bpRecurringReportPage.selectAllAccountsFromDropown("Different");
			bpRecurringReportPage.validateThePastReportsPageButton();
		}
		loginPage.Logout();

	}

}
