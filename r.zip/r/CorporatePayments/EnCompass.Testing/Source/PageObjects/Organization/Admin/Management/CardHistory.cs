﻿using Common;
using Common.Utility;
using NFluent;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EnCompass.Testing.Source.PageObjects.Organization.Admin.Management
{
    [PageModel(@"/admin/management/HierarchyHistory.aspx")]
    class CardHistory : EnCompassOrgPageModel
    {

        public override string RelativeUrl => @"/admin/management/HierarchyHistory.aspx";
        public override string PageIdentifierXPath_Override => @"//h1[text()='History']";

        #region XPath page Elements

        private const string _cardHistoryBtnXPath = @"//button[@role='tab'][contains(@id,'CardsHistory')]";
        private const string _cardHistoryRowXPath = @"//table[contains(@id,'manageCardsChanges')]//tbody//tr[not(contains(@class,'gridPager'))]";
        private const string _hierarchyHistoryRowXPath = @"//table//tbody//tr[not(contains(@class,'gridPager'))][1]";
        private const string _historyExportBtnXPath = @"//input[contains(@id,'manageHierarchiesChanges_rowButtons_btnExportGridText')]";
        #endregion

        #region Page Elements
        private IWebElement _cardHistoryBtn
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_cardHistoryBtnXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_cardHistoryBtn element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _cardHistoryRow
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_cardHistoryRowXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_cardHistoryRow element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _hierarchyHistoryRow
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_hierarchyHistoryRowXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_hierarchyHistoryRow element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _historyExportBtn
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_historyExportBtnXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_historyExportBtn element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        #endregion

        public void ClickCardHistoryBtn()
        {
            _cardHistoryBtn.JSClickWithFocus(Driver);
            Settings.EnCompassExtentTest.Info("Clicked card history button");
        }

        public void ValidateCardHistoryValues()
        {
            _cardHistoryRow.WaitUntilElementIsInteractable();
            //Verify user name
            Check.That(Settings.EnCompassWebDriver.FindElement(By.XPath(_cardHistoryRowXPath + "//td[2]")).Text).Contains(Settings.Scenario["carduser"].ToString());
            Settings.EnCompassExtentTest.Info("Verified user name");
            //Verify cards source hierarchy name            
            Check.That(Settings.EnCompassWebDriver.FindElement(By.XPath(_cardHistoryRowXPath + "//td[3]")).Text.Trim()).Contains(Settings.Scenario["SourceHierarchy"].ToString());
            Settings.EnCompassExtentTest.Info("Verified source hierarchy name");
            //Verify cards destination hierarchy name
            Check.That(Settings.EnCompassWebDriver.FindElement(By.XPath(_cardHistoryRowXPath + "//td[4]")).Text.Trim()).Contains(Settings.Scenario["DestinationHierarchy"].ToString());
            Settings.EnCompassExtentTest.Info("Verified destination hierarchy name");
            //Verify Amount transter status
            Check.That(Settings.EnCompassWebDriver.FindElement(By.XPath(_cardHistoryRowXPath + "//td[5]")).Text).Contains("True");
            Settings.EnCompassExtentTest.Info("Verified amount transfer status");
            //Verify moved card number
            Check.That(Settings.EnCompassWebDriver.FindElement(By.XPath(_cardHistoryRowXPath + "//td[6]")).Text.Trim()).Contains(Settings.Scenario["firstCardNumber"].ToString());
            Settings.EnCompassExtentTest.Info("Verified card number");
            this.AttachOnDemandScreenShot();
        }
        
        public void ValidateHierarchyHistoryValues()
        {
            _hierarchyHistoryRow.WaitUntilElementIsInteractable();
            //Verify user name
            Check.That(Settings.EnCompassWebDriver.FindElement(By.XPath(_hierarchyHistoryRowXPath + "//td[2]")).Text.Trim()).Contains(Settings.Scenario["carduser"].ToString());
            Settings.EnCompassExtentTest.Info("Verified user name");
            //Verify updated field         
            Check.That(Settings.EnCompassWebDriver.FindElement(By.XPath(_hierarchyHistoryRowXPath + "//td[3]")).Text.Trim()).Contains("Hierarchy name");
            Settings.EnCompassExtentTest.Info("Verified updated field");
            //Verify Action name
            Check.That(Settings.EnCompassWebDriver.FindElement(By.XPath(_hierarchyHistoryRowXPath + "//td[4]")).Text.Trim()).Contains("Renamed");
            Settings.EnCompassExtentTest.Info("Verified Action name");
            //Verify Previous Hierarchy Name
            Check.That(Settings.EnCompassWebDriver.FindElement(By.XPath(_hierarchyHistoryRowXPath + "//td[5]")).Text).Contains(Settings.Scenario["hierarchyName"].ToString());
            Settings.EnCompassExtentTest.Info("Verified previous hierarchy name");
            //Verify new Hierarchy Name
            Check.That(Settings.EnCompassWebDriver.FindElement(By.XPath(_hierarchyHistoryRowXPath + "//td[6]")).Text).Contains(Settings.Scenario["updatedHierarchy"].ToString());
            Settings.EnCompassExtentTest.Info("Verified new hierarchy name");
            this.AttachOnDemandScreenShot();
        }

        public void ClickExportBtn()
        {
            _historyExportBtn.JSClickWithFocus(Driver);
            Settings.EnCompassExtentTest.Info("Clicked export button");
        }

        public CardHistory(GlobalSettings settings) : base(settings) { }

    }
}
