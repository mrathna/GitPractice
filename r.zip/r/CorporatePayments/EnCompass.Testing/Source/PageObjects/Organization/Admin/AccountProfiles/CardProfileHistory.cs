﻿using Common;
using Common.Utility;
using EnCompass.Testing.Source.PageObjects.Controls;
using NFluent;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Support.UI;
using System;

namespace EnCompass.Testing.Source.PageObjects.Organization.Admin.AccountProfiles
{
    [PageModel(@"/admin/accountProfiles/cardProfileHistory.aspx")]
    public class CardProfileHistory : EnCompassOrgPageModel
    {
        public override string RelativeUrl => @"/admin/accountProfiles/cardProfileHistory.aspx";
        public override string PageIdentifierXPath_Override => @"//h1[contains(@id,'title')]";

        #region XPath page Elements

        private const string _exportXPath = @"(//input[contains(@id,'btnExportGridText')])[2]";
        private const string _changeDetailsXPath = @"//a[contains(@id,'actionLink0')]";
        private const string _tableChangesXPath = "//table[contains(@id, 'dgRealTimeChanges')]";
        private const string _backButtonXPath = @"//input[contains(@id,'backButton')]";
        #endregion

        #region Page Elements
        private IWebElement _export
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_exportXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Info("Found _export");
                return element;
            }
        }

		private IWebElement _changeDetails
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_changeDetailsXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Info("Found _changeDetails");
                return element;
            }
        }

        private IWebElement _back
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_backButtonXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Info("Found _back");
                return element;
            }
        }
        #endregion

        public void PressExport()
		{
			_export.JSClickWithFocus(Driver);
		}

		public void PressChangeDetails()
		{
			_changeDetails.JSClickWithFocus(Driver);
			Settings.EnCompassWebDriver.WaitForVisible(By.XPath(_tableChangesXPath));
		}

		public void PressBack()
		{
			_back.JSClickWithFocus(Driver);
		}

		private GridControl _mGrid;
		public GridControl CardProfileHistoryGrid
		{
			get
			{
				GridControl grid = _mGrid ?? (_mGrid = new GridControl("dgHistory", Driver));
				grid.WaitForGrid();
				return grid;
			}
		}

		public CardProfileHistory(GlobalSettings settings) : base(settings) { }
    }
}