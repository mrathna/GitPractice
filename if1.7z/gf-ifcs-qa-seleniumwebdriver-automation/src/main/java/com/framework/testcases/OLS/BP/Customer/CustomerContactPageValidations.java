package com.framework.testcases.OLS.BP.Customer;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.BP.BPAccountPage;
import com.framework.pages.BP.BPHomePage;
import com.framework.pages.OLS.common.BPCommonPage;
import com.framework.pages.OLS.common.LoginPage;
import com.framework.pages.OLS.common.ViewAndEditContactsPage;

//Added By Nithya 30-04-2018
/*Updated by Anton for ClientName 15.05.2018*/
public class CustomerContactPageValidations extends BaseTest {
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "Smoke", "Regression","BusinessFlow" })
	public void Add_And_Edit_A_Contact_In_Customer(@Optional("AU") String clientCountry,
			@Optional("BP") String clientName) throws Exception {
		test = extent.createTest(clientName+ ":" +clientCountry+"  BP Contact Page Validation", "Validate Add/Edit/Delete Contacts");
		LoginPage loginPage = new LoginPage(driver, test);
		BPHomePage bpHomePage = new BPHomePage(driver, test);
		if(clientName.equals("BP")) {
			loginPage.Login("BP_URL", "BP_UN_Customer_" + clientCountry, "BP_PWD_Customer_" + clientCountry, clientName);
		} else {
			loginPage.Login("BPPREPAID_URL", "BPPREPAID_UN_Customer_" + clientCountry, "BPPREPAID_PWD_Customer_" + clientCountry, clientName);
		}

		bpHomePage.ValidateBPCustomerLogo();
		BPAccountPage BPaccountPage = new BPAccountPage(driver, test);
		BPCommonPage bpCommonPage = new BPCommonPage(driver, test);
		ViewAndEditContactsPage BPviewAndEditContactPage = new ViewAndEditContactsPage(driver, test);

		// Call Function
		bpHomePage.ValidateBPCustomerLogo();

		// Choose a Account
		bpCommonPage.selectAccount();

		// ADD CONTACT
		// Select Account Details link
		bpHomePage.clickAccountDetailsLink();

		// Navigate to View And Edit Contact Link
		BPaccountPage.clickViewAndEditContactLink();
		BPviewAndEditContactPage.getContactsAlreadyHave("Customer");

		// Add a Contact for type Card Delivery - //Updated By Nithya 03-05-2018
		BPviewAndEditContactPage.clickAddContactButton("Customer");
		BPviewAndEditContactPage.validateAddContactPage();

		// Select Contact Type and enter contact details
		BPviewAndEditContactPage.chooseUniqueContactType("Customer");
		BPviewAndEditContactPage.setContactAsDefault();
		BPviewAndEditContactPage.enterContactInformationDetails();
		BPviewAndEditContactPage.enterContactAddressDetails(clientCountry, "Customer");

		// Save and Check Confirmation Msg
		BPviewAndEditContactPage.saveContactDetails("Customer");

		// EDIT CONTACT
		// Select Account Details link
		bpHomePage.clickAccountDetailsLink();

		// Navigate to View And Edit Contact Link
		BPaccountPage.clickViewAndEditContactLink();

		// Select a Contact
		BPviewAndEditContactPage.selectAContactFromListOfContact();

		// Edit Contact
		BPviewAndEditContactPage.editContactPhoneAndAddress(clientCountry);

		// Save
		BPviewAndEditContactPage.saveContactDetails("Customer");

		// Choose a Account
		bpCommonPage.selectAccount();

		// CHECK EXPORT
		// Select Account Details link
		bpHomePage.clickAccountDetailsLink();

		// Navigate to View And Edit Contact Link
		BPaccountPage.clickViewAndEditContactLink();

		// Export Contacts
		BPviewAndEditContactPage.checkAvailabiltyOfExportContact();

		// DELETE CONTACT
		// Select Account Details link
		bpHomePage.clickAccountDetailsLink();

		// Navigate to View And Edit Contact Link
		BPaccountPage.clickViewAndEditContactLink();

		// Select a Contact and Delete
		BPviewAndEditContactPage.selectAContactFromListOfContact();
		//BPviewAndEditContactPage.deleteAContact();
		
		//Return to List of Contacts
		bpHomePage.clickAccountDetailsLink();
		BPaccountPage.clickViewAndEditContactLink();
		BPviewAndEditContactPage.selectAContactFromListOfContact();
		BPviewAndEditContactPage.clickDeleteAndClickCancelInConfirmation();

		loginPage.Logout();

	}
}
