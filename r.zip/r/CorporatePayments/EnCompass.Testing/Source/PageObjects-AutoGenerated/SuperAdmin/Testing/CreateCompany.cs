using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using Common;
using Common.PageObjects;
using Common.ScenarioConfigurations;
using Common.Utility;

namespace EnCompass.Testing.Source.PageObjects.SuperAdmin.Testing 
{
	/// <summary>
	/// Auto-generated Page Model Class
	/// Navigation Paths: 
		/// [Organization Home]->General->Testing->Create Test Company
		/// </summary>
	[PageModel(@"/superAdmin/testing/CreateCompany.aspx")]
	public partial class CreateCompany : EnCompassSuperPageModel 
	{
		public override string RelativeUrl => @"/superAdmin/testing/CreateCompany.aspx";
		public override string PageIdentifierXPath_Generated => @"//li[contains(@class, 'breadcrumb-item active')][text() = 'Create Test Company']";

		#region Navigation
				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Create Organization']")]
		private IWebElement _general_Testing_CreateTestCompany_CreateOrganization { get; set; }
		public void NavigateTo_General_Testing_CreateTestCompany_CreateOrganization()
		{
			NavigateToMenuItem(_general_Testing_CreateTestCompany_CreateOrganization);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Create Organization Profile']")]
		private IWebElement _general_Testing_CreateTestCompany_CreateOrganizationProfile { get; set; }
		public void NavigateTo_General_Testing_CreateTestCompany_CreateOrganizationProfile()
		{
			NavigateToMenuItem(_general_Testing_CreateTestCompany_CreateOrganizationProfile);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Delete Test Organization']")]
		private IWebElement _general_Testing_CreateTestCompany_DeleteTestOrganization { get; set; }
		public void NavigateTo_General_Testing_CreateTestCompany_DeleteTestOrganization()
		{
			NavigateToMenuItem(_general_Testing_CreateTestCompany_DeleteTestOrganization);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Create Test Company']")]
		private IWebElement _general_Testing_CreateTestCompany_CreateTestCompany { get; set; }
		public void NavigateTo_General_Testing_CreateTestCompany_CreateTestCompany()
		{
			NavigateToMenuItem(_general_Testing_CreateTestCompany_CreateTestCompany);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Corporate Credit Limit']")]
		private IWebElement _general_Testing_CreateTestCompany_CorporateCreditLimit { get; set; }
		public void NavigateTo_General_Testing_CreateTestCompany_CorporateCreditLimit()
		{
			NavigateToMenuItem(_general_Testing_CreateTestCompany_CorporateCreditLimit);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Create Bounce Notification']")]
		private IWebElement _general_Testing_CreateTestCompany_CreateBounceNotification { get; set; }
		public void NavigateTo_General_Testing_CreateTestCompany_CreateBounceNotification()
		{
			NavigateToMenuItem(_general_Testing_CreateTestCompany_CreateBounceNotification);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Reset Merchant Log Error']")]
		private IWebElement _general_Testing_CreateTestCompany_ResetMerchantLogError { get; set; }
		public void NavigateTo_General_Testing_CreateTestCompany_ResetMerchantLogError()
		{
			NavigateToMenuItem(_general_Testing_CreateTestCompany_ResetMerchantLogError);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Performance']")]
		private IWebElement _general_Testing_CreateTestCompany_Performance { get; set; }
		public void NavigateTo_General_Testing_CreateTestCompany_Performance()
		{
			NavigateToMenuItem(_general_Testing_CreateTestCompany_Performance);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='AP Non-Card Payments Testing']")]
		private IWebElement _general_Testing_CreateTestCompany_ApNonCardPaymentsTesting { get; set; }
		public void NavigateTo_General_Testing_CreateTestCompany_ApNonCardPaymentsTesting()
		{
			NavigateToMenuItem(_general_Testing_CreateTestCompany_ApNonCardPaymentsTesting);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Modify Merchant Log']")]
		private IWebElement _general_Testing_CreateTestCompany_ModifyMerchantLog { get; set; }
		public void NavigateTo_General_Testing_CreateTestCompany_ModifyMerchantLog()
		{
			NavigateToMenuItem(_general_Testing_CreateTestCompany_ModifyMerchantLog);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Test Templates']")]
		private IWebElement _general_Testing_CreateTestCompany_TestTemplates { get; set; }
		public void NavigateTo_General_Testing_CreateTestCompany_TestTemplates()
		{
			NavigateToMenuItem(_general_Testing_CreateTestCompany_TestTemplates);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Create Test Statements']")]
		private IWebElement _general_Testing_CreateTestCompany_CreateTestStatements { get; set; }
		public void NavigateTo_General_Testing_CreateTestCompany_CreateTestStatements()
		{
			NavigateToMenuItem(_general_Testing_CreateTestCompany_CreateTestStatements);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Contact Us']")]
		private IWebElement _general_Testing_CreateTestCompany_ContactUs { get; set; }
		public void NavigateTo_General_Testing_CreateTestCompany_ContactUs()
		{
			NavigateToMenuItem(_general_Testing_CreateTestCompany_ContactUs);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Dispute Transaction']")]
		private IWebElement _general_Testing_CreateTestCompany_DisputeTransaction { get; set; }
		public void NavigateTo_General_Testing_CreateTestCompany_DisputeTransaction()
		{
			NavigateToMenuItem(_general_Testing_CreateTestCompany_DisputeTransaction);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Terms and Conditions']")]
		private IWebElement _general_Testing_CreateTestCompany_TermsAndConditions { get; set; }
		public void NavigateTo_General_Testing_CreateTestCompany_TermsAndConditions()
		{
			NavigateToMenuItem(_general_Testing_CreateTestCompany_TermsAndConditions);
		}

		
		private void NavigateToMenuItem(IWebElement element)
		{
			Driver.Url = element.GetAttribute("href");
		}
		#endregion

		public CreateCompany(GlobalSettings settings) : base(settings) { }
	}  
}
