package com.framework.testcases.AJS.EMAP;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.ApplicationsPage;
import com.framework.pages.AJS.CardMaintenancePage;
import com.framework.pages.AJS.MaintainCustomerPage;
import com.framework.pages.AJS.common.Common;
import com.framework.pages.AJS.common.IFCSHomePage;
import com.framework.pages.AJS.common.IFCSLoginPage;
import com.github.javafaker.Faker;

public class ValidateMaintainCustomerTestCases extends BaseTest {
	
	@Parameters({ "clientCountry", "clientName" }) 
	@Test( groups = { "Regression" })
	public void validateMaintainCustomerAddACostCentre(@Optional("SG") String clientCountry,
			@Optional("EMAP") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  IFCS Add and Delete Cost Centre", "TST-SC-60-Maintain Customer - Add and delete Cost Centre");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
	    MaintainCustomerPage maintainCustomerPage = new MaintainCustomerPage(driver, test);
	    Common common= new Common(driver, test);
		IFCSloginPage.login("IFCS_URL_EMAP", "IFCS_EMAP_USERNAME", "IFCS_EMAP_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, " ");

		
			// Add a Cost Centre
			IFCSHomePage.gotoApplicationAndClickApplicationMenu();
			IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);
			IFCSHomePage.gotoCustomerMenuCustomerDetails();
			common.chooseCustomerNumberFromCustomerList();
			maintainCustomerPage.addAndDeleteCostCentreFromCustomer();
		    IFCSHomePage.exitIFCS();
	}
	
		@Parameters({ "clientCountry", "clientName" }) 
	@Test( groups = { "Regression" })
	public void validateMaintainCustomerAddAndDeleteContacts(@Optional("SG") String clientCountry,
			@Optional("EMAP") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  EMAP IFCS Add and Delete Contacts", "TST-SC-59-Maintain Customer- Add and Delete Contacts");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
	    MaintainCustomerPage maintainCustomerPage = new MaintainCustomerPage(driver, test);
	    Common common= new Common(driver, test);
		IFCSloginPage.login("IFCS_URL_EMAP", "IFCS_EMAP_USERNAME", "IFCS_EMAP_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, " ");

		
			// Add a Cost Centre
			IFCSHomePage.gotoApplicationAndClickApplicationMenu();
			IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);
			IFCSHomePage.gotoCustomerMenuCustomerDetails();
			common.chooseCustomerNumberFromCustomerList();
			maintainCustomerPage.validateAddAndDeleteContacts();
			
		    IFCSHomePage.exitIFCS();
	}
	
	@Parameters({ "clientCountry", "clientName" }) 
	@Test( groups = { "Regression" },enabled=false)
	public void validateMaintainCustomerAddAndDeleteNotes(@Optional("SG") String clientCountry,
			@Optional("EMAP") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  EMAP IFCS Add and Delete Notes", "TST-SC-57-Maintain Customer -   Notes - Add - Delete a Note");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
	    MaintainCustomerPage maintainCustomerPage = new MaintainCustomerPage(driver, test);
	    Common common= new Common(driver, test);
		IFCSloginPage.login("IFCS_URL_EMAP", "IFCS_EMAP_USERNAME", "IFCS_EMAP_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, " ");

		
			// Add a Cost Centre
			IFCSHomePage.gotoApplicationAndClickApplicationMenu();
			IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);
			IFCSHomePage.gotoCustomerMenuCustomerDetails();
			common.chooseCustomerNumberFromCustomerList();
			maintainCustomerPage.validateAddAndDeleteNotes();
		    IFCSHomePage.exitIFCS();
	}
	
	@Parameters({ "clientCountry", "clientName"})
	@Test(groups = { "Regression" })
	public void validateMaximumCardExpiryDate(@Optional("SG") String clientCountry,
	@Optional("EMAP") String clientName) {

	test = extent.createTest(clientName+ ":" +clientCountry+"  02 Maintain Customer - Set Maximum Card Expiry Date,Set Maximum Card Expiry Date");

	// creating object for the Pages
	IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
	IFCSHomePage ifcsHomePage = new IFCSHomePage(driver, test);

	ApplicationsPage applicationsPage = new ApplicationsPage(driver, test);
	Common common = new Common(driver, test);
	MaintainCustomerPage maintainCustomerPage=new MaintainCustomerPage(driver,test);

	IFCSloginPage.login("IFCS_URL_EMAP", "IFCS_EMAP_USERNAME", "IFCS_EMAP_PASSWORD");
	IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry," ");
	ifcsHomePage.gotoApplicationAndClickApplicationMenu();

	ifcsHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);
	//
	applicationsPage.applicationFilterOptions(clientCountry+ " General", "TL APP approved");
	common.selectFirstRowNumberInSearchList();
		// Go to Customer Details 
	ifcsHomePage.gotoCustomerMenuCustomerDetails();

	maintainCustomerPage.verifyCardControlProfile();

	maintainCustomerPage.verifyMaximumCardExpiryDate(clientName,clientCountry);

	ifcsHomePage.exitIFCS();
	}
	
	
	/**
	 * Implemented by Rathna
	 * 
	 * @param clientCountry
	 * @param clientName
	 *         
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "BusinessFlow" })
	public void createMoreThanOneCostCentreInIFCS(@Optional("HK") String clientCountry,
			@Optional("EMAP") String clientName) {

		test = extent.createTest(clientName + ":" + clientCountry + " TC-794 TC02_CustMgmt_CostCentre_CardDep_Add_more_CC",
				"RQ:878 - Able to add more than one cost center");
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		MaintainCustomerPage maintainCustomerPage = new MaintainCustomerPage(driver, test);
		Common common = new Common(driver, test);

		IFCSloginPage.login("IFCS_URL_EMAP", "IFCS_EMAP_USERNAME", "IFCS_EMAP_PASSWORD");

		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");

		// getting Active Customer No from DB/
		String customerNumberUsingCardType = common.getActiveCustomerNoUsingCardType();
		if (customerNumberUsingCardType.equals(" ")) {
			common.logForNoDataFound(this.getClass().getSimpleName(),
					"Need to Create A Customer with Card Type and rerun");
		} else {

			for (int count = 1; count <= 2; count++) {
				IFCSHomePage.gotoCustomerMenuCustomerDetails();
				common.chooseCustomerNoAndSearch(customerNumberUsingCardType);
				maintainCustomerPage.chooseCostCentre();
				String costCenterCode = Faker.instance().number().digits(4);
				maintainCustomerPage.addCostCentreAndValidate(costCenterCode);
			}

		}
		IFCSHomePage.exitIFCS();

	}
	
	/**
	 * Implemented by Rathna
	 * 
	 * @param clientCountry
	 * @param clientName
	 *            Business Flow ID:BF-077
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "BusinessFlow" })
	public void createCostCentreInIFCS(@Optional("HK") String clientCountry, @Optional("EMAP") String clientName) {

		test = extent.createTest(clientName + ":" + clientCountry + " ID:BF-077 Create Cost Center",
				"Able to create cost centre in IFCS");
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		MaintainCustomerPage maintainCustomerPage = new MaintainCustomerPage(driver, test);
		Common common = new Common(driver, test);

		IFCSloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");

		// getting Active Customer No from DB/
		String customerNumberUsingCardType = common.getActiveCustomerNoUsingCardType();
		if (customerNumberUsingCardType.equals(" ")) {
			common.logForNoDataFound(this.getClass().getSimpleName(),
					"Need to Create A Customer with Card Type and rerun");
		} else {
			// Add a Cost Centre
			IFCSHomePage.gotoCustomerMenuCustomerDetails();
			common.chooseCustomerNoAndSearch(customerNumberUsingCardType);
			maintainCustomerPage.chooseCostCentre();
			String costCenterCode = Faker.instance().number().digits(4);
			maintainCustomerPage.addCostCentreAndValidate(costCenterCode);

		}
		IFCSHomePage.exitIFCS();

	}
	
	
	/**
	 * Implemented by Rathna
	 * 
	 * @param clientCountry
	 * @param clientName
	 *            
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "BusinessFlow" })
	public void updateExistingCardWithCostCentre(@Optional("HK") String clientCountry,
			@Optional("EMAP") String clientName) {

		test = extent.createTest(clientName + ":" + clientCountry + " TC-795 TC03_CustMgmt_CostCentre_ExtCard_Department_Upd",
				"RQ-788:Update the cost centre details");
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		MaintainCustomerPage maintainCustomerPage = new MaintainCustomerPage(driver, test);
		CardMaintenancePage cardMaintenancePage = new CardMaintenancePage(driver, test);
		Common common = new Common(driver, test);

		IFCSloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");

		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");

		// getting Card No from DB/
		String cardNo = common.getCardNumberhavingNoCostCentreFromDB();
		String costCenterCode = Faker.instance().number().digits(4);
		if (cardNo.equals(" ")) {
			common.logForNoDataFound(this.getClass().getSimpleName(),
					"Need to Create A Customer with Card Type and rerun");
		} else {

			IFCSHomePage.gotoCustomerMenuCustomerDetails();
			cardMaintenancePage.chooseAndSearchCardNo(cardNo);
			maintainCustomerPage.chooseCostCentre();
			maintainCustomerPage.addCostCentreAndValidate(costCenterCode);
		}

		cardMaintenancePage.chooseAndSearchCardNo(cardNo);
		cardMaintenancePage.updateCostCentreForCard(costCenterCode);
		IFCSHomePage.exitIFCS();

	}

	
}
