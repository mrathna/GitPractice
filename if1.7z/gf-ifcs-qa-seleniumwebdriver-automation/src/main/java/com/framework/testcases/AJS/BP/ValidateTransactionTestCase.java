package com.framework.testcases.AJS.BP;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.CardMaintenancePage;
import com.framework.pages.AJS.MaintainCustomerPage;
import com.framework.pages.AJS.common.Common;
import com.framework.pages.AJS.common.IFCSHomePage;
import com.framework.pages.AJS.common.IFCSLoginPage;
import com.framework.pages.BP.BPHomePage;
import com.framework.pages.OLS.common.FindAndExportTransactionPage;
import com.framework.pages.OLS.common.LoginPage;

/**
 * @author smanikandan
 *
 */
public class ValidateTransactionTestCase extends BaseTest{
	
	//Sasi
	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test(groups = {"Regression"})
	public void validateOnlineCustomerTransactionSearch(@Optional("AU") String clientCountry,
			@Optional("BP") String clientName)
	{
		test = extent.createTest(clientName+ ":" +clientCountry+"  Onl_AU_001_Online customer transaction search,Onl_NZ_001_Online customer transaction search", "Search transactions for customers");
		
		String accountNo ="";
		String transactionDate ="";
		int reportFoundCountOLS=0;
		int reportFoundCountIFCS=0;
		//creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);

		Common common=new Common(driver,test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		
		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		BPHomePage bpHomePage = new BPHomePage(driver, test);
		FindAndExportTransactionPage findAndExportTransactions = new FindAndExportTransactionPage(driver, test);
		MaintainCustomerPage maintainCustomerPage = new MaintainCustomerPage(driver, test);
		CardMaintenancePage cardMaintenancePage = new CardMaintenancePage(driver, test);
		
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
			
		// Calling Functions for Login
		loginPage.Login("BP_URL", "BP_UN_Customer_" + clientCountry, "BP_PWD_Customer_" + clientCountry, clientName);

		bpHomePage.ValidateBPCustomerLogo();

		bpHomePage.loadFindAndExportTransactionsPage();

		findAndExportTransactions.clickSearchTransactions();
		
		if (findAndExportTransactions.isTransactionFound()) {
		    accountNo = findAndExportTransactions.gettingAccountNoFromSearchTableResults();
			
			transactionDate = findAndExportTransactions.gettingDateFromSearchTableResults();
			
			findAndExportTransactions.clickExportTransaction();
			
			reportFoundCountOLS = findAndExportTransactions.totalResultsFound();
			
			System.out.println("reportFoundCountOLS : "+reportFoundCountOLS);
		

		IFCSloginPage.login("IFCS_URL_BP", "IFCS_BP_USERNAME", "IFCS_BP_PASSWORD");
		
		IFCSHomePage.gotoApplicationAndClickApplicationMenu();
		
		IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);
		
		IFCSHomePage.gotoCustomerMenuCustomerDetails();
				
		cardMaintenancePage.chooseAndSearchCustomerNo(accountNo);
		
		common.chooseSubMenuFromLeftPanel("Customer Transactions","Transactions");
		
		common.clickDetailSearchIfFilterFieldsNotPresent();
			
		common.enterValueInTextBox("Transaction Filter Fields", "Process Date From", transactionDate);
		
		common.searchListTorch();
		
		reportFoundCountIFCS = common.totalRowsCount();
		
		if(reportFoundCountIFCS==reportFoundCountOLS) {
			common.logPassWhenDataFound(this.getClass().getSimpleName(), "Both reports counts in OLS and IFCS are same");
		}else {
			common.logForNoDataFound(this.getClass().getSimpleName(), "Both reports counts in OLS and IFCS are different");
		}

		maintainCustomerPage.exportReports();

		}
		else
			common.logForNoDataFound(this.getClass().getSimpleName(), "Need to add Accounts having transactions");
	
		IFCSHomePage.exitIFCS();

	}
	

}
