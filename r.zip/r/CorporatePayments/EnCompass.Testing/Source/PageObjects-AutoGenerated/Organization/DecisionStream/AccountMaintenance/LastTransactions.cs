using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using Common;
using Common.PageObjects;
using Common.ScenarioConfigurations;
using Common.Utility;

namespace EnCompass.Testing.Source.PageObjects.Organization.DecisionStream.AccountMaintenance 
{
	/// <summary>
	/// Auto-generated Page Model Class
	/// Navigation Paths: 
		/// [Organization Home]->Cards->Recent Activity
		/// </summary>
	[PageModel(@"/decisionStream/accountMaintenance/lastTransactions.aspx")]
	public partial class LastTransactions : EnCompassOrgPageModel 
	{
		public override string RelativeUrl => @"/decisionStream/accountMaintenance/lastTransactions.aspx";
		public override string PageIdentifierXPath_Generated => @"//li[contains(@class, 'breadcrumb-item active')][text() = 'Recent Activity']";

		#region Navigation
		
		private void NavigateToMenuItem(IWebElement element)
		{
			Driver.Url = element.GetAttribute("href");
		}
		#endregion

		public LastTransactions(GlobalSettings settings) : base(settings) { }
	}  
}
