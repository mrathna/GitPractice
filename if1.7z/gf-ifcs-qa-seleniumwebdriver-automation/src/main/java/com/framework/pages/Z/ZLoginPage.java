package com.framework.pages.Z;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.ExtentTest;
import com.framework.basepage.BasePage;
import com.framework.pages.OLS.common.LoginPage;
import com.framework.repo.Locator;

public class ZLoginPage extends BasePage {

	
	@FindBy(how = How.ID, using = Locator.REQUEST_LOGON)
	public WebElement requestALogon;
	@FindBy(how = How.ID, using = Locator.REQUEST_LOGON_TYPE_CUSTOMER)
	public WebElement requestLogonTypeCustomer;

	@FindBy(how = How.ID, using = Locator.REQUEST_LOGON_ADDRESS)
	public WebElement requestLogonAddress;

	@FindBy(how = How.ID, using = Locator.REQUEST_LOGON_SUBURB)
	public WebElement requestLogonSuburb;

	@FindBy(how = How.ID, using = Locator.REQUEST_LOGON_POSTAL_CODE)
	public WebElement requestLogonPostalCode;

	@FindBy(how = How.ID, using = Locator.REQUEST_LOGON_FIRST_NAME)
	public WebElement requestLogonFirstName;

	@FindBy(how = How.ID, using = Locator.REQUEST_LOGON_LAST_NAME)
	public WebElement requestLogonLastName;

	@FindBy(how = How.ID, using = Locator.REQUEST_LOGON_EMAIL)
	public WebElement requestLogonEmail;

	@FindBy(how = How.ID, using = Locator.REQUEST_LOGON_PHONE)
	public WebElement requestLogonPhone;

	@FindBy(how = How.ID, using = Locator.REQUEST_LOGON_SUBMIT)
	public WebElement requestLogonSubmit;

	@FindBy(how = How.ID, using = Locator.REQUEST_LOGON_ACCOUNT_NUMBER)
	public WebElement requestLogonAccountNumber;
	
	@FindBy(how = How.XPATH, using = Locator.CLIENT_LOGO_IMG)
	public WebElement clientLogo;
	
	@FindBy(how = How.ID, using = Locator.Z_CUSTOMER_NAME)
	public WebElement customerName;	
	
	@FindBy(how = How.ID, using = Locator.CONTACT_US)
	public WebElement contactUs;	
	
	@FindBy(how = How.ID, using = Locator.CONTACT_US_QUERY_SUBMIT)
	public WebElement contactUsSubmit;
	
	@FindBy(how = How.ID, using = Locator.CONTACT_ACC_NUM_TB)
	public WebElement contactUsAccountNumber;
	
	@FindBy(how = How.ID, using = Locator.CONTACT_ACC_NAME_TB)
	public WebElement contactUsAccountName;
	
	@FindBy(how = How.ID, using = Locator.CH_ENQUIRY_TYPE_DROP_DOWN)
	public WebElement contactUsEnquiryTypeDropDown;
	
	@FindBy(how = How.ID, using = Locator.CH_COMMENTS_DROP_DOWN)
	public WebElement contactUsCommentsfield;
	
	@FindBy(how = How.ID, using = Locator.CH_CONTACT_NAME)
	public WebElement contactUsContactName;
	
	@FindBy(how = How.ID, using = Locator.CH_PHONE_NO)
	public WebElement contactUsPhoneNo;
	
	@FindBy(how = How.ID, using = Locator.CH_EMAIL)
	public WebElement contactUsEmail;
	
	@FindBy(how = How.ID, using = Locator.FORGOT_PASSWORD)
	public WebElement forgotPassword;
	
	@FindBy(how = How.XPATH, using = Locator.PAGE_TITLE1)
	public WebElement accountPageTitle;
	
	@FindBy(how = How.XPATH, using = Locator.USER_ID_INPUT)
	public WebElement userIdInput;
	
	@FindBy(how = How.ID, using = Locator.USERID_SUBMIT_FOR_FORGOT_PASSWORD)
	public WebElement submitUserId;
	
	@FindBy(how = How.ID, using = Locator.CONFIRMATIONMESSAGE)
	public WebElement successMessage;
	
	@FindBy(how = How.ID, using = Locator.SIGNIN)
	public WebElement logIN;
	
	@FindBy(how = How.ID, using = Locator.USERNAME)
	public WebElement userName;
	
	
	
	
	
	String firstName, lastName, parentWindow;
	 LoginPage loginPage = new LoginPage(driver, test);

	public ZLoginPage(WebDriver driver, ExtentTest test) {

		super(driver, test);
		PageFactory.initElements(driver, this);

	}
	// Added on 10/01/2019
		public void clickRequestALogonAndValidateTitle() {
		parentWindow = clickAndSwitchToNewWindow(requestALogon);
		sleep(5);
		
		//verifyRequestALogonTitleText();
	}
		public void enterRequestLogonDetails(String validAccountNumber) {
			isDisplayedThenEnterText(customerName, "Request a logon Contact Name", fakerAPI().name().firstName());
			isDisplayedThenEnterText(requestLogonAccountNumber, "Request a logon account number", validAccountNumber);
			sleep(5);
			isDisplayedThenEnterText(requestLogonAddress, "Request a logon address", fakerAPI().address().streetName());
			// APAC_AUTO - Suburb field missing
			try {
				if (requestLogonSuburb.isDisplayed()) {
					isDisplayedThenEnterText(requestLogonSuburb, "Request a logon suburb", fakerAPI().address().cityName());
				}
			} catch (Exception ex) {
				logInfo("Suburb field not present");
			}
			isDisplayedThenEnterText(requestLogonPostalCode, "Request a logon postal code", fakerAPI().address().zipCode());
			firstName = fakerAPI().address().firstName();
			isDisplayedThenEnterText(requestLogonFirstName, "Request a logon first name", firstName);
			lastName = fakerAPI().address().lastName();
			isDisplayedThenEnterText(requestLogonLastName, "Request a logon last name", lastName);
			isDisplayedThenEnterText(requestLogonEmail, "Request a logon email", fakerAPI().internet().emailAddress());
			isDisplayedThenEnterText(requestLogonPhone, "Request a logon phone", fakerAPI().phoneNumber().cellPhone());
		}
		
		public void validateClientLogo() {
			isDisplayed(clientLogo, "Client logo");
		}
		
		public void clickRequestLogonSubmitWithEmptyFieldAndValidate() {
			isDisplayedThenClick(requestLogonSubmit, "Submit request a logon form");
			sleep(5);
//			Removed as per requirement
//			checkTextInPageAndValidate("The recipient address for \"Request A Logon\" screen do not have a valid email set up.", 20);
			checkTextInPageAndValidate("Customer Name  must not be blank.", 20);
			checkTextInPageAndValidate("Account Number  must not be blank.", 20);
		}
		
		public void validateRequestALogoFieldsPresence() {
			checkTextInPageAndValidate("Account Details", 20);
			checkTextInPageAndValidate("Customer Name", 20);
			checkTextInPageAndValidate("Account Number", 20);
			checkTextInPageAndValidate("Business Address", 20);
			checkTextInPageAndValidate("Address", 20);
			checkTextInPageAndValidate("Town/City", 20);
			checkTextInPageAndValidate("Post Code", 20);
			checkTextInPageAndValidate("Country", 20);
			checkTextInPageAndValidate("Contact Details", 20);
			checkTextInPageAndValidate("Job Title", 20);
			checkTextInPageAndValidate("First Name", 20);
			checkTextInPageAndValidate("Last Name", 20);
			checkTextInPageAndValidate("Email", 20);
			checkTextInPageAndValidate("Phone", 20);
		}
		
		public void clickRequestALogonSubmit() {
			isDisplayedThenClick(requestLogonSubmit, "Submit request a logon form");
			sleep(5);
		}
		
		public void clickContactUsAndValidateTitle() {
			parentWindow = clickAndSwitchToNewWindow(contactUs);
			sleep(3);
			checkTextInPageAndValidate("Contact Us", 20);

		}
		
		public void clickSubmitWithEmptyFieldAndValidate() {
			isDisplayedThenClick(contactUsSubmit, "Submit ContactUs form");
			sleep(3);
			checkTextInPageAndValidate("Validation failed", 20);
			checkTextInPageAndValidate("Enquiry Type  must not be blank.", 20);
			checkTextInPageAndValidate("Comments  must not be blank.", 20);
			checkTextInPageAndValidate("Contact Name  must not be blank.", 20);
			checkTextInPageAndValidate("Phone Number  must not be blank.", 20);
			checkTextInPageAndValidate("Email  must not be blank.", 20);
		}
		
		public void validateContactUsFieldsPresence() {
			checkTextInPageAndValidate("Account Number", 20);
			checkTextInPageAndValidate("Account Name", 20);
			checkTextInPageAndValidate("Enquiry Type", 20);
			checkTextInPageAndValidate("Comments", 20);
			checkTextInPageAndValidate("Contact Name", 20);
			checkTextInPageAndValidate("Phone Number", 20);
			checkTextInPageAndValidate("Email", 20);
			checkTextInPageAndValidate("Contact Preference", 20);
			
		}
		
		public void enterContactUsDetails() {
			isDisplayedThenEnterText(contactUsAccountNumber, "contactUs AccountNumber", fakerAPI().number().digits(10));
			isDisplayedThenEnterText(contactUsAccountName, "contactUs AccountName", fakerAPI().name().firstName());
			sleep(5);
			selectDropDownByIndex(contactUsEnquiryTypeDropDown, 1);
			
			firstName = fakerAPI().address().firstName();
			isDisplayedThenEnterText(contactUsContactName, "Request a logon first name", firstName);
			lastName = fakerAPI().address().lastName();
			isDisplayedThenEnterText(contactUsCommentsfield, "Request a logon last name", lastName);
			sleep(3);
			isDisplayedThenEnterText(contactUsEmail, "Request a logon email", fakerAPI().internet().emailAddress());
			sleep(3);
			isDisplayedThenEnterText(contactUsPhoneNo, "Request a logon phone", fakerAPI().phoneNumber().cellPhone());
		}
		
		public void clickContactUsSubmit() {
			isDisplayedThenClick(contactUsSubmit, "Submit ContactUs form");
			sleep(3);
		}
		
		public void clickForgotPasswordAndValidateTitle() {
			clickAndSwitchToNewWindow(forgotPassword);
			verifyForgotPasswordTitleText();
		}
		
		public void verifyForgotPasswordTitleText() {
			if (!(getText(accountPageTitle).equals("Forgotten Password"))) {
				logFail("Expected forgot password page title was not present");
			}
		}
		
		public void enterForgotPasswordUserId() {
			isDisplayedThenEnterText(userIdInput, "User Id", "testfp");
			sleep(1);
		}
		
		public void clickSubmitInForgotPassword() {
			isDisplayedThenClick(submitUserId, "Submit User Id");
		}
		
		public void verifyTheSuccessMessage() {
			if (getText(successMessage).equals("Password has been sent")) {
				logPass("New password sent message was present");
			} else {
				logFail("New password sent message was not present");
			}
		}
		
		public void clickLogInButtonWithEmptyFieldsAndValidate() {
			isDisplayedThenActionClick(logIN, "LogIn Button");
			loginPage.validateErrorMessage("Validation failed User ID: must not be blank.");
			//checkTextInPageAndValidate("Invalid logon attempt", 20);
		}
		
		public void validateInvalidUserID() {
			isDisplayedThenEnterText(userName, "User Name", fakerAPI().name().firstName());
			isDisplayedThenActionClick(logIN, "LogIn Button");
			checkTextInPageAndValidate("Invalid online user ID", 20);
			
			
		}


}
