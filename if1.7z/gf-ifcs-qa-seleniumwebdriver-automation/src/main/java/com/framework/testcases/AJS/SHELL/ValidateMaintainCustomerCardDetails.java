package com.framework.testcases.AJS.SHELL;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.MaintainCustomerPage;
import com.framework.pages.AJS.common.Common;
import com.framework.pages.AJS.common.IFCSHomePage;
import com.framework.pages.AJS.common.IFCSLoginPage;
/**
 * Implemented by Nithya Manikandan
 **/
public class ValidateMaintainCustomerCardDetails extends BaseTest { 

	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test( groups = { "Regression" })
	public void validateMaintainCustomerCardDetailsCards(@Optional("RU") String clientCountry, 
			@Optional("SHELL") String clientName, @Optional("APA") String cardType) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  Maintain Customer - Card Details - Cards", "Cards"); 

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test); 
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		
		MaintainCustomerPage customerPage = new MaintainCustomerPage(driver, test);

		IFCSloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, cardType);
		Common common = new Common(driver, test);
		IFCSHomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);

		// Get Customer having card from DB with Client
		String customerWithCards = customerPage.getCustomerNoHavingCardsUsingCardType();
		if (customerWithCards.equals(" ")) {
			common.logForNoDataFound(this.getClass().getSimpleName(), "Need to Create A Customer With Cards and rerun");
		} else {

		IFCSHomePage.gotoCustomerMenuCustomerDetails();

		customerPage.chooseCustomerNoAndSearch(customerWithCards);

		customerPage.moveToCardsInCustomerMaintanence();

		// Blank Search
		customerPage.performBlankSearchAndValidate();

		// Get data from DB for customer card search
		customerPage.getDataForSearch(customerWithCards);

		// Driver Name Search
		customerPage.customerMaintenanceSearchAndValidation("Driver Name", "Full", "Cards");

		// Card Number Search
		customerPage.customerMaintenanceSearchAndValidation("Card Number", "Full", "Cards");

		// Cost Center Search
		customerPage.customerMaintenanceSearchAndValidation("Cost Centre", "Full", "Cards");

		// Partial Driver Name Search
		customerPage.customerMaintenanceSearchAndValidation("Driver Name", "Partial", "Cards");

		// Partial Card Number Search
		customerPage.customerMaintenanceSearchAndValidation("Card Number", "Partial", "Cards");

		// Partial Cost Center Search
		customerPage.customerMaintenanceSearchAndValidation("Cost Centre", "Partial", "Cards");

		// VRN Search
		customerPage.customerMaintenanceSearchAndValidation("VRN", "Full", "Cards");

		// Partial VRN Search
		customerPage.customerMaintenanceSearchAndValidation("VRN", "Partial", "Cards");

		// Cost Center and Partial Driver Name - Query update
		// customerPage.searchCostCenterAndPartialDriverName();

		// Driver Name that doesn't exist
		customerPage.searchWithInCorrectValue("Name");

		}
		// LogOut
		IFCSHomePage.exitIFCS();

	}

	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test( groups = { "Regression" })
	public void validateMaintainCustomerCardDetailsVehicles(@Optional("RU") String clientCountry,
			@Optional("SHELL") String clientName, @Optional("APA") String cardType) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  Maintain Customer - Card Details - Vehicles", "Vehicles");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		
		MaintainCustomerPage customerPage = new MaintainCustomerPage(driver, test);

		IFCSloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, cardType);
		Common common = new Common(driver, test);
		IFCSHomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);

		// Get Customer having card from DB with Client
		String customerWithCards = customerPage.getCustomerNoHavingCardsWithVehicleDetailsUsingCardType();
		if (customerWithCards.equals(" ")) {
			common.logForNoDataFound(this.getClass().getSimpleName(), "Need to Create A Customer With Cards and rerun");
		} else {

		IFCSHomePage.gotoCustomerMenuCustomerDetails();

		customerPage.chooseCustomerNoAndSearch(customerWithCards);

		customerPage.moveToVehiclesInCustomerMaintanence();

		// Blank Search
		customerPage.performBlankSearchAndValidate();

		// Get data from DB for customer card search
		customerPage.getDataForSearch(customerWithCards);

		// Card Number Search
		customerPage.customerMaintenanceSearchAndValidation("Card Number", "Full", "Vehicles");

		// Partial Card Number Search
		customerPage.customerMaintenanceSearchAndValidation("Card Number", "Partial", "Vehicles");

		// Vehicle Description Search
		customerPage.customerMaintenanceSearchAndValidation("Description", "Full", "Vehicles");

		// Partial Vehicle Description Search
		customerPage.customerMaintenanceSearchAndValidation("Description", "Partial", "Vehicles");

		// Vehicle ID Search
		customerPage.customerMaintenanceSearchAndValidation("Vehicle ID", "Full", "Vehicles");

		// Partial Vehicle ID Search
		customerPage.customerMaintenanceSearchAndValidation("Vehicle ID", "Partial", "Vehicles");

		// Status Search
		customerPage.searchStatusAndValidate();

		// Status and partial VRN Search -  - Query update
		//customerPage.searchPartialVRNAndStatus();

		// Verify Card Popup
		customerPage.selectACardAndVeifyContext("Vehicle");

		// Vehicle description that doesn't exist
		customerPage.searchWithInCorrectValue("Description");

		// VRN Search
		customerPage.customerMaintenanceSearchAndValidation("VRN", "Full", "Vehicles");

		// Partial VRN Search
		customerPage.customerMaintenanceSearchAndValidation("VRN", "Partial", "Vehicles");

		}
		// LogOut
		IFCSHomePage.exitIFCS();

	}

	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test( groups = { "Regression" })
	public void validateMaintainCustomerCardDetailsDrivers(@Optional("RU") String clientCountry,
			@Optional("SHELL") String clientName, @Optional("APA") String cardType) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  Maintain Customer - Card Details - Drivers", "Drivers");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		Common common = new Common(driver, test);
		MaintainCustomerPage customerPage = new MaintainCustomerPage(driver, test);

		IFCSloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, cardType);

		IFCSHomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);

		// Get Customer having card from DB with Client
		String customerWithCards = customerPage.getCustomerNoHavingCardsUsingCardType();
		if (customerWithCards.equals(" ")) {
			common.logForNoDataFound(this.getClass().getSimpleName(), "Need to Create A Customer With Cards and rerun");
		} else {

		IFCSHomePage.gotoCustomerMenuCustomerDetails();

		customerPage.chooseCustomerNoAndSearch(customerWithCards);

		customerPage.moveToDriversInCustomerMaintanence(); 

		// Blank Search
		customerPage.performBlankSearchAndValidate();

		// Get data from DB for customer card search
		customerPage.getDataForSearch(customerWithCards);

		// Card Number Search
		customerPage.customerMaintenanceSearchAndValidation("Card Number", "Full", "Drivers");

		// Partial Card Number Search
		customerPage.customerMaintenanceSearchAndValidation("Card Number", "Partial", "Drivers");

		// Driver Name Search
		customerPage.customerMaintenanceSearchAndValidation("Driver Name", "Full", "Drivers");

		// Partial Driver Name Search
		customerPage.customerMaintenanceSearchAndValidation("Driver Name", "Partial", "Drivers");

		// Driver ID Search
		customerPage.customerMaintenanceSearchAndValidation("Driver Id", "Full", "Drivers");

		// Partial Driver ID Search
		customerPage.customerMaintenanceSearchAndValidation("Driver Id", "Partial", "Drivers");

		// Status Search
		customerPage.searchStatusAndValidate();

		// Status and Partial Driver name - Query update
		// customerPage.searchPartialDriverNameAndStatus();

		// Verify Card Popup
		customerPage.selectACardAndVeifyContext("Driver");

		// Driver Name that doesn't exist
		customerPage.searchWithInCorrectValue("Driver Name");

		}
		// LogOut
		IFCSHomePage.exitIFCS();

	}
	
}
