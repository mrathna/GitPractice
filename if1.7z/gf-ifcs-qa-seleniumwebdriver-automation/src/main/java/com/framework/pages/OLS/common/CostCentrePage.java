package com.framework.pages.OLS.common;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.ExtentTest;
import com.framework.basepage.BasePage;
import com.framework.repo.Locator;

public class CostCentrePage extends BasePage {

	String costCentreName;
	@FindBy(how = How.XPATH, using = Locator.CREATE_NEW_COST_CENTRE_HEADER)
	public WebElement createNewCostCentreHeader;
	@FindBy(how = How.ID, using = Locator.COST_CENTRE_FIELD)
	public WebElement costCentreField;
	@FindBy(how = How.ID, using = Locator.DESCRIPTION_COMMON)
	public WebElement costCentreDescrpitionField;
	@FindBy(how = How.ID, using = Locator.COST_CENTRE_SHORT_DESC_FIELD)
	public WebElement costCentreShortDescriptionField;
	@FindBy(how = How.ID, using = Locator.CREATE_COST_CENTRE_BUTTON)
	public WebElement createCostCentreButton;
	@FindBy(how = How.CSS, using = Locator.CREATE_SUCCESS_MESSAGE)
	public WebElement createCostCentreSuccessMsg;
	@FindBy(how = How.ID, using = Locator.RETURN_TO_COST_CENTRE_BUTTON)
	public WebElement returnToCostCentreButton;
	@FindBy(how = How.ID, using = Locator.SAVE_CHANGES_BUTTON)
	public WebElement saveChangesBtn;

	public CostCentrePage(WebDriver driver, ExtentTest test) {
		super(driver, test);
		PageFactory.initElements(driver, this);
	}

	public void validateCreateNewCostCentreHeader() {
		isDisplayed(createNewCostCentreHeader, "New Cost Center Header");
	}

	public String enterCostCentreName() {
		costCentreName = fakerAPI().name().firstName();
		sleep(1);
		isDisplayedThenEnterText(costCentreField, "Cost Center", costCentreName);
		return costCentreName;
	}

	public void enterCostCentreDescription() {
		isDisplayedThenEnterText(costCentreDescrpitionField, "Cost Center Description", fakerAPI().name().name());
		// if (costCentreDescrpitionField.isDisplayed()) {
		// actionClick(costCentreDescrpitionField);
		// costCentreDescrpitionField.sendKeys(FakerAPI().name().name());
		// logPass("Cost Centre Description field is Displayed");
		// } else {
		// logFail("Cost Centre Description field is Not Displayed");
		// }
	}

	public String getCostCentreDescription() {
		String costCentreDescription = costCentreDescrpitionField.getText();
		return costCentreDescription;
	}

	public void enterCostCentreShortDescription() {
		isDisplayedThenEnterText(costCentreShortDescriptionField, "Cost Short Center Description",
				fakerAPI().name().name());
		// if (costCentreShortDescriptionField.isDisplayed()) {
		// actionClick(costCentreShortDescriptionField);
		// costCentreShortDescriptionField.sendKeys(FakerAPI().name().name());
		// logPass("Cost Centre short description field is Displayed");
		// } else {
		// logFail("Cost Centre short description field is Not Displayed");
		// }
	}

	public void clickCreateCostCentreButton() {
		isDisplayedThenActionClick(createCostCentreButton, "Create Cost Center Button");
	}

	public void validateCreatedCostCentreSuccessMsg() {
		isDisplayed(createCostCentreSuccessMsg, "Created Cost Center Success Msg");
	}

	public void clickReturnToCostCentreButton() {
		isDisplayedThenActionClick(returnToCostCentreButton, "Retunr to Cost Center Button");
		
		sleep(3);
		
		checkTextInPageAndValidate("View and Edit Cost Centre", 30);
		
		
					
		//scrollToTopPage();
		
	}

	public void clickSaveChangesButton()  {
		isDisplayedThenActionClick(saveChangesBtn, "Save Changes Button");
		sleep(10);
		// if (saveChangesBtn.isDisplayed()) {
		// actionClick(saveChangesBtn);
		// logPass("Clicked on Save Changes Btn Button");
		// } else {
		// logFail("Save Changes Btn Button is Not Displayed");
		// }
	}
}
