﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using Common;
using Common.PageObjects;
using Common.ScenarioConfigurations;
using Common.Utility;
using System;
using EnCompass.Testing.Source.PageObjects.Controls;
using OpenQA.Selenium.Support.UI;
using AventStack.ExtentReports;
using NFluent;

namespace EnCompass.Testing.Source.PageObjects.Organization.Admin.MccGroupProfiles
{
    public partial class Index
    {
        #region XPath page Elements

        private const string _addNewMCCGProfilesXPath = @"//a[(contains(@class,'alert-link') or contains(@class,'btn btn-primary')) and contains(text(),'Create')]";
        private const string _editButtonXPath = @"//a[contains(@id,'actionLink0')]";
        private const string _shareButtonXPath = @"//a[contains(@id,'actionLink1')]";
        private const string _selectOrganizationXPath = @"//select[contains(@id, 'ddlOrgList')]";
        private const string _createGroupLinkXPath = @"//a[contains(text(),'Create')]";
        #endregion

        #region Page Elements

        private IWebElement _addNewMCCGProfiles
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_addNewMCCGProfilesXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_addNewMCCGProfiles element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _editButton
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_editButtonXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_editButton element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _shareButton
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_shareButtonXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_shareButton element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _selectOrganization
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_selectOrganizationXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_selectOrganization element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _createGroupLink
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_createGroupLinkXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_createGroupLink element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        #endregion

        public string SelectOrganization
        {
            get { return new SelectElement(_selectOrganization).SelectedOption.Text; }
            set { _selectOrganization.SetListboxByText(value); }
        }

        public void AddNewMCCGProfiles()
        {
            WaitForLoad();
            _createGroupLink.JSClickWithFocus(Driver);
        }

        public void ClickEditButton()
        {
            WaitForLoad();
            _editButton.JSClickWithFocus(Driver);
		}

        public void ClickShareButton(ExtentTest test)
        {
            WaitForLoad();
            _shareButton.JSClickWithFocus(Driver);
			test.Info("Click on share button");
        }

        public void CreateAGroupLink() {
            WaitForLoad();
            _createGroupLink.JSClickWithFocus(Driver);
		}

        private GridControl _resultsMccgProgilesGrid;
        public GridControl ResultsMccgProgilesGrid
        {
            get
            {
                var grid = _resultsMccgProgilesGrid ?? (_resultsMccgProgilesGrid = new GridControl("dgProfiles", Driver));
                grid.WaitForGrid();
                return grid;
            }
        }
    }
}
