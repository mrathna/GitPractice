package com.framework.pages.WES.Cruise;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.ExtentTest;
import com.framework.basepage.BasePage;
import com.framework.repo.Locator_WES;

public class CruiseHomePage extends BasePage {

	@FindBy(xpath = Locator_WES.CRUISE_FULE_CARD_APPLICATION)
	public WebElement fuleCardAppliction;

	@FindBy(xpath = Locator_WES.CRUISE_WES_CHECK_BOX)
	public WebElement wesCheckBox;

	@FindBy(xpath = Locator_WES.HOME_MENU_OPTION)
	public WebElement homeMenu;

	@FindBy(xpath = Locator_WES.UNRETURNED_APPS)
	public WebElement unreturnedApps;

	@FindBy(xpath = Locator_WES.REF_COLUMNHEADER)
	public WebElement refColumn;

	@FindBy(xpath = Locator_WES.REF_GETFIRSTROW)
	public WebElement reffirstRow;

	public WebElement app_Completed;

	@FindBy(xpath = Locator_WES.SAVE_BUT)
	public WebElement saveButton;

	@FindBy(id = Locator_WES.UNASSIGNED_CHECK)
	public WebElement unassignedCheck;

	@FindBy(xpath = Locator_WES.CRUISE_REF_NO)
	public WebElement cruiseRefNo;

	@FindBy(xpath = Locator_WES.ASSIGN_CHECKBOX)
	public WebElement assignCheckBox;

	@FindBy(xpath = Locator_WES.ASSIGN_SELECTED_APPLICATION)
	public WebElement assignSelectedApplication;

	@FindBy(id = Locator_WES.MY_CREDIT_CHECK)
	public WebElement myCreditCheck;

	@FindBy(xpath = Locator_WES.MY_CREDIT_CHECK_REF)
	public WebElement myCreditCheckRef;

	@FindBy(xpath = Locator_WES.ASSIGN_TO_ANALYST_DROPDOWN)
	public WebElement assignToAnalystDropDown;

	@FindBy(xpath = Locator_WES.REF)
	public WebElement refNo;

	@FindBy(xpath = Locator_WES.APP_FORM_PDF_DOCUMENT)
	public WebElement appFormPdfDocument;

	@FindBy(xpath = Locator_WES.WEX_CREDITSUP_TITLE)
	public WebElement wexCreditsupTitle;

	@FindBy(xpath = Locator_WES.CALLSHEET_TAB)
	public WebElement callSheetTab;

	@FindBy(xpath = Locator_WES.MAINTENANCE)
	public WebElement maintenance;

	@FindBy(xpath = Locator_WES.MAINTENANCE_CALLSHEET)
	public WebElement maintenanceCallSheet;

	public CruiseHomePage(WebDriver driver, ExtentTest test) {
		super(driver, test);
		// TODO Auto-generated constructor stub
		PageFactory.initElements(new AjaxElementLocatorFactory(driver, 15), this);
	}

	public void goToHomeAndChooseSubmenu(String subMenuName) {
		
//		verifyTitle("Cruise");
		
		mouseHover(homeMenu);
		
		// isDisplayedThenActionClick(addNewCustomer, "Add New Customer");
		isDisplayedThenActionClick(
				driver.findElement(By.xpath("//ul[@id='nav']//a[contains(text(),'" + subMenuName + "')]")),
				subMenuName);
//		verifyTitle("Cruise");

	}

	public void goToMaintenanceAndCallsheet(String subMenuName) {
		mouseHover(maintenance);
		mouseHover(maintenanceCallSheet);
		isDisplayedThenActionClick(
				driver.findElement(By.xpath("//ul[@id='nav']//a[contains(text(),'" + subMenuName + "')]")),
				subMenuName);

	}

	public void ValidateRefNumberInUnreturnedTab(String refNo) {
		isDisplayedThenClick(unreturnedApps, "Unreturned Apps");
		if ("tabSelected".equalsIgnoreCase(unreturnedApps.getAttribute("class"))) {
			driver.switchTo().frame("appsFrame");
			isDisplayedThenEnterText(refColumn, refNo + "RefNo Row", refNo);
			sleep(2);
			boolean tablePresence = waitToCheckElementIsDisplayed(By.xpath("//table[@id='pendingAppGrid']/tbody/tr[2]"),
					10);
			System.out.println("tablePresence : " + tablePresence);
			if (tablePresence) {
				String actualrefNo = reffirstRow.getText();
				if (refNo.equals(actualrefNo)) {
//					Taking ScreenShots 
					takeScreenshot();
					sleep(2);
					Click(reffirstRow, "1st row is Clicked");
					logPass(actualrefNo + " expected Customer is clicked");
				} else {
					logFail(actualrefNo + " is not expected Customer");
				}
			} else {
				logFail("No data's Found in a table");
			}
		} else {

			logFail("Expected Tab is not Selected");
		}
	}

	// Prakalpha-->GotoCallSheetTable
	public void gotoCallSheetTable() {
		CruiseHomePage homePage = new CruiseHomePage(driver, test);
		homePage.goToHomeAndChooseSubmenu("Home Page");
		sleep(2);
		
		Click(callSheetTab, "Call Sheet Tab");
		driver.switchTo().frame("callsheetFrame");

	}

	/*
	 * Sowmiya Unassign check tab
	 */
	public void assignRefNoInUnassignCheckTab(String referenceNo) {
//		sleep(2);
//		verifyText(wexCreditsupTitle, "Wex Creditsup");
		isDisplayedThenClick(unassignedCheck, "Unassigned check");
	//Unassigned tab
		driver.switchTo().frame("unassignedcreditFrame");
		//selectDropDownByVisibleText(assignToAnalystDropDown, "WEX Creditsup");
		selectDropDownByIndex(assignToAnalystDropDown,59);
		isDisplayedThenEnterText(cruiseRefNo, "Cruise Reference No text box", referenceNo);
//		Taking ScreenShots 
		takeScreenshot();
		sleep(5);
		scrollRightPage();
		sleep(5);
		isDisplayedThenClick(assignCheckBox, "Assign Check Box");
		isDisplayedThenClick(assignSelectedApplication, "Assign Selected Application");
////		Taking ScreenShots 
//		takeScreenshot();
//		sleep(2);

	}

	public void assignRefNoInMyCreditCheckTab(String referenceNo) {
		WebDriverWait wait=new WebDriverWait(driver,20);
		driver.navigate().refresh();
//My Credit Check tab
		isDisplayedThenActionClick(myCreditCheck, "My Credit Check");
		driver.switchTo().frame("mycreditFrame");
		isDisplayedThenEnterText(myCreditCheckRef, "My credit check Reference No text box", referenceNo);
		sleep(3);
		isDisplayedThenDoubleClick(refNo, "Reference Number");
		// For clicking ok button in alert Popup
		if(wait.until(ExpectedConditions.alertIsPresent()) != null)
		{
			driver.switchTo().alert().accept();
		}
//		Taking ScreenShots 
		takeScreenshot();
		sleep(2);
	}

	public void clickingAndValidatingSpecificAccess(String string) {
		// TODO Auto-generated method stub
		
	}

}
