package com.framework.testcases.OLS.CHEV.Customer.ReadOnly;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.CHEV.CHBulkCardOrderPage;
import com.framework.pages.CHEV.CHBulkCardUpdatePage;
import com.framework.pages.CHEV.CHCardListPage;
import com.framework.pages.CHEV.CHHomePage;
import com.framework.pages.CHEV.CHViewCardPage;
import com.framework.pages.OLS.common.LoginPage;

public class ValidateHomePage extends BaseTest {
	
	
	 //Prakalpha
	//Verify Footer Details
	@Parameters({ "clientCountry", "clientName"})
	@Test(priority = 1)
	public void verifFooterDetails(@Optional("PH") String clientCountry, @Optional("CHV") String clientName) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  Chevron Customer Screens Read Only", "OLS - All Pages except cards menu");

		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		if (clientCountry.equals("SG")||clientCountry.equals("MY")||clientCountry.equals("HK")) {
			loginPage.Login("CHV_URL", "CHV_Customer_UN_READ_ONLY_"+clientCountry, "CHV_Customer_PWD_READ_ONLY_"+clientCountry, "CHV");
		} else if (clientCountry.equals("TH")) {
			loginPage.Login("CHV_URL", "CHV_Customer_UN_"+clientCountry, "CHV_Customer_PWD_"+clientCountry, "CHV");
		} else if (clientCountry.equals("PH")) {
			loginPage.Login("CHV_URL", "CHV_Customer_UN_"+clientCountry, "CHV_Customer_PWD_"+clientCountry, "CHV");
		}
		
		CHHomePage chHomePage = new CHHomePage(driver, test);
		
		
		chHomePage.verifyHomePageText();
		chHomePage.selectAccountFromDropdownAndValidate();
		chHomePage.navigateAndValidateTransctionList();
	    loginPage.Logout();
		
	}
	 
	//Prakalpha
	//Verify Mainpage on HomePage
	
	@Parameters({ "clientCountry", "clientName"})
	@Test(priority = 1)
	public void verifMainPageDetailsOnHomePage(@Optional("PH") String clientCountry, @Optional("CHV") String clientName) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  Chevron Customer Screens Read Only", "OLS - All Pages except cards menu");

		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		if (clientCountry.equals("SG")||clientCountry.equals("MY")||clientCountry.equals("HK")) {
			loginPage.Login("CHV_URL", "CHV_Customer_UN_READ_ONLY_"+clientCountry, "CHV_Customer_PWD_READ_ONLY_"+clientCountry, "CHV");
		} else if (clientCountry.equals("TH")) {
			loginPage.Login("CHV_URL", "CHV_Customer_UN_"+clientCountry, "CHV_Customer_PWD_"+clientCountry, "CHV");
		} else if (clientCountry.equals("PH")) {
			loginPage.Login("CHV_URL", "CHV_Customer_UN_"+clientCountry, "CHV_Customer_PWD_"+clientCountry, "CHV");
		}
		
		CHHomePage chHomePage = new CHHomePage(driver, test);
		
		chHomePage.verifyHomePageText();
		chHomePage.selectAccountFromDropdownAndValidate();
		chHomePage.getAccountStatus();
		//homePage.ValidateCustomerNameLabel();
		
	    loginPage.Logout();

	} 
	//Need to Cntu..
	
	
	@Parameters({ "clientCountry", "clientName"})
	@Test(priority = 1)
	public void testCustomerReadOnlyOLSCardsMenu(@Optional("PH") String clientCountry, @Optional("CHV") String clientName) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  Chevron Customer Screens Read Only", "OLS - All Pages except cards menu");

		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		if (clientCountry.equals("SG")||clientCountry.equals("MY")||clientCountry.equals("HK")) {
			loginPage.Login("CHV_URL", "CHV_Customer_UN_RW_ONLY_"+clientCountry, "CHV_Customer_PWD_RW_ONLY_"+clientCountry, "CHV");
		} else if (clientCountry.equals("TH")) {
			loginPage.Login("CHV_URL", "CHV_Customer_UN_"+clientCountry, "CHV_Customer_PWD_"+clientCountry, "CHV");
		} else if (clientCountry.equals("PH")) {
			loginPage.Login("CHV_URL", "CHV_Customer_UN_"+clientCountry, "CHV_Customer_PWD_"+clientCountry, "CHV");
		}


		CHHomePage chHomePage = new CHHomePage(driver, test);
		CHCardListPage cardListPage = new CHCardListPage(driver, test);
		CHViewCardPage chViewCardPage = new CHViewCardPage(driver, test);
		CHBulkCardOrderPage chBulkCardOrderPage = new CHBulkCardOrderPage(driver, test);
		CHBulkCardUpdatePage chBulkCardUpdatePage = new CHBulkCardUpdatePage(driver, test);

		//Find Cards
		chHomePage.loadFindAndUpdateCardPage();
		cardListPage.verifySearchButton();
		cardListPage.verifyExportButton();
		cardListPage.verifyPageSubTitles();
		cardListPage.clickSearchCard();
		cardListPage.verifyCardlistSearchtableHeaders();
		String cardResult = cardListPage.getActiveCardNumber();
		if(cardResult!=null) {
			cardListPage.enterCardNumber(cardResult);
			cardListPage.clickSearchCard();
			cardListPage.clickFirstCardNumberFromCardsList();
			cardListPage.pickCardDetailsOption();
			cardListPage.verifyViewCardPage();
			chViewCardPage.verifyReadOnlyMode();
			chViewCardPage.navigateBacktoCardList();
		} else {
			System.out.println("No Card Result found to Proceed");
		}
		
		//Reissue Controls
		chHomePage.loadReissueControlPage();
		cardListPage.verifyReissueUpload();
		
		//Bulk Card Status Change 
		chHomePage.loadBulkStatusChangePage();
		cardListPage.verifyBulkStatusChangeUpload();
	
		
		// TODO All Fields are diabled in the read only account.

		// String cardNumber = PropUtils.getPropValue(configProp, cardNumberStr);
		//
		// cardListPage.enterCardNumber(cardNumber);
		// cardListPage.clickSearchCard();
		// cardListPage.validateCardNumber(cardNumber);
		// cardListPage.clickFirstCardNumberFromCardsList();
		// cardListPage.verifyContextMenu();
		// cardListPage.pickCardDetailsOption();
		//
		// chViewCardPage.verifySubTitles();
		// chViewCardPage.verifyReadOnlyMode();
		// chViewCardPage.navigateBacktoCardList();

		//Bulk Order
		chHomePage.loadFindAndBulkOrderPage();
		chBulkCardOrderPage.verifyDownloadButton();
		chBulkCardOrderPage.verifyUploadButton();
		
		//Bulk Update
		chHomePage.loadFindAndBulkUpdatePage();
		chBulkCardUpdatePage.verifyDownloadButton();
		chBulkCardUpdatePage.verifyUploadButton();

		loginPage.Logout();

	}

}
