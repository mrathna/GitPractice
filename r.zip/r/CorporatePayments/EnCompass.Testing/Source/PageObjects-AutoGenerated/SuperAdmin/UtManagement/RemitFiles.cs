using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using Common;
using Common.PageObjects;
using Common.ScenarioConfigurations;
using Common.Utility;

namespace EnCompass.Testing.Source.PageObjects.SuperAdmin.UtManagement 
{
	/// <summary>
	/// Auto-generated Page Model Class
	/// Navigation Paths: 
		/// [Organization Home]->General->Remit Files
		/// </summary>
	[PageModel(@"/superAdmin/utManagement/RemitFiles.aspx")]
	public partial class RemitFiles : EnCompassSuperPageModel 
	{
		public override string RelativeUrl => @"/superAdmin/utManagement/RemitFiles.aspx";
		public override string PageIdentifierXPath_Generated => @"//li[contains(@class, 'breadcrumb-item active')][text() = 'Remit Files']";

		#region Navigation
		
		private void NavigateToMenuItem(IWebElement element)
		{
			Driver.Url = element.GetAttribute("href");
		}
		#endregion

		public RemitFiles(GlobalSettings settings) : base(settings) { }
	}  
}
