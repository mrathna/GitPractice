package com.framework.testcases.OLS.SHELL.Customer;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.OLS.HomePage;
import com.framework.pages.OLS.common.CommonPage;
import com.framework.pages.OLS.common.LoginPage;
import com.framework.pages.SHELL.SHELLHomePage;
import com.framework.pages.SHELL.SHELLTransactionListPage;

public class ValidateTransactionTestCases extends BaseTest  {
	
	@Parameters({"clientCountry","clientName", "cardType"})
	@Test(groups = { "Regression" })
	public void validateTransactionExportTransactions(@Optional("AT") String clientCountry, @Optional("SHELL") String clientName, @Optional("APA") String cardType)  {
		
		test = extent.createTest(clientName+ ":" +clientCountry+"  02 TransactionMenu - ExportTransactions", "Transactions Menu - export transactions");
		
        //Creating Objects for the Pages
        LoginPage loginPage = new LoginPage(driver, test);
        HomePage homePage = new HomePage(driver, test);
        SHELLHomePage shellHomePage = new SHELLHomePage(driver, test);
        CommonPage commonPage = new CommonPage(driver, test);
      
		// Calling Functions
        if(cardType.equals("PC"))
        {
        	loginPage.Login("SHLPC_URL", "SHLPC_UN_Customer_Admin_" + clientCountry, "SHLPC_PWD_Customer_Admin_" + clientCountry, clientName);
        }
        else if(cardType.equals("APA"))
        {
        	loginPage.Login("SHLAPA_URL", "SHLAPA_UN_Customer_Admin_" + clientCountry, "SHLAPA_PWD_Customer_Admin_" + clientCountry, clientName);
        }
		homePage.ValidateLogoutLink();
		homePage.ValidateHelpShellLink();
		homePage.ValidateWelcomeText(clientName+"#"+cardType);
		homePage.ValidateQuickLinks();
		shellHomePage.ValidateHeaderMenus("Admin");
		shellHomePage.ValidateFooterMenus();
		shellHomePage.clickTransactionsExportTransactioins(); 
		commonPage.isFileDownloaded(clientCountry);	
		//takeScreenshot();
		loginPage.Logout();
      
	}
	
	
	@Parameters({"clientCountry","clientName", "cardType"})
	@Test(groups = { "Regression" })
	public void validateTransactionsTransactionList(@Optional("AT") String clientCountry, @Optional("SHELL") String clientName, @Optional("APA") String cardType)  {
		
		test = extent.createTest(clientName+ ":" +clientCountry+"  01 TransactionMenu - TransactionList", "Transactions Menu - export transactions");
		
        //Creating Objects for the Pages
        LoginPage loginPage = new LoginPage(driver, test);
        HomePage homePage = new HomePage(driver, test);
        SHELLHomePage shellHomePage = new SHELLHomePage(driver, test);
        CommonPage commonPage = new CommonPage(driver, test);
        SHELLTransactionListPage shellTraListPage = new SHELLTransactionListPage(driver, test);
		// Calling Functions
        if(cardType.equals("PC"))
        {
        	loginPage.Login("SHLPC_URL", "SHLPC_UN_Customer_Admin_" + clientCountry, "SHLPC_PWD_Customer_Admin_" + clientCountry, clientName);
        }
        else if(cardType.equals("APA"))
        {
        	loginPage.Login("SHLAPA_URL", "SHLAPA_UN_Customer_Admin_" + clientCountry, "SHLAPA_PWD_Customer_Admin_" + clientCountry, clientName);
        }
		homePage.ValidateLogoutLink();
		homePage.ValidateHelpShellLink();
		homePage.ValidateWelcomeText(clientName+"#"+cardType);
		homePage.ValidateQuickLinks();
		shellHomePage.ValidateHeaderMenus("Admin");
		shellHomePage.ValidateFooterMenus();
		shellHomePage.clickTransactionsTransactionList(); 
		shellTraListPage.validateTheTransactionListPage();
		shellTraListPage.selectAllAccountsAndSearch();
		shellTraListPage.setTransactionsData();
		//String accountName = shellTraListPage.getAccountNameFromTheTransactions();				
		boolean isTransactionPresent = shellTraListPage.clickTheExport();
		
		if(isTransactionPresent)
		{			
			commonPage.isFileDownloaded("tableTransList");
			
			shellTraListPage.goToTransactionDetailPageAndValidate();
			
			shellTraListPage.backToTransactionListPage();			
		}
		
		loginPage.Logout();
      
	}

	@Parameters({"clientCountry","clientName", "cardType"})
	@Test(groups = { "Regression" })
	public void validateTransactionListNonPurchaseTransaction(@Optional("AT") String clientCountry, @Optional("SHELL") String clientName, @Optional("APA") String cardType)  {
		
		test = extent.createTest(clientName+ ":" +clientCountry+"  15 Transaction list showing in new format", "Transaction list showing Non Purchase Transaction new format");
		
        //Creating Objects for the Pages
        LoginPage loginPage = new LoginPage(driver, test);
        HomePage homePage = new HomePage(driver, test);
        SHELLHomePage shellHomePage = new SHELLHomePage(driver, test);
        SHELLTransactionListPage shellTransactionPage = new SHELLTransactionListPage(driver, test);
      
		// Calling Functions
        if(cardType.equals("PC"))
        {
        	loginPage.Login("SHLPC_URL", "SHLPC_UN_Customer_Admin_" + clientCountry, "SHLPC_PWD_Customer_Admin_" + clientCountry, clientName);
        }
        else if(cardType.equals("APA"))
        {
        	loginPage.Login("SHLAPA_URL", "SHLAPA_UN_Customer_Admin_" + clientCountry, "SHLAPA_PWD_Customer_Admin_" + clientCountry, clientName);
        }
		homePage.ValidateLogoutLink();
		homePage.ValidateHelpShellLink();
		homePage.ValidateWelcomeText(clientName+"#"+cardType);
		homePage.ValidateQuickLinks();
		shellHomePage.ValidateHeaderMenus("Admin");
		shellHomePage.ValidateFooterMenus();
		
		// Select Transaction List
		shellHomePage.clickTransactionsMenuTransactionListAndValidate(); 
		shellHomePage.selectAccountAndSearch();
		
		// Validate Non Purchase Transaction
		shellTransactionPage.validateNonPurchaseTransaction();
		
		// Click Logout
		loginPage.Logout();
      
	}
}
