using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using Common;
using Common.PageObjects;
using Common.ScenarioConfigurations;
using Common.Utility;

namespace EnCompass.Testing.Source.PageObjects.SuperAdmin.ReceiptManagement 
{
	/// <summary>
	/// Auto-generated Page Model Class
	/// Navigation Paths: 
		/// [Organization Home]->General->Unmatched Receipts
		/// </summary>
	[PageModel(@"/superAdmin/receiptManagement/receiptManagement.aspx")]
	public partial class ReceiptManagement : EnCompassSuperPageModel 
	{
		public override string RelativeUrl => @"/superAdmin/receiptManagement/receiptManagement.aspx";
		public override string PageIdentifierXPath_Generated => @"//li[contains(@class, 'breadcrumb-item active')][text() = 'Unmatched Receipts']";

		#region Navigation
		
		private void NavigateToMenuItem(IWebElement element)
		{
			Driver.Url = element.GetAttribute("href");
		}
		#endregion

		public ReceiptManagement(GlobalSettings settings) : base(settings) { }
	}  
}
