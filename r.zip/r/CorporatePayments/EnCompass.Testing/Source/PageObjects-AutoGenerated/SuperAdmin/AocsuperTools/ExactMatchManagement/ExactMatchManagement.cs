using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using Common;
using Common.PageObjects;
using Common.ScenarioConfigurations;
using Common.Utility;

namespace EnCompass.Testing.Source.PageObjects.SuperAdmin.AocsuperTools.ExactMatchManagement 
{
	/// <summary>
	/// Auto-generated Page Model Class
	/// Navigation Paths: 
		/// [Organization Home]->Super Admin Tools->Product Support Tools->Exact Match Management
		/// </summary>
	[PageModel(@"/superAdmin/AOCSuperTools/ExactMatchManagement/ExactMatchManagement.aspx")]
	public partial class ExactMatchManagement : EnCompassSuperPageModel 
	{
		public override string RelativeUrl => @"/superAdmin/AOCSuperTools/ExactMatchManagement/ExactMatchManagement.aspx";
		public override string PageIdentifierXPath_Generated => @"";

		#region Navigation
				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Workflow Analysis']")]
		private IWebElement _superAdminTools_ProductSupportTools_ExactMatchManagement_WorkflowAnalysis { get; set; }
		public void NavigateTo_SuperAdminTools_ProductSupportTools_ExactMatchManagement_WorkflowAnalysis()
		{
			NavigateToMenuItem(_superAdminTools_ProductSupportTools_ExactMatchManagement_WorkflowAnalysis);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Hierarchy Analysis']")]
		private IWebElement _superAdminTools_ProductSupportTools_ExactMatchManagement_HierarchyAnalysis { get; set; }
		public void NavigateTo_SuperAdminTools_ProductSupportTools_ExactMatchManagement_HierarchyAnalysis()
		{
			NavigateToMenuItem(_superAdminTools_ProductSupportTools_ExactMatchManagement_HierarchyAnalysis);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Merchant Log Status']")]
		private IWebElement _superAdminTools_ProductSupportTools_ExactMatchManagement_MerchantLogStatus { get; set; }
		public void NavigateTo_SuperAdminTools_ProductSupportTools_ExactMatchManagement_MerchantLogStatus()
		{
			NavigateToMenuItem(_superAdminTools_ProductSupportTools_ExactMatchManagement_MerchantLogStatus);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Exact Match Management']")]
		private IWebElement _superAdminTools_ProductSupportTools_ExactMatchManagement_ExactMatchManagement { get; set; }
		public void NavigateTo_SuperAdminTools_ProductSupportTools_ExactMatchManagement_ExactMatchManagement()
		{
			NavigateToMenuItem(_superAdminTools_ProductSupportTools_ExactMatchManagement_ExactMatchManagement);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Custom Fax Management']")]
		private IWebElement _superAdminTools_ProductSupportTools_ExactMatchManagement_CustomFaxManagement { get; set; }
		public void NavigateTo_SuperAdminTools_ProductSupportTools_ExactMatchManagement_CustomFaxManagement()
		{
			NavigateToMenuItem(_superAdminTools_ProductSupportTools_ExactMatchManagement_CustomFaxManagement);
		}

		
		private void NavigateToMenuItem(IWebElement element)
		{
			Driver.Url = element.GetAttribute("href");
		}
		#endregion

		public ExactMatchManagement(GlobalSettings settings) : base(settings) { }
	}  
}
