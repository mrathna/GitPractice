﻿extern alias cpt;
using cpt.Newtonsoft.Json;
using cpt.Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Common.Utility.ControlMTool
{
	public class Stage2RunDetails
	{
		JObject parsed;

		public Stage2RunDetails(string parseText)
		{
			parsed = JObject.Parse(parseText);
		}

		[JsonProperty("jobId")]
		public string SLJobId
		{
			get
			{
				return parsed.SelectToken("statuses[0].jobId").Value<string>();
			}
		}

		[JsonProperty("folderId")]
		public string SLfolderId
		{
			get
			{
				return parsed.SelectToken("statuses[0].folderId").Value<string>();
			}
		}

		[JsonProperty("numberOfRuns")]
		public string SLNumOfRuns
		{
			get
			{
				return parsed.SelectToken("statuses[0].numberOfRuns").Value<string>();
			}
		}

		[JsonProperty("name")]
		public string SLJobName
		{
			get
			{
				return parsed.SelectToken("statuses[0].name").Value<string>();
			}
		}

		[JsonProperty("folder")]
		public string SLJobFolder
		{
			get
			{
				return parsed.SelectToken("statuses[1].folder").Value<string>();
			}
		}
		[JsonProperty("type")]
		public string SLJobType
		{
			get
			{
				return parsed.SelectToken("statuses[0].type").Value<string>();
			}
		}
		[JsonProperty("status")]
		public string SLJobStatus
		{
			get
			{
				return parsed.SelectToken("statuses[0].status").Value<string>();
			}
		}
		[JsonProperty("held")]
		public string SLJobHeld
		{
			get
			{
				return parsed.SelectToken("statuses[0].held").Value<string>();
			}
		}
		[JsonProperty("deleted")]
		public string SLJobDeleteStatus
		{
			get
			{
				return parsed.SelectToken("statuses[0].deleted").Value<string>();
			}
		}
		[JsonProperty("startTime")]
		public string SLJobStartTime
		{
			get
			{
				return parsed.SelectToken("statuses[0].startTime").Value<string>();
			}
		}
		[JsonProperty("endTime")]
		public string SLJobEndTime
		{
			get
			{
				return parsed.SelectToken("statuses[0].endTime").Value<string>();
			}
		}

		[JsonProperty("outputURI")]
		public string SLOutputURI
		{
			get
			{
				return parsed.SelectToken("statuses[0].outputURI").Value<string>();
			}
		}
		[JsonProperty("logURI")]
		public string SLLogURI
		{
			get
			{
				return parsed.SelectToken("statuses[0].logURI").Value<string>();
			}
		}

	}
}
