/*
 * Ayub Khan
 */

package com.framework.pages.BP;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.ExtentTest;
import com.framework.basepage.BasePage;
import com.framework.pages.OLS.common.BPCommonPage;
import com.framework.repo.Locator;
import com.framework.util.PropUtils;

public class BPAccountDetailsPage extends BasePage {

	BPHomePage bpHomePage = new BPHomePage(driver, test);
	BPCommonPage bpCommonPage = new BPCommonPage(driver, test);
	@FindBy(how = How.ID, using = Locator.ACCOUNTS_DROPDOWN)
	public WebElement accountsDropDown;
	@FindBy(how = How.ID, using = Locator.EDITACCOUNTDETAILS)
	public WebElement editAccountDetailsButton;
	@FindBy(how = How.ID, using = Locator.ACCOUNTDETAILSNAME)
	public WebElement accountDetailCardName;
	@FindBy(how = How.ID, using = Locator.ACCOUNTDETAILSNUMBER)
	public WebElement accountDetailcardNumber;
	@FindBy(how = How.XPATH, using = Locator.ACCOUNTLEVELPIN)
	public WebElement accountLevelPin;
	@FindBy(how = How.ID, using = Locator.CONFIRMACCOUNTLEVELPIN)
	public WebElement confirmAccountLevelPin;
	@FindBy(how = How.ID, using = Locator.SAVECHANGESBUTTON)
	public WebElement saveChangesButton;
	@FindBy(how = How.ID, using = Locator.CONFIRMATIONMESSAGE)
	public WebElement confirmationMessage;
	@FindBy(how = How.ID, using = Locator.ALERTTHRESHOLD)
	public WebElement alertThresholdField;
	@FindBy(how = How.ID, using = Locator.PHONE_FIELD)
	public WebElement accountPhoneNumber;
	@FindBy(how = How.XPATH, using = Locator.ADVANCED_SEARCH)
	public WebElement viewContactInformationLink;
	@FindBy(how = How.ID, using = Locator.CONTACT_NAME)
	public WebElement accountNameField;
	@FindBy(how = How.ID, using = Locator.EMAIL_FIELD)
	public WebElement accountEmailField;
	@FindBy(how = How.ID, using = Locator.RETURNTOACCOUNTDETAILBUTTON)
	public WebElement returnToAccountDetailButton;
	@FindBy(how = How.ID, using = Locator.UPDATECREDITLIMITLINK)
	public WebElement updateCreditLimitLink;
	@FindBy(xpath = Locator.VIEW_EDIT_ACC_DETAILS)
	public WebElement viewEditAccDetails;
	@FindBy(xpath = Locator.VIEW_EDIT_ACC_DET_TITLE)
	public WebElement viewEditAccDetailsTitle;
	@FindBy(id = Locator.ACCOUNT_LIST)
	public WebElement accountListDD;
	@FindBy(id = Locator.SEARCH_BTN)
	public WebElement searchVehicleButton;
	@FindBy(id = Locator.VEHICLES_TABLE)
	public WebElement VehicleTable;
	@FindBy(id = Locator.MULTIFIELD_SEARCH)
	public WebElement multiTextSearch;
	@FindBy(id = Locator.DESCRIPTION_COMMON)
	public WebElement vehcileDescTB;
	@FindBy(xpath = Locator.RESULT_COUNT)
	public WebElement vehicleResCount;
	@FindBy(id = Locator.FIRST_UPDATEODAMETER)
	public WebElement updateOdameter;
	@FindBy(id = Locator.FIRST_GO_TO_CARD)
	public WebElement goToCard;
	@FindBy(id = Locator.UPDATE_ODA_METER_TB)
	public WebElement updateOMText;
	@FindBy(id = Locator.UPDATE_CHANGES)
	public WebElement updateSaveButton;
	@FindBy(id = Locator.BACK_VEHICLEPAGE)
	public WebElement backToVehPage;
	@FindBy(id = Locator.ACCOUNTCURRENTBALANCE)
	public WebElement accountCurrentBalance;

	@FindBy(id = Locator.ACCOUNTCREDITLIMIT)
	public WebElement accountCreditLimit;

	@FindBy(id = Locator.CREDITLIMIT_EMAILADDRESS)
	public WebElement accountLimitEmailAddress;

	@FindBy(id = Locator.PHONE_NUMBER_FIELD)
	public WebElement phoneNumberField;

	@FindBy(xpath = Locator.EMAIL_ADDRESS_FIELD)
	public WebElement emailAddrField;

	@FindBy(id = Locator.ACCOUNT_TRADING_NAME)
	public WebElement accountTradingName;

	@FindBy(id = Locator.ACCOUNT_MEMBER_NUMBER)
	public WebElement accountMemberNumber;

	@FindBy(id = Locator.ACCTDETAIL_LEFT_HEADER)
	public WebElement accountdetails;

	@FindBy(how = How.XPATH, using = Locator.HOME_MENU)
	public WebElement HomeMenu;

	private String accountCardNumber = "";
	private String accountCardName = "";
	private String accountPin = "";
	private String accountCustomerName = "";
	private String accountCustomerEmail = "";
	private String accountCustomerPhoneNo = "";
	private String alertThresholdData = "";
	private String getDBDetailsFromProperties = "";
	private String pinOffSet = null; // 30-04-2018, Ayub Khan
	String vehicleResultCount = "";
	String accountName=" ";
	String clientName=" ";

	public BPAccountDetailsPage(WebDriver driver, ExtentTest test) {
		super(driver, test);
		PageFactory.initElements(driver, this);
	}

	public void clickEditAccountDetailsbutton() {
		isDisplayedThenClick(editAccountDetailsButton, "Edit Account Details Button");
	}

	public void getPINValuesFromDB(String clientName) {
		try {
			getDBDetailsFromProperties = PropUtils.getPropValue(configProp, "sqlODSServerName");
			// clientNameForDBConnection = clientName;

			String queryToGetPinOffset = "select PIN_OFFSET from m_customers where customer_no=" + accountCardNumber;
			pinOffSet = connectDBAndGetValue(queryToGetPinOffset, getDBDetailsFromProperties);
			System.out.println("Pin offset from DB:- " + pinOffSet + "Card number Is" + accountCardNumber);

			if (pinOffSet.equals(null)) {
				logFail("Pin Offset values is displayed as null in DB");
			} else {
				logPass("Pin offset values is not null in DB");
			}
		}

		catch (Exception e) {
			logFail(e.getMessage());
		}

	}

	public void clickViewContactInformationLink() {
		isDisplayedThenActionClick(viewContactInformationLink, "View Contact Information Link");
	}

	public void clickReturnToAccountDetailButton() {
		isDisplayedThenActionClick(returnToAccountDetailButton, "Return to Account Detail Button");
	}

	public void clickUpdateCreditLimitLink(String clientCountry) {
		if (clientCountry.equalsIgnoreCase("AU")) {
			isDisplayedThenClick(updateCreditLimitLink, "Update Credit Limit Button");
		} else {
			logInfo("No AlertThresholdField dropdown");
		}
	}
	public String checkRemoveAccountLevelPINWithSelectDropDownAccount() {
		isDisplayed(accountsDropDown, "Selected input from Accounts dropdown");
		changePin(accountsDropDown,0);
		sleep(5);
		accountName=selectedStringFrmDropDown(accountsDropDown);
		return accountName;
	}
		
	public void changePin(WebElement locator,int min) {
		    try {
			WebDriverWait wait = new WebDriverWait(driver, 10);
			wait.until(ExpectedConditions.visibilityOf(locator));
			Select accounts = new Select(locator);
			int MaxSize = (accounts.getOptions().size());
		 for(int i=min;i<=MaxSize-1;) {
			  if(i<=3) {
			accounts.selectByIndex(i);
			System.out.println("valus is"+i);
		     bpHomePage.clickAccountDetailsLink();
			clickEditAccountDetailsbutton();
			checkAccountDetailsPage();
			if(isAccountLevelPinIsPresent()) {
				typeAccountLevelPin();
				typeConfirmAccountLevelPin();
				typeAccountPhoneNumber();
				typeAccountEmail();
				clickSaveChangesButton();
				checkConfirmationMessage();
				getPINValuesFromDB(clientName);
				break;
			}
			else
				logInfo("Account has no pin value");
				
			
		 }
			  else
				  logInfo(" We have tried"+i+"times account has no pin value");
			  break;
		 }
		 
	  }	 catch (Exception ex) {
				logFail(ex.getMessage());
        }
	}

			
	



	public void checkAccountDetailsPage() {
		isDisplayed(accountDetailCardName, "Account Details Text");
		accountCardName = getText(accountDetailCardName);
		accountCardNumber = getText(accountDetailcardNumber);
	}
	public boolean isAccountLevelPinIsPresent() {
			System.out.println("acountlevel pin::"+accountLevelPin.getAttribute("value"));
			System.out.println("conformlevel pin::"+confirmAccountLevelPin.getAttribute("value"));
			//if(getAttribute(accountLevelPin,"value").isEmpty() && getAttribute(confirmAccountLevelPin,"value").isEmpty()) {
			if(accountLevelPin.getAttribute("value").isEmpty() && confirmAccountLevelPin.getAttribute("value").isEmpty()) {    
				System.out.println("accountlevelpin is empty");
				return false;
			}
			else
			return true;
			}

	public void typeAccountLevelPin() {
		isDisplayed(accountLevelPin, "Account Level Pin");
		accountLevelPin.clear();
		accountPin = String.valueOf(fakerAPI().number().numberBetween(1901, 1999));
		System.out.println("Generated PIN number is " + accountPin);
		accountLevelPin.sendKeys(accountPin);
	}

	public void typeConfirmAccountLevelPin() {
		isDisplayedThenEnterText(confirmAccountLevelPin, "Confirm Account Level Pin", accountPin);
	}

	public void selectInputFromAlertThreshold(String clientCountry) {
		if (clientCountry.equalsIgnoreCase("AU")) {
			isDisplayed(alertThresholdField, "Select the input from dropdown");
			selectInputFromDropdown(alertThresholdField, 1);
			alertThresholdData = selectedStringFrmDropDown(alertThresholdField);
		} else {
			logInfo("No AlertThresholdField dropdown");
		}
	}

	public void typeAccountPhoneNumber() {
		accountCustomerPhoneNo = fakerAPI().phoneNumber().phoneNumber();
		isDisplayedThenEnterText(accountPhoneNumber, "Account Phone Number", accountCustomerPhoneNo);
	}

	public void typeAccountName() {
		accountCustomerName = fakerAPI().name().username().toString();
		isDisplayedThenEnterText(accountNameField, "Account Name", accountCustomerName);
	}

	public void typeAccountEmail() {
		accountCustomerEmail = fakerAPI().internet().emailAddress();
		isDisplayedThenEnterText(accountEmailField, "Customer Email Field", accountCustomerEmail);
	}

	/*
	 * Added By Anton 03.05.2018
	 */

	public void clickViewEditVehiclesAndValidate() {
		clickLinkAndValidateNavigation(viewEditAccDetails, viewEditAccDetailsTitle);
	}

	public void selectAllAccountsAndValidate() {
		String textFind = null;
		try {
			if (accountListDD.isDisplayed()) {
				selectDropDownByVisibleText(accountListDD, "All Accounts");
				logInfo("All Accounts option is selected");

				sleep(2);

				isDisplayedThenClick(searchVehicleButton, "Search Vehicles button");

				if (vehicleResCount.isDisplayed()) {
					textFind = vehicleResCount.getText();

					setResultCount(textFind);
				}

				boolean checkVFoundText = waitForTextToAppear(textFind, 10);

				if (checkVFoundText) {
					logPass(textFind + " is present");
				}

				else {
					logFail(textFind + " Vehicles found text is not Present");
				}

				isDisplayed(VehicleTable, "Vehicles result table");

			}
		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
	}

	public void setCellDataFromVehicleTable(int expColSize) {
		setCellDataFromTable(VehicleTable, expColSize, false);
	}

	public void searchAndValidate(WebElement searchTB, WebElement searchButton, String keyWord, int colValue,
			int reqColValue) {
		sleep(3);

		flushHashMap(tableSpec);

		if (searchTB.isDisplayed()) {
			searchTB.clear();
			searchTB.sendKeys(keyWord);
		}

		sleep(3);

		if (searchButton.isDisplayed()) {
			searchButton.click();
		}

		sleep(3);

		if (!keyWord.equals("")) {
			// System.out.println(" comes in here ------ ");

			setCellDataFromTable(VehicleTable, reqColValue, true);

			String actualValue = getCellDataFromTable(1, colValue, true);

			if (actualValue.equals(keyWord)) {
				logPass(" Search " + keyWord + " is validated and it is working fine");
			}

			else {
				logFail(" Search " + keyWord + " validation is failed: The Actual Value is = " + actualValue);
			}
		}

		else {
			boolean checkVFoundText = waitForTextToAppear(vehicleResultCount, 10);

			if (checkVFoundText) {
				logPass(vehicleResultCount + " is present");
			}

			else {
				logFail(vehicleResultCount + " is not Present");
			}
		}

	}

	public void searchCardNumberAndValidate() {
		// TODO Auto-generated method stub
		String cardNumber = getCellDataFromTable(1, 3, false);
		searchAndValidate(multiTextSearch, searchVehicleButton, cardNumber, 3, 7);
		sleep(2);
	}

	public void searchDriverNameAndValidate() {
		// TODO Auto-generated method stub
		String driverName = getCellDataFromTable(1, 5, false);
		searchAndValidate(multiTextSearch, searchVehicleButton, driverName, 5, 7);
	}

	public void searchVehicleRegAndValidate() {
		// TODO Auto-generated method stub
		String vehicleReg = getCellDataFromTable(1, 0, false);
		searchAndValidate(multiTextSearch, searchVehicleButton, vehicleReg, 0, 7);
	}

	public void searchwithEmptyStringAndValidate() {
		// TODO Auto-generated method stub
		searchAndValidate(multiTextSearch, searchVehicleButton, "", 0, 7);
	}

	public void searchwithDescAndValidate() {
		// TODO Auto-generated method stub

		String desc = getCellDataFromTable(3, 1, false);
		searchAndValidate(vehcileDescTB, searchVehicleButton, desc, 1, 7);
	}

	public void searchEmptyDescAndValidate() {
		// TODO Auto-generated method stub
		searchAndValidate(vehcileDescTB, searchVehicleButton, "", 0, 7);
	}

	public void updateTheODAMeterValueAndValidate() {
		// TODO Auto-generated method stub
		String cardNumberText = "", odaMeterValue = "";
		boolean isReturnToPrePage = false;
		boolean stopLoop=false;
		try {
			if (VehicleTable.isDisplayed()) {
				System.out.println("------- Comes in here ---- Vehicle Table is Displayed ----- ");
				
				List<WebElement> numberOfRows = VehicleTable.findElements(By.xpath("//tbody[contains(@id,'lform:tableVehicleList:tb')]/tr"));
				WebElement cardNumberElement ;
				boolean isSaved ,isUpdateOdaMeterPagePresent,isCorrectCardPage;
				scrollDownPage();
				
				for(WebElement rowNumber: numberOfRows)
				{
					if(stopLoop)
					break;
					
					System.out.println("-------- rowNumber ------ "+rowNumber.isDisplayed());
					//System.out.println("------ rowNumber get TExt ----- "+rowNumber.getText());
					//sleep(2);
					cardNumberElement= rowNumber.findElement(By.xpath(".//td[1]/div[2]/p/a"));
					System.out.println("-------- cardNumberElement ------ "+cardNumberElement.isDisplayed());
					if(cardNumberElement.isDisplayed())
					{
					cardNumberText = cardNumberElement.getText();
					cardNumberElement.click();
					logInfo("First card number is clicked");
					//sleep(5);
					if (updateOdameter.isDisplayed()) {
						updateOdameter.click();
						logInfo("UpdateOdameter link is clicked");
					}
	
					//sleep(2);
	
					isUpdateOdaMeterPagePresent = waitForTextToAppear("Update Vehicle Odometer", 10);
	
					if (isUpdateOdaMeterPagePresent) {
						logPass("Update Odameter page is opened correctly");
					}
	
					else {
						logFail("Update Odameter page is not opened correctly");
					}
	
					boolean isCardNumberPresent = waitForTextToAppear(cardNumberText, 10);
	
					if (isCardNumberPresent) {
						logPass("Verified correct card number present " + cardNumberText);
					}
	
					else {
						logFail("We are not in correct Page, Because the card numbers are mismatching");
					}
	
					if (updateOMText.isDisplayed()) {
						odaMeterValue = String.valueOf(fakerAPI().number().numberBetween(1000, 10000));
						new Actions(driver).moveToElement(updateOMText).click().perform();
						updateOMText.clear();
						updateOMText.sendKeys(odaMeterValue);
						//sleep(2);
	
						scrollDownPage();
	
						if (updateSaveButton.isDisplayed()) {
							updateSaveButton.click();
							logInfo("Save Changes button is clicked");
						}
	
						scrollUpPage();
	
						//sleep(3);
	
						isSaved= waitForTextToAppear("Congratulations. The odometer value for registration number "
								+ cardNumberText + " has been successfully updated.", 10);
	
						if (isSaved) {
							logPass("Successfully saved the updated Odameter Value = " + odaMeterValue
									+ " for the card number= " + cardNumberText);
						}
	
						else {
							logFail("Unsuccessfully saved the  updated Odameter Value = " + odaMeterValue
									+ " for the card number= " + cardNumberText);
						}
	
						scrollDownPage();
	
						if (backToVehPage.isDisplayed()) {
							backToVehPage.click();
	
							//sleep(2);
	
							isReturnToPrePage = waitForTextToAppear("View and Edit Vehicles", 10);
	
							if (isReturnToPrePage) {
								logPass("Back to View and Edit vehicles page");
							}
	
							else {
								logFail("It is not went to Back To View and Edit Vehicles page");
							}
	
							isCorrectCardPage = waitForTextToAppear(cardNumberText, 10);
	
							if (isCorrectCardPage) {
								logPass("We are in correct card page " + cardNumberText);
							} else {
								logFail("We are not in correct card page " + cardNumberText);
							}
							stopLoop=true;
							
						}
					}

				}
					else
					{
						logInfo("Card Number is empty");
					}
				}
				
			}
		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
	}

	public void goToCardAndValidate() {
		// TODO Auto-generated method stub

		// String cardNumberText = "";
		
		boolean stopLoop = false;
		
		try {
			if (VehicleTable.isDisplayed()) {
				
				scrollDownPage();
				boolean isViewCardDetails ;
				List<WebElement> numberOfRows = VehicleTable.findElements(By.xpath("//tbody[contains(@id,'lform:tableVehicleList:tb')]/tr"));
				WebElement cardNumberElement ;
				for(WebElement cardNumber : numberOfRows)
				{
					if(stopLoop)
						break;
					
					cardNumberElement	= cardNumber.findElement(By.xpath(".//td[1]/div[2]/p/a"));
					// cardNumberText = cardNumberElement.getText();
					
					
					if(cardNumberElement.isDisplayed())
					{
						cardNumberElement.click();
						sleep(2);
						if (goToCard.isDisplayed()) {
							actionClick(goToCard);
						}
		
						//sleep(2);
		
						isViewCardDetails = waitForTextToAppear("View Card Details", 10);
		
						if (isViewCardDetails) {
							logPass("View Card Details page is opened correctly");
						}
		
						else {
							logFail("View Card Details page is not opened correctly");
						}
		
						// View Card Details
		
						scrollUpPage();
						
						stopLoop = true;
					}
					
					else
					{
						logInfo("Card Number is empty");
					}
	
				}
			}
		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
	}

	public void setResultCount(String passValue) {
		vehicleResultCount = passValue;
	}

	public void clickSaveChangesButton() {
		isDisplayedThenActionClick(saveChangesButton, "Save Changes Button");
		//sleep(5);
	}

	public void checkConfirmationMessage() {
		isDisplayed(confirmationMessage, "Confirmation message");
		verifyText(confirmationMessage, "Congratulations. Your details for " + accountCardName + " ("
				+ accountCardNumber + ") have been successfully updated.");
	}

	public void checkUpdatedInput(String clientCountry) {
		if (clientCountry.equalsIgnoreCase("AU")) {
			isDisplayed(alertThresholdField, "Alert Threshold Input");
			verifyTextFromDropdown(alertThresholdField, alertThresholdData);

			isDisplayed(accountNameField, "Account Contact Name is updated");
			verifyAttribute(accountNameField, "value", accountCustomerName);

			isDisplayed(accountEmailField, "Account Contact Email is updated");
			verifyAttribute(accountEmailField, "value", accountCustomerEmail);

			isDisplayed(accountPhoneNumber, "Account Contact Phone Number is updated");
			verifyAttribute(accountPhoneNumber, "value", accountCustomerPhoneNo);
		} else {
			logInfo("No AlertThresholdField dropdown");
		}
	}

	public void clearData() {
		// TODO Auto-generated method stub
		flushHashMap(tableValues);
		flushHashMap(tableSpec);
	}

	public void validateAccountDetailsPage(String accountName) {

		boolean isAccDetPre = waitForTextToAppear("Account Details", 10);
		if (isAccDetPre) {
			logPass("Naviagated to the Account Details Page");
		}

		else {
			logFail("Not Navigated to the Account Details Page");
		}

		boolean isAccountPresent = waitForTextToAppear(accountName, 15);

		if (isAccountPresent) {
			logPass("Naviagated to the  correct  " + accountName + " Account Details Page");
		}

		else {
			logFail("Not naviagated to the  correct  " + accountName + " Account Details Page");
		}

	}

	/*
	 * Select the Account and click the Account Details link and validate the Page.
	 * 
	 */
	public void selectAccountAndClickAndValidate() {

		String accountName = bpCommonPage.selectAccount();
		bpHomePage.clickAccountDetailsLink();
		validateAccountDetailsPage(accountName);

	}
	
	public int accountBalanceAlert(String emailAddr) {
		BPCommonPage bpCommonPage = new BPCommonPage(driver, test);
		int faker = 0;
		int transAmount = 0;
		double calculatedValue=0;
		String currentBalance=null;
		int count=0;
		int size=driver.findElements(By.xpath("//select[@id='accountProfileSelectMemberForm:accountProfileSelectMember']//option")).size();
		System.out.println("Size value :::::::  "+size);
		
		while (faker == 0 && count<size) {
			isDisplayedThenClick(HomeMenu, "Home Page Menu");
			String accountNumber=bpCommonPage.selectAccountRandomly();
			System.out.println("account number::"+accountNumber);
			
			 String mailAlert="select is_using_electronic_reporting from m_customers where customer_no='"+accountNumber+"'";
			 String getmailAlert = connectDBAndGetValue(mailAlert,
						PropUtils.getPropValue(configProp, "sqlODSServerName"));
			 System.out.println("mailAlert::"+getmailAlert);
			 if(getmailAlert.equals("Y")) {
			bpHomePage.clickAccountDetailsLink();
			clickEditAccountDetailsbutton();
			currentBalance = accountCurrentBalance.getText();
			currentBalance = currentBalance.replace("$ ", "");
			currentBalance = currentBalance.replace(",", "");
			System.out.println("CB::" + currentBalance);
			String creditLimit = accountCreditLimit.getText();
			creditLimit = creditLimit.replace(",", "");
			System.out.println("CL::" + creditLimit);
			for (int i = 2; i < 16; i++) {
				String alertThresholdPer = driver
						.findElement(By.xpath("//select[@id='lform:alert_limit']/option[" + i + "]")).getText();
				System.out.println("AT::" + Integer.parseInt(alertThresholdPer.replace("%", "")));
				calculatedValue = Integer.parseInt(creditLimit)
						* Integer.parseInt(alertThresholdPer.replace("%", "")) / 100;
				System.out.println("CV::" + calculatedValue);
				if (calculatedValue <= Double.parseDouble(currentBalance)) {
					selectDropDownByVisibleText(driver.findElement(By.id("lform:alert_limit")), alertThresholdPer);
					faker = faker + 1;
					System.out.println("selected the dropdown");
					logPass("selected the dropdown");
					break;
				}
			}
		transAmount = (int) ( Double.parseDouble(currentBalance)- calculatedValue);
		System.out.println("TA::"+transAmount);
		isDisplayedThenEnterText(accountLimitEmailAddress, "Email Address To Send Alert", emailAddr);
		isDisplayedThenEnterText(phoneNumberField, "Phone Number", String.valueOf(fakerAPI().number().digits(10)));
		isDisplayedThenEnterText(emailAddrField, "Email Address To Send Alert", emailAddr);
		isDisplayedThenClick(saveChangesButton, "Save Button");
		String tradingName = accountTradingName.getText();
		String memberNumber = accountMemberNumber.getText();
		String validationMessage = driver.findElement(By.xpath("//div[@id='successMsg']/p")).getText();
		System.out.println("validtion message::"+validationMessage);
		System.out.println("Congratulations. Your details for" + tradingName + " (" + memberNumber+") have been successfully updated.");
		if (validationMessage.equals("Congratulations. Your details for" + tradingName + " (" + memberNumber
				+ ") have been successfully updated.")) {
			logPass("Account Details Updated");
		} else {
			logFail("Account Details Not Updated");
		}
		}
			 count=count+1;
		}
		sleep(10);
		return transAmount;
	}


}
