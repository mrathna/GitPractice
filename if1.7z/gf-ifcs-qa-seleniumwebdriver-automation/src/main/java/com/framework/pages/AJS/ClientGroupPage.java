package com.framework.pages.AJS;

import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

import com.aventstack.extentreports.ExtentTest;
import com.framework.pages.AJS.common.Common;
import com.framework.repo.Locator_IFCS;
import com.framework.util.PropUtils;
import com.framework.util.SeleniumWrappers;

public class ClientGroupPage extends Common {

	public ClientGroupPage(WebDriver driver, ExtentTest test) {
		super(driver, test);
		PageFactory.initElements(new AjaxElementLocatorFactory(driver, 15), this);
	}

	@FindBy(xpath = Locator_IFCS.COMMON_MAIN_FRAME)
	public WebElement mainFrameTitleBar;

	/** Go to Client - Online Role Permission **/

	public void gotoOnlineRolePermissionsMenu() {
		goToOnlineUsers();
		chooseSubMenuFromLeftPanel("Online", "Roles Permissions");
		sleep(5);
		//driver.navigate().refresh();
		//verifyText(mainFrameTitleBar, "Roles Permissions");
	}

	/** Verify Change/Reissue PIN for Customer Administrator **/

	public void verifyRoleAndAccess(String descriptionInTable, String roleNeedToCheck, String expectedAccess) {
		chooseOptionFromDropdown("Role", roleNeedToCheck);
		int rowCount = SeleniumWrappers.getNumberOfRows(driver);
		int matchingRow = -1;
		String description;
		int colIndexForDesc = SeleniumWrappers.getColumnNoForColumnHeader("Description", cardsTableHeaders);
		int colIndexForAcessLevel = SeleniumWrappers.getColumnNoForColumnHeader("Access Level", cardsTableHeaders);
		for (int i = 0; i < rowCount; i++) {
			description = SeleniumWrappers.getTableDataWithRowAndColumnNumber(i, colIndexForDesc, driver);
			if (description.contains(descriptionInTable)) {
				matchingRow = i;
				break; 
			}
		}
		if (matchingRow >= 0) {
			if (SeleniumWrappers.getTableDataWithRowAndColumnNumber(colIndexForAcessLevel, matchingRow, driver)
					.equalsIgnoreCase(expectedAccess)) {
				logPass("Access Control For " + descriptionInTable + " is "
						+ SeleniumWrappers.getTableDataWithRowAndColumnNumber(colIndexForAcessLevel, matchingRow, driver) + " as expected");
			} else {
				logFail("Access Control For " + descriptionInTable + " is "
						+ SeleniumWrappers.getTableDataWithRowAndColumnNumber(colIndexForAcessLevel, matchingRow, driver) + "But Expected::"
						+ expectedAccess);
			}
		} else {
			logFail("Expected: " + descriptionInTable + "not present on the table");
		}
	}
	
	/*
	Reading data from db
	 */
	public Map<String,String> readCustomerDetailsFromDB(){
		Common common = new Common(driver,test);
		return common.connectDBAndGetDBEntireRowValues("Select distinct mcu.customer_no,tr.card_no from m_customers mcu\n" +
				"inner join m_clients mcl on mcu.client_mid = mcl.client_mid \n" +
				"inner join transactions tr on mcu.customer_mid = tr.customer_mid\n" +
				"where mcu.client_mid =(Select client_mid from m_clients \n" +
				"where name ='BP Australia Pty Ltd')\n" +
				"and tr.processed_at >= mcl.processing_date - 90\n" +
				"and tr.card_no like '7%'\n" +
				"and rownum = 1", PropUtils.getPropValue(configProp, "sqlODSServerName"));
	}

	public String getTransactionCountFromDB(String cardNumber){
		Common common = new Common(driver,test);
		return common.connectDBAndGetValue("select count(tr.card_no) from transactions tr \n" +
				"inner join m_customers mcu on mcu.customer_mid = tr.customer_mid\n" +
				"inner join m_clients mcl on mcu.client_mid = mcl.client_mid \n" +
				"where card_no = '"+cardNumber+"' and tr.processed_at >= mcl.processing_date - 90",PropUtils.getPropValue(configProp, "sqlODSServerName"));
	}

}
