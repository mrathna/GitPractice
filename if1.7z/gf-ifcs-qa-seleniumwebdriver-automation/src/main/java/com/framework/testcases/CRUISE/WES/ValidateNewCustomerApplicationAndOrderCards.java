package com.framework.testcases.CRUISE.WES;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.WES.Cruise.CruiseApplicationPage;
import com.framework.pages.WES.Cruise.CruiseCardsPage;
import com.framework.pages.WES.Cruise.CruiseHomePage;
import com.framework.pages.WES.common.CommonPage;
import com.framework.pages.WES.common.LoginPage;

public class ValidateNewCustomerApplicationAndOrderCards extends BaseTest {

	@DataProvider(name = "Parameters")
	public static String[][] parameters() {

			String clientName = "WES";			
			return new String[][] {	
			{ "Esso", "1", "", clientName,"ShortApplication","Cheque" }//,
//			{ "EDC", "1", "", clientName,"ShortApplication","Cheque" },
//			{ "UK Fuels", "1", "", clientName,"ShortApplication","Cheque" },
//			{ "Esso", "3", "same", clientName,"ShortApplication","Cheque" },
//			{ "EDC", "3", "same", clientName,"ShortApplication","Cheque" },
//			{ "UK Fuels", "3", "same", clientName,"ShortApplication","Cheque" },
//				
//			{ "", "3", "different", clientName,"Long application","Bank Transfer" },
//			{ "", "3", "different", clientName,"Long application","Cheque" },
//			{ "", "3", "different", clientName,"Lite application","Bank Transfer" },
//			{ "", "3", "different", clientName,"Lite application","Cheque" },
//			{ "", "3", "different", clientName,"Short application","Bank Transfer" },
//			{ "", "3", "different", clientName,"Short application","Cheque" },
//			{ "", "3", "different", clientName,"Long application","Bank Details" },
//			{ "", "3", "different", clientName,"Lite application","Bank Details" },
//			{ "", "3", "different", clientName,"Short application","Bank Details" }
				
			};
	}

	@Test(groups = { "Regression" }, dataProvider = "Parameters")
	public void validateCreateApplicationAndOrderCards(String cardType, String cardCount, String type,
			String clientName,String applType,String paymentType) {

		int countOfCards = Integer.valueOf(cardCount);

		if (countOfCards == 1) {
			test = extent.createTest(
					"Create an application and order single " + cardType + " card through CRUISE and verify it in IFCS",
					"Create a single application");
		} else if (countOfCards > 1 && type.equals("same")) {
			test = extent.createTest(clientName+ ":   Create an application and order multiple " + cardType
					+ " cards through CRUISE and verify it in IFCS", "Create multiple for same card");
		} else if (countOfCards == 3 && type.equals("different") && applType.contains("application")) {
			test = extent.createTest(
					"Create a "+applType+" with Pay By "+paymentType+" option  and order multiple Esso,EDC & UK Fuels cards through CRUISE and verify it in IFCS",
					"Create multiple for different cards");
		}
		LoginPage loginPage = new LoginPage(driver, test);
		CruiseHomePage homePage = new CruiseHomePage(driver, test);
		CruiseApplicationPage applicationPage = new CruiseApplicationPage(driver, test);
		CommonPage commonPage = new CommonPage(driver, test);
		CruiseCardsPage cardsPage = new CruiseCardsPage(driver, test);

	/*	// Login the Application
		loginPage.loginWES("Cruise_URL", "Cruise_UN_Sales_User_" + clientName, "Cruise_PWD_Sales_User_" + clientName,
				"CRUISE");

		homePage.goToHomeAndChooseSubmenu("Add New Customer");
		applicationPage.createNewEDCOrUKOrESSOCards(cardType, countOfCards, type, applType);
		// getting the reference number from latest pdf downloaded
		String refNumFromPDF = applicationPage.getReferenceNumberFromPDFFileDownloaded();
		
	// Search Reference Number and fill mandatory fields in Edit Application
		homePage.ValidateRefNumberInUnreturnedTab(refNumFromPDF);
		applicationPage.fillMandatoryForCreatedCustomer(paymentType);

		// validate Card Status has changed
		commonPage.validateCreditStatusChanged(refNumFromPDF, "Pending Security Checks", "Edit Application");
		applicationPage.editCreditStatusFuelCardApplication(paymentType);
		commonPage.validateCreditStatusChanged(refNumFromPDF, "Awaiting Assignment", "Application Summary");		
		loginPage.logoutTheApplication("Cruise");*/
		
		
		String refNumFromPDF = "16811";
		// Login Credit User
		loginPage.loginWES("Cruise_URL", "Cruise_UN_Credit_User_" + clientName,
				"Cruise_PWD_Credit_User_" + clientName, "CRUISE");
		homePage.assignRefNoInUnassignCheckTab(refNumFromPDF);
		homePage.assignRefNoInMyCreditCheckTab(refNumFromPDF);
		applicationPage.validateMyCreditCheckAndEnterDecisionDetails(refNumFromPDF);
		loginPage.logoutTheApplication("Cruise");

		// Login Card User
		loginPage.loginWES("Cruise_URL", "Cruise_UN_Cards_User_" + clientName, "Cruise_PWD_Cards_User_" + clientName,
				"CRUISE");
		cardsPage.validateCardsPage();
		String applicationName = cardsPage.verifyRunCardOrder(refNumFromPDF);
		loginPage.logoutTheApplication("Cruise");
		
		// DB Validation
		commonPage.getTheNewlyCreatedCustomerNo(applicationName);
		if (countOfCards == 1) {
			commonPage.getTheNewlyCreatedCardNo(applicationName,1);
		}else
			commonPage.getTheNewlyCreatedCardNo(applicationName,3);
		
	}
		
	@AfterMethod(alwaysRun=true)
	public void clearCookies() {
		  driver.manage().deleteAllCookies();
	}
	

	
}
