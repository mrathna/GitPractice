using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using Common;
using Common.PageObjects;
using Common.ScenarioConfigurations;
using Common.Utility;

namespace EnCompass.Testing.Source.PageObjects.Organization.Admin.Proxy 
{
	/// <summary>
	/// Auto-generated Page Model Class
	/// Navigation Paths: 
		/// [Organization Home]->Administration->Proxies->User Proxies
		/// </summary>
	[PageModel(@"/admin/proxy/UserProxy.aspx")]
	public partial class UserProxy : EnCompassOrgPageModel 
	{
		public override string RelativeUrl => @"/admin/proxy/UserProxy.aspx";
		public override string PageIdentifierXPath_Generated => @"//li[contains(@class, 'breadcrumb-item active')][text() = 'User Proxies']";

		#region Navigation
				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Create Proxy']")]
		private IWebElement _administration_Proxies_UserProxies_CreateProxy { get; set; }
		public void NavigateTo_Administration_Proxies_UserProxies_CreateProxy()
		{
			NavigateToMenuItem(_administration_Proxies_UserProxies_CreateProxy);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='User Proxies']")]
		private IWebElement _administration_Proxies_UserProxies_UserProxies { get; set; }
		public void NavigateTo_Administration_Proxies_UserProxies_UserProxies()
		{
			NavigateToMenuItem(_administration_Proxies_UserProxies_UserProxies);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Card Proxies']")]
		private IWebElement _administration_Proxies_UserProxies_CardProxies { get; set; }
		public void NavigateTo_Administration_Proxies_UserProxies_CardProxies()
		{
			NavigateToMenuItem(_administration_Proxies_UserProxies_CardProxies);
		}

		
		private void NavigateToMenuItem(IWebElement element)
		{
			Driver.Url = element.GetAttribute("href");
		}
		#endregion

		public UserProxy(GlobalSettings settings) : base(settings) { }
	}  
}
