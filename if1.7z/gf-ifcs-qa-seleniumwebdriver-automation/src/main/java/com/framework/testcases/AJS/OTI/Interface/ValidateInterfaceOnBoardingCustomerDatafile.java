package com.framework.testcases.AJS.OTI.Interface;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.common.IFCSCommonPage;
import com.framework.pages.AJS.common.IFCSLoginPage;
import com.framework.pages.AJS.common.InterfacePage;


public class ValidateInterfaceOnBoardingCustomerDatafile extends BaseTest {
	@Parameters({ "clientCountry", "clientName" })
	@Test(priority = 1)
	public void validateOnBoardingCustomersAndPrepareDataFile(@Optional("BW") String clientCountry, @Optional("OTI") String clientName) throws Exception {
		test = extent.createTest(clientName+ ":" +clientCountry+"  10 Automatic onboarding of customers-Prepare Data files","Validate Automatic onboarding of  customers and prepare data files");
		
		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		
		
		IFCSCommonPage ifcsCommonPage = new IFCSCommonPage(driver, test);
		InterfacePage interfacePage = new InterfacePage(driver,test);
		
		
		//IFCSloginPage.login("IFCS_URL_OTI", "IFCS_OTI_USERNAME", "IFCS_OTI_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
	
		//Getting Local file  Path from InputfileTemplate
		String fileNamePath = interfacePage.getOutgoingCopyExcelFilePath("OutgoingFile",clientCountry+"_Onboarding.xlsx");
		
	
		interfacePage.onboardCustomerDetails(fileNamePath);
		
		
		String folderName = ifcsCommonPage.getControlMFolder(clientName, clientCountry, "jobS_OTI_Onboarding");
        String jobsInOrder =  ifcsCommonPage.getJobsOfFolderInOrder("jobS_OTI_Onboarding");
        
        // Executing control-m jobs
		interfacePage.establishAndExecuteControlMJobs("ControlM_AWS_UAT","ContorlM_AWS_userName","ContorlM_AWS_password",folderName,jobsInOrder);
		
		// Put File Name from IE Server
		ifcsCommonPage.establishThePuttyConnection("OutgoingFile", "PUTTY_HOST", "PUTTY_USERNAME", "PUTTY_PASSWORD", "OTI_OUTGOING_FILE", fileNamePath);
		
		
			
	}
}