package com.framework.testcases.OLS.CHEV.Customer.ReadWrite;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.CHEV.CHAccountMaintenancePage;
import com.framework.pages.CHEV.CHCardListPage;
import com.framework.pages.CHEV.CHContactUsPage;
import com.framework.pages.CHEV.CHHomePage;
import com.framework.pages.CHEV.CHOrderCardPage;
import com.framework.pages.CHEV.CHPasswordMaintenancePage;
import com.framework.pages.CHEV.CHStoredReportsPage;
import com.framework.pages.CHEV.CHTransactionPage;
import com.framework.pages.CHEV.CHTransactionSummaryPage;
import com.framework.pages.OLS.common.CommonPage;
import com.framework.pages.OLS.common.LoginPage;

public class ValidateOLSAllPagesExceptCardsMenu extends BaseTest {
	@Parameters({ "clientCountry", "clientName" })
	@Test(priority = 1)
	public void testCustomerReadWriteOLSAllPagesExceptCardsMenu(@Optional("SG") String clientCountry, @Optional("CHV") String clientName) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  Read or Write Only OLS - All Pages except cards menu", "Chevron Customer Screens Read or Write Only");

		LoginPage loginPage = new LoginPage(driver, test);
		if (clientCountry.equals("SG")||clientCountry.equals("MY")||clientCountry.equals("HK")) {
			loginPage.Login("CHV_URL", "CHV_Customer_UN_RW_ONLY_"+clientCountry, "CHV_Customer_PWD_RW_ONLY_"+clientCountry, "CHV");
		} else if (clientCountry.equals("TH")) {
			loginPage.Login("CHV_URL", "CHV_Customer_UN_"+clientCountry, "CHV_Customer_PWD_"+clientCountry, "CHV");
		} else if (clientCountry.equals("PH")) {
			loginPage.Login("CHV_URL", "CHV_Customer_UN_"+clientCountry, "CHV_Customer_PWD_"+clientCountry, "CHV");
		}

		CHHomePage chHomePage = new CHHomePage(driver, test);
		CHCardListPage cardListPage = new CHCardListPage(driver, test);
		CHOrderCardPage orderCardPage = new CHOrderCardPage(driver, test);
		CHTransactionPage chTransactionPage = new CHTransactionPage(driver, test);
		CHAccountMaintenancePage accountMaintenancePage = new CHAccountMaintenancePage(driver, test);
		CHTransactionSummaryPage chTransactionSummaryPage = new CHTransactionSummaryPage(driver, test);
		CHStoredReportsPage chStoredReportsPage = new CHStoredReportsPage(driver, test);
		CHPasswordMaintenancePage chPasswordMaintenancePage = new CHPasswordMaintenancePage(driver, test);
		CHContactUsPage chContactUsPage = new CHContactUsPage(driver, test);
		CommonPage commonPage = new CommonPage(driver, test);
		chHomePage.verifyHelpLinkandClick();
		chHomePage.loadFindAndClickOnOrderCard();

		chHomePage.clickOnHome();

		chHomePage.findAndClickOrderCardQuickLink();
		orderCardPage.verifyOrderCardPageTitle();
		chHomePage.clickOnHome();

		chHomePage.findAndClickCardStatusQuickLink();
		cardListPage.verifyCardPageTitle();
		chHomePage.clickOnHome();

		chHomePage.findAndClickCardsQuickLink();
		cardListPage.verifyCardPageTitle();
		chHomePage.clickOnHome();

		chHomePage.findAndClickTransactionQuickLink();
		chTransactionPage.verifyTransactionPage();
		chHomePage.clickOnHome();

		chHomePage.findAndClickExportTransactionQuickLink();
//		chHomePage.checkForFileDownload(1);
		String checkFileDate=chHomePage.validateDateInDownloadedFile();
		commonPage.isFileDownloaded(checkFileDate);

		chHomePage.verifyUserNameAndLogoutLink();
		chHomePage.verifyExportAccountLink();
		chHomePage.loadFindAndUpdateAccountmaintenancePage();

		accountMaintenancePage.verifyIfFieldsAreEditable();

		accountMaintenancePage.verifyAddressTitles();
		chHomePage.loadFindAndTransactionsPage();
		chTransactionPage.verifySearchButtons();
		chTransactionPage.verifyExportButtons();

		// TODO PASS credit card number from DB or taken
		//chTransactionPage.enterCardNumberAndSearch();
		chTransactionPage.verifyTransactionListHeaders();
		// TODO Uncomment this when credit card number is fetched either from DB or
		// given

//		chTransactionPage.clickOnCreditCardNumber();

		chTransactionSummaryPage.verifyPageTitle();

		chHomePage.loadFindAndUpdateStoredReportsPage();
		chStoredReportsPage.verifyPageTitle();
		chStoredReportsPage.verifyPageSubTitles();
		chStoredReportsPage.searchResultsTableHeaders();
		chStoredReportsPage.verifySearchButtons();
		chStoredReportsPage.verifyExportButtons();
		chHomePage.loadFindAndFindPasswordPage();
		chPasswordMaintenancePage.verifyPageSubtitles();
//		chHomePage.loadFindAndContactUsPage(); // 404 Error on Contact us 
//		String parentWindow = driver.getWindowHandle();
//		chHomePage.clickOnPrivacyStatement();
//		chHomePage.verifyWindows();
//
//		// TODO Switching window has to be removed when the privacy statement doesn't
//		// open new window and also check pdf values when site is updated
//		chHomePage.switchToNewWindow(parentWindow, driver.getWindowHandles());
//		chHomePage.closeChildAndMoveToParent(parentWindow);

		chContactUsPage.verifySubscribeBtn();
		chHomePage.verifyCloseAccountMenu();
		loginPage.Logout();

	}

}
