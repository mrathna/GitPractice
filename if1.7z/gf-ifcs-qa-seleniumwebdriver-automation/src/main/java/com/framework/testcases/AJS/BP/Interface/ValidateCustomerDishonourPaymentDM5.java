package com.framework.testcases.AJS.BP.Interface;

import java.util.ArrayList;

import javax.xml.transform.TransformerException;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.common.Common;
import com.framework.pages.AJS.common.CommonInterfacePage;
import com.framework.pages.AJS.common.IFCSCommonPage;
import com.framework.pages.AJS.common.IFCSHomePage;
import com.framework.pages.AJS.common.IFCSLoginPage;
import com.framework.util.PropUtils;

public class ValidateCustomerDishonourPaymentDM5 extends BaseTest {
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "Smoke" , "Regression"})
	public void ValidateDM3Payment(@Optional("AU") String clientCountry, @Optional("BP") String clientName) throws TransformerException {

		test = extent.createTest(clientName+ ":" +clientCountry+"  BP_DM5 CustomerDishonourPayments",
				"BP_DM5 CustomerDishonourPayments");
		// creating object for the Pages
		String PaymentAmount ="60";		
		float accBalAfter,accBalBefore;
		String Paymentfee;
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		CommonInterfacePage commonInterfacePage = new CommonInterfacePage(driver, test);
		Common common = new Common(driver, test);
		IFCSCommonPage ifcsCommonPage = new IFCSCommonPage(driver, test);
		String  clientNameInProp = PropUtils.getPropValue(configProp, clientName + "_" + clientCountry);
		System.out.println(clientNameInProp);		
		String CustomerNum = commonInterfacePage.funcFetchCustomerNoFromIFCSDBForBP(configProp, clientNameInProp);		
		String accoAvailableBalBefore=common.getAccAvailableBalance(configProp, CustomerNum);
		accBalBefore = Float.parseFloat(accoAvailableBalBefore);
		ArrayList<String> RefNum = ifcsCommonPage.updateValuesInPaymentXML(CustomerNum,clientNameInProp,clientCountry,"ns0:DishonorDetails");
		System.out.println((RefNum));
		IFCSloginPage.login("IFCS_URL_BP", "IFCS_BP_USERNAME", "IFCS_BP_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, " ");
		IFCSHomePage.gotoClientMenuAndChooseClient(clientNameInProp);
		if(clientCountry.equalsIgnoreCase("AU"))  {
		common.clientBatchJobExecution("RM_GSD_0165");
		}else {common.clientBatchJobExecution("RM_GSD_0173");}
		
		Paymentfee=ifcsCommonPage.validatePaymentandFee(configProp, RefNum);
		String accoAvailableBalAfter=common.getAccAvailableBalance(configProp, CustomerNum);
		accBalAfter  = Float.parseFloat(accoAvailableBalAfter);		
		common.validateDishonourvalue(PaymentAmount,accBalAfter,accBalBefore,Paymentfee);
		IFCSHomePage.exitIFCSwithoutValidation();	
	}
	}
