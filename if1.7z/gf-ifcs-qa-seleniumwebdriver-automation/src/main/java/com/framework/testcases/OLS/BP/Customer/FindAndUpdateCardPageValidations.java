package com.framework.testcases.OLS.BP.Customer;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.BP.BPHomePage;
import com.framework.pages.OLS.common.BPCommonPage;
import com.framework.pages.OLS.common.CommonPage;
import com.framework.pages.OLS.common.FindAndUpdateCardPage;
import com.framework.pages.OLS.common.LoginPage;

//Updated By Nithya 04-05-2018
public class FindAndUpdateCardPageValidations extends BaseTest {
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "Smoke", "Regression","BusinessFlow" })
	public void View_Card_Transactions(@Optional("AU") String clientCountry, @Optional("BP") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  BP Find And Update Card Page Popup Validation",
				"Validate the menu options in update card");
		LoginPage loginPage = new LoginPage(driver, test);
		BPHomePage bpHomePage = new BPHomePage(driver, test);
		if(clientName.equals("BP")) {
			loginPage.Login("BP_URL", "BP_UN_Customer_" + clientCountry, "BP_PWD_Customer_" + clientCountry, clientName);
		} else {
			loginPage.Login("BPPREPAID_URL", "BPPREPAID_UN_Customer_" + clientCountry, "BPPREPAID_PWD_Customer_" + clientCountry, clientName);
		}
		bpHomePage.ValidateBPCustomerLogo();
		BPCommonPage bpCommonPage = new BPCommonPage(driver, test);
		FindAndUpdateCardPage findCardPage = new FindAndUpdateCardPage(driver, test);
		CommonPage commonPage=new CommonPage(driver,test);

		// **View Card Transaction
		// Choose a Account
		/*bpCommonPage.selectAccount();

		// Load Find And Update Card Page
		bpHomePage.loadFindAndUpdateCardPage();

		findCardPage.selectAccountFromFindUpdateCardPage();

		// Search Cards
		findCardPage.clickSearchCard();

		// Select View Transactions from Card Menu
		findCardPage.clickViewTransactionsAndVerifyHeaderTitle();
		findCardPage.checkCardNumberInTransactionPage();

		// ** View Card Transaction from Menu Popup
		// Choose a Account
		bpCommonPage.selectAccount();

		// Load Find And Update Card Page
		bpHomePage.loadFindAndUpdateCardPage();

		findCardPage.selectAccountFromFindUpdateCardPage();
		
		// Go to Card and View Card Status
		findCardPage.viewCardStatus("Active");
		findCardPage.viewCardStatus("Deleted");
		findCardPage.viewCardStatus("Expired");
		findCardPage.viewCardStatus("Lost");
		findCardPage.viewCardStatus("Stolen");
		findCardPage.viewCardStatus("Temp");
		
		// ** Edit Card
		// Choose a Account
		bpCommonPage.selectAccount();

		// Load Find And Update Card Page
		bpHomePage.loadFindAndUpdateCardPage();
		findCardPage.selectAccountFromFindUpdateCardPage();

		// Search Cards
		findCardPage.clickSearchCard();

		// Select Go To from Card Menu
		findCardPage.clickGoToCardAndVerifyHeaderTitle();
		findCardPage.checkCardNumberInViewCardPage();

		// Select View Card Transactions from dropdown
		findCardPage.selectCardOptionInViewCardAndVerify("Edit Card", "Edit Card");
		findCardPage.checkCardNumberInEditCardPage();*/

		// **Change Status
		/*// Choose a Account
		bpCommonPage.selectAccount();

		// Load Find And Update Card Page
		bpHomePage.loadFindAndUpdateCardPage();

		findCardPage.changeCardStatus("Deleted");
		findCardPage.changeCardStatus("Lost");
		findCardPage.changeCardStatus("Stolen");
		findCardPage.changeCardStatus("Temp");*/

		// **Change PIN
		bpCommonPage.selectAccount();

		// Load Find And Update Card Page
		bpHomePage.loadFindAndUpdateCardPage();

		findCardPage.selectAccountFromFindUpdateCardPage();

		// Search Cards
		findCardPage.clickSearchCard();
		commonPage.changeSearchListIntoAscendingOrder();

		// Select Go To from Card Menu
		findCardPage.clickGoToCardAndVerifyHeaderTitle();
		findCardPage.checkCardNumberInViewCardPage();
	
		// Select View Card Transactions from dropdown
		findCardPage.selectCardOptionInViewCardAndVerify("Change PIN", "Change PIN");
		findCardPage.checkCardNumberInChangePINPage();

		// **Resend PIN
		// Choose a Account
		bpCommonPage.selectAccount();

		// Load Find And Update Card Page
		bpHomePage.loadFindAndUpdateCardPage();

		findCardPage.selectAccountFromFindUpdateCardPage();

		// Search Cards
		findCardPage.clickSearchCard();
		commonPage.changeSearchListIntoAscendingOrder();

		// Select Go To from Card Menu
		findCardPage.clickGoToCardAndVerifyHeaderTitle();
		findCardPage.checkCardNumberInViewCardPage();

		// Select View Card Transactions from dropdown
		findCardPage.selectCardOptionInViewCardAndVerify("Resend PIN", "Resend PIN"); 

		// ** Reissue Card
		// Choose a Account
		bpCommonPage.selectAccount();

		// Load Find And Update Card Page
		bpHomePage.loadFindAndUpdateCardPage();

		// View Re-issue Card
		findCardPage.viewReissueCard("Active","Both");
		findCardPage.viewReissueCard("Active","Driver");
		findCardPage.viewReissueCard("Active","Vehicle"); 

		//Reissue Card
		findCardPage.reissueCard("Active",clientCountry);
		findCardPage.reissueCard("Deleted",clientCountry);
		findCardPage.reissueCard("Lost",clientCountry);
		findCardPage.reissueCard("Stolen",clientCountry);
		findCardPage.reissueCard("Temp",clientCountry);
		
		loginPage.Logout();
	}

	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "Regression" ,"BusinessFlow"})
	public void checkExportCards(@Optional("AU") String clientCountry, @Optional("BP") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  BP Customer ", "Check the Export Card functionality");
		LoginPage loginPage = new LoginPage(driver, test);
		BPHomePage bpHomePage = new BPHomePage(driver, test);
		if(clientName.equals("BP")) {
			loginPage.Login("BP_URL", "BP_UN_Customer_" + clientCountry, "BP_PWD_Customer_" + clientCountry, clientName);
		} else {
			loginPage.Login("BPPREPAID_URL", "BPPREPAID_UN_Customer_" + clientCountry, "BPPREPAID_PWD_Customer_" + clientCountry, clientName);
		}
		bpHomePage.ValidateBPCustomerLogo();
		BPCommonPage bpCommonPage = new BPCommonPage(driver, test);
		FindAndUpdateCardPage findCardPage = new FindAndUpdateCardPage(driver, test);

		// **Export Card
		// Choose a Account
		bpCommonPage.selectAccount();
		// Load Find And Update Card Page
		bpHomePage.loadFindAndUpdateCardPage();

		// Select All Accounts option from the Account drop down ValidateExportCards
		findCardPage.selectAccountFromFindUpdateCardPage();

		// Search Cards
		findCardPage.clickSearchCard();
		findCardPage.exportCardToExcelInFindUpdateCardPage();
		loginPage.Logout();

	}
	
	

}
