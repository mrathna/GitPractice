﻿using Common;
using Common.Utility;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NFluent;

namespace EnCompass.Testing.Source.PageObjects.Organization.ExpenseManager.PurchaseLog
{
	[PageModel(@"/expenseManager/PurchaseLog/PurchaseLogCreateExtended.aspx")]

	public partial class PurchaseLogCreateExtended: EnCompassOrgPageModel
	{
		public override string RelativeUrl => @"/expenseManager/PurchaseLog/PurchaseLogCreateExtended.aspx";
		public override string PageIdentifierXPath_Generated => @"//div[@class='crumb_selected_content'][text() = 'Create Purchase Log']";

		public PurchaseLogCreateExtended(GlobalSettings settings) : base(settings) { }

        #region XPath page Elements
        private const string _cardNumberXpath =@"//input[contains(@id, 'AccountText')]";
        private const string _vehicleNumberXpath = @"//input[contains(@id, 'VehicleIdText')]";
        private const string _checkAccountBtnXpath = @"//input[contains(@id, 'CheckAccountButton')]";
        private const string _transactionDateXpath = @"//input[contains(@id, 'ServiceDateText')]";
        private const string _licensePalteXpath = @"//input[contains(@id, 'DriverIdText')]";
        private const string _odoMeterXpath = @"//input[contains(@id, 'OdometerText')]";
        private const string _cardExpirationXpath = @"//input[contains(@id, 'ExpirationDateText')]";
        private const string _partsAndServiceXpath = @"//input[contains(@id, 'ProductTypeAmount')]/../preceding-sibling::td/label[contains(text(), 'Parts and Service')]/../following-sibling::td/input";
        private const string _fuelXpath = @"//input[contains(@id, 'ProductTypeAmount')]/../preceding-sibling::td/label[contains(text(), 'Fuel')]/../following-sibling::td/input";
        private const string _quickLubeXpath = @"//input[contains(@id, 'ProductTypeAmount')]/../preceding-sibling::td/label[contains(text(), 'Quick Lube')]/../following-sibling::td/input";
        private const string _roadSideXpath = @"//input[contains(@id, 'ProductTypeAmount')]/../preceding-sibling::td/label[contains(text(), 'Roadside')]/../following-sibling::td/input";
        private const string _oilAndFluidsXpath = @"//input[contains(@id, 'ProductTypeAmount')]/../preceding-sibling::td/label[contains(text(), 'Oil and Fluids')]/../following-sibling::td/input";
        private const string _laborXpath = @"//input[contains(@id, 'ProductTypeAmount')]/../preceding-sibling::td/label[contains(text(), 'Labor')]/../following-sibling::td/input";
        private const string _merchantPhoneNumberXpath = @"//input[contains(@id, 'Phone_txtPhone')]";
        private const string _submitBtnXpath = @"//input[contains(@id, 'CompleteButton')]";
        private const string _cancelBtnXpath = @"//input[contains(@id, 'CancelButton')]";
        private const string _workOrderTextXpath = @"//span[contains(@id, 'WorkOrder')]";
        private const string _authorizingEmployeeNameXpath= @"//input[contains(@id, 'AmountOverAuthNameText')]";
        private const string _taxAmountTextXpath= @"//table[@role='presentation']/tbody/tr/td[@style]";
        private const string _emergencySubmitBtnXpath = @"//input[contains(@id, 'Emergency500SubmitButton')]";
        #endregion

        #region Page Elements
        private IWebElement _cardNumber
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_cardNumberXpath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_cardNumber element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _vehicleNumber
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_vehicleNumberXpath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_vehicleNumber element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _checkAccountNumberBtn
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_checkAccountBtnXpath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_checkAccountNumberBtn element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _transactionDate
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_transactionDateXpath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_transactionDate element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _licensePlate
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_licensePalteXpath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_licensePlate element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _odometer
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_odoMeterXpath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_odometer element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _cardExpiration
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_cardExpirationXpath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_cardExpiration element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _partsAndService
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_partsAndServiceXpath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_partsAndService element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _fuel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_fuelXpath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_fuel element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _quickLube
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_quickLubeXpath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_quickLube element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _roadSide
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_roadSideXpath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_roadSide element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _oilAndFluids
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_oilAndFluidsXpath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_oilAndFluids element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _labor
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_laborXpath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_labor element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _merchantPhoneNumber
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_merchantPhoneNumberXpath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_merchantPhoneNumber element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _submitBtn
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_submitBtnXpath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_submitBtn element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _cancelBtn
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_cancelBtnXpath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_cancelBtn element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _workOrderText
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_workOrderTextXpath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_workOrderText element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _authorisingEmployeeName
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_authorizingEmployeeNameXpath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_authorisingEmployeeName element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _taxAmountText
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_taxAmountTextXpath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_taxAmountText element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _emergencySubmitBtn
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_emergencySubmitBtnXpath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_emergencySubmitBtn element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        #endregion
        public string CardNumber { set { _cardNumber.Clear(); _cardNumber.SendKeys(value); } }
		public string VehicleNumber { set { _vehicleNumber.Clear(); _vehicleNumber.SendKeys(value); } }
		public string TransactionDate { set { _transactionDate.Clear(); _transactionDate.SendKeys(value); } }
		public void CheckAccount()
		{
			_checkAccountNumberBtn.JSClickWithFocus(Driver);
			WaitForLoad();
		}

		public string LicensePlate { set { _licensePlate.Clear(); _licensePlate.SendKeys(value); } }
		public string Odometer { set { _odometer.Clear(); _odometer.SendKeys(value); } }
		public string CardExpiration { set { _cardExpiration.Clear(); _cardExpiration.SendKeys(value); } }
		public string PartsAndService { set { _partsAndService.Clear(); _partsAndService.SendKeys(value); } }
		public string Fuel { set { _fuel.Clear(); _fuel.SendKeys(value); } }
		public string QuickLube { set { _quickLube.Clear(); _quickLube.SendKeys(value); } }
		public string Roadside { set { _roadSide.Clear(); _roadSide.SendKeys(value); } }
		public string OilAndFluids { set { _oilAndFluids.Clear(); _oilAndFluids.SendKeys(value); } }
		public string Labor { set { _labor.Clear(); _labor.SendKeys(value); } }
		public string MerchantPhoneNumber { set { _merchantPhoneNumber.Clear(); _merchantPhoneNumber.SendKeys(value); } }

		public void Submit()
		{
			_submitBtn.JSClickWithFocus(Driver);
		}

		public void Cancel()
		{
			_cancelBtn.JSClickWithFocus(Driver);
		}

		public string WorkOrder => _workOrderText.Text;

		public string AuthorizingEmployeeName { set { _authorisingEmployeeName.Clear(); _authorisingEmployeeName.SendKeys(value); } }
		public string TransactionAmountText => _taxAmountText.Text;

		public void EmergencySubmit()
		{
			_emergencySubmitBtn.JSClickWithFocus(Driver);
		}
	}
}
