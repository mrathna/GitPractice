package com.framework.testcases.AJS.SHELL;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.MaintainCustomerPage;
import com.framework.pages.AJS.common.Common;
import com.framework.pages.AJS.common.IFCSHomePage;
import com.framework.pages.AJS.common.IFCSLoginPage;

public class ValidateBlockedAccountTestCases extends BaseTest {
	/** Completed - Nithya Manikandan **/
	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test(groups = { "Regression" })
	public void ValidateReissueStolenCardForBlockedMainAccount(@Optional("RU") String clientCountry,
			@Optional("SHELL") String clientName, @Optional("APA") String cardType) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  Blocked Account", "01  Reissue a card with Stolen status");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		MaintainCustomerPage maintainCustomerPage = new MaintainCustomerPage(driver, test);
		Common commonPage = new Common(driver, test);

		IFCSloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, cardType);
		IFCSHomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);

		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		String hierarchyCreation = maintainCustomerPage.createHierarchyWithChildHavingCards("Stolen");
		if (!hierarchyCreation.equals("No Data")) {
			maintainCustomerPage.changeMainAccountStatus("B - Blocked/Suspended");
			maintainCustomerPage.setSubAccountStatusActive();
			IFCSHomePage.gotoCustomerMenuCustomerDetails();
			maintainCustomerPage.reissueACardForBlockedAccount();
			//Change Back Status As Active
			maintainCustomerPage.changeMainAccountStatus("A - Active");
		} else {
			commonPage.logForNoDataFound(this.getClass().getSimpleName(),
					"Expected data not present for hierarchy creation");
		}

		IFCSHomePage.exitIFCS();

	}

	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test(groups = { "Regression" })
	public void ValidateCardStatusStolenAndNoReplace(@Optional("RU") String clientCountry,
			@Optional("SHELL") String clientName, @Optional("APA") String cardType) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  Blocked Account",
				"02  Update the card status to Stolen - Select -No- to Replace Card");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		MaintainCustomerPage maintainCustomerPage = new MaintainCustomerPage(driver, test);

		IFCSloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, cardType);
		IFCSHomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);
		Common commonPage = new Common(driver, test);
		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		String hierarchyCreation = maintainCustomerPage.createHierarchyWithChildHavingCards("Active");
		if (!hierarchyCreation.equals("No Data")) {
			maintainCustomerPage.changeMainAccountStatus("B - Blocked/Suspended");
			maintainCustomerPage.setSubAccountStatusActive();
			IFCSHomePage.gotoCustomerMenuCustomerDetails();
			maintainCustomerPage.changeCardStatusForBlockedAccountAndValidate("no-replace");
			maintainCustomerPage.changeMainAccountStatus("A - Active");
		} else {
			commonPage.logForNoDataFound(this.getClass().getSimpleName(),
					"Expected data not present for hierarchy creation");
		}
		IFCSHomePage.exitIFCS();

	}

	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test(groups = { "Regression" })
	public void ValidateCardStatusStolenAndReplace(@Optional("RU") String clientCountry,
			@Optional("SHELL") String clientName, @Optional("APA") String cardType) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  Blocked Account",
				"02  Update the card status to Stolen - Select -Yes- to Replace Card");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		MaintainCustomerPage maintainCustomerPage = new MaintainCustomerPage(driver, test);

		IFCSloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, cardType);
		IFCSHomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);
		Common commonPage = new Common(driver, test);
		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		String hierarchyCreation = maintainCustomerPage.createHierarchyWithChildHavingCards("Active");
		if (!hierarchyCreation.equals("No Data")) {
			maintainCustomerPage.changeMainAccountStatus("B - Blocked/Suspended");
			maintainCustomerPage.setSubAccountStatusActive();
			IFCSHomePage.gotoCustomerMenuCustomerDetails();
			maintainCustomerPage.changeCardStatusForBlockedAccountAndValidate("replace");
			maintainCustomerPage.changeMainAccountStatus("A - Active");
		}else {
			commonPage.logForNoDataFound(this.getClass().getSimpleName(),
					"Expected data not present for hierarchy creation");
		}
		IFCSHomePage.exitIFCS();

	}

	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test(groups = { "Regression" } )
	public void ValidateOrderNewCardForBlockedAccount(@Optional("RU") String clientCountry,
			@Optional("SHELL") String clientName, @Optional("APA") String cardType) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  Blocked Account", "04  Order a new Card for a sub account");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		MaintainCustomerPage maintainCustomerPage = new MaintainCustomerPage(driver, test);

		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		IFCSloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, cardType);
		IFCSHomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);
		Common commonPage = new Common(driver, test);
		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		String hierarchyCreation = maintainCustomerPage.createHierarchyWithChild();
		if (!hierarchyCreation.equals("No Data")) {
			maintainCustomerPage.changeMainAccountStatus("B - Blocked/Suspended");
			maintainCustomerPage.setSubAccountStatusActive();
			IFCSHomePage.gotoCustomerMenuCustomerDetails();
			maintainCustomerPage.orderCardForBlockedAccountAndValidate();
			maintainCustomerPage.changeMainAccountStatus("A - Active");
		}else {
			commonPage.logForNoDataFound(this.getClass().getSimpleName(),
					"Expected data not present for hierarchy creation");
		}
		IFCSHomePage.exitIFCS();

	}
}
