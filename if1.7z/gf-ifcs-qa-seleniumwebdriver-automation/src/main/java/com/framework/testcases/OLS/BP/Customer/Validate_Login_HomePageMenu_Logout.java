package com.framework.testcases.OLS.BP.Customer;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.BP.BPHomePage;
import com.framework.pages.OLS.HomePage;
import com.framework.pages.OLS.common.LoginPage;

public class Validate_Login_HomePageMenu_Logout extends BaseTest {
	@Parameters({"clientCountry","clientName"})
	@Test()
	public void Login_Homepage_Logout(@Optional("AU") String clientCountry, @Optional("BP") String clientName)  {
		test = extent.createTest(clientName+ ":" +clientCountry+"  BP Customer Login Logout", "Logging in to BP Online and Log Out from Homepage");

        //Creating Objects for the Pages
		
        LoginPage loginPage = new LoginPage(driver, test);
        BPHomePage bpHomePage = new BPHomePage(driver, test);
        HomePage homePage = new HomePage(driver, test);
        
		// Calling Functions
		loginPage.Login("BP_URL", "BP_UN_Customer_" + clientCountry, "BP_PWD_Customer_" + clientCountry, clientName);
		bpHomePage.ValidateBPCustomerLogo();
		// homePage.ValidateWelcomeText();
		homePage.ValidateLogoutLink();
		// homePage.ValidateQuickLinks();
		homePage.ValidateHelpLink();
		// homePage.ValidateAccountsMenu();
		homePage.HomePageValidation();
		// homePage.ValidateCustomerNameLabel();
		// homePage.ValidateCustomerName();
	
        
		loginPage.Logout();
        
	}

	
}
