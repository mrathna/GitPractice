using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using Common;
using Common.PageObjects;
using Common.ScenarioConfigurations;
using Common.Utility;

namespace EnCompass.Testing.Source.PageObjects.SuperAdmin.MccGroup 
{
	/// <summary>
	/// Auto-generated Page Model Class
	/// Navigation Paths: 
		/// [Organization Home]->Merchant Category Codes->Global Groups
		/// </summary>
	[PageModel(@"/superAdmin/mccGroup/Global.aspx")]
	public partial class Global : EnCompassSuperPageModel 
	{
		public override string RelativeUrl => @"/superAdmin/mccGroup/Global.aspx";
		public override string PageIdentifierXPath_Generated => @"//li[contains(@class, 'breadcrumb-item active')][text() = 'Global Groups']";

		#region Navigation
		
		private void NavigateToMenuItem(IWebElement element)
		{
			Driver.Url = element.GetAttribute("href");
		}
		#endregion

		public Global(GlobalSettings settings) : base(settings) { }
	}  
}
