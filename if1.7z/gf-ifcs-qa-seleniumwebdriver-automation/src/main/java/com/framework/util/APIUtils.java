package com.framework.util;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Base64;
import java.util.Date;
import java.util.List;
import java.util.Properties;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;

import com.aventstack.extentreports.ExtentTest;
import com.github.javafaker.Faker;

import io.restassured.RestAssured;
import io.restassured.config.EncoderConfig;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;


public class APIUtils {

	 public JSONObject requestParams = new JSONObject();
	    public RequestSpecification request;
	    public JsonPath jsonPathEvaluator;
	    public String fileSeparator = System.getProperty("file.separator");
	    public Response response;
	   /**
		 * Set the request header to include the authorization token
		 **/

		public Response postRequestAsBasicAuthWithBodyData(String accessToken, JSONObject reqParams, String endPoint) {

			request = RestAssured.given().config(RestAssured.config().encoderConfig(EncoderConfig.encoderConfig().appendDefaultContentCharsetToContentTypeIfUndefined(false))).header("Authorization", "Basic " + accessToken).contentType(ContentType.JSON).body(reqParams.toString()).when();

			System.out.println("Request info::"+request.log().all());

			response = request.post(RestAssured.baseURI + endPoint);

			return response;
		}

		public Response getRequestAsBearerAuth(String endPoint, Properties inputProp) {

			request = RestAssured.given().config(RestAssured.config().encoderConfig(EncoderConfig.encoderConfig().appendDefaultContentCharsetToContentTypeIfUndefined(false))).header("Authorization", "Bearer " +PropUtils.getPropValue(inputProp,"AuthorizationToken")).contentType(ContentType.JSON).when();

			//System.out.println("Request info::"+request.log().all());

			response = request.get(RestAssured.baseURI + endPoint);

			return response;
		}

		public Response getRequestWithPath(String endPoint, String path, Properties inputProp) {

			request = RestAssured.given().config(RestAssured.config().encoderConfig(EncoderConfig.encoderConfig().appendDefaultContentCharsetToContentTypeIfUndefined(false))).header("Authorization", "Bearer " + PropUtils.getPropValue(inputProp, "AuthorizationToken")).contentType(ContentType.JSON).when();

			System.out.println("Request info::"+request.log().all());

			response = request.get(RestAssured.baseURI + endPoint +path);

			return response;

		}

		public Response putRequestAsBasicAuthWithBodyData(String accessToken, JSONObject reqParams, String endPoint) {

			request = RestAssured.given().config(RestAssured.config().encoderConfig(EncoderConfig.encoderConfig().appendDefaultContentCharsetToContentTypeIfUndefined(false))).header("Authorization", "Bearer " + accessToken).contentType(ContentType.JSON).body(reqParams.toString()).when();

			System.out.println("Request info::"+request.log().all());

			response = request.put(RestAssured.baseURI + endPoint);

			return response;
		}
		
		public Response putRequestAsBearerAuthWithBodyData(String accessToken, JSONObject reqParams, String endPoint) {

			request = RestAssured.given().config(RestAssured.config().encoderConfig(EncoderConfig.encoderConfig().appendDefaultContentCharsetToContentTypeIfUndefined(false))).header("Authorization", "Bearer " + accessToken).contentType(ContentType.JSON).body(reqParams.toString()).when();

			System.out.println("Request info::"+request.log().all());

			response = request.put(RestAssured.baseURI + endPoint);

			return response;
		}

		public Response deleteRequestAsBearerAuth(String endPoint, String bearerToken) {

			request = RestAssured.given().config(RestAssured.config().encoderConfig(EncoderConfig.encoderConfig().appendDefaultContentCharsetToContentTypeIfUndefined(false))).header("Authorization", "Bearer " + bearerToken).contentType(ContentType.JSON).when();

			System.out.println("Request info::"+request.log().all());

			response = request.delete(RestAssured.baseURI + endPoint);

			return response;
		}


		public Response postRequestAsBearerAuthWithBodyData(String endPoint, JSONObject reqParams, String bearerToken) {

			request = RestAssured.given().config(RestAssured.config().encoderConfig(EncoderConfig.encoderConfig().appendDefaultContentCharsetToContentTypeIfUndefined(false))).header("Authorization", "Bearer " + bearerToken).contentType(ContentType.JSON).body(reqParams.toString()).when();
		
			System.out.println("Request info::"+request.log().all());

			response = request.post(RestAssured.baseURI + endPoint);

			return response;
		}
		
		public Response postRequestAsBearerAuthWithBodyData(String endPoint, JSONArray reqParams, String bearerToken) {

			request = RestAssured.given().config(RestAssured.config().encoderConfig(EncoderConfig.encoderConfig().appendDefaultContentCharsetToContentTypeIfUndefined(false))).header("Authorization", "Bearer " + bearerToken).contentType(ContentType.JSON).body(reqParams.toString()).when();

			System.out.println("Request info::"+request.log().all());

			response = request.post(RestAssured.baseURI + endPoint);

			return response;
		}

		public Response postRequestAsBearerAuthWithChildData(String endPoint, String reqParams, String bearerToken) {

			request = RestAssured.given().config(RestAssured.config().encoderConfig(EncoderConfig.encoderConfig().appendDefaultContentCharsetToContentTypeIfUndefined(false))).header("Authorization", "Bearer " + bearerToken).contentType(ContentType.JSON).body(reqParams).when();

//				System.out.println("Request info::"+request.log().all());

			response = request.post(RestAssured.baseURI + endPoint);

			return response;
		}
		public Response getRequestAsBasicAuthWithQueryParams(String endPoint, String accessToken, String logOnID, String url) {
		
			RestAssured.urlEncodingEnabled=false;
			request = RestAssured.given().config(RestAssured.config().encoderConfig(EncoderConfig.encoderConfig().appendDefaultContentCharsetToContentTypeIfUndefined(false))).header("Authorization", "Basic " +accessToken).contentType(ContentType.JSON).when().queryParam("username",logOnID).queryParam("url",url);
		
			System.out.println("Request info::"+request.log().all());

			response = request.get(RestAssured.baseURI + endPoint);

			return response;
		}
		
		public Response getRequestAsBasicAuthWithQueryParamsForTokenValidation(String endPoint, String accessToken, String token) {
			
			RestAssured.urlEncodingEnabled=false;
			request = RestAssured.given().config(RestAssured.config().encoderConfig(EncoderConfig.encoderConfig().appendDefaultContentCharsetToContentTypeIfUndefined(false))).header("Authorization", "Basic " +accessToken).contentType(ContentType.JSON).when().queryParam("token",token);
		
			System.out.println("Request info::"+request.log().all());

			response = request.get(RestAssured.baseURI + endPoint);

			return response;
		}
		
		public Response postRequestAsBearerAuthWithNoBodyData(String endPoint, String bearerToken) {

			request = RestAssured.given().config(RestAssured.config().encoderConfig(EncoderConfig.encoderConfig().appendDefaultContentCharsetToContentTypeIfUndefined(false))).header("Authorization", "Bearer " + bearerToken).contentType(ContentType.JSON).when();

			System.out.println("Request info::"+request.log().all());

			response = request.post(RestAssured.baseURI + endPoint);

			return response;
		}
		
		 public String base64Encoder(String Client_id, String Secret_key) {

		        String stringToEncode = Client_id + ":" + Secret_key;

		        // print String to be encoded
		        //System.out.println("String to Encode :\n" + stringToEncode);

		        // Encode into Base64 format
		        String ENCODED_STRING = Base64.getEncoder().encodeToString(stringToEncode.getBytes());

		        // print encoded String
		       // System.out.println("Actual String:\n" + ENCODED_STRING);
		        return ENCODED_STRING;
		    }
		 
		/* public boolean validateResponseData(String responseData, String key, String value) {

		        for (String validate : getValuesForGivenKey(responseData, key)) {
		            if (validate.trim().equals(value)) {
		                System.out.println("validateData::" + validate.trim() + "::value::" + value);
		                return true;
		            }
		        }
		        return false;
		    }*/
		 
		 public static Faker fakerAPI() {
		        Faker faker = new Faker();
		        return faker;
		    }
		 
		/* public List<String> getValuesForGivenKey(String jsonArrayStr, String key) {
		        JSONArray jsonArray = new JSONArray(jsonArrayStr);
		        System.out.println("Key::"+key);
		        return IntStream.range(0, jsonArray.length())
		                .mapToObj(index -> ((JSONObject)jsonArray.get(index)).optString(key))
		                .collect(Collectors.toList());
		    }
*/
		  

	public void validateResponseMessage(String actualResponse, String expectedResponse, ExtentTest log) {
		try {
			System.out.println("Actual Response is " + actualResponse + "Expected Response is " + expectedResponse);
			Assert.assertEquals(actualResponse, expectedResponse);

		} catch (AssertionError e) {
			// ExtentReportListener.testStepHandleAPI("FAIL",log,new Exception());
			throw (e);
		}

	}
		       


		    
		    public static String timeStampToEpochMillisSec(String timestamp) {
		        if (timestamp == null)
		            return null;
		        try {
		            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ");
		            Date dt = sdf.parse(timestamp);
		            long epoch = dt.getTime();
		            int milliSeconds = (int) (epoch / 1000);
		            String milliEpochSeconds = Integer.toString(milliSeconds);
		            return milliEpochSeconds;
		        } catch (ParseException e) {
		            return null;
		        }
		    }
		    
		    public Response postRequestForNoAuthWithHeadersAndBodyData(JSONObject reqParams, String endPoint,String clientMid,Properties configProp) {

		    	String userOid=PropUtils.getPropValue(configProp, "User-Oid");
				request=RestAssured.given().contentType(ContentType.JSON).header("Client-Mid", clientMid).header("User-Oid",userOid).body(reqParams.toString()).when();
				
				System.out.println("Request info::"+request.log().all());

				response = request.post(RestAssured.baseURI + endPoint);

				return response;
			}
			
		
	}

	
