
package com.framework.testcases.OLS.BP.Customer;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.BP.BPHomePage;
import com.framework.pages.OLS.common.BPCommonPage;
import com.framework.pages.OLS.common.FindAndUpdateCardPage;
import com.framework.pages.OLS.common.LoginPage;

public class ValidatePINMailer extends BaseTest {
	@Parameters({"clientCountry","clientName"})
	@Test( groups = { "Smoke","Regression" })
	public void Validate_PIN_Mailer_Resend_PIN(@Optional("AU") String clientCountry, @Optional("BP") String clientName)  {
		test = extent.createTest(clientName+ ":" +clientCountry+"  BP PIN Mailer Validation", "Checking the Resend PIN Feature");
		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		BPHomePage bpHomePage = new BPHomePage(driver, test);
		FindAndUpdateCardPage findCardPage = new FindAndUpdateCardPage(driver, test);
		BPCommonPage bpCommonPage = new BPCommonPage(driver, test);
		// Call Function
		loginPage.Login("BP_URL", "BP_UN_Customer_" + clientCountry, "BP_PWD_Customer_" + clientCountry, clientName);
		bpHomePage.ValidateBPCustomerLogo();

		// Choose a Account
		bpCommonPage.selectAccount();

		// Load Find And Update Card Page
		bpHomePage.loadFindAndUpdateCardPage();

		findCardPage.selectAccountFromFindUpdateCardPage(); 
		
		// Search Cards and give Resend PIN for active card
		findCardPage.clickSearchCard();

		// Get PIN Values from DB
		findCardPage.pickActiveCardNumber("Resend PIN");
		findCardPage.getPINValuesFromDB();

		// Resend PIN and compare values from DB
		findCardPage.pickActiveCardAndResendPIN();
		findCardPage.comparePINValues("Resend PIN");
		
		loginPage.Logout();
	}

}
