package com.framework.pages.OLS.common;

import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.ExtentTest;
import com.framework.basepage.BasePage;
import com.framework.pages.AJS.common.CommonInterfacePage;
import com.framework.repo.Locator;
import com.framework.util.PropUtils;

public class CommonPage extends BasePage {

	public CommonPage(WebDriver driver, ExtentTest test) {
		super(driver, test);
		PageFactory.initElements(driver, this);
	}

	@FindBy(how = How.ID, using = Locator.ACCOUNT_LIST)
	public WebElement accountListDropdown;

	@FindBy(how = How.ID, using = Locator.SEARCH_BTN)
	public WebElement searchbutton;

	//Added by Sasi 04/02/2019
	@FindBy(xpath=Locator.Z_ACCOUNT_STATUS)
	public WebElement accountStatus;

	@FindBy(xpath=Locator.Z_CREDIT_LIMIT)
	public WebElement creditLimit;

	@FindBy(xpath=Locator.Z_AVAILABLE_BALANCE)
	public WebElement availableBalance;

	@FindBy(xpath=Locator.Z_LAST_INVOICE_DATE)
	public WebElement lastInvoiceDate;

	@FindBy(xpath=Locator.Z_NEXT_INVOICE_DATE)
	public WebElement nextInvoiceDate;

	@FindBy(how = How.XPATH, using = Locator.CLIENT_LOGO_IMG)
	public WebElement clientLogo;

	@FindBy(how = How.ID, using = Locator.CARDSFOUND_ASCENDING)
	public WebElement cardsFoundAscending;
	
	//Added by Nithya 13/05/2020
	@FindBy (id=Locator.NEW_PASSWORD)
	public WebElement newPassword;
	
	@FindBy (id=Locator.CONFIRM_PASSWORD)
	public WebElement confirmPassword;
	
	@FindBy (id=Locator.CARD_INFORMATION_SAVECHANGES)
	public WebElement saveBtn;
	
	@FindBy (xpath=Locator.LOGIN_FORM)
	public WebElement loginForm;
		

	public void validateClientLogo() {
		isDisplayed(clientLogo, "Client logo");
	}


	public void selectAllAccountOptionFromAccountDropdown() {
		selectDropDownByVisibleText(accountListDropdown, "All Accounts");
		sleep(5);
	}

	public void clickSearchButton() {
		isDisplayedThenClick(searchbutton, "Search button");
		sleep(15);
	}

	public void clickColumnHeaderAndVerifySorting(WebElement table, String columnName) {
		WebElement columnHeaderLink;
		String colId, columnHeaderSort;
		List<WebElement> rowValues;
		try {
			if (table.isDisplayed()) {
				columnHeaderLink = table.findElement(By.xpath("./thead/tr/th/a[text()='" + columnName + "']"));
				colId = getAttribute(
						table.findElement(By.xpath("./thead/tr/th[descendant::a[text()='" + columnName + "']]")), "id");

				// Unsorted
				columnHeaderSort = getAttribute(
						table.findElement(By.xpath("./thead/tr/th/a[text()='" + columnName + "']")), "class");

				String colString = ":" + colId.split(":")[2];
				rowValues = table.findElements(By.xpath("./tbody[1]/tr//td[contains(@id, '" + colString + "')]"));

				if (rowValues.size() > 1) {
					ArrayList<String> beforeSort = getAllRowValues(rowValues);
					isDisplayedThenActionClick(columnHeaderLink, "Column Header");
					sleep(5);

					rowValues = table.findElements(By.xpath("./tbody[1]/tr//td[contains(@id, '" + colString + "')]"));

					columnHeaderSort = getAttribute(
							table.findElement(By.xpath("./thead/tr/th/a[text()='" + columnName + "']")), "class");
					ArrayList<String> afterSort = getAllRowValues(rowValues);

					logInfo("Sorting Order:" + columnHeaderSort);
					logInfo("Expected Sorting order" + beforeSort);
					logInfo("Actual Sorting order" + beforeSort);
					// Ascending
					if (columnHeaderSort.equals("ascending")) {
						Collections.sort(beforeSort);
					}
					// Descending
					else if (columnHeaderSort.equals("descending")) {
						Collections.reverse(beforeSort);
					}

					if (beforeSort.equals(afterSort)) {
						logPass("Sorting done");
					} else {
						logFail("Sorting not done");
					}

				} else {
					logInfo("Column have" + rowValues.size() + " number of row - Not applicable for sorting");
				}
			}
		} catch (Exception ex) {
			logFail(ex.getStackTrace().toString());
		}
	}
	// Added by SivsSakthi 08-02-2019
	
	public void sortThecardNumberColumnAndValidate(WebElement table, String columnName) {
		WebElement columnHeaderLink;
		String colId, columnHeaderSort;
		List<WebElement> rowValues;
		String cardNumber1;
		String cardNumber2;
		long firstCardNumber;
		long secondCardNumber;
		boolean flag = false;
		try {

			columnHeaderLink = table.findElement(By.xpath("./thead/tr/th/a[text()='" + columnName + "']"));
			colId = getAttribute(
					table.findElement(By.xpath("./thead/tr/th[descendant::a[text()='" + columnName + "']]")), "id");

			// Unsorted

			String colString = ":" + colId.split(":")[2];
			System.out.println("Col String is" + colString);
			rowValues = table.findElements(By.xpath("./tbody[1]/tr//td[contains(@id, '" + colString + "')]"));

			isDisplayedThenActionClick(columnHeaderLink, "Column Header");
			sleep(5);
			columnHeaderSort = getAttribute(table.findElement(By.xpath("./thead/tr/th/a[text()='" + columnName + "']")),
					"class");
//			setCellDataFromTable(table, 8, false);
			setCellDataFromTable(table, 7, false);

			System.out.println("size of the table is" + rowValues.size());
			if (rowValues.size() > 1) {

				for (int i = 0; i < rowValues.size() - 1; i++) {
					cardNumber1 = getCellDataFromTable(i + 1, 0, false);
					System.out.println("First Card number is" + cardNumber1);
					firstCardNumber = Long.parseLong(cardNumber1);
					cardNumber2 = getCellDataFromTable(i + 2, 0, false);
					secondCardNumber = Long.parseLong(cardNumber2);
					System.out.println("Second Card number is" + secondCardNumber);
					if (columnHeaderSort.equals("ascending")) {
						if (firstCardNumber < secondCardNumber) {
							flag = true;
						} else {
							break;
						}
					} else {
						if (firstCardNumber > secondCardNumber) {
							flag = true;
						} else {
							break;
						}
					}
				}
				if (flag) {
					logPass("Colums is sorted successfully:" + columnHeaderSort);
				} else {
					logFail("Column is not sorted successfully");
				}
			}

		}

		catch (Exception ex) {
			System.out.println("Exception is" + ex.getMessage());
			logFail(ex.getStackTrace().toString());
		}
	}

	public ArrayList<String> getAllRowValues(List<WebElement> rowValues) {
		ArrayList<String> beforeSort = new ArrayList<String>();
		for (int i = 0; i < rowValues.size(); i++) {
			if (!(getText(rowValues.get(i)).equals(""))) {
				beforeSort.add(getText(rowValues.get(i)));
			}
		}
		return beforeSort;
	}

	/**
	 * Is excel download file present
	 */
	public void isFileDownloaded(String fileName) {
		try {
			String downloadedFileName = getLatestDownloadedFileFromDir(fileName).getName();
			System.out.println("The Downloaded File Name is   " + downloadedFileName);
			logInfo("The Downloaded File Name is" + downloadedFileName);
			if (downloadedFileName.contains(fileName) || downloadedFileName.contains(fileName.replaceAll(" ", "_"))) {
				logPass(fileName + " file got downloaded");
			} else {
				logFail(fileName + " file not downloaded");
			}
		} catch (NullPointerException e) {
			logFail("Downloaded File does not exist" + e);
		}
	}
	
	
	/**
	 * Is excel download file present
	 */
	public boolean isPrivacyStatementFileDownloaded(String fileName) {
		boolean isFileDownloaded =false;
		try {
			String downloadedFileName = getLatestDownloadedFileFromDir(fileName).getName();
			System.out.println("The Downloaded File Name is   " + downloadedFileName);
			logInfo("The Downloaded File Name is" + downloadedFileName);
			if (downloadedFileName.contains(fileName) || downloadedFileName.contains(fileName.replaceAll(" ", "_"))) {
				isFileDownloaded = true;
				logPass(fileName + " file got downloaded");
			} else {
				logFail(fileName + " file not downloaded");
			}
		} catch (NullPointerException e) {
			logInfo("Downloaded File does not exist" + e);
		}
		return isFileDownloaded;
	}

	 

	/**
	 * Validate the Table Header
	 */
	public void validateTheTableHeaderTitles(WebElement table, int numberOfCols, String[] expectedHeaderValues) {
		setTableHeaderFromTable(table, numberOfCols, true);
		String[] columnValuesExpected = expectedHeaderValues;
		// Checks the presence of table header titles in order
		for (int i = 0; i < numberOfCols; i++) {
			if (columnValuesExpected[i].equals(getCellDataFromTable(0, i, true))) {
				logPass("Expected column " + columnValuesExpected[i] + " is present");
			} else {
				logFail("Expected column " + columnValuesExpected[i] + " is not present");
			}
		}
	}

	@FindBy(how = How.ID, using = Locator.CARD_INFORMATION_PIN_TEXTBOX)
	public WebElement newPIN;

	@FindBy(how = How.ID, using = Locator.CARD_INFORMATION_CONFIRM_PIN)
	public WebElement confirmPIN;

	@FindBy(how = How.ID, using = Locator.CARD_INFORMATION_SAVECHANGES)
	public WebElement saveChangeButton;

	@FindBy(how = How.ID, using = Locator.CONFIRMATIONMESSAGE)
	public WebElement confirmationMessage;

	@FindBy(how = How.ID, using = Locator.REISSUE_CARD_POPUP)
	public WebElement reissueCardPopup;

	@FindBy(how = How.ID, using = Locator.DELIVER_CONFIRM_AND_REISSUE)
	public WebElement confirmReissue;

	@FindBy(id = Locator.ACCOUNT_SEL)
	public WebElement accountList;
	
	@FindBy(how = How.ID, using = Locator.PICK_ACCOUNT_FROM_DROPDOWN)
	public WebElement accountDropdown;
	
	@FindBy(xpath = Locator.ACCOUNT_NAME_IN_HOME_PAGE)
	public WebElement accountNameInHomePage;

	private String accountPin = "";

	public void typeNewPin() {
		accountPin = String.valueOf(fakerAPI().number().numberBetween(1901, 1999));
		isDisplayedThenEnterText(newPIN, "ccount Level Pin", accountPin);
	}

	public void typeconfirmPIN() {
		isDisplayedThenEnterText(confirmPIN, "Account Level Pin", accountPin);
	}

	public void clickSaveChangesButton() {
		isDisplayedThenClick(saveChangeButton, "Save Changes Button");
		sleep(2);
	}

	public void handleReissuePopupIfPresent() {
		try {
			if (reissueCardPopup.isDisplayed()) {
				isDisplayedThenActionClick(confirmReissue, "Confirm Reissue");
				sleep(2);
				if (getText(confirmationMessage)
						.contains("You can expect to receive your new card within 5 business days.")) {
					logPass("Reissue Card with new Pin sent");
				} else {
					checkConfirmationMessage();
				}

			}
		} catch (NoSuchElementException ex) {
			checkConfirmationMessage();
		}
	  
		
		
	}

	public void checkConfirmationMessage() {
		isDisplayed(confirmationMessage, "Confirmation message");

		verifyText(confirmationMessage,
				"Congratulations. Your change of PIN has been made and will take effect at the point of sale within 2 hours.");
	}

	
	public void selectAllAccountInTransactionFilterSearch() {
		selectDropDownByVisibleText(accountList, "All Accounts");
	}

	public void selectAccountFromDropdownAndValidate() {

		isDisplayed(accountDropdown, "Account Drop down in home page");

		int size = getDropdownSize(accountDropdown);

		if (size > 1) {
			String accountName = selectedStringFrmDropDown(accountDropdown);
			System.out.println("accountNAme ---- " + accountName);
			sleep(5);
			selectDifferentValueInsteadOfDefault(accountDropdown, accountName, "");
			sleep(3);
			String accname2 = selectedStringFrmDropDown(accountDropdown);
			sleep(5);
			if (!accountName.contains(accname2)) {
				logInfo("Account 1 = " + accountName + " Different Account selected ---=" + accname2);
				logPass("Different Account Selected");
			}

			else {
				logInfo("Account 1 = " + accountName + " Different Account selected ---=" + accname2);
				logFail("Different Account is not selected");
			}
		} else {
			logInfo("accountDropdown in home page has only one option");
		}
	}
	
	public void verifyCustomerNameInHomePage() {
		String customerNameAndNo = selectedStringFrmDropDown(accountDropdown);
		if (customerNameAndNo.contains(getText(accountNameInHomePage))) {
			logPass("Same account name present in dropdown and details section");
		} else {
			logInfo("Same account name not present in dropdown and details section");
		}
	}
//Added by Sasi 04/02/2019

	public void verifyAccountStatusDetails(String accountType) {

		isDisplayed(accountStatus, "Account Status is visible");

		checkAnElementIsDisabled(accountStatus, "Account Status is not editable");
		logPass("Account Status is not editable");

		if(accountType.equals("parent")) {

			isDisplayed(creditLimit, "Credit Limit is visible");
			isDisplayed(availableBalance, "Available Balance is visible");
			isDisplayed(lastInvoiceDate, "Last Invoice Date is visible");
			isDisplayed(nextInvoiceDate, "Next Invoice Date is visible");
			logInfo("Parent Account");
		}
		else{
			logInfo("Child Account");

		}

	}
//	public void goToCardMenuCardList() { 
	//		mouseHoverClickMenuAndSubMenu("Cards", "Card List");
	//	}
	//	
	//	public void clickViewCardGoToViewCardPageAndValidate() {
	//		
	//		setCellDataFromTable(cardListTable, 9, true);
	//		//List<WebElement> rowElements =  cardListTable.findElements(By.xpath("./tbody[contains(@id,'lform:tableCardList:tb')]/tr"));
	//		//System.out.println("tableCardNumberListSize---"+rowElements.size());
	//		
	//			cardAccNo = getCellDataFromTable(1, 0, true);
	//			
	//			System.out.println("cardAccNo---"+cardAccNo); 
	//			
	//			clickCardNumber(1);
	//					
	//			clickCardTableMenuOption(viewCardMenu);
	//					
	//					//isDisplayedThenActionClick(editCardMenuButton, "Click Edit card Button");
	//			sleep(5);
	//					
	//			checkTextInPageAndValidate("VIEW CARD", 30);
	//			
	//			checkTextInPageAndValidate(cardAccNo, 30);
	//	}


	public ArrayList<String> getDescriptionHeadersInDB() {
		ArrayList<String> columnHeaderDecription = new ArrayList<String>();
		String clientCountry=PropUtils.getPropValue(configProp, "clientCountry");
		System.out.println("clientCountry::"+clientCountry);
		String getDescriptionValues="";
		getDescriptionValues = "select LOWER(description) from BULK_CARD_COLUMNS where bulk_card_template_oid = (select bulk_card_template_oid from bulk_card_templates where description = 'Bulk Card Order BP "+clientCountry+"')";
		columnHeaderDecription = connectDBAndGetDBEntireColumnValues(getDescriptionValues,
		PropUtils.getPropValue(configProp, "sqlODSServerName"));
		System.out.println("Description" + columnHeaderDecription);

		columnHeaderDecription.set(8, "expiry date");
		columnHeaderDecription.set(9, "reference number");
		if(clientCountry.equals("AU")) {
		columnHeaderDecription.set(35, "transaction purchase limit");
		columnHeaderDecription.set(36, "transaction volume limit - fuel");
		columnHeaderDecription.set(37, "transaction purchase soft limit");
		columnHeaderDecription.set(38, "transaction volume soft limit");
		columnHeaderDecription.set(39, "transaction purchase soft limit - non fuel");
		columnHeaderDecription.set(40, "daily volume soft limit");
		columnHeaderDecription.set(41, "daily transaction soft limit");
		columnHeaderDecription.set(42, "monthly volume soft limit");
		}
		else if(clientCountry.equals("NZ")){
			columnHeaderDecription.set(18, "transaction purchase limit - all purchases");
			columnHeaderDecription.set(19,"transaction purchase soft limit - non fuel (shop)");
			columnHeaderDecription.set(20, "transaction volume soft limit - fuel");
			columnHeaderDecription.set(21,"transaction purchase soft limit - fuel");
			columnHeaderDecription.set(22,"daily purchase soft limit - all purchases");	
			columnHeaderDecription.set(23,"daily transaction count soft limit");	
			columnHeaderDecription.set(24,"monthly purchase soft limit - fuel");
			columnHeaderDecription.set(25,"monthly transactions soft limit");	
		}
		columnHeaderDecription.set(26, "temp contact name");
		columnHeaderDecription.set(27, "temp contact title");
		columnHeaderDecription.set(28, "temp postal address");
		columnHeaderDecription.set(31, "temp address suburb");
		columnHeaderDecription.set(29,"temp postal code");
		columnHeaderDecription.set(30,"temp postal state");
		columnHeaderDecription.set(14,"perm contact name");
		columnHeaderDecription.set(15,"perm contact title");
		columnHeaderDecription.set(16,"perm postal address");
		columnHeaderDecription.set(19,"perm address suburb");
		columnHeaderDecription.set(17,"perm postal code");
		columnHeaderDecription.set(18,"perm address state");
		return columnHeaderDecription;
		}
/*Prakalpha-->11/05/2019
 * Validate Expected Values Present in Excel 
 */
	public void validateExpectedValuesInExcel(String fileNameContains, String sheetName, String[] columnHeader,
			ArrayList<String> columnValues) {
		HSSFSheet workSheet = null;
		HSSFRow row = null;
		HSSFWorkbook workBook = null;
		HSSFCell cell = null;
		CommonInterfacePage commonInterfacePage = new CommonInterfacePage(driver, test);
		String fileName = getLatestDownloadedFileFromDir(fileNameContains).getName();
		String filePath = System.getProperty("user.home") + "\\Downloads\\" + fileName;
		System.out.println("File Name :" + filePath);
		try {
			FileInputStream inputStream = new FileInputStream(new File(filePath));
			workBook = new HSSFWorkbook(inputStream);
			workSheet = workBook.getSheet(sheetName);
		} catch (Exception e) {

			e.printStackTrace();
		}
		int flag = 0;
		int col_num = commonInterfacePage.getColumnNoFromExcel(columnHeader[0], workSheet, 0);
		System.out.println("Column_number::" + col_num);
		System.out.println("rowIndex sizze::" + workSheet.getLastRowNum());
		for (int rowIndex = 1; rowIndex <= workSheet.getLastRowNum(); rowIndex++) {
			for (int j = 0; j < columnValues.size(); j++) {
				row = workSheet.getRow(rowIndex);
				cell = row.getCell(col_num);
				System.out.println("cell values from excel::" + cell.getStringCellValue().trim());
				System.out.println("given arraylist column values::" + columnValues.get(j));
				if (cell.getStringCellValue().trim().equals(columnValues.get(j))) {
					logPass("Values Present in a Sheet::" + columnValues.get(j));
					flag++;
				}
			}
			if (flag == columnValues.size()) {
				break;
			}
			if (rowIndex == workSheet.getLastRowNum()) {
				logFail("Expected value is Not Present in Sheet");
			}
		}

	}
	
	public void changeSearchListIntoAscendingOrder() {
		boolean elementPresent=waitToCheckElementIsDisplayed(By.xpath("//a[@class='descending']"),10);
		if(elementPresent) {
		isDisplayedThenClick(cardsFoundAscending,"Ascending clicked");
		sleep(10);
		}
		else {
			logInfo("Already in Ascending Order");
		}
	}
	
	//Added by Nithya - 13/05/2020
	public String getPwdTokenFromDB(String logonId) {
		String queryToTakeToken = "select token from password_link where logon_id='"+logonId+"'";
		return connectDBAndGetValue(queryToTakeToken, PropUtils.getPropValue(configProp, "sqlODSServerName"));
	}
	
	public String generatePasswordSetURL(String client, String logonId) {
		String baseURL = PropUtils.getPropValue(configProp, client+"_URL");
		return baseURL+"/faces/noSecure/createPassword.xhtml?token="+getPwdTokenFromDB(logonId);
	}
	
	public void setNewPasswordAndCheckLogin(String client,String logonId) {
		LoginPage loginPage = new LoginPage(driver, test);
		driver.navigate().to(generatePasswordSetURL(client, logonId));
		String password="Password01Auto";
		isDisplayedThenEnterText(newPassword, "Password in New Pwd field", password);
		isDisplayedThenEnterText(confirmPassword, "Password in Confirm Pwd field", password);
		isDisplayedThenClick(saveBtn, "Save New Password");
		isDisplayed(loginForm, "Password is set and moved to Login");
		loginPage.loginWithUsernameAndPwd(logonId, password);
	} 
}
