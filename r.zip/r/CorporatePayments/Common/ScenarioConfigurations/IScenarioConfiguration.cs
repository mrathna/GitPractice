﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;

namespace Common.ScenarioConfigurations
{
	public interface IScenarioConfiguration
	{
		DataSourceType SourceType { get; }
		DataSet Data { get; }

		string Customer { get; set; }
		string Environment { get; set; }

		bool LoadData();
	}

	public abstract class BaseScenarioConfiguration : IScenarioConfiguration
	{
		private string _customer;
		private string _environment;

		public virtual DataSourceType SourceType { get { return DataSourceType.None; } }

		public virtual DataSet Data => null;

		public virtual bool LoadData()
		{
			return true;
		}

		public virtual string Customer
		{
			get
			{
				// use cached value or look it up
				if (string.IsNullOrWhiteSpace(_customer))
				{
					_customer = ConfigurationManager.AppSettings["Customer"];

					// if it still blank/null use a default value
					if (string.IsNullOrWhiteSpace(_customer))
					{
						_customer = @"WEX";
					}
				}
				return _customer;
			}
			set { _customer = value; }
		}

		public virtual string Environment
		{
			get
			{
				// use cached value or look it up
				if (string.IsNullOrWhiteSpace(_environment))
				{
					_environment = ConfigurationManager.AppSettings["Environment"];

					// if it still blank/null use a default value
					if (string.IsNullOrWhiteSpace(_environment))
					{
						_environment = @"QA";
					}
				}
				return _environment;
			}
			set { _environment = value; }
		}
	}

	public class StandardScenarioConfiguration : BaseScenarioConfiguration { }

}
