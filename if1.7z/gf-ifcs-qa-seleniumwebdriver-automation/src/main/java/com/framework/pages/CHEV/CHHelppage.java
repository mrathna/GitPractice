package com.framework.pages.CHEV;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.ExtentTest;
import com.framework.basepage.BasePage;
import com.framework.repo.Locator;

public class CHHelppage extends BasePage{

	
	@FindBy(how = How.XPATH, using = Locator.PAGE_TITLE_REISSUECARD)
	public WebElement FAQTitle;
	
	public CHHelppage(WebDriver driver, ExtentTest test) {
		super(driver, test);
		PageFactory.initElements(driver, this);
	}

	public void verifyHelpPageTitle() {
		if(FAQTitle.getText().equals("Frequently Asked Questions")) {
			logPass("Frequently Asked Page is Visible"); 
		}
		else {
			logFail("Frequently Asked Page is not Visible");
		}
	}
	
}
