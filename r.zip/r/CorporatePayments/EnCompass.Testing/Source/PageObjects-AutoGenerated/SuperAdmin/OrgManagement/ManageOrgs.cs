using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using Common;
using Common.PageObjects;
using Common.ScenarioConfigurations;
using Common.Utility;

namespace EnCompass.Testing.Source.PageObjects.SuperAdmin.OrgManagement 
{
	/// <summary>
	/// Auto-generated Page Model Class
	/// Navigation Paths: 
		/// [Organization Home]->Users and Organizations->Organization Settings
		/// </summary>
	[PageModel(@"/superAdmin/orgManagement/manageOrgs.aspx")]
	public partial class ManageOrgs : EnCompassSuperPageModel 
	{
		public override string RelativeUrl => @"/superAdmin/orgManagement/manageOrgs.aspx";
		public override string PageIdentifierXPath_Generated => @"//li[contains(@class, 'breadcrumb-item active')][text() = 'Organization Settings']";

		#region Navigation
		
		private void NavigateToMenuItem(IWebElement element)
		{
			Driver.Url = element.GetAttribute("href");
		}
		#endregion

		public ManageOrgs(GlobalSettings settings) : base(settings) { }
	}  
}
