package com.framework.testcases.OLS.BP.Customer;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.BP.BPAccountPage;
import com.framework.pages.BP.BPHomePage;
import com.framework.pages.OLS.common.BPCommonPage;
import com.framework.pages.OLS.common.FindAndExportTransactionPage;
import com.framework.pages.OLS.common.LoginPage;
import com.framework.pages.OLS.common.ViewAndEditContactsPage;

public class ValidateCustomerTransactions extends BaseTest {
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "Smoke","Regression" })
	public void checkCustomerTransaction(@Optional("AU") String clientCountry, @Optional("BP") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  13 - Customer Transactions", "Check the Customer Transaction");

		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		BPHomePage bpHomePage = new BPHomePage(driver, test);
		BPCommonPage bpCommonPage = new BPCommonPage(driver, test);
		BPAccountPage bpAccountPage = new BPAccountPage(driver, test);
		ViewAndEditContactsPage bpViewAndEditContactsPage = new ViewAndEditContactsPage(driver, test);

		// Calling Functions for Login
		loginPage.Login("BP_URL", "BP_UN_Customer_" + clientCountry, "BP_PWD_Customer_" + clientCountry, clientName);
		bpHomePage.ValidateBPCustomerLogo();

		bpCommonPage.selectAccount();

		bpHomePage.clickAccountDetailsLink();

		bpAccountPage.clickViewAndEditContactLink(); 
		bpViewAndEditContactsPage.clickAddContactButton("Customer");

		bpViewAndEditContactsPage.validateAddContactPage();

		loginPage.Logout();

	}

	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "Regression" ,"BusinessFlow"})
	public void exportCustomerTransactionList(@Optional("AU") String clientCountry, @Optional("BP") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  BP Regression - Customer Export Transaction List", "Verify Export Transaction");

		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		BPHomePage bpHomePage = new BPHomePage(driver, test);
		BPCommonPage bpCommonPage = new BPCommonPage(driver, test);
		FindAndExportTransactionPage findAndExportTransactions = new FindAndExportTransactionPage(driver, test);

		// Calling Functions for Login
		loginPage.Login("BP_URL", "BP_UN_Customer_" + clientCountry, "BP_PWD_Customer_" + clientCountry, clientName);

		bpHomePage.ValidateBPCustomerLogo();

		bpHomePage.loadFindAndExportTransactionsPage();

		bpCommonPage.selectAllAccountFromAccountField();

		findAndExportTransactions.selectADateRangeFropDropdown("Last 3 calendar months");

		findAndExportTransactions.clickSearchTransactions();

		findAndExportTransactions.setReceiptValueAndDateFromSearchResults();

		if (findAndExportTransactions.isTransactionFound()) {

			bpHomePage.loadFindAndExportTransactionsPage();

			bpCommonPage.selectAllAccountFromAccountField();

			findAndExportTransactions.selectADateRangeFropDropdown("Last 3 calendar months");

			findAndExportTransactions.clickAdvancedSearchOptions();

			findAndExportTransactions.enterReceiptValue();

			// findAndExportTransactions.selectADateRangeInSearchTransaction();

			findAndExportTransactions.clickSearchTransactions();

			findAndExportTransactions.verifySearchTransactionTable();

			findAndExportTransactions.clickExportTransaction();

		}

		loginPage.Logout();
	}

	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "Regression" })
	public void viewTransactionWithNoProduct(@Optional("AU") String clientCountry, @Optional("BP") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  BP Regression - Customer View Transaction ",
				"Check the Customer Transaction Details");

		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		BPHomePage bpHomePage = new BPHomePage(driver, test);
		BPCommonPage bpCommonPage = new BPCommonPage(driver, test);
		FindAndExportTransactionPage findAndExportTransactions = new FindAndExportTransactionPage(driver, test);

		// Calling Functions for Login
		loginPage.Login("BP_URL", "BP_UN_Customer_" + clientCountry, "BP_PWD_Customer_" + clientCountry, clientName);

		bpHomePage.ValidateBPCustomerLogo();

		bpHomePage.loadFindAndExportTransactionsPage();

		bpCommonPage.selectAllAccountFromAccountField();

		findAndExportTransactions.selectADateRangeFropDropdown("Last 3 calendar months");

		findAndExportTransactions.clickSearchTransactions();

		findAndExportTransactions.chooseTransactionWithNoProduct();

		if (findAndExportTransactions.isTransactionFound()) {

			findAndExportTransactions.clickOnTransactionWithNoProduct();

			findAndExportTransactions.clickViewTransaction();

			findAndExportTransactions.verifyTransactionPageTitle("View Transaction Details");

		}

		loginPage.Logout();
	}

	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "Regression" })
	public void returnToTransactionList(@Optional("AU") String clientCountry, @Optional("BP") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  BP Regression - Customer View Transaction and Return to transaction list",
				"Check the return to transaction list");

		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		BPHomePage bpHomePage = new BPHomePage(driver, test);
		BPCommonPage bpCommonPage = new BPCommonPage(driver, test);
		FindAndExportTransactionPage findAndExportTransactions = new FindAndExportTransactionPage(driver, test);

		// Calling Functions for Login
		loginPage.Login("BP_URL", "BP_UN_Customer_" + clientCountry, "BP_PWD_Customer_" + clientCountry, clientName);

		bpHomePage.ValidateBPCustomerLogo();

		bpHomePage.loadFindAndExportTransactionsPage();

		bpCommonPage.selectAllAccountFromAccountField();

		findAndExportTransactions.selectADateRangeFropDropdown("Last 3 calendar months");

		findAndExportTransactions.clickSearchTransactions();

		findAndExportTransactions.chooseTransactionWithNoProduct();

		if (findAndExportTransactions.isTransactionFound()) {

			findAndExportTransactions.clickOnTransactionWithNoProduct();

			findAndExportTransactions.clickViewTransaction();

			findAndExportTransactions.verifyTransactionPageTitle("View Transaction Details");

			findAndExportTransactions.clickReturnToTransactionList();

			findAndExportTransactions.verifyTransactionPageTitle("Find and Export Transactions");
		}

		loginPage.Logout();
	}

	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "Regression" })
	public void viewTransactionWithCardNumber(@Optional("AU") String clientCountry, @Optional("BP") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  BP Regression - Customer View Transaction",
				"Check the transaction details of card transaction");

		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		BPHomePage bpHomePage = new BPHomePage(driver, test);
		BPCommonPage bpCommonPage = new BPCommonPage(driver, test);
		FindAndExportTransactionPage findAndExportTransactions = new FindAndExportTransactionPage(driver, test);

		// Calling Functions for Login
		loginPage.Login("BP_URL", "BP_UN_Customer_" + clientCountry, "BP_PWD_Customer_" + clientCountry, clientName);

		bpHomePage.ValidateBPCustomerLogo();

		bpHomePage.loadFindAndExportTransactionsPage();

		bpCommonPage.selectAllAccountFromAccountField();

		findAndExportTransactions.selectADateRangeFropDropdown("Last 3 calendar months");

		findAndExportTransactions.clickSearchTransactions();

		findAndExportTransactions.chooseTransactionWithCardNumber();

		if (findAndExportTransactions.isTransactionFound()) {

			findAndExportTransactions.clickOnTransactionWithCardNumber();

			findAndExportTransactions.clickGoToCard();

			findAndExportTransactions.verifyTransactionPageTitle("View Card Details");
		}

		loginPage.Logout();
	}

}
