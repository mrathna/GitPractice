package com.framework.testcases.VELOCITY.WES;

import java.util.LinkedHashMap;
import java.util.Map;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.WES.Velocity.VelocityCardsPage;
import com.framework.pages.WES.Velocity.VelocityHomePage;
import com.framework.pages.WES.common.CommonPage;
import com.framework.pages.WES.common.LoginPage;
import com.framework.util.PropUtils;

public class ValidateOrderCardTestCases extends BaseTest {

	Map<String, String> cardNumbers = new LinkedHashMap<String, String>();

	@DataProvider(name = "Parameters")
	public static String[][] parameters() {

		String clientName = "WES";
		String clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		return new String[][] {

				{ "Esso"     , "1", clientName, clientCountry },
				{ "Esso"     , "3", clientName, clientCountry },
				/*{ "EDC"      , "1", clientName, clientCountry },
				{ "EDC"      , "3", clientName, clientCountry },
				{ "UK_Fuels" , "1", clientName, clientCountry },
				{ "UK_Fuels" , "3", clientName, clientCountry },
				{ "Multiple" , "3", clientName, clientCountry },*/
				{ "EssoBlock", "1", clientName, clientCountry }

		};
	}

	// Sasi
	@Test(groups = { "Regression" }, dataProvider = "Parameters")
	public void CardCreationAndValidation(String cardType, String cardCount, String clientName, String clientCountry) {

		int countOfCards = Integer.valueOf(cardCount);

		if (countOfCards == 1) {
			test = extent.createTest(
					"Ability to order a Single " + cardType + " Card for existing customer via Velocity ",
					"Ability to order a Single " + cardType + " Card for existing customer via Velocity ");
		} else if (countOfCards > 1) {
			test = extent.createTest(
					"Ability to order Multiple " + cardType + " Cards for existing customer via Velocity ",
					"Ability to order Multiple " + cardType + " Cards for existing customer via Velocity ");
		} else if (countOfCards > 1 && cardType.equals("Multiple")) {
			test = extent.createTest(
					"Ability to order Muliple ESSO,EDC & UK Fuels Cards for existing customer via Velocity ",
					"Ability to order Muliple ESSO,EDC & UK Fuels Cards for existing customer via Velocity ");
		} else if (countOfCards == 1 && cardType.equals("EssoBlock")) {
			test = extent.createTest(clientName+ ":" +clientCountry+"  Ability to block / stop a card via Velocity ",
					"Ability to block / stop a card via Velocity ");
		}

		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		CommonPage commonPage = new CommonPage(driver, test);
		VelocityHomePage homePage = new VelocityHomePage(driver, test);
		VelocityCardsPage cardsPage = new VelocityCardsPage(driver, test);
		System.out.println("clientCountry-->" + clientCountry);
		loginPage.loginWES("Velocity_URL", "Velocity_UN_" + clientName, "Velocity_PWD_" + clientName, "VELOCITY");

		String cusNo = commonPage.getCustomerNo(clientName, clientCountry);
		cardNumbers.put("cusNo", cusNo);

		homePage.clickingAndValidatingSpecificAccessType("Distributor");
		homePage.searchingAndValidatingCustomer(cusNo);
		String embossName_cardNo = (cardsPage.validatingAndCreatingNewCards(cardCount, cardType).toUpperCase());
		cardsPage.clickingSubmitAndValidate(cardType);
		
		cardNumbers.putAll(cardsPage.addingCardsInMap(cardType, embossName_cardNo, cusNo, countOfCards));

		loginPage.logoutTheApplication("Velocity");
	}

	// Sasi
	@Parameters({"clientName" })
	@Test(groups = { "Regression" })
	public void RequestingPinMailerAndValidating(@Optional("WES") String clientName) {

		test = extent.createTest(clientName+ ": Ability to request a PIN mailer for an Esso card via Velocity",
				"Ability to request a PIN mailer for an Esso card via Velocity");

		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		VelocityHomePage homePage = new VelocityHomePage(driver, test);
		VelocityCardsPage cardsPage = new VelocityCardsPage(driver, test);
		CommonPage commonPage = new CommonPage(driver, test);
		
		String clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		String cusNo = commonPage.getCustomerNo(clientName, clientCountry);

		loginPage.loginWES("Velocity_URL", "Velocity_UN_" + clientName, "Velocity_PWD_" + clientName, "VELOCITY");

		homePage.clickingAndValidatingSpecificAccessType("Distributor");
		homePage.searchingAndValidatingCustomer(cusNo);
		String cardNo = cardsPage.clickingPinMailerAndValidating();
		cardNumbers.put("PinMailer", cardNo);
		loginPage.logoutTheApplication("Velocity");

	}

	// Sasi
	@Parameters({"clientName" })
	@Test(groups = { "Regression" })
	public void creatingCostCentreAndValidating(@Optional("WES") String clientName) {

		test = extent.createTest(clientName+ ":   To Validate that cards an be placed into cost centres in velocity",
				"To Validate that cards an be placed into cost centres in velocity");

		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		VelocityHomePage homePage = new VelocityHomePage(driver, test);
		VelocityCardsPage cardsPage = new VelocityCardsPage(driver, test);
		CommonPage commonPage = new CommonPage(driver, test);
		
		String clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		String cusNo = commonPage.getCustomerNo(clientName, clientCountry);
		
		loginPage.loginWES("Velocity_URL", "Velocity_UN_" + clientName, "Velocity_PWD_" + clientName, "VELOCITY");
		homePage.clickingAndValidatingSpecificAccessType("Distributor");
		homePage.searchingAndValidatingCustomer(cusNo);
		String groupName = cardsPage.createNewGroupAndValidate();
		cardsPage.assignCardsToCostCentreAndValidate(groupName);
		loginPage.logoutTheApplication("Velocity");

	}
	
	// Sasi
		@Parameters({"clientName" })
		@Test(groups = { "Regression" })
		public void CustomerUpdatationAndValidation(@Optional("WES") String clientName) {

			test = extent.createTest(clientName+ ": Ability to change customer details in IFCS and see the changes in Velocity",
					"Ability to change customer details in IFCS and see the changes in Velocity");

			// Creating Objects for the Pages
			LoginPage loginPage = new LoginPage(driver, test);
			VelocityHomePage homePage = new VelocityHomePage(driver, test);
			VelocityCardsPage cardsPage = new VelocityCardsPage(driver, test);
			CommonPage commonPage = new CommonPage(driver, test);
			
			String clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
			String cusNo = commonPage.getCustomerNo(clientName, clientCountry);
			
			loginPage.loginWES("Velocity_URL", "Velocity_UN_" + clientName, "Velocity_PWD_" + clientName, "VELOCITY");
			homePage.clickingAndValidatingSpecificAccessType("Distributor");
			homePage.searchingAndValidatingCustomer(cusNo);
			cardsPage.updatingCustomerData(cusNo);
			loginPage.logoutTheApplication("Velocity");

		}

	// Sasi
	@Test(groups = { "Regression" })
	public void CreatingPropFile() {

		test = extent.createTest(" CreatingPropFile", "CreatingPropFile");

		// Creating Objects for the Pages
		/*CommonPage commonPage = new CommonPage(driver, test);
		commonPage.MyPropertyFileStore("VelocityTemp.Properties", cardNumbers);*/
		
		PropUtils.creatingTempPropFile("VelocityTemp.Properties", cardNumbers);

	}
}
