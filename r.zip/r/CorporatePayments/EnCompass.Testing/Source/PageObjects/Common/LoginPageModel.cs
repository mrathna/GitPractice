﻿using Common;
using Common.PageObjects;
using Common.Utility;
using EnCompass.Testing.Source.PageObjects.Organization.SecurityManager.SecurityPolicy;
using EnCompass.Testing.Source.PageObjects.SuperAdmin;
using Flurl;
using NFluent;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace EnCompass.Testing.Source.PageObjects.Common
{
	public class LoginPageModel : PageModel
	{
		private const string LOGIN_XPATH = @"//input[contains(@id,'logIn')]";

        #region XPath page Elements

        private static string _usernameXPath = "//input[contains(@id, 'txtusername')]";
        private static string _passwordXPath = "//input[contains(@id, 'txtpassword')]";
        private static string _orgGroupLoginIdXPath = "//input[contains(@id, 'txtLoginOrgGroupId')]";
        private static string _loginTextMessageXPath = @"//span[contains(@id, 'LblloginMsg')]";
        private static string _securityCodeXPath = @"//input[contains(@id, 'txtMultifactorAuthToken')]";
        private static string _forgotUsernameBtnXPath = @"//a[contains(@href, 'RetrieveUserName')]";
        private static string _currentpwdXPath = "//input[contains(@id, 'txtcurrentpswd')]";
        private static string _forgotPasswordBtnXPath = @"//a[contains(@href, 'ResetPassword')]";
        private static string _registerBtnXPath = @"//a[contains(@href,'SelfRegister')]";
        private static string _challengeQuestionXPath = @"//input[contains(@id, 'ChallengeAnswer')]";
        private static string _rblAcceptXPath = "//label[contains(@for,'rblTermsConditions_0')]";
        private static string _valSummaryXPath = @"//div[contains(@id,'ValidationSummary')]";
        private static string _amSuccessMsgXPath = "//div[contains(@id,'amSuccessMessage')]/p";

        private string _rblAccept = "//label[contains(@for,'rblTermsConditions_0')]";

        #endregion

        #region IwebElements Props

		public IWebElement _username
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_usernameXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Debug("Found _username");
                return element;
            }
        }

        public IWebElement _password
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_passwordXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Debug("Found _password");
                return element;
            }
        }

        public IWebElement _orgGroupLoginId
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_orgGroupLoginIdXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Debug("Found _orgGroupLoginId");
                return element;
            }
        }

        public IWebElement _loginButton
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(LOGIN_XPATH), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Debug("Found _loginButton");
                return element;
            }
        }

        public IWebElement _loginFailedTextMessage
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_loginTextMessageXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Debug("Found _loginFailedTextMessage");
                return element;
            }
        }

        public IWebElement _securityCode
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_securityCodeXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Debug("Found _securityCode");
                return element;
            }
        }

        public IWebElement _forgotUsernameBtn
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_forgotUsernameBtnXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Debug("Found _forgotUsernameBtn");
                return element;
            }
        }

        public IWebElement _forgotPasswordBtn
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_forgotPasswordBtnXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Debug("Found _forgotPasswordBtn");
                return element;
            }
        }

        public IWebElement _LoginMsg
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_loginTextMessageXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Debug("Found _LoginMsg");
                return element;
            }
        }

        public IWebElement _registerBtn
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_registerBtnXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Debug("Found _registerBtn");
                return element;
            }
        }

        public IWebElement _challengeQuestion
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_challengeQuestionXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Debug("Found _challengeQuestion");
                return element;
            }
        }


        #endregion

        
                       
        public override string RelativeUrl => string.Empty;

		public override string PageIdentifierXPath_Generated => LOGIN_XPATH;

		public string SecurityCode
		{
			set
			{
				_securityCode.Clear();
				_securityCode.SendKeys(value);
			}
		}

		public bool IsSecurityCodeDisplayed()
		{
			try
			{
				var isDisplayed = _securityCode.Displayed;
				return isDisplayed;
			}
			catch { return false; }
		}

		public bool IsChallengeQuestionDisplayed()
		{
			try
			{
				var isDisplayed = _challengeQuestion.Displayed;
				return isDisplayed;
			}
			catch { return false; }
		}

		public string ChallengeAnswer
		{
			set { _challengeQuestion.Clear(); _challengeQuestion.SendKeys(value); }
		}
		public string LoginFailedMessage
		{
			get
			{
				return _loginFailedTextMessage.Text;
			}
		}

		public bool IsLoginFailedDisplayed
		{
			get
			{
				try
				{
					var isDisplayed = _loginFailedTextMessage.Displayed;
					return isDisplayed;

				}
				catch { return false; }
			}
		}

		public string Username
		{
			set
			{
                _username.ForceDocumentLoadOnSendKeys(value, Driver);
                Settings.EnCompassExtentTest.Info("Username =" + value);
            }
		}
		public string Password
		{
			set
			{
				_password.ForceDocumentLoadOnSendKeys(value, Driver);
				Settings.EnCompassExtentTest.Info("Password =" + value);
			}
		}
		public string OrgGroupLoginId
		{
			set
			{
				_orgGroupLoginId.Clear();
				_orgGroupLoginId.SendKeys(value);
				Settings.EnCompassExtentTest.Info("OrgGroupLoginId =" + value);
			}
		}

		public LoginPageModel(GlobalSettings settings) : base(settings) { }

		public void Login()
		{
			_loginButton.JSClickWithFocus(Driver);
			Settings.EnCompassExtentTest.Info("Clicked on Login Button");
			//Rupam - Do not inject code to wait for OrgHOmeModel page, as depending on
			// Superadmin or ORg level user the page to wait will change
		}

		public void LoginAndWaitForSecurityCode()
		{
			_loginButton.JSClickWithFocus(Driver);
			Settings.EnCompassWebDriver.WaitForVisible(By.XPath("//input[contains(@id, 'txtMultifactorAuthToken')]"));
		}

        /// <summary>
        ///  For newly created org level user, after login>>Terms and conditions page will be displayed
        ///  Once Password is expired, after login>> Force change password page will be displayed
        /// </summary>
        public void LoginAndWaitForAccept()
        {
			_loginButton.JSClickWithFocus(Driver);
            
            if (Driver.TryWaitForElementToBeVisible(By.XPath(_rblAccept), out IWebElement element))
            {
                Settings.EnCompassExtentTest.Info("Terms and conditions page is loaded successfully");
            }       
            else 
            {
                Settings.EnCompassExtentTest.Info("Force passsword change page is loaded successfully");
            }
        }

        public void LoginAndWaitForPasswordResetScreen()
        {
            _loginButton.JSClickWithFocus(Driver);
			Settings.EnCompassWebDriver.WaitForVisible(By.XPath("//input[contains(@id, 'txtcurrentpswd')]"));
        }

        public string GetLoginMsg
        {
            get
            {
                return Settings.EnCompassWebDriver.WaitForVisible(By.XPath(@"//div[contains(@id,'ValidationSummary')]"), TimeSpan.FromSeconds(20)).GetAttribute("innerText");
            }
        }
		public void ForgotPasswordBtn()
		{
			_forgotPasswordBtn.JSClickWithFocus(Driver);
		}

		public void ForgotUsernameBtn()
		{
			_forgotUsernameBtn.JSClickWithFocus(Driver);
		}

		public void RegisterBtn()
		{
			_registerBtn.JSClickWithFocus(Driver);
		}

		public string GetSuccessMessage
		{
			get
			{
				return Settings.EnCompassWebDriver.WaitForVisible(By.XPath("//div[contains(@id,'amSuccessMessage')]/p"), TimeSpan.FromSeconds(5)).GetAttribute("innerText");
			}
		}
	}
}

