package com.framework.testcases.API;

import org.json.JSONException;
import org.json.simple.parser.ParseException;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.common.IFCSLoginPage;
import com.framework.pages.API.common.CommonAPI;
import com.framework.pages.API.common.CustomerAPIMethods;
import com.framework.util.PropUtils;

public class ValidateCreateAndUpdateCustomer extends BaseTest {

	/**
	 * Implemented by Naveen
	 * @param clientCountry
	 * @param clientName
	 * @throws JSONException
	 * @throws ParseException
	 * Busienss Flow ID:BF-003
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow" })
	public void createNewCustomerUsingAPI(@Optional("NZ") String clientCountry, @Optional("BP") String clientName)
			throws JSONException, ParseException {

		test = extent.createTest(clientName + ":" + clientCountry + "ID:BF-003  Create Customer", "Create Customer using API");

		CommonAPI commonAPI = new CommonAPI(driver, test);
		CustomerAPIMethods custAPI = new CustomerAPIMethods(driver, test);
		IFCSLoginPage ifcsLoginPage = new IFCSLoginPage(driver, test);
		ifcsLoginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		ifcsLoginPage.logInfo("------ CREATE CUSTOMER -----");
		commonAPI.loginToAPIUser(
				PropUtils.getPropValue(configProp, "UserNameAPI" + "_" + clientName + "_" + clientCountry),
				PropUtils.getPropValue(configProp, "PassWordAPI" + "_" + clientName + "_" + clientCountry));
		custAPI.customerCreation(clientName, clientCountry);
		commonAPI.logoutAPIUser();

	}

	/**
	 * Implemented by Raxsana Babu
	 * @param clientCountry
	 * @param clientName
	 * @throws JSONException
	 * @throws ParseException
	 * Busienss Flow ID:BF-002
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow" })
	public void customerUpdateUsingAPI(@Optional("BE") String clientCountry, @Optional("WFE") String clientName)
			throws JSONException, ParseException {

		test = extent.createTest("Customer Update" + "_" + clientCountry, "ID:BF-002 Customer update using API");
		CommonAPI commonAPI = new CommonAPI(driver, test);
		CustomerAPIMethods custAPI = new CustomerAPIMethods(driver, test);
		IFCSLoginPage ifcsLoginPage = new IFCSLoginPage(driver, test);
		ifcsLoginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		commonAPI.loginToAPIUser(
				PropUtils.getPropValue(configProp, "UserNameAPI" + "_" + clientName + "_" + clientCountry),
				PropUtils.getPropValue(configProp, "PassWordAPI" + "_" + clientName + "_" + clientCountry));

		custAPI.customerUpdate("Name", clientName, clientCountry);

		commonAPI.logoutAPIUser();

	}

}
