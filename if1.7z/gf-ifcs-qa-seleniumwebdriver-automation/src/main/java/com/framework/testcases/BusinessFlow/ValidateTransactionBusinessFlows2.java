package com.framework.testcases.BusinessFlow;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.CardMaintenancePage;
import com.framework.pages.AJS.MaintainAccountPage;
import com.framework.pages.AJS.MaintainCustomerPage;
import com.framework.pages.AJS.TransactionListPage;
import com.framework.pages.AJS.common.Common;
import com.framework.pages.AJS.common.CommonInterfacePage;
import com.framework.pages.AJS.common.IFCSCommonPage;
import com.framework.pages.AJS.common.IFCSHomePage;
import com.framework.pages.AJS.common.IFCSLoginPage;
import com.framework.pages.AJS.common.InterfacePage;
import com.framework.pages.AJS.common.SalesForceLoginPage;
import com.framework.pages.BusinessFlow.SalesForceCommon;
import com.framework.pages.BusinessFlow.TransactionComponentPage;
import com.framework.pages.BusinessFlow.WFECommon;
import com.framework.util.Constants;
import com.framework.util.PropUtils;
import com.github.javafaker.Faker;

public class ValidateTransactionBusinessFlows2 extends BaseTest {

	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow" })
	public void validateTransactionsPosting(String clientCountry, String clientName) throws TransformerException {

		test = extent.createTest(clientName + ":" + clientCountry + "  Load Card transaction file upload",
				"Post transaction with XMLFile");
		// creating object for the Pages

		Map<String, String> dbvalue = null;
		Map<String, String> lineItem = null;
		Map<String, String> valuesForValidation = new LinkedHashMap<String, String>();
		String folderName = null, jobsInOrder = null, cardNumber = null, refNo = null;
		int k, netValue = 0;
		Common common = new Common(driver, test);
		Map<String, String> cardList = new HashMap<String, String>();
		cardList = common.readDataFromPropertyFile("card_" + clientName + "_" + clientCountry, cardOrderedFile);
		CommonInterfacePage CommonInterfacePage = new CommonInterfacePage(driver, test);
		InterfacePage interfacePage = new InterfacePage(driver, test);
		IFCSHomePage ifcsHomePage = new IFCSHomePage(driver, test);
		String clientNameInProp = PropUtils.getPropValue(configProp, clientName + "_" + clientCountry);

		IFCSCommonPage ifcsCommonPage = new IFCSCommonPage(driver, test);
		String[] headertag = { "FileName", "SequenceNumber", "RecordCount", "CountryCode", "StartDate", "StartTime",
				"ExternalSupplier", "SettlementDate", "ExternalFileName" };
		String[] loadTransaction = { "Transaction", "Card", "Location", "Terminal", "Vehicle", "TransactionLineItem" };
		String[] card = { "CardNumber", "CardType" };
		String[] transaction = { "CaptureTypeCode", "TransactionCode", "AttentionKey", "ReferenceNumber", "OrderNumber",
				"FleetNumber", "SubEntityNumber", "TransactionDateTime", "AuthorisationNumber", "OdometerReading",
				"BatchNumber", "BatchSource", "ExtraCardNo" };
		String[] location = { "IdassNumber", "StreetAddressState", "RetailSiteId", "MarketingTerritory",
				"AdminTerritory" };
		String[] terminal = { "PhysicalTerminalId", "TerminalStatus", "TerminalType" };
		String[] vehicle = { "RegistrationNumber", "CurrentOdometerReading" };
		String[] lineitem = { "LineItemCode", "Quantity", "UnitPrice", "NetValue" };
		String date = CommonInterfacePage.funcFetchLoadCardTransStartDateFromIFCSDB(configProp, clientNameInProp);

		String folderid = CommonInterfacePage.getfolderid(clientName, clientCountry);
		int cardListCount = cardList.size();
		if (cardListCount == 0) {
			cardListCount = 1;
		}

		String client_mid = CommonInterfacePage.funcFetchLoadCardTransClientMidFromDB(configProp, clientName,
				clientCountry);
		String remotedir;
		if (clientName.equalsIgnoreCase("BP")) {
			remotedir = PropUtils.getPropValue(configProp, "IFCS_LOADCARDTRANSACTION") + folderid + "/";
		} else {
			remotedir = PropUtils.getPropValue(configProp, "IFCS_LOADCARDTRANSACTION") + client_mid + "/" + folderid
					+ "/";
		}
		try {
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			Document doc = docBuilder.newDocument();

			Element rootElement = doc.createElement("LoadCardTransactions");
			doc.appendChild(rootElement);

			Element header = doc.createElement("Header");
			rootElement.appendChild(header);
			dbvalue = CommonInterfacePage.fetchLoadCardTransSeqNoandPrefix(configProp, clientName, clientCountry,
					folderid);
			String filename = dbvalue.get("prefixvalue") + dbvalue.get("lastSequenceNumber") + ".xml";
			System.out.println(dbvalue);
			for (k = 0; k < headertag.length; k++) {
				Element subtag = doc.createElement(headertag[k]);
				if (headertag[k].equalsIgnoreCase("FileName")) {

					System.out.println(
							"file Name:" + dbvalue.get("prefixvalue") + dbvalue.get("lastSequenceNumber") + ".xml");
					subtag.setTextContent(dbvalue.get("prefixvalue") + dbvalue.get("lastSequenceNumber") + ".xml");
				} else if (headertag[k].equalsIgnoreCase("SequenceNumber")) {
					subtag.setTextContent(dbvalue.get("lastSequenceNumber"));
				} else if (headertag[k].equalsIgnoreCase("RecordCount")) {
					subtag.setTextContent(Integer.toString(cardListCount));
				} else if (headertag[k].equalsIgnoreCase("CountryCode") && clientName.equalsIgnoreCase("CHEVRON")) {
					subtag.setTextContent("CHEV" + "_" + clientCountry);
				} else if (headertag[k].equalsIgnoreCase("CountryCode")) {
					subtag.setTextContent(clientCountry);
				} else if (headertag[k].equalsIgnoreCase("StartDate")) {
					subtag.setTextContent(date.split(" ")[0]);
				} else if (headertag[k].equalsIgnoreCase("StartTime")) {
					subtag.setTextContent(date.split(" ")[1]);
				} else if (headertag[k].equalsIgnoreCase("ExternalSupplier")) {
					String externalSupplier = CommonInterfacePage.getExternalSupplier(clientName, clientCountry);
					subtag.setTextContent(externalSupplier);
				} else if (headertag[k].equalsIgnoreCase("SettlementDate")) {
					subtag.setTextContent(date.split(" ")[0]);
				} else if (headertag[k].equalsIgnoreCase("Identifier")
						&& (clientName.equalsIgnoreCase("EMAP") || clientName.equalsIgnoreCase("OTI"))) {
					subtag.setTextContent("Y");
				}

				header.appendChild(subtag);
			}
			Faker faker = new Faker();
			Element subtag = null, loadCardTransactionsubtag = null;
			String locNumber;

			Object[] values = cardList.values().toArray();
			for (int i = 0; i < cardListCount; i++) {
				if (cardList.size() == 0) {
					cardNumber = common.getCardNumberFromIFCSDB(clientName, clientCountry, "Active");
				} else {
					cardNumber = values[i].toString();
				}
				lineItem = CommonInterfacePage.getTransactionLineItem(configProp, cardNumber, clientName,
						clientCountry);
				if (clientName.equalsIgnoreCase("Chevron")) {
					locNumber = common.getExternalRefNoFromDB(clientName, clientCountry);
				} else {
					locNumber = common.getLocationNoFromIFCSDB(clientName, clientCountry, lineItem.get("productCode"));
				}

				Element loadCardTransaction = doc.createElement("LoadCardTransaction");

				for (int j = 0; j < loadTransaction.length; j++) {

					loadCardTransactionsubtag = doc.createElement(loadTransaction[j]);
					if (loadTransaction[j].equalsIgnoreCase("Transaction")) {
						for (k = 0; k < transaction.length; k++) {
							subtag = doc.createElement(transaction[k]);
							if (transaction[k].equalsIgnoreCase("TransactionDateTime")) {
								String value = CommonInterfacePage.funcFetchLoadCardTransStartDateFromIFCSDB(configProp,
										clientNameInProp);
								subtag.setTextContent(value.replace(" ", "T"));
							} else if (transaction[k].equalsIgnoreCase("AuthorisationNumber")) {
								String value = faker.number().digits(6);
								subtag.setTextContent(value);
							} else if (transaction[k].equalsIgnoreCase("ReferenceNumber")) {
								refNo = common.getUniqReferenceNumber();
								System.out.println("Ref No:" + refNo);
								subtag.setTextContent(refNo);
							} else if (transaction[k].equalsIgnoreCase("BatchNumber")) {
								String value = faker.number().digits(6);
								subtag.setTextContent(value);
							} else if (transaction[k].equalsIgnoreCase("BatchSource")) {
								if (clientCountry.equals("NZ") && clientName.equals("BP")) {
									subtag.setTextContent("POS");
								} else if (clientCountry.equals("MY") && clientName.equals("CHEVRON")) {
									subtag.setTextContent("AMB");
								} else {
									subtag.setTextContent("EFT");
								}
							} else if (clientCountry.contains("ZEnergy")
									&& transaction[k].equalsIgnoreCase("OriginalAmount")) {
								// depends on TransactionLineItems
							} else if (transaction[k].equalsIgnoreCase("CaptureTypeCode")) {
								if ((clientName.equalsIgnoreCase("CHEVRON") && clientCountry.equalsIgnoreCase("MY"))
										|| clientName.equalsIgnoreCase("BP")) {
									String value = PropUtils.getPropValue(loadCardTransactionPurchaseProp,
											"TRANSCODE_PURCHASE_" + clientName + clientCountry);
									subtag.setTextContent(value.split(",")[1]);
								} else {
									String value = PropUtils.getPropValue(loadCardTransactionPurchaseProp,
											"TRANSCODE_PURCHASE_" + clientName);
									subtag.setTextContent(value.split(",")[1]);
								}

							} else if (transaction[k].equalsIgnoreCase("TransactionCode")) {
								if ((clientName.equalsIgnoreCase("CHEVRON") && clientCountry.equalsIgnoreCase("MY"))
										|| clientName.equalsIgnoreCase("BP")) {
									String value = PropUtils.getPropValue(loadCardTransactionPurchaseProp,
											"TRANSCODE_PURCHASE_" + clientName + clientCountry);
									subtag.setTextContent(value.split(",")[0]);
								} else {
									String value = PropUtils.getPropValue(loadCardTransactionPurchaseProp,
											"TRANSCODE_PURCHASE_" + clientName);
									subtag.setTextContent(value.split(",")[0]);
								}
							}
							loadCardTransactionsubtag.appendChild(subtag);
						}

					}

					if (loadTransaction[j].equalsIgnoreCase("Card")) {
						for (k = 0; k < card.length; k++) {
							subtag = doc.createElement(card[k]);
							if (card[k].equalsIgnoreCase("CardNumber")) {

								subtag.setTextContent(cardNumber);
							}
							loadCardTransactionsubtag.appendChild(subtag);
						}
					}
					if (loadTransaction[j].equalsIgnoreCase("Location")) {
						for (k = 0; k < location.length; k++) {
							subtag = doc.createElement(location[k]);
							if (location[k].equals("IdassNumber")) {
								subtag.setTextContent(locNumber);
							}

							if (clientName.equalsIgnoreCase("Chevron")) {
								if (location[k].equals("RetailSiteId")) {
									subtag.setTextContent(locNumber);
								}
							}
							loadCardTransactionsubtag.appendChild(subtag);
						}
					}

					if (loadTransaction[j].equalsIgnoreCase("Terminal")) {
						for (k = 0; k < terminal.length; k++) {
							subtag = doc.createElement(terminal[k]);
							if (clientName.equalsIgnoreCase("BP")) {

								if (terminal[k].equals("PhysicalTerminalId")) {
									subtag.setTextContent("77");

								}
							}
							loadCardTransactionsubtag.appendChild(subtag);
						}
					}
					if (loadTransaction[j].equalsIgnoreCase("Vehicle")) {
						for (k = 0; k < vehicle.length; k++) {
							subtag = doc.createElement(vehicle[k]);
							loadCardTransactionsubtag.appendChild(subtag);
						}
					}

					if (loadTransaction[j].equalsIgnoreCase("TransactionLineItem")) {

						for (k = 0; k < lineitem.length; k++) {
							Element TransactionLineItemsSubtag = doc.createElement(lineitem[k]);
							// System.out.println("cardNumber::"+cardNumber);

							if (lineitem[k].equalsIgnoreCase("LineItemCode")) {
								System.out.println("prdcode" + lineItem.get("productCode"));
								TransactionLineItemsSubtag.setTextContent(lineItem.get("productCode"));
							}
							if (lineitem[k].equalsIgnoreCase("Quantity")) {
								TransactionLineItemsSubtag.setTextContent(lineItem.get("volume"));
							}
							if (lineitem[k].equalsIgnoreCase("UnitPrice")) {
								TransactionLineItemsSubtag.setTextContent(lineItem.get("unitPrice"));
							}
							if (lineitem[k].equalsIgnoreCase("NetValue")) {
								// System.out.println("volume" + Integer.parseInt(lineItem.get("volume")));
								// System.out.println("unit price" +
								// Integer.parseInt(lineItem.get("unitPrice")));
								netValue = ((Integer.parseInt(lineItem.get("volume")) / 100)
										* ((Integer.parseInt(lineItem.get("unitPrice")) / 100)) / 100);
								// System.out.println("net value::" + netValue);
								TransactionLineItemsSubtag.setTextContent(Integer.toString(netValue) + "00");
							}
							valuesForValidation.put(refNo, String.valueOf(netValue) + "00");
							loadCardTransactionsubtag.appendChild(TransactionLineItemsSubtag);
						}
					}

					loadCardTransaction.appendChild(loadCardTransactionsubtag);
				}

				rootElement.appendChild(loadCardTransaction);

			}

			// Write the content into XML file
			DOMSource source = new DOMSource(doc);
			StreamResult result = new StreamResult(new File("LoadCardTransaction.xml"));

			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer = transformerFactory.newTransformer();

			transformer.setOutputProperty(OutputKeys.INDENT, "yes");
			transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "4");
			transformer.transform(source, result);

			result = new StreamResult(new File(System.getProperty("user.home") + System.getProperty("file.separator")
					+ "Documents" + System.getProperty("file.separator") + filename));
			System.out.println(filename);
			transformer.transform(source, result);

			ifcsCommonPage.establishThePuttyConnectionbyUserGeneratedRemoteDirectory("XML", "PUTTY_HOST",
					"PUTTY_USERNAME", "PUTTY_PASSWORD", remotedir, filename);

			ifcsCommonPage.interfaceBatchJobwithIFCSLogin(clientName, clientCountry, folderid);
			ifcsHomePage.exitIFCS();
			if (clientName.equals("BP") || clientName.equals("CHEVRON")) {
				folderName = ifcsCommonPage.getControlMFolder(clientName, clientCountry,
						"jobS_LoadcardTransactions_" + clientName + "_" + clientCountry);
				jobsInOrder = ifcsCommonPage
						.getJobsOfFolderInOrder("jobS_LoadcardTransactions_" + clientName + "_" + clientCountry);
			} else {
				folderName = ifcsCommonPage.getControlMFolder(clientName, clientCountry,
						"jobS_LoadcardTransactions_" + clientName);
				jobsInOrder = ifcsCommonPage.getJobsOfFolderInOrder("jobS_LoadcardTransactions_" + clientName);
			}
			interfacePage.establishAndExecuteControlMJobs("ControlM_AWS_UAT", "ContorlM_AWS_userName",
					"ContorlM_AWS_password", folderName, jobsInOrder);

			ifcsCommonPage.validateTransactionPostedOrNot(valuesForValidation);

		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow" })
	public void validateDuplicateTransactions(String clientCountry, String clientName) throws TransformerException {

		test = extent.createTest(clientName + ":" + clientCountry + "  Duplicate transaction moves to suspended",
				"Duplicate transaction moves to suspended");
		// creating object for the Pages

		Map<String, String> dbvalue = null;
		Map<String, String> lineItem = null;
		Map<String, String> valuesForValidation = new LinkedHashMap<String, String>();
		String folderName = null, jobsInOrder = null, cardNumber = null, refNo = null;
		int k, netValue = 0;
		Common common = new Common(driver, test);
		Map<String, String> cardList = new HashMap<String, String>();
		cardList = common.readDataFromPropertyFile("card_" + clientName + "_" + clientCountry, cardOrderedFile);
		CommonInterfacePage CommonInterfacePage = new CommonInterfacePage(driver, test);
		InterfacePage interfacePage = new InterfacePage(driver, test);
		IFCSHomePage ifcsHomePage = new IFCSHomePage(driver, test);
		String clientNameInProp = PropUtils.getPropValue(configProp, clientName + "_" + clientCountry);

		IFCSCommonPage ifcsCommonPage = new IFCSCommonPage(driver, test);
		String[] headertag = { "FileName", "SequenceNumber", "RecordCount", "CountryCode", "StartDate", "StartTime",
				"ExternalSupplier", "SettlementDate", "ExternalFileName" };
		String[] loadTransaction = { "Transaction", "Card", "Location", "Terminal", "Vehicle", "TransactionLineItem" };
		String[] card = { "CardNumber", "CardType" };
		String[] transaction = { "CaptureTypeCode", "TransactionCode", "AttentionKey", "ReferenceNumber", "OrderNumber",
				"FleetNumber", "SubEntityNumber", "TransactionDateTime", "AuthorisationNumber", "OdometerReading",
				"BatchNumber", "BatchSource", "ExtraCardNo" };
		/*
		 * String[] transaction1 = { "CaptureTypeCode", "TransactionCode",
		 * "AttentionKey", "ReferenceNumber", "OrderNumber", "FleetNumber",
		 * "SubEntityNumber", "TransactionDateTime", "AuthorisationNumber",
		 * "OdometerReading", "BatchNumber", "BatchSource", "ExtraCardNo" };
		 */
		String[] location = { "IdassNumber", "StreetAddressState", "RetailSiteId", "MarketingTerritory",
				"AdminTerritory" };
		String[] terminal = { "PhysicalTerminalId", "TerminalStatus", "TerminalType" };
		String[] vehicle = { "RegistrationNumber", "CurrentOdometerReading" };
		String[] lineitem = { "LineItemCode", "Quantity", "UnitPrice", "NetValue" };
		String date = CommonInterfacePage.funcFetchLoadCardTransStartDateFromIFCSDB(configProp, clientNameInProp);

		String folderid = CommonInterfacePage.getfolderid(clientName, clientCountry);
		int cardListCount = cardList.size();
		if (cardListCount == 0) {
			cardListCount = 2;
		}

		String client_mid = CommonInterfacePage.funcFetchLoadCardTransClientMidFromDB(configProp, clientName,
				clientCountry);
		String remotedir;
		if (clientName.equalsIgnoreCase("BP")) {
			remotedir = PropUtils.getPropValue(configProp, "IFCS_LOADCARDTRANSACTION") + folderid + "/";
		} else {
			remotedir = PropUtils.getPropValue(configProp, "IFCS_LOADCARDTRANSACTION") + client_mid + "/" + folderid
					+ "/";
		}
		try {
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			Document doc = docBuilder.newDocument();

			Element rootElement = doc.createElement("LoadCardTransactions");
			doc.appendChild(rootElement);

			Element header = doc.createElement("Header");
			rootElement.appendChild(header);
			dbvalue = CommonInterfacePage.fetchLoadCardTransSeqNoandPrefix(configProp, clientName, clientCountry,
					folderid);
			String filename = dbvalue.get("prefixvalue") + dbvalue.get("lastSequenceNumber") + ".xml";
			System.out.println(dbvalue);
			for (k = 0; k < headertag.length; k++) {
				Element subtag = doc.createElement(headertag[k]);
				if (headertag[k].equalsIgnoreCase("FileName")) {

					System.out.println(
							"file Name:" + dbvalue.get("prefixvalue") + dbvalue.get("lastSequenceNumber") + ".xml");
					subtag.setTextContent(dbvalue.get("prefixvalue") + dbvalue.get("lastSequenceNumber") + ".xml");
				} else if (headertag[k].equalsIgnoreCase("SequenceNumber")) {
					subtag.setTextContent(dbvalue.get("lastSequenceNumber"));
				} else if (headertag[k].equalsIgnoreCase("RecordCount")) {
					subtag.setTextContent(Integer.toString(cardListCount));
				} else if (headertag[k].equalsIgnoreCase("CountryCode") && clientName.equalsIgnoreCase("CHEVRON")) {
					subtag.setTextContent("CHEV" + "_" + clientCountry);
				} else if (headertag[k].equalsIgnoreCase("CountryCode")) {
					subtag.setTextContent(clientCountry);
				} else if (headertag[k].equalsIgnoreCase("StartDate")) {
					subtag.setTextContent(date.split(" ")[0]);
				} else if (headertag[k].equalsIgnoreCase("StartTime")) {
					subtag.setTextContent(date.split(" ")[1]);
				} else if (headertag[k].equalsIgnoreCase("ExternalSupplier")) {
					String externalSupplier = CommonInterfacePage.getExternalSupplier(clientName, clientCountry);
					subtag.setTextContent(externalSupplier);
				} else if (headertag[k].equalsIgnoreCase("SettlementDate")) {
					subtag.setTextContent(date.split(" ")[0]);
				} else if (headertag[k].equalsIgnoreCase("Identifier")
						&& (clientName.equalsIgnoreCase("EMAP") || clientName.equalsIgnoreCase("OTI"))) {
					subtag.setTextContent("Y");
				}

				header.appendChild(subtag);
			}
			Faker faker = new Faker();
			Element subtag = null, loadCardTransactionsubtag = null;
			String locNumber;

			Object[] values = cardList.values().toArray();
			for (int i = 0; i < cardListCount; i++) {
				if (cardList.size() == 0) {
					cardNumber = common.getCardNumberFromIFCSDB(clientName, clientCountry, "Active");
				} else {
					cardNumber = values[i].toString();
				}
				lineItem = CommonInterfacePage.getTransactionLineItem(configProp, cardNumber, clientName,
						clientCountry);
				if (clientName.equalsIgnoreCase("Chevron")) {
					locNumber = common.getExternalRefNoFromDB(clientName, clientCountry);
				} else {
					locNumber = common.getLocationNoFromIFCSDB(clientName, clientCountry, lineItem.get("productCode"));
				}

				Element loadCardTransaction = doc.createElement("LoadCardTransaction");

				for (int j = 0; j < loadTransaction.length; j++) {

					loadCardTransactionsubtag = doc.createElement(loadTransaction[j]);
					if (loadTransaction[j].equalsIgnoreCase("Transaction")) {
						for (k = 0; k < transaction.length; k++) {
							subtag = doc.createElement(transaction[k]);
							if (transaction[k].equalsIgnoreCase("TransactionDateTime")) {
								String value = CommonInterfacePage.funcFetchLoadCardTransStartDateFromIFCSDB(configProp,
										clientNameInProp);
								subtag.setTextContent(value.replace(" ", "T"));
							} else if (transaction[k].equalsIgnoreCase("AuthorisationNumber")) {
								String value = faker.number().digits(6);
								subtag.setTextContent(value);
							} else if (transaction[k].equalsIgnoreCase("ReferenceNumber")) {
								refNo = common.getUniqReferenceNumber();
								System.out.println("Ref No:" + refNo);
								subtag.setTextContent(refNo);
							} else if (transaction[k].equalsIgnoreCase("BatchNumber")) {
								String value = faker.number().digits(6);
								subtag.setTextContent(value);
							} else if (transaction[k].equalsIgnoreCase("BatchSource")) {
								if (clientCountry.equals("NZ") && clientName.equals("BP")) {
									subtag.setTextContent("POS");
								} else if (clientCountry.equals("MY") && clientName.equals("CHEVRON")) {
									subtag.setTextContent("AMB");
								} else {
									subtag.setTextContent("EFT");
								}
							} else if (clientCountry.contains("ZEnergy")
									&& transaction[k].equalsIgnoreCase("OriginalAmount")) {
								// depends on TransactionLineItems
							} else if (transaction[k].equalsIgnoreCase("CaptureTypeCode")) {
								if ((clientName.equalsIgnoreCase("CHEVRON") && clientCountry.equalsIgnoreCase("MY"))
										|| clientName.equalsIgnoreCase("BP")) {
									String value = PropUtils.getPropValue(loadCardTransactionPurchaseProp,
											"TRANSCODE_PURCHASE_" + clientName + clientCountry);
									subtag.setTextContent(value.split(",")[1]);
								} else {
									String value = PropUtils.getPropValue(loadCardTransactionPurchaseProp,
											"TRANSCODE_PURCHASE_" + clientName);
									subtag.setTextContent(value.split(",")[1]);
								}

							} else if (transaction[k].equalsIgnoreCase("TransactionCode")) {
								if ((clientName.equalsIgnoreCase("CHEVRON") && clientCountry.equalsIgnoreCase("MY"))
										|| clientName.equalsIgnoreCase("BP")) {
									String value = PropUtils.getPropValue(loadCardTransactionPurchaseProp,
											"TRANSCODE_PURCHASE_" + clientName + clientCountry);
									subtag.setTextContent(value.split(",")[0]);
								} else {
									String value = PropUtils.getPropValue(loadCardTransactionPurchaseProp,
											"TRANSCODE_PURCHASE_" + clientName);
									subtag.setTextContent(value.split(",")[0]);
								}
							}
							loadCardTransactionsubtag.appendChild(subtag);
						}
					}

					if (loadTransaction[j].equalsIgnoreCase("Card")) {
						for (k = 0; k < card.length; k++) {
							subtag = doc.createElement(card[k]);
							if (card[k].equalsIgnoreCase("CardNumber")) {

								subtag.setTextContent(cardNumber);
							}
							loadCardTransactionsubtag.appendChild(subtag);
						}
					}
					if (loadTransaction[j].equalsIgnoreCase("Location")) {
						for (k = 0; k < location.length; k++) {
							subtag = doc.createElement(location[k]);
							if (location[k].equals("IdassNumber")) {
								subtag.setTextContent(locNumber);
							}

							if (clientName.equalsIgnoreCase("Chevron")) {
								if (location[k].equals("RetailSiteId")) {
									subtag.setTextContent(locNumber);
								}
							}
							loadCardTransactionsubtag.appendChild(subtag);
						}
					}

					if (loadTransaction[j].equalsIgnoreCase("Terminal")) {
						for (k = 0; k < terminal.length; k++) {
							subtag = doc.createElement(terminal[k]);
							if (clientName.equalsIgnoreCase("BP")) {

								if (terminal[k].equals("PhysicalTerminalId")) {
									subtag.setTextContent("77");

								}
							}
							loadCardTransactionsubtag.appendChild(subtag);
						}
					}
					if (loadTransaction[j].equalsIgnoreCase("Vehicle")) {
						for (k = 0; k < vehicle.length; k++) {
							subtag = doc.createElement(vehicle[k]);
							loadCardTransactionsubtag.appendChild(subtag);
						}
					}

					if (loadTransaction[j].equalsIgnoreCase("TransactionLineItem")) {

						for (k = 0; k < lineitem.length; k++) {
							Element TransactionLineItemsSubtag = doc.createElement(lineitem[k]);
							// System.out.println("cardNumber::"+cardNumber);

							if (lineitem[k].equalsIgnoreCase("LineItemCode")) {
								System.out.println("prdcode" + lineItem.get("productCode"));
								TransactionLineItemsSubtag.setTextContent(lineItem.get("productCode"));
							}
							if (lineitem[k].equalsIgnoreCase("Quantity")) {
								TransactionLineItemsSubtag.setTextContent(lineItem.get("volume"));
							}
							if (lineitem[k].equalsIgnoreCase("UnitPrice")) {
								TransactionLineItemsSubtag.setTextContent(lineItem.get("unitPrice"));
							}
							if (lineitem[k].equalsIgnoreCase("NetValue")) {
								// System.out.println("volume" + Integer.parseInt(lineItem.get("volume")));
								// System.out.println("unit price" +
								// Integer.parseInt(lineItem.get("unitPrice")));
								netValue = ((Integer.parseInt(lineItem.get("volume")) / 100)
										* ((Integer.parseInt(lineItem.get("unitPrice")) / 100)) / 100);
								// System.out.println("net value::" + netValue);
								TransactionLineItemsSubtag.setTextContent(Integer.toString(netValue) + "00");
							}
							valuesForValidation.put(refNo, String.valueOf(netValue) + "00");
							loadCardTransactionsubtag.appendChild(TransactionLineItemsSubtag);
						}
					}

					loadCardTransaction.appendChild(loadCardTransactionsubtag);

				}
				rootElement.appendChild(doc.adoptNode(loadCardTransaction).cloneNode(true));
				rootElement.appendChild(loadCardTransaction);

			}

			// Write the content into XML file
			DOMSource source = new DOMSource(doc);
			StreamResult result = new StreamResult(new File("LoadCardTransaction.xml"));

			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer = transformerFactory.newTransformer();

			transformer.setOutputProperty(OutputKeys.INDENT, "yes");
			transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "4");
			transformer.transform(source, result);

			result = new StreamResult(new File(System.getProperty("user.home") + System.getProperty("file.separator")
					+ "Documents" + System.getProperty("file.separator") + filename));
			System.out.println(filename);
			transformer.transform(source, result);

			ifcsCommonPage.establishThePuttyConnectionbyUserGeneratedRemoteDirectory("XML", "PUTTY_HOST",
					"PUTTY_USERNAME", "PUTTY_PASSWORD", remotedir, filename);
			System.out.println("Folder id:" + folderid);
			ifcsCommonPage.interfaceBatchJobwithIFCSLogin(clientName, clientCountry, folderid);
			ifcsHomePage.exitIFCS();
			if (clientName.equals("BP") || clientName.equals("CHEVRON")) {
				folderName = ifcsCommonPage.getControlMFolder(clientName, clientCountry,
						"jobS_LoadcardTransactions_" + clientName + "_" + clientCountry);
				jobsInOrder = ifcsCommonPage
						.getJobsOfFolderInOrder("jobS_LoadcardTransactions_" + clientName + "_" + clientCountry);
			} else {
				folderName = ifcsCommonPage.getControlMFolder(clientName, clientCountry,
						"jobS_LoadcardTransactions_" + clientName);
				jobsInOrder = ifcsCommonPage.getJobsOfFolderInOrder("jobS_LoadcardTransactions_" + clientName);
			}
			interfacePage.establishAndExecuteControlMJobs("ControlM_AWS_UAT", "ContorlM_AWS_userName",
					"ContorlM_AWS_password", folderName, jobsInOrder);

			ifcsCommonPage.validateTransactionPostedOrNot(valuesForValidation);

		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow" })
	public void validateTransactionWithInvalidProductCode(String clientCountry, String clientName)
			throws TransformerException {

		test = extent.createTest(
				clientName + ":" + clientCountry + "  TC-1697 TC04_TxnMgmt_Susp_Txn Invalid location and Product",
				"Transaction is suspended if card is swiped with invalid location / invalid Product");

		// creating object for the Pages
		TransactionComponentPage transactionPage = new TransactionComponentPage(driver, test);
		Map<String, String> valuesForValidation = new LinkedHashMap<String, String>();

		// Input Values for XML Creation
		Map<String, String> inputValues = transactionPage.inputValuesForInvalidProductCode(clientName, clientCountry);

		// XML Creation
		valuesForValidation = transactionPage.XMLCreationForTransaction(clientName, clientCountry, inputValues);

		// Validate Transaction Posting
		if (clientName.equalsIgnoreCase("ZEnergy")) {
			transactionPage.validateTransactionPostedOrNot(valuesForValidation, "Invalid Product Code");
		} else {
			transactionPage.validateTransactionPostedOrNot(valuesForValidation, "Invalid POS Line Item Product Code");
		}
	}

	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow" })
	public void validateTransactionWithInvalidLocation(String clientCountry, String clientName)
			throws TransformerException {

		test = extent.createTest(
				clientName + ":" + clientCountry + "  Load Card transaction file upload with Invalid Location",
				"Load Card transaction file upload with Invalid Location");

		// creating object for the Pages
		TransactionComponentPage transactionPage = new TransactionComponentPage(driver, test);
		Map<String, String> valuesForValidation = new LinkedHashMap<String, String>();

		// Input Values for XML Creation
		Map<String, String> inputValues = transactionPage.inputValuesForInvalidLocation(clientName, clientCountry);

		// XML Creation
		valuesForValidation = transactionPage.XMLCreationForTransaction(clientName, clientCountry, inputValues);

		// Validate Transaction Posting
		if (clientName.equalsIgnoreCase("ZEnergy")) {
			transactionPage.validateTransactionPostedOrNot(valuesForValidation, "Invalid Location Agmt");
		} else if (clientName.equalsIgnoreCase("BP") || clientName.equalsIgnoreCase("OTI")) {
			transactionPage.validateTransactionPostedOrNot(valuesForValidation, "Location Agreement Invalid");
		} else {
			transactionPage.validateTransactionPostedOrNot(valuesForValidation, "Location invalid");
		}
	}

	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow" })
	public void validateTransactionWithFutureDateAndTime(String clientCountry, String clientName)
			throws TransformerException {

		test = extent.createTest(
				clientName + ":" + clientCountry + "  Load Card transaction file upload with Invalid Time",
				"Load Card transaction file upload with Invalid Time");

		// creating object for the Pages
		TransactionComponentPage transactionPage = new TransactionComponentPage(driver, test);
		Map<String, String> valuesForValidation = new LinkedHashMap<String, String>();

		// Input Values for XML Creation
		Map<String, String> inputValues = transactionPage.inputValuesForFutureDateAndTime(clientName, clientCountry);

		// XML Creation
		valuesForValidation = transactionPage.XMLCreationForTransaction(clientName, clientCountry, inputValues);

		// Validate Transaction Posting
		if (clientName.equalsIgnoreCase("ZEnergy")) {
			transactionPage.validateTransactionPostedOrNot(valuesForValidation, "Future Dates Trans");
		} else {
			transactionPage.validateTransactionPostedOrNot(valuesForValidation, "Transaction is Future Dated");
		}

	}

	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow" })
	public void validateTransactionWithInvalidUnitPrice(String clientCountry, String clientName)
			throws TransformerException {

		test = extent.createTest(
				clientName + ":" + clientCountry + "  Load Card transaction file upload with Invalid Unit price",
				"Load Card transaction file upload with Invalid Unit price");

		// creating object for the Pages
		TransactionComponentPage transactionPage = new TransactionComponentPage(driver, test);
		Map<String, String> valuesForValidation = new LinkedHashMap<String, String>();

		// Input Values for XML Creation
		Map<String, String> inputValues = transactionPage.inputValuesForInvalidUnitPrice(clientName, clientCountry);

		// XML Creation
		valuesForValidation = transactionPage.XMLCreationForTransaction(clientName, clientCountry, inputValues);

		// Validate Transaction Posting
		transactionPage.validateTransactionPostedOrNot(valuesForValidation, "Unit Price not within Range");

	}

	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow" })
	public void validateTransactionDamagedCardStatus(String clientCountry, String clientName)
			throws TransformerException {

		test = extent.createTest(clientName + ":" + clientCountry + "  Post transaction for Damaged cards",
				"Post transaction for Damaged cards");

		// Initialize objects
		Map<String, String> inputvalues = new HashMap<String, String>();
		TransactionComponentPage transactionComponentPage = new TransactionComponentPage(driver, test);
		Common common = new Common(driver, test);
		Map<String, String> valuesForValidation = new LinkedHashMap<String, String>();
		// Getting input values for XML Creation
		inputvalues = transactionComponentPage.inputValuesForCardStatus(clientName, clientCountry, "Damaged");
		// XML Creation
		valuesForValidation = transactionComponentPage.XMLCreationForTransaction(clientCountry, clientName,
				inputvalues);

		String filename = Constants.TRANSACTION_TEMP_FILE;
		String reference = inputvalues.get("reference");
		String card = inputvalues.get("CardNumber");

		common.updatePropFile("TRANSACTION_DAMAGED_CARD_REF_" + clientName + "_" + clientCountry, reference, filename);
		common.updatePropFile("TRANSACTION_DAMAGED_CARD_" + clientName + "_" + clientCountry, card, filename);

		// Validate transaction posted or not
		// transactionComponentPage.validateSuspendTransaction(valuesForValidation,
		// "Card Locked-Out");

	}

	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow" })
	public void validateTransactionlostCardStatus(String clientCountry, String clientName) throws TransformerException {

		test = extent.createTest(clientName + ":" + clientCountry + "  Post transaction for Lost cards",
				"Post transaction for Lost cards");

		// Initialize objects
		Map<String, String> inputvalues = new HashMap<String, String>();
		Map<String, String> valuesForValidation = new LinkedHashMap<String, String>();
		TransactionComponentPage transactionComponentPage = new TransactionComponentPage(driver, test);
		// Getting input values for XML Creation
		inputvalues = transactionComponentPage.inputValuesForCardStatus(clientName, clientCountry, "Lost");
		// XML Creation
		valuesForValidation = transactionComponentPage.XMLCreationForTransaction(clientCountry, clientName,
				inputvalues);
		// Validate transaction posted or not
		transactionComponentPage.validateSuspendTransaction(valuesForValidation, "Card Locked-Out");
	}

	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow" })
	public void validateTransactionTempBlockCardStatus(String clientCountry, String clientName)
			throws TransformerException {

		test = extent.createTest(clientName + ":" + clientCountry + "  Post transaction for TempBlock cards",
				"Post transaction for TempBlock cards");

		// Initialize objects
		Map<String, String> inputvalues = new HashMap<String, String>();
		TransactionComponentPage transactionComponentPage = new TransactionComponentPage(driver, test);
		Map<String, String> valuesForValidation = new LinkedHashMap<String, String>();

		// Getting input values for XML Creation
		inputvalues = transactionComponentPage.inputValuesForCardStatus(clientName, clientCountry, "Temp");

		// XML Creation
		valuesForValidation = transactionComponentPage.XMLCreationForTransaction(clientCountry, clientName,
				inputvalues);

		// Validate transaction posted or not
		transactionComponentPage.validateSuspendTransaction(valuesForValidation, "Card Locked-Out");

	}

	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow" })
	public void validateTransactionWithValidOdometerReadings(String clientCountry, String clientName)
			throws TransformerException {

		test = extent.createTest(
				clientName + ":" + clientCountry + "  Post transaction for valid odometer reading for vehicle card",
				"Post transaction for valid odometer reading for vehicle card");

		// Initialize objects
		Map<String, String> inputvalues = new HashMap<String, String>();
		TransactionComponentPage transactionComponentPage = new TransactionComponentPage(driver, test);
		IFCSCommonPage ifcsCommonPage = new IFCSCommonPage(driver, test);
		Map<String, String> valuesForValidation = new LinkedHashMap<String, String>();

		// Getting input values for XML Creation
		inputvalues = transactionComponentPage.inputValuesFoValidOdometerReadings(clientName, clientCountry);

		// XML Creation
		valuesForValidation = transactionComponentPage.XMLCreationForTransaction(clientName, clientCountry,
				inputvalues);

		// Validate transaction posted or not
		ifcsCommonPage.validateTransactionPostedOrNot(valuesForValidation);

	}

	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow" })
	public void validateTransactionOverCreditLimits(String clientCountry, String clientName)
			throws TransformerException {

		test = extent.createTest(
				clientName + ":" + clientCountry + "  Post transaction for valid odometer reading for vehicle card",
				"Post transaction for valid odometer reading for vehicle card");

		// Initialize objects
		Map<String, String> inputvalues = new HashMap<String, String>();
		TransactionComponentPage transactionComponentPage = new TransactionComponentPage(driver, test);
		IFCSCommonPage ifcsCommonPage = new IFCSCommonPage(driver, test);
		Map<String, String> valuesForValidation = new LinkedHashMap<String, String>();

		// Getting input values for XML Creation
		inputvalues = transactionComponentPage.inputValuesForValidCreditLimits(clientName, clientCountry);

		// XML Creation
		valuesForValidation = transactionComponentPage.XMLCreationForTransaction(clientName, clientCountry,
				inputvalues);

		// Validate transaction posted or not
		ifcsCommonPage.validateTransactionPostedOrNot(valuesForValidation);
		transactionComponentPage.validateCreditLimitsFromDB(inputvalues, clientName, clientCountry);

	}

	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow" })
	public void validateTransactionMerchantServiceFeeAndTax(String clientCountry, String clientName)
			throws TransformerException {

		test = extent.createTest(clientName + ":" + clientCountry + "  Post transaction for verifying MSF",
				"Post transaction for verifying MSF");

		// Initialize objects
		Map<String, String> inputvalues = new HashMap<String, String>();
		TransactionComponentPage transactionComponentPage = new TransactionComponentPage(driver, test);
		IFCSCommonPage ifcsCommonPage = new IFCSCommonPage(driver, test);
		Map<String, String> valuesForValidation = new LinkedHashMap<String, String>();

		// Getting input values for XML Creation
		inputvalues = transactionComponentPage.inputValuesForMerchantServiceFeeAndTax(clientName, clientCountry);

		valuesForValidation = transactionComponentPage.XMLCreationForTransaction(clientName, clientCountry,
				inputvalues);

		// Validate transaction posted or not
		ifcsCommonPage.validateTransactionPostedOrNot(valuesForValidation);

		transactionComponentPage.validateMerchantServiceFeeAndTax(valuesForValidation, inputvalues);

	}

	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow", "Regression" })
	public void validateXMLCreationForTransactionWFE(String clientCountry, String clientName)
			throws TransformerException {

		test = extent.createTest(clientName + ":" + clientCountry + "  Post transaction for TempBlock cards",
				"Post transaction for TempBlock cards");

		// Initialize objects
		/*
		 * Map<String, String> inputvalues = new HashMap<String, String>();
		 * TransactionComponentPage transactionComponentPage = new
		 * TransactionComponentPage(driver, test); Map<String, String>
		 * valuesForValidation = new LinkedHashMap<String, String>();
		 * 
		 * // Getting input values for XML Creation
		 * inputvalues=transactionComponentPage.inputValuesForCardStatus(clientName,
		 * clientCountry,"Temp");
		 * 
		 * // XML Creation valuesForValidation =
		 * transactionComponentPage.XMLCreationForTransactionWFE(clientCountry,
		 * clientName, inputvalues);
		 * 
		 * // Validate transaction posted or not
		 * transactionComponentPage.validateSuspendTransaction(valuesForValidation,"Card
		 * Locked-Out");
		 */
	}

	/**
	 * Implemented by Venkata Davu & Nithya
	 * 
	 * @param clientCountry
	 * @param clientName
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow" })
	public void validateVINCIIFileProcess(@Optional("RU") String clientCountry, @Optional("SHELL") String clientName) {
		String inputTemplateFileName = "VTE04C2202192.A0000UOZ.RCV";

		test = extent.createTest(clientName + ":" + clientCountry
				+ "  Verify VinCii Transaction file prosessing, Verify VinCii Transaction file prosessing");
		// creating object for the Pages
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		IFCSLoginPage ifcsloginPage = new IFCSLoginPage(driver, test);
		InterfacePage interfacePage = new InterfacePage(driver, test);
		CommonInterfacePage commoninterfacePage = new CommonInterfacePage(driver, test);
		/*
		 * Common common=new Common(driver,test); IFCSHomePage IFCSHomePage = new
		 * IFCSHomePage(driver, test); IFCSCommonPage ifcsCommonPage = new
		 * IFCSCommonPage(driver, test); MaintainCustomerPage maintainCustomerPage = new
		 * MaintainCustomerPage(driver, test); TransactionListPage transactionListPage =
		 * new TransactionListPage(driver, test);
		 */
		ifcsloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		ifcsloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");

		String badgeNumber = commoninterfacePage.getBadgeNumbersForNoOfCardFromICPDB(10, "Normal Service");

		interfacePage.updateOrValidateFlatFile(vinciiconfigProp, "OutgoingFile",
				"IE_INPUTFILE_FOLDER_LOADCARDTRANSACTIONS", badgeNumber, clientName, clientCountry,
				inputTemplateFileName);

		IFCSHomePage.exitIFCS();

	}

	/**
	 * Implemented by Karuppasamy updated by raxsana babu
	 * 
	 * @param clientCountry
	 * @param clientName    RQ-864
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow" })
	public void validateManualTransactionForDualCards(@Optional("BE") String clientCountry,
			@Optional("WFE") String clientName) {

		test = extent.createTest(clientName + ":" + clientCountry
				+ " TC-1659 TC07_TxnMgmt_Manual_Txn Dual Cards,TC-1660 TC08_TxnMgmt_Manual_Txn Customer Breakdown,\r\n"
				+ "TC-1661 TC09_TxnMgmt_Manual_Txn Merchant Breakdown",
				"RQ-864 Able to post transaction using Dual Cards from IFCS");
		// creating object for the Pages
		IFCSLoginPage ifcsloginPage = new IFCSLoginPage(driver, test);
		TransactionComponentPage transactionComponentPage = new TransactionComponentPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		Map<String, String> inputvalues = new HashMap<String, String>();
		// Calling Functions
		ifcsloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		ifcsloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		IFCSHomePage.gotoApplicationAndClickApplicationMenu();
		IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);
		Faker fakerN = new Faker();
		String f_referenceNo = fakerN.number().digits(5);
		inputvalues = transactionComponentPage.inputValuesForDualCardsTransaction(clientName, clientCountry, "Y");

		IFCSHomePage.gotoTransactionAndClickManageTransaction();
		TransactionListPage transactionListPage = new TransactionListPage(driver, test);

		transactionListPage.enterTransactionBatchDetails(true, "160", "1", clientName);
		transactionListPage.enterManualTransactionDetails(inputvalues.get("date"), f_referenceNo,
				inputvalues.get("CardNumber"), inputvalues.get("DualCardNumber"), inputvalues.get("LocationNumber"),
				"160", "");
		transactionListPage.enterTransactionLineItems(inputvalues.get("productCode"), "160", "100", "160");
		transactionListPage.validatePostManualTransaction("Validation successful");
		transactionListPage.validatePostedInTransaction(f_referenceNo);
		transactionComponentPage.validateCustomerBreakdown(f_referenceNo);
		transactionComponentPage.validateMerchantBreakdown(f_referenceNo);
		IFCSHomePage.exitIFCS();
	}

	/**
	 * Implemented by Karuppasamy updated by Raxsana Babu
	 * 
	 * @param clientCountry
	 * @param clientName    RQ-897
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow" })
	public void validateManualReturnTransaction(@Optional("BE") String clientCountry,
			@Optional("WFE") String clientName) {

		test = extent.createTest(
				clientName + ":" + clientCountry
						+ " TC-1702 TC01_TxnMgmt_RetTxn_Manual Return,TC-1704 TC03_TxnMgmt_RetTxn_Acc Bal",
				"RQ-897 Post Return/Refund transactions");
		// creating object for the Pages
		IFCSLoginPage ifcsloginPage = new IFCSLoginPage(driver, test);
		TransactionComponentPage transactionComponentPage = new TransactionComponentPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		WFECommon wfeCommon = new WFECommon(driver, test);
		Map<String, String> inputvalues = new HashMap<String, String>();
		// Calling Functions
		ifcsloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		ifcsloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		IFCSHomePage.gotoApplicationAndClickApplicationMenu();
		IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);
		// TestData
		Faker fakerN = new Faker();
		String f_referenceNo = fakerN.number().digits(5);

		inputvalues = transactionComponentPage.inputValuesForTransaction(clientName, clientCountry, "Y", "");

		IFCSHomePage.gotoTransactionAndClickManageTransaction();
		TransactionListPage transactionListPage = new TransactionListPage(driver, test);
		// ActualBalance
		String actualBalanceBefore = wfeCommon.getAccountActualBalance(inputvalues.get("CardNumber"));
		transactionListPage.enterTransactionBatchDetails(true, "160", "1", clientName);
		transactionListPage.enterManualTransactionDetails(inputvalues.get("date"), f_referenceNo,
				inputvalues.get("CardNumber"), "", inputvalues.get("LocationNumber"), "160", "Return");
		transactionListPage.enterTransactionLineItems(inputvalues.get("productCode"), "160", "100", "160");
		transactionListPage.validatePostManualTransaction("Validation successful");
		transactionListPage.validatePostedInTransaction(f_referenceNo);
		transactionComponentPage.validateAccountBalance(actualBalanceBefore, f_referenceNo,
				inputvalues.get("CardNumber"));
		IFCSHomePage.exitIFCS();
	}

	@Parameters({ "clientCountry", "clientName", "cardCount" })
	@Test( groups = { "BusinessFlow" })
	public void validateXMLCreationForTransactionWFE(@Optional("BE") String clientCountry,
			@Optional("WFE") String clientName, String cardCount) throws TransformerException {
		test = extent.createTest(clientName + ":" + clientCountry + "  Transaction creation", "Trnasaction creation");
		// creating object for the Pages
		WFECommon wfeCommon = new WFECommon(driver, test);
		Map<String, String> inputValues = new HashMap<String, String>();
		wfeCommon.XMLCreationForTransactionWFE(clientName, clientCountry, inputValues, "N", "0");
	}

	/**
	 * Added by Rathna
	 * 
	 * @param clientCountry
	 * @param clientName    Business Flow ID:BF-169
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow" })
	public void ValidateSundryAdjustmentPostPayment(@Optional("BE") String clientCountry,
			@Optional("WFE") String clientName) {

		test = extent.createTest(clientName + ":" + clientCountry + " ID:BF-169 Sundry Adjustment",
				"Verify adjustment is applied for any missed transaction customer ");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);

		Common common = new Common(driver, test);
		MaintainAccountPage maintainAccountPage = new MaintainAccountPage(driver, test);

		TransactionListPage transactionListPage = new TransactionListPage(driver, test);

		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");

		IFCSloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		IFCSHomePage.gotoApplicationAndClickApplicationMenu();
		IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);
		common.chooseApplicationNumberFromApplicationList("Approved"); // changed to Approved from TL APP approved
		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		common.chooseCustomerNumberFromCustomerList();
		IFCSHomePage.gotoAccountAndClickAccountDetails();
		// Get current Date
		String currentDate = common.getCurrentIFCSDateFromDB(clientName + clientCountry);
		// Get the IFCS current date
		String ifcsCurrentDate = common.enterADateValueInStatusBeginDateField("Current", currentDate);
		Faker fakerN = new Faker();
		String f_referenceNo = fakerN.number().digits(3);
		maintainAccountPage.validatePostSundryAdjustmentTransaction(clientName, ifcsCurrentDate, f_referenceNo);
		IFCSHomePage.gotoTransactionAndClickManageTransaction();
		transactionListPage.validatePostedSundryadjustmentTransaction(ifcsCurrentDate, f_referenceNo);
		IFCSHomePage.exitIFCS();

	}

	/**
	 * Implemented by Rathna * @param clientCountry
	 * 
	 * @param clientName RQ-865
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow" })
	public void validatePostManualPurchaseWithFuelProduct(@Optional("BE") String clientCountry,
			@Optional("WFE") String clientName) {

		test = extent.createTest(clientName + ":" + clientCountry + " TC-1662 TC10_TxnMgmt_Manual_Txn Fuel Product",
				"RQ-865:Able to post manual transactions with Product details (under Line items)");

		// creating object for the Pages
		IFCSLoginPage ifcsloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		TransactionListPage transactionListPage = new TransactionListPage(driver, test);
		Common common = new Common(driver, test);
		// CommonInterfacePage commonInterfacePage = new CommonInterfacePage(driver,
		// test);
		TransactionComponentPage transactionComponentPage = new TransactionComponentPage(driver, test);
		Map<String, String> inputvalues = new HashMap<String, String>();

		// Calling Functions
		ifcsloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		ifcsloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		IFCSHomePage.gotoApplicationAndClickApplicationMenu();

		// TestData
		Faker fakerN = new Faker();
		String f_referenceNo = fakerN.number().digits(3);
		IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);
		String currentDate = common.getCurrentIFCSDateFromDB(clientName + clientCountry);
		String ifcsCurrentDate = common.enterADateValueInStatusBeginDateField("Current", currentDate);

		inputvalues = transactionComponentPage.inputValuesForCardStatus(clientName, clientCountry, "Active");
		System.out.println("inputvalues::" + inputvalues);
		// Transaction Details
		IFCSHomePage.gotoTransactionAndClickManageTransaction();
		transactionListPage.enterTransactionBatchDetails(true, "100", "1", clientName);
		transactionListPage.enterManualTransactionDetails(ifcsCurrentDate, f_referenceNo, inputvalues.get("CardNumber"),
				"", inputvalues.get("LocationNumber"), "100", "");
		transactionListPage.enterTransactionLineItems(inputvalues.get("productCode"), "100", "100", "100");
		transactionListPage.validatePostManualTransaction("Validation successful");
		IFCSHomePage.exitIFCS();
	}

	/**
	 * Implemented by Rathna * @param clientCountry
	 * 
	 * @param clientName RQ-897
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow" })
	public void validatePostRetunrOrReFundTrancations(@Optional("BE") String clientCountry,
			@Optional("WFE") String clientName) {

		test = extent.createTest(clientName + ":" + clientCountry + " TC-1702 TC01_TxnMgmt_RetTxn_Manual Return",
				"RQ-897:Post Return/Refund transactions");

		// creating object for the Pages
		IFCSLoginPage ifcsloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		TransactionListPage transactionListPage = new TransactionListPage(driver, test);
		Common common = new Common(driver, test);
		// CommonInterfacePage commonInterfacePage = new CommonInterfacePage(driver,
		// test);
		TransactionComponentPage transactionComponentPage = new TransactionComponentPage(driver, test);
		Map<String, String> inputvalues = new HashMap<String, String>();

		// Calling Functions
		ifcsloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		ifcsloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		IFCSHomePage.gotoApplicationAndClickApplicationMenu();

		// TestData
		Faker fakerN = new Faker();
		String f_referenceNo = fakerN.number().digits(3);
		IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);
		String currentDate = common.getCurrentIFCSDateFromDB(clientName + clientCountry);
		String ifcsCurrentDate = common.enterADateValueInStatusBeginDateField("Current", currentDate);

		inputvalues = transactionComponentPage.inputValuesForCardStatus(clientName, clientCountry, "Active");
		System.out.println("inputvalues::" + inputvalues);
		// Transaction Details
		IFCSHomePage.gotoTransactionAndClickManageTransaction();
		transactionListPage.enterTransactionBatchDetails(true, "100", "1", clientName);
		transactionListPage.enterManualTransactionDetails(ifcsCurrentDate, f_referenceNo, inputvalues.get("CardNumber"),
				"", inputvalues.get("LocationNumber"), "100", "");// ------2,3
		transactionListPage.enterTransactionLineItems(inputvalues.get("productCode"), "100", "100", "100");
		transactionListPage.validatePostManualTransaction("Validation successful");
		transactionListPage.validatePostedInTransaction(f_referenceNo);
		IFCSHomePage.exitIFCS();

	}

	/**
	 * Implemented by Rathna * @param clientCountry
	 * 
	 * @param clientName Busienss Flow ID:BF-159
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow" })
	public void validateManualTransactionWithInvalidTime(@Optional("BE") String clientCountry,
			@Optional("WFE") String clientName) {

		test = extent.createTest(clientName + ":" + clientCountry + "TC-1676 TC17_TxnMgmt_Manual_Txn invalid time",
				"RQ-869 : Card Invalid Status error should appear if posted transaction before card is in Normal Services");
		// creating object for the Pages
		IFCSLoginPage ifcsloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		TransactionListPage transactionListPage = new TransactionListPage(driver, test);
		//Common common = new Common(driver, test);
		TransactionComponentPage transactionComponentPage = new TransactionComponentPage(driver, test);
		Map<String, String> inputvalues = new HashMap<String, String>();

		// Calling Functions
		ifcsloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		ifcsloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		IFCSHomePage.gotoApplicationAndClickApplicationMenu();

		// TestData
		Faker fakerN = new Faker();
		String f_referenceNo = fakerN.number().digits(3);
		IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);
		/*String currentDate = common.getCurrentIFCSDateFromDB(clientName + clientCountry);
		String ifcsCurrentDate = common.enterADateValueInStatusBeginDateField("Current", currentDate);
		// get date and time
		inputvalues = transactionComponentPage.inputValuesForCardStatus(clientName, clientCountry, "Normal Service");
		String statusChangeTime = common.getStatusChangeTime(inputvalues.get("CardNumber"));
		String statusChangeTimeNew = "2010-06-19 00:00:00 AM";// above query is not getting AM/PM along with timestamp,
																// so currenty passing static value- BE
		
		//select * from cards where card_status_oid in (select card_status_oid from card_status where description='Normal Service');
		String dateTime = common.getTimeBeforeStatusChange(statusChangeTimeNew, 1);// new method
		// String dateTime="18/06/2010";//11 pm*/

		inputvalues = transactionComponentPage.inputValuesForInvalidTime(clientName, clientCountry);
		System.out.println("inputvalues::"+inputvalues);
		// Transaction Details
		IFCSHomePage.gotoTransactionAndClickManageTransaction();
		transactionListPage.enterTransactionBatchDetails(true, "100", "1", clientName);
		transactionListPage.enterManualTransactionDetails(inputvalues.get("date"), f_referenceNo, inputvalues.get("CardNumber"), "",
				inputvalues.get("LocationNumber"), "100", "");
		transactionListPage.enterTransactionLineItems(inputvalues.get("productCode"), "100", "100", "100");
		transactionListPage.validatePostManualTransaction("Card Status Invalid");
		IFCSHomePage.exitIFCS();
	}

	/**
	 * Added by Venkata Davu
	 * 
	 * @param clientCountry
	 * @param clientName    Business Flow ID:BF-159
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow" })
	public void validatePostManualPurchaseBasedOnBatchType(@Optional("BE") String clientCountry,
			@Optional("WFE") String clientName) {

		test = extent.createTest(
				clientName + ":" + clientCountry + " ID:BF-159 Transactions should be posted based on the Batch Type",
				"Transactions should be posted based on the Batch Type");

		// creating object for the Pages
		IFCSLoginPage ifcsloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		TransactionListPage transactionListPage = new TransactionListPage(driver, test);
		WFECommon wfecommon = new WFECommon(driver, test);
		Common common = new Common(driver, test);

		// Calling Functions
		ifcsloginPage.login("IFCS_URL_WFE", "IFCS_WFE_USERNAME", "IFCS_WFE_PASSWORD");
		ifcsloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, " ");

		IFCSHomePage.gotoApplicationAndClickApplicationMenu();

		// TestData
		Faker fakerN = new Faker();
		String f_referenceNo = fakerN.number().digits(3);
		IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);

		String clientNameInProp = PropUtils.getPropValue(configProp, clientName + "_" + clientCountry);
		String currentDate = common.getCurrentIFCSDateFromDB(clientNameInProp);
		// Get the IFCS current date
		String ifcsCurrentDate = common.enterADateValueInStatusBeginDateField("Current", currentDate);

		System.out.println("Date ::" + ifcsCurrentDate);
		String cardNo = common.getCardNumberFromIFCSDB(clientName, clientCountry, "Active");
		//String cardNo2 = common.getCardNumberFromIFCSDB(clientName, clientCountry, "Active");

		/*
		 * String queryToGetLocNo = "select location_no from m_locations where" +
		 * " client_mid=(select client_mid from m_clients where name='" +
		 * PropUtils.getPropValue(configProp, clientName + "_" + clientCountry) + "')";
		 * String locationNo = common.connectDBAndGetValue(queryToGetLocNo,
		 * PropUtils.getPropValue(configProp, "sqlODSServerName"));
		 */

		String locationNo = wfecommon.getLocationNumberForWFE(clientName, clientCountry);

		// Transaction Details

		IFCSHomePage.gotoTransactionAndClickManageTransaction();

		transactionListPage.enterTransactionBatchDetails(true, "160", "1", clientName);
		transactionListPage.selectBatchTypeInTransactionDetails("Manual Voucher");
		transactionListPage.enterManualTransactionDetails(ifcsCurrentDate, f_referenceNo, cardNo, "", locationNo,
				"160", "");

		transactionListPage.enterTransactionLineItems("135", "160", "100", "160");
		transactionListPage.validatePostManualTransaction("Validation successful");
		transactionListPage.validatePostedInTransaction(f_referenceNo);
		IFCSHomePage.exitIFCS();
	}

	/**
	 * Added by Nithya
	 * 
	 * @param clientCountry
	 * @param clientName    RQ-865
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow" })
	public void validatePostManualTransactionWithLineItems(@Optional("BE") String clientCountry,
			@Optional("WFE") String clientName) {

		test = extent.createTest(clientName + ":" + clientCountry + " TC-1665 TC13_TxnMgmt_Manual_Txn Multi line items",
				"RQ-865 Able to post manual transactions with Product details (under Line items)");

		// creating object for the Pages
		IFCSLoginPage ifcsloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		TransactionListPage transactionListPage = new TransactionListPage(driver, test);
		Common common = new Common(driver, test);
		WFECommon wfeCommon = new WFECommon(driver, test);
		ifcsloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");

		// Calling Functions
		ifcsloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		IFCSHomePage.gotoApplicationAndClickApplicationMenu();

		// TestData
		Faker fakerN = new Faker();
		String f_referenceNo = fakerN.number().digits(3);
		IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);

		String clientNameInProp = PropUtils.getPropValue(configProp, clientName + "_" + clientCountry);
		String currentDate = common.getCurrentIFCSDateFromDB(clientNameInProp);
		// Get the IFCS current date
		String ifcsCurrentDate = common.enterADateValueInStatusBeginDateField("Current", currentDate);

		System.out.println("Date ::" + ifcsCurrentDate);
		String cardNumber = common.getCardNumberFromIFCSDB(clientName, clientCountry, "Active");

		String locationNo = wfeCommon.getLocationNumberForWFE(clientName, clientCountry);
		// Transaction Details
		IFCSHomePage.gotoTransactionAndClickManageTransaction();
		transactionListPage.enterTransactionBatchDetails(true, "320", "1", clientName);
		transactionListPage.enterManualTransactionDetails(ifcsCurrentDate, f_referenceNo, cardNumber, "", locationNo,
				"320", "");
		transactionListPage.enterTransactionLineItems("135", "160", "100", "160");
		transactionListPage.enterTransactionLineItems("530", "160", "100", "160");
		transactionListPage.validatePostManualTransaction("Validation successful");
		transactionListPage.validatePostedInTransaction(f_referenceNo);

		IFCSHomePage.exitIFCS();
	}

	/**
	 * Added by Nithya
	 * 
	 * @param clientCountry
	 * @param clientName
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow" })
	public void validatePostManualTransactionAgainstPurchaseVelocityControls(@Optional("BE") String clientCountry,
			@Optional("WFE") String clientName) {

		test = extent.createTest(clientName + ":" + clientCountry + " TC-1675 TC16_TxnMgmt_Manual_Txn Invalid Product Velocity",
				"Error should appear if the transsaction posted against the Purchase Velocity Controls");

		// creating object for the Pages
		IFCSLoginPage ifcsloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		TransactionListPage transactionListPage = new TransactionListPage(driver, test);
		Common common = new Common(driver, test);
		WFECommon wfeCommon = new WFECommon(driver, test);
		ifcsloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		CardMaintenancePage cardMaintenancePage = new CardMaintenancePage(driver, test);
		MaintainCustomerPage customerPage = new MaintainCustomerPage(driver, test);
		// Calling Functions
		ifcsloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		IFCSHomePage.gotoApplicationAndClickApplicationMenu();

		// TestData
		Faker fakerN = new Faker();
		String f_referenceNo = fakerN.number().digits(5);
		IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);

		String clientNameInProp = PropUtils.getPropValue(configProp, clientName + "_" + clientCountry);
		String currentDate = common.getCurrentIFCSDateFromDB(clientNameInProp);
		// Get the IFCS current date
		String ifcsCurrentDate = common.enterADateValueInStatusBeginDateField("Current", currentDate);

		System.out.println("Date ::" + ifcsCurrentDate);
		// Order a card with transaction limit for purchase velocity
		String cardNo = common.getDriverCardNumberFromDB(clientName + clientCountry);
		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		cardMaintenancePage.updateCardMaintenanceCardControlProfile(cardNo);
		customerPage.enterDetailsInCardControlsPopUp(clientName + clientCountry);

		String locationNo = wfeCommon.getLocationNumberForWFE(clientName, clientCountry);
		/*
		 * String
		 * productCode=common.chooseANonFuelProductExtCodeInTheLocation(locationNo,"Y",
		 * "externalCode");
		 */
		// Transaction Details
		IFCSHomePage.gotoTransactionAndClickManageTransaction();
		transactionListPage.enterTransactionBatchDetails(true, "160", "1", clientName);
		transactionListPage.enterManualTransactionDetails(ifcsCurrentDate, f_referenceNo, cardNo, "", locationNo, "160",
				"");
		transactionListPage.enterTransactionLineItems("135", "160", "100", "160");
		transactionListPage.validatePostManualTransaction("Validation successful");
		transactionListPage.validatePostedInTransaction(f_referenceNo);

		IFCSHomePage.exitIFCS();
	}

	/**
	 * Added by Nithya
	 * 
	 * @param clientCountry
	 * @param clientName    - RQ-861
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow" })
	public void validatePostManualTransactionWithNewCard(@Optional("BE") String clientCountry,
			@Optional("WFE") String clientName) {

		test = extent.createTest(clientName + ":" + clientCountry + "MD-283 - TC-1653 TC01_TxnMgmt_Manual_Txn New Cards",
				"TC-1653 TC01_TxnMgmt_Manual_Txn New Cards");

		// creating object for the Pages
		IFCSLoginPage ifcsloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		TransactionListPage transactionListPage = new TransactionListPage(driver, test);
		Common common = new Common(driver, test);
		ifcsloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		CardMaintenancePage cardMaintenancePage = new CardMaintenancePage(driver, test);
		MaintainCustomerPage customerPage = new MaintainCustomerPage(driver, test);
		// Calling Functions
		ifcsloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		IFCSHomePage.gotoApplicationAndClickApplicationMenu();
		WFECommon wfecommon = new WFECommon(driver, test);
		// TestData
		Faker fakerN = new Faker();
		String f_referenceNo = fakerN.number().digits(5);
		IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);

		String clientNameInProp = PropUtils.getPropValue(configProp, clientName + "_" + clientCountry);
		String currentDate = common.getCurrentIFCSDateFromDB(clientNameInProp);
		// Get the IFCS current date
		String ifcsCurrentDate = common.enterADateValueInStatusBeginDateField("Current", currentDate);

		System.out.println("Date ::" + ifcsCurrentDate);
		// Order a card with transaction limit for purchase velocity
		String cardNo = common.getCardNumberFromIFCSDBWithNoTransaction(clientName, clientCountry, "Normal Service");
		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		cardMaintenancePage.updateCardMaintenanceCardControlProfile(cardNo);
		customerPage.enterDetailsInCardControlsPopUp(clientName + clientCountry);

		String locationNo = wfecommon.getLocationNumberForWFE(clientName , clientCountry);
		/*
		 * String
		 * productCode=common.chooseANonFuelProductExtCodeInTheLocation(locationNo,"Y",
		 * "externalCode");
		 */
		// Transaction Details
		IFCSHomePage.gotoTransactionAndClickManageTransaction();
		transactionListPage.enterTransactionBatchDetails(true, "160", "1", clientName);
		transactionListPage.enterManualTransactionDetails(ifcsCurrentDate, f_referenceNo, cardNo, "", locationNo, "160",
				"");
		transactionListPage.enterTransactionLineItems("135", "160", "100", "160");
		transactionListPage.validatePostManualTransaction("Validation successful");
		transactionListPage.validatePostedInTransaction(f_referenceNo);

		IFCSHomePage.exitIFCS();
	}

	/**
	 * Implemented by Rathna * @param clientCountry
	 * 
	 * @param clientName Busienss Flow ID:BF-156
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow" })
	public void validatePostManualPurchaseWithFuelProducts(@Optional("BE") String clientCountry,
			@Optional("WFE") String clientName) {

		test = extent.createTest(clientName + ":" + clientCountry + " TC-1662 TC10_TxnMgmt_Manual_Txn Fuel Product",
				"Able to post Manual Purchase transaction with Fuel Products");

		// creating object for the Pages
		IFCSLoginPage ifcsloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		TransactionListPage transactionListPage = new TransactionListPage(driver, test);
		Common common = new Common(driver, test);
		WFECommon wfeCommon = new WFECommon(driver, test);
		// Calling Functions
		ifcsloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		ifcsloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, " ");
		IFCSHomePage.gotoApplicationAndClickApplicationMenu();

		Faker fakerN = new Faker();
		String f_referenceNo = fakerN.number().digits(5);
		IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);
		String currentDate = common.getCurrentIFCSDateFromDB(clientName + clientCountry);
		String ifcsCurrentDate = common.enterADateValueInStatusBeginDateField("Current", currentDate);

		ArrayList<String> cardlist = common.getActivedualCardNumberFromDBWFE(clientName, clientCountry);
		String locationNo = wfeCommon.getLocationNumberForWFE(clientName, clientCountry);

		// Post Transaction
		IFCSHomePage.gotoTransactionAndClickManageTransaction();
		transactionListPage.enterTransactionBatchDetails(true, "160", "1", clientName);
		transactionListPage.enterManualTransactionDetails(ifcsCurrentDate, f_referenceNo, cardlist.get(0),
				cardlist.get(1), locationNo, "160", "");
		transactionListPage.enterTransactionLineItems("135", "160", "100", "160");
		transactionListPage.validatePostManualTransaction("Validation successful");

		transactionListPage.validatePostedInTransaction(f_referenceNo);
		IFCSHomePage.exitIFCS();
	}

	/**
	 * Added by Raxsana Babu
	 * 
	 * @param clientCountry
	 * @param clientName    RQ-863
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow" })
	public void validatePostManualTansactionWithTemporaryBlockedCard(@Optional("BE") String clientCountry,
			@Optional("WFE") String clientName) {

		test = extent.createTest(
				clientName + ":" + clientCountry + " TC-1658 TC06_TxnMgmt_Manual_Txn Card Status in Temporary Blocked",
				"RQ-863 Post Manual transaction for a temporary blocked card");

		// creating object for the Pages
		IFCSLoginPage ifcsloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		TransactionListPage transactionListPage = new TransactionListPage(driver, test);
		// Common common = new Common(driver, test);
		// CommonInterfacePage commonInterfacePage = new CommonInterfacePage(driver,
		// test);
		TransactionComponentPage transactionComponentPage = new TransactionComponentPage(driver, test);
		Map<String, String> inputvalues = new HashMap<String, String>();

		// Calling Functions
		ifcsloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		ifcsloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		IFCSHomePage.gotoApplicationAndClickApplicationMenu();

		// TestData
		Faker fakerN = new Faker();
		String f_referenceNo = fakerN.number().digits(3);
		IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);

		inputvalues = transactionComponentPage.inputValuesForCardStatus(clientName, clientCountry, "Temp");
		System.out.println("inputvalues::" + inputvalues);
		// Transaction Details
		IFCSHomePage.gotoTransactionAndClickManageTransaction();
		transactionListPage.enterTransactionBatchDetails(true, "100", "1", clientName);
		transactionListPage.enterManualTransactionDetails(inputvalues.get("date"), f_referenceNo,
				inputvalues.get("CardNumber"), "", inputvalues.get("LocationNumber"), "100", "");
		transactionListPage.enterTransactionLineItems(inputvalues.get("productCode"), "100", "100", "100");
		transactionListPage.validatePostManualTransaction("Card Status Invalid");
	}

	/**
	 * Added by Davu
	 * 
	 * @param clientCountry
	 * @param clientName    Business Flow ID:BF-163
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow" })
	public void validatePostManualPurchaseWIthInvalidLineItemTotal(@Optional("BE") String clientCountry,
			@Optional("WFE") String clientName) {

		test = extent.createTest(
				clientName + ":" + clientCountry + " TC-1677 TC18_TxnMgmt_Manual_Txn Invalid Line item Total",
				"Invalid Line Item Total error should appear if the line item total does not matches with the Total of Transaction value");

		// creating object for the Pages
		IFCSLoginPage ifcsloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		TransactionListPage transactionListPage = new TransactionListPage(driver, test);
		Common common = new Common(driver, test);
		WFECommon wfecommon = new WFECommon(driver, test);

		// Calling Functions
		ifcsloginPage.login("IFCS_URL_"+clientName, "IFCS_"+clientName+"_USERNAME", "IFCS_"+clientName+"_PASSWORD");
		ifcsloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, " ");

		IFCSHomePage.gotoApplicationAndClickApplicationMenu();

		// TestData
		Faker fakerN = new Faker();
		String f_referenceNo = fakerN.number().digits(3);
		IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);

		String clientNameInProp = PropUtils.getPropValue(configProp, clientName + "_" + clientCountry);
		String currentDate = common.getCurrentIFCSDateFromDB(clientNameInProp);
		// Get the IFCS current date
		String ifcsCurrentDate = common.enterADateValueInStatusBeginDateField("Current", currentDate);
		
		System.out.println("Date ::" + ifcsCurrentDate);
		String cardNo = common.getCardNumberFromIFCSDB(clientName, clientCountry, "Active");
		String locationNo = "";
		if(clientName.equalsIgnoreCase("WFE")) {
		locationNo = wfecommon.getLocationNumberForWFE(clientName , clientCountry);
		}else {
			locationNo = common.getLocationNoFromIFCSDB(clientName, clientCountry, "29");
		}

		// Transaction Details

		IFCSHomePage.gotoTransactionAndClickManageTransaction();

		transactionListPage.enterTransactionBatchDetails(true, "160", "1", clientName);
		if(clientName.equalsIgnoreCase("WFE")) {
			transactionListPage.selectBatchTypeInTransactionDetails("Manual Voucher");
		}else {
			transactionListPage.selectBatchTypeInTransactionDetails("Manual Correction");
		}
		
		transactionListPage.enterManualTransactionDetails(ifcsCurrentDate, f_referenceNo, cardNo, "", locationNo,
				"160", "");
		if(clientName.equalsIgnoreCase("WFE")) {
			transactionListPage.enterTransactionLineItems("530", "180", "100", "160");
		}else{
			transactionListPage.enterTransactionLineItems("29", "180", "100", "160");
		}
		
		transactionListPage.validatePostManualTransaction("Transaction Total not equal Line Items Total");
		IFCSHomePage.exitIFCS();
	}

	/**
	 * Added by Raxsana Babu
	 * 
	 * @param clientCountry
	 * @param clientName    RQ-867
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "BusinessFlow" })
	public void validatePostManualTansactionWithProductRestriction(@Optional("BE") String clientCountry,
			@Optional("WFE") String clientName) {

		// Transaction always successful for the product restriction case
		test = extent.createTest(clientName + ":" + clientCountry + " TC-1674 TC15_TxnMgmt_Manual_Txn Invalid Product",
				"RQ-867 Error should appear if the transaction posted against the Product Restrictions for the Customer Card Control");

		// creating object for the Pages
		IFCSLoginPage ifcsloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		TransactionListPage transactionListPage = new TransactionListPage(driver, test);
		TransactionComponentPage transactionComponentPage = new TransactionComponentPage(driver, test);
		Map<String, String> inputvalues = new HashMap<String, String>();

		// Calling Functions
		ifcsloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		ifcsloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		IFCSHomePage.gotoApplicationAndClickApplicationMenu();

		// TestData
		Faker fakerN = new Faker();
		String f_referenceNo = fakerN.number().digits(5);
		IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);

		inputvalues = transactionComponentPage.inputValuesForProductRestriction(clientName, clientCountry);
		System.out.println("inputvalues::" + inputvalues);
		// Transaction Details
		IFCSHomePage.gotoTransactionAndClickManageTransaction();
		transactionListPage.enterTransactionBatchDetails(true, "100", "1", clientName);
		transactionListPage.enterManualTransactionDetails(inputvalues.get("date"), f_referenceNo,
				inputvalues.get("CardNumber"), "", inputvalues.get("LocationNumber"), "100", "");
		transactionListPage.enterTransactionLineItems("007", "100", "100", "100");
		transactionListPage.validatePostManualTransaction("Validation successful");
		transactionListPage.validatePostedInTransaction(f_referenceNo);
	}

	/**
	 * Added by Raxsana Babu
	 * 
	 * @param clientCountry
	 * @param clientName    RQ-888
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "BusinessFlow" })
	public void validatePostTransactionFromSuspendedTansaction(@Optional("BE") String clientCountry,
			@Optional("WFE") String clientName) {

		test = extent.createTest(
				clientName + ":" + clientCountry + " TC-1698 TC05_TxnMgmt_Susp_Txn process out of suspense ,TC-1699 TC06_TxnMgmt_Susp_Txn Acc_bal",
				"RQ-888 Execution of Post transaction from suspending transaction screen after correcting it");

		// creating object for the Pages
		IFCSLoginPage ifcsloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		TransactionComponentPage transactionComponentPage = new TransactionComponentPage(driver, test);

		// Calling Functions
		ifcsloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		ifcsloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		IFCSHomePage.gotoApplicationAndClickApplicationMenu();
		IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);
		IFCSHomePage.gotoTransactionAndClickManageTransaction();
		transactionComponentPage.postTransactionFromSuspendedTransaction(clientName, clientCountry);
		IFCSHomePage.exitIFCS();
	}

	/**
	 * Added by Raxsana Babu
	 * 
	 * @param clientCountry
	 * @param clientName
	 * @throws TransformerException RQ-897
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "BusinessFlow" })
	public void validatePostReturnAndSalesReversalTransactions(@Optional("BE") String clientCountry,
			@Optional("WFE") String clientName) throws TransformerException {

		test = extent.createTest(clientName + ":" + clientCountry + " TC-1703 TC02_TxnMgmt_RetTxn Tokheim files",
				"RQ-897 Post Return/Refund transactions");

		// creating object for the Pages
		IFCSLoginPage ifcsloginPage = new IFCSLoginPage(driver, test);
		TransactionComponentPage transactionComponentPage = new TransactionComponentPage(driver, test);

		// Calling Functions
		/*
		 * ifcsloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName +
		 * "_USERNAME", "IFCS_" + clientName + "_PASSWORD");
		 */
		ifcsloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		WFECommon wfeCommon = new WFECommon(driver, test);
		Map<String, String> inputValues = new HashMap<String, String>();
		Map<String, String> valuesForValidation = new HashMap<String, String>();

		inputValues = transactionComponentPage.inputValuesForTransaction(clientName, clientCountry, "Y", "");
		valuesForValidation = wfeCommon.XMLCreationForTransactionWFE(clientName, clientCountry, inputValues, "Y", "0");
		wfeCommon.updatePropFile("ReturnTransReference_" + clientName + "_" + clientCountry, valuesForValidation);
		// Validate transaction posted or not
		// ifcsCommonPage.validateTransactionPostedOrNot(valuesForValidation);
	}

	/**
	 * Added by Raxsana Babu
	 * 
	 * @param clientCountry
	 * @param clientName
	 * @throws TransformerException RQ-897
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "BusinessFlow" })
	public void validatePostRefundReversalTransaction(@Optional("BE") String clientCountry,
			@Optional("WFE") String clientName) throws TransformerException {

		test = extent.createTest(clientName + ":" + clientCountry + "TC-1703 TC02_TxnMgmt_RetTxn Tokheim files ",
				"RQ-897 Post Return/Refund transactions");

		// creating object for the Pages
		IFCSLoginPage ifcsloginPage = new IFCSLoginPage(driver, test);
		TransactionComponentPage transactionComponentPage = new TransactionComponentPage(driver, test);

		// Calling Functions
		/*
		 * ifcsloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName +
		 * "_USERNAME", "IFCS_" + clientName + "_PASSWORD");
		 */
		ifcsloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		WFECommon wfeCommon = new WFECommon(driver, test);
		Map<String, String> inputValues = new HashMap<String, String>();
		Map<String, String> valuesForValidation = new HashMap<String, String>();

		inputValues = transactionComponentPage.inputValuesForTransaction(clientName, clientCountry, "Y", "");
		valuesForValidation = wfeCommon.XMLCreationForTransactionWFE(clientName, clientCountry, inputValues, "Y", "20");
		wfeCommon.updatePropFile("RefundReversalTransReference_" + clientName + "_" + clientCountry,
				valuesForValidation);
		// Validate transaction posted or not
		// ifcsCommonPage.validateTransactionPostedOrNot(valuesForValidation);
	}

	/**
	 * Added by Raxsana Babu
	 * 
	 * @param clientCountry
	 * @param clientName    RQ-881
	 * @throws TransformerException
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "BusinessFlow" })
	public void validatePostCrossborderTransactionForFuelProducts(@Optional("BE") String clientCountry,
			@Optional("WFE") String clientName) throws TransformerException {

		test = extent.createTest(
				clientName + ":" + clientCountry + " TC-1686 TC04_TxnMgmt_Process Tokheim file Cross border",
				"RQ-881 Post Cross border transactions for a customer");

		// creating object for the Pages
		IFCSLoginPage ifcsloginPage = new IFCSLoginPage(driver, test);
		TransactionComponentPage transactionComponentPage = new TransactionComponentPage(driver, test);

		// Calling Functions
		ifcsloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		ifcsloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		WFECommon wfeCommon = new WFECommon(driver, test);
		Map<String, String> inputValues = new HashMap<String, String>();
		Map<String, String> valuesForValidation = new HashMap<String, String>();

		inputValues = transactionComponentPage.inputValuesForCrossBorderTransaction(clientName, clientCountry, "Y");
		System.out.println(inputValues);
		valuesForValidation = wfeCommon.XMLCreationForTransactionWFE(clientName, clientCountry, inputValues, "N", "0");
		System.out.println("validation data" + valuesForValidation);
		wfeCommon.updatePropFile("CrossBorderFuelTransReference_" + clientName + "_" + clientCountry,
				valuesForValidation);
		// Validate transaction posted or not
		// ifcsCommonPage.validateTransactionPostedOrNot(valuesForValidation);
	}

	/**
	 * Added by Raxsana Babu
	 * 
	 * @param clientCountry
	 * @param clientName    RQ-881
	 * @throws TransformerException
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "BusinessFlow" })
	public void validatePostCrossborderTransactionForNonFuelProducts(@Optional("BE") String clientCountry,
			@Optional("WFE") String clientName) throws TransformerException {

		test = extent.createTest(
				clientName + ":" + clientCountry + " TC-1686 TC04_TxnMgmt_Process Tokheim file Cross border",
				"RQ-881 Post Cross border transactions for a customer");

		// creating object for the Pages
		IFCSLoginPage ifcsloginPage = new IFCSLoginPage(driver, test);
		TransactionComponentPage transactionComponentPage = new TransactionComponentPage(driver, test);

		// Calling Functions
		/*
		 * ifcsloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName +
		 * "_USERNAME", "IFCS_" + clientName + "_PASSWORD");
		 */
		ifcsloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		WFECommon wfeCommon = new WFECommon(driver, test);
		Map<String, String> inputValues = new HashMap<String, String>();
		Map<String, String> valuesForValidation = new HashMap<String, String>();

		inputValues = transactionComponentPage.inputValuesForCrossBorderTransaction(clientName, clientCountry, "N");
		System.out.println(inputValues);
		valuesForValidation = wfeCommon.XMLCreationForTransactionWFE(clientName, clientCountry, inputValues, "N", "0");
		System.out.println("validation data" + valuesForValidation);
		wfeCommon.updatePropFile("CrossBorderNonFuelTransReference_" + clientName + "_" + clientCountry,
				valuesForValidation);
		// Validate transaction posted or not
		// ifcsCommonPage.validateTransactionPostedOrNot(valuesForValidation);
	}

	/**
	 * Added by Raxsana Babu
	 * 
	 * @param clientCountry
	 * @param clientName    RQ-878
	 * @throws TransformerException
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "BusinessFlow" })
	public void validatePostDualCardsTransaction(@Optional("BE") String clientCountry,
			@Optional("WFE") String clientName) throws TransformerException {

		test = extent.createTest(clientName + ":" + clientCountry
				+ " TC-1689 TC07_TxnMgmt_Process file Dual Cards,TC-1690 TC08_TxnMgmt_Acc_bal after file proceessed",
				"RQ-878	Post transction with dual cards for a customer");

		// creating object for the Pages
		IFCSLoginPage ifcsloginPage = new IFCSLoginPage(driver, test);
		TransactionComponentPage transactionComponentPage = new TransactionComponentPage(driver, test);

		// Calling Functions
		/*
		 * ifcsloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName +
		 * "_USERNAME", "IFCS_" + clientName + "_PASSWORD");
		 */
		ifcsloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		WFECommon wfeCommon = new WFECommon(driver, test);
		Map<String, String> inputValues = new HashMap<String, String>();
		Map<String, String> valuesForValidation = new HashMap<String, String>();

		inputValues = transactionComponentPage.inputValuesForDualCardsTransaction(clientName, clientCountry, "Y");
		System.out.println(inputValues);
		String actualBalanceBefore = wfeCommon.getAccountActualBalance(inputValues.get("CardNumber"));
		valuesForValidation = wfeCommon.XMLCreationForTransactionWFE(clientName, clientCountry, inputValues, "N", "0");
		System.out.println("validation data" + valuesForValidation + "actualBalanceBefore::" + actualBalanceBefore);
		// transactionComponentPage.validateTransactionPostedOrNot(valuesForValidation,
		// "");
		wfeCommon.updatePropFile("DualCardsFuelTransReference_" + clientName + "_" + clientCountry,
				valuesForValidation);
		/*transactionComponentPage.validateAccountBalance(actualBalanceBefore, inputValues.get("ReferenceNo"),
				inputValues.get("CardNumber"));*/
		// Validate transaction posted or not
		// ifcsCommonPage.validateTransactionPostedOrNot(valuesForValidation);
	}

	/**
	 * Added by Rathna
	 * 
	 * @param clientCountry
	 * @param clientName    RQ-883
	 * @throws TransformerException
	 */

	@Parameters({ "clientCountry", "clientName", "cardCount" })
	@Test( groups = { "BusinessFlow" })
	public void validatePostTransactionForNonFuelProducts(@Optional("BE") String clientCountry,
			@Optional("WFE") String clientName, String cardCount) throws TransformerException {
		test = extent.createTest(clientName + ":" + clientCountry + " TC-1683 TC01_TxnMgmt_Process Tokheim Txn File",
				"RQ-883 Able to process the tokheim transaction file");

		// Initialize objects
		IFCSLoginPage ifcsloginPage = new IFCSLoginPage(driver, test);
		TransactionComponentPage transactionComponentPage = new TransactionComponentPage(driver, test);
		ifcsloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		WFECommon wfeCommon = new WFECommon(driver, test);
		Map<String, String> inputValues = new HashMap<String, String>();
		Map<String, String> valuesForValidation = new HashMap<String, String>();

		// Getting input values for XML Creation
		inputValues = transactionComponentPage.inputValuesForTransaction(clientName, clientCountry, "N", "");
		// XML Creation
		valuesForValidation = wfeCommon.XMLCreationForTransactionWFE(clientName, clientCountry, inputValues, "N", "0");
		wfeCommon.updatePropFile("NonFuelTransReference_" + clientName + "_" + clientCountry, valuesForValidation);
		// Validate transaction posted or not
		// ifcsCommonPage.validateTransactionPostedOrNot(valuesForValidation);
	}

	/**
	 * Added by Rathna
	 * 
	 * @param clientCountry
	 * @param clientName    RQ-875
	 * @throws TransformerException
	 */

	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow" })
	public void validateTransactionWithValidOdometerReadingsForVehicleCard(@Optional("BE") String clientCountry,
			@Optional("WFE") String clientName) throws TransformerException {

		test = extent.createTest(clientName + ":" + clientCountry + " TC-1693 TC11_TxnMgmt_Process Txn with Odometer",
				"RQ-875 Post transaction with valid odometer reading for a vehicle card");

		// Initialize objects
		Map<String, String> inputvalues = new HashMap<String, String>();
		TransactionComponentPage transactionComponentPage = new TransactionComponentPage(driver, test);
		// IFCSCommonPage ifcsCommonPage = new IFCSCommonPage(driver, test);
		Map<String, String> valuesForValidation = new LinkedHashMap<String, String>();
		WFECommon wfeCommon = new WFECommon(driver, test);

		// Getting input values for XML Creation
		inputvalues = transactionComponentPage.inputValuesFoValidOdometerReadings(clientName, clientCountry);

		// XML Creation
		valuesForValidation = wfeCommon.XMLCreationForTransactionWFE(clientName, clientCountry, inputvalues, "N", "0");
		wfeCommon.updatePropFile("ValidOdometerTransReference_" + clientName + "_" + clientCountry,
				valuesForValidation);
		// Validate transaction posted or not
		// ifcsCommonPage.validateTransactionPostedOrNot(valuesForValidation);

	}

	/**
	 * Added by Rathna
	 * 
	 * @param clientCountry
	 * @param clientName    RQ-889
	 * @throws TransformerException
	 */

	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow" })
	public void validateTransactionIsSuspendedWhenDuplicate(String clientCountry, String clientName)
			throws TransformerException {

		test = extent.createTest(
				clientName + ":" + clientCountry + "TC-1694 TC01_TxnMgmt_Susp_Txn Duplicate Transaction",
				"RQ-889 Duplicate transaction moves to suspended");
		// IFCSCommonPage ifcsCommonPage = new IFCSCommonPage(driver, test);
		// creating object for the Pages
		TransactionComponentPage transactionComponentPage = new TransactionComponentPage(driver, test);
		Map<String, String> valuesForValidation = new LinkedHashMap<String, String>();
		WFECommon wfeCommon = new WFECommon(driver, test);
		// Common common = new Common(driver, test);

		// Input Values for XML Creation
		Map<String, String> inputvalues = transactionComponentPage.inputValuesForTransactionRefNumber(clientName,
				clientCountry);

		valuesForValidation = wfeCommon.XMLCreationForTransactionWFE(clientName, clientCountry, inputvalues, "N", "0");
		wfeCommon.updatePropFile("DuplicateTransReference_" + clientName + "_" + clientCountry, valuesForValidation);
		// Validate Transaction Posting
		// transactionComponentPage.validateSuspendTransactionForDuplicateTransaction(refNoAndAmount,
		// message);(valuesForValidation);

	}

	/**
	 * Implemented by Raxsana Babu * @param clientCountry
	 * 
	 * @param clientName RQ-873
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow" })
	public void validateManualInternationalTransactionWithRebates(@Optional("BE") String clientCountry,
			@Optional("WFE") String clientName) {

		test = extent.createTest(
				clientName + ":" + clientCountry + " TC-1681 TC22_TxnMgmt_Manual_Txn Rebate in International Txn",
				"RQ-873 Netoff rebate/discount is applied for customer while posting transaction");
		// creating object for the Pages
		IFCSLoginPage ifcsloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		TransactionListPage transactionListPage = new TransactionListPage(driver, test);
		// Common common = new Common(driver, test);
		// CommonInterfacePage commonInterfacePage = new CommonInterfacePage(driver,
		// test);
		TransactionComponentPage transactionComponentPage = new TransactionComponentPage(driver, test);
		Map<String, String> inputvalues = new HashMap<String, String>();

		// Calling Functions
		ifcsloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		ifcsloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");

		inputvalues = transactionComponentPage.inputValuesForCrossBorderTransactionWithRebates(clientName,
				clientCountry);
		System.out.println("inputvalues::" + inputvalues);
		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		transactionComponentPage.setComplexPricingForInternationalTransaction(inputvalues, clientName, clientCountry);
		transactionComponentPage.setRebatesForInternationalTransaction(inputvalues, clientName, clientCountry);
		// Transaction Details
		// TestData
		Faker fakerN = new Faker();
		String f_referenceNo = fakerN.number().digits(5);
		IFCSHomePage.gotoApplicationAndClickApplicationMenu();
		IFCSHomePage
				.gotoApplicationsMenuAndChooseClient(clientName + "_" + inputvalues.get("crossBorderClientCountry"));
		IFCSHomePage.gotoTransactionAndClickManageTransaction();
		transactionListPage.enterTransactionBatchDetails(true, "100", "1", clientName);
		transactionListPage.enterManualTransactionDetails(inputvalues.get("date"), f_referenceNo,
				inputvalues.get("CardNumber"), "", inputvalues.get("LocationNumber"), "100", "");
		transactionListPage.enterTransactionLineItems("135", "100", "100", "100");
		transactionListPage.validatePostManualTransaction("Validation Successful");
		transactionListPage.validatePostedInTransaction(f_referenceNo);
		transactionComponentPage.validateRebatesApplied();
		IFCSHomePage.exitIFCS();
	}

	/**
	 * Implemented by Raxsana Babu
	 * 
	 * @param clientCountry
	 * @param clientName    RQ-873
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow" })
	public void validateManualTransactionWithNetOffRebates(@Optional("BE") String clientCountry,
			@Optional("WFE") String clientName) {

		test = extent.createTest(
				clientName + ":" + clientCountry + " TC-1680 TC21_TxnMgmt_Manual_Txn Rebate in National Txn",
				"RQ-873 Netoff rebate/discount is applied for customer while posting transaction");
		// creating object for the Pages
		IFCSLoginPage ifcsloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		TransactionListPage transactionListPage = new TransactionListPage(driver, test);
		TransactionComponentPage transactionComponentPage = new TransactionComponentPage(driver, test);
		Map<String, String> inputvalues = new HashMap<String, String>();

		// Calling Functions
		ifcsloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		ifcsloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");

		inputvalues = transactionComponentPage.inputValuesForManualTransactionWithRebates(clientName, clientCountry);
		System.out.println("inputvalues::" + inputvalues);
		IFCSHomePage.gotoCustomerMenuCustomerDetails();

		Faker fakerN = new Faker();
		String f_referenceNo = fakerN.number().digits(5);
		IFCSHomePage.gotoApplicationAndClickApplicationMenu();
		IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);
		IFCSHomePage.gotoTransactionAndClickManageTransaction();
		transactionListPage.enterTransactionBatchDetails(true, "100", "1", clientName);
		transactionListPage.enterManualTransactionDetails(inputvalues.get("date"), f_referenceNo,
				inputvalues.get("CardNumber"), "", inputvalues.get("LocationNumber"), "100", "");
		transactionListPage.enterTransactionLineItems("135", "100", "100", "100");
		transactionListPage.validatePostManualTransaction("Validation Successful");
		transactionListPage.validatePostedInTransaction(f_referenceNo);
		transactionComponentPage.validateRebatesApplied();
		IFCSHomePage.exitIFCS();
	}

	/**
	 * Implemented by Raxsana Babu
	 * 
	 * @param clientCountry
	 * @param clientName    RQ-873
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow" })
	public void validateManualTransactionWithNonRebates(@Optional("BE") String clientCountry,
			@Optional("WFE") String clientName) {

		test = extent.createTest(
				clientName + ":" + clientCountry + "TC-1682 TC23_TxnMgmt_Manual_Txn Rebate to Non-Rebate cust ",
				"RQ-873 Netoff rebate/discount is applied for customer while posting transaction");
		// creating object for the Pages
		IFCSLoginPage ifcsloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		TransactionListPage transactionListPage = new TransactionListPage(driver, test);
		// Common common = new Common(driver, test);
		// CommonInterfacePage commonInterfacePage = new CommonInterfacePage(driver,
		// test);
		TransactionComponentPage transactionComponentPage = new TransactionComponentPage(driver, test);
		Map<String, String> inputvalues = new HashMap<String, String>();

		// Calling Functions
		ifcsloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		ifcsloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");

		inputvalues = transactionComponentPage.inputValuesForManualTransactionWithRebates(clientName, clientCountry);
		System.out.println("inputvalues::" + inputvalues);
		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		// Transaction Details
		// TestData
		Faker fakerN = new Faker();
		String f_referenceNo = fakerN.number().digits(5);
		IFCSHomePage.gotoApplicationAndClickApplicationMenu();
		IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);
		IFCSHomePage.gotoTransactionAndClickManageTransaction();
		transactionListPage.enterTransactionBatchDetails(true, "100", "1", clientName);
		transactionListPage.enterManualTransactionDetails(inputvalues.get("date"), f_referenceNo,
				inputvalues.get("CardNumber"), "", inputvalues.get("LocationNumber"), "100", "");
		transactionListPage.enterTransactionLineItems("017", "100", "100", "100");
		transactionListPage.validatePostManualTransaction("Validation Successful");
		transactionListPage.validatePostedInTransaction(f_referenceNo);
		transactionComponentPage.validateRebatesNotApplied();
		IFCSHomePage.exitIFCS();
	}

	/**
	 * Implemented by Raxsana Babu
	 * 
	 * @param clientCountry
	 * @param clientName    RQ-865
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "BusinessFlow" })
	public void validateManualInternationalTransactionWithTax(@Optional("BE") String clientCountry,
			@Optional("WFE") String clientName) {
		test = extent.createTest(clientName + ":" + clientCountry + " TC-1664 TC12_TxnMgmt_Manual_Txn Cross border",
				"RQ-865 Able to post manual transactions with Product details (under Line items)");
		// creating object for the Pages
		IFCSLoginPage ifcsloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage ifcsHomePage = new IFCSHomePage(driver, test);
		TransactionComponentPage transactionComponentPage = new TransactionComponentPage(driver, test);
		// WFECommon wfeCommon= new WFECommon(driver,test);
		Map<String, String> inputvalues = new HashMap<String, String>();
		TransactionListPage transactionListPage = new TransactionListPage(driver, test);
		ifcsloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		ifcsloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, " ");

		inputvalues = transactionComponentPage.inputValuesForCrossBorderTransactionWithRebates(clientName,
				clientCountry);
		System.out.println("inputvalues::" + inputvalues);
		// Selecting client from Application Menu
		ifcsHomePage.gotoCustomerMenuCustomerDetails();
		transactionComponentPage.setComplexPricingForInternationalTransaction(inputvalues, clientName, clientCountry);
		Faker fakerN = new Faker();
		String f_referenceNo = fakerN.number().digits(5);
		ifcsHomePage.gotoApplicationAndClickApplicationMenu();
		ifcsHomePage
				.gotoApplicationsMenuAndChooseClient(clientName + "_" + inputvalues.get("crossBorderClientCountry"));
		ifcsHomePage.gotoTransactionAndClickManageTransaction();
		transactionListPage.enterTransactionBatchDetails(true, "100", "1", clientName);
		transactionListPage.enterManualTransactionDetails(inputvalues.get("date"), f_referenceNo,
				inputvalues.get("CardNumber"), "", inputvalues.get("LocationNumber"), "100", "");
		transactionListPage.enterTransactionLineItems("135", "100", "100", "100");
		transactionListPage.validatePostManualTransaction("Validation successful");
		transactionListPage.validatePostedInTransaction(f_referenceNo);
		transactionComponentPage.validateTaxAmountForCustomerBreakdown();
		ifcsHomePage.exitIFCS();

	}

	/**
	 * Implemented by Raxsana Babu
	 * 
	 * @param clientCountry
	 * @param clientName    RQ-872
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow" })
	public void validateManualTransactionForInvalidLocation(@Optional("BE") String clientCountry,
			@Optional("WFE") String clientName) {

		test = extent.createTest(clientName + ":" + clientCountry + " TC-1679 TC20_TxnMgmt_Manual_Txn invalid location",
				"RQ-872 Invalid Location error should appear when invalid location is used");
		// creating object for the Pages
		IFCSLoginPage ifcsloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		TransactionListPage transactionListPage = new TransactionListPage(driver, test);
		TransactionComponentPage transactionComponentPage = new TransactionComponentPage(driver, test);
		Map<String, String> inputvalues = new HashMap<String, String>();

		// Calling Functions
		ifcsloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		ifcsloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");

		inputvalues = transactionComponentPage.inputValuesForInvalidLocation(clientName, clientCountry);
		System.out.println("inputvalues::" + inputvalues);
		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		// Transaction Details
		// TestData
		Faker fakerN = new Faker();
		String f_referenceNo = fakerN.number().digits(5);
		IFCSHomePage.gotoApplicationAndClickApplicationMenu();
		IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);
		IFCSHomePage.gotoTransactionAndClickManageTransaction();
		transactionListPage.enterTransactionBatchDetails(true, "100", "1", clientName);
		transactionListPage.enterManualTransactionDetails(inputvalues.get("date"), f_referenceNo,
				inputvalues.get("CardNumber"), "", inputvalues.get("LocationNumber"), "100", "");
		transactionListPage.enterTransactionLineItems(inputvalues.get("productCode"), "100", "100", "100");
		transactionListPage.validatePostManualTransaction("Location Agreement Invalid");
		IFCSHomePage.exitIFCS();
	}

	/**
	 * Implemented by Raxsana Babu * @param clientCountry RQ-865
	 * 
	 * @param clientName
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow" })
	public void validatePostManualTransactionWithNonFuelProducts(@Optional("BE") String clientCountry,
			@Optional("WFE") String clientName) {

		test = extent.createTest(
				clientName + ":" + clientCountry
						+ "TC-1663 TC11_TxnMgmt_Manual_Txn Non Fuel Product, TC-1666 TC14_TxnMgmt_Manual_Txn Acc_bal",
				"RQ-865 Able to post manual transactions with Product details (under Line items)");

		// creating object for the Pages
		IFCSLoginPage ifcsloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		TransactionListPage transactionListPage = new TransactionListPage(driver, test);
		TransactionComponentPage transactionComponentPage = new TransactionComponentPage(driver, test);
		WFECommon wfeCommon = new WFECommon(driver, test);
		// Calling Functions
		ifcsloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		ifcsloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, " ");
		IFCSHomePage.gotoApplicationAndClickApplicationMenu();

		Faker fakerN = new Faker();
		String f_referenceNo = fakerN.number().digits(5);
		IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);
		Map<String, String> inputValues = transactionComponentPage.inputValuesForTransaction(clientName, clientCountry,
				"N", "");
		// ActualBalance
		String actualBalanceBefore = wfeCommon.getAccountActualBalance(inputValues.get("CardNumber"));
		// Post Transaction
		IFCSHomePage.gotoTransactionAndClickManageTransaction();
		transactionListPage.enterTransactionBatchDetails(true, "160", "1", clientName);
		transactionListPage.enterManualTransactionDetails(inputValues.get("date"), f_referenceNo,
				inputValues.get("CardNumber"), "", inputValues.get("LocationNumber"), "160", "");
		transactionListPage.enterTransactionLineItems(inputValues.get("productCode"), "160", "100", "160");
		transactionListPage.validatePostManualTransaction("Validation successful");
		transactionListPage.validatePostedInTransaction(f_referenceNo);
		transactionComponentPage.validateAccountBalance(actualBalanceBefore, f_referenceNo,
				inputValues.get("CardNumber"));
		IFCSHomePage.exitIFCS();
	}

	/**
	 * Implemented by Raxsana Babu * @param clientCountry RQ-861
	 * 
	 * @param clientName
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow" })
	public void validatePostManualTransactionForReplacedCards(@Optional("BE") String clientCountry,
			@Optional("WFE") String clientName) {

		test = extent.createTest(clientName + ":" + clientCountry + "TC-1655 TC03_TxnMgmt_Manual_Txn Replaced cards",
				"RQ-861 Post transaction for a newly created card and re-issued card");

		// creating object for the Pages
		IFCSLoginPage ifcsloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		TransactionListPage transactionListPage = new TransactionListPage(driver, test);
		TransactionComponentPage transactionComponentPage = new TransactionComponentPage(driver, test);
		// Calling Functions
		ifcsloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		ifcsloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, " ");
		IFCSHomePage.gotoApplicationAndClickApplicationMenu();

		Faker fakerN = new Faker();
		String f_referenceNo = fakerN.number().digits(5);
		IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);
		Map<String, String> inputValues = transactionComponentPage.inputValuesForTransaction(clientName, clientCountry,
				"N", "Replace");
		// Post Transaction
		IFCSHomePage.gotoTransactionAndClickManageTransaction();
		transactionListPage.enterTransactionBatchDetails(true, "160", "1", clientName);
		transactionListPage.enterManualTransactionDetails(inputValues.get("date"), f_referenceNo,
				inputValues.get("CardNumber"), "", inputValues.get("LocationNumber"), "160", "");
		transactionListPage.enterTransactionLineItems(inputValues.get("productCode"), "160", "100", "160");
		transactionListPage.validatePostManualTransaction("Validation successful");
		transactionListPage.validatePostedInTransaction(f_referenceNo);
		IFCSHomePage.exitIFCS();
	}

	/**
	 * Added by Davu
	 * 
	 * @param clientCountry
	 * @param clientName    Business Flow ID:BF-164
	 */

	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow" })
	public void validatePostNationalTransactionWithMoreThanOneLineItem(@Optional("BE") String clientCountry,
			@Optional("WFE") String clientName) {

		test = extent.createTest(
				clientName + ":" + clientCountry + " TC-1687 TC05_TxnMgmt_Process National Txn with Multi line",
				"Post National transactions with more than one lineitems");

		// creating object for the Pages
		IFCSLoginPage ifcsloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		TransactionListPage transactionListPage = new TransactionListPage(driver, test);
		Common common = new Common(driver, test);
		WFECommon wfecommon = new WFECommon(driver, test);
		ifcsloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");

		// Calling Functions
		ifcsloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		IFCSHomePage.gotoApplicationAndClickApplicationMenu();

		// TestData
		Faker fakerN = new Faker();
		String f_referenceNo = fakerN.number().digits(3);
		IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);

		String clientNameInProp = PropUtils.getPropValue(configProp, clientName + "_" + clientCountry);
		String currentDate = common.getCurrentIFCSDateFromDB(clientNameInProp);
		// Get the IFCS current date
		String ifcsCurrentDate = common.enterADateValueInStatusBeginDateField("Current", currentDate);

		System.out.println("Date ::" + ifcsCurrentDate);
		String cardNumber = common.getCardNumberFromIFCSDB(clientName, clientCountry, "Normal Service");

		// String locationNo = common.chooseALocationWithNonFuelProduct("Y");

		String locationNo = wfecommon.getLocationNumberForWFE(clientName ,clientCountry);

		// Transaction Details 
		IFCSHomePage.gotoTransactionAndClickManageTransaction();
		transactionListPage.enterTransactionBatchDetails(true, "320", "1", clientName);
		transactionListPage.enterManualTransactionDetails(ifcsCurrentDate, f_referenceNo, cardNumber, "", locationNo,
				"320", "");
		transactionListPage.enterTransactionLineItems("135", "160", "100", "160");
		transactionListPage.enterTransactionLineItems("530", "160", "100", "160");
		transactionListPage.validatePostManualTransaction("Validation successful");
		transactionListPage.validatePostedInTransaction(f_referenceNo);

		IFCSHomePage.exitIFCS();
	}

	/**
	 * Added by Davu
	 * 
	 * @param clientCountry
	 * @param clientName    Business Flow ID:BF-122
	 */

	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow", "Regression" })
	public void ValidateTransactionWithInvalidLocation(String clientCountry, String clientName)
			throws TransformerException {

		test = extent.createTest(
				clientName + ":" + clientCountry + " TC-1697 TC04_TxnMgmt_Susp_Txn Invalid location and Product",
				"Transaction is suspended if card is swiped with invalid location / invalid Product");

		// Initialize objects

		Map<String, String> inputvalues = new HashMap<String, String>();
		TransactionComponentPage transactionComponentPage = new TransactionComponentPage(driver, test);
		WFECommon wfecommon = new WFECommon(driver, test);
		Map<String, String> valuesForValidation = new LinkedHashMap<String, String>();
		IFCSLoginPage ifcsloginPage = new IFCSLoginPage(driver, test);
		Common common = new Common(driver, test);
		ifcsloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");

		// Getting input values for XML Creation
		inputvalues = transactionComponentPage.inputValuesForInvalidLocation(clientName, clientCountry);

		System.out.println("Input values " + inputvalues);

		// XML Creation valuesForValidation =
		wfecommon.XMLCreationForTransactionWFE(clientName, clientCountry, inputvalues, "N", "0");

		// Validate transaction posted or not
		// transactionComponentPage.validateSuspendTransaction(valuesForValidation,"CardLocked-Out");

		String filename = Constants.TRANSACTION_TEMP_FILE;
		String reference = inputvalues.get("reference");
		String card = inputvalues.get("CardNumber");

		common.updatePropFile("TRANSACTION_REF_" + clientName + "_" + clientCountry, reference, filename);
		common.updatePropFile("TRANSACTION_CARD_" + clientName + "_" + clientCountry, card, filename);

	}

	/**
	 * Added by Davu
	 * 
	 * @param clientCountry
	 * @param clientName    Business Flow ID:BF-122
	 */

	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow", "Regression" })
	public void ValidatePostedTransactionWithInvalidLocation(String clientCountry, String clientName)
			throws TransformerException {

		test = extent.createTest(clientName + ":" + clientCountry
				+ " ID:BF-122 Validation - Transaction is suspended if card is swiped with invalid location in IFCS",
				"Validation - Transaction is suspended if card is swiped with invalid location in IFCS");

		IFCSLoginPage ifcsLoginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		TransactionComponentPage transactionComponentPage = new TransactionComponentPage(driver, test);

		String refNo = PropUtils.getPropValue(transactionTempFileProp,
				"TRANSACTION_REF_" + clientName + "_" + clientCountry);
		String cardNo = PropUtils.getPropValue(transactionTempFileProp,
				"TRANSACTION_CARD_" + clientName + "_" + clientCountry);

		ifcsLoginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		ifcsLoginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		IFCSHomePage.gotoApplicationAndClickApplicationMenu();
		IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);
		IFCSHomePage.gotoTransactionAndClickManageTransaction();
		transactionComponentPage.validateSuspendedtransaction(refNo, "Customer Pricing Error");

	}

	/**
	 * Added by Davu
	 * 
	 * @param clientCountry
	 * @param clientName    Business Flow ID:BF-123
	 */

	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow", "Regression" })
	public void ValidateTransactionWithInvalidProductCode(String clientCountry, String clientName)
			throws TransformerException {

		test = extent.createTest(
				clientName + ":" + clientCountry
						+ "  ID:BF-123 Transaction is suspended if card is swiped with invalid Product in IFCS",
				"Transaction is suspended if card is swiped with invalid Product in IFCS");

		// Initialize objects

		Map<String, String> inputvalues = new HashMap<String, String>();
		TransactionComponentPage transactionComponentPage = new TransactionComponentPage(driver, test);
		WFECommon wfecommon = new WFECommon(driver, test);
		Common common = new Common(driver, test);
		Map<String, String> valuesForValidation = new LinkedHashMap<String, String>();
		IFCSLoginPage ifcsloginPage = new IFCSLoginPage(driver, test);
		ifcsloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");

		// Getting input values for XML Creation
		inputvalues = transactionComponentPage.inputValuesForInvalidProductCode(clientName, clientCountry);

		System.out.println("Input values " + inputvalues);

		// XML Creation valuesForValidation =
		wfecommon.XMLCreationForTransactionWFE(clientName, clientCountry, inputvalues, "N", "0");

		// Validate transaction posted or not
		// transactionComponentPage.validateSuspendTransaction(valuesForValidation,"CardLocked-Out");

		String filename = Constants.TRANSACTION_TEMP_FILE;
		String reference = inputvalues.get("reference");
		String card = inputvalues.get("CardNumber");

		common.updatePropFile("TRANSACTION_INVALID_PRODUCT_REF_" + clientName + "_" + clientCountry, reference,
				filename);
		common.updatePropFile("TRANSACTION_IVALID_PRODUCT_CARD_" + clientName + "_" + clientCountry, card, filename);

	}

	/**
	 * Added by Davu
	 * 
	 * @param clientCountry
	 * @param clientName    Business Flow ID:BF-123
	 */

	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow", "Regression" })
	public void validatePostedTransactionWithInvalidProductCode(String clientCountry, String clientName)
			throws TransformerException {

		test = extent.createTest(clientName + ":" + clientCountry
				+ " ID:BF-123 Validation - Transaction is suspended if card is swiped with invalid product code in IFCS",
				"Validation - Transaction is suspended if card is swiped with invalid produt code in IFCS");

		IFCSLoginPage ifcsLoginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		TransactionComponentPage transactionComponentPage = new TransactionComponentPage(driver, test);

		String refNo = PropUtils.getPropValue(transactionTempFileProp,
				"TRANSACTION_INVALID_PRODUCT_REF_" + clientName + "_" + clientCountry);

		ifcsLoginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		ifcsLoginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		IFCSHomePage.gotoApplicationAndClickApplicationMenu();
		IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);
		IFCSHomePage.gotoTransactionAndClickManageTransaction();
		transactionComponentPage.validateSuspendedtransaction(refNo, "Invalid POS Line Item Product Code");

	}

	/**
	 * Added by Davu
	 * 
	 * @param clientCountry
	 * @param clientName    Business Flow ID:BF-120
	 */

	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow", "Regression" })
	public void ValidateTransactionWithDamagedCard(@Optional("BE") String clientCountry,
			@Optional("WFE") String clientName) throws TransformerException {

		test = extent.createTest(
				clientName + ":" + clientCountry
						+ " ID:BF-120 Unable to post the transaction with Damaged Card in IFCS",
				"Unable to post the transaction with Damaged Card in IFCS");

		// Initialize objects

		Map<String, String> inputvalues = new HashMap<String, String>();
		TransactionComponentPage transactionComponentPage = new TransactionComponentPage(driver, test);
		WFECommon wfecommon = new WFECommon(driver, test);
		Map<String, String> valuesForValidation = new LinkedHashMap<String, String>();
		IFCSLoginPage ifcsloginPage = new IFCSLoginPage(driver, test);
		Common common = new Common(driver, test);
		ifcsloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");

		// Getting input values for XML Creation
		inputvalues = transactionComponentPage.inputValuesForDamagedCard(clientName, clientCountry);

		System.out.println("Input values " + inputvalues);

		// XML Creation valuesForValidation =
		wfecommon.XMLCreationForTransactionWFE(clientName, clientCountry, inputvalues, "N", "0");

		// Validate transaction posted or not
		// transactionComponentPage.validateSuspendTransaction(valuesForValidation,"CardLocked-Out");

		String filename = Constants.TRANSACTION_TEMP_FILE;
		String reference = inputvalues.get("reference");

		common.updatePropFile("TRANSACTION_DAMAGED_CARD_REF_" + clientName + "_" + clientCountry, reference, filename);

	}

	/**
	 * Added by Davu
	 * 
	 * @param clientCountry
	 * @param clientName    Business Flow ID:BF-120
	 */

	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow", "Regression" })
	public void validatePostedTransactionWithDamaged(String clientCountry, String clientName)
			throws TransformerException {

		test = extent.createTest(clientName + ":" + clientCountry
				+ " ID:BF-120 Validation - Transaction is suspended if card is swiped with Damaged Card in IFCS",
				"Validation - Transaction is suspended if card is swiped with invalid produt code in IFCS");

		IFCSLoginPage ifcsLoginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		TransactionComponentPage transactionComponentPage = new TransactionComponentPage(driver, test);

		String refNo = PropUtils.getPropValue(transactionTempFileProp,
				"TRANSACTION_DAMAGED_CARD_REF_" + clientName + "_" + clientCountry);

		ifcsLoginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		ifcsLoginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		IFCSHomePage.gotoApplicationAndClickApplicationMenu();
		IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);
		IFCSHomePage.gotoTransactionAndClickManageTransaction();
		transactionComponentPage.validateSuspendedtransaction(refNo, "Invalid Card Value");

	}

	/**
	 * Added by Davu
	 * 
	 * @param clientCountry
	 * @param clientName    Business Flow ID:BF-121
	 */

	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow", "Regression" })
	public void ValidateTransactionWithLostCard(String clientCountry, String clientName) throws TransformerException {

		test = extent.createTest(
				clientName + ":" + clientCountry + " TC-1695 TC02_TxnMgmt_Susp_Txn Invalid card status",
				"Transaction should be suspended while posting transaction with invalid card status");

		// Initialize objects

		Map<String, String> inputvalues = new HashMap<String, String>();
		TransactionComponentPage transactionComponentPage = new TransactionComponentPage(driver, test);
		WFECommon wfecommon = new WFECommon(driver, test);
		Map<String, String> valuesForValidation = new LinkedHashMap<String, String>();
		IFCSLoginPage ifcsloginPage = new IFCSLoginPage(driver, test);
		Common common = new Common(driver, test);
		ifcsloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");

		// Getting input values for XML Creation
		inputvalues = transactionComponentPage.inputValuesForLostCard(clientName, clientCountry);

		System.out.println("Input values " + inputvalues);

		// XML Creation valuesForValidation =
		wfecommon.XMLCreationForTransactionWFE(clientName, clientCountry, inputvalues, "N", "0");

		String filename = Constants.TRANSACTION_TEMP_FILE;
		String reference = inputvalues.get("reference");
		String card = inputvalues.get("CardNumber");

		common.updatePropFile("TRANSACTION_LOST_CARD_REF_" + clientName + "_" + clientCountry, reference, filename);
		common.updatePropFile("TRANSACTION_LOST_CARD_" + clientName + "_" + clientCountry, card, filename);

		// Validate transaction posted or not
		// transactionComponentPage.validateSuspendTransaction(valuesForValidation,"CardLocked-Out");

	}

	/**
	 * Added by Davu
	 * 
	 * @param clientCountry
	 * @param clientName    Business Flow ID:BF-121
	 */

	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow", "Regression" })
	public void validatePostedTransactionWithLostCard(String clientCountry, String clientName)
			throws TransformerException {

		test = extent.createTest(clientName + ":" + clientCountry
				+ " ID:BF-121 Validation - Transaction is suspended if card is swiped with Lost Card in IFCS",
				"Validation - Transaction is suspended if card is swiped with invalid Lost card in IFCS");

		IFCSLoginPage ifcsLoginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		TransactionComponentPage transactionComponentPage = new TransactionComponentPage(driver, test);

		String refNo = PropUtils.getPropValue(transactionTempFileProp,
				"TRANSACTION_LOST_CARD_REF_" + clientName + "_" + clientCountry);

		ifcsLoginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		ifcsLoginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		IFCSHomePage.gotoApplicationAndClickApplicationMenu();
		IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);
		IFCSHomePage.gotoTransactionAndClickManageTransaction();
		transactionComponentPage.validateSuspendedtransaction(refNo, "Invalid Card Value");

	}

	/**
	 * Added by Davu
	 * 
	 * @param clientCountry
	 * @param clientName    Business Flow ID:BF-121
	 */

	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow", "Regression" })
	public void ValidateTransactionWithInvalidTime(String clientCountry, String clientName)
			throws TransformerException {

		test = extent.createTest(
				clientName + ":" + clientCountry + " TC-1696 TC03_TxnMgmt_Susp_Txn Invalid Unit Price and Time",
				"Transaction is suspended if card is swiped with invalid Unit Price / invalid time");

		// Initialize objects

		Map<String, String> inputvalues = new HashMap<String, String>();
		TransactionComponentPage transactionComponentPage = new TransactionComponentPage(driver, test);
		WFECommon wfecommon = new WFECommon(driver, test);
		Map<String, String> valuesForValidation = new LinkedHashMap<String, String>();
		IFCSLoginPage ifcsloginPage = new IFCSLoginPage(driver, test);
		Common common = new Common(driver, test);
		ifcsloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");

		// Getting input values for XML Creation
		inputvalues = transactionComponentPage.validInputValues(clientName, clientCountry);

		System.out.println("Input values " + inputvalues);

		// XML Creation valuesForValidation =
		wfecommon.XMLCreationForTransactionWFEWithInvalidvalues(clientName, clientCountry, inputvalues, "N", "Y", "N");

		// Validate transaction posted or not
		// transactionComponentPage.validateSuspendTransaction(valuesForValidation,"CardLocked-Out");

		String filename = Constants.TRANSACTION_TEMP_FILE;
		String reference = inputvalues.get("reference");

		common.updatePropFile("TRANSACTION_INVALID_TIME_REF_" + clientName + "_" + clientCountry, reference, filename);

	}

	/**
	 * Added by Davu
	 * 
	 * @param clientCountry
	 * @param clientName    Business Flow ID:BF-121
	 */

	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow", "Regression" })
	public void validatePostedTransactionWithInvalidTime(String clientCountry, String clientName)
			throws TransformerException {

		test = extent.createTest(clientName + ":" + clientCountry
				+ " ID:BF-121 Validation - Transaction is suspended if card is swiped with Invalid Time in IFCS",
				"Validation - Transaction is suspended if card is swiped with invalid Invalid time in IFCS");

		IFCSLoginPage ifcsLoginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		TransactionComponentPage transactionComponentPage = new TransactionComponentPage(driver, test);

		String refNo = PropUtils.getPropValue(transactionTempFileProp,
				"TRANSACTION_INVALID_TIME_REF_" + clientName + "_" + clientCountry);

		ifcsLoginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		ifcsLoginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		IFCSHomePage.gotoApplicationAndClickApplicationMenu();
		IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);
		IFCSHomePage.gotoTransactionAndClickManageTransaction();
		transactionComponentPage.validateSuspendedtransaction(refNo, "Card Time Limits Exceeded");

	}

	/**
	 * Added by Davu
	 * 
	 * @param clientCountry
	 * @param clientName    Business Flow ID:BF-121
	 */

	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow", "Regression" })
	public void ValidateTransactionWithInvalidSeqNo(String clientCountry, String clientName)
			throws TransformerException {

		test = extent.createTest(
				clientName + ":" + clientCountry
						+ " ID:BF-120 Unable to post the transaction with invalid seq no in IFCS",
				"Unable to post the transaction with invalid seq no in IFCS");

		// Initialize objects

		Map<String, String> inputvalues = new HashMap<String, String>();
		TransactionComponentPage transactionComponentPage = new TransactionComponentPage(driver, test);
		WFECommon wfecommon = new WFECommon(driver, test);
		Map<String, String> valuesForValidation = new LinkedHashMap<String, String>();
		IFCSLoginPage ifcsloginPage = new IFCSLoginPage(driver, test);
		ifcsloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");

		// Getting input values for XML Creation
		inputvalues = transactionComponentPage.validInputValues(clientName, clientCountry);

		System.out.println("Input values " + inputvalues);

		// XML Creation valuesForValidation =
		wfecommon.XMLCreationForTransactionWFEWithInvalidvalues(clientName, clientCountry, inputvalues, "N", "N", "Y");

		// Validate transaction posted or not
		// transactionComponentPage.validateSuspendTransaction(valuesForValidation,"CardLocked-Out");

	}

	/**
	 * Added by Davu
	 * 
	 * @param clientCountry
	 * @param clientName    Business Flow ID:BF-121
	 */

	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow", "Regression" })
	public void ValidateTransactionWithOverCreditLimit(String clientCountry, String clientName)
			throws TransformerException {

		test = extent.createTest(
				clientName + ":" + clientCountry + " ID:BF-120 Post the transaction with Over Credit Limit in IFCS",
				"Post the transaction with Over credit limit in IFCS");

		// Initialize objects

		Map<String, String> inputvalues = new HashMap<String, String>();
		TransactionComponentPage transactionComponentPage = new TransactionComponentPage(driver, test);
		WFECommon wfecommon = new WFECommon(driver, test);
		Common common = new Common(driver, test);
		Map<String, String> valuesForValidation = new LinkedHashMap<String, String>();
		IFCSLoginPage ifcsloginPage = new IFCSLoginPage(driver, test);
		ifcsloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");

		// Getting input values for XML Creation
		inputvalues = transactionComponentPage.inputValuesForOverCreditLimit(clientName, clientCountry);

		System.out.println("Input values " + inputvalues);

		// XML Creation valuesForValidation =
		wfecommon.XMLCreationForTransactionWFE(clientName, clientCountry, inputvalues, "N", "0");

		// Validate transaction posted or not
		// transactionComponentPage.validateSuspendTransaction(valuesForValidation,"CardLocked-Out");

		String filename = Constants.TRANSACTION_TEMP_FILE;
		String reference = inputvalues.get("reference");
		String card = inputvalues.get("CardNumber");

		common.updatePropFile("TRANSACTION_OVER_CRIDIT_REF_" + clientName + "_" + clientCountry, reference, filename);
		common.updatePropFile("TRANSACTION_OVER_CRIDIT_CARD_" + clientName + "_" + clientCountry, card, filename);

	}

	/**
	 * Added by Davu
	 * 
	 * @param clientCountry
	 * @param clientName    Business Flow ID:BF-121
	 */

	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow", "Regression" })
	public void validatePostedTransactionWithOverLimit(String clientCountry, String clientName)
			throws TransformerException {

		test = extent.createTest(
				clientName + ":" + clientCountry
						+ " ID:BF-121 Validation - Transaction is suspended if card is swiped with over cridit in IFCS",
				"Validation - Transaction is suspended if card is swiped with over cridit limit in IFCS");

		IFCSLoginPage ifcsLoginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		TransactionComponentPage transactionComponentPage = new TransactionComponentPage(driver, test);

		String refNo = PropUtils.getPropValue(transactionTempFileProp,
				"TRANSACTION_OVER_CRIDIT_REF_" + clientName + "_" + clientCountry);

		ifcsLoginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		ifcsLoginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		IFCSHomePage.gotoApplicationAndClickApplicationMenu();
		IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);
		IFCSHomePage.gotoTransactionAndClickManageTransaction();
		transactionComponentPage.validateSuspendedtransaction(refNo, "Card Time Limits Exceeded");

	}

	/**
	 * Implemented by Venkata Davu
	 * 
	 * @param clientCountry
	 * @param clientName    Business Flow ID:BF-014
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "BusinessFlow" })
	public void validateDisputeTransaction(@Optional("NL") String clientCountry, @Optional("WFE") String clientName) {
		test = extent.createTest(clientName + ":" + clientCountry + " TC-1762 TC01_Dispute_Txn_Unable",
				" Verify whether dispute is applied if the customer is willing to reverse a transaction");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		CardMaintenancePage cardMaintenancePage = new CardMaintenancePage(driver, test);
		TransactionComponentPage transactionComponentPage = new TransactionComponentPage(driver, test);
		Common common = new Common(driver, test);
		WFECommon wfecommon = new WFECommon(driver, test);
		IFCSloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, " ");

		Map<String,String> cardNo = wfecommon.getCardNumberfromPOSTransactions(clientName +"_"+ clientCountry);

		IFCSloginPage.logInfo("Customer number from DB" + cardNo);

		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		cardMaintenancePage.chooseAndSearchCardNo(cardNo.get("CARD_NO"));
		transactionComponentPage.disputeTransaction(cardNo.get("PROCESSED_AT"));

		IFCSHomePage.exitIFCS();

	}

	/**
	 * Added by Davu
	 * 
	 * @param clientCountry
	 * @param clientName    Business Flow ID:BF-121
	 */

	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow", "Regression" })
	public void ValidateTransactionOverTheMonthlyVelocityLimit(String clientCountry, String clientName)
			throws TransformerException {

		test = extent.createTest(
				clientName + ":" + clientCountry + " TC-1688 TC06_TxnMgmt_Process Txn amount beyond Monthly limit",
				"Velocity Control (Card Level) : Unable to post transaction beyond the monthly limit (Card/ Transaction)");

		// Initialize objects

		Map<String, String> inputvalues = new HashMap<String, String>();
		TransactionComponentPage transactionComponentPage = new TransactionComponentPage(driver, test);
		WFECommon wfecommon = new WFECommon(driver, test);
		Map<String, String> valuesForValidation = new LinkedHashMap<String, String>();
		IFCSLoginPage ifcsloginPage = new IFCSLoginPage(driver, test);
		Common common = new Common(driver, test);
		ifcsloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");

		// Getting input values for XML Creation
		inputvalues = transactionComponentPage.inputValuesForOverVelocityLimit(clientName, clientCountry,"1");

		System.out.println("Input values " + inputvalues);

		// XML Creation valuesForValidation =
		wfecommon.XMLCreationForTransactionWFE(clientName, clientCountry, inputvalues, "N", "0");

		String filename = Constants.TRANSACTION_TEMP_FILE;
		String reference = inputvalues.get("reference");
		String card = inputvalues.get("CardNumber");

		common.updatePropFile("TRANSACTION_MONTHLY_LIMIT_REF_" + clientName + "_" + clientCountry, reference, filename);
		common.updatePropFile("TRANSACTION_MONTHLY_LIMIT_CARD_" + clientName + "_" + clientCountry, card, filename);

	}

	/**
	 * Added by Davu
	 * 
	 * @param clientCountry
	 * @param clientName    Business Flow ID:BF-121
	 */

	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow", "Regression" })
	public void validatePostedTransactionWithOverMothlyVelocityLimit(String clientCountry, String clientName)
			throws TransformerException {

		test = extent.createTest(clientName + ":" + clientCountry
				+ " ID:BF-121 Validation - Transaction is suspended if card is swiped with over monthly velocity limit in IFCS",
				"Validation - Transaction is suspended if card is swiped with over monthly velocity limit in IFCS");

		IFCSLoginPage ifcsLoginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		TransactionComponentPage transactionComponentPage = new TransactionComponentPage(driver, test);

		String refNo = PropUtils.getPropValue(transactionTempFileProp,
				"TRANSACTION_MONTHLY_LIMIT_REF_" + clientName + "_" + clientCountry);

		ifcsLoginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		ifcsLoginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		IFCSHomePage.gotoApplicationAndClickApplicationMenu();
		IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);
		IFCSHomePage.gotoTransactionAndClickManageTransaction();
		transactionComponentPage.validateSuspendedtransaction(refNo, "Need to update error message");

	}

	/**
	 * Added by Davu
	 * 
	 * @param clientCountry
	 * @param clientName    Business Flow ID:BF-121
	 */

	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow", "Regression" })
	public void ValidateTransactionOverTheDailyVelocityLimit(String clientCountry, String clientName)
			throws TransformerException {

		test = extent.createTest(
				clientName + ":" + clientCountry + " TC-1692 TC10_TxnMgmt_Process Txn amount beyond Daily limit",
				"Velocity Control (Card Level) : Unable to post transaction beyond the daily limit (Card/ Transaction)");

		// Initialize objects

		Map<String, String> inputvalues = new HashMap<String, String>();
		TransactionComponentPage transactionComponentPage = new TransactionComponentPage(driver, test);
		WFECommon wfecommon = new WFECommon(driver, test);
		Map<String, String> valuesForValidation = new LinkedHashMap<String, String>();
		IFCSLoginPage ifcsloginPage = new IFCSLoginPage(driver, test);
		Common common = new Common(driver, test);
		ifcsloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");

		// Getting input values for XML Creation
		inputvalues = transactionComponentPage.inputValuesForOverVelocityLimit(clientName, clientCountry,"2");//inputValuesForOverCreditLimit(clientName, clientCountry);

		System.out.println("Input values " + inputvalues);

		// XML Creation valuesForValidation =
		wfecommon.XMLCreationForTransactionWFE(clientName, clientCountry, inputvalues, "N", "0");

		String filename = Constants.TRANSACTION_TEMP_FILE;
		String reference = inputvalues.get("reference");
		String card = inputvalues.get("CardNumber");

		common.updatePropFile("TRANSACTION_DAILY_LIMIT_REF_" + clientName + "_" + clientCountry, reference, filename);
		common.updatePropFile("TRANSACTION_DAILY_LIMIT_CARD_" + clientName + "_" + clientCountry, card, filename);

	}

	/**
	 * Added by Davu
	 * 
	 * @param clientCountry
	 * @param clientName    Business Flow ID:BF-121
	 */

	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow", "Regression" })
	public void validatePostedTransactionWithOverDailyVelocityLimit(String clientCountry, String clientName)
			throws TransformerException {

		test = extent.createTest(clientName + ":" + clientCountry
				+ " ID:BF-121 Validation - Transaction is suspended if card is swiped with over daily velocity limit in IFCS",
				"Validation - Transaction is suspended if card is swiped with over Daily velocity limit in IFCS");

		IFCSLoginPage ifcsLoginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		TransactionComponentPage transactionComponentPage = new TransactionComponentPage(driver, test);

		String refNo = PropUtils.getPropValue(transactionTempFileProp,
				"TRANSACTION_DAILY_LIMIT_REF_" + clientName + "_" + clientCountry);

		ifcsLoginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		ifcsLoginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		IFCSHomePage.gotoApplicationAndClickApplicationMenu();
		IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);
		IFCSHomePage.gotoTransactionAndClickManageTransaction();
		transactionComponentPage.validateSuspendedtransaction(refNo, "Need to update error message");

	}

	/**
	 * Added by Davu
	 * 
	 * @param clientCountry
	 * @param clientName    Business Flow ID:BF-121
	 */

	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow", "Regression" })
	public void ValidateTransactionOverTheWeeklyVelocityLimit(String clientCountry, String clientName)
			throws TransformerException {

		test = extent.createTest(
				clientName + ":" + clientCountry + " TC-1691 TC09_TxnMgmt_Process Txn amount beyond Weekly limit",
				"Velocity Control (Card Level) : Unable to post transaction beyond the weekly limit (Card/ Transaction)");

		// Initialize objects

		Map<String, String> inputvalues = new HashMap<String, String>();
		TransactionComponentPage transactionComponentPage = new TransactionComponentPage(driver, test);
		WFECommon wfecommon = new WFECommon(driver, test);
		Map<String, String> valuesForValidation = new LinkedHashMap<String, String>();
		IFCSLoginPage ifcsloginPage = new IFCSLoginPage(driver, test);
		Common common = new Common(driver, test);
		ifcsloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");

		// Getting input values for XML Creation
		inputvalues = transactionComponentPage.inputValuesForOverVelocityLimit(clientName, clientCountry,"3");

		System.out.println("Input values " + inputvalues);

		// XML Creation valuesForValidation =
		wfecommon.XMLCreationForTransactionWFE(clientName, clientCountry, inputvalues, "N", "0");

		String filename = Constants.TRANSACTION_TEMP_FILE;
		String reference = inputvalues.get("reference");
		String card = inputvalues.get("CardNumber");

		common.updatePropFile("TRANSACTION_WEEKLY_LIMIT_REF_" + clientName + "_" + clientCountry, reference, filename);
		common.updatePropFile("TRANSACTION_WEEKLY_LIMIT_CARD_" + clientName + "_" + clientCountry, card, filename);

	}

	/**
	 * Added by Davu
	 * 
	 * @param clientCountry
	 * @param clientName    Business Flow ID:BF-121
	 */

	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow", "Regression" })
	public void validatePostedTransactionWithOverWeeklyVelocityLimit(String clientCountry, String clientName)
			throws TransformerException {

		test = extent.createTest(clientName + ":" + clientCountry
				+ " ID:BF-121 Validation - Transaction is suspended if card is swiped with over weekly velocity limit in IFCS",
				"Validation - Transaction is suspended if card is swiped with over weekly velocity limit in IFCS");

		IFCSLoginPage ifcsLoginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		TransactionComponentPage transactionComponentPage = new TransactionComponentPage(driver, test);

		String refNo = PropUtils.getPropValue(transactionTempFileProp,
				"TRANSACTION_WEEKLY_LIMIT_REF_" + clientName + "_" + clientCountry);

		ifcsLoginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		ifcsLoginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		IFCSHomePage.gotoApplicationAndClickApplicationMenu();
		IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);
		IFCSHomePage.gotoTransactionAndClickManageTransaction();
		transactionComponentPage.validateSuspendedtransaction(refNo, "Need to update error message");

	}

	/**
	 * Added by Davu
	 * 
	 * @param clientCountry
	 * @param clientName    Business Flow ID:BF-163
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow" })
	public void validatePostManualPurchaseWIthFutureDate(@Optional("BE") String clientCountry,
			@Optional("WFE") String clientName) {

		test = extent.createTest(clientName + ":" + clientCountry + " TC-1678 TC19_TxnMgmt_Manual_Txn Future Date ",
				"Transaction with future date should not be allowed");

		// creating object for the Pages
		IFCSLoginPage ifcsloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		TransactionListPage transactionListPage = new TransactionListPage(driver, test);
		Common common = new Common(driver, test);
		WFECommon wfecommon = new WFECommon(driver, test);

		// Calling Functions
		ifcsloginPage.login("IFCS_URL_WFE", "IFCS_WFE_USERNAME", "IFCS_WFE_PASSWORD");
		ifcsloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, " ");

		IFCSHomePage.gotoApplicationAndClickApplicationMenu();

		// TestData
		Faker fakerN = new Faker();
		String f_referenceNo = fakerN.number().digits(5);
		IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);

		String clientNameInProp = PropUtils.getPropValue(configProp, clientName + "_" + clientCountry);
		String currentDate = common.getCurrentIFCSDateFromDB(clientNameInProp);
		// Get the IFCS current date
		String ifcsCurrentDate = common.enterADateValueInStatusBeginDateField("Current", currentDate);

		System.out.println("ifcs current date before modification" + ifcsCurrentDate);

		String year = ifcsCurrentDate.substring(ifcsCurrentDate.length() - 4);

		System.out.println("ifcs current year before modification" + year);

		int yearInt = Integer.parseInt(year) + 1;

		String year1 = Integer.toString(yearInt);

		System.out.println("ifcs current new year before modification" + year1);

		ifcsCurrentDate = ifcsCurrentDate.replace(year, year1);

		System.out.println("ifcs current date after modification" + ifcsCurrentDate);

		/*
		 * 
		 * String currentDate =
		 * common.getCurrentIFCSDateFromDB(clientName+clientCountry); // Get the IFCS
		 * current date String ifcsCurrentDate =
		 * common.enterADateValueInStatusBeginDateField("Current", currentDate);
		 */
		System.out.println("Date ::" + ifcsCurrentDate);
		String cardNo = common.getActiveCardsWithBalanceAndRowIndex(1);
		String cardNo2 = common.getActiveCardsWithBalanceAndRowIndex(2);
		// String locationNo=common.chooseALocationWithNonFuelProduct("Y");
		// String
		// productCode=common.chooseANonFuelProductExtCodeInTheLocation(locationNo,"Y","externalCode");

		String locationNo = wfecommon.getLocationNumberForWFE(clientName, clientCountry);

		// Transaction Details0.

		IFCSHomePage.gotoTransactionAndClickManageTransaction();

		transactionListPage.enterTransactionBatchDetails(true, "160", "1", clientName);
		transactionListPage.selectBatchTypeInTransactionDetails("Manual Voucher");
		transactionListPage.enterManualTransactionDetails(ifcsCurrentDate, f_referenceNo, cardNo, cardNo2, locationNo,
				"160", "");
		// transactionListPage.enterManualTransactionDetails(ifcsCurrentDate,
		// f_referenceNo, cardlist.get(0),
		// cardlist.get(1), locNoFromDB, "160", "");
		transactionListPage.enterTransactionLineItems("530", "160", "100", "160");
		transactionListPage.validatePostManualTransaction("Transaction is Future Dated");
		// transactionListPage.verifyValidationResult("Transaction Total not equal Line
		// Items Total");
		IFCSHomePage.exitIFCS();
	}

	/**
	 * Added by Davu
	 * 
	 * @param clientCountry
	 * @param clientName    Business Flow ID:BF-163
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow" })
	public void validatePostManualPurchaseForChildCustomer(@Optional("BE") String clientCountry,
			@Optional("WFE") String clientName) {

		test = extent.createTest(clientName + ":" + clientCountry + " TC-1743 TC24_TxnMgmt_Manual_Txn Child Customer ",
				"Post transaction for a newly created card and re-issued card");

		// creating object for the Pages
		IFCSLoginPage ifcsloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		TransactionListPage transactionListPage = new TransactionListPage(driver, test);
		Common common = new Common(driver, test);
		WFECommon wfecommon = new WFECommon(driver, test);

		// Calling Functions
		ifcsloginPage.login("IFCS_URL_WFE", "IFCS_WFE_USERNAME", "IFCS_WFE_PASSWORD");
		ifcsloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, " ");

		IFCSHomePage.gotoApplicationAndClickApplicationMenu();

		// TestData
		Faker fakerN = new Faker();
		String f_referenceNo = fakerN.number().digits(5);
		IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);

		String clientNameInProp = PropUtils.getPropValue(configProp, clientName + "_" + clientCountry);
		String currentDate = common.getCurrentIFCSDateFromDB(clientNameInProp);
		// Get the IFCS current date
		String ifcsCurrentDate = common.enterADateValueInStatusBeginDateField("Current", currentDate);
		System.out.println("Date ::" + ifcsCurrentDate);

		String childCustomerNo = wfecommon.getParentOrChildCustomersHavingCardsWithExpectedStatus(
				clientName + "_" + clientCountry, "child", "Normal Service");
		String cardNo = common.getActiveCardOfTheCustomer(childCustomerNo, clientName, clientCountry);

		// String locationNo=common.chooseALocationWithNonFuelProduct("Y");
		// String
		// productCode=common.chooseANonFuelProductExtCodeInTheLocation(locationNo,"Y","externalCode");

		String locationNo = wfecommon.getLocationNumberForWFE(clientName, clientCountry);

		// Transaction Details0.

		IFCSHomePage.gotoTransactionAndClickManageTransaction();

		transactionListPage.enterTransactionBatchDetails(true, "160", "1", clientName);
		transactionListPage.selectBatchTypeInTransactionDetails("Manual Voucher");
		transactionListPage.enterManualTransactionDetails(ifcsCurrentDate, f_referenceNo, cardNo, " ", locationNo,
				"160", "");
		// transactionListPage.enterManualTransactionDetails(ifcsCurrentDate,
		// f_referenceNo, cardlist.get(0),
		// cardlist.get(1), locNoFromDB, "160", "");
		transactionListPage.enterTransactionLineItems("530", "160", "100", "160");
		transactionListPage.validatePostManualTransaction("Validation successful");
		// transactionListPage.verifyValidationResult("Transaction Total not equal Line
		// Items Total");
		IFCSHomePage.exitIFCS();
	}

	/**
	 * Added by Davu
	 * 
	 * @param clientCountry
	 * @param clientName    Business Flow ID:BF-163
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow" })
	public void validatePostManualPurchaseForParentCustomer(@Optional("BE") String clientCountry,
			@Optional("WFE") String clientName) {

		test = extent.createTest(clientName + ":" + clientCountry + "  TC25_TxnMgmt_Manual_Txn Parent Customer ",
				"Post transaction for a newly created card and re-issued card");

		// creating object for the Pages
		IFCSLoginPage ifcsloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		TransactionListPage transactionListPage = new TransactionListPage(driver, test);
		Common common = new Common(driver, test);
		WFECommon wfecommon = new WFECommon(driver, test);

		// Calling Functions
		ifcsloginPage.login("IFCS_URL_WFE", "IFCS_WFE_USERNAME", "IFCS_WFE_PASSWORD");
		ifcsloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, " ");

		IFCSHomePage.gotoApplicationAndClickApplicationMenu();

		// TestData
		Faker fakerN = new Faker();
		String f_referenceNo = fakerN.number().digits(5);
		IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);

		String clientNameInProp = PropUtils.getPropValue(configProp, clientName + "_" + clientCountry);
		String currentDate = common.getCurrentIFCSDateFromDB(clientNameInProp);
		// Get the IFCS current date
		String ifcsCurrentDate = common.enterADateValueInStatusBeginDateField("Current", currentDate);
		System.out.println("Date ::" + ifcsCurrentDate);

		String parentCustomerNo = wfecommon.getParentOrChildCustomersHavingCardsWithExpectedStatus(
				clientName + "_" + clientCountry, "parent", "Normal Service");
		String cardNo = common.getActiveCardOfTheCustomer(parentCustomerNo, clientName, clientCountry);

		// String locationNo=common.chooseALocationWithNonFuelProduct("Y");
		// String
		// productCode=common.chooseANonFuelProductExtCodeInTheLocation(locationNo,"Y","externalCode");

		String locationNo = wfecommon.getLocationNumberForWFE(clientName, clientCountry);

		// Transaction Details0.

		IFCSHomePage.gotoTransactionAndClickManageTransaction();

		transactionListPage.enterTransactionBatchDetails(true, "160", "1", clientName);
		transactionListPage.selectBatchTypeInTransactionDetails("Manual Voucher");
		transactionListPage.enterManualTransactionDetails(ifcsCurrentDate, f_referenceNo, cardNo, " ", locationNo,
				"160", "");
		// transactionListPage.enterManualTransactionDetails(ifcsCurrentDate,
		// f_referenceNo, cardlist.get(0),
		// cardlist.get(1), locNoFromDB, "160", "");
		transactionListPage.enterTransactionLineItems("530", "160", "100", "160");
		transactionListPage.validatePostManualTransaction("Validation successful");
		// transactionListPage.verifyValidationResult("Transaction Total not equal Line
		// Items Total");
		IFCSHomePage.exitIFCS();
	}

	/*
	 * Added by Davu
	 * 
	 * @param clientCountry
	 * @param clientName    Business Flow ID:BF-163
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow" })
	public void validatePostManualPurchaseTransactionForLostCard(@Optional("BE") String clientCountry,
			@Optional("WFE") String clientName) {

		test = extent.createTest(
				clientName + ":" + clientCountry + " TC-1656 TC04_TxnMgmt_Manual_Txn Card Status in Lost",
				"Unable to post transactions for Damage/Lost Card");

		// creating object for the Pages
		IFCSLoginPage ifcsloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		TransactionListPage transactionListPage = new TransactionListPage(driver, test);
		Common common = new Common(driver, test);
		WFECommon wfecommon = new WFECommon(driver, test);

		// Calling Functions
		ifcsloginPage.login("IFCS_URL_WFE", "IFCS_WFE_USERNAME", "IFCS_WFE_PASSWORD");
		ifcsloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, " ");

		IFCSHomePage.gotoApplicationAndClickApplicationMenu();

		// TestData
		Faker fakerN = new Faker();
		String f_referenceNo = fakerN.number().digits(5);
		IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);

		String clientNameInProp = PropUtils.getPropValue(configProp, clientName + "_" + clientCountry);
		String currentDate = common.getCurrentIFCSDateFromDB(clientNameInProp);
		// Get the IFCS current date
		String ifcsCurrentDate = common.enterADateValueInStatusBeginDateField("Current", currentDate);
		System.out.println("Date ::" + ifcsCurrentDate);

		String cardNo = common.getCardNumberFromIFCSDB(clientName, clientCountry, "Card Lost");

		// String locationNo=common.chooseALocationWithNonFuelProduct("Y");
		// String
		// productCode=common.chooseANonFuelProductExtCodeInTheLocation(locationNo,"Y","externalCode");

		String locationNo = wfecommon.getLocationNumberForWFE(clientName, clientCountry);

		// Transaction Details0.

		IFCSHomePage.gotoTransactionAndClickManageTransaction();

		transactionListPage.enterTransactionBatchDetails(true, "160", "1", clientName);
		transactionListPage.selectBatchTypeInTransactionDetails("Manual Voucher");
		transactionListPage.enterManualTransactionDetails(ifcsCurrentDate, f_referenceNo, cardNo, " ", locationNo,
				"160", "");
		// transactionListPage.enterManualTransactionDetails(ifcsCurrentDate,
		// f_referenceNo, cardlist.get(0),
		// cardlist.get(1), locNoFromDB, "160", "");
		transactionListPage.enterTransactionLineItems("135", "160", "100", "160");
		transactionListPage.validatePostManualTransaction("Card Status Invalid");
		// transactionListPage.verifyValidationResult("Transaction Total not equal Line
		// Items Total");
		IFCSHomePage.exitIFCS();
	}

	/**
	 * Added by Davu
	 * 
	 * @param clientCountry
	 * @param clientName    Business Flow ID:BF-163
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow" })
	public void validatePostManualPurchaseTransactionForInvalidProduct(@Optional("BE") String clientCountry,
			@Optional("WFE") String clientName) {

		test = extent.createTest(clientName + ":" + clientCountry + " TC-1674 TC15_TxnMgmt_Manual_Txn Invalid Product ",
				"Transaction with invalid product");

		// creating object for the Pages
		IFCSLoginPage ifcsloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		TransactionListPage transactionListPage = new TransactionListPage(driver, test);
		Common common = new Common(driver, test);
		WFECommon wfecommon = new WFECommon(driver, test);

		// Calling Functions
		ifcsloginPage.login("IFCS_URL_WFE", "IFCS_WFE_USERNAME", "IFCS_WFE_PASSWORD");
		ifcsloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, " ");

		IFCSHomePage.gotoApplicationAndClickApplicationMenu();

		// TestData
		Faker fakerN = new Faker();
		String f_referenceNo = fakerN.number().digits(5);
		IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);

		String clientNameInProp = PropUtils.getPropValue(configProp, clientName + "_" + clientCountry);
		String currentDate = common.getCurrentIFCSDateFromDB(clientNameInProp);
		// Get the IFCS current date
		String ifcsCurrentDate = common.enterADateValueInStatusBeginDateField("Current", currentDate);
		System.out.println("Date ::" + ifcsCurrentDate);

		String cardNo = common.getCardNumberFromIFCSDB(clientName, clientCountry, "Active");

		// String locationNo=common.chooseALocationWithNonFuelProduct("Y");
		// String
		// productCode=common.chooseANonFuelProductExtCodeInTheLocation(locationNo,"Y","externalCode");

		String locationNo = wfecommon.getLocationNumberForWFE(clientName, clientCountry);

		// Transaction Details

		IFCSHomePage.gotoTransactionAndClickManageTransaction();

		transactionListPage.enterTransactionBatchDetails(true, "160", "1", clientName);
		transactionListPage.selectBatchTypeInTransactionDetails("Manual Voucher");
		transactionListPage.enterManualTransactionDetails(ifcsCurrentDate, f_referenceNo, cardNo, " ", locationNo,
				"160", "");
		// transactionListPage.enterManualTransactionDetails(ifcsCurrentDate,
		// f_referenceNo, cardlist.get(0),
		// cardlist.get(1), locNoFromDB, "160", "");
		transactionListPage.enterTransactionLineItems("000", "160", "100", "160");
		transactionListPage.validatePostManualTransaction("Invalid POS Line Item Product Code");
		// transactionListPage.verifyValidationResult("Transaction Total not equal Line
		// Items Total");
		IFCSHomePage.exitIFCS();

	}

	/**
	 * Implemented by Davu
	 * 
	 * @param clientCountry
	 * @param clientName
	 * 
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow" })
	public void createASundryReversal(@Optional("BE") String clientCountry, @Optional("WFE") String clientName) {
		test = extent.createTest(
				clientName + ":" + clientCountry
						+ "  TC-1651 TC02_TxnMgmt_SunAdj_Entrance Fee and Entrance Fee Reversal",
				"Verify adjustment is applied for any missed transaction ( Both customer and Merchant)");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		Common common = new Common(driver, test);
		WFECommon wfecommon = new WFECommon(driver, test);
		MaintainAccountPage maintainAccountPage = new MaintainAccountPage(driver, test);
		IFCSloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		IFCSHomePage.gotoAccountAndClickAccountDetails();

		String customerNo = wfecommon.getParentOrChildCustomersHavingCardsWithExpectedStatus(
				clientName + "_" + clientCountry, "parent", "Normal Service");
		if (customerNo.equals("")) {

			common.logForNoDataFound(this.getClass().getSimpleName(),
					"Need to Create A Customer with Card Type and rerun");
		} else {
			IFCSHomePage.gotoAccountAndClickAccountDetails();
			common.chooseCustomerNoAndSearch(customerNo);

			String currentIFCSDateforEffAt = common.getCurrentIFCSDateFromDB(clientName + clientCountry);
			String effDate = common.enterADateValueInStatusBeginDateField("Current", currentIFCSDateforEffAt);

			maintainAccountPage.validateSundryAdjustmentWFE(customerNo, effDate, "Account Credit", "Entrance Fee");

		}
		IFCSHomePage.exitIFCS();
	}

	/**
	 * Implemented by Davu
	 * 
	 * @param clientCountry
	 * @param clientName
	 * 
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow" })
	public void createASundryAdjustmentForEntranceFee(@Optional("BE") String clientCountry,
			@Optional("WFE") String clientName) {
		test = extent.createTest(
				clientName + ":" + clientCountry
						+ "  TC-1651 TC02_TxnMgmt_SunAdj_Entrance Fee and Entrance Fee Reversal ",
				"Verify adjustment is applied for any missed transaction ( Both customer and Merchant) ");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		Common common = new Common(driver, test);
		WFECommon wfecommon = new WFECommon(driver, test);
		MaintainAccountPage maintainAccountPage = new MaintainAccountPage(driver, test);
		IFCSloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		IFCSHomePage.gotoAccountAndClickAccountDetails();

		String customerNo = wfecommon.getParentOrChildCustomersHavingCardsWithExpectedStatus(
				clientName + "_" + clientCountry, "parent", "Normal Service");
		if (customerNo.equals("")) {

			common.logForNoDataFound(this.getClass().getSimpleName(),
					"Need to Create A Customer with Card Type and rerun");
		} else {
			common.chooseCustomerNoAndSearch(customerNo);

			String currentIFCSDateforEffAt = common.getCurrentIFCSDateFromDB(clientName + clientCountry);
			String effDate = common.enterADateValueInStatusBeginDateField("Current", currentIFCSDateforEffAt);

			maintainAccountPage.validateSundryAdjustmentWFE(customerNo, effDate, "Account Debit", "Entrance Fee");

		}
		IFCSHomePage.exitIFCS();
	}

	/**
	 * Implemented by Davu
	 * 
	 * @param clientCountry
	 * @param clientName
	 * 
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow" })
	public void createASundryForFraudWriteOffCredit(@Optional("BE") String clientCountry,
			@Optional("WFE") String clientName) {
		test = extent.createTest(
				clientName + ":" + clientCountry
						+ "  TC-1647 TC01_TxnMgmt_SunAdj_Fraud WriteOff CR and Fraud WriteOff DR",
				"Verify adjustment is applied for any missed transaction ( Both customer and Merchant)");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		Common common = new Common(driver, test);
		WFECommon wfecommon = new WFECommon(driver, test);
		MaintainAccountPage maintainAccountPage = new MaintainAccountPage(driver, test);
		IFCSloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		IFCSHomePage.gotoAccountAndClickAccountDetails();

		String customerNo = wfecommon.getParentOrChildCustomersHavingCardsWithExpectedStatus(
				clientName + "_" + clientCountry, "parent", "Normal Service");
		if (customerNo.equals("")) {

			common.logForNoDataFound(this.getClass().getSimpleName(),
					"Need to Create A Customer with Card Type and rerun");
		} else {
			IFCSHomePage.gotoAccountAndClickAccountDetails();
			common.chooseCustomerNoAndSearch(customerNo);

			String currentIFCSDateforEffAt = common.getCurrentIFCSDateFromDB(clientName + clientCountry);
			String effDate = common.enterADateValueInStatusBeginDateField("Current", currentIFCSDateforEffAt);

			maintainAccountPage.validateSundryAdjustmentWFE(customerNo, effDate, "Account Credit", "Fraud WriteOff");

		}
		IFCSHomePage.exitIFCS();
	}

	/**
	 * Implemented by Davu
	 * 
	 * @param clientCountry
	 * @param clientName
	 * 
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow" })
	public void createASundryAdjustmentForFraudWriteOffDebit(@Optional("BE") String clientCountry,
			@Optional("WFE") String clientName) {
		test = extent.createTest(
				clientName + ":" + clientCountry
						+ "  TC-1647 TC01_TxnMgmt_SunAdj_Fraud WriteOff CR and Fraud WriteOff DR ",
				"Verify adjustment is applied for any missed transaction ( Both customer and Merchant) ");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		Common common = new Common(driver, test);
		WFECommon wfecommon = new WFECommon(driver, test);
		MaintainAccountPage maintainAccountPage = new MaintainAccountPage(driver, test);
		IFCSloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		IFCSHomePage.gotoAccountAndClickAccountDetails();

		String customerNo = wfecommon.getParentOrChildCustomersHavingCardsWithExpectedStatus(
				clientName + "_" + clientCountry, "parent", "Normal Service");
		if (customerNo.equals("")) {

			common.logForNoDataFound(this.getClass().getSimpleName(),
					"Need to Create A Customer with Card Type and rerun");
		} else {
			IFCSHomePage.gotoAccountAndClickAccountDetails();
			common.chooseCustomerNoAndSearch(customerNo);

			String currentIFCSDateforEffAt = common.getCurrentIFCSDateFromDB(clientName + clientCountry);
			String effDate = common.enterADateValueInStatusBeginDateField("Current", currentIFCSDateforEffAt);

			maintainAccountPage.validateSundryAdjustmentWFE(customerNo, effDate, "Account Debit", "Fraud WriteOff");

		}
		IFCSHomePage.exitIFCS();
	}

	/**
	 * Added by Davu
	 * 
	 * @param clientCountry
	 * @param clientName    Business Flow ID:BF-163
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow" })
	public void validateMonthlyCardFeeTransaction(@Optional("BE") String clientCountry,
			@Optional("WFE") String clientName) {

		test = extent.createTest(clientName + ":" + clientCountry + " TC-1756 TC02_TxnMgmt_Monthly_card_fee",
				"Card fees posted on Monthend");

		// creating object for the Pages
		IFCSLoginPage ifcsloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);

		TransactionComponentPage transCom = new TransactionComponentPage(driver, test);
		Common common = new Common(driver, test);
		WFECommon wfecommon = new WFECommon(driver, test);

		// Calling Functions
		ifcsloginPage.login("IFCS_URL_WFE", "IFCS_WFE_USERNAME", "IFCS_WFE_PASSWORD");
		ifcsloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, " ");

		IFCSHomePage.gotoApplicationAndClickApplicationMenu();

		IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);

		String clientNameInProp = PropUtils.getPropValue(configProp, clientName + "_" + clientCountry);
		String currentDate = common.getCurrentIFCSDateFromDB(clientNameInProp);
		String ifcsCurrentDate = common.enterADateValueInStatusBeginDateField("Current", currentDate);

		String date = wfecommon.getPreviseMonthEndDate(ifcsCurrentDate);

		String cardNo = wfecommon.getCardNumberWithMonthlyCardFee(clientNameInProp);

		IFCSHomePage.gotoTransactionAndClickManageTransaction();

		transCom.validateMonthEndfeeTransaction(date, cardNo, "Card Fee");

		IFCSHomePage.exitIFCS();
	}

	/**
	 * Added by Davu
	 * 
	 * @param clientCountry
	 * @param clientName    Business Flow ID:BF-163
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow" })
	public void validateMonthlyVinciFeeTransaction(@Optional("BE") String clientCountry,
			@Optional("WFE") String clientName) {

		test = extent.createTest(clientName + ":" + clientCountry + " TC-1757 TC03_TxnMgmt_Vinci_card_fee",
				"Card fees posted on Monthend");

		// creating object for the Pages
		IFCSLoginPage ifcsloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);

		TransactionComponentPage transCom = new TransactionComponentPage(driver, test);
		Common common = new Common(driver, test);
		WFECommon wfecommon = new WFECommon(driver, test);

		// Calling Functions
		ifcsloginPage.login("IFCS_URL_WFE", "IFCS_WFE_USERNAME", "IFCS_WFE_PASSWORD");
		ifcsloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, " ");

		IFCSHomePage.gotoApplicationAndClickApplicationMenu();

		IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);

		String clientNameInProp = PropUtils.getPropValue(configProp, clientName + "_" + clientCountry);
		String currentDate = common.getCurrentIFCSDateFromDB(clientNameInProp);
		String ifcsCurrentDate = common.enterADateValueInStatusBeginDateField("Current", currentDate);

		String date = wfecommon.getPreviseMonthEndDate(ifcsCurrentDate);

		String cardNo = wfecommon.getCardNumberWithMonthlyVinciFee(clientNameInProp);

		IFCSHomePage.gotoTransactionAndClickManageTransaction();

		transCom.validateMonthEndfeeTransaction(date, cardNo, "Frais Abonnement Badge");
		
		IFCSHomePage.exitIFCS();
	}


	/**
	 * Added by Raxsana Babu
	 * 
	 * @param clientCountry
	 * @param clientName
	 * @throws TransformerException
	 */

	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow" })
	public void validateTransactionWithCorsicaMerchantAndLocation(String clientCountry, String clientName)
			throws TransformerException {

		test = extent.createTest(
				clientName + ":" + clientCountry + "TC03_TxnMgmt_Process Tokheim file against Corsica locations",
				"TC03_TxnMgmt_Process Tokheim file against Corsica locations");
		IFCSCommonPage ifcsCommonPage = new IFCSCommonPage(driver, test);
		IFCSLoginPage ifcsloginPage = new IFCSLoginPage(driver, test);
		// creating object for the Pages
		TransactionComponentPage transactionComponentPage = new TransactionComponentPage(driver, test);
		ifcsloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, " ");
		Map<String, String> valuesForValidation = new LinkedHashMap<String, String>();
		WFECommon wfeCommon = new WFECommon(driver, test);
		// Common common = new Common(driver, test);

		// Input Values for XML Creation
		Map<String, String> inputvalues = transactionComponentPage.inputValuesForCorsicaMerchantTransaction(clientName,
				clientCountry);

		valuesForValidation = wfeCommon.XMLCreationForTransactionWFE(clientName, clientCountry, inputvalues, "N", "0");
		wfeCommon.updatePropFile("CorsicaTransReference_" + clientName + "_" + clientCountry, valuesForValidation);

		// Validate Transaction Posting -need to add in new method after job execution
		//ifcsCommonPage.validateTransactionPostedOrNot(valuesForValidation);
		//transactionComponentPage.validateTaxAppliedForCorsicaMerchant(valuesForValidation);
	}
	
	/**
	 * Added by Raxsana Babu
	 * 
	 * @param clientCountry
	 * @param clientName    RQ-862
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow" })
	public void validatePostManualTansactionWithDamaged(@Optional("BE") String clientCountry,
			@Optional("WFE") String clientName) {

		test = extent.createTest(
				clientName + ":" + clientCountry + " TC-1657 TC05_TxnMgmt_Manual_Txn Card Status in Damaged",
				"RQ-862 Unable to post transactions for Damage/Lost Card");

		// creating object for the Pages
		IFCSLoginPage ifcsloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		TransactionListPage transactionListPage = new TransactionListPage(driver, test);
		// Common common = new Common(driver, test);
		// CommonInterfacePage commonInterfacePage = new CommonInterfacePage(driver,
		// test);
		TransactionComponentPage transactionComponentPage = new TransactionComponentPage(driver, test);
		Map<String, String> inputvalues = new HashMap<String, String>();

		// Calling Functions
		ifcsloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		ifcsloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		IFCSHomePage.gotoApplicationAndClickApplicationMenu();

		// TestData
		Faker fakerN = new Faker();
		String f_referenceNo = fakerN.number().digits(3);
		IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);

		inputvalues = transactionComponentPage.inputValuesForCardStatus(clientName, clientCountry, "Damaged");
		System.out.println("inputvalues::" + inputvalues);
		// Transaction Details
		IFCSHomePage.gotoTransactionAndClickManageTransaction();
		transactionListPage.enterTransactionBatchDetails(true, "100", "1", clientName);
		transactionListPage.enterManualTransactionDetails(inputvalues.get("date"), f_referenceNo,
				inputvalues.get("CardNumber"), "", inputvalues.get("LocationNumber"), "100", "");
		transactionListPage.enterTransactionLineItems(inputvalues.get("productCode"), "100", "100", "100");
		transactionListPage.validatePostManualTransaction("Validation successful"); //FR-"Card Accept Data Prep Failure";//("Card Status Invalid");
	}


}
