package com.framework.basetest;

import static com.framework.main.InitExecution.*;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.UnexpectedAlertBehaviour;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.ie.InternetExplorerDriverLogLevel;
import org.openqa.selenium.ie.InternetExplorerDriverService;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.configuration.ChartLocation;
import com.aventstack.extentreports.reporter.configuration.Theme;
import com.framework.basepage.BasePage;
import com.framework.main.InitExecution;
import com.framework.pages.OLS.common.LoginPage;
import com.framework.util.Constants;
import com.framework.util.FrameworkUtils;
import com.framework.util.PropUtils;
import com.framework.util.ReportUtils;
import com.framework.util.VideoRecording;

public class BaseTest extends FrameworkUtils {

	protected WebDriver driver;
	public ExtentHtmlReporter htmlReporter;
	public static ExtentReports extent;
	protected ExtentTest test;
	public static String logfolder = null;
	public static InternetExplorerDriverService ieService;
	public static File configFile = PropUtils.getPropFile(Constants.CONFIG_DIR, Constants.CONFIG_FILE_NAME);
	public static File embossAndIdemiaFile = PropUtils.getPropFile(Constants.CONFIG_DIR, Constants.EMBOSSIDEMIA_FILE_NAME);
	public static File apacintconfigFile = PropUtils.getPropFile(Constants.CONFIG_DIR,
			Constants.APACINT_CONFIG_FILE_NAME);
	public static File apacautoconfigFile = PropUtils.getPropFile(Constants.CONFIG_DIR,
			Constants.APACAUTO_CONFIG_FILE_NAME);
	public static File apacperfconfigFile = PropUtils.getPropFile(Constants.CONFIG_DIR,
			Constants.APACPERF_CONFIG_FILE_NAME);
	public static File apacdev4configFile = PropUtils.getPropFile(Constants.CONFIG_DIR,
			Constants.APACDEV4_CONFIG_FILE_NAME);

	public static File apacdev6configFile = PropUtils.getPropFile(Constants.CONFIG_DIR,
			Constants.APACDEV6_CONFIG_FILE_NAME);
	public static File awsemeauatconfigPropFile = PropUtils.getPropFile(Constants.CONFIG_DIR,
			Constants.AWSEMEAUAT_CONFIG_FILENAME);
	public static File apacdev2configFile = PropUtils.getPropFile(Constants.CONFIG_DIR,
			Constants.APACDEV2_CONFIG_FILE_NAME);
	public static File awsapacuatconfigPropFile = PropUtils.getPropFile(Constants.CONFIG_DIR,
			Constants.AWSAPACUAT_CONFIG_FILENAME);
	public static File CommonAPIConfigFile = PropUtils.getPropFile(Constants.CONFIG_DIR, Constants.COMMON_API_FILENAME);
	public static File customerNumberFile = PropUtils.getPropFile(Constants.CONFIG_DIR, Constants.CUSTOMER_NUMBER_FILE);
	public static File caffileconfigPropFile = PropUtils.getPropFile(Constants.CONFIG_DIR,
			Constants.CAF_CONFIG_FILENAME);
	public static File euafileconfigPropFile = PropUtils.getPropFile(Constants.CONFIG_DIR,
			Constants.EUA_CONFIG_FILENAME);
	public static File loadcardconfigPropFile = PropUtils.getPropFile(Constants.CONFIG_DIR,
			Constants.LOADCARD_CONFIG_FILENAME);
	public static File loadcardFlatconfigropFile = PropUtils.getPropFile(Constants.CONFIG_DIR,
			Constants.LOADCARD_CONFIG_FLATFILENAME);
	public static File batchJobsallClientsPropFile = PropUtils.getPropFile(Constants.CONFIG_DIR,
			Constants.BATCH_JOB_ALL_CLIENTS);
	public static File cardEmbossingPropFile = PropUtils.getPropFile(Constants.CONFIG_DIR,
			Constants.CARD_EMBOSSING_FILENAME);
	public static File emapcardEmbossingPropFile = PropUtils.getPropFile(Constants.CONFIG_DIR,
			Constants.EMAP_CARD_EMBOSSING_FILENAME);
	public static File ppsPaymentFile = PropUtils.getPropFile(Constants.CONFIG_DIR, Constants.HK_PPS_PAYMENT);
	public static File ac2FlatconfigPropFile = PropUtils.getPropFile(Constants.CONFIG_DIR, Constants.CMD_AC2_FILENAME);
	public static File accFlatconfigPropFile = PropUtils.getPropFile(Constants.CONFIG_DIR, Constants.CMD_ACC_FILENAME);
	public static File gsdFlatconfigPropFile = PropUtils.getPropFile(Constants.CONFIG_DIR, Constants.GSD_FILENAME);
	public static File pvvTextconfigPropFile = PropUtils.getPropFile(Constants.CONFIG_DIR, Constants.PVV_FILENAME);
	public static File finstaconfigPropFile = PropUtils.getPropFile(Constants.CONFIG_DIR, Constants.FINSTA_FILENAME);
	public static File vinciiconfigPropFile = PropUtils.getPropFile(Constants.CONFIG_DIR, Constants.VINCII_FILENAME);
	public static File salesForceSyncconfigPropFile = PropUtils.getPropFile(Constants.CONFIG_DIR, Constants.SALESFORCESYNC_FILENAME);
	public static File emapLoadcardFlatconfigPropFileOnlySG = PropUtils.getPropFile(Constants.CONFIG_DIR,
			Constants.EMAP_LOADCARD_CONFIG_FLATFILENAME_ONLY_SG);
	public static File emapLoadcardFlatconfigPropFileAllClients = PropUtils.getPropFile(Constants.CONFIG_DIR,
			Constants.EMAP_LOADCARD_CONFIG_FLATFILENAME_ALL_CLIENTS);
	public static File bulkCardOrderInputValuesPropFile = PropUtils.getPropFile(Constants.CONFIG_DIR,
			Constants.EXCEL_INPUT_VALUES);
	public static File callSheetExcelInputValues = PropUtils.getPropFile(Constants.CONFIG_DIR,
			Constants.CALLSHEET_EXCEL_INPUT_VALUES);
	public static File r3ReportsPropertyFile = PropUtils.getPropFile(Constants.CONFIG_DIR, Constants.R3_REPORTS);
	public static File emapdailyfrequencyPropFile = PropUtils.getPropFile(Constants.CONFIG_DIR,
			Constants.DAILY_FREQUENCY);
	public static File emapdayendreportsPropFile = PropUtils.getPropFile(Constants.CONFIG_DIR,
			Constants.DAYEND_REPORTS);
	public static File wesuatconfigPropFile = PropUtils.getPropFile(Constants.CONFIG_DIR,
			Constants.WESUAT_CONFIG_FILENAME);
	public static File updatelocationca10PropFile = PropUtils.getPropFile(Constants.CONFIG_DIR,
			Constants.CA10_FILENAME);
	public static File CUSTOMERPAYMENT_CONFIG_FILENAME = PropUtils.getPropFile(Constants.CONFIG_DIR,
			Constants.CUSTOMERPAYMENT_CONFIG_FILENAME);
	public static File customerPaymentXMLFile = PropUtils.getPropFile(Constants.CONFIG_DIR,
			Constants.CUSTPAYMENT_FILENAME);
	public static File velocityTempPropFile = PropUtils.getPropFile(Constants.CONFIG_DIR,
			Constants.VELOCITY_TEMP_FILENAME);
	public static File chevronEndToEndTemplateFile = PropUtils.getPropFile(Constants.CONFIG_DIR,
			Constants.CHEVRON_ENDTOEND_TEMP_FILE);
	public static File duplicateTemplateFile = PropUtils.getPropFile(Constants.REPORTS_DIR,
			Constants.DUPLICATE_TEMP_FILE);
	public static File bpdayendreportAUFile = PropUtils.getPropFile(Constants.CONFIG_DIR,
			Constants.BP_DAYEND_REPORTS_AU);
	public static File emapBAFFPropFiles = PropUtils.getPropFile(Constants.CONFIG_DIR, Constants.BAFF_FILES);
	public static File chevronendtoendTemplatePropFile = PropUtils.getPropFile(Constants.CONFIG_DIR,
			Constants.CHEVRON_ENDTOEND_TEMPLATE_FILE);
	public static File loadCardTransactionPurchaseFile = PropUtils.getPropFile(Constants.CONFIG_DIR,
			Constants.LORDCARDTRANSACTION_PURCHASE);
	public static File cardOrderedFile = PropUtils.getPropFile(Constants.CONFIG_DIR, Constants.CARD_ORDERED);
	public static File salesForceValidation = PropUtils.getPropFile(Constants.CONFIG_DIR, Constants.SALESFORCEVALIDATION);
	public static File cardForWhitelistFile = PropUtils.getPropFile(Constants.CONFIG_DIR, Constants.CARD_FOR_WHITELIST_FILE);
	public static File transactionTempFile = PropUtils.getPropFile(Constants.CONFIG_DIR, Constants.TRANSACTION_TEMP_FILE);
	public static File bulkReissueTempFile = PropUtils.getPropFile(Constants.CONFIG_DIR, Constants.BULK_REISSUE_TEMP_FILE);

	// public static Properties configProp = PropUtils.getProps(configFile);
	public Properties envConfigProp;
	/*
	 * public static Properties apacintconfigProp =
	 * PropUtils.getProps(apacintconfigFile); public static Properties
	 * apacdev4configProp = PropUtils.getProps(apacdev4configFile); public static
	 * Properties apacautoconfigProp = PropUtils.getProps(apacautoconfigFile);
	 * public static Properties apacperfconfigProp =
	 * PropUtils.getProps(apacperfconfigFile); public static Properties
	 * apacdev6configProp = PropUtils.getProps(apacdev6configFile); public static
	 * Properties awsemeauatconfigProp =
	 * PropUtils.getProps(awsemeauatconfigPropFile); public static Properties
	 * apacdev2configProp = PropUtils.getProps(apacdev2configFile); public static
	 * Properties awsapacuatconfigProp =
	 * PropUtils.getProps(awsapacuatconfigPropFile);
	 */
	public static Properties cafconfigProp = PropUtils.getProps(caffileconfigPropFile);
	public static Properties euaconfigProp = PropUtils.getProps(euafileconfigPropFile);
	public static Properties loadconfigProp = PropUtils.getProps(loadcardconfigPropFile);
	public static Properties loadcardflatconfigProp = PropUtils.getProps(loadcardFlatconfigropFile);
	public static Properties batchJobsallClientsProp = PropUtils.getProps(batchJobsallClientsPropFile);
	public static Properties cardembossconfigProp = PropUtils.getProps(cardEmbossingPropFile);
	public static Properties emapcardembossCongifProp = PropUtils.getProps(emapcardEmbossingPropFile);
	public static Properties ppsPaymentConfigProp = PropUtils.getProps(ppsPaymentFile);
	public static Properties ac2configProp = PropUtils.getProps(ac2FlatconfigPropFile);
	public static Properties accconfigProp = PropUtils.getProps(accFlatconfigPropFile);
	public static Properties gsdconfigProp = PropUtils.getProps(gsdFlatconfigPropFile);
	public static Properties pvvconfigProp = PropUtils.getProps(pvvTextconfigPropFile);
	public static Properties finstaconfigProp = PropUtils.getProps(finstaconfigPropFile);
	public static Properties vinciiconfigProp = PropUtils.getProps(vinciiconfigPropFile);
	public static Properties salesForceSyncConfigProp = PropUtils.getProps(salesForceSyncconfigPropFile);

	public static Properties emapLoadcardflatconfigPropOnlySG = PropUtils
			.getProps(emapLoadcardFlatconfigPropFileOnlySG);
	public static Properties emapLoadcardflatconfigPropAllClients = PropUtils
			.getProps(emapLoadcardFlatconfigPropFileAllClients);
	public static Properties wesuatconfigProp = PropUtils.getProps(wesuatconfigPropFile);
	public static Properties updatelocationca10Prop = PropUtils.getProps(updatelocationca10PropFile);
	public static Properties customerPaymentXML = PropUtils.getProps(customerPaymentXMLFile);
	public static Properties callSheetExcelInput = PropUtils.getProps(callSheetExcelInputValues);
	public static Properties bulkCardOrderInputValuesConfigProp = PropUtils.getProps(bulkCardOrderInputValuesPropFile);
	public static Properties r3ReportsPropertyFileConfigProp = PropUtils.getProps(r3ReportsPropertyFile);
	public static Properties emapdailyfrequencyConfigFile = PropUtils.getProps(emapdailyfrequencyPropFile);
	public static Properties emapdayendreportsConfigFile = PropUtils.getProps(emapdayendreportsPropFile);
	public static Properties CUSTOMERPAYMENT_CONFIG_FILENAME_configfile = PropUtils
			.getProps(CUSTOMERPAYMENT_CONFIG_FILENAME);
	public static Properties chevronEndToEndTemplateConfigFile = PropUtils.getProps(chevronendtoendTemplatePropFile);
	public static Properties emapBAFFConfigProp = PropUtils.getProps(emapBAFFPropFiles);
	public static Properties bpdayendreportsAU = PropUtils.getProps(bpdayendreportAUFile);
	public static Properties velocityTempProp = PropUtils.getProps(velocityTempPropFile);
	public static Properties chevronEndToEndTemplateProp = PropUtils.getProps(chevronEndToEndTemplateFile);
	public static Properties loadCardTransactionPurchaseProp = PropUtils.getProps(loadCardTransactionPurchaseFile);
	public static Properties cardOrderedProp = PropUtils.getProps(cardOrderedFile);
	public static Properties cardForWhitelistFileProp = PropUtils.getProps(cardForWhitelistFile);
	public static Properties transactionTempFileProp = PropUtils.getProps(transactionTempFile);
	public static Properties bulkReissueTempFileProp = PropUtils.getProps(bulkReissueTempFile);


	public static File commonPropFile = PropUtils.getPropFile(Constants.CONFIG_DIR, environment + ".properties");
	public static Properties commonProp = PropUtils.getProps(commonPropFile);
	public static Properties configProp = PropUtils.getProps(configFile);
	public static Properties embossAndIdemiaFileP = PropUtils.getProps(embossAndIdemiaFile);

	public static String videoFile;
	public static String resultFile;
	public static String indexFile;
	public static String reportsFolder;
	public static String instancereportsFolder;
	public static String ssFolder;
	VideoRecording video = new VideoRecording();
	BasePage basePage;

	@BeforeSuite(alwaysRun = true)
	public void initializeReport() throws Exception {

		if (browser != null && environment != null) {
			System.out.println("POM Browser is: " + browser);
			System.out.println("POM Environment is: " + environment);

			PropUtils.setProps(configProp, "browser", browser);
			PropUtils.setProps(configProp, "environment", environment);
		}
		System.out.println("----- Environment Value ------" + environment);

		// *** Update here when a new environment is added
		/*
		 * if (PropUtils.getPropValue(configProp, "environment").equals("apacint")) {
		 * envConfigProp = apacintconfigProp; } else if
		 * (PropUtils.getPropValue(configProp, "environment").equals("apacauto")) {
		 * envConfigProp = apacautoconfigProp; } else if
		 * (PropUtils.getPropValue(configProp, "environment").equals("apacperf")) {
		 * envConfigProp = apacperfconfigProp; } else if
		 * (PropUtils.getPropValue(configProp, "environment").equals("apacdev4")) {
		 * envConfigProp = apacdev4configProp; } else if
		 * (PropUtils.getPropValue(configProp, "environment").equals("apacdev6")) {
		 * envConfigProp = apacdev6configProp; } else if
		 * (PropUtils.getPropValue(configProp, "environment").equals("awsemeauat")) {
		 * envConfigProp = awsemeauatconfigProp; } else if
		 * (PropUtils.getPropValue(configProp, "environment").equals("apacdev2")) {
		 * envConfigProp = apacdev2configProp; } else if
		 * (PropUtils.getPropValue(configProp, "environment").equals("awsapacuat")) {
		 * envConfigProp = awsapacuatconfigProp; } else if
		 * (PropUtils.getPropValue(configProp, "environment").equals("wesuat")) {
		 * envConfigProp = wesuatconfigProp; }
		 */
		// configProp.putAll(envConfigProp);
		configProp.putAll(commonProp);

		if (getOSDetails().equals("LINUX")) {

			loadLibraries();
			executeFromTerminal();
		}

		ReportUtils.createResultsFolder(Constants.REPORTS_DIR);
		Date currentdate = new Date();
		reportsFolder = Constants.REPORTS_DIR + new SimpleDateFormat("MMMMM_dd_yyyy").format(currentdate);
		ReportUtils.createResultsFolder(reportsFolder);

		instancereportsFolder = reportsFolder + Constants.FILE_SEPARATOR 
				+ new SimpleDateFormat("MMMMM_dd_yyyy_hh-mm").format(currentdate)+"-"+InitExecution.sheetName+"-"+InitExecution.browser;
		ReportUtils.createResultsFolder(instancereportsFolder);

		ssFolder = instancereportsFolder + Constants.FILE_SEPARATOR
				+ new SimpleDateFormat("MMM-dd-yyyy_hh-mm").format(currentdate) + "_screenshots";
		ReportUtils.createResultsFolder(ssFolder);

		resultFile = instancereportsFolder + Constants.FILE_SEPARATOR
				+ PropUtils.getPropValue(configProp, "projectName") + "_"
				+ new SimpleDateFormat("MMM-dd-yyyy_hh-mm").format(currentdate) + "_" + "AutomationResults.html";

		videoFile = PropUtils.getPropValue(configProp, "projectName") + "_"
				+ new SimpleDateFormat("MMM-dd-yyyy_hh-mm").format(currentdate) + "_" + "Video";

		indexFile = Constants.REPORTS_DIR + Constants.FILE_SEPARATOR + "index.html";

		// Configuring Extent Reports
		if (extent == null) {
			htmlReporter = new ExtentHtmlReporter(resultFile);
			extent = new ExtentReports();
			extent.attachReporter(htmlReporter);
			extent.setSystemInfo("Project Name", PropUtils.getPropValue(configProp, "projectName").toUpperCase());
			extent.setSystemInfo("Tester Name", PropUtils.getPropValue(configProp, "testername").toUpperCase());
			extent.setSystemInfo("Automation Tool", "SELENIUM");
			extent.setSystemInfo("Operating System", getOSDetails());
			extent.setSystemInfo("Host Name", getHostDetails());
			extent.setSystemInfo("Environment", PropUtils.getPropValue(configProp, "environment").toUpperCase());
			htmlReporter.config().setChartVisibilityOnOpen(true);
			htmlReporter.config()
					.setDocumentTitle(PropUtils.getPropValue(configProp, "projectName") + " Automation Testing Report");

			try {
				if (PropUtils.getPropValue(configProp, "testtype").equalsIgnoreCase("smoke")) {
					htmlReporter.config().setReportName("Smoke Testing");
				} else if (PropUtils.getPropValue(configProp, "testtype").equalsIgnoreCase("regression")) {
					htmlReporter.config().setReportName("Regression Testing");
				}
			} catch (NullPointerException e) {
				htmlReporter.config().setReportName("Automation Testing");
			}

			try {
				if (PropUtils.getPropValue(configProp, "ReportChartLocation").equalsIgnoreCase("TOP")) {
					htmlReporter.config().setTestViewChartLocation(ChartLocation.TOP);
				} else if (PropUtils.getPropValue(configProp, "ReportChartLocation").equalsIgnoreCase("BOTTOM")) {
					htmlReporter.config().setTestViewChartLocation(ChartLocation.BOTTOM);
				}
			} catch (NullPointerException e) {

				htmlReporter.config().setTestViewChartLocation(ChartLocation.TOP);
			}

			try {
				if (PropUtils.getPropValue(configProp, "ReportTheme").equalsIgnoreCase("DARK")) {
					htmlReporter.config().setTheme(Theme.DARK);
				} else if (PropUtils.getPropValue(configProp, "ReportTheme").equalsIgnoreCase("STANDARD")) {
					htmlReporter.config().setTheme(Theme.STANDARD);
				}
			} catch (NullPointerException e) {
				htmlReporter.config().setTheme(Theme.STANDARD);
			}
		}
	}

	@BeforeMethod(alwaysRun = true)
	public void initializeDriver() throws Exception {
		
		driver=BrowserFactory.getDriver();
		

		
		// Video Record Start
		if (PropUtils.getPropValue(configProp, "VideoRecording").equals("True")) {
			try {
				video.startRecording();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	  	driver.manage().deleteAllCookies();
		((JavascriptExecutor) driver).executeScript("return document.readyState").toString().equals("complete");
		// driver.get(PropUtils.getPropValue(configProp, "appURL"));
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
		//extent.setSystemInfo("Browser", getBrowserDetails());
		
	/*	if (driver == null) {

			// Setting the path for Drivers
			if (getOSDetails().equals("LINUX")) {

				System.setProperty("webdriver.ie.driver", Constants.DRIVER_DIR + "IEDriver/IEDriverServer");
				System.setProperty("webdriver.gecko.driver", Constants.DRIVER_DIR + "GeckoDriver/geckodriver");
				System.setProperty("webdriver.chrome.driver", Constants.DRIVER_DIR + "ChromeDriver/Linux/chromedriver");
			} else if (getOSDetails().contains("WINDOWS")) {

				System.setProperty("webdriver.ie.driver", Constants.DRIVER_DIR + "IEDriver/IEDriverServer.exe");
				System.setProperty("webdriver.gecko.driver", Constants.DRIVER_DIR + "GeckoDriver/geckodriver.exe");
				System.setProperty("webdriver.chrome.driver",
						Constants.DRIVER_DIR + "ChromeDriver/Windows/chromedriver.exe");
			}

			else {
				// Other operating system logic should come here
			}

			if (PropUtils.getPropValue(configProp, "browser").equals("chrome")) {
				ChromeOptions options = new ChromeOptions();
				options.addArguments("chrome.switches", "--disable-extensions");
				options.addArguments("chrome.switches", "test-type");
				options.addArguments("chrome.switches", "start-maximized");
				options.addArguments("chrome.switches", "no-sandbox");
				//options.addArguments("chrome.switches","--headless");
				options.setExperimentalOption("useAutomationExtension", false);
				options.addArguments("chrome.switches", "--incognito"); // For Starting a
				// chrome browser incognito mode.
				//driver = new ChromeDriver(options);
				DesiredCapabilities capabilities = DesiredCapabilities.chrome();
				capabilities.setCapability(ChromeOptions.CAPABILITY, options);

				 capabilities.setCapability(CapabilityType.ForSeleniumServer.
				 ENSURING_CLEAN_SESSION, true);
				

				//driver = new RemoteWebDriver(new URL("http://10.78.61.93:4444/wd/hub"),capabilities );

				
				 DesiredCapabilities capabilities = DesiredCapabilities.chrome();
				  
				  capabilities.setCapability(CapabilityType.ForSeleniumServer.
				  ENSURING_CLEAN_SESSION, true); capabilities.setCapability("chrome.switches",
				 Arrays.asList("--incognito"));
				 
					capabilities.setCapability(ChromeOptions.CAPABILITY, options);

				 driver = new ChromeDriver(capabilities);
				 

			} else if (PropUtils.getPropValue(configProp, "browser").equals("firefox")) {
				FirefoxProfile fp = new FirefoxProfile();
				fp.setAcceptUntrustedCertificates(true);
				fp.setPreference("browser.tabs.remote.autostart", false);
				fp.setPreference("browser.tabs.remote.autostart.1", false);
				fp.setPreference("browser.tabs.remote.autostart.2", false);
				fp.setPreference("browser.tabs.remote.force-enable", "false");
				
				 * fp.setPreference("browser.download.manager.showWhenStarting",false);
				 * fp.setPreference("browser.download.dir",downloadPath);
				 * fp.setPreference("browser.helperApps.neverAsk.saveToDisk",
				 * "text/csv,application/x-msexcel,application/excel,application/x-excel,application/vnd.ms-excel,image/png,image/jpeg,text/html,text/plain,application/msword,application/xml"
				 * );
				 
				DesiredCapabilities firefoxCapabilities = DesiredCapabilities.firefox();
				firefoxCapabilities.setCapability(CapabilityType.ACCEPT_INSECURE_CERTS, true);
				firefoxCapabilities.setCapability(FirefoxDriver.PROFILE, fp);
				firefoxCapabilities.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
				firefoxCapabilities.setCapability(CapabilityType.ELEMENT_SCROLL_BEHAVIOR, 1);
				firefoxCapabilities.setCapability("marionette", true);
				driver = new FirefoxDriver(firefoxCapabilities);
				driver.manage().window().maximize();

			} else if (PropUtils.getPropValue(configProp, "browser").equals("IE")) {
				logfolder = Constants.LOG_DIR + "IEDriver_Logs_"
						+ new SimpleDateFormat("MMMMM_dd_yyyy").format(new Date());
				File logsfolder = new File(logfolder);
				if (!logsfolder.exists()) {
					logsfolder.mkdir();
				}
				File logsFile = new File(logfolder + Constants.FILE_SEPARATOR + "IEDriverServer_"
						+ new SimpleDateFormat("dd_HH_mm").format(new Date()) + "_Logs.log");
				if (logsFile.exists()) {
					logsFile.delete();
				}
				ieService = new InternetExplorerDriverService.Builder().usingAnyFreePort().withLogFile(logsFile)
						.withLogLevel(InternetExplorerDriverLogLevel.TRACE).build();
				try {
					ieService.start();
				} catch (IOException e) {
					e.printStackTrace();
				}
				DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
				capabilities.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
				capabilities.setCapability(CapabilityType.HAS_NATIVE_EVENTS, false);
				capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS,
						true);
				capabilities.setCapability(CapabilityType.UNEXPECTED_ALERT_BEHAVIOUR, UnexpectedAlertBehaviour.DISMISS);
				capabilities.setCapability("ignoreZoomSetting", true);
				capabilities.setCapability("requireWindowFocus", true);
				capabilities.setCapability("ignoreProtectedModeSettings", true);
				capabilities.setCapability("disable-popup-blocking", true);
				capabilities.setCapability("enablePersistentHover", true);
				capabilities.setCapability("requireWindowFocus", true);
				capabilities.setJavascriptEnabled(true);
				driver = new InternetExplorerDriver(ieService, capabilities);
				driver.manage().window().maximize();

			}
			// Video Record Start
			if (PropUtils.getPropValue(configProp, "VideoRecording").equals("True")) {
				try {
					video.startRecording();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			driver.manage().deleteAllCookies();

			// driver.get(PropUtils.getPropValue(configProp, "appURL"));
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
			extent.setSystemInfo("Browser", getBrowserDetails());

		}*/
	}


	@AfterMethod(alwaysRun = true)
	public void getResult(ITestResult result) {

		try {
			if (result.getStatus() == ITestResult.FAILURE) {
				/* if(driver.get) */
				LoginPage loginPage = new LoginPage(driver, test);
				String screenShotPath = capture(driver);
				test.fail(MarkupHelper.createLabel(result.getName() + " Test case FAILED due to below issues:",
						ExtentColor.RED));
				test.fail(result.getThrowable());
				if (PropUtils.getPropValue(configProp, "TakeScreenshot").equalsIgnoreCase("True")) {
					test.fail("Screenshot below: " + test.addScreenCaptureFromPath(screenShotPath));
				}
				System.out.println("Class:" + this.getClass().getName());
				if (!this.getClass().getName().contains("API")) {
					loginPage.LogoutIfFailure();
				
				} else {
					if (driver.getCurrentUrl().contains("ajaxswing")) {
						loginPage.LogoutIfFailure();
						
					}
				}

			} else if (result.getStatus() == ITestResult.SUCCESS) {

				test.pass(MarkupHelper.createLabel(result.getName() + " Test Case PASSED", ExtentColor.GREEN));
			} else {
				test.skip(MarkupHelper.createLabel(result.getName() + " Test Case SKIPPED", ExtentColor.ORANGE));
				test.skip(result.getThrowable());
			}
		} catch (Exception ex) {
			test.fail(ex.getMessage());
		}
		
		driver.quit();//// copied from afterTest
	}

	@AfterTest(alwaysRun = true)
	public void tearDowndriver(ITestContext context) {
		
	//if (!this.getClass().getName().contains("API")&&!InitExecution.getArgs().toLowerCase().contains("fullsuite")&&!InitExecution.getArgs().contains("BusinessFlow")) {
			// Close the Browser
	        //driver.quit();
			// Stop the Video Recording
			if (PropUtils.getPropValue(configProp, "VideoRecording").equals("True")) {
				try {
					video.stopRecording();
				} catch (Exception e) {
					System.out.println("Video Recording Not Saved"+ e.getStackTrace());
					
				}
			}
		//}
	
		

	}
	
	@AfterSuite(alwaysRun = true)
	public void tearDownReports() {

		try {

			//if (this.getClass().getName().contains("API")||InitExecution.getArgs().toLowerCase().contains("fullsuite")||InitExecution.getArgs().contains("BusinessFlow")) {
			//	driver.quit();
				// Stop the Video Recording
				if (PropUtils.getPropValue(configProp, "VideoRecording").equals("True")) {
					try {
						video.stopRecording();
					} catch (Exception e) {
						System.out.println("Video Recording Not Saved"+ e.getStackTrace());
						
					}
				//}
			}
			// Delete the Excel File
			// BasePage.deleteExcelFile();
			// Flush the Reports
				extent.setSystemInfo("Browser", BrowserFactory.browserNameAndVersion);//copied from after driver init...as its printing multi times in report
				if(InitExecution.parallel_Mode.equalsIgnoreCase("yes"))
					extent.setSystemInfo("Run Mode", "Parallel");
				else 
					extent.setSystemInfo("Run Mode", "Sequence");
				if (PropUtils.getPropValue(configProp, "Headless").equals("True"))
					extent.setSystemInfo("Headless", "Yes");
				else 
					extent.setSystemInfo("Headless", "No");
				
		    extent.flush();
			ReportUtils.createIndexFile();
		
			driver=null;
			extent =null;

			if (getOSDetails().contains("WINDOWS")) {
				Runtime.getRuntime().exec("taskkill /im chromedriver.exe /f");
			} else {
				//// Other operating system logic should come here
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	/**
	 * Use this method if you want to take screenshot before the last step, why
	 * because last step is logout. So want to take correct screen shot we can use
	 * 
	 * Added By anton executeFromTerminal(); 16.08.2018
	 */

	public void takeScreenshot() {
		try {
			String screenShotPath = capture(driver);
			// test.pass(MarkupHelper.createLabel(" Test Case PASSED", ExtentColor.GREEN));
			if (PropUtils.getPropValue(configProp, "TakeScreenshot").equalsIgnoreCase("True")) {
				test.addScreenCaptureFromPath(screenShotPath);
				// //test.pass("Screenshot below: " +
				// test.addScreenCaptureFromPath(screenShotPath));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	

}
