﻿using BoDi;
using Common;
using EnCompass.Testing.Source.PageObjects.SuperAdmin.Testing;
using EnCompass.Testing.Source.StepDefinitions.API;
using System;
using System.Collections.Generic;
using System.Linq;
using TechTalk.SpecFlow;

namespace EnCompass.Testing.Source
{
    [Binding]
    public class Hooks : Common.BaseHooks
    {
		public Hooks(ScenarioContext scenarioContext, FeatureContext featureContext, IObjectContainer container, 
                               GlobalSettings settings) : base(scenarioContext, featureContext, container, settings) { }

        //[AfterScenario("UX", Order = 0)]
        public void DeleteOrganizationQueue(ScenarioContext scenario)
        {
            // Ignore this part if its being run for Auto Code Gen and if there Org deletion is turned Off and if Secnario Execution Status is anything apart from OK(i.e. scenario has no failures)
            if ((!scenario.ScenarioInfo.Tags.Contains("CodeGen")) && scenario.ScenarioExecutionStatus.Equals(ScenarioExecutionStatus.OK))
            {
                try
                {
                    // Check if Orgs are to be deleted
                    if (GlobalSettings.AreOrgsToBeDeleted)
                    {
                        // Check if the Env is anything other than PROD
                        if ((!String.IsNullOrWhiteSpace(_settings.CeatedOrgId)) && (!GlobalSettings.Environment.Equals("PROD", StringComparison.InvariantCultureIgnoreCase)))
                        {
                            var deleteOrganizationQueue = new DeleteOrganizationQueue(_settings);
                            deleteOrganizationQueue.Navigate();

                            deleteOrganizationQueue.SetCategoryByName("Organization Name");
                            deleteOrganizationQueue.SearchTerm = _settings.CreatedOrgName;
                            deleteOrganizationQueue.AddBtn();
                            deleteOrganizationQueue.SearchBtn();

                            deleteOrganizationQueue.DeleteOrgQueueGrid.SelectFirstRow();
                            deleteOrganizationQueue.DeleteOrgQueueGrid.PerformActionByText("Queue On");
                            deleteOrganizationQueue.SetQueueDeletionDateByDays(0);
                            deleteOrganizationQueue.QueueOnSubmitModalBtn();

                            //Check.That(deleteOrganizationQueue.HasSuccessMessage).IsTrue();

                            _settings.EnCompassExtentTest.Pass($@"Org {_settings.CreatedOrgName} successfully queued for deletion on {System.DateTime.Now.ToString("MM/dd/yyyy")}");
                        }
                    }
                    else
                    {
                        _settings.EnCompassExtentTest.Info("Org Deletions are turned Off");
                    }
                }
                catch (Exception e)
                {
                    _settings.EnCompassExtentTest.Error("Could not queue all the Organization(s) as Cleanup");
                    _settings.EnCompassExtentTest.Info("Exception :" + e.Message + Environment.NewLine + e.StackTrace);
                }
            }
        }

        /// <summary>
        /// After Every API test, if there are Mlogs created then they need to be closed.
        /// </summary>
        [AfterScenario("API", Order = 0)]
        public void AfterApiScenarioMlogClosure()
        {
            _settings.EnCompassExtentTest.Debug("Inside AfterApiScenarioMlogClosure ");
            List<string> _idsToChangeStatus = new List<string>();

            try
            {
                // Check if there are Mlogs created by API tests that needs to be closed
                _settings.Api_MlogIds_ToBeClosed.ToList().ForEach(kvp =>
                {
                    string mlogId = kvp.Key;
                    _settings.EnCompassExtentTest.Info("Trying to close the Mlog id: " + mlogId);

                    if (!kvp.Value)
                    {
                         // Call the Steps to Cancel Mlog
                        Table datatable = new Table(new string[] { "Field", "Value" });
                        datatable.AddRow(new string[] { "MerchantLogUniqueId", mlogId });
                        new SoapApiSteps(_settings).GivenIModifyTheFileWithPresetDataAndSet(@"APService\CancelMerchantLog_Request.xml", "APService", datatable);
                        SourceString _fileAbsPath = new GlobalTransforms(_settings).LookupInExternalDatasource("[%SCXT:FileAbsPath%]");
                        new SoapApiSteps(_settings).ThenIInvokeTheSOAPWebServiceWithMethodBody("apservice.asmx", "POST", _fileAbsPath);
                        new SoapApiSteps(_settings).ThenIVerifyTheResponseWithResponseCodeAndMessage("Success", "Merchant log successfully cancelled.");
                        _settings.EnCompassExtentTest.Info("Closed the Mlog :" + mlogId);

                        // Retrieve the Mlog to verify status = closed
                         new SoapApiSteps(_settings).GivenIModifyTheFileWithPresetDataAndSet(@"APService\RetrieveMerchantLog_Request.xml", "APService", datatable);
                        _fileAbsPath = new GlobalTransforms(_settings).LookupInExternalDatasource("[%SCXT:FileAbsPath%]");
                        new SoapApiSteps(_settings).ThenIInvokeTheSOAPWebServiceWithMethodBody("apservice.asmx", "POST", _fileAbsPath);
                        new SoapApiSteps(_settings).ThenIVerifyTheResponseWithResponseCodeAndMessage("Success", "Merchant log successfully retrieved.");
                        new SoapApiSteps(_settings).ThenIVerifyThatTheIsPresentInTheResponseWithMatcher(new List<string>() { "Status", "Closed" }, "Exact");
                        _settings.EnCompassExtentTest.Info("Retrieved and verified that the Mlog :" + mlogId + " is closed.");

                        _idsToChangeStatus.Add(kvp.Key);
                    }
                    else
                        _settings.EnCompassExtentTest.Info("The Mlog id is already closed, hence skipping it.");
                });

                // Set the bool to true for each Mlogid, indicating that the Mlog has been closed 
                // already.  This would be needed in case if we have multiple scenarios which are operating
                // on the same Mlog then closing it multiple times doesn't make sense.
                _idsToChangeStatus.ForEach(id => _settings.Api_MlogIds_ToBeClosed[id] = true);
            }catch(Exception ex)
            {
                _settings.EnCompassExtentTest.Error("Exception Caught while closing Mlogs in Hooks.cs file");
                _settings.EnCompassExtentTest.Debug(ex.Message);
                throw ex;
            }
        }
    }
}
