package com.framework.testcases.AJS.EMAP;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.MaintainAccountPage;
import com.framework.pages.AJS.common.Common;
import com.framework.pages.AJS.common.IFCSHomePage;
import com.framework.pages.AJS.common.IFCSLoginPage;

public class ValidateAccountTestCases  extends BaseTest {
	
	@Parameters({ "clientCountry", "clientName" }) 
	@Test(groups = { "Regression" })
	public void verifyAccountDetailsForCustomer(@Optional("SG") String clientCountry,
			@Optional("EMAP") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  EMAP IFCS the account details for the customer can be edited and saved",
				"TST-SC-07-Verfiy that the account details for the customer can be edited and saved");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		MaintainAccountPage maintainAccountPage = new MaintainAccountPage(driver, test);
		Common common= new Common(driver, test);
		IFCSloginPage.login("IFCS_URL_EMAP", "IFCS_EMAP_USERNAME", "IFCS_EMAP_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, " ");
		IFCSHomePage.gotoApplicationAndClickApplicationMenu();
		IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);
		common.chooseApplicationNumberFromApplicationList("TL APP approved");

		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		common.chooseCustomerNumberFromCustomerList();
		IFCSHomePage.gotoAccountAndClickAccountDetails();
		maintainAccountPage.editAndSaveCustomerAccountDetailsAndValidate();
		//maintainAccountPage.editAndSaveCustomerAccountDetailsAndValidate();
		IFCSHomePage.exitIFCS();
	}

}
