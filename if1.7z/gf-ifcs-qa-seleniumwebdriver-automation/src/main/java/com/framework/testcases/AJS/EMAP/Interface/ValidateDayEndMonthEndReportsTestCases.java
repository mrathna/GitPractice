package com.framework.testcases.AJS.EMAP.Interface;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.common.Common;
import com.framework.pages.AJS.common.CommonInterfacePage;
import com.framework.pages.AJS.common.IFCSCommonPage;
import com.framework.pages.AJS.common.IFCSLoginPage;

public class ValidateDayEndMonthEndReportsTestCases extends BaseTest{
	
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "Smoke" })
	public void ValidateDailyFrequencyReports(@Optional("SG") String clientCountry,
			@Optional("EMAP") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  TST-SC-15-Client level report assignments with daily frequency","Daily frequency Report Validations");
		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSCommonPage ifcsCommonPage = new IFCSCommonPage(driver, test);
		CommonInterfacePage commonInterfacePage = new CommonInterfacePage(driver, test);
		Common common = new Common(driver,test);
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry," ");
		
		 String dayEndDatePath="";
		 List<String>  fileNames;
		 String localFolder="";
		 List<String> listFilesPath=new ArrayList<String>();
		 
		 //Data Creation
		 String auditActionAccount = common.getAuditActionForAccount("", "uatxom");
		 ArrayList<String> accountValues = new ArrayList<String>();
		 accountValues.add("");
		 accountValues.add("uatxom");
		 accountValues.add(auditActionAccount);
			String[] accountHeaders = { "Account Number", "Username", "Action" };
			String auditActionappl=common.getAuditActionForApplication("1000444649","uatxom");
			ArrayList<String> appColumnValues = new ArrayList<String>();
			appColumnValues.add("1000444649");
			appColumnValues.add("uatxom");
			appColumnValues.add(auditActionappl);
			String[] appColumnHeaders = { "Application Number", "Username", "Action" };
			String auditActionCard = common.getAuditActionForCard("7800344182093000112", "uatxom");
			ArrayList<String> cardColumnValues = new ArrayList<String>();
			cardColumnValues.add("7800344182093000112");
			cardColumnValues.add("uatxom");
			cardColumnValues.add(auditActionCard);
			String[] cardColumnHeaders = { "Card Number", "Username", "Action" };
			String refNumber="183";
			String transactionValue=common.getClientTransactionValue(refNumber);
			System.out.println("Transaction Value::"+transactionValue);
			Map<String, String> customerNo = common.getCustomerTransactions(refNumber);
		    String cusNo= customerNo.get("CUSTOMER_NO").toString();
		    ArrayList<String> transactionValues = new ArrayList<String>();
		    transactionValues.add(cusNo);
		    transactionValues.add(refNumber);
		    transactionValues.add(transactionValue);
		    String[] transColumnHeaders = { "Customer Number", "Transaction Receipt Number", "Value" };
		    String auditActionCus = common.getAuditActionForCustomer("0700000", "uatxom");
			String file;
			ArrayList<String> CusColumnValues = new ArrayList<String>();
			CusColumnValues.add("0700000");
			CusColumnValues.add("uatxom");
			CusColumnValues.add(auditActionCus);
			String[] cusColumnHeaders = { "Customer Number", "Username", "Action" };
			String accountNo=common.getApprovedCustomerNumberFromDB("Accept");
			String declinedAccountno=common.getDeclinedApplicationNo();
			String cusNum="6300053514";
			 String debitAmt= common.getDirectDebitAmountForCustomer(cusNum);
			 System.out.println("Debit Amount::" +debitAmt);
			 ArrayList<String> columnValues = new ArrayList<String>();
		  		columnValues.add(cusNum);
		  		columnValues.add(debitAmt);
		  		String[] columnHeaders = { "Customer A/c No.","Payment Amount"};
		  		String refNo="104";
		  	Map<String,String> transactionsDetails = common.getCustomerTransactions(refNo);
		  	String creditScore=common.validateCreditAmountForAdjustmentType("Late Payment Fee Adj",refNo);
		  	String suspendedRefNo="046540";
			 
			Map<String, String> suspendedDetails = common.getSuspendedTransactionDetails(suspendedRefNo);
			 String suspendedCardNo= suspendedDetails.get("CARD_NO").toString();
			 String suspendedBatchNo= suspendedDetails.get("BATCH_NO").toString();
			 Map<String, String> transactionDetail= common.getCustomerTransactions(refNo);
		        String cardNumber= transactionDetail.get("CARD_NO").toString();
		         
	  		ArrayList<String> columnValue = new ArrayList<String>();
	  		columnValue.add(cardNumber);
	  		columnValue.add(refNo);
	  		String[] columnHeader = { "Card Number","Ticket Number"};
	  		
	  		String auditActionMer = common.getAuditActionForMerchant("13246579","uatxom");
	  		
			ArrayList<String> merColumnValues = new ArrayList<String>();
			merColumnValues.add("13246579");
			merColumnValues.add("uatxom");
			merColumnValues.add(auditActionMer);
			String[] merchantColumnHeaders = { "Merchant ID", "Username", "Action" };
			
		 //Client Reports File Moving 
			String dateIFCS = common.getCurrentIFCSDateFromDB(clientName + clientCountry);
			String dbProcessingDate = commonInterfacePage.getreportDateFormat(dateIFCS);
			System.out.println("dbProcessingDate::"+dbProcessingDate);
		 fileNames=commonInterfacePage.createClientReportFileFormatByDateAppend(clientCountry,emapdailyfrequencyConfigFile,dbProcessingDate);
		  for(int i=0;i<=fileNames.size();i++) {
				 String fileName= fileNames.get(i);
		  if(clientCountry.equals("SG")) {
		  dayEndDatePath=commonInterfacePage.getFolderPathUsingPreviousProcessingDate(clientName, clientCountry,"IFCS_DAYEND_OUTPUTFILE_SG_CLIENT");
		  }else if(clientCountry.equals("SP")) {
				 dayEndDatePath=commonInterfacePage.getFolderPathUsingPreviousProcessingDate(clientName, clientCountry,"IFCS_DAYEND_OUTPUTFILE_SP_CLIENT");
		  }else if(clientCountry.equals("GU")) {
				 dayEndDatePath=commonInterfacePage.getFolderPathUsingPreviousProcessingDate(clientName, clientCountry,"IFCS_DAYEND_OUTPUTFILE_GU_CLIENT");
		  }else if(clientCountry.equals("HK")) {
				 dayEndDatePath=commonInterfacePage.getFolderPathUsingPreviousProcessingDate(clientName, clientCountry,"IFCS_DAYEND_OUTPUTFILE_HK_CLIENT");
		  }
		  System.out.println("dayEndDatePath::" +dayEndDatePath);
		  ifcsCommonPage.establishThePuttyConnection("incomingFile", "PUTTY_HOST", "PUTTY_USERNAME", "PUTTY_PASSWORD",
					dayEndDatePath, fileName);
		  localFolder = System.getProperty("user.home") + "\\Documents\\" +fileName;
		  listFilesPath.add(localFolder);
		  }
		  //File Validations
		  for(int i=0;i<listFilesPath.size();i++) {
			if(listFilesPath.get(i).contains("Account Status and Sub-status change Report")) {
					System.out.println("Need to implement in future"+listFilesPath.get(i));
			}else if(listFilesPath.get(i).contains("Accounts Audit Report")) {
				file=common.convertCsvToXLS(listFilesPath.get(i));
				commonInterfacePage.validateValuesIsPresentInExcel(file,"sheet1",
						accountHeaders, accountValues,1);	
			}else if(listFilesPath.get(i).contains("Applications Audit Report")) {
				file=common.convertCsvToXLS(listFilesPath.get(i));
				commonInterfacePage.validateValuesIsPresentInExcel(file,"sheet1",
						appColumnHeaders, appColumnValues,1);	
			}else if(listFilesPath.get(i).contains("Card Maintenance Audit Report")) {
				file=common.convertCsvToXLS(listFilesPath.get(i));
				commonInterfacePage.validateValuesIsPresentInExcel(file,"sheet1",
						cardColumnHeaders, cardColumnValues,1);	
			}else if(listFilesPath.get(i).contains("Client Excessive Transactions Report - XLS")) {
				commonInterfacePage.validateValuesIsPresentInExcel(listFilesPath.get(i),"ExcessiveTransactionsVolume_XLS",
			    		transColumnHeaders, transactionValues,10);
			}else if(listFilesPath.get(i).contains("Customers Audit Report")) {
				file=common.convertCsvToXLS(listFilesPath.get(i));
				commonInterfacePage.validateValuesIsPresentInExcel(file,"sheet1",
						cusColumnHeaders, CusColumnValues,1);
			}else if(listFilesPath.get(i).contains("Daily Reconciliation Report")) {
				ifcsCommonPage.validateDailyReconciliationPDFReport(listFilesPath.get(i));
			}else if(listFilesPath.get(i).contains("Day Applications Accepted")) {
				 ifcsCommonPage.validateReportContent(listFilesPath.get(i),accountNo);
			}else if(listFilesPath.get(i).contains("Day Applications Declined")) {
				ifcsCommonPage.validateReportContent(listFilesPath.get(i),declinedAccountno);
			}else if(listFilesPath.get(i).contains("Direct Debit Report")) {
				commonInterfacePage.validateValuesIsPresentInExcel(listFilesPath.get(i), "DirectDebit",
				  		columnHeaders, columnValues,2);
			}else if(listFilesPath.get(i).contains("Day Trans List Detail")) {
				 ifcsCommonPage.validateSuspensePostingReportForTransaction(listFilesPath.get(i),transactionsDetails);
			}else if(listFilesPath.get(i).contains("Day Trans List Sundries")) {
				ifcsCommonPage.validateReportContent(listFilesPath.get(i),creditScore);
			}else if(listFilesPath.get(i).contains("Day Trans List Suspended")) {
				commonInterfacePage.validateTextFromPDF(listFilesPath.get(i),suspendedRefNo,suspendedCardNo+" "+suspendedBatchNo,1,1);
			}else if(listFilesPath.get(i).contains("Standardised Report Extract")) {
				commonInterfacePage.validateValuesIsPresentInExcel(listFilesPath.get(i), "Tab 1",
				  		columnHeader, columnValue,0);
			}else if(listFilesPath.get(i).contains("Merchants and Locations Audit Report")) {
				file=common.convertCsvToXLS(listFilesPath.get(i));
				commonInterfacePage.validateValuesIsPresentInExcel(file,"sheet1",
						merchantColumnHeaders, merColumnValues,1);
			}else if(listFilesPath.get(i).contains("Client Excessive Transaction Value Report - PDF") && listFilesPath.get(i).contains("Client Excessive Transaction Value Report - XLS") && listFilesPath.get(i).contains("Client Excessive Transactions Report - PDF") &&
					listFilesPath.get(i).contains("Collections Account Report") && listFilesPath.get(i).contains("Day Acct Balance Summary") && listFilesPath.get(i).contains("Day Acct Card Ledger")
					&& listFilesPath.get(i).contains("Day Acct Overdue Overlimit") && listFilesPath.get(i).contains("Day Acct Receivables Summary") && listFilesPath.get(i).contains("Day General Ledger")
					&& listFilesPath.get(i).contains("Day Merchant Settlement") && listFilesPath.get(i).contains("Day Trans List Summary") && listFilesPath.get(i).contains("Dishonour Notification Report") 
					&& listFilesPath.get(i).contains("General Ledger Adjustments - Daily") && listFilesPath.get(i).contains("General Ledger Summary - Uninvoiced Transactions") && listFilesPath.get(i).contains("Payment Exception Report")
					 && listFilesPath.get(i).contains("SpeedPass Card Status Report - PDF") && listFilesPath.get(i).contains("SpeedPass Card Status Report - XLS") && listFilesPath.get(i).contains("Uninvoiced COAG Report")) {
				System.out.println("******please do it manually for Validatin the reports******");
			}
			}
		  
	}
	
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "Smoke" },enabled=false)
	public void VerifyReportsOn1stOfTheDayEnd(@Optional("SG") String clientCountry,
			@Optional("EMAP") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  TST-SC-17.1- On 1st Run Day End and Verify reports, Interfaces","DayEnd Report Validations");
		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSCommonPage ifcsCommonPage = new IFCSCommonPage(driver, test);
		CommonInterfacePage commonInterfacePage = new CommonInterfacePage(driver, test);
		Common common = new Common(driver,test);
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry," ");
		
		//Data Creation
		
		String dayEndDatePath="";
		String fileName="";
		List<String>  fileNames;
		String localFolder="";
		List<String> listFilesPath=new ArrayList<String>();
		String refNumber="183";
		String transactionValue=common.getClientTransactionValue(refNumber);
		System.out.println("Transaction Value::"+transactionValue);
		Map<String, String> customerNo = common.getCustomerTransactions(refNumber);
	    String cusNo= customerNo.get("CUSTOMER_NO").toString();
	    ArrayList<String> transactionValues = new ArrayList<String>();
	    transactionValues.add(cusNo);
	    transactionValues.add(refNumber);
	    transactionValues.add(transactionValue);
	    String[] transColumnHeaders = { "Customer Number", "Transaction Receipt Number", "Value" };
	    String accountNo=common.getApprovedCustomerNumberFromDB("Accept");
		String declinedAccountno=common.getDeclinedApplicationNo();
		String refNo="104";
	  	Map<String,String> transactionsDetails = common.getCustomerTransactions(refNo);
	  	String creditScore=common.validateCreditAmountForAdjustmentType("Late Payment Fee Adj",refNo);
	  	String suspendedRefNo="046540";
	
		Map<String, String> suspendedDetails = common.getSuspendedTransactionDetails(suspendedRefNo);
		 String suspendedCardNo= suspendedDetails.get("CARD_NO").toString();
		 String suspendedBatchNo= suspendedDetails.get("BATCH_NO").toString();
		 Map<String, String> transactionDetail= common.getCustomerTransactions(refNo);
	        String cardNumber= transactionDetail.get("CARD_NO").toString();
	         
		ArrayList<String> columnValue = new ArrayList<String>();
		columnValue.add(cardNumber);
		columnValue.add(refNo);
		String[] columnHeader = { "Card Number","Ticket Number"};
		String merchantAccountNo[]= {""};
		 //Client Reports File Moving
		String dateIFCS = common.getCurrentIFCSDateFromDB(clientName + clientCountry);
		String dbProcessingDate = commonInterfacePage.getreportDateFormat(dateIFCS);
		 fileNames=commonInterfacePage.createClientReportFileFormatByDateAppend(clientCountry,emapdayendreportsConfigFile,dbProcessingDate);
		  for(int i=0;i<=fileNames.size();i++) {
				  fileName= fileNames.get(i);
		  if(clientCountry.equals("SG")) {
		  dayEndDatePath=commonInterfacePage.getFolderPathUsingPreviousProcessingDate(clientName, clientCountry,"IFCS_DAYEND_OUTPUTFILE_SG_CLIENT");
		  }else if(clientCountry.equals("SP")) {
				 dayEndDatePath=commonInterfacePage.getFolderPathUsingPreviousProcessingDate(clientName, clientCountry,"IFCS_DAYEND_OUTPUTFILE_SP_CLIENT");
		  }else if(clientCountry.equals("GU")) {
				 dayEndDatePath=commonInterfacePage.getFolderPathUsingPreviousProcessingDate(clientName, clientCountry,"IFCS_DAYEND_OUTPUTFILE_GU_CLIENT");
		  }else if(clientCountry.equals("HK")) {
				 dayEndDatePath=commonInterfacePage.getFolderPathUsingPreviousProcessingDate(clientName, clientCountry,"IFCS_DAYEND_OUTPUTFILE_HK_CLIENT");
		  }
		  System.out.println("dayEndDatePath::" +dayEndDatePath);
		  ifcsCommonPage.establishThePuttyConnection("incomingFile", "PUTTY_HOST", "PUTTY_USERNAME", "PUTTY_PASSWORD",
					dayEndDatePath, fileName);
		  localFolder = System.getProperty("user.home") + "\\Documents\\" +fileName;
		  listFilesPath.add(localFolder);
		  }
		  
		//File Validations
		  for(int i=0;i<listFilesPath.size();i++) {
		  if(listFilesPath.get(i).contains("Client Excessive Transactions Report - XLS")) {
				commonInterfacePage.validateValuesIsPresentInExcel(listFilesPath.get(i),"ExcessiveTransactionsVolume_XLS",
			    		transColumnHeaders, transactionValues,10);
		  }else if(listFilesPath.get(i).contains("Daily Reconciliation Report")) {
			  ifcsCommonPage.validateDailyReconciliationPDFReport(listFilesPath.get(i));
		  }else if(listFilesPath.get(i).contains("Day Applications Accepted")) {
				 ifcsCommonPage.validateReportContent(listFilesPath.get(i),accountNo);
			}else if(listFilesPath.get(i).contains("Day Applications Declined")) {
				ifcsCommonPage.validateReportContent(listFilesPath.get(i),declinedAccountno);
			}else if(listFilesPath.get(i).contains("Day Trans List Detail")) {
				 ifcsCommonPage.validateSuspensePostingReportForTransaction(listFilesPath.get(i),transactionsDetails);
			}else if(listFilesPath.get(i).contains("Day Trans List Sundries")) {
				ifcsCommonPage.validateReportContent(listFilesPath.get(i),creditScore);
			}else if(listFilesPath.get(i).contains("Day Trans List Suspended")) {
				commonInterfacePage.validateTextFromPDF(listFilesPath.get(i),suspendedRefNo,suspendedCardNo+" "+suspendedBatchNo,1,1);
			}else if(listFilesPath.get(i).contains("Standardised Report Extract")) {
				commonInterfacePage.validateValuesIsPresentInExcel(listFilesPath.get(i), "Tab 1",
				  		columnHeader, columnValue,0);
			}else if(listFilesPath.get(i).contains("Client Excessive Transaction Value Report - PDF") && listFilesPath.get(i).contains("Client Excessive Transaction Value Report - XLS") && listFilesPath.get(i).contains("Client Excessive Transactions Report - PDF") &&
					listFilesPath.get(i).contains("Collections Account Report") && listFilesPath.get(i).contains("Day Acct Balance Summary") && listFilesPath.get(i).contains("Day Acct Card Ledger")
					&& listFilesPath.get(i).contains("Day Acct Overdue Overlimit") && listFilesPath.get(i).contains("Day Acct Receivables Summary") && listFilesPath.get(i).contains("Day General Ledger")
					&& listFilesPath.get(i).contains("Day Merchant Settlement") && listFilesPath.get(i).contains("Day Trans List Summary") && 
				    listFilesPath.get(i).contains("General Ledger Adjustments - Daily") && listFilesPath.get(i).contains("General Ledger Summary - Uninvoiced Transactions") && listFilesPath.get(i).contains("Uninvoiced COAG Report")) {
				System.out.println("******Generated files moved to Local if need validation please do it manually******");
			}
	}
		  
	 //SAP Files
	  		fileName= commonInterfacePage.getGeneratedSAPFile(clientCountry,"IFIP");
		    ifcsCommonPage.establishThePuttyConnection("incomingFile", "PUTTY_HOST", "PUTTY_USERNAME", "PUTTY_PASSWORD",
					"IE_OUTPUTFILE_FOLDER_CAF",fileName );
	        localFolder = System.getProperty("user.home") + "\\Documents\\" +fileName;
	        System.out.println("localFolder::" +localFolder);
	        System.out.println("******Generated files moved to Local if need validation please do it manually******");
	  //Merchant DataPost 
			fileName=commonInterfacePage.getRecentProcessedFileNames(clientName, clientCountry,"MerchantPostalMailControl");
			System.out.println("FileName::"+fileName);
			ifcsCommonPage.establishThePuttyConnection("unzip file to xml", "PUTTY_HOST", "PUTTY_USERNAME", "PUTTY_PASSWORD", "IFCS_OUTPUTFILE_SG_MERCHANT_POST", fileName);
			fileName = fileName.split("\\.")[0];
			System.out.println("filename:: " +fileName);
			String merchantDataPostPath = System.getProperty("user.home")+System.getProperty("file.separator")+"Documents" + System.getProperty("file.separator") + fileName + ".xml";
			 ifcsCommonPage.validateIncomingXMLFile(merchantDataPostPath,merchantAccountNo,"ifcs:CustomerAccount","core:AccountNumber");

      //BAFF Files
			 commonInterfacePage.createFileNameFormatForBAFF(emapBAFFConfigProp,clientCountry);	
			 ifcsCommonPage.establishThePuttyConnection("incomingFile", "PUTTY_HOST", "PUTTY_USERNAME", "PUTTY_PASSWORD",
						"IE_OUTPUTFILE_FOLDER_CAF",fileName );
		        localFolder = System.getProperty("user.home") + "\\Documents\\" +fileName;
		        System.out.println("localFolder::" +localFolder);
		        System.out.println("******Generated files moved to Local if need validation please do it manually******");
	}
}
