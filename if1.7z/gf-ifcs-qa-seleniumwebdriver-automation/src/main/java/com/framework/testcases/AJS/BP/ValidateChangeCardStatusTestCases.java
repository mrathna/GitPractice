package com.framework.testcases.AJS.BP;

import java.util.ArrayList;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.CardMaintenancePage;
import com.framework.pages.AJS.ChangeCardStatus;
import com.framework.pages.AJS.MaintainCustomerPage;
import com.framework.pages.AJS.common.Common;
import com.framework.pages.AJS.common.IFCSHomePage;
import com.framework.pages.AJS.common.IFCSLoginPage;
import com.framework.pages.OLS.common.BPCommonPage;

public class ValidateChangeCardStatusTestCases extends BaseTest {

	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "Regression" ,"BusinessFlow"})
	public void viewExistingCardStatus(@Optional("AU") String clientCountry,
			@Optional("BP") String clientName){
		test = extent.createTest(clientName+ ":" +clientCountry+"  TC00041- Card status change- View existing card status", "Validate existing Card Status");
		// creating object for the Pages
		IFCSLoginPage ifcsLoginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage ifcsHomePage = new IFCSHomePage(driver, test);
		Common common = new Common(driver, test);
		BPCommonPage bpCommonPage = new BPCommonPage(driver, test);
		MaintainCustomerPage maintainCustomerPage = new MaintainCustomerPage(driver, test);
		
		ifcsLoginPage.login("IFCS_URL_BP", "IFCS_BP_USERNAME", "IFCS_BP_PASSWORD");
		ifcsLoginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		String customerNo=bpCommonPage.getBPPrepaidCustomer("100 Normal Service");
		if (customerNo.equals(" ")) {
			common.logForNoDataFound(this.getClass().getSimpleName(),
					"Need to Create A Customer with Account SubStatus as Payment Pending and rerun");
		} else {
		ifcsHomePage.gotoApplicationAndClickApplicationMenu();
	    ifcsHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);
		ifcsHomePage.gotoCustomerMenuCustomerDetails();
		common.chooseCustomerNoAndSearch(customerNo);
		maintainCustomerPage.viewExistingStatusFromCardTransfer();
		ifcsHomePage.exitIFCS();
		}
	}
	
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "Regression" })
	public void validateChangecardActiveToLost(@Optional("AU") String clientCountry,
			@Optional("BP") String clientName){
		test = extent.createTest(clientName+ ":" +clientCountry+"  TC00042- Card status change- Change Card from Active to Lost", "Validate Change Card Status from Active to Lost");
		// creating object for the Pages
		IFCSLoginPage ifcsLoginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage ifcsHomePage = new IFCSHomePage(driver, test);
		Common common = new Common(driver, test);
		BPCommonPage bpCommonPage = new BPCommonPage(driver, test);
		ChangeCardStatus changeCardStatus = new ChangeCardStatus(driver, test);
		CardMaintenancePage cardMaintenancePage = new CardMaintenancePage(driver, test);
		
		ifcsLoginPage.login("IFCS_URL_BP", "IFCS_BP_USERNAME", "IFCS_BP_PASSWORD");
		ifcsLoginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		// Click search cards
		String cardNo = bpCommonPage.getBPPrepaidCard("100 Normal Service");
		if (cardNo.equals(" ")) {
			common.logForNoDataFound(this.getClass().getSimpleName(),
					"Need to Create A Customer with No Balance or with Balance and rerun");
		} else {
		    ifcsHomePage.gotoApplicationAndClickApplicationMenu();
			ifcsHomePage.gotoSearchAndClickCards();
			changeCardStatus.verifyCardNumberAndDoubleClick(cardNo);
			changeCardStatus.changeCardStatusAndClickYesAndValidate("200 Card Lost");
			String expiryDate=cardMaintenancePage.getReplacedCardDetails("200 Card Lost");
			cardMaintenancePage.clickNextAndValidateReplacedCardDetails("Card Ordered",expiryDate);
		}
		ifcsHomePage.exitIFCS();
		}
	
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "Regression" })
	public void validateChangecardActiveToExpired(@Optional("AU") String clientCountry,
			@Optional("BP") String clientName){
		test = extent.createTest(clientName+ ":" +clientCountry+"  TC00043- Card status change- Change Card from Active to Expired", "Validate Change Card Status from Active to Expired");
		// creating object for the Pages
				IFCSLoginPage ifcsLoginPage = new IFCSLoginPage(driver, test);
				IFCSHomePage ifcsHomePage = new IFCSHomePage(driver, test);
				Common common = new Common(driver, test);
				BPCommonPage bpCommonPage = new BPCommonPage(driver, test);
				ChangeCardStatus changeCardStatus = new ChangeCardStatus(driver, test);	
				CardMaintenancePage cardMaintenancePage = new CardMaintenancePage(driver, test);
				
		ifcsLoginPage.login("IFCS_URL_BP", "IFCS_BP_USERNAME", "IFCS_BP_PASSWORD");
		ifcsLoginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		//common.getCustomerNoHavingNoBulkReissueAndCardsExpiringInFewDays("");
		String currentIFCSDate = common.getCurrentIFCSDateFromDB(clientName+clientCountry);
		System.out.println("IFCS Date ::"+currentIFCSDate);
		String cardNo =bpCommonPage.getBPPrepaidCardGoingToExpire(currentIFCSDate);
		// Click search cards
		if (cardNo.equals(" ")) {
			common.logForNoDataFound(this.getClass().getSimpleName(),
					"Need to Create A Customer with No Balance or with Balance and rerun");
		} else {
			ifcsHomePage.gotoApplicationAndClickApplicationMenu();
			ifcsHomePage.gotoSearchAndClickCards();
			changeCardStatus.verifyCardNumberAndDoubleClick(cardNo);
			changeCardStatus.changeCardStatusAndClickYesAndValidate("900 Expired");
			String expiryDate=cardMaintenancePage.getReplacedCardDetails("900 Expired");
			cardMaintenancePage.clickNextAndValidateReplacedCardDetails("Card Ordered",expiryDate);
		}
		ifcsHomePage.exitIFCS();
		}
	
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "Regression" })
	public void validateChangecardActiveToStolen(@Optional("AU") String clientCountry,
			@Optional("BP") String clientName){
		test = extent.createTest(clientName+ ":" +clientCountry+"  TC00044- Card status change- Change Card from Active to Stolen", "Validate Change Card Status from Active to Stolen");
		// creating object for the Pages
				IFCSLoginPage ifcsLoginPage = new IFCSLoginPage(driver, test);
				IFCSHomePage ifcsHomePage = new IFCSHomePage(driver, test);
				Common common = new Common(driver, test);
				BPCommonPage bpCommonPage = new BPCommonPage(driver, test);
				ChangeCardStatus changeCardStatus = new ChangeCardStatus(driver, test);
				
				CardMaintenancePage cardMaintenancePage = new CardMaintenancePage(driver, test);
		ifcsLoginPage.login("IFCS_URL_BP", "IFCS_BP_USERNAME", "IFCS_BP_PASSWORD");
		ifcsLoginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		// Click search cards
		String cardNo = bpCommonPage.getBPPrepaidCard("100 Normal Service");
		if (cardNo.equals(" ")) {
			common.logForNoDataFound(this.getClass().getSimpleName(),
					"Need to Create A Customer with No Balance or with Balance and rerun");
		} else {
			ifcsHomePage.gotoApplicationAndClickApplicationMenu();
			ifcsHomePage.gotoSearchAndClickCards();
			changeCardStatus.verifyCardNumberAndDoubleClick(cardNo);
			changeCardStatus.changeCardStatusAndClickYesAndValidate("300 Card Stolen");
			String expiryDate=cardMaintenancePage.getReplacedCardDetails("300 Card Stolen");
			cardMaintenancePage.clickNextAndValidateReplacedCardDetails("Card Ordered",expiryDate);
		}
		ifcsHomePage.exitIFCS();
		}
	
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "Regression" })
	public void validateChangecardActiveToTemp(@Optional("AU") String clientCountry,
			@Optional("BP") String clientName){
		test = extent.createTest(clientName+ ":" +clientCountry+"  TC00045- Card status change- Change Card from Active to Temp", "Validate Change Card Status from Active to Temp");
		// creating object for the Pages
				IFCSLoginPage ifcsLoginPage = new IFCSLoginPage(driver, test);
				IFCSHomePage ifcsHomePage = new IFCSHomePage(driver, test);
				Common common = new Common(driver, test);
				BPCommonPage bpCommonPage = new BPCommonPage(driver, test);
				ChangeCardStatus changeCardStatus = new ChangeCardStatus(driver, test);
				
				CardMaintenancePage cardMaintenancePage = new CardMaintenancePage(driver, test);
		ifcsLoginPage.login("IFCS_URL_BP", "IFCS_BP_USERNAME", "IFCS_BP_PASSWORD");
		ifcsLoginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		// Click search cards
		String cardNo = bpCommonPage.getBPPrepaidCard("100 Normal Service");
		if (cardNo.equals(" ")) {
			common.logForNoDataFound(this.getClass().getSimpleName(),
					"Need to Create A Customer with No Balance or with Balance and rerun");
		} else {
			ifcsHomePage.gotoApplicationAndClickApplicationMenu();
			ifcsHomePage.gotoSearchAndClickCards();
			changeCardStatus.verifyCardNumberAndDoubleClick(cardNo);
			changeCardStatus.changeCardStatusAndClickYesAndValidate("805 Temporary Card Close");
			String expiryDate=cardMaintenancePage.getReplacedCardDetails("805 Temporary Card Close");
			cardMaintenancePage.clickNextAndValidateReplacedCardDetails("Card Ordered",expiryDate);
		}
		ifcsHomePage.exitIFCS();
		}
	
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "Regression","BusinessFlow" })
	public void validateBulkCardStatusChange(@Optional("NZ") String clientCountry,
			@Optional("BP") String clientName){
		test = extent.createTest(clientName+ ":" +clientCountry+"  BPNZ49_Cust_NZ_016_Bulk Card Status Change", "Validate Bulk Card Status Change");
		// creating object for the Pages
				IFCSLoginPage ifcsLoginPage = new IFCSLoginPage(driver, test);
				IFCSHomePage ifcsHomePage = new IFCSHomePage(driver, test);
				Common common = new Common(driver, test);
				CardMaintenancePage cardMaintenancePage = new CardMaintenancePage(driver, test);
				
				ifcsLoginPage.login("IFCS_URL_BP", "IFCS_BP_USERNAME", "IFCS_BP_PASSWORD");
				ifcsLoginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
				String cusNo=common.getCustomerNoHavingMoreThan5ActiveCards();
				if (cusNo.equals(" ")) {
					common.logForNoDataFound(this.getClass().getSimpleName(),
							"Customer having cards need to create");
				} else {
					ifcsHomePage.gotoCustomerMenuCustomerDetails();
					common.chooseCustomerNoAndSearch(cusNo);
					ArrayList<String> cardnumbers=cardMaintenancePage.bulkCardStatusChange("300 Card Stolen","Yes");
					System.out.println("Array Of Card Numbers::"+cardnumbers);
					cardMaintenancePage.validateNewCardStatusIsChanged("600 Requested Not Issued",cardnumbers);
					ifcsHomePage.gotoCustomerMenuCustomerDetails();
					common.chooseCustomerNoAndSearch(cusNo);
					ArrayList<String> cards=cardMaintenancePage.bulkCardStatusChange("300 Card Stolen","No");
					cardMaintenancePage.validateNewCardStatusIsNotChanged("300 Card Stolen",cards);
					String lostCusNo=common.getCustomerNumberWithCardsAndNoHierarchyFromDB("Lost");
					ifcsHomePage.gotoCustomerMenuCustomerDetails();
					common.chooseCustomerNoAndSearch(lostCusNo);
				    cardMaintenancePage.changeLostCardToInvalidStatusInCardBulkStatus("100 Normal Service");
					ifcsHomePage.exitIFCS();
	}
	}
}
