﻿using Common;
using Common.PageObjects;
using Common.Utility;
using NFluent;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EnCompass.Testing.Source.PageObjects
{
	/// <summary>
	/// This page opens up when we click Help Menu from Encompas page home and open it in a new tab or browser
	/// </summary>
	public class HelpCenter : PageModel
	{
		public HelpCenter(GlobalSettings settings) : base(settings) { isGuidPresentOnPage = false; }


		public override string RelativeUrl => @"https://wexqa.encompass-suite.com/help/home.htm";
		public override string PageIdentifierXPath_Override => @"//a[contains(@class,'logo') and (normalize-space(@alt)='Help Center')]";

        #region XPATH

        private const string _transactionsXPath = "//a[contains(@href,'Transactions.htm') and text()='Transactions']";
        private const string _helpCenterVersionXPath = "//span[contains(@class,'NumberVersion')]";

        #endregion

        #region IWebElements Props

        private IWebElement _transactions
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_transactionsXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_transactions element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _helpCenterVersion
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_helpCenterVersionXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_helpCenterVersion element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        #endregion


        public void ClickTransactionsPage()
        {
            _transactions.WaitUntilElementIsInteractable();
            _transactions.JSClickWithFocus(Driver);
            Settings.EnCompassExtentTest.Info("Clicked Transactions Page");
        }

        public string GetHelpCenterVersion()
        {
            _helpCenterVersion.WaitUntilElementIsInteractable();
            this.AttachOnDemandScreenShot();
            return _helpCenterVersion.Text;
        }
    }
}
