﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Common.Utility.ControlMTool
{
	public class Options
	{
		private string _serverBaseUrl;
		public string ServerBaseUrl
		{
			get
			{
				if (_serverBaseUrl == null)
				{
					// Setting the default to STAGING Environment.
					if (Environment.Equals("uat", StringComparison.InvariantCultureIgnoreCase) || Environment.Equals("pat", StringComparison.InvariantCultureIgnoreCase))
					{
						_serverBaseUrl = "https://aue1ctmem000s.coreservicesprod.ue1.wexglobal.com:8443/automation-api/";
					}
					else if (Environment.Equals("qa", StringComparison.InvariantCultureIgnoreCase) || Environment.Equals("dev", StringComparison.InvariantCultureIgnoreCase))
					{
						_serverBaseUrl = "https://aue1ctmem0000d.coreservicesdev.ue1.wexglobal.com:8443/automation-api/";
					}
					else
					{
						_serverBaseUrl = "https://aue1ctmem000s.coreservicesprod.ue1.wexglobal.com:8443/automation-api/";
					}

					// PROD CONTROL-M Server address is: https://aue1ctmem000p.coreservicesprod.ue1.wexglobal.com:8443/automation-api/
				}
				return _serverBaseUrl;
			}
			set { _serverBaseUrl = value; }
		}

		private string _agentName;
		public string AgentName
		{
			get
			{
				if (_agentName == null)
				{
					if (Environment.Equals("uat", StringComparison.InvariantCultureIgnoreCase))
					{
						// Setting the default to UAT Environment.
						_agentName = "cmvaenc-uat";
					}
					else if (Environment.Equals("pat", StringComparison.InvariantCultureIgnoreCase))
					{
						_agentName = "cmvaenc-pat";
					}
					else if (Environment.Equals("dev", StringComparison.InvariantCultureIgnoreCase) || (Environment.Equals("qa", StringComparison.InvariantCultureIgnoreCase)))
					{
						_agentName = "cmvaenc-qa";
					}
				}
				return _agentName;
			}
			set
			{
				_agentName = value;
			}

		}

		private object _creds;
		public object Credentials
		{
			get
			{
				if (_creds == null)
				{
					if (Environment.Equals("uat", StringComparison.InvariantCultureIgnoreCase) || Environment.Equals("pat", StringComparison.InvariantCultureIgnoreCase))
					{
						_creds = new { username = "controlMAPI", password = "b49XSAAd3E4y" };
					}
				}

				return _creds;
			}
		}

		private string _environment;
		public string Environment
		{
			get
			{
				if (_environment == null)
				{
					if (GlobalSettings.Environment == null)
					{
						_environment = "UAT"; // Default Environment is always set to UAT
					}
					else
					{
						_environment = GlobalSettings.Environment;
					}
				}
				return _environment;
			}
			set
			{
				_environment = value;
			}
		}

		#region Singleton Implementation
		private static volatile Options _instance;
		private static object _syncRoot = new Object();

		public static Options Instance
		{
			get
			{
				if (_instance == null)
				{
					lock (_syncRoot)
					{
						if (_instance == null)
							_instance = new Options();
					}
				}

				return _instance;
			}
		}
		#endregion

		private Options()
		{
		}
	}
}
