﻿using Common;
using Common.Utility;
using NFluent;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EnCompass.Testing.Source.PageObjects.Organization.ExpenseManager.TransactionExtract
{
    [PageModel(@"/expenseManager/transactionExtract/executeExtract.aspx")]
    public class ExecuteExtract : EnCompassOrgPageModel
    {
        public override string RelativeUrl => @"/expenseManager/transactionExtract/executeExtract.aspx";
        public override string PageIdentifierXPath_Override => @"//li[@class='breadcrumb-item active'][text() = 'Execute']";

        #region XPath page Elements
        private const string _ddlOptionsXPath = @"//select[contains(@id,'ddlOptions')]";
        private const string _ddlPeriodXPath = @"//select[contains(@id,'ddlPeriod')]";
        private const string _btnPreviewXPath = @"//input[contains(@id,'btn_Preview_Temp')]";
        private const string _totalRecordsValueXPath = @"//div[contains(@id,'divSummary')]//li[contains(text(),'Total records')]//strong";
        private const string _btnExportXPath = @"//input[contains(@id,'btnExportGridText')]";
        #endregion

        #region Page Elements
        private IWebElement _ddlOptions
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_ddlOptionsXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Info("Found _ddlOptions");
                return element;
            }
        }

        private IWebElement _ddlPeriod
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_ddlPeriodXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Info("Found _ddlPeriod");
                return element;
            }
        }

        private IWebElement _btnPreview
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_btnPreviewXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Info("Found _btnPreview");
                return element;
            }
        }

        private IWebElement _totalRecordsValue
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_totalRecordsValueXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Info("Found _totalRecordsValue");
                return element;
            }
        }

        private IWebElement _btnExport
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_btnExportXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Info("Found _btnExport");
                return element;
            }
        }

        #endregion

        public ExecuteExtract(GlobalSettings settings) : base(settings) { }

        public void SetOptions(string value)
        {
            SelectElement ddlOptions = new SelectElement(_ddlOptions);
            ddlOptions.SelectByText(value);
        }

        public void SetPeriod(string value)
        {
            SelectElement ddlPeriod = new SelectElement(_ddlPeriod);
            ddlPeriod.SelectByText(value);
        }

        public void Preview()
        {
            _btnPreview.JSClickWithFocus(Driver);
        }

        public string GetTotalRecords()
        {
            return _totalRecordsValue.Text;
        }

        public void Export()
        {
            _btnExport.JSClickWithFocus(Driver);
        }

    }
}
