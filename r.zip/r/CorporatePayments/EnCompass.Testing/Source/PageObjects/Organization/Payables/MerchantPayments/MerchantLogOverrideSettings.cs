﻿using Common;
using Common.Utility;
using NFluent;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EnCompass.Testing.Source.PageObjects.Organization.Payables.MerchantPayments
{
    [PageModel(@"/payables/merchantPayments/MerchantLogOverrideSettings.aspx")]
    public partial class MerchantLogOverrideSettings : EnCompassOrgPageModel
    {
        public override string RelativeUrl => @"/payables/merchantPayments/MerchantLogOverrideSettings.aspx";
        public override string PageIdentifierXPath_Override => @"//li[@class='breadcrumb-item active'][contains(normalize-space(text()),'Settings Overrides for')]";

        #region XPath Page Elements

        private const string _mLogExpDaysToggleXPath = "//a[contains(@id,'toggletxtMLogExpDays')]";
        private const string _mLogExpDaysXPath = "//input[contains(@id,'txtMLogExpDays')]";
        private const string _remindersPeriodToggleXPath = "//button[contains(@id,'txtRemindersPeriod')]";
        private const string _remindersPeriodXPath = "//input[contains(@id,'txtRemindersPeriod')]";
        private const string _afterExpirationReconciliationXPath = "//input[contains(@id,'txtAfterExpirationReconciliationDays')]";
        private const string _autoReconcilePercentAboveXPath = "//input[contains(@id,'txtAutoReconcilePercentAbove')]";
        private const string _autoReconcileDollarAboveXPath = "//input[contains(@id,'txtAutoReconcileDollarsAbove')]";
        private const string _autoReconcilePercentBelowXPath = "//input[contains(@id,'txtAutoReconcilePercentBelow')]";
        private const string _autoReconcileDollarBelowXPath = "//input[contains(@id,'txtAutoReconcileDollarsBelow')]";
        private const string _cardLimitIncreaseXPath = "//input[contains(@id,'txtCardLimitIncrease')]";
        private const string _cardLmtAbvMLogAmtDDLXPath = "//select[contains(@id, 'CardLimitIncreaseType')]";
        private const string _overrideMlogSettingsCheckboxXPath = ".//input[@type ='checkbox' and contains(@id,'chkAreActive')]";
        public const string _overrideMlogSettingsCheckboxLabelXPath = ".//label[contains(@for,'chkAreActive')]";
        private const string _saveXPath = "//input[contains(@id,'btnSave')]";
        private const string _combineInvoicesSelectXPath = ".//select[contains(@id,'AggregateInvoicesOverride')]";
        private const string _honorCreditInvoicesOverrideXPath = ".//select[contains(@id,'ddlExactMatchHonorCreditInvoicesOverride')]";
        private const string _cancelButtonXPath = "//input[contains(@id,'btnCancel')]";
        private const string _legendAutoReconciliationXPath = "//legend[normalize-space() = 'Auto-Reconciliation']";
        private const string _legendAboveAmountXPath = "//legend[normalize-space() = 'Above Amount']";
        private const string _legendBelowAmountXPath = "//legend[normalize-space() = 'Below Amount']";
        private const string _ddlCRIMatchOverrideXPath = "//select[contains(@id,'ddlCRIMatchOverride')]";
        private const string _ddlInvoiceMatchingOverrideXPath = "//select[contains(@id,'ddlReconciliationInvoiceMatchingOverride')]";
        private const string _checkGridXPath = ".//tr[contains(@id,'ctl03')]";
        #endregion

        #region Page Elements

        private IWebElement _mLogExpDaysToggle
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_mLogExpDaysToggleXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_mLogExpDaysToggle element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _mLogExpDays
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_mLogExpDaysXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_mLogExpDays element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _remindersPeriodToggle
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_remindersPeriodToggleXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_remindersPeriodToggle element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _remindersPeriod
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_remindersPeriodXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_remindersPeriod element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _afterExpirationReconciliation
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_afterExpirationReconciliationXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_afterExpirationReconciliation element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _autoReconcilePercentAbove
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_autoReconcilePercentAboveXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_autoReconcilePercentAbove element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _autoReconcileDollarAbove
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_autoReconcileDollarAboveXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_autoReconcileDollarAbove element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _autoReconcilePercentBelow
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_autoReconcilePercentBelowXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_autoReconcilePercentBelow element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _autoReconcileDollarBelow
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_autoReconcileDollarBelowXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_autoReconcileDollarBelow element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _cardLimitIncrease
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_cardLimitIncreaseXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_cardLimitIncrease element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _cardLmtAbvMLogAmtDDL
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_cardLmtAbvMLogAmtDDLXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_cardLmtAbvMLogAmtDDL element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _overrideMlogSettingsCheckbox
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_overrideMlogSettingsCheckboxXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_overrideMlogSettingsCheckbox element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _overrideMlogSettingsCheckboxLabel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_overrideMlogSettingsCheckboxLabelXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_overrideMlogSettingsCheckboxLabel element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _save
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_saveXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_save element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _combineInvoicesSelect
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_combineInvoicesSelectXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_combineInvoicesSelect element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _honorCreditInvoicesOverride
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_honorCreditInvoicesOverrideXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_honorCreditInvoicesOverride element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _cancelButton
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_cancelButtonXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_cancelButton element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _legendAutoReconciliation
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_legendAutoReconciliationXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_legendAutoReconciliation element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _legendAboveAmount
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_legendAboveAmountXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_legendAboveAmount element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _legendBelowAmount
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_legendBelowAmountXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_legendBelowAmount element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _ddlCRIMatchOverride
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_ddlCRIMatchOverrideXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_ddlCRIMatchOverride element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _ddlInvoiceMatchingOverride
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_ddlInvoiceMatchingOverrideXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_ddlInvoiceMatchingOverride element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _checkGrid
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_checkGridXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_checkGrid element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        #endregion

        public bool EnableOverrideMLogSettings
		{
			set
			{
                if (_overrideMlogSettingsCheckbox.Enabled)
                {
                    _overrideMlogSettingsCheckbox.SetCheckboxStateWithLabel(_overrideMlogSettingsCheckboxLabel, value);
                    Settings.EnCompassExtentTest.Info("Checking the override MlogSettings Checkbox with value: " + value);
                }
            }
		}

        public bool OverrideMlogSettings
        {
            get => _overrideMlogSettingsCheckbox.Selected;
            set
            {
                _overrideMlogSettingsCheckbox.SetCheckboxStateWithLabel(_overrideMlogSettingsCheckboxLabel, value);
                Settings.EnCompassExtentTest.Info("OverrideMlogSettings Selected: " + value);
            }
        }

        public string MLogExpDays
        {
            set
            {
				_mLogExpDays.ForceDocumentLoadOnSendKeys(value, Driver);
            }
        }

        public string RemindersPeriod
        {
            set
            {
				_remindersPeriodToggle.JSClickWithFocus(Driver);
                _remindersPeriod.ForceDocumentLoadOnSendKeys(value, Driver);
            }
        }

        public string AfterExpirationReconciliation
        {
            set
            {
                _afterExpirationReconciliation.Clear();
                _afterExpirationReconciliation.SendKeys(value);
            }
        }

        public string AutoReconcilePercentAbove
        {
            set
            {
                _autoReconcilePercentAbove.ForceDocumentLoadOnSendKeys(value, Driver);
			}
        }
		
		public string AutoReconcileDollarAbove
		{
			set
			{
				_autoReconcileDollarAbove.ForceDocumentLoadOnSendKeys(value, Driver);
			}
		}

		public string AutoReconcilePercentBelow
		{
			set
			{
				_autoReconcilePercentBelow.ForceDocumentLoadOnSendKeys(value, Driver);
			}
		}
		public string AutoReconcileDollarBelow
		{
			set
			{
				_autoReconcileDollarBelow.ForceDocumentLoadOnSendKeys(value, Driver);
			}
		}

		public string CardLimitIncrease
        {
            set
            {
                _cardLimitIncrease.ForceDocumentLoadOnSendKeys(value, Driver);
			}
        }

        public string CombineInvoices
        {
            get
            {
                return new SelectElement(_combineInvoicesSelect).SelectedOption.Text;
            }
            set
            {
                String option = new SelectElement(_combineInvoicesSelect).Options.Where(op => op.Text.Contains(value.Trim())).Select(op => op.Text).First();
                new SelectElement(_combineInvoicesSelect).SelectByText(option);
                Settings.EnCompassExtentTest.Info("Select combine Invoices value: " + value);
            }
        }

        public string HonorCreditInvoicesOverride
		{
			get
			{
				return new SelectElement(_honorCreditInvoicesOverride).SelectedOption.Text;
			}
			set
			{
				new SelectElement(_honorCreditInvoicesOverride).SelectByText(value.Trim());
			}
		}

		public string CardLimitAboveMLogIncreaseType
		{
			set
			{
				new SelectElement(_cardLmtAbvMLogAmtDDL).SelectByText(value);
			}
			get
			{
				return new SelectElement(_cardLmtAbvMLogAmtDDL).SelectedOption.Text;
			}
		}

        public string DDLCRIMatchOverride
        {
            set
            {
                new SelectElement(_ddlCRIMatchOverride).SelectByText(value);
                Settings.EnCompassExtentTest.Info("DDLCRIMatchOverride selected: " + value);
            }
            get
            {
                return new SelectElement(_ddlCRIMatchOverride).SelectedOption.Text;
            }

        }

        public string DDLInvoiceMatchingOverride
        {
            set
            {
                new SelectElement(_ddlInvoiceMatchingOverride).SelectByText(value);
                Settings.EnCompassExtentTest.Info("DDLInvoiceMatchingOverride selected: " + value);
            }
            get
            {
                return new SelectElement(_ddlInvoiceMatchingOverride).SelectedOption.Text;
            }

        }

        public void SetCheckBox(IWebElement chkBox, bool state = true)
        {
			chkBox.SetCheckboxState(state);
            this.RefreshModel();
        }

		// "Save" button
        public void Save()
        {
            _save.JSClickWithFocus(Driver, _saveXPath,Settings);
			ConfirmOnModal();
			this.AttachOnDemandScreenShot();
		}
		
        public void Close()
        {
            _cancelButton.JSClickWithFocus(Driver);
        }

        public void CheckGrid()
        {
            Check.That(_checkGrid).IsNotNull();
        }

        public void CheckAbsenceACHProhibitedElements()
        {
            Settings.EnCompassExtentTest.Info("Checking for the absence of sections which should not be present when ACH is set.");
            Check.That(Driver.IsElementPresent(By.XPath(_legendAutoReconciliationXPath))).IsFalse();
            Check.That(Driver.IsElementPresent(By.XPath(_legendAboveAmountXPath))).IsFalse();
            Check.That(Driver.IsElementPresent(By.XPath(_legendBelowAmountXPath))).IsFalse();
        }

        public MerchantLogOverrideSettings(GlobalSettings Settings) : base(Settings) { }
    }
}
