﻿using Common;
using Common.Utility;
using NFluent;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EnCompass.Testing.Source.PageObjects.Organization.ReportStudio.StandardReports
{
    [PageModel(@"/ReportStudio/standardReports/TransactionReport.aspx")]
    public class TransactionReport : EnCompassPageModel
    {
        public TransactionReport(GlobalSettings settings) : base(settings) { ScheduleReport = new ScheduleReport(Driver, settings); }

        public override string RelativeUrl => @"/reportStudio/standardReports/TransactionReport.aspx";
        public override string PageIdentifierXPath_Override => @"//li[@class='breadcrumb-item active'][text() = 'Transactions']";

        public ScheduleReport ScheduleReport { get; set; }

        #region XPath page Elements
        private const string _executeRunXPath = @"//input[contains(@id,'StdReport_RunButton')]";
        private const string _formatXPath = @".//select[contains(@id, 'StdReport_FormatList')]";
        #endregion

        #region Page Elements
        private IWebElement _executeRun
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_executeRunXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_executeRun element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _format
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_formatXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_format element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        #endregion

        public void Run()
        {
            _executeRun.JSClickWithFocus(Driver);
        }

        public string Format
        {
            set
            {
                _format.SetListboxByText(value, SelectTextOptions.Contains);
                Settings.EnCompassExtentTest.Info("Selected User Report download format as :" + value);
            }
            get
            {
                SelectElement _elem = new SelectElement(_format);
                return _elem.SelectedOption.Text;
            }
        }

    }
}
