package com.framework.testcases.OLS.CHEV.Customer.ReadWrite;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.CHEV.CHContactUsPage;
import com.framework.pages.CHEV.CHLogonPage;
import com.framework.pages.OLS.common.LoginPage;


public class ValidateOLSContactUsScreen extends BaseTest {
	@Parameters({ "clientCountry", "clientName" })
	@Test(priority = 1)
	public void testCustomerReadWriteOLSContactUsScreen(@Optional("SG") String clientCountry, @Optional("CHV") String clientName) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  Read or Write OLS - Contact Us-CHV",
				"OLS - Contact Us");

		// Creating Objects for the Pages
		CHLogonPage chLogonPage = new CHLogonPage(driver, test);
		CHContactUsPage chContactUsPage = new CHContactUsPage(driver, test);
		LoginPage loginPage = new LoginPage(driver, test);
		
		loginPage.OpenOLSApplicationWithoutLogin("CHV_URL"); 
		chLogonPage.clickOnContactUs(); 
		chContactUsPage.enterRandomValuesAndValidate("customer");

		loginPage.validateLoginPage();
		
		
	}
}
 
