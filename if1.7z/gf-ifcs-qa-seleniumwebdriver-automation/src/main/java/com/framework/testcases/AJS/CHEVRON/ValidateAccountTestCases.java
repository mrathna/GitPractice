package com.framework.testcases.AJS.CHEVRON;


import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.MaintainAccountPage;
import com.framework.pages.AJS.common.Common;
import com.framework.pages.AJS.common.IFCSHomePage;
import com.framework.pages.AJS.common.IFCSLoginPage;
import com.framework.util.PropUtils;

public class ValidateAccountTestCases extends BaseTest {
	
	@Parameters({ "clientCountry", "clientName"})
	@Test( groups = { "Regression" })
	public void createASundryCreditAdjustment(@Optional("HK") String clientCountry,
			@Optional("CHEVRON") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  Maintain Account-Sundry Adjustment", "Sundry Credit Adjustment");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		Common common = new Common(driver, test);
		MaintainAccountPage maintainAccountPage = new MaintainAccountPage(driver, test);
		IFCSloginPage.login("IFCS_URL_"+clientName, "IFCS_"+clientName+"_USERNAME", "IFCS_"+clientName+"_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		IFCSHomePage.gotoAccountAndClickAccountDetails();
		String  clientNameInProp = PropUtils.getPropValue(configProp, clientName + "_" + clientCountry);
		String customerNo = common.getCustomerNoHasTransaction(clientNameInProp);
		if (customerNo.equals("")) {

			common.logForNoDataFound(this.getClass().getSimpleName(),
					"Need to Create A Customer with Card Type and rerun");
		} else {
		IFCSHomePage.gotoAccountAndClickAccountDetails();
		common.chooseCustomerNoAndSearch(customerNo);
		// common.chooseCardNoAndSearch("RUA0000019");
		String ActBal=common.getValueFromProtectedTextBox("Account Status","Actual Balance");
		String AvaiBal=common.getValueFromProtectedTextBox("Account Status","Available Balance");
		common.logInfo("Actual Balance before Sundry" +ActBal);
		common.logInfo("Available Balance before Sundry" +AvaiBal);
		String currentIFCSDateforEffAt = common.getCurrentIFCSDateFromDB(clientName + clientCountry);
		String effDate = common.enterADateValueInStatusBeginDateField("Current", currentIFCSDateforEffAt);

		maintainAccountPage.validateSundryAdjustmentWFE(customerNo, effDate, "Account Credit","Bad Debt WriteOff");
		IFCSHomePage.gotoAccountAndClickAccountDetails();
		String ActBalAft=common.getValueFromProtectedTextBox("Account Status","Actual Balance");
		String AvaiBalAft=common.getValueFromProtectedTextBox("Account Status","Available Balance");
		common.logInfo("Actual Balance After Sundry" +ActBalAft);
		common.logInfo("Available Balance After Sundry" +AvaiBalAft);
		double actbalance = Double.parseDouble(ActBal)-Double.parseDouble(ActBalAft);
		double avaibalance = Double.parseDouble(AvaiBalAft)-Double.parseDouble(AvaiBal);
		System.out.println("actbalnce"+actbalance);
		System.out.println("avaibalnce"+actbalance);
		if((actbalance==10.0)&&(avaibalance==10.0)) {
			common.logPass("Credit Sundry Adjusment successfully posted");
		}
		else {
			common.logFail("Credit Sundry Adjusment NOT successfully posted");
		}
		}
		IFCSHomePage.exitIFCS();
	}

	
}
