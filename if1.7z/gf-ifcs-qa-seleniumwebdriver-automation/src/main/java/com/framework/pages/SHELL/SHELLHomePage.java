package com.framework.pages.SHELL;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.ExtentTest;
import com.framework.basepage.BasePage;
import com.framework.repo.Locator;

public class SHELLHomePage extends BasePage {

	@FindBy(id = Locator.ADMIN_MENU)
	public WebElement adminMenu;

	@FindBy(id = Locator.USER_LIST)
	public WebElement userList;

	@FindBy(xpath = Locator.PAGETITLE)
	public WebElement pageTitle;

	@FindBy(id = Locator.EMAP_LOGO_IMG)
	public WebElement shellHPLogo;

	
	@FindBy(how = How.ID, using = Locator.SUPPORT_MENU)
	public WebElement supportMenu;
	
	/*@FindBy(xpath=Locator.SHELL_SUPPORT)
	public WebElement shellSupport;*/
	
	@FindBy(id = Locator.PROFILE)
	public WebElement profile;
	
	@FindBy(id = Locator.SHELL_ACCOUNT_DROPDOWN)
	public WebElement accountDropdown;
	
	@FindBy(xpath = Locator.ACCOUNT_NAME_DISPLAYED)
	public WebElement accountNameDisplayed;
	 
	// Added by Ayub on 15.06.2018
	
	@FindBy(id = Locator.CONTACT)
	public WebElement contact;
	
	
	@FindBy(id = Locator.ACCOUNTS_MENU)
	public WebElement accountMenu;
	
	// Added by Ayub 19.06.2018
	
	@FindBy(id = Locator.DRIVERS_MENU)
	public WebElement drivers;
	
	@FindBy(id = Locator.VEHICLES_MENU)
	public WebElement vechicles;
	
	@FindBy(id = Locator.CLOSE_ACCOUNT)
	public WebElement closeAccount;
	
	@FindBy(xpath=Locator.ACCOUNT_NAME_IN_HOME_PAGE)
	public WebElement accountNameInHomePage;
	
	
// Added by Ayub 20.06.2018
	
	
	@FindBy(id = Locator.BULK_CARD_ORDER_SUBMENU)
	public WebElement bulkCardOrder;
	
	// Added by Ayub 25.06.2018
	
	@FindBy(id = Locator.REPLACE_CARD)
	public WebElement replaceCard;	
	
	@FindBy(id = Locator.REPORTS_AND_INVOICE)
	public WebElement reportsAndInvoice;	
	
	@FindBy(id = Locator.STORED_REPORTS)
	public WebElement storedReports;	
	
	@FindBy(id = Locator.ADHOC_REPORTS_SUBMENU)
	public WebElement adHocReports;

	// Added by Ayub on 27.06.2018

	@FindBy(id = Locator.FOOTER_CONTACTUS)
	public WebElement contactUS;

	@FindBy(id = Locator.MESSAGE_ABOUT_SEL)
	public WebElement selectQueryTypedropdown;

	@FindBy(id = Locator.ORDER_NEW_CARD_QUICK_LINK)
	public WebElement orderNewCardQuickLink;

	@FindBy(id = Locator.HOME_MENU_BP)
	public WebElement homeMenu;

	@FindBy(id = Locator.CHANGE_CARD_STATUS_QUICK_LINK)
	public WebElement changeCardStatusQuickLink;

	@FindBy(id = Locator.QUICK_LINK_CARD_LIST)
	public WebElement cardListQuickLink;

	@FindBy(id = Locator.QUICK_LINK_TRANSACTION_LIST)
	public WebElement transcationListQuickLink;
	
	@FindBy(id = Locator.QUICK_LINK_EXPORT_TRANSACTIONS)
	public WebElement exportTranscationQuickLink;
	
	@FindBy(id = Locator.TOPUSERDD)
	public WebElement topUserName;
	
	@FindBy(id = Locator.HELP_SHELL)
	public WebElement helpLink;
	
	@FindBy(xpath = Locator.DISPLAY_LANGUAGE)
	public WebElement displayLanguage;

	@FindBy(xpath = Locator.LANGUAGE_DROP)
	public WebElement languagedrop;

	@FindBy(xpath = Locator.RUSSIAN_USERNAME_LABEL)
	public WebElement RussianUsernameLabel;

	@FindBy(xpath = Locator.RUSSIAN_PASSWORD_LABEL)
	public WebElement RussianPasswordLabel;

	@FindBy(xpath = Locator.MALAYSIA_USERNAME_LABEL)
	public WebElement MalaysiaUsernameLabel;

	@FindBy(xpath = Locator.MALAYSIA_PASSWORD_LABEL)
	public WebElement MalaysiaPasswordLabel;

	//

	@FindBy(xpath = Locator.ACCOUNT_STATUS_HOME_PAGE)
	public WebElement accountStatusInHomePage;

	// Added by Ayub on 28.06.2018 
	
	@FindBy(id = Locator.UPLOAD_BUTTON)
	public WebElement upLoadButton;
	
	@FindBy(id = Locator.SHELL_INVOICES)
	public WebElement shellInvoices;
	
	@FindBy(id = Locator.FOOTER_HOME_LINK)
	public WebElement footerHomeLink;
	
	@FindBy(id = Locator.FOOTER_CONTACTUS)
	public WebElement footerContactUsLink;
	
	@FindBy(xpath = Locator.FOOTER_LEG_NOTICE_UPDATED)
	public WebElement footerLegalNoticeLink;
	
	@FindBy(xpath = Locator.FOOTER_PRIV_STATEMENT_UPDATED)
	public WebElement footerPrivateStatementLink;
	
	@FindBy(id = Locator.EXPORT_ACCOUNT_HIERARCHY)
	public WebElement exportAccountHierarchyButton;
	
	@FindBy(id = Locator.BULK_REISSUE_TABLE)
	public WebElement bulkReissueTable;
	
	// Added by Ayub on 29.06.2018
	@FindBy(id = Locator.BROWSE_FOR_FILE)
	public WebElement browseFile;

	@FindBy(xpath = Locator.CLEAR_ALL)
	public WebElement clearAll;

	@FindBy(id = Locator.CLOSE_UPLOAD_POPUP)
	public WebElement closePopup;
	
	@FindBy(xpath = Locator.SHELL_UPLOAD_FILE)
	public WebElement shellUploadFile;
	
	// Added by Ayub on 02.07.2018
	
	@FindBy(id = Locator.CARDS_MENU)
	public WebElement cardMenu;
	
	@FindBy(id = Locator.CHANGE_PWD_IN_HELLO_UN_LINK)
	public WebElement changePasswordFromUserNameDD;
	
	@FindBy(id = Locator.HOME_MENU)
	public WebElement homePageShell;
	
	@FindBy(how = How.ID, using = Locator.QUICK_LINKS)
	public WebElement QuickLinks;
	
	// Added by Ayub 12-07-2018
	
	@FindBy(id = Locator.CLOSE_UPLOAD_POPUP)
	public WebElement closePopUp;	
	
	@FindBy(xpath = Locator.SHELL_UPLOAD_FILE)
	public WebElement upLoadFile;

	@FindBy(id = Locator.TRANSACTION_LIST_ACCOUNT)
	public WebElement transactionAccountNumber;	
	
	@FindBy(id = Locator.SEARCH_BTN)
	public WebElement searchButton;   
	
	@FindBy(id = Locator.FROM_DATE)  
	public WebElement fromDate; 
	
	@FindBy(id = Locator.TO_DATE)  
	public WebElement toDate; 
	
	@FindBy(xpath=Locator.ACCOUNT_NUMBER_IN_HOME_PAGE)
	public WebElement accountNumberInHomePage;

	public SHELLHomePage(WebDriver driver, ExtentTest test) {

		super(driver, test);
		PageFactory.initElements(driver, this);

	}

	/*public void selectUserlistFromAdminTab() {

		List<WebElement> headers = driver.findElements(By.xpath("//ul[@id='levelOne']/li/a"));
		List<WebElement> subMs = driver.findElements(By.xpath("//ul[@class='levelTwo']/li/a"));
		

//		mouseHoverClick(headers, subMs, "Admin", "User List");
	}*/


	/*public void selectChangePasswordFromSupportTab() {

		List<WebElement> headers = driver.findElements(By.xpath("//ul[@id='levelOne']/li/a"));
		List<WebElement> subMs = driver.findElements(By.xpath("//ul[@class='levelTwo']/li/a"));

		mouseHoverClick(headers, subMs, "Support", "Change Password");
		
	}*/
	
	public void goToUserProfile() { 
		mouseHoverClickMenuAndSubMenu("Support", "Profile");

	}

	public void ValidatePCShellLogo() {
		isDisplayed(shellHPLogo, "SHELL Logo");
	}

	public void ValidateHeaderMenus(String role) {
		// TODO Auto-generated method stub
		
		checkTextInPageAndValidate("Home", 10);
		checkTextInPageAndValidate("Account", 10);
		checkTextInPageAndValidate("Cards", 10);
		checkTextInPageAndValidate("Transactions", 10);
		//checkTextInPageAndValidate("Reports & Invoices", 10);/* In some countries this is Reports */ 		
		checkTextInPageAndValidate("Support", 10);
		if(role.equals("Admin"))
		{
			checkTextInPageAndValidate("Admin", 10);
		}
	}
	
	public void ValidateFooterMenus() {
		// TODO Auto-generated method stub
		checkTextInPageAndValidate("Home", 5);
		checkTextInPageAndValidate("Contact us", 5);
		checkTextInPageAndValidate("Legal notice", 5);
		checkTextInPageAndValidate("Privacy statement", 5);
		
		sleep(20);
	}
	
	
	public void goToAdminNewUser() { 
		mouseHoverClickMenuAndSubMenu("Admin", "New User");
	}

	public void goToAdminMenuUserList() { 
		mouseHoverClickMenuAndSubMenu("Admin", "User List");
	}
	
	public void goToSupportMenuChangePassword() { 
		mouseHoverClickMenuAndSubMenu("Support", "Change Password");
	}
	
	public void goToSupportMenuContactUs() { 
		mouseHoverClickMenuAndSubMenu("Support", "Contact us");
	}
	
	public void goToSupportMenuProfile() { 
		mouseHoverClickMenuAndSubMenu("Support", "Profile");
	}

	public void validateAdminTabNotDisplayed() {

		checkTextNotInPageAndValidate("Admin", 10);
	}
	
	public void goToCardMenuBulkCardStatus() { 
		mouseHoverClickMenuAndSubMenu("Cards", "Bulk Card Status");
	}
	
	public void goToAccountMenuFundTransfer() { 
		mouseHoverClickMenuAndSubMenu("Account", "Funds Transfer");
	}

	public void goToAccountMenuCustomerMaintenance() { 
		mouseHoverClickMenuAndSubMenu("Account", "Account / Customer Maintenance");
	}
	
	public void goToAccountMenuCardGroups() { 
		mouseHoverClickMenuAndSubMenu("Account", "Card Groups");
	}
	
	public void goToCardMenuCardList() { 
		mouseHoverClickMenuAndSubMenu("Cards", "Card List");
	}
	
	public void goToCardMenuBulkCardUpdate() { 
		mouseHoverClickMenuAndSubMenu("Cards", "Bulk Card Update");
	}
	
	public void selectAccountFromDropdownAndValidate() {
		
		isDisplayed(accountDropdown, "Account Drop down in home page");
		
		int size = getDropdownSize(accountDropdown);
		
		if(size > 1)
		{
			String accountName = selectedStringFrmDropDown(accountDropdown);
			System.out.println("accountNAme ---- "+accountName);
			sleep(5);
			selectDifferentValueInsteadOfDefault(accountDropdown, accountName, "");
			sleep(3);
			String accname2 = selectedStringFrmDropDown(accountDropdown);
			sleep(5);
			if(!accountName.contains(accname2)) {
				logInfo("Account 1 = "+accountName+" Different Account selected ---="+accname2);
				logPass("Different Account Selected");
			} 
			
			else
			{
				logInfo("Account 1 = "+accountName+" Different Account selected ---="+accname2);
				logFail("Different Account is not selected");
			}
		}
		else
		{
			logInfo("accountDropdown in home page has only one option");
		}
	}
	
	public String getDisplayedAccountName() {
		
		String displayedAccount = getText(accountNameDisplayed);
		return displayedAccount;
	}
	
	public String trimAccountName(String accountName)
	{
		String trimAccName ="";
		
		trimAccName = accountName.split("-")[0];
		
		System.out.println("Account Name --- "+trimAccName);
		
		return trimAccName;
	}

	// Added by Ayub on 15.06.2018
	public void goToContactPage() {
		mouseHoverClickMenuAndSubMenu("Account", "Contacts");
		checkTextInPageAndValidate("Contacts List", 20);
		
	}
	
	public void goToAccountMenuDriversPage() {
		mouseHoverClickMenuAndSubMenu("Account", "Drivers");
		checkTextInPageAndValidate("DRIVER LIST", 20);
	}
	
	public void goToAccountMenusVechilesPage() {
		mouseHoverClickMenuAndSubMenu("Account", "Vehicles");
		checkTextInPageAndValidate("VEHICLE LIST", 20);
	}
	
	public void goToSupportMenuCloseAccount() { 
		mouseHoverClickMenuAndSubMenu("Support", "Close Account");
	}
	
	// Added by Ayub 20.06.2018
	
	public void goToCardMenuBulkCardOrder() {
		mouseHoverClickMenuAndSubMenu("Cards", "Bulk Card Order");
	}
	
	public String getCustomerName()
	{
		isDisplayed(accountNameInHomePage, "Account Name In home page");
		String customerAccName = getText(accountNameInHomePage);
		return customerAccName;
	}
	
	public String getCustomerNumber()
	{
		isDisplayed(accountNumberInHomePage, "Account Name In home page");
		String customerAccName = getText(accountNumberInHomePage);
		System.out.println("customerAccName : "+customerAccName);
		String customerNumber = customerAccName.split("[)]")[0];
		customerNumber = (customerNumber.split("[(]")[1]).trim();
		System.out.println("customerAccName : "+customerAccName);
		return customerNumber;
	}
	
	public void verifyCustomerNameInHomePage() {
		String customerNameAndNo = selectedStringFrmDropDown(accountDropdown);
		if (customerNameAndNo.contains(getText(accountNameInHomePage))) {
			logPass("Same account name present in dropdown and details section");
		} else {
			logInfo("Same account name not present in dropdown and details section");
		}
	}

	// Added by Ayub 22.06.2018
	public void goToCardMenuOrderCard() {
		mouseHoverClickMenuAndSubMenu("Cards", "Order Card");
	}

	// Added by Ayub 25.06.2018 

	/**
	 * Added by Suganthi 26.10.2018
	 * For Philippines,Russia and Singapore - Header shows as Reports - Adding this logic as Temporary fix 
	 * @param clientCountryOption
	 */
	public void goToReportsAndInvoiceStoredReports(String clientCountryOption) {
		if(clientCountryOption.equals("PH") || clientCountryOption.equals("SG") || clientCountryOption.equals("RU") ) {
			mouseHoverClickMenuAndSubMenu("Reports", "Stored Reports");
		} else {
			mouseHoverClickMenuAndSubMenu("Reports & Invoices", "Stored Reports");
		}		
	}	

	/**
	 * Added by Suganthi 26.10.2018
	 * For Philippines,Russia and Singapore - Header shows as Reports - Adding this logic as Temporary fix 
	 * @param clientCountryOption
	 */
	public void goToReportsAndInvoiceScheduledReports(String clientCountryOption)
	{
		if(clientCountryOption.equals("PH") || clientCountryOption.equals("SG") || clientCountryOption.equals("RU") ) {
			mouseHoverClickMenuAndSubMenu("Reports", "Scheduled Reports");
		} else {
			mouseHoverClickMenuAndSubMenu("Reports & Invoices", "Scheduled Reports");
		}
	}

	/**
	 * Added by Suganthi 26.10.2018
	 * For Philippines,Russia and Singapore - Header shows as Reports - Adding this logic as Temporary fix 
	 * @param clientCountryOption
	 */
	public void goToReportsAndInvoiceAdhocReports(String clientCountryOption) {

		if(clientCountryOption.equals("PH") || clientCountryOption.equals("SG") || clientCountryOption.equals("RU") ) {
			mouseHoverClickMenuAndSubMenu("Reports", "Reports");
			checkTextInPageAndValidate("REPORT LIST", 20);
		} else {
			mouseHoverClickMenuAndSubMenu("Reports & Invoices", "Reports");
			checkTextInPageAndValidate("REPORT LIST", 20);
		}

	}

	public void goToContactUsPage() {
		scrollDownPage();
		sleep(3);
		isDisplayedThenClick(contactUS, "ContactUS page");
		sleep(3);
    	checkTextInPageAndValidate("CONTACT US", 20);
		checkTextInPageAndValidate("Account Name", 20);
		checkTextInPageAndValidate("Account Number", 20);
		checkTextInPageAndValidate("Select Query Type", 20);
		sleep(2);

	}

	public void validateSelectQueryDropdownValues() {
		// lform:contact_us_selectedQueryType

		String[] expectedQueryDropdownValues = {"--Select One--","General Card","Website Application","Dispute Transaction"};
		List<String> expectedList = new ArrayList<String>();
		for(int i=0;i<expectedQueryDropdownValues.length;i++){
			expectedList.add(expectedQueryDropdownValues[i]);			
		}
		List<String> actualList = new ArrayList<String>();
		List<WebElement> actualQueryDropdownValues=selectDropdownOptionValues(selectQueryTypedropdown);
		for(WebElement actualQueryDropdownValue : actualQueryDropdownValues){
			actualList.add(actualQueryDropdownValue.getText());		
		}  		
		if(expectedList.size()==actualList.size()) {
			for(int i=0;i<expectedList.size();i++) {
				if(expectedList.get(i).equals(actualList.get(i))) {
					System.out.println("Dropdown Values matches with expected "+actualList.get(i));
					logInfo("Dropdown Values matches with expected "+actualList.get(i));
				} else {
					System.out.println("Dropdown Values not matches");
					logInfo("Dropdown Values not matches");
				}
			}
		} else {
			System.out.println("Drop down values are not same in number");
			logInfo("Drop down values are not same in number");
		}
		}

		/*	Select dropdown = new Select(selectQueryTypedropdown);
		// Get all options
		List<WebElement> dd = dropdown.getOptions();
		// Get the length
		System.out.println(dd.size());

		for (int j = 0; j < dd.size(); j++) {
			System.out.println(dd.get(j).getText());
		}
       sleep(2);
	}*/

	public void clickOnOrderNewCardQuickLinkAndValidatePage() {
		isDisplayedThenClick(orderNewCardQuickLink, "Order New Card Link");
		checkTextInPageAndValidate("ORDER NEW CARD", 10);
		checkTextInPageAndValidate("Card Offer", 10);
		checkTextInPageAndValidate("Card Details", 10);
		checkTextInPageAndValidate("Velocity Limits", 10);
		checkTextInPageAndValidate("Delivery Address", 10);
		sleep(2);
		isDisplayedThenClick(homeMenu, " Home Menu");
		sleep(2);
	}

	public void clickOnchangeCardStatusQuickLinkAndValidatePage() {
		isDisplayedThenClick(changeCardStatusQuickLink, "Order New Card Link");
		checkTextInPageAndValidate("CARD LIST", 10);
		checkTextInPageAndValidate("Use filter fields to narrow search.", 10);
		checkTextInPageAndValidate("List of Cards found", 10);
		isDisplayedThenClick(homeMenu, " Home Menu");
		sleep(2);
	}

	public void clickOnCardListQuickLinkAndValidatePage() {
		isDisplayedThenClick(cardListQuickLink, "Card list link");
		checkTextInPageAndValidate("CARD LIST", 10);
		checkTextInPageAndValidate("Use filter fields to narrow search.", 10);
		checkTextInPageAndValidate("List of Cards found", 10);
		isDisplayedThenClick(homeMenu, " Home Menu");
		sleep(2);
	}

	public void clickOntranscationQuickLinkAndValidatePage() {
		isDisplayedThenClick(transcationListQuickLink, "Transcation link");
		checkTextInPageAndValidate("TRANSACTION LIST", 10);
		checkTextInPageAndValidate("Use filter fields to narrow search.", 10);
		isDisplayedThenClick(homeMenu, " Home Menu");
		sleep(2);
	}
	
	public void clickOnExportTranscationQuickLink() {
		isDisplayedThenClick(exportTranscationQuickLink, "Export Transcation link");
		sleep(2);
	}
	
	public void selectTopUserDropdownAndChangePwdValidate() {
		isDisplayedThenClick(topUserName, "Click Top UserName dropdown button");
		isDisplayedThenClick(changePasswordFromUserNameDD, "Click Change Password");
		sleep(3);
		verifyText(pageTitle, "PASSWORD MAINTENANCE");
//		checkTextInPageAndValidate("Password Maintenance", 20);	
	}
	
	/*
	 * Page will be redirected to appended href links
	 * Added "contains" methods for asserting
	*/
	
	public void clickHelpLinkAndValidateRedirection() {
//		String getLink = helpLink.getAttribute("href").split(":")[1];
		validateClickableLinkRedirectionContains(helpLink, "shell");
	}
	
	public boolean validateActiveOrBlockedAccount() {
		if(getDisplayedAccountName().contains("Blocked")) {
			
		}
		return false;
	}
	
	public void selectDisplayLanguageFromDropdown() {
		isDisplayed(displayLanguage, "Display language dropdown is displayed");
		selectDropDownOptionsRandomly(displayLanguage, "Choose language dropdown");
		sleep(3);
	}
	
	public void validateAccountDetailsAtTopCorner() {
		
		String accountName = getText(accountNameInHomePage);
		sleep(3);
		String accountStatus = getText(accountStatusInHomePage);
		if(accountName.contains(getDisplayedAccountName()) && accountStatus.contains(getDisplayedAccountName())) {
			logPass("Account Details verified");
		} else {
			logInfo("Account details Incorrect");
		}
	}
	public void clickShellHomePageAndValidate() {
		isDisplayedThenActionClick(homePageShell, "Click Home Page");
		sleep(3);
		checkTextInPageAndValidate("Quick links", 20);
	}
	public void validateUploadButton() {
		isDisplayed(upLoadButton, "Upload Button");
	}
	// Added by Ayub on 28.06.2018 
	/**
	 * Added by Suganthi 26.10.2018
	 * For Philippines,Russia and Singapore - Header shows as Reports - Adding this logic as Temporary fix 
	 * @param clientCountryOption
	 */
	public void goToReportsAndInvoiceReports(String clientCountryOption)
	{
		if(clientCountryOption.equals("PH") || clientCountryOption.equals("SG") || clientCountryOption.equals("RU") ) {
			mouseHoverClickMenuAndSubMenu("Reports", "Invoices");
			sleep(2);
		} else {
			mouseHoverClickMenuAndSubMenu("Reports & Invoices", "Invoices");
			sleep(2);
		}
	}
	
	public String getAccountStatus()
	{
		return getText(accountStatusInHomePage);
	}

	/*
	 * Click Transactions Export transactions
	 * 
	 */
	
	public void clickTransactionsExportTransactioins() {
		
		mouseHoverClickMenuAndSubMenu("Transactions", "Export Transactions");
		
		sleep(5);
		
	}
	
	/*
	 * Click Transactions Transaction List
	 * 
	 */
	public void clickTransactionsTransactionList() {
		
		mouseHoverClickMenuAndSubMenu("Transactions", "Transaction List");
		
	}
	
	public void clickTransactionsMenuTransactionListAndValidate() {
		
		mouseHoverClickMenuAndSubMenu("Transactions", "Transaction List");
		checkTextInPageAndValidate("TRANSACTION LIST", 10);

	}

	public void selectAccountAndSearch() {

		selectDropDownByVisibleText(transactionAccountNumber,"All Accounts");
		enterText(fromDate,"31/10/2017");
		isDisplayedThenActionClick(searchButton, "Click search button");
		sleep(5);
		scrollDownPage();

	}

	// Added by Meenakshi on 29.06.2018
	public void validateClickFooterLinksAndRedirection() {
	
		goToContactUsPage();
		scrollDownPage();
		isDisplayedThenActionClick(footerHomeLink, "Click Home Footer Link");
		sleep(5);
		
		isDisplayed(QuickLinks, "Quick links Displayed");
//		checkTextInPageAndValidate("Quick Links", 20);
		scrollDownPage();
//		String getLegalNoticeLink = footerLegalNoticeLink.getAttribute("href").split(":")[1];
//		validateClickableLinkRedirection(footerLegalNoticeLink, getLegalNoticeLink);
		validateClickableLinkRedirectionContains(footerLegalNoticeLink, "shell");
		sleep(5);
//		String getPrivateStatementLink = footerPrivateStatementLink.getAttribute("href").split(":")[1];
//		validateClickableLinkRedirection(footerPrivateStatementLink, getPrivateStatementLink);
		validateClickableLinkRedirectionContains(footerPrivateStatementLink, "shell");
	}
	
	public void clickExportHierarchyButton() {
		
		isDisplayedThenActionClick(exportAccountHierarchyButton, "Click Export Hierarchy Button");
	}
	
	public void goToCardMenuReissueControl() { 
		mouseHoverClickMenuAndSubMenu("Cards", "Reissue Control");
	}

	public void validateReissueCard() {
		isDisplayed(bulkReissueTable, "Bulk Reissue table data displayed");
	}

	// Added by Ayub on 29.06.2018 and updated on 12-07-2018
	
		public void uploadFileAndClearAll(String text) {
			isDisplayedThenClick(upLoadButton, "Upload Button");
			sleep(5);
			
			mouseHover(browseFile);
			isDisplayedThenActionClick(browseFile, "Browse File");
			sleep(3);
			uploadTheExcelSheetFromTheLocal(text);
			sleep(15);
			isDisplayedThenActionClick(upLoadFile, "Up Load File");
			sleep(15);
			isDisplayedThenClick(upLoadButton, "Upload Button");
			sleep(5);
			isDisplayedThenActionClick(clearAll, "Clear All");
			sleep(10);
			isDisplayedThenActionClick(closePopUp, "Close the popup");
			sleep(10);
			
		}
		
		public void validateUploadFileAndGetFileName() {
			checkTextInPageAndValidate("Java", 20);
		}
		
		
		public void uploadFileAndGetFileName(String text) {
			isDisplayedThenClick(upLoadButton, "Upload Button");
			sleep(5);		
			mouseHover(browseFile);
			isDisplayedThenActionClick(browseFile, "Browse File");
			sleep(3);
			uploadTheExcelSheetFromTheLocal(text);
			sleep(15);
			isDisplayedThenActionClick(upLoadFile, "Up Load File");
			sleep(15);
			//isDisplayedThenActionClick(closePopUp, "Close the popup");
	        //sleep(10);
			checkTextInPageAndValidate(text, 20);
		
		}
		public void verifyLanguageDropdown() {
			isDisplayed(languagedrop,"Dropdown Language is displayed ");
		    selectDropDownByVisibleText(languagedrop,"русский (Russian)");
			//selectDropDownByIndex(languagedrop,27);
			verifyText(RussianUsernameLabel,"Идентификатор пользователя");
			verifyText(RussianPasswordLabel,"Пароль");
			logPass("Russian language is selected and verified the Labels");
			//selectDropDownByIndex(languagedrop,3);
		    selectDropDownByVisibleText(languagedrop,"English (Malaysia)");
			verifyText(MalaysiaUsernameLabel,"User ID");
			verifyText(MalaysiaPasswordLabel,"Password");
			logPass("English language is selected and verified the Labels");

			}
	
	
}
