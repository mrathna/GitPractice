using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using Common;
using Common.PageObjects;
using Common.ScenarioConfigurations;
using Common.Utility;

namespace EnCompass.Testing.Source.PageObjects.Organization.Admin.MccGroupProfiles 
{
	/// <summary>
	/// Auto-generated Page Model Class
	/// Navigation Paths: 
		/// [Organization Home]->Administration->Merchant Category Codes->Profiles by Card
		/// </summary>
	[PageModel(@"/admin/mccGroupProfiles/Cards.aspx")]
	public partial class Cards : EnCompassOrgPageModel 
	{
		public override string RelativeUrl => @"/admin/mccGroupProfiles/Cards.aspx";
		public override string PageIdentifierXPath_Generated => @"//li[contains(@class, 'breadcrumb-item active')][text() = 'Assign Profiles to Card']";

		#region Navigation
				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Groups']")]
		private IWebElement _administration_MerchantCategoryCodes_ProfilesByCard_Groups { get; set; }
		public void NavigateTo_Administration_MerchantCategoryCodes_ProfilesByCard_Groups()
		{
			NavigateToMenuItem(_administration_MerchantCategoryCodes_ProfilesByCard_Groups);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Profiles']")]
		private IWebElement _administration_MerchantCategoryCodes_ProfilesByCard_Profiles { get; set; }
		public void NavigateTo_Administration_MerchantCategoryCodes_ProfilesByCard_Profiles()
		{
			NavigateToMenuItem(_administration_MerchantCategoryCodes_ProfilesByCard_Profiles);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Hierarchy']")]
		private IWebElement _administration_MerchantCategoryCodes_ProfilesByCard_Hierarchy { get; set; }
		public void NavigateTo_Administration_MerchantCategoryCodes_ProfilesByCard_Hierarchy()
		{
			NavigateToMenuItem(_administration_MerchantCategoryCodes_ProfilesByCard_Hierarchy);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Profiles by Card']")]
		private IWebElement _administration_MerchantCategoryCodes_ProfilesByCard_ProfilesByCard { get; set; }
		public void NavigateTo_Administration_MerchantCategoryCodes_ProfilesByCard_ProfilesByCard()
		{
			NavigateToMenuItem(_administration_MerchantCategoryCodes_ProfilesByCard_ProfilesByCard);
		}

		
		private void NavigateToMenuItem(IWebElement element)
		{
			Driver.Url = element.GetAttribute("href");
		}
		#endregion

		public Cards(GlobalSettings settings) : base(settings) { }
	}  
}
