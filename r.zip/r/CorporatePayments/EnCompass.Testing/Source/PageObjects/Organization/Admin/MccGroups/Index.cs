﻿using EnCompass.Testing.Source.PageObjects.Controls;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Support.UI;
using Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Common.Utility;
using NFluent;

namespace EnCompass.Testing.Source.PageObjects.Organization.Admin.MccGroups
{
    public partial class Index
    {
		private static string _createBtn = ".//a[@role='button' and normalize-space(text())='Create']";

		public void CreateMccg()
		{
			Driver.WaitElementBeClickable(_createBtn);
			Driver.FindElement(By.XPath(_createBtn)).JSClickWithFocus(Driver);
			Settings.EnCompassExtentTest.Info("Clicked on Create MCCG Button");
		}

		private GridControl _MccgsGrid;
        public GridControl MccgsGrid
        {
            get
            {
                var grid = _MccgsGrid ?? (_MccgsGrid = new GridControl("dgListing", Driver));
                grid.WaitForGrid();
                return grid;
            }
        }

        public bool GetIfMCCGIsOnList(string mccgName)
        {
            MccgsGrid.WaitForGrid();
            var Mccg = _MccgsGrid.GetColumnText("TSYS Name");
            if (!Mccg.Contains(mccgName))
            {
                return false;
            }

            return true;
        }
    }
}
