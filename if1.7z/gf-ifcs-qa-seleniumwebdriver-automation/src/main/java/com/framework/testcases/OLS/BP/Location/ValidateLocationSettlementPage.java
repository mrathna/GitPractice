package com.framework.testcases.OLS.BP.Location;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.BP.BPHomePage;
import com.framework.pages.BP.LocationSettlementPage;
import com.framework.pages.OLS.common.LoginPage;

public class ValidateLocationSettlementPage extends BaseTest {
	@Parameters({"clientCountry", "clientName"})
	@Test( groups = { "Smoke", "Regression" })
	public void merchentSettlement(@Optional("AU") String clientCountry, @Optional("BP") String clientName)  {
		test = extent.createTest(clientName+ ":" +clientCountry+"  BP Location Settlement Validation", "Checking BP Merchant Settlement Feature");

		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		BPHomePage bpHomePage = new BPHomePage(driver, test);
		LocationSettlementPage LSettlementPage = new LocationSettlementPage(driver, test);

		// Call Function
		loginPage.Login("BP_URL", "BP_UN_Location_" + clientCountry, "BP_PWD_Location_" + clientCountry, clientName);
		bpHomePage.ValidateMerchantLogo();

		// Select input values from Account drop down
		//bpHomePage.selectInputFromAccountDropdown("BP Kewdale Terminal T/S  (00002498)");

		// Select settlement from transaction menu
		bpHomePage.clickSettlementSubMenuAndValidatePage();

		// findsettlementDetailsForMerchent
		LSettlementPage.findsettlementDetailsForLocation(clientCountry);
		LSettlementPage.clicksettlementList();
		LSettlementPage.clickBackToSettlementList();
		LSettlementPage.clickExportExcel("tableSettLementsList");
		
		loginPage.Logout();
	}
	
}
