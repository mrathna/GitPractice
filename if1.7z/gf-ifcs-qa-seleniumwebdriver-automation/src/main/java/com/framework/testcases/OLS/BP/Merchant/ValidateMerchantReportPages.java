package com.framework.testcases.OLS.BP.Merchant;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;


import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.common.Common;
import com.framework.pages.BP.BPHomePage;
import com.framework.pages.OLS.common.LoginPage;
import com.framework.pages.OLS.common.MerchantReportsPage;

public class ValidateMerchantReportPages extends BaseTest {
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "Smoke", "Regression" })
	public void validate_Adhoc_Report_Page(@Optional("AU") String clientCountry, @Optional("BP") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  BP Merchant Report Page", "Checking the Report Pages");

		// Creating Objects for the Login Pages
		LoginPage loginPage = new LoginPage(driver, test);
		BPHomePage bpHomePage = new BPHomePage(driver, test);
		loginPage.Login("BP_URL", "BP_UN_Merchant_" + clientCountry, "BP_PWD_Merchant_" + clientCountry, clientName);
		bpHomePage.ValidateMerchantLogo();

		// Creating Objects for the Pages
		MerchantReportsPage merchantReportsPage = new MerchantReportsPage(driver, test);

		// Validate Adhoc Report Page
		merchantReportsPage.clickAdhocReportPageAndValidate();
		merchantReportsPage.clickAdhocExportLinkBtn("avaliableReport");

		// Validate Stored Report Page
		merchantReportsPage.clickStoredReportPageAndValidate();
		merchantReportsPage.clickStoredReportSearchBtn();
	    merchantReportsPage.clickStoredReportExportLinkBtn("tableStoredRepList");

		// Validate Invoices Report Page
		merchantReportsPage.clickInvoiceReportPageAndValidate();
		merchantReportsPage.clickInvoiceReportSearchBtn();
		merchantReportsPage.clickInvoiceReportExportLinkBtn("tableStoredRepList");

		// Validate Statements Report Page
		merchantReportsPage.clickStatementPageAndValidate();
		 merchantReportsPage.validateStoredReportHeader();

		// Validate Calendar Control
		merchantReportsPage.selectCreatedFromDateUsingCalendarControl();
		merchantReportsPage.clickMercStatementPageSearchBtn();
		merchantReportsPage.clickStatementPageExportLinkBtn("tableStoredRepList");

		loginPage.Logout();

	}

	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "Smoke", "Regression","BusinessFlow" })
	public void validate_Invoice_Report_Page(@Optional("AU") String clientCountry, @Optional("BP") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  BP Merchant Invoice Report Page", "Checking the Invoice Report Pages");

		// Creating Objects for the Login Pages
		LoginPage loginPage = new LoginPage(driver, test);
		BPHomePage bpHomePage = new BPHomePage(driver, test);
		loginPage.Login("BP_URL", "BP_UN_Merchant_" + clientCountry, "BP_PWD_Merchant_" + clientCountry, clientName);
		bpHomePage.ValidateMerchantLogo();

		// Creating Objects for the Pages
		MerchantReportsPage merchantReportsPage = new MerchantReportsPage(driver, test);

		/*
		 * Selected Account only contains Invoices also dependent towards // IFCS
		 * Desktop
		 */
    	//merchantReportsPage.selectStaticAccount();
		merchantReportsPage.clickInvoiceReportPageAndValidate();
		merchantReportsPage.clickInvoiceReportSearchBtn();
		merchantReportsPage.validateInvoiceSearchRecords();

		// Select Date Range and validate search
		merchantReportsPage.selectCreatedFromDateUsingCalendarControl();
		merchantReportsPage.selectCreatedToDateUsingCalendarControl();
		merchantReportsPage.clickInvoiceReportSearchBtn();
		merchantReportsPage.validateInvoiceSearchRecords();

		
		  //Click Export Button & Partially Completed due to Windows handle Pop-up
		 
		merchantReportsPage.clickInvoiceReportExportLinkBtn("tableStoredRepList");

		// Click logout button
		loginPage.Logout();
	}
	
	 //**** This case requires email-id and encoded password ****//
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "Smoke", "Regression" })
	public void validateMerchantReconciliationReport(@Optional("NZ") String clientCountry, @Optional("BP") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  BP Merchant Reconciliation Report Page", "Checking the Report Pages");
		// Creating Objects for the Login Pages
		LoginPage loginPage = new LoginPage(driver, test);
		BPHomePage bpHomePage = new BPHomePage(driver, test);
		Common common = new Common(driver,test);
        MerchantReportsPage merchantReportsPage = new MerchantReportsPage(driver, test);
        loginPage.Login("BP_URL", "BP_UN_Merchant_" + clientCountry, "BP_PWD_Merchant_" + clientCountry, clientName);
		bpHomePage.ValidateMerchantLogo();
        merchantReportsPage.clickAdhocReportPageAndValidate();
        merchantReportsPage.clickMerchantReconciliationReport();
        String dateFrom = common.getCurrentDate();
        String dateTo = common.getFutureDate(90);
        merchantReportsPage.enterFromAndToDates(dateFrom,dateTo);
        merchantReportsPage.enterDeliveryMailAdressAndClickGenerateButton("srilatha.nerella@wexinc.com");
        String subjectContains[] = {"Merchant Reconciliation Report",common.getCurrentUTCTime()};
        //**** Provide your email id and encoded password below before execution ****//
        merchantReportsPage.loginToGmail("","");
        merchantReportsPage.clickOnGeneratedEmailMerchatReconciliationReport(subjectContains);
		loginPage.Logout();
	}

}
