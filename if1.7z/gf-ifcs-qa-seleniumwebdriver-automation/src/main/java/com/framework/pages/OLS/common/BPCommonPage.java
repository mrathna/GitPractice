package com.framework.pages.OLS.common;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.ExtentTest;
import com.framework.basepage.BasePage;
import com.framework.repo.Locator;
import com.framework.util.PropUtils;

//Added by Anton 07.05.2018. 

public class BPCommonPage extends BasePage {

	String accountName;

	@FindBy(how = How.ID, using = Locator.ACCOUNTS_DROPDOWN)
	public WebElement accountsDropDown;

	@FindBy(id = Locator.PHYSICAL_ADDRESS)
	public WebElement physicalAddress;

	@FindBy(id = Locator.MERCHANT_POSTAL_CONTACT_MAILING_ADDRESS)
	public WebElement postalAddress;

	@FindBy(id = Locator.PHYSICAL_SUBURB)
	public WebElement physicalSuburb;

	@FindBy(id = Locator.MERCHANT_POSTAL_CONTACT_MAILING_SUBURB)
	public WebElement postalSuburb;

	@FindBy(id = Locator.POSTALCODE)
	public WebElement postalCodePhy;

	@FindBy(id = Locator.MERCHANT_POSTAL_CONTACT_MAILING_POSTALCODE)
	public WebElement postalCodeMailing;

	@FindBy(id = Locator.STATE_PHY)
	public WebElement statePhy;

	@FindBy(id = Locator.MERCHANT_POSTAL_CONTACT_MAILING_SATE)
	public WebElement stateMailing;

	@FindBy(id = Locator.CONTACT_NAME)
	public WebElement contactName;

	@FindBy(id = Locator.EMAIL_FIELD)
	public WebElement emailLocation;

	@FindBy(id = Locator.JOBTITLE_FIELD)
	public WebElement jobTitle;

	@FindBy(id = Locator.PHONE_FIELD)
	public WebElement phone;

	@FindBy(id = Locator.MOBILE_FIELD)
	public WebElement mobile;

	@FindBy(id = Locator.FAX_FIELD)
	public WebElement fax;

	@FindBy(how = How.ID, using = Locator.MERCHANT_PHYSICAL_COUNTRY)
	public WebElement physicalCountry;

	@FindBy(how = How.ID, using = Locator.MERCHANT_POSTAL_COUNTRY)
	public WebElement postalCountry;

	@FindBy(id = Locator.ACCOUNT_SEL)
	public WebElement accountDropdown;
	
	@FindBy(id = Locator.ACCTDETAIL_LEFT_HEADER)
	public WebElement accountdetails;
	
	@FindBy(id = Locator.CUS_NUM)
	public WebElement customernumber;
	
	@FindBy(how = How.XPATH, using = Locator.HOME_MENU)
	public WebElement HomeMenu;

	public BPCommonPage(WebDriver driver, ExtentTest test) {
		super(driver, test);
		PageFactory.initElements(driver, this);
		// TODO Auto-generated constructor stub
	}

	public String selectAccount() {
		isDisplayed(accountsDropDown, "Selected input from Accounts dropdown");
		selectInputFromDropdown(accountsDropDown, 1);
		sleep(5);
		accountName = selectedStringFrmDropDown(accountsDropDown);
		return accountName;
	}
	public void selectStaticAccount() {

		selectDropDownByVisibleText(accountsDropDown, "ATS ACCOUNTANTS  (2116160304)");
		sleep(3);

	}

	
	public void selectAllaccountsOption() {
		isDisplayed(accountsDropDown, "Selected input from Accounts dropdown");
		selectDropDownByVisibleText(accountsDropDown,"All Accounts");
		
	}
	

	public String selectPhysicalState() {
		isDisplayed(statePhy, "Select option from state from physical address");
		selectInputFromDropdown(statePhy, 1);
		sleep(5);
		String stateName = selectedStringFrmDropDown(statePhy);
		return stateName;
	}

	public String selectPostalState() {
		isDisplayed(stateMailing, "Select option from state from physical address");
		selectInputFromDropdown(stateMailing, 1);
		sleep(5);
		String stateName = selectedStringFrmDropDown(stateMailing);
		return stateName;
	}

	public String selectPhysicalCountry() {
		isDisplayed(physicalCountry, "Select option from country from physical address");
		selectInputFromDropdown(physicalCountry, 1);
		sleep(5);
		String countryName = selectedStringFrmDropDown(physicalCountry);
		return countryName;
	}

	public String selectPostalCountry() {
		isDisplayed(postalCountry, "Select option from country from physical address");
		selectInputFromDropdown(postalCountry, 1);
		sleep(5);
		String countryName = selectedStringFrmDropDown(postalCountry);
		return countryName;
	}

	public void selectAllAccountFromAccountField() {
		selectDropDownByVisibleText(accountDropdown, "All Accounts");
		sleep(3);
	}
	public String getAccountNumber() {
		isDisplayedThenClick(accountdetails, "Accounts details Link");
		sleep(5);
		String accountNumber = getText(customernumber);
		return accountNumber;
		}
	
	/*Prakalpha -->11/08/2019
	 * get Prepaid card Number	  
	 */
	public String getBPPrepaidCard(String cardStatus) {
		
		String getBPPrepaidCardNo = "select c.card_no from cards c inner join m_customers mc on mc.customer_mid = c.customer_mid inner join card_programs cp on cp.card_program_oid=mc.card_program_oid INNER JOIN CARD_STATUS cs on c.CARD_STATUS_OID = cs.CARD_STATUS_OID and mc.customer_mid NOT IN (select member_oid from relationships) and c.replace_card_oid IS NULL and cp.description = 'BP PrePay Cards' and cs.DESCRIPTION = '"+cardStatus+"' and Rownum <=1";
		String prepaidCardNo = connectDBAndGetValue(getBPPrepaidCardNo,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
        System.out.println("prepaidCardNo ::"+prepaidCardNo);
		return prepaidCardNo;
	}

public String getBPPrepaidCardGoingToExpire(String currentIFCSDate) {
		String expectedDateValue="";
		try {
		
		DateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
		dateFormatter.parse(currentIFCSDate);
		Date newDate;
		Calendar cal = Calendar.getInstance();
		cal.setTime(dateFormatter.parse(currentIFCSDate));
		cal.add(Calendar.MONTH, +3);
		newDate = cal.getTime();
		DateFormat df = new SimpleDateFormat("dd-MMM-yy");
		expectedDateValue = df.format(newDate).toUpperCase();
		System.out.println("expectedDateValue::"+expectedDateValue);
		} catch (ParseException e) {

			e.printStackTrace();
		}
		
		String getBPPrepaidActiveCardNo = "select c.card_no from cards c inner join m_customers mc on mc.customer_mid = c.customer_mid inner join card_programs cp on cp.card_program_oid=mc.card_program_oid INNER JOIN CARD_STATUS cs on c.CARD_STATUS_OID = cs.CARD_STATUS_OID and mc.customer_mid NOT IN (select member_oid from relationships) and c.replace_card_oid IS NULL and cp.description = 'BP PrePay Cards' and cs.DESCRIPTION = '100 Normal Service' and c.expires_on between '"+currentIFCSDate+"' and '"+expectedDateValue+"'";
		String prepaidCardNoGonnaExpired = connectDBAndGetValue(getBPPrepaidActiveCardNo,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));

		return prepaidCardNoGonnaExpired;
	}
public String getBPPrepaidCustomer(String cardStatus) {
		
		String getBPPrepaidCardNo = "select customer_no from cards c inner join m_customers mc on mc.customer_mid = c.customer_mid inner join card_programs cp on cp.card_program_oid=mc.card_program_oid INNER JOIN CARD_STATUS cs on c.CARD_STATUS_OID = cs.CARD_STATUS_OID and mc.customer_mid NOT IN (select member_oid from relationships) and c.replace_card_oid IS NULL and cp.description = 'BP PrePay Cards' and cs.DESCRIPTION = '"+cardStatus+"' and Rownum <=1";
		String prepaidCardNo = connectDBAndGetValue(getBPPrepaidCardNo,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
        System.out.println("prepaidCardNo ::"+prepaidCardNo);
		return prepaidCardNo;
	}
	
	/*Prakalpha -->11/08/2019
	 * get Prepaid card Number	  
	 */
	public String getActiveBPPrepaidCard() {
		
		String getBPPrepaidCardNo = "select c.card_no from cards c inner join m_customers mc on mc.customer_mid = c.customer_mid inner join card_programs cp on cp.card_program_oid=mc.card_program_oid INNER JOIN CARD_STATUS cs on c.CARD_STATUS_OID = cs.CARD_STATUS_OID and mc.customer_mid NOT IN (select member_oid from relationships) and c.replace_card_oid IS NULL and cp.description = 'BP PrePay Cards' and cs.DESCRIPTION = '100 Normal Service' and Rownum <=1";
		String prepaidCardNo = connectDBAndGetValue(getBPPrepaidCardNo,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));

		return prepaidCardNo;
	}
	
	public void clickHomeMenu() {
		sleep(3);
		isDisplayedThenClick(HomeMenu, "Home Page Menu");
		sleep(5);
	}
	
	
	public String selectAccountRandomly() {
		isDisplayed(accountsDropDown, "Selected input from Accounts dropdown");
		selectDropDownOptionsRandomly(accountsDropDown, "Selected");
		sleep(5);
		accountName = getAccountNumber();
		return accountName;
	}
	
}
