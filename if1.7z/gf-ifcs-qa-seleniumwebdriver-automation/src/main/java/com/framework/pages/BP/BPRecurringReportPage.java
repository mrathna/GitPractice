package com.framework.pages.BP;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.ExtentTest;
import com.framework.basepage.BasePage;
import com.framework.pages.OLS.common.BPCommonPage;
import com.framework.pages.OLS.common.PastReportsPage;
import com.framework.repo.Locator;

public class BPRecurringReportPage extends BasePage {

	@FindBy(id = Locator.RECURRING_REPORT_TABLE)
	public WebElement recurringReportTable;

	@FindBy(id = Locator.FIRST_EDIT_RECURRING_REPORT_BUTTON)
	public WebElement firstRecurringReportBTN;

	@FindBy(xpath = Locator.DOWNLOAD_LATEST_COPY_OF_REPORT)
	public WebElement downloadLatestCopyRecurringReport;

	@FindBy(xpath = Locator.EDIT_OPTION_OF_REPORT)
	public WebElement editOptionInReport;

	@FindBy(xpath = Locator.SCHEDULE_FREQUENCY_DROPDOWN)
	public WebElement scheduleFreqReport;

	@FindBy(id = Locator.RUN_REPORT_BUTTON)
	public WebElement updateRecurrReportBTN;

	@FindBy(id = Locator.SEND_EMAIL_TEXT_RB)
	public WebElement sendEmailTextRb;

	@FindBy(id = Locator.CONTACT_TEXT)
	public WebElement sendEmailTextBox;

	@FindBy(id = Locator.PAST_REPORTS)
	public WebElement pastReports;

	@FindBy(how = How.ID, using = Locator.REPORTS_MENU)
	public WebElement selectReportMenu;

	@FindBy(id = Locator.PAST_REPORTS)
	public WebElement pastReportsSM;

	@FindBy(how = How.ID, using = Locator.PAGE_TITLE)
	public WebElement pageTitleText;

	@FindBy(id = Locator.FIRST_VIEW_ALL)
	public WebElement firstViewAll;

	@FindBy(id = Locator.ACTIVE_RB)
	public WebElement recurringReportsActiveRadioButton;

	@FindBy(id = Locator.RETURN_PAST_REPORT_BUTTON)
	public WebElement returnPastReportBTN;

	@FindBy(xpath = Locator.EDIT_RECURRING_REPORTS_DTLS)
	public WebElement editRecurringReportsBTN;

	@FindBy(how = How.ID, using = Locator.ACCOUNTS_DROPDOWN)
	public WebElement accountsDropDown;

	@FindBy(id = Locator.RUN_REPORT_BUTTON)
	public WebElement createNewRecurringReport;

	@FindBy(how = How.XPATH, using = Locator.VIEW_ALL_IN_RECURRING_REPORT_TABLE)
	public List<WebElement> viewAll;

	@FindBy(css = Locator.RECURRING_REPORTS)
	public List<WebElement> recurringReports;

	@FindBy(css = Locator.RADIO_BUTTON_FILTER_IN_RECURRING_REPORTS)
	public List<WebElement> radioButtonFilterInRecurringReports;
	
	@FindBy(xpath=Locator.DELETE_REPORT_POPUP)
	public WebElement deletePopup;
	
	@FindBy(id=Locator.DELETE_BUTTON)
	public WebElement deleteButton;
	

	BPCommonPage bpCommonPage = new BPCommonPage(driver, test);
	private String accountname = "";
	private String expAccount = "";
	private int rowCount = 0, rowCountHold = 0;
	private int reportNumber;

	public BPRecurringReportPage(WebDriver driver, ExtentTest test) {
		super(driver, test);
		PageFactory.initElements(driver, this);
	}

	PastReportsPage pastReportPage = new PastReportsPage(driver, test);

	public void verifyTheRecurringReportsArePresentAndEdit() {
		// TODO Auto-generated method stub

		isDisplayed(recurringReportTable, "Recurring Reports Table");

		boolean noReports = waitForTextToAppear("There are no reports setup under your User ID.", 10);

		if (noReports) {
			logInfo("There are no recurring reports present, So We can not edit the recurring reports");
		}

		else {
			isDisplayedThenClick(firstRecurringReportBTN, "Edit the Recurring report");

			sleep(5);

			checkTextInPageAndValidate("Edit a Recurring Report", 10);

			scrollDownPage();

			isDisplayed(scheduleFreqReport, "Frequency of the Report");

			String defaultText = selectedStringFrmDropDown(scheduleFreqReport);

			selectDifferentValueInsteadOfDefault(scheduleFreqReport, defaultText, "(Select frequency)");

			sleep(5);

			String afterSelectText = selectedStringFrmDropDown(scheduleFreqReport);

			verifyTheSelectedFrequency(defaultText, afterSelectText);

			selectDeleiveryEmail();

			// Executing persons mail need to be added here
			String email = "nithya@sirahu.com";

			isDisplayedThenEnterText(sendEmailTextBox, "Email the Report Textbox", email);

			sleep(3);

			isDisplayedThenClick(updateRecurrReportBTN, "Update Recurring Report Button");

			sleep(5);

			checkTextInPageAndValidate("Success!  Your Recurring Report has been updated.", 10);

			validateTheNavOfPastReportsSubMenu();

			VerifyTheEditedReportInPastReports(afterSelectText, email);
		}

	}

	public void verifyTheRecurringReportsArePresentAndDownloadLatestCopy() {
		//isDisplayed(recurringReportTable, "Recurring Reports Table");
		
		boolean noReports = waitForTextToAppear("You have no Recurring Reports scheduled.", 10);

		if (noReports) {
			logInfo("There are no recurring reports present, So We can not edit the recurring reports");
		}

		else {
			setCellDataFromTable(recurringReportTable, 7, true);
			int recurringTableSize = getRowSize(recurringReportTable);
			for (int i = 1; i < recurringTableSize - 1; i++) {
				if (Integer.parseInt(getCellDataFromTable(i, 5, true)) > 0) {
					isDisplayedThenClick(recurringReports.get(i - 1), "Recurring report");
					sleep(3);
					isDisplayedThenClick(downloadLatestCopyRecurringReport, "Download the Recurring report");
					sleep(3);
					pastReportPage.checkReportAvailability();
				}
			}
		}
	}

	public void verifyTheListedReportsStatus(String expectedStatus) {

		//isDisplayed(recurringReportTable, "Recurring Reports Table");
		//There are no reports setup under your User ID. - Previous Message
		boolean noReports = waitForTextToAppear("You have no Recurring Reports scheduled.", 10);

		if (noReports) {
			logInfo("There are no recurring reports present, So We can not edit the recurring reports");
		}

		else {
			setCellDataFromTable(recurringReportTable, 7, true);
			int recurringTableSize = getRowSize(recurringReportTable);
			for (int i = 1; i < recurringTableSize - 1; i++) {
				if (getCellDataFromTable(i, 4, true).toLowerCase().contains(expectedStatus.toLowerCase())) {
					logPass("Expected report status present");
				} else {
					logFail("Expected report status not present Expected Status ::" + expectedStatus + " Row ::" + i
							+ " Actual Status ::" + getCellDataFromTable(i, 4, true));
				}
			}
		}
	}

	public void verifyTheListedOptionsInRecurringReport() {

		//isDisplayed(recurringReportTable, "Recurring Reports Table");
        //There are no reports setup under your User ID. - Previous Message
		boolean noReports = waitForTextToAppear("You have no Recurring Reports scheduled.", 10);

		if (noReports) {
			logInfo("There are no recurring reports present, So We can not edit the recurring reports");
		}

		else {
			setCellDataFromTable(recurringReportTable, 7, true);
			int recurringTableSize = getRowSize(recurringReportTable);
			for (int i = 1; i < recurringTableSize - 1; i++) {
				isDisplayedThenClick(recurringReports.get(i - 1), "Recurring report to maximize the dropdown");
				sleep(4);
				if (Integer.parseInt(getCellDataFromTable(i, 5, true)) > 0) {
					isDisplayed(downloadLatestCopyRecurringReport, "Download the Recurring report");
					isDisplayed(editOptionInReport, "Edit the Recurring report");
				} else {
					isDisplayed(editOptionInReport, "Edit the Recurring report");
				}
				isDisplayedThenClick(recurringReports.get(i - 1), "Recurring report to minimize the dropdown");
			}
		}
	}

	public void validateTheNavOfPastReportsSubMenu() {

		clickSubMenuAndValidate(selectReportMenu, pastReportsSM, pageTitleText);

	}

	public void verifyTheSelectedFrequency(String text1, String text2) {
		if (!text1.equals(text2)) {
			logPass("Different Values are selected.");
		}

		else {
			logInfo("Different Values are not selected.");
		}
	}

	public void selectDeleiveryEmail() {
		isDisplayedThenClickRadioBTN(sendEmailTextRb, "Radio Button - Send Email");
	}

	public void VerifyTheEditedReportInPastReports(String frequency, String email) {
		isDisplayedThenClick(firstViewAll, "View All button in First row");
		sleep(3);
		checkTextInPageAndValidate(frequency, 10);
		checkTextInPageAndValidate(email, 10);
	}

	/*
	 * Click the View All link, View All reports page is displayed for the chosen
	 * report name. All the fields , dropdown, default data / information, logo,
	 * links displayed on the page are for BP
	 * 
	 */

	public void setAndValidateRecurringReportData() {
		isDisplayed(recurringReportTable, "Recurring Report Table");
		
		boolean nodataPresent = waitForTextToAppear("There are no reports setup under your User ID", 20);
		
		System.out.println("-------- nodataPresent -----------"+nodataPresent);
		
		if(nodataPresent)
		{
			logInfo("There are no reports present");
		}
		else
		{
			setCellDataFromTable(recurringReportTable, 7, false);
		}

	}

	public void setAndValidateRecurringReportDataAfterSearchSort() {
		isDisplayed(recurringReportTable, "Recurring Report Table");
		setCellDataFromTable(recurringReportTable, 7, true);

	}

	public void clickViewAllAndValidateThePage() {

		checkTextInPageAndValidate("My Recurring Reports", 10);
		isDisplayedThenClickRadioBTN(recurringReportsActiveRadioButton, "Active Radio button for Recurring Reports");
		setAndValidateRecurringReportData();
		String expectedReportName = getCellDataFromTable(1, 0, false);
		//String expAccount = getCellDataFromTable(1, 2, false); //Added by Anton due to this validation is not required
		String expFreq = getCellDataFromTable(1, 3, false);
		String expStatus = getCellDataFromTable(1, 4, false);

		// System.out.println("expectedReportName ==== "+expectedReportName+"expAccount
		// ===== "+expAccount+"expFreq ==== "+expFreq+"expStatus ==== "+expStatus);

		isDisplayed(recurringReportTable, "My Recurring Reports table");

		WebElement rowFirst = recurringReportTable
				.findElement(By.xpath("./tbody[contains(@id,'lform:scheduleRepoList:tb')]/tr[1]"));

		WebElement firstViewAllBTN = rowFirst.findElement(By.xpath("./td[7]//a"));

		isDisplayedThenClick(firstViewAllBTN, "View All button in First row");

		sleep(5);

		checkTextInPageAndValidate(expectedReportName, 10);
		//checkTextInPageAndValidate(expAccount, 10);//Added by Anton due to this validation is not required
		checkTextInPageAndValidate(expFreq, 10);
		checkTextInPageAndValidate(expStatus, 10);
	}

	public void validateThePastReportsPageButton() {
		isDisplayed(returnPastReportBTN, "Return to Past Reports");
		isDisplayed(editRecurringReportsBTN, "Edit Recurring Reports Details");
		checkTextInPageAndValidate("Report Filters", 10);
		checkTextInPageAndValidate("Reports", 10);

	}

	/*
	 * get the ReportTypeDetail
	 */

	public LinkedHashSet<String> getReportTypeAndDetail(boolean temp) {
		LinkedHashSet<String> repTypeDetailS = new LinkedHashSet<String>();
		List<WebElement> rows = recurringReportTable
				.findElements(By.xpath("./tbody[@id='lform:scheduleRepoList:tb']/tr"));
		int size = rows.size();
		String repTypeAndDetail = "";
		for (int i = 1; i <= size; i++) {
			repTypeAndDetail = getCellDataFromTable(i, 1, temp);
			System.out.println("---- repTypeAndDetail ----- " + repTypeAndDetail);
			repTypeDetailS.add(repTypeAndDetail);
		}

		return repTypeDetailS;
	}

	/*
	 * click Create New Recurring Report and Verify
	 */
	public void createNewRecurringReport(String clientCountry) {
		// TODO Auto-generated method stub

		isDisplayedThenClick(createNewRecurringReport, "Create New Recurring Report Button");
		sleep(5);
		
		if(clientCountry.equals("AU")) 
		{			
			checkTextInPageAndValidate("Run a Report", 15);
		}
		else if(clientCountry.equals("NZ"))
		{
			checkTextInPageAndValidate("Run a Report", 15);	
		}
		else
		{
			//if anyother BP client other than AU and NZ
		}
		checkTextInPageAndValidate("Report Type", 15);
		checkTextInPageAndValidate("Report Filters", 15);
		checkTextInPageAndValidate("Report Scheduling", 15);
		checkTextInPageAndValidate("Report Delivery", 15);

	}

	/*
	 * sortReportTypeDetailAndValidate Added by Anton 22.05.2018
	 * 
	 */

	public void sortReportTypeDetailAndValidate() {

		setAndValidateRecurringReportData();

		LinkedHashSet<String> beforeSort = getReportTypeAndDetail(false);

		clearData();

		WebElement reportTypeReportDetailHead = recurringReportTable
				.findElement(By.xpath("./thead[@id='lform:scheduleRepoList:th']/tr/th[2]/a"));

		isDisplayedThenClick(reportTypeReportDetailHead, "Report type , Report Detail Sort");

		sleep(10);

		setAndValidateRecurringReportDataAfterSearchSort();

		LinkedHashSet<String> afterSort = getReportTypeAndDetail(true);

		if (beforeSort.equals(afterSort)) {
			List<String> beforeList = new ArrayList<String>(beforeSort);

			Collections.sort(beforeList);

			List<String> afterList = new ArrayList<String>(afterSort);

			System.out.println(beforeList + " ----");

			System.out.println(afterList + " ----");

			if (beforeList.equals(afterList)) {
				logPass("Sorting is working for Report Type and Report Detail");
			}

			else {
				logFail("Sorting is not working for Report Type and Report Detail");
			}

		}

		else {
			logFail("Sorting is not working as expected");
		}

	}

	/*
	 * Added by Anton 23.05 - Sort columns
	 * 
	 */
	public void sortColumnsInTableAndValidate(int column) {

		setAndValidateRecurringReportData();

		LinkedHashSet<String> beforeSort = getReportTypeAndDetail(false);

		List<String> beforeList = new ArrayList<String>(beforeSort);

		Collections.sort(beforeList);

		clearData();

		WebElement reportTypeReportDetailHead = recurringReportTable
				.findElement(By.xpath("./thead[@id='lform:scheduleRepoList:th']/tr/th[2]/a"));

		isDisplayedThenClick(reportTypeReportDetailHead, "Report type , Report Detail Sort");

		sleep(10);

		setAndValidateRecurringReportDataAfterSearchSort();

		LinkedHashSet<String> afterSort = getReportTypeAndDetail(true);

		List<String> afterList = new ArrayList<String>(afterSort);
		// Collections.sort(afterList);

		if (beforeList.equals(afterList)) {
			logPass("Before after sort values are equal - Report Type and Report Detail");
		}

		else {
			logFail("Before after sort values are not equal - Report Type and Report Detail");
		}
	}

	/*
	 * Added By Anton 24.05.2018
	 * 
	 */

	public void makeTheHoldReportToActive() {

		try {

			isDisplayed(recurringReportTable, "Recurring Report Table");

			List<WebElement> allRows = recurringReportTable
					.findElements(By.xpath("./tbody[contains(@id,'lform:scheduleRepoList:tb')]/tr"));

			WebElement StatusCol = null;

			String statusText = null;

			WebElement reportName = null;

			WebElement reportAsActiveBTN = null;

			for (WebElement row : allRows) {
				rowCountHold++;

				StatusCol = row.findElement(By.xpath("./td[5]/p/span"));

				statusText = StatusCol.getText();

				if (statusText.equals("On Hold")) {
					reportName = row.findElement(By.xpath("./td[1]/div[contains(@class,'menu-popup')]//a"));

					isDisplayedThenClick(reportName, "report Name in the Row");

					reportAsActiveBTN = row.findElement(By.xpath(".//a[contains(@id,'mnuActivate')]"));

					isDisplayedThenClick(reportAsActiveBTN, "Put this report Active");

					sleep(5);

					break;

				}

				else {
					logInfo("No Reports are On Hold");
				}

			}

		} catch (Exception e) {
			logFail(e.getMessage());
		}
	}

	public void validateTheHoldReportChangedToActive() {

		isDisplayed(recurringReportTable, "Recurring Report Table");

		WebElement rowOfChange = recurringReportTable
				.findElement(By.xpath("./tbody[contains(@id,'lform:scheduleRepoList:tb')]/tr[" + rowCountHold + "]"));

		WebElement statusColAfterRefresh = null;

		String expStatusText = "";

		statusColAfterRefresh = rowOfChange.findElement(By.xpath("./td[5]/p/span"));

		expStatusText = statusColAfterRefresh.getText();

		if (expStatusText.equals("Active")) {
			logPass(" Put this report Active is clicked and available in the page.");
		}

		else {
			logFail("Put this report Active is not present in the page.");
		}

	}

	public void makeTheActiveReportToHold() {

		try {

			isDisplayed(recurringReportTable, "Recurring Report Table");

			List<WebElement> allRows = recurringReportTable
					.findElements(By.xpath("./tbody[contains(@id,'lform:scheduleRepoList:tb')]/tr"));

			WebElement StatusCol = null;

			String statusText = null;

			WebElement reportName = null;

			WebElement reportAsHoldBTN = null;

			for (WebElement row : allRows) {
				rowCount++;

				StatusCol = row.findElement(By.xpath("./td[5]/p/span"));

				statusText = StatusCol.getText();

				if (statusText.equals("Active")) {
					reportName = row.findElement(By.xpath("./td[1]/div[contains(@class,'menu-popup')]//a"));

					isDisplayedThenClick(reportName, "report Name in the Row");

					reportAsHoldBTN = row.findElement(By.xpath(".//a[contains(@id,'mnuHold')]"));

					isDisplayedThenClick(reportAsHoldBTN, "Put this report on hold");

					sleep(5);

					break;

				}

				else {
					logInfo("No Reports are active");
				}

			}

		} catch (Exception e) {
			logFail(e.getMessage());
		}
	}

	public void validateTheActiveReportChangedToHold() {

		isDisplayed(recurringReportTable, "Recurring Report Table");

		WebElement rowOfChange = recurringReportTable
				.findElement(By.xpath("./tbody[contains(@id,'lform:scheduleRepoList:tb')]/tr[" + rowCount + "]"));

		WebElement statusColAfterRefresh = null;

		String expStatusText = "";

		statusColAfterRefresh = rowOfChange.findElement(By.xpath("./td[5]/p/span"));

		expStatusText = statusColAfterRefresh.getText();

		if (expStatusText.equals("On Hold")) {
			logPass(" Put this report on hold is clicked and available in the page.");
		}

		else {
			logFail("Put this report on hold is not present in the page.");
		}

	}

	/*
	 * selectAllAccountsFromDropown Added by Ayub 22.05.2018
	 * 
	 */

	public void selectAllAccountsFromDropown(String accountType) {
		int dropDownSize = getDropdownSize(accountsDropDown);
		for (int i = 0; i < dropDownSize; i++) {
			selectDropDownByIndex(accountsDropDown, i);
			accountname = selectedStringFrmDropDown(accountsDropDown);
			System.out.println(accountname);
			sleep(3);
			if (selectViewAllReports(accountType)) {
				if (isViewAllSelected) {
					logPass("Selected view all button from table");
					validateThePastReportsPageButton();
					break;
				} else {
					logPass("No Reports counts for the all accounts");
					break;
				}
			} else {
				logInfo("Can't select View all button");
				continue;
			}
		}
	}

	boolean isViewAllSelected = true;

	public boolean selectViewAllReports(String accountType) {
		boolean result = false;
		scrollDownPage();
		boolean noRecurringReport = waitForTextToAppear("You have no Recurring Reports scheduled", 30);
		if(noRecurringReport)
		{
			logInfo("You have no Recurring Reports scheduled");
		}
		else
		{
		isDisplayed(recurringReportTable, "Recurring Report Table");
		setCellDataFromTable(recurringReportTable, 7, false);
		int s = getRowSize(recurringReportTable);
		int tableListSize = viewAll.size();
		System.out.println("Row size " + s);
		System.out.println("List view size is " + viewAll.size());
		for (int j = 1; j <= tableListSize; j++) {
			expAccount = getCellDataFromTable(j, 2, false);
			reportNumber = Integer.parseInt(getCellDataFromTable(j, 5, false));
			System.out.println("Expire account " + expAccount + " Account name" + accountname + "Report Count Number"
					+ reportNumber);
			if (accountType.equals("Same")) {
				if (accountname.contains(expAccount) && reportNumber != 0) {
					result = clickViewAllButton(j);
					logPass("Same Values are selected.");
					break;
				} else {
					logInfo("Different Values are  selected.");
					if (accountname.contains(expAccount) && reportNumber == 0) {
						isViewAllSelected = false;
						result = true;
					}
				}
			} else if (accountType.equals("Different")) {
				if (!accountname.contains(expAccount)) {
					result = clickViewAllButton(j);
					logPass("Different values are selected.");
					break;
				} else {
					logInfo("Same Values are  selected.");
				}
			}
		}
		}
		return result;
	}

	public boolean clickViewAllButton(int j) {
		try {
			isDisplayedThenActionClick(viewAll.get(j - 1), "Selected View All button in same row");
			// System.out.println("Get Text for element"+ expAccount.getr);
			sleep(10);
			return true;
		} catch (Exception e) {
			logFail(e.getMessage());
			return false;
		}
	}

	public void selectFilterForRecurringReportsList(String filterOption) {
		selectRadioButtonFromList(radioButtonFilterInRecurringReports, filterOption, "data-summary-value");
		sleep(2);
	}
	
	/*
	 * Delete The created Report added by Anton 30.05.2018
	 * 
	 */	
	public void deleteTheCreatedReport(String reportData) {	
		
		String reportType=reportData.split("::")[0];
		String reportDetail = reportData.split("::")[1];
		
		System.out.println("reportType -----"+reportType+" ----reportDetail-----"+reportDetail);
		
		isDisplayed(recurringReportTable, "Recurring Report Table");
		
		checkTextInPageAndValidate(reportDetail, 15);

		WebElement rowOfReportCreated = recurringReportTable
				.findElement(By.xpath("./tbody[contains(@id,'lform:scheduleRepoList:tb')]/tr[1]"));
		
		WebElement reportNameCreated = rowOfReportCreated.findElement(By.xpath("./td[1]/div[contains(@class,'menu-popup')]//a"));
		
		isDisplayedThenClick(reportNameCreated, "report Name in the Report created");

		WebElement deleteTheReport = rowOfReportCreated.findElement(By.xpath(".//a[contains(@id,'mnuDeleteReport')]"));

		isDisplayedThenClick(deleteTheReport, "Delete this Report Permanently");

		sleep(3);

		isDisplayed(deletePopup,"Delete popup is present");
		
		isDisplayedThenClick(deleteButton, "Delete button");
		
		sleep(10); 
		
		boolean isDeleted = waitForTextToAppear(reportDetail, 20);
		
		if(isDeleted)
		{
			logFail("The created report is not deleted");
		}
		
		else
		{
			logPass("The Created report is deleted");
		}
		
	}
	
	/*
	 * Check report present or not
	 * 
	 */
	
	public boolean checkReportPresentorNot()
	{
		isDisplayed(recurringReportTable, "Recurring Report Table");
		
		boolean nodataPresent = waitForTextToAppear("There are no reports setup under your User ID", 20);
		
		System.out.println("-------- nodataPresent -----------"+nodataPresent);
		
		if(nodataPresent)
		{
			logInfo("There are no reports present");
		}
		else
		{
			logInfo("Reports are present");
		}
		
		return nodataPresent;
	}
	
	/*
	 * Check Recurring report is present or not
	 * 
	 */

	public boolean checkRecurringReportPresentorNot()
	{
		
		
		boolean noRecurringReport = waitForTextToAppear("You have no Recurring Reports scheduled", 30);
		
		System.out.println("-------- noRecurringReport -----------"+noRecurringReport);
		
		if(noRecurringReport)
		{
			logInfo("There are no recurring reports present");
		}
		else
		{
			logInfo("Recurring reports are present");
		}
		
		return noRecurringReport;
	}
	
	
}
