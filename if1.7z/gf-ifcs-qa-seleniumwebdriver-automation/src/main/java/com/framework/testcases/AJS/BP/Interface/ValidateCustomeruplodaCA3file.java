package com.framework.testcases.AJS.BP.Interface;

import java.util.HashMap;

import javax.xml.transform.TransformerException;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.ApplicationsPage;
import com.framework.pages.AJS.common.Common;
import com.framework.pages.AJS.common.IFCSCommonPage;
import com.framework.pages.AJS.common.IFCSHomePage;
import com.framework.pages.AJS.common.IFCSLoginPage;
import com.framework.util.PropUtils;

public class ValidateCustomeruplodaCA3file extends BaseTest {
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "Smoke" , "Regression","BusinessFlow"})
	public void ValidateCA3File(@Optional("AU") String clientCountry, @Optional("BP") String clientName) throws TransformerException {

		test = extent.createTest(clientName+ ":" +clientCountry+"  CA3 Customer upload file",
				"CA3 Customer upload file");
		// creating object for the Pages	
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		ApplicationsPage IFCSApplicationsPage = new ApplicationsPage(driver, test);
		String  clientNameInProp = PropUtils.getPropValue(configProp, clientName + "_" + clientCountry);
		System.out.println(clientNameInProp);	
		Common common = new Common(driver, test);
		IFCSCommonPage ifcsCommonPage = new IFCSCommonPage(driver, test);
		HashMap<String, String> RefNum = ifcsCommonPage.updateValuescustomeruploadfileXML(clientNameInProp,clientCountry);
		System.out.println((RefNum));
		IFCSloginPage.login("IFCS_URL_BP", "IFCS_BP_USERNAME", "IFCS_BP_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, " ");
		IFCSHomePage.gotoClientMenuAndChooseClient(clientNameInProp);
		if(clientCountry.equalsIgnoreCase("AU"))  {
			common.clientBatchJobExecution("RM_GSD_0080");
			}else {common.clientBatchJobExecution("RM_GSD_0011");}
		String applicationNo= IFCSHomePage.validateApplicationlist(RefNum);		
		IFCSHomePage.searchApplication(applicationNo);
		IFCSApplicationsPage.createNewApplicationForBP("","");
		IFCSApplicationsPage.createCardOffersInApplicationForBP();
		IFCSApplicationsPage.addPricingInApplication();
		IFCSApplicationsPage.addCardControlsInApplication();
		IFCSApplicationsPage.addCardReissueProfiles();
		IFCSApplicationsPage.validateAndCreateApplication();
		IFCSHomePage.exitIFCSwithoutValidation();

	}
	
}


