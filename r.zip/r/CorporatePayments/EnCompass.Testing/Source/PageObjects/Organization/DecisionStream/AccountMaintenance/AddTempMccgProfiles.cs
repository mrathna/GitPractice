﻿using AventStack.ExtentReports;
using Common;
using Common.Utility;
using NFluent;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Support.UI;

namespace EnCompass.Testing.Source.PageObjects.Organization.DecisionStream.AccountMaintenance
{
    [PageModel(@"/decisionStream/accountMaintenance/AddTempMccgProfiles.aspx")]
    public class AddTempMccgProfiles : EnCompassOrgPageModel

    {
        public override string RelativeUrl => @"/decisionStream/accountMaintenance/RecentActivity.aspx";
        public override string PageIdentifierXPath_Override => @"//h1[normalize-space(text())='Add Temporary Profiles']";

        #region XPath page Elements

        private const string _tbEmptyStartDateXPath = @"//input[contains(@id, 'tbEmptyStartDate')]";
        private const string _tbEmptyEndDateXPath = @"//input[contains(@id, 'tbEmptyEndDate')]";
        private const string _includeExcludeProfilesXPath = @"//select[contains(@id, 'ctEditTemporaryMccgProfile')]";
        private const string _btnEmptyAddXPath = @"//input[contains(@id, 'btnEmptyAdd')]";
        private const string _btnSaveXPath = @"//input[contains(@id, 'btnSave') and contains(@onclick,'btnSave')]";
        private const string _btnConfirmXPath = @"//input[contains(@id, 'btnConfirm')]";
        private const string _btnBackXPath = @"//input[contains(@id, 'btnBack')]";
        #endregion

        #region Page Elements

        private IWebElement _tbEmptyStartDate
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_tbEmptyStartDateXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_tbEmptyStartDate element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _tbEmptyEndDate
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_tbEmptyEndDateXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_tbEmptyEndDate element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _includeExcludeProfiles
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_includeExcludeProfilesXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_includeExcludeProfiles element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _btnEmptyAdd
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_btnEmptyAddXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_btnEmptyAdd element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _btnSave
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_btnSaveXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_btnSave element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _btnConfirm
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_btnConfirmXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_btnConfirm element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _btnBack
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_btnBackXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_save element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        #endregion

        public string EmptyStartDate
        {
            set
            {
                _tbEmptyStartDate.SendKeys(value);
            }
        }
        public string EmptyEndDate
        {
            set
            {
                _tbEmptyEndDate.SendKeys(value);
            }
        }

        public string IncludeExcludeProfiles
        {
            get { return new SelectElement(_includeExcludeProfiles).SelectedOption.Text; }
            set { new SelectElement(_includeExcludeProfiles).SelectByText(value); }
        }

        public void Save()
        {
            _btnSave.JSClickWithFocus(Driver);
			Settings.EnCompassExtentTest.Info("Clicked on Save Button on ADD Temporary MCCG Profile page");
			this.AttachOnDemandScreenShot();
		}

        public void Confirm()
        {
            _btnConfirm.JSClickWithFocus(Driver);
			Settings.EnCompassExtentTest.Info("Clicked on  button Confirm");
		}

        public void Add()
        {
            _btnEmptyAdd.JSClickWithFocus(Driver);
			Settings.EnCompassExtentTest.Info("Press button Add");
		}

        public void Back()
        {
            _btnBack.JSClickWithFocus(Driver);
        }

        public void SetTemporaryMCCGProfile(string startDate, string endDate, string temporaryMCCGProfile, ExtentTest test)
        {
            EmptyStartDate = startDate;
            test.Info("Set the start Date to MCCG Profile Temporary via MCCG Profiles by Card : " + startDate);
            EmptyEndDate = endDate;
            test.Info("Set the end Date to MCCG Profile Temporary via MCCG Profiles by Card : " + endDate);
            IncludeExcludeProfiles = temporaryMCCGProfile;
            test.Info("Select MCCG Profile Temporary to apply via MCCG Profiles by Card : " + temporaryMCCGProfile);
            Add();
			WaitForFormLoadingOverlay();
            Save();
            Confirm();
        }

        public AddTempMccgProfiles(GlobalSettings settings) : base(settings) { }
    }
}
