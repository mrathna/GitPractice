package com.framework.testcases.OLS.BP.Merchant;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.BP.BPHomePage;
import com.framework.pages.OLS.common.FindAndExportTransactionPage;
import com.framework.pages.OLS.common.LoginPage;

public class ValidateMerchantFindAndExportTransaction extends BaseTest {

	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "Regression","BusinessFlow" })
	public void Validate_Adhoc_Report_Page(@Optional("AU") String clientCountry, @Optional("BP") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  BP Merchant Find And Export Transaction Page",
				"Checking the Find And Export Transaction Pages");

		// Creating Objects for the Login Pages
		LoginPage loginPage = new LoginPage(driver, test);
		BPHomePage bpHomePage = new BPHomePage(driver, test);
		FindAndExportTransactionPage findAndExportTransactionPage = new FindAndExportTransactionPage(driver, test);
		loginPage.Login("BP_URL", "BP_UN_Merchant_" + clientCountry, "BP_PWD_Merchant_" + clientCountry, clientName);
		bpHomePage.ValidateMerchantLogo();

		// Find and Export Transaction Page
		findAndExportTransactionPage.selectFindAndExportTransactionPage();
		findAndExportTransactionPage.enterFromAndToDate();

		// Click Search Button and Validate
		findAndExportTransactionPage.clickSearch();
		
		boolean isNoTranscPresent = findAndExportTransactionPage.validateTheSearchResults();
		
		System.out.println("-----isNoTranscPresent-------"+isNoTranscPresent);
		
		
		if(!isNoTranscPresent)
		{
			
			// Enter Location Number and Search
			findAndExportTransactionPage.enterLocationNumber();
		
			findAndExportTransactionPage.clickSearch();
	
			boolean isLocNoTransacPresent = findAndExportTransactionPage.validateTheSearchResults();
			
			if(isLocNoTransacPresent)
			{

				/*
				 * Export Transaction Test case & Continuation of Previous Test case
				 */

					findAndExportTransactionPage.clickExportButton();

					/*
					 * Navigate Through Transaction Test case & Continuation of Previous Test case
					 */

					findAndExportTransactionPage.selectTransactionAndValidate();
					findAndExportTransactionPage.validateAndSelectTransactionLineItem();
					findAndExportTransactionPage.clickBackToTransactionList(); 
					
			}
			
		}
		loginPage.Logout();

	}

}
