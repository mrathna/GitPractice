package com.framework.testcases.OLS.BP.Customer;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.BP.BPHomePage;
import com.framework.pages.BP.BPRunAReportPage;
import com.framework.pages.OLS.common.LoginPage;
import com.framework.pages.OLS.common.MerchantReportsPage;

public class ValidateRunReport extends BaseTest {

LoginPage loginPage ;
	BPHomePage bpHomePage;
	BPRunAReportPage bpRunAReportPage;
	
	@Parameters({"clientCountry","clientName"})
	@Test( groups = { "SIP", "Regression" })
	public void testExportTransactionReportSIP(@Optional("AU") String clientCountry, @Optional("BP") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  BP Run A Report Page", "Run A Report Page Validation");
		// Creating Objects for the Pages
		loginPage = new LoginPage(driver, test);
		bpHomePage = new BPHomePage(driver, test);
		bpRunAReportPage = new BPRunAReportPage(driver, test);
        MerchantReportsPage merchantReportsPage = new MerchantReportsPage(driver, test);
        /*
        Login to OLS application
         */
        if(clientName.equals("BP")) {
            loginPage.Login("BP_URL", "BP_UN_Customer_" + clientCountry, "BP_PWD_Customer_" + clientCountry, clientName);
        } else {
            loginPage.Login("BPPREPAID_URL", "BPPREPAID_UN_Customer_" + clientCountry, "BPPREPAID_PWD_Customer_" + clientCountry, clientName);
        }
        merchantReportsPage.clickRunAReport();
        bpRunAReportPage.selectReportType("Transactions");
        bpRunAReportPage.selectReportDetailValue("Export Transactions - Spreadsheet - Format 18");
        bpRunAReportPage.selectAllAccounts();
        bpRunAReportPage.selectReportDateRange("Last 3 calendar months");
        bpRunAReportPage.selectDownloadAndDisplayRadioButton();
        bpRunAReportPage.clickRunReportButton();
		bpRunAReportPage.validateDriverNameOfEachAccountNumberInGeneratedReport();
		loginPage.Logout();
	}


	/*@Parameters({"clientCountry","clientName","reportName"})
	@Test( groups = { "Smoke", "Regression" })
	public void testRunAReportPage(@Optional("AU") String clientCountry, @Optional("BP") String clientName, @Optional("Export Transactions - Spreadsheet - Format 9") String reportName)  {
		test = extent.createTest(clientName+ ":" +clientCountry+"  BP Run A Report Page", "Run A Report Page Validation");
		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		BPHomePage bpHomePage = new BPHomePage(driver, test);
		BPRunAReportPage BPrunAreportPage = new BPRunAReportPage(driver, test);

		// Calling Functions
		if(clientName.equals("BP")) {
			loginPage.Login("BP_URL", "BP_UN_Customer_" + clientCountry, "BP_PWD_Customer_" + clientCountry, clientName);
		} else {
			loginPage.Login("BPPREPAID_URL", "BPPREPAID_UN_Customer_" + clientCountry, "BPPREPAID_PWD_Customer_" + clientCountry, clientName);
		}
		bpHomePage.ValidateBPCustomerLogo();
		bpHomePage.clickOnRunAReportSubMenu();

		BPrunAreportPage.verifyRunReportPageFields();
		
		if(reportName.equals("Export Transaction File - with Headers")) {
			BPrunAreportPage.runTransactionReport("Export Transaction File - with Headers");
		} else if (reportName.equals("Export Transactions -  Text File - Format 16")) {
			BPrunAreportPage.runTransactionReport("Export Transactions -  Text File - Format 16");
		} else if (reportName.equals("Export Transactions -  Text File - Format 18")) {
			BPrunAreportPage.runTransactionReport("Export Transactions -  Text File - Format 18");
		} else if (reportName.equals("Export Transactions -  Text File - Format 9")) {
			BPrunAreportPage.runTransactionReport("Export Transactions -  Text File - Format 9");
		} else if (reportName.equals("Export Transactions - Spreadsheet - Format 16")) {
			BPrunAreportPage.runTransactionReport("Export Transactions - Spreadsheet - Format 16");
		} else if (reportName.equals("Export Transactions - Spreadsheet - Format 18")) {
			BPrunAreportPage.runTransactionReport("Export Transactions - Spreadsheet - Format 18");
		} else if (reportName.equals("Export Transactions - Spreadsheet - Format 9")) {
			BPrunAreportPage.runTransactionReport("Export Transactions - Spreadsheet - Format 9");
		} else if (reportName.equals("Export Transactions - Text Comma Delimiter File - Format 16")) {
			BPrunAreportPage.runTransactionReport("Export Transactions - Text Comma Delimiter File - Format 16");
		} else if (reportName.equals("Export Transactions - Text Comma Delimiter File - Format 18")) {
			BPrunAreportPage.runTransactionReport("Export Transactions - Text Comma Delimiter File - Format 18");
		} else {
			BPrunAreportPage.runTransactionReport("Export Transactions - Text Comma Delimiter File - Format 9");
		}
			
		// * Below Commented Actions are covered in runTransactionReport("Export Transaction File - with Headers")
		BPrunAreportPage.selectInputFromAccountTypeDropdown();
		BPrunAreportPage.clickOnRunReportButton();
		BPrunAreportPage.verifyReportDetailValidationMsg();
		BPrunAreportPage.clickAndVerifyanchorTag(); 
		
		loginPage.Logout();
	}*/

@Parameters({"clientCountry","clientName"})
	@Test( groups = { "Smoke", "Regression" })
	public void testRunAReportPageForAllReports(@Optional("AU") String clientCountry, @Optional("BP") String clientName)  {
		test = extent.createTest(clientName+ ":" +clientCountry+"  BP Run A Report Page", "Run A Report Page Validation");
		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		BPHomePage bpHomePage = new BPHomePage(driver, test);
		BPRunAReportPage BPrunAreportPage = new BPRunAReportPage(driver, test);
		BPRunAReportPage bpRunReportPage = new BPRunAReportPage(driver, test);
		// Calling Functions
		if(clientName.equals("BP")) {
			loginPage.Login("BP_URL", "BP_UN_Customer_" + clientCountry, "BP_PWD_Customer_" + clientCountry, clientName);
		} else {
			loginPage.Login("BPPREPAID_URL", "BPPREPAID_UN_Customer_" + clientCountry, "BPPREPAID_PWD_Customer_" + clientCountry, clientName);
		}
		bpHomePage.ValidateBPCustomerLogo();
		bpHomePage.clickOnRunAReportSubMenu();

		BPrunAreportPage.verifyRunReportPageFields();
		bpRunReportPage.getReportTypeAndDetailInRunAReport();
				
		loginPage.Logout();
	}


}
