package com.framework.testcases.OLS.CHEV.Customer;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.common.Common;
import com.framework.pages.AJS.common.IFCSLoginPage;
import com.framework.pages.CHEV.CHCardListPage;
import com.framework.pages.CHEV.CHChangeCardStatusPage;
import com.framework.pages.CHEV.CHHomePage;
import com.framework.pages.OLS.common.LoginPage;

public class ValidateChangeCardStatusInvalidDates extends BaseTest {
	@Parameters({ "clientCountry", "clientName" })
	@Test(priority = 6)
	public void validateChangeCardStatusForInvalidDates(@Optional("SG") String clientCountry, @Optional("CHV") String clientName) {
		
		test = extent.createTest(clientName+ ":" +clientCountry+"  01 Change Card Status  - Invalid dates", "Invalid Dates on Card Change Status Page");

		// Creating Objects for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		LoginPage loginPage = new LoginPage(driver, test);
		Common common=new Common(driver,test);
		CHHomePage chHomePage = new CHHomePage(driver, test);
		CHCardListPage cardStatusPage = new CHCardListPage(driver, test);
		CHChangeCardStatusPage changeCardStatusPage = new CHChangeCardStatusPage(driver, test);
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		loginPage.Login("CHV_URL", "CHV_Customer_UN_"+clientCountry, "CHV_Customer_PWD_"+clientCountry,clientName);
		chHomePage.loadFindAndUpdateCardPage();
		// Validating the title of card list page
		cardStatusPage.verifyCardPageTitle();
		String cardNumber = cardStatusPage.getActiveCardNumber();
		if(cardNumber!=null) {
		cardStatusPage.enterCardNumber(cardNumber);

		// Clicking the search card button
		cardStatusPage.clickSearchCard();

		// Selecting the first card from the list
		cardStatusPage.clickFirstCardNumberFromCardsList();

		// Selecting the Change status open
		cardStatusPage.pickChangeStatusContextMenu();

		// Get the card number and change the Status
		changeCardStatusPage.verifyChangeCardStatusPage();
		changeCardStatusPage.verifyCountryDropDown();

		String currentDate = common.getCurrentIFCSDateFromDB(clientName+clientCountry);
		
		String invalidDate= common.enterADateValueInStatusBeginDateField("PastSix", currentDate);//"23/03/2018";
		
		changeCardStatusPage.validateDateField(invalidDate);
		}else {
			cardStatusPage.logInfo("No Active Card");
		}

		loginPage.Logout();

	}

}
