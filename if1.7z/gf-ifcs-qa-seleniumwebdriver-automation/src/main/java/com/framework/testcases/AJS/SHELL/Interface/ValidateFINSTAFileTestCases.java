package com.framework.testcases.AJS.SHELL.Interface;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.MaintainCustomerPage;
import com.framework.pages.AJS.TransactionListPage;
import com.framework.pages.AJS.common.Common;
import com.framework.pages.AJS.common.IFCSCommonPage;
import com.framework.pages.AJS.common.IFCSHomePage;
import com.framework.pages.AJS.common.IFCSLoginPage;
import com.framework.pages.AJS.common.InterfacePage;

public class ValidateFINSTAFileTestCases extends BaseTest {
	
	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test(groups = {"Regression"})
	public void validateFINSTAFileProcess(@Optional("RU") String clientCountry,
			@Optional("SHELL") String clientName, @Optional("APA") String cardType)
	{
		String inputTemplateFileName;
		if(clientCountry.equals("RU")) {
			inputTemplateFileName = "finsta_CITI_SHELL-IFCS_RU05.854736.dat";
		} else {
			inputTemplateFileName = "finsta_SCB_SHELL-IFCS_MY05.854694.dat";
		}

		test = extent.createTest(clientName+ ":" +clientCountry+"  Verify 01 Set up a Payment file - FINSTA, 02 Process the Payments-FINSTA  file and 03 Verify that statement details are under Banking Statement", "01 Set up a Payment file - FINSTA, 02 Process the Payments-FINSTA  file and 03 Verify that statement details are under Banking Statement");
		//creating object for the Pages
		IFCSLoginPage ifcsloginPage = new IFCSLoginPage(driver, test);
		InterfacePage interfacePage = new InterfacePage(driver, test);
		Common common=new Common(driver,test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		IFCSCommonPage ifcsCommonPage = new IFCSCommonPage(driver, test);
		MaintainCustomerPage maintainCustomerPage = new MaintainCustomerPage(driver, test);
		TransactionListPage transactionListPage = new TransactionListPage(driver, test);

		
		// Calling Functions
		ifcsloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");
		ifcsloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, cardType);
		
		IFCSHomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);
		transactionListPage.goToIncomingInterfacesPage();
		// get and store the Statement number
		String beforeStatementOrAcknowledgements = common.getTableValuesWithKey("Id", "StatementOrAcknowledgements", "Last Sequence Number");
		System.out.println("Before StatementOrAcknowledgements::"+beforeStatementOrAcknowledgements);
		
		IFCSHomePage.gotoTransactionAndClickManageTransaction();
		transactionListPage.goToBankingStatements();
		maintainCustomerPage.clickDetailSearchIfFilterFieldsNotPresent();
		String fStatementNo = transactionListPage.enterStatementNoAndValidatess("Details not found");
		System.out.println("Statement No::"+fStatementNo);
		
		// Place the Finsta file in IE input files (/data/integration_engine/UATAWS12C/input_files)
		interfacePage.updateOrValidateFlatFile(finstaconfigProp, "OutgoingFile",
				"IE_INPUTFILE_FOLDER_LOADCARDTRANSACTIONS", fStatementNo, clientName, clientCountry,inputTemplateFileName );
		System.out.println("Faker Statement No::"+fStatementNo);
		// Run the FINSTA Contorl-M jobs
		String folderName = ifcsCommonPage.getControlMFolder(clientName, clientCountry, "jobS_Finsta");

		String jobsInOrder = ifcsCommonPage.getJobsOfFolderInOrder("jobS_Finsta");

		interfacePage.establishAndExecuteControlMJobs("ControlM_AWS_UAT", "ContorlM_AWS_userName",
				"ContorlM_AWS_password", folderName, jobsInOrder);
		// Go to Banking statements and Validate 
		IFCSHomePage.gotoTransactionAndClickManageTransaction();
		transactionListPage.goToBankingStatements();
		maintainCustomerPage.clickDetailSearchIfFilterFieldsNotPresent();
		transactionListPage.enterStatementNoAndValidate(fStatementNo);
		transactionListPage.goToAdminClientIncomingInterFacepage();
		// Get the updated Statement number
		String updatedStatementOrAcknowledgements = common.getTableValuesWithKey("Id", "StatementOrAcknowledgements", "Last Sequence Number");
		System.out.println("Updated StatementOrAcknowledgements::"+updatedStatementOrAcknowledgements);
		// Validate the Statement number 
		transactionListPage.validateStatementOrAcknowledgementsNumber(beforeStatementOrAcknowledgements, updatedStatementOrAcknowledgements, "increase");
		IFCSHomePage.exitIFCS();
		 
	}
@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test(groups = {"Regression"})
	public void validateEmptyFINSTAFileProcess(@Optional("RU") String clientCountry,
			@Optional("SHELL") String clientName, @Optional("APA") String cardType)
	{
		String inputTemplateFileName;
		if(clientCountry.equals("RU")) {
			inputTemplateFileName = "finsta_CITI_SHEMPTY-IFCS_RU05.854736.dat";
		} else {
			inputTemplateFileName = "finsta_SCB_SHEMPTY-IFCS_MY05.854694.dat";
		}

		test = extent.createTest(clientName+ ":" +clientCountry+"  Verify 02 Processing empty FINSTA files", "02 Processing empty FINSTA files");
		//creating object for the Pages
		IFCSLoginPage ifcsloginPage = new IFCSLoginPage(driver, test);
		InterfacePage interfacePage = new InterfacePage(driver, test);
		Common common=new Common(driver,test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		//CommonInterfacePage commonInterfacePage = new CommonInterfacePage(driver, test);
		IFCSCommonPage ifcsCommonPage = new IFCSCommonPage(driver, test);
		TransactionListPage transactionListPage = new TransactionListPage(driver, test);

		
		// Calling Functions
		ifcsloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");
		ifcsloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, cardType);
		
		IFCSHomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);
		transactionListPage.goToIncomingInterfacesPage();
		// get and store the Statement number
		String beforeStatementOrAcknowledgements = common.getTableValuesWithKey("Id", "StatementOrAcknowledgements", "Last Sequence Number");
		System.out.println("Before StatementOrAcknowledgements::"+beforeStatementOrAcknowledgements);
		
				
		// Place the Finsta file in IE input files (/data/integration_engine/UATAWS12C/input_files)
		interfacePage.updateOrValidateFlatFile(finstaconfigProp, "OutgoingFile",
				"IE_INPUTFILE_FOLDER_LOADCARDTRANSACTIONS",
				"", clientName, clientCountry,inputTemplateFileName );
		
		// Run the FINSTA Contorl-M jobs
		String folderName = ifcsCommonPage.getControlMFolder(clientName, clientCountry, "jobS_Finsta");

		String jobsInOrder = ifcsCommonPage.getJobsOfFolderInOrder("jobS_Finsta");

		interfacePage.establishAndExecuteControlMJobs("ControlM_AWS_UAT", "ContorlM_AWS_userName",
				"ContorlM_AWS_password", folderName, jobsInOrder);
				
		transactionListPage.goToAdminClientIncomingInterFacepage();
		// Get the updated Statement number
		String updatedStatementOrAcknowledgements = common.getTableValuesWithKey("Id", "StatementOrAcknowledgements", "Last Sequence Number");
		System.out.println("Updated StatementOrAcknowledgements::"+updatedStatementOrAcknowledgements);
		// Validate the Statement number 
		transactionListPage.validateStatementOrAcknowledgementsNumber(beforeStatementOrAcknowledgements, updatedStatementOrAcknowledgements, "sameValue");
		IFCSHomePage.exitIFCS();
		 
	}

}
