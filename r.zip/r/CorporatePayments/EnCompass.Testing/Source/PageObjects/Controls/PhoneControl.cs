﻿using Common.Utility;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace EnCompass.Testing.Source.PageObjects.Controls
{
	public class PhoneControl
	{
		public const string CellPolicyIconXPath = @"//a[contains(@id, 'lbPolicy')]";
		public const string CellPolicyHeaderXPath = @"//h1[contains(text(),'Cellular Phone')]";
		public const string CellPolicyBodyXPath = @"//body[@class = 'iframe-modal']//div[@class = 'modal-body']";
		public const string CellPolicyCloseXPath = @"//input[contains(@name, 'footerContent') and @value= 'Close']";
		public const string CellPolicyIFrameXPath = @"//iframe[contains(@src, 'CellularPolicy.aspx')]";

		private string _elementIdentifier;
		private IWebDriver _driver;
		private IWebElement _cellPolicyIcon;

		public PhoneControl(string controlIdentifier, IWebDriver driver)
		{
			_elementIdentifier = controlIdentifier;
			_driver = driver;
			_cellPolicyIcon = _driver.FindElement(By.XPath($"{CellPolicyIconXPath}[contains(@id, '{_elementIdentifier}')]"));
		}

		public string CellPolicyToolTip
		{
			get
			{
				return _cellPolicyIcon.GetAttribute("title");
			}
		}

		public string CellPolicyHeader
		{
			get
			{
				WaitForCellPolicyIFrame();
				var element = _driver.FindElement(By.XPath(CellPolicyHeaderXPath));
				if (element != null)
				{
					var text = element.Text;
					return text;
				}
				else
				{
					throw new Exception("Could not locate 'Cell Policy Header'.");
				}

				//using (var helper = new FrameHelper(_driver))
				//{
				//	var element = helper.FindElement(By.XPath(CellPolicyHeaderXPath));
				//	if (element != null)
				//	{
				//		var text = element.Text;
				//		return text;
				//	}
				//	else
				//	{
				//		throw new Exception("Could not locate 'Cell Policy Header'.");
				//	}

				//}

			}
		}

		public string CellPolicyBody
		{

			get
			{
				WaitForCellPolicyIFrame();

				using (var helper = new FrameHelper(_driver))
				{
					var element = helper.FindElement(By.XPath(CellPolicyBodyXPath), TimeSpan.FromSeconds(5));
					if (element != null)
					{
						var text = element.Text;
						return text;
					}
					else
					{
						throw new Exception("Could not locate 'Cell Policy Body'.");
					}
				}
			}
		}

		public bool IsCellPolicyVisible
		{
			get
			{
				using (var helper = new FrameHelper(_driver))
				{
					var element = helper.FindElement(By.XPath(CellPolicyHeaderXPath));
					return element != null;
				}
			}
		}

		public void ShowCellPolicy()
		{
			_cellPolicyIcon.JSClickWithFocus(_driver);
		}

		public void HideCellPolicy()
		{
			WaitForCellPolicyIFrame();

			using (var helper = new FrameHelper(_driver))
			{
				var element = helper.FindElement(By.XPath(CellPolicyCloseXPath));
				if (element != null)
				{
					element.JSClickWithFocus(_driver);
				}
				else
				{
					throw new Exception("Could not locate element to close 'Cell Policy' modal.");
				}
			}

		}

		private void WaitForCellPolicyIFrame()
		{
			_driver.WaitForVisible(By.XPath(CellPolicyIFrameXPath));
			_driver.WaitForDocumentLoadToComplete();
		}
	}
}
