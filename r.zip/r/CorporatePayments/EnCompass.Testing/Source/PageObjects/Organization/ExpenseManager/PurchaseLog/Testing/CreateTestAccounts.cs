﻿using Common.Utility;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Support.UI;
using NFluent;

namespace EnCompass.Testing.Source.PageObjects.Organization.ExpenseManager.PurchaseLog.Testing
{
	public partial class CreateTestAccounts
	{
        #region XPath page Elements
        private const string _noOfAccountsToCreateXpath = @".//input[contains(@id,'NumberOfAccountsText')]";
        private const string _createAccountBtnXpath = @".//input[contains(@id,'CreateButton')]";
        private const string _poolNameDropdownXpath = @"//select[contains(@id,'PoolDropdown')]";
        private const string _payablesTypeDropdownXpath = @"//select[contains(@id,'ddlAccountType')]";

        //Side Navigation
        private const string _testing_CardsXpath = @"//ul[contains(@id, 'sideNav')]//li[1]";
        private const string _testing_CreateCardTransactionsXpath = @"//ul[contains(@id, 'sideNav')]//li[2]";
        private const string _testing_singleUseAccountsXpath= @"//ul[contains(@id, 'sideNav')]//li[3]";
        private const string _testing_SingleUseAccountTransactionsXpath = @"//ul[contains(@id, 'sideNav')]//li[4]";
        private const string _testing_CreditLimitUpdateXpath = @"//ul[contains(@id, 'sideNav')]//li[5]";
        private const string _testing_DailyExtractFilesXpath = @"//ul[contains(@id, 'sideNav')]//li[6]";
        #endregion

        #region Page Elements

        private IWebElement _noOfAccountsToCreate
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_noOfAccountsToCreateXpath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Info("Found _view");
                return element;
            }
        }

        private IWebElement _createAccountBtn
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_createAccountBtnXpath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Info("Found _view");
                return element;
            }
        }

        private IWebElement _poolNameDropdown
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_poolNameDropdownXpath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Info("Found _view");
                return element;
            }
        }

        private IWebElement _payablesTypeDropdown
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_payablesTypeDropdownXpath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Info("Found _view");
                return element;
            }
        }

        private IWebElement _testing_Cards
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_testing_CardsXpath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Info("Found _view");
                return element;
            }
        }

        private IWebElement _testing_createCardTransactions
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_testing_CreateCardTransactionsXpath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Info("Found _view");
                return element;
            }
        }

        private IWebElement _testing_singleUseAccounts
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_testing_singleUseAccountsXpath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Info("Found _view");
                return element;
            }
        }

        private IWebElement _testing_singleUseAccountTransactions
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_testing_SingleUseAccountTransactionsXpath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Info("Found _view");
                return element;
            }
        }

        private IWebElement _testing_creditLimitUpdate
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_testing_CreditLimitUpdateXpath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Info("Found _view");
                return element;
            }
        }

        private IWebElement _testing_DailyExtractFiles
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_testing_DailyExtractFilesXpath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Info("Found _view");
                return element;
            }
        }
        #endregion

        #region Side Navigation


        public void NavigateTo_Cards()
		{
			NavigateToMenuItem(_testing_Cards);
		}

		
		public void NavigateTo_CreateCardTransactions()
		{
			NavigateToMenuItem(_testing_createCardTransactions);
		}

	
		public void NavigateTo_SingleUseAccounts()
		{
			NavigateToMenuItem(_testing_singleUseAccounts);
		}

		
		public void NavigateTo_SingleUseAccountTransactions()
		{
			NavigateToMenuItem(_testing_singleUseAccountTransactions);
		}

		public void NavigateTo_CreditLimitUpdate()
		{
			NavigateToMenuItem(_testing_creditLimitUpdate);
		}

		public void NavigateTo_DailyExtractFiles()
		{
			NavigateToMenuItem(_testing_DailyExtractFiles);
		}

		#endregion

		public string NumberOfAccountsToCreate
		{
			set
			{
				_noOfAccountsToCreate.ForceDocumentLoadOnSendKeys(value, Driver);
			}
			get
			{
				return _noOfAccountsToCreate.GetAttribute("value");
			}
		}

		public string PoolName
		{
			get { return new SelectElement(_poolNameDropdown).SelectedOption.Text.Trim(); }
			set { _poolNameDropdown.SetListboxByText(value, SelectTextOptions.StartsWith); WaitForLoad(); }
		}

		public string PoolNameByContains
		{
			get { return new SelectElement(_poolNameDropdown).SelectedOption.Text.Trim(); }
			set { _poolNameDropdown.SetListboxByText(value, SelectTextOptions.Contains); WaitForLoad(); }
		}

		public string PayablesType
		{
			get { return new SelectElement(_payablesTypeDropdown).SelectedOption.Text.Trim(); }
			set { _payablesTypeDropdown.SetListboxByText(value, SelectTextOptions.StartsWith); WaitForLoad(); }
		}

		public void CreateAccount()
		{
			_createAccountBtn.JSClickWithFocus(Driver);

		}
	}
}
