using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using Common;
using Common.PageObjects;
using Common.ScenarioConfigurations;
using Common.Utility;

namespace EnCompass.Testing.Source.PageObjects.SuperAdmin.Cluhistory 
{
	/// <summary>
	/// Auto-generated Page Model Class
	/// Navigation Paths: 
		/// [Organization Home]->Super Admin Tools->Credit Limit Update History
		/// </summary>
	[PageModel(@"/superAdmin/CLUHistory/CLUHistory.aspx")]
	public partial class Cluhistory : EnCompassSuperPageModel 
	{
		public override string RelativeUrl => @"/superAdmin/CLUHistory/CLUHistory.aspx";
		public override string PageIdentifierXPath_Generated => @"//li[contains(@class, 'breadcrumb-item active')][text() = 'Credit Limit Update History']";

		#region Navigation
		
		private void NavigateToMenuItem(IWebElement element)
		{
			Driver.Url = element.GetAttribute("href");
		}
		#endregion

		public Cluhistory(GlobalSettings settings) : base(settings) { }
	}  
}
