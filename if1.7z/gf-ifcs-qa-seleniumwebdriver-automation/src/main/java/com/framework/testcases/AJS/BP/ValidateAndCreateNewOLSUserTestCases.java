package com.framework.testcases.AJS.BP;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.common.Common;
import com.framework.pages.AJS.common.IFCSHomePage;
import com.framework.pages.AJS.common.IFCSLoginPage;
import com.github.javafaker.Faker;

public class ValidateAndCreateNewOLSUserTestCases extends BaseTest {

	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "Regression", "BusinessFlow" })
	public void validateToCreateNewOlsUserwithMerchantOnlineUser(@Optional("AU") String clientCountry,
			@Optional("BP") String clientName) {

		test = extent.createTest(
				clientName + ":" + clientCountry + "  Verify Sys_AU_004_Create new merchant online user",
				"Sys_AU_004_Create new merchant online user");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCShomePage = new IFCSHomePage(driver, test);
		// LoginPage loginPage = new LoginPage(driver, test);
		Common common = new Common(driver, test);
		// HomePage homePage = new HomePage(driver, test);

		IFCSloginPage.login("IFCS_URL_BP", "IFCS_BP_USERNAME", "IFCS_BP_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		//IFCShomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);
		IFCShomePage.gotoAdminMenuAndChooseClientGroup();
		common.goToOnlineUsers();
		Faker fakerN = new Faker();
		String testName1 = fakerN.name().firstName() + "_" + fakerN.name().lastName() + fakerN.number().digits(2);
		String testPwd = "Password" + fakerN.number().digits(2);
		
		String merchantNo = common.getMerchantNoFromDB();
		// To create Merchant Manager online user
		IFCShomePage.createNewOlsMerchantOrCustomerUser(testName1, testPwd, "Merchant Manager", merchantNo, "Merchant",
				clientName);
		// To create Merchant Support online user
		// common.goToOnlineUsers();
		// String testName2 =
		// fakerN.name().firstName()+"_"+fakerN.name().lastName()+fakerN.number().digits(3);
		// IFCShomePage.createNewOlsMerchantOrCustomerUser(testName2,testPwd,"Merchant
		// Support",merchantNo,"Merchant",clientName);

		IFCShomePage.exitIFCS();
		// Login to the OLS Application
		// loginPage.validateLoginPageFooterLinks(clientName, "BP_URL");
		// loginPage.loginWithUsernameAndPwd(testName1, testPwd);
		// Validate the
		// homePage.validateOlsLogonUser(merchantNo);

		// loginPage.Logout();
	}

	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "Regression", "BusinessFlow" })
	public void ValidateToCreateNewOlsUserwithCustomerAssigned(@Optional("AU") String clientCountry,
			@Optional("BP") String clientName) {

		test = extent.createTest(
				clientName + ":" + clientCountry + "  Verify Sys_AU_003_Create new customer online user",
				"Sys_AU_003_Create new customer online user");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCShomePage = new IFCSHomePage(driver, test);
		// LoginPage loginPage = new LoginPage(driver, test);
		Common common = new Common(driver, test);
		// HomePage homePage = new HomePage(driver, test);

		IFCSloginPage.login("IFCS_URL_BP", "IFCS_BP_USERNAME", "IFCS_BP_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		//IFCShomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);
		IFCShomePage.gotoAdminMenuAndChooseClientGroup();
		common.goToOnlineUsers();
		Faker fakerN = new Faker();
		String testName1 = fakerN.name().firstName() + "_" + fakerN.name().lastName() + fakerN.number().digits(2);
		String testPwd = "Password" + fakerN.number().digits(2);
		
		String customerNo = common.getActiveCustomerNoUsingCardType();
		// To create Merchant Manager online user
		IFCShomePage.createNewOlsMerchantOrCustomerUser(testName1, testPwd, "Fleet PIN Fleet Manager", customerNo,
				"Customer", clientName);
		// To create Merchant Support online user
		// common.goToOnlineUsers();
		// String testName2 =
		// fakerN.name().firstName()+"_"+fakerN.name().lastName()+fakerN.number().digits(3);
		// IFCShomePage.createNewOlsMerchantOrCustomerUser(testName2,testPwd,"Fleet PIN
		// Fleet Support",customerNo,"Customer",clientName);

		IFCShomePage.exitIFCS();
		// Login to the OLS Application
		// loginPage.validateLoginPageFooterLinks(clientName, "BP_URL");
		// loginPage.loginWithUsernameAndPwd(testName1, testPwd);
		// Validate the
		// homePage.validateOlsLogonUser(customerNo);
		//

	}
}
