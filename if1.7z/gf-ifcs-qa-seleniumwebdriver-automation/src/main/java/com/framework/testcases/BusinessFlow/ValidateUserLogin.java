package com.framework.testcases.BusinessFlow;

import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.common.IFCSLoginPage;
import com.framework.pages.OLS.common.CommonPage;

public class ValidateUserLogin extends BaseTest {
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow" })
	public void userCreation(String clientCountry, String clientName) {
		test = extent.createTest(clientName + ":" + clientCountry + "  User Login", "Validate Account Login");
		CommonPage commonPage = new CommonPage(driver, test);
		IFCSLoginPage ifcsLoginPage = new IFCSLoginPage(driver, test);
		ifcsLoginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		commonPage.setNewPasswordAndCheckLogin(clientName, "cust_bpauto");
	}
}
