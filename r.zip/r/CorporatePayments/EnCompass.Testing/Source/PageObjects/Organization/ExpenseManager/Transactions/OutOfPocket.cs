﻿using Common;
using Common.Utility;
using NFluent;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace EnCompass.Testing.Source.PageObjects.Organization.ExpenseManager.Transactions
{
	[PageModel(@"/expenseManager/transactions/outOfPocket.aspx")]
	public partial class OutOfPocket : EnCompassOrgPageModel
	{
		public override string RelativeUrl => @"/expenseManager/transactions/outOfPocket.aspx";
		public override string PageIdentifierXPath_Generated => @"//h1[normalize-space(text()='Out Of Pocket' and text()='Create Out of Pocket Transaction')]";

        #region XPath page Elements

        private const string _merchantNameXPath = @"//input[contains(@id, 'txtMerchantName')]";
        private const string _amountXPath = @"//input[contains(@id, 'curAmount')]";
        private const string _transactionDateXPath = @"//input[contains(@id, 'txtTransactionDate')]";
        private const string _postingDateXPath = @"//input[contains(@id, 'tbPostingDate')]";
        private const string _saveBtnXPath = @"//input[contains(@id, 'btnSaveOOP')]";
        private const string _radioCalculatedFieldXPath = @"//input[contains(@id, 'cbCalculatedField')]";
        private const string _radioCalculatedLabelXPath = @"//label[contains(@for, 'cbCalculatedField')]";
        private const string _radioOutOfPocketXPath = @"//input[contains(@id, 'cbOutOfPocket')]";
        private const string _radioOutOfPocketLabelXPath = @"//label[contains(@for, 'cbOutOfPocket')]";
        private const string _ddlCalculatedFieldsXPath = @"//select[contains(@id, 'ddlCalculatedFields')]";
        private const string _NumberOfUnitsXPath = @"//input[contains(@id, 'txtThreshold')]";
        private const string _CalcFieldTransactionDateXPath = @"//input[contains(@id, 'txtCalcFieldTransactionDate')]";
        private const string _CalcFieldPostingDateXPath = @"//input[contains(@id, 'txtCalcFieldPostingDate')]";
        private const string _txtRateXPath = @"//input[contains(@id, 'tbCalculatedRate')]";
        private const string _lblRateXPath = @"//input[contains(@id, 'lblCalculatedRate')]";
        private const string _saveBtnCalculateFildXPath = @"//input[contains(@id, 'btnSaveCalculatedField')]";
        private const string _curCalculatedRateXPath = @"//input[contains(@id, 'curCalculatedRate')]";
        #endregion

        #region Page Elements

        private IWebElement _merchantName
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_merchantNameXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_merchantName element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _amount
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_amountXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_amount element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _transactionDate
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_transactionDateXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_transactionDate element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _postingDate
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_postingDateXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_postingDate element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _saveBtn
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_saveBtnXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_saveBtn element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _radioCalculatedField
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_radioCalculatedFieldXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_radioCalculatedField element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _radioCalculatedLabel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_radioCalculatedLabelXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_radioCalculatedLabel element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _radioOutOfPocket
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_radioOutOfPocketXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_radioOutOfPocket element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _radioOutOfPocketLabel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_radioOutOfPocketLabelXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_radioOutOfPocketLabel element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _ddlCalculatedFields
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_ddlCalculatedFieldsXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_ddlCalculatedFields element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _NumberOfUnits
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_NumberOfUnitsXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_NumberOfUnits element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _CalcFieldTransactionDate
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_CalcFieldTransactionDateXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_CalcFieldTransactionDate element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _CalcFieldPostingDate
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_CalcFieldPostingDateXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_CalcFieldPostingDate element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _txtRate
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_txtRateXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_txtRate element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _lblRate
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_lblRateXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_lblRate element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _saveBtnCalculateFild
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_saveBtnCalculateFildXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_saveBtnCalculateFild element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        #endregion

        public string MerchantName
		{
			set
			{
                Driver.WaitForVisible(By.XPath(_merchantNameXPath));
                _merchantName.JsScrollToElement(Driver);
				_merchantName.Clear();
				_merchantName.SendKeys(value);
                Settings.EnCompassExtentTest.Info("Merchant Name set to:" + value);
			}
		}

		public string Amount
		{
			set
			{
				_amount.Clear();
				_amount.SendKeys(value);
				Settings.EnCompassExtentTest.Info("OOP Transaction Amount =" + value);
			}
		}

		public string TransactionDate
		{
			set
			{
				_transactionDate.Clear();
				_transactionDate.SendKeys(value);
				Settings.EnCompassExtentTest.Info("OOP Transaction Date =" + value);
			}
		}

		public string PostingDate
		{
			set
			{
				_postingDate.Clear();
				_postingDate.SendKeys(value);
				Settings.EnCompassExtentTest.Info("OOP Posting Date =" + value);
			}
		}

        public string CalculatedFieldDropdownlist
        {
            set
            {
                SelectElement ddlCalcFields = new SelectElement(_ddlCalculatedFields);
                ddlCalcFields.SelectByText(value);
                Thread.Sleep(TimeSpan.FromSeconds(2));
            }
        }

        public string NumberOfUnits
        {
            get
            {
                return _NumberOfUnits.GetAttribute("value").ToString();
            }
            set
            {
                _NumberOfUnits.ForceDocumentLoadOnSendKeys(value, Settings.EnCompassWebDriver);
                //Thread sleep is being used here in order to maintain the values
                Thread.Sleep(TimeSpan.FromSeconds(2));
            }
        }

        public string CalcFieldTransactionDate
        {
            get
            {
                return _CalcFieldTransactionDate.GetAttribute("value").ToString();
            }
            set
            {
                _CalcFieldTransactionDate.ForceDocumentLoadOnSendKeys(value, Settings.EnCompassWebDriver);
                //Thread sleep is being used here in order to maintain the values
                Thread.Sleep(TimeSpan.FromSeconds(2));
            }
        }

        public string CalcFieldPostingDate
        {
            get
            {
                return _CalcFieldPostingDate.GetAttribute("value").ToString();
            }
            set
            {
                _CalcFieldPostingDate.ForceDocumentLoadOnSendKeys(value, Settings.EnCompassWebDriver);
                Settings.EnCompassWebDriver.FindElement(By.TagName("body")).JSClickWithFocus(Driver);
                //Thread sleep is being used here in order to maintain the values
                Thread.Sleep(TimeSpan.FromSeconds(2));
            }
        }

        public string TxtRate
        {
            get
            {
                return _txtRate.GetAttribute("value").ToString();
            }
            set
            {
                _txtRate.ForceDocumentLoadOnSendKeys(value, Settings.EnCompassWebDriver);   
                //Thread sleep is being used here in order to maintain the values
                Thread.Sleep(TimeSpan.FromSeconds(2));
            }
        }

        /// <summary>
        /// This method fill the OOP Transaction with the parameters values.
        /// </summary>
        public void SetOutofPocketTransaction(string merchantName, string amount, string SDate, string EDate)
		{
			MerchantName = merchantName;
			Amount = amount;
			TransactionDate = SDate;
			PostingDate = EDate;
		}

        /// <summary>
        /// This method fill the Calculated Field Transaction with the parameters values.
        /// </summary>
        public void SetCalculatedFieldTransaction(string calcField, string unit, string trDate, string pstDate, string rate)
        {
            do
            {
                if (!string.IsNullOrEmpty(calcField))
                {
                    CalculatedFieldDropdownlist = calcField;
                    RefreshModel();
                }
                    
                if (!string.IsNullOrEmpty(unit))
                    NumberOfUnits = unit;

                if (!string.IsNullOrEmpty(trDate))
                    CalcFieldTransactionDate = trDate;

                if (!string.IsNullOrEmpty(pstDate))
                    CalcFieldPostingDate = pstDate;

                if (!string.IsNullOrEmpty(rate))
                    TxtRate = rate;
            } while (string.IsNullOrEmpty(CalcFieldTransactionDate) ||
                string.IsNullOrEmpty(CalcFieldPostingDate) ||
                string.IsNullOrEmpty(NumberOfUnits));
        }

        /// <summary>
        /// Returns the rate field value, case the value is located inside a span tag, the readOnly parameter must be true.
        /// </summary>
        public string Rate(bool readOnly = false)
        {
            if (readOnly)
                return Settings.EnCompassWebDriver.WaitForVisible(By.XPath(_curCalculatedRateXPath)).GetAttribute("innerText");
            return Settings.EnCompassWebDriver.WaitForVisible(By.XPath(_curCalculatedRateXPath)).GetAttribute("value");
        }

        public void SaveBtn()
		{
            ScrollToXPATH(_saveBtnXPath);
            _saveBtn.JSClickWithFocus(Driver);
            WaitForLoad();
			this.AttachOnDemandScreenShot();
		}

        public void SaveCalculatedField()
        {
            _saveBtnCalculateFild.JSClickWithFocus(Driver);
        }

        public void setType(string type)
        {
            if (type.ToLowerInvariant().Equals("calculated field"))
                _radioCalculatedField.SetRadioButtonStateWithLabel(_radioCalculatedLabel, true);
            else
                _radioOutOfPocket.SetRadioButtonStateWithLabel(_radioOutOfPocketLabel, true);
        }
		public OutOfPocket(GlobalSettings settings) : base(settings) { }
	}
}
