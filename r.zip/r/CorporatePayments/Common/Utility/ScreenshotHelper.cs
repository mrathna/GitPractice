﻿
using AventStack.ExtentReports;
using OpenQA.Selenium;
using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using WDSE;
using WDSE.Decorators;
using WDSE.Decorators.CuttingStrategies;
using WDSE.ScreenshotMaker;

namespace Common.Utility
{
	/// <summary>
	/// Class to encapsulate logic to take Screenshots using webdriver object 
	/// and store the screenshots in the "Sreenshot" directory.
	/// </summary>
	public class ScreenshotHelper
	{
		/// <summary>
		/// Method to capture screenshot and save it in path(specified in app.config).
		/// </summary>
		public static string TakeScreenshot(IWebDriver driver, GlobalSettings _settings, string scenarioTitle, string stepText)
		{
			try
			{
				// Try to get screenshots with Unique DateTime and Scenario Title for easy identification
				string fileNameBase = CreateScreenshotFilename();
				string scrnFolderRelPath = GlobalSettings.ScreenshotFolder;
				string artifactDirectory = PathHelper.GetAbsolutePathRelativeToProjectPath(scrnFolderRelPath);
				if (!Directory.Exists(artifactDirectory))
					Directory.CreateDirectory(artifactDirectory);

				ITakesScreenshot takesScreenshot = driver as ITakesScreenshot;
				_settings.EnCompassExtentTest.Info("Got ITakesScreenshot object");

				if (takesScreenshot != null)
				{
					var screenshot = takesScreenshot.GetScreenshot();
					_settings.EnCompassExtentTest.Info("Got Screenshot");
					string screenshotFilePath = Path.Combine(artifactDirectory, fileNameBase);
					screenshot.SaveAsFile(screenshotFilePath, ScreenshotImageFormat.Png);
                    _settings.EnCompassExtentTest.Info("Screenshot Saved in " +screenshotFilePath);
                    NUnit.Framework.TestContext.AddTestAttachment(screenshotFilePath);
                    _settings.EnCompassExtentTest.Info("Attached file to current test result");
                    return fileNameBase;
				}
				else
					_settings.EnCompassExtentTest.Info("Got null ITakesScreenshot object");
			}
			catch (Exception ex)
			{
				_settings.EnCompassExtentTest.Warning($"Error while taking screenshot: {0}" + ex.Message);
			}
			return null;
		}

		/// <summary>
		/// Uses WDSE to capture full page screenshot. Mainly called only when there are errors encountered.
		/// </summary>
		public static string TakeFullPageScreenshot(IWebDriver driver, GlobalSettings _settings, string scenarioTitle, string stepText)
		{
			try
			{
				// Try to get screenshots with Unique DateTime and Scenario Title for easy identification
				string fileNameBase = CreateScreenshotFilename();
				string scrnFolderRelPath = GlobalSettings.ScreenshotFolder;
				string artifactDirectory = PathHelper.GetAbsolutePathRelativeToProjectPath(scrnFolderRelPath);
				if (!Directory.Exists(artifactDirectory))
					Directory.CreateDirectory(artifactDirectory);

				//var wsdeScreenshot = driver.TakeScreenshot(new VerticalCombineDecorator(new ScreenshotMaker()));
				// Take Full page screenshot without footer
				var scMaker = new ScreenshotMaker();
				var cutFooterDecorator = new CutterDecorator(scMaker);
				cutFooterDecorator.SetCuttingStrategy(new CutElementHeightOnEntireWidthThenCombine(By.Id("footer")));
				var vcd = new VerticalCombineDecorator(cutFooterDecorator);
				var wsdeScreenshot = driver.TakeScreenshot(vcd);
				_settings.EnCompassExtentTest.Info("Got byte[] from wsdeScreenshot object");

				if (wsdeScreenshot != null)
				{
					_settings.EnCompassExtentTest.Info("Got Full Page Screenshot");
					string screenshotFilePath = Path.Combine(artifactDirectory, fileNameBase);
					Stream wsdeStream = new MemoryStream(wsdeScreenshot);
					Image wsdeImg = Image.FromStream(wsdeStream);
					wsdeImg.Save(screenshotFilePath, ImageFormat.Png);
					_settings.EnCompassExtentTest.Info("Full Page Screenshot Saved in " + screenshotFilePath);
					NUnit.Framework.TestContext.AddTestAttachment(screenshotFilePath);
					return fileNameBase;
				}
				else
					_settings.EnCompassExtentTest.Info("Got null byte[] from wsdeScreenshot object");
			}
			catch (Exception ex)
			{
				_settings.EnCompassExtentTest.Warning($"Error while taking Full Page screenshot: {0}" + ex.Message);
                _settings.EnCompassExtentTest.Info("Attempting to take default viewport screenshot.");
                // If Full Screen capture fails due to some reason, fall back to default screenshot
                TakeScreenshot(driver, _settings, scenarioTitle, stepText);
            }
			return null;
		}

        /// <summary>
        /// Capture on demand screenshot for Windows Element
        /// </summary>
        public static void OnDemandWinDriverScreenshot(Screenshot scrnshot, GlobalSettings _settings)
        {
            try
            {
                // Try to get screenshots with Unique DateTime and Scenario Title for easy identification
                string fileNameBase = CreateScreenshotFilename();
                string scrnFolderRelPath = GlobalSettings.ScreenshotFolder;
                string artifactDirectory = PathHelper.GetAbsolutePathRelativeToProjectPath(scrnFolderRelPath);
                if (!Directory.Exists(artifactDirectory))
                    Directory.CreateDirectory(artifactDirectory);

                if (scrnshot != null)
                {
                    _settings.EnCompassExtentTest.Info("Got Windows Driver Screenshot");
                    string screenshotFilePath = Path.Combine(artifactDirectory, fileNameBase);
                    Stream wsdeStream = new MemoryStream(scrnshot.AsByteArray);
                    Image wsdeImg = Image.FromStream(wsdeStream);
                    wsdeImg.Save(screenshotFilePath, ImageFormat.Png);
                    _settings.EnCompassExtentTest.Info("Windows DriverScreenshot Saved in " + screenshotFilePath);
                    NUnit.Framework.TestContext.AddTestAttachment(screenshotFilePath);
                    _settings.EnCompassExtentTest.Info("Custom Captured Screenshot: ", MediaEntityBuilder.CreateScreenCaptureFromPath("./Screenshots/" + fileNameBase).Build());
                }
                else
                    _settings.EnCompassExtentTest.Info("Got null byte[] from wsdeScreenshot object");
            }
            catch (Exception ex)
            {
                _settings.EnCompassExtentTest.Warning($"Error while taking OnDemandWinDriverScreenshot: " + ex.Message + "\n" + ex.StackTrace);
            }
        }
       
		/// <summary>
		/// Compose the filename of the screenshot to be saved as
		/// </summary>
		private static string CreateScreenshotFilename()
		{
			// However, apparently we need to conform to the char count limitation - "The fully qualified file name must be less than 260 characters, 
			// and the directory name must be less than 248 characters." Hence the check to truncate leading chars if it grows more than 260 as a fallback
			string fileNameBase = string.Format("{0}", DateTime.Now.ToString("ssffff")).Replace(" ", "_").Replace("\"", "_") + ".png";
			fileNameBase = (fileNameBase.Count() > 12) ? fileNameBase.Remove(0, (fileNameBase.Count() - 12)) : fileNameBase;
			return fileNameBase;
		}
			   
		/*
		/// <summary>
		/// Method to create Screencast Video Recording
		/// </summary>
		/// <param name="scenarioTitle"></param>
		/// <param name="scenarioContext"></param>
		/// <returns></returns>
		public static string StartScreenCapture(string scenarioTitle, ScenarioContext scenarioContext)
		{
			string fileNameBase = scenarioTitle+ ".wmv";				
			string scrnFolderRelPath = GlobalSettings.ScreencastFolder;
			string artifactDirectory = PathHelper.GetAbsolutePathRelativeToProjectPath(scrnFolderRelPath);
			if (!Directory.Exists(artifactDirectory))
				Directory.CreateDirectory(artifactDirectory);

			ScreenCaptureJob scj = new ScreenCaptureJob();
			scj.OutputScreenCaptureFileName = Path.Combine(artifactDirectory, fileNameBase); 
			if(File.Exists(scj.OutputScreenCaptureFileName))
				File.Delete(scj.OutputScreenCaptureFileName);
			scj.Start();
			scenarioContext.Add("ScreenCaptureObject", scj);

			return fileNameBase;			
		}*/

	}
}
