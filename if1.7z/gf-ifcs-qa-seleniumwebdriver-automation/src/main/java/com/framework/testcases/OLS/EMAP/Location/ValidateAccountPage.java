package com.framework.testcases.OLS.EMAP.Location;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.EMAP.EMAPAccountsPage;
import com.framework.pages.EMAP.EMAPHomePage;
import com.framework.pages.OLS.common.LoginPage;

public class ValidateAccountPage extends BaseTest {
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "Regression" })
	public void validateAccountPage(@Optional("SP") String clientCountry, @Optional("EMAP") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  TST-SC-83-OLS Location Site - Account",
				"Login to EMAP Location - Read Only User and check the Account page");
		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		EMAPHomePage emapHomePage = new EMAPHomePage(driver, test);
		EMAPAccountsPage locationAccountPage = new EMAPAccountsPage(driver, test);
		loginPage.Login("EMAP_URL", "EMAP_UN_ReadOnly_Location_" + clientCountry,
				"EMAP_PWD_ReadOnly_Location_" + clientCountry, clientName);

		emapHomePage.checkThePresenceOfQuickLinksOnHomePage("Loc-Read-Only");
		// Location
		emapHomePage.clickLocationAndValidatePage();
		locationAccountPage.checkThePresenceOfTradingNameAndAccountName();
		 locationAccountPage.validateTheAccountMaintenancePageFields(clientCountry);
		locationAccountPage.validateTheContactsTableFields();

		// Contacts
		emapHomePage.clickContactsAndValidatePage();
		locationAccountPage.validateTheContactsTableFields();
		locationAccountPage.checkThePresenceOfAddAContactAndExportOption();

		// // Footer Links - Exxon Mobil Corporation link
		// emapHomePage.clickExxonMobilCorporationInFooterAndValidatePage();
		// emapHomePage.clickHomeMenuAndValidatePage("Loc");

		// Footer Links - Contact Us
		emapHomePage.clickContactUsInFooterAndValidatePage();
		emapHomePage.clickHomeMenuAndValidatePage("Loc");

		// Footer Links - Copyright
		emapHomePage.clickCopyRightAndValidatePage(clientName);
		emapHomePage.clickHomeMenuAndValidatePage("Loc");

		// Footer Links - Terms And Condition
		emapHomePage.checkThePresenceOfTermsAndConditionInFooter();

		// Footer Links - Privacy Statement
		//emapHomePage.clickPrivacyPolicyAndValidatePage();

	/*	// // Footer Links - Client Logos
		emapHomePage.clickExxonMobilLogoAndValidatePage();
		//emapHomePage.clickEssoLogoAndValidatePage();
		emapHomePage.clickMobilLogoAndValidatePage();*/

		// Logout
		loginPage.Logout();
	}
}
