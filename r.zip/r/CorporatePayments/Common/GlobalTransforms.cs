﻿using Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using TechTalk.SpecFlow;

namespace Common
{
    [Binding]
    public class GlobalTransforms
    {
        protected GlobalSettings _settings;

        protected const string SCENARIO_CONTEXT_PREFIX = "SCXT";
        protected const string FEATURE_CONTEXT_PREFIX = "FCXT";
		// This was needed to handle multiple layer of Context prefixes.  
		// e.g- [%B64:UPDATE o SET MqTestingModeId = 1 FROM organization o where o.bankno ='[%SCXT:BankNo%]'and o.companyno ='[%SCXT:CompNo%]' %]
		protected const string MATCH_EXPRESSION = @"\[(?!.*\[)%(.*?)%\]*"; //@"\[%(.*?)%(?!.*%)\]*";
        protected const string SECRET_PREFIX = "SCRT";
		protected const string BASE_64_PREFIX = "B64";


		public GlobalTransforms(GlobalSettings settings)
        {
            _settings = settings;
        }

        [StepArgumentTransformation]
        public SourceString LookupInExternalDatasource(string inputValue)
        {
			try
			{
				// allow multiple matches to be found and replaced in the same inputValue
				// (eg. [%Open~Url%]?parameter=[%Special~Parameter%])
				var keyMatches = Regex.Matches(inputValue, MATCH_EXPRESSION);
				if (keyMatches.Count == 0)
				{
					return new SourceString(inputValue, null);
				}
				else
				{
					string outputValue = inputValue;
					outputValue = ProcessKeyText(keyMatches, outputValue);
					return LookupInExternalDatasource(outputValue);
				}
			}catch(Exception ex)
			{
				_settings.EnCompassExtentTest.Error("Exception caught in Global Transforms. Input Value to Transforms:" + inputValue);
				_settings.EnCompassExtentTest.Info("Exception Message:" + ex.Message);
				throw ex;
			}
        }

		/// <summary>
		/// Method to process the Regex matches and substitue with appropriate values.
		/// e.g. [%SCXT:sss%] , [%B64:dd%] etc
		/// </summary>
		private string ProcessKeyText(MatchCollection keyMatches, string outputValue)
		{
			foreach (Match match in keyMatches)
			{
				string keyText = match.Value.Trim("[%]".ToCharArray());
				if (keyText.StartsWith(SCENARIO_CONTEXT_PREFIX))
				{
					keyText = keyText.Replace('\'', ' '); // Get rid off [%] from string
					var data = this.GetDataFromScenarioContext(keyText);
					outputValue = outputValue.Replace(match.Value, data.ToString());
				}
				else if (keyText.StartsWith(FEATURE_CONTEXT_PREFIX))
				{
					keyText = keyText.Replace('\'', ' ');// Get rid off [%] from string
					var data = this.GetDataFromFeatureContext(keyText);
					outputValue = outputValue.Replace(match.Value, data.ToString());
				}
				else if (keyText.StartsWith(SECRET_PREFIX))
				{
					keyText = keyText.Replace('\'', ' ');// Get rid off [%] from string
					var contextKey = keyText.Replace($"{SECRET_PREFIX}:", string.Empty);
					outputValue = $"{GlobalSettings.Environment}{GlobalSettings.FI}{contextKey}";
				}
				else if (keyText.StartsWith(BASE_64_PREFIX))
				{
					var contextKey = keyText.Replace($"{BASE_64_PREFIX}:", string.Empty);
					outputValue = Convert.ToBase64String(Encoding.ASCII.GetBytes(contextKey), Base64FormattingOptions.None);
				}
				else
				{
					keyText = keyText.Replace('\'', ' ');
					int tableIndex = 0;
					if (keyText.Contains(":"))
					{
						var parts = keyText.Split(':');
						if (!string.IsNullOrWhiteSpace(parts[0]))
						{
							tableIndex = _settings.ScenarioConfiguration.Data.Tables.IndexOf(parts[0]);
						}
						keyText = parts[1];
					}
					var entity = _settings.ScenarioConfiguration.Data.Tables[tableIndex].Rows[0];
					outputValue = outputValue.Replace(match.Value, entity[keyText].ToString());
				}
			}

			return outputValue;
		}

        [StepArgumentTransformation]
        public bool ConvertBool(string input)
        {
            var data = LookupInExternalDatasource(input);
            bool result;
            if (bool.TryParse(data.ToString(), out result))
            {
                return result;
            }
            throw new Exception($"Unable to convert {input} to Bool");
        }

        [StepArgumentTransformation]
        public int ConvertInt(string input)
        {
            var data = LookupInExternalDatasource(input);
            int result;
            if (int.TryParse(data.ToString(), out result))
            {
                return result;
            }
            throw new Exception($"Unable to convert {input} to Integer.");
        }

        [StepArgumentTransformation]
        public double ConvertDouble(string input)
        {
            var data = LookupInExternalDatasource(input);
            double result;
            if (double.TryParse(data.ToString(), out result))
            {
                return result;
            }
            throw new Exception($"Unable to convert {input} to Double.");
        }

        [StepArgumentTransformation]
        public decimal ConvertDecimal(string input)
        {
            var data = LookupInExternalDatasource(input);
            decimal result;
            if (decimal.TryParse(data.ToString(), out result))
            {
                return result;
            }
            throw new Exception($"Unable to convert {input} to Decimal.");
        }

        [StepArgumentTransformation]
        public float ConvertFloat(string input)
        {
            var data = LookupInExternalDatasource(input);
            float result;
            if (float.TryParse(data.ToString(), out result))
            {
                return result;
            }
            throw new Exception($"Unable to convert {input} to Float.");
        }

        [StepArgumentTransformation]
        public long ConvertLong(string input)
        {
            var data = LookupInExternalDatasource(input);
            long result;
            if (long.TryParse(data.ToString(), out result))
            {
                return result;
            }
            throw new Exception($"Unable to convert {input} to Long.");
        }

        [StepArgumentTransformation]
        public IEnumerable<string> ConvertStringCollection(string input)
        {
            input = LookupInExternalDatasource(input).ToString();
            var pieces = input.Split(new[] { ',', ';' });
            return pieces;
        }

        [StepArgumentTransformation]
        public Dictionary<string, string> ConvertDictionaryCollection(string input)
        {
            var keyMatches = Regex.Matches(input, MATCH_EXPRESSION);
            if (keyMatches.Count == 0)
            {
                return null;
            }

            var match = keyMatches[0];

            string keyText = match.Value.Trim("[%]".ToCharArray()).Replace('\'', ' ');
            if (keyText.StartsWith(SCENARIO_CONTEXT_PREFIX))
            {
                return this.GetDataFromScenarioContext<Dictionary<string, string>>(keyText);
            }
            else if (keyText.StartsWith(FEATURE_CONTEXT_PREFIX))
            {
                return this.GetDataFromFeatureContext<Dictionary<string, string>>(keyText);
            }

            return null;
        }

        [StepArgumentTransformation]
        public List<string> ConvertStringToList(string input)
        {
            return ConvertStringCollection(input).ToList();
        }

		protected string GetDataFromScenarioContext(string key)
        {
            var contextKey = key.Replace($"{SCENARIO_CONTEXT_PREFIX}:", string.Empty);
            if (_settings.Scenario.ContainsKey(contextKey))
            {
                var rawValue = _settings.Scenario[contextKey];
                if (rawValue == null)
                {
                    return string.Empty;
                }
                else if (rawValue is List<string>)
                {
                    return string.Join(";", rawValue as List<string>);
                }

                return rawValue.ToString();
            }
            return null;
        }

        protected T GetDataFromScenarioContext<T>(string key)
        {
            var contextKey = key.Replace($"{SCENARIO_CONTEXT_PREFIX}:", string.Empty);
            if (_settings.Scenario.ContainsKey(contextKey))
            {
                var rawValue = _settings.Scenario[contextKey];
                if (rawValue is T result)
                {
                    return result;
                }

            }
            return default(T);
        }

		protected string GetDataFromFeatureContext(string key)
        {
            var contextKey = key.Replace($"{FEATURE_CONTEXT_PREFIX}:", string.Empty);
            if (_settings.Feature.ContainsKey(contextKey))
            {
                var rawValue = _settings.Feature[contextKey];
                if (rawValue == null)
                {
                    return string.Empty;
                }
                else if (rawValue is List<string>)
                {
                    return string.Join(";", rawValue as List<string>);
                }

                return rawValue.ToString();
            }
            return null;
        }

		protected T GetDataFromFeatureContext<T>(string key)
        {
            var contextKey = key.Replace($"{FEATURE_CONTEXT_PREFIX}:", string.Empty);
            if (_settings.Feature.ContainsKey(contextKey))
            {
                var rawValue = _settings.Feature[contextKey];
                if (rawValue is T result)
                {
                    return result;
                }
            }
            return default(T);
        }
    }
}
