using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using Common;
using Common.PageObjects;
using Common.ScenarioConfigurations;
using Common.Utility;

namespace EnCompass.Testing.Source.PageObjects.Organization.Admin.Management 
{
	/// <summary>
	/// Auto-generated Page Model Class
	/// Navigation Paths: 
		/// [Organization Home]->Administration->Account Change Codes
		/// </summary>
	[PageModel(@"/admin/management/AccountChangeCodes.aspx")]
	public partial class AccountChangeCodes : EnCompassOrgPageModel 
	{
		public override string RelativeUrl => @"/admin/management/AccountChangeCodes.aspx";
		public override string PageIdentifierXPath_Generated => @"//li[contains(@class, 'breadcrumb-item active')][text() = 'Account Change Codes']";

		#region Navigation
		
		private void NavigateToMenuItem(IWebElement element)
		{
			Driver.Url = element.GetAttribute("href");
		}
		#endregion

		public AccountChangeCodes(GlobalSettings settings) : base(settings) { }
	}  
}
