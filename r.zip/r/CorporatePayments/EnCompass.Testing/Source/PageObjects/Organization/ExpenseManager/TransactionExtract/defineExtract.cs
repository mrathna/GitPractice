﻿using Common;
using Common.Utility;
using NFluent;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EnCompass.Testing.Source.PageObjects.Organization.ExpenseManager.TransactionExtract
{
    [PageModel(@"/expenseManager/transactionExtract/defineExtract.aspx")]
    public class DefineExtract : EnCompassOrgPageModel
    {
        public override string RelativeUrl => @"/expenseManager/transactionExtract/defineExtract.aspx";
        public override string PageIdentifierXPath_Override => @"//li[@class='breadcrumb-item active'][text() = 'Define']";

        #region XPath page Elements
        private const string _btnDefineExtractXpath = @"//input[contains(@id,'cmdDefineExtract')]";
        #endregion

        #region Page Elements
        private IWebElement _btnDefineExtract
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_btnDefineExtractXpath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Info("Found _view");
                return element;
            }
        }

        #endregion

        public DefineExtract(GlobalSettings settings) : base(settings) { }

         
        public void BtnDefineExtract()
        {
            _btnDefineExtract.JSClickWithFocus(Driver);
        }

    }
}
