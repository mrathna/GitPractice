/*
   *  02-05-2018
   *  Ayub Khan
   */
package com.framework.pages.BP;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.ExtentTest;
import com.framework.basepage.BasePage;
import com.framework.repo.Locator;

public class BPCardReissuePage extends BasePage {

	@FindBy(how = How.XPATH, using = Locator.ENTER_ANOTHER_ADDRESS)
	public WebElement enterAnotherAddress;
	@FindBy(how = How.XPATH, using = Locator.DELIVER_CARD_TO_THIS_ADDRESS)
	public WebElement deliverCardTothisAddress;
	@FindBy(how = How.ID, using = Locator.DELIVER_TITLE)
	public WebElement dTitle;
	@FindBy(how = How.ID, using = Locator.DELIVER_CONTACT_NAME)
	public WebElement dContactName;
	@FindBy(how = How.ID, using = Locator.DELIVER_ADDRESS)
	public WebElement dAddresss;
	@FindBy(how = How.ID, using = Locator.DELIVER_SUBURB)
	public WebElement dSuburb;
	@FindBy(how = How.ID, using = Locator.DELIVER_POSTCODE)
	public WebElement dPostCode;
	@FindBy(how = How.ID, using = Locator.DELIVER_STATE)
	public WebElement dState;
	@FindBy(how = How.ID, using = Locator.DELIVER_CONFIRM_AND_REISSUE)
	public WebElement dConfirmAndReissue;
	@FindBy(how = How.ID, using = Locator.CONFIRMATIONMESSAGE)
	public WebElement confirmationMessage;

	/*private String deliverytitle = "";
	private String deliveryContactName = "";
	private String deliveryAddress = "";
	private String deliverySuburb = "";
	private String deliveryPostcode = "";*/

	public BPCardReissuePage(WebDriver driver, ExtentTest test) {
		super(driver, test);
		PageFactory.initElements(driver, this);
		// TODO Auto-generated constructor stub
	}

	public void clickAnotherAddressButton() {
		isDisplayedThenClick(enterAnotherAddress, "ddress Radio Button");
	}

	public void deliverCardTothisAddress() {
		isDisplayedThenClick(deliverCardTothisAddress, "Address Radio Button");
	}

	public void typeDelivryTitle() {
		isDisplayedThenEnterText(dTitle, "Delivery Title Name", fakerAPI().name().username().toString());
	}

	public void typeDelivryContactName() {
		isDisplayedThenEnterText(dContactName, "Delivery Contact Name", fakerAPI().name().username().toString());
	}

	public void typeDelivryAddress() {
		isDisplayedThenEnterText(dAddresss, "Delivery Address", fakerAPI().name().username().toString());
	}

	public void typeDelivrySuburb() {
		isDisplayedThenEnterText(dSuburb, "Delivery Suburb", fakerAPI().name().username().toString());
	}

	public void typeDelivrySuburb(String clientCountry) {
		if (clientCountry.equalsIgnoreCase("AU")) {
			isDisplayedThenEnterText(dSuburb, "Delivery Suburb", fakerAPI().name().username().toString());
		} else {
			logInfo("No SubUrb field");
		}
	}

	public void typeDelivryPostCode() {
		isDisplayedThenEnterText(dPostCode, "Delivery Postcode Level Pin",
				String.valueOf(fakerAPI().number().numberBetween(1901, 1999)));
	}
	/*
	 * Ayub Khan 03-05-2018
	 */

	public void selectInputFromAlertThreshold(String clientCountry) {
		if (clientCountry.equalsIgnoreCase("AU")) {
			isDisplayed(dState, "Selected input from dropdown State");
			selectInputFromDropdown(dState, 1);
		} else {
			logInfo("No SubUrb field");
		}
	}

	public void confirmAndReissue() {
		isDisplayedThenClick(dConfirmAndReissue, "Confirm And Reissue Button");
	}

	public void checkConfirmationMessage() {
		isDisplayed(confirmationMessage, "Confirmation message");
		verifyText(confirmationMessage,
				"You card has been successfully re-issued and will arrive within 5 working days.");
	}
}
