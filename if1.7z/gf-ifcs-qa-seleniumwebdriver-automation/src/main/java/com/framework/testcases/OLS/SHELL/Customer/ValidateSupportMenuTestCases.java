package com.framework.testcases.OLS.SHELL.Customer;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.OLS.HomePage;
import com.framework.pages.OLS.common.LoginPage;
import com.framework.pages.SHELL.SHELLChangePasswordPage;
import com.framework.pages.SHELL.SHELLHomePage;
import com.framework.pages.SHELL.SHELLSupportPage;
import com.framework.pages.SHELL.UpdateLanguage;

public class ValidateSupportMenuTestCases extends BaseTest {

	@Parameters({ "clientCountry", "clientName", "cardType"})
	@Test(groups = { "Regression" })
	public void validateChangePassword(@Optional("AT") String clientCountry,
			@Optional("SHELL") String clientName,@Optional("APA") String cardType) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  Shell AT Change Password", "Validate Change Password");

		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		HomePage homePage = new HomePage(driver, test);
		SHELLHomePage shellHomePage = new SHELLHomePage(driver, test);
		SHELLChangePasswordPage shellChangePasswordPage = new SHELLChangePasswordPage(driver, test);

		// Calling Functions
				if(cardType.equals("PC"))
			    {
			    	loginPage.Login("SHLPC_URL", "SHLPC_UN_Customer_Admin_" + clientCountry, "SHLPC_PWD_Customer_Admin_" + clientCountry, clientName);
			    }
			    else if(cardType.equals("APA"))
			    {
			    	loginPage.Login("SHLAPA_URL", "SHLAPA_UN_Customer_Admin_" + clientCountry, "SHLAPA_PWD_Customer_Admin_" + clientCountry, clientName);
			    }
		//
		homePage.ValidateLogoutLink();
		homePage.ValidateHelpShellLink();
		homePage.ValidateWelcomeText(clientName+"#"+cardType);
		homePage.ValidateQuickLinks();
		shellHomePage.ValidateHeaderMenus("Admin");
		shellHomePage.ValidateFooterMenus();

		// Selecting the Change Password from Support Tab
		shellHomePage.goToSupportMenuChangePassword();
		
		shellChangePasswordPage.validatePasswordMaintenancePage();
		
		
		// Verify the User ID
		shellChangePasswordPage.verifyCustomerAdminUserId();
		
		// Verify entering Invalid Password
		shellChangePasswordPage.enterInvalidPwdValidNewPwdConfirmPwdAndValidate();
		
		// Verify entering Invalid Password
		shellChangePasswordPage.enterPwdInvalidNewPwdConfirmPwdAndValidate();
				
		// Verify entering Invalid Password
		shellChangePasswordPage.enterPwdLessThanNewPwdConfirmPwdAndValidate();
		
		
		// * we need to update with current password to change success
		 
		if(cardType.equals("PC"))
	    {
			// Verify entering valid Password
//			shellChangePasswordPage.enterValidPwdNewPwdConfirmPwdAndValidate("SHLPC_PWD_Customer_Admin_" + clientCountry);
	    }
	    else if(cardType.equals("APA"))
	    {
//	    	shellChangePasswordPage.enterValidPwdNewPwdConfirmPwdAndValidate("SHLAPA_PWD_Customer_Admin_" + clientCountry);
	    }
		
		
		loginPage.Logout();
		
	}

	@Parameters({ "clientCountry", "clientName", "cardType"})
	@Test(groups = { "Regression" })
	public void validateTermsAndConditionsPage(@Optional("AT") String clientCountry,
			@Optional("SHELL") String clientName, @Optional("APA") String cardType) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  02 Terms and Conditions", "Validate Terms and Conditions");

		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		HomePage homePage = new HomePage(driver, test);
		SHELLHomePage shellHomePage = new SHELLHomePage(driver, test);
		SHELLSupportPage shellSupportPage = new SHELLSupportPage(driver, test);

		// Calling Functions
		if(cardType.equals("PC"))
	    {
	    	loginPage.Login("SHLPC_URL", "SHLPC_UN_Customer_Admin_" + clientCountry, "SHLPC_PWD_Customer_Admin_" + clientCountry, clientName);
	    }
	    else if(cardType.equals("APA"))
	    {
	    	loginPage.Login("SHLAPA_URL", "SHLAPA_UN_Customer_Admin_" + clientCountry, "SHLAPA_PWD_Customer_Admin_" + clientCountry, clientName);
	    }
		//
		homePage.ValidateLogoutLink();
		homePage.ValidateHelpShellLink();
		homePage.ValidateWelcomeText(clientName+"#"+cardType);
		homePage.ValidateQuickLinks();
		shellHomePage.ValidateHeaderMenus("Admin");
		shellHomePage.ValidateFooterMenus();

		// Selecting the Change Password from Support Tab
		shellHomePage.goToSupportMenuContactUs();
		shellSupportPage.validateContactUsPageFooterLinks();
				
		// Verify the Page Redirection and Close new tab
		shellSupportPage.clickAndValidatePageRedirectingToNewTabContains();
		
		// Click Logout
		loginPage.Logout();
	}
	
	@Parameters({ "clientCountry", "clientName", "cardType"})
	@Test(groups = { "Regression" })
	public void validateContactUsFunctionality(@Optional("AT") String clientCountry,
			@Optional("SHELL") String clientName, @Optional("APA") String cardType) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  03 Contact Us,03a Contact Us  Valid Change -  Phone number,03b Contact Us  invalid Change -  Email,03c Contact Us  Valid Change -  Email", "Validate the Support Contact Us Page");

		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		HomePage homePage = new HomePage(driver, test);
		SHELLHomePage shellHomePage = new SHELLHomePage(driver, test);
		SHELLSupportPage shellSupportPage = new SHELLSupportPage(driver, test);

		// Calling Functions
		if(cardType.equals("PC"))
	    {
	    	loginPage.Login("SHLPC_URL", "SHLPC_UN_Customer_Admin_" + clientCountry, "SHLPC_PWD_Customer_Admin_" + clientCountry, clientName);
	    }
	    else if(cardType.equals("APA"))
	    {
	    	loginPage.Login("SHLAPA_URL", "SHLAPA_UN_Customer_Admin_" + clientCountry, "SHLAPA_PWD_Customer_Admin_" + clientCountry, clientName);
	    }
		//
		homePage.ValidateLogoutLink();
		homePage.ValidateHelpShellLink();
		homePage.ValidateWelcomeText(clientName+"#"+cardType);
		homePage.ValidateQuickLinks();
		shellHomePage.ValidateHeaderMenus("Admin");
		shellHomePage.ValidateFooterMenus();

		// Selecting the Change Password from Support Tab
		shellHomePage.goToSupportMenuContactUs();
		shellSupportPage.validateContactUsPageFooterLinks();
		//Validating the Contact Us fields and Contact Us preferences.		
		shellSupportPage.validateTheContactUsPageFields();
		shellSupportPage.validateTheContactUsPageFunctionality();
		
		// Click Logout
		loginPage.Logout();
	}

	
	
	// Added by Ayub on 19.06.2018
	
	@Parameters({ "clientCountry", "clientName", "cardType"})
	@Test(groups = { "Regression" })
	public void validateCloseAccount(@Optional("AT") String clientCountry,
			@Optional("SHELL") String clientName, @Optional("APA") String cardType) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  Shell 05 Close Account", "Validate Close Account");

		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		HomePage homePage = new HomePage(driver, test);
		SHELLHomePage shellHomePage = new SHELLHomePage(driver, test);
		SHELLSupportPage shellSupportPage = new SHELLSupportPage(driver, test);

		// Calling Functions
		if(cardType.equals("PC"))
	    {
	    	loginPage.Login("SHLPC_URL", "SHLPC_UN_Customer_Admin_" + clientCountry, "SHLPC_PWD_Customer_Admin_" + clientCountry, clientName);
	    }
	    else if(cardType.equals("APA"))
	    {
	    	loginPage.Login("SHLAPA_URL", "SHLAPA_UN_Customer_Admin_" + clientCountry, "SHLAPA_PWD_Customer_Admin_" + clientCountry, clientName);
	    }
		//
		homePage.ValidateLogoutLink();
		homePage.ValidateHelpShellLink();
		homePage.ValidateWelcomeText(clientName+"#"+cardType);
		homePage.ValidateQuickLinks();
		shellHomePage.ValidateHeaderMenus("Admin");
		shellHomePage.ValidateFooterMenus();
		
		// Select the Close Account 
		shellHomePage.goToSupportMenuCloseAccount();
		
		boolean isCloseAccountdataPresentorNot =  shellSupportPage.verifyCloseAccountDetailsareAvailable();
		
		if(isCloseAccountdataPresentorNot)
		{
			shellSupportPage.printNoAccountDetailsDataPresent();
		} else {
		
		// Add comment and submit it
		shellSupportPage.typeCommentAndSubmit();
		}
		// Click Logout
		loginPage.Logout();
		
	}
	
	@Parameters({ "clientCountry", "clientName", "cardType"})
	@Test(groups = { "Regression" })
	public void validateUploadDocumentOnContactUs(@Optional("AT") String clientCountry,
			@Optional("SHELL") String clientName, @Optional("APA") String cardType) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  12 Upload document on contact us page", "Validate Upload Document on Support Contact Us Page");

		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		HomePage homePage = new HomePage(driver, test);
		SHELLHomePage shellHomePage = new SHELLHomePage(driver, test);
		SHELLSupportPage shellSupportPage = new SHELLSupportPage(driver, test);

		// Calling Functions
		if(cardType.equals("PC"))
	    {
	    	loginPage.Login("SHLPC_URL", "SHLPC_UN_Customer_Admin_" + clientCountry, "SHLPC_PWD_Customer_Admin_" + clientCountry, clientName);
	    }
	    else if(cardType.equals("APA"))
	    {
	    	loginPage.Login("SHLAPA_URL", "SHLAPA_UN_Customer_Admin_" + clientCountry, "SHLAPA_PWD_Customer_Admin_" + clientCountry, clientName);
	    }
		//
		homePage.ValidateLogoutLink();
		homePage.ValidateHelpShellLink();
		homePage.ValidateWelcomeText(clientName+"#"+cardType);
		homePage.ValidateQuickLinks();
		shellHomePage.ValidateHeaderMenus("Admin");
		shellHomePage.ValidateFooterMenus();

		// Selecting the Change Password from Support Tab
		shellHomePage.goToSupportMenuContactUs();

		shellSupportPage.validateContactUsPage();
		
		// Click upload Button
		shellSupportPage.clickUploadButtonAndValidate();
		
		// Upload File from Local
		shellSupportPage.validateBrowseFileFromLocal();
		
		shellSupportPage.clickUploadFileButtonFromPopup();
		// Click Logout
		loginPage.Logout();
	}
	
	// Added by Ayub 0n 16-7-2018
	
	@Parameters({"clientCountry","clientName", "cardType"})
	@Test(groups = { "Regression" })
	public void validateUpdateLanguage(@Optional("AT") String clientCountry, @Optional("SHELL") String clientName, @Optional("APA") String cardType)  {
		
		test = extent.createTest(clientName+ ":" +clientCountry+"  Shell AT 04 Update language for a customer user", "Checking Customer Update Language");

        //Creating Objects for the Pages
        LoginPage loginPage = new LoginPage(driver, test);
        HomePage homePage = new HomePage(driver, test);
        SHELLHomePage shellHomePage = new SHELLHomePage(driver, test);
        UpdateLanguage updateLanguage = new UpdateLanguage(driver, test);
      
		// Calling Functions
        if(cardType.equals("PC"))
        {
        	loginPage.Login("SHLPC_URL", "SHLPC_UN_Customer_Admin_" + clientCountry, "SHLPC_PWD_Customer_Admin_" + clientCountry, clientName);
        }
        else if(cardType.equals("APA"))
        {
        	loginPage.Login("SHLAPA_URL", "SHLAPA_UN_Customer_Admin_" + clientCountry, "SHLAPA_PWD_Customer_Admin_" + clientCountry, clientName);
        }
        homePage.ValidateLogoutLink();
		homePage.ValidateHelpShellLink();
		homePage.ValidateWelcomeText(clientName+"#"+cardType);
		homePage.ValidateQuickLinks();
		shellHomePage.ValidateHeaderMenus("Admin");
		shellHomePage.ValidateFooterMenus();
		shellHomePage.goToUserProfile(); 
		updateLanguage.updateLanguagePage();
		loginPage.Logout();
		 if(cardType.equals("PC"))
	        {
	        	loginPage.Login("SHLPC_URL", "SHLPC_UN_Customer_Admin_" + clientCountry, "SHLPC_PWD_Customer_Admin_" + clientCountry, clientName);
	        }
	        else if(cardType.equals("APA"))
	        {
	        	loginPage.Login("SHLAPA_URL", "SHLAPA_UN_Customer_Admin_" + clientCountry, "SHLAPA_PWD_Customer_Admin_" + clientCountry, clientName);
	        }
		shellHomePage.goToUserProfile();  
		updateLanguage.validateLanguageSelection();
    	loginPage.Logout();
	}
	 
}
