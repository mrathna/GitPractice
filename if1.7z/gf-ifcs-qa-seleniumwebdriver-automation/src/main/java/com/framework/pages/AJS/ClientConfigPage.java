package com.framework.pages.AJS;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashSet;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

import com.aventstack.extentreports.ExtentTest;
import com.framework.pages.AJS.common.Common;
import com.framework.pages.AJS.common.CommonInterfacePage;
import com.framework.repo.Locator_IFCS;
import com.framework.util.PropUtils;
import com.framework.util.SeleniumWrappers;

/**
 * @author nmanikandan
 *
 */
public class ClientConfigPage extends Common {

	
	@FindBy(xpath = Locator_IFCS.CLIENTCONFIG_LEFTPANEL)
	public WebElement clientConfigLeftPanel;

	

	@FindBy(xpath = Locator_IFCS.OPTIONAL_FOR_CARD)
	public WebElement optionalForCard;
	
	@FindBy(xpath = Locator_IFCS.FEECONFIG_TABLE)
	public WebElement feeConfigTableData;
	
	@FindBy(xpath = Locator_IFCS.FEEAGREEMENT_TABLE)
	public WebElement feeAgreementTableData;
	
	@FindBy(xpath = Locator_IFCS.FEEVALUES_TABLE)
	public WebElement feeValuesTableData;
	

	@FindBy(xpath = Locator_IFCS.CARDFEES_TABLE)
	public WebElement cardFeesTable;
	
	@FindBy(xpath = Locator_IFCS.CALENDAR_FREQUENCIES)
	public WebElement calendarFrequencies;
	
	@FindBy(xpath = Locator_IFCS.OK_BUTTON_SHORTCUT_POPUP)
	public WebElement okButtonShortPopup;

	String nameText = fakerAPI().name().firstName();


	public ClientConfigPage(WebDriver driver, ExtentTest test) {
		super(driver, test);
		PageFactory.initElements(new AjaxElementLocatorFactory(driver, 15), this);

	}
	public void verifyBalanceAlert() {
		chooseSubMenuFromLeftPanel("Customers", "Contact Ranks");
		validateHeaderLabel("Contact Ranks");
        verifyCardRankTable("Account Balance Alert", "Account Balance Alert", "2");
		verifyCardRankTable("Card Balance Alert", "Card Balance Alert", "1");
		
		}

	public void verifyCardProducts() {
		Common common = new Common(driver, test);
		isDisplayed(clientConfigLeftPanel, "Client Config");
		chooseSubMenuFromLeftPanel("Card Offers", "Card Products");
		common.selectFirstRowNumberInSearchList();
		popupForCardProducts();
	}

	public void popupForCardProducts() {
		Common common = new Common(driver, test);
		validatePopupHeaderText("Card Products");
		verifyTabNameAndSize("Embossing,PIN,Reissue Controls,POS Controls,Stored Value,Details");
		isDisplayed(optionalForCard, "Optional Cards");
		common.clickOkButton();
		sleep(5);
	}

//To verify CardBalance and Account balance alert sequences number
	public void verifyCardRankTable(String cell1, String cell2, String cell3) {
		try {
			HashSet<String> tableHeader = SeleniumWrappers
					.getAllTableHeaders(driver.findElements(By.xpath("//div[@class='HeaderRenderer']")));
			logInfo("TableHeaders are" + tableHeader);
			List<WebElement> list = driver
					.findElements(By.xpath("//div[@class='FALTableCellEditor_StrikeThruField JTextComponent']"));
			int size=SeleniumWrappers.getTotalNumberOfCells(list);
			//int rowSize = SeleniumWrappers.getTotalNumberOfRows(list, driver);
			System.out.println("rowSize of Card Rank "+size);
			int col = 0;
			for (int row = 0; row < size; row++) {
				if (SeleniumWrappers.getTableDataWithRowAndColumnNumber(col, row, driver).equals(cell1)) {
					if (SeleniumWrappers.getTableDataWithRowAndColumnNumber(col + 1, row, driver).equals(cell2)
							&& SeleniumWrappers.getTableDataWithRowAndColumnNumber(col + 2, row, driver).equals(cell3)) {
						
                       logPass(cell2 + " Sequence Number is " + cell3);
					} 
                    break;
				}
			}
		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
	}
	public void verfyingThePresenceOfReport() {
		Common common = new Common(driver, test);
		// TODO Auto-generated method stub
		chooseSubMenuFromLeftPanel("Client Config","Report Assignments");
		common.verifyValueInTables("Report Type", "Duty Summary", true);
		common.verifyValueInTables("Report Type", "EI80 Duty Exemption Report", true);
	}
	
	public void goToClientCalenderMenu() {
		chooseSubMenuFromLeftPanel("Client Config","Calendar");
		
		
	}
	
	public void goToStoredReportsAndFilterCurrentDate() {
		chooseSubMenuFromLeftPanel("Client Config","Stored Reports");
		clickDetailSearchIfFilterFieldsNotPresent();
		String currentDate = getCurrentIFCSDateFromDB(PropUtils.getPropValue(configProp, "clientName"));
		SimpleDateFormat currentFormat = new SimpleDateFormat("yyyy-mm-dd");
		SimpleDateFormat expectedFormat = new SimpleDateFormat("dd/mm/yyyy");
		String newDate="";
		Date dateParsed;
		try {
			dateParsed = currentFormat.parse(currentDate);
			newDate = expectedFormat.format(dateParsed);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Current Date Formatted:"+newDate);
		enterValueInTextBox("Filter By", "Created From", newDate);
		enterValueInTextBox("Filter By", "Created To", newDate);
		searchListTorch();
		verifyValidationResult("Record Read OK - Page Size");
	}
	
	public void validateReportsInStoredReports(List<String> assignedReports){
		CommonInterfacePage common = new CommonInterfacePage(driver, test);
		String client_mid=	common.funcFetchLoadCardTransClientMidFromIFCSDB(configProp); 
		String reportFormation="", ifcsDate;
		ifcsDate = getCurrentIFCSDateFromDB(PropUtils.getPropValue(configProp, "clientName"));
		SimpleDateFormat currentFormat = new SimpleDateFormat("yyyy-mm-dd");
		SimpleDateFormat expectedFormat = new SimpleDateFormat("dd.mm.yyyy");
		String newDate="";
		Date dateParsed;
		try {
			dateParsed = currentFormat.parse(ifcsDate);
			newDate = expectedFormat.format(dateParsed);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		List<WebElement> reportTableHeaders = driver.findElements(
				By.xpath("//div[@class='JViewport']/div[@class='JTableHeader']//div[@class='HeaderRenderer']"));
		List<WebElement> list = driver
				.findElements(By.xpath("//div[@class='FALTableCellEditor_StrikeThruField JTextComponent']"));
		int columnNoReportType = SeleniumWrappers.getColumnNoForColumnHeader("Report Type", reportTableHeaders);
		//int columnNoFileName = SeleniumWrappers.getColumnNoForColumnHeader("File Name", reportTableHeaders);
		List<String> reportsGot = SeleniumWrappers.getTableDataWithColumnNumber(columnNoReportType, list, driver);
		//List<String> reportFileNamesGot = SeleniumWrappers.getTableDataWithColumnNumber(columnNoReportType, list, driver);
		for(String reportName: assignedReports) {
			
			if(reportsGot.contains(reportName)) {
				logPass("Expected Report Present"+reportName);
			}else {
				logInfo("Expected Report Not Present"+reportName);
			}
		
		}
		for(String reportName: assignedReports) {
			reportFormation = client_mid+"-"+reportName +" "+newDate;
			System.out.println("Report Name Formation:"+reportFormation);
		}
	}

	public String goToOLSMandatoryPage() {
		switchTabDetails("OLS Mandatory Page");
		String initialMandatoryValue = getValueFromProtectedTextBox("Details", "Initial Mandatory Page display frequency");
		sleep(5);
		return initialMandatoryValue;
	}
	
	public void changeProcessingDateFromInstitutePage(String processdate) {
		chooseSubMenuFromLeftPanel("Client Config", "");
		switchTabDetails("Institute");
		enterValueInTextBox("Details","Processing Date",processdate);
		sleep(5);
		clickSaveIcon();
		verifyValidationResult("Record saved OK");
	}

	// Prakalpha-->11/05/2019
	public String createANewCardFeeProfile(String clientCountry, String clientName, String cardProgram,
			String cardIssueFee, String cardFee1value) {
		chooseSubMenuFromLeftPanel("Fee Config", "Card Fee Profiles");
		sleep(5);
		validateHeaderLabel("Card Fee Profiles");
		waitForElementTobeClickable(cardFeesTable, 10);
		rightClick(cardFeesTable);
		addIteminPopup();
		String processingDate = getCurrentIFCSDateFromDB(clientName + clientCountry);
		String effDate = enterADateValueInStatusBeginDateField("Past", processingDate);
		String expiryDate = enterADateValueInStatusBeginDateField("WayFuture", processingDate);
		String description = enterDetailsInCardFeesProfilesPopUp(effDate, expiryDate, cardProgram, cardIssueFee,
				cardFee1value);
		sleep(5);
		clickSaveIcon();
		verifyValidationResult("Record saved OK");
		sleep(5);
		validateNewItemAddedInTheTableList("Card Fee Profiles", "Description", description);
		return description;
	}

	public String enterDetailsInCardFeesProfilesPopUp(String effDate, String expiryDate, String cardProgram,
			String cardIssueFee, String cardFee1value) {
		validatePopupHeaderText("Card Fee Profiles");
		String text = fakerAPI().name().fullName();
		enterValueInTextBox("Details", "Description", text);

		enterValueInTextBox("Details", "Effective On", effDate);
		sleep(2);
		enterValueInTextBox("Details", "Expires On", expiryDate);
		chooseOptionFromDropdown("Card Program", cardProgram);

		chooseOptionFromDropdown("Card Issue Fee", cardIssueFee);
		chooseOptionFromDropdown("Card Fee 1", cardFee1value);
		clickOkButton();
		return text;
	}

	public void editCardFeeProfilesAndValidate(String description,String clientCountry, String clientName, String cardProgram,
			String cardIssueFee, String cardFee1value) {
	validateExpectedRowValueAndDoubleClick("Card Fee Profiles", "Description", description);
    String processingDate = getCurrentIFCSDateFromDB(clientName + clientCountry);
	String effDate = enterADateValueInStatusBeginDateField("Current", processingDate);
	String expiryDate = enterADateValueInStatusBeginDateField("NextYear", processingDate);
    String editDescription= enterDetailsInCardFeesProfilesPopUp(effDate, expiryDate, cardProgram, cardIssueFee,
				cardFee1value);
    sleep(5);
	clickSaveIcon();
	verifyValidationResult("Record saved OK");
	sleep(5);
	validateNewItemAddedInTheTableList("Card Fee Profiles", "Description", editDescription);
	}
public void navigateAwayAndValidateCreatedCardFeeProfiles(String createdDescription) {
	chooseSubMenuFromLeftPanel("Fee Config", "Transaction Fees");
	sleep(5);
	validateHeaderLabel("Transaction Fees");
	chooseSubMenuFromLeftPanel("Fee Config", "Card Fee Profiles");
	sleep(5);
	validateHeaderLabel("Card Fee Profiles");
	sleep(5);
	validateNewItemAddedInTheTableList("Card Fee Profiles", "Description", createdDescription);
}

/*
	 * Updated by raxsana 29/06/2020
	 * 
	 */
	public void validateOldCardFeeProfiles(String expectedCardProgram, String createdDescription) {
		try {
			clickDetailSearchIfFilterFieldsNotPresent();
			sleep(5);
			chooseOptionFromDropdown("Card Program", expectedCardProgram);
			searchListTorch();
			sleep(2);
			// common.selectFirstRowNumberInSearchList();
			WebElement row = driver.findElement(By.xpath(
					"//div[@class='FALTableCellEditor_StrikeThruField JTextComponent'][contains(@id,'_0_0')]//div[@class='htmlString'][1]"));
			doubleClick(row);
			validatePopupHeaderText("Card Fee Profiles");
			verifyValueInTextBox("Details", "Description", createdDescription);
			clickCancelButton();
			sleep(5);
			chooseBlankOptionFromDropdown("Card Program");
			detailSearch();
			sleep(2);
			searchListTorch();
		} catch (Exception e) {
			e.getMessage();
		}
	}

public void deleteCardFeeProfile(String description) {
	sleep(5);
	rightClickAndDeleteExpectedRow("Card Fee Profiles","Description",description);
    clickSaveIcon();
	verifyValidationResult("Record saved OK");
}
//Nithya-->11/05/2019
			/**
			 * Method for validating the presence/values of fields 
			 * Parameter - verify presence or update value
			 * Client Name and Client Country 
			 * */
			public void verifyOrCreateFeeConfigProfileFields(String verifyOrUpdate,String clientName, String clientCountry) {
					chooseSubMenuFromLeftPanel("Fee Config", "Fees");
					validateHeaderLabel("Fees");
					verifyFeeConfigProfileFields(verifyOrUpdate);
					verifyFeeAgreementFields(verifyOrUpdate,clientName,clientCountry);
					verifyFeeValueFields(verifyOrUpdate);
				}
				
				/**
				 * Method for validating the presence/values of fields in Fee Config Popup 
				 * Parameter - verify presence or update value
				 * 
				 * */
				public void verifyFeeConfigProfileFields(String verifyOrUpdate) {
					if(verifyOrUpdate.equalsIgnoreCase("Verify")) {
					isDisplayedThenDoubleClick(feeConfigTableData,"Fee Config Row");
					sleep(2);
					validatePopupHeaderText("Fees");
					textFieldisPresentForLabel("Details", "Description");
					dropdownFieldisPresentForLabel("Details", "Fee Type");
					dropdownFieldisPresentForLabel("Details", "Frequency");
					dropdownFieldisPresentForLabel("Details", "Fee Posting Method");
					dropdownFieldisPresentForLabel("Details", "Transaction Type");
					dropdownFieldisPresentForLabel("Details", "Product");
					clickCancelButton();
					}else {
						rightClick(feeConfigTableData);
						addIteminPopup();
						enterValueInTextBox("Details", "Description", fakerAPI().company().name());
						chooseARandomDropdownOption("Fee Type");
						chooseARandomDropdownOption("Frequency");
						chooseARandomDropdownOption("Fee Posting Method");
						chooseARandomDropdownOption("Transaction Type");
						chooseARandomDropdownOption("Product");
						clickOkButton();
					}
					
					sleep(2);
				}
				
				/**
				 * Method for validating the presence/values of fields in Fee Agreement Popup 
				 * Parameter - verify presence or update value
				 * 
				 * */
				public void verifyFeeAgreementFields(String verifyOrUpdate,String clientName, String clientCountry) {
					
					if(verifyOrUpdate.equalsIgnoreCase("Verify")) {
					isDisplayedThenDoubleClick(feeAgreementTableData.findElement(By.xpath(".//input[contains(@id,'0_0')]")),"Fee Agreement Row");
					sleep(2);
					textFieldisPresentForLabel("Details", "Description");
					textFieldisPresentForLabel("Details", "Effective On");
					textFieldisPresentForLabel("Details", "Expires On");
					textFieldisPresentForLabel("Details", "Minimum Charge");
					textFieldisPresentForLabel("Details", "Maximum Charge");
					clickCancelButton();
					}else {
						rightClick(feeAgreementTableData);
						addIteminPopup();
						enterValueInTextBox("Details", "Description", fakerAPI().company().name());
						String processingDate =getCurrentIFCSDateFromDB(clientName + clientCountry);
						String effDate = enterADateValueInStatusBeginDateField("Past", processingDate);
						String expiryDate =enterADateValueInStatusBeginDateField("WayFuture", processingDate);
						enterDateInDropdown("Effective On", effDate);
						sleep(1);
						enterDateInDropdown("Expires On", expiryDate);
						enterValueInTextBox("Details", "Minimum Charge","100");
						enterValueInTextBox("Details", "Maximum Charge","150");
						clickOkButton();
					}
					sleep(2);
				}
				
				/**
				 * Method for validating the presence/values of fields in Fee Values
				 * Parameter - verify presence or update value
				 * 
				 * */
				public void verifyFeeValueFields(String verifyOrUpdate) {
					if(verifyOrUpdate.equalsIgnoreCase("Verify")) {
					isDisplayedThenDoubleClick(feeValuesTableData.findElement(By.xpath(".//input[contains(@id,'0_0')]")),"Fee Value Row");
					sleep(2);
					textFieldisPresentForLabel("Details", "Description");
					dropdownFieldisPresentForLabel("Details", "Country");
					dropdownFieldisPresentForLabel("Details", "State");
					textFieldisPresentForLabel("Details", "Range Value From");
					textFieldisPresentForLabel("Details", "Range Value To");
					textFieldisPresentForLabel("Details", "Rate");
					clickCancelButton();
					}
					else {
						rightClick(feeValuesTableData);
						addIteminPopup();
						enterValueInTextBox("Details", "Description", fakerAPI().company().name());
						chooseARandomDropdownOption("Country");
						chooseARandomDropdownOption("State");
						enterValueInTextBox("Details", "Range Value From", "10");
						enterValueInTextBox("Details", "Range Value To", "15");
						enterValueInTextBox("Details", "Rate", "4");
						clickOkButton();
						}
					
					sleep(2);
				}
				
				
				public void creatingCalendar(String label,String option) {
					
					
					boolean elementDisplayed = waitToCheckElementIsDisplayed(By.xpath("//input[@value='"+option+"']"),10);
					System.out.println("elementDisplayed : "+elementDisplayed);
					
					if(elementDisplayed) {
						logInfo(option+" report already assigned to this client country");
					}else{
						rightClick(calendarFrequencies);
						addIteminPopup();
						chooseOptionFromDropdownChe(label,option);
						isDisplayedThenActionClick(okButtonShortPopup, "popup ok button");
					}
					/*try {
						driver.findElement(By.xpath("//input[@value='"+option+"']"));
					} catch(NoSuchElementException e) {
					rightClick(calendarFrequencies);
					addIteminPopup();
					chooseOptionFromDropdownChe(label,option);
					}*/
				}

public void chooseFeesFromFeeConfig() {
	chooseSubMenuFromLeftPanel("Fee Config", "Fees");
	validateHeaderLabel("Fees");
}


}
