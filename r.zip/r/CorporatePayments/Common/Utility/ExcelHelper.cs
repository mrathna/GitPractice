﻿//using OfficeOpenXml;
using System;
using System.IO;
using Microsoft.Office.Interop.Excel;

namespace Common.Utility
{
	public class ExcelHelper
	{
		//public ExcelWorkbook oWorkbook;
		//public ExcelWorksheet oWorksheet;
		//ExcelPackage package;

		Application xlApp;
		Workbook oWorkbook;
		public Worksheet oWorksheet;

		public ExcelHelper(string absPath, string sheetName)
		{
			//package = new ExcelPackage(new FileInfo(absPath));
			//try
			//{
			//	oWorkbook = package.Workbook;
			//	oWorksheet = oWorkbook.Worksheets[sheetName];
			//}
			//catch (Exception) { package.Dispose(); }
			xlApp = new Application();
			oWorkbook = xlApp.Workbooks.Open(absPath);
			oWorksheet = oWorkbook.Worksheets[sheetName];
		}					

		public void SaveAndCloseExcel()
		{
			//package.Save();
			//package.Dispose();
			oWorkbook.Save();
			oWorkbook.Close(true);
			xlApp.Quit();
		}		
	}
}
