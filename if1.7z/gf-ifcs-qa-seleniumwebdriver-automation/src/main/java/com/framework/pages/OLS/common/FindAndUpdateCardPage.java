package com.framework.pages.OLS.common;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Row;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.aventstack.extentreports.ExtentTest;
import com.framework.basepage.BasePage;
import com.framework.pages.AJS.common.IFCSCommonPage;
import com.framework.pages.AJS.common.InterfacePage;
import com.framework.pages.BP.BPOrderCard;
import com.framework.repo.Locator;
import com.framework.util.PropUtils;


public class FindAndUpdateCardPage extends BasePage {

	public FindAndUpdateCardPage(WebDriver driver, ExtentTest test) {
		super(driver, test);
		PageFactory.initElements(driver, this);
	}

	BPOrderCard bpOrderCard = new BPOrderCard(driver, test);
	private String cardNumberChoosen = "";
	private String pinOffSet, pinOffsetCID, isGenerated, encryptedPIN, cardOID;
	private String getDBDetailsFromProperties = "";

	@FindBy(how = How.ID, using = Locator.SEARCH_CARDS)
	public WebElement searchCards;

	@FindBy(how = How.XPATH, using = Locator.ACTIVECARDS_WITHPIN)
	public List<WebElement> activeCardsWithPin;

	@FindBy(how = How.XPATH, using = Locator.ACTIVECARDS_WITHCHANGEPIN)
	public List<WebElement> activeCardsWithChangePin;

	@FindBy(how = How.XPATH, using = Locator.RESEND_PIN)
	public WebElement resendPIN;

	@FindBy(how = How.ID, using = Locator.PINREQUESTSENTMESSAGE)
	public WebElement pinRequestSentMsg;

	@FindBy(how = How.ID, using = Locator.RESENDPINPOPUPOK)
	public WebElement resendPINOK;

	@FindBy(how = How.ID, using = Locator.REQUESTSENTPOPUPOK)
	public WebElement requestSentOK;

	@FindBy(how = How.XPATH, using = Locator.CHANGE_PIN)
	public WebElement changePIN;

	@FindBy(how = How.XPATH, using = Locator.FIRSTCARD_FROM_CARDSLIST)
	public WebElement firstCardsNumberFromCardsList;

	// Added By Nithya - 03-05-2018
	@FindBy(how = How.XPATH, using = Locator.ALL_LISTED_CARDS)
	public List<WebElement> allListedCards;

	@FindBy(how = How.XPATH, using = Locator.VIEW_CARD_TRANSACTION)
	public WebElement viewCardTransaction;

	@FindBy(how = How.XPATH, using = Locator.VIEW_CARD)
	public WebElement goToCard;

	@FindBy(how = How.ID, using = Locator.CARD_STATUS)
	public WebElement cardStatus;

	@FindBy(how = How.XPATH, using = Locator.PAGE_TITLE_DP)
	public WebElement pageTitle;

	@FindBy(how = How.ID, using = Locator.VIEW_CARD_OPTIONS_DROPDOWN)
	public WebElement viewCardOptionsDropDown;

	@FindBy(how = How.ID, using = Locator.GO_IN_VIEW_CARD)
	public WebElement goInViewCardPage;

	@FindBy(how = How.ID, using = Locator.CARDNO_TRANSACTION)
	public WebElement cardNoInTransactionsPage;

	@FindBy(how = How.XPATH, using = Locator.CARDNO_VIEW_CARD)
	public WebElement cardNoInViewCardPage;

	@FindBy(how = How.XPATH, using = Locator.CARDNO_IN_VIEW_CARD)
	public WebElement cardNoInViewCard;

	@FindBy(how = How.ID, using = Locator.CARDNO_CHANGE_STATUS)
	public WebElement cardNoInChangeStatusPage;

	@FindBy(how = How.XPATH, using = Locator.CARDNO_CHANGE_PIN)
	public WebElement cardNoInChangePIN;

	@FindBy(how = How.XPATH, using = Locator.CARDNO_EDIT_CARD)
	public WebElement cardNoInEditCard;

	@FindBy(how = How.ID, using = Locator.RESENDPOPUPMSG)
	public WebElement cardViewResendPopupMsg;

	@FindBy(how = How.ID, using = Locator.CANCEL_RESEND_REQUEST)
	public WebElement cardViewCancelResendRequest;

	// Added by Nithya - 04-05-2018
	@FindBy(how = How.XPATH, using = Locator.PAGE_TITLE_REISSUECARD)
	public WebElement pageTitleInReissueCard;

	@FindBy(how = How.XPATH, using = Locator.REISSUE_CARD)
	public WebElement reissueCard;

	@FindBy(how = How.XPATH, using = Locator.CHANGESTATUS)
	public WebElement changeCardStatus;

	@FindBy(how = How.ID, using = Locator.AN_EXISTING_MULTICARD_SEARCH)
	public WebElement multiCardSearch;

	@FindBy(how = How.ID, using = Locator.AN_EXISTING_ACCOUNT_LIST)
	public WebElement accountListDropdown;

	@FindBy(how = How.ID, using = Locator.AN_EXISTING_CARD_STATUS)
	public WebElement accountCardStatus;

	@FindBy(how = How.ID, using = Locator.ACCOUNT_LIST)
	public WebElement findAndUpdateAccountField;
	
	@FindBy(how = How.XPATH, using = Locator.ACCOUNT_LIST_BOX)
	public WebElement findAndUpdateAccountList;

	@FindBy(how = How.XPATH, using = Locator.CARD_FOUND_HEADER)
	public WebElement cardFoundHeader;

	@FindBy(how = How.ID, using = Locator.NEXT_PAGE)
	public WebElement nextButton;

	@FindBy(how = How.ID, using = Locator.EXPORT_CARD_TOEXCEL)
	public WebElement exportCardToExcel;

	@FindBy(how = How.XPATH, using = Locator.EDIT_CARD)
	public WebElement editCard;

	@FindBy(how = How.ID, using = Locator.POS_PROMPT)
	public WebElement posPromptCheckbox;

	@FindBy(how = How.ID, using = Locator.VOLUME_LIMIT)
	public WebElement volumeLimit;

	@FindBy(how = How.ID, using = Locator.COST_LIMIT)
	public WebElement costLimit;

	// 30-5-2018 Addedd by Ayub
	@FindBy(how = How.ID, using = Locator.RETURNTOCARD_FOUNDLIST_BUTTON)
	public WebElement returnToCardFoundList;

	@FindBy(how = How.ID, using = Locator.RETURN_TO_CARDS)
	public WebElement returnToCardList;

	@FindBy(how = How.LINK_TEXT, using = Locator.PRINT_THIS_PAGE)
	public WebElement printThisPage;

	@FindBy(how = How.ID, using = Locator.ACCOUNT_SEL)
	public WebElement accountSelect;

	@FindBy(how = How.ID, using = Locator.FROM_DATE)
	public WebElement fromDate;

	@FindBy(how = How.ID, using = Locator.TO_DATE)
	public WebElement toDate;

	@FindBy(how = How.ID, using = Locator.DATE_RANGE)
	public WebElement dateRange;

	@FindBy(how = How.ID, using = Locator.ADV_SEARCH_LINK)
	public WebElement advancedSearchLink;

	@FindBy(how = How.ID, using = Locator.RECEIPT_NUM)
	public WebElement receiptNumber;

	@FindBy(how = How.ID, using = Locator.COST_CENTRE_TB)
	public WebElement costCentre;

	@FindBy(how = How.ID, using = Locator.PRD_SEL)
	public WebElement product;

	@FindBy(how = How.ID, using = Locator.SEARCH_BTN)
	public WebElement searchbutton;

	@FindBy(how = How.XPATH, using = Locator.SAVE_CHANGES)
	public WebElement saveChanges;

	@FindBy(how = How.XPATH, using = Locator.STATUS_EFFECTIVE)
	public WebElement statusEffectiveDate;

	@FindBy(how = How.XPATH, using = Locator.CHANGE_STATUS_TO)
	public List<WebElement> changeStatusTo;

	@FindBy(how = How.ID, using = Locator.CARDSTATUSCHANGE_POPUP_YESBUTTON)
	public WebElement changePopupYes;

	@FindBy(how = How.ID, using = Locator.CARDSTATUSCHANGE_POPUP_NOBUTTON)
	public WebElement changePopupNo;

	@FindBy(how = How.XPATH, using = Locator.VIEW_CARD_DETAILS)
	public WebElement viewCardDetails;

	@FindBy(how = How.XPATH, using = Locator.ADVANCED_SEARCH)
	public WebElement advancedSearch;

	@FindBy(how = How.XPATH, using = Locator.ADV_CARD_TYPE)
	public List<WebElement> advCardType;

	@FindBy(how = How.ID, using = Locator.DELIVER_CONFIRM_AND_REISSUE)
	public WebElement confirmReissue;

	@FindBy(how = How.XPATH, using = Locator.ENTER_ANOTHER_ADDRESS)
	public WebElement enterAnotherAddress;

	@FindBy(how = How.XPATH, using = Locator.DELIVER_CARD_TO_THIS_ADDRESS)
	public WebElement deliverCardToAddress;

	@FindBy(how = How.ID, using = Locator.DELIVER_TITLE)
	public WebElement title;

	@FindBy(how = How.ID, using = Locator.DELIVER_CONTACT_NAME)
	public WebElement cname;

	@FindBy(how = How.ID, using = Locator.DELIVER_ADDRESS)
	public WebElement address;

	@FindBy(how = How.ID, using = Locator.DELIVER_SUBURB)
	public WebElement suburb;

	@FindBy(how = How.ID, using = Locator.DELIVER_POSTCODE)
	public WebElement postCode;

	@FindBy(how = How.ID, using = Locator.DELIVER_STATE)
	public WebElement state;
	
	@FindBy(how = How.CSS, using = Locator.DRIVER_NAME_OF_A_CARD)
    public WebElement driverNameOfACard;
	
	@FindBy(css = Locator.CARD_SEARCH)
	public WebElement cardSearchTextBox;

	@FindBy(how = How.ID, using = Locator.REPORT_SEARCH)
	public WebElement customerSearch;

	@FindBy(id = Locator.ACCOUNT_DROP_DOWN)
	public WebElement accountDropDown;

	InterfacePage interfacePage = new InterfacePage(driver, test);

	/**
	 * Select Search Card Button - Added by Nithya
	 * 
	 * @throws Exception
	 */

	public void clickSearchCard() {
		isDisplayedThenActionClick(searchCards, "Search Cards");
		sleep(5);
		scrollDownPage();
	}

	/*
	 * Verify Fields in Find and Update Card Page 03-05-18 Meenakshi
	 */
	public void verifyFindAndUpdateCardPageFields() {
		if (searchCards.isDisplayed()) {
			logPass("Search Cards Button is displayed");
		} else {
			logFail("Search Cards Button is not displayed");
		}
		if (multiCardSearch.isDisplayed()) {
			logPass("Multiple Card search field is displayed");
		} else {
			logFail("Multiple Card search field is not displayed");
		}
		if (accountListDropdown.isDisplayed()) {
			logPass("Account List dropdown is displayed");
		} else {
			logFail("Account List dropdown is not displayed");
		}
		if (accountCardStatus.isDisplayed()) {
			logPass("Account Card Status dropdown is displayed");
		} else {
			logFail("Account card Status dropdown is not displayed");
		}
	}

	/**
	 * Select a Active Card Number- Added by Nithya
	 */
	public void pickActiveCardNumber(String resendOrChange) {
		if (resendOrChange.equalsIgnoreCase("Resend PIN") || resendOrChange.equalsIgnoreCase("Reissue")) {
			if (activeCardsWithPin.size() > 0) {
				cardNumberChoosen = getText(activeCardsWithPin.get(0));
				logPass("Active Card with PIN Required is choosen :: Card Number - >" + cardNumberChoosen);
			} else {
				logFail("No Active Cards with PIN Required Field");
				// ** Need to handle pagination
			}
		} else if (resendOrChange.equalsIgnoreCase("Change PIN")) {
			if (activeCardsWithChangePin.size() > 0) {
				cardNumberChoosen = getText(activeCardsWithChangePin.get(0));
				logPass("Active Card with Change PIN is choosen :: Card Number - >" + cardNumberChoosen);
			} else {
				logFail("No Active Cards with Change PIN Field");
				// ** Need to handle pagination
			}
		}
	}

	/**
	 * Selects a Active Card which is having the PIN Resend enabled Click Resent PIN
	 * for that card and handles the confirmation Popup - Added by Nithya
	 */
	public void pickActiveCardAndResendPIN() {
		isDisplayedThenClick(activeCardsWithPin.get(0), "Active Cards With Pin");
		actionClick(resendPIN);
		// **Analyzing on adding a common purposeful wait for Popups
		sleep(5);
		actionClick(resendPINOK);
		if (getText(pinRequestSentMsg).contains(cardNumberChoosen)) {
			actionClick(requestSentOK);
			logPass("Resent PIN request send for the Card " + cardNumberChoosen);
		} else {
			logFail("Resend PIN request not sent for the card");
		}
	}

	/*
	 * Ayub Khan 02-5-2018
	 */
	public void pickActiveCardAndChangePIN() {
		isDisplayedThenClick(activeCardsWithPin.get(0), "Pick Active Card");
		actionClick(changePIN);
		// **Analyzing on adding a common purposeful wait for Popups
		sleep(5);
	}

	/*
	 * Ayub Khan 02-05-2018
	 */
	public void pickActiveCardAndReissueCard() {
		isDisplayedThenClick(activeCardsWithPin.get(0), "Pick Active Card");
		isDisplayedThenActionClick(reissueCard, "Reissue Card");
		sleep(5);
	}

	/*
	 * Ayub Khan 24-05-2018
	 */
	public void pickActiveCardAndEditCard() {
		isDisplayedThenClick(activeCardsWithPin.get(0), "Pick Active Card");
		isDisplayedThenActionClick(editCard, "Edit Card");
		sleep(5);
	}

	/*
	 * Click First Card Number in Cards Table 03-05-18 Meenakshi
	 */
	public void clickFirstCardNumberFromCardsList() {
		sleep(3);
		if (firstCardsNumberFromCardsList.isDisplayed()) {
			actionClick(firstCardsNumberFromCardsList);
			logPass("Select first cards from Cards List");
		} else {
			logFail("Can't able to select the first cards from cards list");
		}
	}

	/*
	 * Click Change Status Option 03-05-18 Meenakshi
	 */
	public void pickChangeStatusOption() {
		sleep(2);
		mouseHover(changeCardStatus);
		if (changeCardStatus.isDisplayed()) {
			actionClick(changeCardStatus);
			logPass("Select Change status options successfully");
		} else {
			logFail("Can't able to select the change status options");
		}
	}

	/**
	 * Connect DB and get PIN Offset, PIN Offset CID, IS Generated, Card OID,
	 * Encrypted PIN values
	 * 
	 * @throws InterruptedException
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 *             - Added by Nithya
	 */

	public String getPINValuesFromDB(String... cardNumber) {

		getDBDetailsFromProperties = PropUtils.getPropValue(configProp, "sqlODSServerName");

		if (cardNumber.length > 0) {
			cardNumberChoosen = cardNumber[0];
		}

		String queryToGetPinOffset = "Select pin_offset from cards where card_no='" + cardNumberChoosen + "'";
		String queryToGetPinOffsetCID = "Select pin_option_cid from cards where card_no='" + cardNumberChoosen + "'";
		String queryToGetIsGenerated = "Select is_generated_pin from cards where card_no='" + cardNumberChoosen + "'";
		String queryToGetCardOID = "select card_oid from cards where card_no='" + cardNumberChoosen + "'";

		pinOffSet = connectDBAndGetValue(queryToGetPinOffset, getDBDetailsFromProperties);

		pinOffsetCID = connectDBAndGetValue(queryToGetPinOffsetCID, getDBDetailsFromProperties);

		isGenerated = connectDBAndGetValue(queryToGetIsGenerated, getDBDetailsFromProperties);

		cardOID = connectDBAndGetValue(queryToGetCardOID, getDBDetailsFromProperties);

		String queryToGetEncryptedPIN = "select encrypted_pin from encrypted_pins where card_oid='" + cardOID + "'";

		encryptedPIN = connectDBAndGetValue(queryToGetEncryptedPIN, getDBDetailsFromProperties);
		
		return encryptedPIN;

	}

	/**
	 * Compare the PIN Values before resend and after resend
	 * 
	 * @throws InterruptedException
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 *             - Added by Nithya
	 */

	public void comparePINValues(String changeOrResendPIN, String... cardNumber) {
		String pinoffsetBefore = pinOffSet;
		String pinOffsetCIDBefore = pinOffsetCID;
		String isGeneratedBefore = isGenerated;
		String encryptedPINBefore = encryptedPIN;
		String cardOIDBefore = cardOID;

		if (cardNumber.length > 0) {
			getPINValuesFromDB(cardNumber[0]);
		} else {
			getPINValuesFromDB();
		}

		if (changeOrResendPIN.contains("Resend")) {
			if (!(pinoffsetBefore.equals(pinOffSet))) {
				logFail("PIN Offset value changed after " + changeOrResendPIN + " PIN action");
			}
		} else {
			if (pinOffSet != null) {
				if (!(pinoffsetBefore.equals(pinOffSet))) {
					logFail("PIN Offset value changed after " + changeOrResendPIN + " PIN action");
				}
			} else {
				logInfo("PIN Offset not set");
			}
		}
		if (!(pinOffsetCIDBefore.equals(pinOffsetCID))) {
			logFail("PIN Offset CID value changed after " + changeOrResendPIN + " PIN action");
		}

		if (!(isGeneratedBefore.equals(isGenerated))) {
			logFail("Is generated value changed after " + changeOrResendPIN + " PIN action");
		}

		if (!(cardOIDBefore.equals(cardOID))) {
			logFail("Card OID value changed after " + changeOrResendPIN + " PIN action");
		}
		if (changeOrResendPIN.contains("Resend")) {
			if (!(encryptedPINBefore.equals(encryptedPIN))) {
				logFail("Encrypted PIN changed after " + changeOrResendPIN + " PIN action");
			}
		} else {
			if (!encryptedPIN.contains("")) {
				if ((encryptedPINBefore.equals(encryptedPIN))) {
					logFail("Encrypted PIN changed after " + changeOrResendPIN + " PIN action");
				}
			} else {
				logInfo("Encrypted PIN value not present for the card");
			}
		}

	}

	String cardNumber;

	/**
	 * Select a Card and View Transactions - Added by Nithya 03-05-2018
	 */
	public void clickGoToCardAndVerifyHeaderTitle() {
		int randomNo = 0;
		int i=0;
		if (allListedCards.size() > 1) {
			int size=driver.findElements(By.xpath("//tbody[@id='lform:tableCardList:tb']/tr")).size();
			while(i<size) {
			randomNo = getRandomNumber(0, allListedCards.size() - 1);
			cardNumber = getText(allListedCards.get(randomNo));
			String methodName = Thread.currentThread().getStackTrace()[2].getMethodName();
			System.out.println("method name::"+methodName);
			
			if(methodName.equals("changeCardStatus")) {
				String cardStatus="select description from card_status where card_status_oid=(select card_status_oid from cards where card_no='"+cardNumber+"')";
				String getCardStatus=connectDBAndGetValue(cardStatus, PropUtils.getPropValue(configProp, "sqlODSServerName"));
				if(!(getCardStatus.equals("700 No Transactions"))) {
					logInfo("valid status");
					break;
				}
				else {
					i=i+1;
					continue;
				}
			}
			else {
				break;
			}
			}
			actionClick(allListedCards.get(randomNo));
		} else if(allListedCards.size() == 1){
			cardNumber = getText(allListedCards.get(0));
			actionClick(allListedCards.get(0));
		}
			else {
		
			logFail("No Cards Found");
		}
		clickCardTableMenuOption(goToCard, "View Card Details");
	}



	/**
	 * View Card Status 
	 * @param statusValue
	 */
	public void viewCardStatus(String statusValue) {
		List<WebElement> cardStatusOptions = selectDropdownOptionValues(cardStatus);
		WebElement cardValue;
		String cardStatus;
		boolean cardResult;
		if(cardStatusOptions.size()>0) {
			for(WebElement cardStatusOption:cardStatusOptions) {
				if(cardStatusOption.getText().equals(statusValue)) {
					cardStatusOption.click();
					clickSearchCard();
					cardResult = waitForTextToAppear("No cards found",60);
					if(!cardResult) {
						logInfo("Go To Card");
						clickGoToCardAndVerifyHeaderTitle();
						checkCardNumberInViewCardPage();
						cardValue = driver.findElement(By.xpath("//strong[contains(text(),'"+statusValue+"')]"));
						cardStatus = cardValue.getText();
						if(statusValue.equals(cardStatus)) {
							logInfo("Card Status shows - based on the search result "+cardStatus);
						} else {
							logInfo("Card Status not shows - based on the search result "+cardStatus);
						}
						isDisplayedThenActionClick(returnToCardFoundList,"Return To Bulk Card Search");
						//sleep(3);
					} else {
						logInfo("Shows No Cards Found");
					}
					break;
				} else {
					logInfo("Current Card Status " + cardStatusOption.getText() + " Skips");
				}
			} 
			logPass("View Card Status - Pass");
		}  else {
			logInfo("No Options in Card Status");
			logFail("No Options in Card Status");
		}
	}




	/**
	 * Change Card Status
	 * @param newStatusValue
	 */
	public void changeCardStatus(String newStatusValue) {
		selectAccountFromFindUpdateCardPage();
		selectDropDownByVisibleText(cardStatus,"Active");
		clickSearchCard();
		boolean cardSearchResult = waitForTextToAppear("No cards found",60);
		if(!cardSearchResult) {
			clickGoToCardAndVerifyHeaderTitle();
			checkCardNumberInViewCardPage();
			selectCardOptionInViewCardAndVerify("Change Status", "Change Card Status");
			checkCardNumberInChangeStatusPage();
			sleep(2);
			List<WebElement> changeStatusToOptions = changeStatusTo;
			int changeStatusToOptionsSize = changeStatusToOptions.size();
			boolean changeStatusPopupNo;
			WebElement cardChangeStatus;
			String cardNewStatus;
			String cardNo;
			WebElement cardSearchResultStatus;
			String cardChangedStatus;
			if(changeStatusToOptionsSize>0) {
				for(WebElement changeStatusToOption:changeStatusToOptions) {
					if(changeStatusToOption.getAttribute("data-summary-value").equals(newStatusValue)) {
						changeStatusToOption.click();
						sleep(1);
						statusEffectiveDate.click();
						saveChanges.click();
						changeStatusPopupNo = waitToCheckElementIsDisplayed(By.id("lform:saveCardStatusBtnFullAccess"),60);
						if(changeStatusPopupNo) {
							changePopupNo.click();
							sleep(1);
						}
						viewCardDetails.click();
						sleep(1);
						cardChangeStatus = driver.findElement(By.xpath("//strong[contains(text(),'"+newStatusValue+"')]"));
						 cardNewStatus = cardChangeStatus.getText();
						if(cardChangeStatus.getText().equals(newStatusValue)) {
							logInfo("Active Card changed to respective Status "+cardChangeStatus.getText());
						} else {
							logInfo("Active Card not changed");
						} 
						cardNo =cardNoInViewCard.getText();
						isDisplayedThenActionClick(returnToCardFoundList,"Return To Bulk Card Search");
						//sleep(5);	
						enterText(multiCardSearch,cardNo);
						selectDropDownByVisibleText(cardStatus,newStatusValue);
						clickSearchCard();
						//sleep(2);
						cardSearchResultStatus = driver.findElement(By.xpath("//span[@title='"+newStatusValue+"']"));
						cardChangedStatus = cardSearchResultStatus.getText();
						if(cardNewStatus.equals(cardChangedStatus)) {
							logInfo("Card New Status matches with Search Result Card ");
						} else {
							logInfo("Card New Status Not Matches");
						}
						multiCardSearch.clear();
						break;
					}  else {
						logInfo("Current Option"+changeStatusToOption.getAttribute("data-summary-value")+"Skips");
					}
				}
			} else {
				logInfo("Change Status Options are not listed");
			}
			logPass("Card Status Changed to "+newStatusValue);
		} else {
			logInfo("No Cards Found");	
		}
	}


	/**
	 * View - Advance Search - Reissue Card 
	 * @param cardValue
	 * @param cardType
	 */
	public void viewReissueCard(String cardValue,String cardType) {
		selectAccountFromFindUpdateCardPage();
		selectDropDownByVisibleText(cardStatus,cardValue);
		isDisplayedThenActionClick(advancedSearch,"Advanced Search Options");
		boolean cardResult;
		if(advCardType.size()>0){
			for(WebElement cardTypeOption:advCardType) {
				if(cardTypeOption.getAttribute("data-summary-value").equals(cardType)) {
					cardTypeOption.click();
					clickSearchCard();
					cardResult = waitForTextToAppear("No cards found",60);
					if(!cardResult) {
						clickGoToCardAndVerifyHeaderTitle();
						checkCardNumberInViewCardPage();
						selectCardOptionInViewCardAndVerify("Re-issue Card", "Re-issue Card - Card");
						logInfo("View Reissue Card Status done");
						isDisplayedThenActionClick(returnToCardList,"Return To Bulk Card Search");
					} else {
						logInfo("No Cards Found");						
					}
					break;
				} else {
					logInfo("Current Option "+cardTypeOption.getAttribute("data-summary-value")+" Skips");
				}
			}
		} else {
			logInfo("No Card Type");				
		}

	}


	/**
	 * Reissue Card
	 * @param cardStatusOption
	 */
	public void reissueCard(String cardStatusOption,String clientCountry) {
		CommonPage commonPage=new CommonPage(driver,test);
		selectAccountFromFindUpdateCardPage();
		selectDropDownByVisibleText(cardStatus,cardStatusOption);
		clickSearchCard();
		commonPage.changeSearchListIntoAscendingOrder();
		boolean cardSearch = waitForTextToAppear("No cards found",60);
		if(!cardSearch) {
			if(cardStatusOption.equals("Active")) {
			clickGoToCardAndVerifyHeaderTitle();
			checkCardNumberInViewCardPage();
			selectCardOptionInViewCardAndVerify("Re-issue Card", "Re-issue Card - Card");
			} else {
				clickReissueAndVerifyHeaderTitle("Re-issue Card - Card");
			}
			enterAnotherAddress.click();
			deliverCardToAddress.click();
			sleep(2);
			enterText(title,"Mr");
			enterText(cname,"Joseph");
			enterText(address,"23, North Australia");
			if(clientCountry.equals("AU")) {
			enterText(suburb,"34567");
			}
			enterText(postCode,"4566");
			selectDropDownOptionsRandomly(state,"state");
			sleep(2);
			isDisplayedThenActionClick(confirmReissue,"Confirm and Re-issue");
			boolean changeStatusPopupYes = waitToCheckElementIsDisplayed(By.id("lform:saveCardStatusAndReissueCardBtnFullAccess"),60);
			if(changeStatusPopupYes) {
				changePopupYes.click();
				sleep(2);
			}
			boolean invalidStatus = waitToCheckElementIsDisplayed(By.xpath("//h4[contains(text(),'Invalid card status for reissue')]"),60);
			boolean invalidLostStatus = waitToCheckElementIsDisplayed(By.xpath("//h4[contains(text(),'Invalid Entry')]"),60);
			if(invalidStatus) {
				logInfo("Card Reissue Shows- For Deleted Card - Invalid card status for reissue");
				isDisplayedThenActionClick(returnToCardList,"Return To Bulk Card Search");
				sleep(2);
			} else if(invalidLostStatus) {
				logInfo("Card Reissue Shows -For Lost Card - Invalid status for reissue");
				isDisplayedThenActionClick(returnToCardList,"Return To Bulk Card Search");
				sleep(2);
			} else {
				logInfo("Card Reissued Successfully");
				viewCardDetails.click();
				sleep(2);
				isDisplayedThenActionClick(returnToCardFoundList,"Return To Bulk Card Search");	
				sleep(5);
			}	
		logPass("Card Reissued Successfully");
		} else {
			logInfo("No Cards Found");
		}
	}


	/**
	 * Select a Card and View Transactions - Added by Nithya 03-05-2018
	 */
	public void clickChangeCardStatus() {
		int randomNo;
		if (allListedCards.size() > 0) {
			randomNo = getRandomNumber(0, allListedCards.size() - 1);
			cardNumber = getText(allListedCards.get(randomNo));
			actionClick(allListedCards.get(randomNo));
			sleep(2);
		} else {
			logFail("No Cards Found");
		}
		clickCardTableMenuOption(changeCardStatus, "Change Card Status");
	}

	/**
	 * Select a Card and View Transactions - Added by Nithya 03-05-2018
	 */
	public void clickViewTransactionsAndVerifyHeaderTitle() {
		int randomNo;
		if (allListedCards.size() > 1) {
			randomNo = getRandomNumber(0, allListedCards.size() - 1);
			cardNumber = getText(allListedCards.get(randomNo));
			actionClick(allListedCards.get(randomNo));
		} 
		else if(allListedCards.size() == 1){
			cardNumber = getText(allListedCards.get(0));
			actionClick(allListedCards.get(0));
		}
		else {
			logFail("No Cards Found");
		}
		clickCardTableMenuOption(viewCardTransaction, "Find and Export Transactions");
	}
	
	/**Select a Card and Reissue Card
	 * 
	 */
	public void clickReissueAndVerifyHeaderTitle(String title) {
		int randomNo;
		if (allListedCards.size() > 0) {
			if(allListedCards.size()==1) {
				randomNo = 0;
			}else {
			randomNo = getRandomNumber(0, allListedCards.size() - 1);
			}
			cardNumber = getText(allListedCards.get(randomNo));
			actionClick(allListedCards.get(randomNo));
		} else {
			logFail("No Cards Found");
		}
		title = title + " " + cardNumber;
		clickCardTableMenuOption(reissueCard, title);
	}

	/**
	 * Compare Actual and Expected Title - Added by Nithya 03-05-2018
	 */
	public void verifyHeaderTitle(String titleExpected) {
		if (titleExpected.contains("Re-issue Card") || titleExpected.contains("Change Card Status")) {
			if (getText(pageTitleInReissueCard).equals(titleExpected)) {
				logPass("Expected Title Present");
			} else {
				logFail("Expected Title Not Present");
			}
		} else {
			if (getText(pageTitle).equals(titleExpected)) {
				logPass("Expected Title Present");
			} else {
				logFail("Expected Title Not Present");
			}
		}
	}

	/**
	 * Select Any Menu Option - Added by Nithya 03-05-2018
	 */
	public void clickCardTableMenuOption(WebElement option, String titleTOCheck) {
		isDisplayedThenActionClick(option, "Card Table Menu");
		sleep(5);
		verifyHeaderTitle(titleTOCheck);
		// if (option.isDisplayed()) {
		// actionClick(option);
		// sleep(2);
		// verifyHeaderTitle(titleTOCheck);
		// } else {
		// logFail("Option Not Present");
		// }
	}

	/**
	 * Cancel Resend PIN - Added by Nithya 04-05-2018
	 */
	public void cancelResendPIN() {
		actionClick(cardViewCancelResendRequest);
		if (!(cardViewCancelResendRequest.isDisplayed())) {
			logPass("Resend PIN canceled");
		} else {
			logFail("Resend PIN not canceledDF");
		}
	}

	/**
	 * Select A Card Option In View Card And Verify the PageTitle - Added by Nithya
	 * 03-05-2018
	 */
	public void selectCardOptionInViewCardAndVerify(String optionName, String title) {
		if (!optionName.equals("")) {
			if (optionName.equals("Resend PIN")) {
				selectDropDownByVisibleText(viewCardOptionsDropDown, optionName);
				actionClick(goInViewCardPage);
				sleep(3);
				if (getText(cardViewResendPopupMsg).contains(cardNumber)) {
					cancelResendPIN();
					sleep(3);
					logPass("Expected Resend PIN popup present with card number");
				} else {
					logFail("Popup not present");
				}
			} else if (optionName.equals("Re-issue Card")) {
				selectDropDownByVisibleText(viewCardOptionsDropDown, optionName);
				actionClick(goInViewCardPage);
				sleep(3);
				title = title + " " + cardNumber;
				verifyHeaderTitle(title);
			} else {
				selectDropDownByVisibleText(viewCardOptionsDropDown, optionName);
				actionClick(goInViewCardPage);
				sleep(3);
				verifyHeaderTitle(title);
			}
		} else {
			logFail("Please give a option to choose from the dropdown");
		}
	}

	/**
	 * Check Presence of Expected Card Number in the Page - Added by Nithya
	 * 03-05-2018
	 */
	public void checkCardNumberInTransactionPage() {
		if (getAttribute(cardNoInTransactionsPage, "value").contains(cardNumber)) {
			logPass("Selected card number present in transactions page");
		} else {
			logFail("Selected card number not present in transactions page");
		}
	}

	/**
	 * Check Presence of Expected Card Number in the Page - Added by Nithya
	 * 03-05-2018
	 */
	public void checkCardNumberInViewCardPage() {
		if (getText(cardNoInViewCardPage).contains(cardNumber)) {
			logPass("Selected card number present in view card page");
		} else {
			logFail("Selected card number not present in view card page");
		}
	}

	/**
	 * Check Presence of Expected Card Number in the Page - Added by Nithya
	 * 03-05-2018
	 */
	public void checkCardNumberInEditCardPage() {
		if (getText(cardNoInEditCard).contains(cardNumber)) {
			logPass("Selected card number present in edit card page");
		} else {
			logFail("Selected card number not present in edit card page");
		}
	}

	/**
	 * Check Presence of Expected Card Number in the Page - Added by Nithya
	 * 03-05-2018
	 */
	public void checkCardNumberInChangePINPage() {
		if (getText(cardNoInChangePIN).contains(cardNumber)) {
			logPass("Selected card number present in change pin page");
		} else {
			logFail("Selected card number not present in change pin page");
		}
	}

	/**
	 * Check Presence of Expected Card Number in the Page - Added by Nithya
	 * 03-05-2018
	 */
	public void checkCardNumberInChangeStatusPage() {
		if (getText(cardNoInChangeStatusPage).contains(cardNumber)) {
			logPass("Selected card number present in change status page");
		} else {
			logFail("Selected card number not present in change status page");
		}
	}

	public void selectAccountFromFindUpdateCardPage() {
		selectDropDownByVisibleText(findAndUpdateAccountList, "All Accounts");
		sleep(3);
	}

	public void iterateAndCheckCardNumberIsPresent(String cardNumberFromList) {
		scrollDownPage();
		sleep(3);
		// for() {
		isDisplayed(cardFoundHeader, "Card Found");
		if (bpOrderCard.iterateAndSearch(cardNumberFromList) == true) {
			System.out.println("IF ßßiterateAndSearch" + cardNumberFromList);
			logPass("Search result is Displayed");
			// break;
		} else {
			isDisplayedThenActionClick(nextButton, "Next");
			bpOrderCard.iterateAndSearch(cardNumberFromList);
		}

	}

	public void clickSearchButtonInFindUpdateCardPage() {
		bpOrderCard.clickSearchButton();
	}

	/**
	 * Check Presence of ExportCard To Excel button and in the Page - Added by Ayub
	 * 21-05-2018
	 */

	public void exportCardToExcelInFindUpdateCardPage() {
		try {
			if (exportCardToExcel.isDisplayed()) {
				actionClick(exportCardToExcel);
				logPass("Search result is Displayed and exported");
				sleep(5);
			}
		} catch (NoSuchElementException ex) {
			logInfo(" No search results");
		}

	}

	public void checkthePOS() {
		scrollDownPage();
		sleep(1);
		isDisplayedThenActionClick(posPromptCheckbox, "Checked the check box");
		scrollDownPage();
		sleep(1);
		// isDisplayed(volumeLimit, "Selected input from dropdown volumeLimit");
		// selectInputFromDropdown(volumeLimit, 1);

		isDisplayed(costLimit, "Selected input from dropdown volumeLimit");
		selectInputFromDropdown(costLimit, 1);
		sleep(1);

	}

	/*
	 * 30-05-2018 Added by Ayub
	 */
	// Validate the Card Details Page

	public void validateTheCardDetailsPage() {
		checkTextInPageAndValidate("View Card Details", 10);
		checkTextInPageAndValidate("Card Details", 10);
		checkTextInPageAndValidate("Purchase Restrictions", 10);
		checkTextInPageAndValidate("Unusual Activity Limits", 10);
		checkTextInPageAndValidate("Delivery Address", 10);
		isDisplayed(returnToCardFoundList, "Return to Card FoundList button is Present");
		isDisplayed(printThisPage, "Print this Page is Present");
		isDisplayed(viewCardOptionsDropDown, "View Card Dropdown is Present");
		isDisplayed(goInViewCardPage, "Go Button is Present");

	}

	public void validateTheTransactionsDetailsPage() {
		checkTextInPageAndValidate("Find and Export Transactions", 10);
		checkTextInPageAndValidate(
				"Use the filters or advanced search options to limit the transaction list to a specific date range, account or cost centre etc",
				10);
		isDisplayed(cardNoInTransactionsPage, "Card No In TransactionsPage");
		isDisplayed(accountSelect, "Account Select drop down");
		isDisplayed(fromDate, "From Date field ");
		isDisplayed(toDate, "To Date field ");
		isDisplayed(dateRange, "Date Range drop down");
		isDisplayedThenClick(advancedSearchLink, "Adavnced serach");
		sleep(5);
		isDisplayed(product, "Product dropdown");
		isDisplayed(searchbutton, "Search Button");

	}

	// Raxsana added 12/06/19
	public void validateTheExcelSheet(String fileName, String clientCountry, String clientName, int headerRowNum,
			int bulkCount, String accountNumber) {

		HSSFSheet workSheet = null;
		HSSFRow row = null;
		HSSFWorkbook workBook = null;
		HSSFCell cell = null;
		int rowCount = 0;
		int rowCount1 = headerRowNum + 1;
		HashMap<String, String> keysAndValues = new HashMap<String, String>();
		IFCSCommonPage ifcsCommonPage = new IFCSCommonPage(driver, test);
		sleep(5);
		String downloadedFileName = getLatestDownloadedFileFromDir(fileName).getName();
		String downloadedFilePath = System.getProperty("user.home") + "\\Downloads\\" + downloadedFileName;
		System.out.println("Latest downloaded file" + downloadedFilePath);

		try {
			FileInputStream inputStream = new FileInputStream(new File(downloadedFilePath));
			workBook = new HSSFWorkbook(inputStream);
			workSheet = workBook.getSheet("BULKCARD");
		} catch (Exception e) {

			e.printStackTrace();
		}
		try {

			int noOfColumns = workSheet.getRow(headerRowNum).getLastCellNum();
			System.out.println("Number of columns is  " + noOfColumns);
			String[] columnHeaders = new String[noOfColumns];
			for (int j = 0; j < noOfColumns; j++) {
				columnHeaders[j] = workSheet.getRow(headerRowNum).getCell(j).getStringCellValue().replace(" ", "");
				System.out.println("Column headers " + columnHeaders[j]);

			}

			for (int bulkCountIteration = 0; bulkCountIteration < bulkCount; bulkCountIteration++) {
				
				keysAndValues = ifcsCommonPage.readKeyAndValueFromPropertyFile(bulkCardOrderInputValuesConfigProp, configProp, accountNumber,"Driver");
				System.out.println("Keys and values---->" + keysAndValues);
				
				if (fileName.equals("Bulk_Order_")) {
					rowCount = getRowNumberForBulkCardOrder(workSheet, headerRowNum);
					System.out.println("rowCount" + (rowCount));
					row = workSheet.getRow(rowCount - 1);
					row = workSheet.createRow(rowCount - 1);
					for (int a = 0; a < noOfColumns; a++) {
						for (String entry : keysAndValues.keySet()) {
							if (columnHeaders[a].equals(entry)) {
								cell = row.getCell(a);
								cell = row.createCell(a);
								cell.setCellValue(keysAndValues.get(entry));
							}
						}
					}
				} else {
					deleteRowsInExcelForUpdate(workSheet, headerRowNum + bulkCount);
					row = workSheet.getRow(rowCount1);
					for (int a = 0; a < noOfColumns; a++) {
						System.out.println("headers name-->" + columnHeaders[a]);
						if (columnHeaders[a].equals("CurrentCardStatus")) {
							for (String entry : keysAndValues.keySet()) {
								System.out.println("entry name-->" + entry);
								if (entry.equals("CurrentCardStatus")) {
									cell = row.getCell(a);
									cell.setCellValue(keysAndValues.get(entry));
								}
							}
						}
					}
				}

				rowCount1 = rowCount1 + 1;
				FileOutputStream outputStream = new FileOutputStream(downloadedFilePath);
				workBook.write(outputStream);
				outputStream.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public int getRowNumberForBulkCardOrder(HSSFSheet workSheet, int rowNum) {
		int i, k = 0, count = 0, defaultCount = 2;
		System.out.println("Last row num-->" + workSheet.getLastRowNum());
		for (i = rowNum; i < workSheet.getLastRowNum(); i++) {
			for (int j = 0; j < defaultCount; j++) {

				String value = workSheet.getRow(i).getCell(j).getStringCellValue();
				System.out.println("Value" + value);

				if (value.equals("")) {
					k = 1;
					count++;
					break;
				}
			}
			if (k == 1 && count == defaultCount) {
				break;
			}
		}
		return i;
	}

	public void deleteRowsInExcelForUpdate(HSSFSheet workSheet, int startingRowNum) {
		for (int i = startingRowNum + 1; i <= workSheet.getLastRowNum(); i++) {
			Row row = workSheet.getRow(i);
			if (row != null) {
				workSheet.removeRow(row);
			}
		}
	}
	
	public void clickGoButtonInViewCardPage(){
		isDisplayedThenActionClick(goInViewCardPage, "Search Cards");
		sleep(5);
	}
	
	
/*
	Enter search criteria and click on searchcards
	 */
	public void enterSearchCriteriaAndClickSearchCards(String cardNumber, String accountType, String cardStatusReq){
	    enterText(cardSearchTextBox,cardNumber);
	    selectDropDownByVisibleText(accountDropDown,accountType);
	    if(!(cardStatusReq.equals("")||(cardStatusReq.equals(null)))){
	    	 selectDropDownByVisibleText(cardStatus,cardStatusReq);
	        //chooseOptionFromDropdown("Card Status",cardStatus);
        }
        sleep(2);
        isDisplayedThenClick(customerSearch,"Clicking on search button");
    }
	
	public void validateTransactionCount(String accountType,String dateRangeValue,String transactionCount){
	    selectDropDownByVisibleText(accountSelect,"All Accounts");
        sleep(2);
        selectDropDownByVisibleText(dateRange,dateRangeValue);
        sleep(2);
        isDisplayedThenClick(searchbutton,"click on search button");
        List<WebElement> list = driver.findElements(By.cssSelector(Locator.TRANSACTION_COUNT));
        //String actCount = Integer.toString(list.size());
        Assert.assertEquals(list.size(),Integer.parseInt(transactionCount));
    }

}
