package com.framework.testcases.OLS.BP.Customer;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.BP.BPChangeCardStatusPage;
import com.framework.pages.BP.BPHomePage;
import com.framework.pages.OLS.common.BPCommonPage;
import com.framework.pages.OLS.common.FindAndUpdateCardPage;
import com.framework.pages.OLS.common.LoginPage;

public class ValidateChangeCardStatusPage extends BaseTest {
	@Parameters({"clientCountry","clientName"})
	@Test( groups = { "Smoke", "Regression" })
	public void testChangeCardStatusPage(@Optional("AU") String clientCountry, @Optional("BP") String clientName)  {
		test = extent.createTest(clientName+ ":" +clientCountry+"  BP Change Card Status Page", "Change the Card status and View the Card Details Page");
		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		BPHomePage bpHomePage = new BPHomePage(driver, test);
		FindAndUpdateCardPage findAndUpdateCardPage = new FindAndUpdateCardPage(driver, test);
		BPChangeCardStatusPage changeCardStatusPage = new BPChangeCardStatusPage(driver, test);
		BPCommonPage bpCommonPage = new BPCommonPage(driver, test);
		// Calling Functions
		loginPage.Login("BP_URL", "BP_UN_Customer_" + clientCountry, "BP_PWD_Customer_" + clientCountry, clientName);
		
		// Select Account and Validate
		bpHomePage.ValidateBPCustomerLogo();
		bpCommonPage.selectAccount();
		bpHomePage.loadFindAndUpdateCardPage();

		// Click search and select the card number
		findAndUpdateCardPage.verifyFindAndUpdateCardPageFields();
		findAndUpdateCardPage.selectAccountFromFindUpdateCardPage();
		findAndUpdateCardPage.clickSearchCard();
		findAndUpdateCardPage.clickChangeCardStatus();
		// findAndUpdateCardPage.pickChangeStatusOption();

		// Get the card number and change the Status
		changeCardStatusPage.verifyChangeCardStatusPage();
		changeCardStatusPage.getCurrentCardNumber();
		changeCardStatusPage.changeTheCardStatus();
		changeCardStatusPage.clickOnSaveChangesButton();
		if (clientCountry.equals("AU")) {
			changeCardStatusPage.verifyChangeCardStatusPopup();
			changeCardStatusPage.clickOnYesButtonInCardStatusPopup();
			changeCardStatusPage.verifyConfirmAddressPageField();
			changeCardStatusPage.clickConfirmAndReissueButton();

			if (changeCardStatusPage.isReissueDateErrorMsgPresent()) {
				changeCardStatusPage.clickOnSaveChangesButton();
			}
			// Verify the card status
			changeCardStatusPage.verifyCardStatusUpdatePage();
			changeCardStatusPage.verifyConfirmationMessage();

		} else {
			changeCardStatusPage.verifyConfirmationMessage();
		}
		// Verify Card Number
		changeCardStatusPage.clickOnFullCardDetailsButton();
		changeCardStatusPage.verifyFullCardDetailsPageField();
		changeCardStatusPage.clickOnReturnToFullCardDetailsButton();
		findAndUpdateCardPage.verifyFindAndUpdateCardPageFields();

		loginPage.Logout();

	}
}
