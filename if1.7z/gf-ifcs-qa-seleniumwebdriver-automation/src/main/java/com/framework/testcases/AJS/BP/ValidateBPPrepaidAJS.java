package com.framework.testcases.AJS.BP;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.common.Common;
import com.framework.pages.AJS.common.IFCSHomePage;
import com.framework.pages.AJS.common.IFCSLoginPage;
public class ValidateBPPrepaidAJS extends BaseTest {
   
    @Parameters({"clientCountry","clientName"})
    @Test( groups = { "Smoke", "Regression" })
    public void testNewApplicationTypeConfig(@Optional("AU") String clientCountry, @Optional("BP") String clientName)  {
        test = extent.createTest(clientName+ ":" +clientCountry+"  BP AJS New Application Type config", "Verify the new application is present or not in config");
        // Creating Objects for the Pages
        IFCSLoginPage ifcsLoginPage = new IFCSLoginPage(driver, test);
        IFCSHomePage ifcsHomePage = new IFCSHomePage(driver, test);
        Common common = new Common(driver, test);
        // Login to AJS application
        ifcsLoginPage.login("IFCS_URL_BP", "IFCS_BP_USERNAME", "IFCS_BP_PASSWORD");
        ifcsHomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);
        ifcsHomePage.gotoClientConfigAndApplicationTypes();
        ifcsHomePage.clickPrePay();
        ifcsHomePage.verifyPresenceOfReport("Fleet Control - Summary (Invoice) BP Plus Debit");
        common.verifyAccountStatusForPrepayDescription("Description","PrePay","Account Status");
        ifcsHomePage.exitIFCS();
    }
    @Parameters({"clientCountry","clientName"})
    @Test( groups = { "Smoke", "Regression" })
    public void testNewCardProgramConfig(@Optional("AU") String clientCountry, @Optional("BP") String clientName) {
        test = extent.createTest(clientName+ ":" +clientCountry+"  BP AJS New Application Type config", "Verify the new application is present or not in config");
        // Creating Objects for the Pages
        IFCSLoginPage ifcsLoginPage = new IFCSLoginPage(driver, test);
        IFCSHomePage ifcsHomePage = new IFCSHomePage(driver, test);
        // Login to AJS application
        ifcsLoginPage.login("IFCS_URL_BP", "IFCS_BP_USERNAME", "IFCS_BP_PASSWORD");
        ifcsHomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);
        ifcsHomePage.clickCardProgramsFromClientConfig();
        ifcsHomePage.dblClickBpPrepaidCards();
        ifcsHomePage.validateSelectedAccountType("Debit - Balance Fo...");
        ifcsHomePage.exitIFCS();
    }

}