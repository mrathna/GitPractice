package com.framework.pages.API.common;

import java.io.File;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;
import com.framework.basepage.BasePage;
import com.framework.util.APIUtils;
import com.framework.util.PropUtils;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
//import net.sourceforge.htmlunit.corejs.javascript.json.JsonParser.ParseException;

public class CommonAPI extends BasePage {
	public CommonAPI(WebDriver driver, ExtentTest test) {
		super(driver, test);
		// PageFactory.initElements(new AjaxElementLocatorFactory(driver, 15), this);

	}

	// File CommonAPIConfigFile;
	protected APIUtils apiUtils = new APIUtils();
	protected JSONObject requestParams = new JSONObject();
	protected Response response;
	protected JsonPath jsonPathEvaluator;
	protected JSONObject builder = new JSONObject();
	protected JSONObject obj = new JSONObject();

	public int getLastValueOfKeyInProp(File proFile, String prefix, String splitwith) {
		Properties props = PropUtils.getProps(proFile);
		Set<Object> set = props.keySet();
		int count = 1, valueInts;
		for (Object obj : set) {
			String str = obj.toString();
			if (str.startsWith(prefix)) {

				valueInts = Integer.parseInt(str.split(splitwith)[1]);
				if (valueInts >= count) {
					count = Integer.parseInt(str.split(splitwith)[1]) + 1;
				}
			}
		}
		return count;
	}

	/// Implemented by Ram Prasath
	public JSONArray jsonArrayBuilder(String key, String value) {
		builder.put(key, value);
		JSONArray array = new JSONArray();
		array.put(builder);
		System.out.println("JSON Array Builder -->" + array.toString());
		return array;

	}

	public String jsonObjectBuilderGetAsString(String key, String value) {
		obj.put(key, value);
		System.out.println("JSON Object Builder -->" + obj.toString());
		return obj.toString().replace("\"[", "[").replace("]\"", "]").replace("\\\"{", "{").replace("}\\\"", "}")
				.replace("\\\\\\\"", "\"");
	}

	public JSONArray jsonArrayBuilderHash(String key, HashMap<String, String> value) {
		builder.put(key, value);
		JSONArray array = new JSONArray();
		array.put(builder);
		System.out.println("JSON Array Builder -->" + array.toString());
		return array;

	}

	public JSONArray jsonArrayBuilderHashMap(String key, HashMap<String, String> value) {
		builder.put(key, value);
		JSONArray array = new JSONArray();
		array.put(builder);
		System.out.println("JSON Array Builder -->" + array.toString());
		return array;

	}

	public JSONArray jsonArrayBuilderTwoHashMap(String key, HashMap<String, HashMap<String, String>> value) {
		builder.put(key, value);
		JSONArray array = new JSONArray();
		array.put(builder);
		System.out.println("JSON Array Builder -->" + array.toString());
		return array;

	}

	public JSONObject jsonObjectBuilder(String key, String value) {
		obj.put(key, value);
		System.out.println("JSON Object Builder -->" + obj.toString());
		return obj;

	}

	public void loginToAPIUser(String username, String password) {
		RestAssured.baseURI = PropUtils.getPropValue(configProp, "baseURL");
		requestParams.put("grant_type", PropUtils.getPropValue(configProp, "GRANT_TYPE"));
		requestParams.put("username", username);
		requestParams.put("password", password);

		String accessToken = apiUtils.base64Encoder(PropUtils.getPropValue(configProp, "CLIENT_ID"),
				PropUtils.getPropValue(configProp, "SECERT_ID"));
		response = apiUtils.postRequestAsBasicAuthWithBodyData(accessToken, requestParams, "/login");
		/*
		 * System.out.println("Response Code: " + response.getStatusCode());
		 * System.out.println("Response Body: " + response.prettyPrint());
		 */
		jsonPathEvaluator = response.jsonPath();
		if (response.statusCode() == 200) {
			String authorizationToken = jsonPathEvaluator.get("token");
			// System.out.println("Authorization token " + authorizationToken);
			PropUtils.setProps(configProp, "AuthorizationToken", authorizationToken);
			//PropUtils.setProps(configProp, "REFRESH_TOKEN", jsonPathEvaluator.get("refresh_token"));
			System.out.println("Setting Token in Prop--> " + PropUtils.getPropValue(configProp, "AuthorizationToken"));

			Map<String, String> authToken = new HashMap<String, String>();
			authToken.put("AuthorizationToken", authorizationToken);
			PropUtils.creatingTempPropFile("CommonAPIConfig.properties", authToken);
		} else {
			logFail("There is a issue with login:" + response.prettyPrint());
		}
	}

	public void logoutAPIUser() {
		RestAssured.baseURI = PropUtils.getPropValue(configProp, "baseURL");
		response = apiUtils.postRequestAsBearerAuthWithNoBodyData("/logout",
				PropUtils.getPropValue(configProp, "AuthorizationToken"));
		if (response.statusCode() == 200) {
			logPass("LoggedOut of Session");
		} else {
			logInfo("LoggedOut of Session");
		}
	}

	public String getJsonArrayDataForCustomerCreation(String endPoint) {
		Response response;
		String result = null;

		try {
			RestAssured.baseURI = PropUtils.getPropValue(configProp, "baseURL");
			response = apiUtils.getRequestAsBearerAuth(endPoint, PropUtils.getProps(CommonAPIConfigFile));
			result = response.asString().split(",")[0].replaceAll("\\[|\\]", "").replaceAll("^\"|\"$", "");
			System.out.println("Response:" + result);
		} catch (Exception pe) {
			pe.printStackTrace();
		}
		return result;
	}

	public String getJSONArrayKeyFromJSONObject(String endPoint) {
		String result = null;
		RestAssured.baseURI = PropUtils.getPropValue(configProp, "baseURL");
		response = apiUtils.getRequestAsBearerAuth(endPoint, PropUtils.getProps(CommonAPIConfigFile));
		JSONObject jsonObject = new JSONObject(response.asString());
		Iterator<String> keys = jsonObject.keys();
		while (keys.hasNext()) {
			result = (String) keys.next();
		}
		System.out.println("Result:" + result);
		return result;
	}

	public String getJsonArrayDataFromJsonObj(String endPoint) {
		Response response;
		String result = null;

		try {
			RestAssured.baseURI = PropUtils.getPropValue(configProp, "baseURL");
			response = apiUtils.getRequestAsBearerAuth(endPoint, PropUtils.getProps(CommonAPIConfigFile));
			System.out.println(result = response.asString().split("\\[")[1].split(",")[0].replaceAll("\"|\\]\\}", ""));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	//public void locationCreation() throws JSONException, ParseException {
		public void locationCreation() throws JSONException {
		JSONObject requestParams = new JSONObject();
		JSONObject streetAddress = new JSONObject();
		// JSONObject PostalAddress = new JSONObject();

		// JSONArray contacts = new JSONArray();
		Response response;

		RestAssured.baseURI = PropUtils.getPropValue(configProp, "baseURL");

		requestParams.put("externalCode", "");
		requestParams.put("locationStatus", "");
		requestParams.put("name", "");
		requestParams.put("tradingName", "");
		requestParams.put("longitude", "");
		requestParams.put("latitude", "");
		requestParams.put("CustomerType", getJsonArrayDataForCreation("/location-type"));
		requestParams.put("CustomerType", getJsonArrayDataForCreation("/marketing-territories"));
		requestParams.put("StreetAddress", streetAddress);
		streetAddress.put("addressLine", fakerAPI().address().fullAddress());
		streetAddress.put("state", fakerAPI().address().fullAddress());
		streetAddress.put("suburb", fakerAPI().address().city());
		streetAddress.put("postalCode", fakerAPI().number().digits(4));
		streetAddress.put("country", fakerAPI().address().city());

		// above fields for location
		response = apiUtils.postRequestAsBearerAuthWithBodyData("/location", requestParams,
				PropUtils.getPropValue(configProp, "AuthorizationToken"));
		System.out.println("Response Code: " + response.getStatusCode());
		System.out.println("Response Body: " + response.prettyPrint());
	}

	public String getJsonArrayDataForCreation(String endPoint) {
		Response response;
		String result = null;

		try {
			RestAssured.baseURI = PropUtils.getPropValue(configProp, "lookUpURL");
			response = apiUtils.getRequestAsBearerAuth(endPoint, PropUtils.getProps(CommonAPIConfigFile));
			result = response.asString().split(",")[0].replace("[", "").replaceAll("^\"|\"$", "");
			System.out.println("Response:" + result);
		} catch (Exception pe) {
			pe.printStackTrace();
		}
		return result;
	}

}
