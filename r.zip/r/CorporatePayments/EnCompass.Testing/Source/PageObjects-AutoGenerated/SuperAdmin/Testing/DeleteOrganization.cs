using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using Common;
using Common.PageObjects;
using Common.ScenarioConfigurations;
using Common.Utility;

namespace EnCompass.Testing.Source.PageObjects.SuperAdmin.Testing 
{
	/// <summary>
	/// Auto-generated Page Model Class
	/// Navigation Paths: 
		/// [Organization Home]->General->Testing->Delete Test Organization
		/// </summary>
	[PageModel(@"/superAdmin/testing/DeleteOrganization.aspx")]
	public partial class DeleteOrganization : EnCompassSuperPageModel 
	{
		public override string RelativeUrl => @"/superAdmin/testing/DeleteOrganization.aspx";
		public override string PageIdentifierXPath_Generated => @"//li[contains(@class, 'breadcrumb-item active')][text() = 'Delete Test Organization']";

		#region Navigation
				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Create Organization']")]
		private IWebElement _general_Testing_DeleteTestOrganization_CreateOrganization { get; set; }
		public void NavigateTo_General_Testing_DeleteTestOrganization_CreateOrganization()
		{
			NavigateToMenuItem(_general_Testing_DeleteTestOrganization_CreateOrganization);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Create Organization Profile']")]
		private IWebElement _general_Testing_DeleteTestOrganization_CreateOrganizationProfile { get; set; }
		public void NavigateTo_General_Testing_DeleteTestOrganization_CreateOrganizationProfile()
		{
			NavigateToMenuItem(_general_Testing_DeleteTestOrganization_CreateOrganizationProfile);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Delete Test Organization']")]
		private IWebElement _general_Testing_DeleteTestOrganization_DeleteTestOrganization { get; set; }
		public void NavigateTo_General_Testing_DeleteTestOrganization_DeleteTestOrganization()
		{
			NavigateToMenuItem(_general_Testing_DeleteTestOrganization_DeleteTestOrganization);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Create Test Company']")]
		private IWebElement _general_Testing_DeleteTestOrganization_CreateTestCompany { get; set; }
		public void NavigateTo_General_Testing_DeleteTestOrganization_CreateTestCompany()
		{
			NavigateToMenuItem(_general_Testing_DeleteTestOrganization_CreateTestCompany);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Corporate Credit Limit']")]
		private IWebElement _general_Testing_DeleteTestOrganization_CorporateCreditLimit { get; set; }
		public void NavigateTo_General_Testing_DeleteTestOrganization_CorporateCreditLimit()
		{
			NavigateToMenuItem(_general_Testing_DeleteTestOrganization_CorporateCreditLimit);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Create Bounce Notification']")]
		private IWebElement _general_Testing_DeleteTestOrganization_CreateBounceNotification { get; set; }
		public void NavigateTo_General_Testing_DeleteTestOrganization_CreateBounceNotification()
		{
			NavigateToMenuItem(_general_Testing_DeleteTestOrganization_CreateBounceNotification);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Reset Merchant Log Error']")]
		private IWebElement _general_Testing_DeleteTestOrganization_ResetMerchantLogError { get; set; }
		public void NavigateTo_General_Testing_DeleteTestOrganization_ResetMerchantLogError()
		{
			NavigateToMenuItem(_general_Testing_DeleteTestOrganization_ResetMerchantLogError);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Performance']")]
		private IWebElement _general_Testing_DeleteTestOrganization_Performance { get; set; }
		public void NavigateTo_General_Testing_DeleteTestOrganization_Performance()
		{
			NavigateToMenuItem(_general_Testing_DeleteTestOrganization_Performance);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='AP Non-Card Payments Testing']")]
		private IWebElement _general_Testing_DeleteTestOrganization_ApNonCardPaymentsTesting { get; set; }
		public void NavigateTo_General_Testing_DeleteTestOrganization_ApNonCardPaymentsTesting()
		{
			NavigateToMenuItem(_general_Testing_DeleteTestOrganization_ApNonCardPaymentsTesting);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Modify Merchant Log']")]
		private IWebElement _general_Testing_DeleteTestOrganization_ModifyMerchantLog { get; set; }
		public void NavigateTo_General_Testing_DeleteTestOrganization_ModifyMerchantLog()
		{
			NavigateToMenuItem(_general_Testing_DeleteTestOrganization_ModifyMerchantLog);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Test Templates']")]
		private IWebElement _general_Testing_DeleteTestOrganization_TestTemplates { get; set; }
		public void NavigateTo_General_Testing_DeleteTestOrganization_TestTemplates()
		{
			NavigateToMenuItem(_general_Testing_DeleteTestOrganization_TestTemplates);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Create Test Statements']")]
		private IWebElement _general_Testing_DeleteTestOrganization_CreateTestStatements { get; set; }
		public void NavigateTo_General_Testing_DeleteTestOrganization_CreateTestStatements()
		{
			NavigateToMenuItem(_general_Testing_DeleteTestOrganization_CreateTestStatements);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Contact Us']")]
		private IWebElement _general_Testing_DeleteTestOrganization_ContactUs { get; set; }
		public void NavigateTo_General_Testing_DeleteTestOrganization_ContactUs()
		{
			NavigateToMenuItem(_general_Testing_DeleteTestOrganization_ContactUs);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Dispute Transaction']")]
		private IWebElement _general_Testing_DeleteTestOrganization_DisputeTransaction { get; set; }
		public void NavigateTo_General_Testing_DeleteTestOrganization_DisputeTransaction()
		{
			NavigateToMenuItem(_general_Testing_DeleteTestOrganization_DisputeTransaction);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Terms and Conditions']")]
		private IWebElement _general_Testing_DeleteTestOrganization_TermsAndConditions { get; set; }
		public void NavigateTo_General_Testing_DeleteTestOrganization_TermsAndConditions()
		{
			NavigateToMenuItem(_general_Testing_DeleteTestOrganization_TermsAndConditions);
		}

		
		private void NavigateToMenuItem(IWebElement element)
		{
			Driver.Url = element.GetAttribute("href");
		}
		#endregion

		public DeleteOrganization(GlobalSettings settings) : base(settings) { }
	}  
}
