package com.framework.testcases.OLS.SHELL.Customer;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.OLS.HomePage;
import com.framework.pages.OLS.common.LoginPage;
import com.framework.pages.SHELL.SHELLHomePage;

public class ValidateLoginHomePageMenu extends BaseTest {
	
	@Parameters({"clientCountry","clientName","cardType"})
	@Test(groups = { "Regression" })
	public void validateAdminLoginAndVerifyHomePage(@Optional("BE") String clientCountry, @Optional("SHELL") String clientName, @Optional("APA") String cardType)  {
		
		test = extent.createTest(clientName+ ":" +clientCountry+"  01 OLS Login page - Admin", "Logging in to Shell Online and Log Out from the Homepage");

        //Creating Objects for the Pages
        LoginPage loginPage = new LoginPage(driver, test);
        SHELLHomePage shellHpage=new SHELLHomePage(driver, test);
        HomePage homePage = new HomePage(driver, test);
		// Calling Functions
        if(cardType.equals("PC"))
        {
        	loginPage.Login("SHLPC_URL", "SHLPC_UN_Customer_Admin_" + clientCountry, "SHLPC_PWD_Customer_Admin_" + clientCountry, clientName);
        }
        else if(cardType.equals("APA"))
        {  
        	loginPage.Login("SHLAPA_URL", "SHLAPA_UN_Customer_Admin_" + clientCountry, "SHLAPA_PWD_Customer_Admin_" + clientCountry, clientName);
        }
		//
		homePage.ValidateLogoutLink();
		homePage.ValidateHelpShellLink();
		homePage.ValidateWelcomeText(clientName+"#"+cardType);
		homePage.ValidateQuickLinks();
		shellHpage.ValidateHeaderMenus("Admin");
		shellHpage.ValidateFooterMenus();
		shellHpage.ValidatePCShellLogo();
		//takeScreenshot();
		loginPage.Logout();
	}
	
	@Parameters({"clientCountry","clientName","cardType"})
	@Test(groups = { "Regression" })
	public void validateLoginPageAsCustomerUser(@Optional("AT") String clientCountry, @Optional("SHELL") String clientName, @Optional("APA") String cardType)  {
		
		test = extent.createTest(clientName+ ":" +clientCountry+"  01 Login as Customer User", "Logging in to Shell Online and Log Out from the Homepage");

        //Creating Objects for the Pages
        LoginPage loginPage = new LoginPage(driver, test);
        SHELLHomePage shellHpage=new SHELLHomePage(driver, test);
        HomePage homePage = new HomePage(driver, test);
		// Calling Functions
		
        if(cardType.equals("PC"))
        {
        	loginPage.Login("SHLPC_URL", "SHLPC_UN_Customer_User_" + clientCountry, "SHLPC_PWD_Customer_User_" + clientCountry, clientName);
        }
        else if(cardType.equals("APA"))
        {
        	loginPage.Login("SHLAPA_URL", "SHLAPA_UN_Customer_User_" + clientCountry, "SHLAPA_PWD_Customer_User_" + clientCountry, clientName);
        }
		//
		homePage.ValidateLogoutLink();
		homePage.ValidateHelpShellLink();
		homePage.ValidateWelcomeText(clientName+"#"+cardType);
		homePage.ValidateQuickLinks();
		shellHpage.ValidateHeaderMenus("Customer user");
		shellHpage.ValidateFooterMenus();
		shellHpage.ValidatePCShellLogo();
		//takeScreenshot();
		loginPage.Logout();
	}
	
	
	// Added by Ayub 27.06.2018
@Parameters({ "clientCountry", "clientName","cardType" })
	@Test(groups = { "Regression" })
	public void validateSelectQueryTypeDropDownValues(@Optional("AT") String clientCountry,
			@Optional("SHELL") String clientName, 
			@Optional("APA") String cardType) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  01 Select Query Type on Contact us page on OLS",
			"Logging in to Shell Online and Log Out from the Homepage");

		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		SHELLHomePage shellHpage = new SHELLHomePage(driver, test);
		HomePage homePage = new HomePage(driver, test);
		// Calling Functions
		 if(cardType.equals("PC"))
		    {
		    	loginPage.Login("SHLPC_URL", "SHLPC_UN_Customer_Admin_" + clientCountry, "SHLPC_PWD_Customer_Admin_" + clientCountry, clientName);
		    }
		    else if(cardType.equals("APA"))
		    {
		    	loginPage.Login("SHLAPA_URL", "SHLAPA_UN_Customer_Admin_" + clientCountry, "SHLAPA_PWD_Customer_Admin_" + clientCountry, clientName);
		    }
		//
		homePage.ValidateLogoutLink();
		homePage.ValidateHelpShellLink();
		homePage.ValidateWelcomeText(clientName+"#"+cardType);
		homePage.ValidateQuickLinks();
		shellHpage.ValidateHeaderMenus("Customer user");
		shellHpage.ValidateFooterMenus();
		shellHpage.goToContactUsPage();
		shellHpage.validateSelectQueryDropdownValues();
		//takeScreenshot();
		loginPage.Logout();
	}

	// Added by Ayub 27.06.2018
	@Parameters({ "clientCountry", "clientName","cardType" })
	@Test(groups = { "Regression" })
	public void validateQuickLinksFunctionality(@Optional("AT") String clientCountry,
			@Optional("SHELL") String clientName,@Optional("APA") String cardType) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  01 Verify details on home page",
				"Checking the Quickliks");

		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		SHELLHomePage shellHpage = new SHELLHomePage(driver, test);
		HomePage homePage = new HomePage(driver, test);
		// Calling Functions
		 if(cardType.equals("PC"))
		    {
		    	loginPage.Login("SHLPC_URL", "SHLPC_UN_Customer_Admin_" + clientCountry, "SHLPC_PWD_Customer_Admin_" + clientCountry, clientName);
		    }
		    else if(cardType.equals("APA"))
		    {
		    	loginPage.Login("SHLAPA_URL", "SHLAPA_UN_Customer_Admin_" + clientCountry, "SHLAPA_PWD_Customer_Admin_" + clientCountry, clientName);
		    }
		//
		homePage.ValidateLogoutLink();
		homePage.ValidateHelpShellLink();
		homePage.ValidateWelcomeText(clientName+"#"+cardType);
		homePage.ValidateQuickLinks();
		shellHpage.ValidateHeaderMenus("Customer user");
		shellHpage.ValidateFooterMenus();
		shellHpage.clickOnOrderNewCardQuickLinkAndValidatePage();
		shellHpage.clickOnchangeCardStatusQuickLinkAndValidatePage();
		shellHpage.clickOnCardListQuickLinkAndValidatePage();
		shellHpage.clickOntranscationQuickLinkAndValidatePage();
		shellHpage.clickOnExportTranscationQuickLink();
		//takeScreenshot();
		loginPage.Logout();
	}
	
	@Parameters({"clientCountry","clientName","cardType"})
	@Test(groups = { "Regression" })
	public void validateHeaderDetailsOnHomePage(@Optional("AT") String clientCountry, @Optional("SHELL") String clientName,@Optional("APA") String cardType)  {
		
		test = extent.createTest(clientName+ ":" +clientCountry+"  02 Verify Header details on Home page", "Validate Header details on homepage");

        //Creating Objects for the Pages
        LoginPage loginPage = new LoginPage(driver, test);
        SHELLHomePage shellHomePage = new SHELLHomePage(driver, test);
		// Calling Functions
        if(cardType.equals("PC"))
        {
               loginPage.Login("SHLPC_URL", "SHLPC_UN_Customer_Admin_" + clientCountry, "SHLPC_PWD_Customer_Admin_" + clientCountry, clientName);
        }
        else if(cardType.equals("APA"))
        {
               loginPage.Login("SHLAPA_URL", "SHLAPA_UN_Customer_Admin_" + clientCountry, "SHLAPA_PWD_Customer_Admin_" + clientCountry, clientName);
        }
		
		shellHomePage.validateAccountDetailsAtTopCorner();
		
		// Select dropdown and validate
		shellHomePage.selectAccountFromDropdownAndValidate();
		
		// 
		shellHomePage.selectTopUserDropdownAndChangePwdValidate();
			
		shellHomePage.clickHelpLinkAndValidateRedirection();
				
		// select display language randomly
		shellHomePage.selectDisplayLanguageFromDropdown();
		//takeScreenshot();
		// Click Logout validate
		loginPage.Logout();
		
	}
	
	@Parameters({"clientCountry","clientName","cardType"})
	@Test(groups = { "Regression" })
	public void validateFooterDetailsOnHomePage(@Optional("AT") String clientCountry, @Optional("SHELL") String clientName,@Optional("APA") String cardType)  {
		
		test = extent.createTest(clientName+ ":" +clientCountry+"  03 Verify Footer details on Home page", "Validate Footer details on homepage");

        //Creating Objects for the Pages
        LoginPage loginPage = new LoginPage(driver, test);
        SHELLHomePage shellHomePage = new SHELLHomePage(driver, test);
		// Calling Functions
        if(cardType.equals("PC"))
        {
               loginPage.Login("SHLPC_URL", "SHLPC_UN_Customer_Admin_" + clientCountry, "SHLPC_PWD_Customer_Admin_" + clientCountry, clientName);
        }
        else if(cardType.equals("APA"))
        {
               loginPage.Login("SHLAPA_URL", "SHLAPA_UN_Customer_Admin_" + clientCountry, "SHLAPA_PWD_Customer_Admin_" + clientCountry, clientName);
        }
		
		// Check Footer Links and validate the redirections
		shellHomePage.validateClickFooterLinksAndRedirection();
		//takeScreenshot();
		// Click Logout validate
		loginPage.Logout();
		
	}
	
	@Parameters({"clientCountry","clientName","cardType"})
	@Test(groups = { "Regression" })
	public void validateMainPageOnHomePage(@Optional("AT") String clientCountry, @Optional("SHELL") String clientName,@Optional("APA") String cardType)  {
		
		test = extent.createTest(clientName+ ":" +clientCountry+"  04 Verify Main Page details on Home page", "Validate Main Page on Homepage");

        //Creating Objects for the Pages
        LoginPage loginPage = new LoginPage(driver, test);
        SHELLHomePage shellHomePage = new SHELLHomePage(driver, test);
        HomePage homePage = new HomePage(driver, test);
		// Calling Functions
        if(cardType.equals("PC"))
        {
            loginPage.Login("SHLPC_URL", "SHLPC_UN_Customer_User_" + clientCountry, "SHLPC_PWD_Customer_User_" + clientCountry, clientName);
        }
        else if(cardType.equals("APA"))
        {
            loginPage.Login("SHLAPA_URL", "SHLAPA_UN_Customer_User_" + clientCountry, "SHLAPA_PWD_Customer_User_" + clientCountry, clientName);
        }
		//
		homePage.ValidateLogoutLink();
		homePage.ValidateHelpShellLink();
		homePage.ValidateWelcomeText(clientName+"#"+cardType);
		homePage.ValidateQuickLinks();
		shellHomePage.ValidateHeaderMenus("Customer user");
		shellHomePage.ValidateFooterMenus();

		shellHomePage.validateAccountDetailsAtTopCorner();
		
		// Select dropdown and validate
		shellHomePage.selectAccountFromDropdownAndValidate();
		
		// Click And Validate Export Hierarchy Button
		shellHomePage.clickExportHierarchyButton();
		
		// Click Logout validate
		//takeScreenshot();
		loginPage.Logout();
	}

	// Added by Ayub 28.06.2018
	// Below test cases are covered 
	 // 02 validation control UploadButton In CuntactUsPage
	 // 07 Upload button on contact Us Page - Clear all or stop button
	 // 08 Upload Button on Contact Us Page and Upload document
	
	@Parameters({ "clientCountry", "clientName","cardType" })
	@Test(groups = { "Regression" })
	public void validateContactUsPage(@Optional("AT") String clientCountry,
			@Optional("SHELL") String clientName,@Optional("APA") String cardType) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  02 Validation control for Upload Button on Contact us",
				"Checking Upload file functionality");

		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		SHELLHomePage shellHpage = new SHELLHomePage(driver, test);
		HomePage homePage = new HomePage(driver, test);
		// Calling Functions
		if(cardType.equals("PC"))
	    {
	    	loginPage.Login("SHLPC_URL", "SHLPC_UN_Customer_Admin_" + clientCountry, "SHLPC_PWD_Customer_Admin_" + clientCountry, clientName);
	    }
	    else if(cardType.equals("APA"))
	    {
	    	loginPage.Login("SHLAPA_URL", "SHLAPA_UN_Customer_Admin_" + clientCountry, "SHLAPA_PWD_Customer_Admin_" + clientCountry, clientName);
	    }
		//
		homePage.ValidateLogoutLink();
		homePage.ValidateHelpShellLink();
		homePage.ValidateWelcomeText(clientName+"#"+cardType);
		homePage.ValidateQuickLinks();
		shellHpage.ValidateHeaderMenus("Customer user");
		shellHpage.ValidateFooterMenus();
		// 02 validation control UploadButton In CuntactUsPage
		shellHpage.goToContactUsPage();
		shellHpage.validateUploadButton();
		// 07 Upload button on contact Us Page - Clear all or stop button. Added by Ayub on 29.06.2018
		// 06 Upload button on Contact Us Page on OLS -Upload File button on Pop up 
		// 05 Upload button on contact us page on OLS - Browse for button 
	    //shellHpage.uploadFileAndClearAll("Today");
	    shellHpage.uploadFileAndClearAll("ShellLogo");
		// 08 Upload Button on Contact Us Page and Upload document 
	    shellHpage.uploadFileAndGetFileName("ShellLogo");
	    //takeScreenshot();
	    loginPage.Logout();
	}
	
	
	@Parameters({ "clientCountry", "clientName","cardType" })
	@Test(groups = {"Regression" })
	public void validateLanguagedropdown(@Optional("AT") String clientCountry,
			@Optional("SHELL") String clientName,@Optional("APA") String cardType)
	{
	
	test = extent.createTest(clientName+ ":" +clientCountry+"  01 SHELL OLS Login page", "Logging in to Shell Online");
	//creating object for the Pages
	    LoginPage loginPage = new LoginPage(driver, test);
		SHELLHomePage shellHpage = new SHELLHomePage(driver, test);
		if(cardType.equals("PC"))
	    {
			loginPage.OpenOLSApplicationWithoutLogin("SHLPC_URL");
	    }
	    else if(cardType.equals("APA"))
	    {
	    	loginPage.OpenOLSApplicationWithoutLogin("SHLAPA_URL");
	    }
		
		
		shellHpage.verifyLanguageDropdown() ;
	
	}
	
	
	
		
		
	
}
