package com.framework.pages.SHELL;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.ExtentTest;
import com.framework.basepage.BasePage;
import com.framework.repo.Locator;

public class SHELLAccountPage extends BasePage {

	@FindBy(xpath = Locator.PAGETITLE)
	public WebElement pageTitleHeader;
	
	@FindBy(xpath = Locator.ACCOUNT_STATUS_DROPDOWN)
	public WebElement accountStatusDropdown;
	
	@FindBy(id = Locator.TRANSFER_TYPE)
	public WebElement transferType;
	
	@FindBy(id = Locator.FROM_ACCOUNT)
	public WebElement fromAccount;
	
	@FindBy(id = Locator.TO_ACCOUNT)
	public WebElement toAccount;	
	
	@FindBy(id = Locator.AMOUNT)
	public WebElement amount;
	
	@FindBy(id = Locator.SUBMIT_BTN)
	public WebElement submitBTN;	
	
	@FindBy(id = Locator.CONTACT_EXPORT)
	public WebElement exportContact;

	@FindBy(id = Locator.CONTACT_ADD_A_CONTACT)
	public WebElement addContact;

	@FindBy(id = Locator.EMAIL_FIELD)
	public WebElement emailField;

	@FindBy(id = Locator.CONTACT_ADD_A_CONTACT_BACK_CONTACTLIST)
	public WebElement backToContactList;	

	@FindBy(id = Locator.CONTACT_NAME)
	public WebElement contactName;
	
	@FindBy(id = Locator.MERCHANT_PHYSICAL_COUNTRY)
	public WebElement country;
	
	@FindBy(id = Locator.CONTACT_SAVE)
	public WebElement conSave;
	
	@FindBy(id=Locator.ACCOUNT_SUMMARY)
	public WebElement accountSummary;
	
	@FindBy(id = Locator.ACCOUNT_AT_FIND_COST_CENTRE)
	public WebElement accountDropdownCardGroup;
	
	@FindBy(id = Locator.DESCRIPTION_COMMON)
	public WebElement cardGroupDescription;


	@FindBy(id = Locator.COST_CENTRE_FIELD)
	public WebElement cardGroupId;

	@FindBy(id = Locator.SEARCH_CARDS)
	public WebElement searchCards;

	
	
	
	// Added by Ayub on 19.06.2018
	
	@FindBy(id = Locator.CURRENT_CARD_NUMBER)
	public WebElement currentCardNumber;
		
	@FindBy(id = Locator.SEARCH_LINK)
	public WebElement searchLink;
	
	@FindBy(id = Locator.EXPORT_DIRVER_LIST)
	public WebElement exportDriverList;   
	
	@FindBy(id = Locator.EXPORT_VEHICLE_LIST)
	public WebElement exportVechileList;
	
	@FindBy(id = Locator.ALL_DRIVER_ACCOUNT)
	public WebElement allDriverAccount;
	
	@FindBy(id = Locator.DRIVER_TABLE)
	public WebElement driverTable;	


	// Added by Ayub on 20.06.2018
	@FindBy(id = Locator.FROM_CARD)
	public WebElement fromCard;

	@FindBy(id = Locator.TO_CARD)
	public WebElement toCard;

	@FindBy(id = Locator.TO_CARD_NOITEMS)
	public WebElement noItems; 
	
	// Added by Ayub on 05.07.2018
	@FindBy(id = Locator.CONTACT_SAVE)
	public WebElement saveButton;
	
	@FindBy(id = Locator.PHYSICAL_ADDRESS)
	public WebElement address;
    
	@FindBy(id = Locator.ACCOUNT_NUMBER_DROPDOWN)
	public WebElement accountdropdown;
	
	@FindBy(id = Locator.SEARCH_BTN)
	public WebElement searchBtn;
	
	@FindBy(id = Locator.VEHICLE_TABLE)
	public WebElement vehilceTable;
	
	@FindBy(xpath = Locator.PAGE_HEADER)
	public WebElement pageHeader;

	@FindBy(id = Locator.ADD_NEW_CARD_GROUP)
	public WebElement addCardGroup;
	
	@FindBy(id = Locator.COST_CENTRE_SHORT_DESC_FIELD)
	public WebElement cardGrpShortDesc;
	
	@FindBy(id = Locator.BACK_TO_CARD_GROUP_LIST)
	public WebElement backToCardGrpList;
	
	@FindBy(id = Locator.CONFIRMATIONMESSAGE)
	public WebElement successMsg;
	
	// Added by Ayub 24-9-2018
	
	@FindBy(id = Locator.PHONE_FIELD)
	public WebElement phoneFldProfile;
		
	@FindBy(xpath = Locator.CONTACT_NUM)
	public WebElement contactNum;
	
	@FindBy(xpath = Locator.SHELL_CONTACT_NAME)
	public WebElement shellContactName;
	
	private double fundTransferLimit=100.00;
	

	public SHELLAccountPage(WebDriver driver, ExtentTest test) {
		super(driver, test);
		PageFactory.initElements(driver, this);
	}
	
	public void verifyFundTransferPageIsLoaded() {
		
		checkTextInPageAndValidate("Funds Transfer", 20);
		
		checkTextInPageAndValidate("Funds Transfer Details", 20);
		
		checkTextInPageAndValidate("Transfer Type", 20);
		
		checkTextInPageAndValidate("From Account", 20);
		
		checkTextInPageAndValidate("Amount", 20);
		
	}
	
	public void selectTheAccounts()
	{
		isDisplayed(transferType, "Transfer Type");
		selectDropDownByVisibleText(transferType, "Account to Account");
		isDisplayed(fromAccount, "From Account Drop down");
		int fromAccountSize = getDropdownSize(fromAccount);
		int toAccountSize =0;
		boolean loopExit = false;
		
		if(fromAccountSize >0)
		{
			
			System.out.println("----- fromAccountSize ---- "+fromAccountSize); 
			
			if(fromAccountSize > 2)
			{
				for(int i=1;i<fromAccountSize-1;i++)
				{	
					
					if(loopExit)
					{	
						break;
					}
					
					selectDropDownByIndex(fromAccount, i);
					
					sleep(3);
					
					checkTextInPageAndValidate("Available Balance", 10);
					
					boolean isavlbalGZero = isAvaialbleBalanceGreaterThanFundTransferLimit();
					
					if(isavlbalGZero)
					{
						loopExit = true;
						
						isDisplayed(toAccount, "To Account dropdown");
						
						toAccountSize = getDropdownSize(toAccount);
						
						System.out.println("toAccountSize ---- "+toAccountSize);
						
						if(toAccountSize > i+1)
						{
							selectDropDownByIndex(toAccount, i+1);
							sleep(3);
						}
						
						else if(toAccountSize == i+1)
						{
							selectDropDownByIndex(toAccount, i);
							sleep(3);
						}
						
						else
						{
							logInfo("------- There is no to account or only one account present -------");
						}
						
					}
					
					else
					{
						logInfo("Avaialble balance is less than or equal to Fund transfer limit, We can't transfer this amount to the other account");
					}
				} 
			}
			
			else
			{
				selectDropDownByIndex(fromAccount, 1);
				
				checkTextInPageAndValidate("Available Balance", 10);
				
				boolean isavlbalGZero = isAvaialbleBalanceGreaterThanFundTransferLimit();
				
				if(isavlbalGZero)
				{
					isDisplayed(toAccount, "To Account dropdown");
					
					toAccountSize = getDropdownSize(toAccount);
					
					System.out.println("toAccountSize ---- "+toAccountSize);
					
					if(toAccountSize > 2)
					{
						selectDropDownByIndex(toAccount, 2);
						sleep(3);
					}
					
					else if(toAccountSize == 2)
					{
						selectDropDownByIndex(toAccount, 1);
						sleep(3);
					}
					
					else
					{
						logInfo("------- There is no to account or only one account present -------");
					}
				}
				
				else
				{
					logInfo("Avaialble balance is less than or equal to Fund transfer limit, We can't transfer this amount to the other account");
				}
			}
				
			}
		
		else
		{
			logInfo("------- There is no from account -------");
		} 
		
	}

	/*
	 * This method will return availableBalanceGreaterThanZeroOrNot
	 * 
	 */
	
	private boolean isAvaialbleBalanceGreaterThanFundTransferLimit() {
		// TODO Auto-generated method stub
		
		isDisplayed(accountSummary, "Account Summary");
		
		String accountSummaryText=accountSummary.getText();
		System.out.println("accountSummary == "+accountSummaryText);
		
		String availableBalanceFull = accountSummaryText.split("\n")[1];
		
		String availBalance = availableBalanceFull.split(":")[1];
		
		double availBalanceDouble = Double.parseDouble(availBalance.trim());
		
		if(availBalanceDouble > fundTransferLimit )
		{
			return true;
		}
		else
		{		
			return false;
		}
	}
	
	public void enterAmountFundtransferAndValidate()
	{
		isDisplayedThenEnterText(amount, "Amount value for fund transfer", String.valueOf(fundTransferLimit));
		
		isDisplayedThenClick(submitBTN, "Submit for fund transfer");
		
		sleep(10);
		
		boolean fundsSuccessful = waitForTextToAppear("Funds transfer successful", 30);
		
		if(fundsSuccessful)
		{
			logPass("Funds transfer successful, Parent to Child account");
		}
		
		else
		{
			checkTextInPageAndValidate("Validation failed", 30);			
			
			boolean isToacctBlank = waitForTextToAppear("must not be blank.", 30);
			
			if(!isToacctBlank)
			
			{
				boolean sameAccountError =waitForTextToAppear("To Account Cannot be the same as From Account",30);
										
				if(sameAccountError)
				{
					logPass("To Account Cannot be the same as From Account text is present");
				}
				else
				{
					boolean noHierarchy = waitForTextToAppear("No Hierarchy found for this account", 30);
					
					if(noHierarchy)
					{
						logPass("No Hierarchy found for this account text is present");
					}
					
					else
					{
					
						logInfo("No Hierarchy found for this account text is not present");
					
						boolean fromAcctHierarchy = waitForTextToAppear("From Account Not in the same Hierarchy.", 30);
					
						if(fromAcctHierarchy)
						{
							logInfo("From Account Not in the same Hierarchy. text is present");						
							checkTextInPageAndValidate("To Account Not in the same Hierarchy.",30);
						}
					
						else
						{					
							logInfo("From Account Not in the same Hierarchy. text is not present");	
							
							boolean accFinRel = waitForTextToAppear("Account is not an Authorisation node", 30);
							
							if(accFinRel)
							{
								logPass("Account is not an Authorisation node text is present");
							}
							
							else
							{
								logInfo("Account is not an Authorisation node text is not present");
								checkTextInPageAndValidate("Account does not have an active relationship in Financial Hierarchy", 30);
							}
							
							
							
							 
						}
						
					} 
				
				}
			}
			
			else
			{
					
				logPass("Either From Account must not be blank or To account must not be blank or both the texts are present");
				
			}
			 
		} 
		
	}

	/*
	 * This method to verify card to Account Details
	 * 
	 */
	
	public void verifyCardToAccountDetails() {
		// TODO Auto-generated method stub
		isDisplayed(transferType, "Transfer Type drop down");
		
		selectDropDownByVisibleText(transferType, "Card to Account");
		
		sleep(5);		
		
		checkTextInPageAndValidate("From Card", 30);
		
		checkTextInPageAndValidate("To Account", 30);
	}
	

	public void validateCustomerMaintenancePage() {
		sleep(3);
		isDisplayed(pageTitleHeader, "Verify Customer Maintenance");

		

		
		checkTextInPageAndValidate("Details", 20);
		
		checkTextInPageAndValidate("Address", 20);
		
	}
	
	public void checkAccountStatusDisabledOrEnabled() {
	
	try {
		String isDisabled = accountStatusDropdown.getAttribute("disabled");
		if(isDisabled.equals("disabled")) {
			logPass("Account dropdown is Disabled");
		} else {
			isDisplayed(accountStatusDropdown, "Account Drop down is displayed");
			logPass("Account dropdown is displayed");
		}
	} catch(Exception ex) {
			logInfo("Account dropdown is not displayed");
	}
	}
	
	public void selectAccountNameFromDropDown() {
		
		String currentAccStatus = getText(accountStatusDropdown);
		if(currentAccStatus.equals("A - Active")) {
			sleep(3);
		selectDropDownByVisibleText(accountStatusDropdown, "B - Blocked/Suspended");
		}
	}


	public void exportContactList() {

		isDisplayedThenActionClick(exportContact, "Export the contact list");

	}

	public void invalidEmailValidation() {
		isDisplayedThenClick(addContact, "Add A Contact");
		isDisplayedThenEnterText(contactNum, "Contact Number", fakerAPI().phoneNumber().phoneNumber());
		isDisplayedThenEnterText(emailField, "Email Address for New User", "Test");
		isDisplayedThenClick(saveButton, " Save Button");
		checkTextInPageAndValidate("Email Invalid email address", 20);
		sleep(3);
	}

	public void validateBlankAddressPage() {
		String email = fakerAPI().internet().emailAddress();
		isDisplayedThenClearText(shellContactName, "Contact Name");
		isDisplayedThenEnterText(emailField, "Email Address for New User", email);
		sleep(5);
		isDisplayedThenClick(saveButton, " Save Button");
		checkTextInPageAndValidate("Contact Name  must not be blank.", 20);
		sleep(3);
	}

	public void backtoContactList() {
		//isDisplayedThenClick(addContact, "Add A Contact");
		isDisplayedThenClick(backToContactList, "Baack To Contact List");
		sleep(5);

	}
	
	public void addAndSaveContact() {
		String contactname = fakerAPI().name().username().toString();
		String addressdeatils = fakerAPI().address().streetAddress();
		// isDisplayedThenClick(addContact, "Add A Contact");
		isDisplayedThenEnterText(contactName, "Contact Name", contactname);
		sleep(5);
		isDisplayedThenEnterText(address, "Address", addressdeatils);
		sleep(5);
		isDisplayed(country, "Selected input from dropdown State");
		
		selectInputFromDropdown(country, 1);
		sleep(3);
		isDisplayedThenActionClick(conSave, "Save button");
		sleep(3);
		checkTextInPageAndValidate("Successfully Saved Contact-", 20);
		sleep(3);	
	}

	public void validateCardGroupsSearchPage() {
		isDisplayed(pageTitleHeader, "Verify Customer Maintenance");
		verifyText(pageHeader, "CARD GROUP LIST");
		checkTextInPageAndValidate("Search", 20);
	}
		
	public void searchCardGroupBasedOnInputs() {
		selectInputFromDropdown(accountDropdownCardGroup, 3);
		isDisplayedThenEnterText(cardGroupDescription, "Enter the Description", "");
		isDisplayedThenEnterText(cardGroupId, "Enter the Card Group ID", "");
	}
	
	public void clickSearchButton() {
		isDisplayedThenActionClick(searchCards, "Click Search Button");
	}
	
	/*
	 * This method to verify Card to Card page is loaded correctly
	 */

	public void verifyCardToCardDetails() {
		// TODO Auto-generated method stub
		
		isDisplayed(transferType, "Transfer Type drop down");
		
		selectDropDownByVisibleText(transferType, "Card to Card");
		
		sleep(5);
		
		checkTextInPageAndValidate("From Card", 30);
		
		checkTextInPageAndValidate("To Card", 30);
		
	}
	
	/*
	 * This method is to verify the Account to 
	 * card Details
	 * 
	 */

	public void verifyAccountToCardDetails() {
		
		isDisplayed(transferType, "Transfer Type drop down");
		
		selectDropDownByVisibleText(transferType, "Account to Card");
		
		sleep(5);
		
		// TODO Auto-generated method stub
		checkTextInPageAndValidate("From Account", 30);
		checkTextInPageAndValidate("To Card", 30);
		
	}
	
	
	// Added by Ayub on 19.06.2017 
	
	public void validateDriversPage() {
		checkTextInPageAndValidate("DRIVER LIST", 10);
		checkTextInPageAndValidate("Search", 10); 
	}
		
		public void validateVehiclesPage() {
			checkTextInPageAndValidate("Vehicle List", 10);
			//checkTextInPageAndValidate("Search", 10); 
		

	}
	
	public void selectAllAccountsAndValidate() {
		//String textFind = null;
		try {
			if (allDriverAccount.isDisplayed()) {
				selectDropDownByVisibleText(allDriverAccount, "All Accounts");
				logInfo("All Accounts option is selected");

				sleep(2);

				isDisplayedThenClick(searchLink, "Search Vehicles button");
			}
			} catch (Exception ex) {
				logFail(ex.getMessage());
			}
	}
	
	public void setCellDataFromDriverTable(int expColSize) {
		setCellDataFromTable(driverTable, expColSize, false);
	}

	public void serachCardAndExportDriverList() {
		String cardNumber = getCellDataFromTable(1, 3, false);
		sleep(3);
		isDisplayedThenEnterText(currentCardNumber, "Card Number", cardNumber);
		sleep(3);
		isDisplayedThenClick(searchLink, "Serach link");
		sleep(2);
		isDisplayedThenActionClick(exportDriverList, " Export to the Driver List");
		sleep(2);
		isDisplayedThenEnterText(currentCardNumber, " Card Number", "*");
		sleep(3);
		isDisplayedThenClick(searchLink, "Serach link");	
		scrollDownPage();
		sleep(3);
	}
	
	public void serachCardAndExportVehicleList() {
		String cardNumber = getCellDataFromTable(1, 3, false);
		isDisplayedThenEnterText(currentCardNumber, " Card Number", cardNumber);
		sleep(3);
		isDisplayedThenClick(searchBtn, "Serach link");
		sleep(2);
		isDisplayedThenActionClick(exportVechileList, " Export to the Driver List");
		sleep(2);
		isDisplayedThenEnterText(currentCardNumber, " Card Number", "*");
		sleep(3);
		isDisplayedThenClick(searchBtn, "Serach link");
		sleep(3);
	}

	// Added by Ayub on 20.06.2018
	
	public void selectCardToCard() {
		isDisplayed(transferType, "Transfer Type");
		selectDropDownByVisibleText(transferType, "Card to Card");
		sleep(2);
		checkTextInPageAndValidate("From Card", 30);
		checkTextInPageAndValidate("To Card", 30);
		sleep(2);
		isDisplayedThenEnterText(toCard, "To Card No", "7018");
		sleep(2);
		List<WebElement> toCards = driver.findElements(By.xpath("//div[@id='lform:to_card_noItems']/div"));
		sleep(2);

		if (toCards != null && toCards.size() > 0) {
			toCards.get(0).click();
		} else {
			System.out.println(" No Items listed in Auto Suggestion");
		}
		sleep(3);
	}
	
	// Added by Ayub on 05.07.2018
	public void selectAllAccountsFormAccontNumberDropdown() {
		//String textFind = null;
		try {
			if (accountdropdown.isDisplayed()) {
				selectDropDownByVisibleText(accountdropdown, "All Accounts");
				logInfo("All Accounts option is selected");

				sleep(2);

				isDisplayedThenClick(searchBtn, "Search Vehicles button");
				sleep(3);
			}
			} catch (Exception ex) {
				logFail(ex.getMessage());
			}
	}
	
	public void setCellDataFromVehilceTable(int expColSize) {
		setCellDataFromTable(vehilceTable, expColSize, false);
	}
	
	// Added by Ayub on 18-07-2018
	public boolean verifyVehilceListDataIsAvailable()
	{
		boolean isVehilceList = false;
		
		isVehilceList = waitForTextToAppear("No Vehicles Found.", 30);		
		
		return isVehilceList;
	}

	public void printNoVehilceListPresent() {
		logInfo("No Vehilce list is present");		
	}
	
	// Added by Ayub on 25-07-2018
	public boolean verifyDriverListDataIsAvailable()
	{
		boolean isDriverList = false;
		
		//isDriverList = waitForTextToAppear("No Driver Found.", 30);		
		isDriverList = waitForTextToAppear("Driver List is Empty", 30);
		
		return isDriverList;
	}

	public void printNoDriverListPresent() {
		logInfo("No Driver list is present");		
	}
	
	public void clickSearchBtn() {
		
		isDisplayedThenActionClick(searchCards, "Click Search Button");
	}
	
	public void clickSearchBtnAndValidateCardGrp(String actCardGrp) {
		
		isDisplayedThenEnterText(cardGroupId, "Enter the Card Group Number", actCardGrp);
		
		
		isDisplayedThenActionClick(searchCards, "Click Search Button");
		sleep(3);
		checkTextInPageAndValidate(actCardGrp, 30);
		logPass("New Card Group was Present");
	}
	
	public String clickAddCardGroupAndValidate() {
		
		isDisplayedThenActionClick(addCardGroup, "Click Add Card Group");
		sleep(3);
		verifyText(pageHeader, "ADD NEW CARD GROUP");

		String cardGrpNumber = fakerAPI().code().asin();
		String cardGrpDesc = fakerAPI().name().fullName();
		String cardGroupShortDesc = fakerAPI().name().firstName();

		isDisplayedThenEnterText(cardGroupId, "Enter the Card Group Number", cardGrpNumber);
		
		isDisplayedThenEnterText(cardGroupDescription, "Enter the Card Group Description", cardGrpDesc);
		
		isDisplayedThenEnterText(cardGrpShortDesc, "Enter the Card Group Short Desc", cardGroupShortDesc);
		
		isDisplayedThenActionClick(conSave, "Click Save Button");
		sleep(3);
		isDisplayed(successMsg, "Success Popup is Displayed");
		sleep(3);
		return cardGrpNumber;
	}
	
	public void clickBackToCardGrpListAndValidate() {
		
		isDisplayedThenActionClick(backToCardGrpList, "Click Back to Card Grp List");
		sleep(3);
		verifyText(pageHeader, "CARD GROUP LIST");
		
	}
	
	// Added by Ayub 24-09-2018

	public void validatePhoneField() {
		String phone = fakerAPI().phoneNumber().phoneNumber();
		isDisplayedThenEnterText(phoneFldProfile, "Phone for the New User", phone);
		addAndSaveContact();
		
		}
	public void clickAddContact() {
	isDisplayedThenClick(addContact, "Add A Contact");
	}
}
