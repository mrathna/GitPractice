﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EnCompass.Testing.Source.FileTemplates
{
	public class Draft5File
	{
		public string LastFour { get; set; }
		public string Amount { get; set; }
		public string FeeType { get; set; }
	}
}
