package com.framework.pages.SHELL;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.aventstack.extentreports.ExtentTest;
import com.framework.basepage.BasePage;
import com.framework.repo.Locator;

public class UpdateLanguage extends BasePage {
	
	@FindBy(id = Locator.LANGUAGE_FORM)
	public WebElement languageForm;

	public UpdateLanguage(WebDriver driver, ExtentTest test) {
		super(driver, test);
		PageFactory.initElements(driver, this);
		// TODO Auto-generated constructor stub
	}
	
	public void updateLanguagePage() {
		sleep(5);
		Select Language = new Select(driver.findElement(By.id("lform:language_oid")));
		Language.selectByVisibleText("English (Malaysia)");
		
		sleep(2);
		driver.findElement(By.id("lform:userEditProfile_saveBtn")).click();
		sleep(10);
		Select DisplayLanguage = new Select(driver.findElement(By.id("languageForm:j_idt44")));
		DisplayLanguage.selectByVisibleText("Bahasa Melayu");
    	sleep(5);
	}
	
	public boolean validateLanguageSelection() {
			sleep(3);

		boolean isLanguageSelected = false;
		
		Select Language = new Select(driver.findElement(By.id("lform:language_oid")));

		
		System.out.println(Language.getFirstSelectedOption());
		System.out.println(Language.getFirstSelectedOption().getText() + "******************");
		return isLanguageSelected;
	}
   
}
