package com.framework.testcases.OLS.EMAP.Customer;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.OLS.common.LoginPage;
import com.framework.util.PropUtils;

public class ValidateUserBlockOnMultipleInvalidLogin extends BaseTest {
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "Regression" })
	public void validateUserGetBlockedAfterMultipleInvalidLoginAttempt(@Optional("SP") String clientCountry,
			@Optional("EMAP") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  TST-SC-80-OLS - invalid user - block on multiple tries",
				"On multiple invalid login attempts the user account should get blocked");

		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
 		loginPage.validateLoginPageFooterLinks(clientName, "EMAP_URL");
		// Reset Log on Count as 0
		loginPage.resetLogonCountAsZeroForUser(
				PropUtils.getPropValue(configProp, "EMAP_UN_ReadWrite_Customer_LockChk_" + clientCountry));

		// 1st Attempt
		loginPage.loginWithUsernameAndPwd(
				PropUtils.getPropValue(configProp, "EMAP_UN_ReadWrite_Customer_LockChk_" + clientCountry),
				"invalidLoginPwd");
		loginPage.validateErrorMsgValidUsernameAndWrongPassword();

		// 2nd Attempt
		loginPage.loginWithUsernameAndPwd(
				PropUtils.getPropValue(configProp, "EMAP_UN_ReadWrite_Customer_LockChk_" + clientCountry),
				"invalidLoginPwd");
		loginPage.validateErrorMsgValidUsernameAndWrongPassword();

		// 3rd Attempt
		loginPage.loginWithUsernameAndPwd(
				PropUtils.getPropValue(configProp, "EMAP_UN_ReadWrite_Customer_LockChk_" + clientCountry),
				"invalidLoginPwd");
		loginPage.validateErrorMsgValidUsernameAndWrongPassword();

		// 4th Attempt
		loginPage.loginWithUsernameAndPwd(
				PropUtils.getPropValue(configProp, "EMAP_UN_ReadWrite_Customer_LockChk_" + clientCountry),
				"invalidLoginPwd");
		loginPage.validateErrorMsgValidUsernameAndWrongPasswordAccountLock();

		// 5th Attempt
		loginPage.loginWithUsernameAndPwd(
				PropUtils.getPropValue(configProp, "EMAP_UN_ReadWrite_Customer_LockChk_" + clientCountry),
				"invalidLoginPwd");
		loginPage.validateErrorMsgAccountLock();

	}
}
