package com.framework.pages.CHEV;

import java.io.File;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.ExtentTest;
import com.framework.basepage.BasePage;
import com.framework.repo.Locator;

public class CHHomePage extends BasePage {

	@FindBy(id = Locator.CARDS_MENU)
	public WebElement chCardsMenu;

	@FindBy(how = How.ID, using = Locator.FINDANDUPDATECARDS)
	public WebElement findAndUpdateCardSubMenu;
	
	@FindBy(how = How.ID, using = Locator.CH_REISSUE_CONTROL)
	public WebElement reissueControl;
	
	@FindBy(how = How.ID, using = Locator.BULK_CARD_STATUS_SUB_MENU)
	public WebElement bulkStatusChange;
	

	@FindBy(how = How.ID, using = Locator.ORDER_A_CARD)
	public WebElement orderCardSubMenu;

	@FindBy(how = How.XPATH, using = Locator.ADHOC_REPORTS_TITLE)
	public WebElement pageTitleForCardList;

	@FindBy(how = How.XPATH, using = Locator.HELP_REF)
	public WebElement helpLink;

	@FindBy(how = How.XPATH, using = Locator.CH_EDIT_CARD_TITLE)
	public WebElement editCardTitle;

	@FindBy(how = How.XPATH, using = Locator.HOME_MENU)
	public WebElement homeMenuLink;

	@FindBy(how = How.ID, using = Locator.CH_ORDER_CARD_QUICK_LINK)
	public WebElement orderCardQuickLink;

	@FindBy(how = How.ID, using = Locator.CH_CARDS_QUICK_LINK)
	public WebElement cardsQuickLink;

	@FindBy(how = How.ID, using = Locator.CH_CARD_STATUS_QUICK_LINK)
	public WebElement cardStatusQuickLink;

	@FindBy(how = How.ID, using = Locator.CH_TRANSACTION_QUICK_LINK)
	public WebElement transactionsQuickLink;

	@FindBy(how = How.XPATH, using = Locator.MERC_TRANSACTION_LINKS)
	public WebElement merchantTransQuickLink;
	
	@FindBy(how = How.ID, using = Locator.LOC_TRANSACTION_LINKS)
	public WebElement locationTransQuickLink;

	@FindBy(how = How.ID, using = Locator.CH_EXPORT_TRANSACTION_QUICK_LINK)
	public WebElement exportTransactionQuickLink;

	@FindBy(how = How.XPATH, using = Locator.EXPORT_TRANSACTION_LINKS)
	public WebElement merchantExportTransQuickLink;
	
	@FindBy(how = How.ID, using = Locator.SESPENDED_TRANSACTION_LINKS)
	public WebElement suspendedTransaction;

	@FindBy(how = How.XPATH, using = Locator.CH_HOME_PAGE_USERNAME)
	public WebElement userNameDropDown;

	@FindBy(how = How.ID, using = Locator.CH_MERCHANT_CHANGE_PWD_LINK)
	public WebElement changePasswordLink;

	@FindBy(how = How.ID, using = Locator.ACCOUNTS_MENU)
	public WebElement accountsMenu;

	@FindBy(how = How.ID, using = Locator.ACCOUNT_MAINTENANCE_MENU)
	public WebElement accountsMaintenanceMenu;

	@FindBy(how = How.ID, using = Locator.TRANSACTIONS_MENU)
	public WebElement transactionsMenu;

	@FindBy(how = How.ID, using = Locator.FIND_EXPORT_TRANSC)
	public WebElement transactionListLink;

	@FindBy(how = How.XPATH, using = Locator.SCHEDULE_REPORT_MAINTENANCE_PAGE)
	public WebElement secondPageTitle;

	@FindBy(how = How.XPATH, using = Locator.CH_TRANSACTION_LIST_TITLE)
	public WebElement transactionPageTitle;
	
	@FindBy(how = How.XPATH, using = Locator.CH_TRANSACTION_LIST_TITLE)
	public WebElement pageTitle;

	@FindBy(how = How.ID, using = Locator.REPORTS_MENU)
	public WebElement reportsMenu;

	@FindBy(how = How.ID, using = Locator.PAST_REPORTS)
	public WebElement findReportsSubMenu;
	
	@FindBy(how = How.ID, using = Locator.Invoice_REPORTS )
	public WebElement findInvoiceSubMenu;

//	@FindBy(how = How.XPATH, using = Locator.SCHEDULE_REPORT_MAINTENANCE_PAGE)
//	public WebElement storedReportsPageTitle;

	@FindBy(how = How.ID, using = Locator.SUPPORT_MENU)
	public WebElement supportMenu;

	@FindBy(how = How.ID, using = Locator.CH_REPORTS_CHANGE_PWD)
	public WebElement changePasswordMenu;
	
	@FindBy(how = How.ID, using = Locator.CH_REPORTS_OLD_PWD_FIELD)
	public WebElement passwordMenu;
	
	@FindBy(how = How.ID, using = Locator.CH_REPORTS_NEW_PWD_FIELD)
	public WebElement passwordNewMenu;
	
	@FindBy(how = How.ID, using = Locator.CH_REPORTS_CONFIRM_PWD_FIELD)
	public WebElement confirmPasswordMenu;

	@FindBy(how = How.XPATH, using = Locator.CH_SUPPORT_CONTACT_US_LINK)
	public WebElement contactUsMenu;
	
	@FindBy(how = How.ID, using = Locator.PROFILE)
	public WebElement profile;

	@FindBy(how = How.ID, using = Locator.CH_SUPPORT_PRIVACY_STATEMENT)
	public WebElement privacyStatement;

	@FindBy(how = How.ID, using = Locator.BULKORDER_UPDATECARDS)
	public WebElement bulkOrder;

	@FindBy(how = How.XPATH, using = Locator.ADHOC_REPORTS_TITLE)
	public WebElement bulkOrderTitle;

	@FindBy(how = How.ID, using = Locator.CH_BULK_UPDATE)
	public WebElement bulkUpdate;

	@FindBy(how = How.ID, using = Locator.BULK_CARD_STATUS_SUB_MENU)
	public WebElement bulkCardStatus;

	@FindBy(how = How.ID, using = Locator.AU_LOCATION)
	public WebElement locationSubMenu;

	@FindBy(how = How.ID, using = Locator.SETTLEMENTS_MENU)
	public WebElement settlementsSubMenu;

	@FindBy(how = How.XPATH, using = Locator.CONTACTS_MENU)
	public WebElement contactsSubMenu;

	@FindBy(how = How.ID, using = Locator.COPY_RIGHT)
	public WebElement copyRightFooter;

	@FindBy(how = How.ID, using = Locator.CH_SUPPORT_PRIVACY_STATEMENT)
	public WebElement privacyPolicyFooter;

	@FindBy(how = How.ID, using = Locator.LEGAL_NOTICE)
	public WebElement legalnoticeFooter;

	@FindBy(how = How.ID, using = Locator.FOOTER_CONTACTUS)
	public WebElement contactUsFooter;

	@FindBy(how = How.ID, using = Locator.FOOTER_HOME_LINK)
	public WebElement homeFooter;

	@FindBy(how = How.ID, using = Locator.CH_MERCHANT_EXPORT_TRANS_SUB_MENU)
	public WebElement exportTransSubMenu;

	@FindBy(how = How.XPATH, using = Locator.CH_MERCHANT_HOME_CURRENT_BAL)
	public WebElement currentBal;

	@FindBy(how = How.XPATH, using = Locator.CH_MERCHANT_HOME_LAST_BILL_AMOUNT)
	public WebElement lastBillAmount;

	@FindBy(how = How.XPATH, using = Locator.CH_MERCHANT_HOME_LAST_BILL_DATE)
	public WebElement lastBillDate;

	@FindBy(how = How.XPATH, using = Locator.CH_MERCHANT_HOME_LAST_PAYMENT_RECV)
	public WebElement lastPaymentRecv;

	@FindBy(how = How.XPATH, using = Locator.CH_MERCHANT_HOME_LAST_PAYMENT_AMOUNT)
	public WebElement lastPaymentAmount;
	
	@FindBy(how = How.ID, using = Locator.ORDER_A_CARD)
	public WebElement orderCard;

	@FindBy(how = How.ID, using = Locator.CARD_INFORMATION_SAVECHANGES)
	public WebElement saveButton;


	@FindBy(how = How.ID, using = Locator.LOGOUT)
	public WebElement logoutLink;
	
	
	@FindBy(how = How.XPATH, using = Locator.CH_ORDER_A_CARD_PAGE_TITLE)
	public WebElement orderCardTitle;
	
	@FindBy(how = How.XPATH, using = Locator.CLIENT_WELCOME_TEXT)
	public WebElement clientWelcomeText;
	
	@FindBy(how = How.XPATH, using = Locator.CONTACT_US_PAGE)
	public WebElement contactUsPageTitle;
	
	@FindBy(how = How.XPATH, using = Locator.CONTACT_US_CC)
	public WebElement chevronCorporationLink;
	
	@FindBy(how = How.XPATH, using = Locator.CONTACT_US_TERMS_OF_USE)
	public WebElement termsOfUseLink;
	
	@FindBy(how = How.XPATH, using = Locator.CONTACT_US_STATEMENT)
	public WebElement contactUsStatement;
	
	@FindBy(how = How.XPATH, using = Locator.CONTACT_US_COPY_RIGHTS)
	public WebElement contactUsCopyRights;
	
	@FindBy(how=How.ID, using = Locator.PICK_ACCOUNT_FROM_DROPDOWN)
	public WebElement accountDropdown;
	

    @FindBy(xpath = Locator.TRANSACTION_TABLE_CONTENT)
	public WebElement transactionTableContent;

    @FindBy(id=Locator.SEARCH_BTN)
	public WebElement searchButton;
    
    @FindBy(id=Locator.ACCOUNT_SEL)
	public WebElement accountTransactionSel;
	
    @FindBy(how = How.XPATH, using = Locator.CHV_CARD_PAGE_TITLE)
	public WebElement cardpagetitle;
	
    @FindBy(how = How.ID, using = Locator.STATEMENTS_SUBMENU)
	public WebElement statementsSubMenu;
	
    @FindBy(id = Locator.FOOTER_HOME_LINK)
	public WebElement footerHomeLink;
   
    @FindBy(xpath = Locator.ACCOUNT_STATUS_HOME_PAGE)
	public WebElement accountStatusInHomePage;
   
	
	@FindBy(xpath = Locator.FOOTER_PRIV_STATEMENT_UPDATED)
	public WebElement footerPrivateStatementLink;

    @FindBy(id = Locator.FOOTER_CONTACTUS)
	public WebElement footerContactUsLink;
    
    @FindBy(xpath=Locator.CH_CONTACT)
    public WebElement contactUS_text;

    
    @FindBy(id=Locator.CHV_TRANSACTION_TABLE)
    public WebElement chevtransactiontable;
    
	public int downloadFolderCount;
	
	public String getLegalNoticeLink;

	public CHHomePage(WebDriver driver, ExtentTest test) {
		super(driver, test);
		PageFactory.initElements(driver, this);
	}

	public void loadFindAndOrderCardPage() {
		sleep(3);
		clickSubMenuAndValidate(chCardsMenu, orderCard, orderCardTitle);
	}

	public void loadFindAndValidateOrderCardPage() {
		//sleep(3);
		waitForTextToAppear("Welcome to StarCard Online",10);
		clickSubMenuAndValidate(chCardsMenu, orderCard, orderCardTitle);

	}

	public void loadFindAndUpdateCardPage() {
		sleep(3);
		clickSubMenuAndValidate(chCardsMenu, findAndUpdateCardSubMenu, pageTitleForCardList);
	}
	
	
	public void loadFindValidateAndUpdateCardPage() {
		sleep(3);
		clickSubMenuAndValidate(chCardsMenu, findAndUpdateCardSubMenu, pageTitleForCardList);
		
	}

	public void loadReissueControlPage() {
		sleep(3);
		clickSubMenuAndValidate(chCardsMenu,reissueControl ,pageTitleForCardList);
	}
	
	
	public void loadBulkStatusChangePage() {
		sleep(3);
		clickSubMenuAndValidate(chCardsMenu, bulkStatusChange, pageTitleForCardList);
	}
	
	
	public void loadFindAndLocationsPage() {
		sleep(3);
		clickSubMenuAndValidate(accountsMenu, locationSubMenu, transactionPageTitle);
	}

	public void loadFindAndContactsPage() {
		sleep(3);
		clickSubMenuAndValidate(accountsMenu, contactsSubMenu, transactionPageTitle);
	}

	public void loadFindAndBulkOrderPage() {
		sleep(3);
		clickSubMenuAndValidate(chCardsMenu, bulkOrder, bulkOrderTitle);
	}

	public void loadFindAndTransactionsPage() {
		sleep(3);
		clickSubMenuAndValidate(transactionsMenu, transactionListLink, transactionPageTitle);
	}

	public void loadFindAndSettlementsPage() {
		sleep(3);
		clickSubMenuAndValidate(transactionsMenu, settlementsSubMenu, transactionPageTitle);
	}

	public void loadFindAndBulkUpdatePage() {
		sleep(3);
		clickSubMenuAndValidate(chCardsMenu, bulkUpdate, pageTitleForCardList);
	}

	public void loadAndFindBulkStatusChange() {
		sleep(3);
		clickSubMenuAndValidate(chCardsMenu, bulkCardStatus, pageTitleForCardList);
	}

	public void loadFindAndUpdateAccountmaintenancePage() {
		sleep(3);
		clickSubMenuAndValidate(accountsMenu, accountsMaintenanceMenu, secondPageTitle);
	}

	public void loadFindAndUpdateStoredReportsPage() {
		sleep(3);
		clickSubMenuAndValidate(reportsMenu, findReportsSubMenu, secondPageTitle);
	}
	
	//invoice
	public void loadFindAndUpdateInvoiceReportsPage() {
		sleep(3);
		clickSubMenuAndValidate(reportsMenu, findInvoiceSubMenu, secondPageTitle);
	}

	public void loadFindAndFindPasswordPage() {
		sleep(3);
		clickSubMenuAndValidate(supportMenu, changePasswordMenu, secondPageTitle);
		sleep(3);
		isDisplayed(pageTitle, "Password Maintenance");
		logPass("Redirected to the Password Maintenance Page");
	}
	
	public void loadFindAndFindMyProfile() {
		sleep(3);
		clickSubMenuAndValidate(supportMenu, profile, secondPageTitle);
		sleep(3);
		isDisplayed(pageTitle, "Edit Profile");
		logPass("Redirected to the Profile Page");
	}
	
	public void verifyChangePasswordPage() {
		sleep(3);
		isDisplayed(passwordMenu, "Password");
		isDisplayed(passwordNewMenu, "New Password");
		isDisplayed(confirmPasswordMenu, "Confirm Password");
		isDisplayed(saveButton, "Save Button");
		logPass("Password,New Password,Confirm Password and Save are displayed");
	}
	
	public void loadFindAndContactUsPage() {
		sleep(3);
		clickSubMenuAndValidate(supportMenu, contactUsMenu, contactUsPageTitle);
	}
	
	public void loadFindAndProfilePage() {
		sleep(3);
		clickSubMenuAndValidate(supportMenu, profile, secondPageTitle);
	}


	public void verifyHelpLinkandClick() {
		sleep(3);
		isDisplayed(helpLink,"HelpLink");
		String text=getText(helpLink);
		if(text.equals("Help"))
		{
			actionClick(helpLink);
		}else {
			logFail("Help link is not displayed");
		}
	}

	public void loadFindAndClickOnOrderCard() {
		sleep(3);
		clickSubMenuAndValidate(chCardsMenu, orderCardSubMenu, editCardTitle);
	}

	public void findAndClickOrderCardQuickLink() {
		actionClick(orderCardQuickLink);
	}

	public void findAndClickCardStatusQuickLink() {
		actionClick(cardStatusQuickLink);
	}

	
	public void findVerifyAndClickCardStatusQuickLink() {
		actionClick(cardStatusQuickLink);
		sleep(3);
		isDisplayed(cardpagetitle, "Cards");
		logPass("Redirected to the Change card status Page");

	}

	public void findAndClickCardsQuickLink() {
		actionClick(cardsQuickLink);
	}

	public void findAndClickTransactionQuickLink() {
		actionClick(transactionsQuickLink);
	}

	public void clickExportSubMenu() {
		String pathToDownloadFolder = System.getProperty("user.home") + "/Downloads";
		File file = new File(pathToDownloadFolder);
		downloadFolderCount = file.listFiles().length;
		mouseHover(transactionsMenu);
		actionClick(exportTransSubMenu);
		sleep(3);
	}

	public void findAndClickExportTransactionQuickLink() {
		String pathToDownloadFolder = System.getProperty("user.home") + "/Downloads";
		File file = new File(pathToDownloadFolder);
		downloadFolderCount = file.listFiles().length;
		actionClick(exportTransactionQuickLink);
		sleep(5);
	}

	public void checkForFileDownload(int expectedCount) {
		String pathToDownloadFolder = System.getProperty("user.home") + "/Downloads";
		File file = new File(pathToDownloadFolder);
		int actualcount = file.listFiles().length;
		System.out.println("Actual Count: " + actualcount);
		System.out.println("Downloaded Count: " + downloadFolderCount);
		System.out.println("Expected Count: " + expectedCount);
		if (expectedCount == (actualcount - downloadFolderCount)) {
			logPass("File is downloaded");
		} else {
			logFail("File is not downloaded");
		}
	}

	public void clickOnHome() {
		// waitForPageLoad(3);
		sleep(3);
		isDisplayedThenActionClick(homeMenuLink, "HomeLink");
		sleep(5);
	}

	public void verifyExportAccountLink() {
		mouseHover(accountsMenu);
		if (waitForTextToAppear("Export Account", 5)) {
			logFail("Export Account text is displayed");
		} else {
			logPass("Export Account text is not displayed");
		}
	}

	public void clickOnChangePwdLink() {
		if (changePasswordLink.isDisplayed()) {
			actionClick(changePasswordLink);
		} else {
			logFail("Change Password link is not displayed");
		}
	}

	public void findAndClickFindtransactions() {
		mouseHover(transactionsMenu);
		//sleep(3);
		isDisplayedThenActionClick(transactionListLink,"Find Transaction");
		//checkElementPresenceAndClick(transactionListLink,"Find Transaction");
	}

	public void verifyUserNameAndLogoutLink() {
		isDisplayed(userNameDropDown, "User Name In Top Right Corner");
		isDisplayed(logoutLink, "Logout Link");
		if (!getText(userNameDropDown).split("Hello,")[1].equals("")) {
			logPass("Username at top right corner present");
		} else {
			logFail("Username at top right corner not present");
		}
	}

	public void clickOnPrivacyStatement() {
		// TODO Auto-generated method stub
		if (privacyStatement.isDisplayed()) {
			actionClick(privacyStatement);
			sleep(20);
		} else {
			logFail("Privacy Statement is missing");
		}

	}

	public void verifyCloseAccountMenu() {
		mouseHover(supportMenu);
		if (waitForTextToAppear("Close Account", 10)) {
			logPass("Close Account is visible");
		} else {
			logInfo("Close Account is not visible");
		}
	}

	public void verifyFooterLinks() {
		isDisplayed(copyRightFooter, "Copy Right");

		isDisplayed(privacyPolicyFooter, "Privacy Policy");

		isDisplayed(legalnoticeFooter, "Legal notice");

		isDisplayed(contactUsFooter, "Contact Us");

		isDisplayed(homeFooter, "Home");
	}
	

	//Verify Footer details
	 
	  public void selectAccountFromDropdownAndValidate() {
		
		isDisplayed(accountDropdown, "Account Drop down in home page");
		selectDropDownByIndex(accountDropdown,0);
		
	  }
	   public void navigateAndValidateTransctionList() {
		   
		   findAndClickFindtransactions();
		//   selectAllAccountsAndSearch();
		   scrollDownPage();
		   isDisplayedThenActionClick(footerHomeLink, "Click Home Footer Link");
		   verifyHomePageText();
		 //  clickLegalNoticeAndValidateRedirect();
		 //  clickPrivacyStatementAndValidateRedirect();
		   verifyContactUsLink();
		   driver.navigate().back();
	   }
		   
		   public void selectAllAccountsAndSearch() {

			   selectDropDownByVisibleText(accountTransactionSel, "All Accounts");
			 //  selectDropDownByIndex(accountDropdown,0);
				sleep(2);
				
				isDisplayedThenClick(searchButton, "Search button");
				
				sleep(5);
				isDisplayed(chevtransactiontable, "Check Transaction tabel is Present");
		   }
			
		   
	 public void validateTheTransactionListPage() {
		checkTextInPageAndValidate("Transaction List", 30);
		scrollDownPage();
		isDisplayedThenActionClick(footerHomeLink, "Click Home Footer Link");
		verifyHomePageText();
		}
		
		public void clickLegalNoticeAndValidateRedirect(){
		scrollDownPage();
		String getLegalNoticeLink = legalnoticeFooter.getAttribute("href").split(":")[1];
		validateClickableLinkRedirectionContains(legalnoticeFooter, getLegalNoticeLink);
		}
		
		public void clickPrivacyStatementAndValidateRedirect(){
		String getPrivateStatementLink =  privacyPolicyFooter.getAttribute("href").split(":")[1];
		validateClickableLinkRedirectionContains( privacyPolicyFooter, getPrivateStatementLink);
		}
		

	   public void verifyContactUsLink(){
	   isDisplayedThenClick(contactUsFooter, "Contact Us");
	   sleep(2);
	   isDisplayed(contactUS_text,"Contact Us");
	   
	   }
	   
	 
	
	
	public void verifyFooterPageLinks() {
		isDisplayed(chevronCorporationLink, "Chevron Corporation");
		isDisplayed(termsOfUseLink, "Terms Of Use");
		isDisplayed(contactUsStatement, "Privacy Statement");
		isDisplayed(contactUsCopyRights, " Chevron Corporation. All Rights Reserved.");
	}
	
	public void verifyHomePageText() {
		isDisplayed(clientWelcomeText, "Welcome text is displayed");
		String welcomeText = getText(clientWelcomeText);
		if (welcomeText.contains("Welcome to StarCard Online")) {
			logPass("Welcome text is displayed correctly");
		} else {
			logInfo("Welcome is not matched");
		}
	}

	public void verifyWindows() {
		// TODO Auto-generated method stub
		if (driver.getWindowHandles().size() > 1) {
			logInfo("Privacy Statement is opening in a new window");
		} else {
			logPass("Privacy Statement is not opening in a new window");
		}
	}

	/*
	 * Merchant Home Screens Methods start here
	 */
	public void verifyMerchantQuickLinks() {
		if (merchantTransQuickLink.isDisplayed()) {
			logPass("Transactions Link is visible");
		} else {
			logFail("Transactions Link is not visible");
		}
		if (merchantExportTransQuickLink.isDisplayed()) {
			logPass("Export Transactions Link is visible");
		} else {
			logFail("Export Transactions Link is not visible");
		}

	}

	public void clickOnTransactionQuickLink() {
			if (merchantTransQuickLink.isDisplayed()) {
				actionClick(merchantTransQuickLink);
			} else {
				logFail("Transaction link is missing");
			}	
	}
	
	public void clickOnLocationTransactionLink() {
		if (locationTransQuickLink.isDisplayed()) {
			actionClick(locationTransQuickLink);
		} else {
			logInfo("Transaction link is missing");
		}
	}

	public void clickOnExportTransactionLink() {
		String pathToDownloadFolder = System.getProperty("user.home") + "/Downloads";
		File file = new File(pathToDownloadFolder);
		downloadFolderCount = file.listFiles().length;
		if (merchantExportTransQuickLink.isDisplayed()) {
			actionClick(merchantExportTransQuickLink);
		} else {
			logFail("Export link is missing");
		}
	}
	
	public void clickOnSuspendedTransactionsTransactionLink() {
		String pathToDownloadFolder = System.getProperty("user.home") + "/Downloads";
		File file = new File(pathToDownloadFolder);
		downloadFolderCount = file.listFiles().length;
		if (suspendedTransaction.isDisplayed()) {
			actionClick(suspendedTransaction);
		} else {
			logFail("Export link is missing");
		}
	}

	public void clickOnUsername() {
		isDisplayedThenActionClick(userNameDropDown, "UserName");
	}

	public void verifyMerchantAccountDetails() {

		isDisplayed(currentBal, "Current Balance");

		isDisplayed(lastBillAmount, "Last Bill Amount");

		isDisplayed(lastBillDate, "Last Bill Date");

		isDisplayed(lastPaymentRecv, "Last Payment Received");

		isDisplayed(lastPaymentAmount, "Last Payment Amount");

	}
		public void loadFindAndUpdateStatementPage() {
		sleep(3);
		clickSubMenuAndValidate(reportsMenu, statementsSubMenu, secondPageTitle);
	}


	
	public void getChoosenAccountNumber() {
		
		String Split = selectedStringFrmDropDown(accountDropdown).split("\\(")[1];
		String store=Split.split("\\)")[0];
		logInfo("Stored value="+store);
		}
		
	
	public void verifyAccountNoForFileVerification() {
		String s = selectedStringFrmDropDown(accountDropdown).split("\\(")[1];
		String store=s.split("\\)")[0];
		verifyTheDownloadedFile(store);
		}
	
	public String getAccountStatus()
	{
		return getText(accountStatusInHomePage);
	}
	public String validateDateInDownloadedFile() {
		String currentDate=getCurrentDate();
		String date = currentDate.split("/")[0];
		String month = currentDate.split("/")[1];
		String year = currentDate.split("/")[2];
		String fileDate=year+month+date;
		System.out.println("Downloaded file date is"+ fileDate);
		return fileDate;
		
		
	}

}
