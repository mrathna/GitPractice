package com.framework.testcases.AJS.BP;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.CardMaintenancePage;
import com.framework.pages.AJS.MaintainCustomerPage;
import com.framework.pages.AJS.TransactionListPage;
import com.framework.pages.AJS.common.Common;
import com.framework.pages.AJS.common.IFCSHomePage;
import com.framework.pages.AJS.common.IFCSLoginPage;
import com.github.javafaker.Faker;

public class ValidateRebateProfileTestCases extends BaseTest{

	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test(groups = { "Regression" })
	public void validateAndCreateRebatePrivateProfile(@Optional("RU") String clientCountry, @Optional("SHELL") String clientName,
			@Optional("APA") String cardType) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  BPNZ51_Rebates_NZ_002_NetOff Rebates- Private Profile", "Validate and create Rebates- Private Profile");
		// creating object for the Pages
		IFCSLoginPage ifcsloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage ifcsHomePage = new IFCSHomePage(driver, test);
		CardMaintenancePage cardMaintenancePage = new CardMaintenancePage(driver, test);
		MaintainCustomerPage maintainCustomerPage = new MaintainCustomerPage(driver, test);
		Common common = new Common(driver, test);
		
		ifcsloginPage.login("IFCS_URL_BP", "IFCS_BP_USERNAME", "IFCS_BP_PASSWORD");
		ifcsHomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);
		ifcsloginPage.setClientCountryCardTypeDetails(clientName, clientCountry," ");
		ifcsHomePage.gotoCustomerMenuCustomerDetails();
		String customerNumber = common.getActiveCustomerNoUsingCardType();
		cardMaintenancePage.chooseAndSearchCustomerNo(customerNumber);
		
		maintainCustomerPage.createRebateProfile();
		ifcsHomePage.exitIFCS();	
	}
	
	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test(groups = { "Regression","BusinessFlow" })
	public void validateNetOffRebatePublicProfileWithTransaction(@Optional("RU") String clientCountry, @Optional("SHELL") String clientName,
			@Optional("APA") String cardType) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  BPNZ52_Rebates_NZ_003_NetOff Rebates_Public Profile", "Validate Net Off Rebates- Public Profile with Transaction");
		// creating object for the Pages
		IFCSLoginPage ifcsloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage ifcsHomePage = new IFCSHomePage(driver, test);
		CardMaintenancePage cardMaintenancePage = new CardMaintenancePage(driver, test);
		TransactionListPage transactionListPage = new TransactionListPage(driver, test);
		MaintainCustomerPage maintainCustomerPage = new MaintainCustomerPage(driver, test);
		Common common = new Common(driver, test);
		
		ifcsloginPage.login("IFCS_URL_BP", "IFCS_BP_USERNAME", "IFCS_BP_PASSWORD");
		ifcsHomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);
		ifcsloginPage.setClientCountryCardTypeDetails(clientName, clientCountry," ");
		ifcsHomePage.gotoCustomerMenuCustomerDetails();
		String customerNumber = common.getActiveCustomerNoUsingCardType();
		cardMaintenancePage.chooseAndSearchCustomerNo(customerNumber);
		
		//	Opt In Rebate Public Profile
		maintainCustomerPage.checkPublicRebateOptedIn();
		String cardNo = common.getActiveCardsWithBalanceAndRowIndex(1);
		String currentDate = common.getCurrentIFCSDateFromDB(clientName+clientCountry);
		String cardNo2 = common.getActiveCardsWithBalanceAndRowIndex(2);
		String locationNo=common.chooseALocationWithNonFuelProduct("Y");
		String productCode=common.chooseANonFuelProductExtCodeInTheLocation(locationNo,"Y","externalCode");
		if (cardNo.equals(" ") && cardNo2.equals(" ") && locationNo.equals(" ") && productCode.equals(" ")) {
			common.logForNoDataFound(this.getClass().getSimpleName(),
					"Need to Create A Cards with Account and rerun");
		} else {
		// Get the IFCS current date
		String ifcsCurrentDate = common.enterADateValueInStatusBeginDateField("Current", currentDate);
		
		Faker fakerN = new Faker();
		String f_referenceNo = fakerN.number().digits(3);
		ifcsHomePage.gotoTransactionAndClickManageTransaction();
		
		//transactionListPage.validateToPostManualTransactionEntry(ifcsCurrentDate,f_referenceNo,clientCountry,cardNo,cardNo2,locationNo,productCode,true);
		transactionListPage.enterTransactionBatchDetails(true,"160","1",clientName);
		transactionListPage.enterManualTransactionDetails(ifcsCurrentDate,f_referenceNo,cardNo,cardNo2,locationNo,"160","");
		transactionListPage.enterTransactionLineItems(productCode,"160","100","160");
		transactionListPage.validatePostManualTransaction("Validation successful");
		transactionListPage.validatePostSuspendedtransaction(f_referenceNo);
		ifcsHomePage.gotoCustomerMenuCustomerDetails();	
	    transactionListPage.validateCustomerTransaction(cardNo,ifcsCurrentDate,f_referenceNo);
	    ifcsHomePage.exitIFCS();	
	}
	}
@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "Regression" })
	public void validatePrivateRebateForNonFuelProduct(@Optional("AU") String clientCountry, @Optional("BP") String clientName) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  BPNZ44_Rebates_NZ_001_Private Rebate for non-fuel product", "WBPT-18869");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCShomePage = new IFCSHomePage(driver, test);
		TransactionListPage transactionListpage = new TransactionListPage(driver, test);
		Common common = new Common(driver, test);
		IFCSloginPage.login("IFCS_URL_BP", "IFCS_BP_USERNAME", "IFCS_BP_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		IFCShomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);
		IFCShomePage.gotoTransactionAndClickManageTransaction();
		String locationNo=common.chooseALocationWithNonFuelProduct("Y");
		String productCode=common.chooseANonFuelProductExtCodeInTheLocation(locationNo,"Y","externalCode");
		if (locationNo.equals(" ") && productCode.equals(" ")) {
			common.logForNoDataFound(this.getClass().getSimpleName(),
					"Need to Create A Cards with Account and rerun");
		} else {
		transactionListpage.postATransactionWithRebateProfileForNonFuelProduct(productCode);
		}
		IFCShomePage.exitIFCS();

	}
	
}
