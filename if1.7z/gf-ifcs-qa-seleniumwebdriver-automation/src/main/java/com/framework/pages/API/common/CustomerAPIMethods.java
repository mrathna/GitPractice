package com.framework.pages.API.common;

import java.util.HashMap;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONObject;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;
import com.framework.pages.AJS.common.Common;
import com.framework.util.PropUtils;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class CustomerAPIMethods extends CommonAPI {

	public CustomerAPIMethods(WebDriver driver, ExtentTest test) {
		super(driver, test);
	}

	public String getCouponCodeFromDB(String clientFullName) {
		String couponCodeValue = "SELECT coupon_code from applications where coupon_code is NOT NULL \r\n"
				+ " and client_mid = (select client_mid from m_clients where name ='"
				+ PropUtils.getPropValue(configProp, clientFullName) + "')"
				+ " ORDER BY DBMS_RANDOM.VALUE FETCH NEXT 1 ROW ONLY";

		return connectDBAndGetValue(couponCodeValue, PropUtils.getPropValue(configProp, "sqlODSServerName"));
	}

	public String getApplicationNumber(String clientFullName) {
		String applicationNum = "SELECT application_no from applications \r\n"
				+ " where client_mid = (select client_mid from m_clients where name ='"
				+ PropUtils.getPropValue(configProp, clientFullName) + "')"
				+ " ORDER BY DBMS_RANDOM.VALUE FETCH NEXT 1 ROW ONLY";

		return connectDBAndGetValue(applicationNum, PropUtils.getPropValue(configProp, "sqlODSServerName"));
	}

	public String getFrequencies(String clientFullName) {
		String frequency = "SELECT description from frequencies \r\n"
				+ " where frequency_oid IN (select BILLING_FREQUENCY_OID from applications \r\n"
				+ " where client_mid IN (select client_mid from m_clients where name ='"
				+ PropUtils.getPropValue(configProp, clientFullName) + "'))" + " and rownum<=1";

		return connectDBAndGetValue(frequency, PropUtils.getPropValue(configProp, "sqlODSServerName"));
	}

	public String getBuyersClass(String clientFullName) {
		String classBuyer = "SELECT description from descriptions \r\n"
				+ " where description_oid IN (select BUYER_CLASS_DID from applications \r\n"
				+ " where client_mid IN (select client_mid from m_clients where name ='"
				+ PropUtils.getPropValue(configProp, clientFullName) + "'))"
				+ " ORDER BY DBMS_RANDOM.VALUE FETCH NEXT 1 ROW ONLY";

		return connectDBAndGetValue(classBuyer, PropUtils.getPropValue(configProp, "sqlODSServerName"));
	}

	public String getPricingProfile(String clientFullName) {
		String priceProfile = "SELECT description from pricing_profiles \r\n"
				+ " where pricing_profile_oid IN (select pricing_profile_oid from applications \r\n"
				+ " where client_mid IN (select client_mid from m_clients where name ='"
				+ PropUtils.getPropValue(configProp, clientFullName) + "'))"
				+ " ORDER BY DBMS_RANDOM.VALUE FETCH NEXT 1 ROW ONLY";

		return connectDBAndGetValue(priceProfile, PropUtils.getPropValue(configProp, "sqlODSServerName"));
	}

	public String getCustomerNum(String name) {
		String customerNumber = "Select customer_no from m_customers  where name = '" + name + "'";
		return connectDBAndGetValue(customerNumber, PropUtils.getPropValue(configProp, "sqlODSServerName"));
	}

	public void customerCreation(String clientName, String clientCountry) {
		JSONObject requestParams = new JSONObject();
		JSONObject streetAddress = new JSONObject();
		JSONObject bankDetails = new JSONObject();

		JSONArray contacts = new JSONArray();
		Response response;
		Common common = new Common(driver, test);
		/*
		 * System.out.println("CLIENT NAME:"+clientName);
		 * System.out.println("CLIENT_COUNTRY:"+clientCountry);
		 */
		String name = fakerAPI().name().firstName();

		RestAssured.baseURI = PropUtils.getPropValue(configProp, "baseURL");
		requestParams.put("name", name);
		requestParams.put("couponCode", getCouponCodeFromDB(clientName + "_" + clientCountry));
		// APIFix//requestParams.put("couponCode", "BE_LLRPPD_3");
		requestParams.put("customerType", getJsonArrayDataForCustomerCreation("/lookup/customer-types"));
		requestParams.put("applicationNumber", getApplicationNumber(clientName + "_" + clientCountry));
		requestParams.put("applicationType", getJsonArrayDataForCustomerCreation("/lookup/application-types"));

		requestParams.put("contacts", contacts);
		// contacts.put("");

		requestParams.put("streetAddress", streetAddress);
		streetAddress.put("addressLine", fakerAPI().address().fullAddress());
		streetAddress.put("country", clientCountry);

		requestParams.put("contactName", fakerAPI().name().fullName());
		requestParams.put("authenticationAnswer", "Test");
		requestParams.put("phoneBusiness", fakerAPI().phoneNumber().phoneNumber());
		requestParams.put("businessType", getJsonArrayDataForCustomerCreation("/lookup/business-types"));
		requestParams.put("marketingTerritory", getJsonArrayDataForCustomerCreation("/lookup/marketing-territories"));
		requestParams.put("adminTerritory", getJsonArrayDataForCustomerCreation("/lookup/admin-territories"));
		requestParams.put("billingPlan", getJsonArrayDataForCustomerCreation("/lookup/billing-plans"));
		requestParams.put("billingFrequency", getFrequencies(clientName + "_" + clientCountry));
		requestParams.put("cycleFrequency", getFrequencies(clientName + "_" + clientCountry));
		requestParams.put("creditPlan", getJsonArrayDataForCustomerCreation("/lookup/credit-plans"));
		requestParams.put("cardProgram", getJsonArrayDataForCustomerCreation("/lookup/card-programs"));
		requestParams.put("cardOffer", getJsonArrayDataFromJsonObj("/lookup/card-offers"));

		requestParams.put("bankAccount", bankDetails);
		if (!clientName.equals("WFE")) {
			bankDetails.put("accountNo", "02221228946547");
			bankDetails.put("accountName", "XXXXXBank Ltd");
			bankDetails.put("bankNo", "256074974");
			bankDetails.put("branchNo", "0");
		} else {
			bankDetails.put("accountNo", "196666");
			bankDetails.put("accountName", "XXXXXXXXnds Bank Account");
			bankDetails.put("bankNo", "001");
			bankDetails.put("branchNo", "001");
		}
		requestParams.put("buyerClass", getBuyersClass(clientName + "_" + clientCountry));
		requestParams.put("industry", getJSONArrayKeyFromJSONObject("/lookup/industries"));
		requestParams.put("pricingProfile", getPricingProfile(clientName + "_" + clientCountry));
		// requestParams.put("pricingProfile", "Customer Pump Pricing");
		response = apiUtils.postRequestAsBearerAuthWithBodyData("/customer", requestParams,
				PropUtils.getPropValue(configProp, "AuthorizationToken"));
		System.out.println("Response Code: " + response.getStatusCode());
		System.out.println("Response Body: " + response.prettyPrint());

		if (response.getStatusCode() == 201) {
			logPass("Customer was created successfully");
		} else {
			logFail("Customer Creation Failed");
		}

		String customerNumber = getCustomerNum(name);
		Map<String, String> custNo = new HashMap<String, String>();
		custNo.put("Customer_Number_" + clientName + "_" + clientCountry, customerNumber);
		common.updatePropFile("Customer_Number_" + clientName + "_" + clientCountry,customerNumber,"SalesForceValidation.properties");
		System.out
				.println("Created Customer Stored in Properties : " + customerNumber + "--> CustomerNumber.properties");

		PropUtils.creatingTempPropFile("CustomerNumber.properties", custNo);
		// System.out.println("------ ADD CREATED CUSTOMER TO OLS LOGIN -----");
		/*
		 * Common common = new Common(driver, test);
		 * common.addCustomerToOLSLogin(clientName, clientCountry,
		 * PropUtils.getPropValue(configProp, "UserNameAPI" + "_" + clientName + "_" +
		 * clientCountry), customerNumber);
		 */

	}

	public void customerUpdate(String key, String clientName, String clientCountry) {
		JSONObject requestParams = new JSONObject();
		JSONObject StreetAddress = new JSONObject();

		String valueFromDB = null, valueChanged = null;
		String queryToGetCustNo = "select customer_no from m_customers where client_mid=(select client_mid from m_clients "
				+ "where name='" + PropUtils.getPropValue(configProp, clientName + "_" + clientCountry)
				+ "') and rownum=1";
		String custNo = connectDBAndGetValue(queryToGetCustNo, PropUtils.getPropValue(configProp, "sqlODSServerName"));

		if (key.equalsIgnoreCase("streetAddress")) {
			valueChanged = fakerAPI().address().streetAddress();
			requestParams.put("streetAddress", StreetAddress);
			StreetAddress.put("addressLine", valueChanged);
			StreetAddress.put("suburb", getJsonArrayDataForCustomerCreation("/lookup/suburbs"));
		} else if (key.equalsIgnoreCase("Name")) {
			valueChanged = fakerAPI().name().firstName();
			requestParams.put("name", valueChanged);
		}
		requestParams.put("customerNo", custNo);

		System.out.println(requestParams);

		response = apiUtils.putRequestAsBearerAuthWithBodyData(PropUtils.getPropValue(configProp, "AuthorizationToken"),
				requestParams, "/customer/" + custNo);

		System.out.println("Response Code: " + response.getStatusCode());
		System.out.println("Response Body: " + response.prettyPrint());

		if (response.getStatusCode() == 200) {

			logPass("Customer was update successfully through API");
		} else {

			logFail("Customer updation Failed through API");
		}

		if (key.equalsIgnoreCase("streetAddress")) {
			String queryToGetAddr = "select address_line from addresses where address_oid=(select street_address_oid from m_customers where customer_no='"
					+ custNo + "' " + "and client_mid=(select client_mid from m_clients where name='"
					+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountry) + "')";
			valueFromDB = connectDBAndGetValue(queryToGetAddr, PropUtils.getPropValue(configProp, "sqlODSServerName"));
		} else if (key.equalsIgnoreCase("Name")) {
			String queryToGetName = "select name from m_customers where client_mid=(select client_mid from m_clients "
					+ "where name='" + PropUtils.getPropValue(configProp, clientName + "_" + clientCountry)
					+ "') and rownum=1";
			valueFromDB = connectDBAndGetValue(queryToGetName, PropUtils.getPropValue(configProp, "sqlODSServerName"));
		}

		if (valueChanged.equalsIgnoreCase(valueFromDB)) {
			logPass("Customer was update successfully in DB with " + valueChanged);
		} else {
			logFail("Customer updation Failed in DB with " + valueChanged);
		}
	}

}
