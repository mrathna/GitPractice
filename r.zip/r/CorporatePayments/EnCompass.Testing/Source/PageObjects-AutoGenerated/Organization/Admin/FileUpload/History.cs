using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using Common;
using Common.PageObjects;
using Common.ScenarioConfigurations;
using Common.Utility;

namespace EnCompass.Testing.Source.PageObjects.Organization.Admin.FileUpload 
{
	/// <summary>
	/// Auto-generated Page Model Class
	/// Navigation Paths: 
		/// [Organization Home]->Administration->File Uploads
		/// [Organization Home]->Administration->File Uploads->History
		/// </summary>
	[PageModel(@"/admin/fileUpload/History.aspx")]
	public partial class History : EnCompassOrgPageModel 
	{
		public override string RelativeUrl => @"/admin/fileUpload/History.aspx";
		public override string PageIdentifierXPath_Generated => @"//li[contains(@class, 'breadcrumb-item active')][text() = 'History']";

		#region Navigation
				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='History']")]
		private IWebElement _administration_FileUploads_History { get; set; }
		public void NavigateTo_Administration_FileUploads_History()
		{
			NavigateToMenuItem(_administration_FileUploads_History);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Accounts Payable']")]
		private IWebElement _administration_FileUploads_AccountsPayable { get; set; }
		public void NavigateTo_Administration_FileUploads_AccountsPayable()
		{
			NavigateToMenuItem(_administration_FileUploads_AccountsPayable);
		}

                [FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Purchase Log File']")]
        private IWebElement _administration_FileUploads_UploadPurchaseLogFile { get; set; }
        public void NavigateTo_Administration_FileUploads_UploadPurchaseLogFile()
        {
            NavigateToMenuItem(_administration_FileUploads_UploadPurchaseLogFile);
        }

        [FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='New Cards']")]
		private IWebElement _administration_FileUploads_NewCards { get; set; }
		public void NavigateTo_Administration_FileUploads_NewCards()
		{
			NavigateToMenuItem(_administration_FileUploads_NewCards);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Card Update']")]
		private IWebElement _administration_FileUploads_CardUpdate { get; set; }
		public void NavigateTo_Administration_FileUploads_CardUpdate()
		{
			NavigateToMenuItem(_administration_FileUploads_CardUpdate);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Notifications']")]
		private IWebElement _administration_FileUploads_Notifications { get; set; }
		public void NavigateTo_Administration_FileUploads_Notifications()
		{
			NavigateToMenuItem(_administration_FileUploads_Notifications);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Users']")]
		private IWebElement _administration_FileUploads_Users { get; set; }
		public void NavigateTo_Administration_FileUploads_Users()
		{
			NavigateToMenuItem(_administration_FileUploads_Users);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='User Update']")]
		private IWebElement _administration_FileUploads_UserUpdate { get; set; }
		public void NavigateTo_Administration_FileUploads_UserUpdate()
		{
			NavigateToMenuItem(_administration_FileUploads_UserUpdate);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Financial Codes']")]
		private IWebElement _administration_FileUploads_FinancialCodes { get; set; }
		public void NavigateTo_Administration_FileUploads_FinancialCodes()
		{
			NavigateToMenuItem(_administration_FileUploads_FinancialCodes);			
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Workflow Hierarchy']")]
		private IWebElement _administration_FileUploads_WorkflowHierarchy { get; set; }
		public void NavigateTo_Administration_FileUploads_WorkflowHierarchy()
		{
			NavigateToMenuItem(_administration_FileUploads_WorkflowHierarchy);
		}

		
		private void NavigateToMenuItem(IWebElement element)
		{
			Driver.Url = element.GetAttribute("href");
		}
		#endregion

		public History(GlobalSettings settings) : base(settings) { }
	}  
}
