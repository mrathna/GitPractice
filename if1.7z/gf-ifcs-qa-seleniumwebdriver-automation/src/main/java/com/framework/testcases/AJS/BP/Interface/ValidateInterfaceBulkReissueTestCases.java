package com.framework.testcases.AJS.BP.Interface;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.CardMaintenancePage;
import com.framework.pages.AJS.common.Common;
import com.framework.pages.AJS.common.IFCSCommonPage;
import com.framework.pages.AJS.common.IFCSHomePage;
import com.framework.pages.AJS.common.IFCSLoginPage;
import com.framework.pages.AJS.common.InterfacePage;

public class ValidateInterfaceBulkReissueTestCases extends BaseTest {

	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "Regression" ,"BusinessFlow"})
	public void createAndValidateBulkReissueRequest(@Optional("AU") String clientCountry,
			@Optional("BP") String clientName) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  BPNZ47_Cust_NZ_014_Bulk Reissue Manual", "BPNZ47_Cust_NZ_014_Bulk Reissue Manual");
		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		CardMaintenancePage cardMaintenancePage = new CardMaintenancePage(driver, test);
		Common common = new Common(driver, test);
		// Calling Functions
		IFCSloginPage.login("IFCS_URL_BP", "IFCS_BP_USERNAME", "IFCS_BP_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, " ");
		
		// choose Client from Application Page
				IFCSHomePage.gotoApplicationAndClickApplicationMenu();
				IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);
				
		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		// Getting Customer number havign card expiry in 90 days
		String customerNo = common.getCustomerNoHavingNoBulkReissueAndCardsExpiringInFewDays("Manual");
		// Getting IFCS Date
		String currentIFCSDate = common.getCurrentIFCSDateFromDB(clientName + clientCountry);
		String currentProcessingDate = common.enterADateValueInStatusBeginDateField("Current", currentIFCSDate);
		String futureIFCSDate = common.enterADateValueInStatusBeginDateField("Future", currentIFCSDate);
		String wayFutureIFCSDate = common.enterADateValueInStatusBeginDateField("WayFuture", currentIFCSDate);
		
		System.out.println("current IFCS date:::::"+currentIFCSDate);
		System.out.println("Current proccessing date:::::"+currentProcessingDate);
		System.out.println("Future IFCS date:::::"+futureIFCSDate);
		System.out.println("Way Future IFCS date:::::"+wayFutureIFCSDate);
		
		if (customerNo.equals("")) {
			// need to call method to logfail
			common.logForNoDataFound(this.getClass().getSimpleName(), "Need to Create A Cards For Customers and rerun");
		} else {
			common.chooseCustomerNoAndSearch(customerNo);
			// Calling Functions
			cardMaintenancePage.chooseCardAndCreateBulkReissueRequest(currentProcessingDate, futureIFCSDate,
					wayFutureIFCSDate);
			cardMaintenancePage.bulkReissueRequestWithValidDate(wayFutureIFCSDate);
		}
		String expiringDateBeforeDayEnd = common.getCardExpiryDateForReissueCard(customerNo);
		// Execute Control-M - Day End
		
		// Validate in IFCS - Reissue Request
		cardMaintenancePage.validateBulkReissueStatus(customerNo,"Reissue Complete");
		
		String expiringDateAfterDayEnd = common.getCardExpiryDateForReissueCard(customerNo);
		// Validate in IFCS - Reissue Cards Expiry Date
		cardMaintenancePage.validateBulkReissuedCardsExpiryDate(expiringDateBeforeDayEnd,expiringDateAfterDayEnd,48);

		IFCSHomePage.exitIFCS();

	}
	
	// Need cofirmation of - Expiry Date for automatic reissue
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "Regression","BusinessFlow" })
	public void createAndValidateAutomaticBulkReissueRequest(@Optional("AU") String clientCountry,
			@Optional("BP") String clientName) {
		//In Progress
		test = extent.createTest(clientName+ ":" +clientCountry+"  BPNZ48_Cust_NZ_015_Bulk Reissue Automatic", "BPNZ48_Cust_NZ_015_Bulk Reissue Automatic");
		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		CardMaintenancePage cardMaintenancePage = new CardMaintenancePage(driver, test);
		Common common = new Common(driver, test);
		// Calling Functions
		IFCSloginPage.login("IFCS_URL_BP", "IFCS_BP_USERNAME", "IFCS_BP_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, " ");
		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		
		IFCSCommonPage ifcsCommonPage = new IFCSCommonPage(driver, test);
		InterfacePage interfacePage = new InterfacePage(driver,test);
		// Getting Customer number having card expiry in 90 days
		String customerNo = common.getCustomerNoHavingNoBulkReissueAndCardsExpiringInFewDays("Automatic");
		if (customerNo.equals("")) {
			// need to call method to logfail
			common.logForNoDataFound(this.getClass().getSimpleName(), "Need to Create A Cards For Customers and rerun");
		} else {
			//Run Automatic Bulk Reissue Job
			
			String folderName = ifcsCommonPage.getControlMFolder(clientName, clientCountry, "jobS_AutoBulkReissue");
			String jobsInOrder =  ifcsCommonPage.getJobsOfFolderInOrder("jobS_AutoBulkReissue");
			interfacePage.establishAndExecuteControlMJobs("ControlM_AWS_UAT","ContorlM_AWS_userName","ContorlM_AWS_password",folderName,jobsInOrder);
			
			// Validate Bulk Reissue Request
			cardMaintenancePage.validateBulkReissueStatus(customerNo,"Awaiting Confirmation");
			
			String expiringDateBeforeDayEnd = common.getCardExpiryDateForReissueCard(customerNo);
			
			// Execute Control-M Bulk reissue job - Day End
			
			// Validate in IFCS - Reissue Request
			cardMaintenancePage.validateBulkReissueStatus(customerNo,"Reissue Complete");
			
			String expiringDateAfterDayEnd = common.getCardExpiryDateForReissueCard(customerNo);
			// Validate in IFCS - Reissue Cards Expiry Date
			cardMaintenancePage.validateBulkReissuedCardsExpiryDate(expiringDateBeforeDayEnd,expiringDateAfterDayEnd,48);
		}
		
		IFCSHomePage.exitIFCS();

	}
}
