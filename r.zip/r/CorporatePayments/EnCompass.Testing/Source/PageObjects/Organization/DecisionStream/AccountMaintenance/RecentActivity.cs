﻿using Common;
using Common.Utility;
using EnCompass.Testing.Source.PageObjects.Controls;
using NFluent;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EnCompass.Testing.Source.PageObjects.Organization.DecisionStream.AccountMaintenance
{
	[PageModel(@"/decisionStream/accountMaintenance/RecentActivity.aspx")]
	public class RecentActivity : EnCompassOrgPageModel

	{
		public override string RelativeUrl => @"/decisionStream/accountMaintenance/RecentActivity.aspx";
		public override string PageIdentifierXPath_Override => @"//li[@class='breadcrumb-item active'][text() = 'Recent Authorizations']";

        #region XPath page Elements

        private const string _frameCreateInstantApprovalBtn = "//input[contains(@id, 'btnInstantApproval')][@type='submit'][@value='Instant Approval'][not(contains(@id, 'Confirm'))]";
        private const string _closeButtonXPath = @"//input[contains(@value,'Close')]";
        private const string _editInstantApprovalBtnXPath = @"//input[contains(@id, 'EditInstantApproval')]";
        private const string _deleteInstantApprovalBtnXPath = @"//input[contains(@id, 'DeleteInstantApproval')]";
        private const string _instantApprovalAmountXPath = @"//input[contains(@id, 'InstantApprovalAmount')]";
        private const string _instantApprovalExpirationXPath = @"//input[contains(@id, 'approvalHours')]";
        private const string _numOfTxnsAllowedXPath = @"//input[contains(@id, 'InstantApprovalNumber')]";
        private const string _toggleAllOverrideAuthCBXPath = @"//input[contains(@id, 'iaReasons_toggleAll')]";
        private const string _toggleAllOverrideAuthLabelXPath = @"//label[contains(@for, 'iaReasons')][contains(text(), 'Toggle all')]";
        private const string _cardStatusCBXPath = @"//input[contains(@id, 'iaReasons')][@value='AccountStatus']";
        private const string _cardStatusLabelXPath = @"//label[contains(@for, 'iaReasons')][contains(text(), 'Card status')]";
        private const string _cv2CBXPath = @"//input[contains(@id, 'iaReasons')][@value='CV2']";
        private const string _cv2LabelXPath = @"//label[contains(@for, 'iaReasons')][contains(text(), 'CV2')]";
        private const string _cvvCBXPath = @"//input[contains(@id, 'iaReasons')][@value='CVV']";
        private const string _cvvLabelXPath = @"//label[contains(@for, 'iaReasons')][contains(text(), 'CVV')]";
        private const string _cardHolderLimitCBXPath = @"//input[contains(@id, 'iaReasons')][@value='CardholderLimit']";
        private const string _cardHolderLimitLabelXPath = @"//label[contains(@for, 'iaReasons')][contains(text(), 'Cardholder limit')]";
        private const string _dailyTransactionLimitCBXPath = @"//input[contains(@id, 'iaReasons')][@value='DailyTransactionLimit']";
        private const string _dailyTransactionLimitLabelXPath = @"//label[contains(@for, 'iaReasons')][contains(text(), 'Daily transaction limit')]";
        private const string _expirationDateCBXPath = @"//input[contains(@id, 'iaReasons')][@value='ExpirationDate']";
        private const string _expirationDateLabelXPath = @"//label[contains(@for, 'iaReasons')][contains(text(), 'Expiration date')]";
        private const string _fleetIDCBXPath = @"//input[contains(@id, 'iaReasons')][@value='FleetId']";
        private const string _fleetIDLabelXPath = @"//label[contains(@for, 'iaReasons')][contains(text(), 'Fleet ID')]";
        private const string _fraudCriteriaCBXPath = @"//input[contains(@id, 'iaReasons')][@value='FraudCriteria']";
        private const string _fraudCriteriaLabelXPath = @"//label[contains(@for, 'iaReasons')][contains(text(), 'Fraud criteria')]";
        private const string _merchantCategoryCodeCBXPath = @"//input[contains(@id, 'iaReasons')][@value='MCC']";
        private const string _merchantCategoryCodeLabelXPath = @"//label[contains(@for, 'iaReasons')][contains(text(), 'Merchant Category Code')]";
        private const string _pinCBXPath = @"//input[contains(@id, 'iaReasons')][@value='PIN']";
        private const string _pinLabelXPath = @"//label[contains(@for, 'iaReasons')][contains(text(), 'PIN')]";
        private const string _singleTransactionLimitCBXPath = @"//input[contains(@id, 'iaReasons')][@value='SingleTransactionLimit']";
        private const string _singleTransactionLimitLabelXPath = @"//label[contains(@for, 'iaReasons')][contains(text(), 'Single transaction limit')]";
        private const string _toggleAllOverrideManuallyCBXPath = @"//input[contains(@id, 'iaSuperOverride_toggleAll')]";
        private const string _toggleAllOverrideManuallyLabelXPath = @"//label[contains(@for, 'iaSuperOverride')][contains(text(), 'Toggle all')]";
        private const string _centralBillLimitCBXPath = @"//input[contains(@id, 'iaSuperOverride')][@value='CentralBillLimit']";
        private const string _centralBillLimitLabelXPath = @"//label[contains(@for, 'iaSuperOverride')][contains(text(), 'Central bill limit')]";
        private const string _corporateLimitCBXPath = @"//input[contains(@id, 'iaSuperOverride')][@value='CorporateLimit']";
        private const string _corporateLimitLabelXPath = @"//label[contains(@for, 'iaSuperOverride')][contains(text(), 'Corporate limit')]";
        private const string _authOverrideDelinquencyCBXPath = @"//input[contains(@id, 'iaSuperOverride')][@value='Delinquency']";
        private const string _authOverrideDelinquencyLabelXPath = @"//label[contains(@for, 'iaSuperOverride')][contains(text(), 'Delinquency')]";
        private const string _hierarchyLimitCBXPath = @"//input[contains(@id, 'iaSuperOverride')][@value='HierarhcyLimit']";
        private const string _hierarchyLimitLabelXPath = @"//label[contains(@for, 'iaSuperOverride')][contains(text(), 'Hierarchy limit')]";
        private const string _approveInstantApprovalBtnXPath = @"//input[contains(@id, 'btnInstantApprovalConfirm')]";
        private const string _confirmInstantApprovalXPath = @"//button[@type='button'][contains(@class,'btn-primary')][text()='Confirm']";
        private const string _cancelInstantApprovalXPath = @"//button[@type='button'][contains(@class,'btn-secondary')][text()='Cancel']";
        private const string _authGridXPath = @"//table[contains(@id,'AuthGrid')]//td";
        private const string _cmdEditInstantApprovalXPath = @"//input[contains(@id, 'cmdEditInstantApproval')]";
        private const string _frameGenericXPath = @"//div[contains(@id,'showInstantApprovalModal')]";
        private const string _detailsXPath = @"//caption[contains(text(),'Details')]";
        private const string _recentAuthorizationsXPath = @"//caption[contains(text(),'Recent Authorizations')]";
        private const string _iaSuperOverride_1XPath = "//label[contains(@for, 'iaSuperOverride_1')][text()='Corporate limit']";
        private const string _instantApprovalFooterXPath = @"//div[contains(@id, 'InstantApprovalFooter')]/button[contains(text(),'Cancel')]";
        private const string _cmdDeleteInstantApprovalXPath = @"//input[contains(@id, 'cmdDeleteInstantApproval')]";
        private const string _btnInstantApprovalDeleteXPath = @"//input[contains(@id, 'btnInstantApprovalDelete')]";
        private const string _modalSuccessMessageXPath = @"//div[contains(@id, 'SuccessMessage')]/p";
        private const string _modalValidationSummary = @"//div[contains(@id, '_ValidationSummary')]//li";
        #endregion

        #region Page Elements
        private IWebElement _closeButton
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_closeButtonXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_closeButton element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _editInstantApprovalBtn
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_editInstantApprovalBtnXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_editInstantApprovalBtn element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _deleteInstantApprovalBtn
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_deleteInstantApprovalBtnXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_deleteInstantApprovalBtn element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        #region InstantApprovalDialogElements

        private IWebElement _instantApprovalAmount
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_instantApprovalAmountXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_instantApprovalAmount element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _instantApprovalExpiration
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_instantApprovalExpirationXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_instantApprovalExpiration element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _numOfTxnsAllowed
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_numOfTxnsAllowedXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_numOfTxnsAllowed element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _toggleAllOverrideAuthCB
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_toggleAllOverrideAuthCBXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_toggleAllOverrideAuthCB element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _toggleAllOverrideAuthLabel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_toggleAllOverrideAuthLabelXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_toggleAllOverrideAuthLabel element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _cardStatusCB
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_cardStatusCBXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_cardStatusCB element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _cardStatusLabel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_cardStatusLabelXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_cardStatusLabel element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _cv2CB
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_cv2CBXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_cv2CB element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _cv2Label
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_cv2LabelXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_cv2Label element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _cvvCB
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_cvvCBXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_cvvCB element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _cvvLabel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_cvvLabelXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_cvvLabel element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _cardHolderLimitCB
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_cardHolderLimitCBXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_cardHolderLimitCB element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _cardHolderLimitLabel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_cardHolderLimitLabelXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_cardHolderLimitLabel element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _dailyTransactionLimitCB
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_dailyTransactionLimitCBXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_dailyTransactionLimitCB element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _dailyTransactionLimitLabel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_dailyTransactionLimitLabelXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_dailyTransactionLimitLabel element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _expirationDateCB
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_expirationDateCBXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_expirationDateCB element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _expirationDateLabel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_expirationDateLabelXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_expirationDateLabel element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _fleetIDCB
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_fleetIDCBXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_fleetIDCB element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _fleetIDLabel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_fleetIDLabelXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_fleetIDLabel element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _fraudCriteriaCB
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_fraudCriteriaCBXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_fraudCriteriaCB element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _fraudCriteriaLabel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_fraudCriteriaLabelXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_fraudCriteriaLabel element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _merchantCategoryCodeCB
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_merchantCategoryCodeCBXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_merchantCategoryCodeCB element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _merchantCategoryCodeLabel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_merchantCategoryCodeLabelXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_merchantCategoryCodeLabel element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _pinCB
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_pinCBXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_pinCB element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _pinLabel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_pinLabelXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_pinLabel element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _singleTransactionLimitCB
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_singleTransactionLimitCBXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_singleTransactionLimitCB element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _singleTransactionLimitLabel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_singleTransactionLimitLabelXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_singleTransactionLimitLabel element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _toggleAllOverrideManuallyCB
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_toggleAllOverrideManuallyCBXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_toggleAllOverrideManuallyCB element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _toggleAllOverrideManuallyLabel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_toggleAllOverrideManuallyLabelXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_toggleAllOverrideManuallyLabel element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _centralBillLimitCB
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_centralBillLimitCBXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_save element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _centralBillLimitLabel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_centralBillLimitLabelXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_centralBillLimitLabel element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _corporateLimitCB
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_corporateLimitCBXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_corporateLimitCB element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _corporateLimitLabel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_corporateLimitLabelXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_corporateLimitLabel element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _authOverrideDelinquencyCB
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_authOverrideDelinquencyCBXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_authOverrideDelinquencyCB element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _authOverrideDelinquencyLabel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_authOverrideDelinquencyLabelXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_authOverrideDelinquencyLabel element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _hierarchyLimitCB
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_hierarchyLimitCBXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_hierarchyLimitCB element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _hierarchyLimitLabel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_hierarchyLimitLabelXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_hierarchyLimitLabel element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        #endregion

        private IWebElement _approveInstantApprovalBtn
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_approveInstantApprovalBtnXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_approveInstantApprovalBtn element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _confirmInstantApproval
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_confirmInstantApprovalXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_confirmInstantApproval element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _cancelInstantApproval
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_cancelInstantApprovalXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_cancelInstantApproval element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        #endregion

        private GridControl _authGrid;
		public GridControl AuthGrid
		{
			get
			{
				_authGrid = new GridControl("AuthGrid", Driver);
				_authGrid.WaitForGrid();
				return _authGrid;
			}
		}

		public int TotalAuthorizations()
		{
			if (Driver.FindElement(By.XPath(_authGridXPath)).Text.Contains("No Recent Authorizations found."))
				return 0;
			else
			{
				return AuthGrid.GetRows().Count();
			}
		}

		/// <summary>
		/// This method clicks the 'Confirm' button in the Warning popup while creating an Instant Approval.
		/// </summary>
		public void ConfirmInstantApprovalCreationInWarningDialog()
		{
			_confirmInstantApproval.JSClickWithFocus(Driver);
		}

		/// <summary>
		/// This method clicks the 'Cancel' button in the Warning popup while creating an Instant Approval.
		/// </summary>
		public void CancelInstantApprovalCreationInWarningDialog()
		{
			_cancelInstantApproval.JSClickWithFocus(Driver);
		}

		public int TotalTransactions()
		{


			if (Driver.FindElement(By.XPath(_authGridXPath)).Text.Contains("No Transactions."))
				return 0;
			else
			{
				GridControl authGrid = new GridControl("AuthGrid", Driver);
				return authGrid.GetRows().Count();
			}

		}

		public void Editbutton()
		{
			Driver.FindElement(By.XPath(_cmdEditInstantApprovalXPath)).JSClickWithFocus(Driver);
		}

		public void EditInstantApproval(string amount, string message)
		{
			Driver.WaitForVisible(By.XPath(_frameGenericXPath));
			using (FrameHelper modal = new FrameHelper(Driver, By.XPath(_frameGenericXPath)))
			{

				modal.FindElement(By.XPath(_instantApprovalAmountXPath)).Clear();
				modal.FindElement(By.XPath(_instantApprovalAmountXPath)).SendKeys(amount);
				modal.FindElement(By.XPath(_approveInstantApprovalBtnXPath)).JSClickWithFocus(Driver);

				ConfirmOnModal();
				Driver.SwitchTo().ActiveElement();

				Check.That(SuccessMessage.Equals(message));
			}
		}

		public bool IsStatusDetailsVisible
		{
			get
			{
				if (Driver.TryFindElement(By.XPath(_detailsXPath), out IWebElement element))
				{
					return true;
				}
				else
				{
					return false;
				}
			}
		}

		/// <summary>
		/// This checks for "10 Most Recent Authorizations for ...." message and returns 'true' or 'false'.
		/// </summary>
		public bool IsRecentAuthorizationsVisible
		{
			get
			{
				if (Driver.TryFindElement(By.XPath(_recentAuthorizationsXPath), out IWebElement element))
				{
					return true;
				}
				else
				{
					return false;
				}
			}
		}
		/// <summary>
		/// This method clicks the 'Edit' button in Recent Activity page.
		/// </summary>
		public void EditInstantApproval()
		{
			_editInstantApprovalBtn.JSClickWithFocus(Driver);
			WaitForModalToAppear();
		}

		/// <summary>
		/// This property returns 'true' or 'false' if the Corporate limit' label/input field is present in the Edit Recent Auths dialog.
		/// </summary>
		public bool IsCorporateLimitPresent
		{
			get
			{
				if (Driver.TryFindElement(By.XPath(_iaSuperOverride_1XPath), out IWebElement element))
				{
					return element.Displayed;
				}
				else
				{
					return false;
				}
			}
		}

		/// <summary>
		/// This method closes the 'Instant Approval' dialog.
		/// </summary>
		public void CancelInstantApprovalDialog()
		{
			if (Driver.TryFindElement(By.XPath(_instantApprovalFooterXPath), out IWebElement element))
			{
				element.JSClickWithFocus(Driver);
			}
		}

		/// <summary>
		/// This method Approves the 'Instant Approval' dialog.
		/// </summary>
		public void ApproveInstantApprovalInDialog()
		{
			if (Driver.TryFindElement(GetBy(()=>this._approveInstantApprovalBtn), out IWebElement element))
			{
				element.JSClickWithFocus(Driver);
			}
		}

		/// <summary>
		/// This method deletes the Instant Approval on a Transaction and verifies the message text.
		/// </summary>
		/// <param name="messageType"></param>
		/// <param name="message"></param>
		public void DeleteInstantApprovalNoModalClose(string messageType, string message)
		{
			using (FrameHelper modal = new FrameHelper(Driver, By.XPath(_frameGenericXPath)))
			{
				Driver.FindElement(By.XPath(_cmdDeleteInstantApprovalXPath)).JSClickWithFocus(Driver);
				Driver.SwitchTo().ActiveElement();
				Driver.FindElement(By.XPath(_btnInstantApprovalDeleteXPath)).JSClickWithFocus(Driver);
				Driver.SwitchTo().ActiveElement();

				string msg = GetResultMessage(messageType);

				Check.That(msg.Equals(message));
			}
		}

		/// <summary>
		/// This method returns the text of either Success/Error message in the page.
		/// </summary>
		/// <param name="messageType"></param>
		/// <returns></returns>
		public string GetResultMessage(string messageType)
		{
			if (messageType.ToLowerInvariant().Equals("success"))
			{
				return Driver.FindElement(By.XPath(_modalSuccessMessageXPath)).Text;
			}
			else
			{
				return Driver.FindElement(By.XPath(_modalValidationSummary)).Text;
			}

		}

		/// <summary>
		/// This method clicks on the 'Instant Approval' button to create one for a Transaction.
		/// </summary>
		public void CreateInstantApprovalButtonClick()
		{
			Driver.FindElement(By.XPath(_frameCreateInstantApprovalBtn)).JSClickWithFocus(Driver);
			Driver.WaitForVisible(GetBy(() => _instantApprovalAmount));
		}

		// All the Elements in the Instal Approval popup dialog.
		#region InstantApprovalAmount
		public string InstantApprovalAmount
		{
			get
			{
				if (Driver.TryFindElement(GetBy(() => this._instantApprovalAmount), out IWebElement element))
				{
					return element.Text;
				}
				else
				{
					return "";
				}
			}

			set
			{
				if (Driver.TryFindElement(GetBy(() => this._instantApprovalAmount), out IWebElement element))
				{
					element.Clear(); element.SendKeys(value);
				}
			}
		}
		#endregion

		#region ApprovalExpiration
		public string ApprovalExpiration
		{
			get
			{
				if (Driver.TryFindElement(GetBy(() => this._instantApprovalExpiration), out IWebElement element))
				{
					return element.Text;
				}
				else
				{
					return "";
				}
			}
			set
			{
				if (Driver.TryFindElement(GetBy(() => this._instantApprovalExpiration), out IWebElement element))
				{
					element.Clear(); element.SendKeys(value);
				}
			}
		}
		#endregion

		#region NumberOfTxnsAllowed
		public string NumberOfTransactionsAllowed
		{
			get
			{
				return Driver.FindElement(GetBy(() => this._numOfTxnsAllowed)).GetAttribute("value").ToString().Trim();
			}

			set
			{
				if (Driver.TryFindElement(By.XPath("//a[contains(@id, 'toggleInstantApprovalNumber')]"), out IWebElement element))
				{
					element.Click();
					Driver.FindElement(GetBy(() => this._numOfTxnsAllowed)).Clear();
					Driver.FindElement(GetBy(() => this._numOfTxnsAllowed)).SendKeys(value);
				}
			}
		}
		#endregion

		#region OverrideAuthSelectAll
		public bool IsOverrideAuthSelectAllPresent
		{
			get
			{
				if (Driver.TryFindElement(GetBy(() => this._toggleAllOverrideAuthLabel), out IWebElement element))
				{
					return element.Displayed;
				}
				else
				{
					return false;
				}
			}
		}

		public bool OverrideAuthSelectAll
		{
			get
			{
				return _toggleAllOverrideAuthCB.Selected;
			}

			set
			{
				_toggleAllOverrideAuthCB.SetCheckboxStateWithLabel(_toggleAllOverrideAuthLabel, value);
			}
		}
		#endregion

		#region CV2
		public bool IsCV2Present
		{
			get
			{
				if (Driver.TryFindElement(GetBy(() => this._cv2Label), out IWebElement element))
				{
					return element.Displayed;
				}
				else
				{
					return false;
				}
			}
		}

		public bool CV2
		{
			get
			{
				return _cv2CB.Selected;
			}

			set
			{
				_cv2CB.SetCheckboxStateWithLabel(_cv2Label, value);
			}
		}
		#endregion

		#region CVV
		public bool IsCVVPresent
		{
			get
			{
				if (Driver.TryFindElement(GetBy(() => this._cvvLabel), out IWebElement element))
				{
					return element.Displayed;
				}
				else
				{
					return false;
				}
			}
		}

		public bool CVV
		{
			get
			{
				return _cvvCB.Selected;
			}

			set
			{
				_cvvCB.SetCheckboxStateWithLabel(_cvvLabel, value);
			}
		}
		#endregion

		#region CardholderLimit
		public bool IsCardholderLimitPresent
		{
			get
			{
				if (Driver.TryFindElement(GetBy(() => this._cardHolderLimitLabel), out IWebElement element))
				{
					return element.Displayed;
				}
				else
				{
					return false;
				}
			}
		}

		public bool CardholderLimit
		{
			get
			{
				return _cardHolderLimitCB.Selected;
			}

			set
			{
				_cardHolderLimitCB.SetCheckboxStateWithLabel(_cardHolderLimitLabel, value);
			}
		}
		#endregion

		#region DailyTransactionLimit
		public bool IsDailyTransactionLimitPresent
		{
			get
			{
				if (Driver.TryFindElement(GetBy(() => this._dailyTransactionLimitLabel), out IWebElement element))
				{
					return element.Displayed;
				}
				else
				{
					return false;
				}
			}
		}

		public bool DailyTransactionLimit
		{
			get
			{
				return _dailyTransactionLimitCB.Selected;
			}

			set
			{
				_dailyTransactionLimitCB.SetCheckboxStateWithLabel(_dailyTransactionLimitLabel, value);
			}
		}
		#endregion

		#region ExpirationDate
		public bool IsExpirationDatePresent
		{
			get
			{
				if (Driver.TryFindElement(GetBy(() => this._expirationDateLabel), out IWebElement element))
				{
					return element.Displayed;
				}
				else
				{
					return false;
				}
			}
		}

		public bool ExpirationDate
		{
			get
			{
				return _expirationDateCB.Selected;
			}

			set
			{
				_expirationDateCB.SetCheckboxStateWithLabel(_expirationDateLabel, value);
			}
		}
		#endregion

		#region SingleTransactionLimit
		public bool IsSingleTransactionLimitPresent
		{
			get
			{
				if (Driver.TryFindElement(GetBy(() => this._singleTransactionLimitLabel), out IWebElement element))
				{
					return element.Displayed;
				}
				else
				{
					return false;
				}
			}
		}

		public bool SingleTransactionLimit
		{
			get
			{
				return _singleTransactionLimitCB.Selected;
			}

			set
			{
				_singleTransactionLimitCB.SetCheckboxStateWithLabel(_singleTransactionLimitLabel, value);
			}
		}
		#endregion

		#region AccountStatus
		public bool IsAccountStatusPresent
		{
			get
			{
				if (Driver.TryFindElement(GetBy(() => this._cardStatusLabel), out IWebElement element))
				{
					return element.Displayed;
				}
				else
				{
					return false;
				}
			}
		}

		public bool AccountStatus
		{
			get
			{
				return _cardStatusCB.Selected;
			}

			set
			{
				_cardStatusCB.SetCheckboxStateWithLabel(_cardStatusLabel, value);
			}
		}
		#endregion

		#region FleetID
		public bool IsFleetIDPresent
		{
			get
			{
				if (Driver.TryFindElement(GetBy(() => this._fleetIDLabel), out IWebElement element))
				{
					return element.Displayed;
				}
				else
				{
					return false;
				}
			}
		}

		public bool FleetID
		{
			get
			{
				return _fleetIDCB.Selected;
			}

			set
			{
				_fleetIDCB.SetCheckboxStateWithLabel(_fleetIDLabel, value);
			}
		}
		#endregion

		#region PIN
		public bool IsPINPresent
		{
			get
			{
				if (Driver.TryFindElement(GetBy(() => this._pinLabel), out IWebElement element))
				{
					return element.Displayed;
				}
				else
				{
					return false;
				}
			}
		}

		public bool PIN
		{
			get
			{
				return _pinCB.Selected;
			}

			set
			{
				_pinCB.SetCheckboxStateWithLabel(_pinLabel, value);
			}
		}
		#endregion

		#region MCC
		public bool IsMCCPresent
		{
			get
			{
				if (Driver.TryFindElement(GetBy(() => this._merchantCategoryCodeLabel), out IWebElement element))
				{
					return element.Displayed;
				}
				else
				{
					return false;
				}
			}
		}

		public bool MCC
		{
			get
			{
				return _merchantCategoryCodeCB.Selected;
			}

			set
			{
				_merchantCategoryCodeCB.SetCheckboxStateWithLabel(_merchantCategoryCodeLabel, value);
			}
		}
		#endregion

		#region FraudCriteria
		public bool IsFraudCriteriaPresent
		{
			get
			{
				if (Driver.TryFindElement(GetBy(() => this._fraudCriteriaLabel), out IWebElement element))
				{
					return element.Displayed;
				}
				else
				{
					return false;
				}
			}
		}

		public bool FraudCriteria
		{
			get
			{
				return _fraudCriteriaCB.Selected;
			}

			set
			{
				_fraudCriteriaCB.SetCheckboxStateWithLabel(_fraudCriteriaLabel, value);
			}
		}
		#endregion

		#region HierarchyLimit
		public bool IsHierarchyLimitPresent
		{
			get
			{
				if (Driver.TryFindElement(GetBy(() => this._hierarchyLimitLabel), out IWebElement element))
				{
					return element.Displayed;
				}
				else
				{
					return false;
				}
			}
		}

		public bool HierarchyLimit
		{
			get
			{
				return _hierarchyLimitCB.Selected;
			}

			set
			{
				_hierarchyLimitCB.SetCheckboxStateWithLabel(_hierarchyLimitLabel, value);
			}
		}
		#endregion

		#region CorporateLimit
		public bool CorporateLimit
		{
			get
			{
				return _corporateLimitCB.Selected;
			}

			set
			{
				_corporateLimitCB.SetCheckboxStateWithLabel(_corporateLimitLabel, value);
			}
		}
		#endregion

		#region CentralBillLimit
		public bool IsCentralBillLimitPresent
		{
			get
			{
				if (Driver.TryFindElement(GetBy(() => this._centralBillLimitLabel), out IWebElement element))
				{
					return element.Displayed;
				}
				else
				{
					return false;
				}
			}
		}

		public bool CentralBillLimit
		{
			get
			{
				return _centralBillLimitCB.Selected;
			}

			set
			{
				_centralBillLimitCB.SetCheckboxStateWithLabel(_centralBillLimitLabel, value);
			}
		}
		#endregion

		#region Delinquency
		public bool IsDelinquencyPresent
		{
			get
			{
				if (Driver.TryFindElement(GetBy(() => this._authOverrideDelinquencyLabel), out IWebElement element))
					return element.Displayed;
				else
					return false;
			}
		}

		public bool Delinquency
		{
			get
			{
				return _authOverrideDelinquencyCB.Selected;
			}

			set
			{
				_authOverrideDelinquencyCB.SetCheckboxStateWithLabel(_authOverrideDelinquencyLabel, value);
			}
		}
		#endregion




		public void Close()
		{
			_closeButton.JSClickWithFocus(Driver);
			Settings.EnCompassExtentTest.Info("Click on the button to close");
		}
		public RecentActivity(GlobalSettings settings) : base(settings) { }
	}
}
