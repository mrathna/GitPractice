package com.framework.testcases.OLS.SHELL.Customer;

import org.testng.SkipException;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.OLS.HomePage;
import com.framework.pages.OLS.common.LoginPage;
import com.framework.pages.SHELL.SHELLHomePage;
import com.framework.pages.SHELL.SHELLReportsPage;

public class ValidateReportsAndInvoiceTestCases extends BaseTest {
	
	@Parameters({"clientCountry","clientName", "cardType"})
	@Test(groups = { "Regression" })
	public void validateStoredReports(@Optional("AT") String clientCountry, @Optional("SHELL") String clientName, @Optional("APA") String cardType)  {
		
		test = extent.createTest(clientName+ ":" +clientCountry+"  Stored Reports", "Export the stored reports");

		//Creating Objects for the Pages
        LoginPage loginPage = new LoginPage(driver, test);
        HomePage homePage = new HomePage(driver, test);
        SHELLHomePage shellHomePage = new SHELLHomePage(driver, test);
        SHELLReportsPage shellReportsPage = new SHELLReportsPage(driver, test); 
        
        // Calling Login Functions And Validate
        if(cardType.equals("PC"))
	    {
	    	loginPage.Login("SHLPC_URL", "SHLPC_UN_Customer_Admin_" + clientCountry, "SHLPC_PWD_Customer_Admin_" + clientCountry, clientName);
	    }
	    else if(cardType.equals("APA"))
	    {
	    	loginPage.Login("SHLAPA_URL", "SHLAPA_UN_Customer_Admin_" + clientCountry, "SHLAPA_PWD_Customer_Admin_" + clientCountry, clientName);
	    }
		homePage.ValidateLogoutLink();
		homePage.ValidateHelpShellLink();
		homePage.ValidateWelcomeText(clientName+"#"+cardType);
		homePage.ValidateQuickLinks();
		shellHomePage.ValidateHeaderMenus("Admin");
		shellHomePage.ValidateFooterMenus();
		// select the stored Reports 
		shellHomePage.goToReportsAndInvoiceStoredReports(clientCountry);
		// Export stored Reports 
		shellReportsPage.validateExportStoredReports();
		shellHomePage.goToReportsAndInvoiceStoredReports(clientCountry);
		// Validate Blank field 
		shellReportsPage.validateBlankFieldwithDateRangeStoredReports();
		shellHomePage.goToReportsAndInvoiceStoredReports(clientCountry);
		shellReportsPage.validateBlankFieldStoredReports();
		loginPage.Logout();	
	} 
	
	@Parameters({"clientCountry","clientName", "cardType"})
	@Test(groups = { "Regression" })
	public void validateSchuduleReports(@Optional("AT") String clientCountry, @Optional("SHELL") String clientName, @Optional("APA") String cardType)  {
		
		test = extent.createTest(clientName+ ":" +clientCountry+"  02 Reports Schudule Reports", "Schudule Reports");

		//Creating Objects for the Pages
        LoginPage loginPage = new LoginPage(driver, test);
        HomePage homePage = new HomePage(driver, test);
        SHELLHomePage shellHomePage = new SHELLHomePage(driver, test);
        SHELLReportsPage shellReportsPage = new SHELLReportsPage(driver, test); 
        
        // Calling Login Functions And Validate
        if(cardType.equals("PC"))
	    {
	    	loginPage.Login("SHLPC_URL", "SHLPC_UN_Customer_Admin_" + clientCountry, "SHLPC_PWD_Customer_Admin_" + clientCountry, clientName);
	    }
	    else if(cardType.equals("APA"))
	    {
	    	loginPage.Login("SHLAPA_URL", "SHLAPA_UN_Customer_Admin_" + clientCountry, "SHLAPA_PWD_Customer_Admin_" + clientCountry, clientName);
	    }
		homePage.ValidateLogoutLink();
		homePage.ValidateHelpShellLink();
		homePage.ValidateWelcomeText(clientName+"#"+cardType);
		homePage.ValidateQuickLinks();
		shellHomePage.ValidateHeaderMenus("Admin");
		shellHomePage.ValidateFooterMenus();
		// select the Scheduled Reports page
		shellHomePage.goToReportsAndInvoiceScheduledReports(clientCountry);
		// Filter the reports 
		shellReportsPage.selectReportTypaNDFrequency();
		// Validate the Search result 
		shellReportsPage.validateTheSearchResults();
		shellReportsPage.exportScheduleReports();
		loginPage.Logout();	
	} 
	
	@Parameters({"clientCountry","clientName", "cardType"})
	@Test(groups = { "Regression" })
	public void validateAdhocReports(@Optional("AT") String clientCountry, @Optional("SHELL") String clientName, @Optional("APA") String cardType)  {
		
		test = extent.createTest(clientName+ ":" +clientCountry+"  03 Reports - AdhocReports", "checking the Adhoc Reports functionality");
		//Creating Objects for the Pages
        LoginPage loginPage = new LoginPage(driver, test);
        HomePage homePage = new HomePage(driver, test);
        SHELLHomePage shellHomePage = new SHELLHomePage(driver, test);
        SHELLReportsPage shellReportsPage = new SHELLReportsPage(driver, test); 
        
        // Calling Login Functions And Validate
        if(cardType.equals("PC"))
	    {
	    	loginPage.Login("SHLPC_URL", "SHLPC_UN_Customer_Admin_" + clientCountry, "SHLPC_PWD_Customer_Admin_" + clientCountry, clientName);
	    }
	    else if(cardType.equals("APA"))
	    {
	    	loginPage.Login("SHLAPA_URL", "SHLAPA_UN_Customer_Admin_" + clientCountry, "SHLAPA_PWD_Customer_Admin_" + clientCountry, clientName);
	    }
		homePage.ValidateLogoutLink();
		homePage.ValidateHelpShellLink();
		homePage.ValidateWelcomeText(clientName+"#"+cardType);
		homePage.ValidateQuickLinks();
		shellHomePage.ValidateHeaderMenus("Admin");
		shellHomePage.ValidateFooterMenus();
		shellHomePage.goToReportsAndInvoiceAdhocReports(clientCountry);
		shellReportsPage.validateGenerateReports();
		// Get the ToolTip 
		shellReportsPage.validateExportReportsAndToolTip();
		loginPage.Logout();	
	} 
	
	@Parameters({"clientCountry","clientName", "cardType"})
	@Test(groups = { "Regression" })
	public void validateAddSchuduleReports(@Optional("AT") String clientCountry, @Optional("SHELL") String clientName, @Optional("APA") String cardType)  {
		
		test = extent.createTest(clientName+ ":" +clientCountry+"  06 Reports - AddSchuduleReports", "Checking the ADD Schudule Reports Page");

		//Creating Objects for the Pages
        LoginPage loginPage = new LoginPage(driver, test);
        HomePage homePage = new HomePage(driver, test);
        SHELLHomePage shellHomePage = new SHELLHomePage(driver, test);
        SHELLReportsPage shellReportsPage = new SHELLReportsPage(driver, test); 
        
        // Calling Login Functions And Validate
        if(cardType.equals("PC"))
	    {
	    	loginPage.Login("SHLPC_URL", "SHLPC_UN_Customer_Admin_" + clientCountry, "SHLPC_PWD_Customer_Admin_" + clientCountry, clientName);
	    }
	    else if(cardType.equals("APA"))
	    {
	    	loginPage.Login("SHLAPA_URL", "SHLAPA_UN_Customer_Admin_" + clientCountry, "SHLAPA_PWD_Customer_Admin_" + clientCountry, clientName);
	    }
		homePage.ValidateLogoutLink();
		homePage.ValidateHelpShellLink();
		homePage.ValidateWelcomeText(clientName+"#"+cardType);
		homePage.ValidateQuickLinks();
		shellHomePage.ValidateHeaderMenus("Admin");
		shellHomePage.ValidateFooterMenus();
		// select the Scheduled Reports page
		shellHomePage.goToReportsAndInvoiceScheduledReports(clientCountry);
		shellReportsPage.validateAddscheduleRepotsPage();
		loginPage.Logout();	
	}
	
	@Parameters({"clientCountry","clientName", "cardType"})
	@Test(groups = { "Regression" })
	public void validateInvoiceReports(@Optional("AT") String clientCountry, @Optional("SHELL") String clientName, @Optional("APA") String cardType)  {
		
		test = extent.createTest(clientName+ ":" +clientCountry+"  04 Reports - InvoiceReports", "Checking the Invoice Reports");
		if(clientCountry.equals("PH") || clientCountry.equals("SG") || clientCountry.equals("RU")) {
			System.out.println("InvoiceReport is not available for Philippines,Russia and Singapore - Skipping this execution for: "+clientCountry);
			throw new SkipException("InvoiceReport is not available for Philippines,Russia and Singapore - Skipping this execution");			
		} else {
			//Creating Objects for the Pages
			LoginPage loginPage = new LoginPage(driver, test);
			HomePage homePage = new HomePage(driver, test);
			SHELLHomePage shellHomePage = new SHELLHomePage(driver, test);
			SHELLReportsPage shellReportsPage = new SHELLReportsPage(driver, test); 

			// Calling Login Functions And Validate
			if(cardType.equals("PC"))
			{
				loginPage.Login("SHLPC_URL", "SHLPC_UN_Customer_Admin_" + clientCountry, "SHLPC_PWD_Customer_Admin_" + clientCountry, clientName);
			}
			else if(cardType.equals("APA"))
			{
				loginPage.Login("SHLAPA_URL", "SHLAPA_UN_Customer_Admin_" + clientCountry, "SHLAPA_PWD_Customer_Admin_" + clientCountry, clientName);
			}
			homePage.ValidateLogoutLink();
			homePage.ValidateHelpShellLink();
			homePage.ValidateWelcomeText(clientName+"#"+cardType);
			homePage.ValidateQuickLinks();
			shellHomePage.ValidateHeaderMenus("Admin");
			shellHomePage.ValidateFooterMenus();
			// select the Scheduled Reports page
			if(clientCountry.equals("MY")) {
				shellHomePage.goToReportsAndInvoiceReports(clientCountry);
				shellReportsPage.invoiceSearch();
			} else {
				shellHomePage.goToReportsAndInvoiceReports(clientCountry);
				shellReportsPage.validateClickHerePage();
			}		
		}
	}  
}
