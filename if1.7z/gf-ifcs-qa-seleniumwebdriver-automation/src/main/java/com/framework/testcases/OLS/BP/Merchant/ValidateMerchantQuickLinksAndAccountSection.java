package com.framework.testcases.OLS.BP.Merchant;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.BP.BPHomePage;
import com.framework.pages.OLS.common.LoginPage;

public class ValidateMerchantQuickLinksAndAccountSection extends BaseTest {

	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "Regression" })
	public void validate_Merchant_Account_DropDown(@Optional("AU") String clientCountry,
			@Optional("BP") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  BP Merchant Home Page", "Verify Account drop down");

		// Creating Objects for the Login Pages
		LoginPage loginPage = new LoginPage(driver, test);
		BPHomePage bpHomePage = new BPHomePage(driver, test);
		loginPage.Login("BP_URL", "BP_UN_Merchant_" + clientCountry, "BP_PWD_Merchant_" + clientCountry, clientName);
		bpHomePage.ValidateMerchantLogo();

		// Select the Account from Drop down
		bpHomePage.selectAccountsFromDropDown();

		// Logout
		loginPage.Logout();

	}

	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "Regression" })
	public void validateMerchantQuickLinkTransactionList(@Optional("AU") String clientCountry,
			@Optional("BP") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  BP Merchant Quick Links", "Verify Merchant HomePage Quick Links ");

		// Creating Objects for the Login Pages
		LoginPage loginPage = new LoginPage(driver, test);
		BPHomePage bpHomePage = new BPHomePage(driver, test);
		loginPage.Login("BP_URL", "BP_UN_Merchant_" + clientCountry, "BP_PWD_Merchant_" + clientCountry, clientName);
		bpHomePage.ValidateMerchantLogo();

		// Select the Transaction list quick links
		bpHomePage.clickTransactionListQuickLinksAndValidate("Merchant");

		// Logout
		loginPage.Logout();
	}

}
