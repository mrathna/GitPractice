package com.framework.testcases.AJS.EMAP;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.ApplicationsPage;
import com.framework.pages.AJS.MaintainCustomerPage;
import com.framework.pages.AJS.common.Common;
import com.framework.pages.AJS.common.IFCSHomePage;
import com.framework.pages.AJS.common.IFCSLoginPage;

public class ValidateAndCreateApplicationType extends BaseTest{

	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test( groups = { "Regression" })
	public void validateAndCreateApplicationTypeAsSGGeneral(@Optional("SG") String clientCountry, @Optional("EMAP") String clientName,
			@Optional("APA") String cardType) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  Create Application Type SG General", "Validate and create SG General application Type");
		// creating object for the Pages
		IFCSLoginPage ifcsloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage ifcsHomePage = new IFCSHomePage(driver, test);
		ApplicationsPage ifcsApplicationsPage = new ApplicationsPage(driver, test);
		MaintainCustomerPage maintainCustomerPage = new MaintainCustomerPage(driver, test);
		Common common = new Common(driver, test);
		
		ifcsloginPage.login("IFCS_URL_EMAP", "IFCS_EMAP_USERNAME", "IFCS_EMAP_PASSWORD");
		ifcsHomePage.gotoApplicationAndClickApplicationMenu();
		ifcsloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		// Selecting client from Application Menu
		ifcsHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);
		
		ifcsApplicationsPage.applicationFilterOptions(clientCountry+ " General", "TL APP approved");
		//common.selectFirstRowNumberInSearchList();
	
		String searchValues = ifcsApplicationsPage.clearExistingFormAndCreateNewApplicationWithMandatoryField("random");
		
		String searchByName = searchValues.split(":")[0];
		String searchByTradingName = searchValues.split(":")[1];
		String searchByMarketingTerritory = searchValues.split(":")[2];
		
//		Unable to select the profile from dropdown
//		ifcsApplicationsPage.selectPricingProfile();
		/*ifcsApplicationsPage.choosePricingFromCustomerProfile();
		ifcsApplicationsPage.createApplicationCustomerPricingProfile(clientCountry);*/
		
		ifcsApplicationsPage.createCardOffersInApplication(clientCountry+ " General");
		
		//ifcsApplicationsPage.chooseCardControlFromCardProfile();
		//ifcsApplicationsPage.createCardControlProfile();		

		maintainCustomerPage.chooseCardReissueProfileFromCustomerProfile();
		// maintainCustomerPage.createCardReissueProfile();
		
		common.rightClickAndSelectProfileFirstApplication();
		
		common.clickSaveIcon();
		
		ifcsApplicationsPage.selectPendingApplicationAndApprove();
		
		ifcsApplicationsPage.addNotesInApplicationMenu("IFCS_EMAP_USERNAME");
		
		ifcsApplicationsPage.addStoredAttachmentInApplicationMenu();
		
		common.enterValueInTextBox("Filter By", "Name", searchByName);
		
		common.validateSearchTable("Name", searchByName, false);
		
		common.enterValueInTextBox("Filter By", "Name", searchByTradingName);
		
		common.validateSearchTable("Name", searchByTradingName, false);
		
		common.chooseOptionFromDropdown("Marketing Territory", searchByMarketingTerritory);
		
		common.validateSearchTablePresence("Applications");
		
		common.chooseOptionFromDropdown("Application Type", "SG General");
		
		common.validateSearchTable("Application Type", "SG General", true);
		
		common.chooseOptionFromDropdown("Status", "TL APP approved");
		
		common.validateSearchTable("New Status", "TL APP approved", true);
		
	}
}
