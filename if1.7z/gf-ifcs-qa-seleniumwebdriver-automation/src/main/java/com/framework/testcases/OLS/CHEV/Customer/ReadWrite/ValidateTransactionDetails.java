package com.framework.testcases.OLS.CHEV.Customer.ReadWrite;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.CHEV.CHHomePage;
import com.framework.pages.CHEV.CHTransactionPage;
import com.framework.pages.OLS.common.LoginPage;

public class ValidateTransactionDetails extends BaseTest {
	@Parameters({ "clientCountry", "clientName"})
	@Test(priority = 1)
	public void testCustomerReadWriteTransactionDetails(@Optional("PH") String clientCountry, @Optional("CHV") String clientName) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  01 TransactionMenu - TransactionList", "Chevron Transaction");

		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		if (clientCountry.equals("SG")||clientCountry.equals("MY")||clientCountry.equals("HK")) {
			loginPage.Login("CHV_URL", "CHV_Customer_UN_RW_ONLY_"+clientCountry, "CHV_Customer_PWD_RW_ONLY_"+clientCountry, "CHV");
		} else if (clientCountry.equals("TH")) {
			loginPage.Login("CHV_URL", "CHV_Customer_UN_"+clientCountry, "CHV_Customer_PWD_"+clientCountry, "CHV");
		} else if (clientCountry.equals("PH")) {
			loginPage.Login("CHV_URL", "CHV_Customer_UN_"+clientCountry, "CHV_Customer_PWD_"+clientCountry, "CHV");
		}
		CHHomePage chHomePage= new CHHomePage(driver,test);
		CHTransactionPage chTransactionPage=new CHTransactionPage(driver,test);
		
		chHomePage.verifyHomePageText();
		chHomePage.findAndClickFindtransactions();
		
		//Transaction Page
		chTransactionPage.verifyTransactionPage();
		chTransactionPage.selectAccountFromDropdownAndValidate();
		
		//Getting Date from DB for transaction 
		if (clientCountry.equals("SG")||clientCountry.equals("MY")||clientCountry.equals("HK")) {
		chTransactionPage.getTransactionDateFromTheDBForTheCurrentInternetUser("CHV_Customer_UN_RW_ONLY_" + clientCountry,clientName);
		}else if (clientCountry.equals("TH")) {
			chTransactionPage.getTransactionDateFromTheDBForTheCurrentInternetUser("CHV_Customer_UN_" + clientCountry,clientName);
		}else if (clientCountry.equals("PH")) {
			chTransactionPage.getTransactionDateFromTheDBForTheCurrentInternetUser("CHV_Customer_UN_" + clientCountry,clientName);
			
		}
		
		chTransactionPage.passFromDateInTransaction();
		chTransactionPage.clickTransactionListSearchButtonAndValidate();
		
		
		boolean isNoTransactionGroupPresent = chTransactionPage.waitForTextToAppear("No Transactions found.", 30);
		if(!isNoTransactionGroupPresent)
		{
			
		//Getting data from table
		chTransactionPage.getACardNumberFromTable();
		
		//Filling the Fields by getting data from table
	//	chTransactionPage.enterCardNumberAndSearch();
		chTransactionPage.enterReferenceAndSearch();
		chTransactionPage.verifyandClickExportButtons();
		chTransactionPage.verifyAccountNoForFileVerification();
		
		chTransactionPage.selectProductFromDropdownAndValidate();
		chTransactionPage.verifySearchButtons();
		chTransactionPage.verifyandClickExportButtons();
		chTransactionPage.verifyAccountNoForFileVerification();
		
		}	else {
			
			loginPage.Logout();
			
		}
		
		
	}	
	
}
