package com.framework.testcases.AJS.BP;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.MaintainCustomerPage;
import com.framework.pages.AJS.common.Common;
import com.framework.pages.AJS.common.IFCSHomePage;
import com.framework.pages.AJS.common.IFCSLoginPage;
import com.framework.pages.BP.BPHomePage;
import com.framework.pages.OLS.common.FindAndExportTransactionPage;
import com.framework.pages.OLS.common.LoginPage;

/**
 * @author smanikandan
 *
 */
public class ValidateMerchantTransactionTestCase extends BaseTest{
	
	//Sasi
	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test(groups = {"Regression"})
	public void validateOnlineMerchantTransactionSearch(@Optional("RU") String clientCountry,
			@Optional("SHELL") String clientName, @Optional("APA") String cardType)
	{
		test = extent.createTest(clientName+ ":" +clientCountry+"  Onl_AU_005_Online merchant transaction search,Onl_NZ_005_Online merchant transaction search", "Search transactions for merchants");
		
		String accountNo ="";
		String transactionDate ="";
		int reportFoundCountOLS=0;
		int reportFoundCountIFCS=0;
		int reportCountOLS=0;
		//creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);

		Common common=new Common(driver,test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		
		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		BPHomePage bpHomePage = new BPHomePage(driver, test);
		FindAndExportTransactionPage findAndExportTransactions = new FindAndExportTransactionPage(driver, test);
		MaintainCustomerPage maintainCustomerPage = new MaintainCustomerPage(driver, test);
		FindAndExportTransactionPage findAndExportTransactionPage = new FindAndExportTransactionPage(driver, test);
		
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, cardType);
		
		// Calling Functions for Login
		loginPage.Login("BP_URL", "BP_UN_Merchant_" + clientCountry, "BP_PWD_Merchant_" + clientCountry, clientName);
		
//		bpHomePage.ValidateMerchantLogo();

		// Find and Export Transaction Page
		findAndExportTransactionPage.selectFindAndExportTransactionPage();

		// Click Search Button and Validate
		findAndExportTransactionPage.clickSearch();
		
		boolean isNoTranscPresent = findAndExportTransactionPage.validateTheSearchResults();
		
		System.out.println("-----isNoTranscPresent-------"+isNoTranscPresent);
		
		
		if(!isNoTranscPresent)
		{
				
			accountNo = bpHomePage.getCustomerNumberFromDropDown();
			transactionDate = bpHomePage.getEffectiveFromDate();
			System.out.println("accountNo : "+accountNo +" "+ "transactionDate : "+transactionDate);


				/*
				 * Export Transaction Test case & Continuation of Previous Test case
				 */

			findAndExportTransactionPage.clickExportButton();	
			reportCountOLS = findAndExportTransactions.totalRowSizeExcludingHeader();
			
			boolean isPaginationPresents = findAndExportTransactionPage.validateIfPaginationPresents();
			
			if(!isPaginationPresents) {
				System.out.println("inside if");
				reportFoundCountOLS = reportCountOLS;
			}else {
				System.out.println("inside else");
				reportFoundCountOLS = findAndExportTransactions.totalRowSizeExcludingHeader();
			}
			System.out.println("reportFoundCountOLS : "+reportFoundCountOLS);
		

		IFCSloginPage.login("IFCS_URL_BP", "IFCS_BP_USERNAME", "IFCS_BP_PASSWORD");
		
		IFCSHomePage.gotoApplicationAndClickApplicationMenu();
		
		IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);
		
		IFCSHomePage.gotoMerchantAndClickMerchantDetails();
				
		common.chooseMerchantNoAndSearch(accountNo);
		
		common.chooseSubMenuFromLeftPanel("Maintain Merchant","Transactions");
		
		common.clickDetailSearchIfFilterFieldsNotPresent();
			
		common.enterValueInTextBox("Transaction Filter Fields", "Process Date From", transactionDate);
		
		common.searchListTorch();
		
		reportFoundCountIFCS = common.totalRowsCount();
		
		if(reportFoundCountIFCS==reportFoundCountOLS) {
			common.logPassWhenDataFound(this.getClass().getSimpleName(), "Both reports counts in OLS and IFCS are same");
		}else {
			common.logForNoDataFound(this.getClass().getSimpleName(), "Both reports counts in OLS and IFCS are different");
		}

		maintainCustomerPage.exportReports();

		}
		else
			common.logForNoDataFound(this.getClass().getSimpleName(), "Need to add Merchant Accounts having transactions");
	
		IFCSHomePage.exitIFCS();

	}
	
	

}
