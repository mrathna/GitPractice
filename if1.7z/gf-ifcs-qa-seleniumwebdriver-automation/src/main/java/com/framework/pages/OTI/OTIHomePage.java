package com.framework.pages.OTI;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.ExtentTest;
import com.framework.basepage.BasePage;
import com.framework.repo.Locator;

public class OTIHomePage extends BasePage {

	@FindBy(how = How.XPATH, using = Locator.CLIENT_WELCOME_TEXT)
	public WebElement clientWelcomeText;
	@FindBy(how = How.XPATH, using = Locator.CH_HOME_PAGE_USERNAME)
	public WebElement userNameDropDown;
	@FindBy(how = How.ID, using = Locator.LOGOUT)
	public WebElement logoutLink;
		

	public OTIHomePage(WebDriver driver, ExtentTest test) {

		super(driver, test);
		PageFactory.initElements(driver, this);

	}
	public void verifyHomePageText() {
		isDisplayed(clientWelcomeText, "Welcome text is displayed");
		String welcomeText = getText(clientWelcomeText);
		if (welcomeText.contains("Welcome to PUMA Online")) {
			logPass("Welcome text is displayed correctly");
		} else {
			logInfo("Welcome is not matched");
		}
		
	}
	public void verifyUserNameAndLogoutLink() {
		isDisplayed(userNameDropDown, "User Name In Top Right Corner");
		isDisplayed(logoutLink, "Logout Link");
		if (!getText(userNameDropDown).split("Hello,")[1].equals("")) {
			logPass("Username at top right corner present");
		} else {
			logFail("Username at top right corner not present");
		}
	}
	}
