package com.framework.testcases.OLS.EMAP.Customer;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.EMAP.EMAPAccountsPage;
import com.framework.pages.EMAP.EMAPHomePage;
import com.framework.pages.EMAP.EMAPReportsPage;
import com.framework.pages.EMAP.EMAPSupportPage;
import com.framework.pages.EMAP.EMAPTransactionsPage;
import com.framework.pages.OLS.common.CommonPage;
import com.framework.pages.OLS.common.LoginPage;

public class ValidateAllPageNavigationsRW extends BaseTest {
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "Regression" })
	public void validateAllPageNavigationsForRWCustomer(@Optional("SP") String clientCountry,
			@Optional("EMAP") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  TST-SC-71-OLS - All pages except cards menu,TST-SC-102-OLS-Verify the Ad-hoc Reports,TST-SC-103-OLS - Verify the Scheduled Reports,TST-SC-100-OLS-Verify Card Profile Changes",
				"Login to EMAP Customer - Read Write and check the page navigations");
		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		loginPage.Login("EMAP_URL", "EMAP_UN_ReadWrite_Customer_" + clientCountry,
				"EMAP_PWD_ReadWrite_Customer_" + clientCountry, clientName);
		EMAPHomePage emapHomePage = new EMAPHomePage(driver, test);
		EMAPAccountsPage accountPage = new EMAPAccountsPage(driver, test);
		EMAPTransactionsPage transactionListsPage = new EMAPTransactionsPage(driver, test);
		CommonPage commonPage = new CommonPage(driver, test);
		EMAPReportsPage reportsPage = new EMAPReportsPage(driver, test);
		EMAPSupportPage supportPage = new EMAPSupportPage(driver, test);
		emapHomePage.validateEMAPCustomerLogo();
		emapHomePage.validateCustomerWelcomeText();
		emapHomePage.checkThePresenceOfQuickLinksOnHomePage("Read-Write");
		emapHomePage.checkThePresenceOfLoginUserNameAndLogoutLink();

	//	emapHomePage.verifyCustomerNumberInHomePage();
		emapHomePage.selectAccountAndCheckSelectedAccountOnContext();

		// Account - Select Account
		emapHomePage.clickSelectAccountAndValidatePage();

		// Account - Account Maintenance
		emapHomePage.clickAccountMaintenanceAndValidatePage();
		accountPage.validateTheAccountMaintenancePageFields(clientCountry);

		// Account - Contacts
		emapHomePage.clickContactsAndValidatePage();
		accountPage.validateTheContactsTableFields();
		accountPage.checkContactsTableSorting();
		emapHomePage.clickHomeMenuAndValidatePage("Customer");

		// Transaction - Transaction List
		emapHomePage.clickTransactionListAndValidatePage();
		transactionListsPage.validateTheTransactionsTableFields("Customer");
		transactionListsPage.selectAllAccountsInTrasactionSearchFilter();
		transactionListsPage.selectProductListFromDropDown();
		boolean isTransactionPresent = transactionListsPage.getACardNumberWithTransaction();
		if (isTransactionPresent) {
			transactionListsPage.enterACardNumberInSearchFilter();
			commonPage.clickSearchButton();
			transactionListsPage.validateSearchResultsAndClickViewTransactionsOption(true);
			transactionListsPage.verifyTransactionDetailsHeaderTitle();
			transactionListsPage.validateTransactionPageFields("Customer");
		}
		// Transaction - Export Transaction
		emapHomePage.clickExportTransactionListAndValidate();

		// Reports - Stored Reports
		emapHomePage.clickStoredReportsAndValidatePage();
		reportsPage.validateTheReportsPageFilterOptions();
		reportsPage.checkThePresenceOfExportAndSearchOptions();
		reportsPage.validateTheReportsTableColumns();

		// Reports - Adhoc Reports
		emapHomePage.clickAdhocReportsAndValidatePage();
		reportsPage.checkThePresenceOfOptionToExportAdhocReport();
		reportsPage.validateTheAdhocReportsTableHeaderColumns(clientCountry);
		reportsPage.validateAdhocReportsTable();

		reportsPage.selectAReportType();
		reportsPage.verifyReportParameters();
		reportsPage.generateAReportWithValidRequestParameters();

		// Reports - Scheduled Reports
		emapHomePage.clickScheduledReportsAndValidatePage("EMAP_UN_ReadWrite_Customer_" + clientCountry);
		reportsPage.createAScheduledReportWithValidValues();

		supportPage.checkClientLogo();
		
		if (!(clientCountry.equals("MO"))) {
			emapHomePage.clickContactUsAndValidatePage();
		} else {
			emapHomePage.clickContactUsMOAndValidatePage();
		}

		supportPage.checkTheContactInfo(clientCountry);
		loginPage.Logout();
	}

	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "Regression" })
	public void validateFooterLinksForRWCustomer(@Optional("SP") String clientCountry,
			@Optional("EMAP") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  TST-SC-78-OLS - Verify menu items and log out",
				"Login to EMAP Customer - Read Write and check footer links and menu items");
		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		loginPage.Login("EMAP_URL", "EMAP_UN_ReadWrite_Customer_" + clientCountry,
				"EMAP_PWD_ReadWrite_Customer_" + clientCountry, clientName);
		EMAPHomePage emapHomePage = new EMAPHomePage(driver, test);
		EMAPSupportPage supportPage = new EMAPSupportPage(driver, test);

		// // Footer Links - Exxon Mobil Corporation link
		if (!clientCountry.contains("SG")) {
			emapHomePage.clickExxonMobilCorporationInFooterAndValidatePage();
			emapHomePage.clickHomeMenuAndValidatePage("Customer");
		}

		// Footer Links - Contact Us
		emapHomePage.clickContactUsInFooterAndValidatePage();
		emapHomePage.clickHomeMenuAndValidatePage("Customer");

		// Footer Links - Copyright
		emapHomePage.clickCopyRightAndValidatePage(clientName);

		// Footer Links - Terms And Condition
		emapHomePage.checkThePresenceOfTermsAndConditionInFooter();

		// Footer Links - Privacy Statement
		//emapHomePage.clickPrivacyPolicyAndValidatePage();

		// Footer Links - Client Logos
		emapHomePage.clickExxonMobilLogoAndValidatePage();
	//	 emapHomePage.clickEssoLogoAndValidatePage();
		emapHomePage.clickMobilLogoAndValidatePage();

		// Support - Change Password
		emapHomePage.clickChangePasswordAndValidatePage();
		supportPage.validateThePasswordMaintenanceFields();

		// Support - Contact Us
		if (!(clientCountry.equals("MO"))) {
			emapHomePage.clickContactUsAndValidatePage();
		} else {
			emapHomePage.clickContactUsMOAndValidatePage();
		}

		loginPage.Logout();
	}

}
