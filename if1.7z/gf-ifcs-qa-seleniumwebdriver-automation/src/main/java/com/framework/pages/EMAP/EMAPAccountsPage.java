package com.framework.pages.EMAP;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.ExtentTest;
import com.framework.basepage.BasePage;
import com.framework.pages.OLS.common.CommonPage;
import com.framework.repo.Locator;

public class EMAPAccountsPage extends BasePage {

	public EMAPAccountsPage(WebDriver driver, ExtentTest test) {
		super(driver, test);
		PageFactory.initElements(driver, this);
	}

	CommonPage commonPage = new CommonPage(driver, test);

	@FindBy(how = How.ID, using = Locator.ACCOUNT_INFO_SECTION)
	public WebElement accountInfoSection;

	@FindBy(how = How.ID, using = Locator.ADDRESS_INFO)
	public WebElement addressInfo;

	@FindBy(how = How.ID, using = Locator.FINANCE_INFORMATION)
	public WebElement financeInformation;

	@FindBy(how = How.XPATH, using = Locator.CONTACT_INFORMATION)
	public WebElement contactInformation;

	@FindBy(how = How.ID, using = Locator.CONTACT_LIST_TABLE)
	public WebElement contactListTable;

	@FindBy(how = How.ID, using = Locator.PHYSICAL_ADDRESS)
	public WebElement physicalAddress;

	@FindBy(how = How.ID, using = Locator.PHYSICAL_SUBURB)
	public WebElement physicalSuburb;

	@FindBy(how = How.ID, using = Locator.POSTALCODE)
	public WebElement physicalPostalCode;

	@FindBy(how = How.ID, using = Locator.MERCHANT_PHYSICAL_COUNTRY)
	public WebElement physicalCountry;

	@FindBy(how = How.ID, using = Locator.MERCHANT_POSTAL_CONTACT_MAILING_ADDRESS)
	public WebElement postalAddress;

	@FindBy(how = How.ID, using = Locator.MERCHANT_POSTAL_CONTACT_MAILING_SUBURB)
	public WebElement postalSuburb;

	@FindBy(how = How.ID, using = Locator.MERCHANT_POSTAL_CONTACT_MAILING_POSTALCODE)
	public WebElement postalCode;

	@FindBy(how = How.ID, using = Locator.MERCHANT_POSTAL_COUNTRY)
	public WebElement postalCountry;

	@FindBy(how = How.ID, using = Locator.CONTACT_NAME)
	public WebElement contactName;

	@FindBy(how = How.ID, using = Locator.EMAIL_FIELD)
	public WebElement emailField;

	@FindBy(how = How.ID, using = Locator.JOBTITLE_FIELD)
	public WebElement jobTitleField;

	@FindBy(how = How.ID, using = Locator.PHONE_FIELD)
	public WebElement phoneField;

	@FindBy(how = How.ID, using = Locator.MOBILE_FIELD)
	public WebElement mobileField;

	@FindBy(how = How.ID, using = Locator.FAX_FIELD)
	public WebElement faxField;

	@FindBy(how = How.ID, using = Locator.LOC_ACC_NAME)
	public WebElement accountName;

	@FindBy(how = How.XPATH, using = Locator.TRADING_NAME)
	public WebElement tradingName;

	@FindBy(how = How.ID, using = Locator.AU_SAVE)
	public WebElement saveOption;

	@FindBy(how = How.ID, using = Locator.CONTACT_ADD_A_CONTACT)
	public WebElement addAContact;

	@FindBy(how = How.ID, using = Locator.CONTACT_EXPORT)
	public WebElement contactExport;

	public void validateTheAccountMaintenancePageFields(String clientCountry) {
		isDisplayed(accountInfoSection, "Account Info Section");
		// Address Section
		//isDisplayed(addressInfo, "Address Info Section");
		// Check Address Section Fields are Read-Only
		checkAnElementIsDisabled(physicalAddress, "Physical address field ");
		checkAnElementIsDisabled(physicalSuburb, "Physical suburb field ");
		checkAnElementIsDisabled(physicalPostalCode, "Physical postal code ");
		checkAnElementIsDisabled(physicalCountry, "Physical country field ");
		checkAnElementIsDisabled(postalAddress, "Postal address field ");
		checkAnElementIsDisabled(postalSuburb, "Postal suburb field ");
		checkAnElementIsDisabled(postalCode, "Postal code field ");
		checkAnElementIsDisabled(postalCountry, "Postal country field ");
		//Updated on 22-01-2020 for release 20.2.1
		//isDisplayed(financeInformation, "Finance Info Section");
		System.out.println("client country::"+clientCountry);
		// Contact Section
		isDisplayed(contactInformation, "Contact Info Section");
		// Check Contact Section Fields are Read-Only
		checkAnElementIsDisabled(contactName, "Contact Name field ");
		checkAnElementIsDisabled(emailField, "Email field ");
		checkAnElementIsDisabled(jobTitleField, "Job Title field ");
		checkAnElementIsDisabled(phoneField, "Phone field ");
		checkAnElementIsDisabled(mobileField, "Mobile field ");
		checkAnElementIsDisabled(faxField, "Fax field ");
		isDisplayed(contactListTable, "Contact List Table");
		// checkAnElementIsDisabled(saveOption, "Save ");
	}

	// Contacts Menu
	public void validateTheContactsTableFields() {
		String[] columnValuesExpected = new String[] { "Contact Type", "Default", "Contact Name", "Phone", "Email" };
		commonPage.validateTheTableHeaderTitles(contactListTable, 5, columnValuesExpected);
		int contactsSize = getRowSize(contactListTable);
		if (!(contactsSize > 2)) {
			logFail("Contacts table not having atleast one contact");
		}
	}

	public void checkThePresenceOfTradingNameAndAccountName() {
		isDisplayed(accountName, "Account Name");
		// isDisplayed(tradingName, "Trading Name");
	}

	public void checkThePresenceOfAddAContactAndExportOption() {
		isDisplayed(addAContact, "Add a contact");
		isDisplayed(contactExport, "Contact Export");
	}

	public void checkContactsTableSorting() {
		String[] columnValuesExpected = new String[] { "Contact Type", "Default", "Contact Name", "Phone", "Email" };
		for (int i = 0; i < columnValuesExpected.length; i++) {
			commonPage.clickColumnHeaderAndVerifySorting(contactListTable, columnValuesExpected[i]);
		}
	}

}
