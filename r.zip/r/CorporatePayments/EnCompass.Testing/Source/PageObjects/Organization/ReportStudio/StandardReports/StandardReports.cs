﻿using Common;
using Common.Utility;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EnCompass.Testing.Source.PageObjects.Organization.ReportStudio.StandardReports
{
	[PageModel(@"/ReportStudio/MyAndStandard/ViewDirectory.aspx?FolderType=STANDARD")]

	public class StandardReports : EnCompassOrgPageModel
	{
		public override string RelativeUrl => @"/ReportStudio/MyAndStandard/ViewDirectory.aspx?FolderType=STANDARD";

		public override string PageIdentifierXPath_Override => @"//li[contains(@class, 'breadcrumb-item active')][text() = 'Standard Reports']";

		public StandardReports(GlobalSettings settings) : base(settings) { }

		public void SelectActionByReportName(string reportName, string action)
		{
			var element = Driver.FindElement(By.XPath($"//h2[@class='h5 card-title']//a[normalize-space(text()) ='{reportName}']/ancestor::div[@class='card-body'][position()=1]//button[contains(@id, 'Actions')]"));
			element.JSClickWithFocus(Driver);
			var actionLink = element.FindElement(By.XPath($"..//a[contains(@id, '{action}')]"));
			actionLink.JSClickWithFocus(Driver);
		}
	}
}
