using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using Common;
using Common.PageObjects;
using Common.ScenarioConfigurations;
using Common.Utility;

namespace EnCompass.Testing.Source.PageObjects.Organization.Admin.Management 
{
	/// <summary>
	/// Auto-generated Page Model Class
	/// Navigation Paths: 
		/// [Organization Home]->Administration->Card Hierarchy->Move Cards
		/// </summary>
	[PageModel(@"/admin/management/MoveCardAccounts.aspx")]
	public partial class MoveCardAccounts : EnCompassOrgPageModel 
	{
		public override string RelativeUrl => @"/admin/management/MoveCardAccounts.aspx";
		public override string PageIdentifierXPath_Generated => @"//li[contains(@class, 'breadcrumb-item active')][text() = 'Move Cards']";

		#region Navigation
				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Create or Edit']")]
		private IWebElement _administration_CardHierarchy_MoveCards_CreateOrEdit { get; set; }
		public void NavigateTo_Administration_CardHierarchy_MoveCards_CreateOrEdit()
		{
			NavigateToMenuItem(_administration_CardHierarchy_MoveCards_CreateOrEdit);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Move Cards']")]
		private IWebElement _administration_CardHierarchy_MoveCards_MoveCards { get; set; }
		public void NavigateTo_Administration_CardHierarchy_MoveCards_MoveCards()
		{
			NavigateToMenuItem(_administration_CardHierarchy_MoveCards_MoveCards);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='History']")]
		private IWebElement _administration_CardHierarchy_MoveCards_History { get; set; }
		public void NavigateTo_Administration_CardHierarchy_MoveCards_History()
		{
			NavigateToMenuItem(_administration_CardHierarchy_MoveCards_History);
		}

		
		private void NavigateToMenuItem(IWebElement element)
		{
			Driver.Url = element.GetAttribute("href");
		}
		#endregion

		public MoveCardAccounts(GlobalSettings settings) : base(settings) { }
	}  
}
