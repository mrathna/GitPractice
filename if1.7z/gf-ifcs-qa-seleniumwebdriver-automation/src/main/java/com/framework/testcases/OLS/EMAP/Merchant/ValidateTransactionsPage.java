package com.framework.testcases.OLS.EMAP.Merchant;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.EMAP.EMAPHomePage;
import com.framework.pages.EMAP.EMAPTransactionsPage;
import com.framework.pages.OLS.common.LoginPage;

public class ValidateTransactionsPage extends BaseTest {
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "Regression" })
	public void validateAccountPage(@Optional("SP") String clientCountry, @Optional("EMAP") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  TST-SC-90-OLS Merchant Site - Transactions",
				"Login to EMAP Merchant - Read Only User and check the transaction page");
		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		EMAPHomePage emapHomePage = new EMAPHomePage(driver, test);
		EMAPTransactionsPage transactionPage = new EMAPTransactionsPage(driver, test);
		loginPage.Login("EMAP_URL", "EMAP_UN_ReadOnly_Merchant_" + clientCountry,
				"EMAP_PWD_ReadOnly_Merchant_" + clientCountry, clientName);
		//emapHomePage.checkThePresenceOfQuickLinksOnHomePage("Mer-Read-Only");

		// Footer Links - Contact Us
		emapHomePage.clickContactUsInFooterAndValidatePage();
		emapHomePage.clickHomeMenuAndValidatePage("Merc");

		// Footer Links - Exxon Mobil Corporation link
		// emapHomePage.clickExxonMobilCorporationInFooterAndValidatePage();
		// emapHomePage.clickHomeMenuAndValidatePage("Merc");

		// Footer Links - Copyright
		emapHomePage.clickCopyRightAndValidatePage(clientName);

		// Footer Links - Terms And Condition
		emapHomePage.checkThePresenceOfTermsAndConditionInFooter();

		// Footer Links - Privacy Statement
		//emapHomePage.clickPrivacyPolicyAndValidatePage();

		// Footer Links - Client Logos
		emapHomePage.clickExxonMobilLogoAndValidatePage();
	//	 emapHomePage.clickEssoLogoAndValidatePage();
		emapHomePage.clickMobilLogoAndValidatePage();

		// Transaction Settlement
		emapHomePage.clickSettlementsAndValidatePage();
		transactionPage.checkPresenceOfExportSettlementOption();
		transactionPage.checkPresenceOfSearchSettlementOption("Merc");
		transactionPage.checkPresenceOfSettlementSearchFilterFields();
		transactionPage.validateTheSettlementsTableFields();

		// Export Transaction
		emapHomePage.clickExportTransactionListAndValidate();

		if (transactionPage.checkLoginHaveTransactionDetails("Merc")) {
			emapHomePage.clickTransactionListAndValidatePage();
			boolean isTransactionPresent = transactionPage.getACardNumberWithTransaction();

			if (isTransactionPresent) {
				transactionPage.validateSearchResultsAndClickViewTransactionsOption(false);
				transactionPage.verifyTransactionDetailsHeaderTitle();
				transactionPage.validateTransactionPageFields("Merc");
			} else {
				transactionPage.selectATransactionWithoutCardAndVerify();
			}
		}

		// Logout
		loginPage.Logout();
	}
}
