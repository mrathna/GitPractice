package com.framework.testcases.AJS.BP;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.CardMaintenancePage;
import com.framework.pages.AJS.MaintainAccountPage;
import com.framework.pages.AJS.TransactionListPage;
import com.framework.pages.AJS.common.Common;
import com.framework.pages.AJS.common.IFCSHomePage;
import com.framework.pages.AJS.common.IFCSLoginPage;
import com.github.javafaker.Faker;

public class ValidateSundryAdjustmentTestCases extends BaseTest {

	@Parameters({ "clientCountry", "clientName","cardType"})
	@Test( groups = { "Regression","BusinessFlow" })
	public void ValidateSundryAdjustmentCreditedInAccount(@Optional("NZ") String clientCountry,
			@Optional("BP") String clientName, @Optional("PP") String cardType) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  BPNZ56_Cust_NZ_019_Sundry Adjustment",
				"BPNZ56_Cust_NZ_019_Sundry Adjustment");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
	    Common common = new Common(driver, test);
		MaintainAccountPage maintainAccountPage=new MaintainAccountPage(driver,test);
		
	    IFCSloginPage.login("IFCS_URL_BP", "IFCS_BP_USERNAME", "IFCS_BP_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry," ");
		IFCSHomePage.gotoApplicationAndClickApplicationMenu();
		IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);
		
		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		if(cardType.contains("Prepaid")) {
			common.chooseCustomerNoAndSearch(common.getBPPrepaidCustomerNo());
		}else {
			common.chooseCustomerNumberFromCustomerList();
		}
		
		IFCSHomePage.gotoAccountAndClickAccountDetails();
		maintainAccountPage.getAccountBalance("Account Status","Actual Balance");
		double bal=maintainAccountPage.getAccountBalance("Account Status", "Available Balance");
		// Get current Date
		String currentDate = common.getCurrentIFCSDateFromDB(clientName);
		// Get the IFCS current date
		String ifcsCurrentDate = common.enterADateValueInStatusBeginDateField("Current", currentDate);
		Faker fakerN = new Faker();
		String f_referenceNo = fakerN.number().digits(3);
		maintainAccountPage.validatePostSundryAdjustmentTransaction(clientName, ifcsCurrentDate, f_referenceNo);
		maintainAccountPage.validateBalanceCreditedForAnAccount(bal);
		IFCSHomePage.exitIFCS();
		
	}
	
	
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "Regression","BusinessFlow" })
	public void ValidateToCreateManualTransaction(@Optional("NZ") String clientCountry,
			@Optional("BP") String clientName) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  BPNZ46_Trans_NZ_005_Manual Transaction",
				"BPNZ46_Trans_NZ_005_Manual Transaction");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
        Common common = new Common(driver, test);
        CardMaintenancePage cardMaintenancePage =new CardMaintenancePage(driver, test);
        TransactionListPage transactionListPage = new TransactionListPage(driver, test);
        MaintainAccountPage maintainAccountPage=new MaintainAccountPage(driver,test);
        
		IFCSloginPage.login("IFCS_URL_BP", "IFCS_BP_USERNAME", "IFCS_BP_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry," ");
		Faker fakerN = new Faker();
		String f_referenceNo = fakerN.number().digits(3);
		String currentDate = common.getCurrentIFCSDateFromDB(clientName+clientCountry);
		// Get the IFCS current date
		String ifcsCurrentDate = common.enterADateValueInStatusBeginDateField("Current", currentDate);
		System.out.println("Date ::"+ifcsCurrentDate);
		String cardNo = common.getActiveCardsWithBalanceAndRowIndex(1);
		String cardNo2 = common.getActiveCardsWithBalanceAndRowIndex(2);
		String locationNo=common.chooseALocationWithNonFuelProduct("Y");
		String productCode=common.chooseANonFuelProductExtCodeInTheLocation(locationNo,"Y","externalCode");
		if (cardNo.equals(" ") && cardNo2.equals(" ") && locationNo.equals(" ") && productCode.equals(" ")) {
			common.logForNoDataFound(this.getClass().getSimpleName(),
					"Need to Create A Cards with Account and rerun");
		} else {
			
		IFCSHomePage.gotoApplicationAndClickApplicationMenu();
		IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);
		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		cardMaintenancePage.chooseAndSearchCardNo(cardNo);
		IFCSHomePage.gotoAccountAndClickAccountDetails();
		double beforebal=maintainAccountPage.getAccountBalance("Account Status","Actual Balance");
		//double bal=maintainAccountPage.getAccountBalance("Account Status", "Available Balance");
		System.out.println(beforebal);
		
		IFCSHomePage.gotoTransactionAndClickManageTransaction();
		//transactionListPage.validateToPostManualTransactionEntry(ifcsCurrentDate,f_referenceNo,clientCountry,cardNo,cardNo2,locationNo,productCode,true);
		transactionListPage.enterTransactionBatchDetails(true,"160","1",clientName);
		transactionListPage.enterManualTransactionDetails(ifcsCurrentDate,f_referenceNo,cardNo,cardNo2,locationNo,"160","");
		transactionListPage.enterTransactionLineItems(productCode,"160","100","160");
		transactionListPage.validatePostManualTransaction("Validation successful");
	    transactionListPage.validatePostedInTransaction(f_referenceNo);
	    double customerValue=maintainAccountPage.getAccountBalance("Header Details","Customer Value");			
		System.out.println(customerValue);	
		IFCSHomePage.gotoAccountAndClickAccountDetails();
		transactionListPage.financialState();
		double afterActualbal=maintainAccountPage.getAccountBalance("Account Status","Actual Balance");
		
		maintainAccountPage.validateTheFinancialBalance(beforebal, afterActualbal,customerValue);
			
		}
		IFCSHomePage.exitIFCS();
	
	}
	
}
