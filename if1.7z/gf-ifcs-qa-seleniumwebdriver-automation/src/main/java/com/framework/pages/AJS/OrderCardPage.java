package com.framework.pages.AJS;

import java.util.HashMap;
import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

import com.aventstack.extentreports.ExtentTest;
import com.framework.pages.AJS.common.Common;
import com.framework.pages.AJS.common.IFCSCommonPage;
import com.framework.pages.AJS.common.IFCSHomePage;
import com.framework.repo.Locator_IFCS;
import com.framework.util.PropUtils;
import com.framework.util.SeleniumWrappers;
import com.github.javafaker.Faker;

public class OrderCardPage extends Common {

	//private static final String Else = null;

	@FindBy(xpath = Locator_IFCS.CARD_NUMBER_FROM_EMBOSSEDCARD)
	public WebElement cardNumberFromEmbossCard;

	@FindBy(xpath = Locator_IFCS.EMBOSS_NAME_FROM_EMBOSSEDCARD)
	public WebElement embossNameFromEmbossCard;
	@FindBy(xpath = Locator_IFCS.Customer_SEARCH_FIRST)
	public WebElement CustomersearchFirst;

	public OrderCardPage(WebDriver driver, ExtentTest test) {
		super(driver, test);
		PageFactory.initElements(new AjaxElementLocatorFactory(driver, 15), this);
	}

	IFCSHomePage ifcsHomePage = new IFCSHomePage(driver, test);
	MaintainCustomerPage maintainCustomerPage = new MaintainCustomerPage(driver, test);

	public void verifyCard(String custNo) {
		searchTorch();
		chooseOptionFromComboPopup("Customer No", custNo);
		findRecordTorch();
		sleep(5);
		closeFindRecordTorch();
		// chooseSubMenuFromLeftPanel("Maintain Customer","Order New Card");
		// rightClick(cardTable);
		// isDisplayedThenClick(popupMenuItemAddCardTransfer,"Add Card Transfer Popup");
	}

	public void validateExpiryDate(String userName) {
		chooseSubMenuFromLeftPanel("Maintain Customer", "Order New Card");
		enterValueInTextBox("Card Offer", "Expiry Date", "41/51/4151");
		clickValidateIcon();
		verifyValidationResult("Invalid Format");
		verifyValidationResult("Date is not a valid date");
		String pastDate, futureDate;

		pastDate = getProcessedIFCSDate("past", 2, userName);
		futureDate = getProcessedIFCSDate("future", 60, userName);
		System.out.println("Past:" + pastDate);
		System.out.println("Future:" + futureDate);

		chooseSubMenuFromLeftPanel("Maintain Customer", "Order New Card");
		enterValueInTextBox("Card Offer", "Expiry Date", "31/02/2001");
		clickValidateIcon();
		verifyValidationResult("Validation failed");
		verifyValidationResult("Date must be future date");

		chooseSubMenuFromLeftPanel("Maintain Customer", "Order New Card");
		enterValueInTextBox("Card Offer", "Expiry Date", "31/02/2056");
		clickValidateIcon();
		verifyValidationResult("Validation failed");
		verifyValidationResult("Expiry date must be less than maximum for card product");
	}

	public void validateCustomerAndCardInContext(String custNo, String cardNo, String embossName) {

		IFCSHomePage ifcsHomePage = new IFCSHomePage(driver, test);
		MaintainCustomerPage maintainCustomerPage = new MaintainCustomerPage(driver, test);

		ifcsHomePage.gotoCustomerMenuCustomerDetails();
		searchTorch();
		enterValueInTextBox("Find Record", "Customer Number", custNo);

		maintainCustomerPage.chooseCardDetailsMenuCardMaintenance();
		searchTorch();
		enterValueInTextBox("Find Record", "Card Number", cardNo);

		validateHeaderLabel("Card Offer");
		maintainCustomerPage.chooseCardDetailsMenuEmbossHistory();

		String getCardNumber = getText(cardNumberFromEmbossCard);
		String getEmbossName = getText(embossNameFromEmbossCard);

		if (cardNo.equals(getCardNumber) && embossName.contains(getEmbossName)) {
			logPass("Card Number and Emboss Name are embossed in the card");
		} else {
			logFail("No card was matched and emboss name not present");
		}

	}

	public String orderNewCardAndValidate() {
		sleep(2);
		chooseSubMenuFromLeftPanel("Card Details", "Order New Card");
		sleep(3);
		String randomNumber = fakerAPI().number().digits(5);
		enterValueInTextBox("Vehicle Details", "VRN", randomNumber);
		sleep(3);
		validateCheckBoxToCheckOrUncheck("Balance", "Balance Allowed", "Checked");
		sleep(3);
		clickValidateIcon();
		sleep(3);
		verifyValidationResult("Validation successful");
		sleep(3);
		createTaskBar();
		String newOrderedCard = getValueFromProtectedTextBox("Card Offer", "Card Number");
		System.out.println("newOrderedCard No :: " + newOrderedCard);
		verifyValidationResult("Card " + newOrderedCard + " ordered");
		return newOrderedCard;

	}

	public String reissuePINCardRequest() {
		sleep(3);
		chooseSubMenuFromLeftPanel("Card Details", "Card Maintenance");
		System.out.println("Selected card Maintenance");
		// String fetchingCardNumber =getActiveCardNumberFromDB();
		String fetchingCardNumber = getActiveCardsforInterface();
		System.out.println("fetchingCardNumber::" + fetchingCardNumber);
		chooseCardNo(fetchingCardNumber);
		sleep(1);
		// cardMaintenancePage.selectFirstcardNumberInCardSearchList();
		switchTabDetails("Request Details");
		sleep(1);
		validateCheckBoxToCheckOrUncheck("New Request Details", "PIN Mailer", "Checked");
		clickCardRequest();
		clickYesButton();
		sleep(1);
		verifyValidationResult("Card Request submitted OK");
		return fetchingCardNumber;
	}

	public void clickCardRequestButton() {
		waitForElementTobeClickable(cardRequest, 30);
		isDisplayedThenClick(cardRequest, "Card Request");
	}

	// Added by mamatha

	public void orderNewStarCardFleetChevron() {
		Common common = new Common(driver, test);
		chooseSubMenuFromLeftPanel("Maintain Customer", "Order New Card");
		sleep(2);
		// chooseOptionFromDropdown("Card Product","StarCard - Dual Card - Driver
		// Card");
		enterValueInTextBox("Driver Details", "Driver Name", fakerAPI().name().firstName());
		enterValueInTextBox("Driver Details", "Short Name", fakerAPI().name().firstName());
		String driverId = fakerAPI().number().digits(3);
		enterValueInTextBox("Driver Details", "Driver Id", driverId);
		common.clickValidateIcon();
		verifyValidationResult("Validation successful");
		common.createTaskBar();

		String cardNumber;
		cardNumber = getValueFromProtectedTextBox("Card Offer", "Card Number");
		String validateCardNumber = "Card " + cardNumber + " ordered";
		System.out.println("Card Number is " + validateCardNumber);
	}
	
	/*
	 * Added by Davu - 30/04/2020
	 */
	
	public void orderNewCardWithInvalidDataChevron() {
		Common common = new Common(driver, test);
		chooseSubMenuFromLeftPanel("Maintain Customer", "Order New Card");
		sleep(2);
		// chooseOptionFromDropdown("Card Product","StarCard - Dual Card - Driver
		// Card");
		enterValueInTextBox("Card Offer", "EXPIRY DATE", "01/04/2020");
		enterValueInTextBox("Driver Details", "Driver Name", fakerAPI().name().firstName());
		enterValueInTextBox("Driver Details", "Short Name", fakerAPI().name().firstName());
		String driverId = fakerAPI().number().digits(3);
		enterValueInTextBox("Driver Details", "Driver Id", driverId);
		common.clickValidateIcon();
		verifyValidationResult("Validation failed");
		verifyValidationResult("Must be future dated");
		

		
	}
	
	public void orderNewCardWithInvalidDataWFE(String clientCountry) {
		Common common = new Common(driver, test);
		chooseSubMenuFromLeftPanel("Maintain Customer", "Order New Card");
		sleep(2);
		
		chooseARandomDropdownOption("Card Offer");
		chooseARandomDropdownOption("Card Product");
		
		//enterValueInTextBox("Card Offer", "EXPIRY DATE", "01/04/2020");
		enterValueInTextBox("Driver Details", "Driver Name", fakerAPI().name().firstName());
		enterValueInTextBox("Driver Details", "Short Name", fakerAPI().name().firstName());
		String driverId = fakerAPI().number().digits(3);
		enterValueInTextBox("Driver Details", "Driver Id", driverId);
		switchTabDetails("Profiles");
		sleep(10);
		try {
		WebElement cellElement1 = SeleniumWrappers.getTableDataWithCellElement(0, 0, driver);
		}catch(Exception e) {
		switchTabDetails("Card Details");
		sleep(5);
		common.clickValidateIcon();
			if(isValidationMessageExists("Validation successful")) {
			
				logFail("New card :Validation Success for invalid data");
			}
			else if(isValidationMessageExists("Validation Failed") || 
					isValidationMessageExists("Default Card Control Profile not defined for Card Offer.") || 
					isValidationMessageExists("Default profile must be set")) {
				logPass("No New Card ordered");
			}
		}
	}

	public void orderNewStarCardStaffChevron() {
		Common common = new Common(driver, test);
		chooseSubMenuFromLeftPanel("Maintain Customer", "Order New Card");
		chooseOptionFromDropdown("Card Product", "StarCard Staff");
		enterValueInTextBox("Driver Details", "Driver Name", fakerAPI().name().firstName());
		enterValueInTextBox("Driver Details", "Short Name", fakerAPI().name().firstName());
		String driverId = fakerAPI().number().digits(3);
		enterValueInTextBox("Driver Details", "Driver Id", driverId);
		common.clickValidateIcon();
		verifyValidationResult("Validation successful");
		common.createTaskBar();

		String cardNumber;
		cardNumber = getValueFromProtectedTextBox("Card Offer", "Card Number");
		String validateCardNumber = "Card " + cardNumber + " ordered";
		System.out.println("Card Number is " + validateCardNumber);
	}

	public void orderNewStarCardFleetForPH() {
		Common common = new Common(driver, test);
		chooseSubMenuFromLeftPanel("Maintain Customer", "Order New Card");
		chooseOptionFromDropdown("Card Product", "StarCard - Open");
		enterValueInTextBox("Driver Details", "Driver Name", fakerAPI().name().firstName());
		enterValueInTextBox("Driver Details", "Short Name", fakerAPI().name().firstName());
		String driverId = fakerAPI().number().digits(3);
		enterValueInTextBox("Driver Details", "Driver Id", driverId);
		common.clickValidateIcon();
		verifyValidationResult("Validation successful");
		common.createTaskBar();

		String cardNumber;
		cardNumber = getValueFromProtectedTextBox("Card Offer", "Card Number");
		String validateCardNumber = "Card " + cardNumber + " ordered";
		System.out.println("Card Number is " + validateCardNumber);
	}

	// Added by Ayub 14/05/2019

	public String[] orderNewCardsAndValidate(String cardType, int cardCount) {
		String cardNo[] = new String[cardCount];
		String newOrderedCard = null;
		chooseSubMenuFromLeftPanel("Card Details", "Order New Card");
		for (int num = 0; num < cardCount; num++) {
			chooseSubMenuFromLeftPanel("Card Details", "Order New Card");
			sleep(3);
			String randomNumber = fakerAPI().number().digits(10);
			String fName = fakerAPI().name().firstName();
			String licensePlate = fakerAPI().number().digits(3);
			if (cardType.equalsIgnoreCase("BP Fuelcard Driver") || cardType.equalsIgnoreCase("BP Plus cards Driver")) {
				chooseOptionFromDropdown("Card Offer", cardType);
				driver.navigate().refresh();
				enterValueInTextBox("Driver Details", "Driver Name", fName);

			} else if (cardType.equalsIgnoreCase("BP Fuelcard Vehicle")
					|| cardType.equalsIgnoreCase("BP Plus cards Vehicle")) {
				chooseOptionFromDropdown("Card Offer", cardType);
				driver.navigate().refresh();
				enterValueInTextBox("Vehicle Details", "Description", fName);
				driver.navigate().refresh();
				enterValueInTextBox("Vehicle Details", "License Plate", licensePlate);

			}
			enterValueInTextBox("Requested By", "Name", fName);
			enterValueInTextBox("Requested By", "Phone", randomNumber);
			validateTaskBar();
			sleep(3);
			verifyValidationResult("Validation successful");
			createTaskBar();
			newOrderedCard = getValueFromProtectedTextBox("Card Offer", "Card Number");
			System.out.println("newOrderedCard No :: " + newOrderedCard);
			verifyValidationResult("Card " + newOrderedCard + " ordered");
			cardNo[num] = newOrderedCard;
			System.out.println("Newly ordered cards:: :: " + cardNo[num]);
		}

		return cardNo;

	}

	public String[] concatTwoStringArrays(String[] s1, String[] s2) {
		String[] result = new String[s1.length + s2.length];
		int i;
		for (i = 0; i < s1.length; i++)
			result[i] = s1[i];
		int tempIndex = s1.length;
		for (i = 0; i < s2.length; i++)
			result[tempIndex + i] = s2[i];
		return result;
	}// concatTwoStringArrays().

	public HashMap<String, String> orderNewCardChevron(Map<String, String> appCust, String clientandCountry) {
		Common common = new Common(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		IFCSCommonPage IFCSCommonPage = new IFCSCommonPage(driver, test);
		MaintainAccountPage maintainAccountPage = new MaintainAccountPage(driver, test);
		String cardNumber;
		String custNum = "";
		String applicationType="";
		HashMap<String, String> hash_map = new HashMap<String, String>();
		for (Map.Entry<String, String> e : appCust.entrySet()) {
			applicationType = e.getKey();
			custNum = e.getValue();
			System.out.println(applicationType + "=" + custNum);
			if (applicationType.contains("StarCash")) {
				Faker fakerN = new Faker();
				String f_referenceNo = fakerN.number().digits(3);
				IFCSHomePage.gotoCustomerMenuCustomer();
				IFCSHomePage.gotoAccountAndClickAccountDetails();
				maintainAccountPage.validatePostSundryAdjustmentTransaction("CHEVRON", custNum, f_referenceNo);
				 IFCSCommonPage.postManualPayments(custNum, "random", clientandCountry);
			}
			IFCSHomePage.gotoCustomerMenuCustomer();
			sleep(3);
			common.clearingAllTextBoxes(textBoxes);
			enterValueInTextBox("Filter By", "Customer No", custNum);
			sleep(2);
			common.searchListTorch();
			doubleClick(CustomersearchFirst);
			sleep(3);
			chooseSubMenuFromLeftPanel("Maintain Customer", "Order New Card");
			sleep(5);
			if (applicationType.contains("StarCash")) {
				enterValueInTextBox("Stored Value", "Order Ref", fakerAPI().number().digits(4));
				enterValueInTextBox("Stored Value", "No of Cards", "1");
				common.clickValidateIcon();
				verifyValidationResult("Validation successful");
				sleep(1);
				common.createTaskBar();
				sleep(1);
				 cardNumber=getValueFromProtectedTextBox("Card Offer","Card Number");

				String messagedetail = returnValidationResult("Card ordered");
				// String validateCardNumber="Card "+cardNumber+" ordered";
				cardNumber = IFCSCommonPage.returnCashCardNumCHV(messagedetail);
				System.out.println("Card Number is " + cardNumber);
				common.writeDataInPropertyFile(
						"cardNo_" + applicationType.replaceAll(" ", "").replaceAll("-", "_") + "_"
								+ PropUtils.getPropValue(configProp, "clientCountry"),
						cardNumber, "chevronEndToEndTemplateFile.Properties");
				hash_map.put(custNum, cardNumber);

			} else if (applicationType.contains("Discount")) {
				 enterValueInTextBox("Vehicle Details","Description",fakerAPI().name().firstName());
				 enterValueInTextBox("Vehicle Details", "LICENSE PLATE",fakerAPI().number().digits(7));
				 enterValueInTextBox("Vehicle Details", "Vehicle Id",
				 fakerAPI().number().digits(3));
				common.clickValidateIcon();
				verifyValidationResult("Validation successful");
				common.createTaskBar();
				cardNumber = getValueFromProtectedTextBox("Card Offer", "Card Number");
				String validateCardNumber = "Card " + cardNumber + " ordered";
				System.out.println("Card Number is " + validateCardNumber);
				common.writeDataInPropertyFile(
						"cardNo_" + applicationType.replaceAll(" ", "").replaceAll("-", "_") + "_"
								+ PropUtils.getPropValue(configProp, "clientCountry"),
						cardNumber, "chevronEndToEndTemplateFile.Properties");
				hash_map.put(custNum, cardNumber);
			} else {
//				 enterValueInTextBox("Vehicle Details","Description",fakerAPI().name().firstName());
//				 enterValueInTextBox("Vehicle Details", "LICENSE PLATE",fakerAPI().number().digits(7));
//				 enterValueInTextBox("Vehicle Details", "Vehicle Id",fakerAPI().number().digits(3));
				 enterValueInTextBox("Driver Details", "Driver Name",fakerAPI().name().firstName());
				 enterValueInTextBox("Driver Details", "Short Name",fakerAPI().name().firstName());
				 enterValueInTextBox("Driver Details", "Driver Id",fakerAPI().number().digits(3));
				common.clickValidateIcon();
				verifyValidationResult("Validation successful");
				common.createTaskBar();
				cardNumber = getValueFromProtectedTextBox("Card Offer", "Card Number");
				String validateCardNumber = "Card " + cardNumber + " ordered";
				System.out.println("Card Number is " + validateCardNumber);
				hash_map.put(custNum, cardNumber);
				common.writeDataInPropertyFile(
						"cardNo_" + applicationType.replaceAll(" ", "").replaceAll("-", "_") + "_"
								+ PropUtils.getPropValue(configProp, "clientCountry"),
						cardNumber, "chevronEndToEndTemplateFile.Properties");
			}

		}
		return hash_map;
	}

	
	public void declineNewCardsAndValidate(String cardType) {
		
		chooseSubMenuFromLeftPanel("Card Details", "Order New Card");
		
			chooseSubMenuFromLeftPanel("Card Details", "Order New Card");
			sleep(3);
			
			String fName = fakerAPI().name().firstName();
			String licensePlate = fakerAPI().number().digits(3);
			if (cardType.equalsIgnoreCase("BP Fuelcard Driver") || cardType.equalsIgnoreCase("BP Plus cards Driver")) {
				chooseOptionFromDropdown("Card Offer", cardType);
				driver.navigate().refresh();
				enterValueInTextBox("Driver Details", "Driver Name", fName);

			} else if (cardType.equalsIgnoreCase("BP Fuelcard Vehicle")
					|| cardType.equalsIgnoreCase("BP Plus cards Vehicle")) {
				chooseOptionFromDropdown("Card Offer", cardType);
				driver.navigate().refresh();
				enterValueInTextBox("Vehicle Details", "Description", fName);
				driver.navigate().refresh();
				enterValueInTextBox("Vehicle Details", "License Plate", licensePlate);

			}
			
			validateTaskBar();
			sleep(3);
			verifyValidationResult("Validation failed");
			

	}
public String orderNewCardWithMonthlyFeeWFE() {
		
		sleep(2);
		chooseSubMenuFromLeftPanel("Card Details", "Order New Card");
		sleep(3);
		//String randomNumber = fakerAPI().number().digits(5);
		chooseARandomDropdownOption("Card Offer");
		sleep(3);
		/*enterValueInTextBox("Vehicle Details", "VRN", randomNumber);
		sleep(3);
		validateCheckBoxToCheckOrUncheck("Balance", "Balance Allowed", "Checked");
		sleep(3);*/
		/*enterValueInTextBox("Vehicle Details", "License Plate", fakerAPI().number().digits(5));
		sleep(3);
		enterValueInTextBox("Vehicle Details", "Description", fakerAPI().color().toString());*/
		/*enterValueInTextBox("Driver Name", "Driver Name", fakerAPI().name().toString());
		sleep(3);*/
		switchTabDetails("Profiles");
		sleep(3);
		maintainCustomerPage.createMaintainCardControlsProfileWFE();
		switchTabDetails("Card Fees");
		Common common = new Common(driver, test);
		int rownum = validateTextInDescription("Profile Selection", "Description","Monthly Card Fee");
		if(rownum==0) {
			
		} else {
		common.rightClickAndSelectProfile("Profile Selection", rownum, "Description");
		}
		switchTabDetails("Card Details");
		clickValidateIcon();
		sleep(3);
		verifyValidationResult("Validation successful");
		sleep(3);
		createTaskBar();
		String newOrderedCard = getValueFromProtectedTextBox("Card Offer", "Card Number");
		System.out.println("newOrderedCard No :: " + newOrderedCard);
		verifyValidationResult("Card " + newOrderedCard + " ordered");
		return newOrderedCard;

	}

public String orderNewCardWithPIN() {
	
	sleep(2);
	chooseSubMenuFromLeftPanel("Card Details", "Order New Card");
	sleep(3);
	chooseARandomDropdownOption("Card Offer");
	sleep(3);
	//checkAndUncheckTheCheckBox("PIN Prompt");
	switchTabDetails("Profiles");
	sleep(3);
	maintainCustomerPage.createMaintainCardControlsProfileWFE();
	switchTabDetails("Card Fees");
	Common common = new Common(driver, test);
	int rownum = validateTextInDescription("Profile Selection", "Description","Monthly Card Fee");
	if(rownum==0) {
		
	} else {
	common.rightClickAndSelectProfile("Profile Selection", rownum, "Description");
	}
	switchTabDetails("Card Details");
	clickValidateIcon();
	sleep(3);
	verifyValidationResult("Validation successful");
	sleep(3);
	createTaskBar();
	String newOrderedCard = getValueFromProtectedTextBox("Card Offer", "Card Number");
	System.out.println("newOrderedCard No :: " + newOrderedCard);
	verifyValidationResult("Card " + newOrderedCard + " ordered");
	return newOrderedCard;

}
}
