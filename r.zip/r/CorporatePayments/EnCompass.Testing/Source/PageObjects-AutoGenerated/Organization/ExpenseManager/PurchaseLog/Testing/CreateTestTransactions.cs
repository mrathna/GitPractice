using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using Common;
using Common.PageObjects;
using Common.ScenarioConfigurations;
using Common.Utility;

namespace EnCompass.Testing.Source.PageObjects.Organization.ExpenseManager.PurchaseLog.Testing 
{
	/// <summary>
	/// Auto-generated Page Model Class
	/// Navigation Paths: 
		/// [Organization Home]->Payables->Purchase Log->Create Test Transactions
		/// [Organization Home]->Payables->Accounts Payable->Create Test Transactions
		/// </summary>
	[PageModel(@"/expenseManager/PurchaseLog/Testing/CreateTestTransactions.aspx")]
	public partial class CreateTestTransactions : EnCompassOrgPageModel 
	{
		public override string RelativeUrl => @"/expenseManager/PurchaseLog/Testing/CreateTestTransactions.aspx";
		public override string PageIdentifierXPath_Generated => @"//li[contains(@class, 'breadcrumb-item active')][text() = 'Create Test Transactions' or text() = 'Single-Use Account Transactions']";

		#region Navigation
				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Purchase Logs']")]
		private IWebElement _payables_PurchaseLog_CreateTestTransactions_PurchaseLogs { get; set; }
		public void NavigateTo_Payables_PurchaseLog_CreateTestTransactions_PurchaseLogs()
		{
			NavigateToMenuItem(_payables_PurchaseLog_CreateTestTransactions_PurchaseLogs);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Create Purchase Log']")]
		private IWebElement _payables_PurchaseLog_CreateTestTransactions_CreatePurchaseLog { get; set; }
		public void NavigateTo_Payables_PurchaseLog_CreateTestTransactions_CreatePurchaseLog()
		{
			NavigateToMenuItem(_payables_PurchaseLog_CreateTestTransactions_CreatePurchaseLog);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Purchase Log Settings']")]
		private IWebElement _payables_PurchaseLog_CreateTestTransactions_PurchaseLogSettings { get; set; }
		public void NavigateTo_Payables_PurchaseLog_CreateTestTransactions_PurchaseLogSettings()
		{
			NavigateToMenuItem(_payables_PurchaseLog_CreateTestTransactions_PurchaseLogSettings);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Chargeback Reconciliation']")]
		private IWebElement _payables_PurchaseLog_CreateTestTransactions_ChargebackReconciliation { get; set; }
		public void NavigateTo_Payables_PurchaseLog_CreateTestTransactions_ChargebackReconciliation()
		{
			NavigateToMenuItem(_payables_PurchaseLog_CreateTestTransactions_ChargebackReconciliation);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Disputes']")]
		private IWebElement _payables_PurchaseLog_CreateTestTransactions_Disputes { get; set; }
		public void NavigateTo_Payables_PurchaseLog_CreateTestTransactions_Disputes()
		{
			NavigateToMenuItem(_payables_PurchaseLog_CreateTestTransactions_Disputes);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Create Single-Use Accounts']")]
		private IWebElement _payables_PurchaseLog_CreateTestTransactions_CreateSingleUseAccounts { get; set; }
		public void NavigateTo_Payables_PurchaseLog_CreateTestTransactions_CreateSingleUseAccounts()
		{
			NavigateToMenuItem(_payables_PurchaseLog_CreateTestTransactions_CreateSingleUseAccounts);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Create Test Transactions']")]
		private IWebElement _payables_PurchaseLog_CreateTestTransactions_CreateTestTransactions { get; set; }
		public void NavigateTo_Payables_PurchaseLog_CreateTestTransactions_CreateTestTransactions()
		{
			NavigateToMenuItem(_payables_PurchaseLog_CreateTestTransactions_CreateTestTransactions);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Daily Extract Files']")]
		private IWebElement _payables_PurchaseLog_CreateTestTransactions_DailyExtractFiles { get; set; }
		public void NavigateTo_Payables_PurchaseLog_CreateTestTransactions_DailyExtractFiles()
		{
			NavigateToMenuItem(_payables_PurchaseLog_CreateTestTransactions_DailyExtractFiles);
		}

		
		private void NavigateToMenuItem(IWebElement element)
		{
			Driver.Url = element.GetAttribute("href");
		}
		#endregion

		public CreateTestTransactions(GlobalSettings settings) : base(settings) { }
	}  
}
