using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using Common;
using Common.PageObjects;
using Common.ScenarioConfigurations;
using Common.Utility;

namespace EnCompass.Testing.Source.PageObjects.SuperAdmin.SuperUserManagement 
{
	/// <summary>
	/// Auto-generated Page Model Class
	/// Navigation Paths: 
		/// [Organization Home]->UserAccount->
		/// </summary>
	[PageModel(@"/superAdmin/superUserManagement/updateSuper.aspx")]
	public partial class UpdateSuper : EnCompassSuperPageModel 
	{
		public override string RelativeUrl => @"/superAdmin/superUserManagement/updateSuper.aspx";
		public override string PageIdentifierXPath_Generated => @"//li[contains(@class, 'breadcrumb-item active')][contains(text(), 'Edit')]";

		#region Navigation
		
		private void NavigateToMenuItem(IWebElement element)
		{
			Driver.Url = element.GetAttribute("href");
		}
		#endregion

		public UpdateSuper(GlobalSettings settings) : base(settings) { }
	}  
}
