using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using Common;
using Common.PageObjects;
using Common.ScenarioConfigurations;
using Common.Utility;

namespace EnCompass.Testing.Source.PageObjects.Organization.Payables.MerchantPayments 
{
	/// <summary>
	/// Auto-generated Page Model Class
	/// Navigation Paths: 
		/// [Organization Home]->Payables->Accounts Payable->Merchant Log Settings
		/// </summary>
	[PageModel(@"/payables/merchantPayments/NotifyMeMerchantLogSettings.aspx")]
	public partial class NotifyMeMerchantLogSettings : EnCompassOrgPageModel 
	{
		public override string RelativeUrl => @"/payables/merchantPayments/NotifyMeMerchantLogSettings.aspx";
		public override string PageIdentifierXPath_Generated => @"//li[contains(@class, 'breadcrumb-item active')][text() = 'Merchant Log Settings']";

		#region Navigation
				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Merchant Logs']")]
		private IWebElement _payables_AccountsPayable_MerchantLogSettings_MerchantLogs { get; set; }
		public void NavigateTo_Payables_AccountsPayable_MerchantLogSettings_MerchantLogs()
		{
			NavigateToMenuItem(_payables_AccountsPayable_MerchantLogSettings_MerchantLogs);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Create Merchant Log']")]
		private IWebElement _payables_AccountsPayable_MerchantLogSettings_CreateMerchantLog { get; set; }
		public void NavigateTo_Payables_AccountsPayable_MerchantLogSettings_CreateMerchantLog()
		{
			NavigateToMenuItem(_payables_AccountsPayable_MerchantLogSettings_CreateMerchantLog);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Merchant Log Reconciliation']")]
		private IWebElement _payables_AccountsPayable_MerchantLogSettings_MerchantLogReconciliation { get; set; }
		public void NavigateTo_Payables_AccountsPayable_MerchantLogSettings_MerchantLogReconciliation()
		{
			NavigateToMenuItem(_payables_AccountsPayable_MerchantLogSettings_MerchantLogReconciliation);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Merchant Log Settings']")]
		private IWebElement _payables_AccountsPayable_MerchantLogSettings_MerchantLogSettings { get; set; }
		public void NavigateTo_Payables_AccountsPayable_MerchantLogSettings_MerchantLogSettings()
		{
			NavigateToMenuItem(_payables_AccountsPayable_MerchantLogSettings_MerchantLogSettings);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Disputes']")]
		private IWebElement _payables_AccountsPayable_MerchantLogSettings_Disputes { get; set; }
		public void NavigateTo_Payables_AccountsPayable_MerchantLogSettings_Disputes()
		{
			NavigateToMenuItem(_payables_AccountsPayable_MerchantLogSettings_Disputes);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Merchants']")]
		private IWebElement _payables_AccountsPayable_MerchantLogSettings_Merchants { get; set; }
		public void NavigateTo_Payables_AccountsPayable_MerchantLogSettings_Merchants()
		{
			NavigateToMenuItem(_payables_AccountsPayable_MerchantLogSettings_Merchants);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Merchant Enrollment Status']")]
		private IWebElement _payables_AccountsPayable_MerchantLogSettings_MerchantEnrollmentStatus { get; set; }
		public void NavigateTo_Payables_AccountsPayable_MerchantLogSettings_MerchantEnrollmentStatus()
		{
			NavigateToMenuItem(_payables_AccountsPayable_MerchantLogSettings_MerchantEnrollmentStatus);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='EnCircle Enrollment']")]
		private IWebElement _payables_AccountsPayable_MerchantLogSettings_EncircleEnrollment { get; set; }
		public void NavigateTo_Payables_AccountsPayable_MerchantLogSettings_EncircleEnrollment()
		{
			NavigateToMenuItem(_payables_AccountsPayable_MerchantLogSettings_EncircleEnrollment);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='AR-Exchange Invoices']")]
		private IWebElement _payables_AccountsPayable_MerchantLogSettings_ArExchangeInvoices { get; set; }
		public void NavigateTo_Payables_AccountsPayable_MerchantLogSettings_ArExchangeInvoices()
		{
			NavigateToMenuItem(_payables_AccountsPayable_MerchantLogSettings_ArExchangeInvoices);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Create Single-Use Accounts']")]
		private IWebElement _payables_AccountsPayable_MerchantLogSettings_CreateSingleUseAccounts { get; set; }
		public void NavigateTo_Payables_AccountsPayable_MerchantLogSettings_CreateSingleUseAccounts()
		{
			NavigateToMenuItem(_payables_AccountsPayable_MerchantLogSettings_CreateSingleUseAccounts);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Create Test Transactions']")]
		private IWebElement _payables_AccountsPayable_MerchantLogSettings_CreateTestTransactions { get; set; }
		public void NavigateTo_Payables_AccountsPayable_MerchantLogSettings_CreateTestTransactions()
		{
			NavigateToMenuItem(_payables_AccountsPayable_MerchantLogSettings_CreateTestTransactions);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Start CLU or ECLU']")]
		private IWebElement _payables_AccountsPayable_MerchantLogSettings_StartCluOrEclu { get; set; }
		public void NavigateTo_Payables_AccountsPayable_MerchantLogSettings_StartCluOrEclu()
		{
			NavigateToMenuItem(_payables_AccountsPayable_MerchantLogSettings_StartCluOrEclu);
		}

		
		private void NavigateToMenuItem(IWebElement element)
		{
			Driver.Url = element.GetAttribute("href");
		}
		#endregion

		public NotifyMeMerchantLogSettings(GlobalSettings settings) : base(settings) { }
	}  
}
