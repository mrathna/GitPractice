﻿using Common.Utility;
using EnCompass.Testing.Source.PageObjects.Controls;
using NFluent;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace EnCompass.Testing.Source.PageObjects.Organization.Admin.Proxy
{
    public partial class CreateProxy
    {
        #region XPATH

        private const string UserProxyRadioButtonXPath = @"//input[contains(@id, 'rblTypeOfProxy_1')]";
        private const string CardProxyRadioBtnXpath = @"//input[contains(@id, 'rblTypeOfProxy_0')]";
        private const string SaveBtnXpath = @"//input[contains(@id, 'btnSave')]";
        private const string CheckProxyUserChkBoxXpath = @"//input[contains(@id, 'chkProxyUser')]";
        private const string _searchBtnXPath = @"//input[contains(@id, 'btnSearch')]";
        private const string _searchTermXPath = @"//select[contains(@id,'searchTermSelect')]";
        private const string _FilterTypeXPath = @"//div[contains(@id, 'SearchOutput')]/select[2]";
        private const string _searchValueXPath = @"//div[contains(@id,'searchTermValueInputGroup')]//input[contains(@id, 'SearchOutput_txt')]";
        private const string _selectProxyUserXPath = @"//a[contains(@id, 'SelectProxyUser')]";
        public const string _checkProxyCardCheckboxXPath = @"//input[contains(@id, 'chkProxyCard')]";
        private const string _checkProxyCardCheckboxLabelXPath = @"//label[contains(@for,'chkProxyCard')]";
        private const string _checkProxyUserCheckboxLabelXPath = @"//label[contains(@for, 'chkProxyUser')]";
        private const string _checkProxyOwnersCheckboxXPath = @"//input[contains(@id, 'ProxyOwners')]";
        private const string _checkProxyOwnersCheckboxLabelXPath = @"//label[contains(@for, 'ProxyOwners')]";
        private const string _checkAllCardsAssignedToUserCheckboxXPath = @"//input[contains(@id, 'chkProxyCards')]";
        private const string _checkAllCardsAssignedToUserCheckboxLabelXPath = @"//label[contains(@for, 'content_contents_chkProxyCards')]";
        private const string _userProxyRadiobuttonLabelXPath = @"//label[contains(@for, 'rblTypeOfProxy_1')]";
        private const string _cardProxyRadiobuttonLabelXPath = @"//label[contains(@for, 'rblTypeOfProxy_0')]";
        private const string _changeButtonXPath = @"//a[contains(@id,'lbCancel')]";
        private const string _proxyThisCardCheckboxXPath = @"//INPUT[contains(@id,'CheckboxColumnBoxActual')]";
        private const string _cancelCardProxyButtonXPath = @"//input[contains(@name, 'btnCancelCardProxy')]";
        private const string _saveCardProxyButtonXPath = @"//input[contains(@name, 'btnSaveCardProxy')]";
        private const string _resetBtnXPath = @"//input[@value='Reset']";
        private const string _searchCriteriaAddBtnXPath = @"//input[@type='button' and @value='Add']";
        private const string _topPageSizesDropdownXPath = @"//div[contains(@id,'dgCards_ctl01')]//select[contains(@id,'pageSizesDropdown')]";
        private const string _bntSelectUserXPath = @"//a[contains(@id,'rowButtons')]";
        private const string _cbAllCardsXPath = @"//input[contains(@id,'CheckboxColumnBoxActual')]";
        private const string _lblAllCardsXPath = @"//label[contains(@for,'CheckboxColumnBoxActual')]";

        #endregion

        #region IWebElements Props

        public IWebElement _searchBtn
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_searchBtnXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_searchBtn element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _searchTerm
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_searchTermXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_searchTerm element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _FilterType
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_FilterTypeXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_FilterType element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _searchValue
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_searchValueXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_searchValue element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _selectProxyUser
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_selectProxyUserXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_selectProxyUser element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _checkProxyCardCheckbox
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_checkProxyCardCheckboxXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_checkProxyCardCheckbox element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _checkProxyCardCheckboxLabel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_checkProxyCardCheckboxLabelXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_checkProxyCardCheckboxLabel element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _checkProxyUserCheckboxLabel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_checkProxyUserCheckboxLabelXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_checkProxyUserCheckboxLabel element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _checkProxyOwnersCheckbox
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_checkProxyOwnersCheckboxXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_checkProxyOwnersCheckbox element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _checkProxyOwnersCheckboxLabel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_checkProxyOwnersCheckboxLabelXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_checkProxyOwnersCheckboxLabel element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _checkAllCardsAssignedToUserCheckbox
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_checkAllCardsAssignedToUserCheckboxXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_checkAllCardsAssignedToUserCheckbox element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _checkAllCardsAssignedToUserCheckboxLabel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_checkAllCardsAssignedToUserCheckboxLabelXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_checkAllCardsAssignedToUserCheckboxLabel element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _userProxyRadiobutton
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(UserProxyRadioButtonXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_userProxyRadiobutton element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _userProxyRadiobuttonLabel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_userProxyRadiobuttonLabelXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_userProxyRadiobuttonLabel element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _cardProxyRadiobuttonLabel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_cardProxyRadiobuttonLabelXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_cardProxyRadiobuttonLabel element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _changeButton
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_changeButtonXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_changeButton element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _proxyThisCardCheckbox
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_proxyThisCardCheckboxXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_proxyThisCardCheckbox element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _cancelCardProxyButton
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_cancelCardProxyButtonXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_cancelCardProxyButton element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _saveCardProxyButton
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_saveCardProxyButtonXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_saveCardProxyButton element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _resetBtn
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_resetBtnXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_resetBtn element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _searchCriteriaAddBtn
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_searchCriteriaAddBtnXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_searchCriteriaAddBtn element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _topPageSizesDropdown
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_topPageSizesDropdownXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_topPageSizesDropdown element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _bntSelectUser
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_bntSelectUserXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_bntSelectUser element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _cbAllCards
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_cbAllCardsXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_cbAllCards element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _lblAllCards
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_lblAllCardsXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_lblAllCards element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        #endregion
        
        // We've been facing the following: sometimes the loading overlay is executed so fastly
        // that it fades away even before EncompassPageModel.WaitForFormLoadingOverlay() is called.
        // This is the method where we treat this issue when it happens in CreateProxy page.
        public override void WaitForFormLoadingOverlay(TimeSpan? tSpan = null)
        {
            try
            {
                base.WaitForFormLoadingOverlay(tSpan);
            }
            catch (NoSuchElementException)
            {
                Settings.EnCompassExtentTest.Info($"Test could not find Form Loading Overlay. Proceeding nevertheless...");
            }
            catch (WebDriverTimeoutException)
            {
                Settings.EnCompassExtentTest.Info($"Test could not Form find Loading Overlay. Proceeding nevertheless...");
            }
        }

        public void SearchBtn()
        {
            _searchBtn.JsScrollToElement(Driver);
            _searchBtn.JSClickWithFocus(Driver);
            Settings.EnCompassExtentTest.Info("Clicked on Search Button");
			this.WaitForLoad();
        }

        public void SelectProxyUser()
        {
            _selectProxyUser.JSClickWithFocus(Driver);
        }

        public void SaveBtn()
        {
            Driver.TryWaitForElementToBeVisible(By.XPath(SaveBtnXpath), out IWebElement _saveBtn);
            _saveBtn.JsScrollToElement(Driver);
            _saveBtn.JSClickWithFocus(Driver);
            this.AttachOnDemandScreenShot();
            Settings.EnCompassExtentTest.Info("Clicked on Save Button");
        }

		public void Add()
		{
			_searchCriteriaAddBtn.JSClickWithFocus(Driver);
		}

        public void ChangeBtn()
        {
            _changeButton.JSClickWithFocus(Driver);
        }

		public void ResetBtn()
		{
			_resetBtn.JSClickWithFocus(Driver);
		}

		private GridControl _selectUserProxy, _cardsGrid;
        public GridControl SelectUserProxy
        {
            get
            {
                _selectUserProxy = _selectUserProxy ??  new GridControl("dgSelectProxyUser", Driver);
                _selectUserProxy.WaitForGrid();
                return _selectUserProxy;
            }
        }

		private GridControl _selectUserToProxyGrid;
		public GridControl SelectUserToProxyGrid
		{
			get
			{
                _selectUserToProxyGrid = _selectUserToProxyGrid ?? new GridControl("dgSelectUserToProxy", Driver);
                _selectUserToProxyGrid.WaitForGrid();
                return _selectUserToProxyGrid;
            }
		}

		public void SetSearchTermByText(string whichText)
        {
            _searchTerm.WaitUntilElementIsInteractable();
            _searchTerm.SetListboxByText(whichText);
            Settings.EnCompassExtentTest.Info("Selectd search term :"+whichText);
        }

		public void SetSearchTermByValue(string whichText)
		{
			var selectElement = new SelectElement(_searchTerm);
			selectElement.SelectByValue(whichText);
		}

		public void SetFilterTypeByValue(string whichText)
        {
            var selectElement = new SelectElement(_FilterType);
            selectElement.SelectByText(whichText);
        }

        public void SetTopPageSize(string whichText)
        {
            Driver.JsScrollToBottom();            
            var selectElement = new SelectElement(_topPageSizesDropdown);
            selectElement.SelectByValue(whichText);
        }

		public GridControl CardsGrid
		{
			get {
                _cardsGrid = new GridControl("dgCards", Driver);
                _cardsGrid.WaitForGrid();
                return _cardsGrid;
            }
		}

		public string SearchValue
        {
            set
            {
                _searchValue.Clear();
                _searchValue.SendKeys(value);
            }
        }

        public void CheckProxyCard()
        {
            _checkProxyCardCheckbox.SetCheckboxStateWithLabelJS(Driver, true);
            WaitForModalToDisappear();
		}

		public void CheckProxyUser()
		{
            Driver.TryWaitForElement(By.XPath(CheckProxyUserChkBoxXpath), out IWebElement _checkProxyUserCheckbox);
            _checkProxyUserCheckbox.SetCheckboxStateWithLabelJS(Driver, true);
            WaitForModalToDisappear();
        }

		public void CheckProxyOwners()
        {
			_checkProxyOwnersCheckbox.SetCheckboxStateWithLabel(_checkProxyOwnersCheckboxLabel,true);
        }

		public void SelectRadioCardProxy()
		{
            Driver.TryWaitForElement(By.XPath(CardProxyRadioBtnXpath), out IWebElement _cardProxyRadiobutton);
            _cardProxyRadiobutton.SetRadioButtonStateWithLabel(_cardProxyRadiobuttonLabel, true);

        }

		public void SelectRadioUserProxy()
		{
            Driver.WaitFor(By.XPath(UserProxyRadioButtonXPath));
			_userProxyRadiobutton.SetRadioButtonStateWithLabelJS(Driver,true);
            WaitForFormLoadingOverlay();
		}

		public bool CheckAllCardsAssignedToUser
		{
			set { _checkAllCardsAssignedToUserCheckbox.SetCheckboxStateWithLabel(_checkAllCardsAssignedToUserCheckboxLabel, value); }
		}

		public void SelectRowByCheckboxProxyToUser(int whichRow, bool chkboxState)
		{
			IWebElement chkBoxInRow = Settings.EnCompassWebDriver.FindElement(By.XPath(SelectUserToProxyGrid._baseRowXPath + "[" + whichRow.ToString() + "]//input[@type='checkbox']"));
			chkBoxInRow.SetCheckboxStateWithLabel(null, chkboxState);
		}

		public void CheckUsersOnGrid()
        {
            Settings.EnCompassWebDriver.WaitForVisible(By.XPath("//a[text()='CardHolderUser']"));
            Settings.EnCompassWebDriver.WaitForVisible(By.XPath("//a[text()='ProgramAdminUser']"));
            Settings.EnCompassWebDriver.WaitForVisible(By.XPath("//a[text()='ProxyUser']"));
        }

        public string CheckProxyUserMessage()
        {
            //return Settings.EnCompassWebDriver.WaitForVisible(By.XPath("//table[contains(@role,'presentation')]/tbody/tr[1]/td[1]")).GetAttribute("innerText");
            
            return Settings.EnCompassWebDriver.WaitForVisible(By.XPath("//div[contains(@id,'searchContainer')]/div/div[1]/div/h2")).GetAttribute("innerText");
        }

        public string CheckProxyStep1Message()
        {
            //return Settings.EnCompassWebDriver.WaitForVisible(By.XPath("//tr[contains(@id,'SimpleSearch')]")).GetAttribute("innerText");
            return Settings.EnCompassWebDriver.WaitForVisible(By.XPath(" //div[contains(@id,'searchContainer')]/div/div[1]/div/h2")).GetAttribute("innerText");
           
        }
        public void SelectProxyThisCard()
        {
            Driver.JsScrollToBottom();
            Driver.ScrollToXPATH("//input[contains(@id,'CheckboxColumnBoxActual')]");
            _cbAllCards.SetCheckboxStateWithLabel(_lblAllCards, true);
            //Settings.EnCompassWebDriver.WaitForVisible(By.XPath("//input[contains(@id,'CheckboxColumnBoxActual')]")).JSClickWithFocus(Driver);
            //Driver.FindElement(By.XPath("//input[contains(@id,'CheckboxColumnBoxActual')]")).JSClickWithFocus(Driver);
        }

        public void CheckIfCheckedBox(IWebElement chkbox)
        {
            Driver.ScrollToXPATH("//input[contains(@id, 'chkProxyCard')]");
            Check.That(chkbox.Selected).IsEqualTo(true);
        }

        public void CheckIfUnCheckedBox(IWebElement chkbox)
        {
            Check.That(chkbox.Selected).IsEqualTo(false);
        }
        public void Cancel()
        {
            Driver.ScrollToXPATH("//input[contains(@name, 'btnCancelCardProxy')]");
            Settings.EnCompassWebDriver.WaitForVisible(By.XPath("//input[contains(@name, 'btnCancelCardProxy')]"));
            _cancelCardProxyButton.JSClickWithFocus(Driver);
        }
  
        public void Save()
        {
            Driver.ScrollToXPATH("//input[contains(@name, 'btnSaveCardProxy')]");
            Settings.EnCompassWebDriver.WaitForVisible(By.XPath("//input[contains(@name, 'btnSaveCardProxy')]")).JSClickWithFocus(Driver);
			this.AttachOnDemandScreenShot();
		}
        public string GetSuccessMessage()
        {
            return Settings.EnCompassWebDriver.WaitForVisible(By.XPath("//div[contains(@id,'SuccessMessage')]")).GetAttribute("innerText");
        }

		public void PresSelectUser()
		{
			_bntSelectUser.JSClickWithFocus(Driver, _bntSelectUserXPath, Settings);
			Settings.EnCompassExtentTest.Info("Selected the User");
		}

    }
}
