package com.framework.util;

import java.io.File;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import java.util.Set;

import org.json.simple.JSONObject;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class ControlMUtils{

	private static String token = "";
	private static List<Object> responseStatus;
	// private static String monitorPageURL;
	private static HashMap<String, String> map1;

	private static HashMap<String, String> map3;
	private static int size;
	private static String jobId = null;
	private static String jobStatus = null;
	private static String jobName_c = null;

	@SuppressWarnings("unchecked")
	public static void setSessionLoginToken(String controlMBaseUrl, String ctrlMUN, String ctrlMPWD) {

		try {
			System.out.println("---- START OF setSessionLoginToken method ---- ");

			RestAssured.baseURI = controlMBaseUrl + "/automation-api/session/login";
			RequestSpecification request = RestAssured.given().relaxedHTTPSValidation();

			JSONObject requestParams = new JSONObject();
			requestParams.put("username", ctrlMUN);
			requestParams.put("password", ctrlMPWD);

			request.header("Content-Type", "application/json");
			request.body(requestParams.toJSONString());
			Response responseToken = request.post("/");
			System.out.println("responseToken :" + request.toString());
			
			String responseBody = responseToken.getBody().asString();

			System.out.println("Response Body is =>  " + responseBody + "\n");

			int statusCode = responseToken.getStatusCode();

			if (statusCode == 200) {
				JsonPath jsonPathEvaluator = responseToken.jsonPath();
				token = jsonPathEvaluator.get("token");
			}

			else {
				token = "authentication failed";
			}

			System.out.println("Token received from Response " + token + "\n");

			System.out.println("---- END OF setSessionLoginToken method ---- ");

		} catch (Exception e) {
			System.out.println("ControlMUtils.setSessionLoginToken :" + e.getMessage());
		}

	}

	@SuppressWarnings("unchecked")
	public static String triggerJobFolderandGetRunId(String controlMBaseUrl, String foldername, String... jobname) {
		System.out.println(" ---- START OF triggerJobFolderandGetRunId method ----  ");

		String runId = null;
		try {

			if (!token.equals("authentication failed")) {
				RestAssured.baseURI = controlMBaseUrl + "/automation-api/run/order";
				RequestSpecification request = RestAssured.given().relaxedHTTPSValidation();

				JSONObject requestParams = new JSONObject();
				if(foldername.contains("eurogarage")) {
					requestParams.put("ctm", "cmfrawfe-uat");
				}else {
				requestParams.put("ctm", "cmfraifcs-uat"); // Need to confirm
				}
				requestParams.put("folder", foldername);
				requestParams.put("hold", true);

				request.header("Content-Type", "application/json");
				request.header("Accept", "application/json");
				request.header("Authorization", "Bearer " + token);

				request.body(requestParams.toJSONString());
				Response response = request.post("/");

				try {
					Thread.sleep(5000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				int statusCode = response.getStatusCode();

				if (statusCode == 200) {
					JsonPath jsonPathEvaluator = response.jsonPath();

					runId = jsonPathEvaluator.get("runId");

					System.out.println("Run Id received from Response " + runId + "\n"
							+ " END Of the method triggerJobFolderandGetRunId");

					return runId;
				} else {
					System.out.println(
							"run\\order  status code is not 200... END Of the method triggerJobFolderandGetRunId");

					return runId;
				}
			} else {
				System.out.println("Token Authentication failed. END Of the method triggerJobFolderandGetRunId");
				return runId;
			}
		} catch (Exception e) {
			System.out.println("ControlMUtils.triggerJobFolderandGetRunId :" + e.getMessage());
			return runId;
		}
	}

	public static void setRunStatus(String controlMBaseUrl, String runId) {

		System.out.println("Executing Status Job");
		try {
			if (!token.equals("authentication failed")) {
				RestAssured.baseURI = controlMBaseUrl + "/automation-api/run/status/" + runId;
				RequestSpecification httpRequest = RestAssured.given().relaxedHTTPSValidation();
				httpRequest.header("Authorization", "Bearer " + token);
				Response response = httpRequest.request(Method.GET, "/");
				System.out.println("URL is:" + RestAssured.baseURI + "\n" + httpRequest.get().getSessionId());
				responseStatus = response.jsonPath().getList("statuses");
				size = responseStatus.size();
				int statusCode = response.getStatusCode();
				if (statusCode == 200) {
					System.out.println("Correct status code returned");
				}
			} else {
				System.out.println("Token Authentication failed.");

			}
		} catch (Exception e) {
			System.out.println("ControlMUtils.getRunStatus :" + e.getMessage());
		}
	}

	@SuppressWarnings("unchecked")
	public static void setJobStatus() {

		try {

			map1 = new HashMap<String, String>();
			HashMap<String, String> res;
			for (int i = 0; i < size; i++) {
				res = (HashMap<String, String>) responseStatus.get(i);
				map1.put(res.get("jobId"), res.get("status"));

			}
		} catch (Exception e) {
			System.out.println("ControlMUtils.setJobStatus :" + e.getMessage());
		}
	}

	public static String getJobStatus() {

		String jobStatus = null;

		for (String jobId : map1.keySet()) {
			jobStatus = map1.get(jobId);
			System.out.println("---- Job Status ---- " + jobStatus);
		}

		return jobStatus;
	}

	@SuppressWarnings("unchecked")
	public static void setJobName() {

		try {
			map3 = new HashMap<String, String>();
			HashMap<String, String> nameId;
			for (int i = 0; i < size; i++) {
				nameId = (HashMap<String, String>) responseStatus.get(i);
				map3.put(nameId.get("jobId"), nameId.get("name"));

			}
		} catch (Exception e) {
			System.out.println("ControlMUtils.setJobName :" + e.getMessage());
		}
	}

	public static HashSet<String> getJobName() {
		String jobName = null;
		HashSet<String> jobNameSet = new HashSet<String>();

		for (String jobId : map3.keySet()) {

			jobName = map3.get(jobId);

			jobNameSet.add(jobName);
		}

		return jobNameSet;
	}

	public static String setJobStatusRunNow(String controlMBaseUrl, String jobName, String folderName) {

		System.out.println("Start job status as Runnow");

		//int statusCode = 0;
		String status = null;
		Response response = null;

		try {
			if (!token.equals("authentication failed")) {

				Set keys = map1.keySet();
				OuterLoop: for (Iterator i = keys.iterator(); i.hasNext();) {

					jobId = (String) i.next();
					jobStatus = (String) map1.get(jobId);
					jobName_c = (String) map3.get(jobId);
					if (jobName_c.equals(jobName)) {

						if (folderName.contains("CHV") || folderName.contains("BP") 
								||folderName.contains("EX") || folderName.contains("SH") ||folderName.contains("OT")
								||folderName.contains("ZE")) {
							//System.out.println("Inside Chevyyyyy");
							
							File batchJobsallClientsPropFile = PropUtils.getPropFile(Constants.CONFIG_DIR,Constants.BATCH_JOB_ALL_CLIENTS);
							Properties batchJobsallClientsProp = PropUtils.getProps(batchJobsallClientsPropFile);
							String value=PropUtils.getPropValue(batchJobsallClientsProp, "jobS_NotToRun");
							String jobsWithValidation=PropUtils.getPropValue(batchJobsallClientsProp, "jobS_WithValidation");
							System.out.println("values from property::"+value);
							if(value.contains(jobName)) {
								//System.out.println("Inside if::");
								System.out.println("Skipping job:::" + jobName);
								deleteJobs(controlMBaseUrl);
								status = jobStatus;
							}
							//Updated by Nithya - For VINCII File Validation
							else if(jobsWithValidation.contains(jobName)) {
								boolean fileFound = false;
								if(jobName.equals("")) {
									fileFound = filePresenceValidation(PropUtils.getPropValue(batchJobsallClientsProp, "jobValidation_VINCIIPath"), PropUtils.getPropValue(batchJobsallClientsProp, "jobValidation_VINCIIFile"),PropUtils.getPropValue(batchJobsallClientsProp, "jobValidation_Host"),PropUtils.getPropValue(batchJobsallClientsProp, "jobValidation_UN"),PropUtils.getPropValue(batchJobsallClientsProp, "jobValidation_PWD"));
								}else if(jobName.equals("")) {
									fileFound = filePresenceValidation(PropUtils.getPropValue(batchJobsallClientsProp, "jobValidation_VINCIITransPath"), PropUtils.getPropValue(batchJobsallClientsProp, "jobValidation_VINCIITransFile"),PropUtils.getPropValue(batchJobsallClientsProp, "jobValidation_Host"),PropUtils.getPropValue(batchJobsallClientsProp, "jobValidation_UN"),PropUtils.getPropValue(batchJobsallClientsProp, "jobValidation_PWD"));
								}else {
									System.out.println("No validation added for job"+jobName);
								}
							}
							else {
								//System.out.println("chevyyyyy else");
								setJobStatusAsFree(controlMBaseUrl);

								System.out.println("GetjobStatusGetjobStatus:::" + jobStatus);
								
								try {
									
									response = getJobStatus(controlMBaseUrl, jobId);
									System.out.println("Response asString:"+response.asString());
									
									System.out.println("Response getBody.asString:"+response.getBody().asString());
									
									System.out.println("Response body.asString:"+response.body().asString());
									
								} catch (InterruptedException e) {
									e.printStackTrace();
								}
								JsonPath jsonPathEvaluator = response.jsonPath();
								jobStatus = jsonPathEvaluator.get("status");
								int runCount = jsonPathEvaluator.get("numberOfRuns");
								jobName =  jsonPathEvaluator.get("name");
								
								//System.out.println("^^^^^^^^^^^^^^^^^^^^^^^^Count --> " + runCount);

								System.out.println("GetjobStatusAfter:::" + jobStatus);

								if (jobStatus.equalsIgnoreCase("Wait Condition") && runCount==0) {

									setJobToRun(controlMBaseUrl);

								} else {
									System.out.println("Jobs Automatically starts to run after freeing");
								}

								Thread.sleep(4000);
								status = jobWaitCondition(controlMBaseUrl, jobId);
								System.out.println("------ job status -----" + status);

								/*
								 * Checking Conditions Holding Jobs Deleting JObs
								 */
								if (status.equals("Ended Not OK")) {
									break OuterLoop;
								} else if (status.equals("Executing")) {
									System.out.println("Job is still Executing so that moved to nxt job");
								} else
									setJobStatusAsHold(controlMBaseUrl);
									deleteJobs(controlMBaseUrl);
							}
							System.out.println("GetjobStatusGetjobStatus:::" + jobStatus);

						} else {
							//System.out.println("Inside Commonyyyy");
							setJobStatusAsFree(controlMBaseUrl);

							System.out.println("GetjobStatusGetjobStatus:::" + jobStatus);

							try {
								
								response = getJobStatus(controlMBaseUrl, jobId);
								System.out.println("Response asString:"+response.asString());
								
								System.out.println("Response getBody.asString:"+response.getBody().asString());
								
								System.out.println("Response body.asString:"+response.body().asString());
								
							} catch (InterruptedException e) {
								e.printStackTrace();
							}
							JsonPath jsonPathEvaluator = response.jsonPath();
							jobStatus = jsonPathEvaluator.get("status");
							int runCount = jsonPathEvaluator.get("numberOfRuns");
							jobName =  jsonPathEvaluator.get("name");
							
							//System.out.println("^^^^^^^^^^^^^^^^^^^^^^^^Count --> " + runCount);

							System.out.println("GetjobStatusAfter:::" + jobStatus);

							if (jobStatus.equalsIgnoreCase("Wait Condition") && runCount==0) {

								setJobToRun(controlMBaseUrl);

							} else {
								System.out.println("Jobs Automatically starts to run after freeing");
							}

							Thread.sleep(4000);
							status = jobWaitCondition(controlMBaseUrl, jobId);
							System.out.println("------ job status -----" + status);

							/*
							 * Checking Conditions Holding Jobs Deleting JObs
							 */
							if (status.equals("Ended Not OK")) {
								break OuterLoop;
							} else if (status.equals("Executing")) {
								System.out.println("Job is still Executing so that moved to nxt job");
							} else
								setJobStatusAsHold(controlMBaseUrl);
								deleteJobs(controlMBaseUrl);
						}
					}
				}
			}

			else {
				System.out.println("Token Authentication failed.");
			}
		} catch (Exception e) {
			System.out.println("ControlMUtils.setJobStatusRunNow :" + e.getMessage());
		}
		return status;
	}

	private static void setJobToRun(String controlMBaseUrl) {
		
		System.out.println("Run Now with Job ID");
		
		System.out.println("Job ID " + jobId + " Job status " + jobStatus);

		RestAssured.baseURI = controlMBaseUrl + "/automation-api/run/job/" + jobId + "/runNow";

		RequestSpecification httpRequest = RestAssured.given().relaxedHTTPSValidation();

		httpRequest.header("Content-Type", "application/json");

		httpRequest.header("Authorization", "Bearer " + token);

		Response response = httpRequest.request(Method.POST, "/");

		
	}

	private static void deleteJobs(String controlMBaseUrl) {
		
		
		System.out.println("Before getJobName Delete***************** getJobName:::" + jobName_c);

		try {

			if (!token.equals("authentication failed")) {

				RestAssured.baseURI = controlMBaseUrl + "/automation-api/run/job/" + jobId + "/delete";
				RequestSpecification httpRequest = RestAssured.given().relaxedHTTPSValidation();

				httpRequest.header("Content-Type", "application/json");
				httpRequest.header("Authorization", "Bearer " + token);

				Response response = httpRequest.request(Method.POST, "/");

				/*try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}*/

				String responseBody = response.getBody().asString();

				System.out.println("Response Body is =>  " + responseBody + "\n");
			} else {
				System.out.println("Token Authentication failed.");
			}

		} catch (Exception e) {
			System.out.println("ControlMUtils.deleteJobsHold :" + e.getMessage());
		}
		
	}

	private static String jobWaitCondition(String controlMBaseUrl, String jobId) throws InterruptedException {
		Response response = null;

		int runCount;
		String jobName;
		long startTime = System.currentTimeMillis();
		do {
			try {
				
				response = getJobStatus(controlMBaseUrl, jobId);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			JsonPath jsonPathEvaluator = response.jsonPath();
			jobStatus = jsonPathEvaluator.get("status");
			runCount = jsonPathEvaluator.get("numberOfRuns");
			jobName =  jsonPathEvaluator.get("name");
			
			//System.out.println("^^^^^^^^^^^^^^^^^^^^^^^^Intial 1 count --> " + runCount);
			System.out.println("------Job Status --> " + jobStatus);
			System.out.println("------Job Name --> " + jobName);
			
			
			long endTime = System.currentTimeMillis();
			
			System.out.println("startTime :"+startTime);
			
			System.out.println("endTime :"+endTime);
			
			if (runCount >= 1 || jobStatus.equals("Ended Not Ok")) {
				if(endTime-startTime > 360000){
					System.out.println(jobStatus + "Job is executed more than 6 min");
					break;
				} else if (jobStatus.equals("Executing")) {
					System.out.println(jobStatus + "======= JOb Status");
					Thread.sleep(60000);
					continue;
				} else if(jobStatus.equals("Ended Not Ok")){
					System.out.println(jobStatus + "======= JOb Status");
					break;
				} else
					System.out.println(jobStatus + "======= JOb Status ");
					break;
			}
				 			
		} while (!("Ended OK".equals(jobStatus)));

		System.out.println("***** Job id is " + jobId + " ******* Job Status is " + jobStatus);

		//System.out.println("^^^^^^^^^^^^^^^^^^^Intial 2 count --> " + runCount);

		Thread.sleep(2000);

		return jobStatus;

	}

	public static void setJobStatusAsFree(String controlMBaseUrl) {

		System.out.println("Before getJobName Free***************** getJobName:::" + jobName_c);

		try {

			if (!token.equals("authentication failed")) {

				RestAssured.baseURI = controlMBaseUrl + "/automation-api/run/job/" + jobId + "/free";
				RequestSpecification httpRequest = RestAssured.given().relaxedHTTPSValidation();

				httpRequest.header("Content-Type", "application/json");
				httpRequest.header("Authorization", "Bearer " + token);

				Response response = httpRequest.request(Method.POST, "/");

		/*		try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}*/

				String responseBody = response.getBody().asString();

				System.out.println("Response Body is =>  " + responseBody + "\n");
			} else {
				System.out.println("Token Authentication failed.");
			}

		} catch (Exception e) {
			System.out.println("ControlMUtils.setJobStatusAsFree :" + e.getMessage());
		}

	}

	public static void setJobStatusSetToOk(String controlMBaseUrl) {

		try {

			if (!token.equals("authentication failed")) {

				Set keys = map1.keySet();
				for (Iterator i = keys.iterator(); i.hasNext();) {
					jobId = (String) i.next();
					jobStatus = (String) map1.get(jobId);
					System.out.println(jobId + "))))))))" + jobStatus);
					if (jobStatus.equalsIgnoreCase("Ended Not OK")) {
						System.out.println("Failure log => \n" + getJobLog(controlMBaseUrl, jobId));
						RestAssured.baseURI = controlMBaseUrl + "/automation-api/run/job/" + jobId + "/setToOk";
						RequestSpecification httpRequest = RestAssured.given().relaxedHTTPSValidation();
						httpRequest.header("Content-Type", "application/json");
						httpRequest.header("Authorization", "Bearer " + token);
						Response response = httpRequest.request(Method.POST, "/");
						try {
							getJobStatus(controlMBaseUrl, jobId);
						} catch (InterruptedException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}

						int statusCode = response.getStatusCode();
						if (statusCode == 200)
							System.out.println("Correct status code returned");
					}

				}
			} else {
				System.out.println("Token Authentication failed.");
			}
			// getJobStatus("cmfraifcs-uat:00vms");
		} catch (Exception e) {
			System.out.println("ControlMUtils.setJobStatusSetToOk :" + e.getMessage());
		}
	}

	public static String getJobId(String jobName) {
		System.out.println("Getting Job ID");
		String jobId = null;
		try {

			HashMap<String, String> res;
			for (int i = 0; i < 3; i++) {
				res = (HashMap<String, String>) responseStatus.get(i);
				if (res.get("name").equals(jobName)) {
					jobId = res.get("jobId");
				}
			}
			System.out.println("Job Id => " + jobId + "\n");
			return jobId;
		} catch (Exception e) {
			System.out.println("ControlMUtils.getJobId :" + e.getMessage());
			return jobId;
		}

	}

	public static void changeJobStatustoHold(String controlMBaseUrl, String tokenAccess) {
		System.out.println("Change JobStatus to Hold");

		try {

			if (!token.equals("authentication failed")) {

				RestAssured.baseURI = controlMBaseUrl + "/automation-api/run/job/" + jobId + "/hold";
				RequestSpecification httpRequest = RestAssured.given().relaxedHTTPSValidation();

				httpRequest.header("Content-Type", "application/json");
				httpRequest.header("Authorization", "Bearer " + tokenAccess);

				Response response = httpRequest.request(Method.POST, "/");
				String responseBody = response.getBody().asString();

				System.out.println("Response Body is =>  " + responseBody);

				int statusCode = response.getStatusCode();

				if (statusCode == 200)
					System.out.println("Correct status code returned");
			} else {
				System.out.println("Token Authentication failed.");
			}

		}

		catch (Exception e) {
			System.out.println("ControlMUtils.changeJobStatustoHold :" + e.getMessage());
		}
	}

	// Sasi
	public static void setJobStatusAsHold(String controlMBaseUrl) {

		System.out.println("Before getJobName HOLD***************** getJobName:::" + jobName_c);

		try {

			if (!token.equals("authentication failed")) {

				RestAssured.baseURI = controlMBaseUrl + "/automation-api/run/job/" + jobId + "/hold";
				RequestSpecification httpRequest = RestAssured.given().relaxedHTTPSValidation();

				httpRequest.header("Content-Type", "application/json");
				httpRequest.header("Authorization", "Bearer " + token);

				Response response = httpRequest.request(Method.POST, "/");
				/*
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}*/

				String responseBody = response.getBody().asString();

				System.out.println("Response Body is =>  " + responseBody + "\n");
			} else {
				System.out.println("Token Authentication failed.");
			}

		} catch (Exception e) {
			System.out.println("ControlMUtils.setJobStatusAsHold :" + e.getMessage());
		}

	}

	// Sasi
	public static void confrimJobStatus(String controlMBaseUrl) {

		System.out.println("Before getJobName confrim***************** getJobName:::" + jobName_c);

		try {

			if (!token.equals("authentication failed")) {

				RestAssured.baseURI = controlMBaseUrl + "/automation-api/run/job/" + jobId + "/confrim";
				RequestSpecification httpRequest = RestAssured.given().relaxedHTTPSValidation();

				httpRequest.header("Content-Type", "application/json");
				httpRequest.header("Authorization", "Bearer " + token);

				Response response = httpRequest.request(Method.POST, "/");

				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				String responseBody = response.getBody().asString();

				System.out.println("Response Body is =>  " + responseBody + "\n");
			} else {
				System.out.println("Token Authentication failed.");
			}

		} catch (Exception e) {
			System.out.println("ControlMUtils.confrimJobStatus :" + e.getMessage());
		}

	}

	/*
	 * public static void changeJobStatustoFree(String tokenAccess, String jobid) {
	 * System.out.println("Change JobStatus to Free"); RestAssured.baseURI =
	 * "https://10.80.82.11:8443/automation-api/run/job/" + jobid + "/free";
	 * RequestSpecification httpRequest =
	 * RestAssured.given().relaxedHTTPSValidation();
	 * 
	 * httpRequest.header("Content-Type", "application/json");
	 * httpRequest.header("Authorization", "Bearer " + tokenAccess);
	 * 
	 * Response response = httpRequest.post(); String responseBody =
	 * response.getBody().asString();
	 * 
	 * System.out.println("Response Body is =>  " + responseBody);
	 * 
	 * int statusCode = response.getStatusCode(); assert statusCode == 200 :
	 * "Correct status code returned"; }
	 */

	/*
	 * public static String getJobStatus(String controlMBaseUrl,String jobid) throws
	 * InterruptedException {
	 * 
	 * String jobStatus=null; int runCount;
	 * 
	 * try {
	 * 
	 * if(!token.equals("authentication failed")) {
	 * 
	 * RestAssured.baseURI = controlMBaseUrl+"/automation-api/run/job/" + jobid +
	 * "/status";
	 * 
	 * RequestSpecification httpRequest =
	 * RestAssured.given().relaxedHTTPSValidation();
	 * 
	 * httpRequest.header("Content-Type", "application/json");
	 * 
	 * httpRequest.header("Authorization", "Bearer " + token);
	 * 
	 * Response response = httpRequest.request(Method.GET, "/");
	 * 
	 * int statusCode = response.getStatusCode();
	 * 
	 * if (statusCode == 200 ) { JsonPath jsonPathEvaluator = response.jsonPath();
	 * long startTime = System.currentTimeMillis(); long endTime ; do { jobStatus =
	 * jsonPathEvaluator.get("status"); runCount =
	 * jsonPathEvaluator.get("numberOfRuns");
	 * System.out.println("$$$$$$$$$$$$$$$$$$$$$$$$Intial 1 count --> "+runCount);
	 * Thread.sleep(5000); if(jobStatus.equals("Ended Ok") ||
	 * jobStatus.equals("Ended Not Ok")) {
	 * 
	 * System.out.println(jobStatus + "======= JOb Status inside if"); break; }
	 * endTime = System.currentTimeMillis();
	 * 
	 * }while(!("Ended OK".equals(jobStatus)) && (endTime-startTime < 200000));
	 * 
	 * do { jobStatus = jsonPathEvaluator.get("status"); runCount =
	 * jsonPathEvaluator.get("numberOfRuns");
	 * System.out.println("^^^^^^^^^^^^^^^^^^^^^^^^Intial 1 count --> " + runCount);
	 * System.out.println("^^^^^^^^^^^^^^^^^^^^^^^^JOb Status --> " + jobStatus);
	 * Thread.sleep(5000); if (runCount >= 1 || jobStatus.equals("Ended Not Ok")) {
	 * if (jobStatus.equals("Executing")) { System.out.println(jobStatus +
	 * "======= JOb Status inside if"); continue; } else
	 * System.out.println(jobStatus + "======= JOb Status inside if"); break; }
	 * 
	 * } while (!("Ended OK".equals(jobStatus)));
	 * 
	 * System.out.println("***** Job id is " + jobid + " ******* Job Status is " +
	 * jobStatus);
	 * 
	 * System.out.println("^^^^^^^^^^^^^^^^^^^Intial 2 count --> "+runCount);
	 * 
	 * return jobStatus; } else {
	 * System.out.println("Status code is not 200: "+statusCode);
	 * 
	 * return null; }
	 * 
	 * } else { System.out.println("Token Authentication failed."); return
	 * jobStatus; }
	 * 
	 * } catch(Exception e) {
	 * System.out.println("ControlMUtils.getJobStatus :"+e.getMessage()); return
	 * jobStatus; } }
	 */

	public static Response getJobStatus(String controlMBaseUrl, String jobid) throws InterruptedException {

		System.out.println("Getting job Status");
		//String jobStatus = null;
		//int runCount;
		Response response = null;

		try {

			if (!token.equals("authentication failed")) {

				RestAssured.baseURI = controlMBaseUrl + "/automation-api/run/job/" + jobid + "/status";

				RequestSpecification httpRequest = RestAssured.given().relaxedHTTPSValidation();

				httpRequest.header("Content-Type", "application/json");

				httpRequest.header("Authorization", "Bearer " + token);

				response = httpRequest.request(Method.GET, "/");

				int statusCode = response.getStatusCode();

				if (statusCode == 200) {
					//JsonPath jsonPathEvaluator = response.jsonPath();
					//long startTime = System.currentTimeMillis();
					//long endTime;
					/*
					 * do { jobStatus = jsonPathEvaluator.get("status"); runCount =
					 * jsonPathEvaluator.get("numberOfRuns");
					 * System.out.println("$$$$$$$$$$$$$$$$$$$$$$$$Intial 1 count --> "+runCount);
					 * Thread.sleep(5000); if(jobStatus.equals("Ended Ok") ||
					 * jobStatus.equals("Ended Not Ok")) {
					 * 
					 * System.out.println(jobStatus + "======= JOb Status inside if"); break; }
					 * endTime = System.currentTimeMillis();
					 * 
					 * }while(!("Ended OK".equals(jobStatus)) && (endTime-startTime < 200000));
					 */

					/*
					 * do { jobStatus = jsonPathEvaluator.get("status"); runCount =
					 * jsonPathEvaluator.get("numberOfRuns");
					 * System.out.println("^^^^^^^^^^^^^^^^^^^^^^^^Intial 1 count --> " + runCount);
					 * System.out.println("^^^^^^^^^^^^^^^^^^^^^^^^JOb Status --> " + jobStatus);
					 * Thread.sleep(5000); if (runCount >= 1 || jobStatus.equals("Ended Not Ok")) {
					 * if (jobStatus.equals("Executing")) { System.out.println(jobStatus +
					 * "======= JOb Status inside if"); continue; } else
					 * System.out.println(jobStatus + "======= JOb Status inside if"); break; }
					 * 
					 * } while (!("Ended OK".equals(jobStatus)));
					 * 
					 * System.out.println("***** Job id is " + jobid + " ******* Job Status is " +
					 * jobStatus);
					 * 
					 * System.out.println("^^^^^^^^^^^^^^^^^^^Intial 2 count --> " + runCount);
					 */

					return response;
				} else {
					System.out.println("Status code is not 200: " + statusCode);

					return null;
				}

			} else {
				System.out.println("Token Authentication failed.");
				return response;
			}

		} catch (Exception e) {
			System.out.println("ControlMUtils.getJobStatus :" + e.getMessage());
			return response;
		}
	}

	public static String getJobLog(String controlMBaseUrl, String jobid) {
		System.out.println("Getting Job Log");

		try {

			if (!token.equals("authentication failed")) {

				RestAssured.baseURI = controlMBaseUrl + "/automation-api/run/job/" + jobid + "/log";

				RequestSpecification httpRequest = RestAssured.given().relaxedHTTPSValidation();

				httpRequest.header("Content-Type", "application/json");
				httpRequest.header("Authorization", "Bearer " + token);

				Response response = httpRequest.request(Method.GET, "/");

				int statusCode = response.getStatusCode();
				assert statusCode == 200 : "Correct status code returned";
				return response.getBody().asString();
			} else {
				System.out.println("Token Authentication failed.");
				return null;
			}

		} catch (Exception e) {
			System.out.println("ControlMUtils.getJobLog :" + e.getMessage());
			return null;
		}
	}
	
	public static boolean filePresenceValidation(String path,String filename,String host, String userName,String password) {
		
		return PuttyUtils.puttyConnectionAndCheckFilePresence(host, userName, password, path, filename);
		 	
	}
}
