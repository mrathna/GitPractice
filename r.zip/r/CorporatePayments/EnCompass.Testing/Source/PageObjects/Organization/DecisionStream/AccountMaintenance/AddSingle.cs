﻿using EnCompass.Testing.Source.StepDefinitions.Common;
using EnCompass.Testing.Source.PageObjects.Common;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using Common.Utility;
using EnCompass.Testing.Source.PageObjects.Controls;
using Common;
using OpenQA.Selenium.Interactions;
using NFluent;

namespace EnCompass.Testing.Source.PageObjects.Organization.DecisionStream.AccountMaintenance
{
	[PageModel(@"/decisionStream/AccountMaintenance/AddSingle.aspx")]
	public partial class AddSingle : EnCompassPageModel, IMobilePhone
	{
		public const string CellPolicyIconXPath = @"//a[contains(@id, 'lbPolicy')]";
		public const string CellPolicyHeaderXPath = @"//h1[contains(text(),'Cellular Phone')]";
		public const string CellPolicyBodyXPath = @"//body[@class = 'iframe-modal']//div[@class = 'modal-body']";
		public const string CellPolicyCloseXPath = @"//input[contains(@name, 'footerContent') and @value= 'Close']";
		public const string CellPolicyIFrameXPath = @"//iframe[contains(@src, 'CellularPolicy.aspx')]";
		public override string RelativeUrl => @"/decisionStream/AccountMaintenance/AddSingle.aspx";
		public override string PageIdentifierXPath_Override => @"//li[@class='breadcrumb-item active'][text() = 'Create Card']";
		public const string NUMBER_OF_MONTHS_EXPIRATION_LABEL_XPATH = @"//label[contains(text(),'Number of months to expiration')]";
		public const string NUMBER_OF_MONTHS_EXPIRATION_LISTBOX_XPATH = @"//div[contains(@id, 'MonthsBeforeExpirationContainer')]";
        //public const string MOBILE_PHONE_XPATH = @"//input[contains(@id,'txtMobilePhone')]";

        #region Expand Elements
        private const string AP_CARD_INFO = "CardInfo";
        private const string AP_CARD_HOLDER = "apCardholder";
        private const string AP_LIMITS = "limits";
        private const string AP_LIMITS_UPPER = "Limits";
        private const string AP_ADDENDUM = "Addendum";

        private const string ADD_ACCOUNT_Generic = "content_contents_addAccount";

        private const string processorTypeHP = "addAccountHP_acCardHP_apLimits";
        private const string processorTypeTS1 = "addAccountTS1_acCardTS1_limits";
        private const string processorTypeTS2NA = "addAccountTS2NorthAmerica_acCardTS1_aplimits";

        #endregion

        #region XPath Page Elements
        private const string _confrmXPath = @"//input[contains(@id,'cmdConfirm')]";
        private const string _activationCodeXPath = @"//input[contains(@id,'UniqueId')]";
        private const string _firstNameXPath = @"//input[contains(@id,'txtFirstName')]";
        private const string _lastNameXPath = @"//input[contains(@id,'txtLastName')]";
        private const string _legalFirstNameXPath = @"//input[contains(@id,'txtlegalFirstName')]";
        private const string _legalLastNameXPath = @"//input[contains(@id,'txtlegalLastName')]";
        private const string _ssnXPath = @"//input[contains(@id,'UniqueId')]";
        private const string _birthDateXPath = @"//input[contains(@id,'txtBirthDate')]";
        private const string _businessPhoneXPath = @"//input[contains(@id,'BusinessPhone')]";
        private const string _mobilePhoneXPath = @"//input[contains(@id,'ctlMobilePhone')]";
        private const string _addressLine1XPath = @"//input[contains(@id,'txtAddressLine1')]";
        private const string _addressLine2XPath = @"//input[contains(@id,'txtAddressLine2')]";
        private const string _cityTownXPath = @"//input[contains(@id,'txtCity')]";
        private const string _zipXPath = @"//input[contains(@id,'txtZip')]";
        private const string _emailXPath = @"//input[contains(@id, 'txtEmailAddress')]";
        private const string _numberOfMonthsToExpirationLabelXPath = @"//label[contains(text(),'Number of months to expiration')]";
        private const string _numberOfMonthsToExpirationFieldXPath = @"//div[contains(@id, 'MonthsBeforeExpirationContainer')]";
        private const string _createCardXPath = @"//input[contains(@id, 'createCard')]";
        private const string _saveXPath = @"//input[contains(@value, 'Save') or contains(@value, 'Create')]";
        private const string _workEmailLblXPath = @"//label[contains(@id, 'EmailAddressLabel')]";
        private const string _addAnotherCardXPath = @"//ul[contains(@id, 'amSuccessMessage')]/li[1]/a";
        private const string _validationSummaryMessageXPath = @"//div[contains(@id, 'ValidationSummary') and contains(@class, 'alert')]/ul";
        private const string _productTypeXPath = @"//select[contains(@id, 'cboProductCode') or contains(@id, '_ddlProductId')]";
        private const string _cellPolicyIconXPath = @"//a[contains(@id, 'lbPolicy')]";
        private const string _cellPolicyHeaderXPath = @"//h1[contains(text(),'Cellular Phone')]";
        private const string _cellPolicyBodyXPath = @"//body[@class = 'iframe-modal']//div[@class = 'modal-body']";
        private const string _cellPolicyCloseXPath = @"//input[contains(@name, 'footerContent') and @value= 'Close']";
        private const string _ddlStateXPath = @"//select[contains(@id,'ddlState')]";
        private const string _alternativePhoneXPath = @"//input[contains(@id,'HomePhone')]";
        private const string _requestedCreditLimitXPath = @"//input[contains(@id,'txtRequestedLimit')]";
        private const string __identificationNoXPath = @"//input[contains(@id,'txtIdentificationNumber')]";
        private const string _TS2CardsRequestedXPath = @"//select[contains(@id,'NumCardsReq')]";
        private const string _TS2CreditLimitXPath = @"//input[contains(@id,'txtRequestedLimit')]";
        private const string _MonthsBeforeExpirationContainerMinXPath = @"//div[contains(@id, 'MonthsBeforeExpirationContainer')]//strong[contains(@id, 'Min')]";
        private const string _MonthsBeforeExpirationContainerMaxXPath = @"//div[contains(@id, 'MonthsBeforeExpirationContainer')]//strong[contains(@id, 'Max')]";
        private const string _MonthsBeforeExpirationContainerSliderXPath = @"//div[contains(@id, 'MonthsBeforeExpirationContainer')]//div[contains(@class, 'min') and @role='slider']";
        private const string _cdtLmtXpath = "//input[contains(@id,'txtRequestedLimit') or contains(@id,'txtCreditLimit')]";
        private const string _confirmMsgXpath = "//div[contains(@id,'amInformationMessage_divMessage')]";
        private const string _generalLedgerCodeTextBoxXpath = @"//input[contains(@id,'_DefaultAccountingFields_0')]";
        private const string _costCenterTextBoxXpath = @"//input[contains(@id,'_DefaultAccountingFields_1')]";
        #endregion

        private readonly string _sameAsBusinessCheckBoxXPath = "//input[contains(@id, 'chkCopy')]";
        private readonly string _sameAsBusinessLabelXPath = "//label[contains(text(), 'Same as Business Address')]";
        private readonly string _mothersNameXPath = "//input[contains(@id, 'txtAuthorizedUserName3')]";
        private readonly string _employmentYearsXPath = "//input[contains(@id, 'txtEmploymentYears')]";
        private readonly string _employmentMonthsXPath = "//input[contains(@id, 'txtEmploymentMonths')]";
        private readonly string _confirmXPath = @"//input[contains(@id,'cmdConfirm')]";
        private readonly string _cancelXPath = @"//input[contains(@id,'cmdCancel')]";
        private readonly string _profileXPath = @"//select[contains(@id,'Profiles')]";

        #region Page Elements
        private IWebElement _confrm
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_confrmXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_confrm element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _profile
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_profileXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_profile element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _generalLedgerCode
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_generalLedgerCodeTextBoxXpath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_confrm element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _costCentre
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_costCenterTextBoxXpath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_confrm element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _activationCode
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_activationCodeXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_activationCode element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _firstName
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_firstNameXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_firstName element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _lastName
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_lastNameXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_lastName element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _legalFirstName
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_legalFirstNameXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_legalFirstName element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _legalLastName
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_legalLastNameXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_legalLastName element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _ssn
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_ssnXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_ssn element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _birthDate
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_birthDateXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_birthDate element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _businessPhone
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_businessPhoneXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_businessPhone element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _mobilePhone
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_mobilePhoneXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_mobilePhone element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _addressLine1
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_addressLine1XPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_addressLine1 element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _addressLine2
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_addressLine2XPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_addressLine2 element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _cityTown
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_cityTownXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_cityTown element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _zip
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_zipXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_zip element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _email
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_emailXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_email element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _numberOfMonthsToExpirationLabel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_numberOfMonthsToExpirationLabelXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_numberOfMonthsToExpirationLabel element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _numberOfMonthsToExpirationField
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_numberOfMonthsToExpirationFieldXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_numberOfMonthsToExpirationField element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _createCard
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_createCardXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_createCard element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _save
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_saveXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_save element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _workEmailLbl
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_workEmailLblXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_workEmailLbl element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _addAnotherCard
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_addAnotherCardXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_addAnotherCard element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _validationSummaryMessage
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_validationSummaryMessageXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_validationSummaryMessage element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _productType
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_productTypeXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_productType element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _cellPolicyIcon
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_cellPolicyIconXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_cellPolicyIcon element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _cellPolicyHeader
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_cellPolicyHeaderXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_cellPolicyHeader element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _cellPolicyBody
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_cellPolicyBodyXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_cellPolicyBody element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _cellPolicyClose
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_cellPolicyCloseXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_cellPolicyClose element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _ddlState
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_ddlStateXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_ddlState element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _alternativePhone
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_alternativePhoneXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_alternativePhone element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _requestedCreditLimit
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_requestedCreditLimitXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_requestedCreditLimit element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement __identificationNo
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(__identificationNoXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"__identificationNo element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _TS2CardsRequested
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_TS2CardsRequestedXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_TS2CardsRequested element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _TS2CreditLimit
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_TS2CreditLimitXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_TS2CreditLimit element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        #endregion

        public string TS2CardsRequested {
			set
			{
				SelectElement ddlCardsRequestued = new SelectElement(_TS2CardsRequested);
				ddlCardsRequestued.SelectByValue(value);
			}
			get
			{
				SelectElement ddlCardsRequestued = new SelectElement(_TS2CardsRequested);
				return ddlCardsRequestued.SelectedOption.ToString();
			}
		}

		public string TS2CreditLimit
		{
			set
			{
				_TS2CreditLimit.Clear();
				_TS2CreditLimit.SendKeys(value);
			}
			get
			{
				return _TS2CreditLimit.Text;
			}
		}

		public void Save()
		{
            Driver.TryWaitForElementToBeVisible(By.XPath(_saveXPath), out IWebElement _save);
            _save.JSClickWithFocus(Driver);
			Settings.EnCompassExtentTest.Info("Clicked on Save button");
			this.AttachOnDemandScreenShot();
		}

		public void CreateCard()
		{
			_createCard.JSClickWithFocus(Driver);
			Settings.EnCompassExtentTest.Info("Clicked on Create Card button");
		}

		public string ValidationSummary { get { return _validationSummaryMessage.Text; } }

		/// <summary>
		/// Set Product Type DDL value as per input
		/// </summary>
		public string SetProductTypeByText
		{
			set
			{
				var selectElement = new SelectElement(_productType);
				var cardProduct = selectElement.Options.First(c => c.Text.ToLower().Contains(value.ToLower()));
				selectElement.SelectByText(cardProduct.Text);
			}
		}

		/// <summary>
		/// Set Any value other than the selected option in the DDL
		/// </summary>
		public void SetProductTypeToAnyValueOtherThanSelectedOption()
		{
			var selectElement = new SelectElement(_productType);
			var cardProduct = selectElement.SelectedOption;
			List<IWebElement> values = selectElement.Options.ToList();
			values.Remove(cardProduct);
			Settings.EnCompassExtentTest.Info("Removed selected option from Product Type DDL - :" + cardProduct.Text);
            if (values.Count > 0)
            {
                selectElement.SelectByText(values.ElementAt(0).Text);
                Settings.EnCompassExtentTest.Info("Selected first option from Product Type DDL");
            }
            else
            {
                Settings.EnCompassExtentTest.Warning("Product Type DDL cannot be changed because we have only one option - " + cardProduct.Text);
            }
			this.AttachOnDemandScreenShot();
		}

		public string SetState
		{
			set
			{
				var selectElement = new SelectElement(_ddlState);
				selectElement.SelectByText(value);
			}
		}

		public string SetListBoxByValue
		{
			set
			{
				var selectElement = new SelectElement(_numberOfMonthsToExpirationField);
				selectElement.SelectByValue(value);
			}
		}
		public bool IsMonthsExpirationLabelPresent
		{
			get { return Driver.IsElementPresent(GetBy(() => this._numberOfMonthsToExpirationLabel)); }
		}

		public bool IsMonthsExpirationFieldPresent
		{
			get { return Driver.IsElementPresent(GetBy(() => this._numberOfMonthsToExpirationField)); }
		}

		public bool RangeValuesInListbox(string lower, string higher)
		{
			var selectElement = new SelectElement(_numberOfMonthsToExpirationField); // Get the Listbox reference
			string selectedValue = "";
			int valuePresentCount = 0;
			for (int i = Int32.Parse(lower); i <= Int32.Parse(higher); i++) // Loop through the range of values that is expected to be present in the Listbox
			{
				selectElement.SelectByValue((i).ToString()); // Set the value in Listbox
				selectedValue = selectElement.SelectedOption.Text; // Retrieve the value
				if (selectedValue == i.ToString()) // Compare the values
					valuePresentCount++; // Increment the counter of passes
			}

			return valuePresentCount.ToString().Equals(higher); // Return the expected value
		}
		public bool SliderRangeValues(string lower, string higher)
		{
			// Get the Lower Limit Value based off the actual Slider Element.
			string lowerLimitInUI = Driver.FindElement(By.XPath(_MonthsBeforeExpirationContainerMinXPath)).Text.Trim();
			string higherLimitInUI = Driver.FindElement(By.XPath(_MonthsBeforeExpirationContainerMaxXPath)).Text.Trim();

			// Get the actual CIRCLE slider ball reference.
			//IWebElement actualCircleSlider = _numberOfMonthsToExpirationField.FindElement(By.XPath(@"//div[contains(@class, 'min') and @role='slider']"));
			IWebElement actualCircleSlider = Driver.FindElement(By.XPath(_MonthsBeforeExpirationContainerSliderXPath));

			Actions act = new Actions(Driver);

			string selectedValue = "";
			int valuePresentCount = 0;

			for (int i = Int32.Parse(lower) + 1; i <= Int32.Parse(higher); i++) // Loop through the range of values that is expected to be present in the Listbox
			{
				act.MoveToElement(actualCircleSlider).Perform();
				actualCircleSlider.Click();
				actualCircleSlider.SendKeys(Keys.ArrowRight);
				this.RefreshModel();

				selectedValue = actualCircleSlider.GetAttribute("aria-valuenow").Trim();

				if (selectedValue == i.ToString()) // Compare the values
					valuePresentCount++; // Increment the counter of passes
			}

			return (valuePresentCount + 1).ToString().Equals(higher); // Return the expected value
		}


		public string ActivationCode
		{
			set
			{
				_activationCode.WaitUntilElementIsInteractable();
				_activationCode.Clear();
				_activationCode.SendKeys(value);
				Settings.EnCompassExtentTest.Info("ActivationCode = " + value);
			}
		}

		public string FirstName
		{
			set
			{
				_firstName.WaitUntilElementIsInteractable();
				_firstName.Clear();
				_firstName.SendKeys(value);
				Settings.EnCompassExtentTest.Info("FirstName = " + value);
			}
		}

		public string LastName
		{
			set
			{
				_lastName.WaitUntilElementIsInteractable();
				_lastName.Clear();
				_lastName.SendKeys(value);
				Settings.EnCompassExtentTest.Info("LastName = " + value);
			}
		}

        public string LegalFirstName
        {
            set
            {
                _legalFirstName.WaitUntilElementIsInteractable();
                _legalFirstName.Clear();
                _legalFirstName.SendKeys(value);
                Settings.EnCompassExtentTest.Info("LegalFirstName = " + value);
            }
        }

        public string LegalLastName
        {
            set
            {
                _legalLastName.WaitUntilElementIsInteractable();
                _legalLastName.Clear();
                _legalLastName.SendKeys(value);
                Settings.EnCompassExtentTest.Info("LegalLastName = " + value);
            }
        }

        public string SSN
		{
			set
			{
				_ssn.WaitUntilElementIsInteractable();
				_ssn.Clear();
				_ssn.SendKeys(value);
				Settings.EnCompassExtentTest.Info("SSN = " + value);
			}
		}

		public string BusinessPhone
		{
			set
			{
				_businessPhone.Clear();
				_businessPhone.SendKeys(value);
				Settings.EnCompassExtentTest.Info("BusinessPhone = " + value);
			}
		}

		public string MobilePhone
		{
			set
			{
				_mobilePhone.Clear();
				_mobilePhone.SendKeys(value);
				Settings.EnCompassExtentTest.Info("MobilePhone = " + value);
			}
		}

		public string AlternativePhone
		{
			set
			{
				_alternativePhone.Clear();
				_alternativePhone.SendKeys(value);
				Settings.EnCompassExtentTest.Info("AlternativePhone = " + value);
			}
		}

		public bool HasMobilePhone
		{
			get
			{
				return Driver.IsElementPresent(GetBy(() => this._mobilePhone));
			}
		}

		public string AddressLine1
		{
			set
			{
				_addressLine1.Clear();
				_addressLine1.SendKeys(value);
				Settings.EnCompassExtentTest.Info("AddressLine1 = " + value);
			}
		}

		public string AddressLine2
		{
			set
			{
				_addressLine2.Clear();
				_addressLine2.SendKeys(value);
				Settings.EnCompassExtentTest.Info("AddressLine2 = " + value);
			}
		}

		public string CityTown
		{
			set
			{
				_cityTown.Clear();
				_cityTown.SendKeys(value);
				Settings.EnCompassExtentTest.Info("CityTown = " + value);
			}
		}

		public string Zip
		{
			set
			{
				_zip.Clear();
				_zip.SendKeys(value);
				Settings.EnCompassExtentTest.Info("Zip = " + value);
			}
		}

        public bool SetSameAsBussiness
        {
            set
            {
                Driver.TryWaitForElement(By.XPath(_sameAsBusinessCheckBoxXPath), out IWebElement _sameAsBusinessCheckBox);
                Driver.TryWaitForElementToBeVisible(By.XPath(_sameAsBusinessLabelXPath), out IWebElement _sameAsBusinessLabel);
                _sameAsBusinessCheckBox.SetCheckboxStateWithLabel(_sameAsBusinessLabel, value);
                Settings.EnCompassExtentTest.Info($"Same as Business Address set to {value}");
            }
        }

        public string MothersMaidenName
        {
            set
            {
                Driver.TryWaitForElementToBeVisible(By.XPath(_mothersNameXPath), out IWebElement _mothersName);
                _mothersName.Clear();
                _mothersName.SendKeys(value);
                Settings.EnCompassExtentTest.Info("Mother's maiden name = " + value);
            }
        }

        public string YearsEmployment
        {
            set
            {
                Driver.TryWaitForElementToBeVisible(By.XPath(_employmentYearsXPath), out IWebElement _employmentYears);
                _employmentYears.Clear();
                _employmentYears.SendKeys(value);
                Settings.EnCompassExtentTest.Info("Years of Employment = " + value);
            }
        }

        public string MonthsEmployment
        {
            set
            {
                Driver.TryWaitForElementToBeVisible(By.XPath(_employmentMonthsXPath), out IWebElement _employmentMonths);
                _employmentMonths.Clear();
                _employmentMonths.SendKeys(value);
                Settings.EnCompassExtentTest.Info("Months of Employment = " + value);
            }
        }

        private static string _toggleXpath = "//button[contains(@id,'CardsRequested')]";
		private static string _numCardTxtBoxXpath = "//input[contains(@id,'CardsRequested')]";
		private static string _numCardsRBXpath = $"//input[contains(@id,'rbCardsToIssue_{0}')]";
		private static string _numCardsRBLabelXpath = $"//label[contains(@for,'rbCardsToIssue_{0}')]";
		public string NumCardRequested
		{
			set
			{
				// if its CBKC then this field is a Radio Button
				if (GlobalSettings.FI.Equals(StringKeys.FI.COMMERCE.ToString()))
				{
					IWebElement numCardRqstdRadioButton = null;
					if (Driver.TryWaitForElement(By.XPath(String.Format(_numCardsRBXpath, value)), out numCardRqstdRadioButton, TimeSpan.FromSeconds(5)))
					{
						IWebElement numCardRqstdRadioButtonLabel = Driver.FindElement(By.XPath(String.Format(_numCardsRBLabelXpath,value)));
						numCardRqstdRadioButton.SetRadioButtonStateWithLabel(numCardRqstdRadioButtonLabel, true);
						Settings.EnCompassExtentTest.Info("Selected the Radio Button for Number cards to be orderd as :" + value);
					}
				}
				else
				{
					IWebElement numCardRqstd = null;
					// Try to toggle to bring text box only if its not visible by default
					if (!Driver.TryWaitForElementToBeVisible(By.XPath(_numCardTxtBoxXpath), out numCardRqstd, TimeSpan.FromSeconds(5)))
					{
						Settings.EnCompassExtentTest.Info("Slider is visible to indicate No of Cards, need to toggle to bring text box in view");
						Check.That(Driver.TryWaitForElement(By.XPath(_toggleXpath), out IWebElement toggle, TimeSpan.FromSeconds(10))).IsTrue();
						Settings.EnCompassExtentTest.Info("Got toggle webelement");
						toggle.JSClickWithFocus(Driver);
						Settings.EnCompassExtentTest.Info("Clicked on toggle webelement");
						Check.That(Driver.TryWaitForElementToBeVisible(By.XPath(_numCardTxtBoxXpath), out numCardRqstd, TimeSpan.FromSeconds(10))).IsTrue();
						Settings.EnCompassExtentTest.Info("Got Txt box to enter number of Cards");
					}
					numCardRqstd.Clear();
					numCardRqstd.SendKeys(value);
					Settings.EnCompassExtentTest.Info("Entered the Number cards to be orderd as :" + value);
				}
			}
		}

		public string CreditLimit
		{
			set
			{
				Driver.TryWaitForElementToBeVisible(By.XPath(_cdtLmtXpath), out IWebElement _creditLimit, TimeSpan.FromSeconds(10));
				_creditLimit.Clear();
				_creditLimit.SendKeys(value);
				Settings.EnCompassExtentTest.Info("Entered Credit Limit = " + value);
			}
		}

		public string ConfirmMessage
		{
			get
			{
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_confirmMsgXpath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_confirmMsg element exist is {found}");
                Check.That(found).IsTrue();
                return element.Text;
			}
		}

		public string RequestedCreditLimit
		{
			set
			{
				_requestedCreditLimit.Clear();
				_requestedCreditLimit.SendKeys(value);
			}
		}

		public string IdentificationNumber
		{
			set
			{
				__identificationNo.Clear();
				__identificationNo.SendKeys(value);
			}
		}

		public string Email
		{
			set
			{
				_email.WaitUntilElementIsInteractable();
				_email.Clear();
				_email.SendKeys(value);
			}
		}

		public string WorkEmailLbl
		{
			get
			{
				return _workEmailLbl.Text;
			}
		}

		public string BirthDate
		{		
			set
			{
				try
				{
					_birthDate.Clear();
					_birthDate.SendKeys(value);
					Settings.EnCompassExtentTest.Info("BirthDate = " + value);
				}
				catch (Exception) { Settings.EnCompassExtentTest.Warning("Birth Date Field is absent."); }
			}		
        }


		public void Confirm()
		{
            Driver.TryWaitForElementToBeVisible(By.XPath(_confirmXPath), out IWebElement _confirm);
            _confirm.JSClickWithFocus(Driver);
			Settings.EnCompassExtentTest.Info("Clicked on Confirm button");
		}

		public void AddAnotherCard()
		{
			_addAnotherCard.JSClickWithFocus(Driver);
		}
		public AddSingle(GlobalSettings settings) : base(settings) { }

		public string CellPolicyToolTip
		{
			get
			{
				return _cellPolicyIcon.GetAttribute("title");
			}
		}

		public string CellPolicyHeader
		{
			get
			{
				return _cellPolicyHeader.Text;
			}
		}

		public string CellPolicyBody
		{

			get
			{
				WaitForCellPolicyIFrame();

				using (var helper = new FrameHelper(Driver))
				{
					var element = helper.FindElement(By.XPath(CellPolicyBodyXPath), TimeSpan.FromSeconds(5));
					if (element != null)
					{
						var text = element.Text;
						return text;
					}
					else
					{
						throw new Exception("Could not locate 'Cell Policy Body'.");
					}
				}
			}
		}
		private void WaitForCellPolicyIFrame()
		{
			Driver.WaitForVisible(By.XPath(CellPolicyIFrameXPath));
			Driver.WaitForDocumentLoadToComplete();
		}

		public bool IsCellPolicyVisible
		{
			get
			{
				return _cellPolicyHeader.Displayed;
			}
		}

		public void ShowCellPolicy()
		{
			Driver.WaitForDocumentLoadToComplete();
			_cellPolicyIcon.WaitUntilElementIsInteractable();
			_cellPolicyIcon.JSClickWithFocus(Driver);
		}

		public void HideCellPolicy()
		{
			Actions act = new Actions(Driver);
			act.SendKeys(Keys.Escape);
		}

        public void ExpandLimits()
        {
            // Masking the exception because the Limits XPath changes depends on the FI
            try
            {
                ExpandCardHeader(ADD_ACCOUNT_Generic, AP_LIMITS);
            }
            catch
            {
                Settings.EnCompassExtentTest.Info("AP_LIMITS is not found hence trying with AP_LIMITS_UPPER xpath");
                ExpandCardHeader(ADD_ACCOUNT_Generic, AP_LIMITS_UPPER);
            }
            
            Settings.EnCompassExtentTest.Info("Expanded Limits Section");
		}

        public void ExpandCardholder()
		{
            //Changed to the generic method
            ExpandCardHeader(ADD_ACCOUNT_Generic, AP_CARD_HOLDER);
			Settings.EnCompassExtentTest.Info("Expanded CardHolder Section");
		}
        
		public void ExpandCard()
		{
            //Changed to the generic method
            ExpandCardHeader(ADD_ACCOUNT_Generic, AP_CARD_INFO);
            Settings.EnCompassExtentTest.Info("Expanded Cards Section");
		}

        public void ExpandAddendum()
        {
                ExpandCardHeader(ADD_ACCOUNT_Generic, AP_ADDENDUM);
                WaitForFormLoadingOverlay();
                Settings.EnCompassExtentTest.Info("Expanded Addendum Section");
        }

        public void Cancel()
        {
            Driver.TryWaitForElementToBeVisible(By.XPath(_cancelXPath), out IWebElement _cancel);
            _cancel.JSClickWithFocus(Driver);
            Settings.EnCompassExtentTest.Info("Clicked on Cancel button");
        }

        public void enterGeneralLedgerCode(string FinancialCodeValue)
        {
            _generalLedgerCode.Clear();
            _generalLedgerCode.SendKeys(FinancialCodeValue);
            Settings.EnCompassExtentTest.Info($"Entered Financial Code value: {FinancialCodeValue}");
        }

        public void enterCostCentre(string FinancialCodeValue)
        {
            _costCentre.Clear();
            _costCentre.SendKeys(FinancialCodeValue);
            Settings.EnCompassExtentTest.Info($"Entered Financial Code value: {FinancialCodeValue}");
        }

        public string SetProfile
        {
            set
            {
                SelectElement lstProfile = new SelectElement(_profile);
                lstProfile.SelectByText(value);
                Settings.EnCompassExtentTest.Info($"Selected Profile as: {value}");
            }
        }

        public bool validateAddendumSection(string FinancialCodeValues)
        {
            bool flag = false;

            if (FinancialCodeValues.Contains(_generalLedgerCode.GetAttribute("value")) && FinancialCodeValues.Contains(_costCentre.GetAttribute("value")))
                flag = true;

            return flag;
        }

        public bool Profile(string fincodeGroup)
        {
            bool flag = false;
            if (_profile.Text.Contains(fincodeGroup))
                flag = true;
            return flag;
          
        }

    }
}
