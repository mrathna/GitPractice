﻿using Common;
using Common.Utility;
using NFluent;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EnCompass.Testing.Source.PageObjects.Organization.ExpenseManager.Transactions
{
    [PageModel(@"/expenseManager/transactions/transactionDispute.aspx")]
    public class TransactionDispute : EnCompassOrgPageModel
    {
        public override string RelativeUrl => @"/expenseManager/transactions/transactionDispute.aspx";
        public override string PageIdentifierXPath_Override => @"//div[@class='crumb_selected_content'][text() = 'Dispute Transaction']";

        public TransactionDispute(GlobalSettings settings) : base(settings) { }

        #region XPath page Elements

        private const string _otherPaymentRadioXPath = @"//input[contains(@id,'rbOtherPayment1') and @value='rbOtherPayment1']";
        private const string _otherPaymentCashRadioXPath = @"//input[contains(@id,'rbOtherPayment1') and @value='rbOtherPayment1_Cash']";
        private const string _btnSubmitXPath = @"//input[contains(@id,'btnSubmit')]";
        #endregion

        #region Page Elements

        private IWebElement _otherPaymentRadio
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_otherPaymentRadioXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_otherPaymentRadio element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _otherPaymentCashRadio
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_otherPaymentCashRadioXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_otherPaymentCashRadio element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _btnSubmit
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_btnSubmitXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_btnSubmit element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        #endregion

        public void FillFormSimplePathAndSubmit()
        {
            _otherPaymentRadio.JSClickWithFocus(Driver);
            WaitForLoad();
            _otherPaymentCashRadio.JSClickWithFocus(Driver);
            _btnSubmit.JSClickWithFocus(Driver);
            ConfirmOnModal();
        }

    }
}
