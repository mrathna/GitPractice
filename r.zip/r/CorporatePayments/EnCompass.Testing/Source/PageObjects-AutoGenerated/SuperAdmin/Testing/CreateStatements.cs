using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using Common;
using Common.PageObjects;
using Common.ScenarioConfigurations;
using Common.Utility;

namespace EnCompass.Testing.Source.PageObjects.SuperAdmin.Testing 
{
	/// <summary>
	/// Auto-generated Page Model Class
	/// Navigation Paths: 
		/// [Organization Home]->General->Testing->Create Test Statements
		/// </summary>
	[PageModel(@"/superAdmin/testing/CreateStatements.aspx")]
	public partial class CreateStatements : EnCompassSuperPageModel 
	{
		public override string RelativeUrl => @"/superAdmin/testing/CreateStatements.aspx";
		public override string PageIdentifierXPath_Generated => @"//li[contains(@class, 'breadcrumb-item active')][text() = 'Create Test Statements']";

		#region Navigation
				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Create Organization']")]
		private IWebElement _general_Testing_CreateTestStatements_CreateOrganization { get; set; }
		public void NavigateTo_General_Testing_CreateTestStatements_CreateOrganization()
		{
			NavigateToMenuItem(_general_Testing_CreateTestStatements_CreateOrganization);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Create Organization Profile']")]
		private IWebElement _general_Testing_CreateTestStatements_CreateOrganizationProfile { get; set; }
		public void NavigateTo_General_Testing_CreateTestStatements_CreateOrganizationProfile()
		{
			NavigateToMenuItem(_general_Testing_CreateTestStatements_CreateOrganizationProfile);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Delete Test Organization']")]
		private IWebElement _general_Testing_CreateTestStatements_DeleteTestOrganization { get; set; }
		public void NavigateTo_General_Testing_CreateTestStatements_DeleteTestOrganization()
		{
			NavigateToMenuItem(_general_Testing_CreateTestStatements_DeleteTestOrganization);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Create Test Company']")]
		private IWebElement _general_Testing_CreateTestStatements_CreateTestCompany { get; set; }
		public void NavigateTo_General_Testing_CreateTestStatements_CreateTestCompany()
		{
			NavigateToMenuItem(_general_Testing_CreateTestStatements_CreateTestCompany);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Corporate Credit Limit']")]
		private IWebElement _general_Testing_CreateTestStatements_CorporateCreditLimit { get; set; }
		public void NavigateTo_General_Testing_CreateTestStatements_CorporateCreditLimit()
		{
			NavigateToMenuItem(_general_Testing_CreateTestStatements_CorporateCreditLimit);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Create Bounce Notification']")]
		private IWebElement _general_Testing_CreateTestStatements_CreateBounceNotification { get; set; }
		public void NavigateTo_General_Testing_CreateTestStatements_CreateBounceNotification()
		{
			NavigateToMenuItem(_general_Testing_CreateTestStatements_CreateBounceNotification);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Reset Merchant Log Error']")]
		private IWebElement _general_Testing_CreateTestStatements_ResetMerchantLogError { get; set; }
		public void NavigateTo_General_Testing_CreateTestStatements_ResetMerchantLogError()
		{
			NavigateToMenuItem(_general_Testing_CreateTestStatements_ResetMerchantLogError);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Performance']")]
		private IWebElement _general_Testing_CreateTestStatements_Performance { get; set; }
		public void NavigateTo_General_Testing_CreateTestStatements_Performance()
		{
			NavigateToMenuItem(_general_Testing_CreateTestStatements_Performance);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='AP Non-Card Payments Testing']")]
		private IWebElement _general_Testing_CreateTestStatements_ApNonCardPaymentsTesting { get; set; }
		public void NavigateTo_General_Testing_CreateTestStatements_ApNonCardPaymentsTesting()
		{
			NavigateToMenuItem(_general_Testing_CreateTestStatements_ApNonCardPaymentsTesting);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Modify Merchant Log']")]
		private IWebElement _general_Testing_CreateTestStatements_ModifyMerchantLog { get; set; }
		public void NavigateTo_General_Testing_CreateTestStatements_ModifyMerchantLog()
		{
			NavigateToMenuItem(_general_Testing_CreateTestStatements_ModifyMerchantLog);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Test Templates']")]
		private IWebElement _general_Testing_CreateTestStatements_TestTemplates { get; set; }
		public void NavigateTo_General_Testing_CreateTestStatements_TestTemplates()
		{
			NavigateToMenuItem(_general_Testing_CreateTestStatements_TestTemplates);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Create Test Statements']")]
		private IWebElement _general_Testing_CreateTestStatements_CreateTestStatements { get; set; }
		public void NavigateTo_General_Testing_CreateTestStatements_CreateTestStatements()
		{
			NavigateToMenuItem(_general_Testing_CreateTestStatements_CreateTestStatements);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Contact Us']")]
		private IWebElement _general_Testing_CreateTestStatements_ContactUs { get; set; }
		public void NavigateTo_General_Testing_CreateTestStatements_ContactUs()
		{
			NavigateToMenuItem(_general_Testing_CreateTestStatements_ContactUs);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Dispute Transaction']")]
		private IWebElement _general_Testing_CreateTestStatements_DisputeTransaction { get; set; }
		public void NavigateTo_General_Testing_CreateTestStatements_DisputeTransaction()
		{
			NavigateToMenuItem(_general_Testing_CreateTestStatements_DisputeTransaction);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Terms and Conditions']")]
		private IWebElement _general_Testing_CreateTestStatements_TermsAndConditions { get; set; }
		public void NavigateTo_General_Testing_CreateTestStatements_TermsAndConditions()
		{
			NavigateToMenuItem(_general_Testing_CreateTestStatements_TermsAndConditions);
		}

		
		private void NavigateToMenuItem(IWebElement element)
		{
			Driver.Url = element.GetAttribute("href");
		}
		#endregion

		public CreateStatements(GlobalSettings settings) : base(settings) { }
	}  
}
