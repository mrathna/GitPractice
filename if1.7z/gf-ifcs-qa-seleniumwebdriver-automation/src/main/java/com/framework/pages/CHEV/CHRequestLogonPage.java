package com.framework.pages.CHEV;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.ExtentTest;
import com.framework.basepage.BasePage;
import com.framework.repo.Locator;

public class CHRequestLogonPage extends BasePage {

	@FindBy(how = How.XPATH, using = Locator.SCHEDULE_REPORT_MAINTENANCE_PAGE)
	public WebElement pageTitle;

	@FindBy(how = How.ID, using = Locator.CH_REQ_LOGON_ACC_NO)
	public WebElement accountNo;

	@FindBy(how = How.ID, using = Locator.CH_REQ_LOGON_ADDR)
	public WebElement address;

	@FindBy(how = How.ID, using = Locator.CH_REQ_LOGON_POSTAL_CODE)
	public WebElement postalCode;

	@FindBy(how = How.ID, using = Locator.CH_REQ_LOGON_FIRST_NAME)
	public WebElement firstName;

	@FindBy(how = How.ID, using = Locator.CH_REQ_LOGON_LAST_NAME)
	public WebElement lastName;

	@FindBy(how = How.ID, using = Locator.CH_REQ_LOGON_EMAIL)
	public WebElement email;

	@FindBy(how = How.ID, using = Locator.CH_REQ_LOGON_PHONE)
	public WebElement phoneNo;

	@FindBy(how = How.ID, using = Locator.CH_REQ_LOGON_SUBMIT_BTN)
	public WebElement submitButton;

	@FindBy(how = How.ID, using = Locator.CONFIRMATIONMESSAGE)
	public WebElement confirmationMsg;
	
	@FindBy(how = How.ID, using = Locator.ACCOUNT_NUMBER)
	public WebElement accountNumber;
	
	@FindBy(how = How.ID, using = Locator.FULL_NAME_CONTACTUS)
	public WebElement fullName;
	
	@FindBy(how = How.ID, using = Locator.EMAIL_FIELD_CONTACUS)
	public WebElement emailField;
	
	@FindBy(how = How.XPATH, using = Locator.CUSTOMER_OPTION)
	public WebElement customerMenu;
	
	@FindBy(how = How.XPATH, using = Locator.USER_TYPE_DROPDOWN)
	public WebElement userCountryTypeDropdown;
	
	@FindBy(how = How.XPATH, using = Locator.USER_TYPE_OPTION)
	public WebElement userTypeSelection;
	
	@FindBy(how = How.XPATH, using = Locator.SUBMIT_OPTION)
	public WebElement submitOption;
	
	@FindBy(how = How.XPATH, using = Locator.ERROR_MESSAGE)
	public WebElement errorMessageValidation;
	
	@FindBy(how = How.XPATH, using = Locator.CONTACT_US_PAGE)
	public WebElement pageHeader;

	@FindBy(how = How.XPATH, using = Locator.USER_TYPE_DROPDOWN_LIST)
	public WebElement userTypeDropdown;
	
	
	

	public CHRequestLogonPage(WebDriver driver, ExtentTest test) {
		super(driver, test);
		PageFactory.initElements(driver, this);
	}

	public void verifyTitle() {	
		sleep(5);
		if (pageHeader.isDisplayed()) {
			verifyText(pageHeader, "Request Logon Form - Singapore");
			sleep(3);
		} else {
			logFail("Log On Request is not displayed");
		}
	}

	public void enterDetails() {
		
		// TODO Change this when you have read account Number
		// enterText(accountNo, accountNumber);
		enterText(accountNo, fakerAPI().number().digits(9));
		enterText(address, fakerAPI().address().fullAddress());
		enterText(postalCode, fakerAPI().address().zipCode());
		enterText(firstName, fakerAPI().address().firstName());
		enterText(lastName, fakerAPI().address().lastName());
		enterText(email, fakerAPI().address().lastName() + "@gmail.com");
		enterText(phoneNo, fakerAPI().phoneNumber().cellPhone());
	}

	public void clickSubmitBtn() {
		if (submitButton.isDisplayed()) {
			actionClick(submitButton);
			logPass("Submit is displayed");
		} else {
			logFail("Submit is not displayed");
		}
	}

	public void verifyConfirmationMessage() {
		String expectedMessage = "Your request for a new StarCard Online logon has been successfully submitted";
		sleep(5);
		System.out.println(confirmationMsg.getText());
		if (confirmationMsg.isDisplayed()) {
			if (confirmationMsg.getText().contains(expectedMessage)) {
				logPass("Confirmation Message is displayed");
			} else {
				logFail("Confirmation Message is not displayed");
			}

		} else {
			logFail("Confirmation Message is not displayed");
		}
	}
	
	public void enterDetailsAndVerifyMessage() {
		enterText(accountNumber, fakerAPI().number().digits(9));
		enterText(fullName, fakerAPI().name().fullName());
		enterText(emailField, fakerAPI().name().firstName() + "@gmail.com");
		isDisplayedThenClick(customerMenu, "Customer");
		isDisplayed(userCountryTypeDropdown, "User Country");
		sleep(3);
		isDisplayedThenClick(userTypeDropdown, "Clicking the drop down");
		isDisplayedThenClick(userTypeSelection, "Read Only Access");
		isDisplayedThenClick(submitOption, "Submit");
		sleep(2);
		if(errorMessageValidation.isDisplayed() && errorMessageValidation.getText().equals("Please fill captch")) {
			logInfo("Expected Behaviour");
		} else {
			logInfo("Not an Expected Behaviour");
		}
		String childWindow = driver.getWindowHandle();
		closeChildWindowAndswitchToParent(childWindow, driver.getWindowHandles());
	}

}
