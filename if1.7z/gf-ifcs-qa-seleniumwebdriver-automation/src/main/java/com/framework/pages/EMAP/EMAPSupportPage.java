package com.framework.pages.EMAP;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.ExtentTest;
import com.framework.basepage.BasePage;
import com.framework.repo.Locator;

public class EMAPSupportPage extends BasePage {

	public EMAPSupportPage(WebDriver driver, ExtentTest test) {
		super(driver, test);
		PageFactory.initElements(driver, this);
	}

	@FindBy(how = How.ID, using = Locator.PASSWORD_FIELD)
	public WebElement passwordField;

	@FindBy(how = How.ID, using = Locator.NEW_PASSWORD)
	public WebElement newPassword;

	@FindBy(how = How.ID, using = Locator.CONFIRM_PASSWORD)
	public WebElement confirmPassword;

	@FindBy(how = How.ID, using = Locator.CARD_INFORMATION_SAVECHANGES)
	public WebElement saveButton;

	@FindBy(how = How.XPATH, using = Locator.CLIENT_LOGO_IMG)
	public WebElement clientLogo;

	@FindBy(how = How.XPATH, using = Locator.MERCHANT_CLIENT_LOGO_IMG)
	public WebElement merchantClientLogo;

	@FindBy(how = How.XPATH, using = Locator.CONTACT_TABLE_PHONE_LABEL)
	public WebElement phoneLabel;

	@FindBy(how = How.XPATH, using = Locator.CONTACT_TABLE_PHONE)
	public WebElement phoneNumber;

	@FindBy(how = How.XPATH, using = Locator.CONTACT_TABLE_FAX_LABEL)
	public WebElement faxLabel;

	@FindBy(how = How.XPATH, using = Locator.CONTACT_TABLE_FAX)
	public WebElement faxValue;

	@FindBy(how = How.ID, using = Locator.MESSAGE_ABOUT_SEL)
	public WebElement queryType;

	@FindBy(how = How.ID, using = Locator.CONTACT_MESSAGE_TA)
	public WebElement commentField;

	@FindBy(how = How.ID, using = Locator.CONTACT_US_NAME)
	public WebElement contactName;

	@FindBy(how = How.ID, using = Locator.CONTACT_US_PH)
	public WebElement contactPhone;

	/*@FindBy(how = How.ID, using = Locator.CONTACT_US_EMAIL)
	public WebElement contactEmail;*/
	//Added by senthil 24/02/2020
	@FindBy(how = How.XPATH, using = Locator.CONTACT_US_EMAIL)
	public WebElement contactEmail;

	@FindBy(how = How.ID, using = Locator.CONTACT_US_QUERY_SUBMIT)
	public WebElement contactUsSubmit;

	@FindBy(how = How.ID, using = Locator.CONFIRMATIONMESSAGE)
	public WebElement confirmationMsg;

	@FindBy(how = How.XPATH, using = Locator.ERR_MSG)
	public WebElement errorMsg;

	@FindBy(how = How.XPATH, using = Locator.CHANGE_PASSWORD_ERROR_MESSAGE)
	public WebElement errorMessage;

	@FindBy(how = How.XPATH, using = Locator.USER_ID)
	public WebElement userID;

	public void validateThePasswordMaintenanceFields() {
		isDisplayed(passwordField, "Password Field");
		isDisplayed(newPassword, "New Password");
		isDisplayed(confirmPassword, "Confirm Password");
		isDisplayed(saveButton, "Save Button");
	}

	public void checkThePasswordResetFieldsAreEnabled() {
		if (Boolean.parseBoolean(getAttribute(passwordField, "disabled"))) {
			logFail("Password Field is read only");
		}
		if (Boolean.parseBoolean(getAttribute(newPassword, "disabled"))) {
			logFail("New Password Field is read only");
		}
		if (Boolean.parseBoolean(getAttribute(confirmPassword, "disabled"))) {
			logFail("Confirm Password Field is read only");
		}
		if (Boolean.parseBoolean(getAttribute(saveButton, "disabled"))) {
			logFail("Save button is read only");
		}
	}

	public void checkClientLogo() {
		isDisplayed(clientLogo, "Client logo");
	}

	public void checkMerchantClientLogo() {
		isDisplayed(merchantClientLogo, "Merchant Client logo");
	}

	public void checkTheContactInfo(String clientCountry) {
		if (clientCountry.equals("SP")) {
			if (!(getText(phoneLabel).equalsIgnoreCase("Saipan Phone"))) {
				logFail("Phone label field not present");
			}
			if (!(getText(phoneNumber).equalsIgnoreCase(": 1-877-254-1330"))) {
				logFail("Phone number field not present");
			}
			if (!(getText(faxLabel).equalsIgnoreCase("Saipan Fax"))) {
				logFail("Fax label field not present");
			}
			if (!(getText(faxValue).equalsIgnoreCase(": 1-855-658-7997"))) {
				logFail("Fax value field not present");
			}
		}
	}

	public void selectAQueryType() {
		// isDisplayedThenClick(queryType, "Query type");
		selectDropDownByIndex(queryType, 1);
		// selectDropDownByVisibleText(queryType, "General Card");
	}

	public void enterCommentInContactUsField(String commentText) {
		isDisplayedThenEnterText(commentField, "Comment in Contact us", commentText);
	}

	public void clearCommentSection() {
		try
		{
		commentField.clear();
	} catch (Exception ex) {
		logFail(ex.getMessage());
	}
	}
	public void enterAContactName() {

		isDisplayedThenEnterText(contactName, "Contact Name", fakerAPI().name().firstName());
	}

	public void clearContactName() {
	try
		{
			contactName.clear();
	} catch (Exception ex) {
		logFail(ex.getMessage());
	}
	}

	public void enterAContactPhone() {
		isDisplayedThenEnterText(contactPhone, "Contact Phone", fakerAPI().phoneNumber().cellPhone());
	}

	public void clearPhoneField() {
		try {
			contactPhone.clear();
		} catch (Exception ex) {
			logFail(ex.getMessage());
		}

	}

	public void enterAContactEmail() {
		contactEmail.clear();
		isDisplayedThenEnterText(contactEmail, "Contact Email", fakerAPI().internet().emailAddress());
	}

	public void enterAEmptyContactEmail() {
		try {
			contactEmail.clear();
		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
	}

	public void enterAInvalidEmail() {
		contactEmail.clear();
		isDisplayedThenEnterText(contactEmail, "Contact Email", fakerAPI().internet().emailAddress().replace("@", ""));
	}

	public void submitTheContactQuery() {
		isDisplayedThenClick(contactUsSubmit, "Contact Us Sumbit");
		sleep(5);
	}

	public void validateTheConfirmationMessage() {
		isDisplayed(confirmationMsg, "Confirmation Message");
		if (!(getText(confirmationMsg).equals("Email was sent successfully"))) {
			logFail("Confirmation message not present as expected");
		}
	}

	public void validateTheErrorMessage(String mandatoryField) {
		String expectedErrorMsg = " must not be blank.";
		if (mandatoryField.contains("query")) {
			expectedErrorMsg = "Select Query Type " + expectedErrorMsg;
		} else if (mandatoryField.contains("comment")) {
			expectedErrorMsg = "Comments " + expectedErrorMsg;
		} else if (mandatoryField.contains("name")) {
			expectedErrorMsg = "Contact Name " + expectedErrorMsg;
		} else if (mandatoryField.contains("phone")) {
			expectedErrorMsg = "Phone Number " + expectedErrorMsg;
		} else if (mandatoryField.contains("invalidemail")) {
			expectedErrorMsg = "Email Email field must contain valid email address";
		} else if (mandatoryField.contains("email")) {
			expectedErrorMsg = "Email " + expectedErrorMsg;
		}
		logInfo("Expected Error Msg:" + expectedErrorMsg);
		logInfo("Actual Error Msg:" + getText(errorMessage));

		if (!(getText(errorMessage).contains(expectedErrorMsg))) {
			logFail("Error message for " + mandatoryField + " not given as expected :: Actual " + getText(errorMessage)
					+ ":: Expected " + expectedErrorMsg);
		}
	}

	public void validateChangePasswordErrorMessage(String mandatoryField) {
		String expectedErrorMsg = "";
		if (mandatoryField.equals("password")) {
			expectedErrorMsg = "Password Password must be entered";
		} else if (mandatoryField.equals("confirm password")) {
			expectedErrorMsg = "Confirm Password Password must be entered";
		} else if (mandatoryField.equals("invalid confirm password")) {
			expectedErrorMsg = "Confirm Password New Passwords must match";
		}
		if (getText(errorMessage).contains(expectedErrorMsg)) {
			logPass("Error message for " + mandatoryField + "present as expected");
		} else {
			logFail("Error message for " + mandatoryField + " not present as expected");
		}
	}

	public void checkTheLogonIdInPasswordMaintenance(String expectedUserId) {
		if (getText(userID).contains(expectedUserId)) {
			logPass("Expected User id is present");
		} else {
			logFail("Expected User id not present");
		}
	}

	public void fillChangePasswordFields(String oldPwd, String newPwd, String confirmPwd) {
		isDisplayedThenEnterText(passwordField, "Old Password", oldPwd);
		isDisplayedThenEnterText(newPassword, "New Password", newPwd);
		isDisplayedThenEnterText(confirmPassword, "Confirm Password", confirmPwd);
		isDisplayedThenClick(saveButton, "Save Button");
		sleep(2);
	}

	public void enterEmptyPwdValidNewPwdConfirmPwdAndValidate() {
		fillChangePasswordFields("", "PasswordOLS1!", "PasswordOLS1!");
	}

	public void enterValidPwdNewPwdEmptyConfirmPwdAndValidate(String validPwd) {
		fillChangePasswordFields(validPwd, "PasswordOLS1!", "");
	}

	public void enterValidPwdNewPwdInvalidConfirmPwdAndValidate(String validPwd) {
		fillChangePasswordFields(validPwd, "PasswordOLS1!", "PasswordOLS1");
	}

	// public void enterValidPwdNewPwdConfirmPwdAndValidateSuccessMessage(String
	// validPwd) {
	// String validNewPassword = "Password0" + getRandomNumber(2, 3) + "#";
	// logInfo("Password going to reset as :: " + validNewPassword);
	// fillChangePasswordFields(PropUtils.getPropValue(configProp, validPwd),
	// validNewPassword, validNewPassword);
	// validateTheSuccessMessage();
	// PropUtils.setProps(configProp, validPwd, validNewPassword);
	// logInfo("Property Changed for Password :: " + validPwd);
	// }

	public void validateTheSuccessMessage() {
		isDisplayed(confirmationMsg, "Confirmation Message");
		if (!(getText(confirmationMsg).equals("Congratulations. Your password has been changed successfully."))) {
			logFail("Password was not successfully resetted");
		}
	}

}
