﻿using Common.Utility;
using EnCompass.Testing.Source.PageObjects.Controls;
using NFluent;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Support.UI;
using System.Collections.Generic;

namespace EnCompass.Testing.Source.PageObjects.Organization.ExpenseManager.Transactions
{
	public partial class FinancialCodeProfileSearchCards
	{
        #region XPath page Elements
        private const string _searchCriteriaTextSearchValueXPath = @"//input[contains(@id,'txt')]";
        private const string _searchCriteriaSearchTermXPath = @"//select[contains(@id, 'searchTermSelect')]";
        private const string _searchCriteriaAddBtnXPath = @"//input[@type='button' and @value='Add']";
        private const string _searchXPath = @"//input[contains(@id, 'btnSearch')]";
        private const string _searchCriteriaResetBtnXPath = @"//button[@type='button' and text()='Clear']";
        #endregion

        #region Page Elements
        private IWebElement _searchCriteriaTextSearchValue
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_searchCriteriaTextSearchValueXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_searchCriteriaTextSearchValue element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _searchCriteriaSearchTerm
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_searchCriteriaSearchTermXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_searchCriteriaSearchTerm element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _searchCriteriaAddBtn
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_searchCriteriaAddBtnXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_searchCriteriaAddBtn element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _search
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_searchXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_search element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _searchCriteriaResetBtn
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_searchCriteriaResetBtnXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_searchCriteriaResetBtn element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        #endregion

        public void Reset()
        {
            _searchCriteriaResetBtn.JSClickWithFocus(Driver);
        }

        public void SearchAndAssignProfileToCard(string searchTerm, string searchVal)
		{
			SearchCodeProfile(searchTerm, searchVal);
            CardsListGrid.SelectFirstRow();
            Driver.JsScrollToBottom();
            CardsListGrid.PerformActionByText("Assign Profiles");
		}

		public void SearchCodeProfile(string searchTerm, string searchVal)
		{
			SetSearchCriteriaSearchTerm(searchTerm);
			SearchCriteriaTextSearchValue = searchVal;
			Add();
			Search();
			RefreshModel();
		}

		public string SearchCriteriaTextSearchValue
		{
			set
			{
				_searchCriteriaTextSearchValue.Clear();
				_searchCriteriaTextSearchValue.SendKeys(value);
			}
		}

		public void SetSearchCriteriaSearchTerm(string whichText)
		{
			var selectElement = new SelectElement(_searchCriteriaSearchTerm);
			selectElement.SelectByText(whichText);
		}

		public void Add()
		{
			_searchCriteriaAddBtn.JSClickWithFocus(Driver);
		}

		public void Search()
		{
			_search.JSClickWithFocus(Driver);
			WaitForLoad();
		}

		private GridControl _mGrid;
		public GridControl CardsListGrid
		{
			get
			{
				GridControl grid = _mGrid ?? (_mGrid = new GridControl("dgAccounts", Driver));
				grid.WaitForGrid();
				return grid;
			}
		}
	}
}
