﻿using Common;
using Common.Utility;
using EnCompass.Testing.Source.PageObjects.Controls;
using NFluent;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Support.UI;
using System;

namespace EnCompass.Testing.Source.PageObjects.Organization.Admin.AccountProfiles
{
    [PageModel(@"/admin/accountProfiles/manageUserProfiles.aspx")]
    public class ManageUserProfiles : EnCompassOrgPageModel
    {
        public override string RelativeUrl => @"/admin/accountProfiles/manageUserProfiles.aspx";
        public override string PageIdentifierXPath_Override => @"//h1[contains(@id,'title')]";

        #region XPath page Elements

        private const string _viewXPath = @"//a[contains(@class,'btn-primary') and text()='View']";
        private const string _editXPath = @"//a[contains(@class,'btn-primary') and text()='Edit']";
        private const string _applyXPath = @"//a[contains(@class,'btn-primary') and text()='Apply']";
        private const string _deleteXPath = @"//a[contains(@class,'btn-primary') and text()='Delete']";
        private const string _gridXPath = @"//tr[contains(@id,'profilesDataGrid')]";
        private const string _userProfileNotFoundXPath = ".//td[normalize-space(text()) = 'No User Profiles found.']";
        private const string _successMessageXPath = ".//div[contains(@id,'SuccessMessage')]";
        private const string _validateDeleteButtonXPath = "//a[contains(@id,'actionLink4')]";
        #endregion

        #region Page Elements
        private IWebElement _view
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_viewXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Info("Found _view");
                return element;
            }
        }

        private IWebElement _edit
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_editXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Info("Found _edit");
                return element;
            }
        }

        private IWebElement _apply
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_applyXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Info("Found _apply");
                return element;
            }
        }

        private IWebElement _delete
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_deleteXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Info("Found _delete");
                return element;
            }
        }

        private IWebElement _grid
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_gridXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Info("Found _save");
                return element;
            }
        }

        private IWebElement _userProfileNotFound
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_userProfileNotFoundXPath), out IWebElement element, TimeSpan.FromSeconds(10));
                Settings.EnCompassExtentTest.Info($"_userProfileNotFound element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _userProfileGrid
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_gridXPath), out IWebElement element, TimeSpan.FromSeconds(10));
                Settings.EnCompassExtentTest.Info($"_userProfileGrid element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _successMessage
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_successMessageXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_successMessage element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        #endregion

        #region Navigation

        private void NavigateToMenuItem(IWebElement element)
        {
            Driver.Url = element.GetAttribute("href");
        }
        #endregion


        private GridControl _mGrid;
        public GridControl UserProfileGrid
        {
            get
            {
                GridControl grid = _mGrid ?? (_mGrid = new GridControl("profilesDataGrid", Driver));
                grid.WaitForGrid();
                return grid;
            }
        }

        public void DeleteUserProfile()
        {
            _delete.JSClickWithFocus(Driver);
            DeleteOnModal();
            Check.That(_userProfileNotFound).IsNotNull();
        }

        public void CancelDeletionUserProfile()
        {
            _delete.JSClickWithFocus(Driver);
            CancelOnModal();
            Check.That(_userProfileGrid).IsNotNull();
        }

        public void ViewUserProfile()
        {
            _view.JSClickWithFocus(Driver);
        }

        public void ApplyUserProfile()
        {
            _apply.JSClickWithFocus(Driver);
        }

        public bool GetSuccessMessageDelete(string message)
        {
            if (Check.That(SuccessMessage).Equals(message))
                return true;
            else
                return false;
        }

        public void ValidateDeleteButton()
        {
            Settings.EnCompassWebDriver.WaitForAbsence(By.XPath(_validateDeleteButtonXPath));
        }

        public void EditUserProfile()
        {
            _edit.JSClickWithFocus(Driver);
        }

        public ManageUserProfiles(GlobalSettings settings) : base(settings) { }
    }
}