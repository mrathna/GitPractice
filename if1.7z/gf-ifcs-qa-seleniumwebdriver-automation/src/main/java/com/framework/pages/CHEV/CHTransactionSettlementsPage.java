package com.framework.pages.CHEV;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.ExtentTest;
import com.framework.basepage.BasePage;
import com.framework.repo.Locator;

public class CHTransactionSettlementsPage extends BasePage {

	@FindBy(how = How.XPATH, using = Locator.SCHEDULE_REPORT_MAINTENANCE_PAGE)
	public WebElement transactionPageTitle;

	@FindBy(how = How.ID, using = Locator.CARD_NUMBER)
	public WebElement cardNumber;

//	@FindBy(how = How.ID, using = Locator.SEARCH_CARDS)
//	public WebElement searchBtn;
	
		@FindBy(how = How.ID, using = Locator.SEARCH_BTN)
	public WebElement searchBtn;

	@FindBy(how = How.ID, using = Locator.EXPORT_TO_EXCEL_SETT)
	public WebElement exportBtn;

	@FindBy(how = How.ID, using = Locator.ENQUIRY_START_DATE)
	public WebElement startDateField;

	@FindBy(how = How.ID, using = Locator.CH_MERCHANT_TRANS_LOC_NO)
	public WebElement locationNoField;
	
	@FindBy(how = How.ID, using = Locator.CH_MERCHANT_EXPORT_TRANS_PROCESSED_TABLE_HEADER)
	public WebElement processedTableHeader;
	
	@FindBy(how = How.ID, using = Locator.CH_MERCHANT_EXPORT_TRANS_DATE_TABLE_HEADER)
	public WebElement dateBatchTableHeader;
	
	@FindBy(how = How.ID, using = Locator.CH_MERCHANT_EXPORT_TRANS_LOC_NO_TABLE_HEADER)
	public WebElement locationNoTableHeader;
	
	@FindBy(how = How.ID, using = Locator.CH_MERCHANT_EXPORT_TRANS_DETAIL_TABLE_HEADER)
	public WebElement detailTableHeader;
	
	@FindBy(how = How.ID, using = Locator.CH_MERCHANT_EXPORT_TRANS_STATUS_TABLE_HEADER)
	public WebElement statusTableHeader;
	
	@FindBy(how = How.ID, using = Locator.CH_MERCHANT_EXPORT_TRANS_GROSS_AMT_TABLE_HEADER)
	public WebElement grossAmountTableHeader;
	
	@FindBy(how = How.ID, using = Locator.CH_MERCHANT_EXPORT_TRANS_CONTRIB_TABLE_HEADER)
	public WebElement contribTableHeader;
	
	@FindBy(how = How.ID, using = Locator.CH_MERCHANT_EXPORT_TRANS_VARIANCE_TABLE_HEADER)
	public WebElement varianceTableHeader;
	
	@FindBy(how = How.ID, using = Locator.CH_MERCHANT_EXPORT_TRANS_NET_AMT_TABLE_HEADER)
	public WebElement netAmountTableHeader;
	
	public CHTransactionSettlementsPage(WebDriver driver, ExtentTest test) {
		super(driver, test);
		PageFactory.initElements(driver, this);
	}

	public void verifyMerchantSettlementsPage() {
		sleep(3);
		isDisplayed(transactionPageTitle, "Merchant Settlements");
		logPass("Redirected to the Merchant Settlements Status Page");

	} 

	public void verifySearchButtons() {
		sleep(3);
		scrollDownPage();
		if (searchBtn.isDisplayed()) {
			logPass("Search is displayed");
		} else {
			logFail("Search is not displayed");
		}

	}

	public void verifyExportButtons() {
		if (exportBtn.isDisplayed()) {
			logPass("exportBtn is displayed");
		} else {
			logFail("exportBtn is not displayed");
		}

	}
	public void verifyMerchantSettlementsHeaders() {
		isDisplayed(startDateField, "Start Date ");
		isDisplayed(locationNoField, "Location Number ");
	}

	public void verifyMerchantSettlementsTableHeaders() {
		
		checkTextInPageAndValidate("Processed", 30);
		
		checkTextInPageAndValidate("Date/Batch", 30);
		
		checkTextInPageAndValidate("Location No", 30);
		
		checkTextInPageAndValidate("Detail", 30);
		
		checkTextInPageAndValidate("Status" , 30);
		
		checkTextInPageAndValidate("Gross Amt", 30);
		
		checkTextInPageAndValidate("Contrib.", 30);
		
		checkTextInPageAndValidate("Variance", 30);
		
		checkTextInPageAndValidate("Net Amount", 30);
	}

}
