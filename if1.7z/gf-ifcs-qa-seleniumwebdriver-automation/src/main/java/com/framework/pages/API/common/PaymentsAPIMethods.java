package com.framework.pages.API.common;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONObject;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;
import com.framework.pages.AJS.common.Common;
import com.framework.pages.AJS.common.CommonInterfacePage;
import com.framework.util.PropUtils;

import io.restassured.RestAssured;

public class PaymentsAPIMethods extends CommonAPI {
	public PaymentsAPIMethods(WebDriver driver, ExtentTest test) {
		super(driver, test);
		// TODO Auto-generated constructor stub
	}

	/*
	 * Added by raxsana on 31/07/2020
	 */
	/**
	 * @param clientName
	 * @param clientCountry
	 * @param paymentType
	 */
	public void paymentsViaAPI(String clientName, String clientCountry, String paymentType,String dishonourFlag) {
		JSONObject requestBody = new JSONObject();
		JSONObject currency = new JSONObject();
		JSONObject paymentInputs = new JSONObject();
		JSONObject transactionCode = new JSONObject();
		JSONArray paymentRefs = new JSONArray();
		Common common = new Common(driver, test);
		CommonInterfacePage commonInterfacePage = new CommonInterfacePage(driver, test);
		//WFECommon wfeCommon=new WFECommon(driver,test);
		Map<String, String> inputValues = new HashMap<String, String>();
		ArrayList<String> allocatedAmounts=new ArrayList<String>();
		String queryToGetDetailGroupOid,requestTotal;
		ArrayList<String> detailGroupOid;
		String clientNameCountry = PropUtils.getPropValue(configProp, clientName + "_" + clientCountry);
		String clientMid = commonInterfacePage.funcFetchLoadCardTransClientMidFromIFCSDB(configProp);

		RestAssured.baseURI = PropUtils.getPropValue(configProp, "baseURLPayment");
		String processingDate = common.getProcessingDateWithExpectedFormat("yyyy-MM-dd");
		try {
			if(dishonourFlag.contains("Y")) {
				requestTotal="=0";
			}else {
				requestTotal=">0";
			}
		String queryToGetValues = "select distinct mc.customer_no,mc.name,dg.remittance_id,tt.external_code,a.account_oid,"
				+ "pc.payment_request_oid,pc.payment_reference,pc.request_total from accounts a\r\n" 
				+ "inner join detail_groups dg on a.account_oid=dg.account_oid \r\n"
				+ "inner join transactions t on a.account_oid=t.account_oid \r\n"
				+ "inner join trans_translations tt on t.transaction_type_oid=tt.transaction_type_oid\r\n"
				+ "inner join m_customers mc on mc.customer_mid=a.customer_mid \r\n"
				+ "inner join account_status acs on a.account_status_oid=acs.account_status_oid\r\n"
				+ "inner join payment_requests pc on pc.account_oid=a.account_oid "
				+ "where tt.description='" + paymentType + "' and \r\n"
				+ "mc.client_mid=(select client_mid from m_clients where name='" + clientNameCountry + "') \r\n"
				+ "and a.actual_balance>0 and dg.host_credit_amount=0 and dg.remittance_id <> '(null)' \r\n"
				+ "and acs.description like '%Active%' and pc.request_total_actual"+requestTotal+" and rownum=1";
		inputValues = connectDBAndGetDBEntireRowValues(queryToGetValues,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		
		if(dishonourFlag.contains("Y")) {
			 paymentInputs.put("amount", inputValues.get("REQUEST_TOTAL"));
			paymentInputs.put("transactionCode", transactionCode.put("description", "TWIKEY_DIRECT_DISHONOUR"));
			
		}else {
			 paymentInputs.put("amount", inputValues.get("REQUEST_TOTAL"));
				paymentInputs.put("transactionCode", transactionCode.put("description", inputValues.get("EXTERNAL_CODE")));
		}
		paymentInputs.put("dishonourFeeFlag", dishonourFlag);
		paymentInputs.put("processedDate", processingDate);

		paymentInputs.put("executionDate", processingDate);

		paymentInputs.put("payee", inputValues.get("NAME"));

		paymentInputs.put("accountNumber", inputValues.get("CUSTOMER_NO"));
		paymentInputs.put("remittanceId", inputValues.get("PAYMENT_REFERENCE"));
		paymentInputs.put("bankAccountNumber", "000000000");

		String currencyCode = "select currency_code from currencies where currency_oid=(select currency_oid from m_clients where name='"
				+ clientNameCountry + "')";
		String currencyCodeValue = connectDBAndGetValue(currencyCode,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		paymentInputs.put("currency", currency.put("currencyCode", currencyCodeValue));
		
		paymentRefs.put(paymentInputs);
		requestBody.put("paymentRefs", paymentRefs);
		System.out.println("Request Code: " + requestBody);
		response = apiUtils.postRequestForNoAuthWithHeadersAndBodyData(requestBody, "/payment", clientMid, configProp);
		System.out.println("Response Code: " + response.getStatusCode());
		System.out.println("Response Body: " + response.prettyPrint());
		
		 if(dishonourFlag.contains("Y")) {
		String queryToGetPaymentAmount="select payment_currency_value from transactions where reference='"+inputValues.get("PAYMENT_REFERENCE")+"' "
				+ "and transaction_type_oid=(select transaction_type_oid from transaction_types where description='Direct Debit Dishonour' and is_debit='Y')";
		String transactionPaymentsAmount = connectDBAndGetValue(queryToGetPaymentAmount,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		if(transactionPaymentsAmount.equals(inputValues.get("REQUEST_TOTAL"))) {
			logPass("Dishonour Payment posted successfully");
		}else {
			logFail("Dishonour Payment not posted successfully");
		}
		 }else {
			 String queryToGetPaymentAmount="select payment_currency_value from transactions where reference='"+inputValues.get("PAYMENT_REFERENCE")+"'";
				String transactionPaymentsAmount = connectDBAndGetValue(queryToGetPaymentAmount,
						PropUtils.getPropValue(configProp, "sqlODSServerName"));
				if(transactionPaymentsAmount.equals("-"+inputValues.get("REQUEST_TOTAL"))) {
					logPass("Payment posted successfully");
				}else {
					logFail("Payment not posted successfully");
				} 
		 }
		if(dishonourFlag.equals("N")) {
			queryToGetDetailGroupOid="select detail_group_oid from detail_groups where payment_request_oid='"+inputValues.get("PAYMENT_REQUEST_OID")+"'";
			detailGroupOid=connectDBAndGetDBEntireColumnValues(queryToGetDetailGroupOid,
					PropUtils.getPropValue(configProp, "sqlODSServerName"));
			String queryToGetRemittanceAmounts="select remittance_amount from detail_groups where payment_request_oid='"+inputValues.get("PAYMENT_REQUEST_OID")+"'";
			ArrayList<String> remittanceAmounts=connectDBAndGetDBEntireColumnValues(queryToGetRemittanceAmounts,
					PropUtils.getPropValue(configProp, "sqlODSServerName"));
			
			for(int i=0;i<detailGroupOid.size();i++) {
				String queryToGetAllocatedPayment="select amount from allocations where dr_detail_group_oid='"+detailGroupOid.get(i)+"'";
				String allocatedPayment=connectDBAndGetValue(queryToGetAllocatedPayment,
						PropUtils.getPropValue(configProp, "sqlODSServerName"));
				allocatedAmounts.add(allocatedPayment);
			}
			if(remittanceAmounts.containsAll(allocatedAmounts)) {
				logPass("Payment allocations done successfully");
			}
			else {
				logFail("Payment  allocations not done successfully");
			}
		}
		}catch(Exception e) {
			e.getMessage();
		}
	}

}
