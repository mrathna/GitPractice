﻿extern alias cpt;
using cpt.Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Common.Utility.ControlMTool
{
	public class AuthorizationResponse
	{
		[JsonProperty("username")]
		public string LoginId { get; set; }

		[JsonProperty("token")]
		public string LoginToken { get; set; }
	}
}
