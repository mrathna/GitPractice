package com.framework.testcases.OLS.CHEV.Merchant;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.CHEV.CHHomePage;
import com.framework.pages.OLS.common.CommonPage;
import com.framework.pages.OLS.common.LoginPage;

public class ValidateOLSMerchantSiteSupport extends BaseTest {
	@Parameters({ "clientCountry", "clientName" })
	@Test(priority = 1)
	public void testOLSMerchantSiteSupport(@Optional("TH") String clientCountry, @Optional("CHV") String clientName) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  OLS - Merchant Site - Support", "Chevron Merchant Site Read Only");

		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		CHHomePage chHomePage = new CHHomePage(driver, test);
	//	CHContactUsPage chContactUsPage = new CHContactUsPage(driver, test);
		//CHTransactionPage chTransactionPage = new CHTransactionPage(driver, test);
		CommonPage commonPage = new CommonPage(driver, test);
		
		/*if (clientCountry.equals("SG")) {
			loginPage.Login("CHV_URL", "CHV_Merchant_UN_"+clientCountry, "CHV_Merchant_PWD_"+clientCountry, "CHV");
//			chHomePage.verifyUserName("Hello, Test");
			chHomePage.verifyMerchantAccountDetails();
		} else if (clientCountry.equals("TH")) {
			loginPage.Login("CHV_URL", "CHV_Merchant_UN_"+clientCountry, "CHV_Merchant_PWD_"+clientCountry, "CHV");
//			chHomePage.verifyUserName("Hello, THuser");
		} else if (clientCountry.equals("PH")) {
			loginPage.Login("CHV_URL", "CHV_Merchant_UN_"+clientCountry, "CHV_Merchant_PWD_"+clientCountry, "CHV");
//			chHomePage.verifyUserName("Hello, PHuser");
		}*/
		

		// Validating Home Page - Quick Links
	//	chHomePage.verifyMerchantQuickLinks();
	//	chHomePage.clickOnTransactionQuickLink();
	//	chTransactionPage.verifyTransactionPage();
		loginPage.Login("CHV_URL", "CHV_Merchant_UN_"+clientCountry, "CHV_Merchant_PWD_"+clientCountry, "CHV");
		chHomePage.clickOnHome();
		chHomePage.clickOnExportTransactionLink();
		String checkFileDate=chHomePage.validateDateInDownloadedFile();
		commonPage.isFileDownloaded(checkFileDate);
		//commonPage.isFileDownloaded("0700031161__20190408_");
		//chHomePage.checkForFileDownload(1); 
		
		// Change Password 
		chHomePage.loadFindAndFindPasswordPage();
		chHomePage.verifyChangePasswordPage();
		
	
		//Contact Us 
	//	chHomePage.loadFindAndContactUsPage();
	//	chHomePage.verifyFooterPageLinks();
	//	chContactUsPage.verifyContactUsFields();
	//	chContactUsPage.enterRandomValuesAndValidate("merchant");
	
		
		// Below functions are commented - due to page fields changed 
		/*	chHomePage.verifyFooterLinks();
		
		chContactUsPage.enterRandomValuesExceptEnquiryType();
		chContactUsPage.clickSubmitButton();
		chContactUsPage.verifyErrorMessage("Query Type");
		
		chContactUsPage.enterRandomValuesExceptComments();
		chContactUsPage.clickSubmitButton();  
		chContactUsPage.verifyErrorMessage("Comment required");
		
		chContactUsPage.enterRandomValuesExceptContactName();
		chContactUsPage.clickSubmitButton();
		chContactUsPage.verifyErrorMessage("Validation failed");
		
		chContactUsPage.enterRandomValuesExceptPhoneNo();
		chContactUsPage.clickSubmitButton();
		chContactUsPage.verifyErrorMessage("Validation failed");
		
		chContactUsPage.enterRandomValuesExceptEmail();
		chContactUsPage.clickSubmitButton();
		chContactUsPage.verifyErrorMessage("Email Required");	
		
		chContactUsPage.enterRandomValuesWithIncorrectEmail();
		chContactUsPage.clickSubmitButton();
		chContactUsPage.verifyErrorMessage("Validation failed");	
		
		chContactUsPage.enterRandomValues();
		chContactUsPage.clickSubmitButton();
		chContactUsPage.checkConfirmationMessage(); 
			
		 */
	}
}
