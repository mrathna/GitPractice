package com.framework.testcases.OLS.EMAP.Customer;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.BP.BPHomePage;
import com.framework.pages.CHEV.CHHomePage;
import com.framework.pages.CHEV.CHStoredReportsPage;
import com.framework.pages.EMAP.EMAPHomePage;
import com.framework.pages.EMAP.EMAPReportsPage;
import com.framework.pages.OLS.common.LoginPage;
import com.framework.pages.OLS.common.MerchantReportsPage;

public class ValidateStoredReportsPage extends BaseTest {
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "Regression" })
	public void validateStoredReports(@Optional("SP") String clientCountry, @Optional("EMAP") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  TST-SC-101-OLS - Verify the Stored Reports",
				"Validate stored reports page for read-only, read/write and view-only");
		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		loginPage.Login("EMAP_URL", "EMAP_UN_ReadOnly_Customer_" + clientCountry,
				"EMAP_PWD_ReadOnly_Customer_" + clientCountry, clientName);
		EMAPHomePage emapHomePage = new EMAPHomePage(driver, test);
		EMAPReportsPage reportsPage = new EMAPReportsPage(driver, test);

		// Reports - Stored Reports
		emapHomePage.clickStoredReportsAndValidatePage();
		reportsPage.validateTheReportsPageFilterOptions();
		reportsPage.checkThePresenceOfExportAndSearchOptions();
		reportsPage.validateTheReportsTableColumns();
		reportsPage.selectAStoredReportAndVerify();
		loginPage.Logout();

		// Creating Objects for the Pages
		loginPage.Login("EMAP_URL", "EMAP_UN_ReadWrite_Customer_" + clientCountry,
				"EMAP_PWD_ReadWrite_Customer_" + clientCountry, clientName);

		// Reports - Stored Reports
		emapHomePage.clickStoredReportsAndValidatePage();
		reportsPage.validateTheReportsPageFilterOptions();
		reportsPage.checkThePresenceOfExportAndSearchOptions();
		reportsPage.validateTheReportsTableColumns();
		reportsPage.selectAStoredReportAndVerify();

		loginPage.Logout();

		// Creating Objects for the Pages
		loginPage.Login("EMAP_URL", "EMAP_UN_ViewOnly_Customer_" + clientCountry,
				"EMAP_PWD_ViewOnly_Customer_" + clientCountry, clientName);

		// Reports - Stored Reports
		emapHomePage.clickStoredReportsAndValidatePage();
		reportsPage.validateTheReportsPageFilterOptions();
		reportsPage.checkThePresenceOfExportAndSearchOptions();
		reportsPage.validateTheReportsTableColumns();
		reportsPage.selectAStoredReportAndVerify();

		loginPage.Logout();

	}
	
	
	
}
