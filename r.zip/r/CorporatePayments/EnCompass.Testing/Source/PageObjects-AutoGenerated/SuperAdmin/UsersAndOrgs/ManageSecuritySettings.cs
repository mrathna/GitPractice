using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using Common;
using Common.PageObjects;
using Common.ScenarioConfigurations;
using Common.Utility;

namespace EnCompass.Testing.Source.PageObjects.SuperAdmin.UsersAndOrgs 
{
	/// <summary>
	/// Auto-generated Page Model Class
	/// Navigation Paths: 
		/// [Organization Home]->Users and Organizations->Security Settings
		/// </summary>
	[PageModel(@"/superAdmin/UsersAndOrgs/manageSecuritySettings.aspx")]
	public partial class ManageSecuritySettings : EnCompassSuperPageModel 
	{
		public override string RelativeUrl => @"/superAdmin/UsersAndOrgs/manageSecuritySettings.aspx";
		public override string PageIdentifierXPath_Generated => @"//li[contains(@class, 'breadcrumb-item active')][text() = 'Security Settings']";

		#region Navigation
		
		private void NavigateToMenuItem(IWebElement element)
		{
			Driver.Url = element.GetAttribute("href");
		}
		#endregion

		public ManageSecuritySettings(GlobalSettings settings) : base(settings) { }
	}  
}
