﻿using Common;
using Common.PageObjects;
using Common.Utility;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace EnCompass.Testing.Source.PageObjects
{
    /// <summary>
    /// Page object for Textfree Login Page.
    /// </summary>
    public class TextfreeLoginPage : PageModel
    {
        public TextfreeLoginPage(GlobalSettings settings) : base(settings) { }


        public override string RelativeUrl => @"https://messages.textfree.us/login";
        public override string PageIdentifierXPath_Override => @".//div[normalize-space(text())='Textfree Web']";

        private readonly string _usernameInput = ".//input[@id='username']";
        private readonly string _passwordInput = ".//input[@id='password']";
        private readonly string _logInButton = ".//button[@type='submit']";
        private readonly string _upperRightLoginButton = ".//button[@id = 'loginButton']";

        public string UsernameInput
        {
            get
            {
                IWebElement UserElement = Settings.EnCompassWebDriver.WaitFor(By.XPath(_usernameInput));
                return UserElement.Text;
            }
            set
            {
                IWebElement UserElement = Settings.EnCompassWebDriver.WaitFor(By.XPath(_usernameInput));
                UserElement.Clear();
                UserElement.SendKeys(value);
                Settings.EnCompassExtentTest.Info("Set Username on TextFree login page as :" + value);
            }
        }

        public string PasswordInput
        {
            get
            {
                IWebElement PassElement = Settings.EnCompassWebDriver.WaitFor(By.XPath(_passwordInput));
                return PassElement.Text;
            }
            set
            {
                IWebElement PassElement = Settings.EnCompassWebDriver.WaitFor(By.XPath(_passwordInput));
                PassElement.Clear();
                PassElement.SendKeys(value);
                Settings.EnCompassExtentTest.Info("Set Password on TextFree login page as :" + value);
            }
        }

        public void ClickUpperRightLoginButton()
        {
            Settings.EnCompassWebDriver.WaitFor(By.XPath(_upperRightLoginButton)).Click();
            AttachOnDemandScreenShot();
            Settings.EnCompassExtentTest.Info($"Clicked on the Upper Right Login Button.");
        }

        public void ClickLogIn()
        {
            ScrollToXPATH(_logInButton);
            Settings.EnCompassWebDriver.WaitFor(By.XPath(_logInButton)).Click();
            Settings.EnCompassExtentTest.Info($"Clicked on the Log In Button.");
        }

        public void WaitForFooterToBeVisible()
        {
            Settings.EnCompassWebDriver.WaitForElementsToBeVisible(By.XPath("//footer"));
        }

    }
}
