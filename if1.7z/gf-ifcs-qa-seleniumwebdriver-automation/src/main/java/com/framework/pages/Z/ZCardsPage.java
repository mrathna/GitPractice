package com.framework.pages.Z;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.ExtentTest;
import com.framework.basepage.BasePage;
import com.framework.pages.OLS.common.CardsPage;
import com.framework.pages.OLS.common.CommonPage;
import com.framework.repo.Locator;
import com.framework.util.ExcelUtils;
import com.framework.util.PropUtils;

public class ZCardsPage extends BasePage {

	CardsPage cardcommonPage = new CardsPage(driver, test);

	@FindBy(how = How.XPATH, using = Locator.CARD_OFFER)
	public WebElement cardOffer;

	@FindBy(how = How.ID, using = Locator.CARD_OFFER_TITLE)
	public WebElement cardOfferTitle;

	@FindBy(how = How.ID, using = Locator.CARD_PRODUCT)
	public WebElement cardProduct;

	@FindBy(xpath = Locator.ACCOUNT_LIST_BOX)
	public WebElement accountList;

	@FindBy(id = Locator.SEARCH_BTN)
	public WebElement searchButton;

	@FindBy(id = Locator.CARD_LIST_TABLE)
	public WebElement cardListTable;

	@FindBy(xpath = Locator.VIEW_CARD_MENU)
	public WebElement viewCardMenu;

	@FindBy(xpath = Locator.CUSTOMER_NUMBER_LIST)
	public List<WebElement> customerNumberList;

	@FindBy(xpath = Locator.Z_CLONE_CARD)
	public WebElement cloneCard;

	@FindBy(id = Locator.CH_VIEW_CARD_BACK_BUTTON)
	public WebElement backToCardList;

	@FindBy(id = Locator.CARD_STATUS)
	public WebElement filterCardStatus;
	
	@FindBy(xpath = Locator.CHANGE_CARD_STATUS)
	public WebElement filterchangeCardStatus;

	@FindBy(xpath = Locator.Z_CARD_NUMBER)
	public WebElement cardNumber;

	@FindBy(xpath = Locator.Z_REGO_NUMBER)
	public WebElement regoNumber;

	@FindBy(xpath = Locator.Z_DRIVER_NAME)
	public WebElement driverName;

	@FindBy(xpath = Locator.Z_REFERENCE_NUMBER)
	public WebElement referenceNumber;

	@FindBy(xpath = Locator.Z_VEHICLE_DISCRIPTION)
	public WebElement vehicleDiscription;

	@FindBy(xpath = Locator.Z_COSTCENTRE_CODE)
	public WebElement costCentreCode;

	@FindBy(id = Locator.UAL_CONTTINUE)
	public WebElement orderCard;
	
	@FindBy(id = Locator.Z_SUCCESS_MSG)
	public WebElement successMsg;
	
	@FindBy(id = Locator.Z_FLEET_ID)
	public WebElement fleetId;

	@FindBy(id = Locator.CARD_INFORMATION_DRIVER_NAME)
	public WebElement driverNameConfirm;

	@FindBy(id = Locator.REGO_NUMBER_FIELD)
	public WebElement regoNumberConfirm;

	@FindBy(id = Locator.CARD_EXPIRES_ON)
	public WebElement cardExpireson;

	@FindBy(id = Locator.Z_CARD_NO)
	public WebElement cardNo;

	@FindBy(id = Locator.CARD_INFORMATION_REFERENCE_NUMBER)
	public WebElement cardReferenceNumber;

	@FindBy(id = Locator.Z_COST_CENTER)
	public WebElement costCenter;

	@FindBy(xpath = Locator.Z_PERMANENT_ADDRESS)
	public WebElement permanentAddress;

	@FindBy(xpath = Locator.Z_PURCHASE_CONTROLS)
	public WebElement purchaseControls;

	@FindBy(xpath = Locator.Z_CARD_LIMITS)
	public WebElement cardLimits;

	@FindBy(xpath = Locator.Z_TEMPORARY_ADDRESS)
	public WebElement temporaryAddress;

	@FindBy(how = How.XPATH, using = Locator.ALL_LISTED_CARDS)
	public List<WebElement> allListedCards;

	@FindBy(id = Locator.NEW_CARD_STATUS)
	public WebElement newCardStatuss;

	@FindBy(id = Locator.DELIVER_CONFIRM_AND_REISSUE)
	public WebElement saveButton;

	@FindBy(id = Locator.CARDSTATUSCHANGE_POPUP_REISSUEBUTTON)
	public WebElement confirmReissueButton;
	
	@FindBy(how = How.ID, using = Locator.LATER_ON_THIS_DATE_FIELD)
	public WebElement newStatusBeginDate;
	
	@FindBy(css = Locator.FUTURE_CARDRADIO_BUTTON)
	public WebElement futureCardRadioButton;
	
	@FindBy(id = Locator.SEARCH_BTN)
	public WebElement searchVehicleButton;

	@FindBy(id = Locator.CURRENT_CARD_NUMBER)
	public WebElement currentCardNumber;

	@FindBy(xpath = Locator.Z_TABLES_LIST)
	public WebElement tablesList;
	
	@FindBy(xpath = Locator.EDIT_CARD_MENU_OPTION)
	public WebElement editCardMenuButton;
	
	@FindBy(xpath = Locator.PAGE_HEADER)
	public WebElement pageTitle;
	
	@FindBy(id = Locator.CARD_INFORMATION_DRIVER_NAME)
	public WebElement driverNameEditPage;

	@FindBy(id = Locator.CARD_INFORMATION_VEHICLE_REGO_NUMBER)
	public WebElement vehicleRegoNumber;

	@FindBy(id = Locator.CDA_TITLE)
	public WebElement contactTitleName;

	@FindBy(id = Locator.CDA_CONTACT_NAME)
	public WebElement contactName;

	@FindBy(id = Locator.CDA_CONTACT_ADDRESS)
	public WebElement contactAddress;

	@FindBy(id = Locator.CDA_SUBURB)
	public WebElement cityName;

	@FindBy(id = Locator.CDA_POSTCOAD)
	public WebElement postCode;

	@FindBy(id = Locator.CDA_SATE)
	public WebElement stateName;

	@FindBy(xpath = Locator.CDA_COUNTRY)
	public WebElement countryName;

	@FindBy(id = Locator.CARD_PURCHASE_PRODUCTS_DURING_TIME)
	public WebElement timeLimit;

	@FindBy(xpath = Locator.CARD_PURCHASE_PRODUCTS_LOCATION_RESTRICTION)
	public WebElement locationRes;

	@FindBy(xpath = Locator.CARD_CONFIRM_PRODUCTS_LOCATION_RESTRICTION)
	public WebElement productlocationRes;

	@FindBy(xpath = Locator.CARD_PURCHASE_PRODUCTS_PRODUCT_RESTRICTION)
	public WebElement productRes;

	@FindBy(xpath = Locator.CARD_LIMITS_MONTHLY_DOLLAR)
	public WebElement monthlyLimit;

	@FindBy(xpath = Locator.CARD_LIMITS_TRANSACTION_DOLLAR_LIMIT)
	public WebElement transactionDolarLimit;

	@FindBy(xpath = Locator.CARD_LIMITS_DAILY_DOLLAR)
	public WebElement dailyDolarLimit;

	@FindBy(xpath = Locator.CARD_LIMITS_TRANSACTION_LIMIT)
	public WebElement transactionLimit;
	
	@FindBy(xpath = Locator.Z_CARD_TABLE_STATUS_HEADER)
	public WebElement currentStatusHeader;

	@FindBy(id = Locator.PRODUCT_RESTRICTION_OID)
	public WebElement productRestrictionOid;

	@FindBy(id = Locator.CARD_PURCHASE_PRODUCTS_DURING_TIME)
	public WebElement productDuringTime;

	@FindBy(how = How.XPATH, using = Locator.CHANGE_CARD_STATUS_MENU_OPTION)
	public WebElement changeCardStatus;

	@FindBy(id = Locator.BACK_TO_SETTLEMENT_LIST)
	public WebElement backToCardListCS;
	
	@FindBy(how = How.XPATH, using = Locator.ORDER_CARD_BUTTON)
	public WebElement orderCardButton;
	
	@FindBy(how = How.XPATH, using = Locator.SUCCESS_MESSAGE)
	public WebElement successMessage;
	
	@FindBy(how = How.XPATH, using = Locator.SUCCESS_MESSAGE_CARD_NUMBER)
	public WebElement successMessageWithCardNumber;
	
	@FindBy(how = How.ID, using = Locator.Z_CARD_SEARCH_BOX)
	public WebElement cardSearchBox;

CommonPage commonPage = new CommonPage(driver, test);
	private String cardAccNo = "";
String f_cardNumber;

	
	private String currentCardStatus = "";

	private String f_cardNo = "";

	private String status = "";

	private String offer = "";

	private String rego = "";
	private String f_drivername = "";
	private String f_fleetID = "";
	private String f_regoNo2 = "";
	private String f_regoNo = "";
	private String f_productRestrictionOID = "";
	private String f_productAlertTime = "";
/*	private String f_productLocationAlert = "";
	private String f_monthlyLimits = "";
	private String f_transactionDolarLimits = "";
	private String f_dailyDolarLimits = "";
	private String f_transactionLimis = "";*/
	private String f_contactTitlename = "";
	private String f_contactname = "";
	private String f_contactAddress = "";
	private String f_cityName = "";
	private String f_postCode = "";
	private String cardofferType = "";
	


	

	//	private String cardNo = "";
private String getDBDetailsFromProperties = "";

	public ZCardsPage(WebDriver driver, ExtentTest test) {
		super(driver, test);
		PageFactory.initElements(driver, this);
	}

	/**
	 * Go To - Cards - Order A Card
	 */
	public void goToCardOrder() {
		mouseHoverClickMenuAndSubMenu("Cards", "Order a Card");
	}

	/**
	 * Select Driver Card Offer
	 */
	public void selectDriverCard() {
		selectDropDownByVisibleText(cardOffer, "Driver Card");
		sleep(10);
	}

	/**
	 * Validating Driver Card Offer is selected
	 */
	public void validateSelectedCardOffer() {
		String retrievedCardProduct = selectedStringFrmDropDown(cardProduct);
		System.out.println("Respective Card Product for Selected Card Offer " + retrievedCardProduct);
		if ("Driver Card".equals(retrievedCardProduct)) {
			logPass("Respective Card Offer Selected " + retrievedCardProduct);
		} else {
			logFail("Different Card Offer Selected " + retrievedCardProduct);
		}
	}

	// Added on 16/01/2019
	public void clickCardsFindCards() {

		mouseHoverClickMenuAndSubMenu("Cards", "Find Cards");
	}

	public void selectAllAccountsAndSearch() {

		selectDropDownByVisibleText(accountList, "All Accounts");
		sleep(2);
		isDisplayedThenClick(searchButton, "Search button");
		sleep(10);
	}

	public void clickCardDetailsGoToViewCardPageAndValidate() {

		setCellDataFromTable(cardListTable, 7, true);
		cardAccNo = getCellDataFromTable(0, 1, true);

		System.out.println("cardAccNo---" + cardAccNo);

		clickCardNumber(1);

		clickCardTableMenuOption(viewCardMenu);

		sleep(5);

		checkTextInPageAndValidate("View Card", 30);

	}

	public void clickCardNumber(int index) {
		try {
			isDisplayedThenActionClick(customerNumberList.get(index - 1), "Click selected Card from card list");
			// System.out.println("Get Text for element"+ expAccount.getr);
			sleep(3);

		} catch (Exception e) {
			logInfo(e.getMessage());

		}

	}

	public void clickCardTableMenuOption(WebElement option) {
		isDisplayedThenActionClick(option, "Card Table Menu");
		// isDisplayedThenClick(option, "Card Table Menu");
		sleep(5);
		// verifyHeaderTitle(titleTOCheck);
	}
	
	public void clickBackToCardList() {
		isDisplayedThenActionClick(backToCardList, "Back To ScheduleReport List");
		 sleep(2);
	}

	public void clickCloneCardAndValidate() {

		setCellDataFromTable(cardListTable, 7, true);
		cardAccNo = getCellDataFromTable(0, 1, true);

		System.out.println("cardAccNo---" + cardAccNo);

		clickCardNumber(1);

		clickCardTableMenuOption(cloneCard);

		sleep(5);

		checkTextInPageAndValidate("Order New Card", 30);

	}
//	sasi
	public void clickEditCardFromCardListAndValidate() {
		setCellDataFromTable(cardListTable, 7, false);
		System.out.println("inside edit card");
		List<WebElement> rowElements =  cardListTable.findElements(By.xpath("./tbody[contains(@id,'lform:tableCardList:tb')]/tr"));
		System.out.println("inside rowElements card"+rowElements.size());
		for (int j = 0; j < rowElements.size(); j++) {
			currentCardStatus = getCellDataFromTable(j+1, 1, false);
			System.out.println("Current card status::"+currentCardStatus);
			if ("Active".equals(currentCardStatus)||"PIN pending".equals(currentCardStatus)) {
				System.out.println("inside edit card if method");
				clickCardNumber(j+1);
				clickCardTableMenuOption(editCardMenuButton);
				sleep(5);		
//				verifyText(pageTitle, "EDIT CARD");
				verifyText(pageTitle, "Edit Card");
//				checkTextInPageAndValidate("Edit Card", 20);				
				break;
			}else if(j == rowElements.size()-1 ) {
				logFail("Edit card sub menu not clicked");
			}
		}

	}

	public void clickViewCardGoToViewCardPageAndValidate() {

		setCellDataFromTable(cardListTable, 7, true);
                f_cardNo = getCellDataFromTable(1, 0, true);

		status = getCellDataFromTable(1, 1, true);

		offer = getCellDataFromTable(1, 2, true);

		rego = getCellDataFromTable(1, 3, true);
		
		cardAccNo = getCellDataFromTable(1, 6, true);

		System.out.println("cardAccNo---"+cardAccNo); 

		clickCardNumber(1);

		clickCardTableMenuOption(viewCardMenu);

		sleep(5);

		checkTextInPageAndValidate("View Card", 20);

		checkTextInPageAndValidate(f_cardNo, 10);

		checkTextInPageAndValidate(status, 10);

		checkTextInPageAndValidate(offer, 10);

		checkTextInPageAndValidate(rego, 10);


		validateViewCardPage();
	}

	//	Added by Sasi

	public void validateViewCardPage() {
		// First check The Sections Are present

		checkTextInPageAndValidate("Card Details", 20);
		checkTextInPageAndValidate("Card Limits", 20);
		checkTextInPageAndValidate("Delivery Address", 20);
		checkTextInPageAndValidate("Card Number", 20);
		checkTextInPageAndValidate("Card Status", 20);
		checkTextInPageAndValidate("Card Offer", 20);
		checkTextInPageAndValidate("Fleet ID", 20);
		checkTextInPageAndValidate("Card Product", 20);

		checkTextInPageAndValidate("Cost Centre Code", 20);
		checkTextInPageAndValidate("Pos Prompts", 20);
		checkTextInPageAndValidate("Expiry Date", 20);
		checkTextInPageAndValidate("Additional Card Reference", 20);

		checkTextInPageAndValidate("Purchase Controls", 20);
		checkTextInPageAndValidate("Product Restriction", 20);
		checkTextInPageAndValidate("Location Alert", 20);
		checkTextInPageAndValidate("Time of Use Alert", 20);


		checkTextInPageAndValidate("Driver Details", 20);
		checkTextInPageAndValidate("Driver Name", 20);
		checkTextInPageAndValidate("Mobile", 20);

		checkTextInPageAndValidate("Vehicle Details", 20);
		checkTextInPageAndValidate("Vehicle Description", 20);
		checkTextInPageAndValidate("Rego", 20);

		checkTextInPageAndValidate("Monthly $", 20);
		checkTextInPageAndValidate("Transaction $", 20);
		checkTextInPageAndValidate("Daily $", 20);
		checkTextInPageAndValidate("Daily transaction count", 20);
		checkTextInPageAndValidate("Transaction volume (litres)", 20);
		checkTextInPageAndValidate("Monthly shop $", 20);
		checkTextInPageAndValidate("Monthly premium $", 20);
		checkTextInPageAndValidate("Monthly vehicle servicing $", 20);

		checkTextInPageAndValidate("Account Delivery Address", 20);

		//		checkAnElementIsDisabled(cardInfoOdoMeter, "Pos prompts Odometer");
		
		//		checkAnElementIsDisabled(customerRef, "Pos prompts Customer Reference");

	}
//	Sasi 06-02-19
	
	public void clickingSearchResultsTableHeaderAndValidateOrder() {

		setCellDataFromTable(cardListTable, 7, true);
		System.out.println("3");
		isDisplayedThenClick(currentStatusHeader, "Checking the sorting order");
	
	}

	public void searchResultsTableValidate() {

		setCellDataFromTable(cardListTable, 7, true);
		System.out.println("3");
		searchCardNumberAndValidate();
		//		searchCardOfferAndValidate();
		//		searchCostCentreCodeAndValidate();
		//		searchCurrentStatusAndValidate();
		searchDriverNameAndValidate();
		searchVehicleRegAndValidate();

	}
	public void searchCardNumberAndValidate() {
		System.out.println("1");
		String CardNumber = getCellDataFromTable(1, 0, true);
		System.out.println("Cardno---" +CardNumber);
		cardcommonPage.searchAndValidate(cardNumber, searchButton, CardNumber, 0, 8);
		System.out.println("2");
		sleep(2);
	}

	public void searchVehicleRegAndValidate() {
		// TODO Auto-generated method stub
		String Rego = getCellDataFromTable(1, 3, true);
		System.out.println("R--" +Rego);
		cardcommonPage.searchAndValidate(regoNumber, searchButton, Rego, 3, 8);
		sleep(2);
	}

	public void searchDriverNameAndValidate() {
		// TODO Auto-generated method stub
		String Driver = getCellDataFromTable(1, 4, true);
		System.out.println("D--" +Driver);
		cardcommonPage.searchAndValidate(driverName, searchButton, Driver, 4, 8);
		sleep(2);
	}	
	//	 Sasi (31-01-2019)

	public void validateBulkCardOrderPage() {
		checkTextInPageAndValidate("Bulk Card Ordering", 20);
		checkTextInPageAndValidate("Template", 10);
	}

	public void validateBuldCardUpdatePage() {
		// TODO Auto-generated method stub
		checkTextInPageAndValidate("Bulk Update", 20);
	}

	public void verifyReissueControlPage() {

		//		checkTextInPageAndValidate("Bulk Re-issue", 10);
		checkTextInPageAndValidate("Bulk Reissue Requesting", 10);
		sleep(3);
	}

	public boolean verifyBulkReIssueListDataIsAvailable() {

		boolean isBulkReIssue = false; 

		//		isBulkReIssue = waitForTextToAppear("Bulk Re-issue List is Empty.", 30);

		isBulkReIssue = waitForTextToAppear("No cards due to expire soon.", 20);

		return isBulkReIssue;
	}
	
public void goToCardMenuOrderCard() {
		mouseHoverClickMenuAndSubMenu("Cards", "Order a Card");
		sleep(2);
	}

	public void verifyAllExpectedFeilds() {
		checkTextInPageAndValidate("Order New Card", 20);
		checkTextInPageAndValidate("Card Details", 20);
		checkTextInPageAndValidate("Driver Details", 20);
		checkTextInPageAndValidate("Vehicle Details", 20);
		checkTextInPageAndValidate("Fleet ID", 20);
		checkTextInPageAndValidate("POS Prompts", 20);
		isDisplayed(cardExpireson, "Expires  on");
		checkAnElementIsDisabled(cardNo, "Card No field");
		isDisplayed(fleetId, "Fleet ID");
		isDisplayed(cardReferenceNumber, "Additional Card Reference");
		isDisplayed(costCenter, "Cost Center Oid");
		isDisplayed(purchaseControls, "purchase controls");
		scrollDownPage();
		// isDisplayed(cardLimits, "Card Limit");
		isDisplayed(permanentAddress, "Permanent Address");
		isDisplayed(temporaryAddress, "Temporary Address");

	}

	public void mandatoryFieldsValidation() {
		isDisplayedThenActionClick(orderCard, "Order Card");
		checkTextInPageAndValidate("Card Product  must not be blank.", 20);
		sleep(2);
		orderDriverCardValidation();
		sleep(2);
		mouseHoverClickMenuAndSubMenu("Cards", "Order a Card");
		orderVehicleCardValidation();
	}

	public void orderDriverCardValidation() {
		f_drivername = fakerAPI().name().fullName();
		f_fleetID = fakerAPI().number().digits(5);

		selectDropDownByVisibleText(cardOffer, "Driver Card");
		sleep(10);
		scrollDownPage();
		isDisplayedThenActionClick(orderCard, "Order Card");
		scrollUpPage();
		checkTextInPageAndValidate("Driver Name  must not be blank.", 20);
        //removed as per new req
        //checkTextInPageAndValidate("Fleet ID  must not be blank.", 20);	
		sleep(5);
		scrollDownPage();
		isDisplayedThenEnterText(driverName, "Driver Name", f_drivername);
		isDisplayedThenEnterText(fleetId, "Fleet ID", f_fleetID);
		isDisplayedThenActionClick(orderCard, "Order Card");
		sleep(5);
//		checkTextInPageAndValidate("Validation successful", 20);
		isDisplayed(successMsg, "successMsg");
		sleep(5);

		if (driverNameConfirm.getText().trim().equalsIgnoreCase(f_drivername)) {
			logPass("Driver Name is same");
		} else {
			logFail("Driver name is differnt");
		}
		if (fleetId.getText().trim().equalsIgnoreCase(f_fleetID)) {
			logPass("Fleet ID is same");
		} else {
			logFail("Fleet IDis differnt");
		}

	}

	/*
	 * public void validateCards(String cardOfferType) {
	 * 
	 * selectDropDownByVisibleText(cardOffer, cardOfferType); sleep(10);
	 * scrollDownPage(); isDisplayedThenActionClick(orderCard, "Order Card");
	 * scrollUpPage(); checkTextInPageAndValidate("Fleet ID  must not be blank.",
	 * 20);
	 * 
	 * if(cardOfferType.equals("Driver Card")) {
	 * checkTextInPageAndValidate("Driver Name  must not be blank.", 20); sleep(2);
	 * isDisplayedThenEnterText(driverName, "Driver Name",
	 * FakerAPI().name().fullName());
	 * 
	 * } else if (cardOfferType.equals("Vehicle Card")) {
	 * 
	 * }
	 * 
	 * 
	 * }
	 */

	public void orderVehicleCardValidation() {
		f_fleetID = fakerAPI().number().digits(5);
		f_regoNo = fakerAPI().number().digits(5);
		f_regoNo2 = fakerAPI().number().digits(15);

		selectDropDownByVisibleText(cardOffer, "Vehicle Card");
		sleep(10);
		scrollDownPage();
		isDisplayedThenActionClick(orderCard, "Order Card");
		scrollUpPage();
//		checkTextInPageAndValidate("Fleet ID  must not be blank.", 20);
		checkTextInPageAndValidate("Rego  must not be blank.", 20);
		sleep(2);
		isDisplayedThenEnterText(fleetId, "Fleet ID", f_fleetID);

		isDisplayedThenEnterText(regoNumber, "Rego number", f_regoNo2);

		isDisplayedThenActionClick(orderCard, "Order Card");
		sleep(10);
		checkTextInPageAndValidate("Rego Field allows only max of 12 [A-Za-z0-9.,'/[-]()&$# ] characters", 20);
		sleep(5);
		isDisplayedThenEnterText(regoNumber, "Rego number", f_regoNo);
		isDisplayedThenActionClick(orderCard, "Order Card");
		sleep(5);
		checkTextInPageAndValidate("Validation successful", 20);

		if (fleetId.getText().trim().equalsIgnoreCase(f_fleetID)) {
			logPass("Fleet ID is same");
		} else {
			logFail("Fleet IDis differnt");
		}

		if (regoNumberConfirm.getText().trim().equalsIgnoreCase(f_regoNo)) {
			logPass("Rego Number is same");
		} else {
			logFail("Rego Number is differnt");
		}

	}

	public void purchaseControlsfields() {

		selectDropDownByVisibleText(cardOffer, "Driver Card");
		sleep(5);
		selectDropDownByIndex(productRestrictionOid, 1);
		f_productRestrictionOID = selectedStringFrmDropDown(productRestrictionOid);
		System.out.println("---------" + f_productRestrictionOID + "------------------");
		selectDropDownByIndex(locationRes, 1);
		f_productAlertTime = selectedStringFrmDropDown(locationRes);
		selectDropDownByIndex(productDuringTime, 1);
		f_productAlertTime = selectedStringFrmDropDown(productDuringTime);

	}

	public void validateProtectedFieldsAndOderZBusinessCard() {

		//f_drivername = fakerAPI().name().fullName();
		f_drivername = fakerAPI().name().firstName();
		f_fleetID = fakerAPI().number().digits(5);
		f_regoNo = fakerAPI().number().digits(5);

		selectDropDownByIndex(cardOffer, 1);
		sleep(10);
		cardofferType = selectedStringFrmDropDown(cardOffer);
		System.out.println("----------------" + cardofferType + "----------------");
		
		if (cardofferType.contains("Driver Card")) {
			isDisplayedThenEnterText(driverName, "Driver Name", f_drivername);
			logPass("Driver Name Enter"+f_drivername);
		} else {
			logInfo("Dirver Name is not Enter");
		}

		sleep(5);
		isDisplayedThenEnterText(fleetId, "Fleet ID", f_fleetID);
		isDisplayedThenEnterText(regoNumber, "Rego number", f_regoNo);

		validateProtectedFieldsAndUpdateEditable();

		sleep(5);
		isDisplayedThenActionClick(orderCard, "Order Card");
		sleep(5);
		checkTextInPageAndValidate("Validation successful", 20);

		if (getText(fleetId).trim().equalsIgnoreCase(f_fleetID)) {
			logPass("Fleet ID is same");
		} else {
			logFail("Fleet IDis differnt");
		}

		if (getText(regoNumberConfirm).trim().equalsIgnoreCase(f_regoNo)) {
			logPass("Rego Number is same");
		} else {
			logFail("Rego Number is differnt");
		}

		if (getText(cardOfferTitle).equalsIgnoreCase(cardofferType)) {
			logPass("cardoffer Type is same");
		} else {
			logFail("cardoffer Type  is differnt");
		}

		if (getText(productRestrictionOid).trim().equalsIgnoreCase(f_productRestrictionOID)) {
			logPass("Product RestrictionOID is same");
		} else {
			logFail("Product RestrictionOID  is differnt");
		}

		if (getText(timeLimit).trim().equalsIgnoreCase(f_productAlertTime)) {
			logPass("Product AlertTime is same");
		} else {
			logFail("Product AlertTime is differnt");
		}

		/*
		 * if(getText(productlocationRes).trim().equalsIgnoreCase(f_productLocationAlert
		 * )) { logPass("Product AlertTime is same"); } else {
		 * logFail("Product AlertTime is differnt"); }
		 */

	}
	
	public void clickOrderCardButtonAndValidateSuccessMsg() {
		isDisplayedThenActionClick(orderCardButton, "Order Card Button");
		sleep(6);
		//validateSuccessMsgWithCardNumber(cardNumber);
	}

	public void validateSuccessMsgWithCardNumber(String cardNumberFromSuccessMsg) {
		System.out.println("Getting into the method");
		try {
			if (successMessage.isDisplayed()) {
				String getSuccessMsgCardNumber = successMessageWithCardNumber.getText();
				System.out.println("Getting card number from Success msg" + getSuccessMsgCardNumber);
				if (getSuccessMsgCardNumber.equals(cardNumberFromSuccessMsg)) {
					logPass("Success message with card number is Displayed");
				}
			} else {
				logFail("Success message with card number is Not Displayed");
			}
		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
	}

	public void validateProtectedFieldsAndUpdateEditable() {

		f_contactTitlename = fakerAPI().name().title();
		f_contactname = fakerAPI().name().fullName();
		f_contactAddress = fakerAPI().address().fullAddress();
		f_cityName = fakerAPI().address().cityName();
		f_postCode = fakerAPI().number().digits(4);

		// TODO Auto-Generated Method Stub

		// checkTextNotInPageAndValidate("PIN", 10);

		// POS validate
		selectDropDownOptionsRandomly(timeLimit, "select Different Limits");
		f_productAlertTime = selectedStringFrmDropDown(timeLimit);

//		selectDropDownOptionsRandomly(locationRes, "select Different Limits");
//		f_productLocationAlert = selectedStringFrmDropDown(locationRes);

		selectDropDownOptionsRandomly(productRes, "select Different Limits");
		f_productRestrictionOID = selectedStringFrmDropDown(productRes);

	/*	selectDropDownOptionsRandomly(monthlyLimit, "select Different Limits");
		f_monthlyLimits = selectedStringFrmDropDown(monthlyLimit);

		selectDropDownOptionsRandomly(transactionDolarLimit, "select Different Limits");
		f_transactionDolarLimits = selectedStringFrmDropDown(transactionDolarLimit);

		selectDropDownOptionsRandomly(dailyDolarLimit, "select Different Limits");
		f_dailyDolarLimits = selectedStringFrmDropDown(dailyDolarLimit);

		selectDropDownOptionsRandomly(transactionLimit, "select Different Limits");
		f_transactionLimis = selectedStringFrmDropDown(transactionLimit);*/

		// checkAnElementIsDisabled(driverName, "Driver Name is not editable");

		// checkAnElementIsDisabled(vehicleRegoNumber, "VRN is not editable");

		// isDisplayedThenEnterText(driverNameEditPage, "Driver Name is not editable",
		// FakerAPI().name().firstName());

		// isDisplayedThenEnterText(regoNumber, "VRN is not editable",
		// FakerAPI().number().digits(4));

		isDisplayedThenEnterText(contactTitleName, "Enter contact title name", f_contactTitlename);

		isDisplayedThenEnterText(contactName, "Enter contact name", f_contactname);

		isDisplayedThenEnterText(contactAddress, "Enter Address name", f_contactAddress);

		isDisplayedThenEnterText(cityName, "Enter City name", f_cityName);

		isDisplayedThenEnterText(postCode, "Enter Post Code", f_postCode);

		// sleep(3);
		// selectInputFromDropdown(stateName, 1);
		// sleep(3);
		selectInputFromDropdown(countryName, 2);
		sleep(3);

	}

	public void selectAllAccountsAndCardStatus(String cardStatus) {
		sleep(2);
		selectDropDownByVisibleText(accountList, "All Accounts");
		sleep(3);
		selectDropDownByVisibleText(filterCardStatus, cardStatus);

		sleep(2);
		isDisplayedThenClick(searchButton, "Search button");
		sleep(2);
	}

	public void clickOnCardAndSelectChangeStatus() {

		int randomNo;
		if (allListedCards.size() == 1) {
			randomNo = 0;
			f_cardNumber = getText(allListedCards.get(randomNo));
			System.out.println(f_cardNumber);

			actionClick(allListedCards.get(randomNo));
		} else if (allListedCards.size() > 1) {
			randomNo = getRandomNumber(0, allListedCards.size() - 1);
			f_cardNumber = getText(allListedCards.get(randomNo));
			System.out.println(f_cardNumber);
			actionClick(allListedCards.get(randomNo));
		} else {
			logInfo("No Cards Found");
		}
		sleep(5);
		clickCardTableMenuOption(changeCardStatus);
	}

	public void verifyChangeStatusActiveToCardOnHoldCustomerRequest() {

		checkTextInPageAndValidate("Change Card Status", 20);
		selectDropDownByVisibleText(newCardStatuss, "Card on hold - customer request");
		sleep(2);
		isDisplayedThenClick(saveButton, "Save button");
		// checkTextInPageAndValidate("New Card Status Invalid card status change
		// combination", 30);
		sleep(10);
		//isDisplayedThenActionClick(confirmReissueButton, " Reissue ");//check if exist , click else skip - RM add condition based on other clients
		sleep(10);
		isDisplayedThenActionClick(backToCardListCS, "Back to Card List");
	}

	public void verifyChangeStatuPinPendingToCardDamaged() {

		checkTextInPageAndValidate("Change Card Status", 20);
		selectDropDownByVisibleText(newCardStatuss, "Card damaged");
		sleep(2);
		isDisplayedThenClick(saveButton, "Save button");
		// checkTextInPageAndValidate("New Card Status Invalid card status change
		// combination", 30);
		sleep(10);
		isDisplayedThenActionClick(confirmReissueButton, " Reissue ");
		sleep(10);
		isDisplayedThenActionClick(backToCardListCS, "Back to Card List");
	}
	
	public void verifyChangeStatuCardRequestedToCardCancelled() {

		checkTextInPageAndValidate("Change Card Status", 20);
		selectDropDownByVisibleText(newCardStatuss, "Card order cancelled");
		sleep(2);
		isDisplayedThenClick(saveButton, "Save button");
		// checkTextInPageAndValidate("New Card Status Invalid card status change
		// combination", 30);
		/*sleep(10);
		isDisplayedThenActionClick(confirmReissueButton, " Reissue ");*/
		sleep(10);
		isDisplayedThenActionClick(backToCardListCS, "Back to Card List");
		sleep(2);
	}
	
	
	public void verifyChangeStatuCardOnHoldCustomerRequestToActive() {

		checkTextInPageAndValidate("Change Card Status", 20);
		selectDropDownByVisibleText(newCardStatuss, "Active");
		//enterADateValueInStatusBeginDateField("Future","ZE NZ");
		sleep(2);
		/*if(futureCardRadioButton.isDisplayed()) {
			isDisplayedThenActionClick(futureCardRadioButton, "Future Card Radio Button");
		} else {
			logInfo("No future card Radio Button");
		}*/
		sleep(5);
		isDisplayedThenClick(saveButton, "Save button");
		sleep(10);
	//	isDisplayedThenActionClick(confirmReissueButton, " Reissue ");
		sleep(10);
		isDisplayedThenActionClick(backToCardListCS, "Back to Card List");
		sleep(5);
	}

	public void checkCardStatusActiveToCardOnHoldCustomerRequest() {

		clickOnCardAndSelectChangeStatus();
		sleep(10);
		validateNewCardStatusDropdownValues();
		sleep(5);
		verifyChangeStatusActiveToCardOnHoldCustomerRequest();
		sleep(5);
		selectDropDownByVisibleText(filterchangeCardStatus, "Card on hold - customer request");
		sleep(2);
		isDisplayedThenClick(searchButton, "Search button");
		sleep(2);
		setCellDataFromTable(cardListTable, 7, false);
		int tableCardNumberListSize = customerNumberList.size();
		for (int j = 0; j < tableCardNumberListSize; j++) {
			cardAccNo = getCellDataFromTable(j, 0, false);
			currentCardStatus = getCellDataFromTable(j, 1, false);

			if (f_cardNumber.equals(cardAccNo)) {
				System.out.println("Got the current card status" + currentCardStatus);
				logPass("Successfully verified card status");
				break;
			} else {
				logPass("card status is diffirent");
			}
		}
	}

	public void validateNewCardStatusDropdownValues() {

		String[] expectedNewCardStatuDropdownValues = { "--Select One--", "Card Damaged", "Card Lost/Stolen",
				"Card cancelled", "Card on hold - Customer request", "Pin Pending" };
		List<String> expectedList = new ArrayList<String>();
		for (int i = 0; i < expectedNewCardStatuDropdownValues.length; i++) {
			expectedList.add(expectedNewCardStatuDropdownValues[i]);
		}
		List<String> actualList = new ArrayList<String>();
		List<WebElement> actualQueryDropdownValues = selectDropdownOptionValues(newCardStatuss);
		for (WebElement actualQueryDropdownValue : actualQueryDropdownValues) {
			actualList.add(actualQueryDropdownValue.getText());
		}
		if (expectedList.size() == actualList.size()) {
			for (int i = 0; i < expectedList.size(); i++) {
				if (expectedList.get(i).equals(actualList.get(i))) {
					System.out.println("Dropdown Values matches with expected " + actualList.get(i));
					logInfo("Dropdown Values matches with expected " + actualList.get(i));
				} else {
					System.out.println("Dropdown Values not matches");
					logInfo("Dropdown Values not matches");
				}
			}
		} else {
			System.out.println("Drop down values are not same in number");
			logInfo("Drop down values are not same in number");
		}

	}

	public void changeCardStatusPinPendingToDifferentStatus() {
		
		clickOnCardAndSelectChangeStatus();
		sleep(5);
		verifyChangeStatuPinPendingToCardDamaged();
		sleep(5);
		selectDropDownByVisibleText(filterCardStatus, "Card damaged");
		sleep(2);
		isDisplayedThenClick(searchButton, "Search button");
		sleep(10);
		scrollDownPage();
		setCellDataFromTable(cardListTable, 7, false);
		int tableCardNumberListSize = customerNumberList.size();
		System.out.println("F_cardNo:"+f_cardNumber);
		for (int j = 0; j < tableCardNumberListSize; j++) {
			cardAccNo = getCellDataFromTable(j, 0, false);
			currentCardStatus = getCellDataFromTable(j, 1, false);
			System.out.println("CardAccno:"+cardAccNo);
			System.out.println("currentCardStatus:"+currentCardStatus);
			if (f_cardNumber.equals(cardAccNo)) {
				System.out.println("Got the current card status:" + currentCardStatus);
				logPass("Successfully verified card status");
				break;
			} else if (!f_cardNumber.equals(cardAccNo)&&j==tableCardNumberListSize-1){
				logFail("No Cards Found");
			}
		}
	}

	public void changeCardStatusCardRequestedToCardCancelled() {

		clickOnCardAndSelectChangeStatus();
		sleep(5);
		verifyChangeStatuCardRequestedToCardCancelled();
		sleep(5);
		selectDropDownByVisibleText(filterCardStatus, "Card order cancelled");
		sleep(2);
		isDisplayedThenClick(searchButton, "Search button");
		sleep(10);
		scrollDownPage();
		setCellDataFromTable(cardListTable, 7, false);
		int tableCardNumberListSize = customerNumberList.size();
		for (int j = 0; j < tableCardNumberListSize; j++) {
			cardAccNo = getCellDataFromTable(j, 0, false);
			currentCardStatus = getCellDataFromTable(j, 1, false);

			if (f_cardNumber.equals(cardAccNo)) {
				System.out.println("Got the current card status" + currentCardStatus);
				logPass("Successfully verified card status");
				break;
			} else if (!f_cardNumber.equals(cardAccNo)&&j==tableCardNumberListSize-1){
				logFail("No Cards Found");
			}
		}
	}
	
	public void changeCardStatusCardOnHoldCustomerRequestToActive() {

		clickOnCardAndSelectChangeStatus();
		sleep(5);
		verifyChangeStatuCardOnHoldCustomerRequestToActive();
		sleep(5);
		selectDropDownByVisibleText(filterCardStatus, "Active");
		sleep(2);
		isDisplayedThenClick(searchButton, "Search button");
		sleep(10);
		scrollDownPage();
		setCellDataFromTable(cardListTable, 7, false);
		int tableCardNumberListSize = customerNumberList.size();
		for (int j = 0; j < tableCardNumberListSize; j++) {
			cardAccNo = getCellDataFromTable(j, 0, false);
			currentCardStatus = getCellDataFromTable(j, 1, false);

			if (f_cardNumber.equals(cardAccNo)) {
				System.out.println("Got the current card status" + currentCardStatus);
				logPass("Successfully verified card status");
				break;
			} else if (!f_cardNumber.equals(cardAccNo)&&j==tableCardNumberListSize-1){
				logFail("No Cards Found");
			}
		}
	}
	
	
	public void enterADateValueInStatusBeginDateField(String beginDate, String clientCountry) {
		String currentIFCSDate;
		String beginDateValue;
		getDBDetailsFromProperties = PropUtils.getPropValue(configProp, "sqlODSServerName");
		String queryToResetLogonCount = "SELECT PROCESSING_DATE from M_CLIENTS where IE_CLIENT_ID='" + clientCountry
				+ "'";
		currentIFCSDate = connectDBAndGetValue(queryToResetLogonCount, getDBDetailsFromProperties);
		try {
			DateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
			Date newDate;
			Calendar cal = Calendar.getInstance();
			cal.setTime(dateFormatter.parse(currentIFCSDate));

			if (beginDate.equals("Past")) {
				cal.add(Calendar.MONTH, -3);
			} else if (beginDate.equals("Current")) {
				newDate = cal.getTime();				
			} else {		
				cal.add(Calendar.MONTH, +3);
			}
			newDate = cal.getTime();
			DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
			beginDateValue = df.format(newDate);
			isDisplayedThenEnterText(newStatusBeginDate, "New Card Status Begin Date", beginDateValue);
		} catch (Exception e) {
			logFail(e.getMessage());
		}

	}
	
	public void checkCardListTableSorting() {
		String columnValuesExpected = "Card Number";
		commonPage.sortThecardNumberColumnAndValidate(cardListTable, columnValuesExpected);
		
	}
	
	
	public HashMap<String, String> bulkCardOrderUsingExcelSheetTemplate(String fileName, String accountNumber,String cardType, int bulkCount) {
		String downloadedFileName = getLatestDownloadedFileFromDir(fileName).getName();
		System.out.println("downloadedFileName :"+downloadedFileName);
//		String downloadedFileName ="Bulk_Order_20191204_112242.xls";
//		String downloadedFileName = "Bulk_Order_20191204_111703.xls";
		String downloadedFilePath = System.getProperty("user.home") + "\\Downloads\\" + downloadedFileName;
		System.out.println("downloadedFilePath :"+downloadedFilePath);
		HSSFSheet hssfSheet = ExcelUtils.readExcel(downloadedFilePath, "BULKCARD");
		HashMap<String, String> validationValues = new HashMap<String, String>();
		int rowCount = 0;
		HSSFRow row = null;
		HSSFCell cell = null;
		ArrayList<String> columnHeaders = ExcelUtils.readHeader(hssfSheet, 2);
		System.out.println("column headers::" + columnHeaders);
		
		/*Bulk Card Order*/
		
		for (int i = 0; i < bulkCount; i++) {
			HashMap<String, String> map = new HashMap<String, String>();

			if (cardType.equals("Driver")) {
				System.out.println("s1");
				SimpleDateFormat formatter = new SimpleDateFormat("YYMMddHHmmss");
				Date date = new Date();
				String currentDate = formatter.format(date);
				map.put("CardOffer", "Driver Card");
				map.put("DriverName", fakerAPI().name().firstName() + currentDate+i);
			} else if (cardType.equals("Vehicle")) {
				SimpleDateFormat formatter = new SimpleDateFormat("YYMMmmss");
				Date date = new Date();
				String currentDate = formatter.format(date);
				map.put("CardOffer", "Vehicle Card");
				map.put("RegoNumber", currentDate+i);
				map.put("VehicleDescription", fakerAPI().name().firstName() + currentDate);
			}
				map.put("AccountNumber", accountNumber);

			for (String entry : map.keySet()) {
				if (cardType.equals("Driver")) {
					if (entry.equals("DriverName")) {
						validationValues.put(entry + i, map.get(entry));
						System.out.println("s1");
						System.out.println("<---->"+validationValues.put(entry + i, map.get(entry)));
					}
				} else {
					if (entry.equals("RegoNumber")) {
						validationValues.put(entry + i, map.get(entry));
						System.out.println("<---->"+validationValues.put(entry + i, map.get(entry)));
					}
				}
			}
			
			rowCount = getRowNumberForBulkCardOrder(hssfSheet, 2);
			System.out.println("outside");
			row = hssfSheet.getRow(rowCount - 1);
			row = hssfSheet.createRow(rowCount - 1);
			for (int a = 0; a < columnHeaders.size(); a++) {
				for (String entry : map.keySet()) {
					if (columnHeaders.get(a).equals(entry)) {
						cell = row.getCell(a);
						cell = row.createCell(a);
						cell.setCellValue(map.get(entry));
					}
				}
			}

		}
		ExcelUtils.writeExcel(downloadedFilePath);
		return validationValues;
	}

	public int getRowNumberForBulkCardOrder(HSSFSheet workSheet, int rowNum) {
		int i, k = 0, count = 0, defaultCount = 2;
		 System.out.println("Last row num-->" + workSheet.getLastRowNum());
		for (i = rowNum; i < workSheet.getLastRowNum(); i++) {
			for (int j = 0; j < defaultCount; j++) {
				 System.out.println("i-->" + i);
				 System.out.println("j-->" + j);
				String value = workSheet.getRow(i).getCell(j).getStringCellValue();
				 System.out.println("Value" + value);

				if (value.equals("")) {
					k = 1;
					count++;
					break;
				}
			}
			if (k == 1 && count == defaultCount) {
				break;
			}
		}
		return i;
	}
	
	public ArrayList<String> getBulkCardNumberForCardType(HashMap<String, String> keyAndValues, String cardType) {

		String cardNumber = null;
		ArrayList<String> bulkCardNumbers=new ArrayList<String>();
		String cardNumberFromDB ;
		for(int i=0;i<keyAndValues.size();i++) {
		for (String key : keyAndValues.keySet()) {
//			if (cardType.equals("Vehicle"+i)) {
				if (key.equals("RegoNumber"+i)) {
					cardNumberFromDB= "Select card_no from cards where vehicle_oid in (select vehicle_oid from vehicles where license_plate='"
							+ keyAndValues.get(key) + "')";
					cardNumber = connectDBAndGetValue(cardNumberFromDB,
							PropUtils.getPropValue(configProp, "sqlODSServerName"));
//				}
			} else {
				if (key.equals("DriverName"+i)) {
					cardNumberFromDB = "Select card_no from cards where driver_oid in (select driver_oid from drivers where driver_name='"
							+ keyAndValues.get(key).toUpperCase() + "')";
					cardNumber = connectDBAndGetValue(cardNumberFromDB,
							PropUtils.getPropValue(configProp, "sqlODSServerName"));
				}
			}
		}
		bulkCardNumbers.add(cardNumber);
		}
		return bulkCardNumbers;

	}
	
	public ArrayList<String> getBulkCardNumberForCardType(HashMap<String, String> keyAndValues) {

		String cardNumber = null;
		int count=1;
		ArrayList<String> bulkCardNumbers = new ArrayList<String>();
		for (int i = 0; i < keyAndValues.size(); i++) {
			for (String key : keyAndValues.keySet()) {
				if (key.equals("RegoNumber" + i)) {
					String cardNumberFromDB = "Select card_no from BULK_CARD_DETAILS where LICENSE_PLATE = '"+keyAndValues.get(key)+"'";
					cardNumber = connectDBAndGetValue(cardNumberFromDB,
							PropUtils.getPropValue(configProp, "sqlODSServerName"));
					if(!cardNumber.equals(" ")) {
						logPass(cardNumber+" Card no successfully generated in IFCS");
					}else
						logInfo(keyAndValues.get(key)+" There is some issue in this record, So card is not generated");
				} else {
					if (key.equals("DriverName" + i)) {
						String cardNumberFromDB = "Select card_no from BULK_CARD_DETAILS where DRIVER_NAME = '"+keyAndValues.get(key)+"'";
						cardNumber = connectDBAndGetValue(cardNumberFromDB,
								PropUtils.getPropValue(configProp, "sqlODSServerName"));
					if(!cardNumber.equals(" ")) {
						logPass(cardNumber+" Card no successfully generated in IFCS");
					}else
						logInfo(keyAndValues.get(key)+" There is some issue in this record, So card is not generated");
					}
				}
			}
			bulkCardNumbers.add(cardNumber);
		}
		
		for(String values : bulkCardNumbers) {
			if(values.equals(" ")) {
				count++;
			}
		}
		
		System.out.println("count -->"+count);
		
		if(count==bulkCardNumbers.size()) {
			logFail("Something went wrong, so that card were not generated");
		}
		return bulkCardNumbers;

	}

	public void searchOrderedCardsInOLS(ArrayList<String> CardNos) {

		ZCardsPage cardPage = new ZCardsPage(driver, test);
		CardsPage cardsCommonPage = new CardsPage(driver, test);
		ZHomePage zHomePage = new ZHomePage(driver, test);
		
		// Go to Card List
		zHomePage.goToCardMenuCardList();

		zHomePage.verifyCardListPage();
		String actualCardNo="";

		cardsCommonPage.selectAllAccountsAlone();
		for(String cardNo : CardNos) {
		
		isDisplayedThenEnterText(cardSearchBox, "card search filter", cardNo);
		
		isDisplayedThenClick(searchButton, "Search button");
		
//		cardsCommonPage.clickSearchButtonAndValidate();
		sleep(1);
		
		setCellDataFromTable(cardListTable, 7, false);
			actualCardNo = getCellDataFromTable(1, 0, false);
			System.out.println("/n"+actualCardNo);

			if (actualCardNo.equals(cardNo)) {
				System.out.println("Got the current card status" + currentCardStatus);
				logInfo("CardNo --> "+cardNo);
				logPass("Successfully verified card No");
			} else {
				softFail(cardNo+"card not found in cards table");
			}

		
		}

		boolean isNoCardsPresent = cardPage.waitForTextToAppear("No Cards found.", 10);

		if (!isNoCardsPresent) {
			cardPage.checkCardListTableSorting();

		}

	}




}

