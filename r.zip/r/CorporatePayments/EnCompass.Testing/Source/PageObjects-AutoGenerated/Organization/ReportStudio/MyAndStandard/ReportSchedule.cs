using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using Common;
using Common.PageObjects;
using Common.ScenarioConfigurations;
using Common.Utility;

namespace EnCompass.Testing.Source.PageObjects.Organization.ReportStudio.MyAndStandard 
{
	/// <summary>
	/// Auto-generated Page Model Class
	/// Navigation Paths: 
		/// [Organization Home]->Reports->Scheduled Reports
		/// </summary>
	[PageModel(@"/reportStudio/myAndStandard/ReportSchedule.aspx")]
	public partial class ReportSchedule : EnCompassOrgPageModel 
	{
		public override string RelativeUrl => @"/reportStudio/myAndStandard/ReportSchedule.aspx";
		public override string PageIdentifierXPath_Generated => @"//li[contains(@class, 'breadcrumb-item active')][text() = 'Scheduled Reports']";

		#region Navigation
		
		private void NavigateToMenuItem(IWebElement element)
		{
			Driver.Url = element.GetAttribute("href");
		}
		#endregion

		public ReportSchedule(GlobalSettings settings) : base(settings) { }
	}  
}
