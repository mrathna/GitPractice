package com.framework.testcases.AJS.BP.Interface;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.ChangeCardStatus;
import com.framework.pages.AJS.common.Common;
import com.framework.pages.AJS.common.IFCSCommonPage;
import com.framework.pages.AJS.common.IFCSHomePage;
import com.framework.pages.AJS.common.IFCSLoginPage;
import com.framework.pages.AJS.common.InterfacePage;

public class ValidateManualAccountLockTestCase extends BaseTest {
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "Smoke" ,"BusinessFlow"})
	public void validateManualAccountTempLock(@Optional("NZ") String clientCountry, @Optional("BP") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  BPNZ28_Cust_NZ_007_Manual account lock",
				"Change the Active Account to Temp Lock, Run CT1b job and Validate Card Status");
		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCShomePage = new IFCSHomePage(driver, test);
		Common common = new Common(driver, test);
		ChangeCardStatus changeCardStatus = new ChangeCardStatus(driver, test);
		IFCSCommonPage ifcsCommonPage = new IFCSCommonPage(driver, test);
		InterfacePage interfacePage = new InterfacePage(driver, test);
		//CommonInterfacePage commonInterfacePage = new CommonInterfacePage(driver, test);
		// Calling Functions

		IFCSloginPage.login("IFCS_URL_BP", "IFCS_BP_USERNAME", "IFCS_BP_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, " ");
		String customerNumber = common.getActiveOrTemporaryBlockCustomerNoHavingCardsAndRowIndex(1, "Active");
		IFCShomePage.gotoCustomerMenuCustomerDetails();
		common.chooseCustomerNoAndSearch(customerNumber);
		IFCShomePage.gotoAccountAndClickAccountDetails();

		// Change CustomerAccount Status
		changeCardStatus.changeCustomerAccountStatus("Temporary Lock");
		String folderName = ifcsCommonPage.getControlMFolder(clientName, clientCountry,
				"jobS_CardPositiveChanges" + clientCountry);
		String jobsInOrder = ifcsCommonPage.getJobsOfFolderInOrder("jobS_CardPositiveChanges" + clientCountry);

		// Executing control-m jobs
		interfacePage.establishAndExecuteControlMJobs("ControlM_AWS_UAT", "ContorlM_AWS_userName",
				"ContorlM_AWS_password", folderName, jobsInOrder);
		IFCShomePage.gotoCustomerMenuCustomerDetails();
		changeCardStatus.validateCustomerHasCards();
		changeCardStatus.validateTemporaryLockStatusInCards("400 Temporary Acct Lock");

//		// Get Recent Processed File from IE Server  - Fix Needed
//		String fileName = commonInterfacePage.getRecentProcessedFileNames(clientName, clientCountry, "RM_G1_0198");
//		ifcsCommonPage.establishThePuttyConnection("unzip", "PUTTY_HOST", "PUTTY_USERNAME", "PUTTY_PASSWORD",
//				"IE_OUTPUTFILE_FOLDER_POS_CARDCHANGE", fileName);

	//	String localFolder = System.getProperty("user.home") + "\\Documents\\" + (fileName.replace(".zip", ".xml"));
		//As we have validated using array, aded record count in a array
		
	//	String expectedCardNumbers[];
	//	expectedCardNumbers = common.getCardsListOfTheCustomer(customerNumber);
		/*ifcsCommonPage.validateIncomingXMLFile(localFolder, expectedCardNumbers, "ifcs:GetPositiveCard",
				"core:CardNumber");*/
		 IFCShomePage.exitIFCS();

	}

	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "Smoke" ,"BusinessFlow"})
	public void validateAccountStatusChangeToActive(@Optional("NZ") String clientCountry,
			@Optional("BP") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  BPNZ29_Cust_NZ_008_Manually activating temp locked account",
				"Change the Temp Lock Account to Active, Run CT1b job and Validate Card Status");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCShomePage = new IFCSHomePage(driver, test);
		IFCSCommonPage ifcsCommonPage = new IFCSCommonPage(driver, test);
		InterfacePage interfacePage = new InterfacePage(driver, test);
		ChangeCardStatus changeCardStatus = new ChangeCardStatus(driver, test);
		Common common = new Common(driver, test);
		//CommonInterfacePage commonInterfacePage = new CommonInterfacePage(driver, test);
		IFCSloginPage.login("IFCS_URL_BP", "IFCS_BP_USERNAME", "IFCS_BP_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		IFCShomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);
		// Get CustomerNumber from DB
		String customerNumber = common.getActiveOrTemporaryBlockCustomerNoHavingCardsAndRowIndex(1, "Temporary Lock");
		IFCShomePage.gotoCustomerMenuCustomerDetails();
		common.chooseCustomerNoAndSearch(customerNumber);
		IFCShomePage.gotoAccountAndClickAccountDetails();

		// Change CustomerAccount Status
		changeCardStatus.changeCustomerAccountStatus("Active");
			String folderName = ifcsCommonPage.getControlMFolder(clientName, clientCountry,
				"jobS_CardPositiveChanges" + clientCountry);
		String jobsInOrder = ifcsCommonPage.getJobsOfFolderInOrder("jobS_CardPositiveChanges" + clientCountry);

		// Executing control-m jobs
		interfacePage.establishAndExecuteControlMJobs("ControlM_AWS_UAT", "ContorlM_AWS_userName",
				"ContorlM_AWS_password", folderName, jobsInOrder);
		IFCShomePage.gotoCustomerMenuCustomerDetails();
		changeCardStatus.validateCustomerHasCards();
		changeCardStatus.validateStatusInCardsAfterUnblock();
		// File Verification  - Fix Needed

		// Get Recent Processed File from IE Server
		/*String fileName = commonInterfacePage.getRecentProcessedFileNames(clientName, clientCountry, "RM_G1_0198");
		ifcsCommonPage.establishThePuttyConnection("unzip", "PUTTY_HOST", "PUTTY_USERNAME", "PUTTY_PASSWORD",
				"IE_OUTPUTFILE_FOLDER_POS_CARDCHANGE", fileName);

		String localFolder = System.getProperty("user.home") + "\\Documents\\" + (fileName.replace(".zip", ".xml"));

		String expectedRecordCount[] = new String[1];
		expectedRecordCount[0] = "0";
		ifcsCommonPage.validateIncomingXMLFile(localFolder, expectedRecordCount, "ifcs:GetPositiveCards", "core:RecordCount");
		*///IFCShomePage.exitIFCS();
	}
}
