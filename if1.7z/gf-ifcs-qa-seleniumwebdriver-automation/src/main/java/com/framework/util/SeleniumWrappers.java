package com.framework.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class SeleniumWrappers {

	private static int totalTH;
	private static HashMap<String, String> rowColValue = new HashMap<String, String>();
	private static HashMap<String, String> rowColElement = new HashMap<String, String>();

	// private static HashMap<String, String> rowColValue = new HashMap<String,
	// String>();

	public static void setTotalTableHeaders(int totTH) {
		totalTH = totTH;
	}

	public static int getTotalTableHeaders() {
		return totalTH;
	}

	// Retrieving table headers of a table in HashSet
	public static HashSet<String> getAllTableHeaders(List<WebElement> allHeadersOfTable) {
		HashSet<String> allHeaderSet = new HashSet<String>();
		int totalHeaders = 0;

		try {

			String headerValue = null;
			/*
			 * System.out.println("Storing all header of table in a hashset ");
			 * System.out.println("Headers in table are below:");
			 */

			totalHeaders = allHeadersOfTable.size();
			/* System.out.println("Total headers found: "+totalHeaders); */
			setTotalTableHeaders(totalHeaders);
			for (WebElement header : allHeadersOfTable) {
				headerValue = header.getText();
				allHeaderSet.add(headerValue);
			}
			return allHeaderSet;
		}

		catch (Exception e) {
			System.out.println(e.getMessage());
			return allHeaderSet;

		}
	}

	/**
	 * Get table data with the column number you are giving
	 * 
	 * @return List of row values in the Column Number
	 */

	public static List<String> getTableDataWithColumnNumber(int colIndex, List<WebElement> allCells, WebDriver driver) {
		int noOfRows = getTotalNumberOfRows(allCells, driver);
		List<String> retrivedDatas = new ArrayList<String>();
		String value;
		for (int i = 0; i < noOfRows; i++) {
			try {
				value = driver.findElement(By.xpath("//div[contains(@id,'_" + i + "_" + colIndex + "')]//*[2]")).getTagName();
				if (value.equals("div")) {
					System.out.println("inside if");
					value = (driver.findElement(By.xpath("//div[contains(@id,'_" + i + "_" + colIndex + "')]//*[2]"))
							.getText());
				}
				else {
					value = driver.findElement(By.xpath("//div[contains(@id,'_" + i + "_" + colIndex + "')]//*[2]"))
							.getAttribute("value");
				}
			} catch (Exception ex) {
				value = "";
			}
			retrivedDatas.add(value);
			System.out.println("Row Data: " + i + ":" + colIndex + ":" + value);
		}
		return retrivedDatas;
	}

	/**
	 * Get table data with the row and column number with passed parameters
	 * 
	 * @return Table cell value with the row and column name
	 */
	public static String getTableDataWithRowAndColumnNumber(int colIndex, int rowNo, WebDriver driver) {
		String value = " ";
		System.out.println("Col::"+colIndex);
		System.out.println("rowNo::"+rowNo);
		try {
		driver.findElement(By.xpath("//div[contains(@id,'_" + rowNo + "_" + colIndex + "')]")).isDisplayed();
		} catch (NoSuchElementException ex) {
		System.out.println(
		"No Data found for the Row and Column value provided!!!  Row:" + rowNo + "Col:" + colIndex);
		}
		try {
		value = driver.findElement(By.xpath("//div[contains(@id,'_" + rowNo + "_" + colIndex + "')]//*[2]")).getTagName();
		System.out.println(" value is 0 "+value);
		//.getAttribute("value");
		if (value.equals("div")) {
		value = (driver.findElement(By.xpath("//div[contains(@id,'_" + rowNo + "_" + colIndex + "')]//*[2]"))
		.getText());
		System.out.println(" value is 1"+value);
		}
		else {
		value = (driver.findElement(By.xpath("//div[contains(@id,'_" + rowNo + "_" + colIndex + "')]//*[2]"))
		.getAttribute("value"));
		System.out.println(" value is 2 "+value);
		}
		} catch (NoSuchElementException ex) {
		value = "";
		}
		System.out.println("Row Data: " + value);
		return value;
		}

	// Added by NK
	public static WebElement getTableDataWithCellElement(int row, int column, WebDriver driver) {
		WebElement cellValueElement = null;

		try {
			driver.findElement(By.xpath("//div[contains(@id,'_" + row + "_" + column + "')]")).isDisplayed();
		} catch (NoSuchElementException ex) {
			System.out.println("No Data found for the Row and Column value provided!!!  Row:" + row + "Col:" + column);
		}
		try {
			cellValueElement = driver.findElement(By.xpath("//div[contains(@id,'_" + row + "_" + column + "')]//*[2]"));
		} catch (NoSuchElementException ex) {
			ex.getMessage();
		}
		// System.out.println("Row Data: " + value);
		return cellValueElement;
	}

	/**
	 * Get matched table rows with expected values
	 * 
	 * @return List of row indexes that matched the expected value
	 */
	public static List<Integer> getMatchedTableRowsWithExpectedValues(int colIndex, List<WebElement> allCells,
			String expectedValue, WebDriver driver) {
		int noOfRows = getTotalNumberOfRows(allCells, driver);
		List<Integer> retrivedDatas = new ArrayList<Integer>();
		String value;
		for (int i = 0; i < noOfRows; i++) {
			try {
				value = driver.findElement(By.xpath("//div[contains(@id,'_" + i + "_" + colIndex + "')]//*[2]"))
						.getAttribute("value");
				if (value.length() <= 0) {
					value = (driver.findElement(By.xpath("//div[contains(@id,'_" + i + "_" + colIndex + "')]//*[2]"))
							.getText());
				}
			} catch (Exception ex) {
				value = "";
			}
			if (value.equalsIgnoreCase(expectedValue)) {
				retrivedDatas.add(i);
			}
			System.out.println("Row Data: " + i + ":" + colIndex + ":" + value);
		}
		return retrivedDatas;
	}

	public static void setCellValue(List<WebElement> allCells) {

		try {

			int column, row;

			String cellKey;
			String cellValue = null;
			String locFormation;
			String cellElementString = " ";
			WebElement subElement;

			row = 0;
			column = 0;
			for (WebElement cellA : allCells) {

				locFormation = "";
				cellKey = "Cell";

				locFormation = "_" + row + "_" + column + "Input";

				cellKey = cellKey + locFormation;

				try {
					subElement = cellA.findElement(By.xpath(".//*[2]"));
					if (subElement.getTagName().equalsIgnoreCase("div")) {
						if (subElement.getAttribute("@class") == "") {
							cellValue = subElement.getText();
							cellElementString = "//div[@id='" + cellA.getAttribute("id")
									+ "']//div[@class='htmlString']";
						} else if (cellA.findElement(By.xpath(".//*[3]")).getAttribute("class") == "htmlImage") {
							cellValue = "";
							cellElementString = "//div[@id='" + cellA.getAttribute("id")
									+ "']//div[@class='htmlImage']";
						}

					} else if (subElement.getTagName().equalsIgnoreCase("input")) {
						cellValue = subElement.getAttribute("value");
						cellElementString = ".//input[contains(@id,'" + locFormation + "')]";
					} else {
						cellValue = "";
						cellElementString = "//div[@id='" + cellA.getAttribute("id") + "']//*";
						System.out.println(
								"Table Cell has other tags than div and input:: Unable to read the cell data!!");
					}

				} catch (Exception ex) {
					cellValue = "";
					cellElementString = "//div[@id='" + cellA.getAttribute("id") + "']//div[not(@class)]";

				}

				System.out.println("---- Cell Key in set ----" + cellKey);

				System.out.println("---- Cell value in set ----" + cellValue);

				rowColValue.put(cellKey, cellValue);
				rowColElement.put(cellKey, cellElementString);
				column++;
				if (column == (getTotalTableHeaders())) {
					row++;
					column = 0;
				}
			}

			System.out.println("ROW Col Value Size 11111 " + rowColValue.size());
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

	}

	public static void setCellValueforPopup(List<WebElement> allCells, String locator, WebDriver driver) {

		try {

			int column, row;

			String cellKey;
			String cellValue = null;
			String locFormation;
			String cellElementString;

			for (WebElement cellA : allCells) {
				row = 0;
				column = 0;
				locFormation = "";
				cellKey = "Cell";
				WebElement subElement;
				locFormation = "_" + row + "_" + column + "Input";

				cellKey = cellKey + locFormation;

				System.out.println("---- locFormation ----" + locFormation);

				try {
					subElement = cellA.findElement(By.xpath(".//*[2]"));
					if (subElement.getTagName().equalsIgnoreCase("div")) {
						cellValue = subElement.getText();
						cellElementString = "//div[@id='" + cellA.getAttribute("id") + "']//div[@class='htmlString']";
					} else if (subElement.getTagName().equalsIgnoreCase("input")) {
						cellValue = subElement.getAttribute("value");
						cellElementString = locator + "//input[contains(@id,'" + locFormation + "')]";
					} else {
						cellValue = " ";
						cellElementString = "//div[@id='" + cellA.getAttribute("id") + "']//*";
						System.out.println(
								"Table Cell has other tags than div and input:: Unable to read the cell data!!");
					}

				} catch (Exception ex) {
					cellValue = " ";
					cellElementString = "//div[@id='" + cellA.getAttribute("id") + "']//div[not(@class)]";

				}

				System.out.println("---- Cell Key in set ----" + cellKey);

				System.out.println("---- Cell value in set ----" + cellValue);

				rowColValue.put(cellKey, cellValue);
				rowColElement.put(cellKey, cellElementString);
				column++;
				if (column == (getTotalTableHeaders())) {
					row++;
					column = 0;
				}

			}

			System.out.println("ROW Col Value Size 11111 " + rowColValue.size());
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

	}

	// Retrieving the particular Cell Value in a table
	public static String getTableCellValue(int row, int column) {
		String cellValue = "";
		try {

			String key = "Cell_" + row + "_" + column + "Input";

			/*
			 * System.out.println("ROW Col Value Size 2222 "+rowColValue.size());
			 * 
			 * System.out.println("---- Cell Key in get ----"+key);
			 */

			cellValue = rowColValue.get(key);

			/* System.out.println("---- Cell value in get ----"+cellValue); */

			return cellValue;
		}

		catch (Exception e) {
			System.out.println(e.getMessage());
			return cellValue;
		}
	}

	// Retrieve the total number of cells in a table
	public static int getTotalNumberOfCells(List<WebElement> allCells) {
		int totCells = 0;

		try {

			totCells = allCells.size();

			return totCells;
		} catch (Exception e) {
			return totCells;
		}
	}

	// Raxsana ---> Added
	// Retrieving the particular WebElement of the Cell in a table -> Need to
	// setCellValue
	public static WebElement getTableCellElement(int row, int column, WebDriver driver) {
		WebElement cellValueElement = null;

		String elementValue;

		try {
			String key = "Cell_" + row + "_" + column + "Input";
			System.out.println("row column::" + key);
			System.out.println("map::" + rowColElement);

			elementValue = rowColElement.get(key);

			System.out.println(elementValue);

			cellValueElement = driver.findElement(By.xpath(elementValue));

			return cellValueElement;
		}

		catch (Exception e) {
			System.out.println(e.getMessage());

			return cellValueElement;
		}
	}

	// Retrieve the total number of rows in a table
	public static int getTotalNumberOfRows(List<WebElement> allCells, WebDriver driver) {

		int row = 0;
		WebElement cellElement;
		String cellValue;

		try {
			cellElement = allCells.get(allCells.size() - 1);
			cellValue = cellElement.getAttribute("id");
			//System.out.println("CellValue:" + cellValue);
			String[] bits = cellValue.split("_");
			row = Integer.parseInt(bits[bits.length - 2]);
			row = row + 1;
			//System.out.println("Row:" + row);

			return row;
		} catch (Exception e) {
			System.out.println(e.getMessage());
			return row;
		}
	}

	public static int getColumnNoForColumnHeader(String colHeader, List<WebElement> headers) {
		int colIndex = 0;
		String[] bits;
		for (WebElement header : headers) {
			if (header.getText().equals(colHeader)) {
				bits = header.getAttribute("id").split("_");
				colIndex = Integer.parseInt(bits[bits.length - 1]);
				//colIndex++;
				break;
			}
			colIndex++;
		}
		return colIndex;
	}

	public static int getNumberOfColumns(WebDriver driver, String tableName) {
		int colSize = driver.findElements(By.xpath("//div[@class='JFALSeparator']//div[" + tableName
				+ "]/preceding::div[@class='JFALCompControlPanel'][1]//div[@class='JViewport']/div[@class='JTableHeader']//div[@class='HeaderRenderer']"))
				.size();
		setTotalTableHeaders(colSize);
		return colSize;
	}

	public static int getNumberOfColumnsInPopup(WebDriver driver, String tableName) {
		int colSize = driver.findElements(By.xpath(
				"//div[@class='JFALCompControlPanel']//div[@class='JViewport']/div[@class='JTableHeader']//div[@class='HeaderRenderer']"))
				.size();
		setTotalTableHeaders(colSize);
		return colSize;
	}

	public static int getNumberOfRows(WebDriver driver) {
		int rowSize = getTotalNumberOfRows(
				driver.findElements(By.xpath("//div[starts-with(@class,'FALTableCellEditor_StrikeThru')]")), driver);
		return rowSize;
	}

}
