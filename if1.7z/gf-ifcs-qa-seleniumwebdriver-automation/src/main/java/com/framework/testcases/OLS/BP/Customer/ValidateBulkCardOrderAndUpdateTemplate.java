package com.framework.testcases.OLS.BP.Customer;

import java.util.HashMap;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.common.Common;
import com.framework.pages.AJS.common.IFCSHomePage;
import com.framework.pages.AJS.common.IFCSLoginPage;
import com.framework.pages.BP.BPHomePage;
import com.framework.pages.BP.BPOrderCard;
import com.framework.pages.OLS.common.BPCommonPage;
import com.framework.pages.OLS.common.BulkOrderAndUpdatePage;
import com.framework.pages.OLS.common.FindAndUpdateCardPage;
import com.framework.pages.OLS.common.LoginPage;


public class ValidateBulkCardOrderAndUpdateTemplate extends BaseTest {

	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "Smoke" }, enabled=false)
	public void validateOnlineCardOrder(@Optional("AU") String clientCountry, @Optional("BP") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  BP Bulk Card Order Template", "Validate the Bulk Card Order Template");

		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		LoginPage loginPage = new LoginPage(driver, test);
		BPOrderCard orderCardPage = new BPOrderCard(driver, test);
		FindAndUpdateCardPage findAndUpdateCardPage = new FindAndUpdateCardPage(driver, test);
		BPHomePage bpHomePage = new BPHomePage(driver, test);
		BPCommonPage bpCommonPage = new BPCommonPage(driver, test);
		Common common = new Common(driver, test);

		loginPage.Login("BP_URL", "BP_UN_Customer_" + clientCountry, "BP_PWD_Customer_" + clientCountry, clientName);

		HashMap<String, String> vehicleKeysAndValues = new HashMap<String, String>();
		HashMap<String, String> driverKeysAndValues = new HashMap<String, String>();

		bpHomePage.ValidateBPCustomerLogo();
		bpCommonPage.selectAccount();
		String accountNumber = bpCommonPage.getAccountNumber();
		orderCardPage.clickBulkOrderAndUpdateCard();
		orderCardPage.clickBulkCardOrderBtnAndValidate("Bulk_Order");
		//fill the order card template 
		vehicleKeysAndValues = orderCardPage.orderCardUsingExcelSheetTemplate("Bulk_Order_", accountNumber, "Vehicle");

		driverKeysAndValues = orderCardPage.orderCardUsingExcelSheetTemplate("Bulk_Order_", accountNumber, "Driver");
		
		orderCardPage.assertColumnHeaders("BULKCARD");
		
		orderCardPage.bulkOrderUpload("Bulk_Order");

		loginPage.Logout();

		IFCSloginPage.login("IFCS_URL_BP", "IFCS_BP_USERNAME", "IFCS_BP_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");

		//run Control-M jobs
		IFCSHomePage.gotoAdminBatchMenuAndChooseClient(clientName,clientCountry);
		common.batchJobExecution("Card Processing", "Online Card Management Request",
				"Online Card Ordering Request Processor");
		common.batchJobExecution("Card Processing", "Card Emboss Catalog", "Card Emboss Catalog");
	
		String vehicleCardNo = orderCardPage.getCardNumberForCardType(vehicleKeysAndValues, "Vehicle");
		String driverCardNo = orderCardPage.getCardNumberForCardType(driverKeysAndValues , "Driver");
	
		//validate ordered card number in IFCS
		common.validateOrderedCardNumberInIFCS(vehicleCardNo);
		common.validateOrderedCardNumberInIFCS(driverCardNo);
		
		IFCSHomePage.exitIFCS();

		loginPage.Login("BP_URL", "BP_UN_Customer_" + clientCountry, "BP_PWD_Customer_" + clientCountry, clientName);

		bpHomePage.loadFindAndUpdateCardPage();

		// Search in Find Update Card Page
		findAndUpdateCardPage.selectAccountFromFindUpdateCardPage();
		//validate ordered card number in OLS
		orderCardPage.validateOrderedCardInOLS(vehicleCardNo);
		orderCardPage.validateOrderedCardInOLS(driverCardNo);

		loginPage.Logout();

	}
	
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "Smoke" })
	public void validateOnlineCardUpdate(@Optional("AU") String clientCountry, @Optional("BP") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  BP Bulk Card Update Template", "Validate the Bulk Card Update Template");
		
		LoginPage loginPage = new LoginPage(driver, test);
		BPHomePage bpHomePage = new BPHomePage(driver, test);
		BPCommonPage bpCommonPage = new BPCommonPage(driver, test);
		BPOrderCard orderCardPage = new BPOrderCard(driver, test);
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		Common common = new Common(driver, test);
		FindAndUpdateCardPage findAndUpdateCardPage = new FindAndUpdateCardPage(driver, test);
		BulkOrderAndUpdatePage bulkOrdeAndUpdatePage = new BulkOrderAndUpdatePage(driver, test);
		loginPage.Login("BP_URL", "BP_UN_Customer_" + clientCountry, "BP_PWD_Customer_" + clientCountry, clientName);
		
		bpHomePage.ValidateBPCustomerLogo();
		bpCommonPage.selectAccount();
		String accountNumber = bpCommonPage.getAccountNumber();
		
		//Update the driver card values in template
		bpHomePage.loadBulkOrderAndUpdateCardPage();
		bulkOrdeAndUpdatePage.selectBulkCardOperation("Bulk Card Update");
		bulkOrdeAndUpdatePage.selectAllAccountFromBulkCardOperation("Update");
		String driverCardNumber=bulkOrdeAndUpdatePage.getCardNumberToUpdateExcel("Bulk_Update",accountNumber,"Driver");
		String updatedDriverName=bulkOrdeAndUpdatePage.updateExcelValues("Bulk_Update",driverCardNumber,"Driver");
		orderCardPage.bulkOrderUpload("Bulk_Update");
		
		//Update the vehicle card values in template
		bpHomePage.loadBulkOrderAndUpdateCardPage();
		bulkOrdeAndUpdatePage.selectBulkCardOperation("Bulk Card Update");
		String vehicleCardNumber=bulkOrdeAndUpdatePage.getCardNumberToUpdateExcel("Bulk_Update",accountNumber,"Vehicle");
		String updatedRegNumber=bulkOrdeAndUpdatePage.updateExcelValues("Bulk_Update",vehicleCardNumber,"Vehicle");
		orderCardPage.bulkOrderUpload("Bulk_Update");
		
		loginPage.Logout();
		
		IFCSloginPage.login("IFCS_URL_BP", "IFCS_BP_USERNAME", "IFCS_BP_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		
		//run Control-M jobs
		IFCSHomePage.gotoAdminBatchMenuAndChooseClient(clientName,clientCountry);
		common.batchJobExecution("Card Processing", "Online Card Management Request",
				"Online Card Detail Update Request Processor");
		common.batchJobExecution("Card Processing", "Card Emboss Catalog", "Card Emboss Catalog");
		
		//Validate Updated values in IFCS
		common.validateUpdatedValuesInIFCS(vehicleCardNumber,updatedRegNumber,"Vehicle");
		common.validateUpdatedValuesInIFCS(driverCardNumber,updatedDriverName,"Driver");
		
		loginPage.Login("BP_URL", "BP_UN_Customer_" + clientCountry, "BP_PWD_Customer_" + clientCountry, clientName);

		bpHomePage.loadFindAndUpdateCardPage();

		// Search in Find Update Card Page
		findAndUpdateCardPage.selectAccountFromFindUpdateCardPage();
		//Validate Updated values in OLS
		bulkOrdeAndUpdatePage.validateUpdatedValuesInOLS(vehicleCardNumber,"Vehicle",updatedRegNumber);
		bulkOrdeAndUpdatePage.validateUpdatedValuesInOLS(driverCardNumber,"Driver",updatedDriverName);

		loginPage.Logout();
		
	}
	
	
	//InProgress
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "Smoke" })
	public void validateOnlineNegativeCardUpdate(@Optional("AU") String clientCountry, @Optional("BP") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  BP Negative Bulk Card Update Template", "Validate the Negative Bulk Card Update Template");
		
		LoginPage loginPage = new LoginPage(driver, test);
		BPHomePage bpHomePage = new BPHomePage(driver, test);
		BPCommonPage bpCommonPage = new BPCommonPage(driver, test);
		BPOrderCard orderCardPage = new BPOrderCard(driver, test);
		//FindAndUpdateCardPage findAndUpdateCardPage = new FindAndUpdateCardPage(driver, test);
		BulkOrderAndUpdatePage bulkOrdeAndUpdatePage = new BulkOrderAndUpdatePage(driver, test);
		loginPage.Login("BP_URL", "BP_UN_Customer_" + clientCountry, "BP_PWD_Customer_" + clientCountry, clientName);
		
		bpHomePage.ValidateBPCustomerLogo();
		bpCommonPage.selectAccount();
		String accountNumber = bpCommonPage.getAccountNumber();
		
		bpHomePage.loadBulkOrderAndUpdateCardPage();
		bulkOrdeAndUpdatePage.selectBulkCardOperation("Bulk Card Update");
		bulkOrdeAndUpdatePage.selectAllAccountFromBulkCardOperation("Update");
		String cardNumber=bulkOrdeAndUpdatePage.getCardNumberToUpdateExcel("Bulk_Update",accountNumber,"Driver");
		bulkOrdeAndUpdatePage.updateNegativeExcelValues("Bulk_Update",cardNumber);
		orderCardPage.bulkOrderUpload("Bulk_Update");
		
		/*bpHomePage.loadBulkOrderAndUpdateCardPage();
		bulkOrdeAndUpdatePage.selectBulkCardOperation("Bulk Card Update");
		String vehicleCardNumber=bulkOrdeAndUpdatePage.getCardNumberToUpdateExcel("Bulk_Update",accountNumber,"Vehicle");
		String updatedRegNumber=bulkOrdeAndUpdatePage.updateExcelValues("Bulk_Update",vehicleCardNumber,"Vehicle");
		orderCardPage.bulkOrderUpload("Bulk_Update");*/
		
		loginPage.Logout();
		
		/*IFCSloginPage.login("IFCS_URL_BP", "IFCS_BP_USERNAME", "IFCS_BP_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");

		IFCSHomePage.gotoAdminBatchMenuAndChooseClient(clientName+"_"+clientCountry);
		common.batchJobExecution("Card Processing", "Online Card Management Request",
				"Online Card Detail Update Request Processor");
		common.batchJobExecution("Card Processing", "Card Emboss Catalog", "Card Emboss Catalog");*/
		
		//common.validateUpdatedValuesInIFCS(vehicleCardNumber,updatedRegNumber,"Vehicle");
		/*common.validateUpdatedValuesInIFCS(driverCardNumber,updatedDriverName,"Driver");
		
		loginPage.Login("BP_URL", "BP_UN_Customer_" + clientCountry, "BP_PWD_Customer_" + clientCountry, clientName);

		bpHomePage.loadFindAndUpdateCardPage();

		// Search in Find Update Card Page
		findAndUpdateCardPage.selectAccountFromFindUpdateCardPage();
		/bulkOrdeAndUpdatePage.validateUpdatedValuesInOLS(vehicleCardNumber,"Vehicle",updatedRegNumber);
		bulkOrdeAndUpdatePage.validateUpdatedValuesInOLS(driverCardNumber,"Driver",updatedDriverName);

		loginPage.Logout();*/
		
	}
	
}
