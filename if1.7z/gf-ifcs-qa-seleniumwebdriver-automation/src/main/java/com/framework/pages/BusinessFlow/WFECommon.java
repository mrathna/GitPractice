package com.framework.pages.BusinessFlow;

import java.io.File;
import java.math.RoundingMode;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.PropertiesConfiguration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.aventstack.extentreports.ExtentTest;
import com.framework.basepage.BasePage;
import com.framework.pages.AJS.MaintainCustomerPage;
import com.framework.pages.AJS.common.Common;
import com.framework.pages.AJS.common.IFCSCommonPage;
import com.framework.pages.AJS.common.CommonInterfacePage;
import com.framework.pages.AJS.common.IFCSHomePage;
import com.framework.repo.Locator_IFCS;
import com.framework.util.Constants;
import com.framework.util.PropUtils;
import com.github.javafaker.Faker;

public class WFECommon extends BasePage {

	@FindBy(xpath = Locator_IFCS.CLONE_FORM)
	public WebElement cloneForm;

	@FindBy(xpath = Locator_IFCS.DECLINE_ICON)
	public WebElement declineIcon;

	@FindBy(xpath = Locator_IFCS.EXPORT_REPORT_BUTTON)
	public WebElement exportReportButton;

	@FindBy(xpath = Locator_IFCS.PROCESS_ALLOCATION_ICON)
	public WebElement processAllocationIcon;

	@FindBy(xpath = Locator_IFCS.SEARCH_CARDS_TEXTBOX)
	public List<WebElement> textBoxes;
	
	@FindBy(xpath = Locator_IFCS.POPUP_MENUITEM_SORT)
	public WebElement popupMenuItemSort;
	
	@FindBy(xpath = Locator_IFCS.POPUP_MENUITEM_SORTDESC)
	public WebElement popupMenuItemSortDesc;

	public WFECommon(WebDriver driver, ExtentTest test) {
		super(driver, test);
		PageFactory.initElements(new AjaxElementLocatorFactory(driver, 15), this);
	}

	public String getActiveCustomerUsingApplicationType(String applicationType) {
		String clientName, clientCountry;
		String customerNo = "";
		String queryToGetCustomerNumberHasTransaction;
		clientName = PropUtils.getPropValue(configProp, "clientName");
		clientCountry = PropUtils.getPropValue(configProp, "clientCountry");

		queryToGetCustomerNumberHasTransaction = "Select distinct mcu.customer_no from m_customers mcu \r\n"
				+ "inner join accounts acc on mcu.customer_mid=acc.customer_mid \r\n"
				+ "inner join account_status accs on accs.account_status_oid=acc.account_status_oid \r\n"
				+ "inner join account_sub_status accss on acc.account_sub_status_oid=accss.account_sub_status_oid \r\n"
				+ "inner join card_programs cp on mcu.card_program_oid = cp.card_program_oid \r\n"
				+ "where (accs.description like '%Active' or accs.description like '%ACTIVE') \r\n"
				+ "and accss.description='Active' and mcu.client_mid =(Select client_mid from m_clients where"
				+ " name ='" + PropUtils.getPropValue(configProp, clientName + "_" + clientCountry) + "') \r\n"
				+ "and   mcu.customer_no in (select customer_no from applications \r\n"
				+ "where application_type_oid = (select application_type_oid from application_types "
				+ "where description='" + applicationType + "')) and Rownum <=1";
		customerNo = connectDBAndGetValue(queryToGetCustomerNumberHasTransaction,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));

		// System.out.println("customerNo:: " + customerNo);
		return customerNo;
	}

	public void validateApplicationDecline() {
		Common common = new Common(driver, test);
		sleep(3);
		chooseSubMenuFromLeftPanel("Maintain Application", "");
		sleep(3);
		common.clickSaveIcon();
		common.clickValidateIcon();
		verifyValidationResult("Validation successful");
		sleep(3);
		isDisplayedThenClick(declineIcon, "Decline Icon");
		sleep(3);
		verifyValidationResult("Application Declined");
		String accountNumber = getValueFromTextBox("Details", "Customer No");
		chooseSubMenuFromLeftPanel("Applications", "");
		enterValueInTextBox("Filter By", "Customer No", accountNumber);
		common.searchListTorch();
		verifyValidationResult("Record Read OK - Page Size 200 Rows");

	}

	public String getActiveOrTemporaryBlockCustomerNoHavingCardsAndRowIndex(int rowIndex, String status) {
		String clientCountry, clientName;
		String queryToGetCustomer = "", cardTypeDesc = "", customerNo = "";
		clientName = PropUtils.getPropValue(configProp, "clientName");
		clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		if (status.equals("Temporary Lock")) {
			cardTypeDesc = "cp.client_mid=(select Client_mid from m_clients where name ='"
					+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountry) + "')";
			queryToGetCustomer = "Select distinct mcu.customer_no from m_customers mcu inner join card_programs cp on mcu.card_program_oid = cp.card_program_oid inner join accounts acc on mcu.customer_mid=acc.customer_mid inner join account_status accs on accs.account_status_oid=acc.account_status_oid inner join account_sub_status accss on acc.account_sub_status_oid=accss.account_sub_status_oid  where mcu.customer_mid In (select customer_mid from cards) and accs.description like '%Temporary Lock' and accss.description= 'Bad Debt' and "
					+ cardTypeDesc + "";
		} else if (status.equals("Active")) {
			cardTypeDesc = "cp.client_mid=(select Client_mid from m_clients where name ='"
					+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountry) + "')";
			queryToGetCustomer = "Select distinct mcu.customer_no from m_customers mcu inner join card_programs cp on mcu.card_program_oid = cp.card_program_oid inner join accounts acc on mcu.customer_mid=acc.customer_mid inner join account_status accs on accs.account_status_oid=acc.account_status_oid inner join account_sub_status accss on acc.account_sub_status_oid=accss.account_sub_status_oid  where mcu.customer_mid In (select customer_mid from cards) and accs.description ='Active' and accss.description='Active' and "
					+ cardTypeDesc + "";
		}

		customerNo = connectDBAndGetDBRowValue(queryToGetCustomer,
				PropUtils.getPropValue(configProp, "sqlODSServerName"), rowIndex);
		// System.out.println("customerNo:: " + customerNo);

		return customerNo;
	}

	/*
	 * Added by Raxsana Input Values for Sequence no,Date
	 */
	public Map<String, String> getInputValuesFromDB(String clientName, String clientCountry) {
		Map<String, String> dbValues = new HashMap<String, String>();
		String queryToGetSeqNoFromDB = "select last_sequence_number from interface_files_incoming where description='Tokheim transaction file' \r\n"
				+ "and client_mid=(select client_mid from m_clients where name='"
				+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountry) + "')";
		String seqNoFromDB = connectDBAndGetValue(queryToGetSeqNoFromDB,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		dbValues.put("lastSequenceNumber", seqNoFromDB);

		String queryToGetDateFromDB = "select processing_date from m_clients where "
				+ "client_mid=(select client_mid from m_clients where name='"
				+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountry) + "')";
		String dateFromDB = connectDBAndGetValue(queryToGetDateFromDB,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		// System.out.println("before::" + dateFromDB);

		dbValues.put("dateWithoutTime", dateFromDB.split(" ")[0]);
		dateFromDB = dateFromDB.split(" ")[0].replaceAll("-", "").substring(2, 8);
		// System.out.println("after::" + dateFromDB);
		dbValues.put("Date", dateFromDB);

		return dbValues;
	}

	/*
	 * Added by Raxsana Line Items for Non Fuel Products
	 */
	public Map<String, String> getTransactionLineItemForNonFuels(Properties properties, String cardNumber,
			String clientName, String clientCountry) {
		// int seqNo;
		String getDBDetailsFromProperties = "";
		Map<String, String> result;
		String productCode, unitPrice, volume;
		String clientNameInProp = PropUtils.getPropValue(configProp, clientName + "_" + clientCountry);
		getDBDetailsFromProperties = PropUtils.getPropValue(properties, "sqlODSServerName");

		String queryToGetprdcode;

		queryToGetprdcode = "select tp.external_code,pt.MINIMUM_UNIT_PRICE,pt.MINIMUM_VOLUME\r\n" + "from cards c\r\n"
				+ "inner join m_customers cus on cus.customer_mid = c.customer_mid\r\n"
				+ "inner join card_programs cp on cp.card_program_oid=c.card_program_oid\r\n"
				+ "inner join card_control_profiles ccp on ccp.card_control_profile_oid = c.card_control_profile_oid\r\n"
				+ "inner join card_controls cc on cc.card_control_profile_oid=ccp.card_control_profile_oid\r\n"
				+ "inner join product_restrictions pr on pr.product_restriction_oid=cc.product_restriction_oid\r\n"
				+ "inner join PRODUCT_RESTRICT_PRODS rp on rp.product_restriction_oid=pr.product_restriction_oid\r\n"
				+ "inner join PRODUCT_THRESHOLDS pt on pt.product_oid=rp.product_oid\r\n"
				+ "inner join PRODUCT_TRANSLATIONS tp on tp.product_oid=pt.product_oid "
				+ "inner join products p on p.product_oid = tp.product_oid " + "where  c.card_no='" + cardNumber
				+ "' and p.is_fuel='N' and pt.client_mid=(select client_mid from m_clients where name ='"
				+ clientNameInProp + "') and ROWNUM = 1";

		result = connectDBAndGetDBEntireRowValues(queryToGetprdcode, getDBDetailsFromProperties);
		productCode = result.get("EXTERNAL_CODE");
		unitPrice = result.get("MINIMUM_UNIT_PRICE");
		volume = result.get("MINIMUM_VOLUME");
		result.put("productCode", productCode);

		int volu = (int) Math.round(Float.parseFloat(volume));

		int unitprice = (int) Math.round(Float.parseFloat(unitPrice));
		// System.out.println("inside uSp::" + unitprice);
		if (volu > 1) {
			result.put("volume", String.valueOf(volu) + "00");
		} else {
			result.put("volume", "10000");
		}
		if (unitprice > 1) {
			result.put("unitPrice", String.valueOf(unitprice) + "00");
		} else {
			result.put("unitPrice", "10000");
		}

		return result;
	}

	/*
	 * raxsana added on 07/07/2020
	 */
	/**
	 * @param applicationType
	 */
	public void exportApplication(String applicationType) {
		Common common = new Common(driver, test);
		chooseSubMenuFromLeftPanel("Applications", "");
		logInfo("Click on Applications");
		if (applicationType.equalsIgnoreCase("Status")) {
			common.chooseOptionFromDropdown(applicationType, "Approved");
			//common.chooseOptionFromDropdownByJSClick(applicationType, "Approved");
		} else {
			common.chooseARandomDropdownOption(applicationType);
		}
		common.searchListTorch();
		verifyValidationResult("Record Read OK - Page Size 200 Rows");
		sleep(3);
		isDisplayed(exportReportButton, "Export Button");
		Click(exportReportButton, "Export Button");
		sleep(3);
		common.isFileDownloaded("wexdownload1");
	}

	/*
	 * raxsana added updated on 28/09/2020
	 */
	/**
	 * @param status
	 */
	public void applicationStatusChangeToApproved(String status) {
		Common common = new Common(driver, test);
		chooseSubMenuFromLeftPanel("Applications", "");
		common.chooseARandomDropdownOption("Application Type");
		common.chooseOptionFromDropdown("Status", status);
		common.searchListTorch();
		try {
			verifyValidationResult("Record Read OK - Page Size 200 Rows");
			common.selectFirstRowNumberInSearchList();
			sleep(3);
			chooseSubMenuFromLeftPanel("Card Profiles", "Card Reissue Profiles");
			String checkBox = driver.findElement(By.xpath(""
					+ "//div[@class='FALTableCellEditor_StrikeThruCheckBox enabled'][contains(@id,'_0_0')]//div[@class='htmlImage']"))
					.getAttribute("style");
			if (checkBox.contains("unselected.gif")) {
				common.rightClickAndSelectProfileFirstApplication();
				common.clickSaveIcon();
				verifyValidationResult("Record saved OK");
				chooseSubMenuFromLeftPanel("Maintain Application", "");
			} else {
				chooseSubMenuFromLeftPanel("Maintain Application", "");
			}
			common.clickSaveIcon();
			verifyValidationResult("Record saved OK");
			common.clickValidateIcon();
			sleep(2);
			verifyValidationResult("Validation successful");
			common.clickApproveIcon();
			sleep(5);
			try {
				WebElement verifyTextElement = driver
						.findElement(By.xpath("//div[@class='ExtLabel'][3]/div[@class='htmlString']"));
				String verifyText = verifyTextElement.getText();
				if (verifyText.equalsIgnoreCase("Must be blank")) {
					common.chooseBlankOptionFromDropdown("Denial Reason");
					common.clickSaveIcon();
					verifyValidationResult("Record saved OK");
					common.clickValidateIcon();
					sleep(2);
					verifyValidationResult("Validation successful");
					common.clickApproveIcon();
					sleep(5);
					verifyValidationResult("Application Approved");
				}
			} catch (Exception e) {
				verifyValidationResult("Application Approved");
			}
		} catch (Exception e) {
			e.getMessage();
			logFail("No Pending/New Applications");
		}
	}

	/*
	 * Added by Davu Update the values for validation in property file
	 * [TransactionTempFile.properties]
	 */
	public void updatePropFile(String key, Map<String, String> values) {

		PropertiesConfiguration config = null;
		try {
			config = new PropertiesConfiguration(Constants.CONFIG_DIR + "TransactionTempFile.properties");
			for (String value : values.keySet()) {
				config.setProperty(key, value);
				config.save();
			}
		} catch (ConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/* XML Creation */
	public Map<String, String> XMLCreationForTransactionWFE(String clientName, String clientCountry,
			Map<String, String> inputvalues, String isReversalFlag, String transactionType)
			throws TransformerException {

		Map<String, String> valuesForValidation = new LinkedHashMap<String, String>();
		int k;
		String ticketNumber = null, netValue = null, timeStamp = null, transactionTimeStamp = null;
		Element subtag = null, loadCardTransactionsubtag = null;
		// IFCSCommonPage ifcsCommonPage = new IFCSCommonPage(driver, test);
		Faker faker = new Faker();

		// Elements and nodes
		String[] Transaction = { "Identifier", "TerminalInfo", "TransactionInfo", "CardInfo", "SalesItem" };
		String[] Identifier = { "StationID", "SystemTraceAuditNumber", "TransactionTimestamp" };
		String[] TerminalInfo = { "TerminalID", "TerminalType" };
		String[] TransactionInfo = { "TransactionType", "OriginalSystemTraceAuditNumber", "TransactionResult",
				"TransactionAmount", "CurrencyCode", "BatchSequenceNumber", "CustomerInput", "TicketNumber",
				"AuthorisationType" };
		String[] CardInfo = { "PAN", "PANEntryMode", "TrackData", "ExpiryDate" };
		String[] SalesItem = { "ProductCode", "Quantity", "UnitPrice", "UnitOfMeasure", "Amount", "PumpInfo",
				"VATPercentage", "AdditionalProductCode" };

		/* Timestamp Values */
		Calendar cal = Calendar.getInstance();
		String date = getFileCreationDate();
		// System.out.println(":File creation date ::" + date);

		String time = getFileCreationTime();
		// System.out.println(":File creation Time ::" + time);

		String newTime = addMinitesToTime(time, 10);
		// System.out.println("New time :" + newTime);

		String transactionTime = addMinitesToTime(newTime, -2);
		String transTime = addMinitesToTime("00:30:00", -2);

		/* Location Number */
		String locationNo = inputvalues.get("LocationNumber");
		// String locationNo=locNo.substring(locNo.length()-9, locNo.length());
		// System.out.println("locNo::" + locationNo);

		/* Card Expiry Date */
		String queryToGetExpiryDate = "select expires_on from cards where card_no='" + inputvalues.get("CardNumber")
				+ "'";
		String expiryDate = connectDBAndGetValue(queryToGetExpiryDate,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		String expiresOn = expiryDate.split(" ")[0].split("-")[0].substring(2, 4)
				+ expiryDate.split(" ")[0].split("-")[1];
		// System.out.println("expiry date::" + expiresOn);

		/* Last Sequence no, Date */
		Map<String, String> dbValue = getInputValuesFromDB(clientName, clientCountry);

		if (dbValue.get("dateWithoutTime").equals(date)) {
			timeStamp = date + "T" + newTime;
			transactionTimeStamp = date + "T" + transactionTime;
		} else {
			timeStamp = dbValue.get("dateWithoutTime") + "T" + "00:30:00";
			transactionTimeStamp = dbValue.get("dateWithoutTime") + "T" + transTime;
		}

		String stanNo = cal.getTime().toString().replaceAll(":", "").split(" ")[3];
		// System.out.println("stan::" + stanNo);
		netValue = "100.00";
		String queryToGetUnitOfMeasure = "select is_fuel from products where product_oid in (select product_oid from PRODUCT_TRANSLATIONS where external_code='"
				+ inputvalues.get("productCode") + "')";
		String unitOfMeasure = connectDBAndGetValue(queryToGetUnitOfMeasure,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		String seqNo = String.valueOf((Integer.parseInt(dbValue.get("lastSequenceNumber")) + 1));

		// String remotedir = PropUtils.getPropValue(configProp,
		// "IFCS_LOADCARDTRANSACTION_TOKHIEM");
		// System.out.println("remotedir::" + remotedir);

		try {
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			Document doc = docBuilder.newDocument();

			Element rootElement = doc.createElement("SettlementFile");
			doc.appendChild(rootElement);
			rootElement.setAttribute("CreationTimestamp", timeStamp);
			if (isReversalFlag.equalsIgnoreCase("N") && transactionType.equalsIgnoreCase("20")) {
				rootElement.setAttribute("CreditAmount", "100.00");
				rootElement.setAttribute("CreditReversalAmount", "0.00");
				rootElement.setAttribute("DebitAmount", "0.00");
				rootElement.setAttribute("DebitReversalAmount", "0.00");
			} else if (isReversalFlag.equalsIgnoreCase("Y") && transactionType.equalsIgnoreCase("20")) {
				rootElement.setAttribute("CreditReversalAmount", "100.00");
				rootElement.setAttribute("CreditAmount", "0.00");
				rootElement.setAttribute("DebitAmount", "0.00");
				rootElement.setAttribute("DebitReversalAmount", "0.00");
			} else if (isReversalFlag.equalsIgnoreCase("N") && transactionType.equalsIgnoreCase("0")) {
				try {
					if (!(inputvalues.get("DuplicateCardNumber").equals(" "))) {
						rootElement.setAttribute("DebitAmount", "200.00");
						rootElement.setAttribute("CreditAmount", "0.00");
						rootElement.setAttribute("CreditReversalAmount", "0.00");
						rootElement.setAttribute("DebitReversalAmount", "0.00");
					}
				} catch (Exception e) {
					rootElement.setAttribute("DebitAmount", "100.00");
					rootElement.setAttribute("CreditAmount", "0.00");
					rootElement.setAttribute("CreditReversalAmount", "0.00");
					rootElement.setAttribute("DebitReversalAmount", "0.00");
				}
			} else if (isReversalFlag.equalsIgnoreCase("Y") && transactionType.equalsIgnoreCase("0")) {
				rootElement.setAttribute("DebitReversalAmount", "100.00");
				rootElement.setAttribute("DebitAmount", "0.00");
				rootElement.setAttribute("CreditReversalAmount", "0.00");
				rootElement.setAttribute("CreditAmount", "0.00");
			}
			rootElement.setAttribute("FileSequenceNumber", seqNo);
			try {
				if (!(inputvalues.get("DuplicateCardNumber").equals(" "))) {
					rootElement.setAttribute("NumberOfTransactions", "2");
				}
			} catch (Exception e) {
				rootElement.setAttribute("NumberOfTransactions", "1");
			}
			rootElement.setAttribute("Version", "01.00");

			String filename = "027_" + dbValue.get("Date") + "_" + seqNo + ".xml";
			String batchSeqNo = faker.number().digits(4);

			for (int i = 0; i < 1; i++) {

				Element loadCardTransaction = doc.createElement("Transaction");

				for (int j = 0; j < Transaction.length; j++) {

					loadCardTransactionsubtag = doc.createElement(Transaction[j]);
					if (Transaction[j].equalsIgnoreCase("Identifier")) {
						for (k = 0; k < Identifier.length; k++) {
							subtag = doc.createElement(Identifier[k]);
							if (Identifier[k].equalsIgnoreCase("StationID")) {
								subtag.setTextContent(locationNo);
							}
							if (Identifier[k].equalsIgnoreCase("SystemTraceAuditNumber")) {

								subtag.setTextContent(stanNo);
							}
							if (Identifier[k].equalsIgnoreCase("TransactionTimestamp")) {
								subtag.setTextContent(transactionTimeStamp);

							}
							loadCardTransactionsubtag.appendChild(subtag);
						}

					}

					if (Transaction[j].equalsIgnoreCase("TerminalInfo")) {
						for (k = 0; k < TerminalInfo.length; k++) {
							String terminalId = fakerAPI().number().digits(8);
							subtag = doc.createElement(TerminalInfo[k]);
							if (TerminalInfo[k].equalsIgnoreCase("TerminalID")) {
								subtag.setTextContent(terminalId);

							}
							if (TerminalInfo[k].equalsIgnoreCase("TerminalType")) {
								subtag.setTextContent("1");

							}
							loadCardTransactionsubtag.appendChild(subtag);
						}

					}
					if (Transaction[j].equalsIgnoreCase("TransactionInfo")) {
						for (k = 0; k < TransactionInfo.length; k++) {

							subtag = doc.createElement(TransactionInfo[k]);
							if (TransactionInfo[k].equalsIgnoreCase("TransactionType")) {
								subtag.setTextContent(transactionType);
							}

							if (TransactionInfo[k].equalsIgnoreCase("OriginalSystemTraceAuditNumber")) {

								subtag.setTextContent(stanNo);
							}
							if (TransactionInfo[k].equalsIgnoreCase("TransactionResult")) {
								Element Approved = doc.createElement("Approved");
								Element AuthorisationCode = doc.createElement("AuthorisationCode");
								Approved.setTextContent("true");
								AuthorisationCode.setTextContent("D6KE92");
								subtag.appendChild(Approved);
								subtag.appendChild(AuthorisationCode);
							}
							if (TransactionInfo[k].equalsIgnoreCase("TransactionAmount")) {
								subtag.setTextContent(netValue);
							}
							if (TransactionInfo[k].equalsIgnoreCase("CurrencyCode")) {
								String queryToGetcurrencyCode = "select iso_currency_no from CURRENCIES";
								String currencyCode = connectDBAndGetValue(queryToGetcurrencyCode,
										PropUtils.getPropValue(configProp, "sqlODSServerName"));
								subtag.setTextContent(currencyCode);
							}
							if (TransactionInfo[k].equalsIgnoreCase("BatchSequenceNumber")) {
								subtag.setTextContent(batchSeqNo);
							}
							if (TransactionInfo[k].equalsIgnoreCase("CustomerInput")) {
								try {
									if (!(inputvalues.get("Mileage").equals(" "))) {
										Element vehicleNumber = doc.createElement("VehicleNumber");
										vehicleNumber.setTextContent("8946");
										subtag.appendChild(vehicleNumber);
										Element mileage = doc.createElement("Mileage");
										mileage.setTextContent(inputvalues.get("Mileage"));
										subtag.appendChild(mileage);
									}
								} catch (Exception e) {
									Element DriverNumber = doc.createElement("DriverNumber");
									DriverNumber.setTextContent("2412");
									subtag.appendChild(DriverNumber);
								}

							}
							if (TransactionInfo[k].equalsIgnoreCase("TicketNumber")) {
								ticketNumber = faker.number().digits(10);

								subtag.setTextContent(ticketNumber);
								inputvalues.put("ReferenceNo", ticketNumber);
							}
							if (TransactionInfo[k].equalsIgnoreCase("AuthorisationType")) {
								String value = "1";
								subtag.setTextContent(value);

							}
							loadCardTransactionsubtag.appendChild(subtag);

						}
						Element reversal = null;
						if (isReversalFlag.equalsIgnoreCase("Y")) {
							reversal = doc.createElement("Reversal");
							reversal.setTextContent("true");
							loadCardTransactionsubtag.appendChild(reversal);
						}
					}

					if (Transaction[j].equalsIgnoreCase("CardInfo")) {
						for (k = 0; k < CardInfo.length; k++) {
							subtag = doc.createElement(CardInfo[k]);

							if (CardInfo[k].equals("PAN")) {
								subtag.setTextContent(inputvalues.get("CardNumber"));
							} else if (CardInfo[k].equals("PANEntryMode")) {
								subtag.setTextContent("2");
							} else if (CardInfo[k].equals("TrackData")) {
								subtag.setTextContent(inputvalues.get("CardNumber") + "=2004400791079793662");
							} else if (CardInfo[k].equals("ExpiryDate")) {
								subtag.setTextContent(expiresOn);
							}
							loadCardTransactionsubtag.appendChild(subtag);
						}
						Element dualCard = null;
						try {
							if (!(inputvalues.get("DualCardNumber").equals(" "))) {
								dualCard = doc.createElement("Track2DataSecondaryCard");
								dualCard.setTextContent(inputvalues.get("DualCardNumber") + "=2211430190020000012");
								loadCardTransactionsubtag.appendChild(dualCard);
							}
						} catch (Exception e) {
						}

					}
					if (Transaction[j].equalsIgnoreCase("SalesItem")) {

						for (k = 0; k < SalesItem.length; k++) {
							Element TransactionLineItemsSubtag = doc.createElement(SalesItem[k]);

							if (SalesItem[k].equalsIgnoreCase("ProductCode")) {
								System.out.println("prdcode" + inputvalues.get("productCode"));
								TransactionLineItemsSubtag.setTextContent(inputvalues.get("productCode"));
							}
							if (SalesItem[k].equalsIgnoreCase("Quantity")) {
								TransactionLineItemsSubtag.setTextContent("100.00");
							}
							if (SalesItem[k].equalsIgnoreCase("UnitPrice")) {
								TransactionLineItemsSubtag.setTextContent("1.000");
							}
							if (SalesItem[k].equalsIgnoreCase("UnitOfMeasure")) {
								if (unitOfMeasure.equalsIgnoreCase("Y")) {
									TransactionLineItemsSubtag.setTextContent("L");
								} else if (unitOfMeasure.equalsIgnoreCase("N")) {
									TransactionLineItemsSubtag.setTextContent("U");
								}
							}
							if (SalesItem[k].equalsIgnoreCase("Amount")) {
								TransactionLineItemsSubtag.setTextContent(netValue);
							}
							if (SalesItem[k].equalsIgnoreCase("PumpInfo")) {
								Element PumpInfo = doc.createElement("Pump");
								Element Nozzle = doc.createElement("Nozzle");
								PumpInfo.setTextContent("6");
								Nozzle.setTextContent("1");
								TransactionLineItemsSubtag.appendChild(PumpInfo);
								TransactionLineItemsSubtag.appendChild(Nozzle);
							}
							if (SalesItem[k].equalsIgnoreCase("VATPercentage")) {
								if (clientCountry.equals("BE") || clientCountry.equals("NL")) {
									TransactionLineItemsSubtag.setTextContent("21.00");
								} else if (clientCountry.equals("FR")) {
									TransactionLineItemsSubtag.setTextContent("20.00");

								} else if (clientCountry.equals("LU")) {
									TransactionLineItemsSubtag.setTextContent("19.00");

								} else {
									TransactionLineItemsSubtag.setTextContent("19.00");
								}
							}
							if (SalesItem[k].equalsIgnoreCase("AdditionalProductCode")) {
								TransactionLineItemsSubtag.setTextContent("3");
							}

							loadCardTransactionsubtag.appendChild(TransactionLineItemsSubtag);
						}
					}

					loadCardTransaction.appendChild(loadCardTransactionsubtag);
				}
				try {
					if (!(inputvalues.get("DuplicateCardNumber").equals(" "))) {
						rootElement.appendChild(doc.adoptNode(loadCardTransaction).cloneNode(true));
						rootElement.appendChild(loadCardTransaction);
					}
				} catch (Exception e) {
					rootElement.appendChild(loadCardTransaction);
				}

			}
			valuesForValidation.put(ticketNumber, netValue);
			// Write the content into XML file
			DOMSource source = new DOMSource(doc);
			StreamResult result = new StreamResult(new File("LoadCardTransaction.xml"));

			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer = transformerFactory.newTransformer();

			transformer.setOutputProperty(OutputKeys.INDENT, "yes");
			transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "4");
			transformer.transform(source, result);

			result = new StreamResult(new File(System.getProperty("user.home") + System.getProperty("file.separator")
					+ "Documents" + System.getProperty("file.separator") + filename));
			System.out.println(filename);
			transformer.transform(source, result);

			// SFTP Connection for uploading xml file
			// ifcsCommonPage.establishThePuttyConnectionbyUserGeneratedRemoteDirectory("XML",
			// "PUTTY_HOST",
			// "PUTTY_USERNAME", "PUTTY_PASSWORD", remotedir, filename);

			// not yet completed
			/*
			 * if (clientName.equals("BP") || clientName.equals("CHEVRON")) { folderName =
			 * ifcsCommonPage.getControlMFolder(clientName, clientCountry,
			 * "jobS_LoadcardTransactions_" + clientName + "_" + clientCountry); jobsInOrder
			 * = ifcsCommonPage .getJobsOfFolderInOrder("jobS_LoadcardTransactions_" +
			 * clientName + "_" + clientCountry); } else { folderName =
			 * ifcsCommonPage.getControlMFolder(clientName, clientCountry,
			 * "jobS_LoadcardTransactions_" + clientName); jobsInOrder =
			 * ifcsCommonPage.getJobsOfFolderInOrder("jobS_LoadcardTransactions_" +
			 * clientName); }
			 * interfacePage.establishAndExecuteControlMJobs("ControlM_AWS_UAT",
			 * "ContorlM_AWS_userName", "ContorlM_AWS_password", folderName, jobsInOrder);
			 */

		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return valuesForValidation;
	}

	public Map<String, String> XMLCreationForTransactionWFEWithInvalidvalues(String clientName, String clientCountry,
			Map<String, String> inputvalues, String isReversalFlag, String isInvalidTime, String isInvalidSeq)
			throws TransformerException {

		Map<String, String> valuesForValidation = new LinkedHashMap<String, String>();
		int k, netValue = 0;
		IFCSCommonPage ifcsCommonPage = new IFCSCommonPage(driver, test);

		String[] Transaction = { "Identifier", "TerminalInfo", "TransactionInfo", "CardInfo", "SalesItem" };
		String[] Identifier = { "StationID", "SystemTraceAuditNumber", "TransactionTimestamp" };
		String[] TerminalInfo = { "TerminalID", "TerminalType" };
		String[] TransactionInfo = { "TransactionType", "Reversal", "OriginalSystemTraceAuditNumber",
				"TransactionResult", "TransactionAmount", "CurrencyCode", "BatchSequenceNumber", "CustomerInput",
				"TicketNumber" };
		String[] CardInfo = { "PAN", "PANEntryMode", "TrackData", "ExpiryDate" };
		String[] SalesItem = { "ProductCode", "Quantity", "UnitPrice", "UnitOfMeasure", "Amount", "PumpInfo",
				"VATPercentage", "AdditionalProductCode" };

		String locNo = inputvalues.get("LocationNumber");
		String locationNo = locNo.substring(locNo.length() - 9, locNo.length());
		System.out.println("locNo::" + locationNo);
		Map<String, String> dbValue = getInputValuesFromDB(clientName, clientCountry);
		Calendar cal = Calendar.getInstance();
		if (isInvalidTime.equals("Y")) {
			cal.add(Calendar.HOUR_OF_DAY, +5);
		}
		String timeStamp = dbValue.get("dateWithoutTime") + "T" + cal.getTime().toString().split(" ")[3];

		System.out.println("date::" + dbValue.get("Date").substring(0, 4));
		String stanNo = cal.getTime().toString().replaceAll(":", "").split(" ")[3];
		System.out.println("stan::" + stanNo);
		netValue = ((Integer.parseInt(inputvalues.get("volume")) / 100)
				* ((Integer.parseInt(inputvalues.get("unitPrice")) / 100)) / 100);
		String seqNo = String.valueOf((Integer.parseInt(dbValue.get("lastSequenceNumber")) + 1));

		if (isInvalidSeq.equals("Y")) {
			seqNo = String.valueOf(Integer.parseInt(seqNo) - 2);
		}

		String remotedir = PropUtils.getPropValue(configProp, "IFCS_LOADCARDTRANSACTION_TOKHIEM");
		System.out.println("remotedir::" + remotedir);

		try {
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			Document doc = docBuilder.newDocument();

			Element rootElement = doc.createElement("SettlementFile");
			doc.appendChild(rootElement);
			rootElement.setAttribute("CreationTimestamp", timeStamp);
			rootElement.setAttribute("CreditAmount", Integer.toString(netValue) + ".00");
			rootElement.setAttribute("CreditReversalAmount", "0.0");
			rootElement.setAttribute("DebitAmount", "0.0");
			rootElement.setAttribute("DebitReversalAmount", "0.0");
			rootElement.setAttribute("FileSequenceNumber", seqNo);
			rootElement.setAttribute("NumberOfTransactions", "1");
			rootElement.setAttribute("Version", "01.00");

			String filename = "027_" + dbValue.get("Date") + "_" + seqNo + ".xml";

			Faker faker = new Faker();
			Element subtag = null;
			Element loadCardTransactionsubtag = null;

			for (int i = 0; i < 1; i++) {

				Element loadCardTransaction = doc.createElement("Transaction");

				for (int j = 0; j < Transaction.length; j++) {

					loadCardTransactionsubtag = doc.createElement(Transaction[j]);
					if (Transaction[j].equalsIgnoreCase("Identifier")) {
						for (k = 0; k < Identifier.length; k++) {
							subtag = doc.createElement(Identifier[k]);
							if (Identifier[k].equalsIgnoreCase("StationID")) {
								subtag.setTextContent(locationNo);
							}
							if (Identifier[k].equalsIgnoreCase("SystemTraceAuditNumber")) {

								subtag.setTextContent(stanNo);
							}
							if (Identifier[k].equalsIgnoreCase("TransactionTimestamp")) {
								subtag.setTextContent(timeStamp);

							}
							loadCardTransactionsubtag.appendChild(subtag);
						}

					}

					if (Transaction[j].equalsIgnoreCase("TerminalInfo")) {
						for (k = 0; k < TerminalInfo.length; k++) {
							String terminalId = fakerAPI().number().digits(8);
							subtag = doc.createElement(TerminalInfo[k]);
							if (TerminalInfo[k].equalsIgnoreCase("TerminalID")) {
								subtag.setTextContent(terminalId);

							}
							if (TerminalInfo[k].equalsIgnoreCase("TerminalType")) {
								subtag.setTextContent("1");

							}
							loadCardTransactionsubtag.appendChild(subtag);
						}

					}
					if (Transaction[j].equalsIgnoreCase("TransactionInfo")) {
						for (k = 0; k < TransactionInfo.length; k++) {

							subtag = doc.createElement(TransactionInfo[k]);
							if (TransactionInfo[k].equalsIgnoreCase("TransactionType")) {
								subtag.setTextContent("0");
							}
							if (isReversalFlag.equalsIgnoreCase("Y")) {
								if (TransactionInfo[k].equalsIgnoreCase("Reversal")) {
									subtag.setTextContent("true");
								}
							}
							if (TransactionInfo[k].equalsIgnoreCase("OriginalSystemTraceAuditNumber")) {

								subtag.setTextContent(stanNo);
							}
							if (TransactionInfo[k].equalsIgnoreCase("TransactionResult")) {
								Element Approved = doc.createElement("Approved");
								Element AuthorisationCode = doc.createElement("AuthorisationCode");
								Approved.setTextContent("true");
								AuthorisationCode.setTextContent("");
								subtag.appendChild(Approved);
								subtag.appendChild(AuthorisationCode);
							}
							if (TransactionInfo[k].equalsIgnoreCase("TransactionAmount")) {
								subtag.setTextContent(Integer.toString(netValue));
							}
							if (TransactionInfo[k].equalsIgnoreCase("CurrencyCode")) {
								String queryToGetcurrencyCode = "select iso_currency_no from CURRENCIES";
								String currencyCode = connectDBAndGetValue(queryToGetcurrencyCode,
										PropUtils.getPropValue(configProp, "sqlODSServerName"));
								subtag.setTextContent(currencyCode);
							}
							if (TransactionInfo[k].equalsIgnoreCase("BatchSequenceNumber")) {
								subtag.setTextContent(dbValue.get("lastSequenceNumber"));
							}
							if (TransactionInfo[k].equalsIgnoreCase("CustomerInput")) {
								Element DriverNumber = doc.createElement("DriverNumber");
								DriverNumber.setTextContent("dn" + stanNo);
								subtag.appendChild(DriverNumber);
							}
							if (TransactionInfo[k].equalsIgnoreCase("TicketNumber")) {
								String value = faker.number().digits(10);
								subtag.setTextContent(value);
							}
							loadCardTransactionsubtag.appendChild(subtag);
						}
					}

					if (Transaction[j].equalsIgnoreCase("CardInfo")) {
						for (k = 0; k < CardInfo.length; k++) {
							subtag = doc.createElement(CardInfo[k]);

							if (CardInfo[k].equals("PAN")) {
								subtag.setTextContent(inputvalues.get("CardNumber"));
							} else if (CardInfo[k].equals("PANEntryMode")) {
								subtag.setTextContent("2");
							} else if (CardInfo[k].equals("TrackData")) {
								subtag.setTextContent(inputvalues.get("CardNumber") + "=2004400791079793662");
							} else if (CardInfo[k].equals("ExpiryDate")) {
								subtag.setTextContent(dbValue.get("Date").substring(0, 4));
							}
							loadCardTransactionsubtag.appendChild(subtag);
						}
					}
					if (Transaction[j].equalsIgnoreCase("SalesItem")) {

						for (k = 0; k < SalesItem.length; k++) {
							Element TransactionLineItemsSubtag = doc.createElement(SalesItem[k]);

							if (SalesItem[k].equalsIgnoreCase("ProductCode")) {
								System.out.println("prdcode" + inputvalues.get("productCode"));
								TransactionLineItemsSubtag.setTextContent(inputvalues.get("productCode"));
							}
							if (SalesItem[k].equalsIgnoreCase("Quantity")) {
								TransactionLineItemsSubtag.setTextContent(inputvalues.get("volume"));
							}
							if (SalesItem[k].equalsIgnoreCase("UnitPrice")) {
								TransactionLineItemsSubtag.setTextContent(inputvalues.get("unitPrice"));
							}
							if (SalesItem[k].equalsIgnoreCase("UnitOfMeasure")) {
								TransactionLineItemsSubtag.setTextContent("U");
							}
							if (SalesItem[k].equalsIgnoreCase("Amount")) {

								System.out.println("net value::" + netValue);
								TransactionLineItemsSubtag.setTextContent(Integer.toString(netValue) + "00");
								// valuesForValidation.put(refNo, "");
							}
							if (SalesItem[k].equalsIgnoreCase("PumpInfo")) {
								Element PumpInfo = doc.createElement("Pump");
								Element Nozzle = doc.createElement("Nozzle");
								PumpInfo.setTextContent("6");
								Nozzle.setTextContent("1");
								TransactionLineItemsSubtag.appendChild(PumpInfo);
								TransactionLineItemsSubtag.appendChild(Nozzle);
							}
							if (SalesItem[k].equalsIgnoreCase("VATPercentage")) {
								if (clientCountry.equals("BE") || clientCountry.equals("NL")) {
									TransactionLineItemsSubtag.setTextContent("21.00");
								} else if (clientCountry.equals("FR")) {
									TransactionLineItemsSubtag.setTextContent("20.00");

								} else if (clientCountry.equals("LU")) {
									TransactionLineItemsSubtag.setTextContent("19.00");

								} else {
									TransactionLineItemsSubtag.setTextContent("19.00");
								}
							}
							if (SalesItem[k].equalsIgnoreCase("AdditionalProductCode")) {
								TransactionLineItemsSubtag.setTextContent("");
							}

							loadCardTransactionsubtag.appendChild(TransactionLineItemsSubtag);
						}
					}

					loadCardTransaction.appendChild(loadCardTransactionsubtag);
				}
				rootElement.appendChild(loadCardTransaction);
			}

			// Write the content into XML file
			DOMSource source = new DOMSource(doc);
			StreamResult result = new StreamResult(new File("LoadCardTransaction.xml"));

			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer = transformerFactory.newTransformer();

			transformer.setOutputProperty(OutputKeys.INDENT, "yes");
			transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "4");
			transformer.transform(source, result);

			result = new StreamResult(new File(System.getProperty("user.home") + System.getProperty("file.separator")
					+ "Documents" + System.getProperty("file.separator") + filename));
			System.out.println(filename);
			transformer.transform(source, result);

			// SFTP Connection for uploading xml file
			// ifcsCommonPage.establishThePuttyConnectionbyUserGeneratedRemoteDirectory("XML",
			// "PUTTY_HOST",
			// "PUTTY_USERNAME", "PUTTY_PASSWORD", remotedir, filename);

			// not yet completed
			/*
			 * if (clientName.equals("BP") || clientName.equals("CHEVRON")) { folderName =
			 * ifcsCommonPage.getControlMFolder(clientName, clientCountry,
			 * "jobS_LoadcardTransactions_" + clientName + "_" + clientCountry); jobsInOrder
			 * = ifcsCommonPage .getJobsOfFolderInOrder("jobS_LoadcardTransactions_" +
			 * clientName + "_" + clientCountry); } else { folderName =
			 * ifcsCommonPage.getControlMFolder(clientName, clientCountry,
			 * "jobS_LoadcardTransactions_" + clientName); jobsInOrder =
			 * ifcsCommonPage.getJobsOfFolderInOrder("jobS_LoadcardTransactions_" +
			 * clientName); }
			 * interfacePage.establishAndExecuteControlMJobs("ControlM_AWS_UAT",
			 * "ContorlM_AWS_userName", "ContorlM_AWS_password", folderName, jobsInOrder);
			 */

		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return valuesForValidation;
	}

	/* Added by Davu */
	public String getFileCreationDate() {
		// String queryToGetDateFromDB = "Select file_Created_at from (select
		// file_Created_at from Interface_file_inc_logs order by file_created_at desc)
		// where rownum=1";
		String queryToGetDateFromDB = "select file_Created_at from interface_file_inc_logs where external_file_name like '027%' order by file_created_at desc";
		String fileCreatedDate = connectDBAndGetValue(queryToGetDateFromDB,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		Date date = null;
		String date1 = null;
		System.out.println("file creation date here from DB" + fileCreatedDate);

		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		try {
			date = formatter.parse(fileCreatedDate);
			System.out.println("Date:" + date);
			date1 = new SimpleDateFormat("yyyy-MM-dd").format(date);

		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return date1;

	}

	/* Added by Davu */
	public String getFileCreationTime() {

		// String queryToGetDateFromDB = "Select file_Created_at from (select
		// file_Created_at from Interface_file_inc_logs order by file_created_at desc)
		// where rownum=1";
		String queryToGetDateFromDB = "select file_Created_at from interface_file_inc_logs where external_file_name like '027%' order by file_created_at desc";
		String fileCreatedDate = connectDBAndGetValue(queryToGetDateFromDB,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));

		Date date = null;
		String time = null;

		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		try {
			date = formatter.parse(fileCreatedDate);
			System.out.println("Date:" + date);
			time = new SimpleDateFormat("HH:mm:ss").format(date);

		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return time;

	}

	/* Added by Davu */
	public String addMinitesToTime(String time, int minites) {
		SimpleDateFormat df = new SimpleDateFormat("HH:mm:ss");
		Date d = null;
		try {
			d = df.parse(time);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Calendar cal = Calendar.getInstance();
		cal.setTime(d);
		cal.add(Calendar.MINUTE, minites);
		String newTime = df.format(cal.getTime());

		return newTime;

	}

	/*
	 * Raxsana Added 17/09/2020
	 */
	public String getAccountActualBalance(String cardNo) {
		String queryToGetActualBal = "select actual_balance from accounts where account_oid =(select account_oid from cards where card_no='"
				+ cardNo + "')";
		String actualBalanceBefore = connectDBAndGetValue(queryToGetActualBal,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		logInfo("actualBalanceBefore::" + actualBalanceBefore);
		return actualBalanceBefore;
	}

	/*
	 * Raxsana added 21/09/2020
	 */

	public void postManualWriteOffPayments(String paymentType, String clientName, String clientCountry) {
		Common common = new Common(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		CommonInterfacePage commonInterfacePage = new CommonInterfacePage(driver, test);
		String clientNameInProp = PropUtils.getPropValue(configProp, clientName + "_" + clientCountry).trim()
				.toString();
		logInfo("client name::" + clientNameInProp);
		Map<String, String> inputValues = getInputValuesForPayment(paymentType, clientName, clientCountry);
		System.out.println("inputValues::" + inputValues);
		IFCSHomePage.gotoTransactionAndClickManualPayment();
		enterValueInTextBox("Manual Payment", "Account No", inputValues.get("CUSTOMER_NO"));
		chooseOptionFromDropdown("Type", "Cheque Payment");
		String date = commonInterfacePage.funcFetchLoadCardTransStartDateFromIFCSDB(configProp, clientNameInProp);
		logInfo("date::" + date);
		Date dateFormat = null;
		String dateFormatted = "";
		try {
			DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
			dateFormat = df.parse(date);
			// dateFormat1 = new SimpleDateFormat("dd/MM/yyyy").parse(processingDate);
			logInfo("Date Format" + dateFormat);
			dateFormatted = new SimpleDateFormat("dd/MM/yyyy").format(dateFormat);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		DecimalFormat decimalFormat = new DecimalFormat("#.##");
		Double writeOffAmount = Double.parseDouble(inputValues.get("REQUEST_TOTAL")) - 0.05;
		decimalFormat.setRoundingMode(RoundingMode.UP);
		enterValueInTextBox("Manual Payment", "Effective Date", dateFormatted);
		enterValueInTextBox("Manual Payment", "Amount", String.valueOf(decimalFormat.format(writeOffAmount)));
		sleep(3);
		String refNo = inputValues.get("PAYMENT_REFERENCE");
		logInfo("reference no::" + refNo);
		enterValueInTextBox("Manual Payment", "Reference No", refNo);
		sleep(3);
		common.clickValidateIcon();
		verifyValidationResult("Validation successful");
		sleep(3);
		common.clickPostTransaction();
		verifyValidationResult("Record saved OK");
		validateManualWriteOffPayment(dateFormatted, inputValues.get("CUSTOMER_NO"));
		validateWriteOffPaymentAllocation(inputValues);
	}

	public String amount;

	public void postManualPayments(String paymentTypeDB, String paymentToSelect, String clientName,
			String clientCountry, String paymentAdvNumber, String paymentAmount) {
		Common common = new Common(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		CommonInterfacePage commonInterfacePage = new CommonInterfacePage(driver, test);
		// String clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		String clientNameInProp = PropUtils.getPropValue(configProp, clientName + "_" + clientCountry).trim()
				.toString();
		logInfo("client name::" + clientNameInProp);
		Map<String, String> inputValues = getInputValuesForPayment(paymentTypeDB, clientName, clientCountry);
		System.out.println("inputValues::" + inputValues);
		IFCSHomePage.gotoTransactionAndClickManualPayment();
		customerNo = inputValues.get("CUSTOMER_NO");
		enterValueInTextBox("Manual Payment", "Account No", inputValues.get("CUSTOMER_NO"));
		chooseOptionFromDropdown("Type", paymentToSelect);// Cheque Payment
		String date = commonInterfacePage.funcFetchLoadCardTransStartDateFromIFCSDB(configProp, clientNameInProp);
		logInfo("date::" + date);
		Date dateFormat = null;
		String dateFormatted = "";
		try {
			DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
			dateFormat = df.parse(date);
			// dateFormat1 = new SimpleDateFormat("dd/MM/yyyy").parse(processingDate);
			logInfo("Date Format" + dateFormat);
			dateFormatted = new SimpleDateFormat("dd/MM/yyyy").format(dateFormat);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		enterValueInTextBox("Manual Payment", "Effective Date", dateFormatted);
		enterValueInTextBox("Manual Payment", "Amount", inputValues.get("REQUEST_TOTAL"));//paymentAmount);
		amount = paymentAmount;
		sleep(3);
		refNo = inputValues.get("PAYMENT_REFERENCE");
		enterValueInTextBox("Manual Payment", "Reference No", refNo);//paymentAdvNumber);
		sleep(3);
		common.clickValidateIcon();
		verifyValidationResult("Validation successful");
		sleep(3);
		common.clickPostTransaction();
		verifyValidationResult("Record saved OK");
		refNoRemittane = inputValues.get("REMITTANCE_ID");

	}

	/*
	 * Rathna added 25/09/2020
	 */
	public void VerifyPostTransaction(String allocationType, String table, boolean flag) {
		MaintainCustomerPage maintainCustomerPage = new MaintainCustomerPage(driver, test);
		Common common = new Common(driver, test);
		chooseSubMenuFromLeftPanel("Maintain Account", "Maintain Allocated Funds");
		common.chooseCustomerNoAndSearch(customerNo);
		int rowCount = maintainCustomerPage.getRowCount(table);

		if (flag)
			isPaymentPosted(table, rowCount);
		else
			isPaymentNotPosted(table, rowCount);

	}

	/*
	 * Rathna added 23/09/2020
	 */
	public void isPaymentPosted(String seperatorLabelName, int rowCount) {
		List<WebElement> tableHeaders;
		String seperator = " ";
		String cardNo = "";
		int colIndex = 8;
		int count = 0;
		seperator = splitStringAndGenerateXpath(seperatorLabelName);

		for (int rowIndex = 0; rowIndex <= rowCount - 1; rowIndex++) {
			String s = "//div[@class='JFALSeparator']//div[" + seperator
					+ "]//preceding::div[@class='JFALCompControlPanel'][1]//div[@class='FALTableCellEditor_StrikeThruField JTextComponent']//input[contains(@id,'_"
					+ rowIndex + "_" + colIndex + "')]";
			WebElement paymentRef = driver.findElement(By.xpath("//div[@class='JFALSeparator']//div[" + seperator
					+ "]//preceding::div[@class='JFALCompControlPanel'][1]//div[@class='FALTableCellEditor_StrikeThruField JTextComponent']//input[contains(@id,'_"
					+ rowIndex + "_" + colIndex + "')]"));

			System.out.println("statuscellValue::" + paymentRef);
			String refNum = paymentRef.getAttribute("submittedvalue");
			if (refNum.contains(amount)) {
				count++;
				break;
			}

		}
		if (count > 0)
			logPass("ChequePayment is Posted");
		else
			logFail("ChequePayment is not Posted");

	}

	/*
	 * Rathna added 23/09/2020
	 */
	public void isPaymentNotPosted(String seperatorLabelName, int rowCount) {
		List<WebElement> tableHeaders;
		String seperator = " ";
		String cardNo = "";
		int colIndex = 8;
		int count = 0;
		seperator = splitStringAndGenerateXpath(seperatorLabelName);

		for (int rowIndex = 0; rowIndex <= rowCount - 1; rowIndex++) {
			WebElement paymentRef = driver.findElement(By.xpath("//div[@class='JFALSeparator']//div[" + seperator
					+ "]//preceding::div[@class='JFALCompControlPanel'][1]//div[@class='FALTableCellEditor_StrikeThruField JTextComponent']//input[contains(@id,'_"
					+ rowIndex + "_" + colIndex + "')]"));

			System.out.println("statuscellValue::" + paymentRef);
			String refNum = paymentRef.getAttribute("submittedvalue");
			if (refNum.contains(amount)) {
				paymentRef.click();
				driver.findElement(By.xpath(
						"//div[@class='JFALToolBarButton enabled JButton'][contains(@title,'Process') and  contains(@title,'Reversal')]/div[@class='htmlImage']"))
						.click();
				count++;
				break;
			}

		}
		if (count == 0)
			logPass("ChequePayment is not Posted");
		else
			logFail("ChequePayment is not Posted");

	}


	/*
	 * Raxsana added 21/09/2020
	 */

	public void validateManualWriteOffPayment(String dateFormatted, String customerNo) {

		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		Common common = new Common(driver, test);
		IFCSHomePage.gotoTransactionAndClickManageTransaction();
		chooseSubMenuFromLeftPanel("Client Transactions", "Transactions");
		common.clearingAllTextBoxes(textBoxes);
		enterValueInTextBox("Transaction Filter Fields", "Process Date From",
		 dateFormatted);
		chooseOptionFromDropdown("Transaction Type", "Payment Threshold Write-Off");
		// enterValueInTextBox("Transaction Filter Fields", "Customer No", customerNo);
		common.searchListTorch();
		String writeOffType = driver.findElement(By.xpath("//input[contains(@id,'_0_2Input')]")).getAttribute("value");
		//String writeOffValue = driver.findElement(By.xpath("//input[contains(@id,'_0_8Input')]")).getAttribute("value");
		if (writeOffType.equalsIgnoreCase("Payment Threshold Write Off") ) {//&& writeOffValue.equalsIgnoreCase("-0.05")) {
			logPass("WritOff Payment posted");
		} else {
			logFail("WriteOff payment not posted");
		}
	}

	/*
	 * Raxsana added 21/09/2020
	 */
	public void validateWriteOffPaymentAllocation(Map<String, String> inputValues) {
		String queryToGetDetailGroupOid = "select detail_group_oid from detail_groups where payment_request_oid='"
				+ inputValues.get("PAYMENT_REQUEST_OID") + "'";
		String detailGroupOid = connectDBAndGetValue(queryToGetDetailGroupOid,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		String queryToGetRemittanceAmounts = "select remittance_amount from detail_groups where payment_request_oid='"
				+ inputValues.get("PAYMENT_REQUEST_OID") + "'";
		String remittanceAmounts = connectDBAndGetValue(queryToGetRemittanceAmounts,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		String queryToGetAllocatedPayment = "select amount from allocations where dr_detail_group_oid='"
				+ detailGroupOid + "'";
		String allocatedPayment = connectDBAndGetValue(queryToGetAllocatedPayment,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		DecimalFormat decimalFormat = new DecimalFormat("##.##");
		decimalFormat.setRoundingMode(RoundingMode.UP);
		String allocatedAmount = String.valueOf(decimalFormat.format(Double.parseDouble(allocatedPayment) + 0.05));
		if (remittanceAmounts.equals(allocatedAmount)) {
			logPass("Payment allocations done successfully");
		} else {
			logFail("Payment  allocations not done successfully");
		}

	}

	/*
	 * Raxsana added 21/09/2020
	 */
	public Map<String, String> getInputValuesForPayment(String paymentType, String clientName, String clientCountry) {
		Map<String, String> inputValues = new HashMap<String, String>();
		String clientNameCountry = PropUtils.getPropValue(configProp, clientName + "_" + clientCountry);
		String queryToGetValues;
		if(paymentType.contains("Dishonour")) {
			queryToGetValues = "select distinct mc.customer_no,mc.name,dg.remittance_id,tt.external_code,a.account_oid,"
					+ "pc.payment_request_oid,pc.payment_reference,pc.request_total from accounts a\r\n"
					+ "inner join detail_groups dg on a.account_oid=dg.account_oid \r\n"
					+ "inner join transactions t on a.account_oid=t.account_oid \r\n"
					+ "inner join trans_translations tt on t.transaction_type_oid=tt.transaction_type_oid\r\n"
					+ "inner join m_customers mc on mc.customer_mid=a.customer_mid \r\n"
					+ "inner join account_status acs on a.account_status_oid=acs.account_status_oid\r\n"
					+ "inner join payment_requests pc on pc.account_oid=a.account_oid "
					+ "inner join cards c on mc.customer_mid=c.customer_mid\r\n"
					+ "inner join card_status cs on cs.card_status_oid=c.card_status_oid \r\n" + "where tt.description='"
					+ paymentType + "' and \r\n" + "mc.client_mid=(select client_mid from m_clients where name='"
					+ clientNameCountry + "') \r\n"
					+ "and pc.request_total between 0 and 500 and cs.description ='Normal Service' \r\n"
					+ "and dg.remittance_id not like '" + clientCountry + "%' and pc.payment_reference like '00%' \r\n"
					+ "and acs.description like '%Active%' and pc.is_paid_in_full = 'Y'";//a.actual_balance>0
		}else {
		queryToGetValues = "select distinct mc.customer_no,mc.name,dg.remittance_id,tt.external_code,a.account_oid,"
				+ "pc.payment_request_oid,pc.payment_reference,pc.request_total from accounts a\r\n"
				+ "inner join detail_groups dg on a.account_oid=dg.account_oid \r\n"
				+ "inner join transactions t on a.account_oid=t.account_oid \r\n"
				+ "inner join trans_translations tt on t.transaction_type_oid=tt.transaction_type_oid\r\n"
				+ "inner join m_customers mc on mc.customer_mid=a.customer_mid \r\n"
				+ "inner join account_status acs on a.account_status_oid=acs.account_status_oid\r\n"
				+ "inner join payment_requests pc on pc.account_oid=a.account_oid "
				+ "inner join cards c on mc.customer_mid=c.customer_mid\r\n"
				+ "inner join card_status cs on cs.card_status_oid=c.card_status_oid \r\n" + "where tt.description='"
				+ paymentType + "' and \r\n" + "mc.client_mid=(select client_mid from m_clients where name='"
				+ clientNameCountry + "') \r\n"
				+ "and pc.request_total between 0 and 500 and dg.host_credit_amount=0 and cs.description ='Normal Service' \r\n"
				+ "and dg.remittance_id not like '" + clientCountry + "%' and pc.payment_reference like '00%' \r\n"
				+ "and acs.description like '%Active%' and pc.is_paid_in_full = 'N'";//a.actual_balance>0
		}
		inputValues = connectDBAndGetDBEntireRowValues(queryToGetValues,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		return inputValues;
	}

	/*
	 * Raxsana added 23/09/2020
	 */

	public Map<String, String> getAccountDetailsForManualPayments(String clientName, String clientCountry,
			String isPartialOrFull) {
		IFCSHomePage ifcsHomePage = new IFCSHomePage(driver, test);
		Common common = new Common(driver, test);
		Map<String, String> inputValues = new HashMap<String, String>();
		String queryToGetAccountNo = "select distinct a.account_no from accounts a\r\n"
				+ "inner join m_customers mc on mc.customer_mid=a.customer_mid\r\n"
				+ "inner join account_status ass on ass.account_status_oid=a.account_status_oid\r\n"
				+ "inner join unallocated_funds uf on uf.account_oid= a.account_oid\r\n"
				+ "inner join payment_requests pc on pc.account_oid=a.account_oid\r\n"
				+ "inner join cards c on c.customer_mid=mc.customer_mid\r\n"
				+ "where ass.description like '%Active' and uf.amount <> '0' and pc.payment_reference is not null \r\n"
				+ "and pc.request_total_actual <> '0' and c.expires_on >=(SELECT PROCESSING_DATE from M_CLIENTS where Name ='"
				+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountry) + "')"
				+ " and mc.client_mid=(select client_mid from m_clients where name='"
				+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountry) + "')";
		String accountNo = connectDBAndGetValue(queryToGetAccountNo,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		inputValues.put("ACCOUNT_NO", accountNo);
		ifcsHomePage.gotoAccountAndClickAccountDetails();
		common.searchTorch();
		common.chooseNoAndSearch("Customer No", accountNo);
		sleep(3);
		common.findRecordTorch();
		sleep(5);
		common.closeFindRecordTorch();
		chooseSubMenuFromLeftPanel("Maintain Account", "Maintain Unallocated Funds");
		String paymentAdvice = driver.findElement(By.xpath(
				"//div[@class='JFALSeparator_1']//div[@class='htmlString'][contains(text(),'Debits')]/preceding::div[contains(@id,'_0_7')]//div[@class='htmlString']"))
				.getText();
		inputValues.put("PAYMENT_ADVICE", paymentAdvice);
		String amount = driver.findElement(By.xpath(
				"//div[@class='JFALSeparator_1']//div[@class='htmlString'][contains(text(),'Debits')]/preceding::input[contains(@id,'_0_11Input')]"))
				.getAttribute("value");
		if (isPartialOrFull.equalsIgnoreCase("Partial")) {
			DecimalFormat df = new DecimalFormat("##.##");
			df.setRoundingMode(RoundingMode.UP);
			String unallocatedAmount = String.valueOf(df.format(Double.parseDouble(amount) / 2));
			inputValues.put("AMOUNT", unallocatedAmount);
		} else {
			inputValues.put("AMOUNT", amount);
		}
		System.out.println("inputValues::" + inputValues);
		logInfo("Values::" + inputValues);
		return inputValues;
	}

	/*
	 * Raxsana added 23/09/2020
	 */

	public void postManualPayments(String paymentType, Map<String, String> inputValues, String clientName,
			String clientCountry) {
		Common common = new Common(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		CommonInterfacePage commonInterfacePage = new CommonInterfacePage(driver, test);
		String clientNameInProp = PropUtils.getPropValue(configProp, clientName + "_" + clientCountry).trim()
				.toString();
		logInfo("client name::" + clientNameInProp);
		IFCSHomePage.gotoTransactionAndClickManualPayment();
		enterValueInTextBox("Manual Payment", "Account No", inputValues.get("ACCOUNT_NO"));
		chooseOptionFromDropdown("Type", paymentType);
		String date = commonInterfacePage.funcFetchLoadCardTransStartDateFromIFCSDB(configProp, clientNameInProp);
		logInfo("date::" + date);
		Date dateFormat = null;
		String dateFormatted = "";
		try {
			DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
			dateFormat = df.parse(date);
			// dateFormat1 = new SimpleDateFormat("dd/MM/yyyy").parse(processingDate);
			logInfo("Date Format" + dateFormat);
			dateFormatted = new SimpleDateFormat("dd/MM/yyyy").format(dateFormat);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		enterValueInTextBox("Manual Payment", "Effective Date", dateFormatted);
		enterValueInTextBox("Manual Payment", "Amount", inputValues.get("AMOUNT"));
		sleep(3);
		enterValueInTextBox("Manual Payment", "Reference No", inputValues.get("PAYMENT_ADVICE"));
		sleep(3);
		common.clickValidateIcon();
		verifyValidationResult("Validation successful");
		sleep(3);
		common.clickPostTransaction();
		verifyValidationResult("Record saved OK");
	}
	
	

	/*
	 * Raxsana Added 23/09/2020
	 */
	public void validateAlloctedAmount(Map<String, String> inputValues) {
		IFCSHomePage ifcsHomePage = new IFCSHomePage(driver, test);
		Common common = new Common(driver, test);
		ifcsHomePage.gotoAccountAndClickAccountDetails();
		chooseSubMenuFromLeftPanel("Maintain Account", "Maintain Unallocated Funds");
		try {
			WebElement paymentAdvice = driver.findElement(
					By.xpath("//div[@class='FALTableCellEditor_StrikeThruField JTextComponent']//input[@value='"
							+ inputValues.get("PAYMENT_ADVICE") + "']"));
			paymentAdvice.click();
			driver.findElement(
					By.xpath("//div[@class='FALTableCellEditor_StrikeThruField JTextComponent']//input[@value='" + "-"
							+ inputValues.get("AMOUNT") + "']"));
			logPass("Payment credited");
		} catch (Exception e) {
			logFail("Payment not credited");
		}
		common.rightClick(driver.findElement(By.xpath(
				"//div[@class='JFALSeparator_1']//div[contains(text(),'Funds') and contains(text(),'Allocation')]/preceding::div[@class='JFALTable']")));
		common.addIteminPopup();
		common.clickOkButton();
		sleep(5);
		isDisplayedThenClick(processAllocationIcon, "Process allocation");
		sleep(2);
		verifyValidationResult("Record saved OK");

		String unallocatedAmount = String.valueOf(
				Double.parseDouble(inputValues.get("AMOUNT")) * 2 - Double.parseDouble(inputValues.get("AMOUNT")));
		if (!(unallocatedAmount.equalsIgnoreCase("0.00"))) {
			logPass("Amount Allocated");
		} else {
			logFail("Amount not allocated");
		}
	}

	/*
	 * Raxsana Added 23/09/2020
	 */
	public String getAmountForPartialPayment() {

		String unallocatedAmount = driver.findElement(By.xpath(
				"//div[@class='JFALSeparator_1']//div[@class='htmlString'][contains(text(),'Debits')]/preceding::input[contains(@id,'_0_11Input')]"))
				.getAttribute("value");
		logInfo("unallocatedAmount::" + unallocatedAmount);
		return unallocatedAmount;
	}

	/*
	 * Raxsana Added 23/09/2020
	 */
	public void validateFullAlloctedAmount(Map<String, String> inputValues) {
		IFCSHomePage ifcsHomePage = new IFCSHomePage(driver, test);
		ifcsHomePage.gotoAccountAndClickAccountDetails();
		chooseSubMenuFromLeftPanel("Maintain Account", "Maintain Allocated Funds");
		String unallocatedAmount = driver.findElement(By.xpath(
				"//div[@class='JFALSeparator_1']//div[@class='htmlString'][contains(text(),'Debits')]/preceding::input[contains(@id,'_0_10')]"))
				.getAttribute("value");
		if (unallocatedAmount.equalsIgnoreCase("0.00")) {
			logPass("Amount allocated fully");
		} else {
			logFail("Amount not allocated fully");
		}
	}

	/*
	 * Raxsana Added 24/09/2020
	 */
	public void validateUnallocatedDishonourPayment(String paymentType, Map<String, String> inputValues) {
		IFCSHomePage ifcsHomePage = new IFCSHomePage(driver, test);
		ifcsHomePage.gotoAccountAndClickAccountDetails();
		chooseSubMenuFromLeftPanel("Maintain Account", "Maintain Unallocated Funds");
		try {
			String id = driver.findElement(By.xpath(
					"//div[@class='JFALSeparator_1']//div[@class='htmlString'][contains(text(),'Debits')]/preceding::input[contains(@id,'_11Input')][contains(@value,'"
							+ inputValues.get("AMOUNT") + "')]"))
					.getAttribute("id");
			String row = id.split("_")[4];
			String paymentTypeFromTable = driver.findElement(By.xpath(
					"//div[@class='JFALSeparator_1']//div[@class='htmlString'][contains(text(),'Debits')]/preceding::div[contains(@id,'_"
							+ row + "_5')]//div[@class='htmlString']"))
					.getText();
			String paymentReferenceFromTable = driver.findElement(By.xpath(
					"//div[@class='JFALSeparator_1']//div[@class='htmlString'][contains(text(),'Debits')]/preceding::div[contains(@id,'_"
							+ row + "_8')]//div[@class='htmlString']"))
					.getText();
			String accountNoFromTable = driver.findElement(By.xpath(
					"//div[@class='JFALSeparator_1']//div[@class='htmlString'][contains(text(),'Debits')]/preceding::input[contains(@id,'_"
							+ row + "_12Input')]"))
					.getAttribute("value");
			System.out.println(paymentTypeFromTable + paymentReferenceFromTable + accountNoFromTable);
			if (paymentTypeFromTable.equalsIgnoreCase(paymentType)
					&& paymentReferenceFromTable.equalsIgnoreCase(inputValues.get("PAYMENT_ADVICE"))
					&& accountNoFromTable.equalsIgnoreCase(inputValues.get("ACCOUNT_NO"))) {
				logPass("Dishonour posted");
			} else {
				logFail("Dishonour not posted");
			}
		} catch (Exception e) {
			e.getMessage();
		}
	}

	/*
	 * Rathna added
	 */
	public String customerNo, refNo, refNoRemittane;

	public void postManualPayments(String paymentTypeDB, String paymentToSelect, String clientName,
			String clientCountry) {
		Common common = new Common(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		CommonInterfacePage commonInterfacePage = new CommonInterfacePage(driver, test);
		// String clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		String clientNameInProp = PropUtils.getPropValue(configProp, clientName + "_" + clientCountry).trim()
				.toString();
		logInfo("client name::" + clientNameInProp);
		Map<String, String> inputValues = getInputValuesForPayment(paymentTypeDB, clientName, clientCountry);
		System.out.println("inputValues::" + inputValues);
		IFCSHomePage.gotoTransactionAndClickManualPayment();
		customerNo = inputValues.get("CUSTOMER_NO");
		enterValueInTextBox("Manual Payment", "Account No", inputValues.get("CUSTOMER_NO"));
		chooseOptionFromDropdown("Type", paymentToSelect);
		String date = commonInterfacePage.funcFetchLoadCardTransStartDateFromIFCSDB(configProp, clientNameInProp);
		logInfo("date::" + date);
		Date dateFormat = null;
		String dateFormatted = "";
		try {
			DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
			dateFormat = df.parse(date);
			// dateFormat1 = new SimpleDateFormat("dd/MM/yyyy").parse(processingDate);
			logInfo("Date Format" + dateFormat);
			dateFormatted = new SimpleDateFormat("dd/MM/yyyy").format(dateFormat);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String amount=inputValues.get("REQUEST_TOTAL");
		enterValueInTextBox("Manual Payment", "Effective Date", dateFormatted);
		enterValueInTextBox("Manual Payment", "Amount", amount);
		sleep(3);
		Faker faker = new Faker();
		if(paymentToSelect.equalsIgnoreCase("Direct Debit Dishonour")) {
			refNo = faker.number().digits(5);
		}else {
			refNo = inputValues.get("PAYMENT_REFERENCE");
		}
		enterValueInTextBox("Manual Payment", "Reference No", refNo);
		sleep(3);
		common.clickValidateIcon();
		verifyValidationResult("Validation successful");
		sleep(3);
		common.clickPostTransaction();
		verifyValidationResult("Record saved OK");
		refNoRemittane = inputValues.get("REMITTANCE_ID");

	}

	/*
	 * Rathna added 23/09/2020
	 */
	public void CheckPaymentIsPosted(String allocationType, String table) {
		MaintainCustomerPage maintainCustomerPage = new MaintainCustomerPage(driver, test);
		Common common = new Common(driver, test);
		chooseSubMenuFromLeftPanel("Maintain Account", allocationType);
		common.chooseCustomerNoAndSearch(customerNo);
		WebElement location = driver.findElement(By.xpath(
				"//div[@class='JFALSeparator']//div[contains(text(),'Debits')]/preceding::div[@class = 'JFALCompControlPanel'][1]//div[contains(@id,'_0_3')]//*[2]"));
		common.rightClickAndSelectMenuItem("Details", location, popupMenuItemSortDesc);
		int rowCount = maintainCustomerPage.getRowCount(table);
		if (table.equalsIgnoreCase("Debits")) {
			checkPaymentInDebits(table, rowCount);
		} else {
			checkPaymentInCredits(table, rowCount);
		}

	}

	/*
	 * Rathna added 25/09/2020
	 */
	public void VerifyPostTransaction(String allocationType, String table) {
		MaintainCustomerPage maintainCustomerPage = new MaintainCustomerPage(driver, test);
		Common common = new Common(driver, test);
		chooseSubMenuFromLeftPanel("Maintain Account", "Maintain Allocated Funds");
		common.chooseCustomerNoAndSearch(customerNo);
		int rowCount = maintainCustomerPage.getRowCount(table);

		checkPaymentInCredits(table, rowCount);

	}
/*
	 * Rathna added 23/09/2020
	 */
	public void checkPaymentInDebits(String seperatorLabelName, int rowCount) {
		List<WebElement> tableHeaders;
		String seperator = " ";
		String cardNo = "";
		int colIndex = 7;
		int count = 0;
		seperator = splitStringAndGenerateXpath(seperatorLabelName);

		for (int rowIndex = 0; rowIndex <= rowCount - 1; rowIndex++) {
			WebElement paymentRef = driver.findElement(By.xpath("//div[@class='JFALSeparator']//div[" + seperator
					+ "]//preceding::div[@class='JFALCompControlPanel'][1]//div[@class='FALTableCellEditor_StrikeThruField JTextComponent'][contains(@id,'_"
					+ rowIndex + "_" + colIndex + "')]//div[2]"));

			System.out.println("statuscellValue::" + paymentRef);
			System.out.println(paymentRef.getText());
			String refNum = paymentRef.getText();
			if (refNum.equals(refNo)) {
				count++;
				break;
			}

		}
		if (count > 0)
			logPass("Dishonoured DD Payment is Posted");
		else
			logFail("Dishonoured DD Payment is not Posted");
	}

	/*
	 * Rathna added 23/09/2020
	 */
	public void checkPaymentInCredits(String seperatorLabelName, int rowCount) {
		List<WebElement> tableHeaders;
		String seperator = " ";
		String cardNo = "";
		int colIndex = 8;
		int count = 0;
		seperator = splitStringAndGenerateXpath(seperatorLabelName);

		for (int rowIndex = 0; rowIndex <= rowCount - 1; rowIndex++) {
			WebElement paymentRef = driver.findElement(By.xpath("//div[@class='JFALSeparator']//div[" + seperator
					+ "]//preceding::div[@class='JFALCompControlPanel'][1]//div[@class='FALTableCellEditor_StrikeThruField JTextComponent']//input[contains(@id,'_"
					+ rowIndex + "_" + colIndex + "')]"));

			System.out.println("statuscellValue::" + paymentRef);
			try {
				System.out.println(paymentRef.getAttribute("submittedvalue"));
			} catch (Exception e) {
				System.out.println(paymentRef.getAttribute("value"));
			}

			String refNum = paymentRef.getAttribute("submittedvalue");
			if (refNum.contains("401.67")) {
				count++;
				break;
			}

		}
		if (count > 0)
			logPass("ChequePayment is Posted");
		else
			logFail("ChequePayment is not Posted");
	}
/*
	 * added by davu
	 */
	public String getCustomerNoBasedOnBulkReissueStatus(String clientFullName, String reissueStatus) {

		Common common = new Common(driver, test);
		String queryTogetCustomerNo = null;

		if (reissueStatus.equals("Awaiting Confirmation")) {
			queryTogetCustomerNo = "select mc.customer_no from card_bulk_reissues cbr\r\n"
					+ "inner join M_customers mc on cbr.customer_mid = mc.customer_mid\r\n"
					+ "inner join m_clients mcs on mc.client_mid = mcs.client_mid\r\n"
					+ "where bulk_reissue_status_cid ='6101' and mcs.name ='"
					+ PropUtils.getPropValue(configProp, clientFullName) + "'";
		}

		else if (reissueStatus.equals("Confirmed Reissue Pending")) {
			queryTogetCustomerNo = "select mc.customer_no from card_bulk_reissues cbr\r\n"
					+ "inner join M_customers mc on cbr.customer_mid = mc.customer_mid\r\n"
					+ "inner join m_clients mcs on mc.client_mid = mcs.client_mid\r\n"
					+ "where bulk_reissue_status_cid ='6102' and mcs.name ='"
					+ PropUtils.getPropValue(configProp, clientFullName) + "'";
		} else if (reissueStatus.equals("Reissue Complete")) {
			queryTogetCustomerNo = "select mc.customer_no from card_bulk_reissues cbr\r\n"
					+ "inner join M_customers mc on cbr.customer_mid = mc.customer_mid\r\n"
					+ "inner join m_clients mcs on mc.client_mid = mcs.client_mid\r\n"
					+ "where bulk_reissue_status_cid ='6103' and mcs.name ='"
					+ PropUtils.getPropValue(configProp, clientFullName) + "'";
		}

		String customerNo = common.connectDBAndGetValue(queryTogetCustomerNo,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		return customerNo;
	}

	public String getLocationNumberForWFE(String clientName, String clientCountry) {

		Common common = new Common(driver, test);
		String queryToGetLocationNumber = "select external_code from m_locations ml inner join addresses ad on ml.postal_address_oid=ad.address_oid\r\n"
				+ "inner join countries c on c.country_oid=ad.country_oid where"
				+ " ml.client_mid=(select client_mid from m_clients where name='"
				+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountry) + "') and name not like '%VINCI%'";
						/*+ " and c.country_code='"
				+ clientCountry + "'";*/

		String locationNo = common.connectDBAndGetValue(queryToGetLocationNumber,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));

		return locationNo;
	}

	/*
	 * Added by davu
	 */

	public String getPreviseMonthEndDate(String ifcsDate) {

		String month = null;
		String date = null;
		String currentMonth = ifcsDate.substring(3, 5);
		String year = ifcsDate.substring(ifcsDate.length() - 4);

		if (currentMonth.equals("01")) {
			month = "12";
			int yearInt = Integer.parseInt(year) - 1;

			year = Integer.toString(yearInt);

		} else {
			int monthInt = Integer.parseInt(currentMonth) - 1;
			month = Integer.toString(monthInt);
		}

		if (month.equals("01") || month.equals("03") || month.equals("05") || month.equals("07") || month.equals("08")
				|| month.equals("10") || month.equals("12")) {

			date = "31";
		} else if (month.equals("04") || month.equals("06") || month.equals("09") || month.equals("11")) {
			date = "30";
		} else if (month.equals("02")) {

			date = "28";
		}

		String previsemonthEndDate = date + "/" + month + "/" + year;

		System.out.println("date :::" + previsemonthEndDate);

		return previsemonthEndDate;
	}

	/*
	 * added by davu
	 */
	public Map<String,String> getCardNumberfromPOSTransactions(String clientCode) {

		String queryToGetCardFromDB = "select Card_no,processed_at from POS_Transactions where external_code_client ='" + clientCode
				+ "'";// order by processed_at desc
		/*String queryToGetCardFromDB ="select card_no from transactions where \r\n" + 
		"customer_mid in (select customer_mid from m_customers where client_mid=(select client_mid from m_clients where name='"+PropUtils.getPropValue(configProp, clientCode)+"'))\r\n" + 
		"and card_no is not null order by processed_at desc";*/
		Map<String,String> cardNo = connectDBAndGetDBEntireRowValues(queryToGetCardFromDB, PropUtils.getPropValue(configProp, "sqlODSServerName"));//connectDBAndGetValue(queryToGetCardFromDB,
				//PropUtils.getPropValue(configProp, "sqlODSServerName"));
		System.out.println(queryToGetCardFromDB);
		return cardNo;
	}

	/*
	 * added by davu
	 */
	public String getCardNumberWithLowVelocityValue(String clientCode, String velocityValue) {

		String queryToGetCardFromDB = "select  c.card_no from cards c "
				+ "INNER join Card_control_profiles  ccp on c.card_oid = ccp.card_oid "
				+ "INNER join card_controls cc on ccp.CARD_CONTROL_PROFILE_OID = cc.CARD_CONTROL_PROFILE_OID "
				+ "Inner join Velocity_Assignments va on cc.velocity_assignment_oid = va.velocity_assignment_oid "
				+ "inner join m_customers mc on c.customer_mid = mc.customer_mid "
				+ "Inner join Card_status CS on c.card_status_oid = cs.card_status_oid "
				+ "inner join velocity_type_values vtv on va.velocity_type_value_" + velocityValue
				+ "_oid = vtv.velocity_type_value_oid "
				+ "inner join m_clients ms on ms.client_mid = mc.client_mid inner join time_limits tl on tl.time_limit_oid=cc.time_limit_oid where ms.IE_Client_ID ='" + clientCode
				+ "' and CS.Description like 'Normal Service' and\r\n" + 
				"tl.description='All days, all times' and value <100 order by value  DESC";
		String cardNo = connectDBAndGetValue(queryToGetCardFromDB,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		System.out.println(queryToGetCardFromDB);
		return cardNo;
	}

	/*
	 * added by davu
	 */

	public String getParentOrChildCustomersHavingCardsWithExpectedStatus(String clientFullName, String customerType,
			String cardStatus) {

		String customerNumber = null;
		Map<String, String> childCustomerNumberAndHierarchyId = null;
		clientFullName = PropUtils.getPropValue(configProp, clientFullName);

		if (customerType.equals("child")) {
			String childCustomerNumberQuery = "select distinct mc.customer_no,rel.hierarchy_oid from cards c \r\n"
					+ "inner join m_customers mc on mc.customer_mid = c.customer_mid\r\n"
					+ "inner join card_programs cp on cp.card_program_oid=mc.card_program_oid\r\n"
					+ "INNER JOIN CARD_STATUS cs on c.CARD_STATUS_OID = cs.CARD_STATUS_OID\r\n"
					+ "inner join relationships rel on c.customer_mid = rel.member_oid\r\n"
					+ "inner join M_clients mcs on mc.client_mid = mcs.client_mid\r\n"
					+ "where rel.relationship_oid<>rel.parent_relationship_oid \r\n"
					+ "and c.replace_card_oid IS NULL and\r\n" + "mcs.name = '" + clientFullName
					+ "' and cs.DESCRIPTION = '" + cardStatus + "'";
			childCustomerNumberAndHierarchyId = connectDBAndGetDBEntireRowValues(childCustomerNumberQuery,
					PropUtils.getPropValue(configProp, "sqlODSServerName"));
			customerNumber = childCustomerNumberAndHierarchyId.get("CUSTOMER_NO");
			System.out.println("Child Customer Number:" + customerNumber);

		}
		if (customerType.equals("parent")) {

			String childCustomerNumberQuery = "select distinct mc.customer_no,rel.hierarchy_oid from cards c \r\n"
					+ "inner join m_customers mc on mc.customer_mid = c.customer_mid\r\n"
					+ "inner join card_programs cp on cp.card_program_oid=mc.card_program_oid\r\n"
					+ "INNER JOIN CARD_STATUS cs on c.CARD_STATUS_OID = cs.CARD_STATUS_OID\r\n"
					+ "inner join relationships rel on c.customer_mid = rel.member_oid\r\n"
					+ "inner join M_clients mcs on mc.client_mid = mcs.client_mid\r\n"
					+ "where rel.relationship_oid<>rel.parent_relationship_oid \r\n"
					+ "and c.replace_card_oid IS NULL and\r\n" + "mcs.name = '" + clientFullName
					+ "' and cs.DESCRIPTION = '" + cardStatus + "'";
			childCustomerNumberAndHierarchyId = connectDBAndGetDBEntireRowValues(childCustomerNumberQuery,
					PropUtils.getPropValue(configProp, "sqlODSServerName"));

			String parentCustomerNumberQuery = "select mc.customer_no from relationships rel\r\n"
					+ "inner join relationship_assignments rels on rel.relationship_oid=rels.relationship_oid \r\n"
					+ "inner join accounts acc on acc.customer_mid=rel.member_oid \r\n"
					+ "inner join m_customers mc on mc.customer_mid=acc.customer_mid \r\n"
					+ "inner join hierarchies hc on rel.hierarchy_oid = hc.hierarchy_oid\r\n"
					+ "and rel.relationship_oid =rel.parent_relationship_oid where hc.hierarchy_oid='"
					+ childCustomerNumberAndHierarchyId.get("HIERARCHY_OID") + "'";
			customerNumber = connectDBAndGetValue(parentCustomerNumberQuery,
					PropUtils.getPropValue(configProp, "sqlODSServerName"));

			System.out.println("Parent Number:" + customerNumber);

		}

		return customerNumber;
	}

	/*
	 * added by davu
	 */

	public String getCardNumberWithMonthlyCardFee(String clientFullName) {

		String queryToGetCardNumber = "select c.card_no from cards c\r\n"
				+ "inner join Fee_profiles fp on c.fee_profile_oid = fp.fee_profile_oid\r\n"
				+ "inner join m_customers mc on c.customer_mid = mc.customer_mid\r\n"
				+ "inner join Card_status cs on c.card_status_oid = cs.card_status_oid\r\n"
				+ "inner join m_clients mcs on mc.client_mid = mcs.client_mid where mcs.name = '" + clientFullName
				+ "' \r\n" + "and cs.description ='Normal Service' and fp.description like 'Monthly Card Fee%'";

		String cardNumber = connectDBAndGetValue(queryToGetCardNumber,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		return cardNumber;
	}

	/*
	 * added by davu
	 */
	public String getCardNumberWithMonthlyVinciFee(String clientFullName) {

		String queryToGetCardNumber = "select c.card_no from cards c\r\n"
				+ "inner join Fee_profiles fp on c.fee_profile_oid = fp.fee_profile_oid\r\n"
				+ "inner join m_customers mc on c.customer_mid = mc.customer_mid\r\n"
				+ "inner join Card_status cs on c.card_status_oid = cs.card_status_oid\r\n"
				+ "inner join m_clients mcs on mc.client_mid = mcs.client_mid where mcs.name = '" + clientFullName
				+ "' \r\n" + "and cs.description ='Normal Service' and fp.description like 'Monthly Vinci Fee%'";

		String cardNumber = connectDBAndGetValue(queryToGetCardNumber,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		return cardNumber;
	}
	
	/*
	 * Raxsana added on 21/10/2020
	 */
	
	public String getMerchantNoWithLocationHierarchy(String clientName,String clientCountry) {
		String merchantNo = null;
		String queryToGetMerchantNoFromDB="select mm.merchant_no from m_merchants mm \r\n" + 
				"inner join relationships r on r.member_oid=mm.merchant_mid \r\n" + 
				"where mm.client_mid=(select client_mid from m_clients where name='"+PropUtils.getPropValue(configProp, clientName+"_"+clientCountry)+"') and mm.merchant_no like '0000%' order by DBMS_RANDOM.VALUE";
		merchantNo= connectDBAndGetValue(queryToGetMerchantNoFromDB,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		return merchantNo;
	}

}
