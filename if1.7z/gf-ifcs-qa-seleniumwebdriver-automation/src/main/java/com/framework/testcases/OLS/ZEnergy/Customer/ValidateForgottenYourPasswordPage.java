package com.framework.testcases.OLS.ZEnergy.Customer;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.OLS.common.LoginPage;
import com.framework.pages.Z.ZLoginPage;

public class ValidateForgottenYourPasswordPage extends BaseTest {
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "Smoke" })
	public void verifyForgottenYourPasswordsPageDetails(@Optional("Z") String clientCountry,
			@Optional("ZEnergy") String clientName) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  Verifing Forgotten your password page ", "Verifing Forgotten your password page ");

		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		ZLoginPage zLoginPage = new ZLoginPage(driver, test);
		// launch login page
		loginPage.validateLoginPageFooterLinks(clientName, "ZEnergy_URL");
		// Click onForgotten your password link
		zLoginPage.clickForgotPasswordAndValidateTitle();
		// Validate logo
		zLoginPage.validateClientLogo();
		// Enter userID
		zLoginPage.enterForgotPasswordUserId();
		// zLoginPage.verifyTheSuccessMessage();
	}

}
