package com.framework.testcases.AJS.BP;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.ClientConfigPage;
import com.framework.pages.AJS.MaintainCustomerPage;
import com.framework.pages.AJS.OrderCardPage;
import com.framework.pages.AJS.common.Common;
import com.framework.pages.AJS.common.IFCSHomePage;
import com.framework.pages.AJS.common.IFCSLoginPage;

public class ValildateOrderNewCardTestCases extends BaseTest {
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "Prepaid", "Regression" })
	public void ValidateCreateNewPrivateProfileInOrderNewCard(@Optional("AU") String clientCountry,
			@Optional("BP") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  TC00017 & TC00018",
				"Create new private profile in Order New Card and Delete the private profile in Order New Card");

		// creating object for the Pages
		IFCSLoginPage ifcsLoginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage ifcsHomePage = new IFCSHomePage(driver, test);
		ClientConfigPage clientConfig = new ClientConfigPage(driver, test);
		MaintainCustomerPage maintainCustomerPage = new MaintainCustomerPage(driver, test);
		Common common = new Common(driver, test);

		ifcsLoginPage.login("IFCS_URL_BP", "IFCS_BP_USERNAME", "IFCS_BP_PASSWORD");
		ifcsLoginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		ifcsHomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);
		clientConfig.createANewCardFeeProfile(clientName, clientCountry, "BP PrePay Cards",
				"280 Card Issue Fee (GST Incl)", "210 Card Admin Fee (GST inc)");
		clientConfig.verifyOrCreateFeeConfigProfileFields("create", clientName, clientCountry);
		// Save the profile
		common.clickSaveIcon();
		common.checkRecordSaved();

		// Customer set Prepay Customer
		ifcsHomePage.gotoCustomerMenuCustomerDetails();
		String prepaidCustomer = common.getBPPrepaidCustomerNo();
		maintainCustomerPage.chooseCustomerNoAndSearch(prepaidCustomer);
		// Go to Customer -> Maintain Card Fees -> Add Available Profile and Add Card
		// Fee
		maintainCustomerPage.chooseMaintainCardFeesFromCustomerProfile();
		maintainCustomerPage.createCardFeePrivateProfile();
		common.clickSaveIcon();
		common.verifyValidationMessage();

		// Go to Cards and add a profile and delete
		maintainCustomerPage.updateOrderNewCardCardFeeProfile1();
		common.rightClickDeletePrivateProfileAndValidate("Profile Selection", "Description");

		ifcsHomePage.exitIFCS();

	}

	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "Smoke", "BusinessFlow" })
	public void ValidateAndDeclineANewCard(@Optional("AU") String clientCountry, @Optional("BP") String clientName) {
		String driverCard;

		if (clientCountry.equals("NZ")) {

			driverCard = "BP Fuelcard Driver";
		} else {

			driverCard = "BP Plus cards Driver";
		}

		test = extent.createTest(
				"Verify Interface BPNZ04_Card_NZ_001_Order cards and BPNZ05_Card_NZ_002_Emboss cards via ControlM",
				"Order Card and Card Embossing");

		// creating object for the Pages
		IFCSLoginPage ifcsLoginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage ifcsHomePage = new IFCSHomePage(driver, test);
		OrderCardPage orderCardpage = new OrderCardPage(driver, test);
		Common common = new Common(driver, test);

		ifcsLoginPage.login("IFCS_URL_BP", "IFCS_BP_USERNAME", "IFCS_BP_PASSWORD");
		ifcsLoginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		ifcsHomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);

		// Store the customer Number
		String customerNumber = common.getActiveCustomerNoUsingCardType();

		ifcsHomePage.gotoCustomerMenuCustomerDetails();
		common.chooseCustomerNoAndSearch(customerNumber);
		orderCardpage.declineNewCardsAndValidate(driverCard);
		ifcsHomePage.exitIFCS();

	}
}
