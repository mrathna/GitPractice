package com.framework.pages.AJS.common;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

import com.aventstack.extentreports.ExtentTest;
import com.framework.basepage.BasePage;
import com.framework.repo.Locator_SalesForce;
import com.framework.util.PropUtils;

public class SalesForceLoginPage extends BasePage{
	
	
	@FindBy(xpath = Locator_SalesForce.SALESFORCE_USERNAME)
	public WebElement userName;

	@FindBy(xpath = Locator_SalesForce.SALESFORCE_PASSWORD)
	public WebElement password;
	
	@FindBy(xpath = Locator_SalesForce.SALESFORCE_LOGIN)
	public WebElement loginButton;
	
	@FindBy(xpath = Locator_SalesForce.SALESFORCE_SEARCH)
	public WebElement search;
	
	@FindBy(xpath = Locator_SalesForce.SALESFORCE_ACCOUNT_NUMBER)
	public WebElement accountNumber;
	@FindBy(xpath = Locator_SalesForce.SALESFORCE_BILLING_PLAN)
	public WebElement billingPlan;

	@FindBy(xpath = Locator_SalesForce.SALESFORCE_SEARCH_AUTOCOMPLETE)
	public List<WebElement> searchAutoComplete;
	
	
	
	
	public SalesForceLoginPage(WebDriver driver, ExtentTest test) {
		super(driver, test);
		PageFactory.initElements(new AjaxElementLocatorFactory(driver, 15), this);
	}

	public void login(String url, String uname, String pwd) {

		// public void login(String url, String uname) {
		System.out.println("------- url ------------" + url);
		System.out.println("------- uname ------------" + uname);
		System.out.println("------- Pwd ------------" + pwd);

		System.out.println("PROP URL VALUE ------ " + PropUtils.getPropValue(configProp, url));

		driver.get(PropUtils.getPropValue(configProp, url));

		sleep(5);

		isDisplayedThenEnterText(userName, "IFCS login user name element", PropUtils.getPropValue(configProp, uname));

	//	isDisplayedThenEnterText(password, "IFCS login Password element", "");
		isDisplayedThenEnterText(password, "IFCS login Password element",  PropUtils.getPropValue(configProp, pwd));
		isDisplayedThenClick(loginButton, "Login Button");
		sleep(5);

		//isDisplayed(welcomeText, "Welcome");
	}
	
	
	public void Login(String url, String uname, String pwd) {

		// public void login(String url, String uname) {
		System.out.println("------- url ------------" + url);
		System.out.println("------- uname ------------" + uname);
		System.out.println("------- Pwd ------------" + pwd);
		System.out.println("PROP URL VALUE ------ " + PropUtils.getPropValue(configProp, url));

		driver.get(PropUtils.getPropValue(configProp, url));

		sleep(5);
		isDisplayedThenEnterText(userName, "IFCS login user name element", PropUtils.getPropValue(configProp, uname));
		isDisplayedThenEnterText(password, "IFCS login Password element",  PropUtils.getPropValue(configProp, pwd));
		isDisplayedThenClick(loginButton, "Login Button");
		sleep(5);

		
	}
	
	
	public void searchAccount(String accountNum) {

		sleep(2);
		isDisplayedThenEnterText(search, "Search textbox", accountNum);
		sleep(2);
		try
		{
		List<WebElement> items = searchAutoComplete;
		for (int index = 0; index <= items.size() - 1; index++) {
			WebElement item = items.get(index);
               
			if (item.getText().contains(accountNum)) {
				sleep(2);
				item.click();
				sleep(2);
				logPass("account number is selected from search menu");
				break;
			}
		}
		} catch (Exception ex) {
			logFail(ex.getMessage());}
		
}

	public String getAccountNumber()
	{
		String accountNo=accountNumber.getText();
		return accountNo;
	}
	
	public String getBillingPlan()
	{
		String accountNo=billingPlan.getText();
		return accountNo;
	}
	
	

}
