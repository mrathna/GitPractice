using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using Common;
using Common.PageObjects;
using Common.ScenarioConfigurations;
using Common.Utility;

namespace EnCompass.Testing.Source.PageObjects.Organization.SecurityManager.Workflow 
{
	/// <summary>
	/// Auto-generated Page Model Class
	/// Navigation Paths: 
		/// [Organization Home]->Security->Workflow Hierarchy->History
		/// </summary>
	[PageModel(@"/securityManager/workflow/WorkflowHistory.aspx")]
	public partial class WorkflowHistory : EnCompassOrgPageModel 
	{
		public override string RelativeUrl => @"/securityManager/workflow/WorkflowHistory.aspx";
		public override string PageIdentifierXPath_Generated => @"//li[contains(@class, 'breadcrumb-item active')][text() = 'History']";

		#region Navigation
				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Create']")]
		private IWebElement _security_WorkflowHierarchy_History_Create { get; set; }
		public void NavigateTo_Security_WorkflowHierarchy_History_Create()
		{
			NavigateToMenuItem(_security_WorkflowHierarchy_History_Create);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Edit']")]
		private IWebElement _security_WorkflowHierarchy_History_Edit { get; set; }
		public void NavigateTo_Security_WorkflowHierarchy_History_Edit()
		{
			NavigateToMenuItem(_security_WorkflowHierarchy_History_Edit);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Assign Users']")]
		private IWebElement _security_WorkflowHierarchy_History_AssignUsers { get; set; }
		public void NavigateTo_Security_WorkflowHierarchy_History_AssignUsers()
		{
			NavigateToMenuItem(_security_WorkflowHierarchy_History_AssignUsers);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='History']")]
		private IWebElement _security_WorkflowHierarchy_History_History { get; set; }
		public void NavigateTo_Security_WorkflowHierarchy_History_History()
		{
			NavigateToMenuItem(_security_WorkflowHierarchy_History_History);
		}

		
		private void NavigateToMenuItem(IWebElement element)
		{
			Driver.Url = element.GetAttribute("href");
		}
		#endregion

		public WorkflowHistory(GlobalSettings settings) : base(settings) { }
	}  
}
