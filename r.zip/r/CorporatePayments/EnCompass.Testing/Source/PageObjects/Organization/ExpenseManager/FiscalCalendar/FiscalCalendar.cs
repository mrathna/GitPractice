﻿using Common;
using Common.Utility;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NFluent;

namespace EnCompass.Testing.Source.PageObjects.Organization.ExpenseManager.FiscalCalendar

{   
    public partial class FiscalCalendar   
    {
        public override string PageIdentifierXPath_Override => @"//li[@class='breadcrumb-item active'][text() = 'Fiscal Calendar']";

        #region XPath page Elements
        private const string _datePeriodDropdownXpath = @"//select[contains(@id, 'lstDateRangePeriods')]";
        private const string _startDateTextBoxXpath = @"//input[contains(@id, 'txtStartDate')]";
        private const string _endDateTextBoxXpath = @"//input[contains(@id, 'txtEndDate')]";
        private const string _addDateRangesXpath = @"//input[contains(@id, 'btnModifyDateRanges')]";
        private const string _saveBtnXpath = @"//input[contains(@id, 'btnSave')]";
        private const string _cancelBtnXpath = @"//input[contains(@id, 'btnCancel')]";
        private const string _deleteBtnXpath = @"//input[contains(@id, 'cbtnFormDelete')]";
        #endregion

        #region Page Elements
        private IWebElement _datePeriodDropdown
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_datePeriodDropdownXpath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_datePeriodDropdown element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _startDateTextBox
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_startDateTextBoxXpath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_startDateTextBox element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _endDateTextBox
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_endDateTextBoxXpath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_endDateTextBox element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _addDateRanges
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_addDateRangesXpath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_addDateRanges element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _saveBtn
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_saveBtnXpath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_saveBtn element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _cancelBtn
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_cancelBtnXpath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_cancelBtn element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _deleteBtn
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_deleteBtnXpath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_deleteBtn element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        #endregion

        public string SelectDatePeriod
        {
            get
            {
                return new SelectElement(_datePeriodDropdown).SelectedOption.Text;
            }
            set
            {
                new SelectElement(_datePeriodDropdown).SelectByText(value);
            }
        }

        public string StartDate
        {
            get { return _startDateTextBox.GetAttribute("value"); }
            set
            {
                _startDateTextBox.Clear();
                _startDateTextBox.SendKeys(value);
            }
        }

        public string EndDate
        {
            get { return _endDateTextBox.GetAttribute("value"); }
            set
            {
                _endDateTextBox.Clear();
                _endDateTextBox.SendKeys(value);
            }
        }

        public void AddDateRange()
        {
            _addDateRanges.JSClickWithFocus(Driver);
        }

        public void Save()
        {
            _saveBtn.JSClickWithFocus(Driver);
			this.AttachOnDemandScreenShot();
		}

    }
}
