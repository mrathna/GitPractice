package com.framework.testcases.BusinessFlow;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;


import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.ApplicationsPage;
import com.framework.pages.AJS.CardMaintenancePage;
import com.framework.pages.AJS.ChangeCardStatus;
import com.framework.pages.AJS.MaintainAccountPage;
import com.framework.pages.AJS.MaintainCustomerPage;
import com.framework.pages.AJS.OrderCardPage;
import com.framework.pages.AJS.SearchPage;
import com.framework.pages.AJS.common.Common;
import com.framework.pages.AJS.common.IFCSCommonPage;
import com.framework.pages.AJS.common.IFCSHomePage;
import com.framework.pages.AJS.common.IFCSLoginPage;
import com.framework.pages.AJS.common.InterfacePage;
import com.framework.pages.AJS.common.SalesForceLoginPage;
import com.framework.pages.BusinessFlow.WFECommon;

import com.framework.util.PropUtils;
import com.github.javafaker.Faker;

public class ValidateMaintainCustomerBusinessFlows4 extends BaseTest {

	/**
	 * Implemented by Venkata Davu
	 * 
	 * @param clientCountry
	 * @param clientName    Business Flow ID:BF-014
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "BusinessFlow" })
	public void validateMaintainCustomerDeleteContacts(@Optional("NL") String clientCountry,
			@Optional("WFE") String clientName) {
		test = extent.createTest(clientName + ":" + clientCountry + "RQ-785 - TC-702 TC05_CustMgmt_CustMaint_SecContInfo_Delete",
				"Delete Contact");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		MaintainCustomerPage maintainCustomerPage = new MaintainCustomerPage(driver, test);
		Common common = new Common(driver, test);
		IFCSloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, " ");

		// IFCSHomePage.gotoApplicationAndClickApplicationMenu();
		// IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" +
		// clientCountry);

		String customerNo = common.getCustomerWithContactType(clientName + "_" + clientCountry);

		IFCSloginPage.logInfo("Customer number from DB" + customerNo);

		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		common.chooseCustomerNoAndSearch(customerNo);
		maintainCustomerPage.validateDeleteContact();

		IFCSHomePage.exitIFCS();
	}

	/**
	 * Added by Nithya
	 * 
	 * @param clientCountry
	 * @param clientName  RQ-839  
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "BusinessFlow" })
	public void cardMaintenanceUpdateCardControlProfile(@Optional("AU") String clientCountry,
			@Optional("BP") String clientName) {
		test = extent.createTest(
				clientName + ":" + clientCountry + " TC-773 TC01_CardMgmt_Update existing card limit",
				"RQ-839 Card control profiles (limit clusters)is updated for a existing customer based on customer request");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		Common common = new Common(driver, test);
		CardMaintenancePage cardMaintenancePage = new CardMaintenancePage(driver, test);
		MaintainCustomerPage customerPage = new MaintainCustomerPage(driver, test);
		String cardNumber;

		IFCSloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");

		/*
		 * if (clientCountry.equals("RU")) { cardNumber =
		 * common.getVehicleCardNumberFromDB(clientName + clientCountry); } else {
		 */
		cardNumber = common.getDriverCardNumberFromDB(clientName + clientCountry);
		// }

		if (cardNumber.equals(" ")) {
			common.logForNoDataFound(this.getClass().getSimpleName(),
					"Need to Create A Customer with Card Type and rerun");
		} else {
			IFCSHomePage.gotoCustomerMenuCustomerDetails();
			cardMaintenancePage.updateCardMaintenanceCardControlProfile(cardNumber);
			customerPage.enterDetailsInCardControlsPopUp(clientName + clientCountry);

		}

		IFCSHomePage.exitIFCS();
	}

	/**
	 * Added by Nithya
	 * 
	 * @param clientCountry
	 * @param clientName    Business Flow ID:RQ-806,RQ-807,RQ-808,RQ-809
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "BusinessFlow" })
	public void verifyAccountDetailsForCustomer(@Optional("AU") String clientCountry,
			@Optional("BP") String clientName) {
		test = extent.createTest(
				clientName + ":" + clientCountry + "RQ-806,RQ-807,RQ-808,RQ-809 Update Account Details",
				"Customer wanted to update a credit plan from salesforce\r\n"
						+ "Customer billing plan is updated for existing customer from salesforce\r\n"
						+ "Customer billing frequency is updated for exisitng customer from salesforce\r\n"
						+ "Customer account cycle is updated for exisitng customer from salesforce\r\n" + "");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCShomePage = new IFCSHomePage(driver, test);
		ApplicationsPage ifcsApplicationsPage = new ApplicationsPage(driver, test);
		MaintainAccountPage maintainAccountPage = new MaintainAccountPage(driver, test);
		Common common = new Common(driver, test);
		IFCSloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, " ");
		IFCShomePage.gotoApplicationAndClickApplicationMenu();
		IFCShomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);
		if (clientName.contains("WFE")) {
			ifcsApplicationsPage.applicationFilterOptions(clientCountry + " Go Cards", "Approved");
		} else {
			ifcsApplicationsPage.applicationFilterOptions("", "Approved");
		}
		common.selectFirstRowNumberInSearchList();
		IFCShomePage.gotoAccountAndClickAccountDetails();
		maintainAccountPage.editAndSaveCustomerAccountDetailsAndValidate();
		maintainAccountPage.editAndSaveCustomerBillingFrequency("Invoice Bi-Weekly");
		maintainAccountPage.editAndSaveCustomerBillingFrequency("Invoice Monthly");
		maintainAccountPage.editAndSaveCustomerBillingFrequency("Invoice Daily");
		IFCShomePage.exitIFCS();
	}

	/**
	 * Implemented by Raxsana Babu
	 * 
	 * @param clientCountry
	 * @param clientName    RQ-763
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow" })
	public void declineApplication(@Optional("BE") String clientCountry, @Optional("WFE") String clientName) {

		test = extent.createTest(clientName + ":" + clientCountry + " TC-696 TC01_CustMgmt_CustOnbd_App_Decline ",
				"RQ-763 A new customer application is Declined");
		// creating object for the Pages
		IFCSLoginPage ifcsloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage ifcsHomePage = new IFCSHomePage(driver, test);
		ApplicationsPage ifcsApplicationsPage = new ApplicationsPage(driver, test);
		Common common = new Common(driver, test);
		WFECommon wfeCommon = new WFECommon(driver, test);

		ifcsloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		ifcsloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");

		ifcsHomePage.gotoApplicationAndClickApplicationMenu();
		ifcsloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		// Selecting client from Application Menu
		ifcsHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);

		if (clientName.contains("WFE")) {
			ifcsApplicationsPage.applicationFilterOptions(clientCountry + " Go Cards", "Approved");
		} else {
			ifcsApplicationsPage.applicationFilterOptions("", "Approved");
		}
		//common.selectFirstRowNumberInSearchList();

		ifcsApplicationsPage.clearExistingFormAndCreateNewApplicationWithMandatoryField("0");
		wfeCommon.validateApplicationDecline();

		ifcsHomePage.exitIFCS();
	}

	/**
	 * Added by Raxsana Babu
	 * 
	 * @param clientCountry
	 * @param clientName
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow" })
	public void validateManualAccountTempBlock(@Optional("BE") String clientCountry,
			@Optional("WFE") String clientName) {
		test = extent.createTest(clientName + ":" + clientCountry + "RQ-810 - TC-736 TC01_AcctMgmt_Actstatus_Active to Temporary Locked",
				"Change the Active Account to Temp Lock");
		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCShomePage = new IFCSHomePage(driver, test);
		Common common = new Common(driver, test);
		ChangeCardStatus changeCardStatus = new ChangeCardStatus(driver, test);
		IFCSCommonPage ifcsCommonPage = new IFCSCommonPage(driver, test);
		InterfacePage interfacePage = new InterfacePage(driver, test);
		// Calling Functions

		IFCSloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, " ");
		String customerNumber = common.getActiveOrTemporaryBlockCustomerNoHavingCardsAndRowIndex(1, "Active");
		IFCShomePage.gotoCustomerMenuCustomerDetails();
		common.chooseCustomerNoAndSearch(customerNumber);
		IFCShomePage.gotoAccountAndClickAccountDetails();

		// Change CustomerAccount Status
		changeCardStatus.changeCustomerAccountStatus("Temp Blocked");
		/*String folderName = ifcsCommonPage.getControlMFolder(clientName, clientCountry, "job_wfe_CustUpdates");
		IFCSloginPage.logInfo("folderName order::" + folderName);
		String jobsInOrder = ifcsCommonPage.getJobsOfFolderInOrder("job_wfe_CustUpdates");
		IFCSloginPage.logInfo("jobsin order::" + jobsInOrder);

		// Executing control-m jobs
		interfacePage.establishAndExecuteControlMJobs("ControlM_AWS_UAT", "ContorlM_AWS_userName",
				"ContorlM_AWS_password", folderName, jobsInOrder);
		String jobsInOrder1 = ifcsCommonPage.getJobsOfFolderInOrder("job_wfe_CardChanges");
		IFCSloginPage.logInfo("jobsin order::" + jobsInOrder);

		// Executing control-m jobs
		interfacePage.establishAndExecuteControlMJobs("ControlM_AWS_UAT", "ContorlM_AWS_userName",
				"ContorlM_AWS_password", folderName, jobsInOrder1);
		IFCShomePage.gotoCustomerMenuCustomerDetails();
		changeCardStatus.validateCustomerHasCards();
		changeCardStatus.validateTemporaryLockStatusInCards("Temporary Blocked");*/
		common.updatePropFile("Account_ActiveToTemp" + clientName + "_" + clientCountry, customerNumber,
				"EmbossIdemiaValidation.properties");
		IFCShomePage.exitIFCS();

	}

	/**
	 * Implemented by Raxsana Babu
	 * 
	 * @param clientCountry
	 * @param clientName    Business Flow ID:BF-089
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow" })
	public void validateCustomerClosing(@Optional("BE") String clientCountry, @Optional("WFE") String clientName) {
		test = extent.createTest(clientName + ":" + clientCountry + " RQ-810  - TC-737 TC02_AcctMgmt_Actstatus_Active to Permanent Locked  Closed",
				"Change the Active Account to Closed");
		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCShomePage = new IFCSHomePage(driver, test);
		Common common = new Common(driver, test);
		ChangeCardStatus changeCardStatus = new ChangeCardStatus(driver, test);
		IFCSCommonPage ifcsCommonPage = new IFCSCommonPage(driver, test);
		InterfacePage interfacePage = new InterfacePage(driver, test);

		IFCSloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, " ");
		String customerNumber = common.getActiveOrTemporaryBlockCustomerNoHavingCardsAndRowIndex(1, "Active");
		IFCShomePage.gotoCustomerMenuCustomerDetails();
		common.chooseCustomerNoAndSearch(customerNumber);
		IFCShomePage.gotoAccountAndClickAccountDetails();

		// Change CustomerAccount Status
		changeCardStatus.changeCustomerAccountStatus("Closed");
		/*String folderName = ifcsCommonPage.getControlMFolder(clientName, clientCountry, "job_wfe_CustUpdates");
		IFCSloginPage.logInfo("folderName order::" + folderName);
		String jobsInOrder = ifcsCommonPage.getJobsOfFolderInOrder("job_wfe_CustUpdates");
		IFCSloginPage.logInfo("jobsin order::" + jobsInOrder);

		// Executing control-m jobs
		interfacePage.establishAndExecuteControlMJobs("ControlM_AWS_UAT", "ContorlM_AWS_userName",
				"ContorlM_AWS_password", folderName, jobsInOrder);
		String jobsInOrder1 = ifcsCommonPage.getJobsOfFolderInOrder("job_wfe_CardChanges");
		IFCSloginPage.logInfo("jobsin order::" + jobsInOrder);

		// Executing control-m jobs
		interfacePage.establishAndExecuteControlMJobs("ControlM_AWS_UAT", "ContorlM_AWS_userName",
				"ContorlM_AWS_password", folderName, jobsInOrder1);
		IFCShomePage.gotoCustomerMenuCustomerDetails();
		changeCardStatus.validateCustomerHasCards();
		changeCardStatus.validateTemporaryLockStatusInCards("Closed");*/
		common.updatePropFile("Account_ActiveToClosed" + clientName + "_" + clientCountry, customerNumber,
				"EmbossIdemiaValidation.properties");
		IFCShomePage.exitIFCS();
	}

	/**
	 * Added by Nithya
	 * 
	 * @param clientCountry
	 * @param clientName    Business Flow ID:BF-087
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow" })
	public void validateCustomerActivation(@Optional("BE") String clientCountry, @Optional("WFE") String clientName) {
		test = extent.createTest(clientName + ":" + clientCountry + " RQ-811 - TC-709 TC03_AcctMgmt_Actstatus_Temporary Locked to Active, RQ-847 TC-1356 TC02_CardMgmt_status_Upd_based on Acc Status",
				"Change the Temp Lock Account to Active");
		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCShomePage = new IFCSHomePage(driver, test);
		Common common = new Common(driver, test);
		ChangeCardStatus changeCardStatus = new ChangeCardStatus(driver, test);
		IFCSCommonPage ifcsCommonPage = new IFCSCommonPage(driver, test);
		InterfacePage interfacePage = new InterfacePage(driver, test);

		IFCSloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, " ");
		String customerNumber = common.getActiveOrTemporaryBlockCustomerNoHavingCardsAndRowIndex(1, "Temp Blocked");
		IFCShomePage.gotoCustomerMenuCustomerDetails();
		common.chooseCustomerNoAndSearch(customerNumber);
		IFCShomePage.gotoAccountAndClickAccountDetails();

		// Change CustomerAccount Status
		changeCardStatus.changeCustomerAccountStatus("Active");
		/*String folderName = ifcsCommonPage.getControlMFolder(clientName, clientCountry, "job_wfe_CustUpdates");
		IFCSloginPage.logInfo("folderName order::" + folderName);
		String jobsInOrder = ifcsCommonPage.getJobsOfFolderInOrder("job_wfe_CustUpdates");
		IFCSloginPage.logInfo("jobsin order::" + jobsInOrder);

		// Executing control-m jobs
		interfacePage.establishAndExecuteControlMJobs("ControlM_AWS_UAT", "ContorlM_AWS_userName",
				"ContorlM_AWS_password", folderName, jobsInOrder);
		String jobsInOrder1 = ifcsCommonPage.getJobsOfFolderInOrder("job_wfe_CardChanges");
		IFCSloginPage.logInfo("jobsin order::" + jobsInOrder);

		// Executing control-m jobs
		interfacePage.establishAndExecuteControlMJobs("ControlM_AWS_UAT", "ContorlM_AWS_userName",
				"ContorlM_AWS_password", folderName, jobsInOrder1);
		IFCShomePage.gotoCustomerMenuCustomerDetails();
		changeCardStatus.validateCustomerHasCards();
		changeCardStatus.validateTemporaryLockStatusInCards("Normal Service");*/
		common.updatePropFile("Account_TempToActive" + clientName + "_" + clientCountry, customerNumber,
				"EmbossIdemiaValidation.properties");
		IFCShomePage.exitIFCS();
	}

	/**
	 * Added by Raxsana Babu
	 * 
	 * @param clientCountry
	 * @param clientName   
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow" })
	public void validateCustomerActivationFromClosedToActive(@Optional("BE") String clientCountry, @Optional("WFE") String clientName) {
		test = extent.createTest(clientName + ":" + clientCountry + " RQ-811 -  TC-710 TC04_AcctMgmt_Actstatus_Permanent Locked  Closed to Active",
				"Change the Closed to Active");
		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCShomePage = new IFCSHomePage(driver, test);
		Common common = new Common(driver, test);
		ChangeCardStatus changeCardStatus = new ChangeCardStatus(driver, test);
		IFCSCommonPage ifcsCommonPage = new IFCSCommonPage(driver, test);
		InterfacePage interfacePage = new InterfacePage(driver, test);

		IFCSloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, " ");
		String customerNumber = common.getActiveOrTemporaryBlockCustomerNoHavingCardsAndRowIndex(1, "Closed");
		IFCShomePage.gotoCustomerMenuCustomerDetails();
		common.chooseCustomerNoAndSearch(customerNumber);
		IFCShomePage.gotoAccountAndClickAccountDetails();

		// Change CustomerAccount Status
		changeCardStatus.changeCustomerAccountStatus("Active");
		/*String folderName = ifcsCommonPage.getControlMFolder(clientName, clientCountry, "job_wfe_CustUpdates");
		IFCSloginPage.logInfo("folderName order::" + folderName);
		String jobsInOrder = ifcsCommonPage.getJobsOfFolderInOrder("job_wfe_CustUpdates");
		IFCSloginPage.logInfo("jobsin order::" + jobsInOrder);

		// Executing control-m jobs
		interfacePage.establishAndExecuteControlMJobs("ControlM_AWS_UAT", "ContorlM_AWS_userName",
				"ContorlM_AWS_password", folderName, jobsInOrder);
		String jobsInOrder1 = ifcsCommonPage.getJobsOfFolderInOrder("job_wfe_CardChanges");
		IFCSloginPage.logInfo("jobsin order::" + jobsInOrder);

		// Executing control-m jobs
		interfacePage.establishAndExecuteControlMJobs("ControlM_AWS_UAT", "ContorlM_AWS_userName",
				"ContorlM_AWS_password", folderName, jobsInOrder1);
		IFCShomePage.gotoCustomerMenuCustomerDetails();
		changeCardStatus.validateCustomerHasCards();
		changeCardStatus.validateTemporaryLockStatusInCards("Normal Service");*/
		common.updatePropFile("Account_ClosedToActive" + clientName + "_" + clientCountry, customerNumber,
				"EmbossIdemiaValidation.properties");
		IFCShomePage.exitIFCS();
	}
	/**
	 * Implemented by Raxsana Babu
	 * 
	 * @param clientCountry
	 * @param clientName    RQ-775,RQ-776
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow" })
	public void validateSearchCustomer(@Optional("NZ") String clientCountry, @Optional("BP") String clientName) {
		test = extent.createTest(
				clientName + ":" + clientCountry
						+ "RQ-775, RQ-776 - TC-757 TC01_CustMgmt_CustSrch,TC-758 TC02_CustMgmt_CustSrch_Cust Num",
				" Search Customer,Search by Customer number");
		// creating object for the Pages
		IFCSLoginPage ifcsloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage ifcsHomePage = new IFCSHomePage(driver, test);

		MaintainCustomerPage maintainCustomerPage = new MaintainCustomerPage(driver, test);
		Common common = new Common(driver, test);

		ifcsloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		ifcsHomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);
		ifcsloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, " ");
		ifcsHomePage.gotoCustomerMenuCustomerDetails();
		String customerNumber = common.getActiveCustomerNoUsingCardType();
		maintainCustomerPage.searchCustomerAndValidate(customerNumber);
		ifcsHomePage.exitIFCS();
	}

	/**
	 * Implemented by Karuppasamy
	 * 
	 * @param clientCountry
	 * @param clientName    RQ-895
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow" })
	public void createASundryCreditAdjustment(@Optional("HK") String clientCountry,
			@Optional("CHEVRON") String clientName) {
		test = extent.createTest(
				clientName + ":" + clientCountry + " TC-1701 TC04_TxnMgmt_SunAdj_Acc_Bal CreditAdj",
				"RQ-895 Sundry Credit Adjustment");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		Common common = new Common(driver, test);
		MaintainAccountPage maintainAccountPage = new MaintainAccountPage(driver, test);
		IFCSloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		IFCSHomePage.gotoAccountAndClickAccountDetails();
		String clientNameInProp = PropUtils.getPropValue(configProp, clientName + "_" + clientCountry);
		String customerNo = common.getCustomerNoHasTransaction(clientNameInProp);
		if (customerNo.equals("")) {

			common.logForNoDataFound(this.getClass().getSimpleName(),
					"Need to Create A Customer with Card Type and rerun");
		} else {
			IFCSHomePage.gotoAccountAndClickAccountDetails();
			common.chooseCustomerNoAndSearch(customerNo);
			String ActBal = common.getValueFromProtectedTextBox("Account Status", "Actual Balance");
			String AvaiBal = common.getValueFromProtectedTextBox("Account Status", "Available Balance");
			common.logInfo("Actual Balance before Sundry" + ActBal);
			common.logInfo("Available Balance before Sundry" + AvaiBal);
			String currentIFCSDateforEffAt = common.getCurrentIFCSDateFromDB(clientName + clientCountry);
			String effDate = common.enterADateValueInStatusBeginDateField("Current", currentIFCSDateforEffAt);

			maintainAccountPage.validateSundryAdjustmentWFE(customerNo, effDate, "Account Credit", "Bad Debt WriteOff");

			maintainAccountPage.validateActualAndAvailableBalanceForCredit(ActBal, AvaiBal);
			/*
			 * IFCSHomePage.gotoAccountAndClickAccountDetails(); String ActBalAft =
			 * common.getValueFromProtectedTextBox("Account Status", "Actual Balance");
			 * String AvaiBalAft = common.getValueFromProtectedTextBox("Account Status",
			 * "Available Balance"); common.logInfo("Actual Balance After Sundry" +
			 * ActBalAft); common.logInfo("Available Balance After Sundry" + AvaiBalAft);
			 * double actbalance = Double.parseDouble(ActBal) -
			 * Double.parseDouble(ActBalAft); double avaibalance =
			 * Double.parseDouble(AvaiBalAft) - Double.parseDouble(AvaiBal);
			 * common.logInfo("actbalnce" + actbalance); common.logInfo("avaibalnce" +
			 * actbalance); if ((actbalance == 10.0) && (avaibalance == 10.0)) {
			 * common.logPass("Credit Sundry Adjusment successfully posted"); } else {
			 * common.logFail("Credit Sundry Adjusment NOT successfully posted"); }
			 */
		}
		IFCSHomePage.exitIFCS();
	}

	/**
	 * Implemented by Karuppasamy
	 * 
	 * @param clientCountry
	 * @param clientName    RQ-895
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow" })
	public void createASundryDebitAdjustment(@Optional("HK") String clientCountry,
			@Optional("CHEVRON") String clientName) {
		test = extent.createTest(
				clientName + ":" + clientCountry + " TC03_TxnMgmt_SunAdj_Acc_Bal DebitAdj",
				"RQ-895 Sundry Debit Adjustment");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		Common common = new Common(driver, test);
		MaintainAccountPage maintainAccountPage = new MaintainAccountPage(driver, test);
		IFCSloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		IFCSHomePage.gotoAccountAndClickAccountDetails();
		String clientNameInProp = PropUtils.getPropValue(configProp, clientName + "_" + clientCountry);
		String customerNo = common.getCustomerNoHasTransaction(clientNameInProp);
		if (customerNo.equals("")) {

			common.logForNoDataFound(this.getClass().getSimpleName(),
					"Need to Create A Customer with Card Type and rerun");
		} else {

			IFCSHomePage.gotoAccountAndClickAccountDetails();
			common.chooseCustomerNoAndSearch(customerNo);
			// common.chooseCardNoAndSearch("RUA0000019");
			String ActBal = common.getValueFromProtectedTextBox("Account Status", "Actual Balance");
			String AvaiBal = common.getValueFromProtectedTextBox("Account Status", "Available Balance");
			common.logInfo("Actual Balance before Sundry" + ActBal);
			common.logInfo("Available Balance before Sundry" + AvaiBal);
			String currentIFCSDateforEffAt = common.getCurrentIFCSDateFromDB(clientName + clientCountry);
			String effDate = common.enterADateValueInStatusBeginDateField("Current", currentIFCSDateforEffAt);

			maintainAccountPage.validateSundryAdjustmentWFE(customerNo, effDate, "Account Debit", "Bad Debt WriteOff");
			maintainAccountPage.validateActualAndAvailableBalanceForDebit(ActBal, AvaiBal);
			/*IFCSHomePage.gotoAccountAndClickAccountDetails();
			String ActBalAft = common.getValueFromProtectedTextBox("Account Status", "Actual Balance");
			String AvaiBalAft = common.getValueFromProtectedTextBox("Account Status", "Available Balance");
			common.logInfo("Actual Balance After Sundry" + ActBalAft);
			common.logInfo("Available Balance After Sundry" + AvaiBalAft);
			double actbalance = Double.parseDouble(ActBalAft) - Double.parseDouble(ActBal);
			double avaibalance = Double.parseDouble(AvaiBalAft) - Double.parseDouble(AvaiBal);
			common.logInfo("actbalnce" + actbalance);
			common.logInfo("avaibalnce" + actbalance);
			if ((actbalance == 10.0) && (avaibalance == 10.0)) {
				common.logPass("Debit Sundry Adjusment successfully posted");
			} else {
				common.logFail("Debit Sundry Adjusment NOT successfully posted");
			}*/
		}
		IFCSHomePage.exitIFCS();
	}

	/**
	 * Implemented by Venkata Davu
	 * 
	 * @param clientCountry
	 * @param clientName    Busienss Flow ID:BF-032
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow" })
	public void validateMaintainCustomerAddMoreThanOneContact(@Optional("NL") String clientCountry,
			@Optional("WFE") String clientName) {
		test = extent.createTest(
				clientName + ":" + clientCountry + "RQ-783 - TC-1727 TC03_CustMgmt_CustMaint_SecContactInfo_Add",
				"Add more than one Contact Type (Secondary Contact) under Contacts tab");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		MaintainCustomerPage maintainCustomerPage = new MaintainCustomerPage(driver, test);
		Common common = new Common(driver, test);
		IFCSloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, " ");

		IFCSHomePage.gotoApplicationAndClickApplicationMenu();
		IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);

		String customerNo = common.getCustomerWithOutContactType(clientName + "_" + clientCountry);

		System.out.println("Customer number from DB" + customerNo);

		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		// common.chooseCustomerNumberFromCustomerList();
		common.chooseCustomerNoAndSearch(customerNo);
		maintainCustomerPage.ValidateAddContacts();
		maintainCustomerPage.addContactType("Invoice Copy Address");//("Cards Address");

		maintainCustomerPage.ValidateAddContacts();
		maintainCustomerPage.addContactType("Renewal Address");//("Invoice Address");

		IFCSHomePage.exitIFCS();
	}

	/**
	 * Implemented by Venkata Davu
	 * 
	 * @param clientCountry
	 * @param clientName    Busienss Flow ID:BF-033
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow" })
	public void validateMaintainCustomerUpdateContact(@Optional("NL") String clientCountry,
			@Optional("WFE") String clientName) {
		test = extent.createTest(
				clientName + ":" + clientCountry + "RQ-784 - TC-701 TC04_CustMgmt_CustMaint_SecContactInfo_Update",
				"Update the Secondary Contact Information under Contacts tab");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		MaintainCustomerPage maintainCustomerPage = new MaintainCustomerPage(driver, test);
		Common common = new Common(driver, test);
		IFCSloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, " ");

		// IFCSHomePage.gotoApplicationAndClickApplicationMenu();
		// IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" +
		// clientCountry);

		String customerNo = common.getCustomerWithContactType(clientName + "_" + clientCountry);

		System.out.println("Customer number from DB" + customerNo);

		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		common.chooseCustomerNoAndSearch(customerNo);
		maintainCustomerPage.updateContact();

		IFCSHomePage.exitIFCS();
	}

	/**
	 * Implemented by Rathna
	 * 
	 * @param clientCountry
	 * @param clientName    Busienss Flow ID:BF-020
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "BusinessFlow" })
	public void validateOnboardCustomerApplicationStatusWhenSavedAndNotSumitted(@Optional("BE") String clientCountry,
			@Optional("WFE") String clientName) {

		test = extent.createTest(clientName + ":" + clientCountry + "RQ-765	- TC-763 TC03_ CustMgmt_CustOnbd_App_Not submitted",
				"Onboard a customer but never submit (Received but not validated - New Application)");
		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		ApplicationsPage IFCSApplicationsPage = new ApplicationsPage(driver, test);
		// Calling Functions
		IFCSloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");

		IFCSHomePage.gotoApplicationAndClickApplicationMenu();
		IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);
		IFCSApplicationsPage.searchRandomApplicationWithApprovedStatusAndClone();

		// Save application without submit
		IFCSApplicationsPage.applicationCloneRecordAndProvideDetails();
		IFCSHomePage.gotoApplicationAndClickApplicationMenu();
		IFCSApplicationsPage.validateApplicationStatus("Details", "Current Status", "New Application");
		IFCSHomePage.exitIFCS();

	}

	/**
	 * Implemented by Rathna
	 * 
	 * @param clientCountry
	 * @param clientName    Business Flow ID:BF-021
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "BusinessFlow" })
	public void ValidateOnboardCustomerApplicationStatusWhenSumittedAndNotApproved(@Optional("BE") String clientCountry,
			@Optional("WFE") String clientName) {

		test = extent.createTest(
				clientName + ":" + clientCountry + "RQ-766 - TC-1726 TC04_ CustMgmt_CustOnbbd_App_Validation Only",
				" Onboard a customer and validated (not approved-Pending status))");
		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		ApplicationsPage IFCSApplicationsPage = new ApplicationsPage(driver, test);

		// Calling Functions
		IFCSloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		IFCSHomePage.gotoApplicationAndClickApplicationMenu();
		IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);
		IFCSApplicationsPage.searchRandomApplicationWithApprovedStatusAndClone();
		IFCSApplicationsPage.applicationCloneRecordAndProvideDetails();
		IFCSApplicationsPage.createCardOffersInApplicationAndDontSave();
		IFCSApplicationsPage.addPricingInApplication();
		IFCSApplicationsPage.addCardReissueProfiles();
		IFCSApplicationsPage.validateApplicationForClonedRecord();

		IFCSHomePage.gotoApplicationAndClickApplicationMenu();
		IFCSApplicationsPage.validateApplicationStatus("Details", "Current Status", "Pending");
		IFCSHomePage.exitIFCS();

	}

	/**
	 * Implemented by Rathna
	 * 
	 * @param clientCountry
	 * @param clientName    Business Flow ID:BF-022
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "BusinessFlow" })
	public void ValidateOnboardCustomerApplicationWhenApprovedByCloningApplciationTemplate(
			@Optional("BE") String clientCountry, @Optional("WFE") String clientName) {

		test = extent.createTest(clientName + ":" + clientCountry + "RQ-764, RQ-767 - TC-762 TC02_CustMgmt_CustOnbd_App_Approved\r\n" + 
				"TC-764 TC05_CustMgmt_CustOnbd_Clone App Template",
				"A new customer application is won & approved, Onboard customer by cloning application template");
		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		ApplicationsPage IFCSApplicationsPage = new ApplicationsPage(driver, test);
		// Calling Functions
		IFCSloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		IFCSHomePage.gotoApplicationAndClickApplicationMenu();
		IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);
		IFCSApplicationsPage.searchRandomApplicationWithApprovedStatusAndClone();

		IFCSApplicationsPage.applicationCloneRecordAndProvideDetails();
		IFCSApplicationsPage.createCardOffersInApplicationAndDontSave();
		IFCSApplicationsPage.addPricingInApplication();
		IFCSApplicationsPage.addCardReissueProfiles();
		IFCSApplicationsPage.validateAndCreateApplicationForClonedRecord();

		IFCSHomePage.gotoApplicationAndClickApplicationMenu();
		IFCSApplicationsPage.validateApplicationStatus("Details", "Current Status", "Approved");
		IFCSHomePage.exitIFCS();

	}

	/**
	 * Implemented by Rathna
	 * 
	 * @param clientCountry
	 * @param clientName    Business Flow ID:BF-034
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "BusinessFlow" })
	public void createMoreThanOneCostCentreInIFCS(@Optional("BE") String clientCountry,
			@Optional("WFE") String clientName) {

		test = extent.createTest(
				clientName + ":" + clientCountry + "RQ-878 - TC-794 TC02_CustMgmt_CostCentre_CardDep_Add_more_CC",
				"Able to add more than one cost center");
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		MaintainCustomerPage maintainCustomerPage = new MaintainCustomerPage(driver, test);
		Common common = new Common(driver, test);

		IFCSloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");

		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");

		// getting Active Customer No from DB/
		String customerNumberUsingCardType = common.getActiveCustomerNoUsingCardType();
		if (customerNumberUsingCardType.equals(" ")) {
			common.logForNoDataFound(this.getClass().getSimpleName(),
					"Need to Create A Customer with Card Type and rerun");
		} else {

			for (int count = 1; count <= 2; count++) {
				IFCSHomePage.gotoCustomerMenuCustomerDetails();
				common.chooseCustomerNoAndSearch(customerNumberUsingCardType);
				maintainCustomerPage.chooseCostCentre();
				String costCenterCode = Faker.instance().number().digits(4);
				maintainCustomerPage.addCostCentreAndValidate(costCenterCode);
			}

		}
		IFCSHomePage.exitIFCS();

	}

	/**
	 * Implemented by Raxsana Babu
	 * 
	 * @param clientCountry
	 * @param clientName    RQ-777,RQ-778,RQ-779
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "BusinessFlow" })
	public void validateSearchByCustomerFilters(@Optional("BE") String clientCountry,
			@Optional("WFE") String clientName) {
		test = extent.createTest(clientName + ":" + clientCountry
				+ "RQ-777,RQ-778,RQ-779 - TC-761 TC05_CustMgmt_CustSrch_Cust_All filters,TC-759 TC03_CustMgmt_CustSrch_Cust by Marketing,TC-760 TC04_CustMgmt_CustSrch_CustName",
				" Search by Marketing & Admin Territory,\r\n" + " Search by Name,\r\n"
						+ " Search for a Customer with all other filter conditions");
		// creating object for the Pages
		IFCSLoginPage ifcsloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage ifcsHomePage = new IFCSHomePage(driver, test);
		MaintainCustomerPage maintainCustomerPage = new MaintainCustomerPage(driver, test);

		ifcsloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		ifcsHomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);
		ifcsloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, " ");
		ifcsHomePage.gotoCustomerMenuCustomerDetails();
		maintainCustomerPage.searchCustomerFiltersAndValidate();

		ifcsHomePage.exitIFCS();
	}

	/**
	 * Implemented by Raxsana Babu
	 * 
	 * @param clientCountry
	 * @param clientName    RQ-771
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "BusinessFlow" })
	public void validateApplicationExport(@Optional("BE") String clientCountry, @Optional("WFE") String clientName) {
		test = extent.createTest(clientName + ":" + clientCountry + "RQ-771 - TC-1736 TC09_CustMgmt_CustOnbd_GenRep_AppStatus",
				"Search application by 'Application Status' and generate the report in excel");
		// creating object for the Pages
		IFCSLoginPage ifcsloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage ifcsHomePage = new IFCSHomePage(driver, test);
		WFECommon wfeCommon = new WFECommon(driver, test);

		ifcsloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		ifcsHomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);
		ifcsloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, " ");
		ifcsHomePage.gotoApplicationAndClickApplicationMenu();
		wfeCommon.exportApplication("Application Type");
		ifcsHomePage.gotoApplicationAndClickApplicationMenu();
		wfeCommon.exportApplication("Status");
		ifcsHomePage.exitIFCS();
	}

	/**
	 * Implemented by Raxsana Babu
	 * 
	 * @param clientCountry
	 * @param clientName    RQ-768,RQ-770
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "BusinessFlow" })
	public void validateApplicationStatusFromPendingToApproved(@Optional("BE") String clientCountry,
			@Optional("WFE") String clientName) {
		test = extent.createTest(
				clientName + ":" + clientCountry + "RQ-768, RQ-770 - TC-765 TC06_CustMgmt_CustOnbd_CustSrch By AppType_Approve\r\n"
						+ ",TC-766 TC07_CustMgmt_CustOnbd_CUstSrch By Search AppStatus_Approve",
				" Search application by 'Application Type' and approve the 'Pending/New' Applicants,\r\n"
						+ "Search application by 'Application Status' and approve the 'Pending/New' Applicants");
		// creating object for the Pages
		IFCSLoginPage ifcsloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage ifcsHomePage = new IFCSHomePage(driver, test);
		WFECommon wfeCommon = new WFECommon(driver, test);

		ifcsloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		ifcsHomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);
		ifcsloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, " ");
		ifcsHomePage.gotoApplicationAndClickApplicationMenu();
		wfeCommon.applicationStatusChangeToApproved("Pending");
		ifcsHomePage.exitIFCS();
	}

	/**
	 * Implemented by Raxsana Babu
	 * 
	 * @param clientCountry
	 * @param clientName    RQ-772
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "BusinessFlow" })
	public void validateSearchByApplicationFilters(@Optional("BE") String clientCountry,
			@Optional("WFE") String clientName) {
		test = extent.createTest(
				clientName + ":" + clientCountry + "RQ-772 - TC-767 TC08_CustMgmt_CustOnbd_CustSrch By Marketing Territory",
				" Search application by 'Marketing Territory' and 'Admin Territory'");
		// creating object for the Pages
		IFCSLoginPage ifcsloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage ifcsHomePage = new IFCSHomePage(driver, test);
		ApplicationsPage applicationsPage = new ApplicationsPage(driver, test);

		ifcsloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		ifcsHomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);
		ifcsloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, " ");
		ifcsHomePage.gotoApplicationAndClickApplicationMenu();
		applicationsPage.searchApplicationFilters("Admin Territory");
		applicationsPage.searchApplicationFilters("Marketing Territory");

		ifcsHomePage.exitIFCS();
	}

	/**
	 * Implemented byRathna
	 * 
	 * @param clientCountry
	 * @param clientName    Business Flow ID:BF-100
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "BusinessFlow" })
	public void updateCustomerFromChequePaymentToSEPA_DD(@Optional("BE") String clientCountry,
			@Optional("WFE") String clientName) {
		test = extent.createTest(clientName + ":" + clientCountry + " ID:BF-100 Update Customer Payment-SEPA",
				"Able to update customer from Cheque Payment to SEPA DD along with bank details and UMR No");
		// creating object for the Pages
		IFCSLoginPage ifcsloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage ifcsHomePage = new IFCSHomePage(driver, test);
		SearchPage searchPage = new SearchPage(driver, test);
		Common common = new Common(driver, test);
		MaintainCustomerPage maintainCustomerPage = new MaintainCustomerPage(driver, test);

		ifcsloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		ifcsloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, " ");
		// Selecting client from Application Menu
		ifcsHomePage.gotoApplicationAndClickApplicationMenu();
		ifcsHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);
		ifcsHomePage.gotoCustomerMenuCustomerDetails();
		String customerNumber = common.getActiveCustomerNoUsingCardType();
		maintainCustomerPage.searchCustomerAndValidate(customerNumber);
		searchPage.SelectCustormerFromCustomerList();
		ifcsHomePage.gotoAccountAndClickAccountDetails();
		// Update Cheque Payment to SEPA-DD - 1DAYS
		maintainCustomerPage.updateCustomerFromChequePayToSEPA(clientName, clientCountry);

		ifcsHomePage.exitIFCS();
	}

	/**
	 * Added by Rathna
	 * 
	 * @param clientCountry
	 * @param clientName    Busienss Flow ID:BF-040
	 */
	/*
	 * need to add proper steps raxsana 
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "Regression" })
	public void validateCreatePrivateProfile_Rebate(@Optional("BE") String clientCountry,
			@Optional("WFE") String clientName) {

		test = extent.createTest(clientName + ":" + clientCountry + " RQ-794 - TC-748 TC02_CustMgmt_Reb_Create private rebate profile",
				"Able to create a private profile");

		// creating object for the Pages
		IFCSLoginPage ifcsloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage ifcsHomePage = new IFCSHomePage(driver, test);
		CardMaintenancePage cardMaintenancePage = new CardMaintenancePage(driver, test);
		MaintainCustomerPage maintainCustomerPage = new MaintainCustomerPage(driver, test);
		Common common = new Common(driver, test);

		ifcsloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		ifcsHomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);
		ifcsloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, " ");
		ifcsHomePage.gotoCustomerMenuCustomerDetails();
		String customerNumber = common.getActiveCustomerNoUsingCardType();
		cardMaintenancePage.chooseAndSearchCustomerNo(customerNumber);
		String currentDate = common.getCurrentIFCSDateFromDB(clientName + clientCountry);
		// Get the IFCS date ---new
		String effDate = common.enterADateValueInStatusBeginDateField("Current", currentDate);
		String expiryDate = common.enterADateValueInStatusBeginDateField("WayFuture", currentDate);
		System.out.println("Date ::" + effDate);

		// Parent with Periodic rebate ------new
		String rebateParentCusNo = common.getRebateParentCustomerNoInHierarchy();
		// maintainCustomerPage.createRebateProfile();
		maintainCustomerPage.wfeCreateRebateProfileWithRequiredRebateDetails(rebateParentCusNo, effDate, expiryDate);// this
																														// method
																														// added
		maintainCustomerPage.undoCheboxOptedOut(); //
		ifcsHomePage.exitIFCS();

	}

	/**
	 * Added by Rathna
	 * 
	 * @param clientCountry
	 * @param clientName    Busienss Flow ID:BF-016
	 */

	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "Regression" })
	public void validateAccountCreationInIFCSSyncedToSF(@Optional("BE") String clientCountry,
			@Optional("WFE") String clientName) {
		test = extent.createTest(clientName + ":" + clientCountry + " IFCS-validateAccountCreationInIFCSSyncedToSF",
				"IFCS-Validate account creation in IFCS");
		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCShomePage = new IFCSHomePage(driver, test);
		Common common = new Common(driver, test);
		ApplicationsPage ifcsApplicationsPage = new ApplicationsPage(driver, test);
		IFCSloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");

		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		IFCShomePage.gotoApplicationAndClickApplicationMenu();
		IFCShomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);

		ifcsApplicationsPage.searchRandomApplicationWithApprovedStatusAndClone();

		ifcsApplicationsPage.applicationCloneRecordAndProvideDetails();
		ifcsApplicationsPage.createCardOffersInApplicationAndDontSave();
		ifcsApplicationsPage.addPricingInApplication();
		ifcsApplicationsPage.addCardReissueProfiles();
		ifcsApplicationsPage.validateAndCreateApplicationForClonedRecord();

		IFCShomePage.gotoApplicationAndClickApplicationMenu();
		ifcsApplicationsPage.validateApplicationStatus("Details", "Current Status", "Approved");

		common.textFieldVal = common.getValueFromTextBox("Details", "Customer No");
		System.out.println(common.textFieldVal);

		IFCShomePage.gotoCustomerMenuCustomerDetails();
		ifcsApplicationsPage.validateCustomerNoInCustomerDetails(common.textFieldVal);

		IFCShomePage.exitIFCS();

	}

	/**
	 * Added by rathna
	 * 
	 * @param clientCountry
	 * @param clientName    Business Flow ID:BF-005, BF-006,BF-007,BF-008
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow" })
	public void validateUpdateAccountInIFCSSyncedToSF(@Optional("BE") String clientCountry,
			@Optional("WFE") String clientName) {
		test = extent.createTest(
				clientName + ":" + clientCountry + "ID:BF-005,BF-006, BF-007,BF-008  Update Account Details",
				"Customer wanted to update a credit plan from salesforce\r\n"
						+ "Customer billing plan is updated for existing customer from salesforce\r\n"
						+ "Customer billing frequency is updated for exisitng customer from salesforce\r\n"
						+ "Customer account cycle is updated for exisitng customer from salesforce\r\n" + "");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCShomePage = new IFCSHomePage(driver, test);
		ApplicationsPage ifcsApplicationsPage = new ApplicationsPage(driver, test);
		MaintainAccountPage maintainAccountPage = new MaintainAccountPage(driver, test);
		Common common = new Common(driver, test);
		IFCSloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, " ");
		IFCShomePage.gotoApplicationAndClickApplicationMenu();
		IFCShomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);
		if (clientName.contains("WFE")) {
			ifcsApplicationsPage.applicationFilterOptions(clientCountry + " Go Cards", "Approved");
		} else {
			ifcsApplicationsPage.applicationFilterOptions("", "Approved");
		}
		// common.selectFirstRowNumberInSearchList();
		IFCShomePage.gotoAccountAndClickAccountDetails();
		maintainAccountPage.editAndSaveCustomerAccountDetailsAndValidate();
		IFCShomePage.exitIFCS();
	}

	/**
	 * Added by rathna
	 * 
	 * @param clientCountry
	 * @param clientName    Business Flow ID:BF-005, BF-006,BF-007,BF-008
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "Regression" })
	public void validateUpdatedAccountDetailsInSalesForce(@Optional("BE") String clientCountry,
			@Optional("WFE") String clientName) {
		test = extent.createTest(clientName + ":" + clientCountry + " Web-validateAccountNumberinSalesForce",
				"Web-Validate updated account details in sales force");
		Common common = new Common(driver, test);
		MaintainAccountPage maintainAccountPage = new MaintainAccountPage(driver, test);
		common.textFieldVal = "3285691";
		SalesForceLoginPage loginPages = new SalesForceLoginPage(driver, test);
		loginPages.Login("SF_URL", "SF_UserName", "SF_Password");

		loginPages.searchAccount(common.textFieldVal);
		String actBillingPlan = loginPages.getBillingPlan();
		common.compareTwoValues(maintainAccountPage.ifcsVal, actBillingPlan);

	}


	/**
	 * Added by Nithya
	 * 
	 * @param clientCountry
	 * @param clientName    RQ-843
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "BusinessFlow" })
	public void updateCustomerCostCenter(@Optional("AU") String clientCountry, @Optional("BP") String clientName) {
		test = extent.createTest(clientName + ":" + clientCountry + " RQ-788 - TC-795 TC03_CustMgmt_CostCentre_ExtCard_Department_Upd",
				"A card department (cost centre) is changed for existing customer from salesforce");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		Common common = new Common(driver, test);
		CardMaintenancePage cardMaintenancePage = new CardMaintenancePage(driver, test);
		MaintainCustomerPage customerPage = new MaintainCustomerPage(driver, test);
		

		IFCSloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		String customerNumberUsingCardType = common.getActiveCustomerNoUsingCardType();
		if (customerNumberUsingCardType.equals(" ")) {
			common.logForNoDataFound(this.getClass().getSimpleName(),
					"Need to Create A Customer with Card Type and rerun");
		} else {

			IFCSHomePage.gotoCustomerMenuCustomerDetails();
			common.chooseCustomerNoAndSearch(customerNumberUsingCardType);
			customerPage.chooseCostCentre();
			String costCenterCode = Faker.instance().number().digits(4);
			customerPage.validateMandatoryMessageInCostCentrePopup(costCenterCode);
		}

		
		IFCSHomePage.exitIFCS();
	}
	//Duplicate
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow" })
	public void createPrivateCustomerPricingProfile(@Optional("BE") String clientCountry,
			@Optional("WFE") String clientName) {

		test = extent.createTest(
				clientName + ":" + clientCountry + " ID:BF-037  create a private customer pricing  profile",
				"Able to create a private customer pricing  profile");

		// creating object for the Pages
		IFCSLoginPage ifcsloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		MaintainCustomerPage maintainCustomerPage = new MaintainCustomerPage(driver, test);
		Common common = new Common(driver, test);
		// Calling Functions
		ifcsloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		ifcsloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, " ");
		IFCSHomePage.gotoApplicationAndClickApplicationMenu();
		IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);

		//String currentDate = common.getCurrentIFCSDateFromDB(clientName + clientCountry);
		//String ifcsCurrentDate = common.enterADateValueInStatusBeginDateField("Current", currentDate);

		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		String customerNumber = common.getActiveCustomerNoUsingCardType();
		common.chooseCustomerNoAndSearch(customerNumber);
		maintainCustomerPage.verifyCustomerPricingProfile();
		maintainCustomerPage.popupForPricingProfiles(clientName, clientCountry, "random");//"Lower of Pump & List");

	}

	/**
	 * Implemented by Rathna
	 * 
	 * @param clientCountry
	 * @param clientName    Busienss Flow ID:BF-020
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "BusinessFlow" })
	public void validateOnboardCustomeApplicationStatusWhenNotSubmittedButSaved(@Optional("BE") String clientCountry,
			@Optional("WFE") String clientName) {

		test = extent.createTest(clientName + ":" + clientCountry + "TC-763 TC03_ CustMgmt_CustOnbd_App_Not submitted",
				"RQ-765:Onboard a customer but never submit (Received but not validated - New Application)");
		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		ApplicationsPage IFCSApplicationsPage = new ApplicationsPage(driver, test);
		// Calling Functions
		IFCSloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");

		IFCSHomePage.gotoApplicationAndClickApplicationMenu();
		IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);
		IFCSApplicationsPage.searchRandomApplicationWithApprovedStatusAndClone();

		// Save application without submit
		IFCSApplicationsPage.applicationCloneRecordAndProvideDetails();
		IFCSHomePage.gotoApplicationAndClickApplicationMenu();
		IFCSApplicationsPage.validateApplicationStatus("Details", "Current Status", "New Application");
		IFCSHomePage.exitIFCS();

	}

	/**
	 * Implemented byRathna
	 * 
	 * @param clientCountry
	 * @param clientName    Business Flow ID:RQ-809
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "BusinessFlow" })
	public void updateCustomerFrequncyFromMonthlyToDialy(@Optional("BE") String clientCountry,
			@Optional("WFE") String clientName) {
		test = extent.createTest(
				clientName + ":" + clientCountry
						+ "TC-756 TC04_AcctMgmt_ActBill_Update the billing_account_frequency_Monthly to Daily",
				"RQ-809 : Customer account cycle is updated for exisitng customer");
		// creating object for the Pages
		IFCSLoginPage ifcsloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage ifcsHomePage = new IFCSHomePage(driver, test);
		SearchPage searchPage = new SearchPage(driver, test);
		Common common = new Common(driver, test);
		MaintainCustomerPage maintainCustomerPage = new MaintainCustomerPage(driver, test);

		ifcsloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		ifcsloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, " ");
		// Selecting client from Application Menu
		ifcsHomePage.gotoApplicationAndClickApplicationMenu();
		ifcsHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);
		ifcsHomePage.gotoCustomerMenuCustomerDetails();
		String customerNumber = common.getActiveCustomerNoUsingCardType();
		maintainCustomerPage.searchCustomerAndValidate(customerNumber);
		//searchPage.SelectCustormerFromCustomerList();
		common.selectFirstRowNumberInSearchList();
		ifcsHomePage.gotoAccountAndClickAccountDetails();
		// Update Cheque Payment to SEPA-DD - 1DAYS
		maintainCustomerPage.updateFrequencyToDaily();

		ifcsHomePage.exitIFCS();
	}

	/**
	 * Implemented by Nithya
	 * 
	 * @param clientCountry
	 * @param clientName    Business Flow ID:RQ-802
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "BusinessFlow" })
	public void validateCardControlPrivateProfile(@Optional("BE") String clientCountry,
			@Optional("WFE") String clientName) {

		test = extent.createTest(clientName + ":" + clientCountry + " RQ-802 - TC-884 TC01_CustMgmt_Create_Priv_Card_Vel_Cust",
				"Able to create private profile");
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCShomePage = new IFCSHomePage(driver, test);
		Common common = new Common(driver, test);
		IFCSloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		CardMaintenancePage cardMaintenancePage = new CardMaintenancePage(driver, test);
		MaintainCustomerPage customerPage = new MaintainCustomerPage(driver, test);
		OrderCardPage orderCardpage = new OrderCardPage(driver, test);
		// Serch Cutomer
		IFCShomePage.gotoApplicationAndClickApplicationMenu();
		IFCShomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);
		IFCShomePage.gotoCustomerMenuCustomerDetails();
		// WFE by default Private Profile is Created while creating card
		String cardNo = common.getDriverCardNumberFromDB(clientName + clientCountry);
		common.chooseCustomerNoAndSearch(common.getCustomerNoForCardNumber(cardNo));
		cardMaintenancePage.updateCardMaintenanceCardControlProfile(cardNo);
		customerPage.enterDetailsInCardControlsPopUp(clientName + clientCountry);

		/*
		 * String orderedCardNumber = orderCardpage.orderNewCardWithMonthlyFeeWFE();
		 * 
		 * IFCSloginPage.logPass("Newly ordered card:: :: " + orderedCardNumber);
		 */
		IFCShomePage.exitIFCS();
	}

}
