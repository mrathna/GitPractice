package com.framework.pages.WES.Velocity;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

import com.aventstack.extentreports.ExtentTest;
import com.framework.basepage.BasePage;
import com.framework.repo.Locator_WES;

public class VelocityHomePage extends BasePage {

	@FindBy(xpath = Locator_WES.MAINTENANCE_CALLSHEET)
	public WebElement maintenanceCallSheet;

	@FindBy(how = How.ID, using = Locator_WES.DISTRIBUTOR_ACCESS)
	public WebElement distributorAccess;

	@FindBy(how = How.ID, using = Locator_WES.CUSTOMER_SERVICE_ACCESS)
	public WebElement adminAccess;

	@FindBy(how = How.ID, using = Locator_WES.CUSTOMER_SEARCH_BOX)
	public WebElement customerSearch;

	@FindBy(how = How.CSS, using = Locator_WES.CUTOMER_NAME_HEADER)
	public WebElement customerDetails;

	@FindBy(how = How.CSS, using = Locator_WES.ACCEPT_COOKIE)
	public WebElement acceptCookie;

	@FindBy(how = How.CSS, using = Locator_WES.EXCHANGE_BTN)
	public WebElement exchangeBtn;

	public VelocityHomePage(WebDriver driver, ExtentTest test) {
		super(driver, test);
		PageFactory.initElements(new AjaxElementLocatorFactory(driver, 15), this);
	}

	public void clickingAndValidatingSpecificAccessType(String accessType) {
		verifyTitle("Select view for the site");
		acceptingCookieIfPresents();
		if (accessType.equals("Distributor")) {
			isDisplayedThenActionClick(distributorAccess, "Distributor Access");
			verifyTitle("Please select a customer");
		} else {
			isDisplayedThenActionClick(adminAccess, "Admin Access");
			verifyTitle("Please select a customer");
		}
	}

	public void acceptingCookieIfPresents() {
		sleep(2);
		if (waitToCheckElementIsDisplayed(By.cssSelector("a[class*='cookieAccept']"), 30)) {
			isDisplayedThenActionClick(acceptCookie, "acceptCookie");
		} else {
			logInfo("Cookie is already accepted");
		}

	}

	public void acceptingCookie() {
		isDisplayedThenActionClick(acceptCookie, "acceptCookie");
	}

	public void clickingExchangeBtn() {
		isDisplayedThenActionClick(exchangeBtn, "exchangeBtn");
	}

	public void searchingAndValidatingCustomer(String customerNo) {
		isDisplayedThenEnterText(customerSearch, "searching specific customer", customerNo);
		WebElement customerDetail = driver.findElement(By.xpath("//a[contains(text(),'" + customerNo + "')]"));
		isDisplayedThenActionClick(customerDetail, "Customer Details");
		sleep(10);
		takeScreenshot();
		sleep(2);
		if (customerDetails.getAttribute("title").contains(customerNo)) {
			verifyTitle(customerDetails.getAttribute("title"));
		} else
			logFail("Customer number not associated with velocity and Redirecting to wrong page");

	}
}
