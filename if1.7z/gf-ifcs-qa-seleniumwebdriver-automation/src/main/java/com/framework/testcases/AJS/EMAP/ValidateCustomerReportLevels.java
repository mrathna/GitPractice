package com.framework.testcases.AJS.EMAP;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.common.IFCSHomePage;
import com.framework.pages.AJS.common.IFCSLoginPage;

public class ValidateCustomerReportLevels extends BaseTest{
	
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "Regression" })
	public void validateCustomerLevelReports(@Optional("SG") String clientCountry,
			@Optional("EMAP") String clientName) {
		
		test = extent.createTest(clientName+ ":" +clientCountry+"  03 Maintain Customer Report Levels", "03 Maintain Customer Report Levels");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCShomePage = new IFCSHomePage(driver, test);
		IFCSloginPage.login("IFCS_URL_EMAP", "IFCS_EMAP_USERNAME", "IFCS_EMAP_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		IFCShomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);
		
		//Steps In Progress - Due to DB restoring 
		
		IFCShomePage.exitIFCS();
	}
	
}
