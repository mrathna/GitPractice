using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using Common;
using Common.PageObjects;
using Common.ScenarioConfigurations;
using Common.Utility;

namespace EnCompass.Testing.Source.PageObjects.Organization.ExpenseManager.PurchaseLog.Testing 
{
	/// <summary>
	/// Auto-generated Page Model Class
	/// Navigation Paths: 
		/// [Organization Home]->Payables->Purchase Log->Create Single-Use Accounts
		/// [Organization Home]->Payables->Accounts Payable->Create Single-Use Accounts
		/// </summary>
	[PageModel(@"/expenseManager/PurchaseLog/Testing/CreateTestAccounts.aspx")]
	public partial class CreateTestAccounts : EnCompassOrgPageModel 
	{
		public override string RelativeUrl => @"/expenseManager/PurchaseLog/Testing/CreateTestAccounts.aspx";
		public override string PageIdentifierXPath_Generated => @"//li[contains(@class, 'breadcrumb-item active')][text() = 'Single-Use Accounts']";

		#region Navigation
				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Purchase Logs']")]
		private IWebElement _payables_PurchaseLog_CreateSingleUseAccounts_PurchaseLogs { get; set; }
		public void NavigateTo_Payables_PurchaseLog_CreateSingleUseAccounts_PurchaseLogs()
		{
			NavigateToMenuItem(_payables_PurchaseLog_CreateSingleUseAccounts_PurchaseLogs);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Create Purchase Log']")]
		private IWebElement _payables_PurchaseLog_CreateSingleUseAccounts_CreatePurchaseLog { get; set; }
		public void NavigateTo_Payables_PurchaseLog_CreateSingleUseAccounts_CreatePurchaseLog()
		{
			NavigateToMenuItem(_payables_PurchaseLog_CreateSingleUseAccounts_CreatePurchaseLog);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Purchase Log Settings']")]
		private IWebElement _payables_PurchaseLog_CreateSingleUseAccounts_PurchaseLogSettings { get; set; }
		public void NavigateTo_Payables_PurchaseLog_CreateSingleUseAccounts_PurchaseLogSettings()
		{
			NavigateToMenuItem(_payables_PurchaseLog_CreateSingleUseAccounts_PurchaseLogSettings);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Chargeback Reconciliation']")]
		private IWebElement _payables_PurchaseLog_CreateSingleUseAccounts_ChargebackReconciliation { get; set; }
		public void NavigateTo_Payables_PurchaseLog_CreateSingleUseAccounts_ChargebackReconciliation()
		{
			NavigateToMenuItem(_payables_PurchaseLog_CreateSingleUseAccounts_ChargebackReconciliation);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Disputes']")]
		private IWebElement _payables_PurchaseLog_CreateSingleUseAccounts_Disputes { get; set; }
		public void NavigateTo_Payables_PurchaseLog_CreateSingleUseAccounts_Disputes()
		{
			NavigateToMenuItem(_payables_PurchaseLog_CreateSingleUseAccounts_Disputes);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Create Single-Use Accounts']")]
		private IWebElement _payables_PurchaseLog_CreateSingleUseAccounts_CreateSingleUseAccounts { get; set; }
		public void NavigateTo_Payables_PurchaseLog_CreateSingleUseAccounts_CreateSingleUseAccounts()
		{
			NavigateToMenuItem(_payables_PurchaseLog_CreateSingleUseAccounts_CreateSingleUseAccounts);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Create Test Transactions']")]
		private IWebElement _payables_PurchaseLog_CreateSingleUseAccounts_CreateTestTransactions { get; set; }
		public void NavigateTo_Payables_PurchaseLog_CreateSingleUseAccounts_CreateTestTransactions()
		{
			NavigateToMenuItem(_payables_PurchaseLog_CreateSingleUseAccounts_CreateTestTransactions);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Daily Extract Files']")]
		private IWebElement _payables_PurchaseLog_CreateSingleUseAccounts_DailyExtractFiles { get; set; }
		public void NavigateTo_Payables_PurchaseLog_CreateSingleUseAccounts_DailyExtractFiles()
		{
			NavigateToMenuItem(_payables_PurchaseLog_CreateSingleUseAccounts_DailyExtractFiles);
		}

		
		private void NavigateToMenuItem(IWebElement element)
		{
			Driver.Url = element.GetAttribute("href");
		}
		#endregion

		public CreateTestAccounts(GlobalSettings settings) : base(settings) { }
	}  
}
