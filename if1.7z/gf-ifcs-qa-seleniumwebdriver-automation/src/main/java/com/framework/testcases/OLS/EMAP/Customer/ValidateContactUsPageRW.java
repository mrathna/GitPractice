package com.framework.testcases.OLS.EMAP.Customer;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.EMAP.EMAPHomePage;
import com.framework.pages.EMAP.EMAPSupportPage;
import com.framework.pages.OLS.common.LoginPage;

public class ValidateContactUsPageRW extends BaseTest {
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "Regression" })
	public void validateContactUsPage(@Optional("SP") String clientCountry, @Optional("EMAP") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  TST-SC-72-OLS - Contact Us",
				"Login to EMAP Customer - Read Write and check the contact us page");
		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		loginPage.Login("EMAP_URL", "EMAP_UN_ReadWrite_Customer_" + clientCountry,
				"EMAP_PWD_ReadWrite_Customer_" + clientCountry, clientName);
		EMAPHomePage emapHomePage = new EMAPHomePage(driver, test);
		EMAPSupportPage supportPage = new EMAPSupportPage(driver, test);
		if (!(clientCountry.equals("MO"))) {
			emapHomePage.clickContactUsAndValidatePage();
		} else {
			emapHomePage.clickContactUsMOAndValidatePage();
		}
		supportPage.checkClientLogo();
		supportPage.checkTheContactInfo(clientCountry);
		supportPage.selectAQueryType();
		supportPage.enterCommentInContactUsField("Texting at comment field");
		supportPage.enterAContactName();
		supportPage.enterAContactPhone();
		supportPage.enterAContactEmail();
		supportPage.submitTheContactQuery();
		supportPage.validateTheConfirmationMessage();
		// Logout
		loginPage.Logout();
	}
}
