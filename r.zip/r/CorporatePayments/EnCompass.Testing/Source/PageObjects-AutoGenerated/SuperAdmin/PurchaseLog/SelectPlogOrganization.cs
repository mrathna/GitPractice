using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using Common;
using Common.PageObjects;
using Common.ScenarioConfigurations;
using Common.Utility;

namespace EnCompass.Testing.Source.PageObjects.SuperAdmin.PurchaseLog 
{
	/// <summary>
	/// Auto-generated Page Model Class
	/// Navigation Paths: 
		/// [Organization Home]->Payables->Purchase Logs
		/// </summary>
	[PageModel(@"/SuperAdmin/PurchaseLog/SelectPlogOrganization.aspx")]
	public partial class SelectPlogOrganization : EnCompassSuperPageModel 
	{
		public override string RelativeUrl => @"/SuperAdmin/PurchaseLog/SelectPlogOrganization.aspx";
		public override string PageIdentifierXPath_Generated => @"//li[contains(@class, 'breadcrumb-item active')][text() = 'Purchase Logs']";

		#region Navigation
		
		private void NavigateToMenuItem(IWebElement element)
		{
			Driver.Url = element.GetAttribute("href");
		}
		#endregion

		public SelectPlogOrganization(GlobalSettings settings) : base(settings) { }
	}  
}
