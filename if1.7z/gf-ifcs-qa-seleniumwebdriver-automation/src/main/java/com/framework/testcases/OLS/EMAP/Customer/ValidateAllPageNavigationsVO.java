package com.framework.testcases.OLS.EMAP.Customer;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.EMAP.EMAPAccountsPage;
import com.framework.pages.EMAP.EMAPCardsPage;
import com.framework.pages.EMAP.EMAPHomePage;
import com.framework.pages.EMAP.EMAPReportsPage;
import com.framework.pages.EMAP.EMAPSupportPage;
import com.framework.pages.EMAP.EMAPTransactionsPage;
import com.framework.pages.OLS.common.CommonPage;
import com.framework.pages.OLS.common.LoginPage;

public class ValidateAllPageNavigationsVO extends BaseTest {
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "Regression" })
	public void validateAllPageNavigationsForViewOnlyAndStatusChangeCustomer(@Optional("SP") String clientCountry,
			@Optional("EMAP") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  TST-SC-81-OLS - All pages except cards menu,TST-SC-78-OLS - Verify menu items and log out",
				"Validate pages for - View Only and Status Change Customer Pages and menu items");
		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		loginPage.Login("EMAP_URL", "EMAP_UN_ViewOnly_Customer_" + clientCountry,
				"EMAP_PWD_ViewOnly_Customer_" + clientCountry, clientName);
		EMAPHomePage emapHomePage = new EMAPHomePage(driver, test);
		EMAPAccountsPage accountPage = new EMAPAccountsPage(driver, test);
		EMAPTransactionsPage transactionListsPage = new EMAPTransactionsPage(driver, test);
		CommonPage commonPage = new CommonPage(driver, test);
		EMAPSupportPage supportPage = new EMAPSupportPage(driver, test);
		EMAPCardsPage emapCardsPage = new EMAPCardsPage(driver, test);

		emapHomePage.validateEMAPCustomerLogo();
		emapHomePage.validateCustomerWelcomeText();
		emapHomePage.checkThePresenceOfQuickLinksOnHomePage("View-Only");
		emapHomePage.checkThePresenceOfLoginUserNameAndLogoutLink();

		// MC
//	emapHomePage.verifyCustomerNumberInHomePage();
		emapHomePage.selectAccountAndCheckSelectedAccountOnContext();
		emapCardsPage.checkThePresenceOfSubmenuItemsInCardsMenu("View-Only");

		// Account - Select Account
		emapHomePage.clickSelectAccountAndValidatePage();

		// Account - Account Maintenance
		emapHomePage.clickAccountMaintenanceAndValidatePage();
		accountPage.validateTheAccountMaintenancePageFields(clientCountry);

		// Account - Contacts
		emapHomePage.clickContactsAndValidatePage();
		accountPage.validateTheContactsTableFields();
		accountPage.checkContactsTableSorting();

		// Transaction - Transaction List
		emapHomePage.clickTransactionListAndValidatePage();
		transactionListsPage.validateTheTransactionsTableFields("Customer");
		transactionListsPage.selectAllAccountsInTrasactionSearchFilter();
		boolean isTransactionPresent = transactionListsPage.getACardNumberWithTransaction();
		if (isTransactionPresent) {
			transactionListsPage.enterACardNumberInSearchFilter();
			commonPage.clickSearchButton();
			transactionListsPage.validateSearchResultsAndClickViewTransactionsOption(true);
			transactionListsPage.verifyTransactionDetailsHeaderTitle();
			transactionListsPage.validateTransactionPageFields("Customer");
		}
		// Transaction - Export Transaction
		emapHomePage.clickExportTransactionListAndValidate();

		supportPage.checkClientLogo();
		// Support - Contact Us
				if (!(clientCountry.equals("MO"))) {
					emapHomePage.clickContactUsAndValidatePage();
				} else {
					emapHomePage.clickContactUsMOAndValidatePage();
				}
		supportPage.checkTheContactInfo(clientCountry);

		loginPage.Logout();
	}

	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "Regression" })
	public void validateFooterLinksForViewOnlyAndStatusChangeCustomer(@Optional("SP") String clientCountry,
			@Optional("EMAP") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  TST-SC-102-OLS-Verify the Ad-hoc Reports,TST-SC-103-OLS - Verify the Scheduled Reports,TST-SC-100-OLS-Verify Card Profile Changes",
				"Validate pages for - View Only and Status Change Customer Pages");
		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		loginPage.Login("EMAP_URL", "EMAP_UN_ViewOnly_Customer_" + clientCountry,
				"EMAP_PWD_ViewOnly_Customer_" + clientCountry, clientName);
		EMAPHomePage emapHomePage = new EMAPHomePage(driver, test);
		EMAPReportsPage reportsPage = new EMAPReportsPage(driver, test);
		EMAPSupportPage supportPage = new EMAPSupportPage(driver, test);

		// Reports - Stored Reports
		emapHomePage.clickStoredReportsAndValidatePage();
		reportsPage.validateTheReportsPageFilterOptions();
		reportsPage.checkThePresenceOfExportAndSearchOptions();
		reportsPage.validateTheReportsTableColumns();

		// Reports - Adhoc Reports
		emapHomePage.clickAdhocReportsAndValidatePage();
		reportsPage.checkThePresenceOfOptionToExportAdhocReport();
		reportsPage.validateTheAdhocReportsTableHeaderColumns(clientCountry);
		reportsPage.validateAdhocReportsTable();

		emapHomePage.clickCardListAndValidatePage();

		// Support - Change Password
		emapHomePage.clickChangePasswordAndValidatePage();
		supportPage.validateThePasswordMaintenanceFields();

		// Support - Contact Us
		if (!(clientCountry.equals("MO"))) {
			emapHomePage.clickContactUsAndValidatePage();
		} else {
			emapHomePage.clickContactUsMOAndValidatePage();
		}
		// // Footer Links - Exxon Mobil Corporation link
		if (!clientCountry.contains("SG")) {
			emapHomePage.clickExxonMobilCorporationInFooterAndValidatePage();
			emapHomePage.clickHomeMenuAndValidatePage("Customer");
		}
		// Footer Links - Contact Ussd
		emapHomePage.clickContactUsInFooterAndValidatePage();
		emapHomePage.clickHomeMenuAndValidatePage("Customer");

		// Footer Links - Copyright
		emapHomePage.clickCopyRightAndValidatePage(clientName);

		// Footer Links - Terms And Condition
		emapHomePage.checkThePresenceOfTermsAndConditionInFooter();

		// Footer Links - Privacy Statement
		//emapHomePage.clickPrivacyPolicyAndValidatePage();

		// Footer Links - Client Logos
	//	emapHomePage.clickExxonMobilLogoAndValidatePage();
	//	 emapHomePage.clickEssoLogoAndValidatePage();
	//	emapHomePage.clickMobilLogoAndValidatePage();
		
		loginPage.Logout();
	}
}
