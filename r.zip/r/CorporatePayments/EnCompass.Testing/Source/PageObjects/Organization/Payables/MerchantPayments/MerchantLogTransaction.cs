﻿using Common;
using Common.Utility;
using EnCompass.Testing.Source.PageObjects.Controls;
using EnCompass.Testing.Source.PageObjects.Organization.ExpenseManager.PurchaseLog;
using NFluent;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Support.UI;
using System.Text.RegularExpressions;

namespace EnCompass.Testing.Source.PageObjects.Organization.Payables.MerchantPayments
{
    [PageModel(@"/payables/merchantPayments/MerchantLogTransaction.aspx")]
    public class MerchantLogTransaction : EnCompassOrgPageModel
    {
        public override string RelativeUrl => @"/payables/merchantPayments/MerchantLogTransaction.aspx";
        public override string PageIdentifierXPath_Override => @"//li[@class='breadcrumb-item active'][normalize-space(text()) = 'Merchant Log Transactions']";

        #region XPath page Elements

        private const string _mLogTransactionsTitleXPath = @"//h1[contains(@id, 'h1title')]";
        private const string _selectMLogFormatValueXPath = @"//select[contains(@id, 'ddlExportType')]";
        private const string _btnExportGridTextXPath = @"//input[contains(@id, 'btnExportGridText')]";
        private const string _billingDetailsIFrameXPath = @"//iframe[contains(@id, 'viewBillingDetails')]";

        private const string _disputeTransactionButtonXPath = @".//input[contains(@id, 'btnSubmitDispute')]";
        private const string _disputeCloseTransactionButtonXPath = @".//input[contains(@id, 'btnCloseDispute')]";
        private const string _disputeCancelButtonXPath = @".//div[@class='modal-footer']//button[contains(text(), 'Cancel')]";

        private const string _disputeAmountXPath = ".//input[contains(@id, 'txtDisputedAmount')]";
        private const string _disputeEmailXPath = ".//textarea[contains(@id, 'txtDisputeEmailAddress')]";
        private const string _disputeSelectReasonXPath = ".//select[contains(@id, 'ddlDisputeReason')]";
        private const string _disputeCommentXPath = ".//textarea[contains(@id, 'txtDisputeReasonOther')]";
        private const string _disputeConfirmButtonXPath = ".//div[contains(@id, 'footer_Modal')]//button[text() = 'Confirm']";
        private const string _disputeCancelConfirmButtonXPath = ".//div[contains(@id, 'footer_Modal')]//button[text() = 'Cancel']";

        private const string _disputeRequiredAmountXPath = ".//span[contains(@id, 'rfvDisputedAmount')]";
        private const string _disputeRequiredEmailXPath = ".//span[contains(@id, 'rfvDisputeEmailAddress')]";
        private const string _disputeRequiredCommentXPath = ".//span[contains(@id, 'rfvDisputeReasonOther')]";
        private const string _disputeRequiredReasonXPath = ".//span[contains(@id, 'rfvDisputeReason')]";
        private const string _disputeValidationXPath = ".//div[contains(@id, 'DisputeValidation')]";
        private const string _modalHeaderXPath = @".//h1[contains(@id,'ModalTitle_Modal')]";
        #endregion

        #region Page Elements 
        public IWebElement _mLogTransactionsTitle
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_mLogTransactionsTitleXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_mLogTransactionsTitle element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _selectMLogFormatValue
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_selectMLogFormatValueXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_selectMLogFormatValue element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _btnExportGridText
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_btnExportGridTextXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_btnExportGridText element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _billingDetailsIFrame
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_billingDetailsIFrameXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_billingDetailsIFrame element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _disputeTransactionButton
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_disputeTransactionButtonXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_disputeTransactionButton element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _disputeCloseTransactionButton
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_disputeCloseTransactionButtonXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_disputeCloseTransactionButton element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _disputeAmount
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_disputeAmountXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_disputeAmount element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _disputeEmail
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_disputeEmailXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_disputeEmail element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _disputeSelectReason
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_disputeSelectReasonXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_disputeSelectReason element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _disputeComment
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_disputeCommentXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_disputeComment element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _disputeConfirmButton
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_disputeConfirmButtonXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_disputeConfirmButton element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _disputeCancelConfirmButton
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_disputeCancelConfirmButtonXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_disputeCancelConfirmButton element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _disputeCancelButton
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_disputeCancelButtonXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_disputeCancelButton element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _disputeRequiredAmount
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_disputeRequiredAmountXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_disputeRequiredAmount element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _disputeRequiredEmail
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_disputeRequiredEmailXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_disputeRequiredEmail element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _disputeValidation
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_disputeValidationXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_disputeValidation element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _disputeRequiredComment
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_disputeRequiredCommentXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_disputeRequiredComment element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _disputeRequiredReason
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_disputeRequiredReasonXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_disputeRequiredReason element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _modalHeader
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_modalHeaderXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_modalHeader element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        #endregion

        private GridControl _mLogGrid;
        public GridControl MLogTransactionsGrid
        {
            get
            {
                GridControl grid = _mLogGrid ?? (_mLogGrid = new GridControl("dgTransactions", Driver));
                grid.WaitForGrid();
                return grid;
            }
        }

        private string _captionXpath = "//table[contains(@id,'_dgTransactions')]/caption";
        public string TotalTransactionAmount
        {
            get
            {
                IWebElement _caption = Driver.WaitForVisible(By.XPath(_captionXpath));
                string _amt = _caption.Text.Split('=')[1].Trim(); // return xx.yy USD
                return _amt;
            }
        }

        /// <summary>
        /// Check if the Billing Details IFrame is Displayed
        /// </summary>
        /// <returns></returns>
        public bool IsBillingDetailsIFrameDisplayed()
        {
            if (_billingDetailsIFrame.Displayed)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// Method Get for Billing Details IFrame
        /// </summary>
        public BillingDetailsIFrame GetBillingDetailsIFrame
        {
            get
            {
                using (FrameHelper helper = new FrameHelper(Settings.EnCompassWebDriver, By.XPath(_billingDetailsIFrameXPath)))
                {
                    return new BillingDetailsIFrame(helper, Settings);
                }
            }
        }

        /// <summary>
        /// The IFrame Helper class that would check information in the Billing Details IFrame modal popup.
        /// </summary>
        public class BillingDetailsIFrame : MerchantLogTransaction
        {
            FrameHelper _helper;
            public BillingDetailsIFrame(FrameHelper helper, GlobalSettings settings) : base(settings)
            { _helper = helper; }

            public string GetIFrameElementText(string xPath)
            {
                IWebElement element = _helper.FindElement(By.XPath(xPath));

                if (element != null)
                {
                    return element.FindElement(By.XPath(@"strong")).Text;
                }
                else
                {
                    return string.Empty;
                }
            }

            /// <summary>
            /// Method to close Billing Details IFrame
            /// </summary>
            public void CloseBillingDetailsIFrame()
            {
                IWebElement element = _helper.FindElement(By.XPath("//input[contains(@id,'footerContent_btnClose')]"));
                if (element != null)
                {
                    element.JSClickWithFocus(Driver);
                    Settings.EnCompassExtentTest.Info("Clicked on close on Billing Details Modal.");
                }
            }
        }

        /// <summary>
        /// Method to select the Mlog format by value
        /// </summary>
        /// <param name="whichText"></param>
        public void SelectMLogFormatValue(string whichText)
        {
            var selectElement = new SelectElement(_selectMLogFormatValue);
            selectElement.SelectByText(whichText);
            Settings.EnCompassExtentTest.Info("Select MLog Format with Value: " + whichText);
        }

        /// <summary>
        /// Method used to perfom click in Export Grid button
        /// </summary>
        public void ExportGridText()
        {
            _btnExportGridText.JSClickWithFocus(Driver);
            Settings.EnCompassExtentTest.Info("Clicked on Export button for Transaction Mlog");
      
        }

        /// <summary>
        /// Method used to submit Dispute Transaction
        /// </summary>
        public void DisputeTransaction()
        {
            _disputeTransactionButton.JSClickWithFocus(Driver);
            Settings.EnCompassExtentTest.Info("Clicked on Dispute button for Transaction Mlog");
        }

        /// <summary>
        /// Method used to close Dispute Transaction
        /// </summary>
        public void DisputeCloseTransaction()
        {
            _disputeCloseTransactionButton.JSClickWithFocus(Driver);
            WaitForModalToAppear();
            Settings.EnCompassExtentTest.Info("Clicked on Close Dispute button for Transaction Mlog");
        }

        /// <summary>
        /// Method used to cancel Dispute Transaction
        /// </summary>
        public void DisputeCancel()
        {
            _disputeCancelButton.JSClickWithFocus(Driver);
            Settings.EnCompassExtentTest.Info("Clicked on Cancel button for Transaction Mlog");
        }

        /// <summary>
        /// Method used to confirm the dispute transaction in confirmation modal
        /// </summary>
        public void DisputeConfirm()
        {
            _disputeConfirmButton.JSClickWithFocus(Driver);
            Settings.EnCompassExtentTest.Info("Clicked on Confirm button for Transaction Mlog");
        }

        /// <summary>
        /// Method used to cancel the dispute transaction in confirmation modal
        /// </summary>
        public void DisputeCancelConfirm()
        {
            _disputeCancelConfirmButton.JSClickWithFocus(Driver);
            Settings.EnCompassExtentTest.Info("Clicked on Cancel Confirm button for Transaction Mlog");
        }

        /// <summary>
        /// Function used to get/set the Dispute Amount
        /// </summary>
        public string DisputeAmount
        {
            get
            {
                return _disputeAmount.Text;
            }
            set
            {
                _disputeAmount.Clear();
                _disputeAmount.SendKeys(value);
                ModalHeaderClick();
                Settings.EnCompassExtentTest.Info($"Inserted {value} on the field Dispute Amount.");
            }
        }

        /// <summary>
        ///  Function used to get/set the Dispute Email
        /// </summary>
        public string DisputeEmail
        {
            get
            {
                return _disputeEmail.Text;
            }
            set
            {
                _disputeEmail.Clear();
                _disputeEmail.SendKeys(value);
                ModalHeaderClick();
                Settings.EnCompassExtentTest.Info($"Inserted {value} on the field Dispute Email.");
            }
        }

        /// <summary>
        ///  Function used to get/select the Dispute Reason
        /// </summary>
        public string DisputeSelectReason
        {
            get
            {
                return new SelectElement(_disputeSelectReason).SelectedOption.Text.Trim();
            }
            set
            {
                if (value == "")
                    new SelectElement(_disputeSelectReason).SelectByIndex(0);
                else
                    new SelectElement(_disputeSelectReason).SelectByText(value);

                Settings.EnCompassExtentTest.Info($"Selected {value} on Reason DDL.");
            }
        }

        /// <summary>
        ///  Function used to get/set the Dispute Comment
        /// </summary>
        public string DisputeComment
        {
            get
            {
                return _disputeComment.Text;
            }
            set
            {
                _disputeComment.Clear();
                _disputeComment.SendKeys(value);
                ModalHeaderClick();
                Settings.EnCompassExtentTest.Info($"Inserted {value} on the field Dispute Comment.");
            }
        }

        /// <summary>
        ///  Function used to get the Amount required message
        /// </summary>
        public string GetRequiredAmount
        {
            get
            {
                return _disputeRequiredAmount.Text;
            }
        }

        /// <summary>
        ///  Function used to get the Email required message
        /// </summary>
        public string GetRequiredEmail
        {
            get
            {
                return _disputeRequiredEmail.Text;
            }
        }

        /// <summary>
        ///  Function used to get the Comment required message
        /// </summary>
        public string GetRequiredComment
        {
            get
            {
                return _disputeRequiredComment.Text;
            }
        }

        /// <summary>
        ///  Function used to get the Reason required message
        /// </summary>
        public string GetRequiredReason
        {
            get
            {
                return _disputeRequiredReason.Text;
            }
        }

        public string GetValidationMessage
        {
            get
            {
                return _disputeValidation.Text;
            }
        }

        
        /// <summary>
        /// Fill the Modal to Dispute Transaction
        /// </summary>
        /// <param name="amount"></param>
        /// <param name="email"></param>
        /// <param name="reason"></param>
        /// <param name="comment"></param>
        public void FillDisputeTransactionModalAndConfirm(string amount, string email, string reason, string comment)
        {
            WaitForModalToAppear();

            DisputeAmount = amount;
            DisputeEmail = email;
            DisputeSelectReason = reason;
            DisputeComment = comment;

            //Confirm On Modal doesn't work for this one and we don't have a static modal ID.
            DisputeTransaction();

            // Another confirmation modal pops out. Since WaitForModalToAppear is ineffective here, I wait for Confirm button.
            // This button belongs only in the innermost confirmation modal.
            DisputeConfirm();

            if (Regex.IsMatch(amount, @"([0-9]+)(\.([0-9]+))"))
                WaitForModalToDisappear();
        }

        /// <summary>
        /// Return the value if DisputeValidation is visible
        /// </summary>
        public bool DisputeValidationIsVisible
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_disputeValidationXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_disputeValidation element exist is {found}");
                return found;
            }
        }

        /// <summary>
        /// Method used to focus out a field at the modal
        /// </summary>
        public void ModalHeaderClick()
        {
            _modalHeader.JSClickWithFocus(Driver);
        }

        public bool IsMLogTransactionsTitleDisplayed => _mLogTransactionsTitle.Displayed;

        public MerchantLogTransaction(GlobalSettings settings) : base(settings) { }
    }
}
