package com.framework.testcases.OLS.CHEV.Customer.ReadOnly;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.CHEV.CHBulkCardOrderPage;
import com.framework.pages.CHEV.CHBulkCardUpdatePage;
import com.framework.pages.CHEV.CHCardListPage;
import com.framework.pages.CHEV.CHHomePage;
import com.framework.pages.CHEV.CHViewCardPage;
import com.framework.pages.OLS.common.LoginPage;

public class ValidateOLSCardsMenu extends BaseTest {
	@Parameters({ "clientCountry", "clientName"})
	@Test(priority = 1)
	public void testCustomerReadOnlyOLSCardsMenu(@Optional("PH") String clientCountry, @Optional("CHV") String clientName) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  Read Only OLS - Cards Menu", "Chevron Customer Screens Read Only");

		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
        CHHomePage chHomePage = new CHHomePage(driver, test);
		CHCardListPage cardListPage = new CHCardListPage(driver, test);
		CHViewCardPage chViewCardPage = new CHViewCardPage(driver, test);
		CHBulkCardOrderPage chBulkCardOrderPage = new CHBulkCardOrderPage(driver, test);
		CHBulkCardUpdatePage chBulkCardUpdatePage = new CHBulkCardUpdatePage(driver, test);
		
		loginPage.Login("CHV_URL", "CHV_Customer_UN_READ_ONLY_"+clientCountry, "CHV_Customer_PWD_READ_ONLY_"+clientCountry, clientName);
		//Find Cards
		chHomePage.loadFindAndUpdateCardPage();
		cardListPage.verifySearchButton();
		cardListPage.verifyExportButton();
		cardListPage.verifyPageSubTitles();
		cardListPage.clickSearchCard();
		cardListPage.verifyCardlistSearchtableHeaders();
		String cardResult = cardListPage.getActiveCardNumber();
		if(cardResult!=null) {
			cardListPage.enterCardNumber(cardResult);
			cardListPage.clickSearchCard();
			cardListPage.clickFirstCardNumberFromCardsList();
			cardListPage.pickCardDetailsOption();
			cardListPage.verifyViewCardPage();
			chViewCardPage.verifyReadOnlyMode();
			chViewCardPage.navigateBacktoCardList();
		} else {
			System.out.println("No Card Result found to Proceed");
		}
		
		//Reissue Controls
		chHomePage.loadReissueControlPage();
		cardListPage.verifyReissueUpload();
		
		//Bulk Card Status Change 
		chHomePage.loadBulkStatusChangePage();
		cardListPage.verifyBulkStatusChangeUpload();
	
		
		// TODO All Fields are diabled in the read only account.

		// String cardNumber = PropUtils.getPropValue(configProp, cardNumberStr);
		//
		// cardListPage.enterCardNumber(cardNumber);
		// cardListPage.clickSearchCard();
		// cardListPage.validateCardNumber(cardNumber);
		// cardListPage.clickFirstCardNumberFromCardsList();
		// cardListPage.verifyContextMenu();
		// cardListPage.pickCardDetailsOption();
		//
		// chViewCardPage.verifySubTitles();
		// chViewCardPage.verifyReadOnlyMode();
		// chViewCardPage.navigateBacktoCardList();

		//Bulk Order
		chHomePage.loadFindAndBulkOrderPage();
		chBulkCardOrderPage.verifyDownloadButton();
		chBulkCardOrderPage.verifyUploadButton();
		
		//Bulk Update
		chHomePage.loadFindAndBulkUpdatePage();
		chBulkCardUpdatePage.verifyDownloadButton();
		chBulkCardUpdatePage.verifyUploadButton();

		loginPage.Logout();

	}

}
