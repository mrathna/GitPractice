package com.framework.testcases.API;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.common.IFCSLoginPage;
import com.framework.pages.API.common.MerchantMethodsAPI;
import com.framework.util.PropUtils;

public class ValidateCreateAndUpdateMerchant extends BaseTest {
	@Parameters({ "clientCountry", "clientName", "merchantNo", "marketingTerritory" })
	@Test( groups = { "BusinessFlow" })
	public void createNewMerchant(@Optional("AU") String clientCountry, @Optional("BP") String clientName,
			@Optional("random") String merchantNo, @Optional("random") String marketingTerritory) {

		test = extent.createTest(clientName + ":" + clientCountry + "  Create Merchant",
				"Create new merchant via API ");

		MerchantMethodsAPI merchantAPI = new MerchantMethodsAPI(driver, test);
		IFCSLoginPage ifcsLoginPage = new IFCSLoginPage(driver, test);

		ifcsLoginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");

		merchantAPI.loginToAPIUser(
				PropUtils.getPropValue(configProp, "UserNameAPI" + "_" + clientName + "_" + clientCountry),
				PropUtils.getPropValue(configProp, "PassWordAPI" + "_" + clientName + "_" + clientCountry));
		merchantAPI.createMerchant(clientName, clientCountry, merchantNo, marketingTerritory);

		merchantAPI.logoutAPIUser();

	}

}
