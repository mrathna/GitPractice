package com.framework.testcases.AJS.EMAP.Interface;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.common.CommonInterfacePage;
import com.framework.pages.AJS.common.IFCSCommonPage;
import com.framework.pages.AJS.common.IFCSLoginPage;

public class ValidateMOPSPricingTestCase extends BaseTest {
	// Report Validation
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "Smoke" })
	public void ValidateMOPSPricingReportsGeneratedFromDayEndAndMonthEnd(@Optional("SG") String clientCountry,
			@Optional("EMAP") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  Verify the Perform MOPS pricing", "Perform MOPS pricing");
		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		CommonInterfacePage commonInterfacePage = new CommonInterfacePage(driver, test);
		IFCSCommonPage ifcsCommonPage = new IFCSCommonPage(driver, test);

		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, " ");

		String dayEndDatePath = "";
		String fileName = "";
		String localFolder = "";

		// Customer Statement Report
		String cusNo = "0007282";
		//String CustomerAmount = common.getCustomerAmountFromPeriodRebates(cusNo);
		fileName = commonInterfacePage.getRecentProcessedReportFiles(clientName, clientCountry,
				"Customer Statement(Standard)", cusNo);
		 if (clientCountry.equals("SP")) {
			dayEndDatePath = commonInterfacePage.getFolderPathUsingPreviousProcessingDate(clientName, clientCountry,
					"IFCS_DAYEND_OUTPUTFILE_SP_CUSTOMER");
		} else if (clientCountry.equals("GU")) {
			dayEndDatePath = commonInterfacePage.getFolderPathUsingPreviousProcessingDate(clientName, clientCountry,
					"IFCS_DAYEND_OUTPUTFILE_GU_CUSTOMER");
		} 
		System.out.println("dayEndDatePath::" + dayEndDatePath);
		ifcsCommonPage.establishThePuttyConnection("incomingFile", "PUTTY_HOST", "PUTTY_USERNAME", "PUTTY_PASSWORD",
				dayEndDatePath, fileName);
		localFolder = System.getProperty("user.home") + "\\Documents\\" + fileName;
		System.out.println("localFolder::" + localFolder);
		// Validate customer amount Before change the pricing
		commonInterfacePage.validateTextFromPDF(fileName, "101", "CustomerAmount",1,5);

		// Validate customer amount After change the pricing
		fileName = commonInterfacePage.getRecentProcessedReportFiles(clientName, clientCountry,
				"Customer Statement(Standard)", cusNo);
		 if (clientCountry.equals("SP")) {
			dayEndDatePath = commonInterfacePage.getFolderPathUsingPreviousProcessingDate(clientName, clientCountry,
					"IFCS_DAYEND_OUTPUTFILE_SP_CUSTOMER");
		} else if (clientCountry.equals("GU")) {
			dayEndDatePath = commonInterfacePage.getFolderPathUsingPreviousProcessingDate(clientName, clientCountry,
					"IFCS_DAYEND_OUTPUTFILE_GU_CUSTOMER");
		} 
		System.out.println("dayEndDatePath::" + dayEndDatePath);
		ifcsCommonPage.establishThePuttyConnection("incomingFile", "PUTTY_HOST", "PUTTY_USERNAME", "PUTTY_PASSWORD",
				dayEndDatePath, fileName);
		localFolder = System.getProperty("user.home") + "\\Documents\\" + fileName;
		System.out.println("localFolder::" + localFolder);
		// Validate customer amount After change the pricing
		commonInterfacePage.validateTextFromPDF(fileName, "101", "CustomerAmount",1,5);
	}

}
