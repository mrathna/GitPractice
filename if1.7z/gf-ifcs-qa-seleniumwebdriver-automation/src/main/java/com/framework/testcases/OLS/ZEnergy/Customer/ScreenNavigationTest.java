package com.framework.testcases.OLS.ZEnergy.Customer;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.OLS.common.LoginPage;
import com.framework.pages.Z.ZAccountsPage;
import com.framework.pages.Z.ZCardsPage;
import com.framework.pages.Z.ZHomePage;
import com.framework.pages.Z.ZTransactionPage;

public class ScreenNavigationTest extends BaseTest {

	@Parameters({"clientCountry","clientName"})
	@Test(groups = { "Smoke" })
	public void validateTheAccountNameChange(@Optional("Z") String clientCountry, @Optional("ZEnergy") String clientName) {
		
		test = extent.createTest(clientName+ ":" +clientCountry+"  Changing the Account in home page", "Verfying by changing the Account in home page");
		
        //Creating Objects for the Pages
        LoginPage loginPage = new LoginPage(driver, test);
        ZHomePage zHomePage = new ZHomePage(driver, test);
        loginPage.Login("ZEnergy_URL", "ZEnergy_UN_Customer_" + clientCountry, "ZEnergy_PWD_Customer_" + clientCountry, clientName);
        zHomePage.selectAccountFromDropdownAndValidate();
        zHomePage.verifyCustomerNameInHomePage();
        loginPage.Logout();

	}
	
	/*@Parameters({"clientCountry","clientName"})
	@Test(groups = { "Smoke" })
	public void validateSearchTransactionsFindTransactionScreen(@Optional("Z") String clientCountry, @Optional("ZEnergy") String clientName) {
		
		test = extent.createTest(clientName+ ":" +clientCountry+"  Search transactions in find transaction screen", "Verfying Search transactions in find transaction screen");
		
        //Creating Objects for the Pages
        LoginPage loginPage = new LoginPage(driver, test);
        ZTransactionPage zTransactionPage = new ZTransactionPage(driver, test);
        loginPage.Login("ZEnergy_URL", "ZEnergy_UN_Customer_" + clientCountry, "ZEnergy_PWD_Customer_" + clientCountry, clientName);
    zTransactionPage.clickTransactionsFindTransactioins();
        zTransactionPage.selectAllAccountsAndSearch();
        loginPage.Logout();

	}*/
	
	@Parameters({"clientCountry","clientName"})
	@Test(groups = { "Smoke" })
	public void validateSearchCardsbySelectingAllAccount(@Optional("Z") String clientCountry, @Optional("Z Energy Limited") String clientName) {
		
		test = extent.createTest(clientName+ ":" +clientCountry+"  Search cards by selecting all account in find cards screen", "Verfying Search cards by selecting all account");
		
        //Creating Objects for the Pages
        LoginPage loginPage = new LoginPage(driver, test);
        ZHomePage zHomePage = new ZHomePage(driver, test);
       /* ZCardsPage cardPage = new ZCardsPage(driver, test);
     
        ZReportsPage zReportPage = new ZReportsPage(driver, test);
        ZAccountsPage accountPage = new ZAccountsPage(driver,test);
        ZTransactionPage zTransactionPage = new ZTransactionPage(driver, test);
        CardsPage cardsCommonPage = new CardsPage(driver, test);*/
        loginPage.Login("ZEnergy_URL", "ZEnergy_UN_Customer_" + clientCountry, "ZEnergy_PWD_Customer_" + clientCountry, clientName);
               
       //TC-01-Changing the Account in home page
        zHomePage.selectAccountFromDropdownAndValidate();
        zHomePage.verifyCustomerNameInHomePage();
        
//       /* //TC-02- Search transactions in find transaction screen
//        zTransactionPage.clickTransactionsFindTransactioins();
//        zTransactionPage.selectAllAccountsAndSearch();*/
//        
//        // TC-03- Navigate to transaction detail screen
//        
//        cardPage.clickCardsFindCards();
//        // TC-04- Search cards by selecting all account
//        cardPage.selectAllAccountsAndSearch();
//        
//        // TC-05- Click Details in the Card list
////        cardPage.clickCardDetailsGoToViewCardPageAndValidate();
//        cardsCommonPage.clickViewCardGoToViewCardPageAndValidate("ZEnergy"); 
//        
//        // TC-06- Click clone Card from card list
//        cardPage.clickBackToCardList();
//        cardPage.selectAllAccountsAndSearch();
//        cardPage.clickCloneCardAndValidate();
//        
//        // TC-07 - Click on add a schedule report
//        zReportPage.goToscheduleReport();
//        zReportPage.clickAddScheduleReport();
//        
//       // TC-08- Click a back to scheduled report list
//        zReportPage.clickBackToScheduleReportList();       
//        
//        // TC-09- Click on Request a report from Reports
//        zReportPage.clickRequestAReport();
//        
//        // TC-10- Select a report name from request a report list
//        zReportPage.ClickReportName();        
//                   
//        // TC-11- Navigate to cost center page
//        accountPage.goToAccountsCostCentres();
//        accountPage.selectCostCentreAllAccountOption();
//        accountPage.clickCostCentreSearchButton();
//        accountPage.validateCostCentreExist();
//        
//        // TC 12- Selecting Card offer from Order new card
//        cardPage.goToCardOrder();
//        cardPage.selectDriverCard();
//       // cardPage.validateSelectedCardOffer();
//        
//        // TC-13- Search vehicles from Accounts>>Vehicles
//        accountPage.goToAccountsVehicles();
//        accountPage.selectVehcileAllAccountOption();
//        accountPage.clickVehicleSearchButton();
//        accountPage.validateVehicleExist();
//        
//        // TC-14- Click a Order a card from Quick links
//        zReportPage.clickHomeMenu();
//        zHomePage.clickOrderACard();
//        
//        // TC-15- Navigate to find report page   
//         zReportPage.goToFindReports();
//       
//        // TC-16- Search reports from stored report screen
//        zReportPage.searchStoredReports();
//        
//        // TC-17- Navigate to home screen from find report        
//        zReportPage.clickHomeMenu();
//        
//        // TC-18- Click a user guide from Quick links  
//        zHomePage.clickUserGuide();
//        
//        // TC-19- Search invoices from find reports invoices
//        zReportPage.goToInvoicesAndSearchInovices();
//        
//        // TC-20- Click a contact from contact list
//        accountPage.goToContactsDetailScreen();
        
                  
        
	}
		
	
	@Parameters({"clientCountry","clientName"})
	@Test(groups = { "Smoke" })
	public void validateSearchCostCenter(@Optional("Z") String clientCountry, @Optional("ZEnergy") String clientName) {
		
		test = extent.createTest(clientName+ ":" +clientCountry+"  Navigate to cost center page", "Navigate to cost center page");
		
        //Creating Objects for the Pages
        LoginPage loginPage = new LoginPage(driver, test);
        loginPage.Login("ZEnergy_URL", "ZEnergy_UN_Customer_" + clientCountry, "ZEnergy_PWD_Customer_" + clientCountry, clientName);
        ZAccountsPage accountPage = new ZAccountsPage(driver,test);
        accountPage.goToAccountsCostCentres();
        accountPage.selectCostCentreAllAccountOption();
        accountPage.clickCostCentreSearchButton();
        accountPage.validateCostCentreExist();
        loginPage.Logout();

	} 
	
	@Parameters({"clientCountry","clientName"})
	@Test(groups = { "Smoke" })
	public void validateCardOffer(@Optional("Z") String clientCountry, @Optional("ZEnergy") String clientName) {
		
		test = extent.createTest(clientName+ ":" +clientCountry+"  Selecting Card offer from Order new card", "Selecting Card offer from Order new card");
		
        //Creating Objects for the Pages
        LoginPage loginPage = new LoginPage(driver, test);
        loginPage.Login("ZEnergy_URL", "ZEnergy_UN_Customer_" + clientCountry, "ZEnergy_PWD_Customer_" + clientCountry, clientName);
        ZCardsPage cardPage = new ZCardsPage(driver, test);
        cardPage.goToCardOrder();
        cardPage.selectDriverCard();
        cardPage.validateSelectedCardOffer();
        loginPage.Logout();

	} 
	
	@Parameters({"clientCountry","clientName"})
	@Test(groups = { "Smoke" })
	public void validateSearchVehicles(@Optional("Z") String clientCountry, @Optional("ZEnergy") String clientName) {
		
		test = extent.createTest(clientName+ ":" +clientCountry+"  Search vehicles from Accounts>>Vehicles", "Search vehicles from Accounts>>Vehicles");
		
        //Creating Objects for the Pages
        LoginPage loginPage = new LoginPage(driver, test);
        loginPage.Login("ZEnergy_URL", "ZEnergy_UN_Customer_" + clientCountry, "ZEnergy_PWD_Customer_" + clientCountry, clientName);
        ZAccountsPage accountPage = new ZAccountsPage(driver,test);
        accountPage.goToAccountsVehicles();
        accountPage.selectVehcileAllAccountOption();
        accountPage.clickVehicleSearchButton();
        accountPage.validateVehicleExist();
        loginPage.Logout();

	}
	
	@Parameters({"clientCountry","clientName"})
	@Test(groups = { "Smoke" })
	public void validateOrderCardFromQuickLinks(@Optional("Z") String clientCountry, @Optional("ZEnergy") String clientName) {
		
		test = extent.createTest(clientName+ ":" +clientCountry+"  Click a Order a card from Quick links", "Click a Order a card from Quick links");
		
        //Creating Objects for the Pages
        LoginPage loginPage = new LoginPage(driver, test);
        ZHomePage zHomePage = new ZHomePage(driver, test);
        loginPage.Login("ZEnergy_URL", "ZEnergy_UN_Customer_" + clientCountry, "ZEnergy_PWD_Customer_" + clientCountry, clientName);
        zHomePage.clickOrderACard();
        loginPage.Logout();

	} 
	
	@Parameters({"clientCountry","clientName"})
	@Test(groups = { "Smoke" })
	public void validateUserGuideFromQuickLinks(@Optional("Z") String clientCountry, @Optional("ZEnergy") String clientName) {
		
		test = extent.createTest(clientName+ ":" +clientCountry+"  Click a user guide from Quick links", "Click a user guide from Quick links");
		
        //Creating Objects for the Pages
        LoginPage loginPage = new LoginPage(driver, test);
        ZHomePage zHomePage = new ZHomePage(driver, test);
        loginPage.Login("ZEnergy_URL", "ZEnergy_UN_Customer_" + clientCountry, "ZEnergy_PWD_Customer_" + clientCountry, clientName);
        zHomePage.clickUserGuide();
        loginPage.Logout();

	} 
	
	/*@Parameters({"clientCountry","clientName"})
	@Test(groups = { "Smoke" })
	public void validateUserGuideFromQuickLinks(@Optional("Z") String clientCountry, @Optional("ZEnergy") String clientName) {
		
		test = extent.createTest(clientName+ ":" +clientCountry+"  Navigate to find report page", "Navigate to find report page");
		
        //Creating Objects for the Pages
        LoginPage loginPage = new LoginPage(driver, test);
        ZReportsPage zReportPage = new ZReportsPage(driver, test);
        loginPage.Login("ZEnergy_URL", "ZEnergy_UN_Customer_" + clientCountry, "ZEnergy_PWD_Customer_" + clientCountry, clientName);
        zReportPage.goToFindReports();
        loginPage.Logout();

	}*/
	

    @Parameters({"clientCountry","clientName"})
	@Test(groups = { "Smoke" })
	public void validateSearchTransactionsFindTransactionScreen(@Optional("Z") String clientCountry, @Optional("Z Energy Limited") String clientName) {
		
		test = extent.createTest(clientName+ ":" +clientCountry+"  Search transactions in find transaction screen", "Verfying Navigate to transaction detail screen");
		
        //Creating Objects for the Pages
        LoginPage loginPage = new LoginPage(driver, test);
        ZTransactionPage zTransactionPage = new ZTransactionPage(driver, test);
        loginPage.Login("ZEnergy_URL", "ZEnergy_UN_Customer_" + clientCountry, "ZEnergy_PWD_Customer_" + clientCountry, clientName);
     //   zTransactionPage.clickTransactionsFindTransactioins();
        zTransactionPage.getTransactionDateFromTheDBForTheCurrentInternetUser("ZEnergy_UN_Customer_" + clientCountry, clientName);
        zTransactionPage.selectAllAccountsdTransactionDateAndSearch();
        zTransactionPage.goToTransactionDetailScreen();
        loginPage.Logout();

	}
	
	
}
