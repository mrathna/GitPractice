using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using Common;
using Common.PageObjects;
using Common.ScenarioConfigurations;
using Common.Utility;

namespace EnCompass.Testing.Source.PageObjects.SuperAdmin.AocsuperTools.JobTestAutomation 
{
	/// <summary>
	/// Auto-generated Page Model Class
	/// Navigation Paths: 
		/// [Organization Home]->Super Admin Tools->Job Test Automation->Run Test
		/// </summary>
	[PageModel(@"/superAdmin/AOCSuperTools/JobTestAutomation/SubmitTestRun.aspx")]
	public partial class SubmitTestRun : EnCompassSuperPageModel 
	{
		public override string RelativeUrl => @"/superAdmin/AOCSuperTools/JobTestAutomation/SubmitTestRun.aspx";
		public override string PageIdentifierXPath_Generated => @"//li[contains(@class, 'breadcrumb-item active')][text() = 'Run Test']";

		#region Navigation
				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Test Results']")]
		private IWebElement _superAdminTools_JobTestAutomation_RunTest_TestResults { get; set; }
		public void NavigateTo_SuperAdminTools_JobTestAutomation_RunTest_TestResults()
		{
			NavigateToMenuItem(_superAdminTools_JobTestAutomation_RunTest_TestResults);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Run Test']")]
		private IWebElement _superAdminTools_JobTestAutomation_RunTest_RunTest { get; set; }
		public void NavigateTo_SuperAdminTools_JobTestAutomation_RunTest_RunTest()
		{
			NavigateToMenuItem(_superAdminTools_JobTestAutomation_RunTest_RunTest);
		}

		
		private void NavigateToMenuItem(IWebElement element)
		{
			Driver.Url = element.GetAttribute("href");
		}
		#endregion

		public SubmitTestRun(GlobalSettings settings) : base(settings) { }
	}  
}
