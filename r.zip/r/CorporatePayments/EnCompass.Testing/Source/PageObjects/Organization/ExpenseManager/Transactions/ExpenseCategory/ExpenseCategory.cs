﻿using Common;
using Common.Utility;
using EnCompass.Testing.Source.PageObjects.Controls;
using NFluent;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EnCompass.Testing.Source.PageObjects.Organization.ExpenseManager.Transactions.ExpenseCategory
{
	public class ExpenseCategory : EnCompassPageModel
	{
		public ExpenseCategory(GlobalSettings settings) : base(settings) { }

        #region XPATH

        public override string RelativeUrl => @"/expenseManager/transactions/expenseCategory/expenseCategory.aspx";
		public override string PageIdentifierXPath_Override => @"//li[@class='breadcrumb-item active'][text() = 'Create Expense Category' or 'Edit Expense Category']";

        private const string _nameXPath = @".//input[contains(@name,'txtName')]";
        private const string _descriptionXPath = @".//textarea[contains(@name,'txtDescription')]";
        public const string _activeRBXPath = @".//input[contains(@id,'_rbStatusActive')]";
        public const string _inactiveRBXPath = @".//input[contains(@id,'_rbStatusInactive')]";
        public const string _activeRBLabelXPath = @".//label[contains(@for,'_rbStatusActive')]";
        public const string _inactiveRBLabelXPath = @".//label[contains(@for,'_rbStatusInactive')]";
        public const string _mccRBXPath = @".//input[@value='rbMcc']";
        private const string _mccMappingXPath = @".//textarea[contains(@name,'txtMccMapping')]";
        public const string _mccGroupRBXPath = @".//input[@value = 'rbMccGroup']";
        public const string _mccGroupRBLabelXPath = @".//label[contains(@for,'rbMccGroup')]";
        private const string _mccGroupSelectBtnXPath = @".//input[contains(@id,'btnSelectMccGroup')]";
        private const string _mccGroupMappingXPath = @".//input[contains(@name,'txtMccGroup')]";
        public const string _reqNoteForEveryTransactionCheckboxXPath = @".//input[contains(@id,'chkRequireNoteForEveryTransaction')]";
        public const string _reqNoteForEveryTransactionLabelXPath = @".//label[contains(@for,'chkRequireNoteForEveryTransaction')]";
        public const string _reqAdditonalNoteCheckboxXPath = @".//input[contains(@id,'chkRequireAdditionalNotes')]";
        public const string _reqAdditonalNoteLabelXPath = @".//label[contains(@for,'chkRequireAdditionalNotes')]";
        private const string _labelForAdditonalNotesXPath = @".//input[contains(@id,'_txtLabelForAdditionalNotes')]";
        private const string _glAccountingFieldXPath = @".//input[contains(@name,'ctlAccountingFields_0')]";
        private const string _ccAccountingFieldXPath = @".//input[contains(@name,'ctlAccountingFields_1')]";
        private const string _noOfSplitsXPath = @".//input[contains(@id,'txtNumberOfSplits')]";
        private const string _applyBtnXPath = @".//input[contains(@id,'btnApplySplitNumber')]";
        public const string _reqNoteForSplitTransCheckboxXPath = @".//input[contains(@id,'chkRequireNoteForEverySplit')]";
        public const string _reqNoteForSplitTransLabelXPath = @".//label[contains(@for,'chkRequireNoteForEverySplit')]";
        private const string _saveBtnXPath = @".//input[contains(@id,'btnSave')]";
        private const string _validationErrorsXPath = @".//div[contains(@id,'_ValidationSummary')]";
        public static string _txtPercent = ".//input[contains(@id,'txtPercent')]";
        public static string _accFeilds = ".//input[contains(@id,'ctlAccountingFields_')]";

        #endregion

        #region IWebElements Props

        public IWebElement _name
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_nameXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_name element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _description
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_descriptionXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_description element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _activeRB
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_activeRBXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_activeRB element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _inactiveRB
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_inactiveRBXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_inactiveRB element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _activeRBLabel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_activeRBLabelXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_activeRBLabel element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _inactiveRBLabel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_inactiveRBLabelXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_inactiveRBLabel element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _mccRB
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_mccRBXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_mccRB element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _mccMapping
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_mccMappingXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_mccMapping element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _mccGroupRB
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_mccGroupRBXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_mccGroupRB element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _mccGroupRBLabel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_mccGroupRBLabelXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_mccGroupRBLabel element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _mccGroupSelectBtn
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_mccGroupSelectBtnXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_mccGroupSelectBtn element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _mccGroupMapping
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_mccGroupMappingXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_mccGroupMapping element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _reqNoteForEveryTransactionCheckbox
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_reqNoteForEveryTransactionCheckboxXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_reqNoteForEveryTransactionCheckbox element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _reqNoteForEveryTransactionLabel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_reqNoteForEveryTransactionLabelXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_reqNoteForEveryTransactionLabel element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _reqAdditonalNoteCheckbox
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_reqAdditonalNoteCheckboxXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_reqAdditonalNoteCheckbox element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _reqAdditonalNoteLabel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_reqAdditonalNoteLabelXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_reqAdditonalNoteLabel element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _labelForAdditonalNotes
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_labelForAdditonalNotesXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_labelForAdditonalNotes element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _glAccountingField
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_glAccountingFieldXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_glAccountingField element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _ccAccountingField
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_ccAccountingFieldXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_ccAccountingField element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _noOfSplits
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_noOfSplitsXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_noOfSplits element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _applyBtn
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_applyBtnXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_applyBtn element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _reqNoteForSplitTransCheckbox
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_reqNoteForSplitTransCheckboxXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_reqNoteForSplitTransCheckbox element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _reqNoteForSplitTransLabel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_reqNoteForSplitTransLabelXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_reqNoteForSplitTransLabel element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _saveBtn
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_saveBtnXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_saveBtn element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _validationErrors
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_validationErrorsXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_validationErrors element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        #endregion


		public string Name
		{
			get	{return _name.GetAttribute("innerText");}
			set	{_name.ForceDocumentLoadOnSendKeys(value, Driver);}
		}

		public string Description
		{
			get { return _description.GetAttribute("innerText"); }
			set
            {
                _description.ForceDocumentLoadOnSendKeys(value, Driver);
                Settings.EnCompassExtentTest.Debug("Description = " + value);
            }
		}

		public string MccMapping
		{
			get { return _mccMapping.GetAttribute("innerText"); }
			set
            {
                _mccMapping.ForceDocumentLoadOnSendKeys(value, Driver);
                Settings.EnCompassExtentTest.Debug("MccMapping = " + value);
            }
		}

		// TODO - MCC Group can be set uisng Iframe popout as well. If that's needed 
		// we would have to add code to do it.
		public string MccGroupMapping
		{
			get { return _mccGroupMapping.GetAttribute("innerText"); }
			set
            {
                _mccGroupMapping.ForceDocumentLoadOnSendKeys(value, Driver);
                Settings.EnCompassExtentTest.Debug("MccGroupMapping = " + value);
            }
		}

		public string GLFinCodeMapping
		{
			get { return _glAccountingField.GetAttribute("innerText"); }
			set
            {
                _glAccountingField.ForceDocumentLoadOnSendKeys(value, Driver);
                Settings.EnCompassExtentTest.Debug("GLFinCodeMapping = " + value);
            }
		}

		public string CCFinCodeMapping
		{
			get { return _ccAccountingField.GetAttribute("innerText"); }
			set
            {
                _ccAccountingField.ForceDocumentLoadOnSendKeys(value, Driver);
                Settings.EnCompassExtentTest.Debug("CCFinCodeMapping = " + value);
            }
		}

		/// <summary>
		/// Opens the window for AccountingFieldLookup page based on the input provided and selects the first Fin Code
		/// available in the page. (the test creates 1 Fin Code)
		/// </summary>
		public void AssignFirstAvailableFinancialCode(string financialCodeName, IWebElement _parent = null)
		{
			IWebElement searchButton;
            searchButton = Driver.FindElement(By.XPath($"//*[contains(@id,'ctlAccountingFields')]//*[text() = '{financialCodeName}']//following-sibling::div//div//button"));

            string xpathTrailing = string.Empty;

            if (financialCodeName == "GL")
                xpathTrailing = "0";
            else if (financialCodeName == "CC")
                xpathTrailing = "1";

            //JSClickWithFocus is not working for that Element
            searchButton.BootstrapClick();
			Settings.EnCompassExtentTest.Info("Click on the Add button to open the list of available codes");
            WaitForFormLoadingOverlay();
			SelectFinancialCodeAvailables();
			Settings.EnCompassExtentTest.Info("Financial code : " + financialCodeName +  " is assigned for the Expense Category.");
            WaitForModalToDisappear();
		}

		/// <summary>
		/// Selects the Financial code from the new window
		/// </summary>
		private void SelectFinancialCodeAvailables()
		{
			string mainWindow = Driver.CurrentWindowHandle; //get the ID of main Window

			//The assign between transaction and financial code open a new window
			//Created new method to Find Elements in different pages
			using (FrameHelper helper = new FrameHelper(Settings.EnCompassWebDriver))
			{
				helper.FindElement(By.XPath("//*[contains(@id,'etCodeValues')]/tbody/tr/td[1]/div/button")).JSClickWithFocus(Driver);
				Settings.EnCompassExtentTest.Info("Finding element on multiple window handles");
				Driver.SwitchTo().Window(mainWindow);
				Settings.EnCompassExtentTest.Info("Switched back to main window handle : Expense Category Page");
			}
		}

        public void SelectMCCGroup()
        {
            // TODO: To be implemented. It requires navigating through the grids ine modal and 
            // picking the RadioButton correspondent to the MCCG Group desired
        }

        public string AdditonalNoteLabel
		{
			set => _labelForAdditonalNotes.ForceDocumentLoadOnSendKeys(value, Driver);
		}

		public string NoOfSplits
		{
			set => _noOfSplits.ForceDocumentLoadOnSendKeys(value, Driver);
		}


		public void ApplySplits()
		{
			_applyBtn.JSClickWithFocus(Driver);
		}

		public GridControl TransactionSplitGrid
		{
			get
			{
				GridControl _transSplitGrid = new GridControl("splitTable", Driver);
				//_transSplitGrid.WaitForGrid();
				return _transSplitGrid;
			}
		}

		public void PressSave()
		{
			_saveBtn.JSClickWithFocus(Driver);
			Settings.EnCompassExtentTest.Info("Clicked on Save button on Expense Category.");
			this.AttachOnDemandScreenShot();
		}

		public string ValidationErrors => _validationErrors.GetAttribute("innerText");

        public void ClickMCCGroupRadio()
        {
            _mccGroupRB.SetRadioButtonStateWithLabel(_mccGroupRBLabel, true);
        }

        public void ClickMCCGroupAddButton()
        {
            _mccGroupSelectBtn.JSClickWithFocus(Driver);
        }

    }

}
