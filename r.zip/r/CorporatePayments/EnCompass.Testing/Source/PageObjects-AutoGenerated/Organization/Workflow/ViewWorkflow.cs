using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using Common;
using Common.PageObjects;
using Common.ScenarioConfigurations;
using Common.Utility;

namespace EnCompass.Testing.Source.PageObjects.Organization.Workflow 
{
	/// <summary>
	/// Auto-generated Page Model Class
	/// Navigation Paths: 
		/// [Organization Home]->UserAccount->
		/// [Organization Home]->UserAccount->->Workflow Items
		/// </summary>
	[PageModel(@"/workflow/viewWorkflow.aspx")]
	public partial class ViewWorkflow : EnCompassOrgPageModel 
	{
		public override string RelativeUrl => @"/workflow/viewWorkflow.aspx";
		public override string PageIdentifierXPath_Generated => @"//li[contains(@class, 'breadcrumb-item active')][text() = 'Workflow Items']";

		#region Navigation
				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Workflow Items']")]
		private IWebElement _useraccount__WorkflowItems { get; set; }
		public void NavigateTo_Useraccount__WorkflowItems()
		{
			NavigateToMenuItem(_useraccount__WorkflowItems);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Messages']")]
		private IWebElement _useraccount__Messages { get; set; }
		public void NavigateTo_Useraccount__Messages()
		{
			NavigateToMenuItem(_useraccount__Messages);
		}

		
		private void NavigateToMenuItem(IWebElement element)
		{
			Driver.Url = element.GetAttribute("href");
		}
		#endregion

		public ViewWorkflow(GlobalSettings settings) : base(settings) { }
	}  
}
