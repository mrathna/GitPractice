﻿using Common;
using Common.Utility;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EnCompass.Testing.Source.PageObjects.Organization.Admin.MccGroups.Testing
{
	class MccGroupTesting : EnCompassOrgPageModel
	{
		public override string RelativeUrl => @"/Admin/MccGroups/Testing/MccGroupTesting.aspx";
		public override string PageIdentifierXPath_Override => @"//li[contains(@class, 'breadcrumb-item active')][text() = 'Merchant Category Code Group']";

		private static string _enableButton = ".//input[contains(@id,'btnEnable')]";

		public void EnableCompanyMCCGs()
		{
			Driver.WaitFor(By.XPath(_enableButton)).Click();
			Settings.EnCompassExtentTest.Info("Clicked on Enable button.");
		}


		public MccGroupTesting(GlobalSettings Setting) : base(Setting) { }
	}
}
