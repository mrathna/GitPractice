using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using Common;
using Common.PageObjects;
using Common.ScenarioConfigurations;
using Common.Utility;

namespace EnCompass.Testing.Source.PageObjects.Organization.Admin.MccGroups 
{
	/// <summary>
	/// Auto-generated Page Model Class
	/// Navigation Paths: 
		/// [Organization Home]->Administration->Merchant Category Codes
		/// [Organization Home]->Administration->Merchant Category Codes->Groups
		/// </summary>
	[PageModel(@"/Admin/MccGroups/Index.aspx")]
	public partial class Index : EnCompassOrgPageModel 
	{
		public override string RelativeUrl => @"/Admin/MccGroups/Index.aspx";
		public override string PageIdentifierXPath_Generated => @"//li[contains(@class, 'breadcrumb-item active')][text() = 'Groups']";

		#region Navigation
				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Groups']")]
		private IWebElement _administration_MerchantCategoryCodes_Groups { get; set; }
		public void NavigateTo_Administration_MerchantCategoryCodes_Groups()
		{
			NavigateToMenuItem(_administration_MerchantCategoryCodes_Groups);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Profiles']")]
		private IWebElement _administration_MerchantCategoryCodes_Profiles { get; set; }
		public void NavigateTo_Administration_MerchantCategoryCodes_Profiles()
		{
			NavigateToMenuItem(_administration_MerchantCategoryCodes_Profiles);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Hierarchy']")]
		private IWebElement _administration_MerchantCategoryCodes_Hierarchy { get; set; }
		public void NavigateTo_Administration_MerchantCategoryCodes_Hierarchy()
		{
			NavigateToMenuItem(_administration_MerchantCategoryCodes_Hierarchy);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Profiles by Card']")]
		private IWebElement _administration_MerchantCategoryCodes_ProfilesByCard { get; set; }
		public void NavigateTo_Administration_MerchantCategoryCodes_ProfilesByCard()
		{
			NavigateToMenuItem(_administration_MerchantCategoryCodes_ProfilesByCard);
		}

		
		private void NavigateToMenuItem(IWebElement element)
		{
			Driver.Url = element.GetAttribute("href");
		}
		#endregion

		public Index(GlobalSettings settings) : base(settings) { }
	}  
}
