package com.framework.pages.BusinessFlow;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.ExtentTest;
import com.framework.basepage.BasePage;
import com.framework.pages.AJS.common.Common;
import com.framework.repo.Locator_SalesForce;
import com.framework.util.PropUtils;

public class SalesForceCommon extends Common {
	
	@FindBy(xpath = Locator_SalesForce.SALESFORCE_ACCOUNTS)
	public WebElement accounts;
	@FindBy(xpath = Locator_SalesForce.SALESFORCE_SELECTED_VIEW)
	public WebElement selectedListView;
	@FindBy(xpath = Locator_SalesForce.SALESFORCE_VIEWS_SEARCH)
	public WebElement viewsSearch;
	@FindBy(xpath = Locator_SalesForce.SALESFORCE_ALL_ACCOUNTS_VIEW)
	public WebElement allAccountsView;
	@FindBy(xpath = Locator_SalesForce.SALESFORCE_SEARCH_TYPE)
	public WebElement searchType;
	@FindBy(xpath = Locator_SalesForce.SALESFORCE_SEARCH_LIST_OPTION)
	public WebElement searchListOption;
	@FindBy(xpath = Locator_SalesForce.SALESFORCE_GLOBAL_SEARCH)
	public WebElement globalSearch;
	@FindBy(xpath = Locator_SalesForce.SALESFORCE_SEARCH)
	public WebElement search;
	@FindBy(xpath = Locator_SalesForce.SALESFORCE_SEARCH_RESULT_ACCOUNT_NO)
	public WebElement accountNoFromSearchResults;
	@FindBy(xpath = Locator_SalesForce.SALESFORCE_SEARCH_RESULT_ACCOUNT_STATUS)
	public WebElement accountStatusFromSearchResults;
	@FindBy(xpath = Locator_SalesForce.SALESFORCE_SEARCH_RESULT_ROW)
	public List<WebElement> rowsSearchResults;
	@FindBy(xpath = Locator_SalesForce.ACCOUNT_CARDS_QUICK_LINK)
	public WebElement cardsQuickLink;
	@FindBy(xpath = Locator_SalesForce.ACCOUNT_NUMBER)
	public WebElement accountNumber;
	@FindBy(xpath = Locator_SalesForce.CARD_HEADER_TITLE)
	public WebElement cardMenuTitle;
	@FindBy(xpath = Locator_SalesForce.FILTER_SEARCH)
	public WebElement searchFilterIcon;
	@FindBy(xpath = Locator_SalesForce.FILTER_SEARCH_CARD_NUMBER)
	public WebElement searchFilterCardField;
	@FindBy(xpath = Locator_SalesForce.FILTER_SEARCH_APPLY)
	public WebElement searchFilterApply;
	@FindBy(xpath = Locator_SalesForce.USER_PROFILE_ICON)
	public WebElement userProfileIcon;
	@FindBy(xpath = Locator_SalesForce.LOGOUT_SALESFORCE)
	public WebElement logOut;
	@FindBy(xpath = Locator_SalesForce.TOOLTIP_FIRST_RESULT)
	public WebElement searchResultToolTipFirst;
	@FindBy(xpath = Locator_SalesForce.SHOW_ALL)
	public List<WebElement> showAll;
	@FindBy(xpath = Locator_SalesForce.ACCNT_ADDRESS)
	public List<WebElement> acctAddress;
	@FindBy(xpath = Locator_SalesForce.SALESFORCE_ACCOUNT_NAME)
	public WebElement accountName;
	@FindBy(xpath = Locator_SalesForce.SF_RELATED_TAB)
	public WebElement relatedTab;
	@FindBy(xpath = Locator_SalesForce.SALESFORCE_SEARCH_RESULT_CARD_NO)
	public WebElement cardNoFromSearchResults;
	
	@FindBy(xpath = Locator_SalesForce.SALESFORCE_SEARCH_RESULT_CARD_STATUS)
	public WebElement cardStatusFromSearchResults;
	
	@FindBy(xpath = Locator_SalesForce.SALESFORCE_USER)
	public WebElement userMenu;
	
	@FindBy(className = Locator_SalesForce.SALESFORCE_LOGOUT)
	public WebElement logoutMenu;
	
	@FindBy(xpath = Locator_SalesForce.SF_ACCOUNT_ADDRESSES_MENU)
	public WebElement accountAddressMenu;
	
	@FindBy(xpath = Locator_SalesForce.SALESFORCE_TRANSACTIONS)
	public WebElement transactions;
	
	@FindBy(xpath = Locator_SalesForce.SALESFORCE_FILTER)
	public WebElement filter;
	
	@FindBy(xpath = Locator_SalesForce.SALAESFORCE_STARTDATE)
	public WebElement startdate;
	
	@FindBy(xpath = Locator_SalesForce.SALESFORCE_APPLY)
	public WebElement apply;
	
	@FindBy(xpath = Locator_SalesForce.SALESFORCE_ENDDATE)
	public WebElement enddate;
	
	
	WebDriverWait wait = new WebDriverWait(driver,30);

	public SalesForceCommon(WebDriver driver, ExtentTest test) {
		super(driver, test);
		PageFactory.initElements(new AjaxElementLocatorFactory(driver, 15), this);
	}
	
	public void navigateToAllAccountsView() {
		
		clickElementWithJs(accounts);
		clickElementWithJs(selectedListView);
		clickElementWithJs(viewsSearch);
		isDisplayedThenEnterText(viewsSearch," view entered","All accounts" );
		clickElementWithJs(allAccountsView);
		
		sleep(10);
		
	}
	
	public void validateSalesForceAccountStatus(String accountNo,String iFCSAccountStatus) {
		
		String sFAccountNo = accountNoFromSearchResults.getText();
		if(accountNo.equals(sFAccountNo)) {
		String sFAccountStatus =	accountStatusFromSearchResults.getText();
		
		if(iFCSAccountStatus.equals("Temp Blocked")) {
			
			if(sFAccountStatus.equals("Temporary Block")) {
				System.out.println("IFCS Account status ++++"+ iFCSAccountStatus+" reflected in Sales force");
				logPass("IFCS Account status ++++"+ iFCSAccountStatus+" reflected in Sales force");
			}
			else {
				System.out.println("IFCS Account status ++++"+ iFCSAccountStatus+" not reflected in Sales force");	
				logFail("IFCS Account status ++++"+ iFCSAccountStatus+" not reflected in Sales force");
			}
		}
		
		System.out.println("Account status ++++"+ sFAccountStatus);
		}
		else {
			System.out.println("Account Number  ++++"+ accountNo+"not available in Sales forces");
			logFail("Account Number  ++++"+ accountNo+"not available in Sales forces");
		}
		
	}

	public void validateSalesForceCardStatus(String cardNo,String iFCSCardStatus) {
		
		String sFCardNo = cardNoFromSearchResults.getText();
		if(cardNo.equals(sFCardNo)) {
		String sFCardStatus =	cardStatusFromSearchResults.getText();
		
		
		
		if(iFCSCardStatus.equals("Card Stolen")) {
			
			if(sFCardStatus.equals("Permanent Block")) {
				System.out.println("IFCS Account status ++++"+ iFCSCardStatus+" reflected in Sales force");
				logPass("IFCS Account status ++++"+ iFCSCardStatus+" reflected in Sales force");
			}
			else {
				System.out.println("IFCS Account status ++++"+ iFCSCardStatus+" not reflected in Sales force");	
				logFail("IFCS Account status ++++"+ iFCSCardStatus+" not reflected in Sales force");
			}
		}
		
		System.out.println("Account status ++++"+ sFCardStatus);
		}
		else {
			System.out.println("Account Number  ++++"+ cardNo+"not available in Sales forces");
			logFail("Account Number  ++++"+ cardNo+"not available in Sales forces");
		}
		
	}
	
	public void GlobalSearchInSalesForce(String searchValue) {
		sleep(10);
	//	clickElementWithJs(searchType);
	//	isDisplayedThenEnterText(searchType," view entered","Accounts" );
		
		clickElementWithJs(globalSearch);
		isDisplayedThenEnterText(globalSearch," text entered",searchValue );
		clickElementWithJs(search);
		
		sleep(10);
	}

	
	public void searchAccountInSalesForce(String searchValue) {
		sleep(10);
	//	clickElementWithJs(searchType);
	//	isDisplayedThenEnterText(searchType," view entered","Accounts" );
		
		clickElementWithJs(globalSearch);
		isDisplayedThenEnterText(globalSearch," text entered",searchValue );
		clickElementWithJs(search);
		
		
		
		sleep(10);
	}
	
	public void clickElementWithJs(WebElement locator) {
		
		wait.until(ExpectedConditions.elementToBeClickable(locator));
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		executor.executeScript("arguments[0].click();", locator);
		
	}

public void searchAndVerifyCardPresence(String cardNumber) {
		Common common = new Common(driver, test);
		Map<String, String> cardDetail = new HashMap<String, String>();
		cardDetail=PropUtils.getPropsAsMap(salesForceValidation);

		String custNo=common.getCustomerNoForCardNumber(cardDetail.get(cardNumber));
		sleep(2);
		isDisplayedThenEnterText(globalSearch, "Search Customer", custNo);
		waitUntilElementDisplayed(searchResultToolTipFirst);
		isDisplayedThenClick(searchResultToolTipFirst, "Search Cust");
		verifyText(accountNumber, custNo);
		isDisplayedThenClick(cardsQuickLink, "Cards Quick Link");
		isDisplayed(cardMenuTitle, "CardsTitle");
		isDisplayedThenClick(searchFilterIcon, "Quick Search");
		isDisplayedThenEnterText(searchFilterCardField, "Search Card", cardDetail.get(cardNumber));
		isDisplayedThenClick(searchFilterApply, "Apply Filter");
		sleep(2);
		if(rowsSearchResults.size()==1) {
			logPass("Card "+cardDetail.get(cardNumber)+" Synced with Sales Force");
		}else 
		{
			logFail("Card "+cardDetail.get(cardNumber)+" Not Synced with Sales Force");
		}
	}
	public void searchAndVerifyUpdatedContact(String custNo) {
		
		Map<String, String> contactDetails = new HashMap<String, String>();
		contactDetails=PropUtils.getPropsAsMap(salesForceValidation);
		String customerNo=contactDetails.get(custNo).split(":")[1];
		String contactName=contactDetails.get(custNo).split(":")[0];
		sleep(2);
		isDisplayedThenEnterText(globalSearch, "Search Customer", customerNo);
		waitUntilElementDisplayed(searchResultToolTipFirst);
		sleep(1);
		isDisplayedThenClick(searchResultToolTipFirst, "Search Cust");
		verifyText(accountNumber, customerNo);
		isDisplayedThenClick(showAll.get(0), "Show All");
		sleep(1);
		isDisplayedThenClick(acctAddress.get(0), "Account Address");
		sleep(1);
		verifyTextPresenceNumOfTimes(contactName, 1, false);
	}

public void searchAndVerifyCustomerPresence(String custNumber) {
		Map<String, String> detail = new HashMap<String, String>();
		detail=PropUtils.getPropsAsMap(salesForceValidation);
		String custNo=detail.get(custNumber);
		sleep(2);
		isDisplayedThenEnterText(globalSearch, "Search Customer", custNo);
		waitUntilElementDisplayed(searchResultToolTipFirst);
		sleep(2);
		isDisplayedThenClick(searchResultToolTipFirst, "Search Cust");

		verifyText(accountNumber, custNo);
		logPass("Customer "+custNo+" Synced with Sales Force");
	}

	/*
	 * Raxsana Added 07/08/2020
	 * Validate newly created contacts sync in Sales force
	 */
	public void validateAccountContacts(String accountNo,String contactName) {
		
		waitToCheckElementIsDisplayed(By.xpath("//span[@class='slds-truncate uiOutputText'][contains(text(),'"+accountNo+"')"),10);
		isDisplayedThenClick(accountName,"Account Name");
		isDisplayedThenClick(relatedTab,"Related Tab");
		isDisplayedThenActionClick(accountAddressMenu,"Account Addresses");
		isDisplayed(driver.findElement(By.xpath("//div[@class='slds-media__body slds-align-middle']/h1[text()='Account Addresses Functionality']")),"account");
		WebElement contactNameElement = driver.findElement(By.xpath("//table//span[@title='"+contactName+"']"));
		isDisplayed(contactNameElement,"Contact Name Text");
		String text=contactNameElement.getText();
		System.out.println(text);
		if(text.equalsIgnoreCase(contactName)) {
			logPass("Account Contacts Synced in SF");
			System.out.println(text);
		}else {
			logFail("Account Contacts Not Synced in SF");
		}
		
	}
	public String getdateformat(String clientCountry)
	{
		// old string format
		String currentdateformat = getCurrentIFCSDateFromDB(clientCountry);

		// parse old string to date
		LocalDate date = LocalDate.parse(currentdateformat, DateTimeFormatter.ofPattern("dd/mm/yyyy"));

		// format date to string
		String newdateformat = date.format(DateTimeFormatter.ofPattern("dd-MMM-yyyy"));

		// print both strings
		System.out.println("Old Date Format: " + currentdateformat);
		System.out.println("New Date Format: " + newdateformat);
		return(newdateformat);
	}

	public void searchTransaction(String newdateformat,int ifcscount)
	{
		isDisplayedThenClick(transactions, "Transactions");
		isDisplayedThenClick(filter, "Filter");
		isDisplayedThenEnterText(startdate, "startdate", newdateformat);
		isDisplayedThenClick(enddate, "END DATE");
		isDisplayedThenClick(apply, "Apply");	
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,1000)");
		List<WebElement> row= driver.findElements(By.xpath("//ttable//tbody//tr"));
		int sfcount = row.size();
		if(ifcscount == sfcount)
		{
			logPass("Transactions synced in SalesForce");
		}
		else
		{
			logFail("Transactions not synced in SalesForce");
		}
		
	}
	
	public void logOutSalesForce() {
		isDisplayedThenClick(userProfileIcon, "User ProfileIco");
		isDisplayedThenClick(logOut, "Log out");
	}
	
}
