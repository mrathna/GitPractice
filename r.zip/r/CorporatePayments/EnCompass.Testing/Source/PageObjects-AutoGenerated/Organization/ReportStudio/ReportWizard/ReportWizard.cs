using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using Common;
using Common.PageObjects;
using Common.ScenarioConfigurations;
using Common.Utility;

namespace EnCompass.Testing.Source.PageObjects.Organization.ReportStudio.ReportWizard 
{
	/// <summary>
	/// Auto-generated Page Model Class
	/// Navigation Paths: 
		/// [Organization Home]->Reports->Report Wizard
		/// </summary>
	[PageModel(@"/ReportStudio/ReportWizard/ReportWizard.aspx")]
	public partial class ReportWizard : EnCompassOrgPageModel 
	{
		public override string RelativeUrl => @"/ReportStudio/ReportWizard/ReportWizard.aspx";
		public override string PageIdentifierXPath_Generated => @"//li[contains(@class, 'breadcrumb-item active')][text() = 'Report Wizard']";

		#region Navigation
				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Step 1: Select Your Focus']")]
		private IWebElement _reports_ReportWizard_Step1SelectYourFocus { get; set; }
		public void NavigateTo_Reports_ReportWizard_Step1SelectYourFocus()
		{
			NavigateToMenuItem(_reports_ReportWizard_Step1SelectYourFocus);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Step 2: Select Your Fields']")]
		private IWebElement _reports_ReportWizard_Step2SelectYourFields { get; set; }
		public void NavigateTo_Reports_ReportWizard_Step2SelectYourFields()
		{
			NavigateToMenuItem(_reports_ReportWizard_Step2SelectYourFields);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Step 3: Group Your Fields']")]
		private IWebElement _reports_ReportWizard_Step3GroupYourFields { get; set; }
		public void NavigateTo_Reports_ReportWizard_Step3GroupYourFields()
		{
			NavigateToMenuItem(_reports_ReportWizard_Step3GroupYourFields);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Step 4: Apply Filters']")]
		private IWebElement _reports_ReportWizard_Step4ApplyFilters { get; set; }
		public void NavigateTo_Reports_ReportWizard_Step4ApplyFilters()
		{
			NavigateToMenuItem(_reports_ReportWizard_Step4ApplyFilters);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Step 5: Format Your Report']")]
		private IWebElement _reports_ReportWizard_Step5FormatYourReport { get; set; }
		public void NavigateTo_Reports_ReportWizard_Step5FormatYourReport()
		{
			NavigateToMenuItem(_reports_ReportWizard_Step5FormatYourReport);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Step 6: Run Your Report']")]
		private IWebElement _reports_ReportWizard_Step6RunYourReport { get; set; }
		public void NavigateTo_Reports_ReportWizard_Step6RunYourReport()
		{
			NavigateToMenuItem(_reports_ReportWizard_Step6RunYourReport);
		}

		
		private void NavigateToMenuItem(IWebElement element)
		{
			Driver.Url = element.GetAttribute("href");
		}
		#endregion

		public ReportWizard(GlobalSettings settings) : base(settings) { }
	}  
}
