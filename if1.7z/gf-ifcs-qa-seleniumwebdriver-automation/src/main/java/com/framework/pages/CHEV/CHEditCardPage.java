
package com.framework.pages.CHEV;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.ExtentTest;
import com.framework.basepage.BasePage;
import com.framework.repo.Locator;

public class CHEditCardPage extends BasePage {

	@FindBy(how = How.XPATH, using = Locator.SCHEDULE_REPORT_MAINTENANCE_PAGE)
	public WebElement editCardPageTitle;

	@FindBy(how = How.XPATH, using = Locator.CH_NEW_CARD_STATUS_DROPDOWN)
	public WebElement cardStatusDropDown;

	@FindBy(how = How.ID, using = Locator.CH_EDIT_CARD_UPDATE_BTN)
	public WebElement updateBtn;

	@FindBy(how = How.ID, using = Locator.CH_POPUP_ACCEPT_BTN)
	public WebElement acceptBtn;

	@FindBy(how = How.XPATH, using = Locator.CH_POPUP_MESSAGE)
	public WebElement editCardPopupTitle;

	@FindBy(how = How.ID, using = Locator.CH_REPLACE_CARD_POPUP_REPLACE_BTN)
	public WebElement replaceBtn;

	@FindBy(how = How.ID, using = Locator.CH_REPLACE_CARD_POPUP_DONOT_REPLACE_BTN)
	public WebElement donotReplaceBtn;

	@FindBy(how = How.ID, using = Locator.CH_REPLACE_CARD_POPUP_TITLE)
	public WebElement replacePopUpTitle;

	@FindBy(how = How.XPATH, using = Locator.CH_RELPACE_CONFIRM_ERROR_MESSAGE)
	public WebElement confirmationErrorMessage;

	@FindBy(how = How.XPATH, using = Locator.CH_CHANGE_STATUS_SUCCESS_MSG)
	public WebElement replaceCardConfirmationSucessMessage;
	
	@FindBy(how = How.ID, using = Locator.AN_EXISTING_ACCOUNT_LIST)
	public WebElement accountEditCard;
	
	@FindBy(how = How.XPATH, using = Locator.LISTED_TRANSACTIONS_WITH_CARD)
	public List<WebElement> cardNumPresent;

	@FindBy(how = How.ID, using = Locator.CHV_CARDS_TABLE)
	public WebElement chvCardTable;
	
	@FindBy(how = How.ID, using = Locator.CHV_CARDS_NO)
	public WebElement chvCardNoPass;
	
	@FindBy(how = How.ID, using = Locator.REPORTS_SEARCH)
	public WebElement searchBtn;
	
	@FindBy(how = How.ID, using = Locator.CHV_CARDS_NO)
	public WebElement cardNum;
	
	@FindBy(how = How.ID, using = Locator.LICENSE_PLATE_FILTER_FIELD)
	public WebElement regNo;
	
	@FindBy(how = How.XPATH, using = Locator.CHV_REG_NO)
	public WebElement regNoTable;
	
	@FindBy(how = How.ID, using = Locator.CHV_CARD_TABLE_POPUP)
	public WebElement cardNumPopUp;
	
	@FindBy(how = How.XPATH, using = Locator.CHV_CARD_EDIT_TABLE_POPUP)
	public WebElement editInPopUp;
	
	@FindBy(how = How.ID, using = Locator.CHV_CARD_TABLE)
	public WebElement cardNumTable;
	
	@FindBy(how = How.XPATH, using = Locator.CH_VIEW_CARD_ODOMETER_TITLE)
	public WebElement odometerBox;
	
	@FindBy(how = How.ID, using = Locator.CDA_TITLE)
	public WebElement contactTitle;
	
	@FindBy(how = How.ID, using = Locator.CDA_CONTACT_NAME)
	public WebElement contactName;
	
	@FindBy(how = How.ID, using = Locator.CDA_CONTACT_ADDRESS)
	public WebElement contactAddress;
	
	@FindBy(how = How.XPATH, using = Locator.CDA_SATE)
	public WebElement contactState;
	
	@FindBy(how = How.XPATH, using = Locator.CDA_COUNTRY)
	public WebElement contactCountry;
	
	@FindBy(how = How.ID, using = Locator.CH_POPUP_CANCEL_BTN)
	public WebElement cancelBtn;
	
	@FindBy(how = How.XPATH, using = Locator.CHV_CARD_SUCCESS_MSG)
	public WebElement successMsg;
	
	@FindBy(how = How.ID, using = Locator.CHV_CARD_BACK_TO_CARD)
	public WebElement backEditButton;
	
	@FindBy(how = How.XPATH, using = Locator.CHV_CARD_DETAIL_TABLE_POPUP)
	public WebElement cardDetailsInPopUp;
	
	@FindBy(how = How.XPATH, using = Locator.CHV_CARD_PAGE_TITLE)
	public WebElement cardPageTitle;
	
	@FindBy(how = How.XPATH, using = Locator.CHV_VIEW_CARD_TITLE)
	public WebElement viewCardTitle;
	
	@FindBy(how = How.XPATH, using = Locator.CHV_DELIVERY_ADDRESS)
	public WebElement deliveryAddress;
	
	@FindBy(how = How.XPATH, using = Locator.CHV_DELIVERY_NAME_TITLE)
	public WebElement deliveryNameTitle;
	
	@FindBy(how = How.XPATH, using = Locator.CHV_DELIVERY_COUNTRY_STATE)
	public WebElement deliveryCountryState;
	
	@FindBy(how = How.ID, using = Locator.CARD_PURCHASE_PRODUCTS_DURING_TIME)
	public WebElement purchaseTimeLimit;
	
	@FindBy(how = How.ID, using = Locator.REGO_NUMBER_FIELD)
	public WebElement regNoLicensePlate;
	
	@FindBy(how = How.ID, using = Locator.CARD_INFORMATION_DRIVER_NAME)
	public WebElement driverNameInEditcard;
	
	String CardNumberChoose;
	String fakeTitle=fakerAPI().expression("Permanant Details");
	String fakeName=fakerAPI().name().fullName();
	String fakeAddress=fakerAPI().address().fullAddress();
	String stateDropDown,countryDropDown;
	
	
	public CHEditCardPage(WebDriver driver, ExtentTest test) {
		super(driver, test);
		PageFactory.initElements(driver, this);
	} 

	public void verifyPageTitle(String pageTitle) {
		if (editCardPageTitle.isDisplayed()) {
			String actualTitle = editCardPageTitle.getText();
			if (actualTitle.equals(pageTitle)) {
				logPass("Edit Card Page title is displayed");
			} else {
				logFail("Edit Card Page title is not displayed");
			}

		}
	}

	public void changeCardStatus(String optionValue) {
		selectDropDownByVisibleText(cardStatusDropDown, optionValue);
		scrollDownPage();
		if (updateBtn.isDisplayed()) {
			actionClick(updateBtn);
			logInfo("Update Button is clicked");
		} else {
			logFail("Update Button is not displayed");
		}

	}

	public void verifyEditCardStatusPopupMessage() {
		sleep(10);
		waitForElementTobeClickable(acceptBtn, 20);
		if (editCardPopupTitle.isDisplayed()) {
			logPass("Edit Status Accept Popup message is displayed");
		} else {
			logFail("Edit Status Accept Popup message is not displayed");
		}
	}

	public void clickOnAcceptButtonIneditStatusPopup() {
		sleep(10);
		isDisplayedThenActionClick(acceptBtn, "Clicked the ACCEPT button in Card status popup");
	}

	public void verifyEditCardStatusReplacePopupMessage() {
		sleep(5);
		waitForElementTobeClickable(replaceBtn, 20);
		if (replacePopUpTitle.isDisplayed()) {
			logPass("Edit Status Replace Popup message is displayed");
		} else {
			logFail("Edit Status Replace Popup message is not displayed");
		}
	}

	public void clickOnReplaceButtonIneditStatusReplacePopup() {
		sleep(5);
		isDisplayedThenActionClick(replaceBtn, "Clicked the REPLACE button in Card status popup");
	}
	
	public void clickOnDonotReplaceButtonIneditStatusReplacePopup() {
		sleep(5);
		isDisplayedThenActionClick(donotReplaceBtn, "Clicked the REPLACE button in Card status popup");
	}

	public void verifyErrorConfirmationMessage(String message) {
		sleep(5);
		if (confirmationErrorMessage.isDisplayed()) {
			String actualText = confirmationErrorMessage.getText();
			if (actualText.equals(message)) {
				System.out.println(actualText);
				logPass(message + "is displayed");
			} else {
				logFail(message + "is not displayed");
			}
		} else {
			logFail(message + "is not displayed");
		}
	}
	
	public void verifySuccessConfirmationMessage(String message) {
		sleep(5);
		if (replaceCardConfirmationSucessMessage.isDisplayed()) {
			String actualText = replaceCardConfirmationSucessMessage.getText();
			if (actualText.equals(message)) {
				System.out.println(actualText);
				logPass(message + "is displayed");
			} else {
				logFail(message + "is not displayed");
			}
		} else {
			logFail(message + "is not displayed");
		}
	}
	
	
	public void selectAccountFromDropdownAndValidateCard() {

		isDisplayed(accountEditCard, "Account Drop down in home page");

		int size = getDropdownSize(accountEditCard);

		if (size > 1) {
			String accountName = selectedStringFrmDropDown(accountEditCard);
			System.out.println("accountName ---- " + accountName);
			sleep(5);
			selectDifferentValueInsteadOfDefault(accountEditCard, accountName, "");
			sleep(3);
			String accname2 = selectedStringFrmDropDown(accountEditCard);
			sleep(5);
			if (!accountName.contains(accname2)) {
				logInfo("Account 1 = " + accountName + " Different Account selected ---=" + accname2);
				logPass("Different Account Selected");
			}

			else {
				logInfo("Account 1 = " + accountName + " Different Account selected ---=" + accname2);
				logFail("Different Account is not selected");
			}
		} else {
			logInfo("accountDropdown in home page has only one option");
		}
	}
	
	public boolean getACardNumberFromTable() {
		int randomNo = 0;
		boolean isTablePresent = true;
		sleep(10);
		if (getRowSize(chvCardTable) > 1) {
			setCellDataFromTable(chvCardTable, 8, true);
			int cardWithTransaction = cardNumPresent.size();
			logInfo("Listed Card:" + cardWithTransaction);
			if (cardWithTransaction > 1) {
				randomNo = getRandomNumber(0, cardNumPresent.size() - 1);
			}
		 CardNumberChoose = getText(cardNumPresent.get(randomNo));
		} else {
			logInfo("No Transactions present");
			isTablePresent = false;
		}
		return isTablePresent;
	}
	
	public void enterACardNumberInSearchFilter() {
		isDisplayedThenEnterText(chvCardNoPass, "Card number", CardNumberChoose);
	}
	
	public void clickSearchButtonAndValidate() {
		isDisplayedThenActionClick(searchBtn, "Click Search Button");
	}
	
	public void cardStatusInFindCards()
	{
		selectDropDownByVisibleText(cardStatusDropDown, "Active");
		logInfo("Status Changed to active");
		isDisplayedThenActionClick(searchBtn, "Click Search Button");
	}
	
	public void cardNoPickEnterandValidate()
	{
		String CardNo;
		for(int i=1;i<=20;i++)
		{
			CardNo=getCellDataFromTable(i,0,true);
			if(CardNo.isEmpty())
			{
				logInfo("Selected Acc no:"+CardNo);
				enterText(cardNum,CardNo);
				break;
			}
			else {
				logInfo("Card Number not present");		
			}
		}
	}
	
	public void getVehRegNoFromTableAndSearch()
	{
		String textfromTable=getText(regNoTable);
		enterText(regNo,textfromTable);
		isDisplayedThenActionClick(searchBtn, "Click Search Button");
	}
	
	
	public void verifySearchResults() {
		String cardNumberinTable = getText(cardNumTable);
		if (cardNumberinTable.contains(getText(cardNum))) {
			logPass("Same results present");
		} else {
			logInfo("Same results are not present");
		}
	}
	
	public void editPageInCardTable()
	{
		sleep(3);
		actionClick(cardNumTable);
		if(cardNumPopUp.isDisplayed())
			logPass("Card pop up appeared");
		actionClick(editInPopUp);
			logPass("Edit option clicked");
	}
	
	public void verifyEditCardText()
	{
		verifyPageTitle("Edit Card");
		
	}
	
	public void disableFields()
	{
		checkAnElementIsDisabled(odometerBox,"Odometer");
		checkAnElementIsDisabled(regNoLicensePlate,"License Plate");
		checkAnElementIsDisabled(driverNameInEditcard,"Driver Name");
	}
	
	public void purchaseControlsTimeLimit()
	{
		selectDropDownByIndex(purchaseTimeLimit,1);
	}
	
	public void permanentAddressFill()
	{
		sleep(2);
			enterText(contactTitle,fakeTitle);
			enterText(contactName,fakeName);		
			enterText(contactAddress,fakeAddress);
			selectDropDownByIndex(contactState,1);
			stateDropDown=selectedStringFrmDropDown(contactState);
			countryDropDown=selectedStringFrmDropDown(contactCountry);
			selectDropDownOptionsRandomly(contactState,"state");
			selectDropDownOptionsRandomly(contactCountry,"country");
	}
	
	
	public void updateClick()
	{
		sleep(3);
		actionClick(updateBtn);
		logPass("Update Button is clicked");
	}
	
	public void clickOnCancelButtonIneditStatusPopup() {
		sleep(5);
		isDisplayedThenActionClick(cancelBtn, "Clicked the Cancel button in Card status popup");
		
	}
	
	public void successMsg()
	{
		sleep(3);
		isDisplayed(successMsg,"Success!");
		
	}

	public void backToCardListLink()
	{
			actionClick(backEditButton);
			logPass("Clicked the back button");
			sleep(3);
	}
	
	public void viewCardDetailsInTable()
	{
		actionClick(cardNumTable);
		if(cardNumPopUp.isDisplayed())
			logPass("Card pop up appeared");
		actionClick(cardDetailsInPopUp);
			logPass("Card Details clicked");
	}
	
	public void cardsPageValidatePageTitle()
	{
		verifyText(cardPageTitle,"Cards");
	}
	
	public void viewCardValidateTitle() {
		sleep(5);
		isDisplayed(viewCardTitle,"View Card");
		
	}
	
	public void deliveryAddressUpdatedCheck() {
		
		isDisplayed(deliveryNameTitle,fakeTitle+" "+fakeName);
		isDisplayed(deliveryAddress,fakeAddress);
		isDisplayed(deliveryCountryState,stateDropDown+", "+countryDropDown);
		
	}

}
