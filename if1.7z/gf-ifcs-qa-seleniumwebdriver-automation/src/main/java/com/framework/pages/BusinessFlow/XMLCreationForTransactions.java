package com.framework.pages.BusinessFlow;

import java.io.File;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.openqa.selenium.WebDriver;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.aventstack.extentreports.ExtentTest;
import com.framework.basepage.BasePage;
import com.framework.pages.AJS.common.Common;
import com.framework.pages.AJS.common.CommonInterfacePage;
import com.framework.pages.AJS.common.IFCSCommonPage;
import com.framework.pages.AJS.common.IFCSHomePage;
import com.framework.pages.AJS.common.InterfacePage;
import com.framework.util.PropUtils;
import com.github.javafaker.Faker;

public class XMLCreationForTransactions extends BasePage {
	
	public XMLCreationForTransactions(WebDriver driver, ExtentTest test) {
		super(driver, test);
	}


	public Map<String,String> inputValuesForInvalidProductCode(String clientName,String clientCountry){
		Map<String,String> inputValues =new HashMap<String,String>()  ;
		Map<String, String> lineItem = null;
		String locNumber = null;
		String cardNumber = null;
		Common common = new Common(driver, test);
		CommonInterfacePage CommonInterfacePage = new CommonInterfacePage(driver, test);
		
		cardNumber = common.getCardNumberFromIFCSDB(clientName, clientCountry,"Active");
		System.out.println("card number::"+cardNumber);
		inputValues.put("CardNumber", cardNumber);
		
		lineItem = CommonInterfacePage.getTransactionLineItem(configProp, cardNumber, clientName,
			clientCountry);
		inputValues.putAll(lineItem);
		
		if (clientName.equalsIgnoreCase("Chevron")) { 
			 locNumber = common.getExternalRefNoFromDB(clientName, clientCountry);
			 } else { 
				 locNumber  = common.getLocationNoFromIFCSDB(clientName, clientCountry,
		  lineItem.get("productCode")); 
				 }
		inputValues.put("LocationNumber", locNumber);

		//String invalidProductCode=common.getInvalidProductCodeFromIFCSDB(clientName,clientCountry,locNumber);//"00";//fakerAPI().number().digits(3);
		//System.out.println("invalid product code::"+invalidProductCode);
		//inputValues.put("productCode", invalidProductCode);		
				
		System.out.println("inputValues::"+inputValues);
		
		return inputValues;
	}
	
	
	/*public Map<String, String> xmlCreationForPostingTransaction(String clientName, String clientCountry,String filename,String seqNo) {
		
		Map<String, String> lineItem = null;
		Map<String, String> valuesForValidation = new LinkedHashMap<String, String>();

		String cardNumber = null;
		int k;
		int netValue = 0;
		String refNo = null;
		Faker faker = new Faker();
		Element subtag = null;
		Element loadCardTransactionsubtag = null;
		String locNumber = null;
		String valueDateAndTime = null;
		Common common = new Common(driver, test);
		CommonInterfacePage CommonInterfacePage = new CommonInterfacePage(driver, test);
		

		String[] headertag = { "FileName", "SequenceNumber", "RecordCount", "CountryCode", "StartDate", "StartTime",
				"ExternalSupplier", "SettlementDate", "ExternalFileName" };
		String[] loadTransaction = { "Transaction", "Card", "Location", "Terminal", "Vehicle", "TransactionLineItem" };
		String[] card = { "CardNumber", "CardType" };
		String[] transaction = { "CaptureTypeCode", "TransactionCode", "AttentionKey", "ReferenceNumber", "OrderNumber",
				"FleetNumber", "SubEntityNumber", "TransactionDateTime", "AuthorisationNumber", "OdometerReading",
				"BatchNumber", "BatchSource", "ExtraCardNo" };
		String[] location = { "IdassNumber", "StreetAddressState", "RetailSiteId", "MarketingTerritory", "AdminTerritory" };
		String[] terminal = { "PhysicalTerminalId", "TerminalStatus", "TerminalType" };
		String[] vehicle = { "RegistrationNumber", "CurrentOdometerReading" };
		String[] lineitem = { "LineItemCode", "Quantity", "UnitPrice", "NetValue" };
		
		String clientNameInProp = PropUtils.getPropValue(configProp, clientName + "_" + clientCountry);
		System.out.println(clientNameInProp);
		

		String date = CommonInterfacePage.funcFetchLoadCardTransStartDateFromIFCSDB(configProp, clientNameInProp);
		System.out.println("DateWithTime::" + date);
	
		try {
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			Document doc = docBuilder.newDocument();
			Element rootElement = doc.createElement("LoadCardTransactions");
			doc.appendChild(rootElement);

			Element header = doc.createElement("Header");
			rootElement.appendChild(header);
			

			for (k = 0; k < headertag.length; k++) {
				subtag = doc.createElement(headertag[k]);
				if (headertag[k].equalsIgnoreCase("FileName")) {
					System.out.println(
							"file Name:" +filename);
					subtag.setTextContent(filename);
				} else if (headertag[k].equalsIgnoreCase("SequenceNumber")) {
					subtag.setTextContent(seqNo);
				} else if (headertag[k].equalsIgnoreCase("RecordCount")) {
					subtag.setTextContent(Integer.toString(01));
				} else if (headertag[k].equalsIgnoreCase("CountryCode") && clientName.equalsIgnoreCase("CHEVRON")) {
					subtag.setTextContent("CHEV" + "_" + clientCountry);
				} else if (headertag[k].equalsIgnoreCase("CountryCode")) {
					subtag.setTextContent(clientCountry);
				} else if (headertag[k].equalsIgnoreCase("StartDate")) {
					subtag.setTextContent(date.split(" ")[0]);
				} else if (headertag[k].equalsIgnoreCase("StartTime")) {
					subtag.setTextContent(date.split(" ")[1]);
				} else if (headertag[k].equalsIgnoreCase("ExternalSupplier")) {
					String externalSupplier = CommonInterfacePage.getExternalSupplier(clientName, clientCountry);
					subtag.setTextContent(externalSupplier);
				} else if (headertag[k].equalsIgnoreCase("SettlementDate")) {
					subtag.setTextContent(date.split(" ")[0]);
				} else if (headertag[k].equalsIgnoreCase("Identifier")
						&& (clientName.equalsIgnoreCase("EMAP") || clientName.equalsIgnoreCase("OTI"))) {
					subtag.setTextContent("Y");
				}

				header.appendChild(subtag);
			}
			
			for (int i = 0; i < 1; i++) {
					cardNumber = common.getActiveCardNumberFromIFCSDB(clientName, clientCountry);
					lineItem = CommonInterfacePage.getTransactionLineItem(configProp, cardNumber, clientName,
						clientCountry);
				
				 if (clientName.equalsIgnoreCase("Chevron")) { 
					 locNumber = common.getExternalRefNoFromDB(clientName, clientCountry);
					 } else { 
						 locNumber  = common.getLocationNoFromIFCSDB(clientName, clientCountry,
				  lineItem.get("productCode")); 
						 }
				 

				Element loadCardTransaction = doc.createElement("LoadCardTransaction");
				
				for (int j = 0; j < loadTransaction.length; j++) {

					loadCardTransactionsubtag = doc.createElement(loadTransaction[j]);
					if (loadTransaction[j].equalsIgnoreCase("Transaction")) {
						for (k = 0; k < transaction.length; k++) {
							subtag = doc.createElement(transaction[k]);
							if (transaction[k].equalsIgnoreCase("TransactionDateTime")) {
								valueDateAndTime = CommonInterfacePage
										.funcFetchLoadCardTransStartDateFromIFCSDB(configProp, clientNameInProp);
								subtag.setTextContent(valueDateAndTime.replace(" ", "T"));
							} else if (transaction[k].equalsIgnoreCase("AuthorisationNumber")) {
								String value = faker.number().digits(6);
								subtag.setTextContent(value);
							} else if (transaction[k].equalsIgnoreCase("ReferenceNumber")) {
								refNo = common.getUniqReferenceNumber();
								System.out.println("Ref No:" + refNo);
								subtag.setTextContent(refNo);
							} else if (transaction[k].equalsIgnoreCase("BatchNumber")) {
								String value = faker.number().digits(6);
								subtag.setTextContent(value);
							} else if (transaction[k].equalsIgnoreCase("BatchSource")) {
								if (clientCountry.equals("NZ") && clientName.equals("BP")) {
									subtag.setTextContent("POS");
								} else if (clientCountry.equals("MY") && clientName.equals("CHEVRON")) {
									subtag.setTextContent("AMB");
								} else {
									subtag.setTextContent("EFT");
								}
							} else if (clientCountry.contains("ZEnergy")
									&& transaction[k].equalsIgnoreCase("OriginalAmount")) {
								// depends on TransactionLineItems
							} else if (transaction[k].equalsIgnoreCase("CaptureTypeCode")) {
								if ((clientName.equalsIgnoreCase("CHEVRON") && clientCountry.equalsIgnoreCase("MY"))
										|| clientName.equalsIgnoreCase("BP")) {
									String value = PropUtils.getPropValue(loadCardTransactionPurchaseProp,
											"TRANSCODE_PURCHASE_" + clientName + clientCountry);
									subtag.setTextContent(value.split(",")[1]);
								} else {
									String value = PropUtils.getPropValue(loadCardTransactionPurchaseProp,
											"TRANSCODE_PURCHASE_" + clientName);
									subtag.setTextContent(value.split(",")[1]);
								}

							} else if (transaction[k].equalsIgnoreCase("TransactionCode")) {
								if ((clientName.equalsIgnoreCase("CHEVRON") && clientCountry.equalsIgnoreCase("MY"))
										|| clientName.equalsIgnoreCase("BP")) {
									String value = PropUtils.getPropValue(loadCardTransactionPurchaseProp,
											"TRANSCODE_PURCHASE_" + clientName + clientCountry);
									subtag.setTextContent(value.split(",")[0]);
								} else {
									String value = PropUtils.getPropValue(loadCardTransactionPurchaseProp,
											"TRANSCODE_PURCHASE_" + clientName);
									subtag.setTextContent(value.split(",")[0]);
								}
							}
							loadCardTransactionsubtag.appendChild(subtag);
						}

					}

					if (loadTransaction[j].equalsIgnoreCase("Card")) {
						for (k = 0; k < card.length; k++) {
							subtag = doc.createElement(card[k]);
							if (card[k].equalsIgnoreCase("CardNumber")) {

								subtag.setTextContent(cardNumber);
							}
							loadCardTransactionsubtag.appendChild(subtag);
						}
					}
					if (loadTransaction[j].equalsIgnoreCase("Location")) {
						for (k = 0; k < location.length; k++) {
							subtag = doc.createElement(location[k]);
							if (location[k].equals("IdassNumber")) {
								subtag.setTextContent(locNumber);
							}

							if (clientName.equalsIgnoreCase("Chevron")) {
								if (location[k].equals("RetailSiteId")) {
									subtag.setTextContent(locNumber);
								}
							}
							loadCardTransactionsubtag.appendChild(subtag);
						}
					}

					if (loadTransaction[j].equalsIgnoreCase("Terminal")) {
						for (k = 0; k < terminal.length; k++) {
							subtag = doc.createElement(terminal[k]);
							if (clientName.equalsIgnoreCase("BP")) {

								if (terminal[k].equals("PhysicalTerminalId")) {
									subtag.setTextContent("77");

								}
							}
							loadCardTransactionsubtag.appendChild(subtag);
						}
					}
					if (loadTransaction[j].equalsIgnoreCase("Vehicle")) {
						for (k = 0; k < vehicle.length; k++) {
							subtag = doc.createElement(vehicle[k]);
							loadCardTransactionsubtag.appendChild(subtag);
						}
					}

					if (loadTransaction[j].equalsIgnoreCase("TransactionLineItem")) {

						for (k = 0; k < lineitem.length; k++) {
							Element TransactionLineItemsSubtag = doc.createElement(lineitem[k]);
							String invalidProductCode=common.getInvalidProductCodeFromIFCSDB(clientName,clientCountry,locNumber);
							System.out.println("invalid product code::"+invalidProductCode);
							if (lineitem[k].equalsIgnoreCase("LineItemCode")) {
								System.out.println("prdcode" + invalidProductCode);
								TransactionLineItemsSubtag.setTextContent(invalidProductCode);
							}
							if (lineitem[k].equalsIgnoreCase("Quantity")) {
								TransactionLineItemsSubtag.setTextContent(lineItem.get("volume"));
							}
							if (lineitem[k].equalsIgnoreCase("UnitPrice")) {
								TransactionLineItemsSubtag.setTextContent(lineItem.get("unitPrice"));
							}
							if (lineitem[k].equalsIgnoreCase("NetValue")) {
								System.out.println("volume" + Integer.parseInt(lineItem.get("volume")));
								System.out.println("unit price" + Integer.parseInt(lineItem.get("unitPrice")));
								netValue = ((Integer.parseInt(lineItem.get("volume")) / 100)
										* ((Integer.parseInt(lineItem.get("unitPrice")) / 100)) / 100);
								System.out.println("net value::" + netValue);
								TransactionLineItemsSubtag.setTextContent(Integer.toString(netValue) + "00");
							}
							valuesForValidation.put(refNo, String.valueOf(netValue) + "00");
							loadCardTransactionsubtag.appendChild(TransactionLineItemsSubtag);
						}
					}

					loadCardTransaction.appendChild(loadCardTransactionsubtag);
				}

				rootElement.appendChild(loadCardTransaction);

			}
			writeContentInXmlFile(doc,filename);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return valuesForValidation;
	}

	public void writeContentInXmlFile(Document doc, String filename) {
		try {
			DOMSource source = new DOMSource(doc);
			StreamResult result = new StreamResult(new File("LoadCardTransaction.xml"));

			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer = transformerFactory.newTransformer();
			// Beautify the format of the resulted XML
			transformer.setOutputProperty(OutputKeys.INDENT, "yes");
			transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "4");
			transformer.transform(source, result);

			result = new StreamResult(new File(System.getProperty("user.home") + System.getProperty("file.separator")
					+ "Documents" + System.getProperty("file.separator") + filename));
			System.out.println(filename);
			transformer.transform(source, result);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}*/
	
	
	public Map<String, String> XMLCreationForTransaction(String clientName, String clientCountry,
			Map<String, String> inputvalues) throws TransformerException {

		Map<String, String> dbvalue = null;
		//Map<String, String> lineItem = null;
		Map<String, String> valuesForValidation = new LinkedHashMap<String, String>();
		String folderName = null, jobsInOrder = null;

		//String cardNumber = null;
		int k;
		Common common = new Common(driver, test);
		//Map<String, String> cardList = new HashMap<String, String>();
		IFCSCommonPage ifcsCommonPage = new IFCSCommonPage(driver, test);
		// cardList = common.readDataFromPropertyFile("card_" + clientName + "_" +
		// clientCountry, cardOrderedFile);
		CommonInterfacePage CommonInterfacePage = new CommonInterfacePage(driver, test);
		InterfacePage interfacePage = new InterfacePage(driver, test);
		IFCSHomePage ifcsHomePage = new IFCSHomePage(driver, test);
		String clientNameInProp = PropUtils.getPropValue(configProp, clientName + "_" + clientCountry);
		System.out.println(clientNameInProp);
		int netValue = 0;
		String refNo = null;

		String[] headertag = { "FileName", "SequenceNumber", "RecordCount", "CountryCode", "StartDate", "StartTime",
				"ExternalSupplier", "SettlementDate", "ExternalFileName" };
		String[] loadTransaction = { "Transaction", "Card", "Location", "Terminal", "Vehicle", "TransactionLineItem" };
		String[] card = { "CardNumber", "CardType" };
		String[] transaction = { "CaptureTypeCode", "TransactionCode", "AttentionKey", "ReferenceNumber", "OrderNumber",
				"FleetNumber", "SubEntityNumber", "TransactionDateTime", "AuthorisationNumber", "OdometerReading",
				"BatchNumber", "BatchSource", "ExtraCardNo" };
		String[] location = { "IdassNumber", "StreetAddressState", "RetailSiteId", "MarketingTerritory",
				"AdminTerritory" };
		String[] terminal = { "PhysicalTerminalId", "TerminalStatus", "TerminalType" };
		String[] vehicle = { "RegistrationNumber", "CurrentOdometerReading" };
		String[] lineitem = { "LineItemCode", "Quantity", "UnitPrice", "NetValue" };
		String date = CommonInterfacePage.funcFetchLoadCardTransStartDateFromIFCSDB(configProp, clientNameInProp);

		String folderid = CommonInterfacePage.getfolderid(clientName, clientCountry);
		int cardListCount = 1;
		/*
		 * int cardListCount = cardList.size(); if (cardListCount == 0) { cardListCount
		 * = 1; }
		 */

		String client_mid = CommonInterfacePage.funcFetchLoadCardTransClientMidFromDB(configProp, clientName,
				clientCountry);
		String remotedir;
		if (clientName.equalsIgnoreCase("BP")) {
			remotedir = PropUtils.getPropValue(configProp, "IFCS_LOADCARDTRANSACTION") + folderid + "/";
		} else {
			remotedir = PropUtils.getPropValue(configProp, "IFCS_LOADCARDTRANSACTION") + client_mid + "/" + folderid
					+ "/";
		}
		try {
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			Document doc = docBuilder.newDocument();
			// students root element
			Element rootElement = doc.createElement("LoadCardTransactions");
			doc.appendChild(rootElement);

			Element header = doc.createElement("Header");
			rootElement.appendChild(header);
			dbvalue = CommonInterfacePage.fetchLoadCardTransSeqNoandPrefix(configProp, clientName, clientCountry,
					folderid);
			String filename = dbvalue.get("prefixvalue") + dbvalue.get("lastSequenceNumber") + ".xml";
			System.out.println(dbvalue);
			for (k = 0; k < headertag.length; k++) {
				Element subtag = doc.createElement(headertag[k]);
				if (headertag[k].equalsIgnoreCase("FileName")) {
					// String folderid=CommonInterfacePage.getfolderid(clientName,clientCountry);
					System.out.println(
							"file Name:" + dbvalue.get("prefixvalue") + dbvalue.get("lastSequenceNumber") + ".xml");
					subtag.setTextContent(dbvalue.get("prefixvalue") + dbvalue.get("lastSequenceNumber") + ".xml");
				} else if (headertag[k].equalsIgnoreCase("SequenceNumber")) {
					subtag.setTextContent(dbvalue.get("lastSequenceNumber"));
				} else if (headertag[k].equalsIgnoreCase("RecordCount")) {
					subtag.setTextContent(Integer.toString(cardListCount));
				} else if (headertag[k].equalsIgnoreCase("CountryCode") && clientName.equalsIgnoreCase("CHEVRON")) {
					subtag.setTextContent("CHEV" + "_" + clientCountry);
				} else if (headertag[k].equalsIgnoreCase("CountryCode")) {
					subtag.setTextContent(clientCountry);
				} else if (headertag[k].equalsIgnoreCase("StartDate")) {
					subtag.setTextContent(date.split(" ")[0]);
				} else if (headertag[k].equalsIgnoreCase("StartTime")) {
					subtag.setTextContent(date.split(" ")[1]);
				} else if (headertag[k].equalsIgnoreCase("ExternalSupplier")) {
					String externalSupplier = CommonInterfacePage.getExternalSupplier(clientName, clientCountry);
					subtag.setTextContent(externalSupplier);
				} else if (headertag[k].equalsIgnoreCase("SettlementDate")) {
					subtag.setTextContent(date.split(" ")[0]);
				} else if (headertag[k].equalsIgnoreCase("Identifier")
						&& (clientName.equalsIgnoreCase("EMAP") || clientName.equalsIgnoreCase("OTI"))) {
					subtag.setTextContent("Y");
				}

				header.appendChild(subtag);
			}
			Faker faker = new Faker();
			Element subtag = null;
			Element loadCardTransactionsubtag = null;
			//String locNumber;

			//Object[] values = cardList.values().toArray();
			for (int i = 0; i < cardListCount; i++) {

				Element loadCardTransaction = doc.createElement("LoadCardTransaction");

				for (int j = 0; j < loadTransaction.length; j++) {

					loadCardTransactionsubtag = doc.createElement(loadTransaction[j]);
					if (loadTransaction[j].equalsIgnoreCase("Transaction")) {
						for (k = 0; k < transaction.length; k++) {
							subtag = doc.createElement(transaction[k]);
							if (transaction[k].equalsIgnoreCase("TransactionDateTime")) {
								String value = CommonInterfacePage.funcFetchLoadCardTransStartDateFromIFCSDB(configProp,
										clientNameInProp);
								subtag.setTextContent(value.replace(" ", "T"));
							} else if (transaction[k].equalsIgnoreCase("AuthorisationNumber")) {
								String value = faker.number().digits(6);
								subtag.setTextContent(value);
							} else if (transaction[k].equalsIgnoreCase("ReferenceNumber")) {
								refNo = common.getUniqReferenceNumber();
								System.out.println("Ref No:" + refNo);
								subtag.setTextContent(refNo);
							} else if (transaction[k].equalsIgnoreCase("BatchNumber")) {
								String value = faker.number().digits(6);
								subtag.setTextContent(value);
							} else if (transaction[k].equalsIgnoreCase("BatchSource")) {
								if (clientCountry.equals("NZ") && clientName.equals("BP")) {
									subtag.setTextContent("POS");
								} else if (clientCountry.equals("MY") && clientName.equals("CHEVRON")) {
									subtag.setTextContent("AMB");
								} else {
									subtag.setTextContent("EFT");
								}
							} else if (clientCountry.contains("ZEnergy")
									&& transaction[k].equalsIgnoreCase("OriginalAmount")) {
								// depends on TransactionLineItems
							} else if (transaction[k].equalsIgnoreCase("CaptureTypeCode")) {
								if ((clientName.equalsIgnoreCase("CHEVRON") && clientCountry.equalsIgnoreCase("MY"))
										|| clientName.equalsIgnoreCase("BP")) {
									String value = PropUtils.getPropValue(loadCardTransactionPurchaseProp,
											"TRANSCODE_PURCHASE_" + clientName + clientCountry);
									subtag.setTextContent(value.split(",")[1]);
								} else {
									String value = PropUtils.getPropValue(loadCardTransactionPurchaseProp,
											"TRANSCODE_PURCHASE_" + clientName);
									subtag.setTextContent(value.split(",")[1]);
								}

							} else if (transaction[k].equalsIgnoreCase("TransactionCode")) {
								if ((clientName.equalsIgnoreCase("CHEVRON") && clientCountry.equalsIgnoreCase("MY"))
										|| clientName.equalsIgnoreCase("BP")) {
									String value = PropUtils.getPropValue(loadCardTransactionPurchaseProp,
											"TRANSCODE_PURCHASE_" + clientName + clientCountry);
									subtag.setTextContent(value.split(",")[0]);
								} else {
									String value = PropUtils.getPropValue(loadCardTransactionPurchaseProp,
											"TRANSCODE_PURCHASE_" + clientName);
									subtag.setTextContent(value.split(",")[0]);
								}
							}
							loadCardTransactionsubtag.appendChild(subtag);
						}

					}

					if (loadTransaction[j].equalsIgnoreCase("Card")) {
						for (k = 0; k < card.length; k++) {
							subtag = doc.createElement(card[k]);
							if (card[k].equalsIgnoreCase("CardNumber")) {

								subtag.setTextContent(inputvalues.get("CardNumber"));
								valuesForValidation.put(refNo, inputvalues.get("CardNumber"));
							}
							loadCardTransactionsubtag.appendChild(subtag);
						}
					}
					if (loadTransaction[j].equalsIgnoreCase("Location")) {
						for (k = 0; k < location.length; k++) {
							subtag = doc.createElement(location[k]);
							if (location[k].equals("IdassNumber")) {
								subtag.setTextContent(inputvalues.get("LocationNumber"));
							}

							if (clientName.equalsIgnoreCase("Chevron")) {
								if (location[k].equals("RetailSiteId")) {
									subtag.setTextContent(inputvalues.get("LocationNumber"));
								}
							}
							loadCardTransactionsubtag.appendChild(subtag);
						}
					}

					if (loadTransaction[j].equalsIgnoreCase("Terminal")) {
						for (k = 0; k < terminal.length; k++) {
							subtag = doc.createElement(terminal[k]);
							if (clientName.equalsIgnoreCase("BP")) {

								if (terminal[k].equals("PhysicalTerminalId")) {
									subtag.setTextContent("77");

								}
							}
							loadCardTransactionsubtag.appendChild(subtag);
						}
					}
					if (loadTransaction[j].equalsIgnoreCase("Vehicle")) {
						for (k = 0; k < vehicle.length; k++) {
							subtag = doc.createElement(vehicle[k]);
							loadCardTransactionsubtag.appendChild(subtag);
						}
					}

					if (loadTransaction[j].equalsIgnoreCase("TransactionLineItem")) {

						for (k = 0; k < lineitem.length; k++) {
							Element TransactionLineItemsSubtag = doc.createElement(lineitem[k]);
							// System.out.println("cardNumber::"+cardNumber);

							if (lineitem[k].equalsIgnoreCase("LineItemCode")) {
								System.out.println("prdcode" + inputvalues.get("productCode"));
								TransactionLineItemsSubtag.setTextContent(inputvalues.get("productCode"));
							}
							if (lineitem[k].equalsIgnoreCase("Quantity")) {
								TransactionLineItemsSubtag.setTextContent(inputvalues.get("volume"));
							}
							if (lineitem[k].equalsIgnoreCase("UnitPrice")) {
								TransactionLineItemsSubtag.setTextContent(inputvalues.get("unitPrice"));
							}
							if (lineitem[k].equalsIgnoreCase("NetValue")) {
								System.out.println("volume" + Integer.parseInt(inputvalues.get("volume")));
								System.out.println("unit price" + Integer.parseInt(inputvalues.get("unitPrice")));
								netValue = ((Integer.parseInt(inputvalues.get("volume")) / 100)
										* ((Integer.parseInt(inputvalues.get("unitPrice")) / 100)) / 100);
								System.out.println("net value::" + netValue);
								TransactionLineItemsSubtag.setTextContent(Integer.toString(netValue) + "00");
							}
							/* valuesForValidation.put(refNo, String.valueOf(netValue) + "00"); */
							loadCardTransactionsubtag.appendChild(TransactionLineItemsSubtag);
						}
					}

					loadCardTransaction.appendChild(loadCardTransactionsubtag);
				}

				rootElement.appendChild(loadCardTransaction);

			}

			// Write the content into XML file
			DOMSource source = new DOMSource(doc);
			StreamResult result = new StreamResult(new File("LoadCardTransaction.xml"));

			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer = transformerFactory.newTransformer();
			// Beautify the format of the resulted XML
			transformer.setOutputProperty(OutputKeys.INDENT, "yes");
			transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "4");
			transformer.transform(source, result);

			result = new StreamResult(new File(System.getProperty("user.home") + System.getProperty("file.separator")
					+ "Documents" + System.getProperty("file.separator") + filename));
			System.out.println(filename);
			transformer.transform(source, result);

			ifcsCommonPage.establishThePuttyConnectionbyUserGeneratedRemoteDirectory("XML", "PUTTY_HOST",
					"PUTTY_USERNAME", "PUTTY_PASSWORD", remotedir, filename);

			ifcsCommonPage.interfaceBatchJobwithIFCSLogin(clientName, clientCountry, folderid);
			ifcsHomePage.exitIFCS();
			if (clientName.equals("BP") || clientName.equals("CHEVRON")) {
				folderName = ifcsCommonPage.getControlMFolder(clientName, clientCountry,
						"jobS_LoadcardTransactions_" + clientName + "_" + clientCountry);
				jobsInOrder = ifcsCommonPage
						.getJobsOfFolderInOrder("jobS_LoadcardTransactions_" + clientName + "_" + clientCountry);
			} else {
				folderName = ifcsCommonPage.getControlMFolder(clientName, clientCountry,
						"jobS_LoadcardTransactions_" + clientName);
				jobsInOrder = ifcsCommonPage.getJobsOfFolderInOrder("jobS_LoadcardTransactions_" + clientName);
			}
			interfacePage.establishAndExecuteControlMJobs("ControlM_AWS_UAT", "ContorlM_AWS_userName",
					"ContorlM_AWS_password", folderName, jobsInOrder);

		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return valuesForValidation;
	}
}
