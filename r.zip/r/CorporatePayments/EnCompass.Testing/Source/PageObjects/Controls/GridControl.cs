﻿using Common.Utility;
using NFluent;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EnCompass.Testing.Source.PageObjects.Controls
{
	public class GridControl
	{
		private string _controlIdentifier;
		private IWebDriver _driver;

		public string _baseRowXPath;
		public string _baseRowXPathForGridsWithMultipleChildRows;
		private string _baseTableHeaderXPath;
		private string _noSelectionXPath;
		private string _baseRowActionXPath;
		private string _currentPageXPath;
		private string _nextPageXPath;
		private string _previousPageXPath;
		private string _pageSizeXPath;
		private string _tableHeaderIdentifier;
		private string _headerSortingXPath;
		private string _UXbaseTableHeaderXPath;


		public int CurrentPage
		{
			get
			{
				var element = _driver.FindElement(By.XPath(_currentPageXPath));
				int pageNumber;
				if (int.TryParse(element.Text, out pageNumber))
				{
					return pageNumber;
				}
				else
				{
					throw new Exception("Unable to evaluate the 'CurrentPage', the value could not be parsed to an integer.");
				}
			}
		}

		public bool HasNextPage
		{
			get
			{
				return _driver.IsElementPresent(By.XPath(_nextPageXPath));
			}
		}

		public bool HasPreviousPage
		{
			get
			{
				return _driver.IsElementPresent(By.XPath(_previousPageXPath));
			}
		}

		public event EventHandler PagingActionTriggered;
		public event EventHandler RowActionTriggered;

		public GridControl(string controlIdentifier, IWebDriver driver)
		{
			_controlIdentifier = controlIdentifier;
			_driver = driver;

			InitializeXPaths();
		}

		public void WaitForGrid()
		{
			_driver.WaitForVisible(By.XPath(_baseTableHeaderXPath));
		}

		public void LoadNextPage()
		{
			if (HasNextPage)
			{
				var element = _driver.FindElement(By.XPath(_nextPageXPath));
				element.Click();
				PagingActionTriggered?.Invoke(this, EventArgs.Empty);
			}
		}

		public void LoadPreviousPage()
		{
			if (HasPreviousPage)
			{
				var element = _driver.FindElement(By.XPath(_previousPageXPath));
				element.JSClickWithFocus(_driver);
				PagingActionTriggered?.Invoke(this, EventArgs.Empty);
			}
		}

        public void SelectFirstRow()
        {
            _driver.TryWaitForElementToBeVisible(By.XPath(_baseRowXPath + "[1]"), out IWebElement elementInRow);
            elementInRow.JsScrollToElement(_driver);
            IWebElement colToClick = GetColumnsWithoutLinks(elementInRow).First();
            Check.That(colToClick).IsNotNull();
            colToClick.JSClickWithFocus(_driver);
        }

        /*This method was created because Selenium element.Click() clicks in the middle of the element
         and for some grids the middle of the row is an hyperlink, which is causing some tests to failure when the test is trying to select it.*/
        private IEnumerable<IWebElement> GetColumnsWithoutLinks(IWebElement row)
        {
            /*This Xpath starts from the grid row element, from that it discovers all columns with elements inside it
             * It's ignoring the ones tagged with 'invisibleLink' because those ones doesn't trigger anything while it's clicked.
             * After that, we returned to the column level and then we exclude them from the original columns list. */


            var columnsWithElements = row.FindElements(By.XPath("./td[not(@class='gridHideColumn')]/child::*[not(@class='invisibleLink')]/parent::td"));
            var columns = row.FindElements(By.XPath("./td[not(@class='gridHideColumn')]"));
            return columns.Except(columnsWithElements);
        }

        public void SelectRow(int whichRow)
		{
			var elementInRow = _driver.FindElement(By.XPath(_baseRowXPath + "[" + whichRow.ToString() + "]"));
			elementInRow.JsScrollToElement(_driver);
            GetColumnsWithoutLinks(elementInRow).First().JSClickWithFocus(_driver);
		}

        public void SelectRowWithMultipleChild(int whichRow)
        {
            var elementInRow = _driver.FindElement(By.XPath(_baseRowXPathForGridsWithMultipleChildRows + "[" + whichRow.ToString() + "]"));
			elementInRow.JsScrollToElement(_driver);
			GetColumnsWithoutLinks(elementInRow).First().JSClickWithFocus(_driver);
        }

        public void SelectRowContaining(params string[] textList)
		{
			var rowElement = GetRowContaining(textList);
			rowElement.JsScrollToElement(_driver);
            GetColumnsWithoutLinks(rowElement).First().JSClickWithFocus(_driver);
		}

		/// <summary>
		/// This method Selects the row THAT HAS EXACT TEXT IN THE <TD></TD> CELLS. IT ALSO TAKES THE INSTANCE OF FOUND RECORD THAT NEEDS TO BE CLICKED.
		/// </summary>
		/// <param name="whichInstance"></param>
		/// <param name="textList"></param>
		public void SelectRowExactly(int whichInstance, params string[] textList)
		{
			var rowElement = GetRowExactly(whichInstance, textList);
			rowElement.JsScrollToElement(_driver);
			GetColumnsWithoutLinks(rowElement).First().Click();

		}

		/// <summary>
		/// This method BUILDS returns the EXACTLY MATCHED ROW XPATH from the TABLE GRID based on the passed COLUMN VALUES.
		/// </summary>
		/// <param name="instance"></param>
		/// <param name="textList"></param>
		/// <returns></returns>
		public IWebElement GetRowExactly(int instance, params string[] textList)
		{
			var individualCriteria = textList.Select(s => $"/./td[text()='{s}']/ancestor::tr");
			var combinedCriteria = (string.Join(string.Empty, individualCriteria).Substring(5) + $")[{instance}]");

			var rowElement = _driver.FindElement(By.XPath($@"({_baseRowXPath}//*{combinedCriteria}"));
			rowElement.JsScrollToElement(_driver);
			return rowElement;
		}

		public IWebElement GetRowContaining(params string[] textList)
		{
            var individualCriteria = textList.Select(s => $"[contains(text(), '{s}')]");
            var combinedCriteria = string.Join(string.Empty, individualCriteria);
            var rowXpath = $@"{_baseRowXPath}//*{combinedCriteria}/ancestor::tr[1]";
            _driver.WaitElementBeClickable(rowXpath);
            var rowElement = _driver.FindElement(By.XPath(rowXpath));
            rowElement.JsScrollToElement(_driver);
            return rowElement;
		}

		public IWebElement GetRow(int index)
		{
            _driver.TryWaitForElementToBeVisible(By.XPath($@"{_baseRowXPath}[{index + 1}]"), out IWebElement rowElement);
            rowElement.JsScrollToElement(_driver);
			return rowElement;
		}

        /// <summary>
        /// This method returns the ROW from the TABLE GRID with multiple child rows based on the passed row index value
        /// </summary>
        public IWebElement GetRowWithMultipleChildRows(int index)
        {
            var rowElement = _driver.FindElement(By.XPath($@"{_baseRowXPathForGridsWithMultipleChildRows}[{index}]"));
            return rowElement;
        }
        /// <summary>
        /// Exceptional cases where row.FindElement do not work and rather appending the xpath
        /// to the xpath of the base row element works.  e.g.  Invoiced Grid while creating Mlogs
        /// </summary>
        public IWebElement GetSpecificColInRowIdentifiedByXpath(int index, string additionalXpath)
		{
			var rowElement = _driver.FindElement(By.XPath($@"{_baseRowXPath}[{index + 1}]" + additionalXpath));
			return rowElement;
		}

		public IEnumerable<IWebElement> GetRows()
		{
			var rowElements = _driver.WaitForElements(By.XPath($@"{_baseRowXPath}"));
			return rowElements;
		}
		public IEnumerable<IWebElement> GetRowsWithChild()
		{
			var rowElements = _driver.WaitForElements(By.XPath($@"{_baseRowXPathForGridsWithMultipleChildRows}"));
			return rowElements;
		}


		public bool DoesRowContainingTextExist(string whatText)
		{
			if (_driver.TryFindElement(By.XPath($@"{_tableHeaderIdentifier}//*[a[contains(text(), '{whatText.Trim()}')] or td[contains(text(), '{whatText.Trim()}')]]"), out IWebElement element))
				return true;
			else
				return false;
		}

		public bool DoesRowContainingTextExist(string whatText, int whichRow = 1)
		{
			if (_driver.TryFindElement(By.XPath($@"({_tableHeaderIdentifier}//*[a[contains(text(), '{whatText.Trim()}')] or td[contains(text(), '{whatText.Trim()}')]])[{whichRow}]"), out IWebElement element))
				return true;
			else
				return false;
		}

		/*	$ % $ % $ % $ % $ % $ % $ % $ % $ % $ % $ % $ % $ % $ % $ % $ % $ % $ % $ % $ % $ % $ % $ % $ % $ % $ % $ % $ % $ % $ % $ % $ % $ % $ % $ % $ % $ % $ % $ % $ % $ % $ % */
		/// <summary>
		/// This method returns an array of strings if passed the 'COLUMN HEADER NAME'.
		/// NOTE: ANY HIDDEN COLUMN(S) BEYOND ON THE INSPECTED COLUMN RESULTS IN WRONG COLUMN DATA. IF SO THIS METHOD NEEDS TO BE RE-VISITED.
		/// </summary>
		/// <param name="headerName"></param>
		/// <returns></returns>
		public IEnumerable<string> GetColumnText(string colHeaderName, bool multipleChildRows = false)
		{
			List<string> results = new List<string>();
			var cells =  (multipleChildRows) ? GetColumnByHeaderText(colHeaderName, multipleChildRows) : GetColumnByHeaderText(colHeaderName);
			IWebElement innerElement;
			foreach (var cell in cells)
			{
				if (cell.TryFindElement(By.XPath(@"./*[not(contains(@class,'sr-only'))][1]"), out innerElement))
				{
					if (innerElement.TagName.Equals("select", StringComparison.InvariantCultureIgnoreCase))
					{
						results.Add(new SelectElement(innerElement).SelectedOption.Text);
					}
					else if (innerElement.TagName.Equals("input", StringComparison.InvariantCultureIgnoreCase))
					{
						results.Add(innerElement.GetAttribute("value"));
					}
					else if (innerElement.TagName.Equals("td", StringComparison.InvariantCultureIgnoreCase))
					{
						results.Add(new SelectElement(innerElement.FindElement(By.XPath(@"select"))).SelectedOption.Text);
					}
                    else if (innerElement.TagName.Equals("span", StringComparison.InvariantCultureIgnoreCase))
                    {
                        if (String.IsNullOrEmpty(innerElement.Text))
                        {
                            //IWebElement _parent = innerElement.FindElement(By.XPath(@"/parent::*"));
                            //results.Add(_parent.Text);
                            results.Add(cell.Text);
                        }
                        else
                            results.Add(innerElement.Text);
                    }
                    else if (innerElement.TagName.Equals("br", StringComparison.InvariantCultureIgnoreCase))
					{
						// Add the parent's text if the inner element is a break line
						results.Add(cell.Text);
					}
					else if (innerElement.TagName.Equals("div", StringComparison.InvariantCultureIgnoreCase))
					{
						if (innerElement.TryFindElement(By.XPath(@"select"), out IWebElement subElement))
							results.Add(new SelectElement(subElement).SelectedOption.Text);
						else if (innerElement.TryFindElement(By.XPath(@"span"), out IWebElement subElementSpan))
							results.Add(subElementSpan.Text);
						else
							results.Add(innerElement.Text);
					}
					else
					{
						results.Add(innerElement.Text);
					}
				}
				else
				{
					results.Add(cell.Text);
				}
			}
			return results;
		}

		/// <summary>
		/// This method CHECKS THE CHECKBOX PRESENT IN THE HEADER and NOT THE COLUMN.
		/// </summary>
		/// <param name="checkboxIdentifierText"></param>
		/// <param name="check"></param>
		public void SetCheckboxColumn(string checkboxIdentifierText, bool check)
		{
			// This method will check the checkbox in the Header.
			if (_driver.TryFindElement(By.XPath($@"//input[@type='checkbox' and contains(@id, '{checkboxIdentifierText}')]"), out IWebElement myHeaderCheckbox))
			{
				myHeaderCheckbox.JsScrollToElement(_driver);
				myHeaderCheckbox.SetCheckboxStateWithLabelJS(_driver, check);
			}
		}

		/// <summary>
		/// Checks any checkbox present in the specified row in a grid.
		/// Set _chkBoxLabel to false if you DO NOT want the CBLabel to be used, else it will find out the Label Element
		/// and then try to check the CB
		/// </summary>
		public void SetCheckboxInTable(string checkboxIdentifierText, int rowNumber, bool checkboxState, string typeIdentifer = "id", bool _chkBoxLabel = false)
		{
			if (_driver.TryFindElement(By.XPath($@"{_baseRowXPath}[{rowNumber}]//input[@type='checkbox'][contains(@{typeIdentifer}, '{checkboxIdentifierText}')]"), out IWebElement cbElement))
			{
                _driver.ScrollToXPATH($@"{ _baseRowXPath}[{rowNumber}]//input[@type='checkbox'][contains(@{typeIdentifer}, '{checkboxIdentifierText}')]");
                if (!_chkBoxLabel)			
                cbElement.SetCheckboxStateWithLabelJS(_driver, checkboxState);
				else
				{
					// Find the Label for the corresponding CB first
					if(_driver.TryFindElement(By.XPath($@"{_baseRowXPath}[{rowNumber}]//label[contains(@for,'{_controlIdentifier}')]"), out IWebElement cbLabel))
					{
						cbElement.SetCheckboxStateWithLabel(cbLabel, checkboxState);
					}
				}
			}
		}

		private string GetColumnByHeaderTextHelper(string colHeaderName)
		{
			string[] headerBAseXPaths = { String.Format(@"{0}[@aria-label='{1}{2}']", _UXbaseTableHeaderXPath, colHeaderName, "{0}"), String.Format(@"{0}[contains(text(), '{1}{2}')]", _baseTableHeaderXPath, colHeaderName, "{0}") };

			foreach (string head in headerBAseXPaths)
			{
				var headerBaseXPath = head;
				IWebElement element = null;
				var tries = 0;

				List<string> headerNames = new List<string>()
				{
					String.Format(headerBaseXPath,string.Empty),
					String.Format(headerBaseXPath," Sortable"),
					String.Format(headerBaseXPath," Descending"),
					String.Format(headerBaseXPath," Ascending"),
					String.Format(headerBaseXPath," Sorted Descending"),
					String.Format(headerBaseXPath," Sorted Ascending"),
				};

				while (element == null && tries < 6)
				{
					_driver.TryFindElement(By.XPath(headerNames.ElementAt(tries)), out element);
					tries++;
				}

				if (element != null)
					return headerNames.ElementAt(tries - 1);
			}

			//return headerNames.ElementAt(0);
			return string.Empty;
		}


		private IEnumerable<IWebElement> GetColumnByHeaderText(string colHeaderName, bool multipleChildRows = false)
		{
			string newHeaderName = GetColumnByHeaderTextHelper(colHeaderName);

			//var precedingHeaderXPath = $@"{_baseTableHeaderXPath}[@aria-label='{colHeaderName}']/ancestor-or-self::*[self::td or self::th][1]/preceding-sibling::*";
			var precedingHeaderXPath = $@"{newHeaderName}/ancestor-or-self::*[self::td or self::th][1]/preceding-sibling::*";
			var precedingHeaders = _driver.FindElements(By.XPath(precedingHeaderXPath));
			var anyPrecedingHidden = precedingHeaders.Any(h => !h.Displayed);
			int headerIndex = precedingHeaders.Count + 1; //Header position
			IEnumerable<IWebElement> allRows = null;
			if (!multipleChildRows)
				allRows = GetRows(); // Get all the rows to be used later.
			else
				allRows = GetRowsWithChild(); // Get all the rows to be used later.

			if (!allRows.Any())
			{
				return new List<IWebElement>(); // Return empty list if there are no elements.
			}

			if (!anyPrecedingHidden)
			{
				headerIndex += allRows.First().FindElements(By.XPath("td")).Count(e => !e.Displayed); // Find hidden columns and add that count to the main header index.
			}

			//return allRows.Select(s => s.FindElement(By.XPath($"td[{headerIndex}]")).Text); // Return the column TEXT collection.
			List<string> results = new List<string>();
			return allRows.Select(s => s.FindElement(By.XPath($"td[{headerIndex}]")));
		}

		public int GetColumnHeaderIndex(string colHeaderName)
		{
			var precedingHeaderXPath = $@"{_baseTableHeaderXPath}[contains(@aria-label, '{colHeaderName}')]/ancestor-or-self::*[self::td or self::th][1]/preceding-sibling::*";
			var precedingHeaders = _driver.FindElements(By.XPath(precedingHeaderXPath));
			var anyPrecedingHidden = precedingHeaders.Any(h => !h.Displayed);
			int headerIndex = precedingHeaders.Count + 1; //Header position
			var allRows = GetRows(); // Get all the rows to be used later.
			if (!allRows.Any())
			{
				return -1; // Return -1 if there are no elements.
			}

			if (anyPrecedingHidden)
			{
				headerIndex += allRows.First().FindElements(By.XPath("td")).Count(e => !e.Displayed); // Find hidden columns and add that count to the main header index.
				return headerIndex;
			}
			else
			{
				return headerIndex;
			}
		}

		/// <summary>
		/// This method simply checks if the COLUMN HEADER is present in the grid and if so returns TRUE else FALSE.
		/// </summary>
		/// <param name="colHeaderName"></param>
		/// <returns></returns>
		public bool DoesHeaderColumnExist(string colHeaderName)
		{
			//var precedingHeaderXPath = $@"{_baseTableHeaderXPath}[@aria-label='{colHeaderName}' or contains(text(), '{colHeaderName}')]/ancestor-or-self::*[self::td or self::th][1]/preceding-sibling::*";
			//var precedingHeaders = _driver.FindElements(By.XPath(precedingHeaderXPath));

			//if (precedingHeaders.Count == 0)
			//	return false;
			//else
			//	return true;
			return HeaderColumnExist(colHeaderName);
		}

		/// <summary>
		/// This method simply checks if the COLUMN HEADER is present in the grid and if so returns TRUE else FALSE.
		/// </summary>
		/// <param name="colHeaderName"></param>
		/// <returns></returns>
		public bool HeaderColumnExist(string colHeaderName)
		{
			var precedingHeaderXPath = $@"{_baseTableHeaderXPath}[@aria-label='{colHeaderName}' or contains(text(), '{colHeaderName}')]";
			var precedingHeaders = _driver.FindElements(By.XPath(precedingHeaderXPath));

			if (precedingHeaders.Count == 0)
				return false;
			else
				return true;
		}

		/*	$ % $ % $ % $ % $ % $ % $ % $ % $ % $ % $ % $ % $ % $ % $ % $ % $ % $ % $ % $ % $ % $ % $ % $ % $ % $ % $ % $ % $ % $ % $ % $ % $ % $ % $ % $ % $ % $ % $ % $ % $ % $ % */

		public void PerformActionByText(string text)
		{
			var actionElement = _driver.FindElement(By.XPath($@"{_baseRowActionXPath}[text() = '{text}']"));
			// We should not use the regular Bootstrap click here because - upon selecting a grid row by default certain
			// buttons/actions gets pre-selected. Bootstrp click would attempt to do a Keys.Enter first, which would invoke the wrong action.
			// Eg :  On emulate User grid, the "Edit" button is default selection when user clicks on a row.
			//actionElement.JSClickWithFocus(_driver);
            actionElement.JSClickWithFocus(_driver);
            RowActionTriggered?.Invoke(this, EventArgs.Empty);
		}

        public bool IsActionAvailableByText(string text)
        {
            return _driver.IsElementPresent(By.XPath($@"{_baseRowActionXPath}[text() = '{text}']"));
        }

		public void PerformActionByClass(string cssClass)
		{
			var actionElement = _driver.FindElement(By.XPath($@"{_baseRowActionXPath}[contains(@class, '{cssClass}')]"));
			actionElement.JSClickWithFocus(_driver);
			RowActionTriggered?.Invoke(this, EventArgs.Empty);
		}

		public void PerformActionByHref(string partialHref)
		{
			var actionElement = _driver.FindElement(By.XPath($@"{_baseRowActionXPath}[contains(@href, '{partialHref}')]"));
			actionElement.JSClickWithFocus(_driver);
			RowActionTriggered?.Invoke(this, EventArgs.Empty);
		}

		public void PerformActionByOnClick(string partialText)
		{
			var actionElement = _driver.FindElement(By.XPath($@"{_baseRowActionXPath}[contains(@onclick, '{partialText}')]"));
			actionElement.JSClickWithFocus(_driver);
			RowActionTriggered?.Invoke(this, EventArgs.Empty);
		}

		public void SetPageSize(int size)
		{
			var sizeElements = _driver.FindElements(By.XPath(_pageSizeXPath));
			var select = new SelectElement(sizeElements.First());
			select.SelectByValue(size.ToString());
			sizeElements = _driver.FindElements(By.XPath(_pageSizeXPath)); // re-initializing to make sure the following statement executes without the STALE ELEMENT EXCEPTION.
			var idOfSecond = sizeElements.Last().GetAttribute("id");
			_driver.WaitFor(By.XPath($@"//select[@id='{idOfSecond}']/option[@selected='selected'][@value='{size}']"));
		}

		public string GetCurrentSortingOnColumn(string columnName)
		{
            string columnHeader_Xpath = $@"{_headerSortingXPath}";
            //Substring will throw invalid length if the text doesn't contains space. Thus, updating to Split for handling string without spaces
            if (_driver.TryFindElement(By.XPath(columnHeader_Xpath), out IWebElement element))
			{
				return element.GetAttribute(@"aria-sort");
			} 
			else
			{
				return null;
			}
		}

		public string ClickColumnForSorting(string columnName)
		{            
            if (_driver.TryFindElement(By.XPath($@"{_headerSortingXPath}/a[contains(text(), '{columnName.Trim()}')]"), out IWebElement element))
			{
				element.JSClickWithFocus(_driver);
				WaitForGrid();
                //Substring will throw invalid length if the text doesn't contains space. Thus, updating to Split for handling string without spaces
                _driver.TryFindElement(By.XPath($@"{_headerSortingXPath}/a[contains(text(), '{columnName.Trim()}') or contains(text(), '{columnName.Trim().Split(new char[] {' '})[0]}')]"), out element);
				return element.GetAttribute(@"aria-label");
			}
			else
			{
				return null;
			}
		}

		private void InitializeXPaths()
		{
			_currentPageXPath = $@"//table[contains(@id, '{_controlIdentifier}')]//div[contains(@id, 'EDGPager')]/span";
			_nextPageXPath = $@"{_currentPageXPath}/following-sibling::*[1]";
			_previousPageXPath = $@"{_currentPageXPath}/preceding-sibling::*[1]";
			_noSelectionXPath = $@"//div[contains(@id,'{_controlIdentifier}')][@class='emptyActionText']";
			_baseRowActionXPath = $@"//a[contains(@id,'{_controlIdentifier}')][@role='menuitem']";
			_baseRowXPath = $@"//table[contains(@id,'{_controlIdentifier}')]/tbody/tr[not(contains(@id, 'Pager'))][not(contains(@class, 'Pager'))]"; // Added the 'not contains' based on class attribute [Inventory] page grid.
			_baseRowXPathForGridsWithMultipleChildRows = $@"//table[contains(@id,'{_controlIdentifier}')]/tbody/tr[not(contains(@id, '_R'))][not(contains(@class, 'Pager'))]"; // Eg Transaction Grid Table
			_pageSizeXPath = $@"//table[contains(@id, '{_controlIdentifier}')]//select[contains(@id, 'pageSize')]";
			_baseTableHeaderXPath = $@"//table[contains(@id,'{_controlIdentifier}')]/thead/tr//*";
			_tableHeaderIdentifier = $@"//table[contains(@id,'{_controlIdentifier}')]";
			_headerSortingXPath = @"//table[contains(@class, 'floatThead')]//*[contains(@class, 'sort')]";
			//UX new 
			_UXbaseTableHeaderXPath = $@"//table[contains(@id,'{_controlIdentifier}')]/thead/tr/th";
		}

        public bool ColumnContainsValue(string column, string value)
        {
            var columnResult = GetColumnText(column);
            return columnResult.Contains(value.Trim());
        }

        /// <summary>
        /// This method is used over here because at Firefox it was a necessity for the row to be visible on screen to be clicked. 
        /// </summary>
        
        public void ScrollToXPATH(string xpath)
        {
            var element = _driver.WaitFor(By.XPath(xpath));
            // Trying luck on javascript injection
            ((IJavaScriptExecutor)_driver).ExecuteScript("arguments[0].scrollIntoView(true);", element);

            // now fallback using selenium actions scroll
            Actions actions = new Actions(_driver);
            actions.MoveToElement(element);
            actions.Build().Perform();
        }
    }
}
