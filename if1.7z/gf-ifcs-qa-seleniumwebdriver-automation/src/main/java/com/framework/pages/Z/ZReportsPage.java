package com.framework.pages.Z;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.ExtentTest;
import com.framework.basepage.BasePage;
import com.framework.repo.Locator;
import com.framework.util.PropUtils;

public class ZReportsPage extends BasePage {
	
	@FindBy(id=Locator.HOME_MENU_BP)
	public WebElement homeMenu;

	@FindBy(id=Locator.ADD_SCHEDULE_REPORT_BUTTON)
	public WebElement addScheduleReport;
	
	@FindBy(id=Locator.BACK_TO_SCHEDULE_REPORT_LINK)
	public WebElement backToScheduleReportList;
	
			
	@FindBy(how = How.XPATH, using = Locator.Z_REPORT_NAME)
	public WebElement reportName;
	
	@FindBy(id=Locator.SEARCH_CARDS)
	public WebElement searchCards;	

	@FindBy(how = How.XPATH, using = Locator.REPORT_TABLE_LIST)
	public List<WebElement> adhocReportsList;

	@FindBy(how = How.XPATH, using = Locator.SCHEDULE_REPORT_MAINTENANCE_PAGE)
	public WebElement storedReportsPageTitle;

	@FindBy(how = How.ID, using = Locator.REPORT_GENERATE)
	public WebElement reportGenerate;

	@FindBy(how = How.ID, using = Locator.BACK_TO_ADHOC_REPORT_LINK)
	public WebElement backToAdhocReportsPage;

	@FindBy(how = How.ID, using = Locator.ADHOC_REPORTS_EXPORT)
	public WebElement adhocReportExportLink;

	@FindBy(how = How.XPATH, using = Locator.ADHOC_REPORTS_TITLE) 
	public WebElement bulkOrderTitle;
	
	@FindBy(how = How.XPATH, using = Locator.Z_DELIVERY_ADDRESS) 
	public WebElement deliveryEmailAddress;
	
	@FindBy(how = How.XPATH, using = Locator.Z_DELIVERY_SUCCESS_MSG) 
	public WebElement deliverySuccessMsg;
	
	@FindBy(how = How.XPATH, using = Locator.Z_SHEDULED_REPORTS) 
	public WebElement sheduledReportsMsg;
	
	

	public ZReportsPage(WebDriver driver, ExtentTest test) {
		super(driver, test);
		PageFactory.initElements(driver, this);
	}
	
	/**
	 * Go to Reports - Find Reports
	 */
	public void goToFindReports() { 
		mouseHoverClickMenuAndSubMenu("Reports", "Find Reports");
		checkTextInPageAndValidate("Stored Reports" , 20);
	}
	
	public void searchStoredReports() {
		isDisplayedThenActionClick(searchCards, "Stored Reports Search");
	}
	
	public void goToscheduleReport(String userID) { 
		mouseHoverClickMenuAndSubMenu("Reports", "Scheduled Reports");
//		checkTextInPageAndValidate("Scheduled Reports for Zcustomer ("+userID+")" , 20);
		isDisplayed(sheduledReportsMsg, getText(sheduledReportsMsg));
	}
	
	public void clickAddScheduleReport() {
		isDisplayedThenActionClick(addScheduleReport, "Add a Schedule Report Button");
		
	}
	
	public void clickBackToScheduleReportList() {
		isDisplayedThenActionClick(backToScheduleReportList, "Back To ScheduleReport List");
		 sleep(2);
	}
	
	public void ClickReportName() {
		isDisplayedThenActionClick(reportName, "Report Name");
		sleep(5);
		checkTextInPageAndValidate("Report Request", 20);
	}
	
	public void clickRequestAReport() { 
		mouseHoverClickMenuAndSubMenu("Reports", "Request a Report");
		checkTextInPageAndValidate("On demand Reports" , 20);
		sleep(2);
	}
	
	public void clickHomeMenu() {
		isDisplayedThenActionClick(homeMenu, "Home Menu");
	}
	
	public void goToInvoicesAndSearchInovices() { 
		mouseHoverClickMenuAndSubMenu("Reports", "Invoices");
		checkTextInPageAndValidate("Invoices" , 20);
		isDisplayedThenActionClick(searchCards, "Search button");
	}

	//added -raxsana

	public void clickOnAdhocReportsList() {
		int randomNo = getRandomNumber(0, adhocReportsList.size());
		isDisplayed(adhocReportsList.get(randomNo), "Report");
		isDisplayedThenActionClick(adhocReportsList.get(randomNo), "Report Table List");
		sleep(5);
		verifyPageTitle();	
		// sleep(5);
	}
	public void verifyPageTitle() {
		sleep(10);
		if (storedReportsPageTitle.isDisplayed()) {
			logPass("StoredReports Page is displayed");
		} else {
			logFail("StoredReports Page is not displayed");
		}
	}

	public void verifyandClickGenerateButton() {

		isDisplayedThenClick(reportGenerate,"Generate Report is Displayed and Clicked");	   
	}
	
	public void enterDeliveryMailAdressAndClickGenerateButton() {
		
		isDisplayedThenEnterText(deliveryEmailAddress, "Delivery Adress is displayed", fakerAPI().internet().emailAddress());

		isDisplayedThenClick(reportGenerate,"Generate Report is Displayed and Clicked");	
		
		isDisplayed(deliverySuccessMsg, "Report send successfully");
		
		logInfo("Report send successfully");
	}

	public void verifyGenerateFileDownload() {
		String date=getCurrentDate();
		String split[]=date.split("/");
		System.out.println(split[0]+split[1]+split[2]);
		String ifcsDate=split[2]+"-"+split[1]+"-"+split[0];
		System.out.println(ifcsDate);
		//System.out.println(date);
		if(verifyNoReportData()) {
		logInfo("No report data");
		}
		else {
		verifyTheDownloadedFile(ifcsDate); 
		}
		}

	public boolean verifyNoReportData() {
		boolean noReport=false;
		try {
			WebElement noReportData=driver.findElement(By.xpath("//div[@class='errorFull']/h4"));//[contains(text(),'No report data')]
			String text=noReportData.getText();
			if(text.equals("No report data")) {
				isDisplayed(noReportData,"Displayed");
				noReport=true;
			}
		}catch(Exception e) {
			logInfo("File is downloaded");
		}
		return noReport;
	}

	public void clickBackToAdhocReportsPage() {
		isDisplayedThenClick(backToAdhocReportsPage,"Displayed");
		String text=bulkOrderTitle.getText();
		waitForTextToAppear(text,10);
	}
	public void clickAdhocExportLinkBtn() {
		isDisplayedThenActionClick(adhocReportExportLink, "Export Button Link");
		//sleep(5);
	}

	public void generateReportTypeAndValidate() {
		List<WebElement> element=driver.findElements(By.xpath("//span[@class='required']/parent::label/following-sibling::*"));
		int size=element.size();
		//System.out.println(size);
		//System.out.println(element);
		String elementAttribute;
		String elementTagName;
		WebElement elementInputText;
		List<WebElement> elementText1;
		int randomNumber;
		if(size>1) {
			for(int i=0;i<=size-1;i++) {    		
				//for(WebElement ele:element) {
				elementAttribute=element.get(i).getAttribute("id");
				//System.out.println(elementAttribute);
				elementTagName=element.get(i).getTagName();
				//System.out.println(elementTagName);

				if(elementTagName.equals("div")) {
					try {
						elementInputText=driver.findElement(By.xpath("//span[@class='required']/parent::label/following-sibling::"+elementTagName+""
								+ "//span[@id='"+elementAttribute.concat("Popup")+"']//input[@class='rf-cal-inp text abbreviated dateType']"));
						//System.out.println(elementText1);
						if(elementAttribute.contains("from")) {
							//System.out.println("comes inside from");
							enterADateValueInStatusBeginDateField("Current","ZE NZ",elementInputText);
						}
						else if(elementAttribute.contains("to")){
							//System.out.println("comes inside to");
//							enterADateValueInStatusBeginDateField("Future","ZE NZ",elementInputText);
							enterADateValueInStatusBeginDateField("AfterAMonth","ZE NZ",elementInputText);
							
						}
					}catch(Exception ex) {
						logInfo("empty tag");
					}
				}
				else if(elementTagName.equals("select")){
					//System.out.println("comes inside select");
					elementText1=driver.findElements(By.xpath("//span[@class='required']/parent::label/following-sibling::"+elementTagName+"/option"));
					randomNumber = getRandomNumber(0, elementText1.size());
					isDisplayed(elementText1.get(randomNumber), "Report");
					isDisplayedThenActionClick(elementText1.get(randomNumber), "Report Table List");
				}
				else {
					logInfo("Different fields selected");
				}
			}
		}
		else {   
			//System.out.println("no mandatory fields");
			logInfo("No Mandatory Fields");
		}
	}
	
	private String getDBDetailsFromProperties = "";
	public void enterADateValueInStatusBeginDateField(String beginDate, String clientCountry,WebElement elementInputText) {
		String currentIFCSDate;
		String beginDateValue;
		getDBDetailsFromProperties = PropUtils.getPropValue(configProp, "sqlODSServerName");
//		clientCountry = clientCountry.replace("CHV", "CHEV_");
		String queryToResetLogonCount = "SELECT PROCESSING_DATE from M_CLIENTS where IE_CLIENT_ID='" + clientCountry
				+ "'";
		currentIFCSDate = connectDBAndGetValue(queryToResetLogonCount, getDBDetailsFromProperties);
		try {
			DateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
			//Date dateGen = dateFormatter.parse(currentIFCSDate);
			// Date dateGen = new
			// SimpleDateFormat("dd/MM/yyyy").parse(currentIFCSDate.split(" ")[0]);
			Date newDate;
			Calendar cal = Calendar.getInstance();
			cal.setTime(dateFormatter.parse(currentIFCSDate));

			if (beginDate.equals("Past")) {
				cal.add(Calendar.MONTH, -3);
			} else if (beginDate.equals("Current")) {
				newDate = cal.getTime();
				// if (!dateInStatusTable.equals("null")) {
				// if (!newDate.before(dateInStatusTable)) {
				// logFail("Already Future Card Status Set");
				// }
				// }
			}else if (beginDate.equals("AfterAMonth")) {
				cal.add(Calendar.MONTH, +1);
			} else {
				// if (!dateInStatusTable.equals(null)) {
				// cal.setTime(dateInStatusTable);
				// cal.add(Calendar.DATE, -3);
				// } else {
				cal.add(Calendar.MONTH, +3);
				// }
			}
			newDate = cal.getTime();
			DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
			beginDateValue = df.format(newDate);
			isDisplayedThenEnterText(elementInputText, "New Card Status Begin Date", beginDateValue);
		} catch (Exception e) {
			logFail(e.getMessage());
		}

	}
	
	
}
