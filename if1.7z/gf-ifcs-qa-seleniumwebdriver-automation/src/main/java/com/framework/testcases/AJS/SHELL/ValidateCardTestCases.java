package com.framework.testcases.AJS.SHELL;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.CardMaintenancePage;
import com.framework.pages.AJS.common.Common;
import com.framework.pages.AJS.common.IFCSHomePage;
import com.framework.pages.AJS.common.IFCSLoginPage;

public class ValidateCardTestCases extends BaseTest {
	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test(groups = {"Regression"}) 
	public void updateAndValidateVehicleID(@Optional("RU") String clientCountry,
			@Optional("SHELL") String clientName, @Optional("APA") String cardType)  
	{

		test = extent.createTest(clientName+ ":" +clientCountry+"  SHELL IFCS Update VehicleID Field in Card Maintenace", "31 Maintain Customer -  Card Details -  Card Maintenance - Vehicle Card - Update Vehicle Id");
		//creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		CardMaintenancePage cardMaintenancePage=new CardMaintenancePage(driver,test);
		Common common = new Common(driver, test);
		// Calling Functions
		IFCSloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME","IFCS_SHELL_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, cardType);
		IFCSHomePage.gotoCustomerMenuCustomerDetails();
	//	String vehicleCardNumber=common.getVehicleCardNumberFromDB(clientName+clientCountry);
		String vehicleCardNumber=common.getDriverCardNumberFromDB(clientName+clientCountry);
		if(vehicleCardNumber.equals("")) {
		//need to call method to logfail
		common.logForNoDataFound(this.getClass().getSimpleName(),"Need to Create A Card and rerun");	
		}
		else {	

		cardMaintenancePage.validateUpdateVehicleID(vehicleCardNumber); 
		} 
		
		IFCSHomePage.exitIFCS();
		
		}
	
	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test(groups = {"Regression"})
	public void updateAndValidateVehicleDescription(@Optional("RU") String clientCountry,
			@Optional("SHELL") String clientName, @Optional("APA") String cardType)
	{

		test = extent.createTest(clientName+ ":" +clientCountry+"  SHELL IFCS Update Vehicle Description in Card Maintenace", "32 Maintain Customer -  Card Details -  Card Maintenance - Vehicle Card - Update Vehicle Description");
		//creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		CardMaintenancePage cardMaintenancePage=new CardMaintenancePage(driver,test);
		Common common = new Common(driver, test);
		// Calling Functions
		IFCSloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME","IFCS_SHELL_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, cardType);
		IFCSHomePage.gotoCustomerMenuCustomerDetails();
	//	String vehicleCardNumber=common.getVehicleCardNumberFromDB(clientName+clientCountry);
		String vehicleCardNumber=common.getDriverCardNumberFromDB(clientName+clientCountry);
		if(vehicleCardNumber.equals("")) {
		//need to call method to logfail
		common.logForNoDataFound(this.getClass().getSimpleName(),"Need to Create A Card and rerun");	
		}
		else {	

		cardMaintenancePage.validateUpdateVehicleDescription(vehicleCardNumber);
		}
		
		IFCSHomePage.exitIFCS();
		
		}
	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test(groups = {"Regression"})
	public void updateAndValidateVehicleVRN(@Optional("RU") String clientCountry,
			@Optional("SHELL") String clientName, @Optional("APA") String cardType)
	{

		test = extent.createTest(clientName+ ":" +clientCountry+"  SHELL IFCS Update Vehicle VRN in Card Maintenance", "34 Maintain Customer -  Card Details -  Card Maintenance - Vehicle Card - Update VRN");
		//creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		CardMaintenancePage cardMaintenancePage=new CardMaintenancePage(driver,test);
		Common common = new Common(driver, test);
		// Calling Functions
		IFCSloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME","IFCS_SHELL_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, cardType);
		
		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		String vehicleCardNumber=common.getVehicleCardNumberFromDB(clientName+clientCountry);
		if(vehicleCardNumber.equals("")) {
		//need to call method to logfail
		common.logForNoDataFound(this.getClass().getSimpleName(),"Need to Create A Card and rerun");	
		}
		else {	

		cardMaintenancePage.validateUpdateVehicleVRN(vehicleCardNumber);
		}
		
		IFCSHomePage.exitIFCS();
		
		}
}
