package com.framework.pages.EMAP;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.ExtentTest;
import com.framework.basepage.BasePage;
import com.framework.pages.OLS.common.CommonPage;
import com.framework.repo.Locator;
import com.framework.util.PropUtils;

/*** Added by Nithya - 07.06.2018 ***/
public class EMAPCardsPage extends BasePage {

	public EMAPCardsPage(WebDriver driver, ExtentTest test) {
		super(driver, test);
		PageFactory.initElements(driver, this);
	}

	// Page Element Definition
	@FindBy(how = How.ID, using = Locator.EXPORT_CARD_TOEXCEL)
	public WebElement exportCardToExcel;

	@FindBy(how = How.ID, using = Locator.SEARCH_BTN)
	public WebElement searchbutton;

	@FindBy(how = How.ID, using = Locator.CURRENT_CARD_NUMBER)
	public WebElement cardNumber;

	@FindBy(how = How.ID, using = Locator.CARD_LIST_TABLE)
	public WebElement cardListTable;

	@FindBy(how = How.ID, using = Locator.LICENSE_PLATE_FILTER_FIELD)
	public WebElement licensePlateFilterField;

	@FindBy(how = How.ID, using = Locator.DRIVER_NAME_FILTER_FIELD)
	public WebElement driverNameFilterField;

	@FindBy(how = How.ID, using = Locator.COST_CENTRE)
	public WebElement costCenterFilterField;

	@FindBy(how = How.ID, using = Locator.CARD_STATUS)
	public WebElement cardStatus;

	@FindBy(how = How.ID, using = Locator.CARD_OFFER_FILTER_FIELD)
	public WebElement cardOfferFilterField;

	@FindBy(how = How.ID, using = Locator.CARD_PRODUCT_DROPDOWN)
	public WebElement cardProductFilterField;

	@FindBy(how = How.ID, using = Locator.VEHICLE_DESC_FILTER_FIELD)
	public WebElement vehicleDescFilterField;

	@FindBy(how = How.ID, using = Locator.ACCOUNT_LIST)
	public WebElement accountListDropdown;

	@FindBy(how = How.XPATH, using = Locator.CARDS_IN_CARDLIST)
	public List<WebElement> cardsInCardList;

	@FindBy(how = How.XPATH, using = Locator.CARDS_WITHPIN_IN_CARDLIST)
	public List<WebElement> cardsWithPINInCardList;

	@FindBy(how = How.XPATH, using = Locator.LICENSE_PLATE_IN_CARDLIST)
	public List<WebElement> licensePlateInCardList;

	@FindBy(how = How.CSS, using = Locator.SUB_CATEGORIES_ON_VIEW_CARD)
	public List<WebElement> subCategoriesOnViewCard;

	@FindBy(how = How.XPATH, using = Locator.VIEW_CARD_MENU_OPTION)
	public WebElement viewCardMenuOption;

	@FindBy(how = How.XPATH, using = Locator.EDIT_CARD_MENU_OPTION)
	public WebElement editCardMenuOption;

	@FindBy(how = How.XPATH, using = Locator.TRANSACTION_PAGE_TITLE)
	public WebElement pageTitle;

	@FindBy(how = How.ID, using = Locator.CARD_NUMBER_FIELD)
	public WebElement cardNumberField;

	@FindBy(how = How.ID, using = Locator.CARD_STATUS_FIELD)
	public WebElement cardStatusField;

	@FindBy(how = How.ID, using = Locator.CARD_COST_CENTER)
	public WebElement cardCostCenter;

	@FindBy(how = How.ID, using = Locator.CARD_EXPIRES_ON)
	public WebElement cardExpiresOn;

	@FindBy(how = How.ID, using = Locator.CARD_INFORMATION_REFERENCE_NUMBER)
	public WebElement cardRefNo;

	@FindBy(how = How.ID, using = Locator.CARD_INFORMATION_REPORT_EMAIL)
	public WebElement cardEmailAddress;

	@FindBy(how = How.ID, using = Locator.CARD_PURCHASE_CONTROL_RESTRICTION)
	public WebElement controlRestriction;

	@FindBy(how = How.XPATH, using = Locator.CARD_TIME_LIMIT)
	public WebElement cardTimeLimit;

	@FindBy(how = How.ID, using = Locator.VEHICLE_DESCRIPTION_FIELD)
	public WebElement vehicleDescriptionField;

	@FindBy(how = How.ID, using = Locator.REGO_NUMBER_FIELD)
	public WebElement licensePlate;

	@FindBy(how = How.ID, using = Locator.ODOMETER_OPTION)
	public WebElement odometerOption;

	@FindBy(how = How.XPATH, using = Locator.DAILY_LIMIT_AMOUNT_FUEL)
	public WebElement dailyLimitAmountFuel;

	@FindBy(how = How.XPATH, using = Locator.DAILY_LIMIT_AMOUNT_NON_FUEL)
	public WebElement dailyLimitAmountNonFuel;

	@FindBy(how = How.XPATH, using = Locator.MONTHLY_LIMIT_AMOUNT_NON_FUEL)
	public WebElement monthlyLimitAmountNonFuel;

	@FindBy(how = How.XPATH, using = Locator.DAILY_LIMIT_NO_OF_TRX)
	public WebElement dailyLimitNoOfTrx;

	@FindBy(how = How.XPATH, using = Locator.MONTHLY_LIMIT_AMOUNT_TOTAL)
	public WebElement monthlyLimitAmountTotal;

	@FindBy(how = How.XPATH, using = Locator.TRX_LIMIT_AMOUNT_FUEL)
	public WebElement trxLimitAmountFuel;

	@FindBy(how = How.XPATH, using = Locator.TRX_LIMIT_AMOUNT_NON_FUEL)
	public WebElement trxLimitAmountNonFuel;

	@FindBy(how = How.XPATH, using = Locator.MONTHLY_LIMIT_AMOUNT_FUEL)
	public WebElement monthlyLimitAmountFuel;

	@FindBy(how = How.XPATH, using = Locator.BACK_TO_CARD_LIST)
	public WebElement backToCardList;

	@FindBy(how = How.XPATH, using = Locator.ADHOC_REPORTS_TITLE)
	public WebElement cardListPageTitle;

	@FindBy(how = How.XPATH, using = Locator.VELOCITY_CONTROL_LIST_PDF)
	public WebElement velocityControlListPDF;

	@FindBy(how = How.XPATH, using = Locator.VELOCITY_CONTROL_LIST_XLS)
	public WebElement velocityControlListXLS;

	@FindBy(how = How.XPATH, using = Locator.CHANGE_CARD_STATUS_MENU_OPTION)
	public WebElement changeCardStatus;

	@FindBy(how = How.XPATH, using = Locator.CHANGE_PIN_MENU_OPTION)
	public WebElement changePin;

	@FindBy(how = How.XPATH, using = Locator.CHANGE_PIN_WITH_CARDS)
	public List<WebElement> changePinMenuOption;

	@FindBy(how = How.XPATH, using = Locator.REISSUE_PIN_SMENU)
	public WebElement resendPin;

	@FindBy(how = How.XPATH, using = Locator.REISSUE_PIN_SMENU_OPTIONS)
	public List<WebElement> resendPinOptions;

	@FindBy(how = How.ID, using = Locator.DOWNLOAD_BULK_CARD_ORDER_TEMPLATE)
	public WebElement downloadBulkCardOrderTemplate;

	@FindBy(how = How.XPATH, using = Locator.UPLOAD_BULK_CARD_ORDER_TEMPLATE)
	public WebElement uploadBulkCardOrderTemplate;

	@FindBy(how = How.ID, using = Locator.CARD_OFFER)
	public WebElement cardOffer;

	@FindBy(how = How.ID, using = Locator.CARD_INFORMATION_EXPIRE_DATE)
	public WebElement cardInformationExpiryDate;

	@FindBy(how = How.ID, using = Locator.CARD_INFORMATION_EMBOSSING_NAME)
	public WebElement cardInformationmbossingName;

	@FindBy(how = How.ID, using = Locator.PRODUCT_RESTRICTION)
	public WebElement productRestriction;

	@FindBy(how = How.ID, using = Locator.CARD_PURCHASE_PRODUCTS_DURING_TIME)
	public WebElement cardPurchaseTimeLimit;

	@FindBy(how = How.ID, using = Locator.CARD_PURCHASE_TRANS_COST_LIMILTS)
	public WebElement cardPurchaseCostLimits;

	@FindBy(how = How.ID, using = Locator.CARD_PURCHASE_TRANS_VALUME_LIM)
	public WebElement cardPurchaseDailyLimitFuel;

	@FindBy(how = How.ID, using = Locator.CARD_PURCHASE_TRANS_VALUME_LIM)
	public WebElement cardPurchaseDailyLimitNonFuel;

	@FindBy(how = How.ID, using = Locator.UAL_FUEL_TRANSACTION_COST_OVER)
	public WebElement cardPurchaseMonthlyLimitFuel;

	@FindBy(how = How.ID, using = Locator.UAL_FUEL_TRANSACTION_VOLUME_OVER)
	public WebElement cardPurchaseDailyLimitNoOfTrx;

	@FindBy(how = How.ID, using = Locator.UAL_NON_FUEL_TRANSACTION_COST_OVER)
	public WebElement cardPurchaseMonthlyLimitAmountTotal;

	@FindBy(how = How.ID, using = Locator.UAL_FUEL_DAILY_VOLUME_OVER)
	public WebElement cardPurchaseTrxLimitAmountFuel;

	@FindBy(how = How.ID, using = Locator.UAL_NUMBER_TRANSACTION_DAILY_OVER)
	public WebElement cardPurchaseTrxLimitAmountNonFuel;

	@FindBy(how = How.ID, using = Locator.UAL_FUEL_MONTHLY_OVER)
	public WebElement cardPurchaseMonthlyLimitAmountFuel;

	@FindBy(how = How.ID, using = Locator.CONTINUE_BUTTON)
	public WebElement orderCard;

	@FindBy(how = How.ID, using = Locator.DOWNLOAD_CARDS_TO_EXCEL)
	public WebElement downloadBulkCardUpdate;

	@FindBy(how = How.XPATH, using = Locator.UPLOAD_BULK_CARD_UPDATE_TEMPLATE)
	public WebElement uploadBulkCardUpdate;

	@FindBy(how = How.ID, using = Locator.NEW_CARD_STATUS)
	public WebElement newCardStatus;

	@FindBy(how = How.ID, using = Locator.LATER_ON_THIS_DATE_FIELD)
	public WebElement newStatusBeginDate;

	@FindBy(how = How.ID, using = Locator.DELIVER_CONFIRM_AND_REISSUE)
	public WebElement saveStatusChange;

	@FindBy(how = How.XPATH, using = Locator.REPORT_DELIVERY_FULLERRORMSG)
	public WebElement changeCardStatusErrorMsg;

	@FindBy(how = How.ID, using = Locator.CONFIRMATIONMESSAGE)
	public WebElement successMsg;

	@FindBy(how = How.ID, using = Locator.REPLACE_CARD_POPUP)
	public WebElement replaceCardPopup;

	@FindBy(how = How.ID, using = Locator.REPLACE_POPUP_CONTENT)
	public WebElement replacePopupContent;

	@FindBy(how = How.ID, using = Locator.CARDSTATUSCHANGE_POPUP_YESBUTTON)
	public WebElement replaceCardOk;

	@FindBy(how = How.ID, using = Locator.CARDSTATUSCHANGE_POPUP_NOBUTTON)
	public WebElement replaceCardCancel;
	
	@FindBy(how = How.XPATH, using = Locator.CARDSTATUSCHANGE_CONFIRM_POPUP_NOBUTTON)
	public WebElement dontReplaceCard;
	
    @FindBy(how = How.XPATH, using = Locator.BULK_CARD_UPDATE_UPLOAD)
	public WebElement bulkUploadExcel;

	@FindBy(how = How.ID, using = Locator.BROWSE_UPLOAD_FILE)
	public WebElement browseUploadFile;

	@FindBy(how = How.ID, using = Locator.SEARCH_BULK_CARD)
	public WebElement searchBulkCard;

	@FindBy(how = How.ID, using = Locator.BULK_UPDATE_FILE_UPLOADED_POPUP)
	public WebElement bulkCardUpdatePopup;

	@FindBy(how = How.XPATH, using = Locator.BULK_UPDATE_POPUP_CLOSE)
	public WebElement bulkUpdatePopupClose;

	@FindBy(how = How.ID, using = Locator.CARD_INFORMATION_PIN_TEXTBOX)
	public WebElement cardInfoPIN;

	@FindBy(how = How.ID, using = Locator.CARD_INFORMATION_CONFIRM_PIN)
	public WebElement cardInfoCofirmPIN;

	@FindBy(how = How.XPATH, using = Locator.ACTIVECARDS_WITHPIN)
	public List<WebElement> activeCardsWithPIN;

	@FindBy(how = How.ID, using = Locator.ACCOUNTDETAILSNUMBER)
	public WebElement accountDetailcardNumber;

	@FindBy(how = How.ID, using = Locator.CARD_STATUS_TABLE)
	public WebElement cardStatusTable;
	
	@FindBy(how = How.ID, using = Locator.BULK_CARD_CLOSE)
	public WebElement bulkCardUpdateClose;
	
	@FindBy(how = How.ID, using = Locator.BULK_CARD_REQUEST_MESSAGE)
	public WebElement bulkCardRequestMessage ;
	

	String cardNumberChosen, licensePlateChoosen, cardOfferChoosen, cardProductChoosen;
	int randomNoForCard;

	CommonPage commonPage = new CommonPage(driver, test);

	public void checkThePresenceOfExportCardOption() {
		try {
			if (exportCardToExcel.isDisplayed()) {
				logPass("Option for exporting the card search result is present");
			}
		} catch (NoSuchElementException ex) {
			logInfo("Export card option not displayed");
		}

	}

	public void clickSearchButtonInBulkCard() {
		isDisplayedThenClick(searchBulkCard, "Search button");
		sleep(5);
	}

	public void checkThePresenceOfSearchCardButton() {
		try {
			if (searchbutton.isDisplayed()) {
				logPass("Search button displayed");
			}
		} catch (NoSuchElementException ex) {
			logInfo("Search button not displayed");
		}

	}

	public void verifyTheListOfCardsFoundTableColumn(String clientCountry) {
		String[] columnValues;
		if (clientCountry.equals("HK") || clientCountry.equals("MO")) {
			columnValues = new String[] { "Card No", "Current Card Status", "Card Offer", "Card Product",
					"License Plate", "Driver Name", "Cost Centre", "Customer No" };
		} else {
			columnValues = new String[] { "Card No", "Current Card Status", "Card Offer", "License Plate",
					"Driver Name", "Cost Centre", "Customer No", "Avail Bal" };
		}

		commonPage.validateTheTableHeaderTitles(cardListTable, 8, columnValues);
	}

	public void checkThePresenceOfCardFilterCriteria(String clientCountry) {
		isDisplayed(cardNumber, "Card No filter field");
		isDisplayed(licensePlateFilterField, "License Plate filter field");
		isDisplayed(driverNameFilterField, "Driver Name filter field");
		isDisplayed(costCenterFilterField, "Cost Center filter field");
		if (!getTagNameForLocators(cardStatus).equals("select")) {
			logFail("Card Status Dropdown not present");
		}
		if (clientCountry.equals("HK") || clientCountry.equals("MO")) {
			if (!getTagNameForLocators(cardProductFilterField).equals("select")) {
				logFail("Card Product Dropdown not present");
			}
		} else {
			if (!getTagNameForLocators(cardOfferFilterField).equals("select")) {
				logFail("Card Offer Dropdown not present");
			}
		}
		isDisplayed(vehicleDescFilterField, "Vehicle Description filter field");
		if (!getTagNameForLocators(accountListDropdown).equals("select")) {
			logFail("Account List Dropdown not present");
		}
	}

	public void selectACardFromCardListTable(boolean clickCard) {
		if (cardsInCardList.size() > 0) {
			randomNoForCard = getRandomNumber(0, cardsInCardList.size());
			cardNumberChosen = getText(cardsInCardList.get(randomNoForCard));
			if (clickCard) {
				isDisplayedThenActionClick(cardsInCardList.get(randomNoForCard), "Select a card in card list");
				sleep(2);
			}
		}
	}

	public boolean isCardsPresent(boolean... failOrInfo) {
		if (cardsInCardList.size() > 0) {
			return true;
		} else {
			if (failOrInfo.length > 0) {
				if (failOrInfo[0])
					logFail("No Cards present for this user");
			}
			return false;
		}
	}

	public String selectACardWithPINFromCardListTable(String changePinOrResendPin) {
		if (cardsInCardList.size() > 0) {
			boolean cardChosen = false;
			int i = 0;
			while (!cardChosen && i < cardsInCardList.size()) {
				isDisplayedThenActionClick(cardsInCardList.get(i), "Card");
				sleep(1);
				try {
					if (changePinOrResendPin.equals("Change PIN")) {
						if (!(getAttribute(changePinMenuOption.get(i), "class").contains("dis"))) {
							cardNumberChosen = getText(cardsInCardList.get(i));
							changePinMenuOption.get(i).click();
							cardChosen = true;
						}
					} else {
						if (!(getAttribute(resendPinOptions.get(i), "class").contains("dis"))) {
							cardNumberChosen = getText(cardsInCardList.get(i));
							resendPinOptions.get(i).click();
							cardChosen = true;
						}
					}
				} catch (Exception ex) {
					break;
				}
				if (i == cardsInCardList.size()) {
					logFail("No Cards with " + changePinOrResendPin);
				}
				i++;
			}
		}
		return cardNumberChosen;
	}

	public void selectAValidLicensePlateFromCardListTable() {
		if (licensePlateInCardList.size() > 0) {
			randomNoForCard = getRandomNumber(0, licensePlateInCardList.size());
			licensePlateChoosen = getText(licensePlateInCardList.get(randomNoForCard));
		}
	}

	public void enterSelectedCardNumberInCardNumberFilter() {
		isDisplayedThenEnterText(cardNumber, "Card Number Filter", cardNumberChosen);
	}

	public void selectACardStatus() {
		selectDropDownByVisibleText(cardStatus, "Active");
	}

	public void selectACardOffer() {
		selectDropDownByIndex(cardOfferFilterField, 1);
		cardOfferChoosen = selectedStringFrmDropDown(cardOfferFilterField);
	}

	public void selectACardProduct() {
		selectDropDownByIndex(cardProductFilterField, 1);
		cardProductChoosen = selectedStringFrmDropDown(cardProductFilterField);
	}

	public void selectFleetCardFromCardProduct() {
		selectDropDownByVisibleText(cardProductFilterField, "Fleet Card Vehicle");
		sleep(3);
	}

	public void enterVehicleDescription(String vehicleDescription) {
		isDisplayedThenEnterText(vehicleDescFilterField, "Vehicle Description", vehicleDescription);
	}

	public void enterALicensePlate() {
		isDisplayedThenEnterText(licensePlateFilterField, "License Plate", licensePlateChoosen);
	}

	public void verifyTheCardListTableWithCardNumber() {
		setCellDataFromTable(cardListTable, 8, true);
		if (getCellDataFromTable(1, 0, true).equals(cardNumberChosen)) {
			logPass("Card Number in filter field retrived the card with the correct number");
		} else {
			logFail("Card Number in filter field and card number in retrived table doesn't match");
		}
	}

	public void verifyTheCardListTableWithCardStatus() {
		setCellDataFromTable(cardListTable, 8, true);
		if (getRowSize(cardListTable) > 3) {
			for (int i = 1; i < getRowSize(cardListTable) - 1; i++) {
				if (getCellDataFromTable(i, 1, true).equals("Active")) {
					logPass("Card Status in filter field retrived the card with the correct status");
				} else {
					logFail("Card Status in filter field and card status in retrived table doesn't match");
				}
			}
		}
	}

	public void verifyTheCardListTableWithCardOffer() {
		setCellDataFromTable(cardListTable, 8, true);
		if (getRowSize(cardListTable) > 3) {
			for (int i = 1; i < getRowSize(cardListTable) - 1; i++) {
				if (getCellDataFromTable(i, 2, true).equals(cardOfferChoosen)) {
					logPass("Card Offer in filter field retrived the card with the correct offer");
				} else {
					logFail("Card Offer in filter field and card offer in retrived table doesn't match");
				}
			}
		}
	}

	public void verifyTheCardListTableWithCardProduct() {
		setCellDataFromTable(cardListTable, 8, true);
		if (getRowSize(cardListTable) > 3) {
			for (int i = 1; i < getRowSize(cardListTable) - 1; i++) {
				if (getCellDataFromTable(i, 3, true).equals(cardProductChoosen)) {
					logPass("Card Product in filter field retrived the card with the correct product");
				} else {
					logFail("Card Product in filter field and card product in retrived table doesn't match");
				}
			}
		}
	}

	public void verifyTheCardListTableWithVehicleDescription() {
		setCellDataFromTable(cardListTable, 8, true);
		if (getRowSize(cardListTable) > 3) {
			logPass("Card List Table have results matching for vehicle description");
		} else {
			logInfo("Card List Table not having results matching for vehicle description");
		}
	}

	public void verifyTheCardListTableWithLicensePlate() {
		setCellDataFromTable(cardListTable, 8, true);
		if (getRowSize(cardListTable) > 3) {
			sleep(5);
			for (int i = 1; i < getRowSize(cardListTable) - 1; i++) {
			
				if (getCellDataFromTable(i, 4, true).toLowerCase().equals(licensePlateChoosen.toLowerCase())) {
					logPass("License Plate in filter field retrived the card with the correct license plate");
				} else {
					logFail("License Plate in filter field and license plate in retrived table doesn't match "
							+ "Expected::" + getCellDataFromTable(i, 4, true).toLowerCase() + "Actual::"
							+ licensePlateChoosen.toLowerCase());
				}
			}
		}
	}

	public void clickContextMenuOptionAndVerifyCardNumberInNavigatedPage(String contextMenuOption) {
		if (contextMenuOption.equals("Edit Card")) {
			isDisplayedThenActionClick(editCardMenuOption, "Edit Card Menu");
		} else if (contextMenuOption.equals("View Card")) {
			isDisplayedThenActionClick(viewCardMenuOption, "View Card Menu");
		} else if (contextMenuOption.equals("Change Card Status")) {
			isDisplayedThenActionClick(changeCardStatus, "Change Card status");
		} else if (contextMenuOption.equals("Change PIN")) {
			isDisplayedThenActionClick(changePin, "Change PIN");
			contextMenuOption = "Change Card PIN";
		} else if (contextMenuOption.equals("Resend PIN")) {
			isDisplayedThenActionClick(resendPin, "Resend PIN");
		}
		sleep(7);
		if (getText(pageTitle).toLowerCase().contains(contextMenuOption.toLowerCase())) {
			logPass(contextMenuOption + " page title present");
		} else {
			logFail(contextMenuOption + " page title not present");
		}
	}

	public boolean checkContextMenuOptionIsPresent(String contextMenuOption) {
		Boolean isContextMenuOptionPresent = false;
		try {
			if (contextMenuOption.equals("Edit Card")) {
				if (editCardMenuOption.isDisplayed())
					isContextMenuOptionPresent = true;
			} else if (contextMenuOption.equals("View Card")) {
				if (viewCardMenuOption.isDisplayed())
					isContextMenuOptionPresent = true;
			} else if (contextMenuOption.equals("Change Card Status")) {
				if (changeCardStatus.isDisplayed() && getAttribute(changeCardStatus, "class").contains("unsel"))
					isContextMenuOptionPresent = true;
			} else if (contextMenuOption.equals("Change PIN")) {
				if (changePin.isDisplayed() && getAttribute(changePin, "class").contains("unsel"))
					isContextMenuOptionPresent = true;
			} else if (contextMenuOption.equals("Resend PIN")) {
				if (resendPin.isDisplayed())
					isContextMenuOptionPresent = true;
			}
		} catch (Exception ex) {
			logInfo(contextMenuOption + "not present");
		}
		return isContextMenuOptionPresent;
	}

	public void checkContextMenuNotPresent(String contextMenuOption) {
		if (checkContextMenuOptionIsPresent(contextMenuOption))
			logFail("Context Menu :: " + contextMenuOption + " should not present");
	}

	public void checkContextMenuPresent(String contextMenuOption) {
		if (!(checkContextMenuOptionIsPresent(contextMenuOption)))
			logFail("Context Menu :: " + contextMenuOption + " should present");
	}

	public void verifySubCategoriesOnViewCardPage(String orderCardOrViewCard) {
		String[] subCategories;
		if (orderCardOrViewCard.equals("View Card")) {
			subCategories = new String[] { "Card Details", "Velocity Control", "Delivery address" };
		} else {
			subCategories = new String[] { "Card Details", "Velocity Control", "Delivery address" };
		}
		for (int i = 0; i < 3; i++) {
			if (getText(subCategoriesOnViewCard.get(i)).contains(subCategories[i])) {
				logPass("Expected subcategory " + subCategories[i] + " is present");
			} else {
				logFail("Expected subcategory " + subCategories[i] + " is not present");
			}
		}
	}

	public void verifyTheCardDetailsAreInViewMode(String clientCountry) {
		sleep(3);
		if (!getTagNameForLocators(cardNumberField).equals("span")) {
			logFail("Card Number field is not read-only");
		}
		if (!getTagNameForLocators(cardStatusField).equals("span")) {
			logFail("Card Status field is not read-only");
		}
		if (!getTagNameForLocators(cardCostCenter).equals("span")) {
			logFail("Card cost center field is not read-only");
		}
		if (!getTagNameForLocators(cardExpiresOn).equals("span")) {
			logFail("Card expires on field is not read-only");
		}
		if (!getTagNameForLocators(cardRefNo).equals("span")) {
			logFail("Card Status field is not read-only");
		}
		if (!getTagNameForLocators(cardEmailAddress).equals("span")) {
			logFail("Card cost center field is not read-only");
		}
		if (clientCountry.equals("SP") || clientCountry.equals("GU")) {
			if (!getTagNameForLocators(controlRestriction).equals("span")) {
				logFail("Card control restriction field is not read-only");
			}
		}
		if (!getTagNameForLocators(cardTimeLimit).equals("span")) {
			logFail("Card time limit field is not read-only");
		}
		if (!getTagNameForLocators(vehicleDescriptionField).equals("span")) {
			logFail("Vehicle description field is not read-only");
		}
		if (!getTagNameForLocators(licensePlate).equals("span")) {
			logFail("License plate field is not read-only");
		}
		String checkBoxBeforeClick = getAttribute(odometerOption, "disabled");
		//Below line is commented while Release 20.2.1 23/01/2020
		//isDisplayedThenClick(odometerOption, "Odometer Option");
		if (!(checkBoxBeforeClick.equals(getAttribute(odometerOption, "disabled")))) {
			logFail("Odometer field is not read-only");
		}
	}

	public void verifyTheVelocityControlFieldValues() {
		if (!getTagNameForLocators(dailyLimitAmountFuel).equals("span")) {
			logFail("Daily Limit Amount Fuel is not read-only");
		}
		if (!getTagNameForLocators(dailyLimitAmountNonFuel).equals("span")) {
			logFail("Daily Limit Amount Non Fuel field is not read-only");
		}
		if (!getTagNameForLocators(monthlyLimitAmountNonFuel).equals("span")) {
			logFail("Monthly Limit Amount Non Fuel field is not read-only");
		}
		if (!getTagNameForLocators(dailyLimitNoOfTrx).equals("span")) {
			logFail("Daily Limit No Of Trx field is not read-only");
		}
		if (!getTagNameForLocators(monthlyLimitAmountTotal).equals("span")) {
			logFail("Monthly limit amount total field is not read-only");
		}
		if (!getTagNameForLocators(trxLimitAmountFuel).equals("span")) {
			logFail("Trx Limit Amount Fuel field is not read-only");
		}
		if (!getTagNameForLocators(trxLimitAmountNonFuel).equals("span")) {
			logFail("Trx Limit Amount Non Fuel field is not read-only");
		}
		if (!getTagNameForLocators(monthlyLimitAmountFuel).equals("span")) {
			logFail("Monthly Limit Amount Fuel field is not read-only");
		}
	}

	public void validateBackToCardListPageLink() {
		isDisplayedThenClick(backToCardList, "Back to card list");
		verifyText(cardListPageTitle, "Card list");
		sleep(10);
	}

	public void checkThePresenceOfVelocityControlListPDFAndXLS() {
		isDisplayed(velocityControlListPDF, "Velocity Control List PDF");
		isDisplayed(velocityControlListXLS, "Velocity Control List XLS");
	}

	public void selectACardStatus(String cardStatusNeedToChoose) {
		selectDropDownByVisibleText(cardStatus, cardStatusNeedToChoose);
	}

	public void checkThePresenceOfBulkCardOrderDownloadAndUpload(String userRole) {
		if (userRole.equals("Read-Write")) {
			isDisplayed(downloadBulkCardOrderTemplate, "Download Bulk Card Order");
			isDisplayed(uploadBulkCardOrderTemplate, "Upload Bulk Card Order");
		} else {
			if (checkSubMenuPresence("cards", "bulk card order")) {
				logFail("Bulk card order present for " + userRole + " customer");
			}
		}
	}

	public void clickDownloadBulkCardOrder() {
		isDisplayedThenClick(downloadBulkCardOrderTemplate, "Bulk Card Order");
		sleep(3);
	}

	public void clickDownloadBulkCardUpdate() {
		isDisplayedThenClick(downloadBulkCardUpdate, "Bulk Card Update");
		sleep(3);
	}

	public void checkThePresenceOfSubmenuItemsInCardsMenu(String userRole) {
		if (userRole.contains("Read-Write")) {
			if (!checkSubMenuPresence("cards", "order card")) {
				logFail("Order card option not present for " + userRole + " customer");
			}
			if (!checkSubMenuPresence("cards", "bulk card update")) {
				logFail("Bulk card update option not present for " + userRole + " customer");
			}
			if (!checkSubMenuPresence("cards", "bulk card order")) {
				logFail("Bulk card order option not present for " + userRole + " customer");
			}
		} else if (userRole.contains("View-Only")) {
			if (!checkSubMenuPresence("cards", "bulk card update")) {
				logFail("Bulk card update option not present for " + userRole + " customer");
			}
		}
		if (!checkSubMenuPresence("cards", "card list")) {
			logFail("Card list option not present for " + userRole + " customer");
		}
	}

	public void checkThePresenceOfBulkCardUpdateDownloadAndUpload() {
		isDisplayed(downloadBulkCardUpdate, "Download bulk card update");
		isDisplayed(uploadBulkCardUpdate, "Upload bulk card update");
	}

	public void enterAllMandotoryFieldsForOrderingCard() {
		sleep(5);
		selectDropDownByIndex(cardOffer, 1);
		selectDifferentValueInsteadOfDefault(cardOffer, "", "--Select One--");
		sleep(5);
		if (!getText(cardInformationExpiryDate).equals("")) {
			logFail("Card expiry date not auto-generated");
		}
		if (!(getText(cardInformationmbossingName).equals(""))) {
			logFail("Embossing name not auto-generated");
		}
		selectDifferentValueInsteadOfDefault(productRestriction, "--Select One--", "--Select One--");
		sleep(5);
		selectDifferentValueInsteadOfDefault(cardPurchaseTimeLimit, "--Select One--", "--Select One--");
		sleep(15);

		isDisplayedThenEnterText(licensePlate, "License Plate", fakerAPI().number().digits(4));

		if (selectedStringFrmDropDown(cardPurchaseDailyLimitFuel).contains("Select One")) {
			logFail("Card purchase daily limit fuel value not auto-generated as per the Product Restriction");
		}
		if (selectedStringFrmDropDown(cardPurchaseDailyLimitNonFuel).contains("Select One")) {
			logFail("Card purchase daily limit non-fuel value not auto-generated as per the Product Restriction");
		}
		if (selectedStringFrmDropDown(cardPurchaseMonthlyLimitFuel).contains("Select One")) {
			logFail("Card purchase monthly limit fuel value not auto-generated as per the Product Restriction");
		}
		if (selectedStringFrmDropDown(cardPurchaseDailyLimitNoOfTrx).contains("Select One")) {
			logFail("Card purchase daily limit no of trx value not auto-generated as per the Product Restriction");
		}
		if (selectedStringFrmDropDown(cardPurchaseMonthlyLimitAmountTotal).contains("Select One")) {
			logFail("Card purchase monthly limit amount total value not auto-generated as per the Product Restriction");
		}
		if (selectedStringFrmDropDown(cardPurchaseTrxLimitAmountFuel).contains("Select One")) {
			logFail("Card purchase trx limit amount fuel value not auto-generated as per the Product Restriction");
		}
		if (selectedStringFrmDropDown(cardPurchaseTrxLimitAmountNonFuel).contains("Select One")) {
			logFail("Card purchase trx limit amount non-fuel value not auto-generated as per the Product Restriction");
		}
		if (selectedStringFrmDropDown(cardPurchaseMonthlyLimitAmountFuel).contains("Select One")) {
			logFail("Card purchase monthly limit amount fuel value not auto-generated as per the Product Restriction");
		}

		isDisplayedThenActionClick(orderCard, "Order Card");

		sleep(10);
	}

	public void clickOrderCardAndValidateSuccessMsg() {
		isDisplayedThenActionClick(orderCard, "Order Card");
		sleep(10);
		if (getText(successMsg).contains("Success!  Card ")) {
			logPass("Card Ordered");
		} else {
			logPass("Card not ordered");
		}
	}

	public void clickSaveNewPIN() {
		isDisplayedThenClick(orderCard, "Save PIN");
	}

	private String getDBDetailsFromProperties = "";

	public void enterADateValueInStatusBeginDateField(String beginDate, String clientCountry) {
		String currentIFCSDate;
		String beginDateValue;
		getDBDetailsFromProperties = PropUtils.getPropValue(configProp, "sqlODSServerName");
		clientCountry = clientCountry.replace("EMAP", "EX ");
		String queryToResetLogonCount = "SELECT PROCESSING_DATE from M_CLIENTS where IE_CLIENT_ID='" + clientCountry
				+ "'";
		currentIFCSDate = connectDBAndGetValue(queryToResetLogonCount, getDBDetailsFromProperties);
		try {
			DateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
			dateFormatter.parse(currentIFCSDate);
			// Date dateGen = new
			// SimpleDateFormat("dd/MM/yyyy").parse(currentIFCSDate.split(" ")[0]);
			Date newDate;
			Calendar cal = Calendar.getInstance();
			cal.setTime(dateFormatter.parse(currentIFCSDate));

			if (beginDate.equals("Past")) {
				cal.add(Calendar.MONTH, -3);
			} else if (beginDate.equals("Current")) {
				newDate = cal.getTime();
				// if (!dateInStatusTable.equals("null")) {
				// if (!newDate.before(dateInStatusTable)) {
				// logFail("Already Future Card Status Set");
				// }
				// }
			} else {
				// if (!dateInStatusTable.equals(null)) {
				// cal.setTime(dateInStatusTable);
				// cal.add(Calendar.DATE, -3);
				// } else {
				cal.add(Calendar.MONTH, +3);
				// }
			}
			newDate = cal.getTime();
			DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
			beginDateValue = df.format(newDate);
			isDisplayedThenEnterText(newStatusBeginDate, "New Card Status Begin Date", beginDateValue);
		} catch (Exception e) {
			logFail(e.getMessage());
		}

	}

	public void chooseANewCardStatus(String newCardStatusValue) {
		selectDropDownByVisibleText(newCardStatus, newCardStatusValue);
		sleep(5);
	}

	Date dateInStatusTable;

	public void checkStatusHistoryTable() {
		sleep(2);
		try {
			DateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
			if (cardStatusTable.isDisplayed()) {
				setCellDataFromTable(cardStatusTable, 4, true);
				if (getRowSize(cardStatusTable) > 3) {
					for (int i = 1; i < getRowSize(cardStatusTable); i++) {

						if (dateFormatter.parse(getCellDataFromTable(i, 2, true))
								.before(dateFormatter.parse(getCellDataFromTable(i + 1, 2, true)))) {
							dateInStatusTable = dateFormatter.parse(getCellDataFromTable(i, 2, true));
						} else {
							dateInStatusTable = dateFormatter.parse(getCellDataFromTable(i + 1, 2, true));
						}
					}
				} else {
					dateInStatusTable = dateFormatter.parse(getCellDataFromTable(1, 2, true));
				}
			}
		} catch (Exception ex) {
			logInfo("No Card Status Change Table Present");
		}
	}

	public boolean isStatusHistoryTablePresent() {
		try {
			if (cardStatusTable.isDisplayed()) {
				return true;
			} else {
				return false;
			}
		} catch (Exception ex) {
			return false;
		}
	}

	public void clickSaveStatusChange() {
		isDisplayedThenClick(saveStatusChange, "Save");
		sleep(5);
	}

	public void verifyErrorMessageForInvalidBeginDate() {
		verifyText(changeCardStatusErrorMsg, "New Status Begin Date Date cannot be in the past.");
	}

	public void verifyCardStatusChangedSuccessMessage(String cardStatus) {
		verifyText(successMsg, "The card status for card " + cardNumberChosen + " has been successfully changed to "
				+ cardStatus + ".");
	}

	public void checkReplaceCardPopupContent(String cardStatus) {
		try {
			if (replaceCardPopup.isDisplayed()) {
				if (getText(replacePopupContent).equals("Would you like a Replacement for your " + cardStatus
						+ " Card?. Note: The Card Number will change.")) {
					logPass("Replace popup present with expected content");
				} else {
					logFail("Replace popup present not having expected content");
				}
				isDisplayedThenClick(dontReplaceCard, "Cancel Replace Card");
				sleep(5);
			}
		} catch (Exception ex) {
			logInfo("Replace Popup not present");
		}
	}

	public void clickReplaceCardAndCheckSuccessMsg() {
		isDisplayedThenClick(replaceCardOk, "Replace Card Okay");
		if (getText(successMsg).contains("Success!  Card ")) {
			logPass("Success Message present");
		} else {
			logFail("Success Message not present");
		}
	}

	public void clickUploadBulkCardUpload() {
		isDisplayedThenClick(bulkUploadExcel, "Bulk Card Upload");
		sleep(5);
		isDisplayed(browseUploadFile, "Browse Popup");
		isDisplayedThenClick(browseUploadFile, "Browse Upload");
	}
	

	public void checkFileUploadedPopup() {
		isDisplayed(bulkUpdatePopupClose, "Bulk Card Update Popup");
		sleep(2);
		isDisplayedThenClick(bulkUpdatePopupClose, "Close Bulk Update Popup");
		sleep(5);
	}
	public void  clickClosePopupAndVerifyBulkCardMessage() {
		isDisplayedThenClick(bulkUpdatePopup,"Bulk card update close");
		sleep(10);
		isDisplayed(bulkCardRequestMessage,"Bulk card Request Message");
		isDisplayedThenClick(bulkUpdatePopupClose, "Close Bulk Update Popup");
		
	}
@FindBy(how = How.ID, using = Locator.UPDATE_REQUEST_MESSAGE_POPUP)
	public WebElement bulkUpdatePopup;

	/*public void checkFileUploadedPopup() {
		isDisplayed(bulkCardUpdatePopup, "Bulk Card Update Popup");
		isDisplayedThenClick(bulkUpdatePopupClose, "Close Bulk Update Popup");
		sleep(2);
	}*/

}
