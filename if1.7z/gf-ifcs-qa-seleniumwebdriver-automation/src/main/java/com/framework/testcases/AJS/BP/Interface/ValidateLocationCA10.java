package com.framework.testcases.AJS.BP.Interface;

import java.util.HashMap;

import javax.xml.transform.TransformerException;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.common.Common;
import com.framework.pages.AJS.common.IFCSCommonPage;
import com.framework.pages.AJS.common.IFCSHomePage;
import com.framework.pages.AJS.common.IFCSLoginPage;
import com.framework.util.PropUtils;

public class ValidateLocationCA10 extends BaseTest {
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "Smoke" , "Regression","BusinessFlow"})
	public void ValidateCA10Location(@Optional("AU") String clientCountry, @Optional("BP") String clientName) throws TransformerException {

		test = extent.createTest(clientName+ ":" +clientCountry+"  CA10_Location_Upload and Update",
				"CA10_Location_Upload and Update");
		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		Common common = new Common(driver, test);
		IFCSCommonPage ifcsCommonPage = new IFCSCommonPage(driver, test);
		String  clientNameInProp = PropUtils.getPropValue(configProp, clientName + "_" + clientCountry);
		System.out.println(clientNameInProp);		
		
		HashMap<String, String> RefNum = ifcsCommonPage.updateLocationfileXML(clientNameInProp,clientCountry);
		System.out.println((RefNum));
		IFCSloginPage.login("IFCS_URL_BP", "IFCS_BP_USERNAME", "IFCS_BP_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, " ");
		IFCSHomePage.gotoClientMenuAndChooseClient(clientNameInProp);
		System.out.println(clientCountry);
		if(clientCountry.equalsIgnoreCase("AU")) {
			common.clientBatchJobExecution("RM_GSD_0081");
			}else {common.clientBatchJobExecution("RM_GSD_0012");}		
			
		 ifcsCommonPage.validateDBandXMLfileValueCA10(clientNameInProp,RefNum);
		 IFCSHomePage.exitIFCSwithoutValidation();

	}
	
}
