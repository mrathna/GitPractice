using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using Common;
using Common.PageObjects;
using Common.ScenarioConfigurations;
using Common.Utility;

namespace EnCompass.Testing.Source.PageObjects.Organization.SecurityManager.AccountManagement 
{
	/// <summary>
	/// Auto-generated Page Model Class
	/// Navigation Paths: 
		/// [Organization Home]->Security->Users
		/// </summary>
	[PageModel(@"/securityManager/accountManagement/manageAccounts.aspx")]
	public partial class ManageAccounts : EnCompassOrgPageModel 
	{
		public override string RelativeUrl => @"/securityManager/accountManagement/manageAccounts.aspx";
		public override string PageIdentifierXPath_Generated => @"//li[contains(@class, 'breadcrumb-item active')][text() = 'Users']";

		#region Navigation
		
		private void NavigateToMenuItem(IWebElement element)
		{
			Driver.Url = element.GetAttribute("href");
		}
		#endregion

		public ManageAccounts(GlobalSettings settings) : base(settings) { }
	}  
}
