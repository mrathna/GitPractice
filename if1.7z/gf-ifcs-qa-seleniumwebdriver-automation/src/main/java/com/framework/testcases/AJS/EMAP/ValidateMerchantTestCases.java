package com.framework.testcases.AJS.EMAP;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.MerchantLocationPage;
import com.framework.pages.AJS.common.Common;
import com.framework.pages.AJS.common.IFCSHomePage;
import com.framework.pages.AJS.common.IFCSLoginPage;
import com.github.javafaker.Faker;

public class ValidateMerchantTestCases extends BaseTest {
	
	@Parameters({ "clientCountry", "clientName"})
	@Test( groups = { "Regression" })
	public void ValidateNewMerchantAgreementWithPrivateAndPublicProfiles(@Optional("SG") String clientCountry,
			@Optional("EMAP") String clientName) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  TST-SC-27-Create a new merchant agreement using with private and Public Profiles",
				"TST-SC-27-Create a new merchant agreement using with private and Public Profiles");
		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		Common common=new Common(driver,test);
		MerchantLocationPage  merchantLocation=new MerchantLocationPage(driver,test);
		IFCSloginPage.login("IFCS_URL_EMAP", "IFCS_EMAP_USERNAME", "IFCS_EMAP_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry," ");
		IFCSHomePage.gotoApplicationAndClickApplicationMenu();
		IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);
		IFCSHomePage.gotoMerchantAndClickMerchantDetails();
		String merchant=common.getMerchantNoFromDB();
		common.chooseMerchantNoAndSearch(merchant);
		merchantLocation.verifyExistingMerchantHasCustomers();
		Faker fakerNumber = new Faker();
		String f_merchantNo1 = fakerNumber.number().digits(6);
		String f_merchantNo2 = fakerNumber.number().digits(6);
		merchantLocation.createNewMerchant(f_merchantNo1);
		merchantLocation.createNewMerchant(f_merchantNo2);
		merchantLocation.createMerchantAgreementPublicAndPrivateProfile();
		merchantLocation.createPricingProfileInPublicAndPrivateProfile(clientName,clientCountry,"Private");
		merchantLocation.createPricingProfileInPublicAndPrivateProfile(clientName,clientCountry,"Public");
		
		
		IFCSHomePage.exitIFCS();
	}
	
	@Parameters({ "clientCountry", "clientName"})
	@Test( groups = { "Regression" })
	public void ValidateToCreateMerchant(@Optional("SG") String clientCountry,
			@Optional("EMAP") String clientName) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  TST-SC-26-Create Merchant",
				"TST-SC-26-Create Merchant");
		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		Common common=new Common(driver,test);
		MerchantLocationPage  merchantLocation=new MerchantLocationPage(driver,test);
		IFCSloginPage.login("IFCS_URL_EMAP", "IFCS_EMAP_USERNAME", "IFCS_EMAP_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry,"");
		IFCSHomePage.gotoApplicationAndClickApplicationMenu();
		IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);
		IFCSHomePage.gotoMerchantAndClickMerchantDetails();
		String merchant=common.getMerchantNoFromDB();
		common.chooseMerchantNoAndSearch(merchant);
		Faker fakerNumber = new Faker();
		String f_merchantNo = fakerNumber.number().digits(6);
		merchantLocation.createNewMerchant(f_merchantNo);	
		IFCSHomePage.exitIFCS();
	}
	
	/*
	 * Added by Davu - 30/04/2020
	 * 
	 */
	
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "Regression" })
	public void updateAndValidateMerchant(@Optional("HK") String clientCountry,
			@Optional("EMAP") String clientName) {
		
		test = extent.createTest(clientName+ ":" +clientCountry+"   Update Merchant   ",
				"Update merchant for EMAP");
		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		
		Common common = new Common(driver, test);
		
		MerchantLocationPage merchantLocation = new MerchantLocationPage(driver, test);
		IFCSloginPage.login("IFCS_URL_EMAP", "IFCS_EMAP_USERNAME", "IFCS_EMAP_PASSWORD");
		//IFCSloginPage.login("IFCS_CHV_URL", "IFCS_CHV_UN", "IFCS_CHV_PWD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		IFCSHomePage.gotoApplicationAndClickApplicationMenu();
		IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);
		IFCSHomePage.gotoMerchantAndClickMerchantDetails();

		// Get Merchant Num and Location Num from DB
		String merchant = common.getMerchantNoFromDB();
		

		// create Merchant
		common.chooseMerchantNoAndSearch(merchant);
		
		
		merchantLocation.updateMerchant();

		
	}
	
	
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = {  })
	public void updateAndValidateMerchantWFE(@Optional("HK") String clientCountry,
			@Optional("WFE") String clientName) {
		
		test = extent.createTest(clientName+ ":" +clientCountry+"   Update Merchant   ",
				"Update merchant for WFE");
		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		
		Common common = new Common(driver, test);
		
		MerchantLocationPage merchantLocation = new MerchantLocationPage(driver, test);
		IFCSloginPage.login("IFCS_URL_WFE", "IFCS_WFE_USERNAME", "IFCS_WFE_PASSWORD");
		//IFCSloginPage.login("IFCS_CHV_URL", "IFCS_CHV_UN", "IFCS_CHV_PWD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		IFCSHomePage.gotoApplicationAndClickApplicationMenu();
		IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);
		IFCSHomePage.gotoMerchantAndClickMerchantDetails();

		// Get Merchant Num and Location Num from DB
		String merchant = common.getMerchantNoFromDB();
		

		// create Merchant
		common.chooseMerchantNoAndSearch(merchant);
		
		
		merchantLocation.updateMerchant();

		
	}
	
		
}
