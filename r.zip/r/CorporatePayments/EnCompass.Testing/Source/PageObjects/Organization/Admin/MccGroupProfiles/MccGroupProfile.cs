﻿using AventStack.ExtentReports;
using Common;
using Common.Utility;
using EnCompass.Testing.Source.PageObjects.Controls;
using NFluent;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;

namespace EnCompass.Testing.Source.PageObjects.Organization.Admin.MccGroupProfiles
{
    [PageModel(@"/admin/mccGroupProfiles/mccGroupProfile.aspx")]
    public class MccGroupProfile : EnCompassOrgPageModel
    {
        public override string RelativeUrl => @"/admin/mccGroupProfiles/mccGroupProfile.aspx";
        public override string PageIdentifierXPath_Override => @"//h1[contains(@id,'title')]";

        #region XPath page Elements

        private const string _descriptionMccgProfileXPath = @"//textarea[contains(@id,'Description')]";
        private const string _mccGroupXPath = @"//*[contains(@id,'MccGroupId')]";
        private const string _saveXPath = @"//input[contains(@id,'btnSave')]";
        private const string _cancelXPath = @"//button[normalize-space(text()) ='Cancel']";
        private const string _addNewMccGroupXPath = @"//button[contains(@id,'ProfileItems') and text()='Create']";
        private const string _removeMccGroupXPath = @"//button[@type='button' and text()='Remove']";
        private const string _btnDeleteXPath = @"//input[contains(@id,'btnDelete')]";
        private const string mccgProfileNameXpath = "//input[contains(@id,'Name')]";
        #endregion

        #region Page Elements

        private IWebElement _descriptionMccgProfile
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_descriptionMccgProfileXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_descriptionMccgProfile element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _mccGroup
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_mccGroupXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_mccGroup element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _save
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_saveXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_save element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _cancel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_cancelXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_cancel element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _addNewMccGroup
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_addNewMccGroupXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_addNewMccGroup element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _removeMccGroup
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_removeMccGroupXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_removeMccGroup element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _btnDelete
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_btnDeleteXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_btnDelete element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        #endregion

        public void RemoveMccGroup()
        {
            _removeMccGroup.JSClickWithFocus(Driver);
        }

        public void AddNewMccGroup()
        {
            _addNewMccGroup.JSClickWithFocus(Driver);
        }

        public string NameMccgProfile
        {
            set
            {
                Driver.TryWaitForElementToBeVisible(By.XPath(mccgProfileNameXpath), out IWebElement _nameMccgProfile);
                _nameMccgProfile.Clear();
                _nameMccgProfile.SendKeys(value);
            }
        }

        public string DescriptionMccgProfile
        {
            set
            {
                _descriptionMccgProfile.Clear();
                _descriptionMccgProfile.SendKeys(value);
            }
        }

        public void Save()
        {
            _save.JSClickWithFocus(Driver);
			this.AttachOnDemandScreenShot();
		}

        public void Cancel()
        {
            _cancel.JSClickWithFocus(Driver);
        }

        public void SetMccGroup(string whichText)
        {
            var selectElement = new SelectElement(_mccGroup);
            selectElement.SelectByText(whichText);
        }

		/// <summary>
		/// _mccgRowIndex - The index of the Row count for which MCCG is being created
		/// value - the value of the Settings DDL option on UI to choose from
		/// </summary>
		public void InformMccGroups(int _mccgRowIndex, string value="All (Global)")
        {
            var ElementMccGroups = Settings.EnCompassWebDriver.WaitForVisible(By.XPath($@"(//select[contains(@id,'MccGroupId_{_mccgRowIndex}')])"));
			// Always select the first index, "All(Global)"
			ElementMccGroups.SetListboxByText(value, SelectTextOptions.Contains);
			Settings.EnCompassExtentTest.Info("Selected Settings Value as :" + value);
		}

        public void InformNameAndDescriptionToProfile(string mccgProfileName)
        {
            NameMccgProfile = mccgProfileName;
            DescriptionMccgProfile = mccgProfileName+ " Description";
        }

        public void InformAmountLimit(List<string>amountLimitsList, int i)
        {
            var ElementAmountLimit = Settings.EnCompassWebDriver.WaitForVisible(By.XPath($@"(//input[contains(@id,'DollarSingle_{i}')])"));
            ElementAmountLimit.ForceDocumentLoadOnSendKeys(amountLimitsList[i], Settings.EnCompassWebDriver);
        }

        public void DeleteMccGroupProfile()
        {
            _btnDelete.JSClickWithFocus(Driver);
            DeleteOnModal();
        }

        public void VerifyDeleteButtonDoesntAppears()
        {
            Settings.EnCompassWebDriver.WaitForAbsence(By.XPath(_btnDeleteXPath));
        }

        //for to create n MCCGroup inside MCCG Profile
        public void CreateMCCGroupInsideMCCGProfile(int numGroups, List<string> mccGroupList, List<string> amountLimitsList, ExtentTest test)
        {
            if (!GlobalSettings.FI.ToString().Equals(StringKeys.FI.AMEX.ToString()))
            {
                for (int j = 0; j < numGroups; j++)
                {
                    InformMccGroups(j, Settings.Scenario["MccgName"+ (j+1)].ToString());
                    test.Info("set MCCG Id Profile for group index: " + j);
                    InformAmountLimit(amountLimitsList, j);
                    test.Info("Inform Amount Limit for group index: " + j);
                    AddNewMccGroup();
                    test.Info("Click to Add a New MccGroup for group index: " + j);
                }
            }
            else
            {
                for (int j = 0; j < numGroups; j++)
                {
                    string mccGroupName;
                    if (j <= 9 )
                        mccGroupName = "AUTO000" + j + " (Global)";
                    else if (j <= 99)
                        mccGroupName = "AUTO00" + j + " (Global)";
                    else if (j <= 999)
                        mccGroupName = "AUTO0" + j + " (Global)";
                    else
                        mccGroupName = "AUTO" + j + " (Global)";
                    InformMccGroups(j , "All (Global)");

					test.Info("set MCCG Profile group for group index: " + j);
                    if (j < numGroups - 1)
                    {
                        AddNewMccGroup();
                        test.Info("Click to Add a New MccGroup for group index: " + j);
                    }
                }
            }
        }

        public MccGroupProfile(GlobalSettings settings) : base(settings) { }
    }
}