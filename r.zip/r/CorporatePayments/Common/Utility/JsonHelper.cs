﻿extern alias cpt;
using System;
using System.Collections.Generic;
using System.IO;
using System.Json;

namespace Common.Utility
{
    /*
     * Class for all JSON related helper methods 
     */
    public class JsonHelper
    {
        #region Dynamic Json Parsing

        /*
         * Helper method to parse Json Array from a String content which is sent as input. Returns a dynamic C# object representation of the Json Array.
         * Below is a sample json Array:
         * this helper can handle.
         * [
         *  {
         *   id: 001
         *   name: test
         *  }
         *  {
         *   id: 002 
         *   name: test1 
         *  }
         * ]
         */
        public static dynamic parseJsonArrayFromString(String content)
        {
            dynamic deserializedObj = cpt.Newtonsoft.Json.Linq.JArray.Parse(content);
            return deserializedObj;
        }

        /*
         * Helper method to parse Json Object from a String content which is sent as input. Returns a dynamic C# object representation of the Json Object.
         * Below is a sample json Object:
         *  {
         *   id: 001
         *   name: test
         *  }
         */
        public static dynamic parseJsonObjectFromString(String content)
        {
            dynamic deserializedObj = cpt.Newtonsoft.Json.Linq.JObject.Parse(content);
            return deserializedObj;
        }

        /*
         * Helper method to parse Json Array from a Json File which is sent as input. Returns a dynamic C# object representation of the Json Array.
         * Below is a sample json Array:
         * this helper can handle.
         * [
         *  {
         *   id: 001
         *   name: test
         *  }
         *  {
         *   id: 002 
         *   name: test1 
         *  }
         * ]
         */
        public static dynamic parseJsonArrayFromFile(String filePath)
        {
            dynamic deserializedObj = null;
            using (StreamReader r = new StreamReader(filePath))
            {
                string content = r.ReadToEnd();
                deserializedObj = cpt.Newtonsoft.Json.Linq.JArray.Parse(content);
            }
            return deserializedObj;
        }

        /*
         * Helper method to parse Json Object from a Json File which is sent as input. Returns a dynamic C# object representation of the Json Object.
         * Below is a sample json Object:
         *  {
         *   id: 001
         *   name: test
         *  }
         */
        public static dynamic parseJsonObjectFromFile(String filePath)
        {
            dynamic deserializedObj = null;
            using (StreamReader r = new StreamReader(filePath))
            {
                string content = r.ReadToEnd();
                deserializedObj = cpt.Newtonsoft.Json.Linq.JObject.Parse(content);
            }
            return deserializedObj;
        }

        #endregion

        #region Static Json Parsing

        /*
         * Helper method to parse Json Array response content as per the given input list of items, and returns
         * a dictionary object corresponding to each JsonObject block in the response. Below is a sample json:
         * this helper can handle.
         * [
         *  {
         *   id: 001
         *   name: test
         *  }
         *  {
         *   id: 002 
         *   name: test1 
         *  }
         * ]
         * NOTE :  if your input content string is more complex than above structure, we need to handle it in a new helper
         */
        public static IReadOnlyDictionary<int, Dictionary<String, String>> parseJsonArrayResponse(List<String> itemsToLookFor, String content)
        {
            List<JsonObject> deserializedList = cpt.Newtonsoft.Json.JsonConvert.DeserializeObject<List<JsonObject>>(content);
            Console.WriteLine("deserializedList count: " + deserializedList.Count);
            List<JsonObject>.Enumerator e = deserializedList.GetEnumerator();
            int n = deserializedList.Count;
            Dictionary<int, Dictionary<String, String>> jsonDict = new Dictionary<int, Dictionary<String, String>>(n);
            int counter = 0;
            while (e.MoveNext())
            {
                Dictionary<String, String> dict = new Dictionary<String, String>(itemsToLookFor.Count);
                JsonObject obj = e.Current;
                itemsToLookFor.ForEach(x =>
                {
                    obj.TryGetValue(x, out JsonValue val);
                    dict.Add(x, val.ToString());
                });
                jsonDict.Add(counter++, dict);
            }
            return jsonDict;
        }

        public static dynamic parseJsonArrayResponse(String content)
        {
            dynamic stuff = cpt.Newtonsoft.Json.Linq.JObject.Parse(content);
            return stuff;
        }


        /*
         * Helper method to parse a single Json Object response content as per the given input list of items, and returns
         * a dictionary object corresponding to each JsonObject block in the response. Below is a sample json:
         * this helper can handle.         * 
         *  {
         *   id: 001
         *   name: test
         *  }
         * NOTE :  if your input content string is more complex than above structure, we need to handle it in a new helper
         */
        public static IReadOnlyDictionary<String, String> parseJsonObjectResponse(List<String> itemsToLookFor, String content)
        {
            JsonObject deserializedObj = cpt.Newtonsoft.Json.JsonConvert.DeserializeObject<JsonObject>(content);
            Dictionary<String, String> dict = new Dictionary<String, String>(itemsToLookFor.Count);
            itemsToLookFor.ForEach(x =>
            {
                deserializedObj.TryGetValue(x, out JsonValue val);
                dict.Add(x, val.ToString());
            });
            return dict;
        }

        /*
         * Helper method to take json file path as input(expects absolute pathname),
         * parse it to JsonObject and return it.
         * This method will be usually called to modify json object content prior to a Post.
         */
        public static JsonObject getJsonObjectFromFile(String filePath)
        {
            JsonObject deserializedObj = null;
            using (StreamReader r = new StreamReader(filePath))
            {
                string content = r.ReadToEnd();
                deserializedObj = cpt.Newtonsoft.Json.JsonConvert.DeserializeObject<JsonObject>(content);
            }

            return deserializedObj;
        }

        /*
         * Helper method to take json file path as input (expects absolute pathname)
         * parse it to List of JsonObjects and return it.
         * This method will be usually called to modify json object content prior to a Post.
         */
        public static List<JsonObject> getJsonArrayFromFile(String filePath)
        {
            List<JsonObject> deserializedList = null;
            using (StreamReader r = new StreamReader(filePath))
            {
                string content = r.ReadToEnd();
                deserializedList = cpt.Newtonsoft.Json.JsonConvert.DeserializeObject<List<JsonObject>>(content);
            }
            return deserializedList;
        }

        /// <summary>
        /// This method returns the TOKEN VALUE from the passed on JSON STRING.
        /// </summary>
        /// <param name="jsonString"></param>
        /// <param name="tokenName"></param>
        /// <param name="tokenInstance"></param>
        /// <returns></returns>
        public static string GetTokenTextFromJSON(string JSONMessage, string jsonString, string tokenName, int tokenInstance = 1)
        {
            cpt.Newtonsoft.Json.Linq.JToken text = cpt.Newtonsoft.Json.Linq.JObject.Parse(JSONMessage);
            return text.SelectToken($@"Items[{tokenInstance}].{tokenName}").ToString().Replace("\"", "");
        }

        /// <summary>
        /// This method returns the TOKEN VALUE from the passed JSON String expecting to have only 1 instance of the Token Key.
        /// </summary>
        /// <param name="jsonString"></param>
        /// <param name="tokenName"></param>
        /// <returns></returns>
        public static string GetTextFromJSON(string jsonString, string tokenName)
        {
            cpt.Newtonsoft.Json.Linq.JToken text = cpt.Newtonsoft.Json.Linq.JObject.Parse(jsonString);
            return text.SelectToken(tokenName).ToString().Replace("\"", "");
        }

        #endregion

    }
}
