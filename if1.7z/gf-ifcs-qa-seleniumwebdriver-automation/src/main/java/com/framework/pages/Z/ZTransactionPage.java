package com.framework.pages.Z;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.ExtentTest;
import com.framework.basepage.BasePage;
import com.framework.repo.Locator;
import com.framework.util.PropUtils;

public class ZTransactionPage extends BasePage {
	private String getDBDetailsFromProperties = "";
	private String transactionDatefrom = null;
	@FindBy(id=Locator.ACCOUNT_SEL)
	public WebElement accountTransactionSel;
	
	@FindBy(id = Locator.SEARCH_BTN)
	public WebElement searchButton;
	
	@FindBy(xpath = Locator.TRANSACTION_DATE_FROM)
	public WebElement transactionDateFrom;
	
	@FindBy(how = How.XPATH, using = Locator.ALL_LISTED_TRANSACTIONS)
	public List<WebElement> allListedTransactions;
	
	@FindBy(how = How.XPATH, using = Locator.TRANSACTION_DETAIL)
	public WebElement transactionDetails;
	
	@FindBy(how = How.XPATH, using = Locator.RETURN_TO_TRANSACTION_LIST)
	public WebElement returnToTransactionList;
	
	

	public ZTransactionPage(WebDriver driver, ExtentTest test) {

		super(driver, test);
		PageFactory.initElements(driver, this);

	}
	  // Added on 10/01/2019
	public void clickTransactionsFindTransactions() {

		mouseHoverClickMenuAndSubMenu("Transactions", "Find Transactions");

	}

	public void selectAllAccountsAndSearch() {

		selectDropDownByVisibleText(accountTransactionSel, "All Accounts");
		sleep(2);
		isDisplayedThenClick(searchButton, "Search button");
		
	}
	
	public void getTransactionDateFromTheDBForTheCurrentInternetUser(String userName,String clientName) {
		
		try {
			getDBDetailsFromProperties = PropUtils.getPropValue(configProp, "sqlODSServerName");
			// clientNameForDBConnection = clientName;

			String queryToGetTransactionDate = "Select tr.processed_at from transactions tr inner join m_customers mcu  on mcu.customer_mid = tr.customer_mid  inner join m_clients mcl on  mcu.client_mid = mcl.client_mid  inner join accounts a on mcu.customer_mid = a.customer_mid inner join internet_users iu on mcl.client_group_mid = iu.client_group_mid where mcu.client_mid =(Select client_mid from m_clients where name ='"+clientName+"') and iu.logon_id = 'Zcustomer' and rownum = 1";
			transactionDatefrom = connectDBAndGetValue(queryToGetTransactionDate, getDBDetailsFromProperties);
			
			
			transactionDatefrom = transactionDatefrom.substring(0, 10);

			DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd"); 
			
			System.out.println("Transaction Date is very first time"+transactionDatefrom);
			
			
			 
			Date date = (Date)formatter.parse(transactionDatefrom);
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy");
			transactionDatefrom = simpleDateFormat.format(date);
			transactionDatefrom = transactionDatefrom.replaceAll("-","/");
			
          System.out.println(transactionDatefrom);
			
		}

		catch (Exception e) {
			logFail(e.getMessage());
		}
		
	}
	
	public void selectAllAccountsdTransactionDateAndSearch() {
	
		selectDropDownByVisibleText(accountTransactionSel, "All Accounts");
		//waitForTextToAppear("Transaction Date From",30);
		sleep(2);
		//waitForElementTobeClickable(transactionDateFrom, 30);
		isDisplayedThenEnterText(transactionDateFrom,"Transaction Date From" , transactionDatefrom);
		//waitForElementTobeClickable(searchButton,30);
		sleep(2);
		isDisplayedThenClick(searchButton, "Search button");
		
	}
	
	public void goToTransactionDetailScreen() {
		
		if(allListedTransactions.size()>0) {
			isDisplayedThenClick(allListedTransactions.get(0),"Transaction List");
			waitForElementTobeClickable(transactionDetails, 30);
			isDisplayedThenClick(transactionDetails,"Transaction Detail Screen");
			isDisplayed(returnToTransactionList,"Return To Transaction List");
		}
		else {
			logInfo("Transaction Details are not Found");
		}
		
	}
}
