package com.framework.testcases.OLS.CHEV.Merchant;

import org.openqa.selenium.By;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.CHEV.CHHomePage;
import com.framework.pages.CHEV.CHStoredReportsPage;
import com.framework.pages.OLS.common.LoginPage;
import com.framework.pages.OLS.common.MerchantReportsPage;

public class ValidateOLSMerchantSiteValidations extends BaseTest {

	@Parameters({ "clientCountry", "clientName" })
	@Test(priority = 1)
	public void testOLSMerchantSiteValidations(@Optional("TH") String clientCountry,
			@Optional("CHV") String clientName) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  OLS - Merchant Site - Login Page - Validations",
				"Chevron Merchant Screens Read Only Role");

		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		
		loginPage.verifyHyperlinkPresent();
		loginPage.verifyFooterHyperlinkPresent();
		
		CHHomePage chHomePage = new CHHomePage(driver, test);

		if (clientCountry.equals("SG")||clientCountry.equals("MY")||clientCountry.equals("HK")) {
			loginPage.Login("CHV_URL", "CHV_Merchant_UN_"+clientCountry, "CHV_Merchant_PWD_"+clientCountry, "CHV");
//			chHomePage.verifyUserName("Hello, Test");
			chHomePage.verifyMerchantAccountDetails();
		} else if (clientCountry.equals("TH")) {
			loginPage.Login("CHV_URL", "CHV_Merchant_UN_"+clientCountry, "CHV_Merchant_PWD_"+clientCountry, "CHV");
//			chHomePage.verifyUserName("Hello, THuser");
		} else if (clientCountry.equals("PH")) {
			loginPage.Login("CHV_URL", "CHV_Merchant_UN_"+clientCountry, "CHV_Merchant_PWD_"+clientCountry, "CHV");
//			chHomePage.verifyUserName("Hello, PHuser");
		}
		
		chHomePage.verifyHomePageText();
		chHomePage.verifyFooterLinks();
		loginPage.Logout();

	}
	
	
}
