using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using Common;
using Common.PageObjects;
using Common.ScenarioConfigurations;
using Common.Utility;

namespace EnCompass.Testing.Source.PageObjects.SuperAdmin.RoleManagement 
{
	/// <summary>
	/// Auto-generated Page Model Class
	/// Navigation Paths: 
		/// [Organization Home]->Users and Organizations->Privileges
		/// </summary>
	[PageModel(@"/superAdmin/roleManagement/modifyrole.aspx")]
	public partial class ModifyRole : EnCompassSuperPageModel 
	{
		public override string RelativeUrl => @"/superAdmin/roleManagement/modifyrole.aspx";
        public override string PageIdentifierXPath_Generated => @"//li[contains(@class, 'breadcrumb-item active')][text() = 'Privileges']";

        #region Navigation

        private void NavigateToMenuItem(IWebElement element)
		{
			Driver.Url = element.GetAttribute("href");
		}
		#endregion

		public ModifyRole(GlobalSettings settings) : base(settings) { }
	}  
}
