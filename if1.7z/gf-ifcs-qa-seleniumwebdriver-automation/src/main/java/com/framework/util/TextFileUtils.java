package com.framework.util;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.LineIterator;

public class TextFileUtils {

	public void validateTextFileWithString(String fileName,String cardNo)
	{
		
	LineIterator it = null;
	 
	 
	 try {
		 File file = new File(fileName);
   	 
   	 it = FileUtils.lineIterator(file, "UTF-8");
	   while (it.hasNext()) {
	     String line = it.nextLine();
	     String block = null;
	     
	     if(line.contains("[")) {
	    	 block = line;
	     }
	     
	     if(line.contains(cardNo)) {
	    	 System.out.println("Line :"+line);
	    	 System.out.println("Card number present in FIle");
	    	 System.out.println("Card number present in block"+block);
	    	 break;
	     }
	   }
	 } catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		
	} finally {
		 LineIterator.closeQuietly(it);
	 }
	 
	}

}
