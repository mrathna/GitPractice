using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using Common;
using Common.PageObjects;
using Common.ScenarioConfigurations;
using Common.Utility;

namespace EnCompass.Testing.Source.PageObjects.Organization.ExpenseManager.Transactions 
{
	/// <summary>
	/// Auto-generated Page Model Class
	/// Navigation Paths: 
		/// [Organization Home]->Transactions->Financial Codes->Profiles->Assign Cards
		/// </summary>
	[PageModel(@"/expenseManager/transactions/FinancialCodeProfileSearchCards.aspx")]
	public partial class FinancialCodeProfileSearchCards : EnCompassOrgPageModel 
	{
		public override string RelativeUrl => @"/expenseManager/transactions/FinancialCodeProfileSearchCards.aspx";
		public override string PageIdentifierXPath_Generated => @"//li[contains(@class, 'breadcrumb-item active')][text() = 'Assign Cards']";

		#region Navigation
				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Profiles']")]
		private IWebElement _transactions_FinancialCodes_Profiles_AssignCards_Profiles { get; set; }
		public void NavigateTo_Transactions_FinancialCodes_Profiles_AssignCards_Profiles()
		{
			NavigateToMenuItem(_transactions_FinancialCodes_Profiles_AssignCards_Profiles);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Assign Cards']")]
		private IWebElement _transactions_FinancialCodes_Profiles_AssignCards_AssignCards { get; set; }
		public void NavigateTo_Transactions_FinancialCodes_Profiles_AssignCards_AssignCards()
		{
			NavigateToMenuItem(_transactions_FinancialCodes_Profiles_AssignCards_AssignCards);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Assign Hierarchies']")]
		private IWebElement _transactions_FinancialCodes_Profiles_AssignCards_AssignHierarchies { get; set; }
		public void NavigateTo_Transactions_FinancialCodes_Profiles_AssignCards_AssignHierarchies()
		{
			NavigateToMenuItem(_transactions_FinancialCodes_Profiles_AssignCards_AssignHierarchies);
		}

		
		private void NavigateToMenuItem(IWebElement element)
		{
			Driver.Url = element.GetAttribute("href");
		}
		#endregion

		public FinancialCodeProfileSearchCards(GlobalSettings settings) : base(settings) { }
	}  
}
