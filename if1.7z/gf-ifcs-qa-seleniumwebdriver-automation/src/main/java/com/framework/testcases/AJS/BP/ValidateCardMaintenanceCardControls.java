package com.framework.testcases.AJS.BP;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basepage.BasePage;
import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.CardMaintenancePage;
import com.framework.pages.AJS.common.Common;
import com.framework.pages.AJS.common.IFCSHomePage;
import com.framework.pages.AJS.common.IFCSLoginPage;

public class ValidateCardMaintenanceCardControls extends BaseTest{
	 @Parameters({ "clientCountry", "clientName" })
	    @Test(groups = { "Regression","BusinessFlow" })
	    public void testCardMaintenanceCardControls(@Optional("AU") String clientCountry,
	                                                               @Optional("BP") String clientName){
	        test = extent.createTest(clientName+ ":" +clientCountry+"  testCardMaintenanceCardControlsChangeDailyVolumeSoftLimit", "Create a private profile for card");

	        // creating object for the Pages
	        IFCSLoginPage ifcsLoginPage = new IFCSLoginPage(driver, test);
	        ifcsLoginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
	        Common common = new Common(driver, test);
	            IFCSHomePage ifcsHomePage = new IFCSHomePage(driver, test);
	        CardMaintenancePage cardMaintenancePage = new CardMaintenancePage(driver, test);
	        
	        ifcsLoginPage.login("IFCS_URL_BP", "IFCS_BP_USERNAME", "IFCS_BP_PASSWORD");
	        ifcsHomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);
	        ifcsHomePage.gotoCustomerMenuCustomerDetails();
	        String cardNum=common.getActiveCardNumberFromDBWhichDoesNotHavePrivateProfile();
	        cardMaintenancePage.chooseAndSearchCardNo(cardNum);
	        cardMaintenancePage.createPrivateProfileForACard();
	     //   basePage.scrollDownPage(); moved to createPrivateProfileForACard()
	        String privateProfileDescription = common.fakerAPI().getClass().getName();
	        cardMaintenancePage.enterPrivateProfileDescription(privateProfileDescription);
	      //  basePage.scrollDownPage(); //moved to  enterPrivateProfileDescription(privateProfileDescription);
	        common.chooseOptionFromDropdown("Daily Volume Soft Limit","100 litres");
	        common.chooseOptionFromDropdown("Daily Transaction Soft Limit","4 Transactions");
	        common.chooseOptionFromDropdown("Monthly Volume Soft Limit","2000 litres");
	        cardMaintenancePage.saveProfileAndValidateMessage();
	        common.chooseSubMenuFromLeftPanel("Customer Profiles","Maintain Card Controls");
	        common.validatePrivateProfileDescription(privateProfileDescription);
	        ifcsHomePage.exitIFCS();
	    }
}
