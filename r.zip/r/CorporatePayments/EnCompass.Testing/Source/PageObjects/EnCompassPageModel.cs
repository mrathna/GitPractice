﻿using AventStack.ExtentReports;
using Common;
using Common.PageObjects;
using Common.Utility;
using EnCompass.Testing.Source.PageObjects.Common;
using EnCompass.Testing.Source.PageObjects.Organization.Payables.MerchantPayments;
using EnCompass.Testing.Source.PageObjects.SuperAdmin.UserEmulatorSearch;
using NFluent;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EnCompass.Testing.Source.PageObjects
{
	public class EnCompassPageModel : PageModel
	{
		private const string LOGOUT_XPATH = @"//a[normalize-space(text())='Log Out']";
		private const string USER_DROPDOWN_XPATH = "//a[contains(@id, 'accountDropdown')]";
        private const string LANG_SELECT_XPATH = @"//a[normalize-space(text())='{0}']";
        private const string LANG_DROPDOWN_XPATH = "//a[contains(@id, 'languageDropdown')]";
        private const string LANG_DESC_XPATH = "//span[normalize-space(text())='{0}']";
        private string logoutDDLXpath = "//*[@id='accountDropdown']";

        #region OrgID
        protected const string ORG_GROUP_LABEL_XPATH = "//a[contains(@id, 'accountDropdown')]/span";

		protected IWebElement _orgGroup
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(ORG_GROUP_LABEL_XPATH), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_orgGroup element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        #endregion

        #region SuccessMessage

        private const string SUCCESS_MESSAGE_XPATH = "//div[contains(@id,'SuccessMessage') or contains(@id, 'ValidationAlertMessages') and string-length(normalize-space(text())) > 0] | " +
            "//div[@data-encompass-table-success-message and string-length(normalize-space(text())) > 0]";         
        
        private IWebElement _successMessage
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(SUCCESS_MESSAGE_XPATH), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_successMessage element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
       
		public string SuccessMessage { get { return  (HasSuccessMessage)?_successMessage.Text.Trim(): null; } }

		public bool HasSuccessMessage
		{
			get
			{
				try
				{
					this.AttachOnDemandScreenShot();
                    int _timeOut = 10;
                    if (GlobalSettings.Browser.Equals(GlobalSettings.Browsers.FIREFOX.ToString()) || 
                        GlobalSettings.Browser.Equals(GlobalSettings.Browsers.IE.ToString()) )
                        _timeOut = 20;
					else if(GlobalSettings.DeviceType.Equals(GlobalSettings.Device.MOBILE.ToString()))
						_timeOut = 60;

					Settings.EnCompassExtentTest.Debug("Inside HasSuccessMessage.  Timeout =" + _timeOut.ToString());
					// First check the message is not present (this happens when on the same page we get 2 success messages upon
					// successive clicks, without this check it will fail
					try
					{
                        Driver.WaitForAbsence(By.XPath(SUCCESS_MESSAGE_XPATH), TimeSpan.FromSeconds(_timeOut));
						Settings.EnCompassExtentTest.Info("Success message is absent, now will wait for it to appear.");
					}
                    catch(Exception)
					{
                        Settings.EnCompassExtentTest.Info("Success message might be present before code reached here, hence ignoring the failure."); 
					}

                    var isDisplayed = Settings.EnCompassWebDriver.WaitForVisible(By.XPath(SUCCESS_MESSAGE_XPATH), 
                        TimeSpan.FromSeconds(_timeOut)).Displayed;
					Settings.EnCompassExtentTest.Info("Got Displayed Property for Success Message as :" + isDisplayed);
					// Refresh the page model after success message is seen, this will initialize the page factory elements
					// which are otherwise not visible
					this.RefreshModel();
					Settings.EnCompassExtentTest.Info("Executed Refresh Model on Page Object");
					// included isDisplayed below to prevent the compiler from optimizing out the line above (just in case)
					return isDisplayed || true;
				}
				catch(Exception ex)
				{
					Settings.EnCompassExtentTest.Warning("Exception Caught : " + ex.Message);
					//scroll to top of the page, for ease of taking screenshot which would conclusively
					// help determine if the message is present or not. 
					Driver.JsScrollToTop();
					Settings.EnCompassExtentTest.Warning("Success Message not present on UI");
					return false;
				}
				finally
				{
					Driver.JsScrollToTop();
					this.AttachOnDemandScreenShot();
				}
			}
		}

        #endregion

        #region ErrorMessages
        
        private const string ERROR_MESSAGE_XPATH = "//div[contains(@id,'_ValidationSummary')]";
		private const string BUTTON_POP_ERRORS_XPATH = @"//button[contains(@id,'popErrors')]";
		/// <summary>
		/// Check is page has error messages or not
		/// </summary>
		public bool HasErrorMessages
		{
			get
			{
				try
				{
					var isDisplayed = Settings.EnCompassWebDriver.WaitForVisible(By.XPath(ERROR_MESSAGE_XPATH)).Displayed;
					Settings.EnCompassExtentTest.Info("Got Displayed Property for Error Message as :" + isDisplayed);

					this.AttachOnDemandScreenShot();
					return isDisplayed;
				}
				catch
				{
					Settings.EnCompassExtentTest.Warning("Error Message not present on UI");
					return false;
				}
			}
		}

		public string GetErrorMessages
		{
			get
			{
				return Settings.EnCompassWebDriver.WaitForVisible(By.XPath(ERROR_MESSAGE_XPATH)).Text;
			}
		}

		public string[] GetErrorMessagesAsList
		{
			get
			{
				var text = GetErrorMessages;
				string[] result = text.Split(new string[] { "\n", "\r\n" }, StringSplitOptions.RemoveEmptyEntries);
				return result;
			}
		}
		
        public bool verifyErrorMessagesInGrid(string msg)
        {
            Driver.TryWaitForElementToBeVisible(By.XPath(BUTTON_POP_ERRORS_XPATH), out IWebElement btnError);
            return btnError.GetAttribute("data-content").ToLowerInvariant().Contains(msg.ToLowerInvariant());
        }

		#endregion

		#region Validation Summary

		[FindsBy(How = How.XPath, Using = @"//div[contains(@id, 'ValidationSummary')]//ul/li")] //p
        private IList<IWebElement> _vaildationSummary { get; set; }

        public bool HasValidationMessage(string message, bool isExact)
        {
            // The new grid is using JS to populate validation messages. We have to wait for it to show up. 
            Driver.TryWaitForElementToBeVisible(GetBy(() => this._vaildationSummary), out IWebElement el, TimeSpan.FromSeconds(2));
            return isExact ? _vaildationSummary.Any(v => v.Text.Equals(message)) : _vaildationSummary.Any(v => v.Text.Contains(message));
        }

        #endregion

        #region Info Summary

        private const string INFORMATION_MESSAGE_XPATH = @"//div[contains(@id, 'InformationMessage')]/p";
        private IWebElement _informationSummary
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(INFORMATION_MESSAGE_XPATH), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_informationSummary element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public bool HasInformationMessage(string message, bool isExact)
        {
            return isExact ? _informationSummary.Text.Equals(message) : _informationSummary.Text.Contains(message);
        }
        #endregion

        private const string ORG_LIST_XPATH = @"//select[contains(@id, 'ddlOrgList')]";
		private IWebElement _orgList
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(ORG_LIST_XPATH), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_orgList element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private const string TERMS_LINK_XPATH = "//a[contains(@id,'Terms')]";
        public bool _IsTermsLinkPresent
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(TERMS_LINK_XPATH), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_orgList element exist is" + found);
                return found;
            }
        }

        #region Grid

        public void VerifyGridNoRecordsMessage(string expErrMsg)
		{
			string _actErrMsg = Driver.WaitForVisible(By.XPath("//td[@class='gridNoRecordsMessage']"), TimeSpan.FromSeconds(3.0)).GetAttribute("innerText");
			Check.That(_actErrMsg.Trim().ToLower()).Equals(expErrMsg.Trim().ToLower());
		}

        public void VerifyNewGridNoRecordsMessage(string expErrMsg)
        {
            string _actErrMsg = Driver.WaitForVisible(By.XPath("//tr[@class='no-records-found']//td"), TimeSpan.FromSeconds(3.0)).GetAttribute("innerText");
            Check.That(_actErrMsg.Trim().ToLower()).Equals(expErrMsg.Trim().ToLower());
        }

        #endregion

        #region Site Headers

        private const string UndoUserEmulationMenu = @"//div[contains(@id,'EmulationPanel')]//button[contains(@id,'endEmulationButton')]";
        private const string _selectOrgActionXPath = @"//li[contains(@id, 'selectOrg')]/a[contains(@class, 'nav-link')]|//li[contains(@class, 'nav-item')]/a[contains(@id, 'SuperAdmin')]";
        private const string _superAdminUtilitiesXPath = @"//li[contains(@id, 'selectOrg')]/a[contains(@class, 'nav-link')]|//li[contains(@class, 'nav-item')]/a[contains(@id, 'SuperAdmin')]";
        private const string _undoUserEmulationBtnXPath = @"//a[contains(@id, 'lbUndoEmulate')][text()='User Emulator']";
        private const string _SuperAdminXPath = "//li[contains(@class, 'nav-item')]/a[contains(@id, 'SuperAdmin')]";

        private IWebElement _selectOrgAction
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_selectOrgActionXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_selectOrgAction element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

		private IWebElement _superAdminUtilities
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_superAdminUtilitiesXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_superAdminUtilities element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

		private IWebElement _undoUserEmulationBtn
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_undoUserEmulationBtnXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_undoUserEmulationBtn element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _undoUserEmulationMenu
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(UndoUserEmulationMenu), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_undoUserEmulationMenu element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

		protected IWebElement _userDropdown
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(USER_DROPDOWN_XPATH), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_userDropdown element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private string _menuItems = ".//div[@id='mainNav']/div[contains(@id,'MainMenu2')]";

		public bool IsLoggedIn
		{
			get
			{
				try
				{
                    _userDropdown.JSClickWithFocus(Driver);
					var isDisplayed = Driver.TryWaitForElementToBeVisible(By.XPath(LOGOUT_XPATH), out IWebElement _logoutAction);
					// included isDisplayed below to prevent the compiler from optimizing out the line above (just in case)
					return isDisplayed || _logoutAction.Displayed;

				}
				catch { return false; }
			}
		}

		public string OrgGroup
		{
			get
			{
				return _orgGroup.Text.Split(new string[] { "\r", "\n", "\r\n" }, StringSplitOptions.RemoveEmptyEntries)[2].Trim();
			}
		}

		public void ShowUserDropdown()
		{
			Actions act = new Actions(Driver);
			act.MoveToElement(Driver.FindElement(By.XPath(USER_DROPDOWN_XPATH))).Perform();
		}
		
        public void Logout()
		{
            //Build action to activate the dropdown menu and after move the mouse to click on the logout button
            Driver.TryWaitForElement(By.XPath(logoutDDLXpath), out IWebElement _logOutDropdown);
			_logOutDropdown.WaitUntilElementIsInteractable();
            //For Firefox we have to scroll to logout drop down else will fail
            //Scroll is getting failed for IE execution in bamboo, its working for Firefox
            if (GlobalSettings.Browser.Equals("FIREFOX"))
            {
                _logOutDropdown.JsScrollToElement(Driver);
            }
            ClickAndHold(logoutDDLXpath);
            Settings.EnCompassExtentTest.Info("Scrolled to _logOutDropdown with xpath:" + logoutDDLXpath);
            // If the above mousde move is success then we expect logout option to be visible on UI
            bool found = Driver.TryWaitForElementToBeVisible(By.XPath(LOGOUT_XPATH), out IWebElement _logoutAction);
            if (found)
            {
                _logoutAction.JsScrollToElement(Driver);
                Settings.EnCompassExtentTest.Info("Scrolled to _logoutAction with xpath:" + LOGOUT_XPATH);
                _logoutAction.JSClickWithFocus(Driver);
                Settings.EnCompassExtentTest.Info("Mouse moved and Clicked on Log out Action");
                Settings.EnCompassExtentTest.Info("_logoutAction with xpath: " + LOGOUT_XPATH + " is visible on UI");
            }
            else
            {
                Settings.EnCompassExtentTest.Warning("_logoutAction with xpath: " + LOGOUT_XPATH + " is not visible on UI. Still trying to click");
                throw new Exception("Logout is not visible on UI");
            }

            


        
		}

        public void SelectLanguage(string lang)
        {
            Driver.TryFindElement(By.XPath(LANG_DROPDOWN_XPATH),out IWebElement _dropdown);
            _dropdown.WaitUntilElementIsInteractable();
            
            Actions action = new Actions(Driver);

            action.MoveToElement(_dropdown).Click().Build().Perform();
            Settings.EnCompassExtentTest.Info("Language dropdown selected");

            Driver.TryFindElement(By.XPath(String.Format(LANG_SELECT_XPATH, lang)), out IWebElement _lang);

            Actions anotherAction = new Actions(Driver);
            anotherAction.MoveToElement(_lang).Click().Perform();

            if (lang != "Clear")
            {
                Driver.TryFindElement(By.XPath(String.Format(LANG_DESC_XPATH,lang)), out IWebElement _selectedOption);
                Settings.Scenario["Language"] = _selectedOption.Text;
                Settings.EnCompassExtentTest.Info(String.Format("Language {0} selected", _selectedOption.Text));
            }
        }
        

        private string _stayInTheOrgXpath = ".//a[contains(@id,'_lbUndoEmulate_StayInOrg')]";
        private string _userEmulatorXpath = ".//a[contains(@id,'_lbUndoEmulate') and normalize-space(text())='User Emulator']";
        public void UndoUserEmulation(bool ignoreIfAbsent = false, string mode = "user emulator")
        {
			if (!ignoreIfAbsent)
			{
				try
				{
                    Driver.TryWaitForElementToBeVisible(By.XPath(UndoUserEmulationMenu), out IWebElement _undoUserEmulationMenu);

                    _undoUserEmulationMenu.JSClickWithFocus(Driver);
                    Settings.EnCompassExtentTest.Info("Clicked on undoUserEmulationMenu Button");

                    IWebElement undoEmulMode = null;
                    if (mode.ToLowerInvariant().Contains("user emulator"))
                    {
                        Settings.EnCompassWebDriver.TryWaitForElementToBeVisible(By.XPath(_userEmulatorXpath), out undoEmulMode);
                        Settings.EnCompassExtentTest.Info("Undo User Emulation mode set to 'User Emulator'");
                        undoEmulMode.JSClickWithFocus(Driver);
                        Settings.EnCompassExtentTest.Info("Undo User Emulation is done");
                        // Wait for user emulator search pagfe to load
                        UserEmulatorSearch userEmulSearchPage = new UserEmulatorSearch(Settings);
                        userEmulSearchPage.WaitForLoad();
                        Settings.EnCompassExtentTest.Info("User Emulator Search page loaded after Undo User Emulation is done");
                    }
                    else if (mode.ToLowerInvariant().Contains("stay in this organization"))
                    {
                        Settings.EnCompassWebDriver.TryWaitForElementToBeVisible(By.XPath(_stayInTheOrgXpath), out undoEmulMode);
                        Settings.EnCompassExtentTest.Info("Undo User Emulation mode set to 'Stay in this Organization'");
                        undoEmulMode.JSClickWithFocus(Driver);
                        Settings.EnCompassExtentTest.Info("Undo User Emulation is done");
                        // Wait for Srartup.aspx to load
                        OrgHomeModel orgHomeModel = new OrgHomeModel(Settings);
                        orgHomeModel.WaitForLoad();
                        Settings.EnCompassExtentTest.Info("Org Home Model (startup.aspx) loaded after Undo User Emulation is done");
                    }

                    AttachOnDemandScreenShot();
                    if (Settings.IsEmulationModeOn)
                    {
                        // turn off emulation mode flag once its turned off on the UI
                        Settings.IsEmulationModeOn = false;
                    }
                }
				catch
				{
					if (!ignoreIfAbsent)
					{
						throw;
					}
				}
			}
		}

		private static string _modalBaseXpath = ".//div[contains(@id,'Modal_') and @data-focus='true']";
		/// <summary>
		/// Checks if a Modal is present. 
		/// </summary>
		public bool WaitForModalToAppear(string modalBaseXpath = null, double timeInSec = 20)
		{
			modalBaseXpath = modalBaseXpath ?? _modalBaseXpath;
			try
			{
                //Driver.TryWaitForElement(By.XPath(modalBaseXpath), out IWebElement element,TimeSpan.FromSeconds(timeInSec));
                Driver.WaitFor(By.XPath(modalBaseXpath), TimeSpan.FromSeconds(timeInSec));
                Settings.EnCompassExtentTest.Info("Modal appeared with base Xpath:" + modalBaseXpath);
				return true;
			}catch(WebDriverTimeoutException)
			{
				Settings.EnCompassExtentTest.Warning($"Modal did not appear within {timeInSec.ToString()} secs");
				return false;
			}
		}

		public void WaitForModalToDisappear(string modalBaseXpath = null, double timeInSec = 20)
		{
			modalBaseXpath = modalBaseXpath ?? _modalBaseXpath;
			try
			{
				Driver.WaitForAbsence(By.XPath(modalBaseXpath), TimeSpan.FromSeconds(timeInSec));
				Settings.EnCompassExtentTest.Info("Modal disappeared.");
			}
			catch (WebDriverTimeoutException ex)
			{
				Settings.EnCompassExtentTest.Warning($"Modal did not disappear within {timeInSec.ToString()} secs");
				throw ex;
			}
		}

		private static string _modalPrimaryButtonXpath = "//button[text() = 'Confirm' or text()='Yes' or text()='Close' or text()='Submit' or  text()='Reject' or text()= 'Save' or text()= 'Delete']";

		// This clicks on the Confirm button on the modal
		virtual public bool ConfirmOnModal(string modalBaseXpath = null, double timeInSec = 30)
		{
            modalBaseXpath = modalBaseXpath ?? _modalBaseXpath;
            bool val = WaitForModalToAppear(modalBaseXpath, timeInSec);
            if (val)
            {
				string confirmButtonOnModalXpath = modalBaseXpath + _modalPrimaryButtonXpath;

				Driver.WaitElementBeClickable(confirmButtonOnModalXpath);
                Settings.EnCompassExtentTest.Info("Confirm button is clickable");
                Driver.FindElement(By.XPath(confirmButtonOnModalXpath)).JSClickWithFocus(Driver, confirmButtonOnModalXpath,Settings);
				Settings.EnCompassExtentTest.Info("Accepted Modal with default primary button click");
				// Verify if the modal is gone before proceeding
				WaitForModalToDisappear(modalBaseXpath, timeInSec);
			}
			else
				Settings.EnCompassExtentTest.Info("Could not confirm/accept the modal as modal did not appear.");

			return val;
		}

        private static string _modalSecondaryButtonXpath = "//button[contains(@class,'btn-secondary')]";
		// This clicks on cancel on a modal
		public bool CancelOnModal(string modalBaseXpath = null, double timeInSec = 30)
        {
			modalBaseXpath = modalBaseXpath ?? _modalBaseXpath;
			bool val = WaitForModalToAppear(modalBaseXpath,timeInSec);
			if (val)
			{
				string _cancelButtonOnModalXpath = modalBaseXpath + _modalSecondaryButtonXpath;
				Driver.WaitElementBeClickable(_cancelButtonOnModalXpath);
                Settings.EnCompassExtentTest.Info("Cancel button is clickable");
                Driver.FindElement(By.XPath(_cancelButtonOnModalXpath)).JSClickWithFocus(Driver, _cancelButtonOnModalXpath,Settings);
				Settings.EnCompassExtentTest.Info("Accepted Modal with default primary button click");
			}
			else
				Settings.EnCompassExtentTest.Info("Could not confirm/accept the modal");

			return val;
		}

        private static string _modalDeleteButtonXpath = "//button[text() = 'Delete']";
        // This clicks on cancel on a modal
        public bool DeleteOnModal(string modalBaseXpath = null, double timeInSec = 30)
        {
			modalBaseXpath = modalBaseXpath ?? _modalBaseXpath;
			bool val = WaitForModalToAppear(modalBaseXpath,timeInSec);
            if (val)
            {
				string _deleteButtonOnModalXpath = modalBaseXpath + _modalDeleteButtonXpath;
				Driver.FindElement(By.XPath(_deleteButtonOnModalXpath)).JSClickWithFocus(Driver, _deleteButtonOnModalXpath,Settings);
                Settings.EnCompassExtentTest.Info("Accepted Modal with delete  button click");
            }
            else
                Settings.EnCompassExtentTest.Info("Could not confirm/accept the modal");

            return val;
        }

        public void SuperAdminUtilites()
		{
			// Super Admin Utlities can be reached by 2 ways. If org is selected then its accessed via 
			// "Admin Tools" gear icon else, if org is not selected, then try Home tab.
			try
			{
				// Try with Admin Tools options
				Driver.TryWaitForElementToBeVisible(By.XPath(_SuperAdminXPath), out IWebElement _superAdminUtilitiesFromOrgView);
				_superAdminUtilitiesFromOrgView.JSClickWithFocus(Driver, _SuperAdminXPath,Settings);
			} catch (Exception)
			{
				// If exception is throws proceed with Home tab
				_superAdminUtilities.JSClickWithFocus(Driver);
			}
		}

		/// <summary>
		/// Gets all the menu items displayed on the UI like: ADMIN,SECURITY  MANAGER,PAYABLES,REPORT STUDIO,CARD MGMT,TRANSACTION MAINT,HELP
		/// </summary>
		public List<string> MenuItems
		{
			get
			{
				return Driver.FindElements(By.XPath(_menuItems)).ToList().Select(d => d.GetAttribute("innerText").Trim()).ToList<string>();
			}
		}

        public string GetJavaScriptAlert()
        {
            IAlert alert = Settings.EnCompassWebDriver.SwitchTo().Alert();
            return alert.Text;
        }

        #endregion

        #region Site Footers

        private const string _footerBuildNumberXPath = @"//span[contains(@id, 'lblBuildnumber')]";
		private IWebElement _footerBuildNumber
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_footerBuildNumberXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_footerBuildNumber element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        #endregion

        #region Wait Methods

        public void WaitForModalLoadingOverlay(TimeSpan? tSpan = null)
		{
			Driver.WaitFor(By.XPath("//div[contains(@id, 'ModalLoader')]"), tSpan ?? TimeSpan.FromSeconds(10));
            //In IE WaitForAbsence taking more time to disapper spinner
            if (GlobalSettings.Browser.ToUpper() == GlobalSettings.Browsers.IE.ToString().ToUpper())
            {
                tSpan = TimeSpan.FromSeconds(20);
            }
			Driver.WaitForAbsence(By.XPath("//div[contains(@id, 'ModalLoader')]"), tSpan ?? TimeSpan.FromSeconds(10));
		}

		#endregion

		#region Sorting Methods

		/// <summary>
		/// Common helper to verify sorting on a particular dataset
		/// </summary>
		public bool VerifyValuesHonoringSortOrder(IReadOnlyCollection<string> _values, string sortOrder, ExtentTest test)
		{
			IReadOnlyCollection<string> _orderedList = null;
			test.Info("Expected List for " + sortOrder + " sort :" + string.Join(",", _values));

			// the sort order displayed is actually reversed
			if (sortOrder.ToLowerInvariant().Equals("ascending"))
			{
				_orderedList = _values.OrderByDescending(d => d).ToList();
				test.Info("Ordered List for Ascending sort :" + string.Join(",", _orderedList));
				return _values.SequenceEqual(_orderedList);
			}
			else if (sortOrder.ToLowerInvariant().Equals("descending"))
			{
				_orderedList = _values.OrderBy(d => d).ToList();
				test.Info("Ordered List for Descending sort :" + string.Join(",", _orderedList));
				return _values.SequenceEqual(_orderedList);				
			}
			else
				return false;
		}

		#endregion

		public override string PageIdentifierXPath_Generated => "//a[@id='accountDropdown']";
		public override string RelativeUrl => null;
		public string GetFooterBuildNumber
		{
			get
			{
				return _footerBuildNumber.GetAttribute("innerText");
			}
		}

		public string OrgList
		{
			get { return new SelectElement(_orgList).SelectedOption.Text.Trim(); }
			set
            {
                _orgList.SetListboxByText(value);
                WaitForLoad();
            } 
		}

        protected void ExpandCardHeader(string cardBodyID, string cardHeaderId)
        {
            IWebElement _nToggle = Driver.WaitFor(By.XPath($"//div[contains(@id, '{cardBodyID}')]/div[contains(@id, '{cardHeaderId}')]/h2/button[@data-toggle='collapse']"));
            bool isExpanded = (_nToggle.GetAttribute("aria-expanded").Equals("true")) ? true : false;
            if (!isExpanded)
                _nToggle.JSClickWithFocus(Driver);
            this.RefreshModel();
        }
        protected void CollapseCardHeader(string cardBodyID, string cardHeaderId)
        {
            IWebElement _nToggle = Driver.WaitFor(By.XPath($"//div[contains(@id, '{cardBodyID}')]/div[contains(@id, '{cardHeaderId}')]/h2/button[@data-toggle='collapse']"));
            bool isExpanded = (_nToggle.GetAttribute("aria-expanded").Equals("true")) ? true : false;
            if (isExpanded)
                _nToggle.JSClickWithFocus(Driver);
            this.RefreshModel();
        }

        // This method could be an extension method in SeleniumExtensions. However, we need 'settings' object which is
        // defined in this project, while SeleniumExtensions belongs in Utility.
        public IWebElement GetIWebElement(IWebDriver driver, By by, string elementNameInLog, TimeSpan? tSpan = null)
        {
            bool found = SeleniumExtensions.TryWaitForElement(driver, by, out IWebElement element, tSpan);
            Settings.EnCompassExtentTest.Info($"{elementNameInLog} element exists is {found}");

            try
            {
                Check.That(found).IsTrue();
            }
            catch (Exception e)
            {
                Settings.EnCompassExtentTest.Info($"{elementNameInLog} element could not be found.");
                throw e;
            }

            return element;
        }

        public IWebElement GetIWebElementWhenVisible(IWebDriver driver, By by, string elementNameInLog, TimeSpan? tSpan = null)
        {
            bool found = SeleniumExtensions.TryWaitForElementToBeVisible(driver, by, out IWebElement element, tSpan);
            Settings.EnCompassExtentTest.Info($"{elementNameInLog} element exists is {found};");

            try
            {
                Check.That(found).IsTrue();
            }
            catch(Exception e)
            {
                Settings.EnCompassExtentTest.Info($"{elementNameInLog} element could not be found.");
                throw e;
            }

            return element;
        }

        #region Link to New or old grid

        private const string _linkReturnToNewGridXPath = @"//input[contains(@id,'uivt') and @value='Switch to New Grid']";
        private IWebElement _linkReturnToNewGrid
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_linkReturnToNewGridXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_linkReturnToNewGrid element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private const string _linkCompareWithPreviouGridXPath = @"//input[contains(@id,'uivt') and @value='Switch to Legacy Grid']";
        private IWebElement _linkCompareWithPreviouGrid
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_linkCompareWithPreviouGridXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_linkCompareWithPreviouGrid element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        //Added the temporary patch to handle the link for new grid
        public void ReturnToNewGrid()
        {
            if (IsReturnToNewVisible())
            {
                Settings.EnCompassExtentTest.Info("Switch to New Grid button present, clicking it");
                _linkReturnToNewGrid.JSClickWithFocus(Driver);
                WaitForLoad();
            }
            else
                Settings.EnCompassExtentTest.Info("Switch to New Grid button absent, proceeding with the flow " +
                    "considering New Grid already loaded on page");
        }

        public void CompareWithPrevious()
        {
			if (IsCompareWithPreviousVisible())
			{
				Settings.EnCompassExtentTest.Info("Checking if Compare with Previous Grid button present, clicking it.");
				_linkCompareWithPreviouGrid.JSClickWithFocus(Driver);
				WaitForLoad();
			}
			else
				Settings.EnCompassExtentTest.Info("Compare with Previous Grid button absent, proceeding with the flow " +
						"considering New Grid already loaded on page");
		}

        public bool IsCompareWithPreviousVisible()
        {
			Settings.EnCompassExtentTest.Info("Checking if Compare with Previous Grid button is present.");
			return Driver.IsElementPresent(By.XPath(_linkCompareWithPreviouGridXPath));
        }

        public bool IsReturnToNewVisible()
        {
			Settings.EnCompassExtentTest.Info("Checking if Switch to New Grid button is present.");
			return Driver.IsElementPresent(By.XPath(_linkReturnToNewGridXPath));
        }
        #endregion

        public EnCompassPageModel(GlobalSettings settings) : base(settings) { }
	}
}
