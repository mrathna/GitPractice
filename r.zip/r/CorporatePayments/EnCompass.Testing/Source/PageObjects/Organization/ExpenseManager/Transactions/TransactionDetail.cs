﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using Common;
using Common.PageObjects;
using Common.ScenarioConfigurations;
using Common.Utility;
using NFluent;
using System.Collections.Generic;
using OpenQA.Selenium.Support.UI;
using System;
using System.Linq;
using EnCompass.Testing.Source.PageObjects.Controls;
using System.Threading;

namespace EnCompass.Testing.Source.PageObjects.Organization.ExpenseManager.Transactions
{
    public class TransactionDetail : EnCompassPageModel
    {
        public override string RelativeUrl => @"/expenseManager/transactions/transactionsDetails.aspx";
        public override string PageIdentifierXPath_Generated => @"//li[@class='breadcrumb-item active'][text() = 'Transaction Details']";

        #region XPATH

        private static string _expCategoryDDL = "//select[contains(@name,'ddlExpenseCategories')]";
        public static string _modifyExpCatMsg = ".//div[contains(@id,'ctlExpenseCategory_spnChangeWarning')]";
        public static string _transSplitCount = ".//input[contains(@id,'ctlSplits_txtNumSplits')]";
        public const string _sectionsExpanded = "//div[contains(@id,'transactionDetailsAccordion')]/h2/button[@data-toggle='collapse' and @aria-expanded='true']";
        public const string _sectionsCollapsed = "//div[contains(@id,'transactionDetailsAccordion')]/h2/button[@data-toggle='collapse' and @aria-expanded='false']";

        private const string  _chkReviewXPath = @"//input[contains(@id,'chkRev')]";
        private const string _chkReviewLabelXPath = @"//label[contains(@for,'chkRev') and text()='Reviewed']";
        private const string _chkApproveXPath = @"//input[contains(@id,'chkApp')]";
        private const string _chkApproveLabelXPath = @"//label[contains(@for,'chkApp') and text()='Approved']";
        private const string _chkSecondApprovalXPath = @"//input[contains(@id,'chkApp2')]";
        private const string _chkSecondApprovalLabelXPath = @"//label[contains(@for,'chkApp2') and text()='Second approval']";
        private const string _btnSaveXPath = @"//input[contains(@id,'btnSave')]";
        private const string _btnSplitXPath = @"//input[contains(@id,'btnSplit')]";
        private const string _txtNumSplitsXPath = @"//input[contains(@id,'txtNumSplits')]";
        private const string _btnSplitContinueXPath = @"//input[contains(@id,'btnSplitContinue')]";
        private const string _btnCancelXPath = @"//button[contains(text(),'Cancel')]";
        private const string _lnkBackToSearchXPath = @"//a[contains(@id,'lnkSearch')]";
        private const string _expandAllXPath = "//a[contains(@onclick,'expand')]";
        private const string _collapseAllXPath = "//a[contains(@onclick,'collapse')]";
        private const string _lnkMerchantInformationXPath = "//a[text()='Merchant Information']";
        private const string _lnkBillingInformationXPath = "//a[text()='Billing Information']";
        private const string _lnkSignOffHistoryXPath = "//a[text()='Sign Off History']";
        private const string _lnkFlagsAndNotesXPath = "//a[text()='Flags & Notes']";
        private const string _lnkCommentsXPath = "//a[text()='Comments']";
        private const string _lnkSplitsXPath = "//a[text()='Splits']";
        private const string _nextTransactionXPath = "//a[contains(@id,'lnkNext')]";
        private const string _previousTransactionXPath = "//a[contains(@id,'lnkPrevious')]";
        private const string _btnManageReceiptXPath = @"//input[contains(@id,'btnManageReceipt')]";
        private const string _flagsAndNotesReviewedCheckboxXPath = @"//input[contains(@id,'FlagsAndNotes_chkRev')]";
        private const string _flagsAndNotesReviewedCheckboxLabelXPath = @"//label[contains(@for,'FlagsAndNotes_chkRev')]";
        private const string _flagsAndNotesTxtSalesTaxXPath = @"//div[@id='chkNoSalesTax']/input[contains(@id,'ctlFlagsAndNotes_chkNoSalesTax')]";
        private const string _flagsAndNotesNoSalesTaxCheckboxXPath = @"//input[contains(@id,'chkNoSalesTax_cb')]";
        private const string _flagsAndNotesNoSalesTaxCheckboxLabelXPath = @"//label[contains(@for,'chkNoSalesTax_cb')]";
        private const string _flagsAndNotesTxtDescriptionXPath = @"//textarea[contains(@id,'FlagsAndNotes_txtDescription')]";
        private const string _transactionComments_txtNoteXPath = @"//textarea[contains(@id,'TransactionComments_txtNote')]";
        private const string _btnAddSplitXPath = @"//input[contains(@id,'btnAddRow') and @type='button' and @value='Add Split']";
        private const string _btnDisputeXPath = @"//input[contains(@id,'btnDispute') and @type='button']";
        private const string _btnCloseUploadXPath = @"//input[contains(@id,'buttonClose')]";
        private const string _btnUploadReceiptsXPath = @"//input[contains(@id,'buttonUpload')]";
        private const string _flagsAndNotesApp2CheckboxXPath = @"//input[contains(@id,'chkApp2')]";
        private const string _flagsAndNotesApp2LabelXPath = @"//label[contains(@for,'chkApp2')]";
        private const string _expenseCategoryXPath = @".//a[@id='expenseCategory']";
        private const string __lblChkReviewXPath = @"//label[contains(@for,'chkRev')]";
        private const string _txnDetailsTitleXPath = @"//h1[contains(@id,'title')]";
        private const string _cardsTitleLast4XPath = @"//h2[contains(@class,'card-title')]";
        private const string _travelLabelXPath = @"//div[contains(@id, 'transactionDetailsAccordion_apBillingInformation')]//h3[text() = 'Travel']";
        private const string _notesXPath = @"//textarea[contains(@id, 'txtDescription')]";
        private const string _nToggleXPath = @"//a[contains(@href,'ExpenseCategory')]";
        private const string _sectionSplitXPath = @"//button[contains(@aria-controls,'{0}') and @data-toggle='{1}']";
        private const string _btnAddRowXPath = @"//input[@type='button' and contains(@id,'btnAddRow')]";
        private const string _apSplitsXPath = @"//label[contains(@for,'apSplits') and contains(text(),'{0}')]/following-sibling::div/input";
        #endregion

        #region Expand Elements

        private const string AC_MAIN = "content_contents_transactionDetailsAccordion";
        private const string AP_EXPENSE_CATEGORY = "apExpenseCategory";
        private const string AP_BILL_INFORMATION = "apBillingInformation";
        #endregion

        public const string WorkflowGroupID = "apFlagsAndNotes";
        public const string MerchantInformation = "apMerchantInformationTitle";
        public const string BillingInformation = "apBillingInformation";
        public const string Splits = "apSplits";
        public const string Comments = "apComments";

        #region IWebElements Props

        public IWebElement _chkReview
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_chkReviewXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_chkReview element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _chkReviewLabel
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_chkReviewLabelXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_chkReviewLabel element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _chkApprove
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_chkApproveXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_chkApprove element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _chkApproveLabel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_chkApproveLabelXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_chkApproveLabel element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _chkSecondApproval
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_chkSecondApprovalXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_chkSecondApproval element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _chkSecondApprovalLabel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_chkSecondApprovalLabelXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_chkSecondApprovalLabel element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _btnSave
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_btnSaveXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_btnSave element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _btnSplit
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_btnSplitXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_btnSplit element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _txtNumSplits
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_txtNumSplitsXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_txtNumSplits element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _btnSplitContinue
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_btnSplitContinueXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_btnSplitContinue element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _btnCancel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_btnCancelXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_btnCancel element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _lnkBackToSearch
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_lnkBackToSearchXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_lnkBackToSearch element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _expandAll
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_expandAllXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_expandAll element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _collapseAll
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_collapseAllXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_collapseAll element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _lnkMerchantInformation
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_lnkMerchantInformationXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_lnkMerchantInformation element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _lnkBillingInformation
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_lnkBillingInformationXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_lnkBillingInformation element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _lnkSignOffHistory
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_lnkSignOffHistoryXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_lnkSignOffHistory element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _lnkFlagsAndNotes
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_lnkFlagsAndNotesXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_lnkFlagsAndNotes element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _lnkComments
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_lnkCommentsXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_lnkComments element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _lnkSplits
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_lnkSplitsXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_lnkSplits element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _nextTransaction
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_nextTransactionXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_nextTransaction element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _previousTransaction
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_previousTransactionXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_previousTransaction element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _btnManageReceipt
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_btnManageReceiptXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_btnManageReceipt element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _flagsAndNotesReviewedCheckbox
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_flagsAndNotesReviewedCheckboxXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_flagsAndNotesReviewedCheckbox element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _flagsAndNotesReviewedCheckboxLabel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_flagsAndNotesReviewedCheckboxLabelXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_flagsAndNotesReviewedCheckboxLabel element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _flagsAndNotesTxtSalesTax
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_flagsAndNotesTxtSalesTaxXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_flagsAndNotesTxtSalesTax element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _flagsAndNotesNoSalesTaxCheckbox
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_flagsAndNotesNoSalesTaxCheckboxXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_flagsAndNotesNoSalesTaxCheckbox element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _flagsAndNotesNoSalesTaxCheckboxLabel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_flagsAndNotesNoSalesTaxCheckboxLabelXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_flagsAndNotesNoSalesTaxCheckboxLabel element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _flagsAndNotesTxtDescription
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_flagsAndNotesTxtDescriptionXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_flagsAndNotesTxtDescription element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _transactionComments_txtNote
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_transactionComments_txtNoteXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_transactionComments_txtNote element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _btnAddSplit
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_btnAddSplitXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_btnAddSplit element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _btnDispute
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_btnDisputeXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_btnDispute element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _btnCloseUpload
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_btnCloseUploadXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_btnCloseUpload element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _btnUploadReceipts
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_btnUploadReceiptsXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_btnUploadReceipts element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _flagsAndNotesApp2Checkbox
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_flagsAndNotesApp2CheckboxXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_flagsAndNotesApp2Checkbox element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _flagsAndNotesApp2Label
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_flagsAndNotesApp2LabelXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_flagsAndNotesApp2Label element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _expenseCategory
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_expenseCategoryXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_expenseCategory element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement __lblChkReview
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(__lblChkReviewXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("__lblChkReview element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _txnDetailsTitle
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_txnDetailsTitleXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_txnDetailsTitle element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _cardsTitleLast4
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_cardsTitleLast4XPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_cardsTitleLast4 element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _travelLabel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_travelLabelXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_travelLabel element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _notes
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_notesXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_notes element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _nToggle
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_nToggleXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_nToggle element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        #endregion



        public enum GroupIDs
        {
            WorkflowGroupID, MerchantInformation, BillingInformation, Splits, Comments
        };

        public string RetrieveActualGroupID(GroupIDs group)
        {
            string id = "";

            switch ((int)group)
            {
                case (int)GroupIDs.WorkflowGroupID:
                    id = "apFlagsAndNotes";
                    break;
                case (int)GroupIDs.MerchantInformation:
                    id = "apMerchantInformationTitle";
                    break;
                case (int)GroupIDs.BillingInformation:
                    id = "apBillingInformation";
                    break;
                case (int)GroupIDs.Splits:
                    id = "apSplits";
                    break;
                case (int)GroupIDs.Comments:
                    id = "apComments";
                    break;
                default:
                    id = "apFlagsAndNotes";
                    break;
            }
            return id;
        }

        public string getSectionsExpandedXPath()
        {
            return _sectionsExpanded;
        }

        public string getSectionsCollapsedXPath()
        {
            return _sectionsCollapsed;
        }

        public void ExpandExpenseCategory()
        {
            //Changed to the generic method
            ExpandCardHeader(AC_MAIN, AP_EXPENSE_CATEGORY);
            Settings.EnCompassExtentTest.Info("Expanded Expense Category Section");
        }

		public bool IsTransactionDetailsTitleDisplayed
		{
			get { return _txnDetailsTitle.Displayed; }
		}

		public string CardNumberLast4
		{
			get { return _cardsTitleLast4.Text.Trim().Substring(_cardsTitleLast4.Text.Trim().Length - 4); }
		}

        public string SelectExpenseCategory
		{
			get
			{
				Driver.TryWaitForElement(By.XPath(_expCategoryDDL), out IWebElement _expCategoryDDList);
				return new SelectElement(_expCategoryDDList).SelectedOption.Text;
			}
			set
			{
				Driver.TryWaitForElement(By.XPath(_expCategoryDDL), out IWebElement _expCategoryDDList);
				new SelectElement(_expCategoryDDList).SelectByText(value);
			}
		}

		public void BtnDispute()
        {
            _btnDispute.JSClickWithFocus(Driver);
		}

        public void BtnCloseUpload()
        {
            _btnCloseUpload.JSClickWithFocus(Driver);
		}

		public string Notes
		{
			get { return _notes.Text; }
			set { _notes.Clear(); _notes.SendKeys(value); }
		}
        

        //New Method
        public void CheckButtonsReceiptAppersOnDetails()
        {
            Settings.EnCompassWebDriver.WaitForVisible(By.XPath("//input[contains(@id, 'btnManageReceipt')]"));
            PressManageReceipts();
            Settings.EnCompassWebDriver.WaitForVisible(By.XPath("//input[contains(@id,'buttonUpload')]"));
            BtnCloseUpload();
        }

        //Set the value for the select transaction
        public void SetSplitGridValues(int row, string amount, string percentage, List<string> fCodeGroups, List<string> fCodes, string note)
        {
            if (row > 0)
            {
                string baseXpath = string.Format(@"//input[contains(@id,'rpSplits_ctl{0}_$$$$$') and not(@type='hidden')]", row.ToString("00"));

                if (!string.IsNullOrEmpty(amount))
                {
                    string amountXpath = baseXpath.Replace("$$$$$", "txtSplitAmt");
                    Driver.FindElement(By.XPath(amountXpath)).ClearWithBackspace();
                    Driver.FindElement(By.XPath(amountXpath)).SendKeys(amount);
                }

                if (!string.IsNullOrEmpty(percentage))
                {
                    string percentageXpath = baseXpath.Replace("$$$$$", "txtPer");
                    Driver.FindElement(By.XPath(percentageXpath)).ClearWithBackspace();
                    Driver.FindElement(By.XPath(percentageXpath)).SendKeys(percentage);
                }

                if (!string.IsNullOrEmpty(note))
                {
                    string noteXpath = baseXpath.Replace("//input","//textarea").Replace("$$$$$", "txtSplitDscr");
                    Driver.WaitElementBeClickable(noteXpath);
                    Driver.FindElement(By.XPath(noteXpath)).Clear();
                    Driver.FindElement(By.XPath(noteXpath)).SendKeys(note);
                }

                //Insert financial code at the proper group
                if (fCodes != null && fCodeGroups != null)
                {
                    if (fCodes.Count() == fCodeGroups.Count())
                    {
                        for (int i = 0; i < fCodes.Count(); i++)
                        {
                            string txtFinCode = string.Format("//div[contains(@id,'ctl{0}')]//label[contains(text(),'{1}')]/following-sibling::div/input[not(@type='hidden')]", row.ToString("00"), fCodeGroups.ElementAt(i));
                            Driver.FindElement(By.XPath(txtFinCode)).Clear();
                            Driver.FindElement(By.XPath(txtFinCode)).SendKeys(fCodes.ElementAt(i));
                        }
                    }
                    else if (fCodes.Count() > 0 || fCodeGroups.Count() > 0)
                        throw new IndexOutOfRangeException("The number of financial codes is different from the number of groups.");
                }
                //end of Insert financial code at the proper group
            }
        }

        public void SetTransactionCommentTxtNote(string value)
        {
            _transactionComments_txtNote.Clear();
            _transactionComments_txtNote.SendKeys(value);
        }

        public void SetFlagsAndNotesTxtDescription(string value)
        {
            _flagsAndNotesTxtDescription.Clear();
            _flagsAndNotesTxtDescription.SendKeys(value);
        }


        public void SetFlagsAndNotesNoSalesTaxCheckbox(bool state)
        {
            _flagsAndNotesNoSalesTaxCheckbox.SetCheckboxStateWithLabel(_flagsAndNotesNoSalesTaxCheckboxLabel, state);
        }

        public void SetFlagsAndNotesTxtSalesTax(string value)
        {
            _flagsAndNotesTxtSalesTax.Clear();
            _flagsAndNotesTxtSalesTax.SendKeys(value);
        }

        public void SetFlagsAndNotesReviewedCheckbox(bool state)
        {
            _flagsAndNotesReviewedCheckbox.SetCheckboxStateWithLabel(_flagsAndNotesReviewedCheckboxLabel,state);
        }

        public void SetFlagsAndNotesApp2Checkbox(bool state)
        {
            _flagsAndNotesApp2Checkbox.SetCheckboxStateWithLabel(_flagsAndNotesApp2Label, state);
        }

        public void NextTransaction()
        {
            _nextTransaction.JSClickWithFocus(Driver);
			WaitForLoad();
        }



        public void PreviousTransaction()
        {
            _previousTransaction.JSClickWithFocus(Driver);
			WaitForLoad();
        }

        public void ExpandAll()
        {
            ExpandGrade("apFlagsAndNotes");
            ExpandGrade("apMerchantInformationTitle");
            ExpandGrade("apBillingInformation");
            ExpandGrade("apSplits");
            ExpandGrade("apComments");
        }

        public void ExpandGrade(string GradeID)
        {
            //Changed to the generic method
            ExpandCardHeader(AC_MAIN, GradeID);
            Settings.EnCompassExtentTest.Info($"Expanded {GradeID} section");
        }

		public void ExpandBillingInformation()
		{
            //Changed to the generic method
            ExpandCardHeader(AC_MAIN, AP_BILL_INFORMATION);
            Settings.EnCompassExtentTest.Info("Expanded Billing Information section");
		}

		public void CollapseAll()
        {
            CollapseGrade("apFlagsAndNotes");
            CollapseGrade("apMerchantInformationTitle");
            CollapseGrade("apBillingInformation");
            CollapseGrade("apSplits");
            CollapseGrade("apComments");
        }

        public void CollapseGrade(string GradeID)
        {
            //Changed to the generic method
            CollapseCardHeader(AC_MAIN, GradeID);
            Settings.EnCompassExtentTest.Info($"Collapsed {GradeID} section");
        }

        public void SelectSectionsAndVerifyState(string section, string state)
        {
            switch (section)
            {
                case "Merchant Information":
                    section = "apMerchantInformationTitle";
                    ExpandGrade(section);
                    VerifySectionState(section,state);
                    break;
                case "Billing Information":
                    section = "apBillingInformation";
                    ExpandGrade(section);
                    VerifySectionState(section, state);
                    break;
                case "Workflow":
                    section = "apFlagsAndNotes";
                    ExpandGrade(section);
                    VerifySectionState(section, state);
                    break;
                case "Comments":
                    section = "apComments";
                    ExpandGrade(section);
                    VerifySectionState(section, state);
                    break;
                case "Splits":
                    section = "apSplits";
                    ExpandGrade(section);
                    VerifySectionState(section, state);
                    break;
            }
        }

        public void VerifySectionState(string section, string state)
        {
            Driver.TryWaitForElementToBeVisible(By.XPath(string.Format(_sectionSplitXPath, section, state)), out IWebElement imgExpandCollapse);
            Check.That(imgExpandCollapse.GetAttribute("aria-expanded").Equals(true));
        }

        public void VerifyTransactionValue(string fcode, string value)
        {
            Driver.WaitForVisible(By.XPath(_btnAddRowXPath));
            IList<IWebElement> fCodeValues = Driver.FindElements(By.XPath(string.Format(_apSplitsXPath, fcode)));
            if(fCodeValues.Count > 0)
                Check.That(fCodeValues[0].GetAttribute("Value").Equals(value));
            else
                throw new NoSuchElementException();
        }

        public void BackToSearch()
        {
            _lnkBackToSearch.JSClickWithFocus(Driver);
            Settings.EnCompassExtentTest.Info("Clicked on 'Back to Search' Link on Transaction Details page");
        }

		public void CheckReview(bool value)
        {
            _chkReview.SetCheckboxStateWithLabel(_chkReviewLabel, value);
            Settings.EnCompassExtentTest.Info("Checked Reviewed option on Transaction Details page");
        }

        public bool VerifyReviewCheckboxState()
        {
            bool state = _chkReview.Enabled;            
            Settings.EnCompassExtentTest.Info("Reviewed option is "+ state +" Transaction Details page");
            return state;
        }

        public void CheckApprove(bool value)
        {
            _chkApprove.SetCheckboxStateWithLabel(_chkApproveLabel, value);
            Settings.EnCompassExtentTest.Info("Checked Approved option on Transaction Details page");
        }

        public void CheckSecondApproval(bool value)
        {
            _chkSecondApproval.SetCheckboxStateWithLabel(_chkSecondApprovalLabel, value);
            Settings.EnCompassExtentTest.Info("Checked Second Approval option on Transaction Details page");
        }

        public void ExpandSection(string section)
        {
            //Changed to the generic method
            ExpandCardHeader(AC_MAIN, section);
            Settings.EnCompassExtentTest.Info($"Collapsed {section} section");
        }

        public void PressSave()
        {
            _btnSave.JSClickWithFocus(Driver, _btnSaveXPath,Settings);
            WaitForFormLoadingOverlay();
            Settings.EnCompassExtentTest.Info("Clicked on Save button.");
			this.AttachOnDemandScreenShot();
		}

		public void PressCancel()
		{
			_btnCancel.JSClickWithFocus(Driver);
		}

		public string NumSplits
		{
			get
			{
				return _txtNumSplits.GetAttribute("value");
			}
			set
			{
				_txtNumSplits.Clear();
				_txtNumSplits.SendKeys(value);
			}
		}

		public void SplitTransaction(string numberSplits)
		{
			_btnSplit.JSClickWithFocus(Driver);
			WaitForLoad();
			NumSplits = numberSplits;
			_btnSplitContinue.JSClickWithFocus(Driver);
			WaitForLoad();
            Settings.EnCompassExtentTest.Info($"Performed 'Split Transaction'. Number of splits: {numberSplits}.");

        }

		public void AddAmount(int numberSplits)
		{
			for (int i = 1; i <= numberSplits; i++)
			{
                IWebElement ElementAmount = Settings.EnCompassWebDriver.WaitForVisible(By.XPath($@"(//input[contains(@id, 'txtSplitAmt')])[{i}]"));
                ElementAmount.Clear();
                //using ClearwithBackSpace() instead of Clear() as in this case, after calling Clear the focus from the textbox goes out and the textbox gets filled in by the placeholder again
                ElementAmount.ClearWithBackspace();                 
                ElementAmount.SendKeys("5.00");
			}
		}

		/// <summary>
		/// This method fills all transactions fields(financial code)
		/// </summary>
		public void FillAllTransactionsFields()
		{
			foreach (var input in Settings.EnCompassWebDriver.FindElements(By.XPath(@"//table[contains(@id,'SplitsTable')]//div[contains(@class,'form-group')]//*[(self::input or self::textarea) and not(@type='checkbox') and not(@type='hidden') and not(@type='button') and not(@readonly) and not(@maxlength<150)]")))
			{
				//IWebElement label = input.FindElement(By.XPath(@".//preceding-sibling::label"));
                IWebElement label = null;

                if (input.TagName.Equals("input"))
                {
                    label = input.FindElement(By.XPath(@"./parent::div/preceding-sibling::label"));
                    input.Clear();
                    input.SendKeys(label.Text.Replace("(optional)",string.Empty).Trim() + "1");
                }
                else
                {
                    label = input.FindElement(By.XPath(@".//preceding-sibling::label"));
                    input.Clear();
                    input.SendKeys(label.Text.Replace("(optional)", string.Empty).Trim());
                }
            }
		}

        public bool CheckState(IWebElement element)
        {
            return element.Enabled;
        }
		public TransactionDetail(GlobalSettings settings) : base(settings) { }

        public void PressManageReceipts()
        {
            _btnManageReceipt.WaitUntilElementIsInteractable();
            _btnManageReceipt.JSClickWithFocus(Driver);
		}

        //New Method
        public void PressUploadReceipts(String fileAbsPath)
        {
            Driver.FindElement(By.XPath("//input[contains(@id,'ManageReceipts') and @type='file']")).SendKeys(fileAbsPath);
            _btnUploadReceipts.JSClickWithFocus(Driver);
		}

		public GridControl SplitsGrid
		{
			get
			{
				// Cannot use WaitForGrid here as xpath doesnt exist
				GridControl _splitsTable = new GridControl("SplitsTable", Settings.EnCompassWebDriver);				
				return _splitsTable;
			}
		}

		public string GetTransactionSplitAmtForRow(int ctr)
		{
			IWebElement amt  = Driver.WaitForElements(By.XPath(".//input[contains(@id,'txtSplitAmt')]")).ElementAt(ctr-1);
			return amt.GetAttribute("value");
		}

		public string GetTransactionSplitPercentForRow(int ctr)
		{
			IWebElement prcnt = Driver.WaitForElements(By.XPath(".//input[contains(@id,'_txtPer')]")).ElementAt(ctr - 1);
			return prcnt.GetAttribute("value");
		}

		public void SetTransactionSplitNotesForRow(int ctr, string value)
		{
			IWebElement notes = Driver.WaitForElements(By.XPath(".//textarea[contains(@id,'_txtSplitDscr')]")).ElementAt(ctr - 1);
			notes.ForceDocumentLoadOnSendKeys(value, Settings.EnCompassWebDriver);
		}

		public string GetElementTextInGroup(string groupXPathId, string elementXPath)
		{
			if (Driver.TryFindElement(By.XPath($@"//div[contains(@id, '{groupXPathId}')]"+elementXPath), out IWebElement element))
			{
				return element.FindElement(By.XPath(@"strong")).Text;
			}
			else
			{
				return "";
			}
		}

		public bool IsTravelLabelPresent()
		{
			bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_travelLabelXPath), out IWebElement element);
            Settings.EnCompassExtentTest.Info($"_travelLabel elment exist is {found}");
            return found;
        }

        public void InsertFinCode(int index, string fCodeGroup, string finCode)
        {
            string txtFinCode = string.Format("//table//tr//div[contains(@class, 'a_c')]//label[text() = '{0}']/following-sibling::div//input[not(@readonly='readonly')]", fCodeGroup);
            Driver.TryWaitForElement(By.XPath(txtFinCode), out IWebElement finCodeElement);
            finCodeElement.SendKeys(finCode);
        }

        /// <summary>
        /// Validates The Traval Data Text and Value
        /// </summary>
        /// <param name="text"></param>
        /// <param name="value"></param>
        /// <returns></returns>
        public bool ValidateTravelData(List<string> text, List<string> value)
		{
			var travelList = Driver.WaitForElementsToBeVisible(By.XPath($"//div[contains(@id, 'transactionDetailsAccordion_apBillingInformation')]//h3[text() = 'Travel']//following-sibling::div//li")).ToList();
			//Thread.Sleep(2000);
			//Driver.TryWaitForElementToBeVisible(By.XPath($"//div[contains(@id, 'transactionDetailsAccordion_apBillingInformation')]//h3[text() = 'Travel']//following-sibling::div//li"), out IWebElement travelList);
			//var travelList = Driver.FindElements(By.XPath($"//div[contains(@id, 'transactionDetailsAccordion_apBillingInformation')]//h3[text() = 'Travel']//following-sibling::div//li"));
			
			for (int i = 0; i < text.Count(); i++)
			{

				var match = travelList[i].Text.Equals($"{text[i]}: {value[i]}");

				if (match)
				{
					Settings.EnCompassExtentTest.Info($"The expected value {text[i]}: {value[i]} matched the actual value {travelList[i].Text}");
				}

				else
				{
					Settings.EnCompassExtentTest.Info($"The expected value {text[i]}: {value[i]} did not match the actual value {travelList[i].Text}");
					throw new Exception($"The expected value {text[i]}: {value[i]} did not match the actual value {travelList[i].Text}");
				}
			}

			return true;
		}
	}
}
