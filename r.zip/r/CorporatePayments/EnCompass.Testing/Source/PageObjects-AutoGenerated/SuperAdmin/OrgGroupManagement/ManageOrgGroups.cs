using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using Common;
using Common.PageObjects;
using Common.ScenarioConfigurations;
using Common.Utility;

namespace EnCompass.Testing.Source.PageObjects.SuperAdmin.OrgGroupManagement 
{
	/// <summary>
	/// Auto-generated Page Model Class
	/// Navigation Paths: 
		/// [Organization Home]->Users and Organizations->Organizations
		/// </summary>
	[PageModel(@"/superAdmin/orgGroupManagement/manageOrgGroups.aspx")]
	public partial class ManageOrgGroups : EnCompassSuperPageModel 
	{
		public override string RelativeUrl => @"/superAdmin/orgGroupManagement/manageOrgGroups.aspx";
		public override string PageIdentifierXPath_Generated => @"//li[contains(@class, 'breadcrumb-item active')][text() = 'Organizations']";

		#region Navigation
		
		private void NavigateToMenuItem(IWebElement element)
		{
			Driver.Url = element.GetAttribute("href");
		}
		#endregion

		public ManageOrgGroups(GlobalSettings settings) : base(settings) { }
	}  
}
