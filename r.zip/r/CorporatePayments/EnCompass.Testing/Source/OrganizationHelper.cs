﻿using System;
using System.Linq;

namespace EnCompass.Testing.Source
{
    /// <summary>
    /// The purpose of this class is generate organization information in order to be a possible replacement for what Encompass informs.
    /// </summary>
    public class OrganizationHelper
    {
        private string CompanyNumber { get; set; }
        private string RandomNumber { get; set; }
        private string OrganizationId { get; set; }
        private string OrganizationName { get; set; }

        private Random random;
        private const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
		private static OrganizationHelper instance;

		private OrganizationHelper()
        {
            random = new Random();
            OrganizationId = new string(Enumerable.Repeat(chars, 10).Select(s => s[random.Next(s.Length)]).ToArray());
            CompanyNumber = random.Next(1, 100000).ToString();
            RandomNumber = random.Next(1, 10000).ToString();
            OrganizationName = string.Format("ZZZ {0} {1}-{2}", OrganizationId, RandomNumber, CompanyNumber);
        }

        public static OrganizationHelper GetInstance
        {
            get
            {
                if (instance == null)
                    return new OrganizationHelper();
                return instance;
            }
        }

        /// <summary>
        /// This method returns a random 5 digit company number.
        /// </summary>
        /// <returns>Company number</returns>
        public string GetCompanyNumber()
        {
            return CompanyNumber;
        }

        /// <summary>
        /// This method returns an alphanumeric chain of 10 characters generated randomly.
        /// </summary>
        /// <returns>Organization Id</returns>
        public string GetOrganizationId()
        {
            return OrganizationId;
        }

        /// <summary>
        /// This method return a complete organization name.
        /// </summary>
        /// <returns>Organization Name</returns>
        public string GetOrganizationName()
        {
            return OrganizationName;
        }

        /// <summary>
        /// This method return a Random String.
        /// </summary>
        /// <returns>Random String</returns>
        public string GetRandomString(int size)
        {
            return new string(Enumerable.Repeat(chars, size).Select(s => s[random.Next(s.Length)]).ToArray());
        }
    }
}
