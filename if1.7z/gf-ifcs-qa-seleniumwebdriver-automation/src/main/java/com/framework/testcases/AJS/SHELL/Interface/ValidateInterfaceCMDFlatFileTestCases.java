package com.framework.testcases.AJS.SHELL.Interface;

import java.util.ArrayList;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.MaintainCustomerPage;
import com.framework.pages.AJS.common.IFCSCommonPage;
import com.framework.pages.AJS.common.IFCSHomePage;
import com.framework.pages.AJS.common.IFCSLoginPage;
import com.framework.pages.AJS.common.InterfacePage;

public class ValidateInterfaceCMDFlatFileTestCases extends BaseTest{

	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "Smoke" })
	public void ValidateAddActiveCustomerUsingCMDFile(@Optional("CZ") String clientCountry,
			@Optional("SH") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  SHELL Interface Add Active Customer with CMD files",
				"01 Add Active Platinum Primary Customer");
		// creating object for the Pages
		IFCSLoginPage ifcsloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage ifcsHomePage = new IFCSHomePage(driver, test);
		IFCSCommonPage ifcsCommonPage = new IFCSCommonPage(driver, test);
		InterfacePage interfacePage = new InterfacePage(driver, test);
		MaintainCustomerPage maintainCustomerPage = new MaintainCustomerPage(driver, test);

//		String updatedCustomerNo = "";
		ArrayList<String> updatedCustomerNo = new ArrayList<String>();

		updatedCustomerNo = interfacePage.updateOrValidateFlatFile(ac2configProp, "OutgoingFileZip",
				"IE_INPUTFILE_FOLDER_LOADCARDTRANSACTIONS", "", clientName, clientCountry,
				"SHELL-32-H3-AC2-000005.dat");

		interfacePage.updateOrValidateFlatFile(accconfigProp, "OutgoingFileZip",
				"IE_INPUTFILE_FOLDER_LOADCARDTRANSACTIONS", "", clientName, clientCountry,
				"SHELL-32-H3-ACC-000005.dat");

		System.out.println("Newly Created customer Number" + updatedCustomerNo);

		if (!updatedCustomerNo.isEmpty() && !updatedCustomerNo.equals(null)) {
			String folderName = ifcsCommonPage.getControlMFolder(clientName, clientCountry, "jobS_CMD");

			String jobsInOrder = ifcsCommonPage.getJobsOfFolderInOrder("jobS_CMD");

			interfacePage.establishAndExecuteControlMJobs("ControlM_AWS_UAT", "ContorlM_AWS_userName",
					"ContorlM_AWS_password", folderName, jobsInOrder);

			// Calling Functions
			ifcsloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");

			ifcsHomePage.gotoCustomerMenuCustomerDetails();

			maintainCustomerPage.validateNewlyCreatedCustomerNumber(updatedCustomerNo.get(0));

		} else {
			System.out.println("Interface is not updated correctly");
		}
	}
	
}
