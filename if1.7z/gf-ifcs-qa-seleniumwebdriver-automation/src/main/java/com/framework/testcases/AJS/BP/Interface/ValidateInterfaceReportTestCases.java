package com.framework.testcases.AJS.BP.Interface;

import java.util.ArrayList;
import java.util.Map;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.TransactionListPage;
import com.framework.pages.AJS.UtilitiesPage;
import com.framework.pages.AJS.common.Common;
import com.framework.pages.AJS.common.CommonInterfacePage;
import com.framework.pages.AJS.common.IFCSCommonPage;
import com.framework.pages.AJS.common.IFCSHomePage;
import com.framework.pages.AJS.common.IFCSLoginPage;
import com.github.javafaker.Faker;

public class ValidateInterfaceReportTestCases extends BaseTest {

	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "Smoke" })
	public void validateCustomisedFleetControlReport(@Optional("AU") String clientCountry,
			@Optional("BP") String clientName) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  BPNZ55_Cust_NZ_018_Customised Fleet Control Report", "BPNZ55_Cust_NZ_018_Customised Fleet Control Report");
		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		Common common = new Common(driver, test);
		TransactionListPage transactionListPage = new TransactionListPage(driver, test);
		UtilitiesPage utilitiesPage = new UtilitiesPage(driver,test);
		// Calling Functions
		IFCSloginPage.login("IFCS_URL_BP", "IFCS_BP_USERNAME", "IFCS_BP_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, " ");
	
		IFCSHomePage.gotoAdminMenuAndChooseClient(clientName+"_"+clientCountry);
		IFCSHomePage.gotoTansactionsAndClickManageTransaction();
		
		String ifcsDate=common.getCurrentIFCSDateFromDB(clientName);
		String cardNumber=common.getCardNumberWithDriverNameForVehicleCard();
		String customerNumber=common.getCustomerNoForCardNumber(cardNumber);
		String locationNo=common.chooseALocationWithNonFuelProduct("Y");
		String productCode=common.chooseANonFuelProductExtCodeInTheLocation(locationNo,"Y","externalCode");

		//First Manual Transaction
		
		Faker fakerN = new Faker();
		String f_referenceNo = fakerN.number().digits(3);
		//transactionListPage.validateToPostManualTransactionEntry(ifcsDate,f_referenceNo,clientCountry,cardNumber,"",locationNo,productCode,false);
		transactionListPage.enterTransactionBatchDetails(false,"160","1",clientName);
		transactionListPage.enterManualTransactionDetails(ifcsDate,f_referenceNo,cardNumber,"",locationNo,"160","");
		transactionListPage.enterTransactionLineItems(productCode,"160","100","160");
		transactionListPage.validatePostManualTransaction("Validation successful");
		
		IFCSHomePage.gotoUtiliesAndClickUtilies();
		utilitiesPage.validateAdhocReportsInUtilities("Customised Fleet Control Report");
		common.taskbarSubmit();

		transactionListPage.enterDetailsInCustomizedFleetControlReportsPopup(cardNumber, customerNumber, ifcsDate);
		String fileName="FleetControlDetail_Customized";
		//Validation Part
		common.isFileDownloaded(fileName);
		ArrayList<String> valuesFromList=transactionListPage.getDriverNameinCardMaintenance(cardNumber);
		
		String textFromPdfFile=common.getDataFromLatestDownloadedPdfFile(fileName);
		
		System.out.println("textFromPdfFile::"+textFromPdfFile);

		common.validateTheTextRetrievedFromPdfFile(textFromPdfFile,"Card Details: "+cardNumber+" - "+valuesFromList.get(2)+" - "+valuesFromList.get(3)+" - "+valuesFromList.get(0));//(textFromPdfFile,driverNameList.get(0));
		
		
		//need to run day end to reflect changes in downloaded report
		

		//Manual Transaction after day end 
		String ifcsDateAfterDayEnd=common.getCurrentIFCSDateFromDB(clientName);
		IFCSHomePage.gotoTansactionsAndClickManageTransaction();
		Faker fakerNum = new Faker();
		String referenceNo = fakerNum.number().digits(3);
		//transactionListPage.validateToPostManualTransactionEntry(ifcsDateAfterDayEnd,referenceNo,clientCountry,cardNumber,"",locationNo,productCode,false);
		transactionListPage.enterTransactionBatchDetails(false,"160","1",clientName);
		transactionListPage.enterManualTransactionDetails(ifcsDateAfterDayEnd,referenceNo,cardNumber,"",locationNo,"160","");
		transactionListPage.enterTransactionLineItems(productCode,"160","100","160");
		transactionListPage.validatePostManualTransaction("Validation successful");

		IFCSHomePage.gotoUtiliesAndClickUtilies();
		utilitiesPage.validateAdhocReportsInUtilities("Customised Fleet Control Report");
		common.taskbarSubmit();

		transactionListPage.enterDetailsInCustomizedFleetControlReportsPopup(cardNumber, customerNumber, ifcsDate);

		//Validation Part
		common.isFileDownloaded(fileName);
		
		String textFromPdfFileAfterDayEnd=common.getDataFromLatestDownloadedPdfFile(fileName);
		
		common.validateTheTextRetrievedFromPdfFile(textFromPdfFileAfterDayEnd,"Card Details: "+cardNumber+" - "+valuesFromList.get(2)+" - "+valuesFromList.get(3)+" - "+valuesFromList.get(1));
		
		IFCSHomePage.exitIFCS();

	}
	
	
	@Parameters({ "clientCountry", "clientName"})
	@Test(groups = {"Smoke"}, enabled=false)
	public void validateDailyRecociliationReport(@Optional("AU") String clientCountry, @Optional("BP") String clientName) {
		
		test = extent.createTest(clientName+ ":" +clientCountry+"  Sys_"+clientCountry+"_008_Daily Rec reports", "Daily Rec reports");
		IFCSLoginPage ifcsloginPage = new IFCSLoginPage(driver, test);
		CommonInterfacePage commonInterfacePage = new CommonInterfacePage(driver, test);
		IFCSCommonPage ifcsCommonPage = new IFCSCommonPage(driver, test);
		
		ifcsloginPage.setClientCountryCardTypeDetails(clientName, clientCountry," ");
		//day End processing
		
		//File Validation
		String fileName=commonInterfacePage.getRecentProcessedReportFiles( clientName, clientCountry,
				"Daily Reconciliation Report","");
		String dayEndDatePath=commonInterfacePage.getFolderPathUsingPreviousProcessingDate(clientName, clientCountry,"IFCS_DAYEND_OUTPUTFILE_AU");
				System.out.println("dayEndDatePath::" +dayEndDatePath);
		ifcsCommonPage.establishThePuttyConnection("incomingFile", "PUTTY_HOST", "PUTTY_USERNAME", "PUTTY_PASSWORD", dayEndDatePath, fileName);		
		
		System.out.println("fileName::" + fileName);
		ifcsCommonPage.validateDailyReconciliationPDFReport(fileName);
	}
	
	@Parameters({ "clientCountry", "clientName"})
	@Test(groups = {"Smoke"})
	public void ValidateCardSalesAggregate(@Optional("AU") String clientCountry, @Optional("BP") String clientName) {
		
		test = extent.createTest(clientName+ ":" +clientCountry+"  Interface_003_R4 Card Sales Aggregate", "Cards Sales Aggregate");
		IFCSLoginPage ifcsloginPage = new IFCSLoginPage(driver, test);
		IFCSCommonPage ifcsCommonPage = new IFCSCommonPage(driver, test);
		Common common = new Common(driver, test);
		CommonInterfacePage commonInterfacePage = new CommonInterfacePage(driver, test);
	    ifcsloginPage.setClientCountryCardTypeDetails(clientName, clientCountry," ");
		//day End processing
		
		//File Validation
	    String fileName = null;
	    if(clientCountry.equals("AU")) {
	    fileName=commonInterfacePage.getRecentProcessedFileNames(clientName, clientCountry, "RM_GSD_0021");
	    }
	    else{
	    	fileName=commonInterfacePage.getRecentProcessedFileNames(clientName, clientCountry, "RM_GSD_0025");
	    }
	    ifcsCommonPage.establishThePuttyConnection("unzip", "PUTTY_HOST", "PUTTY_USERNAME", "PUTTY_PASSWORD",
				"IE_OUTPUTFILE_FOLDER_POS_CARDCHANGE", fileName);

		String localFolder = System.getProperty("user.home") + "\\Documents\\" + (fileName.replace(".zip", ".xml"));
		
		//String fileDirectory="C:\\Users\\W996058\\Documents\\GPCardSalesAggExtract_AU_0095\\GPCardSalesAggExtract_AU_0095.xml";
		String nodeTag="ifcs:CardSalesAggregate";
		Map<String,String> valuesFromQuery=common.getValuesFromQueryForCardSalesAggregate();
		Map<String,String> valuess=ifcsCommonPage.validateAllTagInXMLForCardSalesAggregate(valuesFromQuery,nodeTag,localFolder);
		ifcsCommonPage.validateXMLFileAndValueForCardSalesAggregate(localFolder,valuess,nodeTag);
	}
	
	
	
}
