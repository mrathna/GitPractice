package com.framework.testcases.OLS.CHEV.Merchant;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.CHEV.CHHomePage;
import com.framework.pages.CHEV.CHTransactionPage;
import com.framework.pages.CHEV.CHTransactionSettlementsPage;
import com.framework.pages.OLS.common.CommonPage;
import com.framework.pages.OLS.common.LoginPage;

public class ValidateOLSMerchantSiteTransactions extends BaseTest {
	@Parameters({ "clientCountry", "clientName" })
	@Test(priority = 1)
	public void testOLSMerchantSiteTransactions(@Optional("PH") String clientCountry, @Optional("CHV") String clientName) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  OLS - Merchant Site - Transactions", "Chevron Merchant Screens Read Only");

		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		CHHomePage chHomePage = new CHHomePage(driver, test);
		CHTransactionPage chTransactionPage = new CHTransactionPage(driver, test);
		CHTransactionSettlementsPage chTransactionSettlementsPage = new CHTransactionSettlementsPage(driver, test);
		CommonPage commonPage = new CommonPage(driver, test);
		if (clientCountry.equals("SG")||clientCountry.equals("MY")||clientCountry.equals("HK")) {
			loginPage.Login("CHV_URL", "CHV_Merchant_UN_"+clientCountry, "CHV_Merchant_PWD_"+clientCountry, "CHV");
//			chHomePage.verifyUserName("Hello, Test");
			chHomePage.verifyMerchantAccountDetails();
		} else if (clientCountry.equals("TH")) {
			loginPage.Login("CHV_URL", "CHV_Merchant_UN_"+clientCountry, "CHV_Merchant_PWD_"+clientCountry, "CHV");
//			chHomePage.verifyUserName("Hello, THuser");
		} else if (clientCountry.equals("PH")) {
			loginPage.Login("CHV_URL", "CHV_Merchant_UN_"+clientCountry, "CHV_Merchant_PWD_"+clientCountry, "CHV");
//			chHomePage.verifyUserName("Hello, PHuser");
		}
		

		chHomePage.verifyMerchantQuickLinks();
		chHomePage.clickOnTransactionQuickLink();
		chTransactionPage.verifyTransactionPage();
		chHomePage.clickOnHome();
		chHomePage.clickOnExportTransactionLink();
		//chHomePage.checkForFileDownload(1);
		String checkFileDate=chHomePage.validateDateInDownloadedFile();
		commonPage.isFileDownloaded(checkFileDate);

	//	commonPage.isFileDownloaded("0700031161__20190408_");
		chHomePage.loadFindAndTransactionsPage();
		chTransactionPage.verifySearchButtons();
		chTransactionPage.verifyExportButtons();
		chTransactionPage.verifyMerchantTransListHeaders();
		chTransactionPage.verifyMerchantTransTableHeaders();
		
		// Goto settlements page
		chHomePage.loadFindAndSettlementsPage();
		chTransactionSettlementsPage.verifyMerchantSettlementsPage();
		chTransactionSettlementsPage.verifySearchButtons();
		chTransactionSettlementsPage.verifyExportButtons();
		chTransactionSettlementsPage.verifyMerchantSettlementsHeaders();
		chTransactionSettlementsPage.verifyMerchantSettlementsTableHeaders();

		
		chHomePage.clickExportSubMenu();
		 checkFileDate=chHomePage.validateDateInDownloadedFile();
		commonPage.isFileDownloaded(checkFileDate);
	//	commonPage.isFileDownloaded("00323667__20190408_");
		//chHomePage.checkForFileDownload(1);
		chHomePage.verifyFooterLinks();
		loginPage.Logout(); 
	}
}
