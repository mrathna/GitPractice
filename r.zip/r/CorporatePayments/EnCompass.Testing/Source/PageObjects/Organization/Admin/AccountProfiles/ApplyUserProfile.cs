﻿using Common;
using Common.Utility;
using EnCompass.Testing.Source.PageObjects.Controls;
using NFluent;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Support.UI;
using System;

namespace EnCompass.Testing.Source.PageObjects.Organization.Admin.AccountProfiles
{
    [PageModel(@"/admin/accountProfiles/applyUserProfile.aspx")]
    public class ApplyUserProfile : EnCompassOrgPageModel
    {
        public override string RelativeUrl => @"/admin/accountProfiles/applyUserProfile.aspx";
        public override string PageIdentifierXPath_Override => @"//h1[contains(@id,'title')]";

        #region XPath page Elements

        private const string _actionsCriteriaXPath = @"//select[contains(@id,'searchTermSelect')]";
        private const string _searchTermXPath = @"//select[contains(@id,'searchTermFilter')]";
        private const string _filterTypeXPath = @"//input[contains(@id,'SearchOutput')]";
        private const string _searchCriteriaAddBtnXPath = @"//input[@type='button' and @value='Add']";
        private const string _searchBtnXPath = @"//input[contains(@id, 'btnSearch')]";
        private const string _saveXPath = @"//input[contains(@id,'saveButton')]";
        private const string _applyUserProfileXPath = @"//input[contains(@id,'applySelection')]";
        private const string _enableApplyProfileChkLabelXPath = @"//label[contains(text(),'Apply Profile')]";
        private const string _enableApplyProfileCheckboxXPath = @"//input[contains(@id,'CheckboxColumnBoxActual')]";
        private const string SearchTerm = @"//select[contains(@id,'searchTermSelect')]";
        #endregion

        #region Page Elements
        private IWebElement _actionsCriteria
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_actionsCriteriaXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Info("Found _actionsCriteria");
                return element;
            }
        }

        private IWebElement _searchTerm
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_searchTermXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Info("Found _searchTerm");
                return element;
            }
        }

        private IWebElement _filterType
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_filterTypeXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Info("Found _filterType");
                return element;
            }
        }

        private IWebElement _searchCriteriaAddBtn
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_searchCriteriaAddBtnXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Info("Found _searchCriteriaAddBtn");
                return element;
            }
        }

        private IWebElement _searchBtn
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_searchBtnXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Info("Found _searchBtn");
                return element;
            }
        }

        private IWebElement _save
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_saveXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Info("Found _save");
                return element;
            }
        }

        private IWebElement _applyUserProflie
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_applyUserProfileXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Info("Found _applyUserProfile");
                return element;
            }
        }

        private IWebElement _enableApplyProfileCheckboxLabel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_enableApplyProfileChkLabelXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Info("Found _enableApplyProfileCheckboxLabel");
                return element;
            }
        }

        private IWebElement _enableApplyProfileCheckbox
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_enableApplyProfileCheckboxXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Info("Found _enableApplyProfileCheckbox");
                return element;
            }
        }
        #endregion

        public void SelectActionsCriteria(string whichText)
        {
            Driver.WaitForElementsToBeVisible(By.XPath(SearchTerm));
            var selectElement = new SelectElement(_actionsCriteria);
            selectElement.SelectByText(whichText);
        }
        public void SelectSearchTerm(string whichText)
        {
            var selectElement = new SelectElement(_searchTerm);
            selectElement.SelectByText(whichText);
        }

        public string FilterType
        {
            set
            {
                _filterType.Clear();
                _filterType.SendKeys(value);
            }
        }

        public void SearchCriteriaAddBtn()
        {
            _searchCriteriaAddBtn.JSClickWithFocus(Driver);
        }

        public void SearchBtn()
        {
            _searchBtn.JSClickWithFocus(Driver);
        }

        public void SelectUserToApply()
        {
            Settings.EnCompassWebDriver.WaitFor(By.XPath("//input[contains(@id,'applySelection')]"), TimeSpan.FromSeconds(10));
            _applyUserProflie.JSClickWithFocus(Driver);
        }

        public bool ApplyProfileCB {
            set { _enableApplyProfileCheckbox.SetCheckboxStateWithLabel(_enableApplyProfileCheckboxLabel, value); }
        }

        public void PressSave()
        {
            _save.JSClickWithFocus(Driver);
			this.AttachOnDemandScreenShot();
		}

        public ApplyUserProfile(GlobalSettings settings) : base(settings) { }
    }
}