using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using Common;
using Common.PageObjects;
using Common.ScenarioConfigurations;
using Common.Utility;

namespace EnCompass.Testing.Source.PageObjects.SuperAdmin.AocsuperTools.ReportsManagement 
{
	/// <summary>
	/// Auto-generated Page Model Class
	/// Navigation Paths: 
		/// [Organization Home]->Super Admin Tools->Reports->All Reports
		/// </summary>
	[PageModel(@"/superAdmin/AOCSuperTools/ReportsManagement/AllReports.aspx")]
	public partial class AllReports : EnCompassSuperPageModel 
	{
		public override string RelativeUrl => @"/superAdmin/AOCSuperTools/ReportsManagement/AllReports.aspx";
		public override string PageIdentifierXPath_Generated => @"//li[contains(@class, 'breadcrumb-item active')][text() = 'View Reports']";

		#region Navigation
				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='All Reports']")]
		private IWebElement _superAdminTools_Reports_AllReports_AllReports { get; set; }
		public void NavigateTo_SuperAdminTools_Reports_AllReports_AllReports()
		{
			NavigateToMenuItem(_superAdminTools_Reports_AllReports_AllReports);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Scheduled Reports Viewer']")]
		private IWebElement _superAdminTools_Reports_AllReports_ScheduledReportsViewer { get; set; }
		public void NavigateTo_SuperAdminTools_Reports_AllReports_ScheduledReportsViewer()
		{
			NavigateToMenuItem(_superAdminTools_Reports_AllReports_ScheduledReportsViewer);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='View Scheduled Reports' History']")]
		private IWebElement _superAdminTools_Reports_AllReports_ViewScheduledReportsHistory { get; set; }
		public void NavigateTo_SuperAdminTools_Reports_AllReports_ViewScheduledReportsHistory()
		{
			NavigateToMenuItem(_superAdminTools_Reports_AllReports_ViewScheduledReportsHistory);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='View Report Queue History']")]
		private IWebElement _superAdminTools_Reports_AllReports_ViewReportQueueHistory { get; set; }
		public void NavigateTo_SuperAdminTools_Reports_AllReports_ViewReportQueueHistory()
		{
			NavigateToMenuItem(_superAdminTools_Reports_AllReports_ViewReportQueueHistory);
		}

		
		private void NavigateToMenuItem(IWebElement element)
		{
			Driver.Url = element.GetAttribute("href");
		}
		#endregion

		public AllReports(GlobalSettings settings) : base(settings) { }
	}  
}
