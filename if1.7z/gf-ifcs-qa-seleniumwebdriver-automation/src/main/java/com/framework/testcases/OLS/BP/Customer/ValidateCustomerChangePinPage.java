package com.framework.testcases.OLS.BP.Customer;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.BP.BPChangePINPage;
import com.framework.pages.BP.BPHomePage;
import com.framework.pages.OLS.common.BPCommonPage;
import com.framework.pages.OLS.common.FindAndUpdateCardPage;
import com.framework.pages.OLS.common.LoginPage;

public class ValidateCustomerChangePinPage extends BaseTest {
	@Parameters({"clientCountry","clientName"})
	@Test(groups = {"Smoke" , "Regression" })
	public void Change_Pin(@Optional("AU") String clientCountry, @Optional("BP") String clientName)  {
		test = extent.createTest(clientName+ ":" +clientCountry+"  BP PIN change Validation", "Checking Change PIN Feature");

		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		BPHomePage bpHomePage = new BPHomePage(driver, test);
		BPCommonPage bpCommonPage = new BPCommonPage(driver, test);
		FindAndUpdateCardPage findCardPage = new FindAndUpdateCardPage(driver, test);
		BPChangePINPage bpChangePin = new BPChangePINPage(driver, test);

		// Call Function
	loginPage.Login("BP_URL", "BP_UN_Customer_" + clientCountry, "BP_PWD_Customer_" + clientCountry, clientName);
		bpHomePage.ValidateBPCustomerLogo();
		// Choose a Account
		bpCommonPage.selectAccount();

		// Load Find And Update Card Page
		bpHomePage.loadFindAndUpdateCardPage();
		
		findCardPage.selectAccountFromFindUpdateCardPage();

		// Search Cards and Change PIN for active card
		findCardPage.clickSearchCard();

		// Get ActiveCardNumber
		findCardPage.pickActiveCardNumber("Change PIN");
		findCardPage.pickActiveCardAndChangePIN();

		// Enter the New and confirm PIN
		bpChangePin.typeNewPin();
		bpChangePin.typeconfirmPIN();

		// saveChangeButton
		bpChangePin.clickSaveChangesButton();

		// Handle Reissue Popup if present
		bpChangePin.handleReissuePopupIfPresent();
		
		loginPage.Logout();
	}

}
