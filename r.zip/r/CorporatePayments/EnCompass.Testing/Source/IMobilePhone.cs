﻿using EnCompass.Testing.Source.PageObjects.Controls;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EnCompass.Testing.Source
{
    public interface IMobilePhone
    {
        string CellPolicyToolTip { get; }

        string CellPolicyHeader { get; }

        string CellPolicyBody { get; }

        bool IsCellPolicyVisible { get; }

        void ShowCellPolicy();

        void HideCellPolicy();

    }
}

