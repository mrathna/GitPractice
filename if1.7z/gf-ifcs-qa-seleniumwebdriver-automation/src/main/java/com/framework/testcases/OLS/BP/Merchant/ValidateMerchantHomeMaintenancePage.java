// Ayub Khan 07-05-2018
package com.framework.testcases.OLS.BP.Merchant;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.BP.BPHomePage;
import com.framework.pages.BP.MerchantMaintenancePage;
import com.framework.pages.OLS.HomePage;
import com.framework.pages.OLS.common.LoginPage;

public class ValidateMerchantHomeMaintenancePage extends BaseTest {
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "Smoke", "Regression" })
	public void merchentSettlement(@Optional("AU") String clientCountry, @Optional("NZ") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  BP Merchant MaintenancePage Validation",
				"Checking BP Merchant MaintenancePage Feature");

		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		BPHomePage bpHomePage = new BPHomePage(driver, test);
		MerchantMaintenancePage merchantMaintenancePage = new MerchantMaintenancePage(driver, test);

		// Calling Functions
		loginPage.Login("BP_URL", "BP_UN_Merchant_" + clientCountry, "BP_PWD_Merchant_" + clientCountry, "BP");
		bpHomePage.ValidateMerchantLogo();
		merchantMaintenancePage.clickMerchantSubMenuAndValidatePage();
		merchantMaintenancePage.verifyMerchantMaitenanecePageFields();
		merchantMaintenancePage.updateMerchantDetailsForAccount();
		merchantMaintenancePage.updateMerchantPostalsubandstateforAccount(clientCountry);
		merchantMaintenancePage.clickSaveButton();
		merchantMaintenancePage.checkConfirmationMessage();

		loginPage.Logout();

	}

	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "Regression" })
	public void merchantHomePageValidation(@Optional("AU") String clientCountry, @Optional("NZ") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  BP Merchant Home Page Validation", "Checking BP Merchant Home Page");

		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		BPHomePage bpHomePage = new BPHomePage(driver, test);
		HomePage homePage = new HomePage(driver, test);

		// Calling Functions
		loginPage.Login("BP_URL", "BP_UN_Merchant_" + clientCountry, "BP_PWD_Merchant_" + clientCountry, "BP");
		bpHomePage.ValidateMerchantLogo();
		homePage.ValidateLogoutLink();
		homePage.ValidateQuickLinks();
		homePage.HomePageValidation();
		loginPage.Logout();

	}

}
