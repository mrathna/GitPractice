/*
 * Ayub Khan 07-05-2018
 */

package com.framework.pages.BP;

import java.util.List;

import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.ExtentTest;
import com.framework.basepage.BasePage;
import com.framework.pages.OLS.common.BPCommonPage;
import com.framework.repo.Locator;

public class MerchantSettlementPage extends BasePage {

	boolean flag;
	boolean isDisplayed;

	@FindBy(id = Locator.ENQUIRY_START_DATE)
	public WebElement startDate;
	@FindBy(id = Locator.SET_LOCATION_NUM)
	public WebElement locationNumber;
	@FindBy(id = Locator.SEARCH_BTN)
	public WebElement searchButton;

	@FindBy(how = How.XPATH, using = Locator.SETTLEMENT_LIST)
	public List<WebElement> settlementList;

	@FindBy(id = Locator.SETTLEMENT_LIST_NOITEM)
	public WebElement noItem;
	@FindBy(id = Locator.BACK_TO_SETTLEMENT_LIST)
	public WebElement backToSettlementList;
	@FindBy(id = Locator.EXPORT_TO_EXCEL_SETT)
	public WebElement exportExcel;

	BPHomePage bpHomePage = new BPHomePage(driver, test);
	BPCommonPage bpCommonPage = new BPCommonPage(driver, test);

	public MerchantSettlementPage(WebDriver driver, ExtentTest test) {
		super(driver, test);
		// TODO Auto-generated constructor stub
		PageFactory.initElements(driver, this);
	}

	public void findsettlementDetailsForMerchent(String clientCountry) {
		if (clientCountry.equals("AU")) {
//			bpHomePage.selectInputFromAccountDropdown("RAM TEST - (DSS) Frankford Store  (9000001394)");
			bpCommonPage.selectAccount();
			sleep(5);
			isDisplayedThenEnterText(startDate, "Start Date", "08/07/2012");
			sleep(2);
			//isDisplayedThenEnterText(locationNumber, "Location Number", "00002498");
			isDisplayedThenClick(searchButton, "Search Button");
		//	driver.navigate().refresh();
			sleep(5);
		} else if (clientCountry.equals("NZ")) {
			//bpHomePage.selectInputFromAccountDropdown("3KS AUTOMOBILE AND MECHANICAL  (0100000289)");
			bpCommonPage.selectAccount();
			sleep(5);
			isDisplayedThenEnterText(startDate, "Start Date", "31/05/2012");
			
			isDisplayedThenEnterText(locationNumber, "Location Number", "00001331");
			isDisplayedThenClick(searchButton, "Search Button");
			sleep(5);

		}

	}

	/**
	 * Select a settlement List and View Transactions - Added by Ayub 08-05-2018
	 */
	public void clicksettlementList() {
		int randomNo;
		try {
			if (settlementList.size() > 0) {
				System.out.println("settlemet  size --> " + settlementList.size());
				randomNo = getRandomNumber(0, settlementList.size() - 1);
				// cardNumber = allListedCards.get(randomNo).getText();
				actionClick(settlementList.get(randomNo));
				isDisplayed = true;
			}
		} catch (NoSuchElementException ex) {
			isDisplayed = false;
			logInfo("No items found");
		}
		sleep(5);

	}

	public void clickBackToSettlementList() {
		if (isDisplayed) {
			isDisplayed(backToSettlementList, "Back to Settlement Link");
			backToSettlementList.click();

		} else {
			logInfo("No Rows are found in Settlment Link, So can't able to find Settlement Link");
		}
	}

	public void clickExportExcel() {
		isDisplayed(exportExcel, "exportExcel");
	}
	// Added by Ayub on 3-12-2018
	
	public boolean verifySettlementListIsAvailable()
	{
		boolean isSettlementList = false;
		
		isSettlementList = waitForTextToAppear("No items found.", 30);		
		
		return isSettlementList;
	}
	public void printNoSettlementListPresent() {
		logInfo("No SettlementList is present");		
	}
}
