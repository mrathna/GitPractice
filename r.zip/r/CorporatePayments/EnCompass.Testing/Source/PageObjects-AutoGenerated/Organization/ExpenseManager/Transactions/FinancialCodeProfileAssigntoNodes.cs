using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using Common;
using Common.PageObjects;
using Common.ScenarioConfigurations;
using Common.Utility;

namespace EnCompass.Testing.Source.PageObjects.Organization.ExpenseManager.Transactions 
{
	/// <summary>
	/// Auto-generated Page Model Class
	/// Navigation Paths: 
		/// [Organization Home]->Transactions->Financial Codes->Profiles->Assign Hierarchies
		/// </summary>
	[PageModel(@"/expenseManager/transactions/FinancialCodeProfileAssigntoNodes.aspx")]
	public partial class FinancialCodeProfileAssigntoNodes : EnCompassOrgPageModel 
	{
		public override string RelativeUrl => @"/expenseManager/transactions/FinancialCodeProfileAssigntoNodes.aspx";
		public override string PageIdentifierXPath_Generated => @"//li[contains(@class, 'breadcrumb-item active')][text() = 'Assign Hierarchies']";

		#region Navigation
				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Profiles']")]
		private IWebElement _transactions_FinancialCodes_Profiles_AssignHierarchies_Profiles { get; set; }
		public void NavigateTo_Transactions_FinancialCodes_Profiles_AssignHierarchies_Profiles()
		{
			NavigateToMenuItem(_transactions_FinancialCodes_Profiles_AssignHierarchies_Profiles);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Assign Cards']")]
		private IWebElement _transactions_FinancialCodes_Profiles_AssignHierarchies_AssignCards { get; set; }
		public void NavigateTo_Transactions_FinancialCodes_Profiles_AssignHierarchies_AssignCards()
		{
			NavigateToMenuItem(_transactions_FinancialCodes_Profiles_AssignHierarchies_AssignCards);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Assign Hierarchies']")]
		private IWebElement _transactions_FinancialCodes_Profiles_AssignHierarchies_AssignHierarchies { get; set; }
		public void NavigateTo_Transactions_FinancialCodes_Profiles_AssignHierarchies_AssignHierarchies()
		{
			NavigateToMenuItem(_transactions_FinancialCodes_Profiles_AssignHierarchies_AssignHierarchies);
		}

		
		private void NavigateToMenuItem(IWebElement element)
		{
			Driver.Url = element.GetAttribute("href");
		}
		#endregion

		public FinancialCodeProfileAssigntoNodes(GlobalSettings settings) : base(settings) { }
	}  
}
