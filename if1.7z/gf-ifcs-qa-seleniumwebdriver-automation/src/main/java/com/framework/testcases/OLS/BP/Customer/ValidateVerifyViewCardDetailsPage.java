package com.framework.testcases.OLS.BP.Customer;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.BP.BPHomePage;
import com.framework.pages.OLS.common.BPCommonPage;
import com.framework.pages.OLS.common.FindAndUpdateCardPage;
import com.framework.pages.OLS.common.LoginPage;

public class ValidateVerifyViewCardDetailsPage extends BaseTest {
	@Parameters({ "clientCountry", "clientName" })
	 @Test( groups = { "Regression" })
	 public void VerifyViewCardDetailsPage(@Optional("AU") String clientCountry,
	 @Optional("BP") String clientName) {
	 test = extent.createTest(clientName+ ":" +clientCountry+"  BP CardDetailsPageValidation", "Validate the CardDetailsPage");
	 LoginPage loginPage = new LoginPage(driver, test);
	 BPHomePage bpHomePage = new BPHomePage(driver, test);
	 loginPage.Login("BP_URL", "BP_UN_Customer_" + clientCountry,
	 "BP_PWD_Customer_" + clientCountry, clientName);
	 bpHomePage.ValidateBPCustomerLogo();
	 FindAndUpdateCardPage findCardPage = new FindAndUpdateCardPage(driver, test);
	
	 // Choose a Account
	 //bpCommonPage.selectAccount();
	
	 // Load Find And Update Card Page
	 bpHomePage.loadFindAndUpdateCardPage();
	 findCardPage.selectAccountFromFindUpdateCardPage();
	
	 // Search Cards
	 findCardPage.clickSearchCard();
	
	 // Select Go To from Card Menu
	 findCardPage.clickGoToCardAndVerifyHeaderTitle();
	 findCardPage.checkCardNumberInViewCardPage();
	
	 // Validate the Card Details Page
	 findCardPage.validateTheCardDetailsPage();
	 loginPage.Logout();
	 }

	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "Regression" })
	public void VerifyViewCardTransactionLinkViewCardDetails(@Optional("AU") String clientCountry,
			@Optional("BP") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  BP Transaction Details Page Validation", "Validate the Card Transaction");
		LoginPage loginPage = new LoginPage(driver, test);
		BPHomePage bpHomePage = new BPHomePage(driver, test);
		loginPage.Login("BP_URL", "BP_UN_Customer_" + clientCountry, "BP_PWD_Customer_" + clientCountry, clientName);
		bpHomePage.ValidateBPCustomerLogo();
		BPCommonPage bpCommonPage = new BPCommonPage(driver, test);
		FindAndUpdateCardPage findCardPage = new FindAndUpdateCardPage(driver, test);

		// **View Card Transaction
		// Choose a Account
		bpCommonPage.selectAccount();

		// Load Find And Update Card Page
		bpHomePage.loadFindAndUpdateCardPage();

		// Search Cards
		findCardPage.clickSearchCard();

		// Select View Transactions from Card Menu
		findCardPage.clickViewTransactionsAndVerifyHeaderTitle();
		findCardPage.checkCardNumberInTransactionPage();

		// Validate the Transaction Details page
		findCardPage.validateTheTransactionsDetailsPage();
		loginPage.Logout();
	}
}
