package com.framework.testcases.CRUISE.WES;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.WES.Cruise.CruiseCallSheetPage;
import com.framework.pages.WES.Cruise.CruiseHomePage;
import com.framework.pages.WES.common.LoginPage;

public class ValidateCustomerCampaignsAndCreatingApplication extends BaseTest {
	String salesCampaignName = "";
	String adhocCamapignName = "";
	String customerCamapignName = "";

	@Parameters({ "clientName" })
	@Test(groups = { "Regression" })
	public void validateAndCreatecustomerCampaign(@Optional("WES") String clientName) {

		test = extent.createTest(clientName+ ":  TC008 Customer should able to create a SALES campaign,TC009 Customer should able to create a ADHOC campaign,"
				+ "TC010 Customer should able to create a Customer Maintenance campaign,TC011 Customer should able to view the created campaign",
				"Customer should able to create and View campaigns");

		// Creating Objects for the Pages		
		LoginPage loginPage = new LoginPage(driver, test);

		CruiseCallSheetPage callSheetPage = new CruiseCallSheetPage(driver, test);

		System.out.println("URL: " + clientName);

		loginPage.loginWES("Cruise_URL", "Cruise_UN_Sales_User_" + clientName, "Cruise_PWD_Sales_User_" + clientName,
				"CRUISE");

		// Sales Campaign

		salesCampaignName = callSheetPage.getCampaignNameandValidate("SALES");

		callSheetPage.validateListCampaign(salesCampaignName);

		// Adhoc campaign
		adhocCamapignName = callSheetPage.getCampaignNameandValidate("ADHOC");
		callSheetPage.validateListCampaign(adhocCamapignName);

		/* customer_maintenance Campaign, We are unable to proceed,due to error occurred
		 in customer maintenance summary page*/
		
		 customerCamapignName=callSheetPage.getCampaignNameandValidate("CUSTOMER_MAINTENANCE");
		 
		loginPage.logoutTheApplication("Cruise");

	}

	// sasi
	@Parameters({ "clientName" })
	@Test(groups = { "Regression" })
	public void ValidateCallsheetUploadAndVerify(@Optional("WES") String clientName) {

		test = extent.createTest(clientName+ ":  TC012 Customer should able to upload calls for the SALES campaigns",
				"Customer should able to upload calls for the SALES campaigns");

		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		CruiseCallSheetPage callSheet = new CruiseCallSheetPage(driver, test);
		loginPage.loginWES("Cruise_URL", "Cruise_UN_Sales_User_" + clientName, "Cruise_PWD_Sales_User_" + clientName,
				"CRUISE");

		callSheet.copyAndUpdateExcelFile();
		callSheet.goToCallsheetImport(salesCampaignName);
		callSheet.uploadingCallSheet();

		callSheet.validateListCampaign(salesCampaignName);
		callSheet.validatingValuesFromExcelSheet("Business Name", "CompanyName");
		loginPage.logoutTheApplication("Cruise");

	}
	@Parameters({ "clientName" })
	@Test(groups = { "Regression" })
	public void validateCustomerViewImports(@Optional("WES") String clientName) {

		test = extent.createTest(clientName+ ":   TC 013Customer should able to view the imports",
				"Customer should able to view the imports");
		LoginPage loginPage = new LoginPage(driver, test);
		CruiseCallSheetPage callSheetPage = new CruiseCallSheetPage(driver, test);
		loginPage.loginWES("Cruise_URL", "Cruise_UN_Sales_User_" + clientName, "Cruise_PWD_Sales_User_" + clientName,
				"CRUISE");
		// Creating Objects for the Pages
				
		callSheetPage.viewCustomerImports(salesCampaignName);
		loginPage.logoutTheApplication("Cruise");
	}

	@Parameters({ "clientName" })
	@Test(groups = { "Regression" })
	public void validateManageCustomerCampaignAndAssignSelectedCalls(@Optional("WES") String clientName) {

		test = extent.createTest(clientName+ ": TC014 and TC015 Customer should able to create manage campaign user and assign selected calls",
				"validate manage campaign user and assign selected calls");
		LoginPage loginPage = new LoginPage(driver, test);
		CruiseCallSheetPage callSheetPage = new CruiseCallSheetPage(driver, test);
		loginPage.loginWES("Cruise_URL", "Cruise_UN_Sales_User_" + clientName, "Cruise_PWD_Sales_User_" + clientName,
				"CRUISE");

		// This method is covered by 2 Test cases such as Customer should able to create
		// Manage Campaign User and Assign selected Calls
		
		callSheetPage.validateListCampaign(salesCampaignName);
		callSheetPage.validateManageCamapaignUser();
		callSheetPage.validateAssignSelectedCalls(salesCampaignName, "WexSales Sup");
		loginPage.logoutTheApplication("Cruise");
	}

	@Parameters({ "clientName" })
	@Test(groups = { "Regression" })
	public void validateReclaimPendingCalls(@Optional("WES") String clientName) {

		test = extent.createTest(clientName+ ":   TC016 Customer should able to Reclaim Pending  calls",
				"verify Customer should able to Reclaim Pending calls");

		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		CruiseCallSheetPage callSheetPage = new CruiseCallSheetPage(driver, test);
		loginPage.loginWES("Cruise_URL", "Cruise_UN_Sales_User_" + clientName, "Cruise_PWD_Sales_User_" + clientName,
				"CRUISE");

		callSheetPage.validateListCampaign(salesCampaignName);
		String businessname = callSheetPage.getBusinessNameInCampaignSummary("WexSales Sup");
		callSheetPage.validateReclaimPendingCalls(businessname);
		loginPage.logoutTheApplication("Cruise");

	}

	@Parameters({ "clientName" })
	@Test(groups = { "Regression" })
	public void validateAssignCallsRandomly(@Optional("WES") String clientName) {

		test = extent.createTest(clientName+ ":  TC017 Customer should able to Assign calls Randomly",
				"verify Customer should able to Assign calls Randomly");

		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		CruiseCallSheetPage callSheetPage = new CruiseCallSheetPage(driver, test);
		loginPage.loginWES("Cruise_URL", "Cruise_UN_Sales_User_" + clientName, "Cruise_PWD_Sales_User_" + clientName,
				"CRUISE");

		callSheetPage.validateListCampaign(salesCampaignName);
		int calls = callSheetPage.getUnallocatedCalls();
		callSheetPage.validateAssignCallsRandomly(calls, "WexSales Sup", salesCampaignName);
		loginPage.logoutTheApplication("Cruise");

	}
	//Raxsana
	@Parameters({ "clientName" })
	@Test(groups = { "Regression" })
	public void validateAndCreateFollowupCampaign(@Optional("WES") String clientName) {

		test = extent.createTest(clientName+ ":   TC 018Customer should able to Create Followup Campaign",
				"Customer should able to Create Followup Campaign");

		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		CruiseCallSheetPage callSheetPage = new CruiseCallSheetPage(driver, test);
		loginPage.loginWES("Cruise_URL", "Cruise_UN_Sales_User_" + clientName, "Cruise_PWD_Sales_User_" + clientName,
				"CRUISE");
		callSheetPage.createAndValidateFollowupCampaign(salesCampaignName);
		loginPage.logoutTheApplication("Cruise");
	}

	@Parameters({ "clientName" })
	@Test(groups = { "Regression" })
	public void validateandDownloadCallSheets(@Optional("WES") String clientName) {

		test = extent.createTest(clientName+ ":  TC019 Customer should able to download and view the call details in the sheet",
				"Customer should able to download and view the call details in the sheet");

		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		CruiseCallSheetPage callSheetPage = new CruiseCallSheetPage(driver, test);

		// Login the Application
		loginPage.loginWES("Cruise_URL", "Cruise_UN_Sales_User_" + clientName, "Cruise_PWD_Sales_User_" + clientName,
				"CRUISE");

		callSheetPage.downloadExcelCampaigns(salesCampaignName, "Campaign");

	}


//Ayub
	@Parameters({ "clientName" })
	@Test( groups = { "Regression" })
	public void ValidateCustomerShouldAbleToCreateApplicationThroughCalls(@Optional("WES") String clientName) {

		test = extent.createTest(clientName+ ":  TC 020 Verify Customer should able to create application through calls",
				"Customer should able to create application through calls");

		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		CruiseHomePage homePage = new CruiseHomePage(driver, test);
		CruiseCallSheetPage callSheetPage = new CruiseCallSheetPage(driver, test);
		loginPage.loginWES("Cruise_URL", "Cruise_UN_Sales_User_" + clientName, "Cruise_PWD_Sales_User_" + clientName,
				"CRUISE");
		String salesCampaignName = "Sales_Kari Mayert DDS";
		callSheetPage.validateListCampaign(salesCampaignName);
		String businessname = callSheetPage.getBusinessNameInCampaignSummary("WexSales Sup");
		homePage.gotoCallSheetTable();
		callSheetPage.selectCallsFromCallSheetandValidateApplication(businessname,salesCampaignName);
		loginPage.logoutTheApplication("Cruise");
	}

}
