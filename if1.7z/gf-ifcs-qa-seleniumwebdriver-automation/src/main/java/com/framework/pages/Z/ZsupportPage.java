package com.framework.pages.Z;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.ExtentTest;
import com.framework.basepage.BasePage;
import com.framework.pages.OLS.HomePage;
import com.framework.repo.Locator;
import com.framework.util.PropUtils;

public class ZsupportPage extends BasePage {
	
	@FindBy(id=Locator.TOPUSERDD)
	public WebElement userdropdown;
		
	@FindBy(id=Locator.CHANGE_PWD_IN_HELLO_UN_LINK)
	public WebElement changePassword;
	
	@FindBy(how = How.XPATH, using = Locator.USER_ID)
	public WebElement userId;
	
	@FindBy(id=Locator.PASSWORD_FIELD)
	public WebElement currentPasswordField;
	
	@FindBy(id=Locator.CONFIRM_PASSWORD)
	public WebElement newPasswordField;
	
	@FindBy(id=Locator.CONFIRM_PASSWORD)
	public WebElement confirmPasswordField;
	
	@FindBy(xpath = Locator.CHANGE_PASSWORD_SUCCESS_MESSAGE)
	public WebElement successMessage;
	


	
	public ZsupportPage(WebDriver driver, ExtentTest test) {
		super(driver, test);
		PageFactory.initElements(driver, this);
	}
	
	HomePage homePage = new HomePage(driver, test);
	
	public void goToChangePasswordMaintenancePageAndValidate() {
		isDisplayedThenActionClick(userdropdown, "User drop down");
		isDisplayed(changePassword, "Chnage Password");
		isDisplayedThenActionClick(changePassword, "Chnage Password");
		sleep(2);
		isDisplayed(userId, "User Name");
		isDisplayed(currentPasswordField, "Current Password field");
		isDisplayed(newPasswordField, "New Password field");
		isDisplayed(confirmPasswordField, "Confirm Password Field");
		
	}
	
	public void enterValidPwdNewPwdConfirmPwdAndValidate(String currentPassword) {
		
		String currentPwd = PropUtils.getPropValue(configProp, currentPassword);
		//driver.get(PropUtils.getPropValue(configProp, currentPassword));
		System.out.println("---currentPassword---"+currentPwd);
		homePage.changePassword(currentPwd, currentPwd+"#");
		sleep(3);
	//	isDisplayed(successMessage, "Success Message Displayed");
	}

}
