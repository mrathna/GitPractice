﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace Common.Utility
{
	public class SOAPClientHelper
	{
		public static HttpWebRequest CreateWebRequest(string URI, string requestType)
		{
			HttpWebRequest webRequest = (HttpWebRequest)WebRequest.Create(URI);
			webRequest.Headers.Add(@"SOAP:Action");
			webRequest.ContentType = "text/xml;charset=\"utf-8\"";
			webRequest.Accept = "text/xml";
			webRequest.Method = requestType;
			webRequest.KeepAlive = false;
			webRequest.Timeout = 1800000;
			webRequest.ProtocolVersion = HttpVersion.Version11;
			webRequest.Proxy = null;
			return webRequest;
		}

        public static HttpWebRequest CreateWebRequestAisp(string URI, string requestType, string aispName)
        {
            HttpWebRequest webRequest = (HttpWebRequest)WebRequest.Create(URI);
            webRequest.Headers.Add(@"SOAP:Action");
            webRequest.ContentType = "text/xml";
            webRequest.Headers.Add(@"MutualAuth-ClientCert", aispName);
            webRequest.Headers.Add(@"MutualAuth-ClientCN", aispName);
            webRequest.Method = requestType;
            webRequest.Proxy = null;
            return webRequest;
        }
    }
}
