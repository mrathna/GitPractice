using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using Common;
using Common.PageObjects;
using Common.ScenarioConfigurations;
using Common.Utility;

namespace EnCompass.Testing.Source.PageObjects.SuperAdmin.UserEmulatorSearch 
{
	/// <summary>
	/// Auto-generated Page Model Class
	/// Navigation Paths: 
		/// [Organization Home]->Users and Organizations->User Emulator
		/// </summary>
	[PageModel(@"/superAdmin/UserEmulatorSearch/userEmulatorSearch.aspx")]
	public partial class UserEmulatorSearch : EnCompassSuperPageModel 
	{
		public override string RelativeUrl => @"/superAdmin/UserEmulatorSearch/userEmulatorSearch.aspx";
		public override string PageIdentifierXPath_Generated => @"//li[contains(@class, 'breadcrumb-item active')][text() = 'User Emulator']";

		#region Navigation
		
		private void NavigateToMenuItem(IWebElement element)
		{
			Driver.Url = element.GetAttribute("href");
		}
		#endregion

		public UserEmulatorSearch(GlobalSettings settings) : base(settings) { }
	}  
}
