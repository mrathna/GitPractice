﻿using AventStack.ExtentReports;
using Common;
using Common.Utility;
using EnCompass.Testing.Source.PageObjects.Controls;
using NFluent;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace EnCompass.Testing.Source.PageObjects.Organization.ExpenseManager.Transactions
{
	public partial class TransactionsTopActions
    {
        public override string PageIdentifierXPath_Override => @"//h1[normalize-space(text())='Transaction Management' or text()='Gestión de transacciones' or text()='Transactions' or text()='Gestione transazioni' or text()='Transactiemanagement' or text()='Gestion de la transaction' or text()='Transaktionsmanagement']";

        #region XPath page Elements

        public const string _saveBtn = @"//input[contains(@id,'btnSubmit')]";
        public const string _saveBtnNewGrid = @"//button[contains(@id,'btnUpdate')]";
        public const string _btnAddNotes = @"//button[@data-encompass-table-multi-action='AddNotes']";
        public const string _envelopeIFrame = @"//iframe[contains(@id, 'viewEnvelope')]";
        public const string _billingDetailsIFrame = @"//iframe[contains(@id, 'viewBillingDetails')]";
        public const string _envelopeNameInIFrame = @"//div[@class='modal-body']//ul//li[contains(text(),'Envelope name')]//strong";
        public const string _employeeFirstNameInIFrame = @"//span[contains(@id, 'lblEmployeeFirstName')]";
        public const string _employeeLastNameInIFrame = @"//span[contains(@id, 'lblEmployeeLastName')]";
        public const string _transactionsInEnvelopeInIFrame = @"//span[contains(@id, 'lblTransactionsInEnvelope')]";
        public const string _envelopeAmountInIFrame = @"//div[@class='modal-body']//ul//li[contains(text(),'Envelope amount')]//strong";
        public const string _closeBtnInIFrame = @"//input[contains(@id, 'Button1')]";
        public const string _manageReceiptsModalIframe = @"//iframe[contains(@id,'ManageReceiptsModal') or contains(@src,'ManageReceiptsModal')]";
        // Xpath to use when we want to get assigned FinCode w.r.t any row in the Transactions Grid
        public static string _assignedFinancialCode_Unlocked = ".//following-sibling::tr[contains(@id,'_RC')]//table[contains(@class,'a_cs_table')]//input[@value='{0}']";
        public const string _assignedFinancialCode_Locked = @".//following-sibling::tr[contains(@id,'_RC')]//table[contains(@class,'a_cs_table')]//input[@readonly = 'readonly']";
        public const string _assignedFinancialCode_LockedNewGrid = "//input[contains(@id, 'FC') and @readonly = 'readonly']";
        public const string _assignedFinancialCode_UnlockedNewGrid = "//input[contains(@id, 'FC') and @value='{0}']";
        // Xpaths for Notes and Label w.r.t any row in the Transactions Grid
        public const string _transNotes = ".//label[text() = 'Notes']//following-sibling::textarea";
        public const string _transLabelXPath = ".//label[text() = 'TestLabel']//following-sibling::textarea";
        public const string _dateRangeDropdownXpath = "//select[contains(@id, 'DateRanges_ddlPeriod')]";
        public const string _transactionGridSplitCheck = "//td/i[@class='fa fa-check text-success']";
        public const string _transactionManagementDiv = "//div[contains(@id,'_content_searchContainer')]";

        private const string _searchCriteriaSearchTermXPath = @"//select[contains(@id, 'searchTermSelect')]";
        private const string _searchCriteriaFilterTypeXPath = @"//select[contains(@id, 'searchTermFilter')]";
        private const string _searchCriteriaTextSearchValueXPath = @"//div[contains(@id, 'SearchOutput')]/input[1]";
        private const string _searchCriteriaListboxSearchValueXPath = @"//div[contains(@id, 'SearchOutput')]/select";
        private const string _searchCriteriaResetBtnXPath = @"//button[@type='button'][text()='Clear']";
        private const string _searchCriteriaAddBtnXPath = @"//input[@type='button' and contains(@id, 'addSingleValue')]";
        private const string _searchCriteriaCancelBtnXPath = @"//input[contains(@id, 'btnCancel')]";
        private const string _modalCancelBtnXPath = @"//input[contains(@id, 'footer_btnClose')]";
        private const string _searchXPath = @"//input[contains(@id, 'btnSearch')]";
        private const string _submitToWorkflowXPath = @"//input[contains(@id, 'workflowSubmit')]";
        private const string _outOfPocketBtnXPath = @"//a[@role='button' and contains(@href, 'OutOfPocket')]";
        private const string _pagingXPath = @"//select[contains(@id, 'Top_pageSizesDropdown')]";
        private const string _dateRangeOptionXPath = @"//select[contains(@id, 'DateRanges_ddlOptions')]";
        private const string _dateFromXPath = @"//input[contains(@id, 'txtDateFrom')]";
        private const string _dateToXPath = @"//input[contains(@id, 'txtDateTo')]";
        private const string _showSummaryXPath = @"//a[contains(@id, 'TransactionsSummary')]";
        private const string _reviewedCountXPath = @"//span[contains(@id, 'lblRevCnt')]";
        private const string _txnInEnvelopeCountXPath = @"//ul[@class='list-inline mb-1']/li[contains(text(),'in envelope')]/strong";
        private const string _reviewedAmountXPath = @"//span[contains(@id, 'lblRevSum')]";
        private const string _approvedCountXPath = @"//span[contains(@id, 'lblAppCnt')]";
        private const string _approvedAmountXPath = @"//span[contains(@id, 'lblAppSum')]";
        private const string _approved2CountXPath = @"//span[contains(@id, 'lblApp2Cnt')]";
        private const string _approved2AmountXPath = @"//span[contains(@id, 'lblApp2Sum')]";
        private const string _totalNumberOfTransactionsXPath = @"//span[contains(@id, 'lblTotalNumberofTransactions')]";
        private const string _totalTransactionsAmountXPath = @"//span[contains(@id, 'lblTotalSum')]";
        private const string _reviewerCBXPath = @"//input[contains(@id, '_R')][contains(@id, 'contents_t')]";
        private const string _approver1CBXPath = @"//input[contains(@id, '_A')][contains(@id, 'contents_t')]";
        private const string _approver2CBXPath = @"//input[contains(@id, '_A2')][contains(@id, 'contents_t')]";
        private const string _inEnvelopeCBXPath = @"//input[contains(@id, '_E')][contains(@id, 'contents_t')]";
        private const string _envelopeImageXPath = @"//a[contains(@id, '_EI')][contains(@id, 'contents_t')]";
        private const string _errorMessageXPath = @"//div[contains(@id,'ValidationSummary')]//li";
        private const string _cardNumberXPath = @"//td[contains(@class,'searchBody')][contains(text(),'Card Number')]";
        private const string _transactionDetailsXPath = @"//a[contains(@id,'rowButtons_actionLink2')]";
        private const string _manageReceiptsXPath = @"//a[contains(@id,'rowButtons_actionLink4')]";
        private const string _successMessageXPath = @"//div[contains(@id,'SuccessMessage') or contains(@id,'ValidationAlertMessages')] ";
        private const string _cardNumberDropDownListXPath = @"//select[contains(@id,'ddlAccounts')]";
        private const string _SelectInEnvelopeForAllRowCheckboxXPath = @"//input[contains(@id,'CheckboxColumnBoxActual_14')]";
        private const string _SelectInEnvelopeFirstRowCheckboxXPath = @"//input[contains(@id,'ctl03_E')]";
        private const string _closeButtonXPath = @"//div[contains(@id,'Modal_')]//div[@class='modal-content']/div[contains(@id,'footer_')]/button";
        private const string _closeBillingDetailsXPath = @"//input[@name = 'ctl00$footerContent$btnCloseModal']";
        private const string _SelectInEnvelopeSecondRowCheckboxXPath = @"//input[contains(@id,'ctl04_E')]";
        private const string _btnManageReceiptXPath = @"//input[contains(@id, 'btnManageReceipt')]";
        private const string _btnRejectEnvelopeXPath = @"//input[contains(@id, 'btnRejectEnvelope')]";
        private const string _ddlInEnvelopeSearchXPath = @"//select[contains(@id,'ddlInEnvelopeSearch')]";
        private const string _btnResetXPath = @"//input[@type='reset' and @value='Reset']";
        private const string _btnPrintEnvelopeXPath = @"//button[contains(@id,'printEnvelope')]";
        private const string _envelopeRejectReasonXPath = @"//input[contains(@id, '//div[@id='envelopeRejectDisplayModal']//textarea[contains(@id,'RejectReason')]')]";
        private const string _splitTransactionBtnXPath = @"//a[contains(@id,'actionLink') and text()='Split Transaction']";
        private const string _workflowRejectModalXPath = @"//div[contains(@id, 'WorkflowRejectModalForm')]//textarea[contains(@id,'RejectReason')]";
        private const string _workflowRejectConfirmBtnXPath = @"//div[contains(@id, 'WorkflowRejectModalForm')]//input[contains(@id,'cmdRejectButton')]";
        private const string _rowCardSearchInfoXPath = @"//tr[contains(@id,'rowCardSearch')]";
        private const string _rejectTransactionXPath = @"//a[contains(@id,'actionLink') and text()='Reject Transaction']";
        private const string _selectReviewForAllRowCheckboxXPath = @"//input[contains(@id,'CheckboxColumnBoxActual_11') and @type='checkbox']";
        private const string _selectActionForAllRowCheckboxXPath = @"//input[(contains(@id,'_ToggleAll') or contains(@id,'CheckboxColumnBoxActual_0')) and @type='checkbox']";
        private const string _selectActionForFirstRowCheckboxXPath = @"//input[contains(@id,'ctl03_STCB') or contains(@id,'ctl00_ctl00_content_contents_tblTransactions_Row_Selected')]";
        private const string _selectActionForSecondRowCheckboxXPath = @"//input[contains(@id,'ctl04_STCB') or contains(@id,'ctl00_ctl00_content_contents_tblTransactions_Row_Selected_1')]";
        private const string _selectActionForThirdRowCheckboxXPath = @"//input[contains(@id,'ctl05_STCB') or contains(@id,'ctl00_ctl00_content_contents_tblTransactions_Row_Selected_2')]";
        private const string _selectActionForFourthRowCheckboxXPath = @"//input[contains(@id,'ctl06_STCB') or contains(@id,'ctl00_ctl00_content_contents_tblTransactions_Row_Selected_3')]";
        private const string _selectApprovel1ForAllRowCheckboxXPath = @"//input[contains(@id,'CheckboxColumnBoxActual_12') and @type='checkbox']";
        private const string _saveTransactionXPath = @"//input[contains(@id, 'btnSave')]";
        private const string _btnModalCloseXPath = @"//input[@type='submit' and @value='Close']";
        private const string _myCardsCheckboxXPath = @"//input[contains(@id,'chkMyCards') and @type='checkbox']";
        private const string _myCardsCheckboxLabelXPath = @"//label[contains(@for,'chkMyCards')]";
        private const string _hierarchyExplorerXPath = @"//a[contains(@id,'hierarchyExplorer')]";
        private const string _allSelectTransactionCheckboxXPath = @"//input[contains(@id,'STCB')]";
        private const string _cbFirstTxnRowXPath = @"//input[contains(@id,'ctl03_STCB')]";
        private const string _cbSecondTxnRowXPath = @"//input[contains(@id,'ctl04_STCB')]";
        private const string _cardNameXPath = @"//input[contains(@id,'litAccount')]";
        private const string _confirmModalPopUpXPath = @"//button[text() = 'Confirm']";
        private const string _transactionMgmtTitleXPath = @"//h1[contains(@id,'title') and text()='Transaction Management']";
        public const string _financialCodesTransactionModalIframe = "//iframe[contains(@src,'AccountingFieldLookup.aspx') and contains(@id,'IFrameModal')]";
        private const string _legendLayoutXPath = "//legend[contains(text(), 'Layout')]";
        private const string _envelopePrintPortraitXPath = "//input[@id='envelopePrintPortrait']";
        private const string _envelopePrintLandscapeXPath = "//input[@id='envelopePrintLandscape']";
        private const string _btnCloseXPath = "//button[@id='close']";
        private const string _envelopePrintXPath = "//button[@id='envelopePrint']";
        private const string _modalTittleXPath = "//h1[contains(@id, 'ModalTitle') and text() = 'Submit for Approval']";
        public const string _transWorkflowDiv = @".//td//div[contains(@class, 'progress-text')]//preceding-sibling::div[contains(@class, 'progress-text')]";
        public const string _transWorkflowDetailDiv = "//tr[contains(@class, 'detail-view')]//div[contains(@class, 'progress-text')]//preceding-sibling::div[contains(@class, 'progress-text')]";
        
        /*Add Notes modal*/
        private const string _modalBtnAddNotes = @"//button[@id='btnAddNotes']";
        private const string _modalBtnCancelNotes = @"//button[text()='Cancel']";
        private const string _modalTxtAreaNotes = @"//textarea[contains(@id,'tbNotes')]";
        private const string _modalNotesRequiredValidator = @"//span[contains(@id,'NotesRequiredValidator')]";
        private const string _modalNotesHeader = @"//h1[text()='Add Notes']";

        private const string _modalSaveAsHeaderXPath = @".//h1[contains(@id, 'SaveAsModal')]";
        private const string _modalRenameHeaderXPath = @".//h1[contains(@id, 'RenameModal')]";
        private const string _gridToolbarProfilesButtonXPath = @".//button[@title = 'Profiles' and contains(@id, '_ProfilesMenuLink')]";
        private const string _gridToolbarProfilesOptionXpath = ".//div[contains(@class, 'profiles dropdown-menu')]/button";
        private const string _newProfileNameXPath = "//input[contains(@id,'SaveAsProfileName')]";
        private const string _setAsDefaultProfileCheckboxXPath = "//input[contains(@id,'SaveAsSetDefault')]";
        private const string _setAsDefaultProfileCheckboxLabelXPath = "//label[contains(@for,'SaveAsSetDefault')]";
        private const string _setOverwriteExistingProfileCheckboxXPath = "//input[contains(@id,'SaveAsOverwrite')]";
        private const string _setOverwriteExistingProfileCheckboxLabelXPath = "//label[contains(@for,'SaveAsOverwrite')]";
        private const string _gridToolbarProfilesNamesXpath = @".//div[contains(@class, 'profiles dropdown-menu')]/div[contains(@id, 'Profile')]/h4";
        private const string _errorRequiredNameMessageXPath = ".//span[contains(@id, 'SaveAsProfileName_Error')]";
        private const string _errorRequiredRenameMessageXPath = ".//span[contains(@id, 'RenameProfileName_Error')]";
        private const string _saveAsSaveButtonXPath = "//button[contains(@id,'SaveAsSave')]";
        private const string _saveAsCancelButtonXPath = "//button[contains(@id,'SaveAsCancel')]";
        private const string _rbSelectProfileXPath = @"//input[contains(@id,'ProfilesRadioContainer') and @data-profile-name ='{0}']";
        private const string _rbSelectProfileLabelXPath = @"//label[contains(@for,'ProfilesRadioContainer') and contains(text(), '{0}')]";
        private const string _rbSelectSetDefaultProfileXPath = @"//input[contains(@id,'ProfilesDefaultRadioContainer') and @data-profile-name ='{0}']";
        private const string _rbSelectSetDefaultProfileLabelXPath = @"//label[contains(@for,'ProfilesDefaultRadioContainer') and contains(text(), '{0}')]";

        private const string _profileSetDefaultCancelButtonXPath = "//button[contains(@id,'profileSetDefaultCancel')]";
        private const string _profileSetDefaultSaveButtonXPath = "//button[contains(@id,'profileSetDefaultSave')]";

        private const string _profileResetCancelXPath = "//button[contains(@id, 'profileResetCancel')]";
        private const string _profileResetXPath = "//button[contains(@id, 'profileReset') and text()='Reset']";

        private const string _profileDeleteCancelButtonXPath = "//button[contains(@id, '_profileDeleteCancel')]";
        private const string _deleteProfileNameXPath = "//button[contains(@id, '_profileDelete') and text()='Delete']";

        private const string _profileSetDefaultModalXPath = ".//div[contains(@id, 'profilesSetDefaultModal') and contains(@style,'block')]";
        private const string _profileSaveAsModalXPath = ".//div[contains(@id, 'profilesSaveAsModal') and contains(@style,'block')]";
        private const string _profileResetModalXPath = ".//div[contains(@id, 'profilesResetModal') and contains(@style,'block')]";
        private const string _profileDeleteModalXPath = ".//div[contains(@id, 'profilesDeleteModal') and contains(@style,'block')]";
        private const string _profileRenameModalXPath = ".//div[contains(@id, 'profilesRenameModal') and contains(@style,'block')]";

        private const string _profilesNameXPath = @".//div[contains(@class, 'profiles dropdown-menu')]//div[contains(@id, 'Profile')]/h4[contains(text(), '{0}')]";
        private const string _profileControlsXPath = "//following-sibling::div/button";

        private const string _renameProfileNameXPath = "//input[contains(@id,'RenameProfileName')]";
        private const string _profileRenameCancelButtonXPath = "//button[contains(@id,'profileRenameCancel')]";
        private const string _profileRenameSaveButtonXPath = "//button[contains(@id,'profileRenameSave')]";
        private const string _switchGridButtonXPath = "//input[contains(@id,'SwitchVersion')]";
        #endregion

        #region Page Elements

        private IWebElement _searchCriteriaSearchTerm
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_searchCriteriaSearchTermXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_searchCriteriaSearchTerm element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _searchCriteriaFilterType
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_searchCriteriaFilterTypeXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_searchCriteriaFilterType element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _searchCriteriaTextSearchValue
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_searchCriteriaTextSearchValueXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_searchCriteriaTextSearchValue element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _searchCriteriaListboxSearchValue
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_searchCriteriaListboxSearchValueXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_searchCriteriaListboxSearchValue element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _searchCriteriaResetBtn
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_searchCriteriaResetBtnXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_searchCriteriaResetBtn element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _searchCriteriaAddBtn
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_searchCriteriaAddBtnXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_searchCriteriaAddBtn element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _searchCriteriaCancelBtn
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_searchCriteriaCancelBtnXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_searchCriteriaCancelBtn element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _modalCancelBtn
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_modalCancelBtnXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_modalCancelBtn element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _search
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_searchXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_search element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _submitToWorkflow
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_submitToWorkflowXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_submitToWorkflow element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _outOfPocketBtn
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_outOfPocketBtnXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_outOfPocketBtn element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _transLabel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_transLabelXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_transLabel element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _paging
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_pagingXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_paging element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _dateRangeOption
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_dateRangeOptionXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_dateRangeOption element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _dateFrom
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_dateFromXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_dateFrom element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _dateTo
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_dateToXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_dateTo element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _dateRangePeriod
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_dateRangeDropdownXpath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_dateRangePeriod element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _showSummary
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_showSummaryXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_showSummary element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _reviewedCount
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_reviewedCountXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_reviewedCount element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _txnInEnvelopeCount
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_txnInEnvelopeCountXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_txnInEnvelopeCount element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _reviewedAmount
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_reviewedAmountXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_reviewedAmount element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _approvedCount
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_approvedCountXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_approvedCount element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _approvedAmount
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_approvedAmountXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_approvedAmount element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _approved2Count
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_approved2CountXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_approved2Count element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _approved2Amount
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_approved2AmountXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_approved2Amount element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _totalNumberOfTransactions
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_totalNumberOfTransactionsXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_totalNumberOfTransactions element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _totalTransactionsAmount
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_totalTransactionsAmountXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_totalTransactionsAmount element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _newProfileName
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_newProfileNameXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_newProfileName element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IList<IWebElement> _reviewerCB
        {
            get
            {
                IList<IWebElement> element = Driver.WaitForElements(By.XPath(_reviewerCBXPath)).ToList();

                if (element != null)
                {
                    Settings.EnCompassExtentTest.Info($"_reviewerCB element founded.");
                    return element;
                }
                else
                {
                    Settings.EnCompassExtentTest.Info($"_reviewerCB element not founded.");
                    return null;
                }
            }
        }

        private IList<IWebElement> _approver1CB
        {
            get
            {
                IList<IWebElement> element = Driver.WaitForElements(By.XPath(_approver1CBXPath)).ToList();

                if (element != null)
                {
                    Settings.EnCompassExtentTest.Info($"_approver1CB element founded.");
                    return element;
                }
                else
                {
                    Settings.EnCompassExtentTest.Info($"_approver1CB element not founded.");
                    return null;
                }
            }
        }

        private IList<IWebElement> _approver2CB
        {
            get
            {
                IList<IWebElement> element = Driver.WaitForElements(By.XPath(_approver2CBXPath)).ToList();

                if (element != null)
                {
                    Settings.EnCompassExtentTest.Info($"_approver2CB element founded.");
                    return element;
                }
                else
                {
                    Settings.EnCompassExtentTest.Info($"_approver2CB element not founded.");
                    return null;
                }
            }
        }

        private IList<IWebElement> _inEnvelopeCB
        {
            get
            {
                IList<IWebElement> element = Driver.WaitForElements(By.XPath(_inEnvelopeCBXPath)).ToList();

                if (element != null)
                {
                    Settings.EnCompassExtentTest.Info($"_inEnvelopeCB element founded.");
                    return element;
                }
                else
                {
                    Settings.EnCompassExtentTest.Info($"_inEnvelopeCB element not founded.");
                    return null;
                }
            }
        }

        private IList<IWebElement> _envelopeImage
        {
            get
            {
                bool found = Driver.TryWaitForElementsToBeVisible(By.XPath(_envelopeImageXPath), out IList<IWebElement> elements);
                Settings.EnCompassExtentTest.Info("_envelopeImageXPath is found: " + found);
                IList<IWebElement> element = elements.ToList();
                if (element != null)
                {
                    Settings.EnCompassExtentTest.Info($"_envelopeImage element founded.");
                    return element;
                }
                else
                {
                    Settings.EnCompassExtentTest.Info($"_envelopeImage element not founded.");
                    return null;
                }
            }
        }

        private IWebElement _errorMessage
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_errorMessageXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_errorMessage element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _cardNumber
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_cardNumberXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_cardNumber element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _transactionDetails
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_transactionDetailsXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_transactionDetails element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _manageReceipts
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_manageReceiptsXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_manageReceipts element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _successMessage
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_successMessageXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_successMessage element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _cardNumberDropDownList
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_cardNumberDropDownListXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_cardNumberDropDownList element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _SelectInEnvelopeForAllRowCheckbox
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_SelectInEnvelopeForAllRowCheckboxXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_SelectInEnvelopeForAllRowCheckbox element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _SelectInEnvelopeFirstRowCheckbox
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_SelectInEnvelopeFirstRowCheckboxXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_SelectInEnvelopeFirstRowCheckbox element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _closeButton
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_closeButtonXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_closeButton element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _closeBillingDetails
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_closeBillingDetailsXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_closeBillingDetails element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _SelectInEnvelopeSecondRowCheckbox
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_SelectInEnvelopeSecondRowCheckboxXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_SelectInEnvelopeSecondRowCheckbox element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _btnManageReceipt
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_btnManageReceiptXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_btnManageReceipt element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _btnRejectEnvelope
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_btnRejectEnvelopeXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_btnRejectEnvelope element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _ddlInEnvelopeSearch
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_ddlInEnvelopeSearchXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_ddlInEnvelopeSearch element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _btnReset
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_btnResetXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_btnReset element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _btnPrintEnvelope
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_btnPrintEnvelopeXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_btnPrintEnvelope element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _envelopeRejectReason
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_envelopeRejectReasonXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_envelopeRejectReason element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _splitTransactionBtn
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_splitTransactionBtnXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_splitTransactionBtn element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _workflowRejectModal
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_workflowRejectModalXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_workflowRejectModal element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _workflowRejectConfirmBtn
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_workflowRejectConfirmBtnXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_workflowRejectConfirmBtn element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _rowCardSearchInfo
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_rowCardSearchInfoXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_rowCardSearchInfo element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _rejectTransaction
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_rejectTransactionXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_rejectTransaction element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _selectReviewForAllRowCheckbox
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_selectReviewForAllRowCheckboxXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_selectReviewForAllRowCheckbox element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _selectActionForAllRowCheckbox
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_selectActionForAllRowCheckboxXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_selectActionForAllRowCheckbox element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _selectActionForFirstRowCheckbox
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_selectActionForFirstRowCheckboxXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_selectActionForFirstRowCheckbox element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _selectActionForSecondRowCheckbox
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_selectActionForSecondRowCheckboxXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_selectActionForSecondRowCheckbox element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _selectActionForThirdRowCheckbox
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_selectActionForThirdRowCheckboxXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_selectActionForThirdRowCheckbox element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _selectActionForFourthRowCheckbox
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_selectActionForFourthRowCheckboxXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_selectActionForFourthRowCheckbox element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _selectApprovel1ForAllRowCheckbox
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_selectApprovel1ForAllRowCheckboxXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_selectApprovel1ForAllRowCheckbox element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _saveTransaction
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_saveTransactionXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_saveTransaction element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _btnModalClose
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_btnModalCloseXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_btnModalClose element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _myCardsCheckbox
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_myCardsCheckboxXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_myCardsCheckbox element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _myCardsCheckboxLabel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_myCardsCheckboxLabelXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_myCardsCheckboxLabel element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _hierarchyExplorer
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_hierarchyExplorerXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_hierarchyExplorer element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IList<IWebElement> _allSelectTransactionCheckbox
        {
            get
            {
                IList<IWebElement> element = Driver.WaitForElements(By.XPath(_allSelectTransactionCheckboxXPath)).ToList();

                if (element != null)
                {
                    Settings.EnCompassExtentTest.Info($"_allSelectTransactionCheckbox element founded.");
                    return element;
                }
                else
                {
                    Settings.EnCompassExtentTest.Info($"_allSelectTransactionCheckbox element not founded.");
                    return null;
                }
            }
        }

        private IWebElement _cbFirstTxnRow
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_cbFirstTxnRowXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_cbFirstTxnRow element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _cbSecondTxnRow
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_cbSecondTxnRowXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_cbSecondTxnRow element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _cardName
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_cardNameXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_cardName element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _confirmModalPopUp
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_confirmModalPopUpXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_confirmModalPopUp element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _transactionGrid_SplitYesCheck
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_transactionGridSplitCheck), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_transactionGrid_SplitYesCheck element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _transactionMgmtTitle
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_transactionMgmtTitleXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_transactionMgmtTitle element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _btnClose
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_btnCloseXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_btnClose element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _envelopePrint
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_envelopePrintXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_envelopePrint element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _gridToolbarProfilesButton
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_gridToolbarProfilesButtonXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_gridToolbarProfilesButton element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
            set { }
        }

        private IList<IWebElement> _gridToolbarProfilesOption
        {
            get
            {
                bool found = Driver.TryWaitForElementsToBeVisible(By.XPath(_gridToolbarProfilesOptionXpath), out IList<IWebElement> element);
                Settings.EnCompassExtentTest.Info("_gridToolbarProfilesOption list exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
            set { }
        }

        private IList<IWebElement> _gridToolbarProfilesNames
        {
            get
            {
                bool found = Driver.TryWaitForElementsToBeVisible(By.XPath(_gridToolbarProfilesNamesXpath), out IList<IWebElement> element);
                Settings.EnCompassExtentTest.Info("_gridToolbarProfilesNames list exist is" + found);
                return element;
            }
        }

        private IWebElement _saveAsCancelButton
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_saveAsCancelButtonXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_saveAsCancelButton element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _saveAsSaveButton
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_saveAsSaveButtonXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_saveAsSaveButton element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _setOverwriteExistingProfileCheckbox
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_setOverwriteExistingProfileCheckboxXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_setOverwriteExistingProfileCheckbox element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _setOverwriteExistingProfileCheckboxLabel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_setOverwriteExistingProfileCheckboxLabelXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_setOverwriteExistingProfileCheckboxLabel element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _setAsDefaultProfileCheckboxLabel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_setAsDefaultProfileCheckboxLabelXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_setAsDefaultProfileCheckboxLabel element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _setAsDefaultProfileCheckbox
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_setAsDefaultProfileCheckboxXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_setAsDefaultProfileCheckbox element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _deleteProfileName
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_deleteProfileNameXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_deleteProfileName element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _profileSetDefaultCancelButton
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_profileSetDefaultCancelButtonXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_profileSetDefaultCancelButton element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _profileSetDefaultSaveButton
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_profileSetDefaultSaveButtonXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_profileSetDefaultSaveButton element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _modalSaveAsHeader
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_modalSaveAsHeaderXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_modalSaveAsHeader element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _modalRenameHeader
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_modalRenameHeaderXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_modalRenameHeader element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _profileResetCancel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_profileResetCancelXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_profileResetCancel element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _profileReset
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_profileResetXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_profileReset element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _profileRenameCancelButton
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_profileRenameCancelButtonXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_profileRenameCancelButton element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _renameProfileName
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_renameProfileNameXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_renameProfileName element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _errorRequiredRenameMessage
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_errorRequiredRenameMessageXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_errorRequiredrenameMessage element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _profileRenameSaveButton
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_profileRenameSaveButtonXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_profileRenameSaveButton element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _profileDeleteCancelButton
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_profileDeleteCancelButtonXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_renameProfileName element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        public IWebElement switchGridButton
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_switchGridButtonXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_envelopePrint element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        #endregion

        #region Structures related to Notes

        /*I'd like to leave these structures here instead of the StringKeys class, since this is specific for transactions page. */
        private Dictionary<MODAL_ADD_NOTES_ELEMENTS, string> DicNotesElements = new Dictionary<MODAL_ADD_NOTES_ELEMENTS, string>()
        {
            { MODAL_ADD_NOTES_ELEMENTS.BTN_ADD_NOTES, _modalBtnAddNotes },
            { MODAL_ADD_NOTES_ELEMENTS.BTN_CANCEL_NOTES, _modalBtnCancelNotes },
            { MODAL_ADD_NOTES_ELEMENTS.TXTAREA_NOTES, _modalTxtAreaNotes },
            { MODAL_ADD_NOTES_ELEMENTS.VAL_REQUIRED_NOTES, _modalNotesRequiredValidator },
            { MODAL_ADD_NOTES_ELEMENTS.HEADER, _modalNotesHeader },

        };
        public enum MODAL_ADD_NOTES_ELEMENTS
        {
            BTN_ADD_NOTES,
            BTN_CANCEL_NOTES,
            TXTAREA_NOTES,
            VAL_REQUIRED_NOTES,
            HEADER
        }

        /// <summary>
        /// This methods returns an XPath for the elements of Notes modal listed 'MODAL_ADD_NOTES_ELEMENTS' enum. 
        /// </summary>
        public string GetNotesElementXpath(MODAL_ADD_NOTES_ELEMENTS el)
        {
            return DicNotesElements[el];
        }

        #endregion


        public string GetNotesByRow(string row)
        {
            string notesXPath = $@"//textarea[@id='UserDefined_{int.Parse(row) - 1}']";
            Driver.TryWaitForElement(By.XPath(notesXPath), out IWebElement notesElement);
            return notesElement.Text;
        }

        public bool IsAddNotesEnabled()
        {
            Driver.TryWaitForElementToBeVisible(By.XPath(_btnAddNotes), out IWebElement _btnAddNotesElement);
            bool status = _btnAddNotesElement.Enabled;
            Settings.EnCompassExtentTest.Info($"Add Notes button is enable: {status}");
            return status;
        }

        public bool IsAddNotesVisible()
        {
            Driver.TryWaitForElementToBeVisible(By.XPath(_btnAddNotes), out IWebElement _btnAddNotesElement);
            bool status = _btnAddNotesElement.Displayed;
            Settings.EnCompassExtentTest.Info($"Add Notes button is visible: {status}");
            return status;
        }

        public void AddNotesClick()
        {
            Driver.TryWaitForElementToBeVisible(By.XPath(_btnAddNotes), out IWebElement _btnAddNotesElement);
            Settings.EnCompassExtentTest.Info("Click on Add Notes button on top of the Transactions grid.");
            _btnAddNotesElement.JSClickWithFocus(Driver);
        }

        public void AddNote(string note)
        {
            var txtNote = Driver.FindElement(By.XPath(_modalTxtAreaNotes));
            txtNote.SendKeys(note);
            Settings.EnCompassExtentTest.Info($"Added text note. Content: {note}.");
        }

        //New Method
        public void CheckButtonsReceiptAppears()
        {
            Settings.EnCompassWebDriver.WaitForVisible(By.XPath(_btnManageReceiptXPath));
            ManageReceiptBtn();
            Settings.EnCompassExtentTest.Info("Manage Receiot Button clicked on the transaction page");
            WaitForManageReceiptsModalIFrame();
            ManageReceiptsModalIframe _manageReceiptsModalIframe = GetAddNewProductTypeIframe;
            _manageReceiptsModalIframe.WaitUploadReceiptAppers();
            _manageReceiptsModalIframe.CloseModal();
        }

        //New Method
        public void SearchTransactionForDateRangeOption(string dateRange)
        {
            SetDateRangeOption = dateRange;
            WaitForLoad();
            SetDateFrom = Settings.Scenario["Start Transaction Date"].ToString();
            SetDateTo = Settings.Scenario["End Transaction Date"].ToString();
            Search();
        }


        public string SetDateFrom
        {
            set
            {
                _dateFrom.Clear();
                _dateFrom.ForceDocumentLoadOnSendKeys(value, Driver);
                //Thread.sleep required else this calender control will takes its default value
                Thread.Sleep(1000);
                _dateFrom.SendKeys(Keys.Tab);
                Settings.EnCompassExtentTest.Info("The start date set is" + _dateFrom.Text);
            }
        }
        
        public string SetDateTo
        {
            set
            {
                _dateTo.Clear();
                _dateTo.ForceDocumentLoadOnSendKeys(value, Driver);
                //Thread.sleep required else this calender control will takes its default value
                Thread.Sleep(1000);
                _dateTo.SendKeys(Keys.Tab);
                Settings.EnCompassExtentTest.Info("The stop date set is" + _dateTo.Text);
            }
        }


        public void WaitForFrameToReappear(string _frameId)
        {
            try
            {
                Driver.WaitForAbsence(By.XPath(_frameId), TimeSpan.FromSeconds(2));
                Settings.EnCompassExtentTest.Info("Iframe disappear.");
                Driver.WaitForVisible(By.XPath(_frameId));
                Settings.EnCompassExtentTest.Info("Iframe reappear.");
            }
            catch (Exception)
            {
                Settings.EnCompassExtentTest.Info("Iframe did not disappear.");
            }
        }

        public void BtnModalClose()
        {
            _btnModalClose.JSClickWithFocus(Driver);
        }

        public string GetRowCardSearchInfo()
        {
            return _cardName.GetAttribute("defaultValue");
        }

		public bool IsTransactionManagementTitlePresent
		{
			get { return _transactionMgmtTitle.Displayed; }
		}

        public void SetSearchCardNumber(string cardName)
        {
            Driver.WaitFor(By.XPath(_cardNumberDropDownListXPath));
            var selectElement = new SelectElement(_cardNumberDropDownList);
            IWebElement option = selectElement.Options.Where(o => o.Text.Contains(cardName)).Single();
            selectElement.SelectByText(option.Text);
        }

        public void WaitForManageReceiptsModalIFrame()
        {
            Driver.WaitForVisible(By.XPath(_manageReceiptsModalIframe));
        }

        public void WaitForFinancialCodesTransaction()
        {
            Driver.WaitForVisible(By.XPath(_financialCodesTransactionModalIframe));
        }

        public void SetSearchCriteriaSearchTerm(string whichText)
        {
            Driver.WaitFor(By.XPath(_searchCriteriaSearchTermXPath));
            var selectElement = new SelectElement(_searchCriteriaSearchTerm);
            selectElement.SelectByText(whichText);
        }

        public void SetSearchCriteriaSearchTermByValue(string whichText)
        {
            var selectElement = new SelectElement(_searchCriteriaSearchTerm);
            selectElement.SelectByValue(whichText);
        }

		public void SetSearchFilterSearchTerm(string whichText)
		{
			var selectElement = new SelectElement(_searchCriteriaFilterType);
			selectElement.SelectByText(whichText);
		}

		public string SearchCriteriaTextSearchValue
        {
            set
            {
				_searchCriteriaTextSearchValue.Clear();
                _searchCriteriaTextSearchValue.SendKeys(value);
            }
        }

        public void SetSearchCriteriaListboxSearchValue(string whichText)
        {
            var selectElement = new SelectElement(_searchCriteriaListboxSearchValue);
            selectElement.SelectByText(whichText);
        }

		public void SetEnvelopSearchByValue(string whichText)
		{
			var selectElement = new SelectElement(_ddlInEnvelopeSearch);
			selectElement.SelectByText(whichText);
		}

		public void Reset()
        {
            _searchCriteriaResetBtn.WaitUntilElementIsInteractable();
            _searchCriteriaResetBtn.JSClickWithFocus(Driver);
		}

		public void PressReset()
		{
			_btnReset.JSClickWithFocus(Driver);
		}

		public void PressPrintEnvelope()
		{
			_btnPrintEnvelope.JSClickWithFocus(Driver);
		}        

		public bool VerifyPrintOptions()
		{
            Driver.WaitForVisible(By.XPath(_legendLayoutXPath));

            var portraitElement = Driver.FindElement(By.XPath(_envelopePrintPortraitXPath));
            bool portraitStatus = portraitElement.Enabled;

            var landscapeElement = Driver.FindElement(By.XPath(_envelopePrintLandscapeXPath));
            bool landscapeStatus = landscapeElement.Enabled;

            return portraitStatus && landscapeStatus;
        }

		public void CancelPrintEnvelopeOptions()
		{
            _btnClose.JSClickWithFocus(Driver);
            Settings.EnCompassExtentTest.Info("Cancel print clicked.");
		}

		public void DownloadPrintEnvelopeOptions()
		{
            _envelopePrint.JSClickWithFocus(Driver);
            Settings.EnCompassExtentTest.Info("Download envelope print clicked.");
        }

        public void Add()
        {
            _searchCriteriaAddBtn.WaitUntilElementIsInteractable();
            _searchCriteriaAddBtn.JSClickWithFocus(Driver);
		}

		public void Cancel()
        {
            Driver.WaitFor(By.XPath(_searchCriteriaAddBtnXPath));
			_searchCriteriaCancelBtn.JSClickWithFocus(Driver);
		}
		
        public void ModalCancel()
        {
            _modalCancelBtn.JSClickWithFocus(Driver);
		}
            
		public void Search()
        {
            _search.JSClickWithFocus(Driver);
            Settings.EnCompassExtentTest.Info("Search is clicked on Modal");
            WaitForFormLoadingOverlay();
        }

        private GridControl _cardSearchGrid;
        /// <summary>
        /// Get the Grid element from Transactions page
        /// </summary>
        public GridControl CardSearchGrid
        {
            get
            {
                _cardSearchGrid = (_cardSearchGrid == null) ? new GridControl("content_contents", Driver) : _cardSearchGrid;
                _cardSearchGrid.WaitForGrid();
                return _cardSearchGrid;
            }
        }

        //This new grid should be used just in Grid Testing feature
        //New Grid can be used in specific tests like Table Profiles
        private NewGridControl _cardSearchNewGrid;
        public NewGridControl CardSearchNewGrid
        {
            get
            {                
                _cardSearchNewGrid = (_cardSearchNewGrid == null) ? new NewGridControl("content_contents", Driver, Settings) : _cardSearchNewGrid;
                _cardSearchNewGrid.WaitForGrid();
                return _cardSearchNewGrid;
            }
        }

        public void SetPaging(string size)
        {
            CardSearchGrid.SetPageSize(200);
        }

        public void Save()
        {
            Driver.WaitElementBeClickable(_saveBtn);

            IWebElement _btnSave;
            if (Driver.TryWaitForElement(By.XPath(_saveBtn), out _btnSave))
            {
                _btnSave.JSClickWithFocus(Driver);
                Settings.EnCompassExtentTest.Info("Clicked on Save Button");
                this.WaitForLoad();
                this.AttachOnDemandScreenShot();
            }
        }

        public void SaveNewGrid()
        {
            Driver.WaitElementBeClickable(_saveBtnNewGrid);

            IWebElement _btnSave;
            if (Driver.TryWaitForElement(By.XPath(_saveBtnNewGrid), out _btnSave))
            {
                _btnSave.JSClickWithFocus(Driver);
                Settings.EnCompassExtentTest.Info("Clicked on Save Button");
                this.WaitForLoad();
                this.AttachOnDemandScreenShot();
            }
        }

        public void SubmitToWorkflow()
		{
			_submitToWorkflow.JSClickWithFocus(Driver);
		}

		public void AcceptSubmitForApproval()
		{
			Driver.WaitForVisible(By.XPath(_modalTittleXPath));
			_confirmModalPopUp.Click();
			Driver.WaitForAbsence(By.XPath(_modalTittleXPath));

		}

		public void SubmitToWorkflow(bool accept)
        {
            _submitToWorkflow.JSClickWithFocus(Driver);
            if (accept)
                ConfirmOnModal();
            else
                CancelOnModal();
        }

        public string SetDateRangeOption
		{
			get { return new SelectElement(_dateRangeOption).SelectedOption.Text; }
			set { _dateRangeOption.SetListboxByText(value, SelectTextOptions.StartsWith, Driver, Settings, _dateRangeOptionXPath); }
		}

        public string SetDateRangePeriod
        {
            get
            {
                return new SelectElement(_dateRangePeriod).SelectedOption.Text;
            }
            set
            {
                _dateRangePeriod.SetListboxByText(value, SelectTextOptions.StartsWith, Driver, Settings, _dateRangeDropdownXpath);
            }
        }
        public void SetRange(string whichText)
        {
            Settings.EnCompassWebDriver.WaitFor(By.XPath(_dateRangeDropdownXpath));
            var selectElement = new SelectElement(_dateRangePeriod);
            selectElement.SelectByText(whichText);
        }

        public void SetTransLabel(string whichText)
        {
            _transLabel.SendKeys(whichText); 
        }
        public void ClearTransLabel()
        {
            _transLabel.Clear();
        }

        public void ShowSummary()
        {
            _showSummary.JSClickWithFocus(Driver);
            WaitForLoad();
            Driver.WaitForVisible(By.XPath(_totalNumberOfTransactionsXPath));
        }

        public string ReviewedCount => _reviewedCount.Text;
        public string ApprovedCount => _approvedCount.Text;
        public string Approved2Count => _approved2Count.Text;
        public string TotalTransactions => _totalNumberOfTransactions.Text;
        public string InEnvelopeTransactions => _txnInEnvelopeCount.Text;

        public string ReviewedAmount => _reviewedAmount.Text.Substring(_reviewedAmount.Text.IndexOf(" ")).Trim();
        public string ApprovedAmount => _approvedAmount.Text.Substring(_approvedAmount.Text.IndexOf(" ")).Trim();
        public string Approved2Amount => _approved2Amount.Text.Substring(_approved2Amount.Text.IndexOf(" ")).Trim();
        public string TotalTransactionsAmount => _totalTransactionsAmount.Text.Substring(_totalTransactionsAmount.Text.IndexOf(" ")).Trim();

		public void OutOfPocketBtn()
		{
			_outOfPocketBtn.JSClickWithFocus(Driver);
		}

		public void SetReviewer(bool checkStatus, int index = 0)
		{
            if (index!=0)
			    (_reviewerCB)[index-1].SetCheckboxStateWithLabelJS(Driver, checkStatus);
            else
                (_reviewerCB)[index].SetCheckboxStateWithLabelJS(Driver, checkStatus);
        }

        public bool GetReviewerState(int index = 0)
        {
            return _reviewerCB[index].Selected;
        }

        public void SetApprover1(bool checkStatus, int index = 0)
        {
			if (index > 0)
			{
				(_approver1CB)[index-1].SetCheckboxStateWithLabelJS(Driver, checkStatus);
				Settings.EnCompassExtentTest.Info("Set the approver checkbox for index :" + (index - 1).ToString());
			}
			else
			{
				(_approver1CB)[index].SetCheckboxStateWithLabelJS(Driver, checkStatus);
				Settings.EnCompassExtentTest.Info("Set the approver checkbox for index :" + index.ToString());
			}
        }

        public bool GetApprover1State(int index = 0)
        {
            return _approver1CB[index].Selected;
        }

        public void SetApprover2(bool checkStatus, int index = 0)
        {
            _approver2CB[index].SetCheckboxState(checkStatus);
        }

        public bool GetApprover2State(int index = 0)
        {
            return _approver2CB[index].Selected;
        }

        public void SetInEnvelope(bool checkStatus, int index = 0)
        {
            _inEnvelopeCB[index].SetCheckboxStateWithLabelJS(Driver, checkStatus);
        }

        public bool GetInEnvelopeState(int index = 0)
        {
            Driver.WaitFor(By.XPath(_inEnvelopeCBXPath));
            return _inEnvelopeCB[index].Selected;
        }
        /// <summary>
        /// This methods verifies if the envelope image is displayed at screen for a current row(transaction)
        /// *** PARAMETER ROW MUST BE HIGHER THAN ZERO ***
        /// </summary>
        /// <param name="row"></param>
        /// <returns></returns>
		public bool IsImageEnvelopDisplay(int row)
		{
            if (row <= 0)
                throw new ArgumentOutOfRangeException();
            try
            {
                IWebElement img = Settings.EnCompassWebDriver.FindElement(By.XPath(string.Format(@"(//a[contains(@id, '_EI')][contains(@id, 'contents_t')])[{0}]", row)));

                return img.Displayed;
            }
            catch (NoSuchElementException e)
            {
                return false;
            }

        }

        /// <summary>
        /// This methods verifies if the check image for OOP is displayed at screen for a current row(transaction)
        /// *** PARAMETER ROW MUST BE HIGHER THAN ZERO ***
        /// </summary>
        /// <param name="row"></param>
        /// <returns></returns>
		public bool IsOOPCheckDisplay(int row)
        {
            if (row <= 0)
                throw new ArgumentOutOfRangeException();
            try
            {
                row += 2;
                IWebElement img = Settings.EnCompassWebDriver.FindElement(By.XPath(string.Format(@"//tr[contains(@id,'ctl00_content_contents_t_ctl{0}')]//td/i[contains(@class,'text-success')]", row.ToString("00"))));

                return img.Displayed;
            }
            catch (NoSuchElementException e)
            {
                return false;
            }

        }

		public bool IsImageTitleValid(int index = 0)
        {
            if (_envelopeImage[index].GetAttribute("title").Equals("View Envelope Information", StringComparison.InvariantCultureIgnoreCase))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public void OpenEnvelope(int index = 0)
        {
            Driver.WaitFor(By.XPath(_envelopeImageXPath));
            (_envelopeImage)[index].JSClickWithFocus(Driver);
			Settings.EnCompassExtentTest.Info("Clicked on Envelop Image to open the Transaction Envelop" +
				" for Card with index:" + index.ToString());
		}

        private void WaitForEnvelopeIFrame()
        {
            Driver.WaitForVisible(By.XPath(_envelopeIFrame));
        }

		public bool IsBillingDetailsIFrameDisplayed()
		{
			if(Driver.TryFindElement(By.XPath(_billingDetailsIFrame), out IWebElement element))
			{
				return element.Displayed;
			}
			else
			{
				return false;
			}
		}

        public string EnvelopeInformation_EnvelopeName
        {
            get
            {
                WaitForEnvelopeIFrame();

                using (var ifhelper = new FrameHelper(Driver, By.XPath(_envelopeIFrame)))
                {
                    var element = ifhelper.FindElement(By.XPath(_envelopeNameInIFrame));
                    if (element != null)
                    {
                        return element.Text;
                    }
                    else
                    {
                        throw new Exception($"Could not locate Envelope Name.");
                    }
                }
            }
        }

        public bool UserAdditionalNoteLabelIsPresent(string note)
        {
            string xpath = $@"//label[contains(text(),'{note}')]";
            bool found = Settings.EnCompassWebDriver.TryWaitForElementToBeVisible(By.XPath(xpath), out IWebElement element);
            Settings.EnCompassExtentTest.Info($"_userAdditionalNoteLabel element exist is {found}");
            return found;
        }

        public string EnvelopeInformation_EmployeeFirstName
        {
            get
            {
                WaitForEnvelopeIFrame();

                using (var ifhelper = new FrameHelper(Driver, By.XPath(_envelopeIFrame)))
                {
                    var element = ifhelper.FindElement(By.XPath(_employeeFirstNameInIFrame));
                    if (element != null)
                    {
                        return element.Text;
                    }
                    else
                    {
                        throw new Exception($"Could not locate Employee First Name.");
                    }
                }
            }
        }

        public string EnvelopeInformation_EmployeeLastName
        {
            get
            {
                WaitForEnvelopeIFrame();

                using (var ifhelper = new FrameHelper(Driver, By.XPath(_envelopeIFrame)))
                {
                    var element = ifhelper.FindElement(By.XPath(_employeeLastNameInIFrame));
                    if (element != null)
                    {
                        return element.Text;
                    }
                    else
                    {
                        throw new Exception($"Could not locate Employee Last Name.");
                    }
                }
            }
        }

        public string EnvelopeInformation_TransactionsInEnvelope
        {
            get
            {
                WaitForEnvelopeIFrame();

                using (var ifhelper = new FrameHelper(Driver, By.XPath(_envelopeIFrame)))
                {
                    var element = ifhelper.FindElement(By.XPath(_transactionsInEnvelopeInIFrame));
                    if (element != null)
                    {
                        return element.Text;
                    }
                    else
                    {
                        throw new Exception($"Could not locate Transactions In Envelope.");
                    }
                }
            }
        }

        public string EnvelopeInformation_EnvelopeAmount
        {
            get
            {
                WaitForEnvelopeIFrame();

                using (var ifhelper = new FrameHelper(Driver, By.XPath(_envelopeIFrame)))
                {
                    var element = ifhelper.FindElement(By.XPath(_envelopeAmountInIFrame));
                    if (element != null)
                    {
                        return element.Text;
                    }
                    else
                    {
                        throw new Exception($"Could not locate Envelope Amount.");
                    }
                }
            }
        }

        public void EnvelopeInformation_Close()
        {
            WaitForEnvelopeIFrame();

            using (var ifhelper = new FrameHelper(Driver, By.XPath(_envelopeIFrame)))
            {
                var element = ifhelper.FindElement(By.XPath(_closeBtnInIFrame));
                if (element != null)
                {
                    element.JSClickWithFocus(Driver);
					Settings.EnCompassExtentTest.Info("Clicked on Close button on Transaction Envelop Iframe");
                }
                else
                {
                    throw new Exception($"Could not locate Envelope Close button.");
                }
            }
        }

        public void VerifyIfGridAppears()
        {
            Settings.EnCompassWebDriver.WaitForVisible(By.XPath("//div[contains(@id, 'content_contents')]//tr[contains(@class,'gridHeader')]"));
        }

        public string ErrorMessage
        {
            get
            {
                return _errorMessage.Text;
            }
        }

        public string CardNumber
        {
            get
            {
                return Settings.EnCompassWebDriver.WaitForVisible(By.XPath("//input[contains(@id,'litAccount')]")).GetAttribute("value");
            }
        }

        public void SetFinancialCodesForTransaction(string financialCode1, string financialCode2, int index)
        {
            index--;
            string xpathFinancialCode1 = $"//input[contains(@id,'ctl0{index + 3}_F_0')]//preceding-sibling::div";
            string xpathFinancialCode2 = $"//input[contains(@id,'ctl0{index + 3}_F_1')]//preceding-sibling::div";
            Driver.FindElement(By.XPath(xpathFinancialCode1)).BootstrapClick();
            VerifyAndSelectFinancialCodeAvailable(financialCode1, financialCode1);
            Driver.FindElement(By.XPath(xpathFinancialCode2)).BootstrapClick();
            VerifyAndSelectFinancialCodeAvailable(financialCode2, financialCode2);
            this.AttachOnDemandScreenShot();
        }

        public void CheckFinancialCodeDescription(string financialCode1, string financialCode2, int index)
        {
            index--;
            string xpathFinancialCode1 = $"//button[contains(@id,'ctl0{index + 3}_F_0')]";
            string xpathFinancialCode2 = $"//button[contains(@id,'ctl0{index + 3}_F_1')]";
            Check.That(Driver.FindElement(By.XPath(xpathFinancialCode1)).GetAttribute("data-popover-onshow").Contains(financialCode1)).IsTrue();
            Settings.EnCompassExtentTest.Info("Description of financial code 1 checked with success");
            Check.That(Driver.FindElement(By.XPath(xpathFinancialCode2)).GetAttribute("data-popover-onshow").Contains(financialCode2)).IsTrue();
            Settings.EnCompassExtentTest.Info("Description of financial code 2 checked with success");
        }

        //  Is not possible to get the xpath with another way, there is not indicator xpath to the CC and GL textfield, as in the automation flow
        //we used a default data mass this should be not a problem, follow below the textfield xpath.
        //< input id = "ctl00_contents_t_ctl03_F_0" name = "ctl00$contents$t$ctl03$F_0" value = "" maxlength = "150" size = "15" onclick = "dontStealFocus()" onchange = "setDirtyTextbox(this);" >
        //< input id = "ctl00_contents_t_ctl03_F_1" name = "ctl00$contents$t$ctl03$F_1" value = "" maxlength = "150" size = "15" onclick = "dontStealFocus()" onchange = "setDirtyTextbox(this);" >
        //< input id = "ctl00_contents_t_ctl04_F_0" name = "ctl00$contents$t$ctl04$F_0" value = "" maxlength = "150" size = "15" onclick = "dontStealFocus()" onchange = "setDirtyTextbox(this);" >
        //< input id = "ctl00_contents_t_ctl04_F_1" name = "ctl00$contents$t$ctl04$F_1" value = "" maxlength = "150" size = "15" onclick = "dontStealFocus()" onchange = "setDirtyTextbox(this);" >
        //Same thing happenns with the checkbox for each transaction that the automation created, following the same pattern.
        public void SetGLForTransaction(string financialCode, int index)
        {
            index--;
            string xpath = $"//input[contains(@id,'FCV01_{index}') or contains(@id,'ctl0{index + 3}_F_0')]";
            var element = Driver.FindElement(By.XPath(xpath));
            element.ForceDocumentLoadOnSendKeys(financialCode, Settings.EnCompassWebDriver);
        }

        /// <summary>
        /// Set Financial Code values for Transactions
        /// </summary>
        /// <param name="financialCode"></param>
        /// <param name="index"></param>
        public void SetFinCodeForTransaction(string financialCode, int index)
        {
            if (financialCode.Contains("GL"))
            {
                var Element = Driver.FindElement(By.XPath($"//input[contains(@id,'FCV01_{index}') or contains(@id,'ctl0{index + 3}_F_0')]"));
                Element.ForceDocumentLoadOnSendKeys(financialCode, Settings.EnCompassWebDriver);
            }
            else
            {
                var Element = Driver.FindElement(By.XPath($"//input[contains(@id,'FCV02_{index}') or contains(@id,'ctl0{index + 3}_F_1')]"));
                Element.ForceDocumentLoadOnSendKeys(financialCode, Settings.EnCompassWebDriver);
            }
        }

        public void ClearFinancialCodesGLCC()
        {
            var ElementGL = Driver.FindElement(By.XPath("//input[contains(@id,'ctl03_F_0')]"));
            ElementGL.Clear();
            var ElementCC = Driver.FindElement(By.XPath("//input[contains(@id,'ctl03_F_1')]"));
            ElementCC.Clear();
        }

        public void SetCCForTransaction(string financialCode, int index)
        {
            index--;
            string xpath = $"//input[contains(@id,'FCV02_{index}') or contains(@id,'ctl0{index + 3}_F_1')]";
            var element = Driver.FindElement(By.XPath(xpath));
            element.ForceDocumentLoadOnSendKeys(financialCode, Settings.EnCompassWebDriver);
        }

        public void SetNote(string note, int row)
		{
			var Element = Driver.FindElement(By.XPath($".//label[text() = 'Notes']//following-sibling::textarea[contains(@id, 'ctl0{row + 3}') or contains(@id,'UserDefined_{row}')]"));
            Element.ForceDocumentLoadOnSendKeys(note, Settings.EnCompassWebDriver);
		}

        public string GetGLForTransaction(int row)
        {
            var Element = Driver.FindElement(By.XPath($"//input[contains(@id,'ctl0{row + 2}_F_0')]"));
            return Element.GetAttribute("value");

        }

        public string GetCCForTransaction(int row)
        {
            var Element = Driver.FindElement(By.XPath($"//input[contains(@id,'ctl0{row + 2}_F_1')]"));
            return Element.GetAttribute("value");

        }

        public void SetGLSampleNoteForFirstandSecondTransaction()
        {
            
            Settings.EnCompassWebDriver.WaitForVisible(By.XPath("//input[contains(@id,'ctl03_F_0')]")).SendKeys("GL Desc Sample");
            Settings.EnCompassWebDriver.WaitForVisible(By.XPath("//input[contains(@id,'ctl04_F_0')]")).SendKeys("GL Desc Sample");
        }

        public void SetCCNoteForFirstandSecondTransaction()
        {
            Settings.EnCompassWebDriver.WaitForVisible(By.XPath("//input[contains(@id,'ctl03_F_1')]")).SendKeys("CC Desc Sample");
            Settings.EnCompassWebDriver.WaitForVisible(By.XPath("//input[contains(@id,'ctl04_F_1')]")).SendKeys("CC Desc Sample");
        }

		public void AssignFinancialCode(string financialCodeName)

		{
            var Element = Driver.FindElement(By.XPath($"//*[contains(@id,'ctl03')]//*[text() = '{financialCodeName}']//following-sibling::div/div/button"));
			Element.JSClickWithFocus(Driver);
            WaitForFormLoadingOverlay();
		}

		public void AssignFinancialCodeTxt(string financialCodeName, string code)
		{
			var Element = Driver.FindElement(By.XPath($"//*[contains(@id,'ctl03')]//*[text() = '{financialCodeName}']//following-sibling::div/input"));
			Element.ForceDocumentLoadOnSendKeys(code, Settings.EnCompassWebDriver);
		}

        public void SelectFirstRowCheckbox()
        {
            //Settings.EnCompassWebDriver.WaitForVisible(By.XPath("//input[contains(@id,'ctl03_STCB')]")).JSClickWithFocus(Driver);
            _cbFirstTxnRow.SetCheckboxStateWithLabel(null, true);
        }

        public void SelectSecondRowCheckbox()
        {
            //Settings.EnCompassWebDriver.WaitForVisible(By.XPath("//input[contains(@id,'ctl04_STCB')]")).JSClickWithFocus(Driver);
            ScrollToXPATH("//input[contains(@id,'ctl04_STCB')]");
            _cbSecondTxnRow.SetCheckboxStateWithLabel(null, true);
        }

        public void SelectThirdRowCheckbox()
        {
            Settings.EnCompassWebDriver.WaitForVisible(By.XPath("//input[contains(@id,'ctl05_STCB')]")).JSClickWithFocus(Driver);
        }

        public void SelectFourthRowCheckbox()
        {
            Settings.EnCompassWebDriver.WaitForVisible(By.XPath("//input[contains(@id,'ctl06_STCB')]")).JSClickWithFocus(Driver);
        }

        public void ClickTransactionReceipts()
        {
            Settings.EnCompassWebDriver.WaitForVisible(By.XPath("//a[contains(@id,'rowButtons_actionLink4')]"));
            _manageReceipts.JSClickWithFocus(Driver);
        }

		public bool VerifyCheckedReviewAndApproveOnFirstTransaction()
		{
			return Settings.EnCompassWebDriver.FindElement(By.XPath(@"//input[contains(@id,'ctl03_R')]")).GetAttribute("checked").Equals("true") && Settings.EnCompassWebDriver.FindElement(By.XPath(@"//input[contains(@id,'ctl03_A')]")).GetAttribute("checked").Equals("true") ? true : false;
		}

		public void VerifyCheckedReviewOnFirstTransaction()
        {
            Settings.EnCompassWebDriver.WaitFor(By.XPath("//input[contains(@id,'ctl03_R')]"));
            Settings.EnCompassWebDriver.WaitFor(By.XPath("//input[contains(@id,'ctl03_R')][@checked='checked']"));
        }

		
		//tr[contains(@id,'ctl04')]//td[14]/i[contains(@class,'check')]
		/// <summary>
		/// There is no way to use grids in Transaction Table as each Row is a table itself and using specific index with td renders
		/// the xpath brittle. Thus using position as an approximation hoping the Receipts checkbox would end up between 10-20 index count
		/// and expecting it to be checked, thus the 'Yes' text check
		/// </summary>
		public void VerifyReceiptCheckedOnSecondTransaction()
        {            
            Settings.EnCompassWebDriver.WaitForVisible(By.XPath("//tr[contains(@id,'ctl04')]//td[position() >= 10 and not(position() > 20)][contains(text(),'Yes')]"));
        }

        public void Close()
        {
            _closeButton.JSClickWithFocus(Driver);
        }

        public void CloseBillingDetails()
        {
            _closeBillingDetails.JSClickWithFocus(Driver);
        }

        public void ManageReceiptBtn()
        {
            _btnManageReceipt.JSClickWithFocus(Driver);
        }

		public string GetSuccessMsg
        {
            get { return _successMessage.Text; }
        }

        public bool IsSuccessMsgPresent()
        {
            return Driver.TryWaitForElementToBeVisible(By.XPath(_successMessageXPath), out IWebElement element);
        }

        public void RejectEnvelope()
        {
            _btnRejectEnvelope.JSClickWithFocus(Driver);
        }

        public string EnvelopeRejectReason
        {
            get {
                return Settings.EnCompassWebDriver.WaitForVisible(By.XPath("//div[@id='envelopeRejectDisplayModal']//textarea[contains(@id,'RejectReason')]")).Text;
                }
            set
                {
                Settings.EnCompassWebDriver.WaitForVisible(By.XPath("//div[@id='envelopeRejectDisplayModal']//textarea[contains(@id,'RejectReason')]")).ForceDocumentLoadOnSendKeys(value, Settings.EnCompassWebDriver);
                }
        }

        public void WorkflowRejectConfirmBtn()
        {
            _workflowRejectConfirmBtn.JSClickWithFocus(Driver);
        }

		public string WorkflowRejectReason
		{
			get
			{
                _workflowRejectModal.WaitUntilElementIsInteractable();
                return _workflowRejectModal.Text;
			}
			set
			{
                Settings.EnCompassWebDriver.WaitForVisible(By.XPath("//div[contains(@id,'WorkflowRejectModalForm')]//textarea[contains(@id,'RejectReason')]")).ForceDocumentLoadOnSendKeys(value, Settings.EnCompassWebDriver);

            }
		}

		public void RejectConfirm()
        {
            Settings.EnCompassWebDriver.WaitForVisible(By.XPath("//div[@id='envelopeRejectDisplayModal_footer']//input[contains(@id,'cmdRejectButton')]")).JSClickWithFocus(Driver); ;
        }

        public ManageReceiptsModalIframe GetAddNewProductTypeIframe
        {
            get
            {
                using (FrameHelper helper = new FrameHelper(Settings.EnCompassWebDriver, By.XPath(_manageReceiptsModalIframe))) 
                {
                    return new ManageReceiptsModalIframe(helper, Settings);
                }
            }
        }

		public BillingDetailsIFrame GetBillingDetailsIFrame
		{
			get
			{
				using (FrameHelper helper = new FrameHelper(Settings.EnCompassWebDriver, By.XPath(_billingDetailsIFrame)))
				{
					return new BillingDetailsIFrame(helper, Settings);
				}
			}
		}

		/// <summary>
		/// The IFrame Helper class that would check information in the Billing Details IFrame modal popup.
		/// </summary>
		public class BillingDetailsIFrame: TransactionsTopActions
		{
			FrameHelper _helper;
			public BillingDetailsIFrame(FrameHelper helper, GlobalSettings settings) : base(settings)
			{ _helper = helper; }

			public string GetIFrameElementText(string xPath)
			{
				IWebElement element = _helper.FindElement(By.XPath(xPath));

				if (element != null)
				{ 
					return element.FindElement(By.XPath(@"strong")).Text;
				}
				else
				{
					return "";
				}
			}

			public void CloseBillingDetailsIFrame()
			{
                Driver.TryWaitForElement(By.XPath("//input[contains(@id,'footerContent_btnClose')]"), out IWebElement element);
				if (element != null)
				{
					element.JSClickWithFocus(Driver);
				}
			}
		}


		/// <summary>
		/// Adding a seperate class for Each Iframe embedded within this Page Object model
		/// </summary>
		public class ManageReceiptsModalIframe : TransactionsTopActions
        {
            FrameHelper _helper;
            public const string _browseFile = @"//input[contains(@id,'file0')]";
            public const string _btnUpload = @"//input[contains(@id,'buttonUpload') or contains(@id,'btnUpload')]";
            public const string _btnCloseModal = @"//input[contains(@id,'footerContent_btnClose')]";
            public const string _actionBtnDownloadReceipt = @"//a[contains(@id,'actionLink') and text()='Download']";
            public const string _firstUploadedReceiptRow = @"//tr[contains(@id,'dgUploadedReceipts_ctl03')]";
            public const string _actionBtnDeleteReceipt = @"//a[contains(@id,'actionLink') and text()='Delete Receipt']";

            public void UploadReceiptSuccessfully(string fileAbsolutePath)
            {
                var UploadPathField = _helper.FindElement(By.XPath(_browseFile));                
                UploadPathField.SendKeys(fileAbsolutePath);
                PressUpload();
                Settings.EnCompassWebDriver.WaitForVisible(By.XPath(".//div[contains(@id,'amSuccessMessage')]"));
                this.RefreshModel();
            }

            //New Method
            public void WaitUploadReceiptAppers()
            {
                _helper.FindElement(By.XPath(_btnUpload));
                Settings.EnCompassWebDriver.WaitForVisible(By.XPath("//input[contains(@id,'btnUpload')]"));
            }

            public void PressUpload()
            {
                _helper.FindElement(By.XPath(_btnUpload)).WaitUntilElementIsInteractable();
                _helper.FindElement(By.XPath(_btnUpload)).JSClickWithFocus(Driver);
            }

            public void CloseModal()
            {
                if (_helper.FindElement(By.XPath(_btnCloseModal)) is null)
                {
                    Settings.EnCompassExtentTest.Fail("Cannot Find Close Button on Modal");
                    this.AttachOnDemandScreenShot();
                    throw new Exception("Cannot Find Close Button on Modal");
                }
                    
                _helper.FindElement(By.XPath(_btnCloseModal)).WaitUntilElementIsInteractable();
                _helper.FindElement(By.XPath(_btnCloseModal)).JSClickWithFocus(Driver);
                Settings.EnCompassExtentTest.Info("Element clicked");
                Driver.SwitchTo().DefaultContent();
                Driver.WaitForAbsence(By.XPath(_btnCloseModal));
                Settings.EnCompassExtentTest.Info("Absence is over");
                
            }

            public void CloseModal(By xpath)
            {
                _helper.FindElement(xpath).JSClickWithFocus(Driver);
                
            }

            private GridControl _uploadedReceiptsGrid;
            public GridControl UploadedReceiptsGrid
            {
                get
                {
                    _uploadedReceiptsGrid = new GridControl("UploadedReceipts", Driver);
                    _uploadedReceiptsGrid.WaitForGrid();
                    return _uploadedReceiptsGrid;
                }
            }

            public void SelectFirstRowAndDownloadReceipt()
            {
                _helper.FindElement(By.XPath(_firstUploadedReceiptRow)).JSClickWithFocus(Driver);
                _helper.FindElement(By.XPath(_actionBtnDownloadReceipt)).JSClickWithFocus(Driver);

            }
			
            public void SelectFirstRowAndDeleteReceipt()
            {
                _helper.FindElement(By.XPath(_firstUploadedReceiptRow)).JSClickWithFocus(Driver);
                DeleteReceipt();

            }

            public void DeleteReceipt()
            {
                _helper.FindElement(By.XPath(_firstUploadedReceiptRow)).JSClickWithFocus(Driver);
                _helper.FindElement(By.XPath(_actionBtnDeleteReceipt)).JSClickWithFocus(Driver);
                ConfirmOnModal();
            }

            public ManageReceiptsModalIframe(FrameHelper helper, GlobalSettings settings) : base(settings)
            { _helper = helper; }
        }

        public const string _iframeFinancialCodes = @"//iframe[contains(@src,'AccountingFieldLookup')]";

        public void VerifyAndSelectFinancialCodeAvailable(string code, string description)
        {
            string mainWindow = Driver.CurrentWindowHandle; //get the ID of main Window

            using (FrameHelper helper = new FrameHelper(Settings.EnCompassWebDriver, By.XPath(_iframeFinancialCodes)))
            {
                Check.That(helper.FindElementStrictlyOnIframe(By.XPath(@"//*[contains(@id,'etCodeValues')]/tbody/tr/td[2]")).GetAttribute("textContent").Equals(code)).IsTrue();
                Settings.EnCompassExtentTest.Info("Code checked with success");
                Check.That(helper.FindElementStrictlyOnIframe(By.XPath(@"//*[contains(@id,'etCodeValues')]/tbody/tr/td[3]")).GetAttribute("textContent").Equals(description)).IsTrue();
                Settings.EnCompassExtentTest.Info("Description of financial code checked with success");
                this.AttachOnDemandScreenShot();
                helper.FindElementStrictlyOnIframe(By.XPath(@"//*[contains(@id,'etCodeValues')]/tbody/tr/td[1]/div/button")).JSClickWithFocus(Driver);
                Settings.EnCompassExtentTest.Info("Clicked on cancel button");
                Driver.SwitchTo().Window(mainWindow);
            }
        }

        public void SelectFinancialCodeAvailables()
		{
			string mainWindow = Driver.CurrentWindowHandle; //get the ID of main Window

            using (FrameHelper helper = new FrameHelper(Settings.EnCompassWebDriver,By.XPath(_iframeFinancialCodes)))
            {
                helper.FindElementStrictlyOnIframe(By.XPath(@"//*[contains(@id,'etCodeValues')]/tbody/tr/td[1]/div/button")).JSClickWithFocus(Driver);
                Driver.SwitchTo().Window(mainWindow);
            }
        }

        public void SelectFinancialCodeAvailables(string profileName)
        {
            string mainWindow = Driver.CurrentWindowHandle; //get the ID of main Window

            //The assign between transaction and financial code open a new window
            //Created new method to Find Elements in different pages
            using (FrameHelper helper = new FrameHelper(Settings.EnCompassWebDriver, By.XPath(_financialCodesTransactionModalIframe)) )
            {
                helper.FindElement(By.XPath("//select[contains(@id,'dllProfile')]")).SetListboxByText(profileName);
                
                Search();

                helper.FindElement(By.XPath("//*[contains(@id,'etCodeValues')]/tbody/tr/td[1]/div/button")).JSClickWithFocus(Driver);
                Settings.EnCompassExtentTest.Debug("Clicked on Fin Code on modal");
                helper.Dispose();
            }
        }

        //Select the financial code without financial code and check the error messagem
        public void SelectProfileWithOutFinancialCodeAvailables(string profileName, string errorMessage)
        {
            string mainWindow = Driver.CurrentWindowHandle; //get the ID of main Window

            using (FrameHelper helper = new FrameHelper(Settings.EnCompassWebDriver))
            {
                helper.FindElement(By.XPath("//select[contains(@id,'dllProfile')]")).SetListboxByText(profileName);

                string financialCodesMessage = helper.FindElement(By.XPath("//tr[@class = 'no-records-found']/td")).Text;
                Check.That(financialCodesMessage).Contains(errorMessage);

                this.RefreshModel();
                ModalCancel();
                Driver.SwitchTo().Window(mainWindow);
            }
        }

        //Set Override checkbox and Select the financial code
        public void SetOverrideAndSelectFinancialCodeAvailables(string profileName)
		{
			string mainWindow = Driver.CurrentWindowHandle; //get the ID of main Window

            //The assign between transaction and financial code open a new window
            //Created new method to Find Elements in different pages
            using (WindowHelper helper = new WindowHelper(Settings.EnCompassWebDriver))
            {
                helper.FindElementOnAllOpenWindows(By.XPath("//*[contains(@id,'dllProfile')]")).SetListboxByText(profileName);
                string status = helper.FindElementOnAllOpenWindows(By.XPath("//*[contains(@id,'chkProfileManagerOverride')]")).GetAttribute("checked");
                if (String.IsNullOrEmpty(status))
                {
                    helper.FindElementOnAllOpenWindows(By.XPath("//*[contains(@id,'chkProfileManagerOverride')]")).JSClickWithFocus(Driver);
                }
                helper.FindElementOnAllOpenWindows(By.XPath("//*[contains(@id,'etCodeValues')]/tbody/tr/td[1]/div/button")).JSClickWithFocus(Driver);
                Driver.SwitchTo().Window(mainWindow);
            }
        }

        //Set the Profile Name and select the financial code and doesn't set Override checkbox
        public void SetProfileSelectFinancialCodeAvailables(string profileName)
		{
			string mainWindow = Driver.CurrentWindowHandle; //get the ID of main Window

            //The assign between transaction and financial code open a new window
            //Created new method to Find Elements in different pages
            using (WindowHelper helper = new WindowHelper(Settings.EnCompassWebDriver))
            {
                helper.FindElementOnAllOpenWindows(By.XPath("//*[contains(@id,'dllProfile')]")).SetListboxByText(profileName);
                helper.FindElementOnAllOpenWindows(By.XPath("//*[contains(@id,'etCodeValues')]/tbody/tr/td[1]/div/button")).JSClickWithFocus(Driver);

                Driver.SwitchTo().Window(mainWindow);
            }
        }


        /// <summary>
        /// This method fills all transactions fields(financial code and notes)
        /// </summary>
        public void FillAllGridFields()
        {
            foreach (var input in Settings.EnCompassWebDriver.FindElements(By.XPath(@"//table[contains(@id,'contents_t')]//div[contains(@class,'form-group')]//*[(self::input or self::textarea) and not(@type='checkbox') and not(@type='hidden') and not(@type='button') and not(@readonly) and not(@maxlength<150)]")))
            {
                IWebElement label = null;

                if (input.TagName.Equals("input"))
                {
                    label = input.FindElement(By.XPath(@"./parent::div/preceding-sibling::label"));
                    input.Clear();
                    input.SendKeys(label.Text.Replace("(optional)", string.Empty).Trim() + "1");
                }
                else
                {
                    label = input.FindElement(By.XPath(@".//preceding-sibling::label"));
                    input.Clear();
                    input.SendKeys(label.Text.Replace("(optional)", string.Empty).Trim());
                }
            }
        }

        public void CheckTransactionsState(string state)
        {
            foreach (var input in Settings.EnCompassWebDriver.FindElements(By.XPath(@"//table[contains(@id,'contents_t')]//div[contains(@class,'form-group')]//*[(self::input or self::textarea) and not(@type='checkbox') and not(@type='hidden') and not(@type='button') and not(@maxlength<150)]")))
            {
                if(input.TagName.Equals("input"))
                    Check.That(input.GetAttribute(state).Equals("true")).IsTrue();
                else
                    Check.That(input.GetAttribute("disabled").Equals("true")).IsTrue();
            }
        }

        public FinancialCodeTransactionModal GetFinancialCodeTransactionIframe
        {
            get
            {
                using (FrameHelper helper = new FrameHelper(Settings.EnCompassWebDriver, By.XPath(_financialCodesTransactionModalIframe)))
                {
                    return new FinancialCodeTransactionModal(helper, Settings);
                }
            }
        }

        public class FinancialCodeTransactionModal : TransactionsTopActions
        {
            FrameHelper _helper;
            public const string _selectProfileInModal = "//*[contains(@id,'dllProfile')]";
            public const string _cancelButtonInModal = "//input[contains(@id,'btnClose')";
			public const string _includeAllProfileCheckbox = "//input[contains(@id,'chkProfileManagerOverride')]";
			public const string _includeAllProfileCheckboxLabel = "//label[contains(@for,'chkProfileManagerOverride')]";
            public const string _errorMessageProfile = "//*[contains(@id,'ValidationSummary')]"; 
            public const string _overrideBox = "//*[contains(@id,'etCodeValues')]/tbody/tr/td[1]/div/button";

            public void SelectProfileAndCheckMessage(string profileName, string errorMessage)
            {
                _helper.FindElement(By.XPath("//span[@class='sr-only' and text()='Loading...']")).WaitUntilElementIsInteractable();
                var selectElement = new SelectElement(_helper.FindElement(By.XPath(_selectProfileInModal)));
                selectElement.SelectByText(profileName);
                Check.That(_helper.FindElement(By.XPath(_errorMessageProfile)).Text.Contains(errorMessage));
                ButtonCancel();
            }

            public void SelectProfileWithFinancialCodeAvailables(string profileName)
            {
                _helper.FindElement(By.XPath("//span[@class='sr-only' and text()='Loading...']")).WaitUntilElementIsInteractable();
                var selectElement = new SelectElement(_helper.FindElement(By.XPath(_selectProfileInModal)));
                selectElement.SelectByText(profileName);
                WaitForFormLoadingOverlay();
				_helper.FindElement(By.XPath("//span[@class='sr-only' and text()='Loading...']")).WaitUntilElementIsInteractable();
				_helper.FindElement(By.XPath(_overrideBox)).JSClickWithFocus(Driver);
                _helper.Dispose();
                WaitForFormLoadingOverlay();
            }

            public void SetFinancialCodeAvailables(string profileName)
            {
                _helper.FindElement(By.XPath("//span[@class='sr-only' and text()='Loading...']")).WaitUntilElementIsInteractable();
                var selectElement = new SelectElement(_helper.FindElement(By.XPath(_selectProfileInModal)));
                selectElement.SelectByText(profileName);
				_helper.FindElement(By.XPath("//span[@class='sr-only' and text()='Loading...']")).WaitUntilElementIsInteractable();
				_helper.FindElement(By.XPath(_includeAllProfileCheckboxLabel)).JSClickWithFocus(Driver);
				ButtonCancel();        
            }

            public void ButtonCancel()
            {
                _helper.FindElement(By.XPath(_cancelButtonInModal)).JSClickWithFocus(Driver);
            }

            public FinancialCodeTransactionModal(FrameHelper helper, GlobalSettings settings) : base(settings)
            { _helper = helper; }
        }

        public void SetSelectReviewForAllState(bool state)
        {
            Driver.ScrollToXPATH("//input[contains(@id,'CheckboxColumnBoxActual_11') and @type='checkbox']");
            _selectReviewForAllRowCheckbox.SetCheckboxStateWithLabel(null, state);
        }

        public void SetSelectApproval1ForAllState(bool state)
        {
            Driver.ScrollToXPATH("//input[contains(@id,'CheckboxColumnBoxActual_12') and @type='checkbox']");
            _selectApprovel1ForAllRowCheckbox.SetCheckboxStateWithLabel(null, state);
        }

        public void setSelectActionForAllState(bool state)
        {
            _selectActionForAllRowCheckbox.SetCheckboxStateWithLabelJS(Driver, state);
            Settings.EnCompassExtentTest.Info("Selected Action For All State : "+state);

        }

        public void setSelectActionForFirstTxnRow(bool state)
        {
            _selectActionForFirstRowCheckbox.SetCheckboxStateWithLabel(null, state);
        }

        public void setSelectActionForSecondTxnRow(bool state)
        {
            _selectActionForSecondRowCheckbox.SetCheckboxStateWithLabel(null, state);
        }

        public void setSelectActionForThirdTxnRow(bool state)
        {
            _selectActionForThirdRowCheckbox.SetCheckboxStateWithLabel(null, state);
        }

        public void setSelectActionForFourthTxnRow(bool state)
        {
            _selectActionForFourthRowCheckbox.SetCheckboxStateWithLabel(null, state);
        }

        public void SelectTransactions(List<int> transactions, bool state)
        {
            foreach (int transaction in transactions)
            {
                IWebElement chkTransaction = Driver.FindElement(By.XPath(string.Format(@"(//input[@type='checkbox' and contains(@id,'STCB')])[{0}]", transaction)));
                chkTransaction.SetCheckboxState(state);
            }
        }

        public void CopyFinancialCodes()
        {
            string copyFinancialCodesXpath = "//a[contains(@id,'rowButtons_actionLink5')]";
            IWebElement copyFinancialCodes = Driver.FindElement(By.XPath(copyFinancialCodesXpath));
            //Mobile specific change
            copyFinancialCodes.JSClickWithFocus(Driver, copyFinancialCodesXpath,Settings);
        }

        public void CopyNotes()
        {
            string copyNotesXpath = "//a[contains(@id,'rowButtons_actionLink6')]";
            IWebElement copyNotes = Driver.FindElement(By.XPath(copyNotesXpath));
            //Mobile specific change
            copyNotes.JSClickWithFocus(Driver, copyNotesXpath, Settings);
        }

        public void ClearFinancialCodes()
        {
            string clearFinancialCodesXpath = "//a[contains(@id,'rowButtons_actionLink6')]";
            IWebElement clearFinancialCodes = Driver.FindElement(By.XPath(clearFinancialCodesXpath));
            //Mobile specific change
            clearFinancialCodes.JSClickWithFocus(Driver, clearFinancialCodesXpath,Settings);
        }

        public void ClearNotes()
        {
            string clearNotesXpath = "//a[contains(@id,'rowButtons_actionLink7')]";
            IWebElement clearNotes = Driver.FindElement(By.XPath(clearNotesXpath));
            //Mobile specific change
            clearNotes.JSClickWithFocus(Driver, clearNotesXpath, Settings);
        }

        public string GetNoteFirstTransaction() {
            var Element = Driver.FindElement(By.XPath("//textarea[contains(@id,'ctl03_NT')]"));
            return Element.GetAttribute("value");
        }

        public string GetNoteSecondTransaction()
        {
            var Element = Driver.FindElement(By.XPath("//textarea[contains(@id,'ctl04_NT')]"));
            return Element.GetAttribute("value");
        }

        public void setMyCardsCheckBox(bool state)
        {
            _myCardsCheckbox.SetCheckboxStateWithLabel(_myCardsCheckboxLabel, state);
        }

        public void HierarchyExplorer()
        {
            _hierarchyExplorer.JSClickWithFocus(Driver);
        }

        public void closeHeirarchy()
        {
            string _hierarchyExplorerXPath = @"//div[contains(@id, 'hierachyExplorer')]";
            var _finishButton = Driver.FindElement(By.XPath(_hierarchyExplorerXPath + @"//button[contains(@id, 'finish')]"));
            _finishButton.WaitUntilElementIsInteractable();
            _finishButton.JSClickWithFocus(Driver);
        }

        private static string _expCat = ".//div[@id='expenseCategoryModal']//select[contains(@name,'ddlExpenseCategories')]";
        public string SelectExpenseCategoryOnModal
        {
            get
            {
                Driver.TryWaitForElement(By.XPath(_expCat), out IWebElement expCatDDL);
                try { return new SelectElement(expCatDDL).SelectedOption.Text; }
                catch (NoSuchElementException)
                {
                    Settings.EnCompassExtentTest.Info("No option is selected in Expense Category Dropdown ");
                    return null;
                }
            }

            set
            {
                Driver.TryWaitForElement(By.XPath(_expCat), out IWebElement expCatDDL);
                try { new SelectElement(expCatDDL).SelectByText(value); }
                catch (NoSuchElementException ex) {
                    Settings.EnCompassExtentTest.Info("Could not find the option in Expense Category Dropdown with text " + value);
                    throw ex;
                }
            }
        }

        private static string _expCatOkBtn = ".//div[@id='expenseCategoryModal']//input[contains(@name,'btnSetExpenseCategory')]";
        public void SaveOnExpenseCategoryModal()
        {
            Driver.TryWaitForElement(By.XPath(_expCatOkBtn), out IWebElement okBtn);
            okBtn.JSClickWithFocus(Driver);
            Settings.EnCompassExtentTest.Info("Clicked Ok on Expense Category Modal");
            // Accept the Javascript alert and wait for modal to disappear
            ConfirmOnModal();
            Driver.WaitForAbsence(By.XPath(_expCatOkBtn));
            Settings.EnCompassExtentTest.Info("Expense Category Modal disappeared.");
        }

        private static string _expCatRemoveBtn = ".//div[@id='expenseCategoryModal']//input[contains(@name,'btnRemove')]";
        public void RemoveOnExpenseCategoryModal()
        {
            Driver.TryWaitForElement(By.XPath(_expCatRemoveBtn), out IWebElement removeBtn);
            removeBtn.BootstrapClick();
        }

        private static string _expCatCancelBtn = ".//div[@id='simplemodal-container']//button[contains(@id,'btnEcCancel')]";
        public void CancelOnExpenseCategoryModal()
        {
            Driver.TryWaitForElement(By.XPath(_expCatCancelBtn), out IWebElement cancelBtn);
            cancelBtn.JSClickWithFocus(Driver);
        }

        public string SubmitToWorkflowwithoutSave()
        {
            _submitToWorkflow.JSClickWithFocus(Driver);
            string text = Driver.FindElement(By.XPath("//div[contains(@id,'Modal_')]//div[@class='modal-content']/div[@class='modal-body']/p")).GetAttribute("textContent").ToString();
            return text;
        }

        //Just a replacement untill the code is replaced on EncopassPageModel
        public void AcceptJavascriptAlert()
        {
            IAlert alert = Settings.EnCompassWebDriver.SwitchTo().Alert();
            alert.Accept();

            Driver.SwitchTo().DefaultContent();
            Settings.EnCompassExtentTest.Info("Accepted JavaScript Alert and switched to default Page");
        }

        public int TotalGridTransactions()
        {
            try
            {
                return _allSelectTransactionCheckbox.Count();
            }
            catch (Exception)
            {

                return 0;
            }
        }
        
        public void WaitForTitleToAppear()
        {
            Driver.WaitForVisible(By.XPath(@"//h2[contains(@class,'h3 card-title') and contains(text(),'Card Number:')]"));
        }

        public void WaitForSplitsSection()
        {
            Driver.WaitForVisible(By.XPath(@"//button[contains(@data-toggle,'collapse') and @aria-expanded='true']"));
        }

        /// <summary>
        /// This method verify the condtions of Transaction column
        /// </summary>
        /// <param name="_condition">Condition of Column</param>
        /// <param name="_class">Class of progress bar</param>
        /// <returns></returns>
        private bool VerifyWorkflowClass(string _condition, string _class)
        {
            switch (_condition)
            {
                case "Not Started":
                    Check.That(_class.Contains("zero")).IsTrue();
                    Settings.EnCompassExtentTest.Info($"Workflow {_condition} has the correct zero color.");
                    return true;
                case "Reviewed":
                    Check.That(_class.Contains("info")).IsTrue();
                    Settings.EnCompassExtentTest.Info($"Workflow {_condition} has the correct info color.");
                    return true;
                case "Rejected":
                    Check.That(_class.Contains("danger")).IsTrue();
                    Settings.EnCompassExtentTest.Info($"Workflow {_condition} has the correct dabger color.");
                    return true;
                case "Approved":

                    if (Settings.Scenario["SecondApproval"].Equals("true"))
                    {
                        Check.That(_class.Contains("info")).IsTrue();
                        Settings.EnCompassExtentTest.Info($"Workflow {_condition} has the correct info color.");
                        return true;
                    }
                    else
                    {
                        Check.That(_class.Contains("success")).IsTrue();
                        Settings.EnCompassExtentTest.Info($"Workflow {_condition} has the correct success color.");
                        return true;
                    }
                case "Second Approval":
                    Check.That(_class.Contains("success")).IsTrue();
                    Settings.EnCompassExtentTest.Info($"Workflow {_condition} has the correct success color.");
                    return true;
                default:
                    return false;
            }
        }

        /// <summary>
        /// This method verify the corect percent of Transaction Workflow
        /// </summary>
        /// <param name="_condition">Workflow condition</param>
        /// <param name="_percent">Percent inside the progress bar</param>
        /// <returns></returns>
        private bool VerifyWorkflowPercent(string _condition, string _percent)
        {
            switch (_condition)
            {
                case "Not Started":
                    Check.That(Int32.Parse(_percent)).IsZero();
                    Settings.EnCompassExtentTest.Info($"Workflow {_condition} has 0%.");
                    return true;
                case "Rejected":
                    Check.That(Int32.Parse(_percent)).IsZero();
                    Settings.EnCompassExtentTest.Info($"Workflow {_condition} has 0%.");
                    return true;
                case "Reviewed":
                    if (Settings.Scenario["SecondApproval"].Equals("true"))
                    {
                        Check.That(Int32.Parse(_percent)).Equals(33);
                        Settings.EnCompassExtentTest.Info($"Workflow {_condition} has 33%.");
                    }
                    else
                    {
                        Check.That(Int32.Parse(_percent)).Equals(50);
                        Settings.EnCompassExtentTest.Info($"Workflow {_condition} has 50%.");
                    }
                    return true;
                case "Approved":
                    if (Settings.Scenario["SecondApproval"].Equals("true"))
                    {
                        Check.That(Int32.Parse(_percent)).Equals(66);
                        Settings.EnCompassExtentTest.Info($"Workflow {_condition} has 66%.");
                    }
                    else
                    {
                        Check.That(Int32.Parse(_percent)).Equals(100);
                        Settings.EnCompassExtentTest.Info($"Workflow {_condition} has 100%.");
                    }
                    return true;
                case "Second Approval":
                    Check.That(Int32.Parse(_percent)).Equals(100);
                    Settings.EnCompassExtentTest.Info($"Workflow {_condition} has 100%.");
                    return true;
                default:
                    return false;
            }
        }

        /// <summary>
        /// Method to verify conditions inside the progress bar
        /// </summary>
        /// <param name="progressElement">Elemnt of progress bar (inside the details or not)</param>
        /// <param name="condition">Column condition</param>
        /// <returns></returns>
        private bool InsideProgressBar(IWebElement progressElement, string condition)
        {
            progressElement.TryFindElement(By.XPath(@"div"), out IWebElement subElementDiv);
            Check.That(VerifyWorkflowClass(condition, progressElement.FindElement(By.XPath(@"div")).GetAttribute("class"))).IsTrue();
            Settings.EnCompassExtentTest.Info($"Workflow {condition} has the correct info color.");

            subElementDiv.TryFindElement(By.XPath(@"span"), out IWebElement subElementDivSpan);
            string wPercent = subElementDivSpan.Text;
            Check.That(Int32.TryParse(wPercent.Remove(wPercent.Length - 1), out int result)).IsTrue();
            Check.That(VerifyWorkflowPercent(condition, wPercent.Remove(wPercent.Length - 1))).IsTrue();
            Settings.EnCompassExtentTest.Info($"Workflow {condition} has the correct percent.");

            return true;
        }

        /// <summary>
        /// Method to get the correct row and column to verify the progress bar
        /// </summary>
        /// <param name="column">Column to verify</param>
        /// <param name="wCondition">Condition of Transaction</param>
        /// <returns></returns>
        public bool VerifyTransactionWorkflow(string column, string wCondition)
        {
            List<string> trxWorkflowCol = CardSearchGrid.GetColumnText(column).ToList();
            for (int i = 0; i < trxWorkflowCol.Count(); i++)
            {
                if (trxWorkflowCol[i].Equals(wCondition.ToUpperInvariant()))
                {
                    IWebElement innerElement = CardSearchGrid.GetRow(i);

                    if (innerElement.TryFindElement(By.XPath(_transWorkflowDiv), out IWebElement subElementDivParent))
                    {
                        Check.That(InsideProgressBar(subElementDivParent, wCondition)).IsTrue();
                    }
                }
            }

            return true;
        }

        /// <summary>
        /// Method to get the correct row and details of Transactions to verify progress bar
        /// </summary>
        /// <param name="column">Column to verify</param>
        /// <param name="wCondition">Condition of Transaction</param>
        /// <returns></returns>
        public bool VerifyTransactionWorkflowInsideDetailsView(string column, string wCondition)
        {
            List<string> trxWorkflowCol = CardSearchGrid.GetColumnText(column).ToList();
            for (int i = 0; i < trxWorkflowCol.Count(); i++)
            {
                if (trxWorkflowCol[i].Equals(wCondition.ToUpperInvariant()))
                {
                    IWebElement innerElement = CardSearchGrid.GetRow(i);

                    if (innerElement.TryFindElement(By.XPath(_transWorkflowDetailDiv), out IWebElement subElementDivParent))
                    {
                        Check.That(InsideProgressBar(subElementDivParent, wCondition)).IsTrue();

                        break;
                    }
                }
            }

            return true;
        }

        /// <summary>
        /// Method to verify if workflow progress bar is inside of details row
        /// </summary>
        /// <returns></returns>
        public bool VerifyProgressBarPresentDetailView()
        {
            IWebElement innerElement = CardSearchGrid.GetRow(0);

            Check.That(innerElement.TryFindElement(By.XPath(_transWorkflowDetailDiv), out IWebElement subElementDivParent)).IsTrue();

            return true;
        }


        /// <summary>
        /// Performs the action of inserting a note through the modal. It also performs its related field validations.
        /// </summary>
        public void InsertNoteViaModal(string note)
        {
            // This is not an Iframe but a div with modalId, hence no Xpath is passed as param to FrameHelper
            using (var modal = new FrameHelper(Settings.EnCompassWebDriver))
            {
                var txtArea = modal.FindElement(By.XPath(this.GetNotesElementXpath(MODAL_ADD_NOTES_ELEMENTS.TXTAREA_NOTES)), TimeSpan.FromSeconds(20));
                var btnAdd = modal.FindElement(By.XPath(this.GetNotesElementXpath(MODAL_ADD_NOTES_ELEMENTS.BTN_ADD_NOTES)), TimeSpan.FromSeconds(20));


                if (string.IsNullOrEmpty(txtArea.Text.Trim()))
                {
                    Check.That(btnAdd.Enabled).IsFalse();
                    Settings.EnCompassExtentTest.Info("Note textarea is empty, hence the add button is disabled.");

                    txtArea.SendKeys(Keys.Space);
                    modal.FindElement(By.XPath(this.GetNotesElementXpath(MODAL_ADD_NOTES_ELEMENTS.HEADER))).Click();

                    var validationMsg = modal.FindElement(By.XPath(this.GetNotesElementXpath(MODAL_ADD_NOTES_ELEMENTS.VAL_REQUIRED_NOTES)));
                    Check.That(validationMsg.Text.Equals("Notes is a required value."));
                }
                else
                {
                    Check.That(btnAdd.Enabled).IsTrue();
                    Settings.EnCompassExtentTest.Info("Note textarea has values, hence the add button is enabled.");
                }

                txtArea.Clear();
                txtArea.SendKeys(note);
                Settings.EnCompassExtentTest.Info($"Note \"{note}\" added.");
                btnAdd.JSClickWithFocus(Driver);

            }
        }

        /// <summary>
        /// Verifies if a list of transactions are on the expected status.
        /// </summary>
        /// <param name="transactions">List of transactions to be inserted</param>
        /// <param name="status">Expected transactions status</param>
        /// <param name="expectedReadOnly">Number of read only fields to make the verification against</param>
        public void VerifyTransactionsStatus(List<string> transactions, string status, int expectedReadOnly)
        {
            if (status == "locked")
            {
                foreach (string transaction in transactions)
                {
                    //In mobile device by default new grid is appearing and Brain logged #36178 for the same...will revert the changes once the defect is closed
                    if (isNewGridPresentOnPage)
                        CardSearchNewGrid.ExpandDetailsByIndex(int.Parse(transaction));

                    string financialCodeTableXPath = string.Format(@"(//table[contains(@class,'a_cs_table')])[{0}]", transaction);
                    string readOnlyCodesXPath = "//*[contains(@readonly,'readonly')]";

                    IReadOnlyCollection<IWebElement> readOnlyCodesElements;
                    if (isNewGridPresentOnPage)
                        Driver.TryWaitForElements(By.XPath(readOnlyCodesXPath), out readOnlyCodesElements);
                    else
                        Driver.TryWaitForElements(By.XPath(financialCodeTableXPath + readOnlyCodesXPath), out readOnlyCodesElements);

                    Check.That(readOnlyCodesElements.Count()).IsEqualTo(expectedReadOnly);
                    Settings.EnCompassExtentTest.Info(string.Format("Verified that transaction {0} is locked", transaction));

                    if (isNewGridPresentOnPage)
                        CardSearchNewGrid.CollapseDetailsByIndex(int.Parse(transaction));
                }
            }
            else if (status == "unlocked")
            {
                foreach (string transaction in transactions)
                {
                    //In mobile device by default new grid is appearing and Brain logged #36178 for the same...will revert the changes once the defect is closed
                    if (isNewGridPresentOnPage)
                        CardSearchNewGrid.ExpandDetailsByIndex(int.Parse(transaction));

                    string financialCodeTableXPath = string.Format(@"(//table[contains(@class,'a_cs_table')])[{0}]", transaction);
                    string readOnlyCodesXPath = "//input[not(contains(@readonly,'readonly'))]";

                    IReadOnlyCollection<IWebElement> readOnlyElements;
                    if (isNewGridPresentOnPage)
                        Driver.TryWaitForElements(By.XPath(readOnlyCodesXPath), out readOnlyElements);
                    else
                        Driver.TryWaitForElements(By.XPath(financialCodeTableXPath + readOnlyCodesXPath), out readOnlyElements);

                    Check.That(readOnlyElements.Count()).IsEqualTo(expectedReadOnly);
                    Settings.EnCompassExtentTest.Info(string.Format("Verified that transaction {0} is unlocked", transaction));

                    if (isNewGridPresentOnPage)
                        CardSearchNewGrid.CollapseDetailsByIndex(int.Parse(transaction));
                }
            }
            else
            {
                throw new InvalidDataException($"{status} is not an expected status.");
            }
        }

        public void VerifyIfTransactionsAreUnlocked(List<string> transactions)
        {
            foreach (string transaction in transactions)
            {
                string financialCodeTableXPath = string.Format(@"(//table[contains(@class,'a_cs_table')])[{0}]", transaction);
                string readOnlyCodesXPath = @"//div[contains(@class,'readonly')]";

                Driver.TryWaitForElements((By.XPath(string.Concat(financialCodeTableXPath, readOnlyCodesXPath))), out IReadOnlyCollection<IWebElement> readOnlyElements);

                Check.That(readOnlyElements.Count == 0).IsTrue();
                Settings.EnCompassExtentTest.Info(string.Format("Verified that transaction {0} is unlocked", transaction));
            }
        }

        #region Profiles

        /// <summary>
        /// This method is used to perform Click on Profiles dropdown
        /// </summary>
        public void clickGridToolbarProfilesButton()
        {
            _gridToolbarProfilesButton.JSClickWithFocus(Driver);
            Settings.EnCompassExtentTest.Info("Clicked on Profiles button.");
        }

        /// <summary>
        /// This method is used to verify Profiles dropdown options
        /// </summary>
        public bool VerifyProfilesGridOptions(ExtentTest test)
        {
            clickGridToolbarProfilesButton();

            List<string> options = StringKeys.ProfilesOptions;
            for (int p = 0; p < options.Count(); p++)
            {
                if (!_gridToolbarProfilesOption[p].Text.Contains(options[p]))
                {
                    clickGridToolbarProfilesButton();
                    test.Info($"{options[p]} didn't matched with the Profile options.");
                    return false;
                }
            }
            test.Info("All of Profiles options verified.");
            clickGridToolbarProfilesButton();
            return true;
        }

        /// <summary>
        /// This method is used to click on the profiles dropdown options
        /// </summary>
        public void ProfilesGrid(string option, ExtentTest test)
        {
            clickGridToolbarProfilesButton();

            Driver.TryWaitForElement(By.XPath(_gridToolbarProfilesOptionXpath + "[contains(text(), '" + option + "')]"), out IWebElement profileOption);

            string xpathModal = string.Empty;
            switch (option)
            {
                case "Save As":
                    xpathModal = _profileSaveAsModalXPath;
                    break;
                case "Set Default":
                    xpathModal = _profileSetDefaultModalXPath;
                    break;
                case "Reset":
                    xpathModal = _profileResetModalXPath;
                    break;
            }
            profileOption.JSClickWithFocus(Driver);
            test.Info("Clicked on Profile Option " + option);
            WaitForModalToAppear(xpathModal);

        }

        /// <summary>
        /// This method is used to set/get Profile Name
        /// </summary>
        public string NewProfileName
        {
            get { return _newProfileName.GetAttribute("value"); }
            set
            {
                _newProfileName.Clear();
                _newProfileName.SendKeys(value);
                Settings.EnCompassExtentTest.Info("Set New profile name with value: " + value);
            }
        }

        /// <summary>
        /// Method to unfocus textbox
        /// </summary>
        public void ModalHeaderClick()
        {
            _modalSaveAsHeader.BootstrapClick();//Cliked on header modal to take off focus from textbox
            Settings.EnCompassExtentTest.Info("Cliked on header modal.");
        }

        /// <summary>
        /// Method to unfocus textbox
        /// </summary>
        public void ModalRenameHeaderClick()
        {
            _modalRenameHeader.BootstrapClick();//Cliked on header modal to take off focus from textbox
            Settings.EnCompassExtentTest.Info("Cliked on header modal.");
        }

        /// <summary>
        /// This method is used to error for Required name message
        /// </summary>
        public string GetErrorRequiredNameMessage
        {
            get
            {
                return _errorRequiredNameMessage.Text;
            }
        }

        /// <summary>
        /// This method is used to perform Cancel inside the profiles dropdown option SaveAs
        /// </summary>
        public void SaveAsCancel()
        {
            WaitForModalToAppear(_profileSaveAsModalXPath);
            _saveAsCancelButton.JSClickWithFocus(Driver);
            WaitForModalToDisappear(_profileSaveAsModalXPath);
            Settings.EnCompassExtentTest.Info("Cancel button clicked on modal");
            WaitForFormLoadingOverlay(new TimeSpan(5));
        }

        /// <summary>
        /// This method is used to perform Save inside the profiles dropdown option SaveAs
        /// </summary>
        public void SaveAsSave()
        {
            WaitForModalToAppear(_profileSaveAsModalXPath);
            _saveAsSaveButton.JSClickWithFocus(Driver);
            WaitForModalToDisappear(_profileSaveAsModalXPath);
            Settings.EnCompassExtentTest.Info("Save as button clicked");
            this.RefreshModel();
            WaitForFormLoadingOverlay();
        }

        /// <summary>
        /// This method is used to set Overwrite Existing Profile checkbox inside the profiles dropdown option SaveAs
        /// </summary>
        public bool SetOverwriteExistingProfile
        {
            get { return _setOverwriteExistingProfileCheckbox.Selected; }
            set
            {
                _setOverwriteExistingProfileCheckbox.SetCheckboxStateWithLabel(_setOverwriteExistingProfileCheckboxLabel, value);
                Settings.EnCompassExtentTest.Info("Enable Overwrite existing profile: " + value);
            }
        }

        /// <summary>
        /// This method is used to select a existing profile radio option at Save As modal
        /// </summary>
        public void ChooseDefaultProfileOptionSaveAs(string name, ExtentTest test)
        {
            string xpath = String.Format(_rbSelectProfileXPath, name);
            Driver.TryWaitForElement(By.XPath(xpath), out IWebElement rbOption);
            xpath = String.Format(_rbSelectProfileLabelXPath, name);
            Driver.TryWaitForElement(By.XPath(xpath), out IWebElement label);

            rbOption.SetRadioButtonStateWithLabel(label, true);
            this.RefreshModel();
            test.Info($"The profile {name} selected.");
        }

        /// <summary>
        /// This method is used to check if Profile name field is Enabled
        /// </summary>
        public bool NewProfileNameIsEnabled()
        {
            bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_newProfileNameXPath), out IWebElement element);
            Settings.EnCompassExtentTest.Info("_newProfileName enable is" + found);
            return element.Enabled;
        }

        /// <summary>
        /// This method is used to set default checkbox inside the profiles dropdown option SaveAs
        /// </summary>
        public bool AsDefaultProfileCheckbox
        {
            get { return _setAsDefaultProfileCheckbox.Selected; }
            set
            {
                _setAsDefaultProfileCheckbox.SetCheckboxStateWithLabel(_setAsDefaultProfileCheckboxLabel, value);
                Settings.EnCompassExtentTest.Info("Set as default profile: " + value);
            }
        }

        /// <summary>
        /// This method is used to verify the existing profiles at the Profiles dropdown 
        /// </summary>
        public bool VerifyProfilesGridName(List<string> nameProfile, ExtentTest test)
        {
            clickGridToolbarProfilesButton();

            IList<IWebElement> profileNames = _gridToolbarProfilesNames;
            bool allNamesChecked = false;
            for (int n = 0; n < nameProfile.Count(); n++)
            {
                foreach (IWebElement p in profileNames)
                {
                    if (p.Text.Contains(nameProfile[n]))
                    {
                        allNamesChecked = true;
                        test.Info($"Profile Name {nameProfile[n]} found.");
                        break;
                    }
                }
            }

            clickGridToolbarProfilesButton();

            return allNamesChecked;
        }

        private List<string> GetAllProfileNames()
        {
            clickGridToolbarProfilesButton();
            IList<IWebElement> profileNames = _gridToolbarProfilesNames;
            if (profileNames == null)
                return null;

            List<string> names = new List<string>();
            foreach (var p in profileNames)
            {
                names.Add(p.Text.Replace(" (Default)", ""));
            }

            clickGridToolbarProfilesButton();
            return names;
        }

        /// <summary>
        /// This method is used to perform the hover action (click and hold) 
        /// </summary>
        public bool ClickAndHoldOption(string name, string option, ExtentTest test)
        {
            clickGridToolbarProfilesButton();

            string profileXPath = String.Format(_profilesNameXPath, name);
            ClickAndHold(profileXPath);

            profileXPath = profileXPath + _profileControlsXPath;
            Driver.TryWaitForElementsToBeVisible(By.XPath(profileXPath), out IList<IWebElement> profileControls);

            foreach (IWebElement c in profileControls)
            {
                if (c.Text.ToLowerInvariant().Equals(option.ToLowerInvariant()))
                {
                    c.JSClickWithFocus(Driver);
                    test.Info($"Clicked in {option} for {name} profile");
                    return true;
                }
            }

            test.Info($"{option} did not find for {name} profile");
            return false;
        }

        /// <summary>
        /// This method is used to perform Delete at the delete confirm modal for a existing profile
        /// </summary>
        public void ProfileDelete()
        {
            WaitForModalToAppear(_profileDeleteModalXPath);
            _deleteProfileName.JSClickWithFocus(Driver);
            WaitForModalToDisappear(_profileDeleteModalXPath);
            WaitForFormLoadingOverlay(new TimeSpan(5));
            Settings.EnCompassExtentTest.Info("Delete button clicked on modal");
        }

        /// <summary>
        /// This method is used to Delete all existing profiles 
        /// </summary>
        public void DeleteAllExistingProfiles(ExtentTest test)
        {
            List<string> profileNames = GetAllProfileNames();
            if (profileNames != null)
            {
                foreach (string p in profileNames)
                {
                    ClickAndHoldOption(p, "Delete", test);
                    WaitForModalToAppear(_profileDeleteModalXPath);
                    ProfileDelete();
                    WaitForModalToDisappear(_profileDeleteModalXPath);
                    WaitForFormLoadingOverlay(new TimeSpan(5));
                }
            }
        }

        /// <summary>
        /// This method is used to perform Cancel at the Set Default confirm modal for a existing profile
        /// </summary>
        public void CancelSetDefault()
        {
            WaitForModalToAppear(_profileSetDefaultModalXPath);
            _profileSetDefaultCancelButton.JSClickWithFocus(Driver);
            WaitForModalToDisappear(_profileSetDefaultModalXPath);
            Settings.EnCompassExtentTest.Info("Save as button clicked");
            WaitForFormLoadingOverlay(new TimeSpan(5));
        }

        /// <summary>
        /// This method is used to set default at Save As modal
        /// </summary>
        public void SetDefaultProfileOption(string name, ExtentTest test)
        {
            string xpath = String.Format(_rbSelectSetDefaultProfileXPath, name);
            Driver.TryWaitForElement(By.XPath(xpath), out IWebElement rbOption);
            xpath = String.Format(_rbSelectSetDefaultProfileLabelXPath, name);
            Driver.TryWaitForElement(By.XPath(xpath), out IWebElement label);

            rbOption.SetRadioButtonStateWithLabel(label, true);
            this.RefreshModel();
            test.Info($"The profile {name} selected.");
        }

        /// <summary>
        /// This method is used to perform Save at the Set Default confirm modal for a existing profile
        /// </summary>
        public void SaveSetDefault()
        {
            WaitForModalToAppear(_profileSetDefaultModalXPath);
            _profileSetDefaultSaveButton.JSClickWithFocus(Driver);
            WaitForModalToDisappear(_profileSetDefaultModalXPath);
            Settings.EnCompassExtentTest.Info("Cancel button clicked on modal");
            WaitForFormLoadingOverlay(new TimeSpan(5));
        }

        /// <summary>
        /// This method is used to perform Reset inside the profiles dropdown option Reset
        /// </summary>
        public void ProfileReset()
        {
            WaitForModalToAppear(_profileResetModalXPath);
            _profileReset.JSClickWithFocus(Driver);
            Settings.EnCompassExtentTest.Info("Reset button clicked on modal");           
        }

        /// <summary>
        /// This method is used to perform Cancel inside the profiles dropdown option Reset
        /// </summary>
        public void ProfileResetCancel()
        {
            WaitForModalToAppear(_profileResetModalXPath);
            _profileResetCancel.JSClickWithFocus(Driver);
            WaitForModalToDisappear(_profileResetModalXPath);
            Settings.EnCompassExtentTest.Info("Cancel Reset button clicked on modal");
        }

        /// <summary>
        /// This method is used to perform Cancel at the Rename confirm modal for a existing profile
        /// </summary>
        public void CancelRenameProfile()
        {
            WaitForModalToAppear(_profileRenameModalXPath);
            _profileRenameCancelButton.JSClickWithFocus(Driver);
            WaitForModalToDisappear(_profileRenameModalXPath);
            Settings.EnCompassExtentTest.Info("Profile Rename Save as button clicked");
            WaitForFormLoadingOverlay(new TimeSpan(5));
        }
        private IWebElement _errorRequiredNameMessage
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_errorRequiredNameMessageXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_errorRequiredNameMessage element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        /// <summary>
        /// This method is usederror for Required Rename message
        /// </summary>
        public string RenameProfileName
        {
            get { return _newProfileName.GetAttribute("value"); }
            set
            {
                _renameProfileName.Clear();
                _renameProfileName.SendKeys(value);
                Settings.EnCompassExtentTest.Info("Rename profile name with value: " + value);
            }
        }

        /// <summary>
        /// This method is used to error for Required Rename message
        /// </summary>
        public string GetErrorRequiredRenameMessage
        {
            get
            {
                return _errorRequiredRenameMessage.Text;
            }
        }

        /// <summary>
        /// This method is used to perform Save at the Rename confirm modal for a existing profile
        /// </summary>
        public void SaveRenameProfile()
        {
            WaitForModalToAppear(_profileRenameModalXPath);
            _profileRenameSaveButton.JSClickWithFocus(Driver);
            WaitForModalToDisappear(_profileRenameModalXPath);
            Settings.EnCompassExtentTest.Info("Profile Rename Cancel button clicked on modal");
            WaitForFormLoadingOverlay(new TimeSpan(5));
        }

        /// <summary>
        /// This method is used to check and return if Overwrite Existing Profile checkbox is enabled
        /// </summary>
        public bool SetOverwriteExistingProfileCheckboxEnable()
        {
            bool found = Driver.TryWaitForElement(By.XPath(_setOverwriteExistingProfileCheckboxXPath), out IWebElement element);
            Settings.EnCompassExtentTest.Info("_setOverwriteExistingProfileCheckbox enable is" + found);
            return element.Enabled;
        }

        /// <summary>
        /// This method is used to perform Cancel at the delete confirm modal for a existing profile
        /// </summary>
        public void ProfileDeleteCancel()
        {
            WaitForModalToAppear(_profileDeleteModalXPath);
            _profileDeleteCancelButton.JSClickWithFocus(Driver);
            Settings.EnCompassExtentTest.Info("Cancel Delete button clicked on modal");
            WaitForModalToDisappear(_profileDeleteModalXPath);
            WaitForFormLoadingOverlay(new TimeSpan(5));
        }
        #endregion
    }
}
