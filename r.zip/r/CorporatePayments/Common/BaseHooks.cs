﻿using AventStack.ExtentReports;
using AventStack.ExtentReports.Reporter;
using BoDi;
using Common.Utility;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Appium;
using OpenQA.Selenium.Appium.Android;
using OpenQA.Selenium.Appium.Enums;
using OpenQA.Selenium.Appium.iOS;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Edge;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.IE;
using OpenQA.Selenium.Remote;
using OpenQA.Selenium.Safari;
//using OpenQA.Selenium.PhantomJS;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using TechTalk.SpecFlow;

namespace Common
{
	public abstract class BaseHooks
	{
		protected const string STEP_IDENTIFIER_KEY = "StepId";

		protected static ExtentReports _uiExtent;
		protected ExtentTest _uiTest;
		protected static ExtentV3HtmlReporter _uiHtmlReporter;
		protected static ExtentReports _apiExtent;
		protected ExtentTest _apiTest;
		protected static ExtentV3HtmlReporter _apiHtmlReporter;
		protected ScenarioContext _scenarioContext;
		protected FeatureContext _featureContext;
		protected IObjectContainer _objectContainer;
		public GlobalSettings _settings;
		public static string _BrowserVersion = "N/A";
		public static string _BrowserName = "N/A";
		public static string _BrowserPlatform = "N/A";
		public static string _BrowserJSEnabled = "N/A";
		public static string _BrowserMobEmulEnabled = "N/A";
		public static string _MobileOSVersion = "N/A";
		public static string _MobileDeviceName = "N/A";
		public static string _MobileOS = "N/A";
		public static bool _browserDetailsSet = false;

		public static string AssemblyDirectory
		{
			get
			{
				string codeBase = Assembly.GetExecutingAssembly().CodeBase;
				UriBuilder uri = new UriBuilder(codeBase);
				string path = Uri.UnescapeDataString(uri.Path);
				return Path.GetDirectoryName(path);
			}
		}

		public BaseHooks(ScenarioContext scenarioContext, FeatureContext featureContext, IObjectContainer container, GlobalSettings settings)
		{
			_scenarioContext = scenarioContext;
			_featureContext = featureContext;
			_objectContainer = container;
			_settings = settings;
			_settings.Scenario = _scenarioContext;
			_settings.Feature = _featureContext;
		}

		protected virtual void LogStepResult(ScenarioContext context, bool includeScreenshot)
		{
			try
			{
				string stepText = context.StepContext.StepInfo.Text;
				var stepExceptions = GetStepExceptions(GetStepId(this._scenarioContext.StepContext));

				if (this._scenarioContext.TestError != null)
				{
					stepExceptions.Add(this._scenarioContext.TestError);
				}

				if (stepExceptions.Any())
				{
					foreach (Exception error in stepExceptions) //.Where(e=> e.GetType() != typeof(IgnoreException))) // Kiran M - Added the condition to NOT RE-THROW EXCEPTION IF THE CURRENT SCENARIO THROWS IGNORE EXCEPTION.
					{
						string scenarioTitle = context.ScenarioInfo.Title;
						StringBuilder errorDetails = new StringBuilder();
						errorDetails.AppendLine(error.Data.ToString());
						errorDetails.AppendLine("Message is:" + error.Message + "\n");
						errorDetails.AppendLine("Source is:" + error.Source + "\n");
						errorDetails.AppendLine("Stack Trace is:" + error.StackTrace + "\n");
						Console.WriteLine("-> Step Exception: " + errorDetails.ToString());
						Logger.LogError("-> Step Exception: " + errorDetails.ToString());
						if (includeScreenshot)
						{
                            _settings.EnCompassExtentTest.Info("Step Error Encountered");
                            string scrnSht = null;

                            scrnSht = ScreenshotHelper.TakeFullPageScreenshot(_settings.EnCompassWebDriver, _settings, scenarioTitle, stepText);

                            scrnSht = "./Screenshots/" + scrnSht;
                            if (error.Message.Trim().ToLowerInvariant().Contains("[id:reportexception]"))
                            {
                                _settings.EnCompassExtentTest.Error(stepText + ".   Error Details :  " + errorDetails.ToString(), MediaEntityBuilder.CreateScreenCaptureFromPath(scrnSht).Build());
                            }
                            else
                            {
                                _settings.EnCompassExtentTest.Fail(stepText + ".   Error Details :  " + errorDetails.ToString(), MediaEntityBuilder.CreateScreenCaptureFromPath(scrnSht).Build());
                            }
						}
						else
						{
                            // if include screenshot if false, it is expected the failure is not a step in the test scenario flow, hence 
                            // logging as Error
                            if (error.Message.Trim().ToLowerInvariant().Contains("[id:reportexception]"))
                            {
                                _settings.EnCompassExtentTest.Error(stepText + ".   Error Details :  " + errorDetails.ToString());
                            }
                            else
                            {
                                _settings.EnCompassExtentTest.Fail(stepText + ".   Error Details :  " + errorDetails.ToString());
                            }
                        }

						// Add the Step Exception to Scenario Errors List
						_settings.ScenarioErrors.Add(new StepException(context.StepContext, error));
					}
				}
				else
				{
					Console.WriteLine("Test Step -> done.");
					_settings.EnCompassExtentTest.Pass(stepText);
				}
			}
			catch (Exception ex)
			{
				_settings.EnCompassExtentTest.Debug("StackTrace:" + ex.StackTrace);
				_settings.EnCompassExtentTest.Fatal("Exception Caught in BaseHooks->LogStepResultWithScrnshot:" + ex.Message);

				throw ex;
			}
			finally
			{
				Logger.EndStepLog(context.StepContext.StepInfo.Text);
			}
		}

        protected virtual IWebDriver GetSeleniumDriver(TimeSpan commandTimeout)
		{
			IWebDriver driver = null;
			string browser = GlobalSettings.Browser;
			String proxyUrl = GlobalSettings.Proxy.Trim();
			Proxy proxy = null;
			if (!String.IsNullOrEmpty(proxyUrl))
			{
				proxy = new Proxy
				{
					HttpProxy = proxyUrl,
					SslProxy = proxyUrl
				};
			}

			// Var to point to default download directory for Chrome & Firefox
			var downloadDirectory = PathHelper.GetAbsolutePathRelativeToProjectPath(GlobalSettings.TemplateRelativePath);

			switch (browser.ToUpperInvariant())
			{
				case "CHROME":		
					if(GlobalSettings.DeviceType.Equals(GlobalSettings.Device.DESKTOP.ToString(), StringComparison.InvariantCultureIgnoreCase))
						driver = CreateChromeDriverForDesktop(browser, downloadDirectory, commandTimeout, GlobalSettings.Device.DESKTOP);
					else
						driver = CreateMobileDriverForBrowserStack(GlobalSettings.MobileBrowsers.CHROME.ToString(), downloadDirectory, commandTimeout);
					break;
				case "IE":
                    InternetExplorerOptions ieOptions = new InternetExplorerOptions();
                    ieOptions.IntroduceInstabilityByIgnoringProtectedModeSettings = true; // to ignore IE protected mode settings
                    ieOptions.IgnoreZoomLevel = true; // To ignore zoom level of IE
                    ieOptions.BrowserCommandLineArguments = "-private"; // To launch IE when when the Windows CreateProcess API is used
                    //ieOptions.AcceptInsecureCertfalseificates = true;
                    ieOptions.ElementScrollBehavior = InternetExplorerElementScrollBehavior.Bottom; // scrolling the element to the top of the viewport.
                    ieOptions.EnableNativeEvents = false; // Indicating whether to use native events in interacting with elements.
                    ieOptions.RequireWindowFocus = true; // Indicating whether to require the browser window to have focus before interacting with elements
                    ieOptions.EnablePersistentHover = true;
                    ieOptions.EnsureCleanSession = true; //cache before launching the browser
                    ieOptions.PageLoadStrategy = PageLoadStrategy.Normal; // browser is to wait for pages to load in the IE driver
                    ieOptions.UnhandledPromptBehavior = UnhandledPromptBehavior.Accept;
                    ieOptions.Proxy = proxy;
                    _uiTest.Info("Assembly directory for IEDriverServer exe : " + AssemblyDirectory);
                    if (File.Exists(AssemblyDirectory + "\\IEDriverServer.exe"))
                        _uiTest.Info("IEDriverServer exe found in AssemblyDirectory");
                    else
                        _uiTest.Error("IEDriverServer exe NOT found in AssemblyDirectory");
					ieOptions.BrowserAttachTimeout = TimeSpan.FromSeconds(3);
					driver = new InternetExplorerDriver(AssemblyDirectory, ieOptions, commandTimeout);
                     driver.Manage().Timeouts().PageLoad = TimeSpan.FromSeconds(30);
                    _uiTest.Info("Page load timeout set to 30 secs");

                     break;
				case "FIREFOX":
					FirefoxOptions foptions = new FirefoxOptions();
					foptions.BrowserExecutableLocation = PathHelper.GetBrowserAbsolutePath(browser);
					foptions.Proxy = proxy;
                    foptions.SetPreference("network.proxy.type", 4);
					FirefoxProfile fprofile = new FirefoxProfile();
					//Set Location to store files after downloading.
					fprofile.SetPreference("browser.download.dir", downloadDirectory);
					// This can be set to either 0, 1, or 2.When set to 0, Firefox will save all files on the user’s desktop. 
					// 1 saves the files in the Downloads folder and 2 saves file at the location specified for the most recent download.
				    fprofile.SetPreference("browser.download.folderList", 2);
					// A comma-separated list of MIME types to save to disk without asking what to use to open the file.
					fprofile.SetPreference("browser.helperApps.neverAsk.saveToDisk", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,application/pdf,text/csv,application/vnd.ms-excel");					
					fprofile.SetPreference("pdfjs.disabled", true);
					// Level 5 sandbox to avoid crashes in TFS agents
					fprofile.SetPreference("security.sandbox.content.level", 5);
					foptions.Profile = fprofile;
					_uiTest.Info("Assembly directory for geckodriver exe : " + AssemblyDirectory);
					if (File.Exists(AssemblyDirectory + "\\geckodriver.exe"))
						_uiTest.Info("gecko driver exe found in AssemblyDirectory");
					else
						_uiTest.Error("gecko driver exe NOT found in AssemblyDirectory");
					driver = new FirefoxDriver(AssemblyDirectory, foptions, commandTimeout);
					driver.Manage().Window.Maximize();
					break;
                case "SAFARI":
                    driver = CreateMobileDriverForBrowserStack(GlobalSettings.MobileBrowsers.SAFARI.ToString(), downloadDirectory, commandTimeout);
                    break;
                case "MOBILECHROMELOCAL": 
                    // This is running desktop Chrome on mobile simulation
					driver = CreateChromeDriverForDesktop(browser, downloadDirectory, commandTimeout, GlobalSettings.Device.MOBILE, GlobalSettings.MobileDeviceName);
					break;
				case "EDGE":
                    EdgeOptions eOptions = new EdgeOptions();
                    eOptions.AcceptInsecureCertificates = true;
                    eOptions.PageLoadStrategy = PageLoadStrategy.Normal;
					eOptions.UnhandledPromptBehavior = UnhandledPromptBehavior.Accept;
					_uiTest.Info("Assembly directory for MicrosoftWebDriver exe : " + AssemblyDirectory);
                    if (File.Exists(AssemblyDirectory + "\\MicrosoftWebDriver.exe"))
                        _uiTest.Info("MicrosoftWebDriver exe found in AssemblyDirectory");
                    else
                        _uiTest.Error("MicrosoftWebDriver exe NOT found in AssemblyDirectory");
					EdgeDriverService eDriverService = EdgeDriverService.CreateDefaultService(AssemblyDirectory, "MicrosoftWebDriver.exe");
                    driver = new EdgeDriver(eDriverService, eOptions);
					break;
				default: break;
			}

			if (driver == null)
				_settings.EnCompassExtentTest.Info("Webdriver instantiation failed, null object returned!!");
			else
				_settings.EnCompassExtentTest.Info("Got WebDriver instance");

			
			ICapabilities caps = ((OpenQA.Selenium.Remote.RemoteWebDriver) driver).Capabilities;
			switch (browser.ToUpperInvariant())
			{
				case "CHROME":
					if (GlobalSettings.DeviceType.Equals(GlobalSettings.Device.DESKTOP.ToString(), StringComparison.InvariantCultureIgnoreCase))
					{
						_BrowserVersion = caps.GetCapability("version").ToString();
						_BrowserPlatform = caps.GetCapability("platform").ToString();
						_BrowserJSEnabled = caps.GetCapability("javascriptEnabled").ToString();
						_BrowserMobEmulEnabled = caps.GetCapability("mobileEmulationEnabled").ToString();
					}
					else
					{
						_MobileDeviceName = GlobalSettings.MobileDeviceName;
						_MobileOSVersion = GlobalSettings.MobileOSVersion;
                        _MobileOS = GlobalSettings.MobileOS;
                    }
					_BrowserName = caps.GetCapability("browserName").ToString();
					break;
				case "FIREFOX":
                    _BrowserVersion = caps.GetCapability("browserVersion").ToString();
                    _BrowserName = caps.GetCapability("browserName").ToString();
                    _BrowserPlatform = caps.GetCapability("platformName").ToString() + " " + caps.GetCapability("platformVersion").ToString();
                    break;
                case "IE":
                    _BrowserVersion = caps.GetCapability("browserVersion").ToString();
                    _BrowserPlatform = caps.GetCapability("platformName").ToString();
                    _BrowserJSEnabled = "Not Available";
                    _BrowserMobEmulEnabled = "Not Available";
                    break;
                case "EDGE":
					_BrowserVersion = caps.GetCapability("browserVersion").ToString();
					_BrowserName = caps.GetCapability("browserName").ToString();
                    _BrowserPlatform = caps.GetCapability("platformName").ToString() + " " + caps.GetCapability("platformVersion").ToString();
                    _BrowserJSEnabled = "Not Available";
                    _BrowserMobEmulEnabled = "Not Available";
                    break;
				case "MOBILECHROMELOCAL":
					_BrowserVersion = caps.GetCapability("version").ToString();
					_BrowserName = caps.GetCapability("browserName").ToString();
					_BrowserPlatform = caps.GetCapability("platform").ToString();
					_BrowserJSEnabled = caps.GetCapability("javascriptEnabled").ToString();
					_BrowserMobEmulEnabled = caps.GetCapability("mobileEmulationEnabled").ToString();
					_MobileDeviceName = GlobalSettings.MobileDeviceName;
					break;
				case "SAFARI":
					_MobileDeviceName = GlobalSettings.MobileDeviceName;
					_MobileOSVersion = GlobalSettings.MobileOSVersion;
					_BrowserName = caps.GetCapability("browserName").ToString();
					break;
			default: break;
			}
			
            return driver;
		}

		public ICollection<Exception> GetStepExceptions(Guid stepId)
		{
			return _settings.ScenarioErrors.Where(e => e.StepId == stepId).Select(e => e.Error).ToList();
		}

		public static Guid GetStepId(ScenarioStepContext stepContext)
		{
			if (stepContext.TryGetValue<Guid>(STEP_IDENTIFIER_KEY, out Guid id))
			{
				return id;
			}
			throw new Exception($"Unable to locate StepID for, '{stepContext.StepInfo.Text}'");
		}

		#region Private Methods		

		/// <summary>
		/// Create Chromedriver instance for Mobile(local runs)/Desktop
		/// </summary>
		private IWebDriver CreateChromeDriverForDesktop(string browser, string downloadDirectory, TimeSpan commandTimeout,
			GlobalSettings.Device device, string deviceName = null)
		{
			ChromeOptions chromeOptions = new ChromeOptions();
			//chromeOptions.Proxy = proxy;
			chromeOptions.BinaryLocation = PathHelper.GetBrowserAbsolutePath(browser);
			_uiTest.Info("Chrome browser Directory:" + PathHelper.GetBrowserAbsolutePath(browser));
			chromeOptions.AddArgument("--disable-infobars"); // disabling infobars
			chromeOptions.AddArgument("--disable-extensions"); // disabling extensions
			chromeOptions.AddArgument("--disable-gpu"); // applicable to windows os only
														// refer - https://stackoverflow.com/questions/50642308/org-openqa-selenium-webdriverexception-unknown-error-devtoolsactiveport-file-d/50725918#50725918
			chromeOptions.AddArgument("--disable-dev-shm-usage"); // overcome limited resource problems
			chromeOptions.AddArgument("--no-sandbox");
			chromeOptions.AddArguments("--incognito");
			_uiTest.Info("Running Incognito mode");
			//chromeOptions.AddArgument("--headless");// run headless

			// Set download directory to "Templates" folder
			chromeOptions.AddUserProfilePreference("download.default_directory", downloadDirectory);
			chromeOptions.AddUserProfilePreference("download.prompt_for_download", false);
            chromeOptions.AddUserProfilePreference("profile.default_content_setting_values.automatic_downloads", 1);

            chromeOptions.AddUserProfilePreference("disable-popup-blocking", "true");
			chromeOptions.AddAdditionalCapability("useAutomationExtension", false);

			_uiTest.Info("Assembly directory for chromedriver exe : " + AssemblyDirectory);
			if (File.Exists(AssemblyDirectory + "\\chromedriver.exe"))
				_uiTest.Info("chrome driver exe found in AssemblyDirectory");
			else
				_uiTest.Error("chrome driver exe NOT found in AssemblyDirectory");

			if(device.Equals(GlobalSettings.Device.MOBILE))
			{
				chromeOptions.EnableMobileEmulation(deviceName); // Set mobile device type to emulate for local development only
				return new ChromeDriver(AssemblyDirectory, chromeOptions, commandTimeout);
			}
			else
			{
				chromeOptions.AddArgument("--start-maximized"); // open Browser in maximized mode
				IWebDriver driver = new ChromeDriver(AssemblyDirectory, chromeOptions, commandTimeout);
				driver.Manage().Window.Maximize();
				return driver;
			}
		}

		/// <summary>
		/// Create Mobile Webdriver using Driver Options for each type
		/// </summary>
		private IWebDriver CreateMobileDriverForBrowserStack(string browser, string downloadDirectory, TimeSpan commandTimeout)
		{
			//DesiredCapabilities capability = new DesiredCapabilities();
			//capability.SetCapability("os_version", GlobalSettings.MobileOSVersion);
			//capability.SetCapability("device", GlobalSettings.MobileDeviceName);
			//capability.SetCapability("real_mobile", "true");
			//capability.SetCapability("browserstack.local", "false");
			//capability.SetCapability("browserstack.appium_version", "1.14.0);
			//capability.SetCapability("browserstack.user", GlobalSettings.BrowserStackUser);
			//capability.SetCapability("browserstack.key", GlobalSettings.BrowserStackKey);
			//capability.SetCapability("browser", "Chrome");
			//capability.SetCapability("browserstack.networkProfile", "4g-lte-good");
			//capability.SetCapability("project", GlobalSettings.BambooPlanKey);
			//capability.SetCapability("build", GlobalSettings.BambooResultKey);
			//capability.SetCapability("name", _settings.Scenario.ScenarioInfo.Title);
			//capability.SetCapability(ChromeOptions.Capability, mobileChromeOptions.ToCapabilities());
			//driver = new RemoteWebDriver(new Uri(GlobalSettings.BrowserStackHubUrl), capability);
			IWebDriver driver = null;
			switch (browser.ToUpperInvariant())
			{
				case "CHROME":
					ChromeOptions mobileChromeOptions = new ChromeOptions();
					mobileChromeOptions.AddAdditionalCapability("device", GlobalSettings.MobileDeviceName, true);
					mobileChromeOptions.AddAdditionalCapability("realMobile", "true", true);
					mobileChromeOptions.AddAdditionalCapability("os_version", GlobalSettings.MobileOSVersion, true);
					mobileChromeOptions.AddAdditionalCapability("browser", "Chrome", true);
					mobileChromeOptions.AddAdditionalCapability("browserstack.networkProfile", "4g-lte-advanced-good", true);
					mobileChromeOptions.AddAdditionalCapability("project", GlobalSettings.BambooPlanKey, true);
					mobileChromeOptions.AddAdditionalCapability("build", GlobalSettings.BambooResultKey, true);
					mobileChromeOptions.AddAdditionalCapability("name", _settings.Scenario.ScenarioInfo.Title, true);
					mobileChromeOptions.AddAdditionalCapability("browserstack.appium_version", "1.14.0", true);
					mobileChromeOptions.AddAdditionalCapability("browserstack.user", GlobalSettings.BrowserStackUser, true);
					mobileChromeOptions.AddAdditionalCapability("browserstack.key", GlobalSettings.BrowserStackKey, true);
                    //Browserstack ticket:#231624, By default browserstack.video value : true
                    //mobileChromeOptions.AddAdditionalCapability("browserstack.video", true);
                    //Set download directory to "Templates" folder
                    mobileChromeOptions.AddUserProfilePreference("download.default_directory", downloadDirectory);
					mobileChromeOptions.AddUserProfilePreference("download.prompt_for_download", false);
					mobileChromeOptions.AddUserProfilePreference("disable-popup-blocking", true);
                    //AppiumOptions appiumOptions = new AppiumOptions();
                    //appiumOptions.AddAdditionalCapability(ChromeOptions.Capability, mobileChromeOptions.ToCapabilities());
					driver = CreateOSSpecificMobileDriver(new Uri(GlobalSettings.BrowserStackHubUrl), mobileChromeOptions, commandTimeout);
					break;
				case "SAFARI":
					SafariOptions mobileSafariOptions = new SafariOptions();
					mobileSafariOptions.AddAdditionalCapability("device", GlobalSettings.MobileDeviceName);
					mobileSafariOptions.AddAdditionalCapability("realMobile", "true");
					mobileSafariOptions.AddAdditionalCapability("os_version", GlobalSettings.MobileOSVersion);
					mobileSafariOptions.AddAdditionalCapability("browser", "Safari");
					mobileSafariOptions.AddAdditionalCapability("browserstack.networkProfile", "4g-lte-good");
					mobileSafariOptions.AddAdditionalCapability("project", GlobalSettings.BambooPlanKey);
					mobileSafariOptions.AddAdditionalCapability("build", GlobalSettings.BambooResultKey);
					mobileSafariOptions.AddAdditionalCapability("name", _settings.Scenario.ScenarioInfo.Title);
					mobileSafariOptions.AddAdditionalCapability("browserstack.appium_version", "1.14.0");
					mobileSafariOptions.AddAdditionalCapability("browserstack.user", GlobalSettings.BrowserStackUser);
					mobileSafariOptions.AddAdditionalCapability("browserstack.key", GlobalSettings.BrowserStackKey);
					mobileSafariOptions.AddAdditionalCapability("browserstack.video", true);
					driver = CreateOSSpecificMobileDriver(new Uri(GlobalSettings.BrowserStackHubUrl), mobileSafariOptions, commandTimeout);
					break;
			}
			return driver;
		}

		/// <summary>
		/// Creates AndroidDriver or IOSDriver instance based on the Mobile OS
		/// </summary>
		private IWebDriver CreateOSSpecificMobileDriver(Uri uri, DriverOptions options, TimeSpan commandTimeout)
		{
            if (GlobalSettings.MobileOS.Equals(GlobalSettings.MobileOSList.ANDROID.ToString()))
            {                
				// options.AddAdditionalCapability(MobileCapabilityType.PlatformName, "Android");
				RemoteWebDriver remoteDriver = new RemoteWebDriver(uri, options.ToCapabilities(), commandTimeout);
				_settings.EnCompassExtentTest.Debug("Got RemoteWebDriver instance, storing Session ID next.");
				_settings.Scenario["SessionId"] = remoteDriver.SessionId.ToString();
				_settings.EnCompassExtentTest.Debug("Session ID stored for the current test : " + _settings.Scenario["SessionId"].ToString());
				return remoteDriver;				
            }
            else
            {
				//options.AddAdditionalCapability("platformName", "iOS");
				IOSDriver<IWebElement> iOSDriver = new IOSDriver<IWebElement>(uri, options, commandTimeout);
				_settings.EnCompassExtentTest.Debug("Got IOSDriver<IWebElement> instance, storing Session ID next.");
				_settings.Scenario["SessionId"] = iOSDriver.SessionId.ToString();
				_settings.EnCompassExtentTest.Debug("Session ID stored for the current test : " + _settings.Scenario["SessionId"].ToString());
				return iOSDriver;
			}
		}

		#endregion
	}
}
