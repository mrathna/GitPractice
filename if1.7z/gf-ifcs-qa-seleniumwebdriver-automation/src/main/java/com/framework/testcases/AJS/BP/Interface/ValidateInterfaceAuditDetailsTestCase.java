package com.framework.testcases.AJS.BP.Interface;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.MaintainCustomerPage;
import com.framework.pages.AJS.common.Common;
import com.framework.pages.AJS.common.IFCSCommonPage;
import com.framework.pages.AJS.common.IFCSHomePage;
import com.framework.pages.AJS.common.IFCSLoginPage;
import com.framework.pages.AJS.common.InterfacePage;

public class ValidateInterfaceAuditDetailsTestCase extends BaseTest {
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "Regression" })
	public void validateAuditDetails(@Optional("AU") String clientCountry, @Optional("BP") String clientName) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  Sys_AU_006_Audit details,BPNZ36_Sys_NZ_006_Audit details",
				"Sys_AU_006_Audit details,BPNZ36_Sys_NZ_006_Audit details");
		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		Common common = new Common(driver, test);
		// Calling Functions
		IFCSloginPage.login("IFCS_URL_BP", "IFCS_BP_USERNAME", "IFCS_BP_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, " ");
		MaintainCustomerPage maintainCustomer = new MaintainCustomerPage(driver, test);
		IFCSCommonPage ifcsCommonPage = new IFCSCommonPage(driver, test);
		InterfacePage interfacePage = new InterfacePage(driver, test);
		String optInProfile, optOutProfile;

		String customerNo = common.getActiveCustomerNoUsingCardType();
		if (customerNo.equals("")) {
			// need to call method to logfail
			common.logForNoDataFound(this.getClass().getSimpleName(),
					"Need to create a rebate profiles for customers and rerun");
		} else {
			IFCSHomePage.gotoCustomerMenuCustomerDetails();
			maintainCustomer.chooseCustomerNoAndSearch(customerNo);
			// Opt in rebate profile
			optInProfile = maintainCustomer.optInARebateProfile();
			// Opt in a rebate and Opt out a rebate - Opt out private profile
			optOutProfile = maintainCustomer.optOutARebateProfile();
			// Run Audit details job - Can be heavy on resources
			String folderName = ifcsCommonPage.getControlMFolder(clientName, clientCountry, "jobS_CardPositiveChanges"+clientCountry);
			String jobsInOrder = ifcsCommonPage.getJobsOfFolderInOrder("jobS_CardPositiveChanges"+clientCountry);
			interfacePage.establishAndExecuteControlMJobs("ControlM_AWS_UAT", "ContorlM_AWS_userName",
					"ContorlM_AWS_password", folderName, jobsInOrder);
			// Verify Audit Details on Cards
			maintainCustomer.validateAuditDetailsForCard(optInProfile, optOutProfile);
	}

		IFCSHomePage.exitIFCS();

	}
}
