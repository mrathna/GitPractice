package com.framework.pages.API.common;

import java.util.HashMap;
import java.util.Map;

import org.json.JSONObject;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;
import com.framework.pages.AJS.common.Common;
import com.framework.util.PropUtils;

public class MerchantMethodsAPI extends CommonAPI {

	public MerchantMethodsAPI(WebDriver driver, ExtentTest test) {
		super(driver, test);
		// TODO Auto-generated constructor stub
	}
	
	public String getMerchantNum(String name) {
		String locationNumber = "Select merchant_no from m_merchants  where name = '" + name + "'";
		return connectDBAndGetValue(locationNumber, PropUtils.getPropValue(configProp, "sqlODSServerName"));
	}
	
	String clientFullName;

	public void createMerchant(String clientName, String clientCountry, String merchantNo, String marketingTerritory) {
		clientFullName = clientCountry.contains("_")
				? PropUtils.getPropValue(configProp, clientName + "_" + clientCountry.split("_")[1])
				: PropUtils.getPropValue(configProp, clientName + "_" + clientCountry);
		Common common = new Common(driver, test);
		
		JSONObject merchantReq = new JSONObject();
		JSONObject streetAddress = new JSONObject();
		
		String date = common.getCurrentIFCSDateFromDB(clientName+clientCountry).substring(0, 10);
		
		
		merchantReq.put("accountNo", "");
	//	merchantReq.put("adminTerritory", getJsonArrayDataForCustomerCreation("/lookup/admin-territories"));
		merchantReq.put("businessCommencedOn", date);
		merchantReq.put("clientName", clientFullName);
		merchantReq.put("channelOfTrade", "Default Channel");
		merchantReq.put("createdOn", date);
		//merchantReq.put("custServiceExpiresOn", "");
		merchantReq.put("currencyCode", "EUR");
		merchantReq.put("emailAddress", "davu@wexinc.com");
		merchantReq.put("externalCode", fakerAPI().number().digits(8));
		merchantReq.put("glChannel", "");
		merchantReq.put("glCostCentre", "GL Cost Center");
		merchantReq.put("isWebAccessRequired", "Y");
		merchantReq.put("isUsingElectronicReporting", "Y");
		merchantReq.put("isUsingElectronicMarketing", "Y");
		merchantReq.put("merchantNo", merchantNo);
		merchantReq.put("language", "Dutch");
		merchantReq.put("marketingTerritory", marketingTerritory);
		merchantReq.put("merchantType", "Default");
		String name = fakerAPI().name().fullName();		
		merchantReq.put("name", name);
		merchantReq.put("phoneBusiness", fakerAPI().number().digits(10));
		merchantReq.put("phoneFax", fakerAPI().number().digits(10));
		merchantReq.put("phoneMobile1", fakerAPI().number().digits(10));
		merchantReq.put("phoneMobile2", fakerAPI().number().digits(10));
		merchantReq.put("pullCode", "");
		merchantReq.put("taxNo", fakerAPI().number().digits(10));
		merchantReq.put("tradingName", fakerAPI().name().firstName());
		
		
		merchantReq.put("streetAddress", streetAddress);
		streetAddress.put("addressLine", fakerAPI().address().fullAddress());
		streetAddress.put("country", clientCountry);
		streetAddress.put("postalCode", fakerAPI().number().digits(4));
		streetAddress.put("suburb", fakerAPI().name().firstName());
		
		response = apiUtils.postRequestAsBearerAuthWithBodyData(PropUtils.getPropValue(configProp, "CREATE_MERCHANT"),
				merchantReq,PropUtils.getPropValue(configProp, "AuthorizationToken"));
		
System.out.println(" Printing the PUT response----->" + 		 response.body().prettyPrint());
		
		if (response.getStatusCode() == 201) {
			logPass("Location was created successfully");
			
			System.out.println("Location NO " +merchantNo +" was created successfully");
		} else {
			logFail("Location Creation Failed"+  response.body().prettyPrint());
		}
		
		
		String merchantNumbeFromDB= getMerchantNum(name);
		Map<String, String> merNo = new HashMap<String, String>();
		merNo.put("Merchnat Number"  + "_" + clientCountry, merchantNumbeFromDB);
		System.out.println("Created Customer Stored in Properties : "+merchantNumbeFromDB +"-->MerchantNumber.properties");
		PropUtils.creatingTempPropFile("locationnumber.properties", merNo);
		
	// {
		/*"accountNo": "2116244223",
		"adminTerritory": "4400 DSA1 DISTRIBUTOR SA",
		"businessCommencedOn": "2020-08-01",
		"clientName": "BP Australia Pty Ltd",
		"channelOfTrade": "Branded Jobber",
		"contactName": "Dohnt",
		"createdOn": "2020-08-01",
		"custServiceExpiresOn": "2022-08-01",
		"currencyCode": "AUD",
		"emailAddress": "nobody@wex.com",
		"externalCode": "ABC",
		"glChannel" : "BPAU02",
		"glCostCentre":"BP0002",
		"isWebAccessRequired":"Y",
		"isUsingElectronicReporting": "Y",
		"isUsingElectronicMarketing": "Y",
		"merchantNo": "9000100483",
		"language":"English (Australia)",
		"marketingTerritory":"4400 DSA1-Distributor SA",
		"merchantType":"Distributor",
		"name":"Dohnt",
		"phoneBusiness":"1234567890",
		"phoneFax":"7417417410",
		"phoneMobile1":"1231231230",
		"phoneMobile2": "4564561230",
		"pullCode":"",
		"taxNo":"73154155227",
		"tradingName":"Dohnt & co",
		"contacts": [
		{
		"contactName": "Dohnt",
		"contactType": "AU Accounts",
		"isDefault": "Y",
		"streetAddress": {
		"addressLine": "LOT 238 PENOLA RD",
		"suburb": "NANGWARRY",
		"postalCode": 5277,
		"country": "AU"
		},
		"postalAddress": {
		"addressLine": "PO BOX 70",
		"suburb": "NANGWARRY",
		"postalCode": 5277,
		"country": "AU"
		},
		"emailAddress": "JDohnt@c.com",
		"phoneBusiness": "1234567890",
		"phoneFax": "1234567874",
		"phoneMobile1": "1234567894",
		"phoneMobile2": "1112223333"
		}],
		"streetAddress": {
		"addressLine": "LOT 238 PENOLA RD",
		"suburb": "NANGWARRY",
		"postalCode": 5277,
		"country": "AU"
		},
		"postalAddress": {
		"addressLine": "PO BOX 70",
		"suburb": "NANGWARRY",
		"postalCode": 5277,
		"country": "AU"
		}
		}
		*/
	}

}
