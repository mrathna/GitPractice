package com.framework.pages.SHELL;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.ExtentTest;
import com.framework.basepage.BasePage;
import com.framework.repo.Locator;

public class SHELLAccountMaintenancePage extends BasePage {

	@FindBy(id=Locator.LOC_ACC_NAME)
	public WebElement accNamecustomerMaintenance; 
	
	@FindBy(id=Locator.PREFERRED_LANGUAGE_DD)
	public WebElement perfLangDD;
	
	@FindBy(xpath=Locator.ACCOUNT_STATUS_DROPDOWN)
	public WebElement accountStatusDD;
	
	@FindBy(id=Locator.ALERT_THRESHOLD_AMOUNT)
	public WebElement alertThresoldAmt;
	
	@FindBy(id=Locator.CUR_AVL_BALANCE)
	public List<WebElement> curAvlBalList;
	
	@FindBy(id=Locator.CUR_AVL_BALANCE)
	public WebElement curAvlBal;
	
	@FindBy(id=Locator.CONTACT_NAME)
	public WebElement contactName;
	
	@FindBy(id=Locator.PHONE_FIELD)
	public WebElement phone;
	
	@FindBy(id=Locator.MOBILE_FIELD)
	public WebElement mobile;
	
	@FindBy(id=Locator.EMAIL_FIELD)
	public WebElement email;
	
	@FindBy(id=Locator.JOBTITLE_FIELD)
	public WebElement jobTitle;
	
	@FindBy(id=Locator.FAX_FIELD)
	public WebElement fax;
	
	@FindBy(id=Locator.CONTACT_LIST_TABLE)
	public WebElement contactListTable;
	
	@FindBy(id= Locator.CONTACT_SAVE)
	public WebElement contactSave;
	
	@FindBy(id= Locator.CONTACT_ADD_A_CONTACT_BACK_CONTACTLIST)
	public WebElement backToCusMaintenance;
	
	
	
	public SHELLAccountMaintenancePage(WebDriver driver, ExtentTest test) {

		super(driver, test);
		PageFactory.initElements(driver, this);
	}  
	
	/*
	 * Verify The account Name
	 * 
	 */
	public void verifyTheAccountName(String cusAccName)
	{
		checkTextInPageAndValidate("Details", 30);
		
		isDisplayed(accNamecustomerMaintenance, "Account Name in Customer Maintenance Page");
		
		String accName = getText(accNamecustomerMaintenance);
		
		
		if(!cusAccName.equals(accName))
		{
			
			logInfo("Not Same as the Default account:----"+cusAccName+" ------- Account in Customer Maintenance page== "+accName);
			
			logPass("Account Name is verified, AccountName is not same as the defacult account");
		}
		else
		{
			logInfo("Not Same as the Default account:----"+cusAccName+" ------- Account in Customer Maintenance page== "+accName);
			
			logPass("Account Name is verified, Both Account Name in Customer maintenance page and Default account name in home page are same.");
		}
	}
	
	
	/*
	 * Change The Preferred Language and Validate
	 * 
	 */	
	public void changeThePreferredLangAndValidate()
	{
		isDisplayed(perfLangDD, "Preferred Language Drop down");
		
		selectDropDownByVisibleText(perfLangDD, "English (Singapore)");
		
		sleep(5);
		
		String accountName = selectedStringFrmDropDown(perfLangDD);
		
		if(accountName.equals("English (Singapore)"))
		{
			logPass("Selected the "+accountName);
		}
		else
		{
			logFail("Not selected the "+accountName);
		}
		
	}
	
	/*
	 * Change the Account Status in Drop down
	 * 
	 */
	public void changeTheAccountStatus()
	{
		isDisplayed(accountStatusDD, "Account Status Drop down");
		
		String defaultAccStatus = selectedStringFrmDropDown(accountStatusDD);
		
		selectDifferentValueInsteadOfDefault(accountStatusDD, defaultAccStatus, "");
		
		sleep(5);
		
		String afterChangeStatus = selectedStringFrmDropDown(accountStatusDD);
		
		if(!defaultAccStatus.equals(afterChangeStatus))
		{
			logPass(afterChangeStatus+" new status selected");
		}
		
		else
		{
			logFail(afterChangeStatus+" new Status is not selected");
		}
		
	}

	/*
	 * Validate The Fields or Disabled or not
	 * 
	 */
	
	public void validateTheFiledsAreDisabledOrNot() {
		// TODO Auto-generated method stub
		
		scrollDownPage();
		scrollDownPage();
		
		boolean isCurAvlBal = checkOptionalElementIsPresentOrNot(curAvlBalList);
		if(isCurAvlBal)
			checkAnElementIsDisabled(curAvlBal, "Current Available Balance (€)");
		checkAnElementIsDisabled(contactName, "Contact Name");
		checkAnElementIsDisabled(phone, "Phone");	
		checkAnElementIsDisabled(jobTitle, "Job Title");
		checkAnElementIsDisabled(alertThresoldAmt, "Alert Threshold Amount (€)");		
		// below two fields are enabled
		checkAnElementIsDisabled(email, "Email");
		checkAnElementIsDisabled(mobile, "Mobile");
		checkAnElementIsDisabled(fax, "Fax");
		
		
	}

	/*
	 * Validate The contacts List
	 * 
	 * 
	 */
	public void validateTheContactsList() {
		// TODO Auto-generated method stub
		
		checkTextInPageAndValidate("Contacts List", 30);
		
		boolean isContactsNotPresent = waitForTextToAppear("No items found.", 20);
		
		if(isContactsNotPresent)
		{
			logPass("No Contacts Present for the Account");
		}
		
		else
		{
			verifyThecontactsFunctionality();
		}
				 
		scrollToTopPage();
		
	}
	
	/**
	 * 
	 * Verify the Contacts functionality before the footer.
	 */
	
	public void verifyThecontactsFunctionality()
	{
		isDisplayed(contactListTable, "Contact List Table");
		
		selectFirstColumnAndChooseMenu(contactListTable, null, "", false);
		
		checkTextInPageAndValidate("EDIT CONTACT", 30);
		
		checkTextInPageAndValidate("Contact Detail", 30);

		String emailVal = fakerAPI().internet().emailAddress();

		String PhoneVal = fakerAPI().internet().emailAddress();

		String mobileVal = fakerAPI().internet().emailAddress();

		String jobTitleVal = fakerAPI().internet().emailAddress();

		String faxVal = fakerAPI().internet().emailAddress();

		isDisplayedThenEnterText(email, "Email Field", emailVal);
		
		isDisplayedThenEnterText(phone, "Phone Field", PhoneVal);
		
		isDisplayedThenEnterText(mobile, "Mobile Field", mobileVal);
		
		isDisplayedThenEnterText(jobTitle, "Job title Field", jobTitleVal);
		
		isDisplayedThenEnterText(fax, "Fax Field", faxVal);		
		 
		scrollDownPage();
		
		isDisplayedThenClick(contactSave, "Contact Save");
		
		sleep(3);
		
		scrollToTopPage();
		
		checkTextInPageAndValidate("Successfully Saved Contact", 30);
		
		isDisplayedThenClick(backToCusMaintenance, "Back to Customer Maintenance");
		
		sleep(3);
		
		checkTextInPageAndValidate("ACCOUNT MAINTENANCE", 30);
		
		
	}
	
	
}
