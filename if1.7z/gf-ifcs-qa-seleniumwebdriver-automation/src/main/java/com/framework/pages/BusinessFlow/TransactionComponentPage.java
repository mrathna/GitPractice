package com.framework.pages.BusinessFlow;

import java.io.File;
import java.math.RoundingMode;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.aventstack.extentreports.ExtentTest;
import com.framework.basepage.BasePage;
import com.framework.pages.AJS.MaintainCustomerPage;
import com.framework.pages.AJS.TransactionListPage;
import com.framework.pages.AJS.common.Common;
import com.framework.pages.AJS.common.CommonInterfacePage;
import com.framework.pages.AJS.common.IFCSCommonPage;
import com.framework.pages.AJS.common.IFCSHomePage;
import com.framework.pages.AJS.common.InterfacePage;
import com.framework.repo.Locator_IFCS;
import com.framework.util.PropUtils;
import com.framework.util.SeleniumWrappers;
import com.github.javafaker.Faker;

public class TransactionComponentPage extends Common {

	@FindBy(xpath = Locator_IFCS.SEARCH_CARDS_TEXTBOX)
	public List<WebElement> textBoxes;
	
	@FindBy(xpath = Locator_IFCS.POPUP_MENUITEM_SORT)
	public WebElement popupMenuItemSort;
	
	@FindBy(xpath = Locator_IFCS.POPUP_MENUITEM_DETAILS)
	public WebElement poupMenuItemDetails;

	public TransactionComponentPage(WebDriver driver, ExtentTest test) {
		super(driver, test);
		PageFactory.initElements(new AjaxElementLocatorFactory(driver, 15), this);
	}

	/*
	 * Validate Transaction Posting in DB Validate Suspended Transaction Posting in
	 * DB
	 * 
	 */
	public void validateTransactionPostedOrNot(Map<String, String> refNoAndAmount, String msg) {
		CommonInterfacePage CommonInterfacePage = new CommonInterfacePage(driver, test);
		int i = 0;
		Map<String, String> refNoKeyAndValues = new HashMap<String, String>();
		for (String refNo : refNoAndAmount.keySet()) {
			String transactionAmount = CommonInterfacePage.getTransactionAmount(refNo);
			System.out.println("from parameter::" + Float.parseFloat(refNoAndAmount.get(refNo)) / 100);
			boolean transactionPos = true;
			try {
				Float.parseFloat(transactionAmount);
			} catch (Exception ex) {
				transactionPos = false;
				String suspended = "select was_corrected from suspended_line_items where pos_transaction_oid=(select pos_transaction_oid from pos_transactions where reference='"
						+ refNo + "')";
				if (connectDBAndGetValue(suspended, PropUtils.getPropValue(configProp, "sqlODSServerName")).toString()
						.equals("N")) {
					String suspendedTrans = "select Description from suspended_transactions st\r\n"
							+ "inner join transaction_errors te on te.transaction_error_oid = st.transaction_error_oid\r\n"
							+ "where pos_transaction_oid=(select pos_transaction_oid from pos_transactions where reference='"
							+ refNo + "')";
					String error = connectDBAndGetValue(suspendedTrans,
							PropUtils.getPropValue(configProp, "sqlODSServerName"));
					System.out.println("error::" + error);
					if (error.equalsIgnoreCase(msg)) {
						logInfo("Transaction Moved to Suspended" + refNo);
						refNoKeyAndValues.put("SuspendedTransRefNo" + i, refNo);
					} else {
						logFail("Transaction not Posted for" + refNo);
					}
				} else {
					logFail("Transaction not Posted for" + refNo);
				}
			}
			if (transactionPos) {
				System.out.println("from db::" + Float.parseFloat(transactionAmount));
				if (!(transactionAmount.equals(""))) {
					if (Float.parseFloat(transactionAmount) == ((Float.parseFloat(refNoAndAmount.get(refNo))) / 100)) {
						refNoKeyAndValues.put("RefNo" + i, refNo);
						logPass("Transaction Posted for" + refNo);
					} else {
						logFail("Transaction not Posted for" + refNo);
					}
				} else {
					logFail("Transaction not Posted for" + refNo);
				}
			}

			i++;
		}
		PropUtils.creatingTempPropFile("TransactionReferenceNos.properties", refNoKeyAndValues);

	}

	/*
	 * XML Creation for Transaction Posting Upload XMl File in IFCS Server LoadCard
	 * Transaction Batch job execution Transaction processing control-m job
	 * execution
	 */
	public Map<String, String> XMLCreationForTransaction(String clientName, String clientCountry,
			Map<String, String> inputvalues) throws TransformerException {

		Map<String, String> dbvalue = null;
		Map<String, String> valuesForValidation = new LinkedHashMap<String, String>();
		String folderName = null, jobsInOrder = null, refNo = null;

		int k, netValue = 0;
		Common common = new Common(driver, test);
		IFCSCommonPage ifcsCommonPage = new IFCSCommonPage(driver, test);
		CommonInterfacePage CommonInterfacePage = new CommonInterfacePage(driver, test);
		InterfacePage interfacePage = new InterfacePage(driver, test);
		IFCSHomePage ifcsHomePage = new IFCSHomePage(driver, test);

		String[] headertag = { "FileName", "SequenceNumber", "RecordCount", "CountryCode", "StartDate", "StartTime",
				"ExternalSupplier", "SettlementDate", "ExternalFileName" };
		String[] loadTransaction = { "Transaction", "Card", "Location", "Terminal", "Vehicle", "TransactionLineItem" };
		String[] card = { "CardNumber", "CardType" };
		String[] transaction = { "CaptureTypeCode", "TransactionCode", "AttentionKey", "ReferenceNumber", "OrderNumber",
				"FleetNumber", "SubEntityNumber", "TransactionDateTime", "AuthorisationNumber", "OdometerReading",
				"BatchNumber", "BatchSource", "ExtraCardNo" };
		String[] location = { "IdassNumber", "StreetAddressState", "RetailSiteId", "MarketingTerritory",
				"AdminTerritory" };
		String[] terminal = { "PhysicalTerminalId", "TerminalStatus", "TerminalType" };
		String[] vehicle = { "RegistrationNumber", "CurrentOdometerReading" };
		String[] lineitem = { "LineItemCode", "Quantity", "UnitPrice", "NetValue" };

		String folderid = CommonInterfacePage.getfolderid(clientName, clientCountry);
		int cardListCount = 1;
		String client_mid = CommonInterfacePage.funcFetchLoadCardTransClientMidFromDB(configProp, clientName,
				clientCountry);
		String remotedir;
		if (clientName.equalsIgnoreCase("BP")) {
			remotedir = PropUtils.getPropValue(configProp, "IFCS_LOADCARDTRANSACTION") + folderid + "/";
		} else {
			remotedir = PropUtils.getPropValue(configProp, "IFCS_LOADCARDTRANSACTION") + client_mid + "/" + folderid
					+ "/";
		}
		try {
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			Document doc = docBuilder.newDocument();
			// students root element
			Element rootElement = doc.createElement("LoadCardTransactions");
			doc.appendChild(rootElement);

			Element header = doc.createElement("Header");
			rootElement.appendChild(header);
			dbvalue = CommonInterfacePage.fetchLoadCardTransSeqNoandPrefix(configProp, clientName, clientCountry,
					folderid);
			String filename = dbvalue.get("prefixvalue") + dbvalue.get("lastSequenceNumber") + ".xml";
			System.out.println(dbvalue);
			for (k = 0; k < headertag.length; k++) {
				Element subtag = doc.createElement(headertag[k]);
				if (headertag[k].equalsIgnoreCase("FileName")) {
					System.out.println(
							"file Name:" + dbvalue.get("prefixvalue") + dbvalue.get("lastSequenceNumber") + ".xml");
					subtag.setTextContent(dbvalue.get("prefixvalue") + dbvalue.get("lastSequenceNumber") + ".xml");
				} else if (headertag[k].equalsIgnoreCase("SequenceNumber")) {
					subtag.setTextContent(dbvalue.get("lastSequenceNumber"));
				} else if (headertag[k].equalsIgnoreCase("RecordCount")) {
					subtag.setTextContent(Integer.toString(cardListCount));
				} else if (headertag[k].equalsIgnoreCase("CountryCode") && clientName.equalsIgnoreCase("CHEVRON")) {
					subtag.setTextContent("CHEV" + "_" + clientCountry);
				} else if (headertag[k].equalsIgnoreCase("CountryCode")) {
					subtag.setTextContent(clientCountry);
				} else if (headertag[k].equalsIgnoreCase("StartDate")) {
					subtag.setTextContent(inputvalues.get("date").split(" ")[0]);
				} else if (headertag[k].equalsIgnoreCase("StartTime")) {
					subtag.setTextContent(inputvalues.get("date").split(" ")[1]);
				} else if (headertag[k].equalsIgnoreCase("ExternalSupplier")) {
					String externalSupplier = CommonInterfacePage.getExternalSupplier(clientName, clientCountry);
					subtag.setTextContent(externalSupplier);
				} else if (headertag[k].equalsIgnoreCase("SettlementDate")) {
					subtag.setTextContent(inputvalues.get("date").split(" ")[0]);
				} else if (headertag[k].equalsIgnoreCase("Identifier")
						&& (clientName.equalsIgnoreCase("EMAP") || clientName.equalsIgnoreCase("OTI"))) {
					subtag.setTextContent("Y");
				}

				header.appendChild(subtag);
			}
			Faker faker = new Faker();
			Element subtag = null;
			Element loadCardTransactionsubtag = null;

			for (int i = 0; i < cardListCount; i++) {

				Element loadCardTransaction = doc.createElement("LoadCardTransaction");

				for (int j = 0; j < loadTransaction.length; j++) {

					loadCardTransactionsubtag = doc.createElement(loadTransaction[j]);
					if (loadTransaction[j].equalsIgnoreCase("Transaction")) {
						for (k = 0; k < transaction.length; k++) {
							subtag = doc.createElement(transaction[k]);
							if (transaction[k].equalsIgnoreCase("TransactionDateTime")) {
								subtag.setTextContent(inputvalues.get("date").replace(" ", "T"));
							} else if (transaction[k].equalsIgnoreCase("AuthorisationNumber")) {
								String value = faker.number().digits(6);
								subtag.setTextContent(value);
							} else if (transaction[k].equalsIgnoreCase("ReferenceNumber")) {
								refNo = common.getUniqReferenceNumber();
								System.out.println("Ref No:" + refNo);
								subtag.setTextContent(refNo);
							} else if (transaction[k].equalsIgnoreCase("BatchNumber")) {
								String value = faker.number().digits(6);
								subtag.setTextContent(value);
							} else if (transaction[k].equalsIgnoreCase("BatchSource")) {
								if (clientCountry.equals("NZ") && clientName.equals("BP")) {
									subtag.setTextContent("POS");
								} else if (clientCountry.equals("MY") && clientName.equals("CHEVRON")) {
									subtag.setTextContent("AMB");
								} else {
									subtag.setTextContent("EFT");
								}
							} else if (clientCountry.contains("ZEnergy")
									&& transaction[k].equalsIgnoreCase("OriginalAmount")) {
								// depends on TransactionLineItems
							} else if (transaction[k].equalsIgnoreCase("CaptureTypeCode")) {
								if ((clientName.equalsIgnoreCase("CHEVRON") && clientCountry.equalsIgnoreCase("MY"))
										|| clientName.equalsIgnoreCase("BP")) {
									String value = PropUtils.getPropValue(loadCardTransactionPurchaseProp,
											"TRANSCODE_PURCHASE_" + clientName + clientCountry);
									subtag.setTextContent(value.split(",")[1]);
								} else {
									String value = PropUtils.getPropValue(loadCardTransactionPurchaseProp,
											"TRANSCODE_PURCHASE_" + clientName);
									subtag.setTextContent(value.split(",")[1]);
								}

							} else if (transaction[k].equalsIgnoreCase("TransactionCode")) {
								if ((clientName.equalsIgnoreCase("CHEVRON") && clientCountry.equalsIgnoreCase("MY"))
										|| clientName.equalsIgnoreCase("BP")) {
									String value = PropUtils.getPropValue(loadCardTransactionPurchaseProp,
											"TRANSCODE_PURCHASE_" + clientName + clientCountry);
									subtag.setTextContent(value.split(",")[0]);
								} else {
									String value = PropUtils.getPropValue(loadCardTransactionPurchaseProp,
											"TRANSCODE_PURCHASE_" + clientName);
									subtag.setTextContent(value.split(",")[0]);
								}
							} else if (transaction[k].equalsIgnoreCase("OdometerReading")) {
								subtag.setTextContent(inputvalues.get("OdometerReading"));
							}
							loadCardTransactionsubtag.appendChild(subtag);
						}

					}

					if (loadTransaction[j].equalsIgnoreCase("Card")) {
						for (k = 0; k < card.length; k++) {
							subtag = doc.createElement(card[k]);
							if (card[k].equalsIgnoreCase("CardNumber")) {

								subtag.setTextContent(inputvalues.get("CardNumber"));
								// valuesForValidation.put(refNo, inputvalues.get("CardNumber"));
							}
							loadCardTransactionsubtag.appendChild(subtag);
						}
					}
					if (loadTransaction[j].equalsIgnoreCase("Location")) {
						for (k = 0; k < location.length; k++) {
							subtag = doc.createElement(location[k]);
							if (location[k].equals("IdassNumber")) {
								subtag.setTextContent(inputvalues.get("LocationNumber"));
							}

							if (clientName.equalsIgnoreCase("Chevron")) {
								if (location[k].equals("RetailSiteId")) {
									subtag.setTextContent(inputvalues.get("LocationNumber"));
								}
							}
							loadCardTransactionsubtag.appendChild(subtag);
						}
					}

					if (loadTransaction[j].equalsIgnoreCase("Terminal")) {
						for (k = 0; k < terminal.length; k++) {
							subtag = doc.createElement(terminal[k]);
							if (clientName.equalsIgnoreCase("BP")) {

								if (terminal[k].equals("PhysicalTerminalId")) {
									subtag.setTextContent("77");

								}
							}
							loadCardTransactionsubtag.appendChild(subtag);
						}
					}
					if (loadTransaction[j].equalsIgnoreCase("Vehicle")) {
						for (k = 0; k < vehicle.length; k++) {
							subtag = doc.createElement(vehicle[k]);
							if (vehicle[k].equalsIgnoreCase("CurrentOdometerReading")) {
								subtag.setTextContent(inputvalues.get("CurrentOdometerReading"));
							} else if (vehicle[k].equalsIgnoreCase("RegistrationNumber")) {
								subtag.setTextContent(inputvalues.get("RegistrationNumber"));
							}
							loadCardTransactionsubtag.appendChild(subtag);
						}
					}

					if (loadTransaction[j].equalsIgnoreCase("TransactionLineItem")) {

						for (k = 0; k < lineitem.length; k++) {
							Element TransactionLineItemsSubtag = doc.createElement(lineitem[k]);

							if (lineitem[k].equalsIgnoreCase("LineItemCode")) {
								System.out.println("prdcode" + inputvalues.get("productCode"));
								TransactionLineItemsSubtag.setTextContent(inputvalues.get("productCode"));
							}
							if (lineitem[k].equalsIgnoreCase("Quantity")) {
								TransactionLineItemsSubtag.setTextContent(inputvalues.get("volume"));
							}
							if (lineitem[k].equalsIgnoreCase("UnitPrice")) {
								TransactionLineItemsSubtag.setTextContent(inputvalues.get("unitPrice"));
							}
							if (lineitem[k].equalsIgnoreCase("NetValue")) {
								System.out.println("volume" + Integer.parseInt(inputvalues.get("volume")));
								System.out.println("unit price" + Integer.parseInt(inputvalues.get("unitPrice")));
								netValue = ((Integer.parseInt(inputvalues.get("volume")) / 100)
										* ((Integer.parseInt(inputvalues.get("unitPrice")) / 100)) / 100);
								System.out.println("net value::" + netValue);
								TransactionLineItemsSubtag.setTextContent(Integer.toString(netValue) + "00");
								valuesForValidation.put(refNo, Integer.toString(netValue) + "00");
							}
							loadCardTransactionsubtag.appendChild(TransactionLineItemsSubtag);
						}
					}

					loadCardTransaction.appendChild(loadCardTransactionsubtag);
				}

				rootElement.appendChild(loadCardTransaction);

			}
			System.out.println(valuesForValidation);
			// Write the content into XML file
			DOMSource source = new DOMSource(doc);
			StreamResult result = new StreamResult(new File("LoadCardTransaction.xml"));

			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer = transformerFactory.newTransformer();

			transformer.setOutputProperty(OutputKeys.INDENT, "yes");
			transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "4");
			transformer.transform(source, result);

			result = new StreamResult(new File(System.getProperty("user.home") + System.getProperty("file.separator")
					+ "Documents" + System.getProperty("file.separator") + filename));
			System.out.println(filename);
			transformer.transform(source, result);

			ifcsCommonPage.establishThePuttyConnectionbyUserGeneratedRemoteDirectory("XML", "PUTTY_HOST",
					"PUTTY_USERNAME", "PUTTY_PASSWORD", remotedir, filename);

			ifcsCommonPage.interfaceBatchJobwithIFCSLogin(clientName, clientCountry, folderid);
			ifcsHomePage.exitIFCS();
			if (clientName.equals("BP") || clientName.equals("CHEVRON")) {
				folderName = ifcsCommonPage.getControlMFolder(clientName, clientCountry,
						"jobS_LoadcardTransactions_" + clientName + "_" + clientCountry);
				jobsInOrder = ifcsCommonPage
						.getJobsOfFolderInOrder("jobS_LoadcardTransactions_" + clientName + "_" + clientCountry);
			} else {
				folderName = ifcsCommonPage.getControlMFolder(clientName, clientCountry,
						"jobS_LoadcardTransactions_" + clientName);
				jobsInOrder = ifcsCommonPage.getJobsOfFolderInOrder("jobS_LoadcardTransactions_" + clientName);
			}
			interfacePage.establishAndExecuteControlMJobs("ControlM_AWS_UAT", "ContorlM_AWS_userName",
					"ContorlM_AWS_password", folderName, jobsInOrder);

		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return valuesForValidation;
	}

	/*
	 * Raxsana added Getting InputValues from DB for Invalid Product Code XML
	 * Creation
	 */
	public Map<String, String> inputValuesForInvalidProductCode(String clientName, String clientCountry) {
		Map<String, String> inputValues = new HashMap<String, String>();
		Map<String, String> lineItem = null;
		String locNumber = null;
		String cardNumber = null;
		Common common = new Common(driver, test);
		CommonInterfacePage CommonInterfacePage = new CommonInterfacePage(driver, test);

		String clientNameInProp = PropUtils.getPropValue(configProp, clientName + "_" + clientCountry);
		String date = CommonInterfacePage.funcFetchLoadCardTransStartDateFromIFCSDB(configProp, clientNameInProp);
		inputValues.put("date", date);

		cardNumber = common.getCardNumberFromIFCSDB(clientName, clientCountry, "Active");
		inputValues.put("CardNumber", cardNumber);

		lineItem = CommonInterfacePage.getTransactionLineItem(configProp, cardNumber, clientName, clientCountry);
		inputValues.putAll(lineItem);

		if (clientName.equalsIgnoreCase("Chevron")) {
			locNumber = common.getExternalRefNoFromDB(clientName, clientCountry);
		} else {
			locNumber = common.getLocationNoFromIFCSDB(clientName, clientCountry, lineItem.get("productCode"));
		}
		inputValues.put("LocationNumber", locNumber);

		String invalidProductCode = "00";
		inputValues.put("productCode", invalidProductCode);

		return inputValues;
	}

	/*
	 * Raxsana added 23/04/2020 Getting InputValues from DB for Invalid Location XML
	 * Creation Updated by davu
	 */
	public Map<String, String> inputValuesForInvalidLocation(String clientName, String clientCountry) {

		Map<String, String> inputValues = new HashMap<String, String>();

		Map<String, String> lineItem = null;
		String locNumber = null, cardNumber = null;

		Common common = new Common(driver, test);
		CommonInterfacePage CommonInterfacePage = new CommonInterfacePage(driver, test);

		String clientNameInProp = PropUtils.getPropValue(configProp, clientName + "_" + clientCountry);
		if (clientName.equalsIgnoreCase("WFE")) {
			String currentDate = common.getCurrentIFCSDateFromDB(clientNameInProp);
			// Get the IFCS current date
			String ifcsCurrentDate = common.enterADateValueInStatusBeginDateField("Current", currentDate);
			inputValues.put("date", ifcsCurrentDate);
		} else {
			String date = CommonInterfacePage.funcFetchLoadCardTransStartDateFromIFCSDB(configProp, clientNameInProp);
			inputValues.put("date", date);
		}

		cardNumber = common.getCardNumberFromIFCSDB(clientName, clientCountry, "Active");
		inputValues.put("CardNumber", cardNumber);

		lineItem = CommonInterfacePage.getTransactionLineItem(configProp, cardNumber, clientName, clientCountry);
		inputValues.putAll(lineItem);

		if (clientName.equalsIgnoreCase("Chevron")) {
			locNumber = fakerAPI().number().digits(16);
		} else {
			String locNumberSub = fakerAPI().number().digits(6);

			if (clientCountry.equals("BE")) {
				locNumber = "032" + locNumberSub;
			} else if (clientCountry.equals("NL")) {
				locNumber = "031" + locNumberSub;
			} else if (clientCountry.equals("FR")) {
				locNumber = "033" + locNumberSub;
			} else if (clientCountry.equals("LU")) {
				locNumber = "352" + locNumberSub;
			} else if (clientCountry.equals("DE")) {
				locNumber = "049" + locNumberSub;
			}
			else {
				locNumber = fakerAPI().number().digits(6);
			}
		}

		inputValues.put("LocationNumber", locNumber);

		return inputValues;
	}

	public Map<String, String> inputValuesForOverCreditLimit(String clientName, String clientCountry) {

		Map<String, String> inputValues = new HashMap<String, String>();

		Map<String, String> lineItem = null;
		String locNumber = null, cardNumber = null;
		WFECommon wfeCommon=new WFECommon(driver,test);
		Common common = new Common(driver, test);
		CommonInterfacePage CommonInterfacePage = new CommonInterfacePage(driver, test);

		String clientNameInProp = PropUtils.getPropValue(configProp, clientName + "_" + clientCountry);
		String date = CommonInterfacePage.funcFetchLoadCardTransStartDateFromIFCSDB(configProp, clientNameInProp);
		inputValues.put("date", date);

		String customerNo = common.getCustomerWithLowCriditLimit(clientName, clientCountry);

		cardNumber = common.getActiveCardOfTheCustomer(customerNo, clientName, clientCountry);
		inputValues.put("CardNumber", cardNumber);

		lineItem = CommonInterfacePage.getTransactionLineItem(configProp, cardNumber, clientName, clientCountry);
		inputValues.putAll(lineItem);

		if (clientName.equalsIgnoreCase("Chevron")) {
			locNumber = common.getExternalRefNoFromDB(clientName, clientCountry);
		} else if(clientName.equalsIgnoreCase("WFE")){
			locNumber = wfeCommon.getLocationNumberForWFE(clientName, clientCountry);
		}else {
			locNumber = common.getLocationNoFromIFCSDB(clientName, clientCountry, lineItem.get("productCode"));
		}
		inputValues.put("LocationNumber", locNumber);

		return inputValues;

	}

	public Map<String, String> inputValuesForOverVelocityLimit(String clientName, String clientCountry,String velocityValue) {

		Map<String, String> inputValues = new HashMap<String, String>();

		Map<String, String> lineItem = null;
		String locNumber = null, cardNumber = null;

		Common common = new Common(driver, test);
		CommonInterfacePage CommonInterfacePage = new CommonInterfacePage(driver, test);
		WFECommon wfecommon = new WFECommon(driver, test);

		String clientNameInProp = PropUtils.getPropValue(configProp, clientName + "_" + clientCountry);
		String date = CommonInterfacePage.funcFetchLoadCardTransStartDateFromIFCSDB(configProp, clientNameInProp);
		inputValues.put("date", date);

		cardNumber = wfecommon.getCardNumberWithLowVelocityValue(clientName + "_" + clientCountry, velocityValue);

		inputValues.put("CardNumber", cardNumber);

		lineItem = CommonInterfacePage.getTransactionLineItem(configProp, cardNumber, clientName, clientCountry);
		inputValues.putAll(lineItem);

		String queryToGetLocNo = "select distinct external_code from m_locations where\r\n"
				+ "client_mid=(select client_mid from m_clients where name='"
				+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountry) + "') ";
		locNumber = common.connectDBAndGetValue(queryToGetLocNo,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		inputValues.put("LocationNumber", locNumber);

		return inputValues;

	}

	public Map<String, String> validInputValues(String clientName, String clientCountry) {

		Map<String, String> inputValues = new HashMap<String, String>();

		Map<String, String> lineItem = null;
		String locNumber = null, cardNumber = null;

		Common common = new Common(driver, test);
		CommonInterfacePage CommonInterfacePage = new CommonInterfacePage(driver, test);

		String clientNameInProp = PropUtils.getPropValue(configProp, clientName + "_" + clientCountry);
		String date = CommonInterfacePage.funcFetchLoadCardTransStartDateFromIFCSDB(configProp, clientNameInProp);
		inputValues.put("date", date);

		cardNumber = common.getCardNumberFromIFCSDB(clientName, clientCountry, "Active");
		inputValues.put("CardNumber", cardNumber);

		lineItem = CommonInterfacePage.getTransactionLineItem(configProp, cardNumber, clientName, clientCountry);
		inputValues.putAll(lineItem);

		if (clientName.equalsIgnoreCase("Chevron")) {
			locNumber = common.getExternalRefNoFromDB(clientName, clientCountry);
		} else {
			locNumber = common.getLocationNoFromIFCSDB(clientName, clientCountry, lineItem.get("productCode"));
		}
		inputValues.put("LocationNumber", locNumber);

		return inputValues;

	}

	public Map<String, String> inputValuesForDamagedCard(String clientName, String clientCountry) {

		Map<String, String> inputValues = new HashMap<String, String>();

		Map<String, String> lineItem = null;
		String locNumber = null, cardNumber = null;

		Common common = new Common(driver, test);
		CommonInterfacePage CommonInterfacePage = new CommonInterfacePage(driver, test);

		String clientNameInProp = PropUtils.getPropValue(configProp, clientName + "_" + clientCountry);
		String date = CommonInterfacePage.funcFetchLoadCardTransStartDateFromIFCSDB(configProp, clientNameInProp);
		inputValues.put("date", date);

		cardNumber = common.getCardNumberFromIFCSDB(clientName, clientCountry, "Card Damaged");
		inputValues.put("CardNumber", cardNumber);

		lineItem = CommonInterfacePage.getTransactionLineItem(configProp, cardNumber, clientName, clientCountry);
		inputValues.putAll(lineItem);

		if (clientName.equalsIgnoreCase("Chevron")) {
			locNumber = common.getExternalRefNoFromDB(clientName, clientCountry);
		} else {
			locNumber = common.getLocationNoFromIFCSDB(clientName, clientCountry, lineItem.get("productCode"));
		}
		inputValues.put("LocationNumber", locNumber);

		return inputValues;

	}

	public Map<String, String> inputValuesForLostCard(String clientName, String clientCountry) {

		Map<String, String> inputValues = new HashMap<String, String>();

		Map<String, String> lineItem = null;
		String locNumber = null, cardNumber = null;
		WFECommon wfeCommon=new WFECommon(driver,test);
		Common common = new Common(driver, test);
		CommonInterfacePage CommonInterfacePage = new CommonInterfacePage(driver, test);

		String clientNameInProp = PropUtils.getPropValue(configProp, clientName + "_" + clientCountry);
		String date = CommonInterfacePage.funcFetchLoadCardTransStartDateFromIFCSDB(configProp, clientNameInProp);
		inputValues.put("date", date);

		cardNumber = common.getCardNumberFromIFCSDB(clientName, clientCountry, "Card Lost");
		inputValues.put("CardNumber", cardNumber);

		lineItem = CommonInterfacePage.getTransactionLineItem(configProp, cardNumber, clientName, clientCountry);
		inputValues.putAll(lineItem);

		if (clientName.equalsIgnoreCase("Chevron")) {
			locNumber = common.getExternalRefNoFromDB(clientName, clientCountry);
		} else if(clientName.equalsIgnoreCase("WFE")){
			locNumber = wfeCommon.getLocationNumberForWFE(clientName, clientCountry);
		}else {
			locNumber = common.getLocationNoFromIFCSDB(clientName, clientCountry, lineItem.get("productCode"));
		}
		inputValues.put("LocationNumber", locNumber);

		return inputValues;

	}

	/*
	 * Raxsana added 23/04/2020 Getting InputValues from DB for Future Date and Time
	 * XML Creation
	 */
	public Map<String, String> inputValuesForFutureDateAndTime(String clientName, String clientCountry) {

		Map<String, String> inputValues = new HashMap<String, String>();
		Map<String, String> lineItem = null;
		String locNumber = null, cardNumber = null, dateValue = null;

		Common common = new Common(driver, test);
		CommonInterfacePage CommonInterfacePage = new CommonInterfacePage(driver, test);
		String clientNameInProp = PropUtils.getPropValue(configProp, clientName + "_" + clientCountry);

		cardNumber = common.getCardNumberFromIFCSDB(clientName, clientCountry, "Active");
		inputValues.put("CardNumber", cardNumber);

		String date = CommonInterfacePage.funcFetchLoadCardTransStartDateFromIFCSDB(configProp, clientNameInProp);

		try {
			DateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
			dateFormatter.parse(date);
			Date newDate;
			Calendar cal = Calendar.getInstance();
			cal.setTime(dateFormatter.parse(date));
			cal.add(Calendar.MONTH, +3);

			newDate = cal.getTime();
			DateFormat df = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
			dateValue = df.format(newDate);

		} catch (Exception e) {
			e.printStackTrace();
		}
		inputValues.put("date", dateValue);

		lineItem = CommonInterfacePage.getTransactionLineItem(configProp, cardNumber, clientName, clientCountry);
		inputValues.putAll(lineItem);

		if (clientName.equalsIgnoreCase("Chevron")) {
			locNumber = common.getExternalRefNoFromDB(clientName, clientCountry);
		} else {
			locNumber = common.getLocationNoFromIFCSDB(clientName, clientCountry, lineItem.get("productCode"));
		}
		inputValues.put("LocationNumber", locNumber);

		return inputValues;

	}

	public Map<String, String> inputValuesForInvalidUnitPrice(String clientName, String clientCountry) {

		Map<String, String> inputValues = new HashMap<String, String>();
		Map<String, String> lineItem = null;
		String locNumber = null, cardNumber = null;

		Common common = new Common(driver, test);
		CommonInterfacePage CommonInterfacePage = new CommonInterfacePage(driver, test);

		String clientNameInProp = PropUtils.getPropValue(configProp, clientName + "_" + clientCountry);
		String date = CommonInterfacePage.funcFetchLoadCardTransStartDateFromIFCSDB(configProp, clientNameInProp);
		inputValues.put("date", date);

		cardNumber = common.getCardNumberFromIFCSDB(clientName, clientCountry, "Active");
		inputValues.put("CardNumber", cardNumber);

		lineItem = CommonInterfacePage.getTransactionLineItem(configProp, cardNumber, clientName, clientCountry);
		inputValues.putAll(lineItem);
		/*
		 * String maxUnitPrice="select maximum_unit_price from product_thresholds \r\n"
		 * + "where client_mid=(select client_mid from m_clients where name='"
		 * +clientNameInProp+"') and rownum=1";
		 */

		String maxUnitPrice = "select pthr.maximum_unit_price from product_thresholds pthr "
				+ "inner join product_translations pt on pt.product_oid=pthr.product_oid "
				+ "where pthr.client_mid=(select client_mid from m_clients where name='" + clientNameInProp + "') "
				+ "and pt.external_code='" + lineItem.get("EXTERNAL_CODE") + "'and rownum=1";
		String unitPrice = connectDBAndGetValue(maxUnitPrice, PropUtils.getPropValue(configProp, "sqlODSServerName"));
		System.out.println("before::" + unitPrice);
		System.out.println("after::" + String.valueOf(Integer.parseInt(unitPrice) + 100) + "00");
		inputValues.put("unitPrice", String.valueOf(Integer.parseInt(unitPrice) + 100) + "00");

		if (clientName.equalsIgnoreCase("Chevron")) {
			locNumber = common.getExternalRefNoFromDB(clientName, clientCountry);
		} else {
			locNumber = common.getLocationNoFromIFCSDB(clientName, clientCountry, lineItem.get("productCode"));
		}
		inputValues.put("LocationNumber", locNumber);

		return inputValues;
	}

	/*
	 * Getting input values for card status xml creation
	 */

	public Map<String, String> inputValuesForCardStatus(String clientName, String clientCountry, String cardStatus) {
		Map<String, String> inputValues = new HashMap<String, String>();

		Map<String, String> lineitem = new HashMap<>();
		String locNumber;

		CommonInterfacePage CommonInterfacePage = new CommonInterfacePage(driver, test);
		Common common = new Common(driver, test);
		String clientNameInProp = PropUtils.getPropValue(configProp, clientName + "_" + clientCountry);

		if (clientName.equalsIgnoreCase("WFE")) {
			String currentDate = common.getCurrentIFCSDateFromDB(clientNameInProp);
			// Get the IFCS current date
			String ifcsCurrentDate = common.enterADateValueInStatusBeginDateField("Current", currentDate);
			inputValues.put("date", ifcsCurrentDate);
		} else {
			String date = CommonInterfacePage.funcFetchLoadCardTransStartDateFromIFCSDB(configProp, clientNameInProp);
			inputValues.put("date", date);
		}

		String cardNumber = common.getCardNumberFromIFCSDB(clientName, clientCountry, cardStatus);
		inputValues.put("CardNumber", cardNumber);
		lineitem = CommonInterfacePage.getTransactionLineItem(configProp, cardNumber, clientName, clientCountry);
		inputValues.putAll(lineitem);
		if (clientName.equalsIgnoreCase("Chevron")) {
			locNumber = common.getExternalRefNoFromDB(clientName, clientCountry);
		} else if (clientName.equalsIgnoreCase("WFE")) {
			/*
			 * String queryToGetLocNo =
			 * "select location_no from m_locations where location_mid in (select member_oid from relationships r\r\n"
			 * +
			 * "inner join RELATIONSHIP_ASSIGNMENTS ra on r.relationship_oid=ra.relationship_oid \r\n"
			 * +
			 * "where ra.expires_on >= (SELECT PROCESSING_DATE from M_CLIENTS where Name ='"
			 * + PropUtils.getPropValue(configProp, clientName + "_" + clientCountry) +
			 * "') and \r\n" +
			 * "ra.effective_on <= (SELECT PROCESSING_DATE from M_CLIENTS where Name ='" +
			 * PropUtils.getPropValue(configProp, clientName + "_" + clientCountry) +
			 * "')) \r\n" + "and client_mid=(select client_mid from m_clients where name='"
			 * + PropUtils.getPropValue(configProp, clientName + "_" + clientCountry) +
			 * "') and rownum=1"; locNumber = common.connectDBAndGetValue(queryToGetLocNo,
			 * PropUtils.getPropValue(configProp, "sqlODSServerName"));
			 */
			locNumber = common.getLocationNoWithMerchantAgreementFromIFCSDB();
		} else {
			locNumber = common.getLocationNoFromIFCSDB(clientName, clientCountry, inputValues.get("productCode"));
		}

		inputValues.put("LocationNumber", locNumber);
		return inputValues;
	}

	/*
	 * Validate suspended transaction
	 */
	public void validateSuspendTransaction(Map<String, String> refNoAndCardNo, String message) {

		Map<String, String> refNoKeyAndValues = new HashMap<String, String>();
		for (String refNo : refNoAndCardNo.keySet()) {
			String suspended = "select Description from suspended_transactions st\r\n"
					+ "inner join transaction_errors te on te.transaction_error_oid = st.transaction_error_oid\r\n"
					+ "where pos_transaction_oid=(select pos_transaction_oid from pos_transactions where reference='"
					+ refNo + "')";
			String error = connectDBAndGetValue(suspended, PropUtils.getPropValue(configProp, "sqlODSServerName"));
			if (error.equalsIgnoreCase(message)) {
				logInfo("Transaction Moved to Suspended" + refNo);
				refNoKeyAndValues.put("SuspendedTransRefNo", refNo);
			} else {
				logFail("Transaction not Posted for" + refNo);
			}

		}
		PropUtils.creatingTempPropFile("TransactionReferenceNos.properties", refNoKeyAndValues);
	}

	public void validateSuspendTransactionForDuplicateTransaction(Map<String, String> refNoAndAmount, String message) {

		Map<String, String> refNoKeyAndValues = new HashMap<String, String>();
		for (String refNo : refNoAndAmount.keySet()) {
			String suspended = "select Description from suspended_transactions st\r\n"
					+ "inner join transaction_errors te on te.transaction_error_oid = st.transaction_error_oid\r\n"
					+ "where pos_transaction_oid=(select pos_transaction_oid from pos_transactions where reference='"
					+ refNo + "')";
			String error = connectDBAndGetValue(suspended, PropUtils.getPropValue(configProp, "sqlODSServerName"));
			if (error.equalsIgnoreCase(message)) {
				logPass("Transaction Moved to Suspended" + refNo);
				refNoKeyAndValues.put("SuspendedTransRefNo", refNo);
			} else {
				logFail("Transaction not Posted for" + refNo);
			}

		}
		PropUtils.creatingTempPropFile("TransactionReferenceNos.properties", refNoKeyAndValues);
	}

	/*
	 * raxsana 05/05/2020 getting input values for valid odometer readings
	 */

	public Map<String, String> inputValuesFoValidOdometerReadings(String clientName, String clientCountry) {
		Map<String, String> inputValues = new HashMap<String, String>();

		Map<String, String> lineitem = new HashMap<>();
		String locNumber;

		CommonInterfacePage CommonInterfacePage = new CommonInterfacePage(driver, test);
		Common common = new Common(driver, test);
		String clientNameInProp = PropUtils.getPropValue(configProp, clientName + "_" + clientCountry);

		String date = CommonInterfacePage.funcFetchLoadCardTransStartDateFromIFCSDB(configProp, clientNameInProp);
		inputValues.put("date", date);

		String cardNumber = getVehicleCardNumberFromIFCSDB(clientName, clientCountry);
		inputValues.put("CardNumber", cardNumber);

		lineitem = CommonInterfacePage.getTransactionLineItem(configProp, cardNumber, clientName, clientCountry);
		inputValues.putAll(lineitem);
		if (clientName.equalsIgnoreCase("Chevron")) {
			locNumber = common.getExternalRefNoFromDB(clientName, clientCountry);
		} else if (clientName.equalsIgnoreCase("WFE")) {
			String queryToGetLocNo = "select distinct external_code from m_locations where\r\n"
					+ "client_mid=(select client_mid from m_clients where name='"
					+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountry) + "') ";
			locNumber = common.connectDBAndGetValue(queryToGetLocNo,
					PropUtils.getPropValue(configProp, "sqlODSServerName"));
		} else {
			locNumber = common.getLocationNoFromIFCSDB(clientName, clientCountry, inputValues.get("productCode"));
		}
		inputValues.put("LocationNumber", locNumber);
		if (clientName.equalsIgnoreCase("WFE")) {
			inputValues.put("Mileage", "100");
		} else {
			inputValues.put("OdometerReading", "100");
			inputValues.put("CurrentOdometerReading", "100");
		}

		String queryToGetRegistrationNo = "select license_plate from vehicles where vehicle_oid=(select vehicle_oid from cards where card_no='"
				+ inputValues.get("CardNumber") + "')";
		String getregistrationNo = connectDBAndGetValue(queryToGetRegistrationNo,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		inputValues.put("RegistrationNumber", getregistrationNo);

		return inputValues;
	}

	// raxsana added
	public String getVehicleCardNumberFromIFCSDB(String clientName, String clientCountry) {

		String queryToGetvehicleCardNumber = "select c.card_no from cards c \r\n"
				+ "inner join  m_customers mc on mc.customer_mid = c.customer_mid \r\n"
				+ "inner join accounts acc on mc.customer_mid=acc.customer_mid \r\n"
				+ "inner join account_status accs on accs.account_status_oid=acc.account_status_oid \r\n"
				+ "inner join account_sub_status accss on accss.account_status_oid = accs.account_status_oid \r\n"
				+ "Where (accs.description like '%Active' OR accs.description like '%ACTIVE') \r\n"
				+ "and (accss.description like '%Active' OR accss.description like '%ACTIVE') and c.driver_oid IS NULL \r\n"
				+ "and c.replace_card_oid IS NULL and mc.client_mid in (SELECT client_mid from M_CLIENTS where name ='"
				+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountry) + "') \r\n"
				+ "and c.expires_on >=(SELECT PROCESSING_DATE from M_CLIENTS where name ='"
				+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountry) + "')\r\n"
				+ "and c.card_status_oid in (select card_status_oid from card_status where \r\n"
				+ "(description like '%Normal Service%' OR description like '%NORMAL SERVICE%' \r\n"
				+ "OR description like '%Active%' OR description like '%ACTIVE%')) and Rownum <=1";
		String cardNumberFromDB = connectDBAndGetValue(queryToGetvehicleCardNumber,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		return cardNumberFromDB;

	}

	// raxsana added
	// 01/06/2020
	public Map<String, String> inputValuesForValidCreditLimits(String clientName, String clientCountry) {
		Map<String, String> lineitem = new HashMap<>();
		Map<String, String> inputValues = new HashMap<String, String>();
		String locNumber;

		CommonInterfacePage CommonInterfacePage = new CommonInterfacePage(driver, test);
		Common common = new Common(driver, test);
		String clientNameInProp = PropUtils.getPropValue(configProp, clientName + "_" + clientCountry);

		String date = CommonInterfacePage.funcFetchLoadCardTransStartDateFromIFCSDB(configProp, clientNameInProp);
		inputValues.put("date", date);
		String creditLimit = "";
		if (clientName.equalsIgnoreCase("BP")) {
			String queryToGetCreditLimit = "select MIN(credit_limit) from accounts where credit_limit > '1000' "
					+ "and credit_plan_oid=(select credit_plan_oid from credit_plans where client_mid=(select client_mid from m_clients where name='"
					+ clientNameInProp + "') and rownum=1)";
			creditLimit = connectDBAndGetValue(queryToGetCreditLimit,
					PropUtils.getPropValue(configProp, "sqlODSServerName"));
			// creditLimit="3000";
		} else {
			creditLimit = "8000";
		}
		String cardNoCredit = "select c.card_no,a.credit_limit from cards c \r\n"
				+ "inner join accounts a on c.account_oid=a.account_oid \r\n"
				+ "inner join account_status acs on a.account_status_oid= acs.account_status_oid\r\n"
				+ "inner join account_sub_status ass on a.account_sub_status_oid =ass.account_sub_status_oid\r\n"
				+ "inner join card_status sc on sc.card_status_oid=c.card_status_oid\r\n"
				+ "where acs.client_mid=(select client_mid from m_clients where name='" + clientNameInProp + "') "
				+ "and a.credit_limit <= '" + creditLimit + "' and a.credit_limit > '0' \r\n"
				+ "and (acs.description like '%Active%' OR acs.description like '%ACTIVE%') and \r\n"
				+ "(ass.description like '%Active%' OR ass.description like '%ACTIVE%') \r\n"
				+ "and (sc.description like '%Active%' OR sc.description like '%Normal Service%') and a.actual_balance != '0' and rownum=1 \r\n"
				+ "order by a.opened_on desc";

		Map<String, String> cardNumberAndCreditLimitFromDB = connectDBAndGetDBEntireRowValues(cardNoCredit,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		inputValues.put("CardNumber", cardNumberAndCreditLimitFromDB.get("CARD_NO"));
		if (!(cardNumberAndCreditLimitFromDB.get("CARD_NO").equals("null"))) {

			String queryTogetLineItems = "select tp.external_code,pt.Maximum_UNIT_PRICE,pt.Maximum_VOLUME  from cards c\r\n"
					+ "inner join m_customers cus on cus.customer_mid = c.customer_mid\r\n"
					+ "inner join card_programs cp on cp.card_program_oid=c.card_program_oid\r\n"
					+ "inner join card_control_profiles ccp on ccp.card_control_profile_oid = c.card_control_profile_oid\r\n"
					+ "inner join card_controls cc on cc.card_control_profile_oid=ccp.card_control_profile_oid\r\n"
					+ "inner join product_restrictions pr on pr.product_restriction_oid=cc.product_restriction_oid\r\n"
					+ "inner join PRODUCT_RESTRICT_PRODS rp on rp.product_restriction_oid=pr.product_restriction_oid\r\n"
					+ "inner join PRODUCT_THRESHOLDS pt on pt.product_oid=rp.product_oid\r\n"
					+ "inner join PRODUCT_TRANSLATIONS tp on tp.product_oid=pt.product_oid \r\n"
					+ "inner join products p on p.product_oid = tp.product_oid \r\n" + "where card_no='"
					+ cardNumberAndCreditLimitFromDB.get("CARD_NO") + "' and p.is_fuel='Y' \r\n" +
					// "and pt.Maximum_UNIT_PRICE <='8000' and pt.Maximum_VOLUME<= '8000'\r\n" +
					"and pt.client_mid=(select client_mid from m_clients where name = '" + clientNameInProp + "' )\r\n"
					+ "and ROWNUM = 1";

			lineitem = connectDBAndGetDBEntireRowValues(queryTogetLineItems,
					PropUtils.getPropValue(configProp, "sqlODSServerName"));
			String productCode = lineitem.get("EXTERNAL_CODE");
			String unitPrice = lineitem.get("MAXIMUM_UNIT_PRICE");
			String volume = lineitem.get("MAXIMUM_VOLUME");
			lineitem.put("productCode", productCode);
			int volu = (int) Math.round(Float.parseFloat(volume));
			if (volu >= 8000) {
				lineitem.put("volume", String.valueOf(cardNumberAndCreditLimitFromDB.get("CREDIT_LIMIT")) + "00");
			} else {
				lineitem.put("volume", String.valueOf(volu) + "00");
			}
			int unitprice = (int) Math.round(Float.parseFloat(unitPrice));
			if (unitprice >= 8000) {
				lineitem.put("unitPrice", String.valueOf(cardNumberAndCreditLimitFromDB.get("CREDIT_LIMIT")) + "00");
			} else {
				lineitem.put("unitPrice", String.valueOf(unitprice) + "00");
			}

			inputValues.putAll(lineitem);
			if (clientName.equalsIgnoreCase("Chevron")) {
				locNumber = common.getExternalRefNoFromDB(clientName, clientCountry);
			} else {
				locNumber = common.getLocationNoFromIFCSDB(clientName, clientCountry, inputValues.get("productCode"));
			}
			inputValues.put("LocationNumber", locNumber);
		} else {
			logFail("No cards found");
		}

		return inputValues;
	}

	// raxsana added
	// 01/06/2020
	public void validateCreditLimitsFromDB(Map<String, String> inputValues, String clientName, String clientCountry) {
		try {
			String queryToGetAccountStatus = "select acs.description from accounts a\r\n"
					+ "inner join account_status acs on a.account_status_oid= acs.account_status_oid\r\n"
					+ "inner join account_sub_status ass on a.account_sub_status_oid =ass.account_sub_status_oid\r\n"
					+ "where a.account_no=(select account_no from accounts where account_oid=(select account_oid from cards where "
					+ "card_no='" + inputValues.get("CardNumber") + "')) "
					+ "and acs.client_mid=(select client_mid from m_clients where name='"
					+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountry) + "')";
			String accountStatusFromDB = connectDBAndGetValue(queryToGetAccountStatus,
					PropUtils.getPropValue(configProp, "sqlODSServerName"));
			String queryToGetAccountSubStatus = "select ass.description from accounts a\r\n"
					+ "inner join account_status acs on a.account_status_oid= acs.account_status_oid\r\n"
					+ "inner join account_sub_status ass on a.account_sub_status_oid =ass.account_sub_status_oid\r\n"
					+ "where a.account_no=(select account_no from accounts where account_oid=(select account_oid from cards where "
					+ "card_no='" + inputValues.get("CardNumber") + "')) "
					+ "and acs.client_mid=(select client_mid from m_clients where name='"
					+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountry) + "')";
			String accountSubStatusFromDB = connectDBAndGetValue(queryToGetAccountSubStatus,
					PropUtils.getPropValue(configProp, "sqlODSServerName"));
			if (clientName.equals("ZEnergy")) {
				if (accountStatusFromDB.equalsIgnoreCase("5 - Credit Limit Breach - IFCS")
						&& accountSubStatusFromDB.equalsIgnoreCase("AutoStop Credit Limit")) {
					logPass("Account is automatically locked");
				} else {
					logFail("Account is still in same status");
				}
			} else if (clientName.equals("BP")) {
				if (accountStatusFromDB.equalsIgnoreCase("Automatic Lockout")
						&& accountSubStatusFromDB.equalsIgnoreCase("Automatic lockout at Credit Limit")) {
					logPass("Account is automatically locked");
				} else {
					logFail("Account is still in same status");
				}
			} else if (clientName.equals("EMAP") || clientName.equals("CHEVRON")) {
				if (accountStatusFromDB.equalsIgnoreCase("9 - Temporary Locked")
						&& accountSubStatusFromDB.equalsIgnoreCase("F - AutoStop>Credit Limit")) {
					logPass("Account is automatically locked");
				} else {
					logFail("Account is still in same status");
				}
			} else {
				logFail("Account is still in same status");
			}
		} catch (Exception e) {
			e.getMessage();
		}
	}

	// raxsana added
	// 08/06/2020
	public void validateMerchantServiceFeeAndTax(Map<String, String> refNo, Map<String, String> inputValues) {
		DecimalFormat decimalFormat = new DecimalFormat("#.##");
		String queryToGetOriginalValue;

		String originalValue;
		String msfper;
		String[] msfsplit;
		String msfper1;
		float msf;
		String msfTax;
		String queryToGetMsfAndTaxFromDB;
		Map<String, String> msfAndTaxValues;
		for (String refno : refNo.keySet()) {
			queryToGetOriginalValue = "select original_value from TRANSACTION_LINE_ITEMS "
					+ "where transaction_oid=(select transaction_oid from transactions where  reference='" + refno
					+ "')";
			originalValue = connectDBAndGetValue(queryToGetOriginalValue,
					PropUtils.getPropValue(configProp, "sqlODSServerName"));

			System.out.println("originalValue::" + originalValue);
			msfper = null;
			try {
				msfper = inputValues.get("DESCRIPTION");
			} catch (Exception e) {
				e.getMessage();
			}
			System.out.println(msfper);
			msfsplit = msfper.split(" ");
			msfper1 = null;
			for (int i = 0; i < msfsplit.length; i++) {
				if (msfsplit[i].contains("%")) {
					msfper1 = msfsplit[i].replace("%", "");
				}
			}
			decimalFormat.setRoundingMode(RoundingMode.UP);
			System.out.println("msfper::" + msfper1);
			msf = (Integer.parseInt(originalValue) * Float.parseFloat(msfper1)) / 100;
			System.out.println("msf::" + decimalFormat.format(msf));
			decimalFormat.setRoundingMode(RoundingMode.DOWN);
			msfTax = "-" + String.valueOf(decimalFormat.format((msf * 10) / 100));
			System.out.println("msfTax::" + msfTax);
			decimalFormat.setRoundingMode(RoundingMode.UP);

			queryToGetMsfAndTaxFromDB = "select merchant_service_Fee_total,merchant_service_Fee_total_tax from TRANSACTION_LINE_ITEMS "
					+ "where transaction_oid=(select transaction_oid from transactions where reference='" + refno
					+ "')";
			msfAndTaxValues = connectDBAndGetDBEntireRowValues(queryToGetMsfAndTaxFromDB,
					PropUtils.getPropValue(configProp, "sqlODSServerName"));
			System.out.println("arrayValues::" + msfAndTaxValues);

			if (("-" + String.valueOf(decimalFormat.format(msf)))
					.equalsIgnoreCase(msfAndTaxValues.get("MERCHANT_SERVICE_FEE_TOTAL"))
					&& msfTax.equalsIgnoreCase(msfAndTaxValues.get("MERCHANT_SERVICE_FEE_TOTAL_TAX"))) {
				logPass("verified");
				System.out.println("verified");
			} else {
				logFail("not verified");
			}
		}
	}

	// raxsana added
	// 08/06/2020
	public Map<String, String> inputValuesForMerchantServiceFeeAndTax(String clientName, String clientCountry) {
		Map<String, String> inputValues = new HashMap<String, String>();

		Map<String, String> lineItem = null;
		String cardNumber = null;

		Common common = new Common(driver, test);
		CommonInterfacePage CommonInterfacePage = new CommonInterfacePage(driver, test);

		String clientNameInProp = PropUtils.getPropValue(configProp, clientName + "_" + clientCountry);
		String date = CommonInterfacePage.funcFetchLoadCardTransStartDateFromIFCSDB(configProp, clientNameInProp);
		inputValues.put("date", date);

		cardNumber = common.getCardNumberFromIFCSDB(clientName, clientCountry, "Active");
		inputValues.put("CardNumber", cardNumber);

		lineItem = CommonInterfacePage.getTransactionLineItem(configProp, cardNumber, clientName, clientCountry);
		inputValues.putAll(lineItem);
		String desc;
		if (clientName.equalsIgnoreCase("ZEnergy")) {
			desc = "Fuel MSF (cpl/%)";
		} else {
			desc = "Merchant Service Fee";
		}
		String queryToGetLocNo;
		if (clientCountry.equalsIgnoreCase("TH")) {
			queryToGetLocNo = "select mc.location_no,mv.description from m_locations mc\r\n"
					+ "inner join location_reconciliations lr on mc.location_mid=lr.location_mid\r\n"
					+ "inner join merchant_agreements m on m.merchant_agreement_oid=lr.merchant_agreement_oid\r\n"
					+ "inner join merch_agrmnt_values mv on mv.merch_agrmnt_value_oid= m.merch_agrmnt_value_1_oid\r\n"
					+ "inner join merch_agrmnt_value_types mvt on mvt.merch_agrmnt_value_type_oid=mv.merch_agrmnt_value_type_oid\r\n"
					+ "where mvt.description='Merchant Service Fee' \r\n"
					+ "and mvt.client_mid=(select client_mid from m_clients where name='" + clientNameInProp
					+ "') and mv.description !='MSF Exempt' order by mc.created_on desc";
		} else {
			queryToGetLocNo = "select mc.location_no,mv.description from m_locations mc\r\n"
					+ "inner join location_reconciliations lr on mc.location_mid=lr.location_mid\r\n"
					+ "inner join merchant_agreements m on m.merchant_agreement_oid=lr.merchant_agreement_oid\r\n"
					+ "inner join merch_agrmnt_values mv on mv.merch_agrmnt_value_oid= m.merch_agrmnt_value_1_oid\r\n"
					+ "inner join merch_agrmnt_value_types mvt on mvt.merch_agrmnt_value_type_oid=mv.merch_agrmnt_value_type_oid\r\n"
					+ "where mvt.description='" + desc + "' \r\n"
					+ "and mvt.client_mid=(select client_mid from m_clients where name='" + clientNameInProp
					+ "') order by mc.created_on desc";
		}
		Map<String, String> locNoFromDB = connectDBAndGetDBEntireRowValues(queryToGetLocNo,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		System.out.println(locNoFromDB);
		inputValues.put("LocationNumber", locNoFromDB.get("LOCATION_NO"));
		// inputValues.put("DESCRITPION", locNoFromDB.get("DESCRITPION"));
		inputValues.putAll(locNoFromDB);

		return inputValues;
	}

	public Map<String, String> XMLCreationForTransactionWFE(String clientName, String clientCountry,
			Map<String, String> inputvalues) throws TransformerException {

		Map<String, String> dbvalue = null;
		Map<String, String> valuesForValidation = new LinkedHashMap<String, String>();
		// String folderName = null, jobsInOrder = null,
		String refNo = null;

		int k;
		// int netValue = 0;
		/*
		 * Common common = new Common(driver, test); IFCSCommonPage ifcsCommonPage = new
		 * IFCSCommonPage(driver, test); CommonInterfacePage CommonInterfacePage = new
		 * CommonInterfacePage(driver, test); InterfacePage interfacePage = new
		 * InterfacePage(driver, test); IFCSHomePage ifcsHomePage = new
		 * IFCSHomePage(driver, test);
		 */
		/*
		 * String[] headertag = { "FileName", "SequenceNumber", "RecordCount",
		 * "CountryCode", "StartDate", "StartTime", "ExternalSupplier",
		 * "SettlementDate", "ExternalFileName" };
		 */
		String[] Transaction = { "Identifier", "TerminalInfo", "TransactionInfo", "CardInfo", "SalesItem" };
		String[] Identifier = { "StationID", "SystemTraceAuditNumber", "TransactionTimestamp" };
		String[] TerminalInfo = { "TerminalID", "TerminalType" };
		String[] TransactionInfo = { "TransactionType", "OriginalSystemTraceAuditNumber", "TransactionResult",
				"TransactionAmount", "CurrencyCode", "BatchSequenceNumber", "CustomerInput", "TicketNumber" };
		String[] CardInfo = { "PAN", "PANEntryMode", "TrackData", "ExpiryDate" };
		String[] SalesItem = { "ProductCode", "Quantity", "UnitPrice", "UnitOfMeasure", "Amount", "PumpInfo",
				"VATPercentage", "AdditionalProductCode" };

		/*
		 * String folderid = CommonInterfacePage.getfolderid(clientName, clientCountry);
		 * int cardListCount = 1; String client_mid =
		 * CommonInterfacePage.funcFetchLoadCardTransClientMidFromDB(configProp,
		 * clientName, clientCountry); String remotedir; if
		 * (clientName.equalsIgnoreCase("BP")) { remotedir =
		 * PropUtils.getPropValue(configProp, "IFCS_LOADCARDTRANSACTION") + folderid +
		 * "/"; } else { remotedir = PropUtils.getPropValue(configProp,
		 * "IFCS_LOADCARDTRANSACTION") + client_mid + "/" + folderid + "/"; }
		 */
		try {
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			Document doc = docBuilder.newDocument();
			// students root element
			Element rootElement = doc.createElement("SettlementFile");
			doc.appendChild(rootElement);
			rootElement.setAttribute("CreationTimestamp", "Time");
			rootElement.setAttribute("CreditAmount", "");
			rootElement.setAttribute("CreditReversalAmount", "");
			rootElement.setAttribute("DebitAmount", "");
			rootElement.setAttribute("DebitReversalAmount", "");
			rootElement.setAttribute("FileSequenceNumber", "");
			rootElement.setAttribute("NumberOfTransactions", "");
			rootElement.setAttribute("Version", "");

			// Element header = doc.createElement("Header");
			// rootElement.appendChild(header);
			// dbvalue = CommonInterfacePage.fetchLoadCardTransSeqNoandPrefix(configProp,
			// clientName, clientCountry, folderid);
			// String filename = dbvalue.get("prefixvalue") +
			// dbvalue.get("lastSequenceNumber") + ".xml";
			String filename = "File.xml";
			System.out.println(dbvalue);
			/*
			 * for (k = 0; k < headertag.length; k++) { Element subtag =
			 * doc.createElement(headertag[k]); if
			 * (headertag[k].equalsIgnoreCase("FileName")) { System.out.println(
			 * "file Name:" + dbvalue.get("prefixvalue") + dbvalue.get("lastSequenceNumber")
			 * + ".xml"); subtag.setTextContent(dbvalue.get("prefixvalue") +
			 * dbvalue.get("lastSequenceNumber") + ".xml"); } else if
			 * (headertag[k].equalsIgnoreCase("SequenceNumber")) {
			 * subtag.setTextContent(dbvalue.get("lastSequenceNumber")); } else if
			 * (headertag[k].equalsIgnoreCase("RecordCount")) {
			 * subtag.setTextContent(Integer.toString(cardListCount)); } else if
			 * (headertag[k].equalsIgnoreCase("CountryCode") &&
			 * clientName.equalsIgnoreCase("CHEVRON")) { subtag.setTextContent("CHEV" + "_"
			 * + clientCountry); } else if (headertag[k].equalsIgnoreCase("CountryCode")) {
			 * subtag.setTextContent(clientCountry); } else if
			 * (headertag[k].equalsIgnoreCase("StartDate")) {
			 * subtag.setTextContent(inputvalues.get("date").split(" ")[0]); } else if
			 * (headertag[k].equalsIgnoreCase("StartTime")) {
			 * subtag.setTextContent(inputvalues.get("date").split(" ")[1]); } else if
			 * (headertag[k].equalsIgnoreCase("ExternalSupplier")) { String externalSupplier
			 * = CommonInterfacePage.getExternalSupplier(clientName, clientCountry);
			 * subtag.setTextContent(externalSupplier); } else if
			 * (headertag[k].equalsIgnoreCase("SettlementDate")) {
			 * subtag.setTextContent(inputvalues.get("date").split(" ")[0]); } else if
			 * (headertag[k].equalsIgnoreCase("Identifier") &&
			 * (clientName.equalsIgnoreCase("EMAP") || clientName.equalsIgnoreCase("OTI")))
			 * { subtag.setTextContent("Y"); }
			 * 
			 * header.appendChild(subtag); }
			 */ Faker faker = new Faker();
			Element subtag = null;
			Element loadCardTransactionsubtag = null;

			for (int i = 0; i < 1; i++) {

				Element loadCardTransaction = doc.createElement("Transaction");

				for (int j = 0; j < Transaction.length; j++) {

					loadCardTransactionsubtag = doc.createElement(Transaction[j]);
					if (Transaction[j].equalsIgnoreCase("Identifier")) {
						for (k = 0; k < Identifier.length; k++) {
							subtag = doc.createElement(Identifier[k]);
							if (Identifier[k].equalsIgnoreCase("StationID")) {
								subtag.setTextContent("");
							}
							if (Identifier[k].equalsIgnoreCase("SystemTraceAuditNumber")) {
								String value = faker.number().digits(6);
								subtag.setTextContent(value);
							}
							if (Identifier[k].equalsIgnoreCase("TransactionTimestamp")) {
								subtag.setTextContent("");

							}
							loadCardTransactionsubtag.appendChild(subtag);
						}

					}

					if (Transaction[j].equalsIgnoreCase("TerminalInfo")) {
						for (k = 0; k < TerminalInfo.length; k++) {

							subtag = doc.createElement(TerminalInfo[k]);
							if (TerminalInfo[k].equalsIgnoreCase("TerminalID")) {
								subtag.setTextContent("");
								// valuesForValidation.put(refNo, inputvalues.get("CardNumber"));
							}
							if (TerminalInfo[k].equalsIgnoreCase("TerminalType")) {
								subtag.setTextContent("1");

							}
							loadCardTransactionsubtag.appendChild(subtag);
						}

					}
					if (Transaction[j].equalsIgnoreCase("TransactionInfo")) {
						for (k = 0; k < TransactionInfo.length; k++) {

							subtag = doc.createElement(TransactionInfo[k]);
							if (TransactionInfo[k].equalsIgnoreCase("TransactionType")) {
								subtag.setTextContent("0");
							}
							if (TransactionInfo[k].equalsIgnoreCase("OriginalSystemTraceAuditNumber")) {
								subtag.setTextContent("123456");
							}
							if (TransactionInfo[k].equalsIgnoreCase("TransactionResult")) {
								Element Approved = doc.createElement("Approved");
								Element AuthorisationCode = doc.createElement("AuthorisationCode");
								Approved.setTextContent("true");
								AuthorisationCode.setTextContent("Nozzle");
								subtag.appendChild(Approved);
								subtag.appendChild(AuthorisationCode);
							}
							if (TransactionInfo[k].equalsIgnoreCase("TransactionAmount")) {
								subtag.setTextContent("");
							}
							if (TransactionInfo[k].equalsIgnoreCase("CurrencyCode")) {
								subtag.setTextContent("");
							}
							if (TransactionInfo[k].equalsIgnoreCase("BatchSequenceNumber")) {
								subtag.setTextContent("");
							}
							if (TransactionInfo[k].equalsIgnoreCase("CustomerInput")) {
								Element DriverNumber = doc.createElement("DriverNumber");
								DriverNumber.setTextContent("Driver");
								subtag.appendChild(DriverNumber);
							}
							if (TransactionInfo[k].equalsIgnoreCase("TicketNumber")) {
								subtag.setTextContent("");
							}
							loadCardTransactionsubtag.appendChild(subtag);
						}
					}

					if (Transaction[j].equalsIgnoreCase("CardInfo")) {
						for (k = 0; k < CardInfo.length; k++) {
							subtag = doc.createElement(CardInfo[k]);

							if (TransactionInfo[k].equals("PAN")) {
								subtag.setTextContent("");
							} else if (TransactionInfo[k].equals("PANEntryMode")) {
								subtag.setTextContent("");
							} else if (TransactionInfo[k].equals("TrackData")) {
								subtag.setTextContent("");
							} else if (CardInfo[k].equals("ExpiryDate")) {
								subtag.setTextContent("77");
							}
							loadCardTransactionsubtag.appendChild(subtag);
						}
					}
					if (Transaction[j].equalsIgnoreCase("SalesItem")) {

						for (k = 0; k < SalesItem.length; k++) {
							Element TransactionLineItemsSubtag = doc.createElement(SalesItem[k]);

							if (SalesItem[k].equalsIgnoreCase("ProductCode")) {
								System.out.println("prdcode" + inputvalues.get("productCode"));
								TransactionLineItemsSubtag.setTextContent(inputvalues.get("productCode"));
							}
							if (SalesItem[k].equalsIgnoreCase("Quantity")) {
								TransactionLineItemsSubtag.setTextContent(inputvalues.get("volume"));
							}
							if (SalesItem[k].equalsIgnoreCase("UnitPrice")) {
								TransactionLineItemsSubtag.setTextContent(inputvalues.get("unitPrice"));
							}
							if (SalesItem[k].equalsIgnoreCase("UnitOfMeasure")) {
								TransactionLineItemsSubtag.setTextContent("");
							}
							if (SalesItem[k].equalsIgnoreCase("Amount")) {
								/*
								 * System.out.println("volume" + Integer.parseInt(""));
								 * System.out.println("unit price" + Integer.parseInt(""));
								 * 
								 * System.out.println("net value::" + netValue);
								 */
								TransactionLineItemsSubtag.setTextContent("");
								valuesForValidation.put(refNo, "");
							}
							if (SalesItem[k].equalsIgnoreCase("PumpInfo")) {
								Element PumpInfo = doc.createElement("Pump");
								Element Nozzle = doc.createElement("Nozzle");
								PumpInfo.setTextContent("pump");
								Nozzle.setTextContent("Nozzle");
								TransactionLineItemsSubtag.appendChild(PumpInfo);
								TransactionLineItemsSubtag.appendChild(Nozzle);
								// TransactionLineItemsSubtag.setTextContent(inputvalues.get("unitPrice"));
							}
							if (SalesItem[k].equalsIgnoreCase("VATPercentage")) {
								TransactionLineItemsSubtag.setTextContent(inputvalues.get("unitPrice"));
							}
							if (SalesItem[k].equalsIgnoreCase("AdditionalProductCode")) {
								TransactionLineItemsSubtag.setTextContent(inputvalues.get("unitPrice"));
							}

							loadCardTransactionsubtag.appendChild(TransactionLineItemsSubtag);
						}
					}

					loadCardTransaction.appendChild(loadCardTransactionsubtag);
				}

				rootElement.appendChild(loadCardTransaction);

			}
			System.out.println(valuesForValidation);
			// Write the content into XML file
			DOMSource source = new DOMSource(doc);
			StreamResult result = new StreamResult(new File("LoadCardTransaction.xml"));

			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer = transformerFactory.newTransformer();

			transformer.setOutputProperty(OutputKeys.INDENT, "yes");
			transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "4");
			transformer.transform(source, result);

			result = new StreamResult(new File(System.getProperty("user.home") + System.getProperty("file.separator")
					+ "Documents" + System.getProperty("file.separator") + filename));
			System.out.println(filename);
			transformer.transform(source, result);

			/*
			 * ifcsCommonPage.establishThePuttyConnectionbyUserGeneratedRemoteDirectory(
			 * "XML", "PUTTY_HOST", "PUTTY_USERNAME", "PUTTY_PASSWORD", remotedir,
			 * filename);
			 * 
			 * ifcsCommonPage.interfaceBatchJobwithIFCSLogin(clientName, clientCountry,
			 * folderid); ifcsHomePage.exitIFCS(); if (clientName.equals("BP") ||
			 * clientName.equals("CHEVRON")) { folderName =
			 * ifcsCommonPage.getControlMFolder(clientName, clientCountry,
			 * "jobS_LoadcardTransactions_" + clientName + "_" + clientCountry); jobsInOrder
			 * = ifcsCommonPage .getJobsOfFolderInOrder("jobS_LoadcardTransactions_" +
			 * clientName + "_" + clientCountry); } else { folderName =
			 * ifcsCommonPage.getControlMFolder(clientName, clientCountry,
			 * "jobS_LoadcardTransactions_" + clientName); jobsInOrder =
			 * ifcsCommonPage.getJobsOfFolderInOrder("jobS_LoadcardTransactions_" +
			 * clientName); }
			 * interfacePage.establishAndExecuteControlMJobs("ControlM_AWS_UAT",
			 * "ContorlM_AWS_userName", "ContorlM_AWS_password", folderName, jobsInOrder);
			 */

		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return valuesForValidation;
	}

	/*
	 * Added by raxsana 23/07/2020
	 */
	public void postTransactionFromSuspendedTransaction(String clientName, String clientCountry) {
		Common common = new Common(driver, test);
		WFECommon wfeCommon = new WFECommon(driver, test);
		TransactionListPage transactionListPage = new TransactionListPage(driver, test);
		String cardNo = common.getCardNumberFromIFCSDB(clientName, clientCountry, "Active");
		String queryToGetRefNo = "select reference from pos_transactions where pos_transaction_oid in (select pos_transaction_oid "
				+ "from suspended_transactions where transaction_error_oid in (select transaction_error_oid from transaction_errors where description='Card Locked-Out' "
				+ "and client_mid=(select client_mid from m_clients where name='"
				+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountry) + "'))) and reference not like '%0000000%'"
				+ "order by processed_at desc";
		String refNo = connectDBAndGetValue(queryToGetRefNo, PropUtils.getPropValue(configProp, "sqlODSServerName"));
		String actualBalanceBefore = wfeCommon.getAccountActualBalance(cardNo);
		
		String currentDate = common.getCurrentIFCSDateFromDB(clientName+"_"+clientCountry);
		// Get the IFCS current date
		String ifcsCurrentDate = common.enterADateValueInStatusBeginDateField("Current", currentDate);
		try {
			chooseSubMenuFromLeftPanel("Client Transactions", "Suspended Transactions");
			common.detailSearch();
			sleep(5);
			enterValueInTextBox("Filter By", "Reference No", refNo);
			common.searchListTorch();
			common.selectFirstRowNumberInSearchList();
			sleep(3);
			driver.findElement(By.xpath(
					"//div[@class='JFALSeparator']//div[contains(text(),'Details')]/preceding::div[@class='JFALLabel']/div[starts-with(text(),'Effective') and contains(text(),'Date')]/preceding::div[@class='JFALCompControlPanel'][1]//input[contains(@name,'JFALDateLocaleTextField')]"))
					.clear();;
			driver.findElement(By.xpath(
					"//div[@class='JFALSeparator']//div[contains(text(),'Details')]/preceding::div[@class='JFALLabel']/div[starts-with(text(),'Effective') and contains(text(),'Date')]/preceding::div[@class='JFALCompControlPanel'][1]//input[contains(@name,'JFALDateLocaleTextField')]"))
					.sendKeys(ifcsCurrentDate);
			sleep(3);
			enterValueInTextBox("Details", "Effective Date", "12:30:00 pm");
			sleep(3);
			enterValueInTextBox("Details", "Card Number", cardNo);
			common.clickOkButton();
			sleep(3);
			common.clickSaveIcon();
			verifyValidationResult("Record saved OK");
			sleep(2);
			common.clickValidateManualTransactionIcon();
			verifyValidationResult("Validation successful");
			sleep(5);
			common.clickPostTransaction();
			common.verifyValidationResult("Force Posted Transaction Successfully");
			sleep(2);
			transactionListPage.validatePostedInTransaction(refNo);

		} catch (Exception e) {
			e.getMessage();
		}
		validateAccountBalance(actualBalanceBefore, refNo, cardNo);
	}

	/*
	 * Raxsana Added 17/09/2020
	 */
	public void validateAccountBalance(String actualBalanceBefore, String refNo, String cardNo) {
		DecimalFormat decimalFormat = new DecimalFormat("#.##");
		decimalFormat.setRoundingMode(RoundingMode.DOWN);
		String queryToGetTranAmount = "select customer_amount from transactions where reference='" + refNo + "'";
		String transAmount = connectDBAndGetValue(queryToGetTranAmount,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		System.out.println("actual_balance:" + transAmount);

		String queryToGetActualBalance = "select actual_balance from accounts where account_oid =(select account_oid from cards where card_no='"
				+ cardNo + "')";
		String actualBalanceAfter = connectDBAndGetValue(queryToGetActualBalance,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		System.out.println("actual_balance after:" + actualBalanceAfter);
		String actualBalance = "";
		actualBalance = String.valueOf(Double.parseDouble(transAmount) + Double.parseDouble(actualBalanceBefore));
		String actualAmount = decimalFormat.format(Double.parseDouble(actualBalance));
		System.out.println("actual_balance:" + actualAmount);
		if (actualAmount.equalsIgnoreCase(actualBalanceAfter)) {
			logPass("ActualBalance matched");
		} else {
			logFail("ActualBalance Not matched");
		}
	}
	/*
	 * Raxsana Added
	 */

	public Map<String, String> inputValuesForProductRestriction(String clientName, String clientCountry) {
		Map<String, String> inputValues = new HashMap<String, String>();

		String locNumber;

		CommonInterfacePage CommonInterfacePage = new CommonInterfacePage(driver, test);
		Common common = new Common(driver, test);
		String clientNameInProp = PropUtils.getPropValue(configProp, clientName + "_" + clientCountry);

		if (clientName.equalsIgnoreCase("WFE")) {
			String currentDate = common.getCurrentIFCSDateFromDB(clientNameInProp);
			// Get the IFCS current date
			String ifcsCurrentDate = common.enterADateValueInStatusBeginDateField("Current", currentDate);
			inputValues.put("date", ifcsCurrentDate);
		} else {
			String date = CommonInterfacePage.funcFetchLoadCardTransStartDateFromIFCSDB(configProp, clientNameInProp);
			inputValues.put("date", date);
		}

		String queryToGetCardNumber = "select c.card_no from cards c\r\n"
				+ "inner join card_status cs on cs.card_status_oid=c.card_status_oid\r\n"
				+ "inner join card_controls cc on c.CARD_CONTROL_PROFILE_OID = cc.CARD_CONTROL_PROFILE_OID\r\n"
				+ "inner join PRODUCT_RESTRICTIONS pr on pr.PRODUCT_RESTRICTION_oid=cc.PRODUCT_RESTRICTION_oid inner join card_controls cc on cc.card_control_profile_oid= c.card_control_profile_oid\r\n"
				+ "inner join time_limits tl on tl.time_limit_oid=cc.time_limit_oid\r\n"
				+ "where pr.short_description='S1'and cs.description like '%Normal Service%' \r\n"
				+ "and cs.client_mid=(select client_mid from m_clients where name='" + clientNameInProp + "')\r\n"
				+ "and c.expires_on >= (SELECT PROCESSING_DATE from M_CLIENTS where Name ='" + clientNameInProp
				+ "') and tl.description='All days, all times'";
		String cardNumber = common.connectDBAndGetValue(queryToGetCardNumber,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		inputValues.put("CardNumber", cardNumber);
		if (clientName.equalsIgnoreCase("Chevron")) {
			locNumber = common.getExternalRefNoFromDB(clientName, clientCountry);
		} else if (clientName.equalsIgnoreCase("WFE")) {
			/*
			 * String queryToGetLocNo =
			 * "select location_no from m_locations where location_mid in (select member_oid from relationships r\r\n"
			 * +
			 * "inner join RELATIONSHIP_ASSIGNMENTS ra on r.relationship_oid=ra.relationship_oid \r\n"
			 * +
			 * "where ra.expires_on >= (SELECT PROCESSING_DATE from M_CLIENTS where Name ='"
			 * + PropUtils.getPropValue(configProp, clientName + "_" + clientCountry) +
			 * "') and \r\n" +
			 * "ra.effective_on <= (SELECT PROCESSING_DATE from M_CLIENTS where Name ='" +
			 * PropUtils.getPropValue(configProp, clientName + "_" + clientCountry) +
			 * "')) \r\n" + "and client_mid=(select client_mid from m_clients where name='"
			 * + PropUtils.getPropValue(configProp, clientName + "_" + clientCountry) +
			 * "') and rownum=1"; locNumber = common.connectDBAndGetValue(queryToGetLocNo,
			 * PropUtils.getPropValue(configProp, "sqlODSServerName"));
			 */
			locNumber = common.getLocationNoWithMerchantAgreementFromIFCSDB();
		} else {
			locNumber = common.getLocationNoFromIFCSDB(clientName, clientCountry, inputValues.get("productCode"));
		}
		inputValues.put("LocationNumber", locNumber);
		return inputValues;
	}

	/*
	 * Raxsana Added
	 */
	public Map<String, String> inputValuesForCrossBorderTransaction(String clientName, String clientCountry,
			String isFuelFlag) {
		Map<String, String> inputValues = new HashMap<String, String>();
		String locNumber;

		CommonInterfacePage CommonInterfacePage = new CommonInterfacePage(driver, test);
		Common common = new Common(driver, test);
		WFECommon wfeCommon = new WFECommon(driver, test);
		String clientNameInProp = PropUtils.getPropValue(configProp, clientName + "_" + clientCountry);

		if (clientName.equalsIgnoreCase("WFE")) {
			String currentDate = common.getCurrentIFCSDateFromDB(clientNameInProp);
			// Get the IFCS current date
			String ifcsCurrentDate = common.enterADateValueInStatusBeginDateField("Current", currentDate);
			inputValues.put("date", ifcsCurrentDate);
		} else {
			String date = CommonInterfacePage.funcFetchLoadCardTransStartDateFromIFCSDB(configProp, clientNameInProp);
			inputValues.put("date", date);
		}

		String crossBorderClientCountry = "";
		if (clientCountry.equalsIgnoreCase("BE") || clientCountry.equalsIgnoreCase("LU")
				|| clientCountry.equalsIgnoreCase("FR")) {
			crossBorderClientCountry = "NL";
		} else if (clientCountry.equalsIgnoreCase("NL")) {
			crossBorderClientCountry = "BE";
		}
		inputValues.put("crossBorderClientCountry", crossBorderClientCountry);
		/*
		 * String queryToGetCardNumber = "select distinct c.card_no from cards c\r\n" +
		 * "inner join  m_customers mc on mc.customer_mid=c.customer_mid \r\n" +
		 * "inner join applications a on a.customer_no=mc.customer_no\r\n" +
		 * "inner join accounts ac on ac.customer_mid=mc.customer_mid\r\n" +
		 * "inner join account_status acs on acs.account_status_oid=ac.account_status_oid\r\n"
		 * + "inner join card_status cs on cs.card_status_oid=c.card_status_oid\r\n" +
		 * "where mc.client_mid=(select client_mid from m_clients where name='" +
		 * clientNameInProp + "') \r\n" +
		 * "and a.pricing_profile_oid is not null and acs.description like '%Active%'\r\n"
		 * + "and cs.description like '%Normal Service%' and rownum=1";
		 */
		String queryToGetCardNumber = "select distinct c.card_no from cards c\r\n"
				+ "inner join  m_customers mc on mc.customer_mid=c.customer_mid \r\n"
				+ "inner join applications a on a.customer_no=mc.customer_no\r\n"
				+ "inner join accounts ac on ac.customer_mid=mc.customer_mid\r\n"
				+ "inner join account_status acs on acs.account_status_oid=ac.account_status_oid\r\n"
				+ "inner join card_status cs on cs.card_status_oid=c.card_status_oid \r\n"
				+ "inner join customer_pricing_logs cp on cp.customer_mid=mc.customer_mid\r\n"
				+ "where mc.client_mid=(select client_mid from m_clients where name='" + clientNameInProp + "') \r\n"
				+ "and acs.description like '%Active%' \r\n"
				+ "and cp.pricing_profile_oid in (select pricing_profile_oid from pricing_profiles where description='Pump - Discount' \r\n"
				+ "and client_mid=(select client_mid from m_clients where name='"
				+ PropUtils.getPropValue(configProp, clientName + "_" + crossBorderClientCountry) + "'))\r\n"
				+ "and cp.expires_on >=(SELECT PROCESSING_DATE from M_CLIENTS where Name ='" + clientNameInProp
				+ "')\r\n" + "and cs.description like '%Normal Service%' and rownum=1";
		String cardNumber = common.connectDBAndGetValue(queryToGetCardNumber,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		inputValues.put("CardNumber", cardNumber);
		Map<String, String> lineItems = null;
		if (isFuelFlag.equalsIgnoreCase("Y")) {
			lineItems = CommonInterfacePage.getTransactionLineItem(configProp, cardNumber, clientName, clientCountry);

		} else {
			lineItems = wfeCommon.getTransactionLineItemForNonFuels(configProp, cardNumber, clientName, clientCountry);
		}
		inputValues.putAll(lineItems);

		inputValues.put("LocationClientCountry", crossBorderClientCountry);
		String queryToGetLocNo = "select distinct external_code from m_locations where location_mid in (select member_oid from relationships r\r\n"
				+ "inner join RELATIONSHIP_ASSIGNMENTS ra on r.relationship_oid=ra.relationship_oid \r\n"
				+ "where ra.expires_on >= (SELECT PROCESSING_DATE from M_CLIENTS where Name ='"
				+ PropUtils.getPropValue(configProp, clientName + "_" + crossBorderClientCountry) + "') and \r\n"
				+ "ra.effective_on <= (SELECT PROCESSING_DATE from M_CLIENTS where Name ='"
				+ PropUtils.getPropValue(configProp, clientName + "_" + crossBorderClientCountry) + "')) \r\n"
				+ "and client_mid=(select client_mid from m_clients where name='"
				+ PropUtils.getPropValue(configProp, clientName + "_" + crossBorderClientCountry) + "')";
		locNumber = common.connectDBAndGetValue(queryToGetLocNo,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		inputValues.put("LocationNumber", locNumber);

		String queryToGetNetwork = "select distinct mg.description from m_locations l\r\n"
				+ "inner join LOCATION_RECONCILIATIONS lr on lr.location_mid=l.location_mid\r\n"
				+ "inner join merchant_agreements ma on ma.merchant_agreement_oid=lr.merchant_agreement_oid\r\n"
				+ "inner join merch_agrmnt_values mg on mg.merch_agrmnt_value_oid=ma.merch_agrmnt_value_1_oid\r\n"
				+ "inner join merch_agrmnt_value_types mgt on mgt.merch_agrmnt_value_type_oid=mg.merch_agrmnt_value_type_oid\r\n"
				+ "where l.location_no='" + locNumber + "' and mgt.description='Network'";
		String network = common.connectDBAndGetValue(queryToGetNetwork,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		inputValues.put("network", network);

		return inputValues;

	}

	/*
	 * Raxsana Added
	 */
	/*
	 * public Map<String, String> inputValuesForCrossBorderTransaction(String
	 * clientName, String clientCountry, String isFuelFlag) { Map<String, String>
	 * inputValues = new HashMap<String, String>(); String locNumber;
	 * 
	 * CommonInterfacePage CommonInterfacePage = new CommonInterfacePage(driver,
	 * test); Common common = new Common(driver, test); WFECommon wfeCommon = new
	 * WFECommon(driver, test); String clientNameInProp =
	 * PropUtils.getPropValue(configProp, clientName + "_" + clientCountry);
	 * 
	 * if (clientName.equalsIgnoreCase("WFE")) { String currentDate =
	 * common.getCurrentIFCSDateFromDB(clientNameInProp); // Get the IFCS current
	 * date String ifcsCurrentDate =
	 * common.enterADateValueInStatusBeginDateField("Current", currentDate);
	 * inputValues.put("date", ifcsCurrentDate); } else { String date =
	 * CommonInterfacePage.funcFetchLoadCardTransStartDateFromIFCSDB(configProp,
	 * clientNameInProp); inputValues.put("date", date); }
	 * 
	 * String queryToGetCardNumber = "select distinct c.card_no from cards c\r\n" +
	 * "inner join  m_customers mc on mc.customer_mid=c.customer_mid \r\n" +
	 * "inner join applications a on a.customer_no=mc.customer_no\r\n" +
	 * "inner join accounts ac on ac.customer_mid=mc.customer_mid\r\n" +
	 * "inner join account_status acs on acs.account_status_oid=ac.account_status_oid\r\n"
	 * + "inner join card_status cs on cs.card_status_oid=c.card_status_oid\r\n" +
	 * "where mc.client_mid=(select client_mid from m_clients where name='" +
	 * clientNameInProp + "') \r\n" +
	 * "and a.pricing_profile_oid is not null and acs.description like '%Active%'\r\n"
	 * + "and cs.description like '%Normal Service%' and rownum=1"; String
	 * cardNumber = common.connectDBAndGetValue(queryToGetCardNumber,
	 * PropUtils.getPropValue(configProp, "sqlODSServerName"));
	 * inputValues.put("CardNumber", cardNumber); Map<String, String> lineItems =
	 * null; if (isFuelFlag.equalsIgnoreCase("Y")) { lineItems =
	 * CommonInterfacePage.getTransactionLineItem(configProp, cardNumber,
	 * clientName, clientCountry);
	 * 
	 * } else { lineItems = wfeCommon.getTransactionLineItemForNonFuels(configProp,
	 * cardNumber, clientName, clientCountry); } inputValues.putAll(lineItems);
	 * String crossBorderClientCountry = ""; if
	 * (clientCountry.equalsIgnoreCase("BE") || clientCountry.equalsIgnoreCase("LU")
	 * || clientCountry.equalsIgnoreCase("FR")) { crossBorderClientCountry = "NL"; }
	 * else if (clientCountry.equalsIgnoreCase("NL")) { crossBorderClientCountry =
	 * "BE"; } inputValues.put("LocationClientCountry", crossBorderClientCountry);
	 * String queryToGetLocNo =
	 * "select external_code from m_locations where location_mid in (select member_oid from relationships r\r\n"
	 * +
	 * "inner join RELATIONSHIP_ASSIGNMENTS ra on r.relationship_oid=ra.relationship_oid \r\n"
	 * +
	 * "where ra.expires_on >= (SELECT PROCESSING_DATE from M_CLIENTS where Name ='"
	 * + PropUtils.getPropValue(configProp, clientName + "_" +
	 * crossBorderClientCountry) + "') and \r\n" +
	 * "ra.effective_on <= (SELECT PROCESSING_DATE from M_CLIENTS where Name ='" +
	 * PropUtils.getPropValue(configProp, clientName + "_" +
	 * crossBorderClientCountry) + "')) \r\n" +
	 * "and client_mid=(select client_mid from m_clients where name='" +
	 * PropUtils.getPropValue(configProp, clientName + "_" +
	 * crossBorderClientCountry) + "') and rownum=1"; locNumber =
	 * common.connectDBAndGetValue(queryToGetLocNo,
	 * PropUtils.getPropValue(configProp, "sqlODSServerName"));
	 * inputValues.put("LocationNumber", locNumber);
	 * 
	 * return inputValues;
	 * 
	 * }
	 */

	/*
	 * Raxsana Added
	 */
	public Map<String, String> inputValuesForTransaction(String clientName, String clientCountry, String isFuelFlag,
			String cardType) {
		Map<String, String> inputValues = new HashMap<String, String>();
		String locNumber;

		CommonInterfacePage CommonInterfacePage = new CommonInterfacePage(driver, test);
		Common common = new Common(driver, test);
		WFECommon wfeCommon = new WFECommon(driver, test);
		String clientNameInProp = PropUtils.getPropValue(configProp, clientName + "_" + clientCountry);

		if (clientName.equalsIgnoreCase("WFE")) {
			String currentDate = common.getCurrentIFCSDateFromDB(clientNameInProp);
			// Get the IFCS current date
			String ifcsCurrentDate = common.enterADateValueInStatusBeginDateField("Current", currentDate);
			inputValues.put("date", ifcsCurrentDate);
		} else {
			String date = CommonInterfacePage.funcFetchLoadCardTransStartDateFromIFCSDB(configProp, clientNameInProp);
			inputValues.put("date", date);
		}
		/*
		 * String queryToGetInputValues =
		 * "select distinct t.card_no,c.expires_on,tp.external_code," +
		 * "t.customer_amount,d.driver_id,t.posted_at from transactions t\r\n" +
		 * "inner join cards c on t.card_oid = c.card_oid\r\n" +
		 * "inner join card_programs cp on c.card_program_oid = cp.card_program_oid\r\n"
		 * + "inner join PRODUCT_THRESHOLDS pt on t.product_oid = pt.product_oid\r\n" +
		 * "inner join PRODUCT_TRANSLATIONS tp on tp.product_oid = pt.product_oid\r\n" +
		 * "inner join drivers d on t.driver_oid=d.driver_oid\r\n" +
		 * "where cp.client_mid = (select client_mid from m_clients where name ='" +
		 * clientNameInProp + "')\r\n" + "order by t.posted_at desc"; Map<String,
		 * String> inputReturnValues =
		 * common.connectDBAndGetDBEntireRowValues(queryToGetInputValues,
		 * PropUtils.getPropValue(configProp, "sqlODSServerName"));
		 * inputValues.putAll(inputReturnValues);
		 */
		String cardNumber;
		if (cardType.equalsIgnoreCase("Replace")) {
			cardNumber = common.getReplacedCardNumberFromIFCSDB(clientName, clientCountry, "Active");

		} else {
			cardNumber = common.getCardNumberFromIFCSDB(clientName, clientCountry, "Active");
		}
		inputValues.put("CardNumber", cardNumber);

		Map<String, String> lineItems = null;
		if (isFuelFlag.equalsIgnoreCase("Y")) {
			lineItems = CommonInterfacePage.getTransactionLineItem(configProp, cardNumber, clientName, clientCountry);

		} else {
			lineItems = wfeCommon.getTransactionLineItemForNonFuels(configProp, cardNumber, clientName, clientCountry);
		}
		inputValues.putAll(lineItems);
	
		String queryToGetLocNo = "select external_code from m_locations ml\r\n"
				+ "inner join addresses ad on ml.postal_address_oid=ad.address_oid\r\n"
				+ "inner join countries c on c.country_oid=ad.country_oid where "
				+ "ml.client_mid=(select client_mid from m_clients where name='"
				+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountry) + "') and c.country_code='"
				+ clientCountry + "' and name not like '%VINCI%'";
		locNumber = common.connectDBAndGetValue(queryToGetLocNo,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		inputValues.put("LocationNumber", locNumber);

		return inputValues;

	}

	/*
	 * Raxsana Added
	 */
	public Map<String, String> inputValuesForDualCardsTransaction(String clientName, String clientCountry,
			String isFuelFlag) {
		Map<String, String> inputValues = new HashMap<String, String>();
		String locNumber;

		CommonInterfacePage CommonInterfacePage = new CommonInterfacePage(driver, test);
		Common common = new Common(driver, test);
		WFECommon wfeCommon = new WFECommon(driver, test);
		String clientNameInProp = PropUtils.getPropValue(configProp, clientName + "_" + clientCountry);

		if (clientName.equalsIgnoreCase("WFE")) {
			String currentDate = common.getCurrentIFCSDateFromDB(clientNameInProp);
			// Get the IFCS current date
			String ifcsCurrentDate = common.enterADateValueInStatusBeginDateField("Current", currentDate);
			inputValues.put("date", ifcsCurrentDate);
		} else {
			String date = CommonInterfacePage.funcFetchLoadCardTransStartDateFromIFCSDB(configProp, clientNameInProp);
			inputValues.put("date", date);
		}
		ArrayList<String> cardNumbers = common.getActivedualCardNumberFromDBWFE(clientName, clientCountry);
		inputValues.put("CardNumber", cardNumbers.get(0));
		inputValues.put("DualCardNumber", cardNumbers.get(1));
		Map<String, String> lineItems = null;
		if (isFuelFlag.equalsIgnoreCase("Y")) {
			lineItems = CommonInterfacePage.getTransactionLineItem(configProp, cardNumbers.get(0), clientName,
					clientCountry);

		} else {
			lineItems = wfeCommon.getTransactionLineItemForNonFuels(configProp, cardNumbers.get(0), clientName,
					clientCountry);
		}
		inputValues.putAll(lineItems);
		locNumber = wfeCommon.getLocationNumberForWFE(clientName, clientCountry);
		inputValues.put("LocationNumber", locNumber);

		return inputValues;

	}

	/*
	 * Rathna added
	 */
	public Map<String, String> inputValuesForTransactionRefNumber(String clientName, String clientCountry) {

		Map<String, String> inputValues = new HashMap<String, String>();
		String locNumber = null, cardNumber = null, refNo = null;
		Map<String, String> lineitem = new HashMap<>();
		WFECommon wfeCommon = new WFECommon(driver, test);
		CommonInterfacePage CommonInterfacePage = new CommonInterfacePage(driver, test);
		Common common = new Common(driver, test);
		String clientNameInProp = PropUtils.getPropValue(configProp, clientName + "_" + clientCountry);

		String date = CommonInterfacePage.funcFetchLoadCardTransStartDateFromIFCSDB(configProp, clientNameInProp);
		inputValues.put("date", date);

		cardNumber = getVehicleCardNumberFromIFCSDB(clientName, clientCountry);
		inputValues.put("CardNumber", cardNumber);
		inputValues.put("DuplicateCardNumber", cardNumber);

		lineitem = CommonInterfacePage.getTransactionLineItem(configProp, cardNumber, clientName, clientCountry);
		inputValues.putAll(lineitem);

		refNo = common.getUniqReferenceNumber();
		System.out.println("Ref No:" + refNo);
		inputValues.put("RefNo", refNo);

		// inputValues.put("EXTERNAL_CODE", "30");

		/*
		 * // added rathna as loc number is empty String queryToGetLocNo =
		 * "select location_no from m_locations where" +
		 * " client_mid=(select client_mid from m_clients where name='" +
		 * PropUtils.getPropValue(configProp, clientName + "_" + clientCountry) + "')";
		 * locNumber = common.connectDBAndGetValue(queryToGetLocNo,
		 * PropUtils.getPropValue(configProp, "sqlODSServerName"));
		 */

		locNumber = wfeCommon.getLocationNumberForWFE(clientName, clientCountry);

		inputValues.put("LocationNumber", locNumber);

		return inputValues;

	}

	/*
	 * Raxsana Added
	 */

	public Map<String, String> inputValuesForCrossBorderTransactionWithRebates(String clientName,
			String clientCountry) {

		CommonInterfacePage CommonInterfacePage = new CommonInterfacePage(driver, test);
		Common common = new Common(driver, test);
		String clientNameInProp = PropUtils.getPropValue(configProp, clientName + "_" + clientCountry);
		Map<String, String> inputValues = new HashMap<String, String>();
		String locNumber;

		if (clientName.equalsIgnoreCase("WFE")) {
			String currentDate = common.getCurrentIFCSDateFromDB(clientNameInProp);
			// Get the IFCS current date
			String ifcsCurrentDate = common.enterADateValueInStatusBeginDateField("Current", currentDate);
			inputValues.put("date", ifcsCurrentDate);
		} else {
			String date = CommonInterfacePage.funcFetchLoadCardTransStartDateFromIFCSDB(configProp, clientNameInProp);
			inputValues.put("date", date);
		}

		String crossBorderClientCountry = "";
		if (clientCountry.equalsIgnoreCase("BE") || clientCountry.equalsIgnoreCase("LU")
				|| clientCountry.equalsIgnoreCase("FR")) {
			crossBorderClientCountry = "NL";
		} else if (clientCountry.equalsIgnoreCase("NL")) {
			crossBorderClientCountry = "BE";
		}
		inputValues.put("crossBorderClientCountry", crossBorderClientCountry);
		String queryToGetCardNumber = "select c.card_no from cards c \r\n"
				+ "inner join m_customers mc on mc.customer_mid=c.customer_mid\r\n"
				+ "inner join rebate_profiles rp on rp.customer_mid=mc.customer_mid\r\n"
				+ "inner join rebates r on r.rebate_profile_oid=rp.rebate_profile_oid\r\n"
				+ "inner join card_status cs on cs.card_status_oid=c.card_status_oid\r\n"
				+ "inner join accounts ac on ac.customer_mid=mc.customer_mid\r\n"
				+ "inner join account_status acs on acs.account_status_oid=ac.account_status_oid\r\n"
				+ "inner join product_groups pg on r.product_group_oid=pg.product_group_oid\r\n"
				+ "where  mc.client_mid in (select client_mid from m_clients where name='" + clientNameInProp
				+ "') \r\n" + "and cs.description like '%Normal Service%' and acs.description like '%Active%'\r\n"
				+ "and r.product_group_oid in (select product_group_oid from product_groups where description like '%All Diesels%' or description like '%All Fuels%' "
				+ "and external_client_code like '" + clientName + "_" + clientCountry + "') \r\n"
				+ "order by rp.effective_on desc";
		String cardNumber = common.connectDBAndGetValue(queryToGetCardNumber,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		inputValues.put("CardNumber", cardNumber);

		/*
		 * Map<String, String> lineItems = null; if (isFuelFlag.equalsIgnoreCase("Y")) {
		 * lineItems = CommonInterfacePage.getTransactionLineItem(configProp,
		 * cardNumber, clientName, clientCountry);
		 * 
		 * } else { lineItems = wfeCommon.getTransactionLineItemForNonFuels(configProp,
		 * cardNumber, clientName, clientCountry); } inputValues.putAll(lineItems);
		 */

		inputValues.put("LocationClientCountry", crossBorderClientCountry);
		String queryToGetLocNo = "select distinct location_no from m_locations ml inner join addresses ad on ml.postal_address_oid=ad.address_oid\r\n"
				+ "inner join countries c on c.country_oid=ad.country_oid where ml.location_mid in (select member_oid from relationships r\r\n"
				+ "inner join RELATIONSHIP_ASSIGNMENTS ra on r.relationship_oid=ra.relationship_oid \r\n"
				+ "where ra.expires_on >= (SELECT PROCESSING_DATE from M_CLIENTS where Name ='"
				+ PropUtils.getPropValue(configProp, clientName + "_" + crossBorderClientCountry) + "') and \r\n"
				+ "ra.effective_on <= (SELECT PROCESSING_DATE from M_CLIENTS where Name ='"
				+ PropUtils.getPropValue(configProp, clientName + "_" + crossBorderClientCountry) + "')) \r\n"
				+ "and ml.client_mid=(select client_mid from m_clients where name='"
				+ PropUtils.getPropValue(configProp, clientName + "_" + crossBorderClientCountry) + "')";
		locNumber = common.connectDBAndGetValue(queryToGetLocNo,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		inputValues.put("LocationNumber", locNumber);

		String queryToGetNetwork = "select distinct mg.description from m_locations l\r\n"
				+ "inner join LOCATION_RECONCILIATIONS lr on lr.location_mid=l.location_mid\r\n"
				+ "inner join merchant_agreements ma on ma.merchant_agreement_oid=lr.merchant_agreement_oid\r\n"
				+ "inner join merch_agrmnt_values mg on mg.merch_agrmnt_value_oid=ma.merch_agrmnt_value_1_oid\r\n"
				+ "inner join merch_agrmnt_value_types mgt on mgt.merch_agrmnt_value_type_oid=mg.merch_agrmnt_value_type_oid\r\n"
				+ "where l.location_no='" + locNumber + "' and mgt.description='Network'";
		String network = common.connectDBAndGetValue(queryToGetNetwork,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		inputValues.put("network", network);

		return inputValues;
	}

	/*
	 * Raxsana Added
	 * 
	 */
	public void setComplexPricingForInternationalTransaction(Map<String, String> inputvalues, String clientName,
			String clientCountry) {
		Common common = new Common(driver, test);
		MaintainCustomerPage maintainCustomerPage = new MaintainCustomerPage(driver, test);
		String currentDate = common
				.getCurrentIFCSDateFromDB(PropUtils.getPropValue(configProp, clientName + "_" + clientCountry));
		// Get the IFCS current date
		String ifcsDate = common.enterADateValueInStatusBeginDateField("oneDayBefore", currentDate);
		maintainCustomerPage.chooseCardDetailsMenuCardMaintenance();
		common.searchTorch();
		common.chooseNoAndSearch("Card Number", inputvalues.get("CardNumber"));
		common.findRecordTorch();
		sleep(3);
		common.closeFindRecordTorch();
		sleep(3);
		chooseSubMenuFromLeftPanel("Customer Profiles", "Complex Pricing");
		sleep(3);
		try {
			String element = driver.findElement(By
					.xpath("//div[@class='FALTableCellEditor_StrikeThruField JTextComponent']//input[@submittedvalue='"
							+ inputvalues.get("network") + "']"))
					.getAttribute("id");
			System.out.println("id tag::" + element);
			String row = element.split("_")[5];
			// System.out.println("row string::"+row);
			String element1 = driver.findElement(
					By.xpath("//div[@class='FALTableCellEditor_StrikeThruField JTextComponent']//input[contains(@id,'_"
							+ row + "_0Input')]"))
					.getAttribute("submittedvalue");
			String element2 = driver.findElement(
					By.xpath("//div[@class='FALTableCellEditor_StrikeThruField JTextComponent']//input[contains(@id,'_"
							+ row + "_1Input')]"))
					.getAttribute("submittedvalue");
			System.out.println("Values::" + element1 + "---" + element2);
			if (element1.equalsIgnoreCase("Pump - Discount") && element2.equalsIgnoreCase(PropUtils
					.getPropValue(configProp, clientName + "_" + inputvalues.get("crossBorderClientCountry")))) {
			} else {
				throw new Exception();
			}
		} catch (Exception ex) {
			rightClick(driver.findElement(By.xpath("//div[@class='JFALTable']")));
			common.addIteminPopup();
			sleep(2);
			try {
				if (!(inputvalues.get("crossBorderClientCountry").equalsIgnoreCase(""))) {
					chooseOptionFromDropdown("Client", PropUtils.getPropValue(configProp,
							clientName + "_" + inputvalues.get("crossBorderClientCountry")));
				}
			} catch (Exception e) {
				chooseOptionFromDropdown("Client",
						PropUtils.getPropValue(configProp, clientName + "_" + clientCountry));
			}

			chooseOptionFromDropdown("Card Product Group", clientCountry + " Card Products");
			chooseOptionFromDropdown("Site Price Class", inputvalues.get("network"));
			// chooseOptionFromDropdown("Product Group","All Diesels");
			chooseOptionFromDropdown("Pricing Profile", "Pump - Discount");
			enterDateInDropdown("Assigned From", ifcsDate);
			common.clickOkButton();
			sleep(3);
			common.clickSaveIcon();
			sleep(3);
			verifyValidationResult("Record saved OK");
		}
	}

	public void setRebatesForInternationalTransaction(Map<String,String> inputValues,String clientName,String clientCountry) {
		MaintainCustomerPage maintainCustomerPage=new MaintainCustomerPage(driver,test);
		
		//chooseSubMenuFromLeftPanel("Maintain Customer", "");
		chooseSubMenuFromLeftPanel("Customer Profiles", "Rebates");
		validateHeaderLabel("Rebates");
		detailSearch();
		sleep(10);

		WebElement element = SeleniumWrappers.getTableDataWithCellElement(0, 3, driver);

		WebElement location = driver.findElement(By.xpath(
				"//div[@class='JFALSeparator']//div[contains(text(),'Rebate') and contains(text(),'Profiles')]/preceding::div[@class ='JFALCompControlPanel'][2]//div[contains(@id,'_0_3')]//*[2]"));

		System.out.println("Element value :++++ " + element);
		rightClickAndSelectMenuItem("Sort", location, popupMenuItemSort);
		//sleep(5);
		try {
		WebElement privateElement=driver.findElement(By.xpath("//div[@class='htmlImage'][contains(@style,'ok.gif')]"));
		isDisplayedThenClick(privateElement,"Element");
		rightClickAndSelectMenuItem("Details", privateElement, poupMenuItemDetails);
		rightClick(driver.findElement(By.xpath("//div[@class='JFALSeparator']//div[@class='JFALSeparator_1']/div[contains(text(),'Details')]//preceding::div[@class='JViewport'][2]")));
		addIteminPopup();
		maintainCustomerPage.enterDetailsInRebateDetailsPopup();
		}
		catch(Exception e) {
			e.getMessage();
		}
		
	}
	
	public void validateRebatesApplied() {
		switchTabDetails("Customer Breakdown");
		String siteRebateValue = driver.findElement(By.xpath(
				"//div[@class='FALTableCellEditor_StrikeThruField JTextComponent'][contains(@id,'_1_1')]//div[@class='htmlString']"))
				.getText();
		String networkRebateValue = driver.findElement(By.xpath(
				"//div[@class='FALTableCellEditor_StrikeThruField JTextComponent'][contains(@id,'_2_1')]//div[@class='htmlString']"))
				.getText();
		String customerRebateValue = driver.findElement(By.xpath(
				"//div[@class='FALTableCellEditor_StrikeThruField JTextComponent'][contains(@id,'_3_1')]//div[@class='htmlString']"))
				.getText();
		System.out.println(siteRebateValue + "--" + networkRebateValue + "----" + customerRebateValue);
		if (siteRebateValue.equalsIgnoreCase("0.0000") && networkRebateValue.equalsIgnoreCase("0.0000")
				&& customerRebateValue.equalsIgnoreCase("0.0000")) {
			logFail("Rebates not applied");
		} else {
			logPass("Rebates applied");
		}

	}

	public void validateRebatesNotApplied() {
		switchTabDetails("Customer Breakdown");
		String siteRebateValue = driver.findElement(By.xpath(
				"//div[@class='FALTableCellEditor_StrikeThruField JTextComponent'][contains(@id,'_1_1')]//div[@class='htmlString']"))
				.getText();
		String networkRebateValue = driver.findElement(By.xpath(
				"//div[@class='FALTableCellEditor_StrikeThruField JTextComponent'][contains(@id,'_2_1')]//div[@class='htmlString']"))
				.getText();
		String customerRebateValue = driver.findElement(By.xpath(
				"//div[@class='FALTableCellEditor_StrikeThruField JTextComponent'][contains(@id,'_3_1')]//div[@class='htmlString']"))
				.getText();
		System.out.println(siteRebateValue + "--" + networkRebateValue + "----" + customerRebateValue);
		if (siteRebateValue.equalsIgnoreCase("0.0000") && networkRebateValue.equalsIgnoreCase("0.0000")
				&& customerRebateValue.equalsIgnoreCase("0.0000")) {
			logPass("Rebates not applied");
		} else {
			logFail("Rebates applied");
		}
	}

	public Map<String, String> inputValuesForManualTransactionWithRebates(String clientName, String clientCountry) {

		CommonInterfacePage CommonInterfacePage = new CommonInterfacePage(driver, test);
		Common common = new Common(driver, test);
		WFECommon wfeCommon = new WFECommon(driver, test);
		String clientNameInProp = PropUtils.getPropValue(configProp, clientName + "_" + clientCountry);
		Map<String, String> inputValues = new HashMap<String, String>();
		String locNumber;

		if (clientName.equalsIgnoreCase("WFE")) {
			String currentDate = common.getCurrentIFCSDateFromDB(clientNameInProp);
			// Get the IFCS current date
			String ifcsCurrentDate = common.enterADateValueInStatusBeginDateField("Current", currentDate);
			inputValues.put("date", ifcsCurrentDate);
		} else {
			String date = CommonInterfacePage.funcFetchLoadCardTransStartDateFromIFCSDB(configProp, clientNameInProp);
			inputValues.put("date", date);
		}
		String queryToGetCardNumber = "select c.card_no from cards c \r\n"
				+ "inner join m_customers mc on mc.customer_mid=c.customer_mid\r\n"
				+ "inner join rebate_profiles rp on rp.customer_mid=mc.customer_mid\r\n"
				+ "inner join rebates r on r.rebate_profile_oid=rp.rebate_profile_oid\r\n"
				+ "inner join card_status cs on cs.card_status_oid=c.card_status_oid\r\n"
				+ "inner join accounts ac on ac.customer_mid=mc.customer_mid\r\n"
				+ "inner join account_status acs on acs.account_status_oid=ac.account_status_oid\r\n"
				+ "inner join product_groups pg on r.product_group_oid=pg.product_group_oid\r\n"
				+ "where  mc.client_mid in (select client_mid from m_clients where name='" + clientNameInProp
				+ "') \r\n" + "and cs.description like '%Normal Service%' and acs.description like '%Active%'\r\n"
				+ "and r.product_group_oid in (select product_group_oid from product_groups where description like '%All Diesels%' or description like '%All Fuels%' "
				+ "and external_client_code like '" + clientName + "_" + clientCountry + "') \r\n"
				+ "order by rp.effective_on desc";
		String cardNumber = common.connectDBAndGetValue(queryToGetCardNumber,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		inputValues.put("CardNumber", cardNumber);
		locNumber = wfeCommon.getLocationNumberForWFE(clientName, clientCountry);
		inputValues.put("LocationNumber", locNumber);

		String queryToGetNetwork = "select distinct mg.description from m_locations l\r\n"
				+ "inner join LOCATION_RECONCILIATIONS lr on lr.location_mid=l.location_mid\r\n"
				+ "inner join merchant_agreements ma on ma.merchant_agreement_oid=lr.merchant_agreement_oid\r\n"
				+ "inner join merch_agrmnt_values mg on mg.merch_agrmnt_value_oid=ma.merch_agrmnt_value_1_oid\r\n"
				+ "inner join merch_agrmnt_value_types mgt on mgt.merch_agrmnt_value_type_oid=mg.merch_agrmnt_value_type_oid\r\n"
				+ "where l.location_no='" + locNumber + "' and mgt.description='Network'";
		String network = common.connectDBAndGetValue(queryToGetNetwork,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		inputValues.put("network", network);

		return inputValues;

	}

	/*
	 * Raxsana Added
	 */
	public void validateTaxAmountForCustomerBreakdown() {
		DecimalFormat decimalFormat = new DecimalFormat("#.##");
		switchTabDetails("Customer Breakdown");
		String taxRate = driver.findElement(By.xpath("//div[@ajs_id='tax_rate']//div[@class='htmlString']")).getText();
		String customerUnitPrice = driver
				.findElement(By.xpath("//div[@ajs_id='customer_unit_price']//div[@class='htmlString']")).getText();
		System.out.println("taxRate::" + taxRate + "-------->" + customerUnitPrice);
		String originalUnitPrice = driver
				.findElement(By.xpath("//div[@ajs_id='original_unit_price']//div[@class='htmlString']")).getText();
		System.out.println("originalUnitPrice::" + originalUnitPrice);
		String taxTotal = driver.findElement(By.xpath("//div[@ajs_id='customer_tax_amount']//div[@class='htmlString']"))
				.getText();
		System.out.println("taxTotal:" + taxTotal);
		String customerTotalTax;
		if (!(originalUnitPrice.equalsIgnoreCase("1000.0000"))) {
			customerTotalTax = String
					.valueOf((Double.parseDouble(customerUnitPrice) * Double.parseDouble(taxRate)) / 100);
		} else {
			customerTotalTax = String.valueOf((Double.parseDouble(customerUnitPrice) * Double.parseDouble(taxRate))
					/ Double.parseDouble(originalUnitPrice));
		}
		System.out.println("customerTotalTax::" + customerTotalTax);
		decimalFormat.setRoundingMode(RoundingMode.UP);
		System.out.println("decimal tax::" + decimalFormat.format(Float.parseFloat(customerTotalTax)));
		String customerValue = String.valueOf(decimalFormat.format(Float.parseFloat(customerTotalTax)));
		if (customerValue.equalsIgnoreCase(taxTotal)) {
			logPass("Tax Applied");
		} else {
			logFail("Tax not applied");
		}
	}

	/*
	 * Raxsana Added on 18/09/2020
	 */
	public void validateCustomerBreakdown(String refNo) {
		// switchTabDetails("Customer Breakdown");
		Common common = new Common(driver, test);
		validateTaxAmountForCustomerBreakdown();
		String queryToGetvalues = "select customer_amount,customer_tax_amount,p.description from transactions t inner join products p on t.product_oid=p.product_oid where reference='"
				+ refNo + "'";
		Map<String, String> values = common.connectDBAndGetDBEntireRowValues(queryToGetvalues,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		String productDescription = driver.findElement(By.xpath("//input[contains(@id,'_0_0Input')]"))
				.getAttribute("value");
		String customerAmount = driver.findElement(By.xpath("//input[contains(@id,'_0_4Input')]"))
				.getAttribute("value");
		String taxAmount = driver.findElement(By.xpath("//input[contains(@id,'_0_6Input')]")).getAttribute("value");
		String quantity = driver.findElement(By.xpath("//input[contains(@id,'_0_1Input')]")).getAttribute("value");
		String customerAmountTotal;
		if (values.get("CUSTOMER_AMOUNT").contains(".")) {
			customerAmountTotal = values.get("CUSTOMER_AMOUNT");
		} else {
			customerAmountTotal = values.get("CUSTOMER_AMOUNT") + ".00";
		}
		System.out.println(
				"Total:" + productDescription + "->" + customerAmount + "->" + taxAmount + "-->" + customerAmountTotal);
		if (!(values.isEmpty())) {
			if (productDescription.equalsIgnoreCase(values.get("DESCRIPTION"))
					&& (customerAmount).equalsIgnoreCase(customerAmountTotal)
					&& taxAmount.equalsIgnoreCase(values.get("CUSTOMER_TAX_AMOUNT"))
					&& quantity.equalsIgnoreCase("100.000")) {
				logPass("Customer breakdown values matched");
			} else {
				logFail("Customer breakdown values not matched");
			}
		} else {
			logFail("Transaction not posted");
		}

	}

	/*
	 * Raxsana Added on 18/09/2020
	 */
	public void validateMerchantBreakdown(String refNo) {
		Common common = new Common(driver, test);
		switchTabDetails("Merchant Breakdown");
		String queryToGetvalues = "select merchant_amount,merchant_tax_amount,p.description from transactions t inner join products p on t.product_oid=p.product_oid where reference='"
				+ refNo + "'";
		Map<String, String> values = common.connectDBAndGetDBEntireRowValues(queryToGetvalues,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		String productDescription = driver
				.findElement(By.xpath("//input[contains(@id,'_0_0Input')][@value='" + values.get("DESCRIPTION") + "']"))
				.getAttribute("value");
		String merchantAmount = driver.findElement(By.xpath("//input[contains(@id,'_0_4Input')]"))
				.getAttribute("value");
		String taxAmount = driver.findElement(By.xpath("//input[contains(@id,'_0_5Input')]")).getAttribute("value");
		String quantity = driver.findElement(By.xpath("//input[contains(@id,'_0_1Input')][@value='100.000']"))
				.getAttribute("value");
		System.out.println("Total:" + productDescription + "->" + merchantAmount + "->" + taxAmount);
		String merchantAmountTotal, merchantTaxAmount;
		if (values.get("MERCHANT_AMOUNT").contains(".")) {
			merchantAmountTotal = values.get("MERCHANT_AMOUNT");
			merchantTaxAmount = values.get("MERCHANT_TAX_AMOUNT") + "00";
		} else {
			merchantAmountTotal = values.get("MERCHANT_AMOUNT") + ".00";
			merchantTaxAmount = values.get("MERCHANT_TAX_AMOUNT") + "00";
		}
		System.out.println(merchantAmountTotal + "-->" + merchantTaxAmount);
		if (!(values.isEmpty())) {
			if (productDescription.equalsIgnoreCase(values.get("DESCRIPTION"))
					&& merchantAmount.equalsIgnoreCase(merchantAmountTotal)
					&& taxAmount.equalsIgnoreCase(merchantTaxAmount) && quantity.equalsIgnoreCase("100.000")) {
				logPass("Merchant breakdown values matched");
			} else {
				logFail("Merchant breakdown values not matched");
			}
		} else {
			logFail("Transaction not posted");
		}
	}


	public void validateSuspendedtransaction(String referenceNo, String errorMsg) {
		Common common = new Common(driver, test);
		chooseSubMenuFromLeftPanel("Suspended Transactions", "");

		validateHeaderLabel("Suspended Transactions");

		common.detailSearch();
		// common.clearingAllTextBoxes(textBoxes);
		common.enterValueInTextBox("Filter By", "Reference No", referenceNo);
		sleep(2);
		common.searchListTorch();
		sleep(3);
		String refNo = SeleniumWrappers.getTableDataWithRowAndColumnNumber(3, 0, driver);

		if (refNo.equals(referenceNo)) {

			String error = SeleniumWrappers.getTableDataWithRowAndColumnNumber(6, 0, driver);

			if (error.equalsIgnoreCase(errorMsg)) {
				System.out.println("Correct Error message displayed");
			} else {
				System.out.println("Wrong  Error message displayed");

			}

		} else {
			System.out.println("Taansation not available in suspended transaction list");
		}

	}
	/*
	 * updated by raxsana 03/11/2020
	 */
	public void disputeTransaction(String date) {
		Common common = new Common(driver, test);
		chooseSubMenuFromLeftPanel("Customer Transactions", "Transactions");
		sleep(5);
		String Date=date.split(" ")[0];
		String[] DateAlign=Date.split("-");
		enterValueInTextBox("Transaction Filter Fields", "Process Date From", DateAlign[2]+"/"+DateAlign[1]+"/"+DateAlign[0]);
		sleep(3);
		common.searchListTorch();
		sleep(5);
		common.clickDisputeIcon();
		sleep(5);
		common.verifyValidationResult("Invalid Configuration, Transaction Type may not be Disputed");

	}

	public void validateMonthEndfeeTransaction(String monthEndDate, String cardNo, String transactionType) {
		Common common = new Common(driver, test);

		chooseSubMenuFromLeftPanel("Client Transactions", "Transactions");

		chooseOptionFromDropdown("Transaction Type", transactionType);
		enterValueInTextBox("Transaction Filter Fields", "Card Number", cardNo);
		enterValueInTextBox("Transaction Filter Fields", "Process Date From", monthEndDate);
		enterValueInTextBox("Transaction Filter Fields", "Process Date To", monthEndDate);

		sleep(2);
		common.searchListTorch();
		sleep(5);

		String refNo = SeleniumWrappers.getTableDataWithRowAndColumnNumber(3, 0, driver);

		if (refNo.contains("Monthly Card")) {
			common.logPass("Card fee transaction posted");
			System.out.println("Card fee transaction posted");
		} else if (refNo.contains("Monthly Vinci")) {
			common.logPass("Card fee transaction posted");
			System.out.println("Card fee transaction posted");
		} else {
			common.logFail("Monthly fee transaction not posted");
			System.out.println("monthly fee transaction not posted");
		}

	}

	/*
	 * Raxsana added 29/09/2020
	 */

	public Map<String, String> inputValuesForCorsicaMerchantTransaction(String clientName, String clientCountry) {
		Map<String, String> inputValues = new HashMap<String, String>();

		CommonInterfacePage CommonInterfacePage = new CommonInterfacePage(driver, test);
		Common common = new Common(driver, test);
		String clientNameInProp = PropUtils.getPropValue(configProp, clientName + "_" + clientCountry);

		if (clientName.equalsIgnoreCase("WFE")) {
			String currentDate = common.getCurrentIFCSDateFromDB(clientNameInProp);
			// Get the IFCS current date
			String ifcsCurrentDate = common.enterADateValueInStatusBeginDateField("Current", currentDate);
			inputValues.put("date", ifcsCurrentDate);
		} else {
			String date = CommonInterfacePage.funcFetchLoadCardTransStartDateFromIFCSDB(configProp, clientNameInProp);
			inputValues.put("date", date);
		}

		String cardNumber;
		cardNumber = common.getCardNumberFromIFCSDB(clientName, clientCountry, "Active");
		inputValues.put("CardNumber", cardNumber);

		Map<String, String> lineItems = null;
		lineItems = CommonInterfacePage.getTransactionLineItem(configProp, cardNumber, clientName, clientCountry);
		inputValues.putAll(lineItems);

		String queryToGetLocNo = "select external_code,name from m_locations ml\r\n"
				+ "inner join addresses ad on ml.postal_address_oid=ad.address_oid\r\n"
				+ "inner join countries c on c.country_oid=ad.country_oid\r\n"
				+ "where name like '%VITO%' and client_mid=(select client_mid from m_clients where name='WFE France') and c.country_code='FR'";
		Map<String, String> locNumber = common.connectDBAndGetDBEntireRowValues(queryToGetLocNo,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		inputValues.put("LocationNumber", locNumber.get("EXTERNAL_CODE"));
		inputValues.put("LocationName", locNumber.get("NAME"));
		return inputValues;
	}

	/*
	 * Raxsana Added on 30/09/2020
	 */
	public void validateTaxAppliedForCorsicaMerchant(Map<String, String> valuesForValidation) {
		Common common = new Common(driver, test);
		String queryToGetTransactionValues = "select tax_rate,customer_tax_amount,customer_unit_price,quantity from TRANSACTION_LINE_ITEMS where transaction_oid=(select transaction_oid from transactions where reference='"
				+ valuesForValidation.get("ReferenceNo") + "')";
		Map<String, String> transactionValues = common.connectDBAndGetDBEntireRowValues(queryToGetTransactionValues,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		DecimalFormat df = new DecimalFormat("##.##");
		String taxRate = transactionValues.get("TAX_RATE");
		String customerUnitPrice = transactionValues.get("CUSTOMER_UNIT_PRICE");
		String customerTaxAmount = transactionValues.get("CUSTOMER_TAX_AMOUNT");
		String quantity = transactionValues.get("QUANTITY");
		double taxTotal = ((Double.parseDouble(customerUnitPrice) * Double.parseDouble(quantity)) / 100)
				* (Double.parseDouble(taxRate) / 100);
		String taxTotalFromDB = df.format(Double.parseDouble(customerTaxAmount));
		System.out
				.println("taxTotal::" + df.format(taxTotal) + "-->" + df.format(Double.parseDouble(customerTaxAmount)));
		if (taxTotalFromDB.equalsIgnoreCase(df.format(taxTotal))) {
			logPass("Tax Applied for Corsica merchant");
		} else {
			logFail("Tax not Applied for Corsica merchant");
		}
	}
	
	/*
	 * Raxsana added on 06/11/2020
	 */
	public Map<String, String> inputValuesForInvalidTime(String clientName,String clientCountry) {
		Map<String, String> inputValues = new HashMap<String, String>();

		Map<String, String> lineItem = null;
		String locNumber = null, cardNumber = null;
		WFECommon wfeCommon =new WFECommon(driver,test);
		Common common = new Common(driver, test);
		CommonInterfacePage CommonInterfacePage = new CommonInterfacePage(driver, test);

		//String clientNameInProp = PropUtils.getPropValue(configProp, clientName + "_" + clientCountry);
		
		cardNumber = common.getCardNumberFromIFCSDB(clientName, clientCountry, "Active");
		inputValues.put("CardNumber", cardNumber);
		String statusChangeTime = common.getStatusChangeTime(cardNumber);
		//String dateTime = common.getTimeBeforeStatusChange(statusChangeTime, 1);
		String dateTime=common.enterADateValueInStatusBeginDateField("oneDayBefore", statusChangeTime);
		System.out.println(statusChangeTime+" && "+dateTime);
		
		inputValues.put("date", dateTime);
		lineItem = CommonInterfacePage.getTransactionLineItem(configProp, cardNumber, clientName, clientCountry);
		inputValues.putAll(lineItem);

		locNumber = wfeCommon.getLocationNumberForWFE(clientName, clientCountry);

		inputValues.put("LocationNumber", locNumber);

		return inputValues;
	}
}
