package com.framework.testcases.OLS.EMAP.Customer;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.EMAP.EMAPCardsPage;
import com.framework.pages.EMAP.EMAPHomePage;
import com.framework.pages.OLS.common.CommonPage;
import com.framework.pages.OLS.common.LoginPage;

public class ValidateCardsPage extends BaseTest {
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "Regression" })
	public void checkTheCardsMenuPage(@Optional("SP") String clientCountry, @Optional("EMAP") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  TST-SC-69-OLS - cards menu,TST-SC-92-OLS-Card List-View Card",
				"Login to EMAP Customer - Read Only and check the Cards Menu");
		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		loginPage.Login("EMAP_URL", "EMAP_UN_ReadOnly_Customer_" + clientCountry,
				"EMAP_PWD_ReadOnly_Customer_" + clientCountry, clientName);
		EMAPHomePage emapHomePage = new EMAPHomePage(driver, test);
		EMAPCardsPage emapCardsPage = new EMAPCardsPage(driver, test);
		CommonPage commonPage = new CommonPage(driver, test);
		emapHomePage.validateEMAPCustomerLogo();
		emapHomePage.validateCustomerWelcomeText();
		emapCardsPage.checkThePresenceOfSubmenuItemsInCardsMenu("Read-Only");
		emapHomePage.clickCardListAndValidatePage();
		emapCardsPage.checkThePresenceOfExportCardOption();
		emapCardsPage.checkThePresenceOfSearchCardButton();
		commonPage.clickSearchButton();
		emapCardsPage.verifyTheListOfCardsFoundTableColumn(clientCountry);
		emapCardsPage.checkThePresenceOfCardFilterCriteria(clientCountry);

		// Card options check
		commonPage.selectAllAccountOptionFromAccountDropdown();
		commonPage.clickSearchButton();
		if (emapCardsPage.isCardsPresent()) {
			// Filter with Card Number
			emapCardsPage.selectACardFromCardListTable(false);
			emapCardsPage.enterSelectedCardNumberInCardNumberFilter();
			commonPage.clickSearchButton();
			emapCardsPage.verifyTheCardListTableWithCardNumber();

			// Filter with Card Status
			emapHomePage.clickCardListAndValidatePage();
			commonPage.selectAllAccountOptionFromAccountDropdown();
			emapCardsPage.selectACardStatus();
			commonPage.clickSearchButton();
			emapCardsPage.verifyTheCardListTableWithCardStatus();

			if (clientCountry.equals("HK") || clientCountry.equals("MO")) {
				// Filter with Card Product
				emapHomePage.clickCardListAndValidatePage();
				commonPage.selectAllAccountOptionFromAccountDropdown();
				emapCardsPage.selectACardProduct();
				commonPage.clickSearchButton();
				emapCardsPage.verifyTheCardListTableWithCardProduct();
			} else {
				// Filter with Card Offer
				emapHomePage.clickCardListAndValidatePage();
				commonPage.selectAllAccountOptionFromAccountDropdown();
				emapCardsPage.selectACardOffer();
				commonPage.clickSearchButton();
				emapCardsPage.verifyTheCardListTableWithCardOffer();
			}

			// Filter with Vehicle Description
			emapHomePage.clickCardListAndValidatePage();
			commonPage.selectAllAccountOptionFromAccountDropdown();
			emapCardsPage.enterVehicleDescription("T*");
			commonPage.clickSearchButton();
			emapCardsPage.verifyTheCardListTableWithVehicleDescription();

			// Context menu options
			emapHomePage.clickCardListAndValidatePage();
			commonPage.selectAllAccountOptionFromAccountDropdown();
			commonPage.clickSearchButton();
			emapCardsPage.selectACardFromCardListTable(true);
			emapCardsPage.clickContextMenuOptionAndVerifyCardNumberInNavigatedPage("View Card");
			emapCardsPage.verifySubCategoriesOnViewCardPage("View Card");

			// View Card Page Details
			emapCardsPage.verifyTheCardDetailsAreInViewMode(clientCountry);
			emapCardsPage.verifyTheVelocityControlFieldValues();

			// Back to Cards
			emapCardsPage.validateBackToCardListPageLink();
		}

		loginPage.Logout();
	}
}
