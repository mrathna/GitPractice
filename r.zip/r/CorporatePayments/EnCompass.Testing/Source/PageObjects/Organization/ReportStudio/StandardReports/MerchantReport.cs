﻿using Common;
using Common.Utility;
using EnCompass.Testing.Source.PageObjects.Organization.ExpenseManager.PurchaseLog;
using NFluent;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EnCompass.Testing.Source.PageObjects.Organization.ReportStudio.StandardReports
{
    [PageModel(@"/reportStudio/standardReports/merchantReport.aspx")]
    public class MerchantReport : EnCompassPageModel
    {
        public MerchantReport(GlobalSettings settings, ScheduleReport scheduleReport) : base(settings){ ScheduleReport = scheduleReport; }
        public ScheduleReport ScheduleReport { get; set; }

        public override string RelativeUrl => @"/reportStudio/standardReports/merchantReport.aspx";
        public override string PageIdentifierXPath_Override => @"//li[@class='breadcrumb-item active'][text() = 'Accounts Payable Merchants']";

        #region XPath page Elements
        private const string _executeRunXPath = @"//input[contains(@id,'StdReport_RunButton')]";
        private const string _formatXPath = @".//select[contains(@id, 'StdReport_FormatList')]";
        #endregion

        #region Page Elements
        private IWebElement _executeRun
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_executeRunXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_executeRun element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _format
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_formatXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_format element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        #endregion

        public void Run()
        {
            _executeRun.JSClickWithFocus(Driver);
        }

        public string Format
        {
            set
            {
                _format.SetListboxByText(value, SelectTextOptions.Contains);
                Settings.EnCompassExtentTest.Info("Selected User Report download format as :" + value);
            }
            get
            {
                SelectElement _elem = new SelectElement(_format);
                return _elem.SelectedOption.Text;
            }
        }
    }
}
