﻿using Common.Utility;
using EnCompass.Testing.Source.PageObjects.Controls;
using NFluent;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Support.UI;
using System;

namespace EnCompass.Testing.Source.PageObjects.Organization.Admin.TransactionEnvelope
{
    public partial class CalculatedFields
	{
        public override string PageIdentifierXPath_Override => @"//h1[contains(text(),'Envelope Calculated Fields')]";

        #region XPath page Elements

        private const string _btnSearchXPath = @"//input[contains(@id, 'btnSearch')]";
        private const string _addNewXPath = @"//a[contains(@href,'CalculatedFieldsDetails.aspx')]";
        private const string _calculatedFieldsNotFoundXPath = ".//td[normalize-space(text()) = 'No Out of Pocket Transaction Calculated Fields found.']";
        #endregion

        #region Page Elements
        private IWebElement _btnSearch
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_btnSearchXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_btnSearch element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _addNew
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_addNewXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_save element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _calculatedFieldsNotFound => new WebDriverWait(Settings.EnCompassWebDriver, TimeSpan.FromSeconds(10)).Until(ExpectedConditions.ElementIsVisible(By.XPath(_calculatedFieldsNotFoundXPath)));
        #endregion

        public void VerifySearchCriteriaEnvelopeCalculatedField()
		{
			Settings.EnCompassWebDriver.FindElement(By.XPath("//*[contains(@id, 'SearchOutput')]/select[1]"));
			Settings.EnCompassWebDriver.FindElement(By.XPath("//*[contains(@id, 'SearchOutput')][1]//*[contains(@value, 'Disabled')]"));
			Settings.EnCompassWebDriver.FindElement(By.XPath("//*[contains(@id, 'SearchOutput')][1]//*[contains(@value, 'Currency')]"));
			Settings.EnCompassWebDriver.FindElement(By.XPath("//*[contains(@id, 'SearchOutput')][1]//*[contains(@value, 'FieldName')]"));
			Settings.EnCompassWebDriver.FindElement(By.XPath("//*[contains(@id, 'SearchOutput')][1]//*[contains(@value, 'UseEffectiveDt')]"));
			Settings.EnCompassWebDriver.FindElement(By.XPath("//*[contains(@id, 'SearchOutput')][1]//*[contains(@value, 'UseThreshold')]"));
			Settings.EnCompassWebDriver.FindElement(By.XPath("//*[contains(@id, 'SearchOutput')][2]"));
			Settings.EnCompassWebDriver.FindElement(By.XPath("//*[contains(@id, 'SearchOutput')][3]"));
			Settings.EnCompassWebDriver.FindElement(By.XPath("//*[contains(@id, 'SearchOutput')]//*[contains(@value, 'Add')]"));
			Settings.EnCompassWebDriver.FindElement(By.XPath("//button[contains(text(), 'Clear')]"));
		}

		public void VerifyFieldsGridDisplaysNo()
		{
			Check.That(_calculatedFieldsNotFound).IsNotNull();
		}

		public void PressSearch()
		{
			_btnSearch.JSClickWithFocus(Driver);
		}

		public void PressAddNew()
		{
			_addNew.JSClickWithFocus(Driver);
		}
	}
}
