﻿using Common.Utility;
using NFluent;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace EnCompass.Testing.Source.PageObjects.Organization.ExpenseManager.PurchaseLog.Testing
{
    public partial class CreateTestTransactions
    {
        #region XPath Page Elements

        private const string _accountNumberXPath = "//input[contains(@id, 'AccountNoText')]";
        private const string _authorizationNumberXPath = "//input[contains(@id, 'AuthNoText')]";
        private const string _merchantLogIdXPath = "//input[contains(@id, 'UniqueIdText')]";
        private const string _amountXPath = "//input[contains(@id, 'tpTransaction_AmountText')]";
        private const string _merchantDescriptionXPath = "//input[contains(@id, 'MerchantText')]";
        private const string _postingDateXPath = "//input[contains(@id, 'PostingDateText')]";
        private const string _transactionDateXPath = "//input[contains(@id, 'TransactionDateText')]";
        private const string _currencyXPath = "//input[contains(@id, 'CurrencyText')]";
        private const string _forExSourceAmountXPath = "//input[contains(@id, 'SourceAmountText')]";
        private const string _referenceNumberXPath = "//input[contains(@id, 'ReferenceNoText')]";
        private const string _customerCodeXPath = "//input[contains(@id, 'CustomerCodeText')]";
        private const string _transactionTypeXPath = "//input[contains(@id, 'TransactionTypeText')]";
        private const string _transactionRadioBtnXPath = ".//label[text() = 'Transaction']/preceding-sibling::input";
        private const string _authorizationRadioBtnXPath = ".//label[text() = 'Authorization']/preceding-sibling::input";
        private const string _createBtnXPath = "//input[contains(@id, 'CreateButton')]";
        private const string _viewCorpCLInfoBtnXPath = "//input[contains(@id, 'ViewButton')]";
        private const string _runExpirationProcessBtnXPath = "//input[contains(@id, 'ExpireButton')]";
        private const string _expireDateTextXPath = "//input[contains(@id, 'ExpireDateText')]";
        private const string _corpRealTimeAvailableBalanceBtnXPath = "//input[contains(@id, 'CorpAvailableButton')]";
        private const string _corpRealTimeAvailableBalanceTextXPath = "//input[contains(@id, 'CorpAvailableText')]";
        private const string _corpAccountNumberXPath = "//div[@id='CorpInfoDiv']/ul/li[1]/strong";
        private const string _corpCreditLimitXPath = "//div[@id='CorpInfoDiv']/ul/li[2]/strong";
        private const string _closeCorpCLInfoBtnXPath = "//div[contains(@id, 'CorpInfoDiv')]/button[@type='button' and contains(text(), 'Close')]";
        private const string _payablesXPath = ".//select[contains(@id,'ddlAccountType')]";
        private const string _connectionWithTicketnumberXPath = "//input[contains(@id, 'txtConnectionwithTicketNumber')]";
        private const string _ancillaryPassengerNameXPath = "//input[contains(@id, 'txtAncillaryPassengerName')]";
        private const string _ancillaryTicketDocumentNumberXPath = "//input[contains(@id, 'txtTicketDocNo')]";
        private const string _ancillaryServiceCategoryXPath = "//select[contains(@id, 'ddlServiceCategory')]";

        #endregion

        #region Page Elements

        private IWebElement _accountNumber
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_accountNumberXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_accountNumber element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _authorizationNumber
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_authorizationNumberXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_authorizationNumber element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _merchantLogId
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_merchantLogIdXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_merchantLogId element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _amount
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_amountXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_amount element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _merchantDescription
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_merchantDescriptionXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_merchantDescription element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _postingDate
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_postingDateXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_postingDate element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _transactionDate
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_transactionDateXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_transactionDate element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _currency
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_currencyXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_currency element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _forExSourceAmount
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_forExSourceAmountXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_forExSourceAmount element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _referenceNumber
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_referenceNumberXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_referenceNumber element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _customerCode
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_customerCodeXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_customerCode element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _transactionType
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_transactionTypeXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_transactionType element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _transactionRadioBtn
        {
            get
            {
                //Radio button need to use TryWaitForElement, because the clickable element is not visible
                bool found = Driver.TryWaitForElement(By.XPath(_transactionRadioBtnXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_transactionRadioBtn element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _authorizationRadioBtn
        {
            get
            {
                //Radio button need to use TryWaitForElement, because the clickable element is not visible
                bool found = Driver.TryWaitForElement(By.XPath(_authorizationRadioBtnXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_authorizationRadioBtn element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _createBtn
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_createBtnXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_createBtn element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _viewCorpCLInfoBtn
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_viewCorpCLInfoBtnXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_viewCorpCLInfoBtn element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _runExpirationProcessBtn
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_runExpirationProcessBtnXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_runExpirationProcessBtn element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _expireDateText
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_expireDateTextXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_expireDateText element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _corpRealTimeAvailableBalanceBtn
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_corpRealTimeAvailableBalanceBtnXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_corpRealTimeAvailableBalanceBtn element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _corpRealTimeAvailableBalanceText
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_corpRealTimeAvailableBalanceTextXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_corpRealTimeAvailableBalanceText element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _corpAccountNumber
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_corpAccountNumberXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_corpAccountNumber element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _corpCreditLimit
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_corpCreditLimitXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_corpCreditLimit element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _closeCorpCLInfoBtn
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_closeCorpCLInfoBtnXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_closeCorpCLInfoBtn element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _payables
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_payablesXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_payables element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _connectionWithTicketnumber
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_connectionWithTicketnumberXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_connectionWithTicketnumber element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _ancillaryPassengerName
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_ancillaryPassengerNameXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_ancillaryPassengerName element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _ancillaryTicketDocumentNumber
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_ancillaryTicketDocumentNumberXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_ancillaryTicketDocumentNumber element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _ancillaryServiceCategory
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_ancillaryServiceCategoryXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_ancillaryServiceCategory element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        #endregion


        #region Side Navigation

        private const string _testing_CardsXPath = @"//ul[contains(@id, 'sideNav')]//li[1]";
		private IWebElement _testing_Cards
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_testing_CardsXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_testing_Cards element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        public void NavigateTo_Cards()
		{
			NavigateToMenuItem(_testing_Cards);
		}

        private const string _testing_CreateCardTransactionsXPath = @"//ul[contains(@id, 'sideNav')]//li[2]";
		private IWebElement _testing_CreateCardTransactions
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_testing_CreateCardTransactionsXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_testing_CreateCardTransactions element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        public void NavigateTo_CreateCardTransactions()
		{
			NavigateToMenuItem(_testing_CreateCardTransactions);
		}

        private const string _testing_SingleUseAccountsXPath = @"//ul[contains(@id, 'sideNav')]//li[3]";
		private IWebElement _testing_SingleUseAccounts
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_testing_SingleUseAccountsXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_testing_SingleUseAccounts element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        public void NavigateTo_SingleUseAccounts()
		{
			NavigateToMenuItem(_testing_SingleUseAccounts);
		}

        private const string _testing_SingleUseAccountTransactionsXPath = @"//ul[contains(@id, 'sideNav')]//li[4]";
		private IWebElement _testing_SingleUseAccountTransactions
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_testing_SingleUseAccountTransactionsXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_testing_SingleUseAccountTransactions element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        public void NavigateTo_SingleUseAccountTransactions()
		{
			NavigateToMenuItem(_testing_SingleUseAccountTransactions);
		}

        private const string _testing_CreditLimitUpdateXPath = @"//ul[contains(@id, 'sideNav')]//li[5]";
		private IWebElement _testing_CreditLimitUpdate
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_testing_CreditLimitUpdateXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_testing_CreditLimitUpdate element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        public void NavigateTo_CreditLimitUpdate()
		{
			NavigateToMenuItem(_testing_CreditLimitUpdate);
		}

        private const string _testing_DailyExtractFilesXPath = @"//ul[contains(@id, 'sideNav')]//li[6]";
		private IWebElement _testing_DailyExtractFiles
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_testing_DailyExtractFilesXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_testing_DailyExtractFiles element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        public void NavigateTo_DailyExtractFiles()
		{
			NavigateToMenuItem(_testing_DailyExtractFiles);
		}

        #endregion

        private const string _newButtonXpath = @"//input[contains(@name,'NewButton')]";

		public string Payables
		{
			set	{ new SelectElement(_payables).SelectByText(value);	}
            get	{ return new SelectElement(_payables).SelectedOption.GetAttribute("value");	}
		}

		public string AccountNumber
		{
			get { return _accountNumber.Text; }
			set { _accountNumber.SendKeys(value); }
		}

        public string AuthorizationNumber
        {
            get { return _authorizationNumber.Text; }
            set { _authorizationNumber.SendKeys(value); }
        }

		public string MerchantLogId
		{
            get { return _merchantLogId.GetAttribute("value"); }
			set { _merchantLogId.SendKeys(value); }
		}

		public string Amount
		{
			get { return _amount.Text; }
			set { _amount.SendKeys(value); }
		}
		public string MerchantDescription
		{
			get { return _merchantDescription.Text; }
			set { _merchantDescription.SendKeys(value); }
		}
		public string PostingDate
		{
			get { return _postingDate.Text; }
			set { _postingDate.SendKeys(value); }
		}

		public string CorpAccountNumber
		{
			get { return _corpAccountNumber.Text.Trim(); }
		}

		public string CorpCreditLimit
		{
			get
			{
				string y = _corpCreditLimit.Text.Replace("$", "").Replace(",", "");
				return y.Substring(0, y.IndexOf('.'));
			}
		}

		public void CloseCorpCardInfoNonModal()
		{
			_closeCorpCLInfoBtn.JSClickWithFocus(Driver);
		}

		public string TransactionDate
		{
			get { return _transactionDate.Text; }
			set { _transactionDate.SendKeys(value); }
		}
		public string Currency
		{
			get { return _currency.Text; }
			set { _currency.SendKeys(value); }
		}
		public string ForExSourceAmount
		{
			get { return _forExSourceAmount.Text; }
			set { _forExSourceAmount.SendKeys(value); }
		}
		public string ReferenceNumber
		{
			get { return _referenceNumber.Text; }
			set { _referenceNumber.SendKeys(value); }
		}
		public string CustomerCode
		{
			get { return _customerCode.Text; }
			set { _customerCode.SendKeys(value); }
		}
		public string TransactionType
		{
			get { return _transactionType.Text; }
			set { _transactionType.SendKeys(value); }
		}
		public bool Transaction
		{
			get { return _transactionRadioBtn.Selected; }
			set
			{
				if (_transactionRadioBtn.Selected != value)
					_transactionRadioBtn.JSClickWithFocus(Driver);
			}
		}
		public bool Authorization
		{
			get { return _authorizationRadioBtn.Selected; }
			set
			{
				if (_authorizationRadioBtn.Selected != value)
					_authorizationRadioBtn.JSClickWithFocus(Driver);
			}
		}

		public string ConnectionWithTicketnumber
		{
			get { return _connectionWithTicketnumber.Text; }
			set { _connectionWithTicketnumber.SendKeys(value); }
		}

		public string AncillaryPassengerName
		{
			get { return _ancillaryPassengerName.Text; }
			set { _ancillaryPassengerName.SendKeys(value); }
		}

		public string AncillaryTicketDocumentNumber
		{
			get { return _ancillaryTicketDocumentNumber.Text; }
			set { _ancillaryTicketDocumentNumber.SendKeys(value); }
		}

		public void ancillaryServiceCategory(string text)
		{
			var selectElement = new SelectElement(_ancillaryServiceCategory);
			selectElement.SelectByText(text);
		}

		public string Create()
        {
            _createBtn.JSClickWithFocus(Driver);
            Settings.EnCompassExtentTest.Info("Clicked on create button");
            WaitForLoad();

            // Check for the Success Message.
            if(HasSuccessMessage)
            {
                // Capture and Return the DataGroupID
                return Regex.Match(SuccessMessage, @"(\d+)(?!.*\d)").Value;
            }
            else
            {
                return null;
            }
        }

        /// <summary>
        /// Clicks on create button, verified the success message before returning the Transaction Id
        /// </summary>
        public string CreateAndVerifySuccessMessage(string msg)
        {
            _createBtn.JSClickWithFocus(Driver);
            Settings.EnCompassExtentTest.Info("Clicked on create button");
            WaitForLoad();

            // Check for the Success Message.
            if (HasSuccessMessage)
            {
                string transId = Regex.Match(SuccessMessage, @"(\d+)(?!,*\d)").Value;
                string dataLdGrp = Regex.Match(SuccessMessage, @"(\d+)(?!.*\d)").Value;
                // Compare the actual message using the real time value for Tid and DLId
                msg = String.Format(msg, transId, dataLdGrp);
                Check.That(this.SuccessMessage).Contains(msg);

                Settings.TrxDataLoadList.Enqueue(dataLdGrp);

                // return the transaction ID
                return transId;
            }
            else
            {
                throw new Exception("Success message didn't appear on the page and transId is null or empty");
            }
        }

        /// <summary>
        /// Clicks on create button, verified the success message before returning the Transaction Id
        /// </summary>
        public string CreateAndVerifySuccessMessage(string mLogId, string authNumber, int postDays, int transDays, List<string> amount, List<string> transType, int indexTrx, string msg)
        {
            this.MerchantLogId = mLogId;
            this.AuthorizationNumber = authNumber;
            this.PostingDate = Tools.GetDateFromToday(postDays, true, false);
            this.TransactionDate = Tools.GetDateFromToday(transDays, true, false);

            var amt = (string.IsNullOrEmpty(amount.FirstOrDefault()) || amount.Where(s => s.ToLowerInvariant().Equals("none")).Any()) ? null : amount;
            if (amt != null)
            {
                this.Amount = amount[indexTrx];
            }

            if (transType != null)
            {
                var type = (string.IsNullOrEmpty(transType.FirstOrDefault()) || transType.Where(s => s.ToLowerInvariant().Equals("none")).Any()) ? null : transType;
                if (type != null)
                {
                    this.TransactionType = transType[indexTrx];
                }
            }

            _createBtn.JSClickWithFocus(Driver);
            Settings.EnCompassExtentTest.Info("Clicked on create button");
            WaitForLoad();
            AttachOnDemandScreenShot();

            // Check for the Success Message.
            if (HasSuccessMessage)
            {
                string transId = Regex.Match(SuccessMessage, @"(\d+)(?!,*\d)").Value;
                string dataLdGrp = Regex.Match(SuccessMessage, @"(\d+)(?!.*\d)").Value;
                // Compare the actual message using the real time value for Tid and DLId
                msg = String.Format(msg, transId, dataLdGrp);
                Check.That(this.SuccessMessage).Contains(msg);
                Settings.EnCompassExtentTest.Info($"Transaction created for {mLogId} succesfully.");

                Settings.TrxDataLoadList.Enqueue(dataLdGrp);

                // return the transaction ID
                return transId;
            }
            else
            {
                return null;
            }
        }

        public void CreateandCheckForSuccessMsg()
        {
            _createBtn.JSClickWithFocus(Driver);
            Settings.EnCompassExtentTest.Info("Clicked on create button");
            WaitForLoad();
            Check.That(HasSuccessMessage).Equals(true);
        }

        public void ViewCorpCLInfo()
        {
            _viewCorpCLInfoBtn.JSClickWithFocus(Driver);
            WaitForLoad();
        }

        public void RunExpiration()
        {
            _runExpirationProcessBtn.JSClickWithFocus(Driver);
            WaitForLoad();
        }

        public string RunExpirationProcess
        {
            get { return _expireDateText.Text; }
            set { _expireDateText.SendKeys(value); }
        }

        public void CorpRealTimeAvailableBalance()
        {
            _corpRealTimeAvailableBalanceBtn.JSClickWithFocus(Driver);
            WaitForLoad();
        }

        public string CorporateRealTimeAvailableBalance
        {
            get { return _corpRealTimeAvailableBalanceText.Text; }
            set { _corpRealTimeAvailableBalanceText.SendKeys(value); }
        }

        public void CreateTransactionWithAccountNum(int cardNo, int Days, string amount)
        {
			Driver.TryWaitForElementToBeVisible(By.XPath(_accountNumberXPath), out IWebElement element);
			AccountNumber = Settings.Scenario["CardCreditNumber" + cardNo].ToString();
			// convert amount to 2 decimal places if already decimal is not present
			//amount = (!amount.Contains(".")) ? amount + ".00" : amount;
			Settings.Scenario["TransactionAmount" + amount] = Amount = amount;
			string startTransactionDate = Tools.GetDateFromToday(Days, true, false);
			string endtTransactionDate = Tools.GetDateFromToday(Days + 1, true, false);
			PostingDate = startTransactionDate;
			Settings.Scenario["Start Transaction Date"] = startTransactionDate;
			Settings.Scenario["End Transaction Date"] = endtTransactionDate;
			CreateandCheckForSuccessMsg();
		}

		public void CreateTransactionWithAccountNumAndPostAndTransactionDate(int cardNo, int Days, string amount)
		{
			Driver.TryWaitForElementToBeVisible(By.XPath(_accountNumberXPath), out IWebElement element);
			AccountNumber = Settings.Scenario["CardCreditNumber" + cardNo].ToString();
			Amount = amount;
			string startTransactionDate = Tools.GetDateFromToday(Days, true, false);
			string endtTransactionDate = Tools.GetDateFromToday(Days + 1, true, false);
			PostingDate = startTransactionDate;
			TransactionDate = startTransactionDate;
			Settings.Scenario["Start Transaction Date"] = startTransactionDate;
			Settings.Scenario["End Transaction Date"] = endtTransactionDate;
			CreateandCheckForSuccessMsg();
		}
        public void ClickNewButton()
        {
            IWebElement _newButton;

            Driver.TryFindElement(By.XPath(_newButtonXpath), out _newButton);
            _newButton.JSClickWithFocus(Driver);
            Settings.EnCompassExtentTest.Info("New Button clicked.");

            WaitForLoad();
        }

        public bool NewButtonExists()
        {
            IWebElement _newButton;
            if (Driver.TryFindElement(By.XPath(_newButtonXpath), out _newButton))
                return true;
            return false;
        }

        public void CreateTransactionsMLogOrPlog(string logType, string value, string successMsg, string postDate = "", string transactDate = "")
        {
            switch (logType)
            {
                case "mlogid":
                    MerchantLogId = Settings.MLogId;
                    break;
                case "plogid":
                    MerchantLogId = Settings.PLogId;
                    break;
            }

            Amount = value;
            TransactionType = "D"; //Transaction type can't be empty or Y

            if (postDate == "" || postDate == String.Empty)
                PostingDate = Tools.GetDateFromToday(0, true, false);
            else if (postDate == null)
                PostingDate = String.Empty;
            else
                PostingDate = postDate;

            if (transactDate == "" || transactDate == String.Empty)
                TransactionDate = Tools.GetDateFromToday(2, true, false);
            else if (transactDate == null)
                TransactionDate = String.Empty;
            else
                TransactionDate = transactDate;

            string tansId = CreateAndVerifySuccessMessage(successMsg);
            System.Threading.Thread.Sleep(3000);// wait for transaction to post
            ClickNewButton();

		}
	}
}
