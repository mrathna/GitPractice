﻿using Common;
using Common.Utility;
using NFluent;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EnCompass.Testing.Source.PageObjects.Organization.ExpenseManager.PurchaseLog
{
	[PageModel(@"/expenseManager/PurchaseLog/PurchaseLogDetails.aspx")]

	public partial class PurchaseLogDetails: EnCompassOrgPageModel
	{
		public override string RelativeUrl => @"/expenseManager/PurchaseLog/PurchaseLogDetails.aspx";
		public override string PageIdentifierXPath_Generated => @"//div[@class='crumb_selected_content'][text() = 'Details']";

		public PurchaseLogDetails(GlobalSettings settings) : base(settings) { }

        #region XPath Page Elements

        private const string _infoMessageXPath = "//div[contains(@id, 'DivInformationMessage')]";
        private const string _transactionTypesXPath = "//select[contains(@id, 'TransactionType')]";
        private const string _categoriesXPath = "//select[contains(@id, 'Category')]";
        private const string _productsXPath = "//select[contains(@id, 'Product')]";
        private const string _ppusXPath = "//input[contains(@id, 'txtPPU')]";
        private const string _amountsXPath = "//input[contains(@id, 'Amount')]";
        private const string _merchantInvoiceNumberXPath = "//input[contains(@id, 'MerchantInvoiceNum')]";
        private const string _submitXPath = "//input[contains(@id, 'btnSave')]";
        private const string _authorizingEmployeeNameXPath = "//input[contains(@id, 'AmountOverAuthNameText')]";
        private const string _txnAmountTextXPath = "//table[@role='presentation']/tbody/tr/td[@style]";
        private const string _emergencySubmitBtnXPath = "//input[contains(@id, 'Emergency500SubmitButton')]";
        private const string _authorizeWithoutLimitsBtnXPath = "//input[contains(@id, 'EmergencyWithoutLimits500Button')]";
        private const string _assignedAccountNumberXPath = "//span[contains(@id, 'lblActNo')]";
        private const string _assignedAccountExpirationXPath = "//span[contains(@id, 'lblExpDt')]";
        private const string _assignedAccountCSCXPath = "//span[contains(@id, 'lblCVC2value')]";

        #endregion

        #region Page Elements

        private IWebElement _infoMessage
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_infoMessageXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_infoMessage element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IList<IWebElement> _transactionTypes
        {
            get
            {
                IList<IWebElement> element = Driver.WaitForElements(By.XPath(_transactionTypesXPath)).ToList();

                if (element != null)
                {
                    Settings.EnCompassExtentTest.Info($"_transactionTypes element founded.");
                    return element;
                }
                else
                {
                    Settings.EnCompassExtentTest.Info($"_transactionTypes element not founded.");
                    return null;
                }
            }
        }
        private IList<IWebElement> _categories
        {
            get
            {
                IList<IWebElement> element = Driver.WaitForElements(By.XPath(_categoriesXPath)).ToList();

                if (element != null)
                {
                    Settings.EnCompassExtentTest.Info($"_categories element founded.");
                    return element;
                }
                else
                {
                    Settings.EnCompassExtentTest.Info($"_categories element not founded.");
                    return null;
                }
            }
        }
        private IList<IWebElement> _products
        {
            get
            {
                IList<IWebElement> element = Driver.WaitForElements(By.XPath(_productsXPath)).ToList();

                if (element != null)
                {
                    Settings.EnCompassExtentTest.Info($"_products element founded.");
                    return element;
                }
                else
                {
                    Settings.EnCompassExtentTest.Info($"_products element not founded.");
                    return null;
                }
            }
        }
        private IList<IWebElement> _ppus
        {
            get
            {
                IList<IWebElement> element = Driver.WaitForElements(By.XPath(_ppusXPath)).ToList();

                if (element != null)
                {
                    Settings.EnCompassExtentTest.Info($"_ppus element founded.");
                    return element;
                }
                else
                {
                    Settings.EnCompassExtentTest.Info($"_ppus element not founded.");
                    return null;
                }
            }
        }
        private IList<IWebElement> _amounts
        {
            get
            {
                IList<IWebElement> element = Driver.WaitForElements(By.XPath(_amountsXPath)).ToList();

                if (element != null)
                {
                    Settings.EnCompassExtentTest.Info($"_amounts element founded.");
                    return element;
                }
                else
                {
                    Settings.EnCompassExtentTest.Info($"_amounts element not founded.");
                    return null;
                }
            }
        }
        private IWebElement _merchantInvoiceNumber
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_merchantInvoiceNumberXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_merchantInvoiceNumber element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _submit
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_submitXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_submit element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _authorizingEmployeeName
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_authorizingEmployeeNameXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_authorizingEmployeeName element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _txnAmountText
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_txnAmountTextXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_txnAmountText element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _emergencySubmitBtn
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_emergencySubmitBtnXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_emergencySubmitBtn element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _authorizeWithoutLimitsBtn
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_authorizeWithoutLimitsBtnXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_authorizeWithoutLimitsBtn element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _assignedAccountNumber
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_assignedAccountNumberXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_assignedAccountNumber element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _assignedAccountExpiration
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_assignedAccountExpirationXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_assignedAccountExpiration element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _assignedAccountCSC
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_assignedAccountCSCXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_assignedAccountCSC element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        #endregion


        public string InfoMessage => _infoMessage.Text;

		public bool IsInfoMessagePresent
		{
			get
			{
				try
				{
					return _infoMessage.Displayed;
				}
				catch
				{
					return false;
				}
			}
		}

		public void SetTransactionType(string whichText, int index = 0)
		{
			_transactionTypes[index].SetListboxByText(whichText);
			Driver.WaitForVisible(By.XPath($@"(//select[contains(@id, 'Category')])[{index+1}]"));
			Check.That(GetProductText(index)).Equals("Select an item");
		}

		public void SetCategory(string whichText, int index = 0)
		{
			_categories[index].SetListboxByText(whichText);
			Driver.WaitForVisible(By.XPath($@"(//select[contains(@id, 'Product')])[{index+1}]"));
			Check.That(GetProductText(index)).Equals("Select an item");
		}

		public void SetProduct(string whichText, int index = 0)
		{
			_products[index].SetListboxByText(whichText);
		}

		public void SetPPU(string whichText, int index = 0)
		{
			_ppus[index].SetTextboxValue(whichText);
		}

		public void SetAmount(string whichText, int index = 0)
		{
			_amounts[index].SetListboxByText(whichText);
		}

		public string MerchantInvoiceNumber
		{
			get { return _merchantInvoiceNumber.GetAttribute("value"); }
			set { _merchantInvoiceNumber.SendKeys(value); }
		}
		
		public string GetTransactionTypeText(int index=0)
		{
			return new SelectElement(_transactionTypes[index]).SelectedOption.Text;
		}

		public string GetCategoryText(int index = 0)
		{
			return new SelectElement(_categories[index]).SelectedOption.Text;
		}

		public string GetProductText(int index = 0)
		{
			return new SelectElement(_products[index]).SelectedOption.Text;
		}

		public void Submit()
		{
			_submit.JSClickWithFocus(Driver);
		}

		public string AuthorizingEmployeeName { set { _authorizingEmployeeName.Clear(); _authorizingEmployeeName.SendKeys(value); } }
		public string TransactionAmountText => _txnAmountText.Text;

		public void EmergencySubmit()
		{
			_emergencySubmitBtn.JSClickWithFocus(Driver);
		}

		public void AuthorizeWithoutLimits()
		{
			_authorizeWithoutLimitsBtn.JSClickWithFocus(Driver);
		}

		public string AssignedAccountNumber => _assignedAccountNumber.Text;
		public string AssignedAccountExpiration => _assignedAccountExpiration.Text;
		public string AssignedAccountCSC => _assignedAccountCSC.Text;
		public string AssignedAccountNumberLast4 => _assignedAccountNumber.Text.Trim().Substring(_assignedAccountNumber.Text.Trim().Length - 4);
	}
}
