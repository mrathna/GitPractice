using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using Common;
using Common.PageObjects;
using Common.ScenarioConfigurations;
using Common.Utility;

namespace EnCompass.Testing.Source.PageObjects.SuperAdmin.AocsuperTools.OrgSettingManagement 
{
	/// <summary>
	/// Auto-generated Page Model Class
	/// Navigation Paths: 
		/// [Organization Home]->Super Admin Tools->Organization Settings
		/// </summary>
	[PageModel(@"/superAdmin/AOCSuperTools/OrgSettingManagement/ManageOrgSettings.aspx")]
	public partial class ManageOrgSettings : EnCompassSuperPageModel 
	{
		public override string RelativeUrl => @"/superAdmin/AOCSuperTools/OrgSettingManagement/ManageOrgSettings.aspx";
		public override string PageIdentifierXPath_Generated => @"//li[contains(@class, 'breadcrumb-item active')][text() = 'Organization Settings']";

		#region Navigation
		
		private void NavigateToMenuItem(IWebElement element)
		{
			Driver.Url = element.GetAttribute("href");
		}
		#endregion

		public ManageOrgSettings(GlobalSettings settings) : base(settings) { }
	}  
}
