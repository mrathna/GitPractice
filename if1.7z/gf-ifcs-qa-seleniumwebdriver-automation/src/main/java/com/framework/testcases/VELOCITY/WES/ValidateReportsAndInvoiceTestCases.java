package com.framework.testcases.VELOCITY.WES;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.WES.Velocity.VelocityCardsPage;
import com.framework.pages.WES.Velocity.VelocityHomePage;
import com.framework.pages.WES.Velocity.VelocityReportsPage;
import com.framework.pages.WES.common.CommonPage;
import com.framework.pages.WES.common.LoginPage;
import com.framework.util.PropUtils;

public class ValidateReportsAndInvoiceTestCases extends BaseTest {

	@Parameters({ "clientName" })
	@Test(groups = { "Regression" })
	public void CustomerTransactionsViewingAndValidating(@Optional("WES") String clientName) {

		test = extent.createTest(clientName+ ":   Ability to see new transactions in Velocity at customer level",
				"Ability to see new transactions in Velocity at customer level");

		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		VelocityHomePage homePage = new VelocityHomePage(driver, test);
		VelocityReportsPage reportsPage = new VelocityReportsPage(driver, test);
		loginPage.loginWES("Velocity_URL", "Velocity_UN_" + clientName, "Velocity_PWD_" + clientName, "VELOCITY");

		homePage.clickingAndValidatingSpecificAccessType("Distributor");
		homePage.searchingAndValidatingCustomer(PropUtils.getPropValue(wesuatconfigProp, "Transaction_CusNo"));

		reportsPage.verifyingCustomerTransactions(PropUtils.getPropValue(wesuatconfigProp, "Transaction_Amount"),
				PropUtils.getPropValue(wesuatconfigProp, "Transaction_CardNo"));

		loginPage.logoutTheApplication("Velocity");

	}

	@Parameters({ "clientName" })
	@Test(groups = { "Regression" })
	public void MKIIReportsViewingAndValidating(@Optional("WES") String clientName) {

		test = extent.createTest(clientName+ ":   Ability to download the MKII report via Velocity",
				"Ability to download the MKII report via Velocity");

		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		VelocityHomePage homePage = new VelocityHomePage(driver, test);
		VelocityReportsPage reportsPage = new VelocityReportsPage(driver, test);
		loginPage.loginWES("Velocity_URL", "Velocity_UN_" + clientName, "Velocity_PWD_" + clientName, "VELOCITY");

		homePage.clickingAndValidatingSpecificAccessType("Distributor");

		homePage.searchingAndValidatingCustomer(PropUtils.getPropValue(wesuatconfigProp, "MKII_CusNo"));
		reportsPage.verifyingMKIIReports();

		loginPage.logoutTheApplication("Velocity");

	}

	@Parameters({ "clientName" })
	@Test(groups = { "Regression" })
	public void InvoicesViewingAndValidating(@Optional("WES") String clientName) {

		test = extent.createTest(
				"Ability to access historical  invoices via Velocity,Ability to access invoices via Velocity",
				"Ability to access historical and specified invoices via Velocity");

		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		VelocityHomePage homePage = new VelocityHomePage(driver, test);
		VelocityReportsPage reportsPage = new VelocityReportsPage(driver, test);
		VelocityCardsPage cardsPage = new VelocityCardsPage(driver, test);
		loginPage.loginWES("Velocity_URL", "Velocity_UN_" + clientName, "Velocity_PWD_" + clientName, "VELOCITY");

		homePage.clickingAndValidatingSpecificAccessType("Distributor");
		homePage.searchingAndValidatingCustomer(PropUtils.getPropValue(wesuatconfigProp, "Invoice_CusNo"));
		reportsPage.verifyingCustInvoices("historic");
		cardsPage.navigateToHome();
		reportsPage.verifyingCustInvoices(PropUtils.getPropValue(wesuatconfigProp, "Invoice_No"));

		loginPage.logoutTheApplication("Velocity");

	}

	@Parameters({ "clientName" })
	@Test( groups = { "Regression" })
	public void PaymentAdviceViewingAndValidating(@Optional("WES") String clientName) {

		test = extent.createTest(clientName+ ":   To validate that a Payment advice can be downloaded for a customer in Velocity",
				"To validate that a Payment advice can be downloaded for a customer in Velocity");

		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		VelocityHomePage homePage = new VelocityHomePage(driver, test);
		VelocityReportsPage reportsPage = new VelocityReportsPage(driver, test);
		loginPage.loginWES("Velocity_URL", "Velocity_UN_" + clientName, "Velocity_PWD_" + clientName, "VELOCITY");

		homePage.clickingAndValidatingSpecificAccessType("Distributor");
		homePage.searchingAndValidatingCustomer(PropUtils.getPropValue(wesuatconfigProp, "PaymentAdvice_CusNo"));
		reportsPage.verifyingPaymentAdvice();

		loginPage.logoutTheApplication("Velocity");

	}

	// Sasi
	@Parameters({ "clientName" })
	@Test( groups = { "Regression" })
	public void CustomerUpdationAndValidation(@Optional("WES") String clientName) {

		test = extent.createTest(clientName+ ":  Ability to change customer details in IFCS and see the changes in Velocity",
				"Ability to change customer details in IFCS and see the changes in Velocity");

		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		VelocityHomePage homePage = new VelocityHomePage(driver, test);
		VelocityCardsPage cardsPage = new VelocityCardsPage(driver, test);
		CommonPage commonPage = new CommonPage(driver, test);

		String clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		String cusNo = commonPage.getCustomerNo(clientName, clientCountry);

		loginPage.loginWES("Velocity_URL", "Velocity_UN_" + clientName, "Velocity_PWD_" + clientName, "VELOCITY");
		homePage.clickingAndValidatingSpecificAccessType("Distributor");
		homePage.searchingAndValidatingCustomer(PropUtils.getPropValue(wesuatconfigProp, "Cruise_Customer"));
		cardsPage.validatingUpdatedCustomerData(cusNo);
		loginPage.logoutTheApplication("Velocity");

	}

	@Parameters({ "clientName" })
	@Test( groups = { "Regression" })
	public void VerifyingAndValidatingCustomer(@Optional("WES") String clientName) {

		test = extent.createTest(
				"Ability to see newly created IFCS customer in Velocity,To validate that new cards ordered in IFCS are visible in the Velocity ",
				"Ability to see customer and cards creatyed in IFCS in Velocity");

		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		VelocityHomePage homePage = new VelocityHomePage(driver, test);
		VelocityCardsPage cardsPage = new VelocityCardsPage(driver, test);
		loginPage.loginWES("Velocity_URL", "Velocity_UN_" + clientName, "Velocity_PWD_" + clientName, "VELOCITY");

		homePage.clickingAndValidatingSpecificAccessType("Distributor");
		homePage.searchingAndValidatingCustomer(PropUtils.getPropValue(wesuatconfigProp, "IFCS_Created_CusNO"));

		cardsPage.navigatingToManageCards();
		cardsPage.scrollDownPage();
		cardsPage.cardNumFilter(PropUtils.getPropValue(wesuatconfigProp, "IFCS_Created_CardNO"));
		cardsPage.validatingAndVerifyingCards("Pan No", PropUtils.getPropValue(wesuatconfigProp, "IFCS_Created_CardNO"),
				"IFCS_Created_CardNO");

		homePage.clickingExchangeBtn();

		homePage.searchingAndValidatingCustomer(PropUtils.getPropValue(velocityTempProp, "Card_Customer"));

		cardsPage.navigatingToManageCards();
		cardsPage.scrollDownPage();
		
		cardsPage.cardNumFilter(PropUtils.getPropValue(velocityTempProp, "Esso_Solo"));
		cardsPage.validatingAndVerifyingCards("Pan No", PropUtils.getPropValue(velocityTempProp, "Esso_Solo"),
				"Esso_Solo");

		cardsPage.cardNumFilter(PropUtils.getPropValue(velocityTempProp, "EDC_Solo"));
		cardsPage.validatingAndVerifyingCards("Pan No", PropUtils.getPropValue(velocityTempProp, "EDC_Solo"),
				"EDC_Solo");

		cardsPage.cardNumFilter(PropUtils.getPropValue(velocityTempProp, "UK_Fuels_Solo"));
		cardsPage.validatingAndVerifyingCards("Pan No", PropUtils.getPropValue(velocityTempProp, "UK_Fuels_Solo"),
				"UK_Fuels_Solo");

		cardsPage.cardNumFilter(PropUtils.getPropValue(velocityTempProp, "Esso_Multi0"));
		cardsPage.validatingAndVerifyingCards("Pan No", PropUtils.getPropValue(velocityTempProp, "Esso_Multi0"),
				"Esso_Multi0");

		cardsPage.cardNumFilter(PropUtils.getPropValue(velocityTempProp, "Esso_Multi1"));
		cardsPage.validatingAndVerifyingCards("Pan No", PropUtils.getPropValue(velocityTempProp, "Esso_Multi1"),
				"Esso_Multi1");

		cardsPage.cardNumFilter(PropUtils.getPropValue(velocityTempProp, "Esso_Multi2"));
		cardsPage.validatingAndVerifyingCards("Pan No", PropUtils.getPropValue(velocityTempProp, "Esso_Multi2"),
				"Esso_Multi2");

		cardsPage.cardNumFilter(PropUtils.getPropValue(velocityTempProp, "EDC_Multi0"));
		cardsPage.validatingAndVerifyingCards("Pan No", PropUtils.getPropValue(velocityTempProp, "EDC_Multi0"),
				"EDC_Multi0");

		cardsPage.cardNumFilter(PropUtils.getPropValue(velocityTempProp, "EDC_Multi1"));
		cardsPage.validatingAndVerifyingCards("Pan No", PropUtils.getPropValue(velocityTempProp, "EDC_Multi1"),
				"EDC_Multi1");

		cardsPage.cardNumFilter(PropUtils.getPropValue(velocityTempProp, "EDC_Multi2"));
		cardsPage.validatingAndVerifyingCards("Pan No", PropUtils.getPropValue(velocityTempProp, "EDC_Multi2"),
				"EDC_Multi2");

		cardsPage.cardNumFilter(PropUtils.getPropValue(velocityTempProp, "UK_Fuels_Multi0"));
		cardsPage.validatingAndVerifyingCards("Pan No", PropUtils.getPropValue(velocityTempProp, "UK_Fuels_Multi0"),
				"UK_Fuels_Multi0");

		cardsPage.cardNumFilter(PropUtils.getPropValue(velocityTempProp, "UK_Fuels_Multi1"));
		cardsPage.validatingAndVerifyingCards("Pan No", PropUtils.getPropValue(velocityTempProp, "UK_Fuels_Multi1"),
				"UK_Fuels_Multi1");

		cardsPage.cardNumFilter(PropUtils.getPropValue(velocityTempProp, "UK_Fuels_Multi2"));
		cardsPage.validatingAndVerifyingCards("Pan No", PropUtils.getPropValue(velocityTempProp, "UK_Fuels_Multi2"),
				"UK_Fuels_Multi2");

		cardsPage.cardNumFilter(PropUtils.getPropValue(velocityTempProp, "Multiple_Multi0"));
		cardsPage.validatingAndVerifyingCards("Pan No", PropUtils.getPropValue(velocityTempProp, "Multiple_Multi0"),
				"Multiple_Multi0");

		cardsPage.cardNumFilter(PropUtils.getPropValue(velocityTempProp, "Multiple_Multi1"));
		cardsPage.validatingAndVerifyingCards("Pan No", PropUtils.getPropValue(velocityTempProp, "Multiple_Multi1"),
				"Multiple_Multi1");

		cardsPage.cardNumFilter(PropUtils.getPropValue(velocityTempProp, "Multiple_Multi2"));
		cardsPage.validatingAndVerifyingCards("Pan No", PropUtils.getPropValue(velocityTempProp, "Multiple_Multi2"),
				"Multiple_Multi2");

		loginPage.logoutTheApplication("Velocity");
	}
}
