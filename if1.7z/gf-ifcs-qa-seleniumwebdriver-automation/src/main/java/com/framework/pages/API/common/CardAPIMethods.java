package com.framework.pages.API.common;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONString;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;
import com.framework.pages.AJS.common.Common;
import com.framework.pages.AJS.common.CommonInterfacePage;
import com.framework.pages.AJS.common.IFCSCommonPage;
import com.framework.pages.AJS.common.IFCSHomePage;
import com.framework.pages.AJS.common.IFCSLoginPage;
import com.framework.pages.AJS.common.InterfacePage;
import com.framework.util.PropUtils;

public class CardAPIMethods extends CommonAPI {

	public CardAPIMethods(WebDriver driver, ExtentTest test) {
		super(driver, test);
		// TODO Auto-generated constructor stub
	}

	/**
	 * Implemented by Nithya Manikandan - For Ordering Cards Across Clients
	 **/
	String clientFullName, cardNoV;

	public void orderCard(String clientName, String clientCountry, String customerNo, String cardProduct,
			String cardType) {

		String logonUserId = PropUtils.getPropValue(configProp, "UserNameAPI" + "_" + clientName + "_" + clientCountry);
		String customerNum = "";
		String customerNoValidation, getAssociatedCustNo;
		clientFullName = clientCountry.contains("_")
				? PropUtils.getPropValue(configProp, clientName + "_" + clientCountry.split("_")[1])
				: PropUtils.getPropValue(configProp, clientName + "_" + clientCountry);

		if (customerNo.equalsIgnoreCase("Associated")) {
			// Get a random customer number associated with the user
			getAssociatedCustNo = "Select customer_no from internet_user_access iua\r\n"
					+ "inner join m_customers mc on iua.member_oid = mc.customer_mid\r\n"
					+ "where internet_user_oid = (Select internet_user_oid from internet_users where logon_id = '"
					+ logonUserId + "')";
			customerNum = connectDBAndGetValue(getAssociatedCustNo,
					PropUtils.getPropValue(configProp, "sqlODSServerName"));
		} else if (customerNo.equalsIgnoreCase("Newly Created")) {
			try {
				customerNum = PropUtils.getProps(customerNumberFile)
						.getProperty("Customer_Number_" + clientName + "_" + clientCountry);

				if (customerNum != null && customerNum.length() > 0) {
					IFCSLoginPage ifcsloginPage = new IFCSLoginPage(driver, test);
					IFCSHomePage ifcsHomePage = new IFCSHomePage(driver, test);
					Common common = new Common(driver, test);
					ifcsloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
							"IFCS_" + clientName + "_PASSWORD");
					ifcsHomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);
					ifcsHomePage.gotoAdminMenuAndChooseClientGroup();
					common.goToOnlineUsers();
					common.searchTheCurrentUserOnOnlineUsers(
							PropUtils.getPropValue(configProp, "UserNameAPI" + "_" + clientName + "_" + clientCountry));
					ifcsHomePage.addCustomerToUser(customerNum);
					ifcsHomePage.exitIFCS();
				} else {
					logInfo("No new customer created! So using the existing User");
					getAssociatedCustNo = "Select customer_no from internet_user_access iua\r\n"
							+ "inner join m_customers mc on iua.member_oid = mc.customer_mid\r\n"
							+ "where internet_user_oid = (Select internet_user_oid from internet_users where logon_id = '"
							+ logonUserId + "')";
					customerNum = connectDBAndGetValue(getAssociatedCustNo,
							PropUtils.getPropValue(configProp, "sqlODSServerName"));
				}
			} catch (Exception ex) {
				logFail("No new customer created!");
			}

		} else {
			// Validation for Valid Customer Number
			customerNoValidation = "select customer_no from m_customers where customer_no = " + customerNo
					+ " and client_mid = (select client_mid from m_clients where name = '" + clientFullName + "')";
			if (connectDBAndGetValue(customerNoValidation,
					PropUtils.getPropValue(configProp, "sqlODSServerName")) == null) {
				logFail("Customer number in the sheet is invalid" + customerNo + " Verified with DB for the client:"
						+ clientFullName);
			} else {
				customerNum = customerNo;
			}

		}

		JSONObject productRequestParams = new JSONObject();
		JSONArray requestBody = new JSONArray();
		String embossName = fakerAPI().company().name();
		productRequestParams.put("companyEmbossName", embossName);
		productRequestParams.put("extraEmbossLine", embossName);
		productRequestParams.put("cardPinControl", "No PIN Required");
		productRequestParams.put("customerWallet", "TEST");
		productRequestParams.put("encryptedPin", fakerAPI().number().digits(4));
		// Customer No in Array

		productRequestParams.put("customer", jsonObjectBuilder("customerNo", customerNum));
		builder = new JSONObject();

		// Card Control in Array
		String cardOffer;
		if (clientName.equalsIgnoreCase("EMAP")) {
			cardOffer = getCardOffer(customerNum, "");
		} else {
			cardOffer = getCardOffer(customerNum, cardType);
		}

		String productRestriction = getProductRestriction(customerNum);
		if (clientName.equals("EMAP") || clientName.equals("CHEVRON") || clientName.equals("WFE")) {
			HashMap<String, String> velocityAss = new HashMap<>();
			//String dafalut = "'Defalut\"':'\"true'".replaceAll("'", "").replaceAll("\\\\","/");
			JSONArray card;
			velocityAss.put("productRestriction", productRestriction);
			//card = jsonArrayBuilderHashMap("cardControl", velocityAss).put(dafalut);
			//productRequestParams.put("cardControlProfiles", card);
			//productRequestParams.put("cardControlProfiles", defaultValue);
			
			
		} else {
			HashMap<String, HashMap<String, String>> velocityAss = new HashMap<>();

			HashMap<String, String> velocityValues = getCardControlProfileVelocityValues(customerNum, cardOffer);
			velocityAss.put("velocityAssignment", velocityValues);
			productRequestParams.put("cardControlProfiles", jsonArrayBuilderTwoHashMap("cardControl", velocityAss));
		}

		builder = new JSONObject();
		obj = new JSONObject();

		// String cardTypeValue = getApplicableCardType(cardType, customerNum);

		jsonObjectBuilder("cardType", cardType);

		productRequestParams.put("cardProduct", jsonObjectBuilder("description", cardProduct));

		builder = new JSONObject();

		if (cardType.toLowerCase().contains("vehicle")) {
			HashMap<String, String> vehicleDetails = new HashMap<>();
			vehicleDetails.put("description", "Skoda-Auto" + fakerAPI().number().digits(4));
			vehicleDetails.put("licensePlate", fakerAPI().number().digits(4));
			vehicleDetails.put("model", "Model" + fakerAPI().number().digits(2));
			vehicleDetails.put("vehicleId", fakerAPI().number().digits(4));
			productRequestParams.put("vehicle", vehicleDetails);
		} else {
			HashMap<String, String> driverDetails = new HashMap<>();
			String driverName = fakerAPI().name().fullName();
			driverDetails.put("driverId", fakerAPI().number().digits(4));
			driverDetails.put("driverName", driverName);
			driverDetails.put("phoneMobile1", fakerAPI().phoneNumber().cellPhone());
			driverDetails.put("shortName", driverName);
			productRequestParams.put("driver", driverDetails);
		}
		requestBody.put(productRequestParams);

		response = apiUtils.postRequestAsBearerAuthWithBodyData(PropUtils.getPropValue(configProp, "ORDER_CARD"),
				requestBody, PropUtils.getPropValue(configProp, "AuthorizationToken"));
		jsonPathEvaluator = response.jsonPath();
		System.out.println(" Printing the Post response----->" + response.body().prettyPrint());
		if (response.statusCode() == 200) {
			String cardNo = response.getBody().jsonPath().get("cardNo").toString();
			logPass("Card Created: " + cardNo + " for Customer:" + customerNum + " Card Product: " + cardProduct
					+ " Card Type: " + cardType);
			cardNoV = cardNo.replaceAll("\\[|\\]", "");
			Map<String, String> cardDetail = new HashMap<String, String>();
			String prefix = "card_" + clientName + "_" + clientCountry + cardProduct.replaceAll(" ", "");
			int count = getLastValueOfKeyInProp(cardOrderedFile, prefix, cardProduct.replaceAll(" ", ""));
			cardDetail.putAll(PropUtils.getPropsAsMap(cardOrderedFile));
			cardDetail.put(prefix + count, cardNo.replaceAll("\\[", "").replaceAll("\\]", ""));
			System.out.println("Created Card Stored in Properties : " + cardDetail + "--> CardOrdered.properties");
			PropUtils.creatingTempPropFile("CardOrdered.properties", cardDetail);

		} else {
			logFail("Card not Created: Customer and Card Program Details:" + customerNum + " Card Product: "
					+ cardProduct + " Card Type: " + cardType + "  Response Got:" + response.getBody());
		}

	}

	/*
	 * private String getApplicableCardType(String cardType, String customerNumber)
	 * { // TODO Auto-generated method stub return null; }
	 */
	/**
	 * Get Card Control Profile Values from DB
	 **/
	public HashMap<String, String> getCardControlProfileVelocityValues(String customerNumber, String cardOffer) {
		HashMap<String, String> velocityKeyAndValue = new HashMap<>();
		Map<String, String> velocityColAndOid;
		String queryToGetCardControlProf = "select velocity_type_value_1_oid,velocity_type_value_2_oid,velocity_type_value_3_oid,velocity_type_value_4_oid,\r\n"
				+ "velocity_type_value_5_oid,velocity_type_value_6_oid,velocity_type_value_7_oid,velocity_type_value_8_oid from velocity_assignments\r\n"
				+ "where velocity_assignment_oid =\r\n"
				+ "(select velocity_assignment_oid from card_controls where card_control_profile_oid =\r\n"
				+ "(select card_control_profile_oid from card_control_profiles where card_program_oid = \r\n"
				+ "(select card_program_oid from m_customers where customer_no= " + customerNumber
				+ " and client_mid = (select client_mid from m_clients where name ='" + clientFullName
				+ "')) and card_offer_oid=\r\n" + "(SELECT card_offer_oid from card_offers where card_offer_oid in \r\n"
				+ "(select card_offer_oid from card_program_offers where card_program_oid =\r\n"
				+ "(select card_program_oid from m_customers where customer_no= " + customerNumber
				+ " and client_mid = (select client_mid from m_clients where name ='" + clientFullName
				+ "')) )and  description = '" + cardOffer + "') and Rownum <=1))";

		String queryToGetCardControlProfWithProdRes = "select  velocity_type_value_1_oid,velocity_type_value_2_oid,velocity_type_value_3_oid,velocity_type_value_4_oid,\r\n"
				+ "velocity_type_value_5_oid,velocity_type_value_6_oid,velocity_type_value_7_oid,velocity_type_value_8_oid from velocity_assignments\r\n"
				+ "where velocity_assignment_oid =\r\n"
				+ "(select velocity_assignment_oid from card_controls where card_control_profile_oid =\r\n"
				+ "(select card_control_profile_oid from card_control_profiles where card_oid in \r\n"
				+ "(select card_oid from cards where card_program_oid = \r\n"
				+ "(select card_program_oid from m_customers \r\n" + "where customer_no= " + customerNumber + " \r\n"
				+ "and client_mid =\r\n" + "(select client_mid from m_clients where name ='" + clientFullName
				+ "'))\r\n" + "and card_offer_oid=(SELECT card_offer_oid from card_offers where description='"
				+ cardOffer + "'))  and Rownum <=1 ))";

		velocityColAndOid = connectDBAndGetDBEntireRowValues(queryToGetCardControlProf,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		if (velocityColAndOid.isEmpty()) {
			System.out.println("Velocity with Product Restriction");
			velocityColAndOid = connectDBAndGetDBEntireRowValues(queryToGetCardControlProfWithProdRes,
					PropUtils.getPropValue(configProp, "sqlODSServerName"));
		}
		String queryToGetVelocityKeyAndValue = "";

		for (Map.Entry<String, String> entry : velocityColAndOid.entrySet()) {
			queryToGetVelocityKeyAndValue = "select description from velocity_type_values where (type_column_name = '"
					+ entry.getKey() + "' and velocity_type_value_oid=" + entry.getValue() + ") ";
			String value = connectDBAndGetValue(queryToGetVelocityKeyAndValue,
					PropUtils.getPropValue(configProp, "sqlODSServerName"));
			System.out.println("Value got" + value);
			velocityKeyAndValue.put("velocityTypeValue" + entry.getKey().replaceAll("[^0-9]", ""), value);
		}
		return velocityKeyAndValue;
	}

	/**
	 * Get Prod Restriction from DB
	 **/
	public String getProductRestriction(String customerNumber) {
		String productRestrictionQuery = "select description from product_restrictions where card_program_oid = (select card_program_oid from m_customers \r\n"
				+ "where customer_no= " + customerNumber + " \r\n" + "and client_mid =\r\n"
				+ "(select client_mid from m_clients where name ='" + clientFullName + "'))";
		return connectDBAndGetValue(productRestrictionQuery, PropUtils.getPropValue(configProp, "sqlODSServerName"));

	}

	/**
	 * Get Card Offer from DB
	 **/
	public String getCardOffer(String customerNumber, String cardType) {
		String description = cardType.length() > 0 ? "and description like '%" + cardType + "'" : "";
		String cardOfferValue = "SELECT description from card_offers where card_offer_oid in \r\n"
				+ "(select card_offer_oid from card_program_offers where card_program_oid =\r\n"
				+ "(select card_program_oid from m_customers where customer_no= " + customerNumber
				+ " and client_mid = (select client_mid from m_clients where name ='" + clientFullName + "')) ) "
				+ description;
		return connectDBAndGetValue(cardOfferValue, PropUtils.getPropValue(configProp, "sqlODSServerName"));
	}

	public void updateCardStatus(String cardNumber, String fromStatus, String toStatus, String clientName,
			String clientCountry, String replaceCard) {
		Common common = new Common(driver, test);
		JSONObject cardStatusChange = new JSONObject();
		String queryParam;
		if (replaceCard.equalsIgnoreCase("Yes")) {
			queryParam = "?reissueAllowed=true";
		} else {
			queryParam = "?reissueAllowed=false";
		}
		if (cardNumber.equalsIgnoreCase("Associated")) {
			cardNumber = getCardWithLogin(fromStatus,
					PropUtils.getPropValue(configProp, "UserNameAPI" + "_" + clientName + "_" + clientCountry));
			if (!(cardNumber != null && cardNumber.length() > 0)) {
				logFail("No Cards from DB!! for the status given");
			}
		} else if (cardNumber.equalsIgnoreCase("Any Card")) {
			cardNumber = common.getActiveCardNumberFromDB();

		} else if (cardNumber.equalsIgnoreCase("Newly Created")) {
			Map<String, String> cardList = new HashMap<String, String>();
			cardList = common.readDataFromPropertyFile("card_" + clientName + "_" + clientCountry, cardOrderedFile);
			Object[] values = cardList.values().toArray();
			cardNumber = values[cardList.size() - 1].toString();
		}
		cardStatusChange.put("cardNumber", cardNumber);
		cardStatusChange.put("status", toStatus);
		response = apiUtils.putRequestAsBearerAuthWithBodyData(PropUtils.getPropValue(configProp, "AuthorizationToken"),
				cardStatusChange, PropUtils.getPropValue(configProp, "UPDATE_CARD_STATUS") + queryParam);
		System.out.println(" Printing the PUT response----->" + response.body().prettyPrint());
		if (response.getStatusCode() == 200) {
			logInfo("Card Status changed successfully for card" + cardNumber + "Response"
					+ response.body().prettyPrint());
		} else {
			logFail("Card Status not changed to :" + toStatus + "Error log: " + response.body().prettyPrint());
		}
	}

	public String getCardWithLogin(String status, String loginUser) {
		String queryToGetRandomCard = "select CARDS.CARD_NO from Cards \r\n"
				+ "inner join m_customers mc on mc.customer_mid = Cards.customer_mid\r\n"
				+ "inner join internet_user_access iua on iua.member_oid = mc.customer_mid\r\n"
				+ "INNER JOIN CARD_STATUS ON cards.card_status_oid = card_status.card_status_oid\r\n"
				+ "inner join  m_customers mc on mc.customer_mid = Cards.customer_mid inner join accounts\r\n"
				+ "acc on mc.customer_mid=acc.customer_mid inner join account_status accs on accs.account_status_oid=acc.account_status_oid\r\n"
				+ "inner join account_sub_status accss on accss.account_status_oid = accs.account_status_oid\r\n"
				+ "Where accs.description like '%Active' and accss.description like '%Active' \r\n"
				+ "and internet_user_oid = \r\n" + "(Select internet_user_oid from internet_users where logon_id = '"
				+ loginUser + "')\r\n" + "AND\r\n" + "CARD_STATUS.DESCRIPTION like '%" + status
				+ "' AND cards.replace_card_oid \r\n" + "IS NULL and rownum=1";
		return connectDBAndGetValue(queryToGetRandomCard, PropUtils.getPropValue(configProp, "sqlODSServerName"));
	}

	public void updateCardValue(String cardNumber, String fieldName, String value, String cardStatus, String clientName,
			String clientCountry, String replaceOrNot) {

		JSONObject updateCardValue = new JSONObject();
		String queryParam;
		if (replaceOrNot.equalsIgnoreCase("Yes")) {
			queryParam = "?reissueAllowed=true";
		} else {
			queryParam = "?reissueAllowed=false";
		}
		if (cardNumber.equalsIgnoreCase("Random")) {
			cardNumber = getCardWithLogin(cardStatus,
					PropUtils.getPropValue(configProp, "UserNameAPI" + "_" + clientName + "_" + clientCountry));
			if (!(cardNumber != null && cardNumber.length() > 0)) {
				logFail("No Active Cards from DB!! For Updaing");
			}
		}
		// Getting all fields
		updateCardValue.put("card", jsonObjectBuilder("cardNo", cardNumber));
		JSONObject jsonArray = new JSONObject();
		/*if (!(fieldName.contains("-"))) {
			updateCardValue.put(fieldName, value);
		} else {
			String tags[] = fieldName.split("-");
			System.out.println("Tag Count:" + tags.length);
			switch (tags.length) {
			case 2:
				if (fieldName.contains("[") || fieldName.contains("]")) {
					for (int key = tags.length; key > 0; key--) {
						System.out.println("Arrya - Key Value Pair:" + tags[key].replace("\\[|\\]", "") + tags.length);
						if (key == tags.length) {
							jsonArray.put(tags[key].replaceAll("\\[|\\]", ""), value);
						} else {
							updateCardValue.put(tags[key], jsonArrayBuilder(tags[key--], jsonArray.toString()));
						}
					}
				} else {
					updateCardValue.put(tags[0], jsonObjectBuilder(tags[1], value));
				}
			default:
				if (fieldName.contains("[")) {
					for (int key = tags.length; key > 0; key--) {
						if (key == tags.length) {
							System.out.println(
									"Array - Key Value Pair:" + tags[key].replace("\\[|\\]", "") + tags.length);
							jsonArray.put(tags[key].replace("\\[|\\]", ""), value);
						} else {
							updateCardValue.put(tags[key], jsonArrayBuilder(tags[key--], jsonArray.toString()));
						}
					}
				} else {
					for (int key = tags.length; key > 0; key--) {
						if (key == tags.length) {
							jsonArray.put(tags[key], value);
						} else {
							updateCardValue.put(tags[key], jsonArrayBuilder(tags[key--], jsonArray.toString()));
						}
					}

				}
			}
		}*/
		System.out.println("Request:" + updateCardValue);
		response = apiUtils.putRequestAsBearerAuthWithBodyData(PropUtils.getPropValue(configProp, "AuthorizationToken"),
				updateCardValue, PropUtils.getPropValue(configProp, "UPDATE_CARD") + queryParam);
		System.out.println(" Printing the Post response----->" + response.body().prettyPrint());
		if (response.getStatusCode() == 200) {
			logPass("Card updated successfully");
		} else {
			logFail("Card Updation for :" + fieldName + "Error log: " + response.body().prettyPrint());
		}
	}

	public void transferCards(String clientName, String clientCountry, String cardNumber, String fromCustomer,
			String toCustomer) {
		Common common = new Common(driver, test);
		JSONObject cardTransfer = new JSONObject();
		if (cardNumber.equalsIgnoreCase("Random")) {
			cardNumber = getCardWithLogin("Active",
					PropUtils.getPropValue(configProp, "UserNameAPI" + "_" + clientName + "_" + clientCountry));
			if (!(cardNumber != null && cardNumber.length() > 0)) {
				logFail("No Active Cards from DB!! For Transfer");
			}
		}
		cardTransfer.put("customerNo", fromCustomer);
		cardTransfer.put("newCustomerNo", toCustomer);
		cardTransfer.put("feeProfileDescription", "");
		cardTransfer.put("cardProductDescription", getCardProductOfCard(cardNumber));
		cardTransfer.put("requestedBy", "AutomationAPI");
		String ifcsDate = "07/06/2020";
		// common.getCurrentIFCSDateFromDB(PropUtils.getPropValue(configProp,
		// clientName+"_"+clientCountry));
		// common.getProcessedIFCSDate("future", 2, "");

		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
		Date dt = new Date();
		try {
			dt = sdf.parse(ifcsDate);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Processed Date:" + ifcsDate);
		cardTransfer.put("effectiveOn", common.timeStampToEpochMillisSec(dt.toString()));
		cardTransfer.put("isCreatePrivateProfile", "Y");
		cardTransfer.put("requestedPhone", fakerAPI().phoneNumber().cellPhone());
		cardTransfer.put("cards", jsonArrayBuilder("cardNo", cardNumber));
		System.out.println("Card Transfer Body" + cardTransfer);
		response = apiUtils.postRequestAsBearerAuthWithBodyData(PropUtils.getPropValue(configProp, "CARD_TRANSFER"),
				cardTransfer, PropUtils.getPropValue(configProp, "AuthorizationToken"));

	}

	public String getCardProductOfCard(String cardNo) {
		return connectDBAndGetValue(
				"select description from card_products c where card_product_oid = (select card_product_oid from cards where card_no='"
						+ cardNo + "' )",
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
	}

	public void runEmbossingJobinControlM(String clientName, String clientCountry) {
		InterfacePage interfacePage = new InterfacePage(driver, test);
		if (clientName.contains("BP")) {
			interfacePage.runCtrlmJobs("BP_jobS_emboss");
		} else if (clientName.contains("EMAP")) {
			if (clientCountry.contains("SP") || clientCountry.contains("GU"))
				interfacePage.runCtrlmJobs("jobS_emap_SP_GU_emboss");
		} else if (clientName.contains("CHEV")) {
			if (clientCountry.equalsIgnoreCase("MY")) {

				interfacePage.runCtrlmJobs("jobs_chv_CardChanges_MY");
			} else if (clientCountry.equalsIgnoreCase("HK")) {
				interfacePage.runCtrlmJobs("jobS_chv_emboss_HK");
				interfacePage.runCtrlmJobs("jobs_chv_CardChanges");
			}

			else {
				interfacePage.runCtrlmJobs("jobS_chv_emboss");
				interfacePage.runCtrlmJobs("jobs_chv_CardChanges");
			}
		}
	}

	public void validateCardEmbossFile(String clientName, String clientCountry, String orderedCardNumber) {
		CommonInterfacePage commonInterfacePage = new CommonInterfacePage(driver, test);
		IFCSCommonPage ifcsCommonPage = new IFCSCommonPage(driver, test);
		InterfacePage interfacePage = new InterfacePage(driver, test);
		// Get Recent Processed File from IE Server
		String fileName = commonInterfacePage.getEMAPRecentProcessedFileName(configProp, clientName, clientCountry,
				"EmbossCards");
		ifcsCommonPage.establishThePuttyConnection("incomingFile", "PUTTY_HOST", "PUTTY_USERNAME", "PUTTY_PASSWORD",
				"IE_OUTPUTFILE_FOLDER_CAF", fileName);
		System.out.println("fileNamefileName::" + fileName);
		String localFolder = System.getProperty("user.home") + "\\Documents\\" + fileName;

		// Validate new Card Present in a File
		interfacePage.updateOrValidateFlatFile(emapcardembossCongifProp, "incomingFile", localFolder, orderedCardNumber,
				clientName, clientCountry, "");
	}

	public void validateCardStatus() {
		Common common = new Common(driver, test);
		logPass("Card Status Changed" + cardNoV);
		String currentStatus = common.getCardStatus(cardNoV);
		logPass("Card Status Changed to " + currentStatus);
		if (currentStatus.equalsIgnoreCase("No Transactions")) {
			logPass("Card Status Changed");
		} else {
			logFail("Card Status Not Changed" + currentStatus);
		}
	}

	public void updateLocation(String locationNo, String fieldName, String value) {

		JSONObject productRequestParams = new JSONObject();

		productRequestParams.put("locationNo", locationNo);
		productRequestParams.put(fieldName, value);

		response = apiUtils.putRequestAsBearerAuthWithBodyData(PropUtils.getPropValue(configProp, "AuthorizationToken"),
				productRequestParams, PropUtils.getPropValue(configProp, "UPDATE_LOCATION"));
		System.out.println(" Printing the PUT response----->" + response.body().prettyPrint());
		if (response.getStatusCode() == 200) {
			logInfo("Location updated successfully for card" + locationNo + "Response" + response.body().prettyPrint());
		} else {
			logFail("Location not updated to :" + value + "Error log: " + response.body().prettyPrint());
		}

	}
}
