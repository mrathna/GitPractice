﻿using Common;
using Common.PageObjects;
using Common.Utility;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace EnCompass.Testing.Source.PageObjects
{
    /// <summary>
    /// Page object for Texfree conversation page, which is, the screen where you can send and receive messages, once you are logged in.
    /// </summary>
    public class TextfreeConversationPage : PageModel
    {
        public TextfreeConversationPage(GlobalSettings settings) : base(settings) { }


        public override string RelativeUrl => @"https://textfree.us/#/conversation";
        public override string PageIdentifierXPath_Override => @".//div[normalize-space(text())='Textfree Web']";

        private readonly string _typeAMessageAreaXPath = ".//div[@class = 'emojionearea-editor']";
        private readonly string _sendButtonXPath = ".//button[@id= 'sendButton']";
        private readonly string _modalCloseXPath = ".//div[@id = 'SyncContactsXDismissPopup']";


        public string TypeAMessageArea
        {
            get
            {
                IWebElement userElement = Settings.EnCompassWebDriver.WaitFor(By.XPath(_typeAMessageAreaXPath));
                return userElement.Text;
            }
            set
            {
                IWebElement userElement = Settings.EnCompassWebDriver.WaitFor(By.XPath(_typeAMessageAreaXPath));
                userElement.WaitUntilElementIsInteractable();
                userElement.Clear();
                userElement.SendKeys(value);
                Settings.EnCompassExtentTest.Info("Set 'Type  message' on TextFree page as :" + value);
            }
        }

        public void ClickSend()
        {
            Settings.EnCompassWebDriver.WaitFor(By.XPath(_sendButtonXPath)).Click();
            AttachOnDemandScreenShot();
            Settings.EnCompassExtentTest.Info("Clicked on Send button.");
        }

        public void WaitForSendButton()
        {
            Settings.EnCompassWebDriver.WaitForElementsToBeVisible(By.XPath(_sendButtonXPath));
        }

        public void ClickPhoneNumberConversation(string phoneNumber)
        {
            string phoneNumberElementXPath = $"//conversation-list-element//div[normalize-space(text())='{phoneNumber}']";
            IWebElement ele = Driver.WaitFor(By.XPath(phoneNumberElementXPath));
            ele.WaitUntilElementIsInteractable();
            ele.Click();
            Settings.EnCompassExtentTest.Info($"Clicked on phone number tile {phoneNumber}.");
        }

        public static readonly string modalXPath = ".//div[normalize-space(@class) = 'modal-dialog']";
        /// <summary>
        /// Checks if an alert is present. 
        /// </summary>
        public bool WaitForModalToAppear(double timeInSec = 30)
        {
            try
            {
                Driver.WaitForVisible(By.XPath(modalXPath), TimeSpan.FromSeconds(timeInSec));
                Settings.EnCompassExtentTest.Info("Modal appeared.");
                return true;
            }
            catch (WebDriverTimeoutException)
            {
                AttachOnDemandScreenShot();
                Settings.EnCompassExtentTest.Warning($"Modal did not appear within {timeInSec.ToString()} secs");
                return false;
            }
        }

        public void WaitForModalToDisappear(double timeInSec = 30)
        {
            try
            {
                Driver.WaitForAbsence(By.XPath(modalXPath), TimeSpan.FromSeconds(timeInSec));
                Settings.EnCompassExtentTest.Info("Modal disappeared.");
            }
            catch (WebDriverTimeoutException ex)
            {
                AttachOnDemandScreenShot();
                Settings.EnCompassExtentTest.Warning($"Modal did not disappear within {timeInSec.ToString()} secs");
                throw ex;
            }
        }

        public void CloseOnModal()
        {
            bool isModalPresent = WaitForModalToAppear(10);

            if (!isModalPresent)
                return;

            Settings.EnCompassWebDriver.WaitFor(By.XPath(_modalCloseXPath)).Click();
            Settings.EnCompassExtentTest.Info("Clicked to close the modal.");

            WaitForModalToDisappear();
        }

        public void WaitForMessageAreaToBeVisible()
        {
            Settings.EnCompassExtentTest.Info($"Waiting for message area to be visible.");

            try
            {
                Driver.TryWaitForElementToBeVisible(By.XPath(_typeAMessageAreaXPath), out IWebElement ele);
            }

            catch (WebDriverTimeoutException ex)
            {
                Settings.EnCompassExtentTest.Info($"Message did not arrive on the expected time.");
                throw ex;
            }
        }

        public void WaitForFeedbackMessageToAppear(string message)
        {
            string feedBackXPath = $".//div[contains(@class, 'received-message') and text() = '{message}']";
            Settings.EnCompassExtentTest.Info($"Waiting for receving a message confirming the card had been put on hold.");
            try
            {
                Driver.WaitForElements(By.XPath(feedBackXPath));
            }

            catch (WebDriverTimeoutException ex)
            {
                Settings.EnCompassExtentTest.Info($"Message did not arrive on the expected time.");
                throw ex;
            }

            AttachOnDemandScreenShot();
            Settings.EnCompassExtentTest.Info($"Message arrived. Proceeding...");
        }
    }
}
