﻿using Common;
using EnCompass.Testing.Source.PageObjects.Controls;
using NFluent;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EnCompass.Testing.Source.PageObjects.Organization.ExpenseManager.PurchaseLog
{
	[PageModel(@"/expenseManager/PurchaseLog/purchaseLogHistory.aspx")]

	public partial class PurchaseLogHistory: EnCompassOrgPageModel
	{
		public override string RelativeUrl => @"/expenseManager/PurchaseLog/purchaseLogHistory.aspx";
		public override string PageIdentifierXPath_Generated => @"//li[contains(@class, 'breadcrumb-item active')][text() = 'History']";
		public PurchaseLogHistory(GlobalSettings settings) : base(settings) { }

		private GridControl _pLogHistory;
		public GridControl PLogHistoryGrid
		{
			get
			{
				GridControl grid = _pLogHistory ?? (_pLogHistory = new GridControl("PlogHistoryGrid", Driver));
				grid.WaitForGrid();
				return grid;
			}
		}

        public void VerifyHistoryEditedName(string name)
        {
            int gridpos  = PLogHistoryGrid.GetColumnHeaderIndex("Name");
            var gridName = PLogHistoryGrid.GetRowContaining(name).FindElement(By.XPath($"./td[{gridpos}]"));
            string ValidationName = gridName.Text;
            Check.That(ValidationName).Equals(name);
        }

        public void VerifyHistoryColumnValue(string column, string expectedvalue)
        {
            var columnValues = PLogHistoryGrid.GetColumnText(column);
            bool contains = false;

            foreach (string value in columnValues)
                if (value.Contains(expectedvalue))
                    contains = true;

            Settings.EnCompassExtentTest.Info($"Check That: Column {column} contains {expectedvalue}.");
            Check.That(contains).IsTrue();
        }
    }
}
