package com.framework.pages.AJS.common;

import java.util.Properties;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

import com.aventstack.extentreports.ExtentTest;
import com.framework.basepage.BasePage;
import com.framework.repo.Locator;
import com.framework.repo.Locator_IFCS;
import com.framework.util.PropUtils;

public class IFCSLoginPage extends BasePage {

	@FindBy(xpath = Locator_IFCS.IFCS_USERNAME)
	public WebElement userName;

	@FindBy(xpath = Locator_IFCS.IFCS_PASSWORD)
	public WebElement password;

	@FindBy(xpath = Locator_IFCS.IFCS_LOGIN)
	public WebElement loginButton;

	@FindBy(xpath = Locator_IFCS.WELCOMETEXT)
	public WebElement welcomeText;

	@FindBy(how = How.ID, using = Locator.USERNAME)
	public WebElement olsUsername;

	@FindBy(how = How.ID, using = Locator.PASSWORD)
	public WebElement olsPassword;

	@FindBy(how = How.ID, using = Locator.SIGNIN)
	public WebElement signin;

	@FindBy(how = How.ID, using = Locator.LOGOUT)
	public WebElement logoff;

	public Properties pointPropertiesfile = null;

	String clientName, clientCountry, cardType;

	public IFCSLoginPage(WebDriver driver, ExtentTest test) {
		super(driver, test);
		PageFactory.initElements(new AjaxElementLocatorFactory(driver, 15), this);
	}

	// Prakalpha
	public void login(String url, String uname, String pwd) {

		// public void login(String url, String uname) {
		System.out.println("------- url ------------" + url);
		System.out.println("------- uname ------------" + uname);
		System.out.println("------- Pwd ------------" + pwd);

		System.out.println("PROP URL VALUE ------ " + PropUtils.getPropValue(configProp, url));

		try
		{
             driver.get(PropUtils.getPropValue(configProp, url));
             
             ((JavascriptExecutor) driver).executeScript("return document.readyState").toString().equals("complete");
			//getURL(PropUtils.getPropValue(configProp, url));
			logInfo("Navigated to : " + PropUtils.getPropValue(configProp, url));
			driver.navigate().refresh();
			sleep(5);

			isDisplayedThenEnterText(userName, "IFCS login user name element",
					PropUtils.getPropValue(configProp, uname));
			System.out.println("username etnered");
			logInfo("User name : " + PropUtils.getPropValue(configProp, uname));

			// isDisplayedThenEnterText(password, "IFCS login Password element", "");
			isDisplayedThenEnterText(password, "IFCS login Password element", PropUtils.getPropValue(configProp, pwd));
			System.out.println("Password etnered");
			logInfo("Password : " + PropUtils.getPropValue(configProp, pwd));
			isDisplayedThenClick(loginButton, "Login Button");
			logInfo("Cilcked on login button");
			System.out.println("Click Click");
			isDisplayed(welcomeText, "Welcome");
			logPass("Login Sucess: welcome text displayed");
		} catch (Exception ex) {
			logFail("Logged In failed");
			}
		
	}
	
	public void loginAndZoomOut(String url, String uname, String pwd) {


		// public void login(String url, String uname) {
		System.out.println("------- url ------------" + url);
		System.out.println("------- uname ------------" + uname);
		System.out.println("------- Pwd ------------" + pwd);

		System.out.println("PROP URL VALUE ------ " + PropUtils.getPropValue(configProp, url));

		driver.get(PropUtils.getPropValue(configProp, url));

		//getURL(PropUtils.getPropValue(configProp, url));
		
		((JavascriptExecutor) driver).executeScript("return document.readyState").toString().equals("complete");
		driver.navigate().refresh();

		isDisplayedThenEnterText(userName, "IFCS login user name element", PropUtils.getPropValue(configProp, uname));

		sleep(3);

		isDisplayedThenEnterText(password, "IFCS login Password element", PropUtils.getPropValue(configProp, pwd));
		isDisplayedThenClick(loginButton, "Login Button");
		sleep(3);
		try {
		if (welcomeText.isDisplayed()) {

		} else {
		userName.sendKeys(PropUtils.getPropValue(configProp, uname));
		password.sendKeys(PropUtils.getPropValue(configProp, pwd));
		loginButton.click();
		}

		} catch (Exception ex) {
		logInfo("Logged In");
		}
		isDisplayed(welcomeText, "Welcome");
		
		/*
		 * driver.getCurrentUrl(); sleep(15);
		 * 
		 * for (int i = 0; i < 3; i++) { System.out.println("Entered into for loop");
		 * driver.findElement(By.xpath("//body")).sendKeys(Keys.chord(Keys.CONTROL,
		 * "l"));
		 * driver.findElement(By.xpath("//body")).sendKeys(Keys.chord(Keys.CONTROL,
		 * Keys.SUBTRACT));
		 */
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		executor.executeScript("document.body.style.zoom = '0.7'");
		

		// driver.findElement(By.tagName("html")).sendKeys(Keys.chord(Keys.CONTROL,
		// Keys.SUBTRACT));
		}
	


	public void setClientCountryCardTypeDetails(String clientName, String clientCountry, String cardType) {

		PropUtils.setProps(configProp, "clientName", clientName);
		PropUtils.setProps(configProp, "clientCountry", clientCountry);
		logInfo("ClientName :"+clientName+"_"+clientCountry);
		PropUtils.setProps(configProp, "cardType", cardType);
	}

	public void loginWithNewUser(String url, String uname, String pwd) {

		// public void login(String url, String uname) {
		System.out.println("------- url ------------" + url);
		System.out.println("------- uname ------------" + uname);
		System.out.println("------- Pwd ------------" + pwd);

		System.out.println("PROP URL VALUE ------ " + PropUtils.getPropValue(configProp, url));

		driver.get(PropUtils.getPropValue(configProp, url));
		((JavascriptExecutor) driver).executeScript("return document.readyState").toString().equals("complete");
		driver.navigate().refresh();
		
		//getURL(PropUtils.getPropValue(configProp, url));

		sleep(5);

		isDisplayedThenEnterText(userName, "IFCS login user name element", uname);

		// isDisplayedThenEnterText(password, "IFCS login Password element", "");
		isDisplayedThenEnterText(password, "IFCS login Password element", pwd);
		isDisplayedThenClick(loginButton, "Login Button");
		isDisplayed(welcomeText, "Welcome");
	}

	public void loginWithUsernameAndPwd(String uname, String pwd) {
		isDisplayedThenEnterText(olsUsername, "User name", uname);
		System.out.println("Username: " + uname);
		isDisplayedThenEnterText(olsPassword, "Password", pwd);
		System.out.println("Password: " + pwd);
		sleep(5);
		isDisplayedThenClick(signin, "Login");
		// isDisplayedThenClick(signin, "Login");
		sleep(5);
	}

}
