package com.framework.testcases.AJS.SHELL;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.MerchantLocationPage;
import com.framework.pages.AJS.common.Common;
import com.framework.pages.AJS.common.IFCSHomePage;
import com.framework.pages.AJS.common.IFCSLoginPage;
import com.github.javafaker.Faker;

public class ValidateMerchantLocationTestCases  extends BaseTest  {
	
	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test( groups = { "Regression" })
	public void validateProductsSoldAtLocation(@Optional("RU") String clientCountry,

			@Optional("SHELL") String clientName, @Optional("APA") String cardType) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  Merchant Location Products Sold at Location",
				"35 Maintain Location -  Products Sold at Location - Add New Product that doesn’t exist in the List "); 
		// creating  object for  the Pages
																													
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		Common common = new Common(driver, test);


		MerchantLocationPage MerchantLocation = new MerchantLocationPage(driver, test);

		IFCSloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, cardType);
		IFCSHomePage.gotoMerchantAndClickMerchantDetails();
		String merchant = common.getMerchantNoFromDB();
		if (merchant.equals(" ")) {
			common.logForNoDataFound(this.getClass().getSimpleName(), "Need to Create A Merchant and rerun");
		} else {
			common.chooseMerchantNoAndSearch(merchant);
			MerchantLocation.verifySoldLocation(clientName, clientCountry);

		}
		IFCSHomePage.exitIFCS();
	}

	
	@Parameters({ "clientCountry", "clientName", "cardType" })
	 @Test( groups = {"Regression"})
	 
	public void validateAddNewAgreement(@Optional("RU") String clientCountry,
			@Optional("SHELL") String clientName, @Optional("APA") String cardType)
	{
	test = extent.createTest(clientName+ ":" +clientCountry+"  MaintainLocation-Maintain Agreement", "48 Maintain Location -  Maintain Agreement  -  Add New Agreement");
	//creating object for the Pages
	IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
	IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
	Common common=new Common(driver,test);
	MerchantLocationPage  MerchantLocation=new MerchantLocationPage(driver,test);

	IFCSloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");
	IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, cardType);
	IFCSHomePage.gotoMerchantAndClickMerchantDetails();
	String merchant=common.getMerchantNoFromDB();
	common.chooseMerchantNoAndSearch(merchant);
	MerchantLocation.gotoMaintainAgreement();
	MerchantLocation.selectMerchantChildHierarchy();
	MerchantLocation.validateAddNewAgreementInAgreementList();
	IFCSHomePage.exitIFCS();

	}
	
	
	@Parameters({ "clientCountry", "clientName", "cardType" })
	 @Test( groups = {"Regression"})
	public void validateMaintainAgreement (@Optional("RU") String clientCountry,
			@Optional("SHELL") String clientName, @Optional("APA") String cardType)
	{
	test = extent.createTest(clientName+ ":" +clientCountry+"  MaintainLocation-Maintain Agreement", "42 Maintain Location -  Maintain Agreement");
	//creating object for the Pages
	IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
	IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
	Common common=new Common(driver,test);
	MerchantLocationPage  MerchantLocation=new MerchantLocationPage(driver,test);

		IFCSloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, cardType);
		IFCSHomePage.gotoMerchantAndClickMerchantDetails();
		String merchant = common.getMerchantNoFromDB();
		if (merchant.equals(" ")) {
			common.logForNoDataFound(this.getClass().getSimpleName(), "Need to Create A Merchant and rerun");
		} else {
			common.chooseMerchantNoAndSearch(merchant);
			MerchantLocation.gotoMaintainAgreement();
			MerchantLocation.validateMerchantChildReport();

		}
		IFCSHomePage.exitIFCS();
	}

@Parameters({ "clientCountry", "clientName", "cardType" })
 @Test( groups = {"Regression"})
	public void validateMaintainLocationAggrements(@Optional("RU") String clientCountry,
			@Optional("SHELL") String clientName, @Optional("APA") String cardType)
	{
		test = extent.createTest(clientName+ ":" +clientCountry+"  47 Maintain Location -Maintain Agreement -Agreements","MaintainLocation-Maintain Agreement");
		//creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		Common common=new Common(driver,test);
		MerchantLocationPage  MerchantLocation=new MerchantLocationPage(driver,test);
		
		IFCSloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, cardType);
		IFCSHomePage.gotoMerchantAndClickMerchantDetails();
		String merchantNo = common.getMerchantNoFromDB();
		if (merchantNo.equals(" ")) {
			common.logForNoDataFound(this.getClass().getSimpleName(), "Need to Create A Merchant  and rerun");
		} else {
			common.chooseMerchantNoAndSearch(merchantNo);
			MerchantLocation.verifyMaintainAgreements();
			MerchantLocation.verifyIsDetailsPresentInAgreement();

		}
		IFCSHomePage.exitIFCS();
	}

	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test( groups = {"Regression"})
	public void validateMerchantLocationAggrements(@Optional("RU") String clientCountry,
			@Optional("SHELL") String clientName, @Optional("APA") String cardType)
	{
		test = extent.createTest(clientName+ ":" +clientCountry+"  51 Merchant Location Agreements ","Merchant Location Agreements");
		//creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		Common common=new Common(driver,test);
		MerchantLocationPage  MerchantLocation=new MerchantLocationPage(driver,test);
		
		IFCSloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, cardType);
		IFCSHomePage.gotoMerchantAndClickMerchantDetails();
		String merchantNo = common.getMerchantNoFromDB();
		if (merchantNo.equals(" ")) {
			common.logForNoDataFound(this.getClass().getSimpleName(), "Need to Create A Merchant and rerun");
		} else {
			common.chooseMerchantNoAndSearch(merchantNo);
			MerchantLocation.validateMerchantAgreement();
			MerchantLocation.verifyIsDetailsPresentInAgreement();

		}
		IFCSHomePage.exitIFCS();
	}
	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test(groups = { "Regression" })

	public void validateAgreementsOverlap(@Optional("CZ") String clientCountry, @Optional("SHELL") String clientName,
			@Optional("APA") String cardType) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  MaintainLocation-Maintain Agreement", "Add New Agreement-Agreements Overlap");
		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		Common common = new Common(driver, test);
		MerchantLocationPage MerchantLocation = new MerchantLocationPage(driver, test);

		IFCSloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, cardType);
		IFCSHomePage.gotoMerchantAndClickMerchantDetails();
		String merchantNo = common.getMerchantNoFromDB();
		common.chooseMerchantNoAndSearch(merchantNo);
		MerchantLocation.gotoMaintainAgreement();
		MerchantLocation.selectMerchantChildHierarchy();
		MerchantLocation.validateNewAgreementsOverlap();
		IFCSHomePage.exitIFCS();

	}

	// Added by Ayub 18-02-2019

/*	@Parameters({ "clientCountry", "clientName", "cardType" })

	@Test( groups = { "Regression" })
	public void validateAddMerchantAndLocationReports(@Optional("RU") String clientCountry,
			@Optional("SHELL") String clientName,

			@Optional("APA") String cardType) {
		test = extent.createTest(
				"Verify Maintain Location -  Maintain Agreement  -  Add Merchant Reports, Add Location Reports",
				"Verifying Maintain Location -  Maintain Agreement  -  Add Merchant Reports, Add Location Reports"); // creating
																														// object
																														// for
																														// the
																														// Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);

		MerchantLocationPage MerchantLocation = new MerchantLocationPage(driver, test);

		IFCSloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");

		IFCSHomePage.gotoMerchantAndClickMerchantDetails(); //
		MerchantLocation.validatAddMerchantReports(); //
		MerchantLocation.validatAddLocationReports();
		IFCSHomePage.exitIFCS();

	}
*/
	
	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test( groups = { "Regression" })
	public void ValidateToCreateMerchant(@Optional("RU") String clientCountry,@Optional("SHELL") String clientName,@Optional("APA") String cardType) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  Create Merchant",
				"Create Merchant");
		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		Common common=new Common(driver,test);
		MerchantLocationPage  merchantLocation=new MerchantLocationPage(driver,test);
		IFCSloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry,"");
		IFCSHomePage.gotoApplicationAndClickApplicationMenu();
		IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);
		IFCSHomePage.gotoMerchantAndClickMerchantDetails();
		String merchant=common.getMerchantNoFromDB();
		common.chooseMerchantNoAndSearch(merchant);
		Faker fakerNumber = new Faker();
		String f_merchantNo = fakerNumber.number().digits(6);
		merchantLocation.createNewMerchant(f_merchantNo);	
		IFCSHomePage.exitIFCS();
	}
	
}
