using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using Common;
using Common.PageObjects;
using Common.ScenarioConfigurations;
using Common.Utility;

namespace EnCompass.Testing.Source.PageObjects.SuperAdmin.Testing 
{
	/// <summary>
	/// Auto-generated Page Model Class
	/// Navigation Paths: 
		/// [Organization Home]->General->Testing->Performance
		/// </summary>
	[PageModel(@"/superAdmin/testing/Performance.aspx")]
	public partial class Performance : EnCompassSuperPageModel 
	{
		public override string RelativeUrl => @"/superAdmin/testing/Performance.aspx";
		public override string PageIdentifierXPath_Generated => @"//li[contains(@class, 'breadcrumb-item active')][text() = 'Performance']";

		#region Navigation
				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Create Organization']")]
		private IWebElement _general_Testing_Performance_CreateOrganization { get; set; }
		public void NavigateTo_General_Testing_Performance_CreateOrganization()
		{
			NavigateToMenuItem(_general_Testing_Performance_CreateOrganization);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Create Organization Profile']")]
		private IWebElement _general_Testing_Performance_CreateOrganizationProfile { get; set; }
		public void NavigateTo_General_Testing_Performance_CreateOrganizationProfile()
		{
			NavigateToMenuItem(_general_Testing_Performance_CreateOrganizationProfile);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Delete Test Organization']")]
		private IWebElement _general_Testing_Performance_DeleteTestOrganization { get; set; }
		public void NavigateTo_General_Testing_Performance_DeleteTestOrganization()
		{
			NavigateToMenuItem(_general_Testing_Performance_DeleteTestOrganization);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Create Test Company']")]
		private IWebElement _general_Testing_Performance_CreateTestCompany { get; set; }
		public void NavigateTo_General_Testing_Performance_CreateTestCompany()
		{
			NavigateToMenuItem(_general_Testing_Performance_CreateTestCompany);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Corporate Credit Limit']")]
		private IWebElement _general_Testing_Performance_CorporateCreditLimit { get; set; }
		public void NavigateTo_General_Testing_Performance_CorporateCreditLimit()
		{
			NavigateToMenuItem(_general_Testing_Performance_CorporateCreditLimit);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Create Bounce Notification']")]
		private IWebElement _general_Testing_Performance_CreateBounceNotification { get; set; }
		public void NavigateTo_General_Testing_Performance_CreateBounceNotification()
		{
			NavigateToMenuItem(_general_Testing_Performance_CreateBounceNotification);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Reset Merchant Log Error']")]
		private IWebElement _general_Testing_Performance_ResetMerchantLogError { get; set; }
		public void NavigateTo_General_Testing_Performance_ResetMerchantLogError()
		{
			NavigateToMenuItem(_general_Testing_Performance_ResetMerchantLogError);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Performance']")]
		private IWebElement _general_Testing_Performance_Performance { get; set; }
		public void NavigateTo_General_Testing_Performance_Performance()
		{
			NavigateToMenuItem(_general_Testing_Performance_Performance);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='AP Non-Card Payments Testing']")]
		private IWebElement _general_Testing_Performance_ApNonCardPaymentsTesting { get; set; }
		public void NavigateTo_General_Testing_Performance_ApNonCardPaymentsTesting()
		{
			NavigateToMenuItem(_general_Testing_Performance_ApNonCardPaymentsTesting);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Modify Merchant Log']")]
		private IWebElement _general_Testing_Performance_ModifyMerchantLog { get; set; }
		public void NavigateTo_General_Testing_Performance_ModifyMerchantLog()
		{
			NavigateToMenuItem(_general_Testing_Performance_ModifyMerchantLog);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Test Templates']")]
		private IWebElement _general_Testing_Performance_TestTemplates { get; set; }
		public void NavigateTo_General_Testing_Performance_TestTemplates()
		{
			NavigateToMenuItem(_general_Testing_Performance_TestTemplates);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Create Test Statements']")]
		private IWebElement _general_Testing_Performance_CreateTestStatements { get; set; }
		public void NavigateTo_General_Testing_Performance_CreateTestStatements()
		{
			NavigateToMenuItem(_general_Testing_Performance_CreateTestStatements);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Contact Us']")]
		private IWebElement _general_Testing_Performance_ContactUs { get; set; }
		public void NavigateTo_General_Testing_Performance_ContactUs()
		{
			NavigateToMenuItem(_general_Testing_Performance_ContactUs);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Dispute Transaction']")]
		private IWebElement _general_Testing_Performance_DisputeTransaction { get; set; }
		public void NavigateTo_General_Testing_Performance_DisputeTransaction()
		{
			NavigateToMenuItem(_general_Testing_Performance_DisputeTransaction);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Terms and Conditions']")]
		private IWebElement _general_Testing_Performance_TermsAndConditions { get; set; }
		public void NavigateTo_General_Testing_Performance_TermsAndConditions()
		{
			NavigateToMenuItem(_general_Testing_Performance_TermsAndConditions);
		}

		
		private void NavigateToMenuItem(IWebElement element)
		{
			Driver.Url = element.GetAttribute("href");
		}
		#endregion

		public Performance(GlobalSettings settings) : base(settings) { }
	}  
}
