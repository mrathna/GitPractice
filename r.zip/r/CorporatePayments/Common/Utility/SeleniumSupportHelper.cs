﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Common.Utility
{
	public static class SeleniumSupportHelper
	{
		public static By GetBy<T>(Expression<Func<T>> propertyExpression)
		{
			var info = ExtractPropertyInfo(propertyExpression);
			var attribute = info.GetCustomAttribute<FindsByAttribute>(true);
			By by = null;
			switch (attribute.How)
			{
				case How.ClassName:
					by = By.ClassName(attribute.Using);
					break;
				case How.CssSelector:
					by = By.CssSelector(attribute.Using);
					break;
				case How.Id:
					by = By.Id(attribute.Using);
					break;
				case How.LinkText:
					by = By.LinkText(attribute.Using);
					break;
				case How.Name:
					by = By.Name(attribute.Using);
					break;
				case How.PartialLinkText:
					by = By.PartialLinkText(attribute.Using);
					break;
				case How.TagName:
					by = By.TagName(attribute.Using);
					break;
				case How.XPath:
					by = By.XPath(attribute.Using);
					break;
			}
			if (by == null)
			{
				throw new Exception($"Unable to generate 'By' from attribute with this 'How' clause: {attribute.How}");
			}
			return by;
		}

		/// <summary>
		/// Extracts the property info from a property expression.
		/// </summary>
		/// <typeparam name="T">The object type containing the property specified in the expression.</typeparam>
		/// <param name="propertyExpression">The property expression (e.g. p => p.PropertyName)</param>
		/// <returns>The property information.</returns>
		/// <exception cref="ArgumentNullException">Thrown if the <paramref name="propertyExpression"/> is null.</exception>
		/// <exception cref="ArgumentException">Thrown when the expression is:<br/>
		///     Not a <see cref="MemberExpression"/><br/>
		///     The <see cref="MemberExpression"/> does not represent a property.<br/>
		///     Or, the property is static.
		/// </exception>
		public static MemberInfo ExtractPropertyInfo<T>(Expression<Func<T>> propertyExpression)
		{
			if (propertyExpression == null)
			{
				throw new ArgumentNullException("propertyExpression");
			}

			var memberExpression = propertyExpression.Body as MemberExpression;
			if (memberExpression == null)
			{
				throw new ArgumentException("The expression is not a member access expression", "propertyExpression");
			}

			var property = memberExpression.Member as PropertyInfo;
			if (property != null)
			{
				var getMethod = property.GetMethod;
				if (getMethod.IsStatic)
				{
					throw new ArgumentException("The referenced property is a static property", "propertyExpression");
				}
			}

			return memberExpression.Member;
		}
	}
}
