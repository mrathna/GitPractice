package com.framework.testcases.OLS.BP.Location;

import java.util.ArrayList;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.BP.BPHomePage;
import com.framework.pages.OLS.common.CommonPage;
import com.framework.pages.OLS.common.LoginPage;
import com.framework.pages.OLS.common.MerchantReportsPage;

public class ValidateLocationReportPages extends BaseTest {

	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "Smoke", "Regression","BusinessFlow" })
	public void validateAdhocReportPage(@Optional("AU") String clientCountry, @Optional("BP") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  BP Location Reports Page", "Validation Location Report Pages");

		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		BPHomePage bpHomePage = new BPHomePage(driver, test);
		MerchantReportsPage merchantReportsPage = new MerchantReportsPage(driver, test);
		loginPage.Login("BP_URL", "BP_UN_Location_" + clientCountry, "BP_PWD_Location_" + clientCountry, clientName);
		bpHomePage.ValidateMerchantLogo();
		// Validate Adhoc Report Page
		merchantReportsPage.clickAdhocReportPageAndValidate();
		merchantReportsPage.clickAdhocExportLinkBtn("avaliableReport");

		// Able to click Merchant Reconciliation Report and Validate
		merchantReportsPage.iterateAndClickFromAdhocReportTable();
		merchantReportsPage.validateAdhocReportRunPage();
		merchantReportsPage.clickBackToAdhocReportLinkAndValidate();

		// Validate Scheduled Report Page
		merchantReportsPage.clickScheduledReportPageAndValidate();
		merchantReportsPage.clickAddScheduledReportButtonAndValidate();

		// Enter all fields and able to save with success message
		merchantReportsPage.selectAllFieldsFromScheduledMaintenancePage();
		merchantReportsPage.enterEmailAddressSaveAndValidate();
		merchantReportsPage.checkEnabledCheckbox();
		merchantReportsPage.clickScheduledReportSearchBtnAndValidate();
		merchantReportsPage.selectReportFromTableAndValidate();
		merchantReportsPage.editScheduleNameSaveAndValidate();

		// Validate Stored Report Page
		merchantReportsPage.clickStoredReportPageAndValidate();

		// Select Report type and validate
		merchantReportsPage.selectReportTypeSearchFromStoredReportAndValidate();

		// Validate Statements Report Page
		merchantReportsPage.clickStatementPageAndValidate();
		merchantReportsPage.validateStoredReportHeader();

		// Select date from the Calendar Control
		merchantReportsPage.selectCreatedFromDateUsingCalendarControl();

		// merchantReportsPage.clickStatementPageExportLinkBtn(); --Window Popup Handle
		merchantReportsPage.clickLocStatementPageSearchBtn();
		merchantReportsPage.clickStoredReportExportLinkBtn("tableStoredRepList");
		

		loginPage.Logout();
	}

	
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "Smoke", "Regression" })
	public void validateExcelOfAdhocExportReport(@Optional("AU") String clientCountry, @Optional("BP") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  TC_13_ Export a Reports", "Validation Location Adhoc Report");

		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		BPHomePage bpHomePage = new BPHomePage(driver, test);
		MerchantReportsPage merchantReportsPage = new MerchantReportsPage(driver, test);
		CommonPage commonPage=new CommonPage(driver,test);
		loginPage.Login("BP_URL", "BP_UN_Location_" + clientCountry, "BP_PWD_Location_" + clientCountry, clientName);
		ArrayList<String> description;
		String[] columnHeader= {"Description"};
		bpHomePage.ValidateMerchantLogo();
		merchantReportsPage.clickAdhocReportPageAndValidate();
		description=merchantReportsPage.validateAdhocTableDescription();
		System.out.println("Description of the list " +description);
		merchantReportsPage.clickAdhocExportLinkBtn("avaliableReport");
		String sheet=merchantReportsPage.getSheetNameForAdhocReport();
		commonPage.validateExpectedValuesInExcel("avaliableReport",sheet,
				columnHeader, description);
	    loginPage.Logout();
	}
	
	/*
	 * Added by Davu 13/05/2020
	 */
	
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "Smoke", "Regression","BusinessFlow" })
	public void scheduleReprotAndValidate(@Optional("AU") String clientCountry, @Optional("BP") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  BP Location schedule Reports Page", "schedule a report and validate in Location Report Pages");

		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		BPHomePage bpHomePage = new BPHomePage(driver, test);
		MerchantReportsPage merchantReportsPage = new MerchantReportsPage(driver, test);
		loginPage.Login("BP_URL", "BP_UN_Location_" + clientCountry, "BP_PWD_Location_" + clientCountry, clientName);
		bpHomePage.ValidateMerchantLogo();
		

		// Validate Scheduled Report Page
		merchantReportsPage.clickScheduledReportPageAndValidate();
		merchantReportsPage.clickAddScheduledReportButtonAndValidate();

		// Enter all fields and able to save with success message
		merchantReportsPage.selectAllFieldsFromScheduledMaintenancePage();
		merchantReportsPage.enterEmailAddressSaveAndValidate();
		merchantReportsPage.checkEnabledCheckbox();
		merchantReportsPage.clickScheduledReportSearchBtnAndValidate();
		merchantReportsPage.selectReportFromTableAndValidate();
		merchantReportsPage.editScheduleNameSaveAndValidate();
	
		loginPage.Logout();
	}


}
