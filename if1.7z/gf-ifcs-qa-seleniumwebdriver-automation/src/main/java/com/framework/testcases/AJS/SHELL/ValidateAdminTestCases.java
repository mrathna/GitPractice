package com.framework.testcases.AJS.SHELL;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.AdminPage;
import com.framework.pages.AJS.CardMaintenancePage;
import com.framework.pages.AJS.common.Common;
import com.framework.pages.AJS.common.IFCSHomePage;
import com.framework.pages.AJS.common.IFCSLoginPage;
import com.framework.util.PropUtils;
import com.github.javafaker.Faker;

/**
 * @author smanikandan
 *
 */
public class ValidateAdminTestCases extends BaseTest {

	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test( groups = { "Regression" }) 
	public void validateAdminUser(@Optional("AT") String clientCountry, @Optional("SHELL") String clientName, @Optional("APA") String cardType) {	 
		test = extent.createTest(clientName+ ":" +clientCountry+"  08 In IFCS locate an Internet Users Logon Id with Role: Customer Administrator for a Customer with Card Offer,"
				+ "09 Verify the Customer Administrator for Application Type can create a user in OLS with Role: Customer Administrator",
				"verifying customers aasigned to the OLS user id ");

		String olsUserId = null;
		//String olsPwd= null;
		String customerType=null;

		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);


		Common common=new Common(driver,test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		CardMaintenancePage cardMaintenancePage = new CardMaintenancePage(driver, test);


		// Calling Functions
		IFCSloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, cardType);

		// Calling Functions 
		if(cardType.equals("PC"))
		{
			olsUserId = PropUtils.getPropValue(configProp, "SHLPC_UN_Customer_Admin_" + clientCountry);
		//	olsPwd = PropUtils.getPropValue(configProp, "SHLPC_PWD_Customer_Admin_" + clientCountry);
			customerType = "Partner";
		}
		else if(cardType.equals("APA"))
		{
			olsUserId = PropUtils.getPropValue(configProp, "SHLPC_UN_Customer_Admin_" + clientCountry);
		//	olsPwd = PropUtils.getPropValue(configProp, "SHLPC_PWD_Customer_Admin_" + clientCountry);		
			customerType = "Pre-Paid";
		}
		System.out.println("OLSUSERID : "+olsUserId);

		IFCSHomePage.gotoAdminMenuAndChooseClientGroup();
		//			cardMaintenancePage.gotoSecurityAndClickOnline();
		common.goToOnlineUsers();
		cardMaintenancePage.verifyingMembersUnderAUserID(olsUserId,customerType);
		

	}
	
	/**
	 * Added by Davu - 28/04/2020
	 *
	 */
	
	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test( groups = { "Regression" })
	public void validateAndCreateNewIFCSDesktopUser(@Optional("AT") String clientCountry, @Optional("SHELL") String clientName, @Optional("APA") String cardType) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  01 Create a new IFCS Desktop user", "Validate and create 01 Create a new IFCS Desktop user");
		// creating object for the Pages
		IFCSLoginPage ifcsloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage ifcsHomePage = new IFCSHomePage(driver, test);
		AdminPage ifcsAdminPage = new AdminPage(driver, test);
		Common common = new Common(driver, test);
		
		ifcsloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");
		ifcsloginPage.setClientCountryCardTypeDetails(clientName, clientCountry," ");
		ifcsHomePage.gotoAdminMenuAndChooseClient(clientName+"_"+clientCountry);
		ifcsHomePage.gotoApplicationAndClickApplicationMenu();
		
		// Selecting client from Application Menu
		ifcsHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);
		
		common.searchListTorch();
		
		common.selectFirstRowNumberInSearchList();
		
		common.validateHeaderLabel("Maintain Application");
		
		ifcsHomePage.gotoAdminMenuAndChooseClientGroup();
		
		ifcsAdminPage.chooseDesktopMenuFromSecurityMenu();
		
		String userName = ifcsAdminPage.validateAndCreateNewUsersEnterDetails();
		ifcsHomePage.exitIFCS();
		ifcsloginPage.loginWithNewUser("IFCS_URL_SHELL", userName, "Password01");
		ifcsHomePage.exitIFCS();
	}
	
	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test( groups = { "Regression" })
	public void ValidateToCreateNewOlsUserwithCustomerAssigned(@Optional("AT") String clientCountry, @Optional("SHELL") String clientName, @Optional("APA") String cardType){
		

		test = extent.createTest(clientName+ ":" +clientCountry+"  Verify 02 Create new ols customer user with a customer assigned, TST-SC-68-OLS - DESKTOP - Change password in First login", "02 Create new ols customer user with a customer assigned, TST-SC-68-OLS - DESKTOP - Change password in First login");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCShomePage = new IFCSHomePage(driver, test);
	//	LoginPage loginPage = new LoginPage(driver, test);
		Common common = new Common(driver, test);
	//	HomePage homePage = new HomePage(driver, test);
	
		IFCSloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		IFCShomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);
		IFCShomePage.gotoAdminMenuAndChooseClientGroup();
		common.goToOnlineUsers();
		Faker fakerN = new Faker();
		String testName = fakerN.name().firstName()+"_"+fakerN.name().lastName()+fakerN.number().digits(2);
		String testPwd = "Password"+fakerN.number().digits(2);
		// String testPwd1 = fakerN.name().firstName()+"_"+fakerN.name().lastName()+fakerN.number().digits(3);
		System.out.println(testName);
		System.out.println(testPwd);
		String customerNo = common.getCustomerNoHavingCardsUsingCardType();
		IFCShomePage.createNewOlsMerchantOrCustomerUser(testName,testPwd,"Customer Administrator",customerNo,"Customer", clientName);
	
		IFCShomePage.exitIFCS();
		
		// loginPage.validateLoginPageFooterLinks(clientName, "EMAP_URL");
		// loginPage.loginWithUsernameAndPwd(testName, testPwd);
		// Validate the 
		// homePage.validatePasswordMaintenancePage(testPwd, testPwd1, testPwd1);
		// loginPage.Logout();

	
	}

	
}
