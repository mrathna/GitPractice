﻿using NFluent;
using Common.Utility;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EnCompass.Testing.Source.PageObjects.Organization.ExpenseManager.Transactions
{
	public partial class SelectCard
	{
        #region XPath page Elements
        private const string _searchTermListXPath = @"//div[contains(@id, 'SearchOutput')]/select[1]";
        #endregion

        #region Page Elements
        private IWebElement _searchTermList
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_searchTermListXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_searchTermList element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        #endregion
        
		public string SearchTermValues
		{
			get
			{
				return _searchTermList.Text;
			}
		}
	}
}
