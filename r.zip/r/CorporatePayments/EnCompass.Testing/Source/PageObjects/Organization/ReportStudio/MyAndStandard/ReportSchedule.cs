﻿using EnCompass.Testing.Source.PageObjects.Controls;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EnCompass.Testing.Source.PageObjects.Organization.ReportStudio.MyAndStandard
{
    public partial class ReportSchedule
    {
        private GridControl _scheduledReportsGrid;

        public GridControl ScheduledReportsGrid
        {
            get
            {
                _scheduledReportsGrid = new GridControl("contents_dg", Driver);
                _scheduledReportsGrid.WaitForGrid();

                return _scheduledReportsGrid;
            }
        }

        public void NavigateToScheduleReport()
        {
            Actions actions = new Actions(Driver);
            actions.MoveToElement(Driver.FindElement(By.XPath(@"//a[contains(@id,'reportStudio')]"))).MoveToElement(Driver.FindElement(By.XPath(@"//a[contains(@href, 'ReportSchedule.aspx')]"))).Click().Build().Perform();
            WaitForLoad();
        }
    }
}
