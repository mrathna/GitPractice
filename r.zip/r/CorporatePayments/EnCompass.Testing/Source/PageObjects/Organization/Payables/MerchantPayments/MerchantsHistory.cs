﻿using Common;
using EnCompass.Testing.Source.PageObjects.Controls;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EnCompass.Testing.Source.PageObjects.Organization.Payables.MerchantPayments
{
	[PageModel(@"/payables/merchantPayments/EditMerchant.aspx")]

	class MerchantsHistory : EnCompassOrgPageModel
	{
		public override string RelativeUrl => @"/payables/MerchantPayments/MerchantsHistory.aspx";
		public override string PageIdentifierXPath_Override => @"//li[@class='breadcrumb-item active'][contains(text(),'History')]";
		
		public MerchantsHistory(GlobalSettings Settings) : base(Settings) { }

		private NewGridControl _merchantHistorygrid;
		public NewGridControl MerchantHistoryGrid
		{
			get
			{
                NewGridControl grid = _merchantHistorygrid ?? (_merchantHistorygrid = new NewGridControl("etMerchantHistory", Driver, Settings));
				grid.WaitForGrid();
				return grid;
			}
		}

	}
}
