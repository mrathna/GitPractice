/*
   *  02-05-2018
   *  Ayub Khan
   */
package com.framework.pages.BP;

import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.ExtentTest;
import com.framework.basepage.BasePage;
import com.framework.repo.Locator;

public class BPChangePINPage extends BasePage {

	@FindBy(how = How.ID, using = Locator.CARD_INFORMATION_PIN_TEXTBOX)
	public WebElement newPIN;

	@FindBy(how = How.ID, using = Locator.CARD_INFORMATION_CONFIRM_PIN)
	public WebElement confirmPIN;

	@FindBy(how = How.ID, using = Locator.CARD_INFORMATION_SAVECHANGES)
	public WebElement saveChangeButton;
	@FindBy(how = How.ID, using = Locator.CONFIRMATIONMESSAGE)
	public WebElement confirmationMessage;

	@FindBy(how = How.ID, using = Locator.REISSUE_CARD_POPUP)
	public WebElement reissueCardPopup;

	@FindBy(how = How.ID, using = Locator.DELIVER_CONFIRM_AND_REISSUE)
	public WebElement confirmReissue;

	private String accountPin = "";

	public BPChangePINPage(WebDriver driver, ExtentTest test) {
		super(driver, test);
		PageFactory.initElements(driver, this);
		// TODO Auto-generated constructor stub
	}

	public void typeNewPin() {
		accountPin = String.valueOf(fakerAPI().number().numberBetween(1901, 1999));
		System.out.print("new pin"+accountPin);
		isDisplayedThenEnterText(newPIN, "ccount Level Pin", accountPin);
	}

	public void typeconfirmPIN() {
		isDisplayedThenEnterText(confirmPIN, "Account Level Pin", accountPin);
	}

	public void clickSaveChangesButton() {
		isDisplayedThenClick(saveChangeButton, "Save Changes Button");
		sleep(2);
	}

	/*
	 * Ayub Khan 02-5-2018
	 */
	public void checkConfirmationMessage() {
		sleep(5);
		isDisplayed(confirmationMessage, "Confirmation message");

		verifyText(confirmationMessage,
				"Congratulations. Your change of PIN has been made and will take effect at the point of sale within 2 hours.");

	}

	public void handleReissuePopupIfPresent() {
		try {
			if (reissueCardPopup.isDisplayed()) {
				isDisplayedThenActionClick(confirmReissue, "Confirm Reissue");
				sleep(5);
				if (getText(confirmationMessage)
						.contains("You can expect to receive your new card within 5 business days.")) {
					logPass("Reissue Card with new Pin sent");
				} else {
					checkConfirmationMessage();
				}

			}
		} catch (NoSuchElementException ex) {
			checkConfirmationMessage();
		}
	}
}
