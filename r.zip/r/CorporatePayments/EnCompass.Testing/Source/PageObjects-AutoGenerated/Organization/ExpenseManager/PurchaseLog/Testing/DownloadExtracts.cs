using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using Common;
using Common.PageObjects;
using Common.ScenarioConfigurations;
using Common.Utility;

namespace EnCompass.Testing.Source.PageObjects.Organization.ExpenseManager.PurchaseLog.Testing 
{
	/// <summary>
	/// Auto-generated Page Model Class
	/// Navigation Paths: 
		/// [Organization Home]->Payables->Purchase Log->Daily Extract Files
		/// </summary>
	[PageModel(@"/expenseManager/PurchaseLog/Testing/DownloadExtracts.aspx")]
	public partial class DownloadExtracts : EnCompassOrgPageModel 
	{
		public override string RelativeUrl => @"/expenseManager/PurchaseLog/Testing/DownloadExtracts.aspx";
		public override string PageIdentifierXPath_Generated => @"//li[contains(@class, 'breadcrumb-item active')][text() = 'Daily Extract Files']";

		#region Navigation
				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Purchase Logs']")]
		private IWebElement _payables_PurchaseLog_DailyExtractFiles_PurchaseLogs { get; set; }
		public void NavigateTo_Payables_PurchaseLog_DailyExtractFiles_PurchaseLogs()
		{
			NavigateToMenuItem(_payables_PurchaseLog_DailyExtractFiles_PurchaseLogs);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Create Purchase Log']")]
		private IWebElement _payables_PurchaseLog_DailyExtractFiles_CreatePurchaseLog { get; set; }
		public void NavigateTo_Payables_PurchaseLog_DailyExtractFiles_CreatePurchaseLog()
		{
			NavigateToMenuItem(_payables_PurchaseLog_DailyExtractFiles_CreatePurchaseLog);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Purchase Log Settings']")]
		private IWebElement _payables_PurchaseLog_DailyExtractFiles_PurchaseLogSettings { get; set; }
		public void NavigateTo_Payables_PurchaseLog_DailyExtractFiles_PurchaseLogSettings()
		{
			NavigateToMenuItem(_payables_PurchaseLog_DailyExtractFiles_PurchaseLogSettings);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Chargeback Reconciliation']")]
		private IWebElement _payables_PurchaseLog_DailyExtractFiles_ChargebackReconciliation { get; set; }
		public void NavigateTo_Payables_PurchaseLog_DailyExtractFiles_ChargebackReconciliation()
		{
			NavigateToMenuItem(_payables_PurchaseLog_DailyExtractFiles_ChargebackReconciliation);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Disputes']")]
		private IWebElement _payables_PurchaseLog_DailyExtractFiles_Disputes { get; set; }
		public void NavigateTo_Payables_PurchaseLog_DailyExtractFiles_Disputes()
		{
			NavigateToMenuItem(_payables_PurchaseLog_DailyExtractFiles_Disputes);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Create Single-Use Accounts']")]
		private IWebElement _payables_PurchaseLog_DailyExtractFiles_CreateSingleUseAccounts { get; set; }
		public void NavigateTo_Payables_PurchaseLog_DailyExtractFiles_CreateSingleUseAccounts()
		{
			NavigateToMenuItem(_payables_PurchaseLog_DailyExtractFiles_CreateSingleUseAccounts);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Create Test Transactions']")]
		private IWebElement _payables_PurchaseLog_DailyExtractFiles_CreateTestTransactions { get; set; }
		public void NavigateTo_Payables_PurchaseLog_DailyExtractFiles_CreateTestTransactions()
		{
			NavigateToMenuItem(_payables_PurchaseLog_DailyExtractFiles_CreateTestTransactions);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Daily Extract Files']")]
		private IWebElement _payables_PurchaseLog_DailyExtractFiles_DailyExtractFiles { get; set; }
		public void NavigateTo_Payables_PurchaseLog_DailyExtractFiles_DailyExtractFiles()
		{
			NavigateToMenuItem(_payables_PurchaseLog_DailyExtractFiles_DailyExtractFiles);
		}

		
		private void NavigateToMenuItem(IWebElement element)
		{
			Driver.Url = element.GetAttribute("href");
		}
		#endregion

		#region Side Navigation

		[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//li[1]")]
		private IWebElement _testing_Cards { get; set; }
		public void NavigateTo_Cards()
		{
			NavigateToMenuItem(_testing_Cards);
		}

		[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//li[2]")]
		private IWebElement _testing_CreateCardTransactions { get; set; }
		public void NavigateTo_CreateCardTransactions()
		{
			NavigateToMenuItem(_testing_CreateCardTransactions);
		}

		[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//li[3]")]
		private IWebElement _testing_SingleUseAccounts { get; set; }
		public void NavigateTo_SingleUseAccounts()
		{
			NavigateToMenuItem(_testing_SingleUseAccounts);
		}

		[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//li[4]")]
		private IWebElement _testing_SingleUseAccountTransactions { get; set; }
		public void NavigateTo_SingleUseAccountTransactions()
		{
			NavigateToMenuItem(_testing_SingleUseAccountTransactions);
		}

		[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//li[5]")]
		private IWebElement _testing_CreditLimitUpdate { get; set; }
		public void NavigateTo_CreditLimitUpdate()
		{
			NavigateToMenuItem(_testing_CreditLimitUpdate);
		}

		[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//li[6]")]
		private IWebElement _testing_DailyExtractFiles { get; set; }
		public void NavigateTo_DailyExtractFiles()
		{
			NavigateToMenuItem(_testing_DailyExtractFiles);
		}

		#endregion

		public DownloadExtracts(GlobalSettings settings) : base(settings) { }
	}  
}
