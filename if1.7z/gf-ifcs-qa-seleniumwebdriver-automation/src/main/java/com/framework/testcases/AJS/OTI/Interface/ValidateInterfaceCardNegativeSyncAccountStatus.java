package com.framework.testcases.AJS.OTI.Interface;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.ChangeCardStatus;
import com.framework.pages.AJS.common.Common;
import com.framework.pages.AJS.common.IFCSCommonPage;
import com.framework.pages.AJS.common.IFCSHomePage;
import com.framework.pages.AJS.common.IFCSLoginPage;
import com.framework.pages.AJS.common.InterfacePage;

public class ValidateInterfaceCardNegativeSyncAccountStatus extends BaseTest {
	@Parameters({ "clientCountry", "clientName" })
	@Test(priority = 1)
	public void validateAccountStatusChangeToTemporaryLock(@Optional("BW") String clientCountry,
			@Optional("OTI") String clientName) {
		test = extent.createTest(
				clientName + ":" + clientCountry
						+ "  20 Card Negative Sync for Account Status change Active to Temp Lock",
				"Validate Change Card status  in IFCS");
		/** Need Fix in Job execution **/
		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCShomePage = new IFCSHomePage(driver, test);
		IFCSCommonPage ifcsCommonPage = new IFCSCommonPage(driver, test);
		ChangeCardStatus changeCardStatus = new ChangeCardStatus(driver, test);
		//CommonInterfacePage commonInterfacePage = new CommonInterfacePage(driver, test);
		Common common = new Common(driver, test);
		IFCSloginPage.login("IFCS_URL_OTI", "IFCS_OTI_USERNAME", "IFCS_OTI_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		IFCShomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);

		// Get CustomerNumber from DB
		String customerNumber = common.getActiveOrTemporaryBlockCustomerNoHavingCardsAndRowIndex(1, "Active");
		IFCShomePage.gotoCustomerMenuCustomerDetails();
		common.chooseCustomerNoAndSearch(customerNumber);
		changeCardStatus.validateCustomerHasCards();
		IFCShomePage.gotoAccountAndClickAccountDetails();

		// Change CustomerAccount Status
		changeCardStatus.changeCustomerAccountStatus("Temporary Lock");
		// Getting latest file path from DB and incremented file name
		/*
		 * String lastProcessedFileNamePath =
		 * commonInterfacePage.getOTIRecentProcessedFileName(configProp, clientName,
		 * clientCountry); String fileName =
		 * commonInterfacePage.getOTIFileName(lastProcessedFileNamePath); String
		 * directoryPath =
		 * commonInterfacePage.getOTIFolderName(lastProcessedFileNamePath,
		 * clientCountry);
		 */
		InterfacePage interfacePage = new InterfacePage(driver, test);
		String folderName = ifcsCommonPage.getControlMFolder(clientName, clientCountry, "jobS_OTI_CardNegativeSync");
		String jobsInOrder = ifcsCommonPage.getJobsOfFolderInOrder("jobS_OTI_CardNegativeSync");
		IFCShomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);
		common.clientOutgoingBatchJobExecution("RM_G1_0199");

		// Executing control-m jobs
		interfacePage.establishAndExecuteControlMJobs("ControlM_AWS_UAT", "ContorlM_AWS_userName",
				"ContorlM_AWS_password", folderName, jobsInOrder);
		// Get File Name from IE Server
		/*
		 * ifcsCommonPage.establishThePuttyConnectionbyUserGeneratedRemoteDirectory(
		 * "incomingFile", "PUTTY_HOST", "PUTTY_USERNAME", "PUTTY_PASSWORD",
		 * directoryPath, fileName);
		 */

		IFCShomePage.gotoCustomerMenuCustomerDetails();
		changeCardStatus.validateCustomerHasCards();
		changeCardStatus.validateTemporaryLockStatusInCards("400 Temporary Acct Lock");
		IFCShomePage.exitIFCS();

	}

	@Parameters({ "clientCountry", "clientName" })
	@Test(priority = 2)
	public void validateAccountStatusChangeToActive(@Optional("BW") String clientCountry,
			@Optional("OTI") String clientName) {
		test = extent.createTest(
				clientName + ":" + clientCountry
						+ "  21 Card Negative Sync for Account Status change  Temp Lock  to Active  ",
				"Validate Change Card Status in IFCS");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCShomePage = new IFCSHomePage(driver, test);
		IFCSCommonPage ifcsCommonPage = new IFCSCommonPage(driver, test);
		ChangeCardStatus changeCardStatus = new ChangeCardStatus(driver, test);
		//CommonInterfacePage commonInterfacePage = new CommonInterfacePage(driver, test);
		Common common = new Common(driver, test);
		IFCSloginPage.login("IFCS_URL_OTI", "IFCS_OTI_USERNAME", "IFCS_OTI_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		IFCShomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);

		// Get CustomerNumber from DB
		String customerNumber = common.getActiveOrTemporaryBlockCustomerNoHavingCardsAndRowIndex(1, "Temporary Lock");
		IFCShomePage.gotoCustomerMenuCustomerDetails();
		common.chooseCustomerNoAndSearch(customerNumber);
		changeCardStatus.validateCustomerHasCards();
		IFCShomePage.gotoAccountAndClickAccountDetails();

		// Change CustomerAccount Status
		changeCardStatus.changeCustomerAccountStatus("Active");
		// Getting latest file path from DB and incremented file name

		/*
		 * String lastProcessedFileNamePath =
		 * commonInterfacePage.getOTIRecentProcessedFileName(configProp, clientName,
		 * clientCountry); String fileName =
		 * commonInterfacePage.getOTIFileName(lastProcessedFileNamePath); String
		 * directoryPath =
		 * commonInterfacePage.getOTIFolderName(lastProcessedFileNamePath,
		 * clientCountry);
		 */
		String folderName = ifcsCommonPage.getControlMFolder(clientName, clientCountry, "jobS_OTI_CardNegativeSync");
		String jobsInOrder = ifcsCommonPage.getJobsOfFolderInOrder("jobS_OTI_CardNegativeSync");
		IFCShomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);
		common.clientOutgoingBatchJobExecution("RM_G1_0199");
		InterfacePage interfacePage = new InterfacePage(driver, test);
		// Executing control-m jobs
		interfacePage.establishAndExecuteControlMJobs("ControlM_AWS_UAT", "ContorlM_AWS_userName",
				"ContorlM_AWS_password", folderName, jobsInOrder);
		// Get File Name from IE Server
		/*
		 * ifcsCommonPage.establishThePuttyConnectionbyUserGeneratedRemoteDirectory(
		 * "incomingFile", "PUTTY_HOST", "PUTTY_USERNAME", "PUTTY_PASSWORD",
		 * directoryPath, fileName);
		 */
		IFCShomePage.gotoCustomerMenuCustomerDetails();
		changeCardStatus.validateCustomerHasCards();
		changeCardStatus.validateActiveStatusInCards();
		IFCShomePage.exitIFCS();
	}

}
