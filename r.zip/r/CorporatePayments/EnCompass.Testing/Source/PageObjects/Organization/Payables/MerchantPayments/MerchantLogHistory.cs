﻿using AventStack.ExtentReports;
using Common;
using Common.Utility;
using EnCompass.Testing.Source.PageObjects.Controls;
using NFluent;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;

namespace EnCompass.Testing.Source.PageObjects.Organization.Payables.MerchantPayments
{
    [PageModel(@"/payables/merchantPayments/MerchantLogHistory.aspx")]
    public class MerchantLogHistory : EnCompassPageModel
    {

        public override string RelativeUrl => @"/payables/merchantPayments/MerchantLogHistory.aspx";
        public override string PageIdentifierXPath_Override => @"//li[@class='breadcrumb-item active'][text() = 'History'] ";

        #region XPath Page Elements

        public const string BACK_XPATH = @"//a[contains(@id,'BackToSearchResults')]";
        public const string COLUMNS_DIV_XPATH = "//div[@title = 'Columns']//div";
        public const string COLUMNS_BUTTON_XPATH = @"//button[@aria-label = 'Columns']";
        public const string MLOG_HISTORY_CAPTION_XPATH = ".//span[contains(@id, 'etMerchantLogHistory_Validator')]/following-sibling::h2";
        private const string colCheckXPATH = "{0}//input[@data-field = '{1}']";

        private const string _modalSaveAsHeaderXPath = @".//h1[contains(@id, 'SaveAsModal')]";
        private const string _modalRenameHeaderXPath = @".//h1[contains(@id, 'RenameModal')]";
        private const string _gridToolbarProfilesButtonXPath = @".//button[@title = 'Profiles' and contains(@id, '_ProfilesMenuLink')]";
        private const string _gridToolbarProfilesOptionXpath = ".//div[contains(@class, 'profiles dropdown-menu')]/button";
        private const string _newProfileNameXPath = "//input[contains(@id,'SaveAsProfileName')]";
        private const string _setAsDefaultProfileCheckboxXPath = "//input[contains(@id,'SaveAsSetDefault')]";
        private const string _setAsDefaultProfileCheckboxLabelXPath = "//label[contains(@for,'SaveAsSetDefault')]";
        private const string _setOverwriteExistingProfileCheckboxXPath = "//input[contains(@id,'SaveAsOverwrite')]";
        private const string _setOverwriteExistingProfileCheckboxLabelXPath = "//label[contains(@for,'SaveAsOverwrite')]";
        private const string _gridToolbarProfilesNamesXpath = @".//div[contains(@class, 'profiles dropdown-menu')]/div[contains(@id, 'Profile')]/h4";
        private const string _errorRequiredNameMessageXPath = ".//span[contains(@id, 'SaveAsProfileName_Error')]";
        private const string _errorRequiredRenameMessageXPath = ".//span[contains(@id, 'RenameProfileName_Error')]";
        private const string _saveAsSaveButtonXPath = "//button[contains(@id,'SaveAsSave')]";
        private const string _saveAsCancelButtonXPath = "//button[contains(@id,'SaveAsCancel')]";
        private const string _rbSelectProfileXPath = @"//input[contains(@id,'ProfilesRadioContainer') and @data-profile-name ='{0}']";
        private const string _rbSelectProfileLabelXPath = @"//label[contains(@for,'ProfilesRadioContainer') and contains(text(), '{0}')]";
        private const string _rbSelectSetDefaultProfileXPath = @"//input[contains(@id,'ProfilesDefaultRadioContainer') and @data-profile-name ='{0}']";
        private const string _rbSelectSetDefaultProfileLabelXPath = @"//label[contains(@for,'ProfilesDefaultRadioContainer') and contains(text(), '{0}')]";

        private const string _profileSetDefaultCancelButtonXPath = "//button[contains(@id,'profileSetDefaultCancel')]";
        private const string _profileSetDefaultSaveButtonXPath = "//button[contains(@id,'profileSetDefaultSave')]";

        private const string _profileResetCancelXPath = "//button[contains(@id, 'profileResetCancel')]";
        private const string _profileResetXPath = "//button[contains(@id, 'profileReset') and text()='Reset']";

        private const string _profileDeleteCancelButtonXPath = "//button[contains(@id, '_profileDeleteCancel')]";
        private const string _deleteProfileNameXPath = "//button[contains(@id, '_profileDelete') and text()='Delete']";

        private const string _profileSetDefaultModalXPath = ".//div[contains(@id, 'profilesSetDefaultModal') and contains(@style,'block')]";
        private const string _profileSaveAsModalXPath = ".//div[contains(@id, 'profilesSaveAsModal') and contains(@style,'block')]";
        private const string _profileResetModalXPath = ".//div[contains(@id, 'profilesResetModal') and contains(@style,'block')]";
        private const string _profileDeleteModalXPath = ".//div[contains(@id, 'profilesDeleteModal') and contains(@style,'block')]";
        private const string _profileRenameModalXPath = ".//div[contains(@id, 'profilesRenameModal') and contains(@style,'block')]";

        private const string _profilesNameXPath = @".//div[contains(@class, 'profiles dropdown-menu')]//div[contains(@id, 'Profile')]/h4[contains(text(), '{0}')]";
        private const string _profileControlsXPath = "//following-sibling::div/button";

        private const string _renameProfileNameXPath = "//input[contains(@id,'RenameProfileName')]";
        private const string _profileRenameCancelButtonXPath = "//button[contains(@id,'profileRenameCancel')]";
        private const string _profileRenameSaveButtonXPath = "//button[contains(@id,'profileRenameSave')]";
        #endregion

        #region Page Elements

        private IWebElement _back
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(BACK_XPATH), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_back element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _columnsDivElement
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(COLUMNS_DIV_XPATH), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_columnsDivElement element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _columnsButton
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(COLUMNS_BUTTON_XPATH), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_columnsButton element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _gridToolbarProfilesButton
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_gridToolbarProfilesButtonXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_gridToolbarProfilesButton element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
            set { }
        }

        private IList<IWebElement> _gridToolbarProfilesOption
        {
            get
            {
                bool found = Driver.TryWaitForElementsToBeVisible(By.XPath(_gridToolbarProfilesOptionXpath), out IList<IWebElement> element);
                Settings.EnCompassExtentTest.Info("_gridToolbarProfilesOption list exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
            set { }
        }

        private IWebElement _newProfileName
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_newProfileNameXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_newProfileName element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _errorRequiredNameMessage
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_errorRequiredNameMessageXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_errorRequiredNameMessage element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _saveAsCancelButton
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_saveAsCancelButtonXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_saveAsCancelButton element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _saveAsSaveButton
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_saveAsSaveButtonXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_saveAsSaveButton element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _setOverwriteExistingProfileCheckbox
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_setOverwriteExistingProfileCheckboxXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_setOverwriteExistingProfileCheckbox element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _setOverwriteExistingProfileCheckboxLabel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_setOverwriteExistingProfileCheckboxLabelXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_setOverwriteExistingProfileCheckboxLabel element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _setAsDefaultProfileCheckboxLabel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_setAsDefaultProfileCheckboxLabelXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_setAsDefaultProfileCheckboxLabel element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _setAsDefaultProfileCheckbox
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_setAsDefaultProfileCheckboxXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_setAsDefaultProfileCheckbox element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IList<IWebElement> _gridToolbarProfilesNames
        {
            get
            {
                bool found = Driver.TryWaitForElementsToBeVisible(By.XPath(_gridToolbarProfilesNamesXpath), out IList<IWebElement> element);
                Settings.EnCompassExtentTest.Info("_gridToolbarProfilesNames list exist is" + found);
                return element;
            }
        }

        private IWebElement _deleteProfileName
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_deleteProfileNameXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_deleteProfileName element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _profileSetDefaultCancelButton
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_profileSetDefaultCancelButtonXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_profileSetDefaultCancelButton element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _profileSetDefaultSaveButton
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_profileSetDefaultSaveButtonXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_profileSetDefaultSaveButton element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _modalSaveAsHeader
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_modalSaveAsHeaderXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_modalSaveAsHeader element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _modalRenameHeader
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_modalRenameHeaderXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_modalRenameHeader element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _profileResetCancel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_profileResetCancelXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_profileResetCancel element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _profileReset
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_profileResetXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_profileReset element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _profileRenameCancelButton
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_profileRenameCancelButtonXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_profileRenameCancelButton element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _renameProfileName
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_renameProfileNameXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_renameProfileName element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _errorRequiredRenameMessage
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_errorRequiredRenameMessageXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_errorRequiredrenameMessage element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _profileRenameSaveButton
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_profileRenameSaveButtonXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_profileRenameSaveButton element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _profileDeleteCancelButton
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_profileDeleteCancelButtonXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_renameProfileName element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _mlogHistoryCaption
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(MLOG_HISTORY_CAPTION_XPATH), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_mlogHistoryCaption element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        #endregion

        public string MLogCaption => _mlogHistoryCaption.Text;

        private NewGridControl _mLogHistoryNewGrid;
        public NewGridControl MLogHistoryNewGrid
        {
            get
            {
                NewGridControl grid = _mLogHistoryNewGrid ?? (_mLogHistoryNewGrid = new NewGridControl("etMerchantLogHistory", Driver, Settings));
                grid.WaitForGrid();
                return grid;
            }
        }

        /// <summary>
        /// Checks if the MLog history has more than 1 entries for the super user 
        /// </summary>
        public void ParseMlogHistory()
        {
            int counter = 0;
            int rowcount = 0;

			// Search MLog History ONLY if its NOT Production Env
			if (!GlobalSettings.Environment.Equals("PROD", StringComparison.InvariantCultureIgnoreCase))
			{
				foreach (IWebElement row in MLogHistoryNewGrid.GetRows())
				{
					rowcount++;				
					Driver.TryWaitForElement(By.XPath(MLogHistoryNewGrid._baseTableRowXPath + "[" + rowcount.ToString() + "]//td[3]"), out IWebElement _modBy);
					string _modifiedBy = _modBy.Text;
					string _actualModBy = GlobalSettings.SuperAdminUser;
					if (_modifiedBy.ToLowerInvariant().Contains(_actualModBy.ToLowerInvariant()))
						counter++;
				}
				Check.That(counter).IsStrictlyGreaterThan(1);
			}
			else
				Check.That(MLogHistoryNewGrid.GetRows().Count()).IsStrictlyGreaterThan(0);
		}

		/// <summary>
		/// Checks if the MLog history has the correct count of entries with expected amounts 
		/// </summary>
		public void ParseMlogHistoryForAmounts(List<string> amts)
		{
			int counter = 0;
			int rowcount = 0;
			foreach (IWebElement row in MLogHistoryNewGrid.GetRows())
			{
				rowcount++;
				Driver.TryWaitForElement(By.XPath(MLogHistoryNewGrid._baseTableRowXPath + "[" + rowcount.ToString() + "]//td[contains(text(),'USD')]"), out IWebElement _amt);
				string _mlogAmt = _amt.Text.Trim();
				if (amts.Any(d => d.Equals(_mlogAmt)))
					counter++;
			}
			Check.That(counter).IsStrictlyGreaterThan(amts.Count()-1);
		}

		public void CloseHistory()
        {
            _back.JSClickWithFocus(Driver);
            Settings.EnCompassExtentTest.Info("Clicked on Close History.");
        }

        public void ColumnsButtonClick()
        {
            _columnsButton.JSClickWithFocus(Driver);
            Settings.EnCompassExtentTest.Info("Clicked on 'Columns' button.");
        }

        public void EnableColumn(string name)
        {
            try
            {
                ColumnsButtonClick();
                _columnsDivElement.WaitUntilElementIsInteractable();
                Driver.TryWaitForElement(By.XPath(String.Format(colCheckXPATH, COLUMNS_DIV_XPATH, name)), out IWebElement colCheck);

                // In this case passing a label doesn't work because the label and checkbox hierarchy for this menu is different from usual.
                colCheck.SetCheckboxStateWithLabel(null, true);
                Settings.EnCompassExtentTest.Info($"Column {name} enabled.");

                // This click is for closing the div and regains focus to the grid
                ColumnsButtonClick();
            }

            catch (Exception ex)
            {
                throw ex;
            }

        }

        #region Profiles

        /// <summary>
        /// This method is used to perform Click on Profiles dropdown
        /// </summary>
        public void clickGridToolbarProfilesButton()
        {
            _gridToolbarProfilesButton.JSClickWithFocus(Driver);
            Settings.EnCompassExtentTest.Info("Clicked on Profiles button.");
        }

        /// <summary>
        /// This method is used to verify Profiles dropdown options
        /// </summary>
        public bool VerifyProfilesGridOptions(ExtentTest test)
        {
            clickGridToolbarProfilesButton();

            List<string> options = StringKeys.ProfilesOptions;
            for (int p = 0; p < options.Count(); p++)
            {
                if (!_gridToolbarProfilesOption[p].Text.Contains(options[p]))
                {
                    test.Info($"{options[p]} didn't matched with the Profile options.");
                    return false;
                }
            }
            test.Info("All of Profiles options verified.");

            return true;
        }

        /// <summary>
        /// This method is used to click on the profiles dropdown options
        /// </summary>
        public void ProfilesGrid(string option, ExtentTest test)
        {
            clickGridToolbarProfilesButton();

            Driver.TryWaitForElement(By.XPath(_gridToolbarProfilesOptionXpath + "[contains(text(), '" + option + "')]"), out IWebElement profileOption);

            string xpathModal = string.Empty;
            switch (option)
            {
                case "Save As":
                    xpathModal = _profileSaveAsModalXPath;
                    break;
                case "Set Default":
                    xpathModal = _profileSetDefaultModalXPath;
                    break;
                case "Reset":
                    xpathModal = _profileResetModalXPath;
                    break;
            }
            profileOption.JSClickWithFocus(Driver);
            test.Info("Clicked on Profile Option " + option);
            WaitForModalToAppear(xpathModal);

        }

        /// <summary>
        /// This method is used to set/get Profile Name
        /// </summary>
        public string NewProfileName
        {
            get { return _newProfileName.GetAttribute("value"); }
            set
            {
                _newProfileName.Clear();
                _newProfileName.SendKeys(value);
                Settings.EnCompassExtentTest.Info("Set New profile name with value: " + value);
            }
        }

        /// <summary>
        /// Method to unfocus textbox
        /// </summary>
        public void ModalHeaderClick()
        {
            _modalSaveAsHeader.BootstrapClick();//Cliked on header modal to take off focus from textbox
            Settings.EnCompassExtentTest.Info("Cliked on header modal.");
        }

        /// <summary>
        /// Method to unfocus textbox
        /// </summary>
        public void ModalRenameHeaderClick()
        {
            _modalRenameHeader.BootstrapClick();//Cliked on header modal to take off focus from textbox
            Settings.EnCompassExtentTest.Info("Cliked on header modal.");
        }

        /// <summary>
        /// This method is used to error for Required name message
        /// </summary>
        public string GetErrorRequiredNameMessage
        {
            get
            {
                return _errorRequiredNameMessage.Text;
            }
        }

        /// <summary>
        /// This method is used to perform Cancel inside the profiles dropdown option SaveAs
        /// </summary>
        public void SaveAsCancel()
        {
            WaitForModalToAppear(_profileSaveAsModalXPath);
            _saveAsCancelButton.JSClickWithFocus(Driver);
            WaitForModalToDisappear(_profileSaveAsModalXPath);
            Settings.EnCompassExtentTest.Info("Cancel button clicked on modal");
            WaitForFormLoadingOverlay();
        }

        /// <summary>
        /// This method is used to perform Save inside the profiles dropdown option SaveAs
        /// </summary>
        public void SaveAsSave()
        {
            WaitForModalToAppear(_profileSaveAsModalXPath);
            _saveAsSaveButton.JSClickWithFocus(Driver);
            WaitForModalToDisappear(_profileSaveAsModalXPath);
            Settings.EnCompassExtentTest.Info("Save as button clicked");
        }

        /// <summary>
        /// This method is used to set Overwrite Existing Profile checkbox inside the profiles dropdown option SaveAs
        /// </summary>
        public bool SetOverwriteExistingProfile
        {
            get { return _setOverwriteExistingProfileCheckbox.Selected; }
            set
            {
                _setOverwriteExistingProfileCheckbox.SetCheckboxStateWithLabel(_setOverwriteExistingProfileCheckboxLabel, value);
                Settings.EnCompassExtentTest.Info("Enable Overwrite existing profile: " + value);
            }
        }

        /// <summary>
        /// This method is used to select a existing profile radio option at Save As modal
        /// </summary>
        public void ChooseDefaultProfileOptionSaveAs(string name, ExtentTest test)
        {
            string xpath = String.Format(_rbSelectProfileXPath, name);
            Driver.TryWaitForElement(By.XPath(xpath), out IWebElement rbOption);
            xpath = String.Format(_rbSelectProfileLabelXPath, name);
            Driver.TryWaitForElement(By.XPath(xpath), out IWebElement label);

            rbOption.SetRadioButtonStateWithLabel(label, true);
            this.RefreshModel();
            test.Info($"The profile {name} selected.");
        }

        /// <summary>
        /// This method is used to check if Profile name field is Enabled
        /// </summary>
        public bool NewProfileNameIsEnabled()
        {
            bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_newProfileNameXPath), out IWebElement element);
            Settings.EnCompassExtentTest.Info("_newProfileName enable is" + found);
            return element.Enabled;
        }

        /// <summary>
        /// This method is used to set default checkbox inside the profiles dropdown option SaveAs
        /// </summary>
        public bool AsDefaultProfileCheckbox
        {
            get { return _setAsDefaultProfileCheckbox.Selected; }
            set
            {
                _setAsDefaultProfileCheckbox.SetCheckboxStateWithLabel(_setAsDefaultProfileCheckboxLabel, value);
                Settings.EnCompassExtentTest.Info("Set as default profile: " + value);
            }
        }

        /// <summary>
        /// This method is used to verify the existing profiles at the Profiles dropdown 
        /// </summary>
        public bool VerifyProfilesGridName(List<string> nameProfile, ExtentTest test)
        {
            clickGridToolbarProfilesButton();

            IList<IWebElement> profileNames = _gridToolbarProfilesNames;
            bool allNamesChecked = false;
            for (int n = 0; n < nameProfile.Count(); n++)
            {
                foreach (IWebElement p in profileNames)
                {
                    if (p.Text.Contains(nameProfile[n]))
                    {
                        allNamesChecked = true;
                        test.Info($"Profile Name {nameProfile[n]} found.");
                        break;
                    }
                }
            }

            clickGridToolbarProfilesButton();

            return allNamesChecked;
        }

        private List<string> GetAllProfileNames()
        {
            clickGridToolbarProfilesButton();
            IList<IWebElement> profileNames = _gridToolbarProfilesNames;
            if (profileNames == null)
                return null;

            List<string> names = new List<string>();
            foreach (var p in profileNames)
            {
                names.Add(p.Text.Replace(" (Default)", ""));
            }

            clickGridToolbarProfilesButton();
            return names;
        }

        /// <summary>
        /// This method is used to perform the hover action (click and hold) 
        /// </summary>
        public bool ClickAndHoldOption(string name, string option, ExtentTest test)
        {
            clickGridToolbarProfilesButton();

            string profileXPath = String.Format(_profilesNameXPath, name);
            ClickAndHold(profileXPath);

            profileXPath = profileXPath + _profileControlsXPath;
            Driver.TryWaitForElementsToBeVisible(By.XPath(profileXPath), out IList<IWebElement> profileControls);

            foreach (IWebElement c in profileControls)
            {
                if (c.Text.ToLowerInvariant().Equals(option.ToLowerInvariant()))
                {
                    c.JSClickWithFocus(Driver);
                    test.Info($"Clicked in {option} for {name} profile");
                    return true;
                }
            }

            test.Info($"{option} did not find for {name} profile");
            return false;
        }

        /// <summary>
        /// This method is used to perform Delete at the delete confirm modal for a existing profile
        /// </summary>
        public void ProfileDelete()
        {
            WaitForModalToAppear(_profileDeleteModalXPath);
            _deleteProfileName.JSClickWithFocus(Driver);
            WaitForModalToDisappear(_profileDeleteModalXPath);
            WaitForFormLoadingOverlay();
            Settings.EnCompassExtentTest.Info("Delete button clicked on modal");
        }

        /// <summary>
        /// This method is used to Delete all existing profiles 
        /// </summary>
        public void DeleteAllExistingProfiles(ExtentTest test)
        {
            List<string> profileNames = GetAllProfileNames();
            if (profileNames != null)
            {
                foreach (string p in profileNames)
                {
                    ClickAndHoldOption(p, "Delete", test);
                    WaitForModalToAppear(_profileDeleteModalXPath);
                    ProfileDelete();
                    WaitForModalToDisappear(_profileDeleteModalXPath);
                    WaitForFormLoadingOverlay();
                }
            }
        }

        /// <summary>
        /// This method is used to perform Cancel at the Set Default confirm modal for a existing profile
        /// </summary>
        public void CancelSetDefault()
        {
            WaitForModalToAppear(_profileSetDefaultModalXPath);
            _profileSetDefaultCancelButton.JSClickWithFocus(Driver);
            WaitForModalToDisappear(_profileSetDefaultModalXPath);
            Settings.EnCompassExtentTest.Info("Save as button clicked");
            WaitForFormLoadingOverlay();
        }

        /// <summary>
        /// This method is used to set default at Save As modal
        /// </summary>
        public void SetDefaultProfileOption(string name, ExtentTest test)
        {
            string xpath = String.Format(_rbSelectSetDefaultProfileXPath, name);
            Driver.TryWaitForElement(By.XPath(xpath), out IWebElement rbOption);
            xpath = String.Format(_rbSelectSetDefaultProfileLabelXPath, name);
            Driver.TryWaitForElement(By.XPath(xpath), out IWebElement label);

            rbOption.SetRadioButtonStateWithLabel(label, true);
            this.RefreshModel();
            test.Info($"The profile {name} selected.");
        }

        /// <summary>
        /// This method is used to perform Save at the Set Default confirm modal for a existing profile
        /// </summary>
        public void SaveSetDefault()
        {
            WaitForModalToAppear(_profileSetDefaultModalXPath);
            _profileSetDefaultSaveButton.JSClickWithFocus(Driver);
            WaitForModalToDisappear(_profileSetDefaultModalXPath);
            Settings.EnCompassExtentTest.Info("Cancel button clicked on modal");
            WaitForFormLoadingOverlay();
        }

        /// <summary>
        /// This method is used to perform Reset inside the profiles dropdown option Reset
        /// </summary>
        public void ProfileReset()
        {
            WaitForModalToAppear(_profileResetModalXPath);
            _profileReset.JSClickWithFocus(Driver);
            WaitForModalToDisappear(_profileResetModalXPath);
            Settings.EnCompassExtentTest.Info("Reset button clicked on modal");
            WaitForFormLoadingOverlay();
        }

        /// <summary>
        /// This method is used to perform Cancel inside the profiles dropdown option Reset
        /// </summary>
        public void ProfileResetCancel()
        {
            WaitForModalToAppear(_profileResetModalXPath);
            _profileResetCancel.JSClickWithFocus(Driver);
            WaitForModalToDisappear(_profileResetModalXPath);
            Settings.EnCompassExtentTest.Info("Cancel Reset button clicked on modal");
            WaitForFormLoadingOverlay();
        }

        /// <summary>
        /// This method is used to perform Cancel at the Rename confirm modal for a existing profile
        /// </summary>
        public void CancelRenameProfile()
        {
            WaitForModalToAppear(_profileRenameModalXPath);
            _profileRenameCancelButton.JSClickWithFocus(Driver);
            WaitForModalToDisappear(_profileRenameModalXPath);
            Settings.EnCompassExtentTest.Info("Profile Rename Save as button clicked");
            WaitForFormLoadingOverlay();
        }

        /// <summary>
        /// This method is usederror for Required Rename message
        /// </summary>
        public string RenameProfileName
        {
            get { return _newProfileName.GetAttribute("value"); }
            set
            {
                _renameProfileName.Clear();
                _renameProfileName.SendKeys(value);
                Settings.EnCompassExtentTest.Info("Rename profile name with value: " + value);
            }
        }

        /// <summary>
        /// This method is used to error for Required Rename message
        /// </summary>
        public string GetErrorRequiredRenameMessage
        {
            get
            {
                return _errorRequiredRenameMessage.Text;
            }
        }

        /// <summary>
        /// This method is used to perform Save at the Rename confirm modal for a existing profile
        /// </summary>
        public void SaveRenameProfile()
        {
            WaitForModalToAppear(_profileRenameModalXPath);
            _profileRenameSaveButton.JSClickWithFocus(Driver);
            WaitForModalToDisappear(_profileRenameModalXPath);
            Settings.EnCompassExtentTest.Info("Profile Rename Cancel button clicked on modal");
            WaitForFormLoadingOverlay();
        }

        /// <summary>
        /// This method is used to check and return if Overwrite Existing Profile checkbox is enabled
        /// </summary>
        public bool SetOverwriteExistingProfileCheckboxEnable()
        {
            bool found = Driver.TryWaitForElement(By.XPath(_setOverwriteExistingProfileCheckboxXPath), out IWebElement element);
            Settings.EnCompassExtentTest.Info("_setOverwriteExistingProfileCheckbox enable is" + found);
            return element.Enabled;
        }

        /// <summary>
        /// This method is used to perform Cancel at the delete confirm modal for a existing profile
        /// </summary>
        public void ProfileDeleteCancel()
        {
            WaitForModalToAppear(_profileDeleteModalXPath);
            _profileDeleteCancelButton.JSClickWithFocus(Driver);
            Settings.EnCompassExtentTest.Info("Cancel Delete button clicked on modal");
            WaitForModalToDisappear(_profileDeleteModalXPath);
            WaitForFormLoadingOverlay();
        }
        #endregion

        public MerchantLogHistory(GlobalSettings settings) : base(settings) { }

    }
}
