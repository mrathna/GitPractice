/*
 * 04-05-2018
 * Ayub khan 
 */
package com.framework.testcases.OLS.BP.Customer;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.BP.BPHomePage;
import com.framework.pages.OLS.common.LoginPage;

public class ValidateManageReissueRequestsPage extends BaseTest {
	@Parameters({"clientCountry","clientName"})
	@Test( groups = { "Smoke", "Regression" })
	public void ReissueRequestsPage(@Optional("AU") String clientCountry, @Optional("BP") String clientName)  {
		test = extent.createTest(clientName+ ":" +clientCountry+"  BP ManageReissueRequestsPage Validation", "Checking ManageReissueRequestsPage Feature");

		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		BPHomePage bpHomePage = new BPHomePage(driver, test);

		// Call Function
		loginPage.Login("BP_URL", "BP_UN_Customer_" + clientCountry, "BP_PWD_Customer_" + clientCountry, clientName);
		bpHomePage.ValidateBPCustomerLogo();
		// Validate ManageReissueRequestPage and Footer links 
		bpHomePage.manageReissueRequestsPage();
		bpHomePage.validateFooterLinksNavigation(clientCountry);
		
		loginPage.Logout();


	}

}
