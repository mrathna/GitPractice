package com.framework.pages.WES.Cruise;

import java.text.DateFormat;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;
import org.sikuli.script.Key;

import com.aventstack.extentreports.ExtentTest;
import com.framework.basepage.BasePage;
import com.framework.pages.WES.Cruise.CruiseHomePage;
import com.framework.repo.Locator_WES;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Properties;
import java.util.Set;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import com.framework.pages.WES.common.CommonPage;

import com.framework.util.Constants;
import com.framework.util.PropUtils;

public class CruiseCallSheetPage extends BasePage {

	@FindBy(xpath = Locator_WES.MAINTENANCE_CALLSHEET_LIST_CAMPAIGN)
	public WebElement maintenanceCallSheetListCampaign;

	@FindBy(xpath = Locator_WES.CAMPAIGN_CHECKBOX)
	public WebElement campaignCheckBox;

	@FindBy(xpath = Locator_WES.RECLAIM_PENDING_CALLS_LINK)
	public WebElement reclaimPendingCallsLink;

	@FindBy(xpath = Locator_WES.RECLAIM_BUTTON)
	public WebElement reclaimButton;

	@FindBy(xpath = Locator_WES.CAMPAIGN_FIRSTROW_CHECKBOX)
	public WebElement campaign_FirstRow_checkBox;

	@FindBy(xpath = Locator_WES.FIRSTROW_BUSINESSNAME)
	public WebElement firstRowBusinessName;

	@FindBy(xpath = Locator_WES.CALLSHEET_NAME_ROW)
	public WebElement callsheetName;

	@FindBy(xpath = Locator_WES.CALLSHEETNAME_FIRSTROW)
	public WebElement callsheetNameFirstRow;

	@FindBy(xpath = Locator_WES.RECLAIM_CHECKBOX)
	public WebElement reclaimCheckBox;

	@FindBy(xpath = Locator_WES.NO_RECORDS_CALLSHEET)
	public WebElement noRecords_callSheet;

	@FindBy(xpath = Locator_WES.ASSIGNCALLSRANDOMLY_LINK)
	public WebElement assignCallsRandomlyLink;

	@FindBy(xpath = Locator_WES.CALLPERUSER_TEXTBOX)
	public WebElement callsPerUserTextBox;

	@FindBy(xpath = Locator_WES.ASSIGN_BUTTON)
	public WebElement assign_btn;

	@FindBy(xpath = Locator_WES.CAMPAIGN_USER_TEXTBOX)
	public WebElement campaign_User_Textbox;

	@FindBy(xpath = Locator_WES.GET_RECLAIM_BUSINESS)
	public WebElement get_Reclaim_business;

	@FindBy(xpath = Locator_WES.CAMPAIGN_BUSINESSNAME_TEXTBOX)
	public WebElement campaignBusinesssname_Textbox;

	@FindBy(xpath = Locator_WES.GET_USER_FROM_FIRSTROW)
	public WebElement getUserFromFirstRow;

	@FindBy(xpath = Locator_WES.UNALLOCATED_CALLS)
	public WebElement unalloactedCalls;

	@FindBy(xpath = Locator_WES.CALLSHEET_CAMPAIGN_TEXTBOX)
	public WebElement callSheetCampaignTextBox;

	@FindBy(xpath = Locator_WES.CALLSHEET_CAMPAIGN_ROW)
	public WebElement callSheetCampaignFirstRow;

	@FindBy(xpath = Locator_WES.WEXSALESSUP_USER)
	public WebElement wexSalesSupUser;

	@FindBy(xpath = Locator_WES.MAINTENANCE_CALLSHEET_CREATE_CAMPAIGN)
	public WebElement maintenanceCallSheetCreateCampaign;

	@FindBy(xpath = Locator_WES.CAMPAIGN_NAME_TEXT)
	public WebElement campaignNameText;

	@FindBy(xpath = Locator_WES.CAMPAIGN_TYPE_DROPDOWN)
	public WebElement campaignTypedropDown;

	@FindBy(xpath = Locator_WES.CAMPAIGN_START_DATE)
	public WebElement campaignStartDate;

	@FindBy(xpath = Locator_WES.CAMPAIGN_END_DATE)
	public WebElement campaignEndDate;

	@FindBy(xpath = Locator_WES.CREATE_BUTTON)
	public WebElement createButton;

	@FindBy(xpath = Locator_WES.CREATE_CAMPAIGN_TEXT)
	public WebElement createCampaignText;

	@FindBy(xpath = Locator_WES.CUSTOMER_CAMPAIGN_LIST)
	public WebElement customerCampaignList;

	@FindBy(xpath = Locator_WES.MANAGE_CAMPAIGN_USERS)
	public WebElement manageCampaignUsers;

	@FindBy(xpath = Locator_WES.ASSIGN_USERS_TO_CAMPAIGN)
	public WebElement assignUsersToCampaign;

	@FindBy(xpath = Locator_WES.SELECT_USERS_CAMPAIGN)
	public WebElement selectUsersInCampaign;

	@FindBy(xpath = Locator_WES.SELECT_CURRENT_USERS)
	public WebElement selectCurrentUSers;

	@FindBy(xpath = Locator_WES.BACK_TO_CAMPAIGN)
	public WebElement backToCampaign;

	@FindBy(xpath = Locator_WES.CAMPAIGN_UPDATE_BUTTON)
	public WebElement campaignUpdateButton;

	@FindBy(xpath = Locator_WES.ASSIGN_SELECTED_CALLS)
	public WebElement assignSelectedCalls;

	@FindBy(xpath = Locator_WES.ASSIGN_SELECTED_CALLS_DROPDOWN)
	public WebElement assignSelectedCallsDropdown;

	@FindBy(xpath = Locator_WES.ASSIGN_SELECTED_SAVE_BUTTON)
	public WebElement assignSelectedSaveButton;

	@FindBy(xpath = Locator_WES.CAMPAIGN_SUMMARY_SROLL_RIGHT)
	public WebElement campaignSummarySrollRight;

	@FindBy(xpath = Locator_WES.CAMPAIGN_SUMMARY_USER)
	public WebElement campaignSummaryUser;

	@FindBy(xpath = Locator_WES.CREATE_FOLLOWUP_CAMPAIGN)
	public WebElement createFollowupCampaign;

	@FindBy(xpath = Locator_WES.FOLLOWUP_CAMPAIGN_START_DATE)
	public WebElement followupCampaignStartDate;

	@FindBy(xpath = Locator_WES.FOLLOWUP_CAMPAIGN_END_DATE)
	public WebElement followupCampaignEndDate;

	@FindBy(xpath = Locator_WES.CAMPAIGN_DROPDOWN)
	public WebElement campaignDropdown;

	@FindBy(xpath = Locator_WES.CHOOSE_FILE_BUTTON)
	public WebElement chooseFileButton;

	@FindBy(xpath = Locator_WES.CHECK_FILE_BUTTON)
	public WebElement checkFileButton;

	@FindBy(xpath = Locator_WES.IMPORT_BUTTON)
	public WebElement importButton;

	@FindBy(xpath = Locator_WES.IMPORT_SUCCESS_MSG)
	public WebElement importSuccessMsg;

	@FindBy(xpath = Locator_WES.OUTCOME)
	public WebElement outCome;

	@FindBy(xpath = Locator_WES.SAVE_NEXT_BUTTON)
	public WebElement saveNextButton;

	@FindBy(xpath = Locator_WES.CALL_NOTES)
	public WebElement callNote;

	@FindBy(xpath = Locator_WES.PLACE_CALL_CAMPAIGN_NAME)
	public WebElement placeCampaighName;

	@FindBy(xpath = Locator_WES.ASSIGN_SELECTED_CALLS_POPUP)
	public WebElement assignSelectedCallsPopup;
	
	@FindBy(xpath = Locator_WES.CALLSHEETIMPORT_DROPDOWN)
	public WebElement callSheetImportDropDown ;
	@FindBy(xpath = Locator_WES.CALLSHEETIMPORT_DROPDOWN_TEXTBOX)
	public WebElement callSheetImportDropDownTextbox;

	ArrayList<String> expValues;
	ArrayList<String> actualValues;

	public CruiseCallSheetPage(WebDriver driver, ExtentTest test) {
		super(driver, test);
		PageFactory.initElements(new AjaxElementLocatorFactory(driver, 15), this);
	}

//Sowmiya	

	public String getCampaignNameandValidate(String campaignType) {

		String campaignName = "";
		CruiseHomePage homePage = new CruiseHomePage(driver, test);
		verifyText(wexSalesSupUser, "WexSales Sup");
		homePage.goToMaintenanceAndCallsheet("Create Campaign");
		if (campaignType.equals("SALES")) {
			campaignName = "Sales_" + fakerAPI().name().fullName();
		} else if (campaignType.equals("ADHOC")) {
			campaignName = "Adhoc_" + fakerAPI().name().fullName();
		} else {
			campaignName = "customer_" + fakerAPI().name().fullName();
		}

		System.out.println("Campaign Name is " + campaignName);
		verifyTitle("Create Campaign");
		isDisplayedThenEnterText(campaignNameText, "Campaign Name text box", campaignName);

		isDisplayedThenEnterText(campaignTypedropDown, "Campaign Type value", campaignType);

		String currentDate = getCurrentDate();
		System.out.println("Current Date is " + currentDate);
		isDisplayedThenEnterText(campaignStartDate, "Start Date", currentDate);

		String futureDate = getFutureDate(11);
		System.out.println("Future date is " + futureDate);
		isDisplayedThenEnterText(campaignEndDate, "end Date", futureDate);

		isDisplayedThenClick(createCampaignText, "Create Campaign Header");

		isDisplayedThenActionClick(createButton, "Create Button");
		boolean  errorPageOccured = waitToCheckElementIsDisplayed(By.xpath("//div//font[contains(text(),'An Error has occurred')]"),10);
		System.out.println("Error Page occured in customer maintenance "+errorPageOccured);
		if(errorPageOccured) {
			driver.navigate().back();
			homePage.goToMaintenanceAndCallsheet("List Campaigns");
			verifyTitle("Campaign List");
			isDisplayedThenEnterText(customerCampaignList, "Name", campaignName);
			WebElement customerMaintenanceName = driver.findElement(By.xpath("//table[@id='campaignList']//tbody//td[contains(text(),'" + campaignName + "')]"));
			isDisplayed(customerMaintenanceName,"Customer Maintenance Name is Listed in List campaign");
		}
		else {
		verifyTitle("Campaign Summary");
		WebElement headerElement = driver.findElement(By.xpath("//span[contains(text(),'" + campaignName + "')]"));
		System.out.println(headerElement);
		verifyText(headerElement, campaignName);
		
		}
		return campaignName;

	}

	public void validateManageCamapaignUser() {
		scrollDownPage();
		boolean tablePresence = waitToCheckElementIsDisplayed(By.xpath(
				"//div[@class='ui-jqgrid-bdiv']//table[@class='ui-jqgrid-btable']//tr[@class='ui-widget-content jqgrow ui-row-ltr'][1]"),
				10);
		System.out.println("tablePresence : " + tablePresence);
		if (tablePresence) {

			isDisplayedThenClick(campaign_FirstRow_checkBox, "Select Check box in Manage Campaign User");

			isDisplayedThenClick(manageCampaignUsers, "Manage Campaign Users");
			waitForPageLoad(10);
			verifyTitle("Campaign Users");
			isDisplayedThenClick(selectCurrentUSers, "Select Current User WesSales Up check box");
			isDisplayedThenActionClick(campaignUpdateButton, "Assign users to campaign update button");
			sleep(2);
			isDisplayedThenClick(backToCampaign, "Back to campaign");
			waitForPageLoad(5);

			verifyTitle("Campaign Summary");
			scrollDownPage();

		} else {
			logFail("Expected table is not present");
		}

	}

	public void validateAssignSelectedCalls(String campaignName, String userName) {
		CruiseHomePage homePage = new CruiseHomePage(driver, test);
		scrollDownPage();
		// Assign Selected Calls
		boolean tablePresence = waitToCheckElementIsDisplayed(By.xpath(
				"//div[@class='ui-jqgrid-bdiv']//table[@class='ui-jqgrid-btable']//tr[@class='ui-widget-content jqgrow ui-row-ltr'][1]"),
				10);
		System.out.println("tablePresence : " + tablePresence);
		if (tablePresence) {
			isDisplayedThenClick(campaign_FirstRow_checkBox, "Selct Check box in  Campaign User");
			isDisplayedThenClick(assignSelectedCalls, "Assign Selected Calls");
			// isDisplayed(assignSelectedCallsPopup,"Assign Selected Calls Popup");

			// waitUntilElementDisplayed(assignSelectedCallsPopup);
			sleep(2);
			selectDropDownByVisibleText(assignSelectedCallsDropdown, userName);
			isDisplayedThenActionClick(assignSelectedSaveButton, "Assign Selected Calls Popup save button");
			
			isDisplayedThenEnterText(campaignSummaryUser, "WexSales Sup text box", userName);
			String businessName = firstRowBusinessName.getText();
			System.out.println("Business name is " + businessName);
			homePage.gotoCallSheetTable();
			isDisplayedThenEnterText(callsheetName, businessName + "Name Row", businessName);
			isDisplayedThenEnterText(callSheetCampaignTextBox, "Campaign TextBox", campaignName);
			String actualBusinessName = callsheetNameFirstRow.getText();
			System.out.println("Actual business name in home page " + actualBusinessName);
			String actualCampaign = callSheetCampaignFirstRow.getText();
			System.out.println("Actual Camapign in home page " + actualCampaign);

			if (businessName.equals(actualBusinessName) && campaignName.equals(actualCampaign)) {

				logPass(actualBusinessName + " and " + actualCampaign + " Assigned Selected Call is Updated");
			} else {
				logFail(actualBusinessName + " and " + actualCampaign + " Assigned Selected Call is Not Updated");
			}

		} else {
			logFail("Expected table is not present");
		}
	}

	/*
	 * Prakalpha choose checkbox calls for Assigned User
	 */
	public String getBusinessNameInCampaignSummary(String AssignedUserName) {
		verifyTitle("Campaign Summary");
		scrollDownPage();
		// Click(campaignCheckBox," campaign CheckBox");
		scrollRightPage();
		isDisplayedThenEnterText(campaign_User_Textbox, AssignedUserName + " Assigned User", AssignedUserName);

		isDisplayedThenClick(campaign_FirstRow_checkBox, "Campaign FirstRow CheckBox");
		String businessname = firstRowBusinessName.getText();
		System.out.println("Business Name::" + businessname);
		return businessname;
	}

	/*
	 * prakalpha-->07/26/2019 Choose calls to reclaim and validate Call has
	 * reclaimed
	 */
	public void validateReclaimPendingCalls(String businessName) {
		CruiseHomePage homePage = new CruiseHomePage(driver, test);
		Click(reclaimPendingCallsLink, "Reclaim Pending calls Link");
		verifyTitle("Reclaim pending calls");
		String actualtext = get_Reclaim_business.getText();
		if (actualtext.equalsIgnoreCase(businessName)) {
			logPass("Actual Text:: " + actualtext + " and ExpectedText:: " + businessName + " are equals");
			isDisplayedThenClick(campaign_FirstRow_checkBox, "Campaign FirstRow CheckBox");
			Click(reclaimButton, "Reclaim Button");
			// Click(reclaimCheckBox,"Reclaim CheckBox");
			verifyTitle("Campaign Summary");
			isDisplayedThenEnterText(campaignBusinesssname_Textbox, businessName + " Businessname TextBox",
					businessName);
			scrollRightPage();
			String userName = getUserFromFirstRow.getText();
			if (userName.equals(" ")) {
				logPass("User was reclaimed the calls");
			} else {
				logFail("User wasn't reclaimed the calls");
			}

			homePage.gotoCallSheetTable();
			isDisplayedThenEnterText(callsheetName, businessName + "Name Row", businessName);
			sleep(2);
			isDisplayed(noRecords_callSheet, "No Records to View");

		} else {
			logFail("Actual Text:: " + actualtext + " and ExpectedText:: " + businessName + " are not equals");
		}

	}

	// Prakalpha-->Validate Assign Random Calls for Created Campaign
	public void validateAssignCallsRandomly(int unallocatedCalls, String userName, String campaignName) {
		CruiseHomePage homePage = new CruiseHomePage(driver, test);
		Click(assignCallsRandomlyLink, "Assign Calls Randomly Link");
		waitForPageLoad(10);
		String text = unalloactedCalls.getText();
		System.out.println(text);
		if (unalloactedCalls.getText().equals(Integer.toString(unallocatedCalls))) {
			verifyTitle("Assign Calls");
			isDisplayedThenEnterText(callsPerUserTextBox, "Calls Per User TextBox", "1");
			sleep(2);
			Click(assign_btn, "Standardised Assign button");

			waitForPageLoad(5);
			verifyTitle("Campaign Summary");
			String businessName = getBusinessNameInCampaignSummary(userName);
			System.out.println(businessName);
			scrollUpPage();
			homePage.gotoCallSheetTable();
			isDisplayedThenEnterText(callsheetName, businessName + "Name Row", businessName);
			sleep(2);
			isDisplayedThenEnterText(callSheetCampaignTextBox, "Campaign TextBox", campaignName);
			sleep(2);
			boolean tablePresence = waitToCheckElementIsDisplayed(
					By.xpath("//table[@id='callsheetCallsGrid']/tbody/tr[2]"), 10);
			System.out.println("tablePresence : " + tablePresence);
			if (tablePresence) {
				String actualBusinessName = callsheetNameFirstRow.getText();
				String actualCampaign = callSheetCampaignFirstRow.getText();

				if (businessName.equals(actualBusinessName) && campaignName.equals(actualCampaign)) {

					logPass(actualBusinessName + " and " + actualCampaign + " Assigned Random Calls Updated");
				} else {
					logFail(actualBusinessName + " and " + actualCampaign + " Assigned Random Calls Not Updated");
				}

			}

		}

	}

	// Prakalpha-->Get Unallocated calls from Campaign table
	public int getUnallocatedCalls() {
		int count = 0;
		sleep(5);
		List<WebElement> campaignUserRow = driver.findElements(By.xpath("//table[@id='campaignLeadsGrid']/tbody/tr"));
		int rowSize = campaignUserRow.size();
		System.out.println("RowSize::" + rowSize);
		for (int i = 2; i <= rowSize; i++) {
			WebElement user = driver
					.findElement(By.xpath("//table[@id='campaignLeadsGrid']/tbody/tr[" + i + "]//td[13]"));
			if (user.getText().equals(" ")) {
				count = count + 1;

			}
			System.out.println("Count::" + count);
		}
		return count;
	}

	// Raxsana
	public void createAndValidateFollowupCampaign(String customerCampaignName) {
		try {
			validateListCampaign(customerCampaignName);
			verifyText(
					driver.findElement(By.xpath(
							"//div[@class='formSectionInner']//div/span[text()='" + customerCampaignName + "']")),
					customerCampaignName);
			isDisplayedThenClick(createFollowupCampaign, "Create Followup Campaign");
			verifyText(driver.findElement(By.xpath("//div[@class='formSectionInner']//div/h3")),
					"Create Follow-up Campaign");
			String text = driver.findElement(By.id("name")).getAttribute("value");
			String startDate = getCurrentDate();

			Date dateFormat = null;
			String dateStartFormatted = "";
			String dateEndFormatted = "";

			DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
			dateFormat = df.parse(startDate);
			dateStartFormatted = getDateInFormat(dateFormat, "yyyy-MM-dd");
			System.out.println("Start date " + dateStartFormatted);

			String endDate = getFutureDate(10);
			dateFormat = df.parse(endDate);
			// System.out.println("Date Format" + dateFormat);
			dateEndFormatted = getDateInFormat(dateFormat, "yyyy-MM-dd");
			System.out.println("End date " + dateEndFormatted);

			enterText(followupCampaignStartDate, dateStartFormatted);
			enterText(followupCampaignEndDate, dateEndFormatted);
			Click(driver.findElement(By.xpath("//div[@class='formSectionInner']//div/h3")),
					"Create Follow-up Campaign");
			sleep(5);
			isDisplayedThenActionClick(createButton, "Create Button");
			waitForPageLoad(10);
			verifyText(
					driver.findElement(By.xpath("//div[@class='formSectionInner']//div/span[text()='" + text + "']")),
					text);
			validateListCampaign(text);
		} catch (Exception e) {
			e.getMessage();
		}
	}

	public ArrayList<String> getValuesFromTableList(String tableHeaderName) {
		int index = 1;
		ArrayList<String> valuesFromTableList = new ArrayList<String>();
		List<WebElement> headerNamesFromTableList = new ArrayList<WebElement>();
		headerNamesFromTableList = driver.findElements(By.xpath("//tr[@class='ui-jqgrid-labels']//th/div"));
		for (WebElement element : headerNamesFromTableList) {
			String valueFromHeader = element.getText();
			if (!(valueFromHeader.equals(tableHeaderName))) {
				index++;
			} else {
				break;
			}
		}
		List<WebElement> elements = driver.findElements(By.xpath(
				"//div[@class='ui-jqgrid-bdiv']//tr[@class='ui-widget-content jqgrow ui-row-ltr']//td[" + index + "]"));
		for (WebElement element : elements) {
			valuesFromTableList.add(element.getText());
		}

		return valuesFromTableList;

	}

	public void viewCustomerImports(String expectedString) {

		CruiseHomePage homePage = new CruiseHomePage(driver, test);
		homePage.goToMaintenanceAndCallsheet("View imports");
		WebElement firstRowElement = driver
				.findElement(By.xpath("//div[@class='ui-jqgrid-bdiv']//table[@id='batchStatusList']//tr[2]"));
		driver.manage().timeouts().implicitlyWait(3, TimeUnit.MINUTES);
		waitUntilElementDisplayed(firstRowElement);
		String textFromRow = firstRowElement.getText();
		isDisplayedThenDoubleClick(firstRowElement, "First Row");
		waitForPageLoad(10);
		verifyTitle("Campaign Summary");
		verifyText(driver.findElement(By.xpath("//span[text()='" + textFromRow + "']")), textFromRow);

	}

	// Sasi
	public void copyAndUpdateExcelFile() {
		String inputTemplatefileName = PropUtils.getPropValue(configProp, "Cruise_Callsheet");
		System.out.println("inputTemplatefileName : " + inputTemplatefileName);
		try {
			getLocalCopyOfExcelFile(inputTemplatefileName, "xls");
			System.out.println("copied");
			validateAndUpdateTheExcelSheet(inputTemplatefileName, 3, 3);
			System.out.println("updating done");
		} catch (Exception e) {
			logInfo("File not found");
		}

	}

	public void goToCallsheetImport(String campaignName) {
		CruiseHomePage homePage = new CruiseHomePage(driver, test);
		homePage.goToMaintenanceAndCallsheet("Callsheet Import");
	//	sleep(5);
		isDisplayedThenClick(callSheetImportDropDown,"Call sheet Import DropDown");
		isDisplayedThenEnterText(callSheetImportDropDownTextbox,"Call Sheet Import Text Box",campaignName);
		Actions act = new Actions(driver);
		act.sendKeys(Key.ENTER).build().perform();
		
	//	selectDropDownByVisibleText(campaignDropdown, campaignName);
		sleep(2);
		isDisplayedThenActionClick(chooseFileButton, "Clicking choose file button");

	}

	public void uploadingCallSheet() {
		CommonPage common = new CommonPage(driver, test);
		String fileName = PropUtils.getPropValue(configProp, "Cruise_Callsheet");
		System.out.println("fileName : " + fileName);
		try {
			common.uploadOrSaveLatestCruiseFile(fileName);
			System.out.println("uploading done");

			isDisplayedThenActionClick(checkFileButton, "clicking check button");
			sleep(5);
			isDisplayedThenActionClick(importButton, "importButton ");
			isDisplayed(importSuccessMsg, "Succesfully imported");
			System.out.println("Completed");

		} catch (Exception e) {
			logInfo("File not found");
		}
		sleep(5);
	}

	public void validatingValuesFromExcelSheet(String actual, String expected) {
		String fileName = PropUtils.getPropValue(configProp, "Cruise_Callsheet");
		System.out.println("fileName : " + fileName);
		try {
			actualValues = getValuesFromTableList(actual);
			expValues = readingExcelFile(fileName, "xls", 3, expected);
			if (actualValues.containsAll(expValues)) {
				logPass("Actual and Expected are same");
			} else
				logFail("Actual and Expected are different");
			/*
			 * System.out.println(expValues+"/n"+actualValues);
			 * System.out.println(expValues);
			 */
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	/* This method makes a copy of excel file to local */
	public void getLocalCopyOfExcelFile(String inputTemplateFileName, String fileformat) throws IOException {
		Workbook workbook = null;
		String inputFileTemplateCopy = Constants.INPUTFILE_DIR + inputTemplateFileName;
		System.out.println(" Input Template File is " + inputFileTemplateCopy);
		// Local Directory
		outgoingFileName = System.getProperty("user.home") + "\\Downloads\\" + inputTemplateFileName;
		System.out.println("Created outgoing fileName is" + outgoingFileName);

		FileInputStream excelFile = new FileInputStream(new File(inputFileTemplateCopy));

		FileOutputStream outputStream = new FileOutputStream(outgoingFileName);

		if (fileformat.equalsIgnoreCase("xls")) {
			workbook = new HSSFWorkbook(excelFile);
		} else if (fileformat.equalsIgnoreCase("xlsx")) {
			workbook = new XSSFWorkbook(excelFile);
		}
		workbook.write(outputStream);
		workbook.close();
	}

	/* This method reads the content of Excel file in local */
	public ArrayList<String> readingExcelFile(String filename, String fileformat, int rowHeader, String headerName)
			throws IOException {
		Workbook workbook = null;
		Sheet sheet = null;
		int rowData = rowHeader + 1;
		int noOfColumns, noOfSheets;
		ArrayList<String> columnHeader = new ArrayList<String>();
		ArrayList<String> columnData = new ArrayList<String>();
		System.out.println("inside");
		// To get latest file
		String downloadedFileName = getLatestDownloadedFileFromDir(filename).getName();
		System.out.println("downloadedFileName : " + downloadedFileName);
		// Local Directory
		String sourceFile = System.getProperty("user.home") + "\\Downloads\\" + downloadedFileName;
		System.out.println("Created outgoing fileName is" + sourceFile);

		FileInputStream excelFile = new FileInputStream(new File(sourceFile));

		if (fileformat.equalsIgnoreCase("xls")) {
			workbook = new HSSFWorkbook(excelFile);
		} else if (fileformat.equalsIgnoreCase("xlsx")) {
			workbook = new XSSFWorkbook(excelFile);
		}

		noOfSheets = workbook.getNumberOfSheets();
		System.out.println("noOfSheets : " + noOfSheets);

		sheet = workbook.getSheet("Sheet1");

		noOfColumns = sheet.getRow(rowHeader).getLastCellNum();
		// System.out.println("noOfColumns : "+noOfColumns);


		for (int i = 0; i < noOfColumns; i++) {
			columnHeader.add(sheet.getRow(rowHeader).getCell(i).getStringCellValue().replaceAll(" ", ""));
			if ((columnHeader.get(i)).equals(headerName)) {

				System.out.println("Gona : " + i + " " + rowData);
				for (int j = rowData; j < rowData + 3; j++) {
					System.out.println("j : " + j);
					columnData.add(sheet.getRow(j).getCell(i).getStringCellValue());
//					if ((columnData.get(i)).isEmpty()) {
//break;
//					}
				}
			}
//			k++;
		}
		workbook.close();
		return columnData;
	}

	public HashMap<String, String> validateAndUpdateTheExcelSheet(String fileName, int headerRowNum, int bulkCount) {

		HSSFSheet workSheet = null;
		HSSFRow row = null;
		HSSFWorkbook workBook = null;
		HSSFCell cell = null;
		int rowCount1 = headerRowNum + 1;
		HashMap<String, String> keysAndValues = new HashMap<String, String>();
		sleep(5);
		String downloadedFileName = getLatestDownloadedFileFromDir(fileName).getName();
		String downloadedFilePath = System.getProperty("user.home") + "\\Downloads\\" + downloadedFileName;
		System.out.println("Latest downloaded file" + downloadedFilePath);
		System.out.println("Keys and values---->" + keysAndValues);
		try {
			FileInputStream inputStream = new FileInputStream(new File(downloadedFilePath));
			workBook = new HSSFWorkbook(inputStream);
			workSheet = workBook.getSheet("Sheet1");
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {

			int noOfColumns = workSheet.getRow(headerRowNum).getLastCellNum();
			System.out.println("Number of columns is  " + noOfColumns);
			String[] columnHeaders = new String[noOfColumns];
			for (int j = 0; j < noOfColumns; j++) {
				columnHeaders[j] = workSheet.getRow(headerRowNum).getCell(j).getStringCellValue().replace(" ", "");
				System.out.println("Column headers " + columnHeaders[j]);
			}

			for (int b = 0; b < bulkCount; b++) {
				keysAndValues = readKeyAndValueFromPropertyFile(callSheetExcelInput, configProp);
				System.out.println("Keys and values---->" + keysAndValues);
				row = workSheet.getRow(rowCount1);
				// row = workSheet.createRow(rowCount1);
				for (int a = 0; a < noOfColumns; a++) {
					System.out.println("headers name-->" + columnHeaders[a]);
					if (columnHeaders[a].equals("CompanyName")) {
						for (String entry : keysAndValues.keySet()) {
							System.out.println("entry name-->" + entry);
							if (entry.equals("CompanyName")) {
								cell = row.getCell(a);
								// cell=row.createCell(a);
								cell.setCellValue(keysAndValues.get(entry));
							}
						}
					}
				}

				rowCount1 = rowCount1 + 1;
				System.out.println("outside" + rowCount1);
				FileOutputStream outputStream = new FileOutputStream(downloadedFilePath);
				workBook.write(outputStream);
				outputStream.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return keysAndValues;

	}

	public HashMap<String, String> readKeyAndValueFromPropertyFile(Properties excelInputValuesConfigProp,
			Properties configProp) {
		HashMap<String, String> map = new HashMap<String, String>();
		Set<Object> keys = excelInputValuesConfigProp.keySet();	
		for (Object k : keys) {
			String key = String.valueOf(k);
			String value = PropUtils.getPropValue(excelInputValuesConfigProp, key);
			if (value.equals("getFakerName")) {
				try {
					value = fakerAPI().name().firstName();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}

			map.put(key, value);

		}
		return map;

	}

	// Ayub
	public void selectCallsFromCallSheetandValidateApplication(String businessName, String campaignName) {
		System.out.println("Campaign Name is " + campaignName);
		isDisplayedThenEnterText(callsheetName, businessName + "Name Row", businessName);
		isDisplayedThenEnterText(callSheetCampaignTextBox, "Campaign TextBox", campaignName);
		boolean tablePresence = waitToCheckElementIsDisplayed(By.xpath("//table[@id='callsheetCallsGrid']/tbody/tr[2]"),
				10);
		System.out.println("tablePresence : " + tablePresence);
		if (tablePresence) {
			String actualBusinessName = callsheetNameFirstRow.getText();
			System.out.println("Actual Business name" + actualBusinessName);
			String actualCampaign = callSheetCampaignFirstRow.getText();

			if (businessName.equals(actualBusinessName) && campaignName.equals(actualCampaign)) {
				Click(callSheetCampaignFirstRow, "1st row is Clicked");
				logPass(actualBusinessName + " and " + actualCampaign + "  expected Customer is clicked");
			} else {
				logFail(actualBusinessName + " and " + actualCampaign + "  expected Customer is not clicked");
			}
		} else {
			logFail("Expected table is not present");
		}
		String handle = driver.getWindowHandle();
		driver.switchTo().window(handle);
		isDisplayedThenEnterText(callNote, "call Note", "HI");
		selectDropDownByVisibleText(outCome, "App Entered");
		String placeCamName = getText(placeCampaighName);
		if (campaignName.equals(placeCamName)) {
			logPass(placeCamName + " expected campaign Name is present");
		} else {
			logFail(placeCamName + " expected campaign Name is not present");
		}

	}

	public void downloadExcelCampaigns(String customerCampaignName, String fileName) {
		ArrayList<String> expectedValues;
		ArrayList<String> actualValues = new ArrayList<String>();
		String line = "";
		BufferedReader br;
		validateListCampaign(customerCampaignName);
		expectedValues = getValuesFromTableList("Business Name");
		String downloadedFileName = getLatestDownloadedFileFromDir(fileName).getName();
		String sourceFile = System.getProperty("user.home") + "\\Downloads\\" + downloadedFileName;
		try {
			br = new BufferedReader(new FileReader(sourceFile));
			while ((line = br.readLine()) != null) {
				String[] actual = line.split(",");
				List<String> newList = Arrays.asList(actual);
				actualValues.addAll(newList);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		if (actualValues.containsAll(expectedValues)) {
			logPass("Actual and Expected are same");
		} else
			logFail("Actual and Expected are different");
	}

	private String refId = "0";

	public void validateListCampaign(String customerCampaignName) {
		CruiseHomePage homePage = new CruiseHomePage(driver, test);
		String campaignList = "";
		homePage.goToMaintenanceAndCallsheet("List Campaigns");
		verifyTitle("Campaign List");
		isDisplayedThenEnterText(customerCampaignList, "Name", customerCampaignName);

		try {
			WebElement customerListName = driver.findElement(
					By.xpath("//table[@id='campaignList']//tbody//td[text()='" + customerCampaignName + "']"));
			System.out.println(customerListName);
			campaignList = customerListName.getText();
			System.out.println("Listed Customer Name is " + campaignList);
			String methodName = Thread.currentThread().getStackTrace()[2].getMethodName();
			if (campaignList.equals(customerCampaignName)) {
				if (methodName.contains("downloadExcelCampaigns")) {
					refId = driver.findElement(By.xpath("//table[@id='campaignList']//tbody//tr//td[text()='" + customerCampaignName + "']/preceding::tr[1]/following::tr[1]")).getAttribute("id");
					if (!(refId.equals("0"))) {
						Click(driver.findElement(By.xpath("//table[@id='campaignList']//tbody//tr//td[text()='" + customerCampaignName + "']/preceding::tr[1]/following::tr[1]//a")), "Download refId");
					}
				}
				isDisplayedThenDoubleClick(customerListName, "Customer List Name");
				logPass("Expected Customer Campaign Listed is Displayed");
			} else {
				logFail("Expected Customer Campaign Listed is not Displayed");
			}

		} catch (Exception ex) {
			logFail(ex.getMessage());
		}

	}

}
