package com.framework.testcases.AJS.EMAP.Interface;

import java.util.ArrayList;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.MaintainCustomerPage;
import com.framework.pages.AJS.common.Common;
import com.framework.pages.AJS.common.IFCSCommonPage;
import com.framework.pages.AJS.common.IFCSHomePage;
import com.framework.pages.AJS.common.IFCSLoginPage;
import com.framework.pages.AJS.common.InterfacePage;

public class ValidateInterfaceLoadCardTransactionFlatFile extends BaseTest{
	
	@Parameters({ "clientCountry", "clientName" })	
	@Test(groups = { "Smoke" })	
	public void validateLoadCardTransactionFlatFromIE(@Optional("SG") String clientCountry, @Optional("EMAP") String clientName)   {
		test = extent.createTest(clientName+ ":" +clientCountry+"  TST-SC-09-Verify the card status changes from No Transactions to Active upon a successful transaction", "Load card transaction EMAP");
	
        InterfacePage interfacePage = new InterfacePage(driver,test);
        IFCSLoginPage ifcsloginPage = new IFCSLoginPage(driver, test);
	    IFCSCommonPage ifcsCommonPage = new IFCSCommonPage(driver, test);
		IFCSHomePage ifcsHomePage = new IFCSHomePage(driver, test);	
		MaintainCustomerPage maintaincustomerPage = new MaintainCustomerPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		Common common = new Common(driver, test);
		ArrayList<String> refNumberUpdated = new ArrayList<String>();

		ifcsloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, " ");

		// String cardNumber = common.getCardsWithStatusAndWithBalance("No
		// Transactions");
		String cardNumber = common.getCardsBasedOnProductRestriction("No Transactions");

		if (cardNumber.equals("")) {
			common.logForNoDataFound(this.getClass().getSimpleName(),
					"Need to Create cards with NoTransaction status with balance and rerun");
		} else {
			if (clientCountry.equals("SG"))
				refNumberUpdated = interfacePage.updateOrValidateFlatFile(emapLoadcardflatconfigPropOnlySG,
						"OutgoingFile", "IE_INPUTFILE_FOLDER_LOADCARDTRANSACTIONS", cardNumber, clientName,
						clientCountry, "FLTRAN_SG_20190528.txt");
			
			else if (clientCountry.equals("GU") || clientCountry.equals("SP"))
				refNumberUpdated = interfacePage.updateOrValidateFlatFile(emapLoadcardflatconfigPropAllClients,
						"OutgoingFile", "IE_INPUTFILE_FOLDER_LOADCARDTRANSACTIONS", cardNumber, clientName,
						clientCountry, "FLTRAN_GU_SP_20190618.txt");
			
			else if (clientCountry.equals("HK") || clientCountry.equals("MO"))
				refNumberUpdated = interfacePage.updateOrValidateFlatFile(emapLoadcardflatconfigPropAllClients,
						"OutgoingFile", "IE_INPUTFILE_FOLDER_LOADCARDTRANSACTIONS", cardNumber, clientName,
						clientCountry, "FLTRAN_HK_MO_20190619.txt");
			
			System.out.println("refNumberUpdated : " + refNumberUpdated);

			if (!refNumberUpdated.contains("")) {
				String folderName = ifcsCommonPage.getControlMFolder(clientName, clientCountry, "jobS_emap_TransProc");

				String jobsInOrder = ifcsCommonPage.getJobsOfFolderInOrder("jobS_emap_TransProc");

				interfacePage.establishAndExecuteControlMJobs("ControlM_AWS_UAT", "ContorlM_AWS_userName",
						"ContorlM_AWS_password", folderName, jobsInOrder);

				// Calling Functions
				ifcsloginPage.login("IFCS_URL_EMAP", "IFCS_EMAP_USERNAME", "IFCS_EMAP_PASSWORD");

				ifcsHomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);

				ifcsHomePage.gotoTansactionsAndClickManageTransaction();

				ifcsHomePage.chooseSubMenuFromLeftPanel("Client Transactions", "Transactions");

				for (int i = refNumberUpdated.size()-1; i >= 0; i--) {

					ifcsHomePage.enterValueInTextBox("Transaction Filter Fields", "Reference No",
							refNumberUpdated.get(i));

					common.searchListTorch();

					common.validateSearchTable("Ref", refNumberUpdated.get(i), true);
				}

				IFCSHomePage.gotoCustomerMenuCustomerDetails();

				common.chooseSubMenuFromLeftPanel("Card Details", "Card Maintenance");

				common.chooseCardNoAndSearch(cardNumber);

				maintaincustomerPage.validateNewCardStatus(cardNumber);

				String cardStatus = maintaincustomerPage.getStatusforCard("Card List", "Status");

				System.out.println("After Transaction Cards Status:" + cardStatus);

				common.validateSearchTable("Status", "Active", true);

				common.chooseSubMenuFromLeftPanel("Card Maintenance", "Card Status");

				common.validateSearchTable("Status", "Active", true);

			}
		
			else {
				System.out.println("Interface is not updated correctly");
			}

		}
		
	 
		}
		
		
	}
	


