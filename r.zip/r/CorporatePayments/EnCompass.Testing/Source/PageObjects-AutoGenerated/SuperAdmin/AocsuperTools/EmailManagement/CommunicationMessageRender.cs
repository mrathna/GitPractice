using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using Common;
using Common.PageObjects;
using Common.ScenarioConfigurations;
using Common.Utility;

namespace EnCompass.Testing.Source.PageObjects.SuperAdmin.AocsuperTools.EmailManagement 
{
	/// <summary>
	/// Auto-generated Page Model Class
	/// Navigation Paths: 
		/// [Organization Home]->Super Admin Tools->Messages->Render Message
		/// </summary>
	[PageModel(@"/superAdmin/AOCSuperTools/EmailManagement/CommunicationMessageRender.aspx")]
	public partial class CommunicationMessageRender : EnCompassSuperPageModel 
	{
		public override string RelativeUrl => @"/superAdmin/AOCSuperTools/EmailManagement/CommunicationMessageRender.aspx";
		public override string PageIdentifierXPath_Generated => @"//li[contains(@class, 'breadcrumb-item active')][text() = 'Render Message']";

		#region Navigation
				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Search']")]
		private IWebElement _superAdminTools_Messages_RenderMessage_Search { get; set; }
		public void NavigateTo_SuperAdminTools_Messages_RenderMessage_Search()
		{
			NavigateToMenuItem(_superAdminTools_Messages_RenderMessage_Search);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Render Message']")]
		private IWebElement _superAdminTools_Messages_RenderMessage_RenderMessage { get; set; }
		public void NavigateTo_SuperAdminTools_Messages_RenderMessage_RenderMessage()
		{
			NavigateToMenuItem(_superAdminTools_Messages_RenderMessage_RenderMessage);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Test by Template']")]
		private IWebElement _superAdminTools_Messages_RenderMessage_TestByTemplate { get; set; }
		public void NavigateTo_SuperAdminTools_Messages_RenderMessage_TestByTemplate()
		{
			NavigateToMenuItem(_superAdminTools_Messages_RenderMessage_TestByTemplate);
		}

		
		private void NavigateToMenuItem(IWebElement element)
		{
			Driver.Url = element.GetAttribute("href");
		}
		#endregion

		public CommunicationMessageRender(GlobalSettings settings) : base(settings) { }
	}  
}
