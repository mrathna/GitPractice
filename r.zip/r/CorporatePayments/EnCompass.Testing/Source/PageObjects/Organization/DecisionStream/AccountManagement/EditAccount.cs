﻿using AventStack.ExtentReports;
using Common;
using Common.Utility;
using EnCompass.Testing.Source.PageObjects.Controls;
using NFluent;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace EnCompass.Testing.Source.PageObjects.Organization.DecisionStream.AccountManagement
{
	[PageModel(@"/decisionStream/accountManagement/EditAccount.aspx")]
	class EditAccount : EnCompassOrgPageModel, IMobilePhone
	{
        #region xpath

        public override string RelativeUrl => @"/decisionStream/accountManagement/EditAccount.aspx";
		public override string PageIdentifierXPath_Override => @"//h1[contains(text(),'Edit Card')]";

        private const string _lblHeirarchyLevel = "//label[@class='custom-control-label']//span[contains(text(),'TestHierarchy')]";

        private const string _cbHeirarchyLevel = "//label[@class='custom-control-label']//span[contains(text(),'TestHierarchy')]/parent::label/preceding-sibling::input[@type='checkbox']";

        private const string firstName = @"//input[contains(@id,'txtFirstName')]";

        private const string _activationCodeXPath = @"//input[contains(@id,'txtUniqueId')]";
        private const string _firstNameXPath = @"//input[contains(@id,'txtFirstName')]";
        private const string _lastNameXPath = @"//input[contains(@id,'txtLastName')]";
        private const string _lineEmbossingXPath = @"//input[contains(@id, 'txtNameLine2')]";
        private const string _alternativePhoneXPath = @"//input[contains(@id,'HomePhoneNumber')]";
        private const string _businessPhoneXPath = @"//input[contains(@id,'BusinessPhoneNumber')]";
        private const string _mobilePhoneTxtXPath = @"//input[contains(@id,'MobilePhoneNumber')]";
        private const string _emailTxtXPath = @"//input[contains(@id,'txtEmailAddress')]";
		private const string _fromEmailTxtXPath = @"//input[contains(@id,'txtFromAddress')]";
		private const string _mobilePhoneWarningTxtXPath = @"//div[contains(@id,'mobileUserMsg')]";
        private const string _saveBtnXPath = @"//input[contains(@id, 'btnSave')]";
        private const string _confirmBtnXPath = @"//input[contains(@id, 'btnConfirm')]";
        private const string _productTypeXPath = @"//select[contains(@id, 'ddlProductTypes')]";
        private const string _cancelBtnXPath = @"//input[contains(@id, 'btnCancel')]";
        private const string _workEmailLblXPath = @"//label[contains(@id, 'EmailAddressLabel')]";
        private const string _expirationXPath = @"//input[contains(@id, 'Expiration')]";
        private const string _virtualTypeXPath = @"//input[contains(@id, 'lblVirtualType')]";
        private const string _historyXPath = @"//a[contains(@id, 'History')]";
        private const string _actionXPath = @"//button[@id='actionsutton']";
        private const string _creditLimitXPath = @"//input[contains(@id, 'txtCreditLimit')]";
        private const string _dailyLimitXPath = @"//input[contains(@id, 'txtDailyLimit')]";
        private const string _monthlyLimitXPath = @"//input[contains(@id, 'txtMonthlyLimit')]";
        private const string _cardProfileDropdownXPath = @"//*[contains(@id,'cardProfileDropdown')]";
        private const string _applyXPath = @"//input[contains(@id, 'applyButton')]";
        private const string _getMCCCGProfileXPath = @"//select[contains(@id,'MccGroupProfileSet_DdlIncludeExcludeProfiles')]";
        private const string _noChangesWereMadeXPath = @"//div[@id='upInformationMessages']";
        private const string _hierarchyExplorerXPath = @"//a[contains(@id,'hierarchyExplorer')]";
        private const string _btnFinishXPath = @"//button[@id ='finish']";
        private const string _singlePurchaseLimitXPath = @"//input[contains(@id,'txtDollarsPerTransactionLimit')]";
        private const string _startDateTempCreditLimitXPath = @"//input[contains(@id,'tbEmptyStartDate') and contains(@name, 'gvEditTempCreditLimitUpdates')]";
        private const string _endDateTempCreditLimitXPath = @"//input[contains(@id,'tbEmptyEndDate') and contains(@name, 'gvEditTempCreditLimitUpdates')]";
        private const string _tbTempCreditLimitXPath = @"//input[contains(@id,'tbEmptyTemporaryCreditLimit') and contains(@name, 'gvEditTempCreditLimitUpdates')]";
        private const string _addBtnTempCreditLimitXPath = @"//input[contains(@id,'btnEmptyAdd') and contains(@name, 'gvEditTempCreditLimitUpdates')]";
        private const string _labelTempCreditLimitXPath = @"//tr[1][contains(@id,'gvEditTempCreditLimitUpdates')]/td[4]";
        private const string _startDateSinglePurchaseLimitXPath = @"//input[contains(@id,'tbEmptyStartDate') and contains(@name, 'gvEditTempSinglePurchaseLimitUpdates')]";
        private const string _endDateSinglePurchaseLimitXPath = @"//input[contains(@id,'tbEmptyEndDate') and contains(@name, 'gvEditTempSinglePurchaseLimitUpdates')]";
        private const string _tbSinglePurchaseLimitXPath = @"//input[contains(@id,'tbEmptyTemporarySinglePurchaseLimit') and contains(@name, 'gvEditTempSinglePurchaseLimitUpdates')]";
        private const string _addBtnSinglePurchaseLimitXPath = @"//input[contains(@id,'btnEmptyAdd') and contains(@name, 'gvEditTempSinglePurchaseLimitUpdates')]";
        private const string _labeSinglePurchaseLimitXPath = @"//tr[1][contains(@id,'gvEditTempSinglePurchaseLimitUpdates')]/td[4]";
        private const string _tempCredLimitconfirmLblXPath = @"//p[contains(@id, 'lblConfirmMessage')]";
        private const string _tempSinglePurchaseconfirmLblXPath = @"//span[contains(@id, 'comDollarsPerTransactionWarningValidator')]";
        private const string _infoMessageXPath = @"//div[contains(@id, 'DivInformationMessage')]";
        private const string _startDateMCCGProfileXPath = @"//input[contains(@id,'tbEmptyStartDate') and contains(@name, 'gvEditTempMccgProfileUpdates')]";
        private const string _endDateMCCGProfileXPath = @"//input[contains(@id,'tbEmptyEndDate') and contains(@name, 'gvEditTempMccgProfileUpdates')]";
        private const string _ddlMCCGProfileXPath = @"//select[contains(@id,'DdlIncludeExcludeProfiles') and contains(@name, 'gvEditTempMccgProfileUpdates')]";
        private const string _addBtnMCCGProfileXPath = @"//input[contains(@id,'btnEmptyAdd') and contains(@name, 'gvEditTempMccgProfileUpdates')]";
        private const string _labelMCCGProfileXPath = @"//tr[1][contains(@id,'gvEditTempMccgProfileUpdates')]/td[4]";
        private const string _labelAccountNrXPath = @"//input[contains(@name,'lblAccountNumber')]";
        private const string _mccGroupProfileSetXPath = @"//select[contains(@id,'MccGroupProfile')]";
        private const string _tempMccgProfileUpdatesXPath = @"//select[contains(@id,'gvEditTempMccgProfileUpdates')]";
        private const string _tempMccgProfileStartDateXPath = @"//input[contains(@id,'StartDate') and contains(@name,'TempMccgProfileUpdates')]";
        private const string _tempMccgProfileEndDateXPath = @"//input[contains(@id,'EndDate') and contains(@name,'TempMccgProfileUpdates')]";
        private const string _creditLimitChangeReasonsXPath = @"//select[contains(@id,'ddlCreditLimitChangeReasons')]";
        private const string _ddlAccountStatusesXPath = @"//select[contains(@id,'ddlAccountStatuses')]";
        private const string _expandAllXpath = ".//button[@data-action='expand'][1]";
        private const string _collapseAllXpath = ".//button[@data-action='collapse'][1]";
        private const string _tempCdtLmtXpath = "//input[contains(@id,'tbEmptyTemporaryCreditLimit') and contains(@name, 'gvEditTempCreditLimitUpdates')]";
        private const string _dailyLimitVerificationXpath = @"//span[contains(@id, 'comDailyLimitWarningValidator')]";
        private const string _lblCreditLimitXpath = @"//label[contains(@id, 'txtCreditLimit_lblCurrency')]";

        #endregion

        #region IWEbeElements Props

        /// <summary>
        /// Expand all Link
        /// </summary>
        public IWebElement _expandAllLink
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_expandAllXpath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_expandAllLink element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

		/// <summary>
		/// Collapse All Link
		/// </summary>
        public IWebElement _collapseAllLink
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_collapseAllXpath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_collapseAllLink element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

		/// <summary>
		/// Temporary Credit Limit
		/// </summary>
        public IWebElement _tempCreditLimit
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_tempCdtLmtXpath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_creditLimit element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _activationCode
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_activationCodeXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_activationCode element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _firstName
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_firstNameXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_firstName element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _lastName
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_lastNameXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_lastName element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _lineEmbossing
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_lineEmbossingXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_lineEmbossing element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _alternativePhone
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_alternativePhoneXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_alternativePhone element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _businessPhone
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_businessPhoneXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_businessPhone element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _mobilePhoneTxt
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_mobilePhoneTxtXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_mobilePhoneTxt element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _emailTxt
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_emailTxtXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_emailTxt element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

		public IWebElement _fromEmail
		{
			get
			{
				bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_fromEmailTxtXPath), out IWebElement element);
				Settings.EnCompassExtentTest.Info("_fromEmail element exist is " + found);
				Check.That(found).IsTrue();
				return element;
			}
		}

		public IWebElement _mobilePhoneWarningTxt
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_mobilePhoneWarningTxtXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_mobilePhoneWarningTxt element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _saveBtn
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_saveBtnXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_saveBtn element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _confirmBtn
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_confirmBtnXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_confirmBtn element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _productType
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_productTypeXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_productType element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _cancelBtn
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_cancelBtnXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_cancelBtn element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _workEmailLbl
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_workEmailLblXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_workEmailLbl element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _expiration
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_expirationXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_expiration element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _virtualType
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_virtualTypeXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_virtualType element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _history
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_historyXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_history element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _action
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_actionXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_action element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _creditLimit
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_creditLimitXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_creditLimit element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _dailyLimit
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_dailyLimitXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_dailyLimit element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _monthlyLimit
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_monthlyLimitXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_monthlyLimit element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _cardProfileDropdown
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_cardProfileDropdownXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_cardProfileDropdown element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }


        public IWebElement _apply
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_applyXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_apply element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _getMCCCGProfile
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_getMCCCGProfileXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_getMCCCGProfile element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _noChangesWereMade
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_noChangesWereMadeXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_noChangesWereMade element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _hierarchyExplorer
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_hierarchyExplorerXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_hierarchyExplorer element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _btnFinish
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_btnFinishXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_btnFinish element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _singlePurchaseLimit
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_singlePurchaseLimitXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_singlePurchaseLimit element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _startDateTempCreditLimit
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_startDateTempCreditLimitXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_startDateTempCreditLimit element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _endDateTempCreditLimit
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_endDateTempCreditLimitXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_endDateTempCreditLimit element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _tbTempCreditLimit
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_tbTempCreditLimitXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_tbTempCreditLimit element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _addBtnTempCreditLimit
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_addBtnTempCreditLimitXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_addBtnTempCreditLimit element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _labelTempCreditLimit
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_labelTempCreditLimitXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_labelTempCreditLimit element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _startDateSinglePurchaseLimit
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_startDateSinglePurchaseLimitXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_startDateSinglePurchaseLimit element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _endDateSinglePurchaseLimit
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_endDateSinglePurchaseLimitXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_endDateSinglePurchaseLimit element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _tbSinglePurchaseLimit
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_tbSinglePurchaseLimitXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_tbSinglePurchaseLimit element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _addBtnSinglePurchaseLimit
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_addBtnSinglePurchaseLimitXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_addBtnSinglePurchaseLimit element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _labeSinglePurchaseLimit
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_labeSinglePurchaseLimitXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_labeSinglePurchaseLimit element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _tempCredLimitconfirmLbl
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_tempCredLimitconfirmLblXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_tempCredLimitconfirmLbl element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _tempSinglePurchaseconfirmLbl
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_tempSinglePurchaseconfirmLblXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_tempSinglePurchaseconfirmLbl element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _infoMessage
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_infoMessageXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_infoMessage element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _startDateMCCGProfile
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_startDateMCCGProfileXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_startDateMCCGProfile element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _endDateMCCGProfile
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_endDateMCCGProfileXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_endDateMCCGProfile element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _ddlMCCGProfile
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_ddlMCCGProfileXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_ddlMCCGProfile element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _addBtnMCCGProfile
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_addBtnMCCGProfileXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_addBtnMCCGProfile element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _labelMCCGProfile
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_labelMCCGProfileXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_labelMCCGProfile element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _labelAccountNr
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_labelAccountNrXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_labelAccountNr element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _mccGroupProfileSet
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_mccGroupProfileSetXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_mccGroupProfileSet element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _tempMccgProfileUpdates
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_tempMccgProfileUpdatesXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_tempMccgProfileUpdates element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _tempMccgProfileStartDate
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_tempMccgProfileStartDateXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_tempMccgProfileStartDate element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _tempMccgProfileEndDate
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_tempMccgProfileEndDateXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_tempMccgProfileEndDate element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _creditLimitChangeReasons
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_creditLimitChangeReasonsXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_creditLimitChangeReasons element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _ddlAccountStatuses
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_ddlAccountStatusesXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_ddlAccountStatuses element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement dailyLimitVerification
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_dailyLimitVerificationXpath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_dailyLimitVerification element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement lblCreditLimit
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_lblCreditLimitXpath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_lblCreditLimitXpath element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        #endregion        

        #region Expand Elements

        private const string AC_EDITCARD = "content_contents_acEditCard";
        private const string AP_CARD_HOLDER = "acpCardholderInfo";
        private const string AP_CARD = "apCardInfo";
        private const string AP_LIMITS = "acpVelocityLimits";
        private const string AP_TEMP_SETTINGS = "rowTemporarySettings";
        private const string AP_MCC_GROUP_PROFILES = "acpMccGroupProfiles";
        #endregion

        private GridControl _processorChangesGrid;
        public GridControl ProcessorChangesGrid
        {
            get
            {
                _processorChangesGrid = new GridControl("dgRealTimeChanges", Driver);
                _processorChangesGrid.WaitForGrid();
                return _processorChangesGrid;
            }
        }

        public string AccountStatuses
        {
            get { return new SelectElement(_ddlAccountStatuses).SelectedOption.Text; }
            set
            {
                _ddlAccountStatuses.SetListboxByText(value);
                Settings.EnCompassExtentTest.Info($"Account Status set to {value}.");
            }
        }

        public bool VerifyCreditLimitChangeReasonsDisplay(string value)
        {
            return new SelectElement(_creditLimitChangeReasons).Options.Where(o => o.Text.Equals(value)).Any();
        }

        public string SelectMccGroupProfile
        {
            get { return new SelectElement(_mccGroupProfileSet).SelectedOption.Text; }
            set { _mccGroupProfileSet.SetListboxByText(value); }
        }

        public string TempMccgProfileUpdates
        {
            get { return new SelectElement(_tempMccgProfileUpdates).SelectedOption.Text; }
            set { _tempMccgProfileUpdates.SetListboxByText(value); }
        }

        public string TempMccgProfileStartDate
        {
            set
            {
                _tempMccgProfileStartDate.Clear();
                _tempMccgProfileStartDate.SendKeys(value);
            }
        }

        public string TempMccgProfileEndDate
        {
            set
            {
                _tempMccgProfileEndDate.Clear();
                _tempMccgProfileEndDate.SendKeys(value);
            }
        }

        public void SelectMCCGProfileAndSave(string mccgProfileName, ExtentTest test)
        {
            SelectMccGroupProfile = mccgProfileName;
            test.Info("Select MCCG Profile to apply via Card Management");
            if (StringKeys.FIsRequiringAddActivationCode.Contains(GlobalSettings.FI))
                ActivationCode = "123456789";
            if (StringKeys.FIsRequiringUniqueIdAndAltPh.Contains(GlobalSettings.FI))
                AlternativePhone = "1123456678";
            PressSave();
            test.Info("Press button Save");
            Confirm();
            test.Info("Press button Confirm");
        }

        public void SaveMCCGProfileAndTemporaryProfile(string mccgProfileName, string temporaryProfile, string startDate, string endDate, ExtentTest test)
        {
			ExpandMerchantCategoryCodeProfile();
            SelectMccGroupProfile = mccgProfileName;
            test.Info("Select MCCG Profile to apply via Card Management");
            ExpandTempSettings();
            TempMccgProfileUpdates = temporaryProfile;
            test.Info("Select MCCG Profile Temporary to apply via Card Management");
            TempMccgProfileStartDate = startDate;
            test.Info("Set the start Date to MCCG Profile Temporary via Card Management");
            TempMccgProfileEndDate = endDate;
            test.Info("Set the end Date to MCCG Profile Temporary via Card Management");
            AddMCCGProfile();
            test.Info("Press button Add");
            PressSave();
            test.Info("Press button Save");
            Confirm();
            test.Info("Press button Confirm");
        }
         
        public void SetHiercharyLevel(int level)
        {
            Driver.WaitForVisible(By.XPath(_lblHeirarchyLevel));
            IWebElement labels = Driver.FindElement(By.XPath(_lblHeirarchyLevel));
            IWebElement checkboxes = Driver.FindElement(By.XPath(_cbHeirarchyLevel));
            if (!checkboxes.Selected)
                checkboxes.SetCheckboxStateWithLabel(labels, true);
            bool isButtonPresent = Driver.TryWaitForElementToBeVisible(By.XPath(_btnFinishXPath), out IWebElement element);
            if(isButtonPresent)
                _btnFinish.JSClickWithFocus(Driver);
        }

        public void HierarchyExplorer()
        {
            _hierarchyExplorer.JSClickWithFocus(Driver);
        }

        public bool NoChangesWereMade()
        {
            return _noChangesWereMade.Text.Contains("No changes were made");
        }

        public string GetMCCCGProfile()
		{
            SelectElement ddlMCCG = new SelectElement(_getMCCCGProfile);
			return ddlMCCG.SelectedOption.Text;
		}

		public string NumberOfMonthsToExpiration
		{
			get { return _expiration.GetAttribute("value"); }
		}
		//public string NumberOfMonthsToExpirationStatus => _expiration.GetAttribute("readonly");
		public string NumberOfMonthsToExpirationStatus => _expiration.GetAttribute("readonly");

		public bool IsExpirationDisplayed
		{
			get
			{
				if(Driver.TryFindElement(By.XPath(@"//input[contains(@id, 'Expiration')]"), out IWebElement element))
				{
					return element.Displayed;
				}
				else
				{
					return false;
				}
			}
		}

		public bool IsVirtualTypeDisplayed
		{
			get
			{
				if (Driver.TryFindElement(By.XPath(@"//input[contains(@id, 'lblVirtualType')]"), out IWebElement element))
				{
					return element.Displayed;
				}
				else
				{
					return false;
				}
			}
		}

		public string VirtualType
		{
			get
			{
				return _virtualType.GetAttribute("value").Replace("(", "").Replace(")","").Trim();
			}
		}

		public void UpdateProductType(string originalOption, string replaceOption)
		{
			var selectElement = new SelectElement(_productType);
			string selectedOption = selectElement.SelectedOption.Text.Trim();
			//if(selectedOption.Equals(originalOption.ToString().Trim(), StringComparison.InvariantCultureIgnoreCase))
			if(selectedOption.StartsWith(originalOption))
			{
				// Getting the List of Options from the Select Item because SelectByText method is not searching based on 'Substring'.
				var selOption = selectElement.Options.FirstOrDefault(f => f.Text.StartsWith(replaceOption));
				if (selOption != null)
				{
					selectElement.SelectByText(selOption.Text);
				}
				else
				{
					throw new Exception($"Select Option not present in the list.");
				}
			}
			else
			{
				var selOption = selectElement.Options.FirstOrDefault(f => f.Text.StartsWith(originalOption));
				if(selOption != null)
				{
					selectElement.SelectByText(selOption.Text);
				}
				else
				{
					throw new Exception($"Select Option not present in the list.");
				}

			}
		}

		/// <summary>
		/// This method extracts the NON-SELECTED Product Type from the list box and returns the TEXT.
		/// </summary>
		/// <param name="textStartsWith"></param>
		/// <returns></returns>
		public string NonSelectedProductType(string textStartsWith)
		{
			var selectElement = new SelectElement(_productType);
			try
			{
				return selectElement.Options.FirstOrDefault(f => f.Text.StartsWith(textStartsWith)).Text;
			}
			catch
			{
				return null;
			}
		}

		public string ProductType
		{
			get { return new SelectElement(_productType).SelectedOption.Text; }
			set { new SelectElement(_productType).SelectByText(value); }
		}

		/// <summary>
		/// This method clicks on the History link in Edit Account page and waits for the History link to disappear.
		/// </summary>
		public void History()
		{
            _action.JSClickWithFocus(Driver);
            WaitForLoad(); 
            _history.JSClickWithFocus(Driver);
			//Driver.WaitForAbsence(By.XPath(@"//a[contains(@id, 'History')]"));
		}

		private PhoneControl _mobilePhone;
		public PhoneControl MobilePhone
		{
			get
			{
				return _mobilePhone ?? (_mobilePhone = new PhoneControl("ctlMobilePhoneNumber", Driver));
			}
		}

		public string ActivationCode
		{
			set
			{
				_activationCode.WaitUntilElementIsInteractable();
				_activationCode.ForceDocumentLoadOnSendKeys(value, Settings.EnCompassWebDriver);
                Settings.EnCompassExtentTest.Info($"Activation Code set value: {value}");
			}
		}

		public string FirstName
		{
            get
            {
                Driver.ScrollToXPATH(firstName);
                _firstName.WaitUntilElementIsInteractable();
                return _firstName.GetAttribute("value");
            }
            set
			{
				_firstName.ForceDocumentLoadOnSendKeys(value, Settings.EnCompassWebDriver);
                Settings.EnCompassExtentTest.Info($"First Name set value: {value}");
            }
		}

		public string LastName
		{
            get
            {
                return _lastName.GetAttribute("value");
            }
            set
			{
				_lastName.ForceDocumentLoadOnSendKeys(value, Settings.EnCompassWebDriver);
                Settings.EnCompassExtentTest.Info($"Last Name set value: {value}");
            }
		}

        public string EmployeeId
        {
            get
            {
                Settings.EnCompassWebDriver.TryWaitForElement(By.XPath(".//input[contains(@id,'txtEmployeeId')]"), out IWebElement element);
                return element.GetAttribute("value");
            }

            set
            {
                Settings.EnCompassWebDriver.TryWaitForElement(By.XPath(".//input[contains(@id,'txtEmployeeId')]"), out IWebElement element);
                element.Clear();
                element.SendKeys(value);
                Settings.EnCompassExtentTest.Info($"Employee ID set value: {value}");
            }
        }

		public string BusinessPhone
		{
            get
            {
                return _businessPhone.GetAttribute("value");
            }
			set
			{
				_businessPhone.ForceDocumentLoadOnSendKeys(value, Settings.EnCompassWebDriver);
                Settings.EnCompassExtentTest.Info($"Business phone input set to {value}.");
			}
		}

		public string AlternativePhone
		{
			set
			{
				bool isPresent = Driver.IsElementPresent(By.XPath("//input[contains(@id,'HomePhoneNumber')]"));
				// At times Alt number migth not be present for some FIs, thus ignoreing it.
				// The list of FIS on which this is invoked does take care of ensuring that we
				// do not miss a legitimate setting
				if (isPresent)
				{
                    _alternativePhone.ForceDocumentLoadOnSendKeys(value, Settings.EnCompassWebDriver);
                    Settings.EnCompassExtentTest.Info($"Alternative Phone set value: {value}");
                }
			}
		}

		public string MobilePhoneTxt
		{
			get
			{
				return _mobilePhoneTxt.GetAttribute("value");

			}
			set
			{
				_mobilePhoneTxt.ForceDocumentLoadOnSendKeys(value, Settings.EnCompassWebDriver);
			}

		}

		public string EmailTxt
		{
			get
			{
				return _emailTxt.GetAttribute("Value");
			}
			set
			{
				_emailTxt.ForceDocumentLoadOnSendKeys(value, Settings.EnCompassWebDriver);
			}
		}

		/// <summary>
		/// From Email field which appears for AMEX on the screen
		/// </summary>
		public string FromEmail
		{
			get
			{
				return _fromEmail.GetAttribute("Value");
			}
			set
			{
				_fromEmail.ForceDocumentLoadOnSendKeys(value, Settings.EnCompassWebDriver);
			}
		}


		public string LineEmbossing
		{
			set
			{
				_lineEmbossing.ForceDocumentLoadOnSendKeys(value, Settings.EnCompassWebDriver);
			}
		}

		public void PressSave()
		{
			_saveBtn.JSClickWithFocus(Driver);
			WaitForLoad();
            Settings.EnCompassExtentTest.Info("Clicked on Save Button.");
            this.AttachOnDemandScreenShot();
		}

        public void PressConfirm()
        {
            //For this specfic case, I really do intend to take the screenshot before the confirmation takes place.
            this.AttachOnDemandScreenShot();
            _confirmBtn.JSClickWithFocus(Driver);
			Settings.EnCompassExtentTest.Info("Clicked on Confirm Button.");
            WaitForLoad();
        }

        public bool HasMobilePhone
		{
			get
			{
				return Driver.IsElementPresent(GetBy(() => this._mobilePhoneTxt));
			}
		}

		public string WorkEmailLbl
		{
			get
			{
				return _workEmailLbl.Text;
			}
		}

		public string MobilePhoneWarningTxt
		{
			get
			{
				return _mobilePhoneWarningTxt.Text;
			}
		}

		public void Confirm()
		{
			bool buttonFound = Driver.TryWaitForElement(By.XPath("//input[contains(@id, 'btnConfirm')]"), out IWebElement _confirmBtn);
			if (buttonFound)
			{
				_confirmBtn.JSClickWithFocus(Driver);
				this.AttachOnDemandScreenShot();
				Settings.EnCompassExtentTest.Info("Clicked on Confirm Button");
			}
			else
			{
				Settings.EnCompassExtentTest.Info("Confirm Button not found, couldn't click");
				throw new Exception("Confirm Button not found");
			}
		}

		public void CancelBtn()
		{			
			bool buttonFound = Driver.TryWaitForElement(By.XPath("//input[contains(@id, 'btnCancel')]"), out IWebElement _cancelBtn);
			if (buttonFound)
			{
				_cancelBtn.JSClickWithFocus(Driver);
				this.AttachOnDemandScreenShot();
				Settings.EnCompassExtentTest.Info("Clicked on Cancel Button");
			}
			else
			{
				Settings.EnCompassExtentTest.Info("Cancel Button not found, couldn't click");
				throw new Exception("Cancel Button not found");
			}
		}

		public string CellPolicyToolTip => MobilePhone.CellPolicyToolTip;

		public string CellPolicyHeader => MobilePhone.CellPolicyHeader;

		public string CellPolicyBody => MobilePhone.CellPolicyBody;

		public bool IsCellPolicyVisible => MobilePhone.IsCellPolicyVisible;

		public void ShowCellPolicy()
		{
			Driver.WaitForDocumentLoadToComplete();
			MobilePhone.ShowCellPolicy();
			//Driver.WaitFor(By.XPath(@"//body[@class = 'iframe-modal']//div[@class = 'modal-body']"));
			//WaitForModalLoadingOverlay();
		}

		public void HideCellPolicy()
		{
			MobilePhone.HideCellPolicy();
		}

        /// <summary>
        /// Sets and retrieves Credit Limit element content on the UI.
        /// </summary>
        public string CreditLimit
        {
            set
            {
                _creditLimit.Clear();
				_creditLimit.ForceDocumentLoadOnSendKeys(value, Settings.EnCompassWebDriver);
                Settings.EnCompassExtentTest.Info($"Credit Limit set value: {value}");
            }
            get
			{
				return _creditLimit.GetAttribute("value");
			}
        }

        /// <summary>
        /// Sets and retrieves Daily Limit element content on the UI.
        /// </summary>
        public string DailyLimit
        {
            set
            {
                _dailyLimit.ForceDocumentLoadOnSendKeys(value, Settings.EnCompassWebDriver);
                Settings.EnCompassExtentTest.Info("Entered Daily Limit.");
            }
            get
            {
                return _dailyLimit.GetAttribute("value");
            }
        }

        /// <summary>
        /// Sets and retrieves Monthly Limit element content on the UI.
        /// </summary>
        public string MonthlyLimit
        {
            set
            {
                _monthlyLimit.ForceDocumentLoadOnSendKeys(value, Settings.EnCompassWebDriver);
                Settings.EnCompassExtentTest.Info("Entered Monthly Limit.");
            }
            get
            {
                return _monthlyLimit.GetAttribute("value");
            }
        }


        public void SetCardProfile(string whichText)
		{
			var selectElement = new SelectElement(_cardProfileDropdown);
			selectElement.SelectByText(whichText);
		}

		public void PressApply()
		{
			_apply.JSClickWithFocus(Driver);
		}

        public bool RefreshCardLimitcheck(string creditlimit, int cardno)
        {
            RefreshModel();
            string statustext = string.Empty;
			int counter = 0;
            do
            {
                ExpandLimits();
				counter++;
				statustext = Settings.EnCompassWebDriver.WaitForVisible(By.XPath(@"//input[contains(@id, 'txtCreditLimit')]")).GetAttribute("value");
                Thread.Sleep(TimeSpan.FromSeconds(2));

                // search again.
                var main = new Main(Settings);
                main.Navigate();
                main.SearchAccountWith("Account Number", Settings.Scenario["CardCreditNumber" + cardno].ToString());
                main.CardGrid.SelectFirstRow();
                main.CardGrid.PerformActionByText("Edit");
                WaitForLoad();
                ExpandLimits();
                Settings.EnCompassWebDriver.WaitForVisible(By.XPath(@"//input[contains(@id, 'txtCreditLimit')]"));
            }while (!statustext.Equals(creditlimit) && counter < 30);

            return (CreditLimit.Trim()).Equals(creditlimit.Trim());
        }

		private string _stDateTempCdtLmtXpath = "//input[contains(@id,'tbEmptyStartDate') and contains(@name, 'gvEditTempCreditLimitUpdates')]";
		/// <summary>
		/// Gets/Sets the Start Date 
		/// </summary>
		public string SetStartDateTempCreditLimit
        {
			get
			{
				Driver.TryWaitForElementToBeVisible(By.XPath(_stDateTempCdtLmtXpath), out IWebElement element); 
				return element.GetAttribute("value");
			}
            set
            {
				Driver.TryWaitForElementToBeVisible(By.XPath(_stDateTempCdtLmtXpath), out IWebElement element);
				element.SendKeys(value);
				Settings.EnCompassExtentTest.Info("Temp Credit Limit Start Date set to:" + value);
			}
		}

		private string _endDtTempCdtXpath = "//input[contains(@id,'tbEmptyEndDate') and contains(@name, 'gvEditTempCreditLimitUpdates')]";
		/// <summary>
		/// Gets/Sets the End Date 
		/// </summary>
		public string SetEndDateTempCreditLimit
		{
			get
			{
				Driver.TryWaitForElementToBeVisible(By.XPath(_endDtTempCdtXpath), out IWebElement element);
				return element.GetAttribute("value");
			}
			set
			{
				Driver.TryWaitForElementToBeVisible(By.XPath(_endDtTempCdtXpath), out IWebElement element);
				element.SendKeys(value);
				Settings.EnCompassExtentTest.Info("Temp Credit Limit End Date set to:" + value);
			}
		}

		public string SetStartDateTempSinglePurchase
        {
            set
            {
                _startDateSinglePurchaseLimit.SendKeys(value);
                Settings.EnCompassExtentTest.Info("Start Date for Temp Single Purchase Limit set to:" + value);
            }
        }

        public string SetStartDateTempMCCGProfile
        {
            set
            {
                _startDateMCCGProfile.SendKeys(value);
            }
        }

        public string SetEndDateTempSinglePurchase
        {
            set
            {
                _endDateSinglePurchaseLimit.SendKeys(value);
                Settings.EnCompassExtentTest.Info("End Date for Temp Single Purchase Limit set to:" + value);
            }
        }

        public string SetEndDateTempMCCGProfile
        {
            set
            {
                _endDateMCCGProfile.SendKeys(value);
            }
        }

		/// <summary>
		/// Sets Temp Credit Limit
		/// </summary>
		public string SetTempCreditLimit
        {
            get
            {
               return  _tempCreditLimit.GetAttribute("value");
            }
            set
            {
				_tempCreditLimit.JSSendKeys(Driver,value);
				Settings.EnCompassExtentTest.Info("Temp Credit Limit set to:" + value);
            }
        }

        /// <summary>
        /// Temporary Single Purchase Limit
        /// </summary>
        public string SetTempSinglePurchaseLimit
        {
            set
            {
                _tbSinglePurchaseLimit.SendKeys(value);
                Settings.EnCompassExtentTest.Info("Temp Single Purchase Limit set to:" + value);
            }
        }

        public string SetMCCGDropDown
        {
            set
            {
                var selectElement = new SelectElement(_ddlMCCGProfile);
                selectElement.SelectByText(value);
            }
        }
        public void AddTempCreditLimit()
        {
            _addBtnTempCreditLimit.JSClickWithFocus(Driver);
			Settings.EnCompassExtentTest.Info("Clicked on Add button for Temp Credit Limit");
		}

        public void AddTempsinglePurchaseLimit()
        {
            _addBtnSinglePurchaseLimit.JSClickWithFocus(Driver);
        }

        public void AddMCCGProfile()
        {
            _addBtnMCCGProfile.JSClickWithFocus(Driver);
        }

        public string ModificationLabelForcreditLimit()

        {
            Settings.EnCompassWebDriver.WaitForVisible(By.XPath("//tr[1][contains(@id,'gvEditTempCreditLimitUpdates')]/td[4]"));
            return _labelTempCreditLimit.Text;
        }

        public string ModificationLabelForSinglePurchase()

        {
            Settings.EnCompassWebDriver.WaitForVisible(By.XPath("//tr[1][contains(@id,'gvEditTempSinglePurchaseLimitUpdates')]/td[4]"));
            return _labeSinglePurchaseLimit.Text;
        }

        public string ModificationLabelForMCCGProfile()

        {
            Settings.EnCompassWebDriver.WaitForVisible(By.XPath("//tr[1][contains(@id,'gvEditTempMccgProfileUpdates')]/td[4]"));
            return _labelMCCGProfile.Text;
        }

        /// <summary>
        /// single Purchase Limit
        /// </summary>
        public string SinglePurchaseLimit
        {
            set
            {
                _singlePurchaseLimit.Clear();
                _singlePurchaseLimit.SendKeys(value);
                Settings.EnCompassExtentTest.Info($"Single Purchase Limit set value: {value}");
            }
            get
            {
                return _singlePurchaseLimit.GetAttribute("value");
            }
        }

        public string ConfirmLabelForCreditLimit()
        {
            Settings.EnCompassWebDriver.WaitForVisible(By.XPath("//p[contains(@id, 'lblConfirmMessage')]"));
            Settings.EnCompassExtentTest.Info($"validation span for credit limit is: {_tempCredLimitconfirmLbl.Text}");
            return _tempCredLimitconfirmLbl.Text;
        }

        public string ConfirmLabelForStructuredDailyLimit()
        {
            Settings.EnCompassWebDriver.WaitForVisible(By.XPath(_dailyLimitVerificationXpath));
            Settings.EnCompassExtentTest.Info($"validation span for daily limit is: {dailyLimitVerification.Text}");
            return dailyLimitVerification.Text;
        }

        public string ConfirmLabelForSinglePurchaseLimit()
        {
            Settings.EnCompassWebDriver.WaitForVisible(By.XPath(_tempSinglePurchaseconfirmLblXPath));
            Settings.EnCompassExtentTest.Info($"validation span for Single Purchase is: { _tempSinglePurchaseconfirmLbl.Text}");
            return _tempSinglePurchaseconfirmLbl.Text;
        }

       
        public bool IsInfoMessagePresent
        {
            get
            {
                try
                {
                    return _infoMessage.Displayed;
                }
                catch
                {
                    return false;
                }
            }
        }

        public string AccountNumberLast4
        {
            get
            {

                //IWebElement _accNr = Driver.WaitForVisible(By.XPath("//input[contains(@name,'lblAccountNumber')]"));
                string accountNr = _labelAccountNr.GetAttribute("value");
                string lastFour = accountNr.Remove(0, 15);
                return lastFour;
            }
        }

        public void SelectAccountStatusAndSave(string accountStatus, ExtentTest test)
        {
            AccountStatuses = accountStatus;
            test.Info("Select Account Status field");
            PressSave();
            test.Info("click save button");
        }

        /// <summary>
        /// Return true if the element is present, but not visible. If element is not found, it throws exception.
        /// </summary>
        public bool IsInvalidFeedbackMessagePresent(string message)
        {
            string xpath = $"//span[@class='invalid-feedback' and @style = 'display: inline;' and contains(text(), '{message.Trim()}')]";
            Driver.TryWaitForElement(By.XPath(xpath), out IWebElement element);

            if (element == null)
            {
                Settings.EnCompassExtentTest.Info($"Element with message {message} is displayed: false.");
                return false;
            }

            Settings.EnCompassExtentTest.Info($"Element with message {message} is displayed: {element.Displayed}.");
            return element.Displayed;
        }

        /// <summary>
        /// Click on Expand all link
        /// </summary>
        public void ExpandAll()
        {
            // Check if collapse link is visible
            try
            {
                IWebElement collapse = _collapseAllLink;
                // If its visible then Expand all is already in action, nothing to do
            }
            catch (Exception)
            {
                // Only if Collpase all is not visible then expand it
                _expandAllLink.JSClickWithFocus(Driver);
                Settings.EnCompassExtentTest.Info("clicked on Expand all Link");
                // Ensure collapse link is visible
                IWebElement collapse = _collapseAllLink;
            }
        }

        /// <summary>
        /// Click on Collapse all link
        /// </summary>
        public void CollapseAll()
        {
            // Check if collapse link is visible
            try
            {
                IWebElement expand = _expandAllLink;
                // If its visible then Collapse all is already in action, nothing to do
            }
            catch (Exception)
            {
                // Only if Collpase all is not visible then expand it
                _collapseAllLink.JSClickWithFocus(Driver);
                Settings.EnCompassExtentTest.Info("clicked on Collapse all Link");
                // Ensure expand link is visible
                IWebElement expand = _expandAllLink;
            }
        }

        public void ExpandCardholder()
        {
            //Changed to the generic method
            ExpandCardHeader(AC_EDITCARD, AP_CARD_HOLDER);
			Settings.EnCompassExtentTest.Info("Expanded CardHolder Section");
		}

        public void ExpandCard()
		{
            //Changed to the generic method
            ExpandCardHeader(AC_EDITCARD, AP_CARD);
			Settings.EnCompassExtentTest.Info("Expanded Cards Section");
		}

        public void ExpandLimits()
        {
            //Changed to the generic method
            ExpandCardHeader(AC_EDITCARD, AP_LIMITS);
			Settings.EnCompassExtentTest.Info("Expanded Limits Section");
		}

        public void ExpandTempSettings()
        {
            //Changed to the generic method
            ExpandCardHeader(AC_EDITCARD, AP_TEMP_SETTINGS);
			Settings.EnCompassExtentTest.Info("Expanded Temporary Settings Section");
        }

        public void ExpandMerchantCategoryCodeProfile()
		{
            //Changed to the generic method
            ExpandCardHeader(AC_EDITCARD, AP_MCC_GROUP_PROFILES);
			Settings.EnCompassExtentTest.Info("Expanded MerchantCategoryCodeProfile Section");
		}

        public EditAccount(GlobalSettings settings) : base(settings) { }	
	}
}
