package com.framework.testcases.AJS.SHELL;



import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.CardMaintenancePage;
import com.framework.pages.AJS.MaintainCustomerPage;
import com.framework.pages.AJS.MerchantLocationPage;
import com.framework.pages.AJS.common.Common;
import com.framework.pages.AJS.common.IFCSHomePage;
import com.framework.pages.AJS.common.IFCSLoginPage;


public class ValidateCustomerMaintenancesTestCases extends BaseTest {

		
	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test( groups = { "Regression" })
	public void ValidateIndividualReportAndAddReport(@Optional("RU") String clientCountry,
			@Optional("SHELL") String clientName, @Optional("APA") String cardType) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  SHELL IFCS CardMaintanace",
				"73 Maintain Customer -  Customer Reporting  -  Individual Reports - Add a new Report for the Customer");
		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		CardMaintenancePage cardMaintenancePage = new CardMaintenancePage(driver, test);
		
		
		Common common = new Common(driver, test);

		// Calling Functions
		IFCSloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, cardType);
		// selecting customer details
		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		String customerNumber = common.getCustomerNoHavingCardsUsingCardType();
		if (customerNumber.equals(" ")) {
			common.logForNoDataFound(this.getClass().getSimpleName(),
					"Need to Create A Customer with Card Type and rerun");
		} else {
			common.chooseCardNoAndSearch(customerNumber);

			// select Individual Reports from left panel
			cardMaintenancePage.getIndividualReport();

			// Add to Report
			common.addIteminPopup();
			// Handle message pop up
			common.messagePopUpHandle();
			// Select Report type from drop down and validate report was saved or not
			cardMaintenancePage.chooseReportTypeFromPopUpAndSaveTheReport();
			// Exit IFCS

		}
		IFCSHomePage.exitIFCS();
	}


	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test( groups = { "Regression" })
	public void updateAndValidateCardRequestedBy(@Optional("RU") String clientCountry,
			@Optional("SHELL") String clientName, @Optional("APA") String cardType) {

		test = extent.createTest(
				"26 Maintain Customer -  Card Details -  Card Maintenance - Update Requested By,"
						+ "27 Maintain Customer -  Card Details -  Card Maintenance - Update Phone No",
				"Update Requested By Field in Card Maintenace");
		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		CardMaintenancePage cardMaintenancePage = new CardMaintenancePage(driver, test);
		Common common = new Common(driver, test);
		// Calling Functions
		IFCSloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, cardType);
		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		String cardNumber = common.getDriverCardNumberFromDB(clientName + clientCountry);//common.getCustomerNoHavingCardsUsingCardType();
		if (cardNumber.equals("")) {
			// need to call method to logfail
			common.logForNoDataFound(this.getClass().getSimpleName(), "Need to Create Customer With Cards and rerun");
		} else {
			// Calling Functions
//			common.chooseCardNoAndSearch("CZ00001762");
			cardMaintenancePage.chooseCardAndUpdateRequestedByField(cardNumber, "Test3", "123");
		}

		IFCSHomePage.exitIFCS();
	}

	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test( groups = { "Regression" })
	public void updateAndValidateDriverId(@Optional("RU") String clientCountry, @Optional("SHELL") String clientName,
			@Optional("APA") String cardType) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  29 Maintain Customer-Card Details-Card Maintenance-Driver Card-Update Driver Id",
				"Update Driver Details in Card Maintenance");
		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		CardMaintenancePage cardMaintenancePage = new CardMaintenancePage(driver, test);
		Common common = new Common(driver, test);
		// Calling Functions
		IFCSloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, cardType);
		IFCSHomePage.gotoCustomerMenuCustomerDetails();

		if (clientCountry.equals("RU")) {
			// need to call method to logfail
			common.logForNoDataFound(this.getClass().getSimpleName(), "Driver card is not applicable for Russia");
		} else {
			String driverCardNumber = common.getDriverCardNumberFromDB(clientName + clientCountry);
			if (driverCardNumber.equals("")) {
				// need to call method to logfail
				common.logForNoDataFound(this.getClass().getSimpleName(), "Need to Create A Driver Card and rerun");
			} else {
				// Calling Functions
				cardMaintenancePage.chooseCardAndUpdateDriverIdInDriverCard(driverCardNumber);
			}
		}

		IFCSHomePage.exitIFCS();
	}

	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test( groups = { "Regression" })
	public void updateAndValidateDriverShortName(@Optional("RU") String clientCountry,
			@Optional("SHELL") String clientName, @Optional("APA") String cardType) {
		test = extent.createTest(
				"30 Maintain Customer-Card Details-Card Maintenance-Driver Card-Update Driver Short Name",
				"Update Driver Details in Card Maintenance");
		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		CardMaintenancePage cardMaintenancePage = new CardMaintenancePage(driver, test);
		Common common = new Common(driver, test);
		// Calling Functions
		IFCSloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, cardType);
		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		if (clientCountry.equals("RU")) {
			// need to call method to logfail
			common.logForNoDataFound(this.getClass().getSimpleName(), "Driver card is not applicable for Russia");
		}

		else {
			String driverCardNumber = common.getDriverCardNumberFromDB(clientName + clientCountry);
			if (driverCardNumber.equals("")) {
				// need to call method to logfail
				common.logForNoDataFound(this.getClass().getSimpleName(), "Need to Create A Driver Card and rerun");
			} else {
				// Calling Functions
				cardMaintenancePage.chooseCardAndUpdateShortNameInDriverCard(driverCardNumber);
			}
		}

		IFCSHomePage.exitIFCS();
	}
	
	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test( groups = { "Regression" })
	public void updateAndValidateDriverName(@Optional("RU") String clientCountry, @Optional("SHELL") String clientName,
			@Optional("APA") String cardType) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  33 Maintain Customer-Card Details-Card Maintenance-Driver Card-Update Driver Name",
				"Update Driver Details in Card Maintenance");
		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		CardMaintenancePage cardMaintenancePage = new CardMaintenancePage(driver, test);
		Common common = new Common(driver, test);
		// Calling Functions
		IFCSloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, cardType);
		IFCSHomePage.gotoCustomerMenuCustomerDetails();

		if (clientCountry.equals("RU")) {
			// need to call method to logfail
			common.logForNoDataFound(this.getClass().getSimpleName(), "Driver card is not applicable for Russia");
		} else {
			String driverCardNumber = common.getDriverCardNumberFromDB(clientName + clientCountry);
			if (driverCardNumber.equals("")) {
				// need to call method to logfail
				common.logForNoDataFound(this.getClass().getSimpleName(), "Need to Create A Driver Card and rerun");
			} else {
				// Calling Functions
				cardMaintenancePage.chooseCardAndUpdateDriverNameInDriverCard(driverCardNumber);
			}
		}

		IFCSHomePage.exitIFCS();
	}

	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test( groups = { "Regression" })
	public void updateAndValidateCostCentre(@Optional("RU") String clientCountry, @Optional("SHELL") String clientName,
			@Optional("APA") String cardType) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  28 Maintain Customer-Card Details-Card Maintenance-Update Card Group",
				"Update Cost Centre Field in Card Maintenace");
		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		CardMaintenancePage cardMaintenancePage = new CardMaintenancePage(driver, test);
		Common common = new Common(driver, test);
		// Calling Functions
		IFCSloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, cardType);
		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		String CardNumber = common.getCardNumberhavingNoCostCentreFromDB();
		if (CardNumber.equals("")) {
			// need to call method to logfail
			common.logForNoDataFound(this.getClass().getSimpleName(),
					"Need to Create A Card With No Cost Centre and rerun");
		} else {
			// Calling Functions
			cardMaintenancePage.chooseCardAndUpdateCardGroup(CardNumber);
		}

		IFCSHomePage.exitIFCS();
	}

	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test( groups = { "Regression" })
	public void createAndValidateBulkReissueRequest(@Optional("RU") String clientCountry,
			@Optional("SHELL") String clientName, @Optional("APA") String cardType) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  44 Maintain Customer-Card Details-Bulk Reissue-Add a new Bulk Reissue Request",
				"Update Cost Centre Field in Card Maintenace");
		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		CardMaintenancePage cardMaintenancePage = new CardMaintenancePage(driver, test);
		Common common = new Common(driver, test);
		// Calling Functions
		IFCSloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, cardType);
		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		// Getting Customer No having cards
		//String customerNo = common.getCustomerNoHavingNoBulkReissueRequestUsingCardType();
		String customerNo = common.getActiveCustomerNoHavingActiveCardsWithNoBulkReissue();
		// Getting IFCS Date
		String currentIFCSDate = common.getCurrentIFCSDateFromDB(clientName + clientCountry);
		String currentProcessingDate = common.enterADateValueInStatusBeginDateField("Current", currentIFCSDate);
		String futureIFCSDate = common.enterADateValueInStatusBeginDateField("Future", currentIFCSDate);
		String wayFutureIFCSDate = common.enterADateValueInStatusBeginDateField("WayFuture", currentIFCSDate);
		String nextDateIFCSDate = common.enterADateValueInStatusBeginDateField("NextDate", currentIFCSDate);
		String maxCardProductIFCSDate = common.enterADateValueInStatusBeginDateField("MaxCardProduct", currentIFCSDate);
		if (customerNo.equals("")) {
			// need to call method to logfail
			common.logForNoDataFound(this.getClass().getSimpleName(), "Need to Create A Cards For Customers and rerun");
		} else {
			// Calling Functions
			common.chooseCustomerNoAndSearch(customerNo);
			cardMaintenancePage.chooseCardAndCreateBulkReissueRequest(currentProcessingDate,
					futureIFCSDate,nextDateIFCSDate);
			cardMaintenancePage.bulkReissueRequestWithInvalidDate(currentProcessingDate, futureIFCSDate,
					maxCardProductIFCSDate);
			cardMaintenancePage.bulkReissueRequestWithValidDate(wayFutureIFCSDate);
		}
		IFCSHomePage.exitIFCS();

	}

	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test( groups = { "Regression" })
	public void cardMaintenanceUpdateCardControlProfile(@Optional("RU") String clientCountry,
			@Optional("SHELL") String clientName, @Optional("APA") String cardType) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  SHELL IFCS Card Maintenance-Update Card Control Profile",
				"Card Maintenance - Update Card Control Profile");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		Common common = new Common(driver, test);
		CardMaintenancePage cardMaintenancePage = new CardMaintenancePage(driver, test);
		MaintainCustomerPage customerPage = new MaintainCustomerPage(driver, test);
		String cardNumber;
		
		IFCSloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, cardType);
		
		
		if (clientCountry.equals("RU"))
		{
			 cardNumber = common.getVehicleCardNumberFromDB(clientName + clientCountry);
		}
		else {
		 cardNumber = common.getDriverCardNumberFromDB(clientName + clientCountry);
		}
		
		if (cardNumber.equals(" ") ) {
			common.logForNoDataFound(this.getClass().getSimpleName(),
					"Need to Create A Customer with Card Type and rerun");
		} else {
			IFCSHomePage.gotoCustomerMenuCustomerDetails();
			cardMaintenancePage.updateCardMaintenanceCardControlProfile(cardNumber);

			customerPage.enterDetailsInCardControlsPopUp(clientCountry);
			int row = customerPage.getRowNumberForSelectProfile("Profiles", "Private");
			common.rightClickAndSelectProfile("Profiles", row, "Description");
			common.rightClickDeletePrivateProfileAndValidate("Profiles", "Description");
			common.rightClickAndSelectProfile("Profiles", 0, "Description");
			common.rightClickDeletePrivateProfileAndValidate("Profiles", "Description");

		}
	 
		IFCSHomePage.exitIFCS();
	}

	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test( groups = { "Regression" })
	public void cardMaintenanceUpdateCardFeeProfile(@Optional("RU") String clientCountry,
			@Optional("SHELL") String clientName, @Optional("APA") String cardType) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  SHELL IFCS Card Maintenance-Update Card Fee Profile",
				"Card Maintenance-Update Card Fee Profile");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		Common common = new Common(driver, test);
	
		CardMaintenancePage cardMaintenancePage = new CardMaintenancePage(driver, test);

		IFCSloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, cardType);
		String cardNumber = common.getDriverCardNumberFromDB(clientName + clientCountry);
		if (cardNumber.equals(" ") ) {
			common.logForNoDataFound(this.getClass().getSimpleName(),
					"Need to Create A Customer with Card Type and rerun");
		} else {
			IFCSHomePage.gotoCustomerMenuCustomerDetails();
		    cardMaintenancePage.updateCardMaintenanceCardFeeProfile(cardNumber);
		    common.rightClickDeletePrivateProfileAndValidate("Profile Selection", "Description");

		}
		IFCSHomePage.exitIFCS();

		}
		
	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test( groups = { "Regression" })
	public void nameAndAdressFieldsShouldAcceptSpecialCharaters(@Optional("RU") String clientCountry,
			@Optional("SHELL") String clientName, @Optional("APA") String cardType) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  SHELL IFCS Card Maintenance-Update name,Address field with special characters, "
				+ "Name with special chars, " + "Address field on card maintenance and customeraddress");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		MerchantLocationPage MerchantLocation = new MerchantLocationPage(driver, test);
		CardMaintenancePage cardMaintenancePage = new CardMaintenancePage(driver, test);
		Common common = new Common(driver, test);

		IFCSloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, cardType);
		IFCSHomePage.gotoCustomerMenuCustomerDetails();

//		String customerNumber="";

		String customerNumber = common.getCustomerNoHavingCardsUsingCardType();
		String cardNumber = common.getCardsWithStatusAndWithBalance("Active");

		if (customerNumber.equals("") && cardNumber.equals("")) {
			// need to call method to logfail
			common.logForNoDataFound(this.getClass().getSimpleName(), "Need to Create Customer With Cards and rerun");
		} else {
			cardMaintenancePage.enterCustomerAddressAndCardWithSpecialCharactersAndValidate(customerNumber,
					clientCountry);
			cardMaintenancePage.enterCardAddressAndNameWithSpecialCharactersAndValidate(cardNumber);
			IFCSHomePage.gotoMerchantAndClickMerchantDetails();
			MerchantLocation.updateNameWithSpecialCharacters(clientCountry);

		}

		IFCSHomePage.exitIFCS();

	}

	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test( groups = { "Regression" })
	public void postalCodeFieldsShouldAcceptSpecialCharaters(@Optional("RU") String clientCountry,
			@Optional("SHELL") String clientName, @Optional("APA") String cardType) {
		test = extent.createTest(
				"SHELL IFCS Card Maintenance-Update Post field with special characters,Postal address to include hyphen as listed below");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);

		CardMaintenancePage cardMaintenancePage = new CardMaintenancePage(driver, test);
		Common common = new Common(driver, test);

		IFCSloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, cardType);
		IFCSHomePage.gotoCustomerMenuCustomerDetails();

//		String customerNumber="";

		String customerNumber = common.getCustomerNoHavingCardsUsingCardType();
		String cardNumber = common.getCardsWithStatusAndWithBalance("Active");

		if (customerNumber.equals("") && cardNumber.equals("")) {
			// need to call method to logfail
			common.logForNoDataFound(this.getClass().getSimpleName(), "Need to Create Customer With Cards and rerun");
		} else {
			cardMaintenancePage.enterCustomerPostCodeWithSpecialCharactersAndValidate(customerNumber, clientCountry);
			cardMaintenancePage.enterCardPostCodeWithSpecialCharactersAndValidate(cardNumber, clientCountry);
			IFCSHomePage.gotoMerchantAndClickMerchantDetails();
			cardMaintenancePage.updatePostCodeWithSpecialCharacters(clientCountry);

		}

		IFCSHomePage.exitIFCS();

	}

}
