using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using Common;
using Common.PageObjects;
using Common.ScenarioConfigurations;
using Common.Utility;

namespace EnCompass.Testing.Source.PageObjects.Organization.SecurityManager.Workflow 
{
	/// <summary>
	/// Auto-generated Page Model Class
	/// Navigation Paths: 
		/// [Organization Home]->Security->Workflow Hierarchy->Assign Users
		/// </summary>
	[PageModel(@"/securityManager/workflow/assignNodeToUsers.aspx")]
	public partial class AssignNodeToUsers : EnCompassOrgPageModel 
	{
		public override string RelativeUrl => @"/securityManager/workflow/assignNodeToUsers.aspx";
		public override string PageIdentifierXPath_Generated => @"//li[contains(@class, 'breadcrumb-item active')][text() = 'Assign Users']";

		#region Navigation
				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Create']")]
		private IWebElement _security_WorkflowHierarchy_AssignUsers_Create { get; set; }
		public void NavigateTo_Security_WorkflowHierarchy_AssignUsers_Create()
		{
			NavigateToMenuItem(_security_WorkflowHierarchy_AssignUsers_Create);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Edit']")]
		private IWebElement _security_WorkflowHierarchy_AssignUsers_Edit { get; set; }
		public void NavigateTo_Security_WorkflowHierarchy_AssignUsers_Edit()
		{
			NavigateToMenuItem(_security_WorkflowHierarchy_AssignUsers_Edit);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Assign Users']")]
		private IWebElement _security_WorkflowHierarchy_AssignUsers_AssignUsers { get; set; }
		public void NavigateTo_Security_WorkflowHierarchy_AssignUsers_AssignUsers()
		{
			NavigateToMenuItem(_security_WorkflowHierarchy_AssignUsers_AssignUsers);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='History']")]
		private IWebElement _security_WorkflowHierarchy_AssignUsers_History { get; set; }
		public void NavigateTo_Security_WorkflowHierarchy_AssignUsers_History()
		{
			NavigateToMenuItem(_security_WorkflowHierarchy_AssignUsers_History);
		}

		
		private void NavigateToMenuItem(IWebElement element)
		{
			Driver.Url = element.GetAttribute("href");
		}
		#endregion

		public AssignNodeToUsers(GlobalSettings settings) : base(settings) { }
	}  
}
