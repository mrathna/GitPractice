using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using Common;
using Common.PageObjects;
using Common.ScenarioConfigurations;
using Common.Utility;

namespace EnCompass.Testing.Source.PageObjects.SuperAdmin.AocsuperTools.CustomFaxManagement 
{
	/// <summary>
	/// Auto-generated Page Model Class
	/// Navigation Paths: 
		/// [Organization Home]->Super Admin Tools->Product Support Tools->Custom Fax Management
		/// </summary>
	[PageModel(@"/superAdmin/AOCSuperTools/CustomFaxManagement/CustomFaxManagementRender.aspx")]
	public partial class CustomFaxManagementRender : EnCompassSuperPageModel 
	{
		public override string RelativeUrl => @"/superAdmin/AOCSuperTools/CustomFaxManagement/CustomFaxManagementRender.aspx";
		public override string PageIdentifierXPath_Generated => @"//li[contains(@class, 'breadcrumb-item active')][text() = 'Custom Fax Management']";

		#region Navigation
				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Workflow Analysis']")]
		private IWebElement _superAdminTools_ProductSupportTools_CustomFaxManagement_WorkflowAnalysis { get; set; }
		public void NavigateTo_SuperAdminTools_ProductSupportTools_CustomFaxManagement_WorkflowAnalysis()
		{
			NavigateToMenuItem(_superAdminTools_ProductSupportTools_CustomFaxManagement_WorkflowAnalysis);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Hierarchy Analysis']")]
		private IWebElement _superAdminTools_ProductSupportTools_CustomFaxManagement_HierarchyAnalysis { get; set; }
		public void NavigateTo_SuperAdminTools_ProductSupportTools_CustomFaxManagement_HierarchyAnalysis()
		{
			NavigateToMenuItem(_superAdminTools_ProductSupportTools_CustomFaxManagement_HierarchyAnalysis);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Merchant Log Status']")]
		private IWebElement _superAdminTools_ProductSupportTools_CustomFaxManagement_MerchantLogStatus { get; set; }
		public void NavigateTo_SuperAdminTools_ProductSupportTools_CustomFaxManagement_MerchantLogStatus()
		{
			NavigateToMenuItem(_superAdminTools_ProductSupportTools_CustomFaxManagement_MerchantLogStatus);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Exact Match Management']")]
		private IWebElement _superAdminTools_ProductSupportTools_CustomFaxManagement_ExactMatchManagement { get; set; }
		public void NavigateTo_SuperAdminTools_ProductSupportTools_CustomFaxManagement_ExactMatchManagement()
		{
			NavigateToMenuItem(_superAdminTools_ProductSupportTools_CustomFaxManagement_ExactMatchManagement);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Custom Fax Management']")]
		private IWebElement _superAdminTools_ProductSupportTools_CustomFaxManagement_CustomFaxManagement { get; set; }
		public void NavigateTo_SuperAdminTools_ProductSupportTools_CustomFaxManagement_CustomFaxManagement()
		{
			NavigateToMenuItem(_superAdminTools_ProductSupportTools_CustomFaxManagement_CustomFaxManagement);
		}

		
		private void NavigateToMenuItem(IWebElement element)
		{
			Driver.Url = element.GetAttribute("href");
		}
		#endregion

		public CustomFaxManagementRender(GlobalSettings settings) : base(settings) { }
	}  
}
