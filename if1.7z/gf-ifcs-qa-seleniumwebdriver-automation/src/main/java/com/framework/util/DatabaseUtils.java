package com.framework.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;

public class DatabaseUtils {
	public static String getMySQLConnection(String query, String dbName, String userName, String password)
			throws ClassNotFoundException, SQLException, InterruptedException {
		String returnValue = "";
		String rowValue = "";

		boolean valFound = false;
		System.out.println("DB = '" + dbName + "'  User = '" + userName + "' Pwd = '" + password + "'");
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			// System.out.println("Oracle JDBC Driver Registered!");
		} catch (ClassNotFoundException e) {
			System.out.println("Oracle JDBC Driver not found...");
			returnValue = "Oracle JDBC Driver not found...";
			e.printStackTrace();
			return returnValue;
		}
		Connection con = null;
		try {
			con = DriverManager.getConnection(dbName, userName, password);
		} catch (SQLException e) {
			System.out.println("Connection Failed! Check output console");
			returnValue = "DB Connection Failed! " + "\n" + e.getStackTrace();
			e.printStackTrace();
			return returnValue;
		}
		if (con != null) {
			// System.out.println("You made it, take control your database now!");
			Statement st = con.createStatement();
			// ResultSet rs = st.executeQuery(query);
			int i = 1;
			// **Commented the while loop as first time itself value got retrieved

			// while (i<=10 && valFound == false )
			// {
			// System.out.println("Entering Loop " + i + " valFound " + valFound + "\n");
			// if (i==3) query="select Card.* from ttpa_pdacct card where
			// card.acctid='9100001464084'";

			System.out.println("Query: " + query);

			ResultSet rs = st.executeQuery(query);
			while (rs.next() && valFound == false) {
				int rowCount = rs.getRow();
				if (rowCount == 1) {
					valFound = true;
					returnValue = "true";
					rowValue = rs.getString(rowCount);
				}
			}

			i = i + 1;
			rs.close();
			if (valFound == false)
				Thread.sleep(5000);
			// }

			st.close();
			con.close();
		} else {
			System.out.println("Failed to make connection!");
			returnValue = "Failed to make connection!";
		}

		// return returnValue;
		// Returned the first row alone as String //** Need to Update as processing Rows
		// and Columns
		return rowValue;
	}

	public static String getMySQLConnectionAndGetValueForRowIndex(String query, String dbName, String userName,
			String password, int rowIndex) throws ClassNotFoundException, SQLException, InterruptedException {
		String returnValue = "";
		String rowValue = "";

		boolean valFound = false;
		System.out.println("DB = '" + dbName + "'  User = '" + userName + "' Pwd = '" + password + "'");
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (ClassNotFoundException e) {
			System.out.println("Oracle JDBC Driver not found...");
			returnValue = "Oracle JDBC Driver not found...";
			e.printStackTrace();
			return returnValue;
		}
		Connection con = null;
		try {
			con = DriverManager.getConnection(dbName, userName, password);
		} catch (SQLException e) {
			System.out.println("Connection Failed! Check output console");
			returnValue = "DB Connection Failed! " + "\n" + e.getStackTrace();
			e.printStackTrace();
			return returnValue;
		}
		if (con != null) {
			Statement st = con.createStatement();
			System.out.println("Query: " + query);

			ResultSet rs = st.executeQuery(query);
			while (rs.next() && valFound == false) {
				int rowCount = rs.getRow();
				System.out.println("currentRow: " + rowCount);
				System.out.println("expected Row: " + rowIndex);
				if (rowCount == rowIndex) {
					valFound = true;
					returnValue = "true";
					rowValue = rs.getString(1);
				}
			}

			rs.close();
			if (valFound == false) {
				Thread.sleep(5000);
			}

			st.close();
			con.close();
		} else {
			System.out.println("Failed to make connection!");
			returnValue = "Failed to make connection!";
		}
		return rowValue;
	}

	public static  void executeQueryAndCommit(String query, String dbName, String userName, String password)
			throws ClassNotFoundException, SQLException, InterruptedException {
		/*String returnValue = "";
		String rowValue = "";*/

		System.out.println("DB = '" + dbName + "'  User = '" + userName + "' Pwd = '" + password + "'");
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			// System.out.println("Oracle JDBC Driver Registered!");
		} catch (ClassNotFoundException e) {
			System.out.println("Oracle JDBC Driver not found...");
		//	returnValue = "Oracle JDBC Driver not found...";
			e.printStackTrace();
		//	return returnValue;
		}
		Connection con = null;
		try {
			con = DriverManager.getConnection(dbName, userName, password);
		} catch (SQLException e) {
			System.out.println("Connection Failed! Check output console");
			//returnValue = "DB Connection Failed! " + "\n" + e.getStackTrace();
			e.printStackTrace();
		//	return returnValue;
		}
		if (con != null) {
			// System.out.println("You made it, take control your database now!");
			Statement st = con.createStatement();
			// ResultSet rs = st.executeQuery(query);
			// int i = 1;
			// **Commented the while loop as first time itself value got retrieved

			// while (i<=10 && valFound == false )
			// {
			// System.out.println("Entering Loop " + i + " valFound " + valFound + "\n");
			// if (i==3) query="select Card.* from ttpa_pdacct card where
			// card.acctid='9100001464084'";

			System.out.println("Query: " + query);
			st.executeQuery(query);
			// ResultSet rs = st.executeQuery(query);
			// while (rs.next() && valFound == false) {
			// int rowCount = rs.getRow();
			// if (rowCount == 1) {
			// valFound = true;
			// returnValue = "true";
			// rowValue = rs.getString(rowCount);
			// }
			// }
			// i = i + 1;
			// rs.close();
			// if (valFound == false)
			// Thread.sleep(5000);
			// }
			con.commit();
			st.close();
			con.close();
		} else {
			System.out.println("Failed to make connection!");
			//returnValue = "Failed to make connection!";
		}

		// return returnValue;
		// Returned the first row alone as String //** Need to Update as processing Rows
		// and Columns
		//return rowValue;
	}
public static String[] getMySQLConnectionAndGetResultSetValue(String query, String dbName, String userName,
			String password) throws ClassNotFoundException, SQLException, InterruptedException {
		String resultSetArray[] = new String[1];
		System.out.println("DB = '" + dbName + "'  User = '" + userName + "' Pwd = '" + password + "'");
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			// System.out.println("Oracle JDBC Driver Registered!");
		} catch (ClassNotFoundException e) {
			System.out.println("Oracle JDBC Driver not found...");
			resultSetArray[0] = "Oracle JDBC Driver not found...";
			e.printStackTrace();
			return resultSetArray;
		}
		Connection con = null;
		try {
			con = DriverManager.getConnection(dbName, userName, password);
		} catch (SQLException e) {
			System.out.println("Connection Failed! Check output console");
			resultSetArray[0] = "DB Connection Failed! " + "\n" + e.getStackTrace();
			e.printStackTrace();
			return resultSetArray;
		}
		if (con != null) {
			// System.out.println("You made it, take control your database now!");
			Statement st = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE,
				    ResultSet.CONCUR_READ_ONLY);
			// ResultSet rs = st.executeQuery(query);
			int i = 0;
			
			ResultSet rs = st.executeQuery(query);
			int rowCount = 0;
			if (rs != null) 
			{
			  rs.beforeFirst();
			  rs.last();
			  rowCount = rs.getRow();
			}
			resultSetArray = new String[rowCount];
			
			 rs.beforeFirst();
			while (rs.next()) {
				System.out.println("Query: " + rs.getString(1));
				resultSetArray[i] = rs.getString(1);
				i++;
			}

			//resultSetArray = new String[i];
			rs.close();

			st.close();
			con.close();
		} else {
			System.out.println("Failed to make connection!");
			resultSetArray[0] = "Failed to make connection!";
		}

		// return returnValue;
		// Returned the first row alone as String //** Need to Update as processing Rows
		// and Columns
		return resultSetArray;
	}

public static String[] getMySQLConnectionAndGetResultSetValue(String query,int nofRows, String dbName, String userName,
		String password) throws ClassNotFoundException, SQLException, InterruptedException {
	String resultSetArray[] = new String[1];
	System.out.println("DB = '" + dbName + "'  User = '" + userName + "' Pwd = '" + password + "'");
	try {
		Class.forName("oracle.jdbc.driver.OracleDriver");
		// System.out.println("Oracle JDBC Driver Registered!");
	} catch (ClassNotFoundException e) {
		System.out.println("Oracle JDBC Driver not found...");
		resultSetArray[0] = "Oracle JDBC Driver not found...";
		e.printStackTrace();
		return resultSetArray;
	}
	Connection con = null;
	try {
		con = DriverManager.getConnection(dbName, userName, password);
	} catch (SQLException e) {
		System.out.println("Connection Failed! Check output console");
		resultSetArray[0] = "DB Connection Failed! " + "\n" + e.getStackTrace();
		e.printStackTrace();
		return resultSetArray;
	}
	if (con != null) {
		// System.out.println("You made it, take control your database now!");
		Statement st = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE,
			    ResultSet.CONCUR_READ_ONLY);
		// ResultSet rs = st.executeQuery(query);
		int i = 0;
		
		ResultSet rs = st.executeQuery(query);
		int rowCount = 0;
		if (rs != null) 
		{
		  rs.beforeFirst();
		  rs.last();
		  rowCount = rs.getRow();
		}
		resultSetArray = new String[rowCount];
		
		 rs.beforeFirst();
		while (rs.next()&i<nofRows) {
			System.out.println("Query: " + rs.getString(1));
			resultSetArray[i] = rs.getString(1);
			i++;
		}

		//resultSetArray = new String[i];
		rs.close();

		st.close();
		con.close();
	} else {
		System.out.println("Failed to make connection!");
		resultSetArray[0] = "Failed to make connection!";
	}

	// return returnValue;
	// Returned the first row alone as String //** Need to Update as processing Rows
	// and Columns
	return resultSetArray;
}

	public static Map<String,String> getMySQLConnectionAndEntireRowValue(String query, String dbName, String userName, String password)
			throws ClassNotFoundException, SQLException, InterruptedException {
		String returnValue = "";
		String colValues = "";
		String colHeaderName = "";
		Map<String, String> tableName = new LinkedHashMap<String, String>();

		boolean valFound = false;
		System.out.println("DB = '" + dbName + "'  User = '" + userName + "' Pwd = '" + password + "'");
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (ClassNotFoundException e) {
			System.out.println("Oracle JDBC Driver not found...");
			returnValue = "Oracle JDBC Driver not found...";
			e.printStackTrace();
			tableName.put("Error", returnValue);
			return tableName;
		}
		Connection con = null;
		try {
			con = DriverManager.getConnection(dbName, userName, password);
		} catch (SQLException e) {
			System.out.println("Connection Failed! Check output console");
			returnValue = "DB Connection Failed! " + "\n" + e.getStackTrace();
			e.printStackTrace();
			tableName.put("Error", returnValue);
			return tableName;
		}
		if (con != null) {
			Statement st = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE,
				    ResultSet.CONCUR_READ_ONLY
					);
			int i = 1;

			System.out.println("Query: " + query);

			ResultSet rs = st.executeQuery(query);

			ResultSetMetaData rsmd = rs.getMetaData();

			while (rs.next() && valFound == false) {
				//rs.last();
				int rowCount = rs.getRow();
				System.out.println("rowCount"+ rowCount);
				//rs.beforeFirst();
				int columnCount = rsmd.getColumnCount();
				System.out.println("columnCount : " + columnCount);
				//if (rowCount == 1) {
				//for(int j=0;j<rowCount;j++) {
					valFound =  true;
					returnValue = "true";
					//rs.next();
					//rs.getRow();
					for (int c = 1; c <= columnCount; c++) {
						colHeaderName = rsmd.getColumnName(c);
						colValues = rs.getString(c);
						tableName.put(colHeaderName, colValues);
						System.out.println("colHeaderName : " + colHeaderName + " " + "colValues : " + colValues);
					}
				//}
				
		  }

			i = i + 1;
			rs.close();
			if (valFound == false)
				Thread.sleep(5000);
			System.out.println("tableName::"+tableName);
			st.close();
			con.close();
		} else {
			System.out.println("Failed to make connection!");
			returnValue = "Failed to make connection!";
			tableName.put("Error", returnValue);
			return tableName;
		}

		return tableName;
	}
	public static ArrayList<String> getMySQLConnectionAndEntireColumnValues(String query, String dbName, String userName, String password)
			throws ClassNotFoundException, SQLException, InterruptedException {
		String returnValue = "";
		String colValues = "";
		String colHeaderName = "";
		ArrayList<String> columnValues = new ArrayList<String>();

		boolean valFound = false;
		System.out.println("DB = '" + dbName + "'  User = '" + userName + "' Pwd = '" + password + "'");
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (ClassNotFoundException e) {
			System.out.println("Oracle JDBC Driver not found...");
			returnValue = "Oracle JDBC Driver not found...";
			e.printStackTrace();
			columnValues.add( returnValue);
			return columnValues;
		}
		Connection con = null;
		try {
			con = DriverManager.getConnection(dbName, userName, password);
		} catch (SQLException e) {
			System.out.println("Connection Failed! Check output console");
			returnValue = "DB Connection Failed! " + "\n" + e.getStackTrace();
			e.printStackTrace();
			columnValues.add(returnValue);
			return 	columnValues;
		}
		if (con != null) {
			Statement st = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE,
				    ResultSet.CONCUR_READ_ONLY
					);
			int i = 1;

			System.out.println("Query: " + query);

			ResultSet rs = st.executeQuery(query);

			ResultSetMetaData rsmd = rs.getMetaData();

			while (rs.next() && valFound == false) {
				rs.last();
				int rowCount = rs.getRow();
				System.out.println("rowCount"+ rowCount);
				rs.beforeFirst();
				int columnCount = rsmd.getColumnCount();
				System.out.println("columnCount : " + columnCount);
				//if (rowCount == 1) {
				for(int j=0;j<rowCount;j++) {
					valFound =  true;
					returnValue = "true";
					rs.next();
					rs.getRow();
					for (int c = 1; c <= columnCount; c++) {
						colHeaderName = rsmd.getColumnName(c);
						colValues = rs.getString(c);
						columnValues.add(colValues);
						System.out.println("colHeaderName : " + colHeaderName + " " + "colValues : " + colValues);
					}
				}
				
		  }

			i = i + 1;
			rs.close();
			if (valFound == false)
				Thread.sleep(5000);
			System.out.println("tableName::"+columnValues);
			st.close();
			con.close();
		} else {
			System.out.println("Failed to make connection!");
			returnValue = "Failed to make connection!";
			columnValues.add(returnValue);
			return columnValues;
		}

		return columnValues;
	}	
	

}
			
			
			
