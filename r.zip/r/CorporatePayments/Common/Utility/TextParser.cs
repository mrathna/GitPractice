﻿using AventStack.ExtentReports;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Common.Utility
{
	public class TextParser
	{
		public static String ParseFileAsText(string fPath, string fName)
		{			
			using (StreamReader reader = new StreamReader(Path.Combine(fPath, fName)))
			{				
				return reader.ReadToEnd();
			}			
		}

        /// <summary>
        /// Parse the file indicated at the path as a txt file and then search for each Line in the file which has the Key
        /// and verify if the same line contains the value of the Dictiorary object
        /// 
        /// Note - this is created for verifying NACHA Summary files in NonCardPayments flow
        /// </summary>
        public static void ParseFileAsTextToVerifyContent(string fPath, string fName, Dictionary<string, string[]> contentKeyVals, ExtentTest test)
        {
            test.Info("Searching for Contents in the file : " + Path.Combine(fPath, fName));

            //Iterate over each element in the dictionary as a list of KeyValuePair

            contentKeyVals.ToList().ForEach(d =>
            {
                using (StreamReader reader = new StreamReader(Path.Combine(fPath, fName)))
                {
                    bool[] _contentFound = new bool[d.Value.Count()];
                    while (!reader.EndOfStream)
                    {
                        string line = reader.ReadLine();
                        //if a content key is found in a specific line then search for the value in the same line
                        if (line.Contains(d.Key))
                        {
                            for (int i = 0; i < d.Value.Count(); ++i)
                            {
                                if (line.Contains(d.Value[i]))
                                {
                                    {
                                        test.Info("Found the Key :" + d.Key + " with value : " + d.Value[i] + " in the file.");
                                        _contentFound[i] = true;
                                        break;
                                    }
                                }
                            }
                        }
						else
						{
							// if already reached end of stream and still no Key is found then
							if (reader.EndOfStream)
								test.Info("Not Found the Key :" + d.Key + " in the file. Hence no values to match to");
						}
					}

                    for (int i = 0; i < _contentFound.Count(); ++i)
                        if (_contentFound[i] == false)
                            throw new Exception($"The key {d.Key} matched no results in the file for the value {d.Value[i]}");
                }
            });
        }

        /// <summary>
        /// Parse the file indicated at the path and then store each line from start position to the length specified as parameters
        /// and returns the result in list
        /// </summary>
        public static List<string> ParseFileAsTextToVerifyContentInColumns(string fPath, string fName, int startPosition, int Lenght, ExtentTest test)
        {
            test.Info("Searching for Contents in the file : " + Path.Combine(fPath, fName));
            //Iterate over each element in the dictionary as a list of KeyValuePair

            using (StreamReader reader = new StreamReader(Path.Combine(fPath, fName)))
            {
                List<string> lstValue = new List<string>();
                int lineNumber = 1;
                while (!reader.EndOfStream)
                {
                    string line = reader.ReadLine();
                    line = line.Substring(startPosition, Lenght);
                    test.Info("Value readed in file: " + fName + " the line " + lineNumber + ": " + line);
                    lstValue.Add(line);
                    lineNumber++;
                }
                return lstValue;
            }
        }

        /// <summary>
        /// Parse the file indicated at the path as a txt file and then search for each Line in the file which has the Key and Mlog ID
        /// and verify if the same line contains the value of the Dictiorary object
        /// </summary>
        public static void ParseFileAsTextToVerifyContentMLog(string fPath, string fName, Dictionary<string, string> contentKeyVals, ExtentTest test, string mLogId)
        {
            test.Info("Searching for Contents in the file : " + Path.Combine(fPath, fName));

            //Iterate over each element in the dictionary as a list of KeyValuePair
            List<bool> _contentFound = new List<bool>();

            contentKeyVals.ToList().ForEach(d =>
            {
                using (StreamReader reader = new StreamReader(Path.Combine(fPath, fName)))
                {
                    bool mLogIdFound = false;
                    while (!reader.EndOfStream)
                    {
                        string line = reader.ReadLine();

                        if (line.Contains(mLogId))
                        {
                            mLogIdFound = true;
                        }
                        else
                        {
                            // if already reached end of stream and still no Key is found then
                            if (reader.EndOfStream)
                            {
                                test.Info("Not Found the MLogId: " + mLogId + " in the file. Hence no values to match to");
                                _contentFound.Add(false);
                            }
                        }

                        //if a content key is found in a specific line then search for the value in the same line
                        if (line.Contains(d.Key) && mLogIdFound)
                        {
                            if (line.Contains(d.Value))
                            {
                                test.Info("Found the Key: " + d.Key + " with value: " + d.Value + " in the file.");
                                _contentFound.Add(true);
                            }
                            else
                            {
                                _contentFound.Add(false);
                            }

                            break;
                        }
                        else
                        {
                            // if already reached end of stream and still no Key is found then
                            if (reader.EndOfStream)
                            {
                                test.Info("Not Found the Key: " + d.Key + " in the file. Hence no values to match to");
                                _contentFound.Add(false);
                            }
                        }
                    }
                }
            });

            if (_contentFound.Contains(false))
                throw new Exception($"One of the key has no matched results in the file");
        }
    }
}
