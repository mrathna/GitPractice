﻿using Common;
using Common.Utility;
using NFluent;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using System.IO;

namespace EnCompass.Testing.Source.PageObjects.Organization.ReportStudio.StandardReports
{
    [PageModel(@"/reportStudio/standardReports/MerchantAuditReport.aspx")]
    public class MerchantAuditReport : EnCompassPageModel
    {
        public MerchantAuditReport(GlobalSettings settings) : base(settings) { ScheduleReport = new ScheduleReport(Driver, settings); }

        public override string RelativeUrl => @"/ReportStudio/standardReports/MerchantAuditReport.aspx";
        public override string PageIdentifierXPath_Override => @"//li[@class='breadcrumb-item active'][text() = 'Merchant Audit']";
        public ScheduleReport ScheduleReport { get; set; }

        #region XPath page Elements
        private const string _formatListXPath = @"//select[contains(@id, 'FormatList')]";
        private const string _merchantCreateListXPath = @"//select[contains(@id, 'CreateDateRanges_ddlOptions')]";
        private const string _modifiedBetweenListXPath = @"//select[contains(@id, 'ModifiedDateRanges_ddlOptions')]";
        private const string _merchantCreatePeriodListXPath = @"//select[contains(@id, 'CreateDateRanges_ddlPeriod')]";
        private const string _modifiedBetweenPeriodListXPath = @"//select[contains(@id, 'ModifiedDateRanges_ddlPeriod')]";
        private const string _merchantDropDownXPath = @"//select[contains(@id, 'MerchantDropDown')]";
        private const string _executeRunXPath = @"//input[contains(@id,'StdReport_RunButton')]";
        private const string _activeMerchantCheckXPath = @"//input[contains(@id,'CBXmerchantActive')]";
        private const string _activeMerchantCheckLabelXPath = @"//label[contains(@for,'CBXmerchantActive')]";
        private const string _inactiveMerchantCheckXPath = @"//input[contains(@id,'CBXmerchantInactive')]";
        private const string _inactiveMerchantCheckLabelXPath = @"//label[contains(@for,'CBXmerchantInactive')]";
        #endregion

        
        #region Page Elements
        private IWebElement _formatList
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_formatListXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_formatList element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _merchantCreateList
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_merchantCreateListXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_merchantCreateList element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _modifiedBetweenList
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_modifiedBetweenListXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_modifiedBetweenList element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _merchantCreatePeriodList
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_merchantCreatePeriodListXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_merchantCreatePeriodList element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _modifiedBetweenPeriodList
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_modifiedBetweenPeriodListXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_modifiedBetweenPeriodList element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _merchantDropDown
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_merchantDropDownXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_merchantDropDown element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _executeRun
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_executeRunXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_executeRun element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _activeMerchantCheck
        {
            get
            {
                bool found = Driver.TryFindElement(By.XPath(_activeMerchantCheckXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_activeMerchantCheck element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _activeMerchantCheckLabel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_activeMerchantCheckLabelXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_activeMerchantCheckLabel element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _inactiveMerchantCheck
        {
            get
            {
                bool found = Driver.TryFindElement(By.XPath(_inactiveMerchantCheckXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_inactiveMerchantCheck element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _inactiveMerchantCheckLabel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_inactiveMerchantCheckLabelXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_inactiveMerchantCheckLabel element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        #endregion

        public string FormatList
        {
            get => new SelectElement(_formatList).SelectedOption.Text;
            set => new SelectElement(_formatList).SelectByText(value);
        }

        public string MerchantCreateList
        {
            get => new SelectElement(_merchantCreateList).SelectedOption.Text;
            set => new SelectElement(_merchantCreateList).SelectByText(value);
        }

        public string ModifiedBetweenList
        {
            get => new SelectElement(_modifiedBetweenList).SelectedOption.Text;
            set => new SelectElement(_modifiedBetweenList).SelectByText(value);
        }

        public string MerchantCreatePeriodList
        {
            get => new SelectElement(_merchantCreatePeriodList).SelectedOption.Text;
            set => new SelectElement(_merchantCreatePeriodList).SelectByText(value);
        }

        public string ModifiedBetweenPeriodList
        {
            get => new SelectElement(_modifiedBetweenPeriodList).SelectedOption.Text;
            set => new SelectElement(_modifiedBetweenPeriodList).SelectByText(value);
        }

        public string MerchantDropDown
        {
            get => new SelectElement(_merchantDropDown).SelectedOption.Text;
            set => new SelectElement(_merchantDropDown).SelectByText(value);
        }

        public void Run()
        {
            _executeRun.JSClickWithFocus(Driver);
        }

        public void GenerateMerchantAuditReport(string reportFormat)
        {
            FormatList = reportFormat;

            MerchantCreateList = "Period";
            MerchantCreatePeriodList = "Today";
            ModifiedBetweenList = "Period";
            ModifiedBetweenPeriodList = "Today";

            MerchantDropDown = "All";

            _activeMerchantCheck.SetCheckboxStateWithLabel(_activeMerchantCheckLabel, true);
            _inactiveMerchantCheck.SetCheckboxStateWithLabel(_inactiveMerchantCheckLabel, true);

            Settings.EnCompassExtentTest.Info("Mlog Audit Report parameters set");

            var fileName = @"MerchantAudit";

            string absPathToTemplateDir = PathHelper.GetAbsolutePathRelativeToProjectPath(GlobalSettings.TemplateRelativePath);
            string fileAbsPath = Path.Combine(absPathToTemplateDir, fileName);

            if (reportFormat == "Adobe PDF (.PDF)")
                fileAbsPath += ".pdf";
            else if (reportFormat == "Excel 97-2003(xls)")
                fileAbsPath += ".xls";
            else if (reportFormat == "Comma-Separated Values (.CSV)")
                fileAbsPath += ".txt";

            Settings.EnCompassExtentTest.Info("Merchant Audit Report download name composed");

            this.Run();
            new WebDriverWait(Driver, TimeSpan.FromSeconds(60)).Until(d => File.Exists(fileAbsPath));

            Settings.EnCompassExtentTest.Info("Merchant Audit Report generated and downloaded to: " + fileAbsPath);

        }

    }

}
