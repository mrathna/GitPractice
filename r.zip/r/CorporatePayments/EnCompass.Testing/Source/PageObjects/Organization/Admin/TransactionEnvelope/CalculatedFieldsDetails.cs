﻿using Common;
using Common.Utility;
using NFluent;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Support.UI;
using System.Collections.Generic;

namespace EnCompass.Testing.Source.PageObjects.Organization.Admin.TransactionEnvelope
{
	[PageModel(@"/admin/transactionEnvelope/CalculatedFieldsDetails.aspx")]
	public partial class CalculatedFieldsDetails : EnCompassPageModel
	{

		public override string RelativeUrl => @"/admin/transactionEnvelope/CalculatedFieldsDetails.aspx";
		public override string PageIdentifierXPath_Override => @"//h1[normalize-space(text())='Envelope Calculated Field Details' or text()='Create a Calculated Field']";

        #region XPath page Elements

        private const string _fieldNameXPath = @"//input[contains(@id, 'fieldName')]";
        private const string _unitNameXPath = @"//input[contains(@id, 'unitName')]";
        private const string _selectCurrencyXPath = @"//select[contains(@id, 'ddlCurrency')]";
        private const string _isActiveCheckboxXPath = @"//input[contains(@id, 'isActive')]";
        private const string _isActiveCheckboxLabelXPath = @"//label[contains(@for, 'isActive')]";
        private const string _useThresholdCheckboxXPath = @"//input[contains(@id, 'useThreshold')]";
        private const string _useThresholdCheckboxLabelXPath = @"//label[contains(@for, 'useThreshold')]";
        private const string _useEffectiveDtCheckboxXPath = @"//input[contains(@id, 'useEffectiveDt')]";
        private const string _useEffectiveDtCheckboxLabelXPath = @"//label[contains(@for, 'useEffectiveDt')]";
        private const string _allowRateOverrideCheckboxXPath = @"//input[contains(@id, 'allowRateOverride')]";
        private const string _allowRateOverrideCheckboxLabelXPath = @"//label[contains(@for, 'allowRateOverride')]";
        private const string _txtRateXPath = @"//input[contains(@id, '_Rate')]";
        private const string _txtThresholdXPath = @"//input[contains(@id, 'Threshold') and @type='text']";
        private const string _saveXPath = @"//input[contains(@id,'cmdSaveField')]";
        private const string _txtEffectiveDtXPath = @"//input[contains(@id, 'EffectiveDt') and @type='text']";
        private const string _successMessageXPath = ".//div[contains(@id,'amSuccessMessage')]";
        private const string _addNewXPath = @"//a[contains(@id,'lbAddNew') and text()=' Create']";
        #endregion

        #region Page Elements
		private IWebElement _fieldName
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_fieldNameXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_fieldName element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _unitName
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_unitNameXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_unitName element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _selectCurrency
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_selectCurrencyXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_selectCurrency element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _isActiveCheckbox
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_isActiveCheckboxXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_isActiveCheckbox element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _isActiveCheckboxLabel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_isActiveCheckboxLabelXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_isActiveCheckboxLabel element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _useThresholdCheckbox
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_useThresholdCheckboxXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_useThresholdCheckbox element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _useThresholdCheckboxLabel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_useThresholdCheckboxLabelXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_useThresholdCheckboxLabel element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _useEffectiveDtCheckbox
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_useEffectiveDtCheckboxXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_useEffectiveDtCheckbox element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _useEffectiveDtCheckboxLabel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_useEffectiveDtCheckboxLabelXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_useEffectiveDtCheckboxLabel element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _allowRateOverrideCheckbox
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_allowRateOverrideCheckboxXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_allowRateOverrideCheckbox element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _allowRateOverrideCheckboxLabel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_allowRateOverrideCheckboxLabelXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_allowRateOverrideCheckboxLabel element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _txtRate
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_txtRateXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_txtRate element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _txtThreshold
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_txtThresholdXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_txtThreshold element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _save
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_saveXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_save element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _txtEffectiveDt
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_txtEffectiveDtXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_txtEffectiveDt element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _successMessage
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_successMessageXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_successMessage element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _addNew
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_addNewXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_addNew element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        #endregion

        public string FieldName
		{
			get { return _fieldName.GetAttribute("value"); }
			set { _fieldName.Clear(); _fieldName.SendKeys(value); }
		}

		public string UnitName
		{
			get { return _unitName.GetAttribute("value"); }
			set { _unitName.Clear(); _unitName.SendKeys(value); }
		}

		public void SetCurrency(string whichText)
		{
			var selectElement = new SelectElement(_selectCurrency);
			selectElement.SelectByText(whichText);
		}

		public string TxtThreshold
		{
			get { return _txtThreshold.GetAttribute("value"); }
			set { _txtThreshold.Clear(); _txtThreshold.SendKeys(value); }
		}

		public string TxtEffectiveDate
		{
			get { return _txtEffectiveDt.GetAttribute("value"); }
			set { _txtEffectiveDt.Clear(); _txtEffectiveDt.SendKeys(value); }
		}

		public string TxtRate
		{
			get { return _txtRate.GetAttribute("value"); }
			set { _txtRate.Clear(); _txtRate.SendKeys(value); }
		}

		public void PressSave()
		{
			_save.JSClickWithFocus(Driver);
            WaitForFormLoadingOverlay();
			this.AttachOnDemandScreenShot();
		}

		public string EnvelopeCalculatedFieldSuccessMessage
		{
			get
			{
				return _successMessage.Text.Trim();
			}
		}
        
		public void PressAddNew()
		{
			_addNew.JSClickWithFocus(Driver);
            WaitForFormLoadingOverlay();
        }

		public bool SetActive
		{
			set
			{
				_isActiveCheckbox.SetCheckboxStateWithLabel(_isActiveCheckboxLabel, value);
			}
		}

		public bool EnableThreshold
		{
			set
			{
				_useThresholdCheckbox.SetCheckboxStateWithLabel(_useThresholdCheckboxLabel, value);
                if (value)
                    WaitForFormLoadingOverlay();
            }
		}

		public bool EnableEffectiveDates
		{
			set
			{
				_useEffectiveDtCheckbox.SetCheckboxStateWithLabel(_useEffectiveDtCheckboxLabel, value);
                if (value)
                    WaitForFormLoadingOverlay();
            }
		}

		public bool EnableRateOverride
		{
			set
			{
				_allowRateOverrideCheckbox.SetCheckboxStateWithLabel(_allowRateOverrideCheckboxLabel, value);
            }
		}

		/// <summary>
		/// This method fills the Calculated fields for OOP Transactions that is using threshold. 
		/// </summary>
		public void AddCalculatedUsingThresholds(string fieldName, string unitNamebox, List<string> thresholdList, List<string> rateList)
		{
			FieldName = fieldName;
			UnitName = unitNamebox;
			SetCurrency("USD - US dollar");
			SetActive = true;
			EnableThreshold = true;
            EnableEffectiveDates = false;
            EnableRateOverride = false;

            for (int i = 0; i < thresholdList.Count; i++)
			{
				var ElementThreshold = Driver.FindElement(By.XPath($@"(//input[contains(@id, 'Threshold') and @type='text'])[{i+1}]"));
				ElementThreshold.Clear();
				ElementThreshold.SendKeys(thresholdList[i]);

				var ElementRate = Driver.FindElement(By.XPath($@"(//input[contains(@id, '_Rate')])[{i+1}]"));
				ElementRate.Clear();
				ElementRate.SendKeys(rateList[i]);

				if(i != thresholdList.Count-1)
					PressAddNew();                
            }
		}

        /// <summary>
        /// This method adds the Calculated fields for OOP Transactions that is using effective date. 
        /// </summary>
		public void AddCalculatedUsingEffectiveDateList(string fieldName, string unitNamebox, List<string> effectiveDateList, List<string> rateList)
		{            
			FieldName = fieldName;
			UnitName = unitNamebox;
			SetCurrency("USD - US dollar");
			SetActive = true;
			EnableThreshold = false;
            EnableEffectiveDates = true;
            EnableRateOverride = false;

            for (int i = 0; i < effectiveDateList.Count; i++)
			{
				var ElementThreshold = Driver.FindElement(By.XPath($@"(//input[contains(@id, 'EffectiveDt') and @type='text'])[{i + 1}]"));
				ElementThreshold.Clear();
				ElementThreshold.SendKeys(effectiveDateList[i]);

				var ElementRate = Driver.FindElement(By.XPath($@"(//input[contains(@id, '_Rate')])[{i + 1}]"));
				ElementRate.Clear();
				ElementRate.SendKeys(rateList[i]);

                if (i != effectiveDateList.Count - 1)
                    PressAddNew();
              
            }
		}

        /// <summary>
        /// This method adds the Calculated fields for OOP Transactions that is using treshold, effective date and rate override. 
        /// </summary>
		public void AddCalculatedUsingThresholdEffectiveDateOverrideList(string fieldName, string unitNamebox, List<string> thresholdList, List<string> effectiveDateList, List<string> rateList)
		{
			FieldName = fieldName;
			UnitName = unitNamebox;
			SetCurrency("USD - US dollar");
			SetActive = true;
			EnableThreshold = true;
            EnableEffectiveDates = true;
            EnableRateOverride = true;

            for (int i = 0; i < effectiveDateList.Count; i++)
			{
				var ElementThreshold = Driver.FindElement(By.XPath($@"(//input[contains(@id, 'Threshold') and @type='text'])[{i + 1}]"));
				ElementThreshold.Clear();
				ElementThreshold.SendKeys(thresholdList[i]);

				var effectiveDate = Driver.FindElement(By.XPath($@"(//input[contains(@id, 'EffectiveDt') and @type='text'])[{i + 1}]"));
				effectiveDate.Clear();
				effectiveDate.SendKeys(effectiveDateList[i]);

				var ElementRate = Driver.FindElement(By.XPath($@"(//input[contains(@id, '_Rate')])[{i + 1}]"));
				ElementRate.Clear();
				ElementRate.SendKeys(rateList[i]);

				if (i != effectiveDateList.Count - 1)
					PressAddNew();
            }
		}		

		public CalculatedFieldsDetails(GlobalSettings settings) : base(settings) { }
	}
}
