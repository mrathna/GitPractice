package com.framework.testcases.OLS.CHEV.Location;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.CHEV.CHContactUsPage;
import com.framework.pages.CHEV.CHHomePage;
import com.framework.pages.CHEV.CHPasswordMaintenancePage;
import com.framework.pages.CHEV.CHTransactionPage;
import com.framework.pages.OLS.common.CommonPage;
import com.framework.pages.OLS.common.LoginPage;

/***
 * 
 * We need to change credentials for for PH and TH
 *
 */

public class ValidateOLSMerchantLocationSiteSupport extends BaseTest {
	@Parameters({ "clientCountry", "clientName" })
	@Test(priority = 1)
	public void testOLSMerchantLocationSiteSupport(@Optional("SG") String clientCountry, @Optional("CHV") String clientName) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  OLS - All Location Site - Support",
				"Chevron Merchant Screens Location Site Read Only");

		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		CHHomePage chHomePage = new CHHomePage(driver, test);
		CommonPage commonPage = new CommonPage(driver, test);
		CHContactUsPage chContactUsPage = new CHContactUsPage(driver, test);
		CHTransactionPage chTransactionPage = new CHTransactionPage(driver, test);
		CHPasswordMaintenancePage chPasswordMaintenancePage = new CHPasswordMaintenancePage(driver, test);

		if (clientCountry.equals("SG")||clientCountry.equals("MY")||clientCountry.equals("HK")) {
			loginPage.Login("CHV_URL", "CHV_Location_UN_"+clientCountry, "CHV_Location_PWD_"+clientCountry, clientName);			
			
		} else if (clientCountry.equals("TH")) {
			loginPage.Login("CHV_URL", "CHV_Location_UN_"+clientCountry, "CHV_Location_PWD_"+clientCountry, clientName);

		} else if (clientCountry.equals("PH")) {
			loginPage.Login("CHV_URL", "CHV_Location_UN_"+clientCountry, "CHV_Location_PWD_"+clientCountry, clientName);

		}

		chHomePage.verifyUserNameAndLogoutLink();
		chHomePage.verifyMerchantAccountDetails();
		chHomePage.clickOnLocationTransactionLink();
		chTransactionPage.verifyTransactionPage();
		chHomePage.clickOnHome();
		chHomePage.clickOnExportTransactionLink();
		
		//commonPage.isFileDownloaded("0700031161__20190408_");
		//chHomePage.checkForFileDownload(1);
		String checkFileDate=chHomePage.validateDateInDownloadedFile();
		commonPage.isFileDownloaded(checkFileDate);
		// Change Password
		chHomePage.loadFindAndFindPasswordPage();
		chPasswordMaintenancePage.verifyPageSubtitles();

		//Contact Us
		chHomePage.loadFindAndContactUsPage();
		chHomePage.verifyFooterPageLinks();
		chContactUsPage.verifyContactUsFields();
		chContactUsPage.enterRandomValuesAndValidate("merchant");

		// Below functions are commented - due to page fields changed 
	/*	chHomePage.verifyFooterLinks();

		chContactUsPage.enterRandomValuesExceptEnquiryType();
		chContactUsPage.clickSubmitButton();
		chContactUsPage.verifyErrorMessage("Query Type");

		chContactUsPage.enterRandomValuesExceptComments();
		chContactUsPage.clickSubmitButton();
		chContactUsPage.verifyErrorMessage("Comment required");

		chContactUsPage.enterRandomValuesExceptContactName();
		chContactUsPage.clickSubmitButton();
		chContactUsPage.verifyErrorMessage("Validation failed");

		chContactUsPage.enterRandomValuesExceptPhoneNo();
		chContactUsPage.clickSubmitButton();
		chContactUsPage.verifyErrorMessage("Validation failed");

		chContactUsPage.enterRandomValuesExceptEmail();
		chContactUsPage.clickSubmitButton();
		chContactUsPage.verifyErrorMessage("Email Required");

		chContactUsPage.enterRandomValuesWithIncorrectEmail();
		chContactUsPage.clickSubmitButton();
		chContactUsPage.verifyErrorMessage("Validation failed");

		chContactUsPage.enterRandomValues();
		chContactUsPage.clickSubmitButton();
		chContactUsPage.checkConfirmationMessage(); */

		
	}
}
