﻿using Common;
using Common.Utility;
using NFluent;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Support.UI;
using System;

namespace EnCompass.Testing.Source.PageObjects.Organization.Admin.AccountProfiles
{
    [PageModel(@"/admin/accountProfiles/viewUserProfile.aspx")]
    public class ViewUserProfile : EnCompassOrgPageModel
    {
        public override string RelativeUrl => @"/admin/accountProfiles/viewUserProfile.aspx";
        public override string PageIdentifierXPath_Override => @"//h1[contains(@id,'title')]";

        #region XPath page Elements

        private const string _viewUserProfileXPath = @"(//div[@class='card-body']//ul[@class='list-unstyled']//li)[1]";
        private const string _backXPath = @"//input[contains(@id,'backButton')]";
        #endregion

        #region Page Elements
        private IWebElement _viewUserProfile
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_viewUserProfileXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_viewUserProfile element exist is {found}");
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Info("Found _viewUserProfile");
                return element;
            }
        }

        private IWebElement _back
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_backXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_back element exist is {found}");
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Info("Found _back");
                return element;
            }
        }
        #endregion

        public void CheckViewUserProfile()
        {
            Check.That(_viewUserProfile).IsNotNull();
        }

        public void BackManageUserProfiles()
        {
            _back.JSClickWithFocus(Driver);
        }

        public ViewUserProfile(GlobalSettings settings) : base(settings) { }
    }
}