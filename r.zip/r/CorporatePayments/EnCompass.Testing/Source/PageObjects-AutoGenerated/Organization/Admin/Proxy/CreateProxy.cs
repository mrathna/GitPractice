using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using Common;
using Common.PageObjects;
using Common.ScenarioConfigurations;
using Common.Utility;

namespace EnCompass.Testing.Source.PageObjects.Organization.Admin.Proxy 
{
	/// <summary>
	/// Auto-generated Page Model Class
	/// Navigation Paths: 
		/// [Organization Home]->Administration->Proxies
		/// [Organization Home]->Administration->Proxies->Create Proxy
		/// </summary>
	[PageModel(@"/admin/proxy/createProxy.aspx")]
	public partial class CreateProxy : EnCompassOrgPageModel 
	{
		public override string RelativeUrl => @"/admin/proxy/createProxy.aspx";
		public override string PageIdentifierXPath_Generated => @"//li[contains(@class, 'breadcrumb-item active')][text() = 'Create Proxy']";

        public const string _administration_Proxies_CreateProxy_Xpath = @"//ul[contains(@id, 'sideNav')]//a[text()='Create Proxy']";
        #region Navigation

		public void NavigateTo_Administration_Proxies_CreateProxy()
		{
            Driver.TryWaitForElementToBeVisible(By.XPath(_administration_Proxies_CreateProxy_Xpath), out IWebElement _administration_Proxies_CreateProxy);
			NavigateToMenuItem(_administration_Proxies_CreateProxy);
		}

		[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='User Proxies']")]
		private IWebElement _administration_Proxies_UserProxies { get; set; }
		public void NavigateTo_Administration_Proxies_UserProxies()
		{
			NavigateToMenuItem(_administration_Proxies_UserProxies);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Card Proxies']")]
		private IWebElement _administration_Proxies_CardProxies { get; set; }
		public void NavigateTo_Administration_Proxies_CardProxies()
		{
			NavigateToMenuItem(_administration_Proxies_CardProxies);
		}

		
		private void NavigateToMenuItem(IWebElement element)
		{
			Driver.Url = element.GetAttribute("href");
		}
		#endregion

		public CreateProxy(GlobalSettings settings) : base(settings) { }
	}  
}
