package com.framework.pages.AJS;

import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

import com.aventstack.extentreports.ExtentTest;
import com.framework.basepage.BasePage;
import com.framework.pages.AJS.common.Common;
import com.framework.pages.AJS.common.CommonInterfacePage;
import com.framework.pages.AJS.common.IFCSHomePage;
import com.framework.repo.Locator_IFCS;
import com.framework.util.PropUtils;
import com.framework.util.SeleniumWrappers;
import com.github.javafaker.Faker;

public class MerchantLocationPage extends BasePage {

	@FindBy(xpath = Locator_IFCS.POPUP_IFCS)
	public WebElement popupIFCS;

	@FindBy(xpath = Locator_IFCS.SAVE_ICON)
	public WebElement saveButton;

	@FindBy(xpath = Locator_IFCS.BOTTOM_LEFT_TEXT)
	public WebElement bottomLeftText;

	@FindBy(xpath = Locator_IFCS.OK_BUTTON)
	public WebElement okButton;

	@FindBy(xpath = Locator_IFCS.PRODUCT_SOLD_TABLE)
	public WebElement productSoldTable;

	@FindBy(xpath = Locator_IFCS.PRODUCT_SOLD_TEXT)
	public WebElement productSoldText;

	@FindBy(xpath = Locator_IFCS.CHILD_LOCATION_HIERARCHY)
	public WebElement childLocationHierarchy;
	/*
	 * @FindBy(xpath=Locator_IFCS.PARENT_MERCHANT_HIERARCHY) public WebElement
	 * parentMerchantHierarchy;
	 */

	/*
	 * @FindBy(xpath=Locator_IFCS.AGREEMENTS_TABLE) public WebElement
	 * agreementsTable;
	 */
	@FindBy(xpath = Locator_IFCS.HIERARCHY_TEXT)
	public WebElement hierarchyText;

	@FindBy(xpath = Locator_IFCS.MAINTAIN_AGREEMENT_TEXT)
	public WebElement maintainAgreementText;

	@FindBy(xpath = Locator_IFCS.LEFTPANEL_MAINTAIN_AGREEMENT)
	public WebElement leftPanelMaintainAgreement;

	@FindBy(xpath = Locator_IFCS.PRICING_PROFILE_TABLE_POPUP)
	public WebElement pricingProfileTablePopup;

	@FindBy(xpath = Locator_IFCS.SECOND_POPUP_IFCS)
	public WebElement secondPopupIFCS;

	/*
	 * @FindBy(xpath=Locator_IFCS.SECOND_POPUP_OK_BUTTON) public WebElement
	 * secondPopupOKButton;
	 */

	@FindBy(xpath = Locator_IFCS.PARENT_MERCHANT_HIERARCHY)
	public WebElement parentMerchantHierarchy;

	@FindBy(xpath = Locator_IFCS.MERCHANT_REPORT)
	public WebElement merchantReport;
	@FindBy(xpath = Locator_IFCS.MERCHANT_REPORTS_TABLE)
	public WebElement merchantReportTable;
	@FindBy(xpath = Locator_IFCS.AGREEMENTS)
	public WebElement agreementText;
	@FindBy(xpath = Locator_IFCS.POPUP_MERCHANT_AGREEMENT)
	public WebElement popupMerchantAgreeement;
	@FindBy(xpath = Locator_IFCS.POPUP_AGREEMENTS)
	public WebElement popupAgreements;
	@FindBy(xpath = Locator_IFCS.POPUP_PRICING)
	public WebElement popupPricing;
	@FindBy(xpath = Locator_IFCS.POPUP_EFFECTIVE_ON)
	public WebElement popupEffectiveOn;
	@FindBy(xpath = Locator_IFCS.POPUP_EXPIRES_ON)
	public WebElement popupExpiresOn;
	@FindBy(xpath = Locator_IFCS.POPUP_ASSIGNEDFROM)
	public WebElement popupAssignedFrom;
	@FindBy(xpath = Locator_IFCS.POPUP_ASSIGNEDTO)
	public WebElement popupAssignedTo;
	@FindBy(xpath = Locator_IFCS.POPUP_HEADER_PRODUCT)
	public WebElement popupProduct;
	@FindBy(xpath = Locator_IFCS.POPUP_HEADER_PRICINGSCHEME)
	public WebElement popupPricingScheme;
	@FindBy(xpath = Locator_IFCS.POPUP_PRICING_DATE)
	public WebElement popupPricingDate;
	@FindBy(xpath = Locator_IFCS.AGREEMENTS_TABLE)
	public WebElement agreementsTable;
	@FindBy(xpath = Locator_IFCS.AGREEMENTS_TABLEs)
	public WebElement agreementsTables;
	@FindBy(xpath = Locator_IFCS.MERCHANT_LOCATION_AGREEMENTS)
	public WebElement merchantLocationAgreements;
	@FindBy(xpath = Locator_IFCS.MERCHANT_LOCATION_GROUP)
	public WebElement merchantLocationGroupSection;

	@FindBy(xpath = Locator_IFCS.MERCHANT_LOCATION_ASSIGNMENT)
	public WebElement merchantLocationGroupAssignment;

	@FindBy(xpath = Locator_IFCS.POPUP_MENUITEM_ADD)
	public WebElement addInMenuPopup;

	@FindBy(xpath = Locator_IFCS.POPUP_LOCATION_GROUP)
	public WebElement popupLocationGroup;

	@FindBy(xpath = Locator_IFCS.POPUP_HEADER)
	public WebElement popupHeader;

	@FindBy(xpath = Locator_IFCS.CLEAR_FORM)
	public WebElement clearForm;
	@FindBy(xpath = Locator_IFCS.CLONE_FORM)
	public WebElement cloneForm;

	@FindBy(xpath = Locator_IFCS.LOCATION_HIERARCHY_IN_POPUP)
	public WebElement locationHirearchyNodeInPopup;
	@FindBy(xpath = Locator_IFCS.MERCHANT_REPORT_OPTIONS_SPECIFICATION)
	public WebElement merchantReportOptionsSpecification;
	@FindBy(xpath = Locator_IFCS.MERCHANT_AGREEMENT_POPUP_IN_PROFILE)
	public WebElement merchantAgreementInProfiles;

	@FindBy(xpath = Locator_IFCS.MAINTAIN_LOCATION_POPUP)
	public WebElement maintainLocationPopup;
	@FindBy(xpath = Locator_IFCS.YES_BUTTON)
	public WebElement yesButton;
	@FindBy(xpath = Locator_IFCS.LEFT_PANEL_LOCATION)
	public WebElement leftPanelLocation;
	@FindBy(xpath = Locator_IFCS.REPORT)
	public WebElement report;
	@FindBy(xpath = Locator_IFCS.SEARCH_RESULTS_TABLE)
	public List<WebElement> searchResultsTable;

	@FindBy(xpath = Locator_IFCS.MERCHANT_NUMBER)
	public WebElement merchantNo;
	
	@FindBy(xpath = Locator_IFCS.LOCATION_NUMBER)
	public WebElement locationNo;
	
	@FindBy(xpath = Locator_IFCS.MERCHANT_ACCOUNT_NO)
	public WebElement accountNo;
	// String currentIFCSDate;

	public MerchantLocationPage(WebDriver driver, ExtentTest test) {
		super(driver, test);
		PageFactory.initElements(new AjaxElementLocatorFactory(driver, 15), this);
		// TODO Auto-generated constructor stub
	}

	public void verifySoldLocation(String clientName, String clientCountry) {
		Common common = new Common(driver, test);
		sleep(5);
		chooseSubMenuFromLeftPanel("Maintain Location", "Products Sold at Location");
		validateHeaderLabel("Products Sold at Location");
		String location = common.getLocationNoFromDB();
		common.chooseLocationNoAndSearch(location);
		rightClick(productSoldTable);
		common.addIteminPopup();
		validatePopupHeaderText("Products Sold at Location");
		common.chooseARandomDropdownOption("Product");
		String processingDate = common.getCurrentIFCSDateFromDB(clientName + clientCountry);
		String effDate = common.enterADateValueInStatusBeginDateField("Current", processingDate);
		enterValueInTextBox("Details", "Effective On", effDate);
		common.clickOkButton();
		common.validateNewDateAddedInTheTableList("Products Sold at Location", "Effective On", effDate);
		sleep(5);
		common.clickSaveIcon();
		sleep(5);
		verifyValidationResult("Record saved OK");

	}

	public void validateAddNewAgreementInAgreementList() {
		Common common = new Common(driver, test);
		rightClick(agreementsTable);
		common.addIteminPopup();

		enterValueInTextBox("Merchant Agreement", "Effective On", "01/01/3000");
		enterValueInTextBox("Merchant Agreement", "Expires On", "02/03/3001");
		chooseOptionFromDropdown("Merchant Payment Type", "Shell-Managed");

		addPricingProfileAndValidateInPopup();
		sleep(3);
		common.clickOkButton();
		sleep(5);
		common.validateNewDateAddedInTheTableList("Agreements", "Effective On", "01/01/3000");
		common.validateNewDateAddedInTheTableList("Agreements", "Expires On", "02/03/3001");

	}

	public void validateNewAgreementsOverlap(String clientName, String clientCountry) {
		Common common = new Common(driver, test);
		rightClick(agreementsTable);
		common.addIteminPopup();
		String processingDate = common.getCurrentIFCSDateFromDB(clientName + clientCountry);
		String effDate = common.enterADateValueInStatusBeginDateField("Current", processingDate);
		String expiryDate = common.enterADateValueInStatusBeginDateField("WayFuture", processingDate);
		sleep(5);
		enterValueInTextBox("Merchant Agreement", "Effective On", effDate);
		sleep(5);
		enterValueInTextBox("Merchant Agreement", "Expires On", expiryDate);
		chooseOptionFromDropdown("Merchant Payment Type", "Shell-Managed");
		common.clickOkButton();

		common.validateNewDateAddedInTheTableList("Agreements", "Effective On", effDate);
		common.validateNewDateAddedInTheTableList("Agreements", "Expires On", expiryDate);
		sleep(5);
		common.clickSaveIcon();
		sleep(5);
		verifyValidationResult("Date Overlaps with another for this member");
		sleep(5);
		validateDateIsOverlap();
	}

	// Prakalpha
	public void validateDateIsOverlap() {
		List<WebElement> list;
		int size;
		try {
			list = driver
					.findElements(By.xpath("//div[@class='FALTableCellEditor_StrikeThruDateField JTextComponent']"));

			size = SeleniumWrappers.getTotalNumberOfRows(list, driver);
			System.out.println(size);
			for (int row = 1; row <= size; row++) {

				String fontweight = driver.findElement(By.xpath(
						"//div[@class='FALTableCellEditor_StrikeThruDateField JTextComponent'][" + row + "]/div"))
						.getCssValue("font-weight");
				String fontStyle = driver.findElement(By.xpath(
						"//div[@class='FALTableCellEditor_StrikeThruDateField JTextComponent'][" + row + "]/div"))
						.getCssValue("font-style");
				if (fontweight.equals("bold") && fontStyle.equals("italic")) {
					logPass("Date is Overlaped");
					break;
				}
			}
		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
	}

	public void gotoMaintainAgreement() {
		sleep(5);
		isDisplayedThenClick(leftPanelMaintainAgreement, "LeftPanel Maintain Agreement");
		validateHeaderLabel("Maintain Agreement");

	}

	public void selectMerchantChildHierarchy() {
		isDisplayed(hierarchyText, "hierarchyText");
		childLocationHierarchy.click();
		sleep(5);
		String childHierarchyName = getValueFromTextBox("Hierarchies", "Hierarchy");
		System.out.println("The Child Hierarchy Name " + childHierarchyName);
	}

	public void merchantAgreementpopUp(String effectiveDate, String expiryDate) {
		// isDisplayed(popupIFCS,"IFCS Text");
		enterValueInTextBox("Merchant Agreement", "Effective On", effectiveDate);
		enterValueInTextBox("Merchant Agreement", "Expires On", expiryDate);
		chooseOptionFromDropdown("Merchant Payment Type", "Shell-Managed");
		sleep(5);

	}

	/** Add Validation for this method **/
	public void selectMaintainLocationGroup() {
		sleep(2);
		chooseSubMenuFromLeftPanel("Maintain Location Groups", "");
		sleep(2);
		// verifyText(, "Maintain Location Groups");
	}

	public void selectLocationGroupsAndGotoMaintainLocationGroup() {
		Common common = new Common(driver, test);
		sleep(2);
		chooseSubMenuFromLeftPanel("Location Groups", "");
		sleep(2);
		common.selectFirstRowNumberInSearchList();

	}

	public void addPricingProfileAndValidateInPopup() {
		Common common = new Common(driver, test);
		rightClick(pricingProfileTablePopup);
		common.addIteminPopup();
		validatePopupHeaderText("Pricing Profiles");
		chooseOptionFromDropdown("Pricing Profile", "Merchant Pump Pricing");
		enterValueInTextBox("Pricing Profile", "Assigned From", "01/01/3000");
		common.clickSecondPopupOkButton();

	}

	public void validateReportTable() {

		try {
			List<WebElement> reportHeader = driver.findElements(By.xpath(
					"//div[@class='JIFCSMerchReportsTable']//div[@class='HeaderRenderer']//div[@class='htmlString']"));
			SeleniumWrappers.getAllTableHeaders(reportHeader);
			logPass("Report Header is Validated");
		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
	}

	public void validateMerchantChildReport() {

		isDisplayed(hierarchyText, "hierarchyText");
		String merchantParent = parentMerchantHierarchy.getText();
		isDisplayedThenClick(parentMerchantHierarchy, merchantParent + "Parent Merchant");
		sleep(5);
		validateReportTable();
		String childLocation = childLocationHierarchy.getText();
		isDisplayedThenClick(childLocationHierarchy, childLocation + "Child Location");
		validateReportTable();
	}

	/*
	 * public void cellbackgroundColorforFailed() { String
	 * tablecolour=driver.findElement(By.
	 * xpath("//div[@class='FALTableCellEditor_StrikeThruDateField JTextComponent'][1]/div"
	 * )).getCssValue("background-color"); if(tablecolour.equals("#b20000")) {
	 * logPass("Overlaped"); } else { logFail("Not Overlaped"); } }
	 */
	public void verifyMaintainAgreements() {

		chooseSubMenuFromLeftPanel("Maintain Agreement", "");
		sleep(5);
		isDisplayed(maintainAgreementText, "Maintain Agreement Text");
		isDisplayed(hierarchyText, "hierarchyText");
		childLocationHierarchy.click();
		isDisplayed(agreementText, "Agreements Text");
		/*
		 * List<WebElement> list=driver.findElements(By.
		 * xpath("//div[@class='FALTableCellEditor_StrikeThruField JTextComponent']"));
		 */

		WebElement cellElement = SeleniumWrappers.getTableDataWithCellElement(0, 2, driver);
		doubleClick(cellElement);
		// isDisplayed(popupIFCS,"IFCS Text is displayed");
	}

	public void verifyIsDetailsPresentInAgreement() {
		Common common = new Common(driver, test);
		// isDisplayed(popupIFCS,"IFCS Text is displayed");
		isDisplayed(popupMerchantAgreeement, "Merchant Agreement");
		isDisplayed(popupEffectiveOn, "Effective On Date");
		// sleep(5);
		isDisplayed(popupExpiresOn, "Expires On Date");
		isDisplayed(popupAgreements, "Popup Agreements");
		isDisplayed(popupPricing, "Pricing Profile");
		List<WebElement> list = driver.findElements(By.xpath(
				"//div[@class='ajaxswingv4 v4init'][2]//div[@class='FALTableCellEditor_StrikeThruField JTextComponent']"));
		SeleniumWrappers.setCellValueforPopup(list, Locator_IFCS.MERCHANT_AGREEMENT_POPUP, driver);
		WebElement cellElement = SeleniumWrappers.getTableDataWithCellElement(0, 0, driver);
		doubleClick(cellElement);
		sleep(3);
		isDisplayed(popupAssignedFrom, "Assigned from Date");
		isDisplayed(popupAssignedTo, "Assigned from To");
		isDisplayed(popupProduct, "Product");
		isDisplayed(popupPricingScheme, "Pricing Scheme");
		sleep(3);
		common.clickSecondPopupOkButton();
		sleep(2);
		common.clickCancelButton();
		sleep(2);

		// isDisplayedThenClick(okButton,"OK button is clicked");
	}

	public void validateMerchantAgreement() {

		chooseSubMenuFromLeftPanel("Merchant/Location Agreements", "");
		sleep(5);
		isDisplayed(merchantLocationAgreements, "Merchant Location Agreements");
		isDisplayed(agreementText, "Agreements Text");
		/*
		 * List<WebElement> list = driver .findElements(By.
		 * xpath("//div[@class='FALTableCellEditor_StrikeThruField JTextComponent']"));
		 */

		WebElement cellElement = SeleniumWrappers.getTableDataWithCellElement(0, 2, driver);
		doubleClick(cellElement);
		sleep(5);
	}

	String currentIFCSDate;

	public void addLocationToNewLocationGroup(String clientCountry, String userName) {
		Common common = new Common(driver, test);
		// common.clearForm();
		sleep(2);
		rightClick(merchantLocationGroupSection);
		common.addIteminPopup();
		// isDisplayedThenClick(addInMenuPopup, "Add New Location Group");
		verifyText(popupHeader, "Location Hierarchy Node");
		// String locationNo = common
		// .getLocationNoHasTransaction(PropUtils.getPropValue(configProp,
		// clientCountry).replaceAll("\"", ""));
		// String locationNo = common.getLocationNoFromDB();

		String locationNo = common
				.getLocationNoHasNoRelationship(PropUtils.getPropValue(configProp, clientCountry).replaceAll("\"", ""));
		if (locationNo != null) {
			enterValueInTextBox("Location Details", "Location No", locationNo);
			common.clickOkButton();
			sleep(5);
			// enterValueInTextBox("Hierarchies", "Location Group Name",
			// fakerAPI().number().digits(4).toString());
			// sleep(5);
			currentIFCSDate = common.getCurrentIFCSDate(userName);
			System.out.println("Current IFCS Date:" + currentIFCSDate);
			sleep(3);
			rightClick(merchantLocationGroupAssignment);
			isDisplayedThenActionClick(addInMenuPopup, "Add New Location Group - Assignment");
			verifyText(popupHeader, "Location Group Assignment");
			enterValueInTextBox("Details", "Effective On", currentIFCSDate);
			common.clickOkButton();
			sleep(3);
			common.clickSaveIcon();
			sleep(5);
			verifyValidationResult("Record saved OK");
		} else {
			logFail("Location not present for the client :" + clientCountry);
		}
		// common.checkRecordSaved();
	}

	public void updateNameWithSpecialCharacters(String clientCountry) {
		// TODO Auto-generated method stub
		Common common = new Common(driver, test);
		String name = fakerAPI().name().firstName() + "#";
		try {

			chooseSubMenuFromLeftPanel("Maintain Merchant", "Locations");
			common.searchListTorch();
			sleep(10);
			common.selectFirstRowNumberInSearchList();
			if (clientCountry.equals("MY")) {
				common.validateFieldIsProtected("Contact", "Name");
				logInfo("For Malaysia country Field is protected");
			} else {
				System.out.println("name : " + name);
				sleep(5);
				enterValueInTextBox("Contact", "Name", name);
				common.clickSaveIcon();
				sleep(5);
				verifyValidationResult("Record saved OK");
				sleep(2);
				verifyValueInTextBox("Contact", "Name", name);
				logInfo("Special Characters added in Name Field");
			}
		} catch (Exception e) {
			logFail(e.getMessage());
		}

	}

	public void validatAddMerchantReports() {
		// common.chooseLocationNoAndSearch("10040506");
		Common common = new Common(driver, test);
		chooseSubMenuFromLeftPanel("Maintain Location", "Maintain Agreement");

		sleep(5);
		isDisplayed(maintainAgreementText, "Maintain Agreement Text");
		isDisplayed(hierarchyText, "hierarchyText");
		childLocationHierarchy.click();
		sleep(5);
		rightClick(agreementsTable);
		common.addIteminPopup();
		/*
		 * isDisplayed(popupIFCS, "IFCS Text"); enterDataInTextBox("Merchant Agreement",
		 * "Effective On", "02/07/2018"); enterDataInTextBox("Merchant Agreement",
		 * "Expires On", "02/07/3000"); isDisplayedThenClick(okButton,
		 * "OK button is clicked"); validateNewValueAddedInTheTableList("02/07/2018",
		 * "02/07/3000"); isDisplayedThenClick(saveButton, "Save button is clicked");
		 * verifyValidationFailedResult("Date Overlaps with another for this member");
		 * cellbackgroundColorforFailed();
		 */
	}
	//need to change static to dynamic
	public void validatAddLocationReports() {
		// common.chooseLocationNo();
		Common common = new Common(driver, test);
		chooseSubMenuFromLeftPanel("Maintain Location", "Maintain Agreement");
		common.chooseLocationNoAndSearch("10040506");
		sleep(5);
		isDisplayed(maintainAgreementText, "Maintain Agreement Text");
		isDisplayed(hierarchyText, "hierarchyText");
		childLocationHierarchy.click();
		sleep(5);
		rightClick(agreementsTable);
		common.addIteminPopup();
		/*
		 * isDisplayed(popupIFCS, "IFCS Text"); enterDataInTextBox("Merchant Agreement",
		 * "Effective On", "02/07/2018"); enterDataInTextBox("Merchant Agreement",
		 * "Expires On", "02/07/3000"); isDisplayedThenClick(okButton,
		 * "OK button is clicked"); validateNewValueAddedInTheTableList("02/07/2018",
		 * "02/07/3000"); isDisplayedThenClick(saveButton, "Save button is clicked");
		 * verifyValidationFailedResult("Date Overlaps with another for this member");
		 * cellbackgroundColorforFailed();
		 */
	}

	public void createNewMerchant(String merchantNo) {
		/*
		 * isDisplayedThenClick(clearForm, "Clear Form"); sleep(2);
		 * verifyValidationResult("New record, not saved yet");
		 */
		Common common = new Common(driver, test);
		String clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		String clientName = PropUtils.getPropValue(configProp, "clientName");
		System.out.println(clientName);
		if (clientName.equals("BP")) {
			isDisplayedThenClick(cloneForm, "Clone Form");
			sleep(2);
			enterValueInTextBox("Merchant", "Ext Merchant Ref", merchantNo);

			if (clientCountry.equals("NZ")) {
				enterValueInTextBox("Merchant", "Trading Name", fakerAPI().name().fullName());
			}
		} else if (clientName.equals("EMAP") || clientName.equals("SHELL")) {
			isDisplayedThenClick(cloneForm, "Clone Form");
			sleep(3);
			enterValueInTextBox("Merchant", "Merchant No", merchantNo);
		} else {
			sleep(2);
			isDisplayedThenClick(clearForm, "Clear Form");
			sleep(2);
			verifyValidationResult("New record, not saved yet");
			enterValueInTextBox("Merchant", "Merchant No", merchantNo);
		}
		sleep(2);
		String testName = fakerAPI().name().fullName();
		enterValueInTextBoxUsingAJSID("name", testName);
		sleep(2);
		String testAddress = fakerAPI().address().fullAddress();
		enterValueInTextArea("Addresses", "Physical Address", testAddress);
		sleep(2);
		// common.chooseOptionFromDropdown("Country", "random");

		/*
		 * if(clientCountry.equals("NZ")) { String f_postalCode =
		 * fakerAPI().number().digits(4); enterValueInTextBox("Addresses",
		 * "Town/City",testName ); enterValueInTextBox("Addresses",
		 * "Post Code",f_postalCode ); }
		 */

		common.selectACountryFromDropdown(1, "Country");

		enterValueInTextBox("Contact", "Name", testName);
		sleep(2);
		String phoneno = fakerAPI().number().digits(10);
		enterValueInTextBox("Contact", "Phone", phoneno);

		// Dimension d = new Dimension(300,300);
		// Resize current window to the set dimension

		/*
		 * JavascriptExecutor je = (JavascriptExecutor) driver;
		 * 
		 * je.executeScript("window.scrollBy(0,1000)"); WebElement glDropdown=
		 * driver.findElement(By.xpath(
		 * "//div[@class='JFALLabel']/div[@class='htmlString'][contains(text(),'GL')]/preceding::div[@class='JFALComboBox_CustomComboboxRenderer']"
		 * )); String title = glDropdown.getAttribute("title");
		 * System.out.println("title :"+ title); sleep(10);
		 * je.executeScript("arguments[0].scrollIntoView(true); arguments[0].click;"
		 * ,driver,glDropdown);
		 */

		/*
		 * WebElement element =
		 * driver.findElement(By.xpath("//div[@class='htmlString'][contains(text(),'"+
		 * title+"')]"));
		 * je.executeScript("arguments[0].scrollIntoView(true); arguments[0].click;"
		 * ,driver, element);
		 */

		/*
		 * JavascriptExecutor executor = (JavascriptExecutor)driver;
		 * executor.executeScript("document.body.style.zoom = '0.8'");
		 * driver.navigate().refresh(); sleep(10);
		 * 
		 * common.chooseOptionFromDropdown("GL Channel", "random");
		 * ajaxswingDropdownSelection("GL Channel", "random");
		 * 
		 * 
		 * 
		 * executor.executeScript("document.body.style.zoom = '1'");
		 */
		common.selectACountryFromDropdown(0, "Country");
		sleep(2);
		enterValueInTextArea("Addresses", "Postal Address", testAddress);
		
		if(clientName.equalsIgnoreCase("WFE")) {
			switchTabDetails("Merchant Details");
			enterValueInTextBox("Merchant Details", "Account No", " ");
			switchTabDetails("Merchant");
		}
		common.clickSaveIcon();
		sleep(3);
		verifyValidationResult("Record saved OK");
		sleep(5);

	}

	public void updateMerchant() {

		Common common = new Common(driver, test);
		String testName = fakerAPI().name().fullName();
		enterValueInTextBoxUsingAJSID("name", testName);
		sleep(2);
		String testAddress = fakerAPI().address().fullAddress();
		enterValueInTextArea("Addresses", "Physical Address", testAddress);
		sleep(2);
		String phoneno = fakerAPI().number().digits(10);
		enterValueInTextBox("Contact", "Phone", phoneno);
		common.clickSaveIcon();
		verifyValidationResult("Record saved OK");
		sleep(5);

	}

	public void updateLocation() {

		Common common = new Common(driver, test);
		String testAddress = fakerAPI().address().fullAddress();
		enterValueInTextArea("Addresses", "Physical Address", testAddress);
		sleep(2);
		common.selectACountryFromDropdown(1, "Country");
		sleep(2);
		String phoneno = fakerAPI().number().digits(10);
		enterValueInTextBox("Contact", "Phone", phoneno);
		common.selectACountryFromDropdown(0, "Country");
		sleep(2);
		enterValueInTextArea("Addresses", "Postal Address", testAddress);
		common.clickSaveIcon();
		verifyValidationResult("Record saved OK");
		sleep(5);

	}

	public void chooseLocationNoFromListAndDoubleClick(String locationNoFromDB) {
		Common common = new Common(driver, test);
		common.chooseSubMenuFromLeftPanel("Locations", "");
		common.enterValueInTextBox("Filter By", "Location No.", locationNoFromDB);
		common.searchListTorch();
		WebElement element = SeleniumWrappers.getTableDataWithCellElement(0, 0, driver);
		doubleClick(element);
	}

	public void createNewLocation(String locationNo) {
		Common common = new Common(driver, test);
		isDisplayedThenClick(clearForm, "Clear Form");
		sleep(2);
		verifyValidationResult("New record, not saved yet");
		enterValueInTextBox("Location", "Location No", locationNo);
		sleep(2);
		String testName = fakerAPI().name().fullName();
		List<WebElement> elementsList = driver.findElements(By.xpath(
				"//div[@class='JFALLabel']//div[text()='Name']/preceding::div[@class='JFALCompControlPanel'][1]//input"));
		elementsList.get(0).sendKeys(testName);
		// commented - rathna not required : next method is working : enterValueInTextBoxUsingAJSID
		/*WebElement element = driver.findElement(By.xpath(
				"//div[@class='JFALLabel']//div[contains(text(),'Location') and contains(text(),'No')]/preceding::div[@class='JFALLabel'][1]//div[contains(text(),'Name')]/preceding::div[@class='JFALCompControlPanel'][1]//input"));
		element.sendKeys(testName);*/
		enterValueInTextBoxUsingAJSID("name", testName);

		enterValueInTextBox("Location", "Ext Location Ref", locationNo);
		sleep(2);
		String testAddress = fakerAPI().address().fullAddress();
		enterValueInTextArea("Addresses", "Physical Address", testAddress);
		sleep(2);
		common.selectACountryFromDropdown(1, "Country");
		sleep(2);
		String phoneno = fakerAPI().number().digits(10);
		common.ScrollToElement("Contact", "Phone");
		sleep(2);
		enterValueInTextBox("Contact", "Phone", phoneno);
		common.selectACountryFromDropdown(0, "Country");
		sleep(2);
		enterValueInTextArea("Addresses", "Postal Address", testAddress);
		common.clickSaveIcon();
		verifyValidationResult("Record saved OK");
		sleep(5);

	}

	// EMAP
	public void verifyExistingMerchantHasCustomers() {
		sleep(2);
		chooseSubMenuFromLeftPanel("Maintain Location", "Maintain Agreement");
		MaintainLocationPopupPresent();
		isDisplayed(maintainAgreementText, "Maintain Agreement Text");
		isDisplayed(hierarchyText, "hierarchyText");
		isDisplayed(childLocationHierarchy, "Child Location Hirearchy");
		isDisplayed(parentMerchantHierarchy, " Parent Merchant Hierarchy");
		chooseSubMenuFromLeftPanel("Maintain Merchant", "");
		sleep(2);

	}

	public void createMerchantAgreementPublicAndPrivateProfile() {
		Common common = new Common(driver, test);

		chooseSubMenuFromLeftPanel("Maintain Location", "");
		MaintainLocationPopupPresent();

		chooseSubMenuFromLeftPanel("Maintain Location", "Maintain Agreement");
		MaintainLocationPopupPresent();
		sleep(5);
		isDisplayed(maintainAgreementText, "Maintain Agreement Text");
		isDisplayed(hierarchyText, "hierarchyText");
		isDisplayed(parentMerchantHierarchy, " Parent Merchant Hierarchy");
		rightClick(parentMerchantHierarchy);
		common.clickAddLocationInPopUp();
		isDisplayed(popupIFCS, "IFCS POPUP");
		isDisplayed(locationHirearchyNodeInPopup, "Location Hirearchy node");

		String locationNo = common.getLocationNoFromDB();
		enterValueInTextBox("Details", "Location No", locationNo);
		common.clickOkButton();
		sleep(2);
		rightClick(merchantReportTable);
		common.addIteminPopup();
		isDisplayed(merchantReportOptionsSpecification, "Merchant Report Options Specification");
		common.clickOkButton();
		sleep(2);
	}

	public void MaintainLocationPopupPresent() {
		try {
			sleep(5);
			driver.navigate().refresh();
			sleep(5);
			WebElement yesButton = driver.findElement(By.xpath("//div[u[text()='Y']]"));
			isDisplayedThenClick(yesButton, "Yes Button");
			sleep(5);
			System.out.println("Maintain Location Popup is  present");
			// common.clickYesButton();

		} catch (Exception e) {
			logInfo("Miantain Location Popup is not present");
		}

	}

	public void createPricingProfileInPublicAndPrivateProfile(String clientName, String clientCountry, String option) {
		Common common = new Common(driver, test);
		childLocationHierarchy.click();
		rightClick(agreementsTable);
		common.addIteminPopup();
		isDisplayed(popupIFCS, "IFCS Text is displayed");
		isDisplayed(merchantAgreementInProfiles, "Merchant Agreement");
		common.chooseOptionFromDropdown("Merchant Payment Type", "R - Reimbursement");
		sleep(3);
		rightClick(pricingProfileTablePopup);
		common.addIteminPopup();
		validatePopupHeaderText("Pricing Profiles");
		String processingDate = common.getCurrentIFCSDateFromDB(clientName + clientCountry);
		String assignFrom = common.enterADateValueInStatusBeginDateField("Current", processingDate);
		String assignTo = common.enterADateValueInStatusBeginDateField("WayFuture", processingDate);
		WebElement comboDropDown = null;
		List<WebElement> comboOptions = null;
		WebElement comboOption = null;
		comboDropDown = driver.findElement(By.xpath(
				"//div[@class='JFALLabel']//div[contains(text(),'Pricing') and contains(text(),'Profile')]//preceding::div[@class='JFALCompControlPanel'][1]/div[@class='JFALComboBox']//div[@class='MetalComboBoxButton enabled JButton']"));
		isDisplayedThenClick(comboDropDown, "Combo Dropdown");
		// comboOptions =
		// driver.findElements(By.xpath("//div[@class='BasicComboPopup_1']/div/div[@class='htmlString']"));
		comboOptions = driver.findElements(By.xpath(
				"//div[@class='BasicComboPopup_1']/div/div[@class='htmlString'][not(contains(text(),'NewPrivateProfile'))]"));
		comboOption = driver.findElement(By.xpath(
				"//div[@class='BasicComboPopup_1']/div/div[@class='htmlString'][contains(text(),'NewPrivateProfile')]"));

		System.out.println(comboOptions.size());
		if (option.equals("Private")) {
			// common.chooseOptionFromDropdown("Pricing Profile","NewPrivateProfile");
			System.out.println("inside");
			// sleep(10);
			isDisplayedThenActionClick(comboOption, "New Private Profile");
			System.out.println("outside");
			// dropdownInPopupTable(Locator_IFCS.PRICING_PROFILE_POPUP_TABLE,"Pricing
			// Schemes","random");

			enterValueInTextBox("Pricing Profile", "Assigned From", assignFrom);
			sleep(2);
			enterValueInTextBox("Pricing Profile", "Assigned To", assignTo);
			common.clickSecondPopupOkButton();
			sleep(2);
			common.clickOkButton();
			sleep(5);

		} else {
			isDisplayedThenActionClick(comboOptions.get(0), " Public Profile");
			enterValueInTextBox("Pricing Profile", "Assigned From", assignFrom);
			sleep(2);
			enterValueInTextBox("Pricing Profile", "Assigned To", assignTo);
			common.clickSecondPopupOkButton();
			sleep(2);
			common.clickOkButton();
			sleep(5);

		}

	}

	public void validateNewlyAddedLocationNumber(String updatedLocationNumber) {
		Common common = new Common(driver, test);

		gotoLocations();
		enterValueInTextBox("Filter By", "Location No.", updatedLocationNumber);
		common.searchListTorch();
		sleep(3);
		common.validateSearchTable("Location No", updatedLocationNumber, true);
	}

	public void gotoLocations() {
		sleep(5);
		isDisplayedThenClick(leftPanelLocation, "LeftPanel Locations");
		validateHeaderLabel("Viewer");
	}

	public void validateMaintainAgreementInMerchant(String clientName, String clientCountry) {
		Common common = new Common(driver, test);
		String merchantNo = getValueFromProtectedTextBox("Merchant", "Merchant No");
		common.chooseMerchantNoAndSearch(merchantNo);
		sleep(5);
		chooseSubMenuFromLeftPanel("Maintain Location", "Maintain Agreement");
		MaintainLocationPopupPresent();
		isDisplayed(maintainAgreementText, "Maintain Agreement Text");
		isDisplayed(hierarchyText, "hierarchyText");
		isDisplayed(parentMerchantHierarchy, " Parent Merchant Hierarchy");
		rightClick(parentMerchantHierarchy);
		common.clickAddLocationInPopUp();
		isDisplayed(popupIFCS, "IFCS POPUP");
		isDisplayed(locationHirearchyNodeInPopup, "Location Hirearchy node");
		String locationNo = common.getLocationNoFromDB();
		enterValueInTextBox("Details", "Location No", locationNo);
		common.clickOkButton();
		sleep(2);
		isDisplayed(childLocationHierarchy, "Child Location Hirearchy");
		sleep(2);
		childLocationHierarchy.click();
		sleep(2);
		rightClick(agreementsTable);
		sleep(2);
		common.addIteminPopup();
		String processingDate = common.getCurrentIFCSDateFromDB(clientName + clientCountry);
		String effDate = common.enterADateValueInStatusBeginDateField("Current", processingDate);
		sleep(5);
		enterValueInTextBox("Merchant Agreement", "Effective On", effDate);
		sleep(5);
		rightClick(pricingProfileTablePopup);
		sleep(5);
		common.addIteminPopup();
		// sleep(5);
		validatePopupHeaderText("Pricing Profiles");
		chooseOptionFromDropdown("Pricing Profile", "random");
		common.clickSecondPopupOkButton();
		sleep(2);
		common.clickOkButton();
		sleep(5);
		if (clientCountry.equals("AU")) {
			rightClick(merchantReportTable);
			common.addIteminPopup();
			isDisplayed(merchantReportOptionsSpecification, "Merchant Report Options Specification");
			chooseOptionFromDropdown("Report Type", "Merchant Statement");
			common.clickOkButton();
			sleep(5);
			rightClick(merchantReportTable);
			common.addIteminPopup();
			isDisplayed(merchantReportOptionsSpecification, "Merchant Report Options Specification");
			chooseOptionFromDropdown("Report Type", "Merchant RCTI");
			common.clickOkButton();
			sleep(5);
			common.validateNewValueAddedInTheTableList("Reports", "Report Type", "Merchant Statement");
			sleep(5);
			common.validateNewValueAddedInTheTableList("Reports", "Report Type", "Merchant RCTI");
		} else if (clientCountry.equals("NZ")) {
			rightClick(merchantReportTable);
			common.addIteminPopup();
			isDisplayed(merchantReportOptionsSpecification, "Merchant Report Options Specification");
			chooseOptionFromDropdown("Report Type", "Merchant Statement");
			common.clickOkButton();
			sleep(5);
			common.validateNewValueAddedInTheTableList("Reports", "Report Type", "Merchant Statement");

		}
	}

	// Added by NK
	public void validateMerchantAgreementForNewMerchantAndLocation(String clientName, String clientCountry,
			String merchantNum, String locationNum) {
		Common common = new Common(driver, test);
		sleep(3);
		chooseSubMenuFromLeftPanel("Maintain Location", "Maintain Agreement");
		common.searchTorch();
		sleep(3);
		isDisplayedThenEnterText(merchantNo, "Merchant Number", merchantNum);
		common.findRecordTorch();
		MaintainLocationPopupPresent();
		common.closeFindRecordTorch();
		isDisplayed(maintainAgreementText, "Maintain Agreement Text");
		isDisplayed(hierarchyText, "hierarchyText");
		isDisplayed(parentMerchantHierarchy, " Parent Merchant Hierarchy");
		rightClick(parentMerchantHierarchy);
		common.clickAddLocationInPopUp();
		isDisplayed(popupIFCS, "IFCS POPUP");
		isDisplayed(locationHirearchyNodeInPopup, "Location Hirearchy node");
		enterValueInTextBox("Details", "Location No", locationNum);
		common.clickOkButton();
		sleep(2);
		isDisplayed(childLocationHierarchy, "Child Location Hirearchy");
		childLocationHierarchy.click();
		rightClick(agreementsTable);
		common.addIteminPopup();
		String processingDate = common.getCurrentIFCSDateFromDB(clientName);
		String effDate = common.enterADateValueInStatusBeginDateField("Current", processingDate);
		enterValueInTextBox("Merchant Agreement", "Effective On", effDate);
		sleep(5);
		rightClick(pricingProfileTablePopup);
		sleep(5);
		common.addIteminPopup();
		// sleep(5);
		validatePopupHeaderText("Pricing Profiles");
		chooseOptionFromDropdown("Pricing Profile", "random");
		common.clickSecondPopupOkButton();
		sleep(2);
		common.clickOkButton();
		sleep(5);
		common.clickSaveIcon();
		if (clientCountry.equals("AU")) {
			rightClick(merchantReportTable);
			common.addIteminPopup();
			isDisplayed(merchantReportOptionsSpecification, "Merchant Report Options Specification");
			chooseOptionFromDropdown("Report Type", "Merchant Statement");
			common.clickOkButton();
			sleep(5);
			rightClick(merchantReportTable);
			common.addIteminPopup();
			isDisplayed(merchantReportOptionsSpecification, "Merchant Report Options Specification");
			chooseOptionFromDropdown("Report Type", "Merchant RCTI");
			common.clickOkButton();
			sleep(5);
			common.validateNewValueAddedInTheTableList("Reports", "Report Type", "Merchant Statement");
			sleep(5);
			common.validateNewValueAddedInTheTableList("Reports", "Report Type", "Merchant RCTI");
		} else if (clientCountry.equals("NZ") || (clientCountry.equals("HK") && clientName.equals("CHEVRON"))) {
			rightClick(merchantReportTable);
			common.addIteminPopup();
			isDisplayed(merchantReportOptionsSpecification, "Merchant Report Options Specification");
			chooseOptionFromDropdown("Report Type", "Merchant Statement");
			common.clickOkButton();
			sleep(5);
			common.validateNewValueAddedInTheTableList("Reports", "Report Type", "Merchant Statement");

		}
	}

	// added by rathna
	public void updateExistingMerchantPricingProfile(String clientName, String clientCountry) {
		Common common = new Common(driver, test);
		String merchantNo = getValueFromProtectedTextBox("Merchant", "Merchant No");
		common.chooseMerchantNoAndSearch(merchantNo);
		sleep(5);
		chooseSubMenuFromLeftPanel("Adjusted Transactions", "Merchant/Location Agreements");
		// Right click on Agreements table
		rightClick(agreementsTables);
		common.detailsIteminPopup();
		sleep(5);
		// Right click on Pricing profile table
		rightClick(pricingProfileTablePopup);
		common.addIteminPopup();
		// add profile and select date
		chooseOptionFromDropdown("Pricing Profile", "Merc List");
		enterValueInTextBox("Pricing Profile", "Assigned From", "15/06/2020");
		common.clickSecondPopupOkButton();
		common.clickOkButton();
		sleep(5);
		common.clickSaveIcon();

	}

	// Added by mamtha

	public void merchantMaintainAgreements() {
		Common common = new Common(driver, test);
		chooseSubMenuFromLeftPanel("Maintain Agreement", "");
		yesButton.click();
		isDisplayed(maintainAgreementText, "Maintain Agreement Text");
		isDisplayed(hierarchyText, "hierarchyText");
		isDisplayed(parentMerchantHierarchy, " Parent Merchant Hierarchy");
		rightClick(parentMerchantHierarchy);
		common.clickAddLocationInPopUp();
		isDisplayed(popupIFCS, "IFCS POPUP");
		isDisplayed(locationHirearchyNodeInPopup, "Location Hirearchy node");

		String locationNo = common.getLocationNoFromDB();
		enterValueInTextBox("Details", "Location No", locationNo);
		common.clickOkButton();
		sleep(2);
		rightClick(merchantReportTable);
		common.addIteminPopup();
		isDisplayed(merchantReportOptionsSpecification, "Merchant Report Options Specification");
		common.clickOkButton();
		sleep(2);

	}

	// Mamta
	public void createNewMerchantForChevronTH(String merchantNo, String merchantType) {
		/*
		 * isDisplayedThenClick(clearForm, "Clear Form"); sleep(2);
		 * verifyValidationResult("New record, not saved yet");
		 */
		Common common = new Common(driver, test);

		isDisplayedThenClick(cloneForm, "Clone Form");
		sleep(2);
		Faker fakerNumber = new Faker();
		merchantNo = fakerNumber.number().digits(6);
		enterValueInTextBox("Merchant", "Merchant No", merchantNo);
		enterValueInTextBox("Merchant", "Trading Name", fakerAPI().name().fullName());

		List<WebElement> nameList = driver.findElements(By.xpath(
				"//div[@class='JFALSeparator']//div[text()='Merchant']/preceding::div[@class='JFALLabel']/div[text()='Name']/preceding::div[@class='JFALCompControlPanel'][1]//input"));
		sleep(5);
		nameList.get(1).sendKeys(fakerAPI().name().firstName());
		// enterValueInTextBox("Merchant", "Name",fakerAPI().name().fullName());

		String testName = fakerAPI().name().fullName();

		chooseOptionFromDropdown("Merchant Type", merchantType);
		String testAddress = fakerAPI().address().fullAddress();
		enterValueInTextArea("Addresses", "Physical Address", testAddress);
		sleep(2);
		// common.chooseOptionFromDropdown("Country", "random");
		common.selectACountryFromDropdown(1, "Country");
		enterValueInTextBox("Contact", "Name", testName);
		sleep(2);
		String phoneno = fakerAPI().number().digits(10);
		enterValueInTextBox("Contact", "Phone", phoneno);
		// common.chooseOptionFromDropdown("GL Channel", "random");
		common.selectACountryFromDropdown(0, "Country");
		sleep(2);
		enterValueInTextArea("Addresses", "Postal Address", testAddress);
		common.clickSaveIcon();
		verifyValidationResult("Record saved OK");
		sleep(5);

	}

	// Mamta
	public void verifyMaintainAgreementsForChevronTH() {

		chooseSubMenuFromLeftPanel("Maintain Agreement", "");
		sleep(5);
		isDisplayed(maintainAgreementText, "Maintain Agreement Text");
		isDisplayed(hierarchyText, "hierarchyText");
		childLocationHierarchy.click();
		isDisplayed(agreementText, "Agreements Text");
		/*
		 * List<WebElement> list=driver.findElements(By.
		 * xpath("//div[@class='FALTableCellEditor_StrikeThruField JTextComponent']"));
		 */

		WebElement cellElement = SeleniumWrappers.getTableDataWithCellElement(0, 2, driver);
		doubleClick(cellElement);
		// isDisplayed(popupIFCS,"IFCS Text is displayed");
	}

	/*updated by raxsana - 29/06/2020
	 * 
	 */
	public void validateAddNewAgreementInAgreementList(String merchantPaymentType) {
		String clientName = PropUtils.getPropValue(configProp, "clientName");
		String clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		Common common = new Common(driver, test);
		rightClick(agreementsTable);
		common.addIteminPopup();
		String currentIFCSDate = common.getCurrentIFCSDateFromDB(clientName + "_" + clientCountry);
		String currentDate = common.enterADateValueInStatusBeginDateField("Current", currentIFCSDate);
		String futureDate = common.enterADateValueInStatusBeginDateField("WayFuture", currentIFCSDate);
		enterValueInTextBox("Merchant Agreement", "Effective On", currentDate);

		enterValueInTextBox("Merchant Agreement", "Expires On", futureDate);//"01/07/2021");
		chooseOptionFromDropdown("Merchant Payment Type", merchantPaymentType);
		enterValueInTextBox("Agreements", "Ship To", fakerAPI().name().firstName());
		enterValueInTextBox("Agreements", "Profit Cntr", "0");
		sleep(3);
		rightClick(pricingProfileTablePopup);
		common.addIteminPopup();
		validatePopupHeaderText("Pricing Profiles");
		chooseOptionFromDropdown("Pricing Profile", "Merchant Pricing");
		enterValueInTextBox("Pricing Profile", "Assigned From", currentDate);
		enterValueInTextBox("Pricing Profile", "Assigned To", futureDate);//"01/07/2021");

		common.clickSecondPopupOkButton();

		// addPricingProfileAndValidateInPopup();
		sleep(3);
		common.clickOkButton();
		sleep(5);
		common.validateNewDateAddedInTheTableList("Agreements", "Effective On", currentDate);
		// common.validateNewDateAddedInTheTableList("Agreements","Expires
		// On","02/03/2031");
		common.clickSaveIcon();
	}

	public void validateNewAgreementsOverlap() {
		Common common = new Common(driver, test);
		rightClick(agreementsTable);
		common.addIteminPopup();
		merchantAgreementpopUp("07/02/2019", "07/02/2999");
		common.clickOkButton();
		sleep(3);
		// validateNewDateAddedInTheTableList("07/02/2019", "07/02/2999");
		common.clickSaveIcon();
		// common.clickYesButton();
		verifyValidationResult("Date Overlaps with another for this member");
		// verifyValidationFailedResult("Date Overlaps with another for this member");
		sleep(5);
		validateDateIsOverlap();
	}

	public void validateNewDateAddedInTheTableList(String effective, String expiry) {
		int rowSize;
		List<WebElement> list;
		int col = 0;
		try {

			list = driver
					.findElements(By.xpath("//div[@class='FALTableCellEditor_StrikeThruDateField JTextComponent']"));

			rowSize = SeleniumWrappers.getTotalNumberOfRows(list, driver);
			System.out.println(rowSize);

			for (int row = 0; row <= rowSize; row++) {
				if (SeleniumWrappers.getTableDataWithRowAndColumnNumber(col, row, driver).equals(effective)) {
					if (SeleniumWrappers.getTableDataWithRowAndColumnNumber(col + 1, row, driver).equals(expiry)) {
						logPass(effective + " and " + expiry + "are updated");
					} else {
						logFail("Incorrect cell Value");
					}
				}
			}
		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
	}
	
	
		/**
		 * @param clientName
		 * @param clientCountry
		 * @param merchantNum
		 * updated by raxsana 09/10/2020
		 */
		public void updateAgreement(String clientName, String clientCountry, String merchantNum)
		{
			Common common = new Common(driver, test); 
			sleep(3);
			chooseSubMenuFromLeftPanel("Maintain Location", "Maintain Agreement");
			common.searchTorch();
			sleep(3);
			//isDisplayedThenEnterText(merchantNo, "Merchant Number", merchantNum); 
			isDisplayedThenEnterText(locationNo, "Location Number", merchantNum); 
			common.findRecordTorch();
			sleep(2);
			common.closeFindRecordTorch();
			childLocationHierarchy.click();
			WebElement cellElement = SeleniumWrappers.getTableDataWithCellElement(0, 2, driver);
			doubleClick(cellElement);
			sleep(3);
			String processingDate=common.getCurrentIFCSDateFromDB(clientName);
			String effDate=common.enterADateValueInStatusBeginDateField("Current",processingDate);
			enterValueInTextBox("Merchant Agreement", "Effective On", effDate);
		    sleep(2);
		    common.clickOkButton();
			sleep(2);
			common.clickSaveIcon();
			sleep(2);
			common.clickOkButtonIfMsgPopupAppears();
			sleep(2);
			verifyValidationResult("Record saved OK");
		}
		
		/*
		 * Raxsana Added 26/10/2020
		 */
		public void expiryAgreementFromMerchant(String clientName, String clientCountry, String merchantNo)
		{
			Common common = new Common(driver, test); 
			IFCSHomePage ifcsHomePage = new IFCSHomePage(driver, test);
			
			sleep(3);
			chooseSubMenuFromLeftPanel("Maintain Location", "Maintain Agreement");
			List<WebElement> element =driver.findElements(By.xpath("//div[@class='FALTreeCellRenderer']//div[@class='htmlString']"));
			String locNo=element.get(1).getText();
			System.out.println("locNo::"+locNo);
			String locationNo=locNo.split(" ")[0].replace("#", "");
			System.out.println("locationNo::"+locationNo);
			WebElement element1 = driver
					.findElement(By.xpath("//div[@class='FALTreeCellRenderer']//div[@class='htmlString']["+splitStringAndGenerateXpath(locNo)+"]"));
			element1.click(); 
			
				List<WebElement> sizeElement=driver.findElements(By.xpath("//div[@class='JFALSeparator_1']/div[contains(text(),'Agreements')]//preceding::div[@class='FALTableCellEditor_StrikeThruDateField JTextComponent']"));
				int size=sizeElement.size();
				for(int i=0;i<size;i++) {
					try {
						WebElement expiresOnEle =driver.findElement(By.xpath("//div[@class='JFALSeparator_1']/div[contains(text(),'Agreements')]//preceding::div[@class='FALTableCellEditor_StrikeThruDateField JTextComponent'][contains(@id,'_"+i+"_1')]//input"));
						System.out.println("expiresOnEle::"+expiresOnEle);
						String submittedValue=expiresOnEle.getAttribute("submittedvalue");
						System.out.println("submittedValue::"+submittedValue);
						if(submittedValue.equals("")) {
							System.out.println("inside else");
							Click(expiresOnEle,"Element");
							//sleep(5);
							doubleClick(expiresOnEle);
							sleep(5);
						}
					}catch(Exception e) {
						break;
					}
				}
			
			sleep(3);
			String processingDate=common.getCurrentIFCSDateFromDB(clientName);
			String expectedDate=common.enterADateValueInStatusBeginDateField("oneDayBefore",processingDate);
			System.out.println(expectedDate);
			
			enterValueInTextBox("Merchant Agreement", "Expires On", expectedDate);
			
		    sleep(2);
		    common.clickOkButton();
			sleep(2);
			common.clickSaveIcon();
			sleep(2);
			common.clickYesButton();
			sleep(2);
			common.clickOkButtonIfMsgPopupAppears();
			sleep(2);
			
			verifyValidationResult("Record saved OK");
			//Manual Transaction
			manualTransactionForMerchantExpiry(clientName,clientCountry,locationNo,"Location Agreement Invalid");
			
			//Merchant Location agreement with Future date
			ifcsHomePage.gotoMerchantAndClickMerchantDetails();
			common.chooseMerchantNoAndSearch(merchantNo);
			sleep(3);
			chooseSubMenuFromLeftPanel("Maintain Location", "Maintain Agreement");

			List<WebElement> element2 = driver
					.findElements(By.xpath("//div[@class='FALTreeCellRenderer']//div[@class='htmlString']"));
			String locNo1 = element2.get(1).getText();
			System.out.println("locNo::" + locNo);
			String locationNo1 = locNo1.split(" ")[0].replace("#", "");
			System.out.println("locationNo::" + locationNo1);
			WebElement element3 = driver
					.findElement(By.xpath("//div[@class='FALTreeCellRenderer']//div[@class='htmlString']["
							+ splitStringAndGenerateXpath(locNo) + "]"));
			 
			element3.click(); 
			rightClick(agreementsTable); 
			common.addIteminPopup();
			sleep(2);
			
			String processingDate1=common.getCurrentIFCSDateFromDB(clientName);
			String expectedDate1=common.enterADateValueInStatusBeginDateField("oneDayAfter",processingDate1);
			System.out.println(expectedDate1);
			
			enterValueInTextBox("Merchant Agreement", "Effective On", expectedDate1);
			common.chooseARandomDropdownOption("Merchant Payment Type");
			sleep(3);
			rightClick(pricingProfileTablePopup);
			common.addIteminPopup();
			validatePopupHeaderText("Pricing Profiles");
			common.chooseARandomDropdownOption("Pricing Profile");
			enterValueInTextBox("Pricing Profile", "Assigned From", expectedDate1);
			common.clickSecondPopupOkButton();
			
			sleep(2);
		    common.clickOkButton();
			sleep(2);
			common.clickSaveIcon();
			sleep(2);
			verifyValidationResult("Record saved OK");
			
			manualTransactionForMerchantExpiry(clientName,clientCountry,locationNo,"Location Agreement Invalid");
		}
		
		public void manualTransactionForMerchantExpiry(String clientName,String clientCountry,String locationNo,String validationMessage) {
			//Manual Transaction
			Common common=new Common(driver,test);
			IFCSHomePage ifcsHomePage=new IFCSHomePage(driver,test);
			CommonInterfacePage commonInterfacePage = new CommonInterfacePage(driver, test);
			TransactionListPage transactionListPage = new TransactionListPage(driver, test);
			String clientNameInProp = PropUtils.getPropValue(configProp, clientName + "_" + clientCountry);
			
			Faker fakerN = new Faker();
			String f_referenceNo = fakerN.number().digits(3);
			String currentDate = common.getCurrentIFCSDateFromDB(clientNameInProp);
			// Get the IFCS current date
			String ifcsCurrentDate = common.enterADateValueInStatusBeginDateField("Current", currentDate);
			System.out.println("Date ::" + ifcsCurrentDate);
			
			String cardNumber = common.getCardNumberFromIFCSDB(clientName, clientCountry, "Active");
			
			Map<String, String> lineItem = commonInterfacePage.getTransactionLineItem(configProp, cardNumber, clientName, clientCountry);

			ifcsHomePage.gotoTransactionAndClickManageTransaction();
		
			transactionListPage.enterTransactionBatchDetails(true, "100", "1", clientName);
			transactionListPage.enterManualTransactionDetails(ifcsCurrentDate, f_referenceNo, cardNumber,
					"", locationNo, "100", "");
			transactionListPage.enterTransactionLineItems(lineItem.get("productCode"), "100", "100", "100");
			transactionListPage.validatePostManualTransaction(validationMessage);
		}

	
		
		
}
