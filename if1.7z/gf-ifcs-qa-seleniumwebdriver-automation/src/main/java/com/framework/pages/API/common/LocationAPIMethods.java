package com.framework.pages.API.common;

import java.util.HashMap;
import java.util.Map;

import org.json.JSONObject;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;
import com.framework.util.PropUtils;

public class LocationAPIMethods extends  CommonAPI{

	public LocationAPIMethods(WebDriver driver, ExtentTest test) {
		super(driver, test);
	}
	
	public void locationCreation(String clientCountry, String locationNo, String locationType, String marketingTerritory)
	{
		JSONObject requestParams = new JSONObject();
		JSONObject streetAddress = new JSONObject();
		
		requestParams.put("locationNo", locationNo);
		requestParams.put("externalCode", fakerAPI().number().digits(8));
		requestParams.put("locationStatus", "Open");
		String name = fakerAPI().name().firstName();
		requestParams.put("name", name);
		requestParams.put("tradingName", fakerAPI().name().fullName());
		requestParams.put("longitude",fakerAPI().number().digits(5)+"."+fakerAPI().number().digits(5));
		requestParams.put("latitude",fakerAPI().number().digits(5)+"."+fakerAPI().number().digits(5));
		
		
		requestParams.put("streetAddress", streetAddress);
		
		
		streetAddress.put("addressLine", fakerAPI().address().fullAddress());
		streetAddress.put("country", clientCountry);
		streetAddress.put("postalCode", fakerAPI().number().digits(4));
		streetAddress.put("suburb", fakerAPI().name().firstName());
		
		requestParams.put("locationType", locationType);
		
		if(!clientCountry.equals("DE")) {
		requestParams.put("marketingTerritory", marketingTerritory);
		}
		
		requestParams.put("phoneBusiness", fakerAPI().number().digits(10));
		
		System.out.println("end point"+ PropUtils.getPropValue(configProp, "CREATE_LOCATION"));
		
		response = apiUtils.postRequestAsBearerAuthWithBodyData(PropUtils.getPropValue(configProp, "CREATE_LOCATION"),
				requestParams,PropUtils.getPropValue(configProp, "AuthorizationToken"));
		
		System.out.println(" Printing the PUT response----->" + 		 response.body().prettyPrint());
		
		if (response.getStatusCode() == 201) {
			logPass("Location was created successfully");
			
			System.out.println("Location NO " +locationNo +" was created successfully");
		} else {
			logFail("Location Creation Failed"+  response.body().prettyPrint());
		}
		
		String locationNumbeFromDB= getLocationNum(name);
		Map<String, String> locNo = new HashMap<String, String>();
		locNo.put("Location Number"  + "_" + clientCountry, locationNumbeFromDB);
		System.out.println("Created Customer Stored in Properties : "+locationNumbeFromDB +"--> CustomerNumber.properties");
		PropUtils.creatingTempPropFile("locationnumber.properties", locNo);
		
	}
	
	
public void updateLocation(String locationNo, String fieldName, String value) {
		
		JSONObject productRequestParams = new JSONObject();
		
		productRequestParams.put("locationNo", locationNo);
		productRequestParams.put(fieldName, value);
		
		
		
		response = apiUtils.putRequestAsBearerAuthWithBodyData(PropUtils.getPropValue(configProp, "AuthorizationToken"),
				productRequestParams, PropUtils.getPropValue(configProp, "UPDATE_LOCATION"));
		 System.out.println(" Printing the PUT response----->" + 		 response.body().prettyPrint());
		if (response.getStatusCode() == 200) {
			logInfo("Location updated successfully for card"+locationNo+"Response"+response.body().prettyPrint());
		} else {
			logFail("Location not updated to :" + value + "Error log: " + response.body().prettyPrint());
		}
		
	}


public String getLocationNum(String name) {
	String locationNumber = "Select location_no from m_locations  where name = '" + name + "'";
	return connectDBAndGetValue(locationNumber, PropUtils.getPropValue(configProp, "sqlODSServerName"));
}

}
 