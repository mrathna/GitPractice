package com.framework.testcases.AJS.EMAP;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.MaintainCustomerPage;
import com.framework.pages.AJS.common.Common;
import com.framework.pages.AJS.common.IFCSHomePage;
import com.framework.pages.AJS.common.IFCSLoginPage;

public class ValidateCardMaintenanceTestCases extends BaseTest {
	
	
	/**
	 * Added by Rathna
	 * 
	 * @param clientCountry
	 * @param clientName
	 *            Busienss Flow ID:045
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "Regression" })
	public void createPrivateAnualCardFeeProfile(@Optional("HK") String clientCountry,
			@Optional("EMAP") String clientName) {
		test = extent.createTest(clientName + ":" + clientCountry + "TC-1731 TC03_CustMgmt_create private Annual Card fee",
				"RQ-799 : Able to create a private Monthly/Annual card fee profile");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		Common common = new Common(driver, test);
		MaintainCustomerPage maintainCustomerPage = new MaintainCustomerPage(driver, test);
		IFCSloginPage.login("IFCS_URL_EMAP", "IFCS_EMAP_USERNAME", "IFCS_EMAP_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");

		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		// Need to select customer no which has no private card fee profile
		String customerNo = common.getCustomerNoHavingCardsUsingCardType();
		if (customerNo.equals(" ")) {
			common.logForNoDataFound(this.getClass().getSimpleName(), "Need to Create A Customer with Cards and rerun");
		} else {
			common.chooseCustomerNoAndSearch(customerNo);
			maintainCustomerPage.chooseMaintainCardFeesFromCustomerProfile();
			if (maintainCustomerPage.getRowCount("Card Fees") == 0) {
				// create card fee
				maintainCustomerPage.createCardFees();
				maintainCustomerPage.createPrivateCardFeeProfile("Annual Card Fee",clientCountry);

				//maintainCustomerPage.SaveAndDeleteProfile();
			} else {
			
				maintainCustomerPage.createPrivateCardFeeProfile("Annual Card Fee",clientCountry);
				//common.logInfo("Card fees cotnains private profile already ");
			}

		}
		IFCSHomePage.exitIFCS();
	}
	
	/**
	 * Added by Rathna
	 * 
	 * @param clientCountry
	 * @param clientName
	 *            Busienss Flow ID:045
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "Regression" })
	public void createPrivateMonthlyCardFeeProfile(@Optional("HK") String clientCountry,
			@Optional("EMAP") String clientName) {
		test = extent.createTest(clientName + ":" + clientCountry + "TC-1732 TC04_CustMgmt_create private Monthly card fee",
				"RQ-799 : Able to create a private Monthly/Annual card fee profile");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		Common common = new Common(driver, test);
		MaintainCustomerPage maintainCustomerPage = new MaintainCustomerPage(driver, test);

		IFCSloginPage.login("IFCS_URL_EMAP", "IFCS_EMAP_USERNAME", "IFCS_EMAP_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");

		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		// Need to select customer no which has no private card fee profile
		String customerNo = common.getCustomerNoHavingCardsUsingCardType();
		if (customerNo.equals(" ")) {
			common.logForNoDataFound(this.getClass().getSimpleName(), "Need to Create A Customer with Cards and rerun");
		} else {
			common.chooseCustomerNoAndSearch(customerNo);
			maintainCustomerPage.chooseMaintainCardFeesFromCustomerProfile();
			if (maintainCustomerPage.getRowCount("Card Fees") == 0) {
				// create card fee
				maintainCustomerPage.createCardFees();
				maintainCustomerPage.createPrivateCardFeeProfile("Monthly Card Fee",clientCountry);

				//maintainCustomerPage.SaveAndDeleteProfile();
			} else {
				maintainCustomerPage.createPrivateCardFeeProfile("Monthly Card Fee",clientCountry);
				//maintainCustomerPage.SaveAndDeleteProfile();
				//common.logInfo("Card fees cotnains private profile ");
			}

		}
		IFCSHomePage.exitIFCS();
	}
	
	
	/**
	 * Added by Rathna
	 * 
	 * @param clientCountry
	 * @param clientName
	 *            Busienss Flow ID:797
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "Regression" })
	public void defaultPublicMonthlyCardFeeProfile(@Optional("HK") String clientCountry,
			@Optional("EMAP") String clientName) {
		test = extent.createTest(clientName + ":" + clientCountry + "TC-1730 TC02_CUstMgmt_default Public Monthly card fee",
				"RQ-797- Able to default public Monthly/Annual card fee");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		Common common = new Common(driver, test);
		MaintainCustomerPage maintainCustomerPage = new MaintainCustomerPage(driver, test);

		IFCSloginPage.login("IFCS_URL_EMAP", "IFCS_EMAP_USERNAME", "IFCS_EMAP_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");

		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		// Need to select who has no private card fee profile
		String customerNo = common.getCustomerNoHavingCardsUsingCardType();
		if (customerNo.equals(" ")) {
			common.logForNoDataFound(this.getClass().getSimpleName(), "Need to Create A Customer with Cards and rerun");
		} else {
			common.chooseCustomerNoAndSearch(customerNo);
			maintainCustomerPage.chooseMaintainCardFeesFromCustomerProfile();

			if (maintainCustomerPage.getRowCount("Card Fees") == 0) {
				System.out.println("row count is : " + maintainCustomerPage.getRowCount("Card Fees"));
				maintainCustomerPage.createCardFees();
			}

			//maintainCustomerPage.setProfileAsDefault("Monthly");
			maintainCustomerPage.setCardFeeProfileAsDefalt("Monthly");
			// maintainCustomerPage.SaveAndDeleteProfile();

		}
		IFCSHomePage.exitIFCS();
	}

	

	/**
	 * Added by Rathna
	 * 
	 * @param clientCountry
	 * @param clientName
	 *            Busienss Flow ID:797
	 */
	@Parameters({ "clientCountry", "clientName"})
	@Test( groups = { "Regression" })
	public void defaultPublicAnualCardFeeProfile(@Optional("HK") String clientCountry,
			@Optional("EMAP") String clientName) {
		test = extent.createTest(clientName + ":" + clientCountry + "TC-1729 TC01_CustMgmt_default Public Annual Card fee",
				"RQ-797- Able to default public Monthly/Annual card fee");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		Common common = new Common(driver, test);
		MaintainCustomerPage maintainCustomerPage = new MaintainCustomerPage(driver, test);

		IFCSloginPage.login("IFCS_URL_EMAP", "IFCS_EMAP_USERNAME", "IFCS_EMAP_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");

		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		// Need to select who has no private card fee profile
		String customerNo = common.getCustomerNoHavingCardsUsingCardType();
		if (customerNo.equals(" ")) {
			common.logForNoDataFound(this.getClass().getSimpleName(), "Need to Create A Customer with Cards and rerun");
		} else {
			common.chooseCustomerNoAndSearch(customerNo);
			maintainCustomerPage.chooseMaintainCardFeesFromCustomerProfile();

			if (maintainCustomerPage.getRowCount("Card Fees") == 0)
			{
				System.out.println("row count is : "+maintainCustomerPage.getRowCount("Card Fees"));
				maintainCustomerPage.createCardFees();}

			//maintainCustomerPage.setProfileAsDefault("Annual");
			maintainCustomerPage.setCardFeeProfileAsDefalt("Annual");
			// maintainCustomerPage.SaveAndDeleteProfile();

		}
		IFCSHomePage.exitIFCS();
	}
	
	/**
	 * Added by Rathna
	 * 
	 * @param clientCountry
	 * @param clientName
	 *            
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "Regression" })
	public void  defaultPublicCardIssueFeeProfile(@Optional("HK") String clientCountry,
			@Optional("EMAP") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  BP IFCS Create New Profile for Card Reissue Profiles",
				"BP Maintain Customer -  Card  Profiles - Card Reissue Profiles  - Create New Profile");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		Common common = new Common(driver, test);
		MaintainCustomerPage maintainCustomerPage = new MaintainCustomerPage(driver, test);

		IFCSloginPage.login("IFCS_URL_EMAP", "IFCS_EMAP_USERNAME", "IFCS_EMAP_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		String customerNo = common.getCustomerNoHavingCardsUsingCardType();
		if (customerNo.equals(" ")) {
			common.logForNoDataFound(this.getClass().getSimpleName(), "Need to Create A Customer with Cards and rerun");
		} else {
			common.chooseCustomerNoAndSearch(customerNo);
			maintainCustomerPage.chooseCardReissueProfileFromCustomerProfile();
			//maintainCustomerPage.createCardReissueProfile(); commented now
			maintainCustomerPage.setCardReissueProfileAsDefalt("Reissue");

		}
		IFCSHomePage.exitIFCS();
	}

	
	/**
	 * Implemented by Davu * @param clientCountry
	 * 
	 * @param clientName
	 *            Busienss Flow ID:BF-046
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow" })
	public void updateCustomerCardFeeProfile(@Optional("HK") String clientCountry,
			@Optional("EMAP") String clientName) {

		test = extent.createTest(clientName + ":" + clientCountry + "TC-1735 TC06_CustMgmt_Upd_Card fee profiles",
				"Able to update the Monthly card fee profile");

		// creating object for the Pages
		IFCSLoginPage ifcsloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		MaintainCustomerPage maintainCustomerPage = new MaintainCustomerPage(driver, test);
		Common common = new Common(driver, test);
		// Calling Functions
		ifcsloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		ifcsloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, " ");
		//IFCSHomePage.gotoApplicationAndClickApplicationMenu();
	//	IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);
		
		
		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		String customerNumber = common.getCustomerNowithPrivateCardFee(clientCountry);
		common.chooseCustomerNoAndSearch(customerNumber);
		maintainCustomerPage.updateCardFeeProfile();
		IFCSHomePage.exitIFCS();
			
		
	}

	
	

}
