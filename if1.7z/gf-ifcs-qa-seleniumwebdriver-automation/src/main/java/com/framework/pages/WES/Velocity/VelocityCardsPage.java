package com.framework.pages.WES.Velocity;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

import com.aventstack.extentreports.ExtentTest;
import com.framework.basepage.BasePage;
import com.framework.pages.WES.common.CommonPage;
import com.framework.repo.Locator_WES;
import com.framework.util.PropUtils;

public class VelocityCardsPage extends BasePage {

	@FindBy(xpath = Locator_WES.MAINTENANCE_CALLSHEET)
	public WebElement maintenanceCallSheet;

	@FindBy(how = How.XPATH, using = Locator_WES.MANAGE_CARDS)
	public WebElement manageCards;

	@FindBy(how = How.ID, using = Locator_WES.ORDER_CARDS)
	public WebElement orderCards;

	@FindBy(how = How.XPATH, using = Locator_WES.NEW_CARD)
	public WebElement newCard;

	@FindBy(how = How.ID, using = Locator_WES.NO_OF_CARD_HOLDERS)
	public WebElement selectingCardHolders;

	@FindBy(how = How.CSS, using = Locator_WES.DRIVER_OR_VRN)
	public List<WebElement> driverOrVrnDetails;

	@FindBy(how = How.CSS, using = Locator_WES.ADDITIONAL_EMBOSS_DETAILS)
	public List<WebElement> addtionalEmbossDetails;

	@FindBy(how = How.CSS, using = Locator_WES.TYPE_CHECKBOX)
	public List<WebElement> typeCheckbox;

	@FindBy(how = How.CSS, using = Locator_WES.SUBMIT_BUTTON)
	public WebElement submit;

	@FindBy(how = How.CSS, using = Locator_WES.ALERT_MSG)
	public List<WebElement> alertMsg;

	@FindBy(how = How.ID, using = Locator_WES.BLOCKING_CARDS)
	public WebElement blockingCards;

	@FindBy(how = How.CSS, using = Locator_WES.REASON_TEXTBOX)
	public WebElement reasonTextbox;

	@FindBy(how = How.CSS, using = Locator_WES.SUBMIT_BUT)
	public WebElement submitBtn;

	@FindBy(how = How.XPATH, using = Locator_WES.CARD_NO)
	public List<WebElement> cardNo;

	@FindBy(how = How.XPATH, using = Locator_WES.FIRST_ROW_CARDNO)
	public WebElement firstRowCardNo;

	@FindBy(how = How.ID, using = Locator_WES.PIN_REMINDER_BUTTON)
	public WebElement pinMailerBtn;

	@FindBy(how = How.ID, using = Locator_WES.MANAGE_GROUPS)
	public WebElement manageGroups;

	@FindBy(how = How.ID, using = Locator_WES.NEW_GROUPS)
	public WebElement newGroups;

	@FindBy(how = How.ID, using = Locator_WES.GROUP_NAME)
	public WebElement groupNameLocator;

	@FindBy(how = How.CSS, using = Locator_WES.OK_BUTTON)
	public WebElement okBtn;

	@FindBy(how = How.ID, using = Locator_WES.ASSIGN_CARDS_TO_GRP)
	public WebElement assignCards;

	@FindBy(how = How.CSS, using = Locator_WES.COSTCENTRE_NAME)
	public List<WebElement> costCentreName;

	@FindBy(how = How.CSS, using = Locator_WES.SELECT_RADIO_BUTTON)
	public List<WebElement> radioBtn;

	@FindBy(how = How.CSS, using = Locator_WES.NEXT_BTN)
	public WebElement nxtBtn;

	@FindBy(how = How.CSS, using = Locator_WES.CARD_PACK)
	public List<WebElement> cardPack;

	@FindBy(how = How.CSS, using = Locator_WES.CARD_BRAND)
	public List<WebElement> cardBrand;

	@FindBy(how = How.CSS, using = Locator_WES.CARD_NUMBER)
	public List<WebElement> hiddenCardNumber;

	@FindBy(how = How.ID, using = Locator_WES.SORTABLE_CARDS)
	public WebElement assignTable;

	@FindBy(how = How.XPATH, using = Locator_WES.UNASSIGNED_COUNTS)
	public WebElement unassignedCounts;

	@FindBy(how = How.CSS, using = Locator_WES.HOMEICON)
	public WebElement homeIcon;

	@FindBy(how = How.ID, using = Locator_WES.FILTER_CARD_NUMBER)
	public WebElement cardNoFilter;

	@FindBy(how = How.XPATH, using = Locator_WES.TABLE_HEADER)
	public List<WebElement> tableHeader;

	@FindBy(how = How.XPATH, using = Locator_WES.TABLE_DATA_VALUES)
	public List<WebElement> tableData;

	@FindBy(how = How.CSS, using = Locator_WES.CUTOMER_NAME_HEADER)
	public WebElement customerDetails;

	@FindBy(how = How.CSS, using = Locator_WES.USER_BTN)
	public WebElement userBtn;

	@FindBy(how = How.ID, using = Locator_WES.CITY_TXTBOX)
	public WebElement cityTxtBox;

	@FindBy(how = How.XPATH, using = Locator_WES.CHANGE_YOUR_DETAILS)
	public WebElement changeYourDetails;

	@FindBy(how = How.ID, using = Locator_WES.CONTACT_NO_TXTBOX)
	public WebElement contactNoTxtBox;

	public VelocityCardsPage(WebDriver driver, ExtentTest test) {
		super(driver, test);
		PageFactory.initElements(new AjaxElementLocatorFactory(driver, 15), this);
	}

	public String validatingAndCreatingNewCards(String noOfCards, String type) {
		String embossNameOrCard = "";
		if (type.contains("Block")) {
			embossNameOrCard = blockingCard();
		} else {
			navigatingToManageCards();
			creatingNewCards();
			embossNameOrCard = enteringMandatoryFileds(noOfCards, type);
		}
		return embossNameOrCard;

	}

	public void navigatingToManageCards() {
		sleep(2);
		isDisplayedThenActionClick(manageCards, "manageCards");
		verifyTitle("Manage Cards");
	}

	public void creatingNewCards() {
		sleep(2);
		isDisplayedThenActionClick(orderCards, "orderCards");

		sleep(2);
		verifyTitle("Order Additional Cards");
		isDisplayedThenActionClick(newCard, "newCard");
		waitForPageLoad(30);
		sleep(2);
	}

	public String blockingCard() {
		navigatingToManageCards();
		sleep(2);
		isDisplayedThenActionClick(blockingCards, "orderCards");
		sleep(2);
		verifyTitle("Put Cards On Stop");
		System.out.println("s1");
		JavascriptExecutor executor = (JavascriptExecutor) driver;
		executor.executeScript("arguments[0].click();", typeCheckbox.get(0));
		String cardNumber = getText(cardNo.get(0));
		System.out.println("cardNumber--> " + cardNumber);
		logInfo("cardNumber--> " + cardNumber);
		isDisplayedThenEnterText(reasonTextbox, "Reason for blocking", "Not Needed");
		sleep(2);
		takeScreenshot();
		sleep(2);
		return cardNumber;

	}

	public String enteringMandatoryFileds(String noOfCards, String type) {
		String clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		selectDropDownByVisibleText(selectingCardHolders, noOfCards);
		int no = Integer.parseInt(noOfCards);
		sleep(10);
		String name = fakerAPI().name().lastName();
		logInfo("Details for ref -->" + name);
		for (int i = 0; i < no; i++) {
			isDisplayedThenEnterText(driverOrVrnDetails.get(i), "Driver or VRN Details", name + i);
			sleep(3);
			isDisplayedThenEnterText(addtionalEmbossDetails.get(i), "Additional Emboss data", name + i);
			sleep(3);
			takeScreenshot();
			sleep(3);
		}

		if (clientCountry.equalsIgnoreCase("UK")) {

			if (type.equals("Esso")) {
				for (int j = 1; j < no * 3;) {
					isDisplayedThenActionClick(typeCheckbox.get(j), "type check box");
					sleep(3);
					takeScreenshot();
					j = j + 3;
					sleep(3);
				}
			} else if (type.equals("UK Fuels")) {
				for (int j = 2; j < no * 3;) {
					isDisplayedThenActionClick(typeCheckbox.get(j), "type check box");
					sleep(3);
					takeScreenshot();
					j = j + 3;
					sleep(3);
				}
			} else if (type.equals("EDC")) {
				for (int j = 0; j < no * 3;) {
					isDisplayedThenActionClick(typeCheckbox.get(j), "type check box");
					sleep(3);
					takeScreenshot();
					j = j + 3;
					sleep(3);
				}
			} else if (type.equals("Multiple")) {
				for (int j = 0; j < no * 3; j++) {
					isDisplayedThenActionClick(typeCheckbox.get(j), "type check box");
					sleep(3);
					takeScreenshot();
					sleep(3);
				}
			}
		} else {
			if (type.equals("Esso")) {
				for (int j = 1; j < no * 2;) {
					isDisplayedThenActionClick(typeCheckbox.get(j), "type check box");
					sleep(3);
					takeScreenshot();
					j = j + 3;
					sleep(3);
				}
			} else if (type.equals("EDC")) {
				for (int j = 0; j < no * 2;) {
					isDisplayedThenActionClick(typeCheckbox.get(j), "type check box");
					sleep(3);
					takeScreenshot();
					j = j + 3;
					sleep(3);
				}
			} else if (type.equals("Multiple")) {
				for (int j = 0; j < no * 2; j++) {
					isDisplayedThenActionClick(typeCheckbox.get(j), "type check box");
					sleep(3);
					takeScreenshot();
					sleep(3);
				}
			}
		}
		return name;
	}

	public void clickingSubmitAndValidate(String type) {

		if (type.contains("Block")) {
			isDisplayedThenActionClick(submitBtn, "submit button");
			sleep(2);
			isDisplayedThenVerifyText(alertMsg,
					"Your request has been received. This will be processed by our customer services team shortly.",
					"Success msg");
			sleep(2);
			takeScreenshot();
			sleep(5);
		} else {
			isDisplayedThenActionClick(submit, "submit button");
			waitForPageLoad(120);
			isDisplayedThenVerifyText(alertMsg, "Your card order has been successfully submitted", "Success msg");
			sleep(2);
			takeScreenshot();
			sleep(2);
		}

	}

	public String clickingPinMailerAndValidating() {
		navigatingToManageCards();
		sleep(2);
		String cardNo = getText(firstRowCardNo);
		isDisplayedThenActionClick(firstRowCardNo, "clicking first row");
		verifyTitle("View Card");
		isDisplayedThenActionClick(pinMailerBtn, "pinMailer button");
		return cardNo;
	}

	public void navigatingToManageGroups() {
		sleep(2);
		isDisplayedThenActionClick(manageGroups, "manageGroups");
		verifyTitle("Manage Groups");
	}

	public String createNewGroupAndValidate() {
		String groupsName = fakerAPI().name().firstName();
		navigatingToManageGroups();
		sleep(2);
		isDisplayedThenActionClick(newGroups, "navigating newGroups");
		verifyTitle("New Group");
		isDisplayedThenEnterText(groupNameLocator, "Group name", groupsName);
		isDisplayedThenActionClick(okBtn, "clicking ok button");
		isDisplayedThenVerifyText(alertMsg, "Card group created successfully.", "Success msg");
		return groupsName;
	}

	public void assignCardsToCostCentreAndValidate(String groupName) {
		navigateToHome();
		navigatingToManageGroups();
		scrollDownPage();

		String beforeAssign = unassignedCounts.getText();
		System.out.println("beforeAssign" + beforeAssign);
		sleep(2);
		isDisplayedThenActionClick(assignCards, "navigating assignCards");
		verifyTitle("Assign Cards");
		scrollDownPage();
		scrollDownPage();
		sleep(3);
		WebElement grpRadiobtn = driver
				.findElement(By.xpath("//li/label[@title='" + groupName + "']/following::input[1]"));

		isDisplayedThenActionClick(grpRadiobtn, "clicking radio button");
		sleep(5);
		isDisplayedThenActionClick(nxtBtn, "clicking next button");
		sleep(5);
		scrollDownPage();
		sleep(5);

		String CardNumber = assigningCardsToCostCente(groupName);

		String afterAssign = unassignedCounts.getText();
		int before = Integer.parseInt(beforeAssign);
		int after = Integer.parseInt(afterAssign);
		if (after == before - 1) {
			logPass(CardNumber + " cardnumber Successfully assigned to the GroupName " + groupName);
			System.out.println("afterAssign" + afterAssign);
			scrollUpPage();
			scrollUpPage();
			sleep(2);
			navigateToHome();
			navigatingToManageCards();
			scrollDownPage();
			cardNumFilter(CardNumber);
			sleep(5);
			gettingValuesFromTable("group", groupName);
		} else
			logFail(CardNumber + " cardnumber not assigned to the GroupName " + groupName);
	}

	public void cardNumFilter(String cardNum) {
		isDisplayedThenEnterText(cardNoFilter, cardNum + " search filter", cardNum);
		sleep(2);
		takeScreenshot();
		sleep(2);
	}

	public void gettingValuesFromTable(String expctedHeader, String expectedData) {
		int c = 0;
		for (WebElement header : tableHeader) {
			String actualHeader = header.getText();
			System.out.println("actualHeader " + actualHeader);

			if (actualHeader.equalsIgnoreCase(expctedHeader)) {
				break;
			}
			c++;
		}
		String actualData = tableData.get(c).getText();
		System.out.println("actualData " + actualData);
		if (actualData.equalsIgnoreCase(expectedData)) {
			logInfo("Expected data found");
		} else {
			logFail("Expected data not found");
		}
	}

	public void navigateToHome() {
		isDisplayedThenActionClick(homeIcon, "Navigate to home page");
		sleep(2);
		verifyTitle(customerDetails.getAttribute("title"));
		sleep(2);
	}

	public String assigningCardsToCostCente(String name) {
		WebElement title = driver.findElement(By.cssSelector("span[title='" + name + "']"));
		isDisplayed(title, "Expected title ");
		String cardNumber = hiddenCardNumber.get(0).getAttribute("value");
		System.out.println("cardNumber --> " + cardNumber);
		logInfo(cardNumber);
		dragAndDrop(cardBrand.get(0), assignTable);
		sleep(5);
		isDisplayedThenActionClick(submitBtn, "submit button");
		sleep(3);
		scrollDownPage();
		return cardNumber;
	}

	public Map<String, String> addingCardsInMap(String cardType, String embossName_cardNo, String cusNo, int countOfCards) {

		CommonPage commonPage = new CommonPage(driver, test);

		Map<String, String> cardList = new LinkedHashMap<String, String>();

		if (countOfCards == 1) {
			if (cardType.contains("Block")) {
				String cardNo = embossName_cardNo;
				// String cardNo = "64154634163";
				cardList.put(cardType, cardNo);
			} else {
				String embossName = embossName_cardNo;
				String cardNo = commonPage.getCardNoByEmbossName(cusNo, embossName + 0);
				// String cardNo = "64154634163";
				cardList.put(cardType + "_Solo", cardNo);
			}
		} else {
			String embossName = embossName_cardNo;
			for (int i = 0; i < countOfCards; i++) {
				String cardNo = commonPage.getCardNoByEmbossName(cusNo, embossName + i);
				// String cardNo = "64154634163";
				cardList.put(cardType + "_Multi" + i, cardNo);
			}
		}
		return cardList;
	}

	public void validatingAndVerifyingCards(String expctedHeader, String expectedData, String cardType) {
		int c = 0;
		for (WebElement header : tableHeader) {
			String actualHeader = header.getText();
			System.out.println("actualHeader " + actualHeader);

			if (actualHeader.equalsIgnoreCase(expctedHeader)) {
				break;
			}
			c++;
		}
		String actualData = tableData.get(c).getText();
		System.out.println("actualData " + actualData);

		if (actualData.equalsIgnoreCase(expectedData)) {
			logInfo("Expected " + cardType + " card found");
		} else {
			softFail("Expected " + cardType + " card not found");
		}
	}

	public void updatingCustomerData(String cusNo) {
		CommonPage commonPage = new CommonPage(driver, test);

		String cityName = fakerAPI().address().cityName();
		String contactNo = fakerAPI().phoneNumber().cellPhone();
		isDisplayedThenActionClick(userBtn, "userBtn");
		sleep(3);
		isDisplayedThenActionClick(changeYourDetails, "changeYourDetails");
		sleep(2);
		verifyTitle("Change Your Details");

		isDisplayedThenEnterText(cityTxtBox, "cityTxtBox", cityName);
		isDisplayedThenEnterText(contactNoTxtBox, "contactNoTxtBox", contactNo);
		// sleep(1);
		takeScreenshot();
		sleep(1);
		JavascriptExecutor executor = (JavascriptExecutor) driver;
		executor.executeScript("arguments[0].click();", okBtn);
		// isDisplayedThenActionClick(okBtn, "okBtn");
		isDisplayedThenVerifyText(alertMsg,
				"Your changes have been submitted. Updates may take up to 24 hours to appear on your account.",
				"Success msg");
		takeScreenshot();
		sleep(1);
		logInfo("cityName --> " + cityName);

		String actualName = commonPage.getCityNameForCustomer(cusNo);
		if (actualName.equalsIgnoreCase(cityName)) {
			logPass("Successfully updated in IFCS");
		} else
			logFail("Not updated in IFCS");

	}

	public void validatingUpdatedCustomerData(String cusNo) {
		CommonPage commonPage = new CommonPage(driver, test);

		isDisplayedThenActionClick(userBtn, "userBtn");
		sleep(3);
		isDisplayedThenActionClick(changeYourDetails, "changeYourDetails");
		sleep(2);
		verifyTitle("Change Your Details");
		takeScreenshot();
		sleep(1);
		String expectedName = commonPage.getCityNameForCustomer(cusNo);
		System.out.println("getText(cityTxtBox) : " + getAttribute(cityTxtBox, "value"));
		if (expectedName.equalsIgnoreCase(getAttribute(cityTxtBox, "value"))) {
			logPass("Successfully updated in Velocity");
		} else {
			logFail("Not updated in Velocity");
		}

	}

}
