package com.framework.pages.CHEV;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.ExtentTest;
import com.framework.basepage.BasePage;
import com.framework.repo.Locator;
import com.framework.util.PropUtils;

public class CHChangePasswordPage extends BasePage {

	@FindBy(how = How.XPATH, using = Locator.SCHEDULE_REPORT_MAINTENANCE_PAGE)
	public WebElement changePasswordPageTitle;

	@FindBy(how = How.XPATH, using = Locator.CH_CONFIRMATION_MSG)
	public WebElement confirmationMessage;

	@FindBy(how = How.ID, using = Locator.CARD_INFORMATION_SAVECHANGES)
	public WebElement saveBtn;

	@FindBy(how = How.XPATH, using = Locator.CH_RELPACE_CONFIRM_ERROR_MESSAGE)
	public WebElement errorMessage;

	@FindBy(how = How.ID, using = Locator.CH_MERCHANT_CHANGE_PWD_OLD_PWD_FIELD)
	public WebElement oldPassword;

	@FindBy(how = How.ID, using = Locator.CH_MERCHANT_CHANGE_PWD_NEW_PWD_FIELD)
	public WebElement newPassword;

	@FindBy(how = How.ID, using = Locator.CH_MERCHANT_CHANGE_PWD_CONFIRM_PWD_FIELD)
	public WebElement confirmPassword;

	public CHChangePasswordPage(WebDriver driver, ExtentTest test) {
		super(driver, test);
		PageFactory.initElements(driver, this);
	}

	public void verifyPasswordMaintenancePage() {
		sleep(3);
		isDisplayed(changePasswordPageTitle, "Password Maintenance");
		logPass("Redirected to the Password Maintenance Page");
	}

	public void enterRandomValuesExceptPasswordField() {
		clearFields();
		String password = fakerAPI().name().fullName();
		enterText(newPassword, password);
		enterText(confirmPassword, password);
	}

	public void enterRandomValuesExceptConfirmationPasswordField(String Pwd) {
		clearFields();
		String password = fakerAPI().name().fullName();
		enterText(newPassword, password);
		enterText(oldPassword, PropUtils.getPropValue(configProp, Pwd));
	}

	public void enterRandomValuesWithDiffNewAndConfirm(String pwd) {
		clearFields();
		enterText(newPassword, fakerAPI().name().fullName());
		enterText(confirmPassword, fakerAPI().name().nameWithMiddle());
		enterText(oldPassword, PropUtils.getPropValue(configProp, pwd));
	}

	public void enterNewValues(String oldpwd, String newpwd) {
		clearFields();
		enterText(newPassword, newpwd);
		enterText(confirmPassword, newpwd);
		enterText(oldPassword, PropUtils.getPropValue(configProp, oldpwd));
	}

	public void clickSubmitButton() {
		if (saveBtn.isDisplayed()) {
			actionClick(saveBtn);
		} else {
			logFail("Submit Button is not displayed");
		}
	}

	public void clearFields() {
		newPassword.clear();
		oldPassword.clear();
		confirmPassword.clear();
	}

	public void checkConfirmationMessage() {
		sleep(10);
		isDisplayed(confirmationMessage, "Password Changed successfully is displayed");
	}

	public void verifyErrorMessage(String expectedMsg) {
		sleep(20);
		if (errorMessage.isDisplayed() && errorMessage.getText().contains(expectedMsg)) {
			logPass(expectedMsg + " error message is displayed");
		} else {
			logFail(expectedMsg + " error message is not displayed");
		}
	}

}
