package com.framework.pages.BP;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.ExtentTest;
import com.framework.basepage.BasePage;
import com.framework.repo.Locator;

public class BPChangeCardStatusPage extends BasePage {

	@FindBy(how = How.ID, using = Locator.CURRENT_CARD_STATUS)
	public WebElement CardStatus;
	@FindBy(how = How.ID, using = Locator.CURRENT_CARD_TYPE)
	public WebElement CardTypes;
	@FindBy(how = How.ID, using = Locator.CURRENT_CARD_NUMBER)
	public WebElement CardNumber;
	@FindBy(how = How.ID, using = Locator.CURRENT_VEHICLE_INFO)
	public WebElement VehicleInfomation;
	@FindBy(how = How.ID, using = Locator.CURRENT_VEHICLE_DESC)
	public WebElement VehicleDescription;
	@FindBy(how = How.ID, using = Locator.CARD_STATUS_GROUP)
	public WebElement CardStatusGroup;
	@FindBy(how = How.XPATH, using = Locator.CARD_STATUS_LIST)
	public List<WebElement> CardStatusTypes;
	@FindBy(how = How.ID, using = Locator.CURRENT_CARD_NUMBER)
	public WebElement CurrentCardNumber;
	@FindBy(how = How.ID, using = Locator.RETURNTO_CARD_FOUNDLIST)
	public WebElement ReturnToCardFoundListButton;
	@FindBy(how = How.ID, using = Locator.DELIVER_CONFIRM_AND_REISSUE)
	public WebElement SaveChangesButton;
	@FindBy(how = How.ID, using = Locator.CARDSTATUSCHANGE_POPUP_YESBUTTON)
	public WebElement cardStatusChangeYesOption;
	@FindBy(how = How.ID, using = Locator.CARDSTATUSCHANGE_POPUP_NOBUTTON)
	public WebElement cardStatusChangeNoOption;
	@FindBy(how = How.ID, using = Locator.CARDSTATUSCHANGE_POPUP_CLOSEBUTTON)
	public WebElement cardStatusChangeCloseButton;
	@FindBy(how = How.ID, using = Locator.CARDSTATUSCHANGE_POPUP_TEXT)
	public WebElement cardStatusChangePopupText;
	@FindBy(how = How.XPATH, using = Locator.ADDRESSDELIVERY_OPTIONS)
	public WebElement cardAddressField;
	@FindBy(how = How.ID, using = Locator.CONFIRMANDREISSUE_BUTTON)
	public WebElement confirmAndReissueButton;
	@FindBy(how = How.ID, using = Locator.CONFIRMATIONMESSAGE)
	public WebElement cardUpdateConfirmMessage;
	@FindBy(how = How.ID, using = Locator.VIEWFULLCARDDETAILS_BUTTON)
	public WebElement viewFullCardDetailsButton;
	@FindBy(how = How.ID, using = Locator.FULLCARD_DETAILS)
	public WebElement fullCardDetailsValues;
	@FindBy(how = How.ID, using = Locator.RETURNTOCARD_FOUNDLIST_BUTTON)
	public WebElement returnToCardFoundListButton;
	@FindBy(how = How.XPATH, using = Locator.SCHEDULE_REPORT_MAINTENANCE_PAGE)
	public WebElement cardChangeStatusPage;
	@FindBy(how = How.ID, using = Locator.LATER_ON_THIS_DATE_FIELD)
	public WebElement laterOnDate;
	@FindBy(how = How.CSS, using = Locator.LATER_ON_THIS_DATE)
	public List<WebElement> reissueAtOption;

	@FindBy(xpath = Locator.REPORT_DELIVERY_FULLERRORMSG)
	public WebElement errorMsg;
	private String cardNumber = "";

	public BPChangeCardStatusPage(WebDriver driver, ExtentTest test) {
		super(driver, test);
		PageFactory.initElements(driver, this);
	}

	public void verifyChangeCardStatusPage() {
		sleep(3);
		isDisplayed(cardChangeStatusPage, "Card Status value");
		logPass("Redirected to the Change Card Status Page");

	}

	public void changeTheCardStatus() {
		try {
			if (CardStatusGroup.isDisplayed()) {
				boolean radioButtonSelectOption = selectRadioButtonFromList(CardStatusTypes, "Temp",
						"data-summary-value");
				sleep(3);
				if (radioButtonSelectOption) {
					logPass("Selected the card status successfully");
				} else {
					logFail("Card Status is not selected");
				}
			}
		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
	}

	public void clickLaterOnDateOptionAndProvideADate() {
		try {
			selectRadioButtonFromList(reissueAtOption, "On this Later date:", "data-summary-value");
			sleep(5);
			String laterOnDateValue;
			String currentDate = getAttribute(laterOnDate, "value");
			Date dateGen = new SimpleDateFormat("dd/MM/yyyy").parse(currentDate);
			Date newDate;
			Calendar cal = Calendar.getInstance();
			cal.setTime(dateGen);
			cal.add(Calendar.DATE, +3);
			newDate = cal.getTime();
			DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
			laterOnDateValue = df.format(newDate);
			System.out.println("Updated Date:: " + laterOnDateValue);
			isDisplayedThenEnterText(laterOnDate, "Later On Date", laterOnDateValue);
			sleep(2);
		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
	}

	public void getCurrentCardNumber() {
		isDisplayed(CurrentCardNumber, "Get Current Card No.");
		cardNumber = getText(CurrentCardNumber).trim();
	}

	public void clickOnSaveChangesButton() {
		sleep(3);
		isDisplayedThenActionClick(SaveChangesButton, "Save Changes button is not clickable");
	}

	public void verifyChangeCardStatusPopup() {
		sleep(5);
		mouseHover(cardStatusChangeYesOption);

		isDisplayed(cardStatusChangeYesOption, "Card status confirmation Popup YES button");
		logPass("Card Status Change Popup is displayed");
		// isDisplayed(cardStatusChangeNoOption, "Card status confirmation Popup NO
		// button");
		// isDisplayed(cardStatusChangeCloseButton, "Card status confirmation Popup
		// CLOSE button");
	}

	public void clickOnYesButtonInCardStatusPopup() {
		isDisplayedThenActionClick(cardStatusChangeYesOption, "Clicked the YES button in Card status popup");
	}

	public void verifyConfirmAddressPageField() {
		isDisplayed(cardAddressField, "Card Address Field");
		logPass("Redirect to the Confirm Address Page Field");
		isDisplayed(confirmAndReissueButton, "Confirm and Reissue button");
	}

	public void clickConfirmAndReissueButton() {
		isDisplayedThenActionClick(confirmAndReissueButton, "Confirm and Reissue Button");

	}

	public void verifyCardStatusUpdatePage() {
		isDisplayed(cardUpdateConfirmMessage, "Card update confirmation message");
		logPass("Redirect to Card Status Update page");
	}

	public boolean isReissueDateErrorMsgPresent() {
		boolean isReissueDateIssuePresent = false;
		try {
			System.out.println("im Checking Error Msg");
			sleep(2);
			if (errorMsg.isDisplayed()) {
				clickLaterOnDateOptionAndProvideADate();
				isReissueDateIssuePresent = true;
			}
		} catch (Exception ex) {
			logInfo("No Error Msg");
			return isReissueDateIssuePresent;
		}
		return isReissueDateIssuePresent;
	}

	public void verifyConfirmationMessage() {
		String confirmationMessage = getText(cardUpdateConfirmMessage);
		if (confirmationMessage.contains(cardNumber)) {
			if (getText(cardUpdateConfirmMessage).contains("Temp")) {
				logPass("Changed Card Status values is displayed in confirmation Message");
			} else {
				logFail("Changed card status values is not displayed in confirmation message");
			}
		} else {
			logFail("Card Number is not displayed in confimation message");
		}
	}

	public void clickOnFullCardDetailsButton() {
		isDisplayedThenActionClick(viewFullCardDetailsButton, "View Full Card Details Button");
	}

	public void verifyFullCardDetailsPageField() {
		/*
		 * isDisplayed(fullCardDetailsValues, "Full Card Details values");
		 * logPass("Redirect to Full Card Details Page");
		 */
		isDisplayed(returnToCardFoundListButton, "Return to Card Found List button");
	}

	public void clickOnReturnToFullCardDetailsButton() {
		isDisplayedThenActionClick(returnToCardFoundListButton, "Return to Card Found List button");
	}

}
