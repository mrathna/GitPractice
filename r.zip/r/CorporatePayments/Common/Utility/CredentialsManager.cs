﻿extern alias cpt;

using Amazon;
using Amazon.SecretsManager;
using Amazon.SecretsManager.Model;
using SecretServer.Processor;
using System;
using System.IO;
using System.Collections.Generic;
using System.Dynamic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace Common.Utility
{
	public class CredentialsManager
	{

		#region KnoxSecretMethods
		/*
		public string ServerUrl { get; private set; }

		public CredentialsManager(string url)
		{
			ServerUrl = url;
		}
		*/

		/// <summary>
		/// OLD METHOD USING KNOX - DELETE AT SOME POINT
		/// </summary>
		/// <param name="secretName"></param>
		/// <returns></returns
		/*
		public CredentialSecret GetCredentials(string secretName)
		{
			using (SecretServerProcessor secretServerClient = new SecretServerProcessor(ServerUrl))
			{
				ExpandoObject secret = null;

				// If secret name starts with Regression Automation prefix then proceed with Username/Pwd required to access Knox
				if (secretName.StartsWith(GlobalSettings.REG_SS_PREFIX))
					secret = (ExpandoObject)secretServerClient.GetSecret(secretName, GlobalSettings.SSUsername, GlobalSettings.SSPassword, GlobalSettings.SSDomain);
				else if(secretName.EndsWith("RanorexSuper", StringComparison.InvariantCultureIgnoreCase))
					secret = (ExpandoObject)secretServerClient.GetSecret(secretName);
				else
					secret = (ExpandoObject)secretServerClient.GetSecret(secretName);

				if (secret == null)
				{
					return null;
				}
				return new CredentialSecret(secretName, secret);
			}
		}
		*/

		// <summary>
		/// OLD METHOD USING KNOX - DELETE AT SOME POINT
		/// </summary>
		/// <param name="secretName"></param>
		/// <returns></returns
		/*
		public string GenerateNewPassword(string secretName)
		{
			string newPassword = null;
			using (SecretServerProcessor secretServerClient = new SecretServerProcessor(ServerUrl))
			{
				newPassword = secretServerClient.UpdatePassword(secretName, "Password", null);
			}
			return newPassword;
		}
		*/

		#endregion


		/// <summary>
		/// Retrieve the login credentials for an existing ENCSuper user in AWS 
		/// </summary>
		/// <param name="secretName"></param>
		/// <returns></returns>
		public CredentialSecret GetCredentials(string secretName)
		{
			CredentialSecret secret = null;
			try
			{
				IAmazonSecretsManager client = new AmazonSecretsManagerClient(GlobalSettings.AWSAccessKeyId, GlobalSettings.AWSAccessKey, RegionEndpoint.GetBySystemName(GlobalSettings.AWSRegion));

				GetSecretValueRequest request = new GetSecretValueRequest();
				request.SecretId = secretName;

				GetSecretValueResponse response = null;
				response = client.GetSecretValueAsync(request).Result;

				if (response.SecretString != null)				
					secret = cpt.Newtonsoft.Json.JsonConvert.DeserializeObject<CredentialSecret>(response.SecretString);				
			}
			catch (Exception ex)
			{
				Logger.LogError($"Could not get credentials for {secretName} in AWS, hence trying to read value from App Config");
				Logger.LogError(ex.StackTrace);
			}
			finally
			{
				// If Secret is null then fall back and gather creds from app config to form a secret				
				secret = (secret == null) ? new CredentialSecret()
				{
					SecretName = "Not Applicable",
					Username = GlobalSettings.SuperAdminUser,
					Password = GlobalSettings.SuperAdminPwd,
					OrgId = GlobalSettings.SuperOrgId					
				} :  secret;				
			}

			return secret;		
		}

		/// <summary>
		/// Update the password for an existing ENCSuper user in AWS
		/// </summary>
		/// <param name="secretName"></param>
		/// <returns></returns>
		public void UpdatePassword(string secretName, string newPassword)
		{
			try
			{

				MemoryStream memoryStream = new MemoryStream();

				IAmazonSecretsManager client = new AmazonSecretsManagerClient(GlobalSettings.AWSAccessKeyId, GlobalSettings.AWSAccessKey, RegionEndpoint.GetBySystemName(GlobalSettings.AWSRegion));

				GetSecretValueRequest request = new GetSecretValueRequest();
				request.SecretId = secretName;

				GetSecretValueResponse response = null;

				response = client.GetSecretValueAsync(request).Result;

				if (response.SecretString != null)
				{
					var currentCreds = cpt.Newtonsoft.Json.JsonConvert.DeserializeObject<CredentialSecret>(response.SecretString);
					currentCreds.Password = newPassword;
					var newCreds = cpt.Newtonsoft.Json.JsonConvert.SerializeObject(currentCreds);

					PutSecretValueRequest update = new PutSecretValueRequest()
					{
						SecretId = secretName,
						SecretString = newCreds
					};

					PutSecretValueResponse updateCreds = null;

					updateCreds = client.PutSecretValue(update);
				}
			}

			catch (Exception ex)
			{
				Logger.LogError($"Could not update password for {secretName} in AWS");
				throw ex;
			}
		}


		/// <summary>
		/// Create a new ENCSuper User in AWS
		/// </summary>
		/// <param name="secretName"></param>
		/// <param name="Username"></param>
		/// <param name="password"></param>
		/// <param name="organizationID"></param>
		public void CreateSecret(string secretName, string Username, string password, string organizationID)
		{
			try
			{
				var newSecret = new CredentialSecret()
				{
					SecretName = secretName,
					Username = Username,
					Password = password,
					OrgId = organizationID
				};

				string json = cpt.Newtonsoft.Json.JsonConvert.SerializeObject(newSecret);

				IAmazonSecretsManager client = new AmazonSecretsManagerClient(GlobalSettings.AWSAccessKeyId, GlobalSettings.AWSAccessKey, RegionEndpoint.GetBySystemName(GlobalSettings.AWSRegion));

				var request = new CreateSecretRequest();
				request.Name = secretName;
				request.SecretString = json;

				var response = client.CreateSecret(request).Name;

			}
			catch (Exception ex)
			{
				Logger.LogError($"Could not Create Secret for {secretName} in AWS");
				throw ex;
			}
		}
	}

	public class CredentialSecret
	{
		public string SecretName { get; set; }
		public string Username { get; set; }
		public string Password { get; set; }
		public string OrgId { get; set; }

		[cpt.Newtonsoft.Json.JsonIgnore]
		public bool IsValid
		{
			get
			{
				return !string.IsNullOrWhiteSpace(Username)
					&& !string.IsNullOrWhiteSpace(Password)
					&& !string.IsNullOrWhiteSpace(OrgId);
			}
		}

		public CredentialSecret() { }

		public CredentialSecret(string secretName, ExpandoObject secret)
		{
			var secretValues = secret as IDictionary<string, object>;

			SecretName = secretName;
			Username = secretValues["Username"].ToString();
			Password = secretValues["Password"].ToString();
			OrgId = secretValues["Organization ID"].ToString();
		}
	}
}
