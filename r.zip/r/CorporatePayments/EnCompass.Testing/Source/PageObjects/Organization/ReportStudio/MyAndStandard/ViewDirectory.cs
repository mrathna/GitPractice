﻿using Common;
using Common.Utility;
using EnCompass.Testing.Source.PageObjects.Organization.ReportStudio.StandardReports;
using NFluent;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Support.UI;
using System.Collections.Generic;

namespace EnCompass.Testing.Source.PageObjects.Organization.ReportStudio.MyAndStandard
{
	public partial class ViewDirectory
	{
        #region XPATH

        public override string PageIdentifierXPath_Override => @"//li[contains(@class, 'breadcrumb-item active')][text() = 'My Reports' or text() = 'Company Reports' or text() = 'Standard Reports' or text() = 'Accounts Payable' or text() = 'Admin' or text() = 'My Reports Subfolder' or text() = 'Reports']";
        private const string _executeUserStandardReportXPath = @".//a[contains(@href,'standardReports/UserReport.aspx') and normalize-space(text())='Execute']";
        private string standardReportURL = @"/ReportStudio/MyAndStandard/ViewDirectory.aspx?FolderType=STANDARD";
        private static string reportStudioMenuXPath = "//a[@id = 'reportStudioMenuHref']";
        private const string myReportsMenuXPath = @"//a[normalize-space(text())='My Reports']";
        private const string companyReportsMenuXPath = @"//a[normalize-space(text())='Company Reports']";
        private const string orgScheduledReportsMenuXPath = @"//a[normalize-space(text())='Organization Scheduled Reports']";

        #endregion

        #region Private Elements

        public IWebElement _executeUserStandardReport
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_executeUserStandardReportXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_executeUserStandardReport element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement reportStudioMenu
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(reportStudioMenuXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("reportStudioMenu element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement myReportsMenu
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(myReportsMenuXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("myReportsMenu element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        public IWebElement companyReportsMenu
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(companyReportsMenuXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("companyReportsMenu element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        public IWebElement orgScheduledReportsMenu
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(orgScheduledReportsMenuXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("orgScheduledReportsMenu element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        #endregion

        public void ExecuteUserStandardReport()
		{
			_executeUserStandardReport.JSClickWithFocus(Driver);
			UserReport _userReport = new UserReport(Settings);
			_userReport.WaitForLoad();
		}

        public void NavigateToStandardReports()
        {
            //As FireFox Doesn't support MoveToElement Actions, it fails most of the time. Hence changed to URL based navigation
            Settings.EnCompassWebDriver.Url = GlobalSettings.BaseEncompassUrl + standardReportURL;
            Driver.WaitForDocumentLoadToComplete();
       
        }
        public void NavigateToMyReports()
        {
            Actions actions = new Actions(Driver);
            actions.MoveToElement(reportStudioMenu).Build().Perform();
            Actions new_actions = new Actions(Driver);
            new_actions.MoveToElement(myReportsMenu).Click().Build().Perform();
        }

        public void NavigateToCompanyReports()
        {
            Actions actions = new Actions(Driver);
            actions.MoveToElement(reportStudioMenu).Build().Perform();
            Actions new_actions = new Actions(Driver);
            new_actions.MoveToElement(companyReportsMenu).Click().Build().Perform();
        }

        public void NavigateToOrganizationScheduledReports()
        {

            Actions actions = new Actions(Driver);
            actions.MoveToElement(reportStudioMenu).Build().Perform();
            Actions new_actions = new Actions(Driver);
            new_actions.MoveToElement(orgScheduledReportsMenu).Click().Build().Perform();
        }

        public void SelectReport(string reportName, string action = "open")
        { 
            // Notifications report has different names accross different FIs. That's why this verification need to
            // be performed.
            switch (reportName)
            {
                case "Notifications":
                    reportName = StringKeys.NotificationReportNamePerFI[GlobalSettings.FI];
                    Settings.EnCompassExtentTest.Info($"reportName 'Notifications' set to {reportName}.");
                    break;
            }

            //Selecting the action to be executed upon the report
            if (action.ToLowerInvariant().Equals("execute") || action.ToLowerInvariant().Equals("schedule") ||
                action.ToLowerInvariant().Equals("edit"))
            {
                string buttonXPath = $"//a[normalize-space(string())='{reportName.Trim()}']/../../..//button[contains(@id, 'reportActions')]";
                string actionXPath = $"//a[normalize-space(string())='{reportName.Trim()}']/../../..//a[contains(text(), '{action}') and @class='dropdown-item']";
                Driver.FindElement(By.XPath(buttonXPath)).JSClickWithFocus(Driver);
                Settings.EnCompassExtentTest.Info($"Clicked on button of report {reportName}");
                Driver.FindElement(By.XPath(actionXPath)).JSClickWithFocus(Driver);
                Settings.EnCompassExtentTest.Info($"Clicked on action {action} of {reportName}.");
            }

            else if(action.ToLowerInvariant().Equals("delete"))
            {
                string buttonXPath = $"//a[normalize-space(string())='{reportName.Trim()}']/../../..//button[contains(@id, 'reportActions')]";
                string actionXPath = $"//a[normalize-space(string())='{reportName.Trim()}']/../../..//input[@value = 'Delete']";
                Driver.FindElement(By.XPath(buttonXPath)).JSClickWithFocus(Driver);
                Settings.EnCompassExtentTest.Info($"Clicked on button of report {reportName}");
                Driver.FindElement(By.XPath(actionXPath)).JSClickWithFocus(Driver);
                Settings.EnCompassExtentTest.Info($"Clicked on action Delete of {reportName}.");
            }

            else if (action.ToLowerInvariant().Equals("open") || action.ToLowerInvariant().Equals("none"))
            {
                //Selecting the action to be executed upon the report
                Driver.ScrollToXPATH($@"//div[@class = 'card-body']//a[contains(@id,'dltReport') and normalize-space(string())='{reportName.Trim()}']");
                Settings.EnCompassWebDriver.WaitElementBeClickable($@"//div[@class = 'card-body']//a[contains(@id,'dltReport') and normalize-space(string())='{reportName.Trim()}']");
                string xpath = $@"//div[@class = 'card-body']//a[contains(@id,'dltReport') and normalize-space(string())='{reportName.Trim()}']";
                Driver.FindElement(By.XPath(xpath)).JSClickWithFocus(Driver);
                Settings.EnCompassExtentTest.Info($"Clicked directly on Report {reportName} to open it.");
            }

        }

        public bool FindReport(string reportNameWithFolder)
        {
            //Searching the report inside some folder
            IWebElement ele;

            if (reportNameWithFolder.Contains(@"/"))
            {
                string folderXPath = $"//a[normalize-space(string())='{reportNameWithFolder.Split('/')[0]}' and contains(@id,'lkbFolderName')]";
                string reportName = reportNameWithFolder.Split('/')[1];


                // Notifications report has different names accross different FIs. That's why this verification need to
                // be performed 
                switch (reportName)
                {
                    case "Notifications":
                        reportName = StringKeys.NotificationReportNamePerFI[GlobalSettings.FI];
                        Settings.EnCompassExtentTest.Info($"reportName 'Notifications' set to {reportName}.");
                        break;
                }

                Driver.FindElement(By.XPath(folderXPath)).JSClickWithFocus(Driver);
                Driver.TryFindElement(By.XPath($@"//a[normalize-space(string())='{reportName}']"), out ele);
            }

            else
                Driver.TryFindElement(By.XPath($@"//a[normalize-space(string())='{reportNameWithFolder}']"), out ele);

            return ele != null;
        }

        //Select 
        public void SelectMyReportByNewFolder(string folderName)
        {
            //Selecting the folder
            string buttonCreateXPath = "//button[contains(@id,'createOptions')]";
            string actionXPath = $"//a[normalize-space(string())='{folderName.Trim()}']";
            Driver.FindElement(By.XPath(buttonCreateXPath)).JSClickWithFocus(Driver);
            Driver.FindElement(By.XPath(actionXPath)).JSClickWithFocus(Driver);
            Settings.EnCompassExtentTest.Info($"Clicked Create button and action {folderName}.");
        }

        public void CheckReportSaved(string reportSaved)
        {
            WaitForLoad();
            //Selecting the folder appears
            Settings.EnCompassWebDriver.WaitForElements(By.XPath($@"(//a[normalize-space(string())='{reportSaved.Trim()}'])"));
        }

        public void CheckReportAndActions(string reportName, List<string> actions)
        {
            WaitForLoad();
            //Selecting the folder appears
            string buttonXPath = $"//a[normalize-space(string())='{reportName.Trim()}']/../../..//button[contains(@id, 'reportActions')]";
            Driver.FindElement(By.XPath(buttonXPath)).JSClickWithFocus(Driver);
            WaitForLoad();
            foreach (string action in actions)
            {
                if(action.Trim().Equals("Delete"))
                    Settings.EnCompassWebDriver.WaitForElements(By.XPath($@"(//a[normalize-space(string())='{reportName.Trim()}']/../../..//input[contains(@id, 'reportDelete')])"));
                else
                    Settings.EnCompassWebDriver.WaitForElements(By.XPath($@"(//a[normalize-space(string())='{reportName.Trim()}']/../../..//a[contains(text(),'{action.Trim()}')])"));
            }
        }

        public void SelectReportByFolder(string reportNameAtFolder, string folderName, string action)
        {
            Driver.FindElement(By.XPath($"//a[normalize-space(string())='{folderName.Trim()}' and contains(@id, 'lkbFolderName')]")).JSClickWithFocus(Driver);
            WaitForLoad();
            Settings.EnCompassExtentTest.Info($"Navigated to Folder {folderName}.");

            switch (reportNameAtFolder)
            {
                case "Notifications":
                    reportNameAtFolder = StringKeys.NotificationReportNamePerFI[GlobalSettings.FI];
                    Settings.EnCompassExtentTest.Info($"ReporNameAtFolder 'Notifications' set to {reportNameAtFolder}.");
                    break;
            }

            //Selecting the action to be executed upon the report
            if (action.ToLowerInvariant().Equals("execute") || action.ToLowerInvariant().Equals("schedule"))
            {
                string buttonXPath = $"//a[normalize-space(string())='{reportNameAtFolder.Trim()}']/../../..//button[contains(@id, 'reportActions')]";
                string actionXPath = $"//a[normalize-space(string())='{reportNameAtFolder.Trim()}']/../../..//a[contains(text(), '{action}')]";
                Driver.FindElement(By.XPath(buttonXPath)).JSClickWithFocus(Driver);
                Driver.FindElement(By.XPath(actionXPath)).JSClickWithFocus(Driver);
                Settings.EnCompassExtentTest.Info($"Clicked on action {action} of {reportNameAtFolder}.");
            }

            else if (action.ToLowerInvariant().Equals("open"))
            {
                Driver.FindElement(By.XPath($"//a[normalize-space(string())='{reportNameAtFolder.Trim()}']")).JSClickWithFocus(Driver);
                Settings.EnCompassExtentTest.Info($"Opened report {reportNameAtFolder}.");
            }
        }
	}
}
