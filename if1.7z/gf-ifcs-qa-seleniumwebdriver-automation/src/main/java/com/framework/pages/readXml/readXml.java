package com.framework.pages.readXml;

import java.io.File;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class readXml {
	public LinkedHashMap<String,String> tagAndValue = null;
	public List<Node> listOfNodes = null;
	LinkedHashMap<String,String> ChildNodeElements=new LinkedHashMap<String,String>();


	public LinkedHashMap<String,String> getAllTagsAndValues(String filePath) throws ParserConfigurationException
	{
		File file=new File(filePath);
		DocumentBuilderFactory dbfactory=DocumentBuilderFactory.newInstance();
		DocumentBuilder db=dbfactory.newDocumentBuilder();
		Document doc;
		try{
			doc=db.parse(file);
			doc.getDocumentElement().normalize();
			String rootNode=doc.getDocumentElement().getNodeName();
			tagAndValue=new LinkedHashMap<String,String>();
			listOfNodes=new ArrayList<Node>();
			System.out.println("Root node : "+rootNode);
			NodeList nodeList=doc.getDocumentElement().getChildNodes();
			/*listOfNodes=getChildNodes(nodeList);
			for(Node child:listOfNodes)
			{
				if(child.getNodeType() == Node.TEXT_NODE)
				{
					tagAndValue.put(child.getNodeName(),child.getTextContent());
				}
				else {
					System.out.println("Else block"+child.getNodeName());
					tagAndValue.put(child.getNodeName(),"");
				}
			}*/
			
			//tagAndValue.putAll(getChildNodesOfParentNode(nodeList));
			tagAndValue.putAll(getChildNodeElements(nodeList));
		}
		catch(Exception e)
		{
			System.err.println(e);
		}
		return tagAndValue;
	}
	public LinkedHashMap<String,String> getElementsByTagName(String tagName,String path) throws ParserConfigurationException
	{
		File file=new File(path);
		DocumentBuilderFactory dbfactory=DocumentBuilderFactory.newInstance();
		DocumentBuilder db=dbfactory.newDocumentBuilder();
		Document doc;
		try{
			doc=db.parse(file);
			doc.getDocumentElement().normalize();
			String rootNode=doc.getDocumentElement().getNodeName();
			System.out.println("Root node : "+rootNode);
			NodeList nodelist=doc.getDocumentElement().getChildNodes();
			listOfNodes=new ArrayList<Node>();
			tagAndValue=new LinkedHashMap<String,String>();
			listOfNodes=getChildNodes(nodelist);
			int count=0;
			for(Node i:listOfNodes)
			{
				if(i.getNodeName().equalsIgnoreCase(tagName))
				{
					count+=1;
					tagAndValue.put(i.getNodeName()+" "+count+" - ", i.getTextContent());
				}
			}
		}
		catch(Exception e)
		{
			System.err.println(e);
		}
		if(tagAndValue.size()==0)
		{
			tagAndValue.put("No matching","Please specify the correct tag");
		}
		return tagAndValue;
	}
	public LinkedHashMap<String,String> getElementsByTagNameUsingIndex(String tagName,String path,int index) throws ParserConfigurationException
	{
		File file=new File(path);
		DocumentBuilderFactory dbfactory=DocumentBuilderFactory.newInstance();
		DocumentBuilder db=dbfactory.newDocumentBuilder();
		Document doc;
		try{
			doc=db.parse(file);
			doc.getDocumentElement().normalize();
			String rootNode=doc.getDocumentElement().getNodeName();
			System.out.println("Root node : "+rootNode);
			NodeList nodelist=doc.getDocumentElement().getChildNodes();
			listOfNodes=new ArrayList<Node>();
			tagAndValue=new LinkedHashMap<String,String>();
			listOfNodes=getChildNodes(nodelist);
			int count=0;
			for(Node i:listOfNodes)
			{
				if(i.getNodeName().equalsIgnoreCase(tagName))
				{
					count+=1;
					if(count == index)
					{
					tagAndValue.put(i.getNodeName()+" of index "+count+" is ", i.getTextContent());
					}
				}
			}
		}
		catch(Exception e)
		{
			System.err.println(e);
		}
		if(tagAndValue.size()==0)
		{
			tagAndValue.put("No matching","Please specify the correct tag");
		}
		return tagAndValue;
	}
	public List<Node> getChildNodes(NodeList nodeList)
	{
		for(int i=0;i<nodeList.getLength();i++)
		{
			Node node=nodeList.item(i);
			if(node.getNodeType() == Node.ELEMENT_NODE)
			{
				listOfNodes.add(node);
				if(node.hasChildNodes())
				{	
					NodeList childNodes=node.getChildNodes();
					getChildNodes(childNodes);
				}
			}
		}
		return listOfNodes;
	}
	public LinkedHashMap<String, String> getChildNodesOfParentNode(NodeList nodeList)
	{
		LinkedHashMap<String,String> childNodesOfParentNode=new LinkedHashMap<String,String>();
		for(int i=0;i<nodeList.getLength();i++)
		{
			Node node=nodeList.item(i);
			if(node.getNodeType() == Node.ELEMENT_NODE)
			{	
				if(node.hasChildNodes())
				{
				childNodesOfParentNode.put(node.getNodeName(),"");
				}
				childNodesOfParentNode.put(node.getNodeName(),node.getTextContent());
			}
		}
		return childNodesOfParentNode;
	}
	public String getElementByTagName(Node node)
	{
		String tagElement;
		Element element=(Element) node;
		if(element.getTextContent().isEmpty())
		{
			System.out.println("null");
			tagElement="null";
		}
		else{
			tagElement=element.getTextContent();
		}
		return tagElement;
	}
	public LinkedHashMap<String,String> getChildNodeElements(NodeList nodeList)
	{
		for(int i=0;i<nodeList.getLength();i++)
		{
			Node node=nodeList.item(i);
			if(node.getNodeType() == Node.ELEMENT_NODE)
			{
				if(node.hasChildNodes())
				{	
					NodeList childNodes=node.getChildNodes();
					ChildNodeElements.put(node.getNodeName(),"");
					//getChildNodesOfParentNode(childNodes);
					getChildNodeElements(childNodes);
					//continue;
				}
				ChildNodeElements.put(node.getNodeName(),getElementByTagName(node));
			}
		}
		return ChildNodeElements;
	}
	
}
