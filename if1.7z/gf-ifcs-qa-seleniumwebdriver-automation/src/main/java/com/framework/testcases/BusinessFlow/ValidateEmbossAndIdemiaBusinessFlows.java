package com.framework.testcases.BusinessFlow;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.CardMaintenancePage;
import com.framework.pages.AJS.ChangeCardStatus;
import com.framework.pages.AJS.OrderCardPage;
import com.framework.pages.AJS.common.Common;
import com.framework.pages.AJS.common.CommonInterfacePage;
import com.framework.pages.AJS.common.IFCSCommonPage;
import com.framework.pages.AJS.common.IFCSHomePage;
import com.framework.pages.AJS.common.IFCSLoginPage;
import com.framework.pages.AJS.common.InterfacePage;
import com.framework.pages.OLS.common.FindAndUpdateCardPage;

public class ValidateEmbossAndIdemiaBusinessFlows extends BaseTest {

	/**
	 * Added by Nithya
	 * 
	 * @param clientCountry
	 * @param clientName    Busienss Flow ID:RQ-827
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "BusinessFlow" })
	public void embossFileGeneration(@Optional("AU") String clientCountry, @Optional("BP") String clientName) {
		test = extent.createTest(
				clientName + ":" + clientCountry + "RQ-827 TC-783 TC01_CardMgmt_Emb_Embossing file generation",
				"Embossing file generated for card embossing process");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		Common common = new Common(driver, test);
		OrderCardPage orderCardPage = new OrderCardPage(driver, test);
		IFCSloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		String customerNumber = common.getActiveOrTemporaryBlockCustomerNoHavingCardsAndRowIndex(1, "Active");
		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		common.chooseCustomerNoAndSearch(customerNumber);
		String newCardNumber = orderCardPage.orderNewCardWithMonthlyFeeWFE();
		common.updatePropFile("EmbossNewCard_" + clientName + "_" + clientCountry, newCardNumber,
				"EmbossIdemiaValidation.properties");
		IFCSHomePage.exitIFCS();
	}

	/**
	 * Added by Nithya
	 * 
	 * @param clientCountry
	 * @param clientName    Busienss Flow ID:RQ-828
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "BusinessFlow" })
	public void embossFileGenerationForDriverName(@Optional("AU") String clientCountry,
			@Optional("BP") String clientName) {
		test = extent.createTest(
				clientName + ":" + clientCountry + "RQ-828 TC-804 TC02_CardMgmt_Emb_Update existing Driver name",
				"The driver name is changed in before embossing and after embossing card");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		Common common = new Common(driver, test);
		IFCSloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		IFCSHomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);
		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		String cardNoForDriverNameUpdate = common.getDriverCardNumberFromDB(clientName + clientCountry);
		common.chooseCustomerNoAndSearch(common.getCustomerNoForCardNumber(cardNoForDriverNameUpdate));
		common.updateCardDriverName(cardNoForDriverNameUpdate);
		common.updatePropFile("EmbossDriverCard_" + clientName + "_" + clientCountry, cardNoForDriverNameUpdate,
				"EmbossIdemiaValidation.properties");
		IFCSHomePage.exitIFCS();
	}

	/**
	 * Added by Nithya
	 * 
	 * @param clientCountry
	 * @param clientName    Busienss Flow ID:RQ-829
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "BusinessFlow" })
	public void embossFileGenerationForLicensePlate(@Optional("AU") String clientCountry,
			@Optional("BP") String clientName) {
		test = extent.createTest(
				clientName + ":" + clientCountry + " RQ-829 TC-809 TC03_CardMgmt_Emb_Update existing license plate",
				"The license plate (VRN) is changed before embossing and after embossing vehicle card");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		Common common = new Common(driver, test);
		IFCSloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		IFCSHomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);
		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		//String cardNoForLicensePlateUpdate = common.getActiveCardNumberFromDBWFE(clientName, clientCountry);
String cardNoForLicensePlateUpdate = common.getVehicleCardNumberFromDB(clientName+clientCountry);
		common.chooseCustomerNoAndSearch(common.getCustomerNoForCardNumber(cardNoForLicensePlateUpdate));
		common.updateCardLicensePlate(cardNoForLicensePlateUpdate);
		common.updatePropFile("EmbossVehicleCard_" + clientName + "_" + clientCountry, cardNoForLicensePlateUpdate,
				"EmbossIdemiaValidation.properties");
		IFCSHomePage.exitIFCS();
	}

	/**
	 * Added by Nithya
	 * 
	 * @param clientCountry
	 * @param clientName    Busienss Flow ID:RQ-830
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "BusinessFlow" })
	public void embossFileGenerationForNewCard(@Optional("AU") String clientCountry,
			@Optional("BP") String clientName) {
		test = extent.createTest(
				clientName + ":" + clientCountry + "RQ-830,RQ-859 TC-1118 TC04_CardMgmt_Emb_file for new cards",
				"Embossing file generated for new cards");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		Common common = new Common(driver, test);
		OrderCardPage orderCardPage = new OrderCardPage(driver, test);
		IFCSloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		IFCSHomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);
		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		String customerNumber = common.getActiveOrTemporaryBlockCustomerNoHavingCardsAndRowIndex(1, "Active");
		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		common.chooseCustomerNoAndSearch(customerNumber);
		String cardNumberForNewCard = orderCardPage.orderNewCardWithMonthlyFeeWFE();
		common.updatePropFile("EmbossNewCard_" + clientName + "_" + clientCountry, cardNumberForNewCard,
				"EmbossIdemiaValidation.properties");
		common.updatePropFile("IdemiaNewCard_" + clientName + "_" + clientCountry, cardNumberForNewCard,
				"EmbossIdemiaValidation.properties");
		IFCSHomePage.exitIFCS();
	}

	/**
	 * Added by Nithya
	 * 
	 * @param clientCountry
	 * @param clientName    Busienss Flow ID:RQ-831
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "BusinessFlow" })
	public void embossFileGenerationForReplacedCard(@Optional("AU") String clientCountry,
			@Optional("BP") String clientName) {
		test = extent.createTest(clientName + ":" + clientCountry + "RQ-831,RQ-859 TC-1120 TC05_CardMgmt_Emb_file Replaced cards, TC-1543 TC01_CardMgmt_'I' file_new and replace card",
				"Embossing file generated for replace cards");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		Common common = new Common(driver, test);
		ChangeCardStatus changeStatusPage = new ChangeCardStatus(driver, test);
		IFCSloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		IFCSHomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);
		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		String cardNoForReplace = common.getActiveCardNumberFromDBWFE(clientName, clientCountry);
		common.chooseCustomerNoAndSearch(common.getCustomerNoForCardNumber(cardNoForReplace));
		common.chooseCardNo(cardNoForReplace);
		changeStatusPage.changeCardStatusAndClickYesAndValidate("Card Lost");
		common.updatePropFile("EmbossReplacedCard_" + clientName + "_" + clientCountry, cardNoForReplace,
				"EmbossIdemiaValidation.properties");
		common.updatePropFile("IdemiaReplacedCard_" + clientName + "_" + clientCountry, cardNoForReplace,
				"EmbossIdemiaValidation.properties");
		IFCSHomePage.exitIFCS();
	}

	/**
	 * Added by Nithya
	 * 
	 * @param clientCountry
	 * @param clientName    Busienss Flow ID:RQ-832
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "BusinessFlow" })
	public void embossFileGenerationForReissuedCard(@Optional("AU") String clientCountry,
			@Optional("BP") String clientName) {
		test = extent.createTest(
				clientName + ":" + clientCountry + " RQ-832,RQ-858 TC-1119 TC06_CardMgmt_Emb_ file Reissued cards, TC-1547 TC02_CardMgmt_'R' file_Reissued cards",
				"Embossing file generated for reissue cards");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		Common common = new Common(driver, test);
		IFCSloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		IFCSHomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);
		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		String cardNoForReissued = common.getActiveCardNumberFromDBWFE(clientName, clientCountry);
		common.chooseCustomerNoAndSearch(common.getCustomerNoForCardNumber(cardNoForReissued));
		common.updateCardExpiryDate(clientName, clientCountry, cardNoForReissued);
		common.updatePropFile("EmbossReissuedCard_" + clientName + "_" + clientCountry, cardNoForReissued,
				"EmbossIdemiaValidation.properties");
		common.updatePropFile("IdemiaReissuedCard_" + clientName + "_" + clientCountry, cardNoForReissued,
				"EmbossIdemiaValidation.properties");
		IFCSHomePage.exitIFCS();
	}

	/**
	 * Added by Nithya
	 * 
	 * @param clientCountry
	 * @param clientName    Busienss Flow ID:RQ-833
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "BusinessFlow" })
	public void pinMailerFileGeneration(@Optional("AU") String clientCountry, @Optional("BP") String clientName) {
		test = extent.createTest(clientName + ":" + clientCountry + " RQ-833 TC-784 TC07_CardMgmt_Emb_Pin Mailer",
				"Pinmailer file generation for the card request");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		Common common = new Common(driver, test);
		IFCSloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		IFCSHomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);
		OrderCardPage orderCardPage = new OrderCardPage(driver, test);
		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		String customerNumber = common.getActiveOrTemporaryBlockCustomerNoHavingCardsAndRowIndex(1, "Active");
		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		common.chooseCustomerNoAndSearch(customerNumber);
		String newCardNumber = orderCardPage.orderNewCardWithPIN();
		common.updatePropFile("EmbossReissuedCard_" + clientName + "_" + clientCountry, newCardNumber,
				"EmbossIdemiaValidation.properties");
		IFCSHomePage.exitIFCS();
	}

	/**
	 * Added by Nithya
	 * 
	 * @param clientCountry
	 * @param clientName    Busienss Flow ID:RQ-840
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "BusinessFlow" })
	public void remailPINRequestFromIFCS(@Optional("AU") String clientCountry, @Optional("BP") String clientName) {
		test = extent.createTest(clientName + ":" + clientCountry + "RQ-840,RQ-819 TC-1610 TC02_CardMgmt_Remail PIN request, TC-799 TC04_CardMgmt_Ord_System generated PIN cards with existing PIN_IFCS",
				"Remail PIN Request, Remail PIN Request and DB Validation");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		Common common = new Common(driver, test);
		FindAndUpdateCardPage findAndUpdate = new FindAndUpdateCardPage(driver, test);
		CardMaintenancePage cardMaintenancePage = new CardMaintenancePage(driver, test);
		IFCSloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		IFCSHomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);
		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		String cardNoForRemailPIN = common.getActiveCardNumberFromDBWFE(clientName, clientCountry);
		common.chooseCustomerNoAndSearch(common.getCustomerNoForCardNumber(cardNoForRemailPIN));
		common.chooseCardNo(cardNoForRemailPIN);
		String pinBeforeJob = ""; 
			//	findAndUpdate.getPINValuesFromDB(cardNoForRemailPIN);
		cardMaintenancePage.requestForNewSystemPIN();
		common.updatePropFile("EmbossReMailPIN_" + clientName + "_" + clientCountry, cardNoForRemailPIN,
				"EmbossIdemiaValidation.properties");
		common.updatePropFile("RemailPINAndDBValdiation_" + clientName + "_" + clientCountry, pinBeforeJob,
				"EmbossIdemiaValidation.properties");
		IFCSHomePage.exitIFCS();
	}

	/**
	 * Added by Nithya
	 * 
	 * @param clientCountry
	 * @param clientName    Busienss Flow ID:RQ-833
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "BusinessFlow" })
	public void pinmailerFileValidation(@Optional("AU") String clientCountry, @Optional("BP") String clientName) {
		test = extent.createTest(clientName + ":" + clientCountry + " ID:Validation of RQ-833",
				"Validate the PINMailer File for New and Reissued Card PIN");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		InterfacePage interfacePage = new InterfacePage(driver, test);
		FindAndUpdateCardPage findAndUpdate = new FindAndUpdateCardPage(driver, test);
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		interfacePage.validatePINMailerFile();
		//String pinAfterJob = findAndUpdate.getPINValuesFromDB(PropUtils.getPropValue(, key));

	}

	/**
	 * Added by Nithya
	 * 
	 * @param clientCountry
	 * @param clientName    Busienss Flow ID:RQ-858
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "BusinessFlow" })
	public void idemiaFileGenerationForNewCardAndReplacedCards(@Optional("AU") String clientCountry,
			@Optional("BP") String clientName) {
		test = extent.createTest(
				clientName + ":" + clientCountry + " ID:TC-1543 TC01_CardMgmt_'I' file_new and replace card",
				"Able to generate the Idemia 'I' file for new cards and replaced cards");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		Common common = new Common(driver, test);
		ChangeCardStatus changeStatusPage = new ChangeCardStatus(driver, test);
		OrderCardPage orderCardPage = new OrderCardPage(driver, test);
		IFCSloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		IFCSHomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);

		String customerNumber = common.getActiveOrTemporaryBlockCustomerNoHavingCardsAndRowIndex(1, "Active");
		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		common.chooseCustomerNoAndSearch(customerNumber);
		String newCardNumberIdemia = orderCardPage.orderNewCardWithMonthlyFeeWFE();
		
		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		String cardNoForReplaceIdemia = common.getActiveCardNumberFromDBWFE(clientName, clientCountry);
		common.chooseCardNo(cardNoForReplaceIdemia);
		changeStatusPage.changeCardStatusAndClickYesAndValidate("Card Lost");
		common.updatePropFile("IdemiaNewCard_" + clientName + "_" + clientCountry, newCardNumberIdemia,
				"EmbossIdemiaValidation.properties");
		common.updatePropFile("IdemiaReplacedCard_" + clientName + "_" + clientCountry, cardNoForReplaceIdemia,
				"EmbossIdemiaValidation.properties");
		IFCSHomePage.exitIFCS();
	}

	/**
	 * Added by Nithya
	 * 
	 * @param clientCountry
	 * @param clientName    Busienss Flow ID:RQ-859
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "BusinessFlow" })
	public void idemiaFileGenerationForReissuedCards(@Optional("AU") String clientCountry,
			@Optional("BP") String clientName) {
		test = extent.createTest(clientName + ":" + clientCountry + " ID:TC-1547 TC02_CardMgmt_'R' file_Reissued cards",
				"Able to generate the Idemia 'R' file for Reissued cards");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		Common common = new Common(driver, test);
		IFCSloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");

		IFCSHomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);
		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		String cardNoForReissuedIdemia = common.getActiveCardNumberFromDBWFE(clientName, clientCountry);
		common.chooseCustomerNoAndSearch(common.getCustomerNoForCardNumber(cardNoForReissuedIdemia));
		common.updateCardExpiryDate(clientName, clientCountry, cardNoForReissuedIdemia);
		common.updatePropFile("IdemiaReissuedCard_" + clientName + "_" + clientCountry, cardNoForReissuedIdemia,
				"EmbossIdemiaValidation.properties");
		IFCSHomePage.exitIFCS();
	}

	/**
	 * Added by Nithya
	 * 
	 * @param clientCountry
	 * @param clientName    Busienss Flow ID:RQ-827, RQ-828, RQ-829, RQ-830, RQ-831,
	 *                      RQ-832
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "BusinessFlow" })
	public void embossFileValidation(@Optional("AU") String clientCountry, @Optional("BP") String clientName) {
		test = extent.createTest(
				clientName + ":" + clientCountry + " ID: Validation of RQ-827, RQ-828, RQ-829, RQ-830, RQ-831, RQ-832",
				"Validate the Emboss file for New,Replaced,Reissues Cards");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		InterfacePage interfacePage = new InterfacePage(driver, test);
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		interfacePage.validateEmbossXMLFile();

	}

	/**
	 * Added by Nithya
	 * 
	 * @param clientCountry
	 * @param clientName    Busienss Flow ID:RQ-858, RQ-859
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "BusinessFlow" })
	public void idemiaFileValidation(@Optional("AU") String clientCountry, @Optional("BP") String clientName) {
		test = extent.createTest(clientName + ":" + clientCountry + " ID:Validation of RQ-858, RQ-859",
				"Validate the Idemia file for New,Replaced,Reissues Cards");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		InterfacePage interfacePage = new InterfacePage(driver, test);
		Common common = new Common(driver, test);
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		interfacePage.validateIdemiaFile();

	}


}
