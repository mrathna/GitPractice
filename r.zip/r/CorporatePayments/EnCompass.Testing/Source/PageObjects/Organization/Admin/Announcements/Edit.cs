﻿using Common;
using Common.Utility;
using EnCompass.Testing.Source.PageObjects;
using EnCompass.Testing.Source.PageObjects.Controls;
using NFluent;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace EnCompass.Testing.Source.PageObjects.Organization.Admin.Announcements
{
    [PageModel(@"/Announcements/Edit.aspx")]
    public class Edit : EnCompassPageModel
    {

        #region xpath

        public override string RelativeUrl => @"/Announcements/Edit.aspx";
        public override string PageIdentifierXPath_Override => @"//li[contains(@class, 'breadcrumb-item active')][contains(text(), 'Edit Announcement')]";
        private const string _divMsgXPath = @"//p[contains(text(),'This announcement has been published; you have lim')]";

        #endregion

        #region IWebElement Props

        public IWebElement _divMsg
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_divMsgXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Debug("Found _divMsg");
                return element;
            }
        }

        #endregion


        public void VerifyAlertMsg(string strMsg)
        {
            Check.That(_divMsg.Text.Contains(strMsg));
            Settings.EnCompassExtentTest.Info("Alert message for Edit Announcement : " + strMsg);
        }
        public Edit(GlobalSettings settings) : base(settings) { }
    }
}
