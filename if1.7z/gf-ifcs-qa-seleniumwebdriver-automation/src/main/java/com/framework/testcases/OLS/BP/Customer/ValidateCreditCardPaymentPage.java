package com.framework.testcases.OLS.BP.Customer;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.BP.BPHomePage;
import com.framework.pages.OLS.common.LoginPage;

public class ValidateCreditCardPaymentPage extends BaseTest{
	@Parameters({"clientCountry","clientName"})
	@Test(groups = {"Smoke" , "Regression","BusinessFlow" })
	public void validateCreditCardPayment(@Optional("AU") String clientCountry, @Optional("BP") String clientName)  {
		test = extent.createTest(clientName+ ":" +clientCountry+"  Credit Card Payment", "TC193_Payment_Your Stored Bank Account_Credit Card payement details");
		
		// Creating Objects for the Pages
				LoginPage loginPage = new LoginPage(driver, test);
				BPHomePage bpHomePage = new BPHomePage(driver, test);
				
				loginPage.Login("BPPREPAID_URL", "BPPREPAID_UN_Customer_" + clientCountry, "BPPREPAID_PWD_Customer_" + clientCountry, clientName);
				bpHomePage.ValidateBPCustomerLogo();
				
				bpHomePage.clickOnMakePaymentSubMenu();
				bpHomePage.selectPaymentMethod("Saved Card");
				bpHomePage.selectPaymentAmountAndConfirm("100");
				bpHomePage.confirmPaymentAndValidateSuccessMessage();
				loginPage.Logout();
				
	}
	
	@Parameters({"clientCountry","clientName"})
	@Test(groups = {"Smoke" , "Regression" })
	public void validateCreditCardPaymentWithNewCardDetails(@Optional("AU") String clientCountry, @Optional("BP") String clientName)  {
		test = extent.createTest(clientName+ ":" +clientCountry+"  Credit Card Payment With New Card", "TC194_Payment_Credit Card payment details With New Card");
		
		// Creating Objects for the Pages
				LoginPage loginPage = new LoginPage(driver, test);
				BPHomePage bpHomePage = new BPHomePage(driver, test);
				
				loginPage.Login("BP_URL", "BPPREPAID_UN_Customer_" + clientCountry, "BPPREPAID_PWD_Customer_" + clientCountry, clientName);
				bpHomePage.ValidateBPCustomerLogo();
				
				bpHomePage.clickOnMakePaymentSubMenu();
				bpHomePage.selectPaymentMethod("New Card");
				bpHomePage.selectPaymentAmountAndConfirm("100");
				
				bpHomePage.paymentDetailsFillUp("Visa");
				bpHomePage.validatePaymentSuccess("Payment Successful");
				loginPage.Logout();
	}
	
}
