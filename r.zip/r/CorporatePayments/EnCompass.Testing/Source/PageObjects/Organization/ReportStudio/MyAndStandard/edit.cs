﻿using Common;
using Common.PageObjects;
using Common.Utility;
using NFluent;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;

namespace EnCompass.Testing.Source.PageObjects.Organization.ReportStudio.MyAndStandard
{

    [PageModel(@"/reportStudio/myAndStandard/edit.aspx")]
    public partial class Edit : EnCompassPageModel
    {
        #region XPATH


        public override string RelativeUrl => @"/reportStudio/myAndStandard/edit.aspx";
        public override string PageIdentifierXPath_Override => @"//h1[normalize-space(text())='New Folder' or text()='Create Folder']";

        private const string _txtNameXPath = @"//input[contains(@id, 'txtName')]";
        private const string _txtDescXPath = @"//textarea[contains(@id, 'txtDesc')]";
        private const string _btnSaveXPath = @"//input[contains(@id,'btnSave')]";

        #endregion

        #region IWebElements 

        public IWebElement _txtName
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_txtNameXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_txtName element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _txtDesc
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_txtDescXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_txtDesc element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _btnSave
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_btnSaveXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_btnSave element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        #endregion

        public string setTxtName
        {
            set
            {
                _txtName.Clear();
                _txtName.SendKeys(value);
            }
        }

        public string setTxtDesc
        {
            set
            {
                _txtDesc.Clear();
                _txtDesc.SendKeys(value);
            }
        }

        public void Save()
        {
            _btnSave.JSClickWithFocus(Driver);
			this.AttachOnDemandScreenShot();
		}

        public void CreateNewFolder(string folderName, string folderDesc)
        {
            setTxtName = folderName;
            setTxtDesc = folderDesc;
            Save();
        }

        public Edit(GlobalSettings settings) : base(settings) { }
    }
}
