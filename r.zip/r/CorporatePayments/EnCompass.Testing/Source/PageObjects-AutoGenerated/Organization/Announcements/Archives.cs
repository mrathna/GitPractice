using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using Common;
using Common.PageObjects;
using Common.ScenarioConfigurations;
using Common.Utility;

namespace EnCompass.Testing.Source.PageObjects.Organization.Announcements 
{
	/// <summary>
	/// Auto-generated Page Model Class
	/// Navigation Paths: 
		/// [Organization Home]->Administration->Announcements->Archives
		/// </summary>
	[PageModel(@"/announcements/archives.aspx")]
	public partial class Archives : EnCompassOrgPageModel 
	{
		public override string RelativeUrl => @"/announcements/archives.aspx";
		public override string PageIdentifierXPath_Generated => @"//li[contains(@class, 'breadcrumb-item active')][text() = 'Archives']";

		#region Navigation
				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='WEX']")]
		private IWebElement _administration_Announcements_Archives_Wex { get; set; }
		public void NavigateTo_Administration_Announcements_Archives_Wex()
		{
			NavigateToMenuItem(_administration_Announcements_Archives_Wex);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='ZZZ WC9RHT3V5W 1106-46988']")]
		private IWebElement _administration_Announcements_Archives_ZzzWc9rht3v5w110646988 { get; set; }
		public void NavigateTo_Administration_Announcements_Archives_ZzzWc9rht3v5w110646988()
		{
			NavigateToMenuItem(_administration_Announcements_Archives_ZzzWc9rht3v5w110646988);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Archives']")]
		private IWebElement _administration_Announcements_Archives_Archives { get; set; }
		public void NavigateTo_Administration_Announcements_Archives_Archives()
		{
			NavigateToMenuItem(_administration_Announcements_Archives_Archives);
		}

		
		private void NavigateToMenuItem(IWebElement element)
		{
			Driver.Url = element.GetAttribute("href");
		}
		#endregion

		public Archives(GlobalSettings settings) : base(settings) { }
	}  
}
