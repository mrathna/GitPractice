﻿using Common;
using Common.Utility;
using EnCompass.Testing.Source.PageObjects.Controls;
using NFluent;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace EnCompass.Testing.Source.PageObjects.Organization.ExpenseManager.PurchaseLog
{
	[PageModel(@"/expenseManager/PurchaseLog/purchaseLogTransaction.aspx")]

	public partial class PurchaseLogTransactions: EnCompassOrgPageModel
	{
		public override string RelativeUrl => @"/expenseManager/PurchaseLog/purchaseLogTransaction.aspx";
		public override string PageIdentifierXPath_Generated => @"//li[contains(@class, 'breadcrumb-item active')][text() = 'Transactions']";

         #region XPath page Elements

        private const string _mLogTransactionsTitleXPath = @"//h1[contains(@id, 'h1title')]";
        private const string _selectMLogFormatValueXPath = @"//select[contains(@id, 'ddlExportType')]";
        private const string _btnExportGridTextXPath = @"//input[contains(@id, 'btnExportGridText')]";
        private const string _billingDetailsIFrameXPath = @"//iframe[contains(@id, 'viewBillingDetails')]";
        //dispute transactions modal buttons
        private const string _disputeTransactionButtonXPath = @".//input[contains(@id, 'btnSubmitDispute')]";
        private const string _disputeCloseTransactionButtonXPath = @".//input[contains(@id, 'btnCloseDispute')]";
        private const string _disputeCancelButtonXPath = @".//div[contains(@id, 'disputeTransactionModal')]//div[@class='modal-footer']//button[contains(text(), 'Cancel')]";

        private const string _disputeAmountXPath = ".//input[contains(@id, 'txtDisputedAmount')]";
        private const string _disputeEmailXPath = ".//textarea[contains(@id, 'txtDisputeEmailAddress')]";
        private const string _disputeSelectReasonXPath = ".//select[contains(@id, 'ddlDisputeReason')]";
        private const string _disputeCommentXPath = ".//textarea[contains(@id, 'txtDisputeReasonOther')]";
        //Confirm dispute buttons
        private const string _disputeConfirmButtonXPath = ".//div[contains(@id, 'footer_Modal')]//button[text() = 'Confirm']";
        private const string _disputeCancelConfirmButtonXPath = ".//div[contains(@id, 'footer_Modal')]//button[text() = 'Cancel']";

        private const string _disputeRequiredAmountXPath = ".//span[contains(@id, 'rfvDisputedAmount')]";
        private const string _disputeRequiredEmailXPath = ".//span[contains(@id, 'rfvDisputeEmailAddress')]";
        private const string _disputeRequiredCommentXPath = ".//span[contains(@id, 'rfvDisputeReasonOther')]";
        private const string _disputeRequiredReasonXPath = ".//span[contains(@id, 'rfvDisputeReason')]";
        private const string _disputeValidationXPath = ".//div[contains(@id, 'DisputeValidation')]";
        private const string _modalHeaderXPath = @".//h1[contains(@id,'ModalTitle_Modal')]";
        #endregion

        #region Page Elements 
        public IWebElement _mLogTransactionsTitle
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_mLogTransactionsTitleXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_mLogTransactionsTitle element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _selectMLogFormatValue
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_selectMLogFormatValueXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_selectMLogFormatValue element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _btnExportGridText
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_btnExportGridTextXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_btnExportGridText element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _billingDetailsIFrame
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_billingDetailsIFrameXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_billingDetailsIFrame element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _disputeTransactionButton
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_disputeTransactionButtonXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_disputeTransactionButton element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _disputeCloseTransactionButton
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_disputeCloseTransactionButtonXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_disputeCloseTransactionButton element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _disputeAmount
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_disputeAmountXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_disputeAmount element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _disputeEmail
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_disputeEmailXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_disputeEmail element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _disputeSelectReason
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_disputeSelectReasonXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_disputeSelectReason element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _disputeComment
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_disputeCommentXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_disputeComment element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _disputeConfirmButton
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_disputeConfirmButtonXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_disputeConfirmButton element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _disputeCancelConfirmButton
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_disputeCancelConfirmButtonXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_disputeCancelConfirmButton element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _disputeCancelButton
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_disputeCancelButtonXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_disputeCancelButton element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _disputeRequiredAmount
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_disputeRequiredAmountXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_disputeRequiredAmount element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _disputeRequiredEmail
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_disputeRequiredEmailXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_disputeRequiredEmail element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _disputeValidation
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_disputeValidationXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_disputeValidation element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _disputeRequiredComment
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_disputeRequiredCommentXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_disputeRequiredComment element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _disputeRequiredReason
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_disputeRequiredReasonXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_disputeRequiredReason element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _modalHeader
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_modalHeaderXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_modalHeader element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        #endregion

        public PurchaseLogTransactions(GlobalSettings settings) : base(settings) { }

		private GridControl _transactions;
		public GridControl TransactionsGrid
		{
			get
			{
				GridControl grid = _transactions ?? (_transactions = new GridControl("dgTransactions", Driver));
				grid.WaitForGrid();
				return grid;
			}
		}

        /// <summary>
        /// Function used to create Dispute Transaction
        /// </summary>
        public void DisputeTransaction()
        {
            _disputeTransactionButton.JSClickWithFocus(Driver);
            Settings.EnCompassExtentTest.Info("Clicked on Dispute button for Transaction Mlog");
        }

        /// <summary>
        /// Function used to close the Dispute Transaction
        /// </summary>
        public void DisputeCloseTransaction()
        {
            _disputeCloseTransactionButton.JSClickWithFocus(Driver);
            WaitForModalToAppear();
            Settings.EnCompassExtentTest.Info("Clicked on Close Dispute button for Transaction Mlog");
        }

        /// <summary>
        /// Function used to cancel the Dispute Transaction
        /// </summary>
        public void DisputeCancel()
        {
            _disputeCancelButton.JSClickWithFocus(Driver);
            Settings.EnCompassExtentTest.Info("Clicked on Cancel button for Transaction Mlog");
        }

        /// <summary>
        /// Function used to confirm the Dispute Transaction confirm modal 
        /// </summary>
        public void DisputeConfirm()
        {
            _disputeConfirmButton.JSClickWithFocus(Driver);
            Settings.EnCompassExtentTest.Info("Clicked on Confirm button for Transaction Mlog");
        }

        /// <summary>
        /// Function used to cancel the Dispute Transaction confirm modal 
        /// </summary>
        public void DisputeCancelConfirm()
        {
            _disputeCancelConfirmButton.JSClickWithFocus(Driver);
            Settings.EnCompassExtentTest.Info("Clicked on Cancel Confirm button for Transaction Mlog");
        }

        /// <summary>
        /// Function used to get/set value for the field Amount at the Dispute Transaction modal
        /// </summary>
        public string DisputeAmount
        {
            get
            {
                return _disputeAmount.Text;
            }
            set
            {
                _disputeAmount.Clear();
                _disputeAmount.SendKeys(value);
                ModalHeaderClick();
                Settings.EnCompassExtentTest.Info($"Inserted {value} on the field Dispute Amount.");
            }
        }

        /// <summary>
        /// Function used to get/set value for the field Email at the Dispute Transaction modal
        /// </summary>
        public string DisputeEmail
        {
            get
            {
                return _disputeEmail.Text;
            }
            set
            {
                _disputeEmail.Clear();
                _disputeEmail.SendKeys(value);
                ModalHeaderClick();
                Settings.EnCompassExtentTest.Info($"Inserted {value} on the field Dispute Email.");
            }
        }

        /// <summary>
        /// Function used to get/select value for the element Reason at the Dispute Transaction modal
        /// </summary>
        public string DisputeSelectReason
        {
            get
            {
                return new SelectElement(_disputeSelectReason).SelectedOption.Text.Trim();
            }
            set
            {
                if (value == "")
                    new SelectElement(_disputeSelectReason).SelectByIndex(0);
                else
                    new SelectElement(_disputeSelectReason).SelectByText(value);

                Settings.EnCompassExtentTest.Info($"Selected {value} on Reason DDL.");
            }
        }

        /// <summary>
        /// Function used to get/set value for the field Comment at the Dispute Transaction modal
        /// </summary>
        public string DisputeComment
        {
            get
            {
                return _disputeComment.Text;
            }
            set
            {
                _disputeComment.Clear();
                _disputeComment.SendKeys(value);
                ModalHeaderClick();
                Settings.EnCompassExtentTest.Info($"Inserted {value} on the field Dispute Comment.");
            }
        }

        /// <summary>
        /// Get the message of required Amount 
        /// </summary>
        public string GetRequiredAmount
        {
            get
            {
                return _disputeRequiredAmount.Text;
            }
        }

        /// <summary>
        /// Get the message of required Email 
        /// </summary>
        public string GetRequiredEmail
        {
            get
            {
                return _disputeRequiredEmail.Text;
            }
        }

        /// <summary>
        /// Get the message of required comment 
        /// </summary>
        public string GetRequiredComment
        {
            get
            {
                return _disputeRequiredComment.Text;
            }
        }

        /// <summary>
        /// Get the message of required reason 
        /// </summary>
        public string GetRequiredReason
        {
            get
            {
                return _disputeRequiredReason.Text;
            }
        }

        /// <summary>
        /// Function used to get the message to be validate
        /// </summary>
        public string GetValidationMessage
        {
            get
            {
                return _disputeValidation.Text;
            }
        }

        /// <summary>
        /// Used to fill the Dispute Transaction modal
        /// </summary>
        /// <param name="amount"></param>
        /// <param name="email"></param>
        /// <param name="reason"></param>
        /// <param name="comment"></param>
        public void FillDisputeTransactionModal(string amount, string email, string reason, string comment)
        {
            WaitForModalToAppear();
            DisputeAmount = amount;
            Settings.EnCompassExtentTest.Info($"Inserted {amount} on the field Dispute Amount.");
            DisputeEmail = email;
            Settings.EnCompassExtentTest.Info($"Inserted {email} on the field Email Address.");
            DisputeSelectReason = reason;
            Settings.EnCompassExtentTest.Info($"Selected {reason} on Reason DDL.");
            DisputeComment = comment;
            Settings.EnCompassExtentTest.Info($"Inserted {comment} on the field Comments.");     

            //Confirm On Modal doesn't work for this one and we don't have a static modal ID.
            DisputeTransaction();
            Settings.EnCompassExtentTest.Info("Clicked on 'Dispute' Button");

            // Another confirmation modal pops out. Since WaitForModalToAppear is ineffective here, I wait for Confirm button.
            // This button belongs only in the innermost confirmation modal.
            DisputeConfirm();
            Settings.EnCompassExtentTest.Info("Clicked on 'Confirm Dispute' Button");

            if (Regex.IsMatch(amount, @"([0-9]+)(\.([0-9]+))"))
                WaitForModalToDisappear();
        }

        /// <summary>
        /// Return the value if DisputeValidation is visible
        /// </summary>
        public bool DisputeValidationIsVisible
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_disputeValidationXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_disputeValidation element exist is {found}");
                return found;
            }
        }

        /// <summary>
        /// Function to click in the modal header to focus out
        /// </summary>
        public void ModalHeaderClick()
        {
            _modalHeader.BootstrapClick();
        }
    }
}
