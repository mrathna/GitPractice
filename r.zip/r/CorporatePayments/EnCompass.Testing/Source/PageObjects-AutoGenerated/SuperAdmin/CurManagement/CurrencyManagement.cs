using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using Common;
using Common.PageObjects;
using Common.ScenarioConfigurations;
using Common.Utility;

namespace EnCompass.Testing.Source.PageObjects.SuperAdmin.CurManagement 
{
	/// <summary>
	/// Auto-generated Page Model Class
	/// Navigation Paths: 
		/// [Organization Home]->General->Currency
		/// </summary>
	[PageModel(@"/superAdmin/curManagement/CurrencyManagement.aspx")]
	public partial class CurrencyManagement : EnCompassSuperPageModel 
	{
		public override string RelativeUrl => @"/superAdmin/curManagement/CurrencyManagement.aspx";
		public override string PageIdentifierXPath_Generated => @"//li[contains(@class, 'breadcrumb-item active')][text() = 'Currency']";

		#region Navigation
		
		private void NavigateToMenuItem(IWebElement element)
		{
			Driver.Url = element.GetAttribute("href");
		}
		#endregion

		public CurrencyManagement(GlobalSettings settings) : base(settings) { }
	}  
}
