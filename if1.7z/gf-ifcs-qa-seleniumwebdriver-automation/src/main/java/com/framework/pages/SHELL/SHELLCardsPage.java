package com.framework.pages.SHELL;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.ExtentTest;
import com.framework.basepage.BasePage;
import com.framework.repo.Locator;

public class SHELLCardsPage extends BasePage {

	@FindBy(id = Locator.BCS_CARD_STATUS)
	public WebElement cardStatus;

	@FindBy(id = Locator.SEARCH_CARDS)
	public WebElement searchCard;

	@FindBy(id = Locator.BCS_NEW_STATUS_DROPDOWN)
	public WebElement newCardStatus;

	@FindBy(id = Locator.BCS_EXPAIRING_AFTER_DATE)
	public WebElement expireFromDate;

	@FindBy(id = Locator.BCS_EXPAIRING_BEFORE_DATE)
	public WebElement expireToDate;

	@FindBy(id = Locator.CARDS_OFFER_DROPDOWN)
	public WebElement cardOfferDropdown;

	@FindBy(id = Locator.PURCHASE_ON_DATE_FIELD)
	public WebElement purchaseOnDate;

	@FindBy(id = Locator.BULK_CARD_TABLE)
	public WebElement bulkOrderTable;

	@FindBy(xpath = Locator.CARD_NUMBER_LIST)
	public List<WebElement> cardNumberList;

	@FindBy(id = Locator.CARD_LIST_CHECK_BOX)
	public List<WebElement> cardListCheckBox;

	@FindBy(id = Locator.AU_SAVE)
	public WebElement saveBtn;

	@FindBy(id = Locator.CONFIRMATIONMESSAGE)
	public WebElement confirmationMsg;

	@FindBy(id = Locator.BULK_CARD_EXPORT_BUTTON)
	public WebElement bulkCardExportButton;

	@FindBy(id = Locator.CARDSTATUSCHANGE_POPUP_NOBUTTON)
	public WebElement cardChangePopupNoButton;

	@FindBy(id = Locator.CARD_LIST_TABLE)
	public WebElement cardListTable;

	@FindBy(xpath = Locator.CUSTOMER_NUMBER_LIST)
	public List<WebElement> customerNumberList;

	@FindBy(id = Locator.CURRENT_CARD_NUMBER)
	public WebElement currentCardNumber;

	@FindBy(id = Locator.CARD_STATUS)
	public WebElement filterCardStatus;

	@FindBy(id = Locator.SEARCH_BTN)
	public WebElement searchButton;

	@FindBy(id = Locator.EXPORT_CARD_TOEXCEL)
	public WebElement exportButton;

	// Added by Ayub 20.06.2018

	@FindBy(id = Locator.DOWNLOAD_BULK_CARD_ORDER_TEMPLATE)
	public WebElement downloadBulkCard;

	// @FindBy(id = Locator.CLOSE_POPUP)
	// public WebElement upLoadBulkOrder;

	@FindBy(xpath = Locator.UPLOAD_BULK_CARD_ORDER_TEMPLATE)
	public WebElement upLoadBulkOrder;

	@FindBy(id = Locator.CLOSE_UPLOAD_POPUP)
	public WebElement closePopUp;

	@FindBy(xpath = Locator.VIEW_CARD_CL)
	public WebElement viewCardCL;

	@FindBy(id = Locator.CARD_INFORMATION_ODOMETER)
	public WebElement cardInfoOdoMeter;

	@FindBy(id = Locator.CUSTOMER_REFERENCE)
	public WebElement customerRef;

	@FindBy(xpath = Locator.EDIT_CARD_MENU_OPTION)
	public WebElement editCardMenuButton;

	@FindBy(id = Locator.CARD_PURCHASE_PRODUCTS_DURING_TIME)
	public WebElement timeLimit;

	@FindBy(id = Locator.CARD_INFORMATION_DRIVER_NAME)
	public WebElement driverName;

	@FindBy(id = Locator.CARD_INFORMATION_VEHICLE_REGO_NUMBER)
	public WebElement vehicleRegoNumber;

	@FindBy(id = Locator.CDA_TITLE)
	public WebElement contactTitleName;

	@FindBy(id = Locator.CDA_CONTACT_NAME)
	public WebElement contactName;

	@FindBy(id = Locator.CDA_CONTACT_ADDRESS)
	public WebElement contactAddress;

	@FindBy(id = Locator.CDA_SUBURB)
	public WebElement cityName;

	@FindBy(id = Locator.CDA_POSTCOAD)
	public WebElement postCode;

	@FindBy(xpath = Locator.CDA_SATE)
	public WebElement stateName;

	@FindBy(xpath = Locator.CDA_COUNTRY)
	public WebElement countryName;

	@FindBy(id = Locator.UPDATE_BUTTON)
	public WebElement updateButton;

	// Added by Ayub on 21.96.2018

	@FindBy(xpath = Locator.ACCOUNT_LIST_BOX)
	public WebElement accountList;

	@FindBy(how = How.XPATH, using = Locator.ALL_LISTED_CARDS)
	public List<WebElement> allListedCards;

	@FindBy(how = How.XPATH, using = Locator.CHANGE_CARD_STATUS_MENU_OPTION)
	public WebElement changeCardStatus;

	@FindBy(id = Locator.NEW_CARD_STATUS)
	public WebElement newCardStatuss;

	@FindBy(id = Locator.LATER_ON_THIS_DATE_FIELD)
	public WebElement startDate;

	@FindBy(id = Locator.LATER_ON_END_DATE_FIELD)
	public WebElement EndDate;

	@FindBy(id = Locator.DELIVER_CONFIRM_AND_REISSUE)
	public WebElement saveButton;

	@FindBy(id = Locator.BACK_TO_SETTLEMENT_LIST)
	public WebElement backToCardList;

	@FindBy(how = How.XPATH, using = Locator.SHELL_EDIT_CARD)
	public WebElement editCard;

	@FindBy(id = Locator.EDIT_NEW_CARD_STATUS)
	public WebElement editNewCardStatus;

	@FindBy(id = Locator.CARDSTATUSCHANGE_POPUP_NOBUTTON)
	public WebElement noButton;
	@FindBy(xpath = Locator.CARDSTATUSCHANGE_CONFIRM_POPUP_NOBUTTON)
	public WebElement confirmNoButton;
	

	// Added by Ayub on 22.06.2018
	@FindBy(xpath = Locator.CARD_OFFER)
	public WebElement cardOffer;

	@FindBy(id = Locator.CARD_PURCHASE_TRANS_COST_LIMILTS)
	public WebElement dailyUseLimits;

	@FindBy(id = Locator.CARD_PURCHASE_TRANS_VALUME_LIM)
	public WebElement dailyValueLimits;

	@FindBy(id = Locator.UAL_FUEL_TRANSACTION_COST_OVER)
	public WebElement weeklyUseLimits;

	@FindBy(id = Locator.UAL_FUEL_TRANSACTION_VOLUME_OVER)
	public WebElement weeklyValueLimits;

	@FindBy(id = Locator.UAL_NON_FUEL_TRANSACTION_COST_OVER)
	public WebElement monthlyUseLimits;

	@FindBy(id = Locator.UAL_FUEL_DAILY_VOLUME_OVER)
	public WebElement monthlyvalueLimits;

	@FindBy(id = Locator.UAL_NUMBER_TRANSACTION_DAILY_OVER)
	public WebElement transactionValueLimits;
    
	@FindBy(xpath=Locator.TRANSACTION_MONTHLY_LIMIT)
	public WebElement transactionMonthlyLimit;
	
	@FindBy(xpath=Locator.TRANSACTION_PURCHASE_LIMIT)
	public WebElement transactionPurchaseLimit;
	
	@FindBy(xpath=Locator.DAILY_TRANSACTION_LIMIT)
	public WebElement dailyTransactionLimit;
	
	@FindBy(xpath=Locator.WEEKLY_TRANSACTION_LIMIT)
	public WebElement weeklyTransactionLimit;
	
	@FindBy(xpath=Locator.MONTHLY_VALUE_LIMIT)
	public WebElement monthlyValueLimit;
	
	@FindBy(id = Locator.UAL_CONTTINUE)
	public WebElement orderCard;

	@FindBy(id = Locator.CHANGE_STATUS_START_DATE)
	public WebElement changeStatusStartDate;

	@FindBy(id = Locator.CHANGE_STATUS_START_DATE_TABLE)
	public WebElement changeStatusStartDateCalendarDialog;
	
	// Added by Ayub 25.06.2018
	
	@FindBy(xpath = Locator.SHELL_REPLACE_CARD)
	public WebElement replaceCard;

	@FindBy(id=Locator.CARD_HISTORY_TBL)
	public WebElement cardHistoryTable;
	
	@FindBy(id=Locator.SEARCH_BULK_CARD)
	public WebElement searchBulkCard;
	@FindBy(id = Locator.CURRENT_CARD_STATUS)
	public WebElement viewCardStatus;
	
	@FindBy(id=Locator.SELECT_ALL_CB)
	public WebElement selectAllCb;
	
	@FindBy(id=Locator.BULK_CARD_UPDATE_TABLE)
	public WebElement bulkCardUpdateTable;
	
	@FindBy(id=Locator.DOWNLOAD_CARDS_TO_EXCEL)
	public WebElement download;

	@FindBy(xpath=Locator.CARD_STATUS_BUTTON)
	public WebElement changeCardStatusButton;
	
	
	@FindBy(id=Locator.REPLACE_POPUP_CONTENT)
	public WebElement replacePopupContent;
	
	@FindBy(id=Locator.CARDSTATUSCHANGE_POPUP_YESBUTTON)
	public WebElement reissueCardYes;
	
	@FindBy(id=Locator.CARDSTATUSCHANGE_POPUP_NOBUTTON)
	public WebElement reissueCardNo;
	@FindBy(xpath=Locator.CARDSTATUSCHANGE_CONFIRM_POPUP_NOBUTTON)
	public WebElement reissueCardConfirmNo;
	
	@FindBy(id=Locator.DELETE_BUTTON)
	public WebElement acceptBTN;
	
	@FindBy(id=Locator.YES_REPLACEMENT_BTN)
	public WebElement yesReplacementBtn;

	@FindBy(id=Locator.REISSUE_EXPORT_BUTTON)
	public WebElement reissueControlExportButton;
	
	@FindBy(id=Locator.UAL_RETURNTO_CARDDETAILS)
	public WebElement returnToReIssueCardList;
	
	@FindBy(id=Locator.BULK_REISSUE_TABLE)
	public WebElement bulkReissueTable;
	
	@FindBy(id=Locator.REQUEST_STATUS)
	public WebElement requestStatus;

	
	@FindBy(xpath=Locator.EXCLUDE_CHECKBOX)
	public List<WebElement> excludeCBs;
	
	@FindBy(id=Locator.SAVE_REISSUE_BTN)
	public WebElement saveReissueBTN;

	@FindBy(id=Locator.REISSUE_REQUEST)
	public WebElement reissueRequest;
	
	@FindBy(id=Locator.REISSUE_REQUEST_EXPORT_BUTTON)
	public WebElement reissueRequestExportButton;
	
	@FindBy(id=Locator.REISSUE_EXPIRES_ON_FROM_DATE)
	public WebElement reissueExpiresOnFromDate;

	// Added by Ayub on 02.07.2018
	@FindBy(id = Locator.CARDS_MENU)
	public WebElement cardMenu;
	
	@FindBy(xpath=Locator.REISSUE_PIN_SMENU)
	public WebElement reissuePIN;

	// Added by Meenakshi on 03.07.2018
	@FindBy(id = Locator.REISSUE_EXPIRES_ON_FROM_DATE)
	public WebElement expiresOnFromDate;
	
	@FindBy(id = Locator.REISSUE_NEW_EXPIRES_ON)
	public WebElement newExpiresOnDate;
	
	@FindBy(id = Locator.REISSUE_ON_DATE)
	public WebElement reissueOnDate;
	
	@FindBy(id = Locator.REISSUE_EXPIRES_ON_TO_DATE)
	public WebElement reissueExpiresOnToDate;
	
	@FindBy(id = Locator.REISSUE_CONFIRM_ON_DATE)
	public WebElement reissueConfirmOnDate;
	
	@FindBy(id = Locator.ORDER_NEW_CARD_QUICK_LINK)
	public WebElement orderNewCardQuickLink;
	
	@FindBy(xpath = Locator.VIEW_CARD_MENU)
	public WebElement viewCardMenu;
	// Added by Ayub on 12-07-2018
	@FindBy(id = Locator.DOWNLOAD_BULK_CARD_ORDER_TEMPLATE)
	public WebElement downloadBulkCardOrder;
	
	@FindBy(id = Locator.BROWSE_FILE)
	public WebElement browseFile;
	
	
	@FindBy(xpath = Locator.SHELL_UPLOAD_FILE)
	public WebElement upLoadFile;
	
	@FindBy(xpath = Locator.PAGE_HEADER)
	public WebElement pageTitle;
	
	/*
	 * @FindBy(how = How.CLASS_NAME, using = Locator.CH_CHANGE_STATUS_ERROR_MSG)
	 * public WebElement changeStatusMessage;
	 */
	
	@FindBy(xpath = Locator.CH_CHANGE_STATUS_ERROR_MSG)
	public WebElement changeStatusMessage;
	
	@FindBy(xpath = Locator.DRIVER_DETAILS)
	public WebElement driverDetailsOption;
	
	@FindBy(id = Locator.CARD_INFORMATION_EMBOSSING_NAME)
	public WebElement cardEmbossName;
	
	@FindBy(id = Locator.CONTINUE_BUTTON)
	public WebElement confirmBtn;
	
	@FindBy(xpath = Locator.SUCCESS_MSG_ORDERED_CARD)
	public WebElement orderedCardSuccessMsg;
	
	@FindBy(xpath = Locator.BACK_BUTTON)
	public WebElement backButton;
	
	@FindBy(xpath = Locator.CHANGE_PASSWORD_ERROR_MESSAGE)
	public WebElement errorMsg;
	@FindBy(xpath = Locator.CUSTOMER_CARD_NUMBER)
	public WebElement customerCardNumber;
	@FindBy(xpath = Locator.EXPIRY_DATE_CALENDER_IN_EDITCARD)
	public WebElement expiryDateCalenderInEditCard;
	@FindBy(xpath = Locator.EXPIRY_DATE_CALENDERDIALOGBOX )
	public WebElement expiryDateInCalenderDialogBox;
	
	@FindBy(xpath = Locator.MESSAGE_IN_POPUP)
	public WebElement messagePopup ;
	
	
	String cardNo = "";

	private String getCardStatus = "";

	private String getCardNumber = "";

	private String cardNumberCol = "";

	private String currentCardStatus = "";

	private String authorisedAt = "";

	private String cardAccNo = "";

	private String availableBal = "";
	
	//private String beforeavailableBal ="";
			
	private String actCardNumber = "";
	
	String cardNumber;

	public SHELLCardsPage(WebDriver driver, ExtentTest test) {
		super(driver, test);
		PageFactory.initElements(driver, this);
	}

	public void selectCardStatusAllFilterOptions() {

		selectDropDownByVisibleText(cardStatus, "Active");

		selectDropDownByVisibleText(cardOfferDropdown, "--Select One--");

		// Static values passed due to IFCS Dependent
		isDisplayedThenEnterText(expireFromDate, "Enter Expiring From Date", "10/10/2015");

		isDisplayedThenEnterText(expireToDate, "Enter Expiring To Date", "10/10/2016");

		isDisplayedThenEnterText(purchaseOnDate, "Enter Purchase On Date", "05/10/2015");

		purchaseOnDate.clear();
	}

	public void clickCardStatusSearchButton() {

		isDisplayedThenActionClick(searchCard, "Click Search Button");
	}

	public String selectCardNumberToChangeStatus() {

		setCellDataFromTable(bulkOrderTable, 6, false);
		int cardNumberListSize = cardNumberList.size();
		for (int j = 1; j < cardNumberListSize; j++) {
			getCardStatus = getCellDataFromTable(j, 2, false);
			getCardNumber = getCellDataFromTable(j, 1, false);
			if ("Active".equals(getCardStatus)) {
				selectCardCheckBox(j);
				sleep(3);
				logPass("Card Number Check Box is Selected");
			} else {
				logInfo("Card Number Check Box is Not Selected");
			}
		}
		return getCardNumber;
	}

	public void selectCardCheckBox(int index) {
		try {
			isDisplayedThenActionClick(cardListCheckBox.get(index - 1), "Select Card Check box");
			sleep(5);

		} catch (Exception e) {
			logInfo(e.getMessage());

		}

	}

	public void changeCardStatusFromNewCardStatus() {
		selectDropDownByVisibleText(newCardStatus, "Lost");
	}

	public void clickSaveButtonAndValidate() {

		scrollDownPage();
		isDisplayedThenActionClick(saveBtn, "Click Save Button");
		sleep(3);
		isDisplayed(confirmationMsg, "Validate Success Msg");
	}

	public void clickExportButtonAndValidate() {

		isDisplayedThenActionClick(bulkCardExportButton, "Click Export Button");
		sleep(3);

	}

	public void clickChangeCardPopupNoButton() {

		isDisplayedThenActionClick(cardChangePopupNoButton, "Click Popup No Button");
		sleep(3);
		isDisplayed(confirmationMsg, "Validate Success Msg");
	}

	public void verifyCardNumberAndCardStatus(String statusChangedCardNo) {

		setCellDataFromTable(bulkOrderTable, 6, false);
		int cardNumberListSize = cardNumberList.size();
		for (int j = 0; j < cardNumberListSize; j++) {
			getCardStatus = getCellDataFromTable(j, 3, false);
			getCardNumber = getCellDataFromTable(j, 2, false);
			if (statusChangedCardNo.equals(getCardNumber)) {
				if ("Lost".equals(getCardStatus)) {
					sleep(3);
					logPass("Card Number status is changed");
				}
			} else {
				logInfo("Card Number status is not changed");
			}
		}
	}

	public void verifyCardListPage() {

		checkTextInPageAndValidate("Card List", 10);
	}

	public String getCardNumberFromCardList() {

		setCellDataFromTable(cardListTable, 9, false);
		int tableCardNumberListSize = customerNumberList.size();
		for (int j = 1; j <= tableCardNumberListSize; j++) {
			currentCardStatus = getCellDataFromTable(j, 1, false);
			if ("Active".equals(currentCardStatus)) {
				cardNumberCol = getCellDataFromTable(j, 0, false);				
			}
		}
		return cardNumberCol;
	}

	public void cardNumberFilterSearch() {
		cardNumber = getCardNumberFromCardList();
			
		isDisplayedThenEnterText(currentCardNumber, "Enter the card number", cardNumber);

		selectDropDownByVisibleText(filterCardStatus, "Active");
	}

	public void cardStatusFilterSearch() {
		selectDropDownByVisibleText(filterCardStatus, "Active");
		isDisplayed(cardListTable, "Table results displayed");

	}

	public void clickEditCardFromCardListAndValidate() {
		setCellDataFromTable(cardListTable, 9, false);
		System.out.println("inside edit card");
		List<WebElement> rowElements =  cardListTable.findElements(By.xpath("./tbody[contains(@id,'lform:tableCardList:tb')]/tr"));
		System.out.println("inside rowElements card"+rowElements.size());
		for (int j = 0; j < rowElements.size(); j++) {
			currentCardStatus = getCellDataFromTable(j+1, 1, false);
			System.out.println("Current card status::"+currentCardStatus);
			if ("Active".equals(currentCardStatus)) {
				System.out.println("inside edit card if method");
				clickCardNumber(j+1);
				clickCardTableMenuOption(editCardMenuButton);
				sleep(5);		
				verifyText(pageTitle, "EDIT CARD");
//				checkTextInPageAndValidate("Edit Card", 20);
				break;
			} else {
				logFail("Edit card sub menu not clicked");
			}
		}

	}
	
	public void clickFirstCardEditCardAndValidate() {
		
		selectFirstColumnAndChooseMenu(cardListTable, editCardMenuButton, "Card Details", true);
		sleep(3);
	}

	public void clickCardNumber(int index) {
		try {
			isDisplayedThenActionClick(customerNumberList.get(index - 1), "Click selected Card from card list");
			// System.out.println("Get Text for element"+ expAccount.getr);
			//sleep(3);

		} catch (Exception e) {
			logInfo(e.getMessage());

		}

	} 
	

	public String clickAndGetCardNumber(int index) {
		String cardNo="";
		try {
			isDisplayedThenActionClick(customerNumberList.get(index - 1), "Click selected Card from card list");
			cardNo = getText(customerNumberList.get(index - 1));
			// System.out.println("Get Text for element"+ expAccount.getr);
			sleep(5);
			return cardNo;
		} catch (Exception e) {
			logInfo(e.getMessage());
			return null;

		}

	}
	 
	public void clickSearchButtonAndValidate() {

		isDisplayedThenActionClick(searchButton, "Click search button");
		
		sleep(5);
		
		scrollDownPage();
		
		if(cardListTable.isDisplayed()) {
			isDisplayed(cardListTable, "Verify Table displayed");	
		} else {
			checkTextInPageAndValidate("No Cards Found", 20);
		}
		
		sleep(5);

	}

	public void clickCarListExportButtonAndValidate() {
		isDisplayedThenActionClick(exportButton, "Click Export Button");
	}

	public void checkBalancedAllowedCardListForCardAccNo() {
		setCellDataFromTable(cardListTable, 9, false);
		int tableCardNumberListSize = customerNumberList.size();
		for (int j = 2; j <= tableCardNumberListSize; j++) {
			cardAccNo = getCellDataFromTable(j, 8, false);
			actCardNumber = getCellDataFromTable(j, 0, false);
			if(actCardNumber.equals("") || cardAccNo.equals("")) {
				logFail("Card Number is Null not checkeds Balance allowed");
			}
			else if (actCardNumber.equals(cardAccNo)) {
				logPass("Successfully verified Balance Allowed card");
				
			} else {
				logPass("Successfully verified Not Balance Allowed Account");
				
			}

		}
	}

	public void checkBalancedOrNotBalanceAllowedCardListForAuthorityAt() {
		setCellDataFromTable(cardListTable, 9, false);
		int tableCardNumberListSize = customerNumberList.size();
		for (int j = 1; j <= tableCardNumberListSize; j++) {
			authorisedAt = getCellDataFromTable(j, 7, false);
			if ("Card".equals(authorisedAt)) {
				System.out.println("Got the balance allowed Card Number " + authorisedAt);
				logPass("Successfully verified Balance Allowed card " + authorisedAt);
			} else if("Account".equals(authorisedAt)) {
				System.out.println("Got the Not balance allowed Card Number " + authorisedAt);
				logPass("Successfully verified Not Balance Allowed card " + authorisedAt);
			} else {
				System.out.println("Got the balance allowed Card Number " + authorisedAt);
				logFail("Mismatches or null in the AuthorisedAT");
			}
		}
	}


	// Added by Ayub 20.06.2018

	public void validateBulkCardOrderPage() {
		checkTextInPageAndValidate("BULK CARD", 20);
		checkTextInPageAndValidate("Select A Template to proceed", 20);
		checkTextInPageAndValidate("Template", 20);
	}

	public void dowloadBulkCard() {
		isDisplayedThenActionClick(downloadBulkCard, "Download the BulkCards");
	}

	public void uploadBulkOrder(String text) {
		isDisplayedThenClick(downloadBulkCardOrder, "Download Bulk Card Order");
		sleep(10);
		isDisplayedThenActionClick(upLoadBulkOrder, "UpLoad the Bulk Order");
		sleep(5);
		// waitForElementTobeClickable(browseFile, 60);
		// isDisplayedThenClick(browseFile, "Browse File");
		mouseHover(browseFile);
		isDisplayedThenActionClick(browseFile, "Browse File");
		sleep(10);
		uploadTheExcelSheetFromTheLocal(text);
		sleep(10);
		isDisplayedThenActionClick(upLoadFile, "Up Load File");
		sleep(15);
		isDisplayedThenActionClick(closePopUp, "Close the popup");
		sleep(10);
	}

	public void verifyPINFieldDisabled() {
		sleep(5);
		checkTextNotInPageAndValidate("PIN", 20);
	}

	public void validateProtectedFieldsAndUpdateEditable() {
		// TODO Auto-Generated Method Stub

		checkTextNotInPageAndValidate("PIN", 10);

		// POS validate
		selectDropDownOptionsRandomly(timeLimit, "select Different Limits");

		//checkAnElementIsDisabled(driverName, "Driver Name is not editable");

		checkAnElementIsDisabled(vehicleRegoNumber, "VRN is not editable");

		isDisplayedThenEnterText(contactTitleName, "Enter contact title name", fakerAPI().name().title());

		isDisplayedThenEnterText(contactName, "Enter contact name", fakerAPI().name().fullName());

		isDisplayedThenEnterText(contactAddress, "Enter contact name", fakerAPI().address().fullAddress());

		isDisplayedThenEnterText(cityName, "Enter City name", fakerAPI().address().cityName());

		isDisplayedThenEnterText(postCode, "Enter Post Code", fakerAPI().address().zipCode());
		
		selectInputFromDropdown(stateName, 1);
		
		selectInputFromDropdown(countryName, 1);
		

	}

	public void clickUpdateButton() {
		sleep(2);
		scrollDownPage();
		scrollDownPage();
		scrollDownPage();
		sleep(3);
		isDisplayedThenClick(updateButton, "Click Update Button");
		sleep(5);
		scrollToTopPage();
		scrollToTopPage();
	}
	
	public void clickSaveButton() {
		
		scrollDownPage();
		isDisplayedThenClick(saveButton, "Save Card Status");
		sleep(5);
		
	}

	/*
	 * Click View card And Go To View Card Page. Added by Anton 21.06
	 */

	public void clickViewCardGoToViewCardPageAndValidate() {
	
		setCellDataFromTable(cardListTable, 9, true);
		//List<WebElement> rowElements =  cardListTable.findElements(By.xpath("./tbody[contains(@id,'lform:tableCardList:tb')]/tr"));
		//System.out.println("tableCardNumberListSize---"+rowElements.size());
		
			cardAccNo = getCellDataFromTable(1, 0, true);
			
			System.out.println("cardAccNo---"+cardAccNo); 
			
			clickCardNumber(1);
					
			clickCardTableMenuOption(viewCardMenu);
					
					//isDisplayedThenActionClick(editCardMenuButton, "Click Edit card Button");
			sleep(5);
					
			checkTextInPageAndValidate("VIEW CARD", 30);
			
			checkTextInPageAndValidate(cardAccNo, 30);
	}

	/*
	 * Click Validate the View card Page. Added by Anton 21.06
	 */
	public void validateViewCardPage() {
		// First check The Sections Are present

		checkTextInPageAndValidate("Card Details", 20);
		checkTextInPageAndValidate("Velocity Limits", 20);
		checkTextInPageAndValidate("Delivery Address", 20);
		checkTextInPageAndValidate("Card Number", 20);
		checkTextInPageAndValidate("Card Status", 20);
		checkTextInPageAndValidate("Card Offer", 20);
		checkTextInPageAndValidate("Customer Card Group", 20);
		checkTextInPageAndValidate("Card Product", 20);

		checkTextInPageAndValidate("Card Type", 20);
		checkTextInPageAndValidate("Pump Control", 20);
		checkTextInPageAndValidate("Pos Prompts", 20);
		checkTextInPageAndValidate("Card Expires On", 20);
		checkTextInPageAndValidate("External Reference", 20);
		checkTextInPageAndValidate("Identification method", 20);

		checkTextInPageAndValidate("Card level Funds", 20);
		checkTextInPageAndValidate("Available Balance", 20);
		checkTextInPageAndValidate("Last Fund Transfers", 20);

		checkTextInPageAndValidate("Purchase Controls", 20);
		checkTextInPageAndValidate("Product Restriction", 20);
		checkTextInPageAndValidate("Time Limit", 20);

		checkTextInPageAndValidate("Driver Details", 20);
		checkTextInPageAndValidate("Driver Name", 20);
		checkTextInPageAndValidate("Driver Id", 20);

		checkTextInPageAndValidate("Vehicle Details", 20);
		checkTextInPageAndValidate("Vehicle Description", 20);
		checkTextInPageAndValidate("VRN", 20);

		checkTextInPageAndValidate("Is Balance Allowed", 20);
		checkTextInPageAndValidate("Actual Balance", 20);

		checkTextInPageAndValidate("Daily Usage Limit", 20);
		checkTextInPageAndValidate("Daily Value Limit", 20);
		checkTextInPageAndValidate("Weekly Usage Limit", 20);
		checkTextInPageAndValidate("Weekly Value Limit", 20);
		checkTextInPageAndValidate("Monthly Usage Limit", 20);
		checkTextInPageAndValidate("Monthly Value Limit", 20);
		checkTextInPageAndValidate("Transaction Value Limit", 20);

		checkTextInPageAndValidate("Account Delivery Address", 20);

		checkAnElementIsDisabled(cardInfoOdoMeter, "Pos prompts Odometer");

		checkAnElementIsDisabled(customerRef, "Pos prompts Customer Reference");

	}

	// Added by Ayub 21.06.2018

	public void selectAllAccountsAndActiveCard() {

		selectDropDownByVisibleText(accountList, "All Accounts");
		sleep(2);
		selectDropDownByVisibleText(filterCardStatus, "Active");

		sleep(2);
		isDisplayedThenClick(searchButton, "Search button");
		sleep(2);
	}

	public void selectAllAccountsAndCardStatus(String selectStatus) {

		selectDropDownByVisibleText(accountList, "All Accounts");
		sleep(2);
		selectDropDownByVisibleText(filterCardStatus, selectStatus);

		sleep(2);
		isDisplayedThenClick(searchButton, "Search button");
		sleep(2);
	}

	public void clickActiveCardAndSelectChangeStatus() {

		int randomNo;
		if (allListedCards.size() == 1) {
			randomNo = 0;
			cardNumber = getText(allListedCards.get(randomNo));

			actionClick(allListedCards.get(randomNo));
			sleep(5);
			clickCardTableMenuOption(changeCardStatus);// commented below code and added here
		} else if (allListedCards.size() > 1) {
			randomNo = getRandomNumber(0, allListedCards.size() - 1);
			cardNumber = getText(allListedCards.get(randomNo));

			actionClick(allListedCards.get(randomNo));
			sleep(5);
			clickCardTableMenuOption(changeCardStatus);// commented below code and added here
		} else {
			logInfo("No Cards Found");
		}
	//	sleep(5);
		//clickCardTableMenuOption(changeCardStatus);
	}

	public void clickCardTableMenuOption(WebElement option) {
		isDisplayedThenActionClick(option, "Card Table Menu");
		//isDisplayedThenClick(option, "Card Table Menu");
		//sleep(5);
		// verifyHeaderTitle(titleTOCheck);
	}

	public void verifyChangeStatusPageAndValidateExpireDate(String effDate,String expiryDate) {
		sleep(5);
		checkTextInPageAndValidate("CHANGE CARD STATUS", 20);
		selectDropDownByVisibleText(newCardStatuss, "Temporary Block");
		sleep(2);
		isDisplayedThenEnterText(startDate, "Start date", "04/12/2018");
		sleep(2);
		isDisplayedThenEnterText(EndDate, "End date", expiryDate);
		sleep(2);
		isDisplayedThenClick(saveButton, "Save button");
		sleep(5);
		String expectedMessage = "New Status Begin Date";
        if(expectedMessage.equals(changeStatusMessage.getText())) {
			checkTextInPageAndValidate("New Status Begin Date Date cannot be in the past.", 30);
		} else {
			checkTextInPageAndValidate("New Status End Date must be after New Status Start Date", 30);
		}
		sleep(5);
		Click(backToCardList, "Back to Card List");
		sleep(5);
	}

	public void verifyChangeStatusPageAndValidateStolen() {
		
		checkTextInPageAndValidate("CHANGE CARD STATUS", 20);
		selectDropDownByVisibleText(newCardStatuss, "Stolen");
		sleep(2);
		isDisplayedThenClick(saveButton, "Save button");
		// checkTextInPageAndValidate("New Card Status Invalid card status change
		// combination", 30);
		sleep(10);
		isDisplayedThenActionClick(confirmNoButton, " No ");
		sleep(10);
		isDisplayedThenActionClick(backToCardList, "Back to Card List");
	}

	public void checkCardStatusAndBalanceofStolencard() {
		
		clickActiveCardAndSelectChangeStatus();
		sleep(10);
		verifyChangeStatusPageAndValidateStolen();
		sleep(5);
		selectDropDownByVisibleText(filterCardStatus, "Stolen");
		sleep(2);
		isDisplayedThenClick(searchButton, "Search button");
		sleep(2);
		setCellDataFromTable(cardListTable, 9, false);
		logInfo("setCellDataFromTable is done");
		int tableCardNumberListSize = customerNumberList.size();
		for (int j = 0; j < tableCardNumberListSize; j++) {
			cardAccNo = getCellDataFromTable(j, 9, false);
			currentCardStatus = getCellDataFromTable(j, 2, false);
			availableBal = getCellDataFromTable(j, 7, false);
			if (cardNumber.equals(cardAccNo)) {
				if ("blocked".equals(currentCardStatus) && "€ 0.00".equals(availableBal)) {
					System.out.println("Got the balance allowed Card Number" + currentCardStatus);
					logPass("Successfully verified Balance Allowed card");
				} else {
					logPass("Successfully verified Not Balance Allowed Account");
				}
			}
		}
		sleep(10);

	}

	public void verifyChangeStatusPageAndValidateNoLongerRequired() {
		checkTextInPageAndValidate("CHANGE CARD STATUS", 20);
		selectDropDownByVisibleText(newCardStatuss, "No Longer Required");
		sleep(2);
		isDisplayedThenClick(saveButton, "Save button");
		sleep(10);
		isDisplayedThenActionClick(backToCardList, "Back to Card List");
	}

	public void checkCardStatusAndBalanceOfNoLongerRequired() {
		
		clickActiveCardAndSelectChangeStatus();		
		sleep(5);
		verifyChangeStatusPageAndValidateNoLongerRequired();
		sleep(3);
		selectDropDownByVisibleText(filterCardStatus, "No Longer Required");
		sleep(2);
		isDisplayedThenClick(searchButton, "Search button");
		sleep(2);
		setCellDataFromTable(cardListTable, 9, false);
		int tableCardNumberListSize = customerNumberList.size();
		for (int j = 0; j < tableCardNumberListSize; j++) {
			cardAccNo = getCellDataFromTable(j, 9, false);
			currentCardStatus = getCellDataFromTable(j, 2, false);
			availableBal = getCellDataFromTable(j, 7, false);
			if (cardNumber.equals(cardAccNo)) {
				if ("blocked".equals(currentCardStatus) && "0".equals(availableBal)) {
					System.out.println("Got the balance allowed Card Number" + currentCardStatus);
					logPass("Successfully verified 0 Balance ");
				} else {
					logPass("Successfully verified Not Balance Allowed Account");
				}
			}
		}

	}

	public boolean goToEditCardPageAfterCheckAvailableBalance() {
		boolean isAvailableBalanceCard = false;
		setCellDataFromTable(cardListTable, 9, true);
		List<WebElement> rowElements =  cardListTable.findElements(By.xpath("./tbody[contains(@id,'lform:tableCardList:tb')]/tr"));
//		int tableCardNumberListSize = customerNumberList.size();
		System.out.println("tableCardNumberListSize---"+rowElements.size());
		for (int j = 0; j < rowElements.size(); j++) {
			cardAccNo = getCellDataFromTable(j+1, 8, true);
			System.out.println("cardAccNo---"+cardAccNo);
			availableBal = getCellDataFromTable(j+1, 6, true);
			System.out.println("availableBal---"+availableBal);
			System.out.println("zeroBal------");
			
			String zeroBal = "€ 0.00";
			String zeroBal1 ="0.00 Kč";
			String zeroBal2 = "0.00 ₽";
			
			System.out.println("-----------"+zeroBal);
//			if (cardNumber.equals(cardAccNo)) {
				if (!availableBal.trim().equals(zeroBal) && !availableBal.equals("") && !availableBal.trim().equals(zeroBal1) && !availableBal.trim().equals(zeroBal2) ) {
					isAvailableBalanceCard = true;
					System.out.println("Got the balance allowed Card Number" + currentCardStatus);
					clickCardNumber(j+1);
					
					clickCardTableMenuOption(editCardMenuButton);
					
					//isDisplayedThenActionClick(editCardMenuButton, "Click Edit card Button");
					sleep(3);
					checkTextInPageAndValidate("Card Details", 30);
					logPass("Selected Card with balance and Active status");
					break;
				} else {
					isAvailableBalanceCard = false;
					logInfo((j+1)+"row Card don't have available balance or don't have available balance greater than zero !!!");
				}
//			}
		}
		
		return isAvailableBalanceCard;

	}
	
	public boolean goToChangeStatusAfterCheckAvailableBalance() {
		boolean hasAvailableBalance = false;
		boolean isCardsNotPresent = waitForTextToAppear("No Cards found.", 20);
		if(!isCardsNotPresent)
				{
		setCellDataFromTable(cardListTable, 9, true);
		List<WebElement> rowElements =  cardListTable.findElements(By.xpath("./tbody[contains(@id,'lform:tableCardList:tb')]/tr"));
		
		System.out.println("rowElements-----"+rowElements);
		for (int j = 0; j < rowElements.size(); j++) {
			
			cardAccNo = getCellDataFromTable(j+1, 8, true);
			System.out.println("cardAccNo-----"+cardAccNo);
			currentCardStatus = getCellDataFromTable(j+1, 1, true);
			availableBal = getCellDataFromTable(j+1, 6, true);
			String zeroBal = "€ 0.00";
			if (!availableBal.trim().equals(zeroBal) && !availableBal.equals("")) {
				hasAvailableBalance = true;
				System.out.println("Click the not balance allowed Card Number" + currentCardStatus);
				clickAndGetCardNumber(j+1);
				 				
				clickCardTableMenuOption(changeCardStatus);
				
				sleep(5);
				
				checkTextInPageAndValidate("CHANGE CARD STATUS", 30);
				logPass("Successfully verified Balance Allowed card");
				break;
			}
			
			else
			{
				hasAvailableBalance = false;
				logInfo("No Card with authorisedAt account");
			}
	
		}
				}else{
					logInfo("No Cards found");
				}
		return hasAvailableBalance;
	}

	public void selectCreatedFromDateUsingCalendarControl() {
		changeStatusPageAndValidateFutureCardStatus(changeStatusStartDate, changeStatusStartDateCalendarDialog,
				"11/June/2012");
	}

	public void changeCardStatusAsNewStatusInEditCard(String newStatus) {

		isDisplayed(editNewCardStatus, "Change New Status");
		sleep(5);
		selectDropDownByVisibleText(editNewCardStatus, newStatus);
	}
	
	public void changeCardStatusAsNewStatus(String newStatus) {

		isDisplayed(newCardStatuss, "Change New Status");
		selectDropDownByVisibleText(newCardStatuss, newStatus);
		
		sleep(5);
		
		String selectedOption = selectedStringFrmDropDown(newCardStatuss);
		
		if(selectedOption.equals(newStatus))
		{
			logPass(newStatus+" is selected");
		}
		
		else
		{
			logFail(newStatus+" is not selected");
		}
		
	}
	
	public void changeStatusPageAndValidateFutureCardStatus(WebElement datePicketButton, WebElement calenderDialogBox,
			String date) {
		checkTextInPageAndValidate("CHANGE CARD STATUS", 20);
		selectDropDownByVisibleText(newCardStatuss, "Temporary Block");
		sleep(2);
		try {
			DateFormat simpleDateFormat = new SimpleDateFormat("dd/MMM/yyyy");
			Date selectDate = simpleDateFormat.parse(date);
			pickDate(selectDate, datePicketButton, calenderDialogBox);
			isDisplayedThenClick(saveButton, "Save button");
		} catch (Exception e) {
			logInfo("Date is not selected" + e);
		}

		sleep(2);
		isDisplayedThenActionClick(backToCardList, "Back to Card List");
	}

	public void validatetheOrderCardPage() {
		checkTextInPageAndValidate("ORDER NEW CARD", 20);
		checkTextInPageAndValidate("Card Details", 20);
		checkTextInPageAndValidate("Purchase Controls", 20);
		isDisplayed(cardOffer, "Card Offer");

	}

	public String validateFillDetailsOfOrderCard() {
		
		validatetheOrderCardPage();
		selectDropDownByIndex(cardOffer, 1);
		sleep(5);
		
		if (driverDetailsOption.isDisplayed()) {
			isDisplayedThenEnterText(driverName, "Driver Name", fakerAPI().name().fullName());
			logPass("Enter the Driver name");
		} else {
			logInfo("No Driver Details");
		}
		
		String embossName = fakerAPI().name().fullName();
		isDisplayedThenEnterText(cardEmbossName,"Emboss name", embossName);
		
		//isDisplayedThenEnterText(driverName, "Driver Name", FakerAPI().name().fullName());
		//isDisplayedThenEnterText(vehicleRegoNumber, "VRN", fakerAPI().number().digits(5));
		
		selectDropDownByIndex(transactionMonthlyLimit, 1);
		
		selectDropDownByIndex(transactionPurchaseLimit, 1);
		
		selectDropDownByIndex(dailyTransactionLimit, 1);
		
		selectDropDownByIndex(weeklyTransactionLimit, 1);
		
		selectDropDownByIndex(monthlyValueLimit, 1);
		sleep(2);
		isDisplayedThenActionClick(orderCard, "Order Card");
		sleep(3);
		isDisplayed(confirmationMsg, "Validation Successful");
		sleep(2);
		isDisplayedThenClick(backButton, "clicking back button");
		sleep(3);
		validatetheOrderCardPage();
		
		isDisplayedThenActionClick(confirmBtn, "Click Confirm button");
		sleep(3);
		isDisplayed(orderedCardSuccessMsg, "Card Ordered Successfully");
		
		String orderedCardNumber = getText(customerCardNumber);
		
		System.out.println("orderedCardNumber : "+orderedCardNumber);
		
		return orderedCardNumber;
	}

	public String clickNotBalancedAllowedCardListForAuthorityAt() {
		String selectedCard = "";
		 
		setCellDataFromTable(cardListTable, 9, true);
		boolean isClicked = false;
		
		List<WebElement> rowElements =  cardListTable.findElements(By.xpath("./tbody[contains(@id,'lform:tableCardList:tb')]/tr"));
		//int tableCardNumberListSize = customerNumberList.size();
		
		System.out.println("rowElements.size()"+rowElements.size());
		
		for (int j = 0; j < rowElements.size(); j++) {
			if(isClicked)
				break;
			authorisedAt = getCellDataFromTable(j+1, 7, true);
			
			System.out.println("----- authorisedAt -------"+authorisedAt);
			
			currentCardStatus = getCellDataFromTable(j+1, 1, true);
			getCardNumber = getCellDataFromTable(j+1, 0, true);
			if ("Account".equals(authorisedAt)) {
				System.out.println("Click the not balance allowed Card Number" + currentCardStatus);
				selectedCard = clickAndGetCardNumber(j+1);
				System.out.println("------ selectedCard ------"+selectedCard);
				  
				//sleep(5);
				
				clickCardTableMenuOption(changeCardStatus);
				
				sleep(5);
				
				checkTextInPageAndValidate("CHANGE CARD STATUS", 10);
				logPass("Successfully verified Balance Allowed card");
				isClicked = true;
			}
			
			else
			{
				logInfo("No Card with authorisedAt account");
			}
			
		} 
		return selectedCard;
	}
	
	public String clickBalanceAllowedCardListForAuthorityAt() {
		String getCardByBalanceAllowed = "";
		setCellDataFromTable(cardListTable, 9, false);
		List<WebElement> rowElements =  cardListTable.findElements(By.xpath("./tbody[contains(@id,'lform:tableCardList:tb')]/tr"));
		//int tableCardNumberListSize = customerNumberList.size();
		
		System.out.println("rowElements.size()"+rowElements.size());
		boolean isClicked=false;
		for (int j = 0; j < rowElements.size(); j++) {
			if(isClicked)
				break;
			authorisedAt = getCellDataFromTable(j+1, 7, false);
			currentCardStatus = getCellDataFromTable(j+1, 1, false);
			getCardNumber = getCellDataFromTable(j+1, 0, false);
			if ("Card".equals(authorisedAt)) {
				System.out.println("Click the balance allowed Card Number" + currentCardStatus);
				getCardByBalanceAllowed = clickAndGetCardNumber(j+1);
				clickCardTableMenuOption(changeCardStatus);
				verifyText(pageTitle, "CHANGE CARD STATUS");
//				checkTextInPageAndValidate("Change Card Status ", 20);
				logPass("Successfully verified Balance Allowed card");
				isClicked = true;
			}
			
			else
			{
				logInfo("No Card with authorisedAt card");
			}
		}
		
		return getCardByBalanceAllowed;
	}

	public void clickBackToCardList() {
		
		scrollToTopPage();
		isDisplayedThenClick(backToCardList, "Click Back to Card List Button");
		sleep(3);
	}

	public void selectCardNewlyUpdatedAndViewCardValidate(String changedStatus, String actSelectedCard) {
		selectAllAccountsAndCardStatus(changedStatus);
		setCellDataFromTable(cardListTable, 9, false);
		List<WebElement> rowElements =  cardListTable.findElements(By.xpath("./tbody[contains(@id,'lform:tableCardList:tb')]/tr"));
//		int tableCardNumberListSize = customerNumberList.size()
		boolean isClicked = false;
		for (int j = 0; j < rowElements.size(); j++) {
			if(isClicked)
				break;
			getCardNumber = getCellDataFromTable(j+1, 0, false);
			if(actSelectedCard.equals(getCardNumber)) {
				System.out.println("Balance allowed Card Number" + getCardNumber);
				clickCardNumber(j+1);
				sleep(3);
				clickCardTableMenuOption(viewCardMenu);
//				clickCardTableMenuOption(viewCardCL);
				sleep(2);
				checkTextInPageAndValidate("VIEW CARD", 20);
				String presentCardStatus = getText(viewCardStatus);
				isClicked=true;
				if(presentCardStatus.equals(changedStatus)) {
					logPass("Successfully verified status in View Card");
				}
				logPass("Successfully verified Balance Allowed card");
			} else {
				logInfo("Card is not present in the list");
			}
		}
	}
	
	// Added by Ayub on 25.06.2018
	public void clickReplaceCardAndGoToReplaceCardPage() {
		int randomNo;
		if (allListedCards.size() == 1) {
			randomNo = 0;
			cardNumber = getText(allListedCards.get(randomNo));

			actionClick(allListedCards.get(randomNo));
		}
		else if (allListedCards.size() > 0) {
			randomNo = getRandomNumber(0, allListedCards.size() - 1);
			cardNumber = getText(allListedCards.get(randomNo));
			actionClick(allListedCards.get(randomNo));
		} else {
			logInfo("No Cards Found");
		}
		scrollDownPage();
		sleep(10);
	    clickCardTableMenuOption(replaceCard);
	    sleep(10);
	}
	public void validateReplaceCardPage() {
		checkTextInPageAndValidate("REPLACE CARD", 20);
		checkTextInPageAndValidate("Card Number", 20);
		checkTextInPageAndValidate("Card Offer", 20);
		checkTextInPageAndValidate("Card Product", 20);
		checkTextInPageAndValidate("Card Type", 20);
		//checkTextInPageAndValidate("Driver Name", 20);
		checkTextInPageAndValidate("Current Card Status", 20);
		//checkTextInPageAndValidate("Driver ID", 20);
		checkTextInPageAndValidate("Delivery Address", 20);
	}
/*
 * Validate Buld card update page
 * 
 */
	public void validateBuldCardUpdatePage() {
		// TODO Auto-generated method stub
		checkTextInPageAndValidate("BULK UPDATE", 30);
	}

	/*
	 * Verify all required fields
	 * 
	 */
	
	public void verifyAllRequiredFieldsBulkCardUpdate() {
		// TODO Auto-generated method stub
		
		checkTextInPageAndValidate("Account Number", 30);
		checkTextInPageAndValidate("Card Number From", 30);
		checkTextInPageAndValidate("Card Number To", 30);
		checkTextInPageAndValidate("Card Offer", 30);
		checkTextInPageAndValidate("Card Status", 30);
		checkTextInPageAndValidate("External Reference", 30);
		checkTextInPageAndValidate("Card Group ID", 30);
		checkTextInPageAndValidate("Card Last Transaction Date", 30);
		checkTextInPageAndValidate("Card Expires On", 30);
		
	}
	
	public void clickBulkCardUpdateSearch() {

		isDisplayedThenActionClick(searchBulkCard, "Click Search Bulk Card Update Button");
		
		sleep(3);
	}
	
	public void UnCheckSelectALL()
	{
		selectORNotSelectElement(selectAllCb, "Select All check box");
		sleep(5);
	}
	
	private void selectFirstRowCustomer(WebElement tableElement, String message) {
		// TODO Auto-generated method stub
		
		WebElement firstCustomer = null;
		
		try {		
			firstCustomer = tableElement.findElement(By.xpath("./tbody/tr[1]"));
			
			isDisplayed(firstCustomer, "First customer");
			
			WebElement firstCustomerCheckBox= firstCustomer.findElement(By.xpath("./td[1]/p/input"));
			
			isDisplayed(firstCustomerCheckBox, "First Customer checkbox");			
				
			selectORNotSelectElement(firstCustomerCheckBox, "First customer");
			
		}
		
		catch(Exception e)
		{
			logFail(e.getMessage());
		}
	}
	
	public void selectOneAccountAndDownload()
	{
		isDisplayed(bulkCardUpdateTable, "Bulk Card Update Table");
		
		selectFirstRowCustomer(bulkCardUpdateTable, "Bulk card Update Table");
		
		sleep(5);
		
		isDisplayedThenClick(download, "Download Button");
		
		sleep(3);
	}

	/*
	 * Upload the Customer And Verify
	 */
	
	public void UploadTheCustomerAndVerify() {
		
		
	}
	// Added by Anton on 26.06.2018
	 
	public void changeStatusPageAndValidateCurrentSystemDate() {

		sleep(5);
		checkTextInPageAndValidate("CHANGE CARD STATUS", 20);

		selectDropDownByVisibleText(newCardStatuss, "Temporary Block");

		sleep(2);

		String curDate = getCurrentDate();

		String futureDate = getFutureDate(10);

		System.out.println("----- Future Date ---- " + futureDate);

		isDisplayedThenEnterText(startDate, "Start date", curDate);

		isDisplayedThenEnterText(EndDate, "End Date", futureDate);

		isDisplayedThenClick(saveButton, "Save Card Status");

		sleep(3);
		
 //		verifyText(confirmationMsg,"New future card status Temporary Block for card  "+currentCardNumber +" has been successfully added.");
		isDisplayed(cardHistoryTable, "Card History Table");

		checkTextInPageAndValidate(curDate, 20);

		checkTextInPageAndValidate(futureDate, 20);

		isDisplayedThenActionClick(backToCardList, "Back to Card List");
	}
	
	 	 
	public void checkCardStatusAndBalanceofTemporaryBlock() {
 

	//	isDisplayedThenActionClick(filterCardStatus, "Click Card Status Drop down");
		isDisplayedThenEnterText(currentCardNumber, "Card Number Search", cardNumber);
//		selectDropDownByVisibleText(filterCardStatus, "Active");
		selectDropDownByVisibleText(filterCardStatus, "Temporary Block");
		sleep(2);
		isDisplayedThenClick(searchButton, "Search button");
		sleep(5);
		
		boolean isCardsNotPresent = waitForTextToAppear("No Cards found.", 20);					
		if(!isCardsNotPresent)			
		{

		isDisplayed(cardListTable, "Card List Table");
		//checkTextInPageAndValidate(cardNumber, 30);		
		setCellDataFromTable(cardListTable, 9, true);
		
		String cardBalance ="";
		cardBalance=getCellDataFromTable(1, 6, true);
		 
		System.out.println("cardBalance ---- "+cardBalance);
		
		if(!cardBalance.equals(""))
		{
			logPass("Card Balance amount is Present");
		}
		
		else
		{
			logInfo("Card Balance amount is not present");
		}
		}else{					
			
			logInfo("No Cards found");}	
		
	}

	
public void changeStatusPageAndValidateFutureCardStatus() {
	sleep(5);
	checkTextInPageAndValidate("CHANGE CARD STATUS", 20);
	 
	selectDropDownByVisibleText(newCardStatuss, "Temporary Block");
	 
	sleep(2);
	 
	String startfutureDate = getFutureDate(6);
	 
	String endfutureDate = getFutureDate(10);
	 
	System.out.println("----- Future Date ---- "+startfutureDate);
	 
	isDisplayedThenEnterText(startDate, "Start date", startfutureDate);
	 
	isDisplayedThenEnterText(EndDate, "End Date", endfutureDate);
	 
	isDisplayedThenClick(saveButton, "Save Card Status");

	sleep(3);
	 
	isDisplayed(cardHistoryTable, "Card History Table");
	 
	checkTextInPageAndValidate(startfutureDate, 20);
	 
	checkTextInPageAndValidate(endfutureDate, 20);
	 
	//isDisplayedThenActionClick(backToCardList, "Back to Card List");
	}
 
	public void validateReplaceContentPopupYesOrNobutton(String replaceBtn) {
		
		sleep(5);
		
		boolean cardStatus = waitForTextToAppear("Invalid card status change combination", 30); 
		
		boolean cardStatus1 =  waitForTextToAppear("New Card Status Invalid card status change combination",30);
		
		if(cardStatus && cardStatus1)
		{
			
			logInfo("Invalid card status change combination is Present");
			
			logInfo("New Card Status Invalid card status change combination is Present");
			
			logInfo("Please check manually in IFCS desktop");
			
			logFail("Fail due to the, error mesage present instead of Replace content Popup is not Displayed");
			
		}
		
		else
		{
			isDisplayed(replacePopupContent, "Replace Content Popup Displayed");
			
			if("Yes".equals(replaceBtn)) {
				isDisplayedThenClick(reissueCardYes, "Click Reissue Yes Button");
			} else {
				isDisplayedThenClick(reissueCardConfirmNo, "Click Reissue No Button");
			}
		
			sleep(10);
		}
		
	}

	/*
	 * Select a different account instead of default account.
	 * 
	 */
	
	public void selectOneAccountAndActiveCard(String defaultAccount) {		
		
		selectDifferentValueInsteadOfDefault(accountList, defaultAccount, "All Accounts");		
		
		sleep(3);
		
		selectDropDownByVisibleText(filterCardStatus, "Active");

		sleep(3);		
		
	}

	/*
	 * Validate The Edit Card And Reissue
	 * 
	 */
	public void validateTheEditCardAndReIssue(String accountStatus) {
		
		sleep(3);
		
		isDisplayedThenClick(acceptBTN, "Accept button");
		
		sleep(3);
		if(waitToCheckElementIsDisplayed(By.id("lform:saveStatusAndReissueCardBnt"), 20)) {
		
		isDisplayedThenClick(yesReplacementBtn, "Yes Replacement Card");
		
		sleep(5);
		} else {
		
		
		if(accountStatus.equals("B - Blocked/Suspended"))
		{
//			isDisplayed(errorMessage, "Validate Error Message");
			checkTextInPageAndValidate("Invalid card status for reissue", 30);
		}
			
		else
		{
			if(waitForTextToAppear("Invalid card status for reissue", 30)) {
				logInfo("Status cannot be changed due to status change combination");
			}
//			checkTextInPageAndValidate("Success!  Your card details have been saved.", 30);
			verifyText(confirmationMsg, "Success!");
			logPass("Card status changed");
		}
		}
	}
	
public void validateTheEditCardAndNotReIssue(String accountStatus) {
		
		sleep(3);
		isDisplayedThenClick(acceptBTN, "Accept button");
		sleep(3);
		isDisplayedThenClick(cardChangePopupNoButton, "No Replacement Card");
		
		sleep(5);
		if(accountStatus.equals("B - Blocked/Suspended")) {
			checkTextInPageAndValidate("Invalid card status for reissue", 30);
		} else {
			if(waitForTextToAppear("Invalid card status for reissue", 30)) {
				logInfo("Status cannot be changed due to status change combination");
			}
			isDisplayed(confirmationMsg, "Is success message is displayed");
//			verifyText(confirmationMsg, "Success!  Your card details have been saved.");
		}
	}


public void validateTheEditCard() {
		
		sleep(3);
		isDisplayedThenClick(acceptBTN, "Accept button");
		sleep(3);
		verifyText(confirmationMsg, "Success!  Your card details have been saved.");
		
}
		
	public void verifyReissueControlPage() {

		checkTextInPageAndValidate("Bulk Re-issue", 10);
		sleep(3);
	}
	
	public void clickExportButton() {
		
		isDisplayedThenActionClick(reissueControlExportButton, "Click Reissue Control Export button");
	}
	
	public boolean verifyBulkReIssueListDataIsAvailable()
	{
		boolean isBulkReIssue = false;
		
		isBulkReIssue = waitForTextToAppear("Bulk Re-issue List is Empty.", 30);		
		
		return isBulkReIssue;
	}
	
	public boolean verifyBulkCardStatusListDataIsAvailable()
	{
		boolean isBulkReIssue = false;
		
		isBulkReIssue = waitForTextToAppear("Card Status List Is Empty", 30);		
		
		return isBulkReIssue;
	}

	public void printNoReissueDataPresent() {
		logInfo("No Reissue Data are present");		
	}

	public void printNoBulkCardDataPresent() {
		logInfo("No Reissue Data are present");	
		sleep(3);
	}


	public void goToReissueDetailsPage() {		
		isDisplayed(bulkReissueTable, "Bulk Reissuie table");
		List<WebElement> rows = bulkReissueTable.findElements(By.xpath("./tbody[@id='lform:dataBulkReissue:tb']/tr"));
		int transactionsSize = getRowSize(bulkReissueTable);
		
		if(transactionsSize > 0)
		{
			logInfo("Rows are present");
			
			WebElement firstRow= rows.get(0);
			
			isDisplayed(firstRow, "First row is present");
			
			WebElement detailsButton = firstRow.findElement(By.xpath("./td"));
			
			/*String js = "arguments[0].style.height='auto'; arguments[0].style.visibility='visible';";

			((JavascriptExecutor) driver).executeScript(js, detailsButton);
			
			sleep(3);*/
			
			isDisplayedThenClick(detailsButton, "Details Button");
			
			sleep(3);
		}
		
	}

	public void returnToBulkReissueList() {
		
		isDisplayedThenClick(returnToReIssueCardList, "Return to Re-issue Card List page");
	}
	
	/*
	 * Verify Reissue details page is loaded
	 * 
	 * 
	 */

	public void verifyReissueDetailsPageIsLoaded()
	{
		checkTextInPageAndValidate("REISSUE REQUESTS DETAILS",30);
		checkTextInPageAndValidate("Card Details",30);
	}

	public void verifyReissueStatusAndProceed() {
		String invalidState = "Reissue Complete";
		String requestState = requestStatus.getText();
	    if(invalidState.equals(requestState)) {
	    	logInfo("Not a valid state to proceed with Bulk Reissue");
	    } else {
	    	excludeACardAndSave();
	    	returnToBulkReissueList();
	    	verifyReissueControlPage();
	    }
	
	}
	
	/*
	 * Exclude A Card and Save and Verify
	 * 
	 */
	
	public void excludeACardAndSave() {
		
		isDisplayed(bulkReissueTable, "Bulk reissue tab");
		
		for(WebElement checkBoxExclude :excludeCBs)
		{
			if(checkBoxExclude.isSelected())
			{
				logInfo("Check box already selected");
				break;
			}
			else
			{
				checkBoxExclude.click();
				logInfo("Check box Newly clicked");
				break;
			}
		}
		
		//sleep(5);
		
		isDisplayedThenClick(saveReissueBTN, "SAVE Reissue button");
		
		sleep(5);
		
		checkTextInPageAndValidate("Your selections have been saved and this Reissue Request has been", 30);
		
				
	}
	
	public void clickReissueRequestAndValidate() {
		isDisplayedThenActionClick(reissueRequest, "Click Reissue request");
		checkTextInPageAndValidate("Reissue Requests Details", 10);
	}

	public void clickReissueRequestExportBtn() {
		isDisplayedThenActionClick(reissueRequestExportButton, "click reissue request button");
	}
	
	public void validateDateAndOptionsFields() {
		
		checkAnElementIsDisabled(expiresOnFromDate, "Validate Expires From Date");
		
		checkAnElementIsDisabled(newExpiresOnDate, "Validate New Expires on Date");
		
		checkAnElementIsDisabled(reissueOnDate, "Validate Reissue on Date");
		
		checkAnElementIsDisabled(reissueExpiresOnToDate, "Validate Expires To Date");
		
		checkAnElementIsDisabled(reissueConfirmOnDate, "Validate Confirm On Date");
	}
	
	// Added by Ayub on 02.07.2018
	public void goToCardMenuAndValidateOrderNewCard(String accountStatus) {
		if (accountStatus.equals("B - Blocked/Suspended") || accountStatus.equals("C - Cancelled/Closed")) {

			if (checkSubMenuPresence("Cards", "Order Card")) {
				logFail("Order Card is presence");
			} else {
				logPass("Order Card is not present");
			}

		}

	}
	
	/*
	 * This method for going to the Reissue PIN for any active card
	 * Added by Anton 03.07.2018
	 * 
	 */
	public void goToReissuePINForAnyActiveCardAndValidate() {
		
		setCellDataFromTable(cardListTable, 9, true);
		
		cardAccNo = getCellDataFromTable(1, 0, true);
			
		System.out.println("cardAccNo---"+cardAccNo); 
			
		String cardNo = clickAndGetCardNumber(1);
					
		clickCardTableMenuOption(reissuePIN); 
					
		sleep(5);
					
		checkTextInPageAndValidate("REISSUE CARD PIN", 30);
			
		checkTextInPageAndValidate(cardAccNo, 30);
		
		isDisplayedThenClick(orderCard, "Reissue PIN confirm");
		
		sleep(5);
		
		boolean confirmationMsgValidation = waitToCheckElementIsDisplayed(By.id("successMsg"),30);
		
		if(confirmationMsgValidation) {
			checkTextInPageAndValidate("Your PIN mailer for card "+cardNo+" was successfully requested.", 30);
		} else {
			checkTextInPageAndValidate("Account status does not permit cards to be ordered", 30);
			logInfo("For this Card - Account Status is in blocked state in IFCS - Need to Change in IFCS");
		}			
	}
	
	//In Progress
	public int getANonReplacedCardAndCheckReissePIN() {
		int cardNumber = 0;
		return cardNumber;
	}
	 

	public void validateOrderCardQuickLinksDisabled(String accountStatus) {
		if (accountStatus.equals("B - Blocked/Suspended") || accountStatus.equals("C - Cancelled/Closed")) {
			try {
				if (orderNewCardQuickLink.isDisplayed()) {
					logFail("Order New card quick links is present");
				}
			} catch (NoSuchElementException ex) {
				logInfo("Order New card quick links not displayed");
			}

		}
	}
	/*
	@DataProvider(name = "invalidNumbers")
	public Object[][] provideInvalidNumbers() {
	return new Object[][]{{"£!@$%^*&"} , {"123456786543"}};
	}*/
	
	public void enterVRNWronglyAndValidateErrorMsg() {
		checkTextInPageAndValidate("ORDER NEW CARD", 20);
		checkTextInPageAndValidate("Card Details", 20);
		checkTextInPageAndValidate("Purchase Controls", 20);
		isDisplayed(cardOffer, "Card Offer");
		
		selectDropDownByIndex(cardOffer, 1);
		sleep(5);
		
		isDisplayedThenEnterText(vehicleRegoNumber, "VRN", "£!@$%^*&");
		sleep(2);
		
		isDisplayedThenActionClick(orderCard, "Order Card");
		sleep(3);
		isDisplayed(errorMsg, "Validation Failed");
		sleep(2);
		isDisplayedThenEnterText(vehicleRegoNumber, "VRN", "12345678654");
		sleep(2);
		
		isDisplayedThenActionClick(orderCard, "Order Card");
		sleep(3);
		isDisplayed(errorMsg, "Validation Failed");
		sleep(2);
		isDisplayedThenEnterText(vehicleRegoNumber, "VRN", fakerAPI().number().digits(5));
		sleep(3);
		isDisplayedThenActionClick(orderCard, "Order Card");
		sleep(3);
		isDisplayed(confirmationMsg, "Validation Successful");
	}
public String fillingAndvalidateDetailsofOrderCard() {
		
		validatetheOrderCardPage();
		
		selectDropDownByIndex(cardOffer, 1);
		sleep(5);
		
		String  f_drivername = fakerAPI().name().fullName();
		String	f_vrn = fakerAPI().number().digits(5);
		
		
		isDisplayedThenEnterText(driverName, "Driver Name", f_drivername);
		
		String embossName = fakerAPI().name().fullName();
		isDisplayedThenEnterText(cardEmbossName,"Emboss name", embossName);
		
		isDisplayedThenEnterText(vehicleRegoNumber, "VRN", f_vrn);
		sleep(2);
		isDisplayedThenActionClick(orderCard, "Order Card");
		sleep(3);
		isDisplayed(confirmationMsg, "Validation Successful");
		
		isDisplayedThenClick(backButton, "clicking back button");
		
		validatetheOrderCardPage();
		String dName = getText(driverName);
		String vrnNo = getText(vehicleRegoNumber);
		
		System.out.println("dName : "+dName+" "+"vrnNo : "+vrnNo);
		
		
		/*if (getText(driverName).trim().equalsIgnoreCase(f_drivername)) {
			logPass("driver name is same");
		} else {
			logFail("driver name is differnt");
		}

		if (getText(vehicleRegoNumber).trim().equalsIgnoreCase(f_vrn)) {
			logPass("Rego Number is same");
		} else {
			logFail("Rego Number is differnt");
		}*/
		
		isDisplayedThenActionClick(confirmBtn, "Click Confirm button");
		
		String orderedCardNumber = customerCardNumber.getText();
		
		System.out.println("orderedCardNumber : "+orderedCardNumber);
		
		return orderedCardNumber;
	}


public void enterVRNInEditCard() {
	String	f_vrn = fakerAPI().number().digits(5);
	isDisplayedThenEnterText(vehicleRegoNumber, "VRN", f_vrn);
	sleep(2);
	clickUpdateButton();
	
}
public void enterExpiryDateInEditCard(String date,String expectedmsg) {
	
	try {
		DateFormat simpleDateFormat = new SimpleDateFormat("dd/MMM/yyyy");
		Date selectDate = simpleDateFormat.parse(date);
		pickDate(selectDate,expiryDateCalenderInEditCard,expiryDateInCalenderDialogBox);
		sleep(2);
		clickUpdateButton();
		sleep(3);
		isDisplayedThenClick(acceptBTN, "Accept button");
		String actualmsg=getText(messagePopup);
		if(actualmsg.equals(expectedmsg)) {
			logPass(expectedmsg+"Expected message is dispalyed");
		}	
		else
			logFail("Expected message is not  dispalyed");
	
		
	} catch (Exception e) {
		logInfo("Date is not selected" + e);
	}

	
	
	
}



}
