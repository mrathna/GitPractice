using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using Common;
using Common.PageObjects;
using Common.ScenarioConfigurations;
using Common.Utility;

namespace EnCompass.Testing.Source.PageObjects.Organization.ExpenseManager.Transactions 
{
	/// <summary>
	/// Auto-generated Page Model Class
	/// Navigation Paths: 
		/// [Organization Home]->Transactions->Disputes
		/// [Organization Home]->Payables->Purchase Log->Disputes
		/// </summary>
	[PageModel(@"/expenseManager/transactions/transactionDisputeManagement.aspx")]
	public partial class TransactionDisputeManagement : EnCompassOrgPageModel 
	{
		public override string RelativeUrl => @"/expenseManager/transactions/transactionDisputeManagement.aspx";
		public override string PageIdentifierXPath_Generated => @"//li[contains(@class, 'breadcrumb-item active')][text() = 'Disputes']";

		#region Navigation
		
		private void NavigateToMenuItem(IWebElement element)
		{
			Driver.Url = element.GetAttribute("href");
		}
		#endregion

		public TransactionDisputeManagement(GlobalSettings settings) : base(settings) { }
	}  
}
