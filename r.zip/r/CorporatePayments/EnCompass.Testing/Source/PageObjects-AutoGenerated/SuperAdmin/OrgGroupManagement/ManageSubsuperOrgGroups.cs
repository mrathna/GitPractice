using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using Common;
using Common.PageObjects;
using Common.ScenarioConfigurations;
using Common.Utility;

namespace EnCompass.Testing.Source.PageObjects.SuperAdmin.OrgGroupManagement 
{
	/// <summary>
	/// Auto-generated Page Model Class
	/// Navigation Paths: 
		/// [Organization Home]->Users and Organizations->Multi-Organizations
		/// </summary>
	[PageModel(@"/superAdmin/orgGroupManagement/manageSubsuperOrgGroups.aspx")]
	public partial class ManageSubsuperOrgGroups : EnCompassSuperPageModel 
	{
		public override string RelativeUrl => @"/superAdmin/orgGroupManagement/manageSubsuperOrgGroups.aspx";
		public override string PageIdentifierXPath_Generated => @"//li[contains(@class, 'breadcrumb-item active')][text() = 'Multi-Organizations']";

		#region Navigation
		
		private void NavigateToMenuItem(IWebElement element)
		{
			Driver.Url = element.GetAttribute("href");
		}
		#endregion

		public ManageSubsuperOrgGroups(GlobalSettings settings) : base(settings) { }
	}  
}
