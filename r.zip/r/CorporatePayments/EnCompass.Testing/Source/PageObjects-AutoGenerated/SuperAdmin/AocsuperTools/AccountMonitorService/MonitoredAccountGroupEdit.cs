using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using Common;
using Common.PageObjects;
using Common.ScenarioConfigurations;
using Common.Utility;

namespace EnCompass.Testing.Source.PageObjects.SuperAdmin.AocsuperTools.AccountMonitorService 
{
	/// <summary>
	/// Auto-generated Page Model Class
	/// Navigation Paths: 
		/// [Organization Home]->General->Account Monitor Service
		/// </summary>
	[PageModel(@"/superAdmin/AOCSuperTools/AccountMonitorService/MonitoredAccountGroupEdit.aspx")]
	public partial class MonitoredAccountGroupEdit : EnCompassSuperPageModel 
	{
		public override string RelativeUrl => @"/superAdmin/AOCSuperTools/AccountMonitorService/MonitoredAccountGroupEdit.aspx";
		public override string PageIdentifierXPath_Generated => @"//li[contains(@class, 'breadcrumb-item active')][text() = 'Account Monitor Service']";

		#region Navigation
		
		private void NavigateToMenuItem(IWebElement element)
		{
			Driver.Url = element.GetAttribute("href");
		}
		#endregion

		public MonitoredAccountGroupEdit(GlobalSettings settings) : base(settings) { }
	}  
}
