package com.framework.testcases.AJS.CHEVRON;

import com.framework.basetest.BaseTest;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.ApplicationsPage;
import com.framework.pages.AJS.CardMaintenancePage;
import com.framework.pages.AJS.MaintainCustomerPage;
import com.framework.pages.AJS.common.Common;
import com.framework.pages.AJS.common.IFCSHomePage;
import com.framework.pages.AJS.common.IFCSLoginPage;
import com.github.javafaker.Faker;

public class ValidateMaintainCustomerTestCases extends BaseTest  {
	
	
	/**
	 * Implemented by Rathna
	 * 
	 * @param clientCountry
	 * @param clientName
	 *  Business Flow ID:BF-034       
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "BusinessFlow" })
	public void createMoreThanOneCostCentreInIFCS(@Optional("HK") String clientCountry,
			@Optional("BP") String clientName) {

		test = extent.createTest(clientName + ":" + clientCountry + " TC-794 TC02_CustMgmt_CostCentre_CardDep_Add_more_CC",
				"RQ:878 - Able to add more than one cost center");
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		MaintainCustomerPage maintainCustomerPage = new MaintainCustomerPage(driver, test);
		Common common = new Common(driver, test);

		IFCSloginPage.login("IFCS_URL_CHEVRON", "IFCS_CHEVRON_USERNAME", "IFCS_CHEVRON_PASSWORD");

		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");

		// getting Active Customer No from DB/
		String customerNumberUsingCardType = common.getActiveCustomerNoUsingCardType();
		if (customerNumberUsingCardType.equals(" ")) {
			common.logForNoDataFound(this.getClass().getSimpleName(),
					"Need to Create A Customer with Card Type and rerun");
		} else {

			for (int count = 1; count <= 2; count++) {
				IFCSHomePage.gotoCustomerMenuCustomerDetails();
				common.chooseCustomerNoAndSearch(customerNumberUsingCardType);
				maintainCustomerPage.chooseCostCentre();
				String costCenterCode = Faker.instance().number().digits(4);
				maintainCustomerPage.addCostCentreAndValidate(costCenterCode);
			}

		}
		IFCSHomePage.exitIFCS();

	}
	
	
	/**
	 * Implemented by Rathna
	 * 
	 * @param clientCountry
	 * @param clientName
	 *            Business Flow ID:BF-077
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "BusinessFlow" })
	public void createCostCentreInIFCS(@Optional("HK") String clientCountry, @Optional("CHEVRON") String clientName) {

		test = extent.createTest(clientName + ":" + clientCountry + " ID:BF-077 Create Cost Center",
				"Able to create cost centre in IFCS");
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		MaintainCustomerPage maintainCustomerPage = new MaintainCustomerPage(driver, test);
		Common common = new Common(driver, test);

		IFCSloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");

		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");

		// getting Active Customer No from DB/
		String customerNumberUsingCardType = common.getActiveCustomerNoUsingCardType();
		if (customerNumberUsingCardType.equals(" ")) {
			common.logForNoDataFound(this.getClass().getSimpleName(),
					"Need to Create A Customer with Card Type and rerun");
		} else {
			// Add a Cost Centre
			IFCSHomePage.gotoCustomerMenuCustomerDetails();
			common.chooseCustomerNoAndSearch(customerNumberUsingCardType);
			maintainCustomerPage.chooseCostCentre();
			String costCenterCode = Faker.instance().number().digits(4);
			maintainCustomerPage.addCostCentreAndValidate(costCenterCode);

		}
		IFCSHomePage.exitIFCS();

	}

	/**
	 * Implemented by Rathna
	 * 
	 * @param clientCountry
	 * @param clientName
	 *            
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "BusinessFlow" })
	public void updateExistingCardWithCostCentre(@Optional("HK") String clientCountry,
			@Optional("CHEVRON") String clientName) {

		test = extent.createTest(clientName + ":" + clientCountry + " TC-795 TC03_CustMgmt_CostCentre_ExtCard_Department_Upd",
				"RQ-788:Update the cost centre details");
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		MaintainCustomerPage maintainCustomerPage = new MaintainCustomerPage(driver, test);
		CardMaintenancePage cardMaintenancePage = new CardMaintenancePage(driver, test);
		Common common = new Common(driver, test);

		IFCSloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");

		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");

		// getting Card No from DB/
		String cardNo = common.getCardNumberhavingNoCostCentreFromDB();
		String costCenterCode = Faker.instance().number().digits(4);
		if (cardNo.equals(" ")) {
			common.logForNoDataFound(this.getClass().getSimpleName(),
					"Need to Create A Customer with Card Type and rerun");
		} else {

			IFCSHomePage.gotoCustomerMenuCustomerDetails();
			cardMaintenancePage.chooseAndSearchCardNo(cardNo);
			maintainCustomerPage.chooseCostCentre();
			maintainCustomerPage.addCostCentreAndValidate(costCenterCode);
		}

		cardMaintenancePage.chooseAndSearchCardNo(cardNo);
		cardMaintenancePage.updateCostCentreForCard(costCenterCode);
		IFCSHomePage.exitIFCS();

	}

}
