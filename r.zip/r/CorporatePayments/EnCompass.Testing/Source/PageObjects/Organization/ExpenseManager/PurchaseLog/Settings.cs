﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EnCompass.Testing.Source.PageObjects.Organization.ExpenseManager.PurchaseLog
{
	public partial class Settings
	{
		[FindsBy(How = How.XPath, Using = @"//input[contains(@id, 'ThresholdLimit')]/../..//td/span//label[contains(text(), 'above')]/../../../td/input")]
		private IWebElement _reconPctAbove { get; set; }

		[FindsBy(How = How.XPath, Using = @"//input[contains(@id, 'ThresholdLimitBelow')]/../..//td/span//label[contains(text(), 'below')]/../../../td/input")]
		private IWebElement _reconPctBelow { get; set; }

		[FindsBy(How = How.XPath, Using = @"//input[contains(@id, 'btnsubmit')]")]
		private IWebElement _save { get; set; }

		public string ReconThresholdPctAbove
		{
			get { return _reconPctAbove.GetAttribute("value").Trim(); }
			set { _reconPctAbove.Clear(); _reconPctAbove.SendKeys(value); }
		}

		public string ReconThresholdPctBelow
		{
			get { return _reconPctBelow.GetAttribute("value").Trim(); }
			set { _reconPctBelow.Clear(); _reconPctBelow.SendKeys(value); }
		}

		public void Save()
		{
			_save.Click();
			this.AttachOnDemandScreenShot();
		}
	}
}
