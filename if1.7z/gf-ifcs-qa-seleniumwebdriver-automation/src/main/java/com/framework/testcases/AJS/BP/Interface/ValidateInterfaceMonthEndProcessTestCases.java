package com.framework.testcases.AJS.BP.Interface;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.TransactionListPage;
import com.framework.pages.AJS.common.Common;
import com.framework.pages.AJS.common.CommonInterfacePage;
import com.framework.pages.AJS.common.IFCSCommonPage;
import com.framework.pages.AJS.common.IFCSHomePage;
import com.framework.pages.AJS.common.IFCSLoginPage;
import com.github.javafaker.Faker;

public class ValidateInterfaceMonthEndProcessTestCases extends BaseTest {

	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "Smoke","BusinessFlow" })
	public void ValidatePeriodicRebates(@Optional("AU") String clientCountry, @Optional("BP") String clientName) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  BPNZ53_Rebates_NZ_004_Periodic Rebates_Private Profile", "Periodic Rebates");
		IFCSLoginPage ifcsloginPage = new IFCSLoginPage(driver, test);
		CommonInterfacePage commonInterfacePage = new CommonInterfacePage(driver, test);
		Common common = new Common(driver, test);
		IFCSCommonPage ifcsCommonPage = new IFCSCommonPage(driver, test);
		ifcsloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, " ");
		// day End processing

		ArrayList<String> columnValues = new ArrayList<String>();
		String cusNo = "6300056922";// "6300048968";//SG
		// String cusNo ="0002680";
		columnValues.add(cusNo);
		String productCode = "0004";
		columnValues.add(productCode);
		// String cusNo = common.getCustomerNumberWithNoHierarchy();
		// String periodRebateCustomerAmount =
		// commonInterfacePage.getCustomerAmountFromPeriodRebates(cusNo);

		String currentIFCSDate = common.getCurrentIFCSDateFromDB(clientName + clientCountry);

		String currentDate = commonInterfacePage.getTransactionMonthStartingDate("Current", currentIFCSDate);
		System.out.println("Transaction Month Current date " + currentDate);

		String transactionMonthStartingDate = commonInterfacePage.getTransactionMonthStartingDate("Past",
				currentIFCSDate);
		System.out.println("Transaction Month starting date " + transactionMonthStartingDate);

		String customerTotalTransactions = commonInterfacePage.getCustomerTotalTransactionsAmountFromDB(cusNo,
				productCode, transactionMonthStartingDate, currentDate);

		String customerRebateCalculation = commonInterfacePage.getRateValueFromDB(cusNo, "503",
				customerTotalTransactions);
		System.out.println("Customer rebate calculation is " + customerRebateCalculation);
		columnValues.add(customerRebateCalculation);

		String fileName = commonInterfacePage.getRecentProcessedReportFiles(clientName, clientCountry,
				"Period Rebates Report", "");
		String dayEndDatePath = commonInterfacePage.getFolderPathUsingPreviousProcessingDate(clientName, clientCountry,
				"IFCS_DAYEND_OUTPUTFILE_AU");
		System.out.println("dayEndDatePath::" + dayEndDatePath);
		ifcsCommonPage.establishThePuttyConnection("incomingFile", "PUTTY_HOST", "PUTTY_USERNAME", "PUTTY_PASSWORD",
				dayEndDatePath, fileName);
		// File Validations
		/*
		 * ArrayList<String> columnValues = new ArrayList<String>();
		 * columnValues.add("0115753031"); columnValues.add("05");
		 * columnValues.add("-0.28");
		 */
		String[] columnHeaders = { "Customer Number receiving rebate", "Product Code", "Rebate\n($)" };
		commonInterfacePage.validateValuesIsPresentInExcel("1-Period Rebates Report 01.06.2020.xls", "PeriodRebates",
				columnHeaders, columnValues,0);

	}

	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "Smoke","BusinessFlow" })
	public void ValidatePeriodicRebatesPublic(@Optional("AU") String clientCountry, @Optional("BP") String clientName) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  BPNZ53_Rebates_NZ_004_Periodic Rebates_Private Profile", "Periodic Rebates");
		IFCSLoginPage ifcsloginPage = new IFCSLoginPage(driver, test);
		CommonInterfacePage commonInterfacePage = new CommonInterfacePage(driver, test);
		Common common = new Common(driver, test);
		IFCSCommonPage ifcsCommonPage = new IFCSCommonPage(driver, test);
		ifcsloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, " ");
		// day End processing

		ArrayList<String> columnValues = new ArrayList<String>();
		String cusNo = "6300056922";// "6300048968";//SG
		// String cusNo ="0002680";
		columnValues.add(cusNo);
		String productCode = "0004";
		columnValues.add(productCode);
		// String cusNo = common.getCustomerNumberWithNoHierarchy();
		// String periodRebateCustomerAmount =
		// commonInterfacePage.getCustomerAmountFromPeriodRebates(cusNo);

		String currentIFCSDate = common.getCurrentIFCSDateFromDB(clientName + clientCountry);

		String currentDate = commonInterfacePage.getTransactionMonthStartingDate("Current", currentIFCSDate);
		System.out.println("Transaction Month Current date " + currentDate);

		String transactionMonthStartingDate = commonInterfacePage.getTransactionMonthStartingDate("Past",
				currentIFCSDate);
		System.out.println("Transaction Month starting date " + transactionMonthStartingDate);

		String customerTotalTransactions = commonInterfacePage.getCustomerTotalTransactionsAmountFromDB(cusNo,
				productCode, transactionMonthStartingDate, currentDate);

		String customerRebateCalculation = commonInterfacePage.getRateValueFromDB(cusNo, "503",
				customerTotalTransactions);
		System.out.println("Customer rebate calculation is " + customerRebateCalculation);
		columnValues.add(customerRebateCalculation);

		String fileName = commonInterfacePage.getRecentProcessedReportFiles(clientName, clientCountry,
				"Period Rebates Report", "");
		String dayEndDatePath = commonInterfacePage.getFolderPathUsingPreviousProcessingDate(clientName, clientCountry,
				"IFCS_DAYEND_OUTPUTFILE_AU");
		System.out.println("dayEndDatePath::" + dayEndDatePath);
		ifcsCommonPage.establishThePuttyConnection("incomingFile", "PUTTY_HOST", "PUTTY_USERNAME", "PUTTY_PASSWORD",
				dayEndDatePath, fileName);
		// File Validations
		/*
		 * ArrayList<String> columnValues = new ArrayList<String>();
		 * columnValues.add("0115753031"); columnValues.add("05");
		 * columnValues.add("-0.28");
		 */
		String[] columnHeaders = { "Customer Number receiving rebate", "Product Code", "Rebate\n($)" };
		commonInterfacePage.validateValuesIsPresentInExcel("1-Period Rebates Report 01.06.2020.xls", "PeriodRebates",
				columnHeaders, columnValues,0);

	}

	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "Smoke" }, enabled = false)
	public void ValidateMerchantStatementsReport(@Optional("AU") String clientCountry,
			@Optional("BP") String clientName) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  Merch_AU_006_Merchant statements", "Merchant Statements");
		IFCSLoginPage ifcsloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		CommonInterfacePage commonInterfacePage = new CommonInterfacePage(driver, test);
		Common common = new Common(driver, test);
		IFCSCommonPage ifcsCommonPage = new IFCSCommonPage(driver, test);
		TransactionListPage transactionListPage = new TransactionListPage(driver, test);
		
		ifcsloginPage.login("IFCS_URL_BP", "IFCS_BP_USERNAME", "IFCS_BP_PASSWORD");
		ifcsloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, " ");
		Map<String, String> merchantTransactionDetails = new HashMap<String, String>();
		ArrayList<String> listFiles = new ArrayList<String>();
		ArrayList<String> listFilePath = new ArrayList<String>();
		String locationNo = common.getLocationNumberForConfiguredReports(clientName, clientCountry);
		String cardNumber = common.getActiveCardNumberFromDB();
		String currentDate = common.getCurrentIFCSDateFromDB(clientName + clientCountry);
		String ifcsCurrentDate = common.enterADateValueInStatusBeginDateField("Current", currentDate);
		String ifcsDate = common.enterADateValueInStatusBeginDateField("oneDayBefore", currentDate);
		Faker fakerN = new Faker();
		String f_referenceNo = fakerN.number().digits(3);
		String productCode = common.chooseANonFuelProductExtCodeInTheLocation(locationNo, "Y", "externalCode");
		IFCSHomePage.gotoApplicationAndClickApplicationMenu();
		IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);
		IFCSHomePage.gotoTransactionAndClickManageTransaction();
		/*transactionListPage.validateToPostManualTransactionEntry(ifcsCurrentDate, f_referenceNo, clientCountry,
				cardNumber, "", locationNo, productCode, false);*/
		transactionListPage.enterTransactionBatchDetails(false,"160","1",clientName);
		transactionListPage.enterManualTransactionDetails(ifcsCurrentDate,f_referenceNo,cardNumber,"",locationNo,"160","");
		transactionListPage.enterTransactionLineItems(productCode,"160","100","160");
		transactionListPage.validatePostManualTransaction("Validation successful");
		// Control M day end
		// DayEnd job

		// File Validation
		merchantTransactionDetails = common.getCustomerTransactions(f_referenceNo);
		String merchantNo = merchantTransactionDetails.get("MERCHANT_NO").toString();

		String fileName1 = commonInterfacePage.getRecentProcessedReportFiles(clientName, clientCountry,
				"Merchant Statement", merchantNo);
		String fileName2 = commonInterfacePage.getRecentProcessedReportFiles(clientName, clientCountry, "Merchant RCTI",
				merchantNo);

		listFiles.add(fileName1);
		listFiles.add(fileName2);
		String dayEndDatePath = null;
		// System.out.println("filenames::"+listFiles);
		for (int i = 0; i < listFiles.size(); i++) {
			String fileName = listFiles.get(i);
			if (clientCountry.equals("SG")) {
				dayEndDatePath = commonInterfacePage.getFolderPathUsingCurrentSystemDate(clientName, clientCountry,
						"IFCS_DAYEND_OUTPUTFILE_SG_MERCHANT");
			} else if (clientCountry.equals("SP")) {
				dayEndDatePath = commonInterfacePage.getFolderPathUsingCurrentSystemDate(clientName, clientCountry,
						"IFCS_DAYEND_OUTPUTFILE_SP_MERCHANT");
			} else if (clientCountry.equals("GU")) {
				dayEndDatePath = commonInterfacePage.getFolderPathUsingCurrentSystemDate(clientName, clientCountry,
						"IFCS_DAYEND_OUTPUTFILE_GU_MERCHANT");
			} else if (clientCountry.equals("HK")) {
				dayEndDatePath = commonInterfacePage.getFolderPathUsingCurrentSystemDate(clientName, clientCountry,
						"IFCS_DAYEND_OUTPUTFILE_HK_MERCHANT");
			} else if (clientCountry.equals("AU")) {
				dayEndDatePath = commonInterfacePage.getFolderPathUsingCurrentSystemDate(clientName, clientCountry,
						"IFCS_DAYEND_OUTPUTFILE_AU_MERCHANT");
			} else if (clientCountry.equals("NZ")) {
				dayEndDatePath = commonInterfacePage.getFolderPathUsingCurrentSystemDate(clientName, clientCountry,
						"IFCS_DAYEND_OUTPUTFILE_NZ_MERCHANT");
			}
			System.out.println("dayEndDatePath::" + dayEndDatePath);
			ifcsCommonPage.establishThePuttyConnection("incomingFile", "PUTTY_HOST", "PUTTY_USERNAME", "PUTTY_PASSWORD",
					dayEndDatePath, fileName);
			String localFolder = System.getProperty("user.home") + "\\Documents\\" + fileName;

			listFilePath.add(localFolder);
		}

		for (int i = 0; i < listFilePath.size(); i++) {
			if (listFilePath.get(i).contains("Merchant Statement")) {
				ifcsCommonPage.validateMerchantStatementReports(listFilePath.get(i), locationNo, ifcsDate);
			} else if (listFilePath.get(i).contains("Merchant RCTI")) {
				ifcsCommonPage.validateMerchantStatementReports(listFilePath.get(i), locationNo, ifcsDate);
			}
		}
		 //ifcsCommonPage.validateMerchantStatementReports("C:\\Users\\W996058\\Documents\\1-Merchant RCTI 01.05.2021-Account 9000001260-4183317.pdf","00007904",ifcsCurrentDate);
	}

	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "Smoke" })
	public void ValidateCustomerReports(@Optional("AU") String clientCountry, @Optional("BP") String clientName) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  BPNZ40_Cust_NZ_013_Customer reports", "Customer Reports");
		IFCSLoginPage ifcsloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		CommonInterfacePage commonInterfacePage = new CommonInterfacePage(driver, test);
		Common common = new Common(driver, test);
		IFCSCommonPage ifcsCommonPage = new IFCSCommonPage(driver, test);
		TransactionListPage transactionListPage = new TransactionListPage(driver, test);

		ifcsloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, " ");

		ifcsloginPage.login("IFCS_URL_BP", "IFCS_BP_USERNAME", "IFCS_BP_PASSWORD");
		ArrayList<String> listFiles = new ArrayList<String>();
		ArrayList<String> listFilePath = new ArrayList<String>();
		String cusNum = common.getCustomerNumberForConfiguredReports(clientName ,clientCountry);
		String cardNumber = common.getCardNumberWithCustomerNo(cusNum);
		String currentDate = common.getCurrentIFCSDateFromDB(clientName + clientCountry);
		String ifcsCurrentDate = common.enterADateValueInStatusBeginDateField("Current", currentDate);
		String ifcsDate = common.enterADateValueInStatusBeginDateField("oneDayBefore", currentDate);
		Faker fakerN = new Faker();
		String f_referenceNo = fakerN.number().digits(3);
		String locationNo = common.chooseALocationWithNonFuelProduct("Y");
		String productCode = common.chooseANonFuelProductExtCodeInTheLocation(locationNo, "Y", "externalCode");
		IFCSHomePage.gotoApplicationAndClickApplicationMenu();
		IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);
		IFCSHomePage.gotoTransactionAndClickManageTransaction();
		/*transactionListPage.validateToPostManualTransactionEntry(ifcsCurrentDate, f_referenceNo, clientCountry,
				cardNumber, "", locationNo, productCode, false);*/
		
		transactionListPage.enterTransactionBatchDetails(false,"160","1",clientName);
		transactionListPage.enterManualTransactionDetails(ifcsCurrentDate,f_referenceNo,cardNumber,"",locationNo,"160","");
		transactionListPage.enterTransactionLineItems(productCode,"160","100","160");
		transactionListPage.validatePostManualTransaction("Validation successful");

		// Control M day end
		
		// File Validation
		
		String fileName1 = commonInterfacePage.getRecentProcessedReportFiles(clientName, clientCountry,
				"Tax Invoice Detail", cusNum);
		String fileName2 = commonInterfacePage.getRecentProcessedReportFiles(clientName, clientCountry,
				"Card Management Report", cusNum);
		String fileName3 = commonInterfacePage.getRecentProcessedReportFiles(clientName, clientCountry,
				"Card Transaction Report", cusNum);

		listFiles.add(fileName1);
		listFiles.add(fileName2);
		listFiles.add(fileName3);
		String dayEndDatePath = null;
		System.out.println("filenames::" + listFiles);
		for (int i = 0; i < listFiles.size(); i++) {
			String fileName = listFiles.get(i);
			if (clientCountry.equals("SG")) {
				dayEndDatePath = commonInterfacePage.getFolderPathUsingCurrentSystemDate(clientName, clientCountry,
						"IFCS_DAYEND_OUTPUTFILE_SG_MERCHANT");
			} else if (clientCountry.equals("SP")) {
				dayEndDatePath = commonInterfacePage.getFolderPathUsingCurrentSystemDate(clientName, clientCountry,
						"IFCS_DAYEND_OUTPUTFILE_SP_MERCHANT");
			} else if (clientCountry.equals("GU")) {
				dayEndDatePath = commonInterfacePage.getFolderPathUsingCurrentSystemDate(clientName, clientCountry,
						"IFCS_DAYEND_OUTPUTFILE_GU_MERCHANT");
			} else if (clientCountry.equals("HK")) {
				dayEndDatePath = commonInterfacePage.getFolderPathUsingCurrentSystemDate(clientName, clientCountry,
						"IFCS_DAYEND_OUTPUTFILE_HK_MERCHANT");
			} else if (clientCountry.equals("NZ")) {
				dayEndDatePath = commonInterfacePage.getFolderPathUsingCurrentSystemDate(clientName, clientCountry,
						"IFCS_DAYEND_OUTPUTFILE_NZ_CUSTOMER");
			}
			else if (clientCountry.equals("AU")) {
				dayEndDatePath = commonInterfacePage.getFolderPathUsingCurrentSystemDate(clientName, clientCountry,
						"IFCS_DAYEND_OUTPUTFILE_AU_CUSTOMER");
			}
			System.out.println("dayEndDatePath::" + dayEndDatePath);
			ifcsCommonPage.establishThePuttyConnection("incomingFile", "PUTTY_HOST", "PUTTY_USERNAME", "PUTTY_PASSWORD",
					dayEndDatePath, fileName);
			String localFolder = System.getProperty("user.home") + "\\Documents\\" + fileName;

			listFilePath.add(localFolder);
		}

		for (int i = 0; i < listFilePath.size(); i++) {
			if (listFilePath.get(i).contains("Tax Invoice Detail")) {
				ifcsCommonPage.validateCustomerReports(listFilePath.get(i), cusNum,ifcsDate);
			} else if (listFilePath.get(i).contains("Card Management Report")) {
				ifcsCommonPage.validateCustomerReports(listFilePath.get(i), cusNum,ifcsDate);
			} else if (listFilePath.get(i).contains("Card Transaction Report")) {
				ifcsCommonPage.validateCustomerReports(listFilePath.get(i), cusNum,ifcsDate);
			}
		}

		/*ifcsCommonPage.validateCustomerReports(
				"C:\\Users\\W996058\\Documents\\2-Card Management Report 01.02.2020-Account 0100701309-20080121.pdf","0100701309");*/
	}

}
