﻿using Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EnCompass.Testing.Source.PageObjects.Organization.Payables.MerchantPayments
{
	[PageModel(@"/payables/merchantPayments/ViewMerchant.aspx")]
	class ViewMerchant : EnCompassOrgPageModel
	{
		public override string RelativeUrl => @"/payables/merchantPayments/ViewMerchant.aspx";
		public override string PageIdentifierXPath_Override => @"//li[contains(@class, 'breadcrumb-item')][text() = 'Merchant Logs']";
	
		public ViewMerchant(GlobalSettings Settings) : base(Settings) { }
	}
}
