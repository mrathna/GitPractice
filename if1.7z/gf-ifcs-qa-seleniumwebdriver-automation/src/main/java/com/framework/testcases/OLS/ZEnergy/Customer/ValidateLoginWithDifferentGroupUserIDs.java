package com.framework.testcases.OLS.ZEnergy.Customer;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.OLS.common.LoginPage;
import com.framework.pages.Z.ZHomePage;

public class ValidateLoginWithDifferentGroupUserIDs extends BaseTest {

	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "Smoke" })
	public void verifyLoginWithFullAccessGroupUserID(@Optional("Z") String clientCountry,
			@Optional("ZEnergy") String clientName) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  Verify Login With Full Access Group UserID",
				"Verifying Login With Full AccessGroup UserID");

		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		ZHomePage zHomePage = new ZHomePage(driver, test);
		loginPage.Login("ZEnergy_URL", "ZEnergy_UN_Customer_" + clientCountry, "ZEnergy_PWD_Customer_" + clientCountry,
				clientName);
		zHomePage.ValidateHeaderMenus("Full Access Group User");
		zHomePage.validateAccountSubMenus("fullAccess");
		zHomePage.validateCardsSubMenus("fullAccess");
		zHomePage.validateTransactionSubMenus();
		zHomePage.validateReportsSubMenus();
		zHomePage.validateSupportSubMenus();
		loginPage.Logout();
	}

	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "Smoke" })
	public void verifyLoginWithCardAndAccountAccessGroupUserID(@Optional("Z") String clientCountry,
			@Optional("ZEnergy") String clientName) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  Verify Login With  Card and Account access group User ID",
				"Verifying Login With  Card and Account access group User ID");

		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		ZHomePage zHomePage = new ZHomePage(driver, test);
		loginPage.Login("ZEnergy_URL", "ZEnergy_UN_CardAccountAccess_" + clientCountry, "ZEnergy_PWD_CardAccountAccess_" + clientCountry,
				clientName);
		zHomePage.ValidateHeaderMenus("Card Account Access Group User");
		zHomePage.validateAccountSubMenus("cardAccess");
		zHomePage.validateCardsSubMenus("cardAccess");
		zHomePage.validateSupportSubMenus();
		loginPage.Logout();
	}

	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "Smoke" })
	public void verifyLoginWithReportingOnlyAccessGroupUserID(@Optional("Z") String clientCountry,
			@Optional("ZEnergy") String clientName) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  Verify Login with Reporting Only access group User ID",
				"Verifying Login with Reporting Only access group User ID");

		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		ZHomePage zHomePage = new ZHomePage(driver, test);
		loginPage.Login("ZEnergy_URL", "ZEnergy_UN_ReportAccess_" + clientCountry, "ZEnergy_PWD_ReportAccess_" + clientCountry,
				clientName);
		zHomePage.ValidateHeaderMenus("Card Account Access Group User");
		zHomePage.validateAccountSubMenus("reportAccess");
		zHomePage.validateCardsSubMenus("reportAccess");
		zHomePage.validateReportsSubMenus();
		zHomePage.validateSupportSubMenus();
		loginPage.Logout();
	}
	
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "Smoke" })
	public void verifyTermsAndConditionsDisplays(@Optional("Z") String clientCountry,
			@Optional("ZEnergy") String clientName) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  Verify terms and conditions displays, clicking disagree button",
				"Verifying terms and conditions displays and clicking disagree button");

		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);


		loginPage.validateLoginPageFooterLinks(clientName, "ZEnergy_URL");
		// Login And Disagree
		loginPage.loginAndDisagree("ZEnergy_UN_New_Customer_" + clientCountry,
				"ZEnergy_PWD_New_Customer_" + clientCountry);			
	}
	
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "Smoke" })
	public void verifyTermsAndConditionsDisplaysAndClickingAgreeButton(@Optional("Z") String clientCountry,
			@Optional("ZEnergy") String clientName) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  Verifing that clicking by clicking agree button",
				"Verifing that clicking by clicking agree button");

		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);

		loginPage.validateLoginPageFooterLinks(clientName, "ZEnergy_URL");
		// Login And Agree
		loginPage.loginAndAgree("ZEnergy_UN_New_Customer_" + clientCountry,
				"ZEnergy_PWD_New_Customer_" + clientCountry);
//		loginPage.Logout();
	}
	

		
	
		
		
}
