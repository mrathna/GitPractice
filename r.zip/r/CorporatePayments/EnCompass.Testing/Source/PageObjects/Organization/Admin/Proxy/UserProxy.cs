﻿using Common.Utility;
using EnCompass.Testing.Source.PageObjects.Controls;
using NFluent;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;

namespace EnCompass.Testing.Source.PageObjects.Organization.Admin.Proxy
{
    public partial class UserProxy
    {
        #region XPATH

        private const string _searchTermListXPath = @"//div[contains(@id, 'SearchOutput')]/select[1]";
        private const string _usersProxyingMeRadiobuttonXPath = @"//input[contains(@id, 'UserSearchOptions_1')]";
        private const string _usersProxyingMeRadiobuttonLabelXPath = @"//label[contains(@for, 'UserSearchOptions_1')]";
        private const string _usersIProxyRadiobuttonXPath = @"//input[contains(@id, 'UserSearchOptions_2')]";
        private const string _usersIProxyRadiobuttonLabelXPath = @"//label[contains(@for, 'UserSearchOptions_2')]";
        private const string _btnSearchXPath = @"//input[contains(@id, 'btnSearch')]";
        private const string _noCardsBeingProxiedFoundXPath = @"//td[@class='gridNoRecordsMessage']";
        private const string _lnkBackToUserXPath = @"//a[contains(@id,'lnkBackToUser')]";
        private const string _addNewXPath = @"//div[contains(@class,'actionItemTextDiv')]";
        private const string _lnkCardProxiesXPath = @"//a[contains(@id,'lnkCardProxies')]";
        private string noRecords_Xpath = "//td[@class='gridNoRecordsMessage']";

        #endregion

        #region IWebElements Props

        public IWebElement _searchTermList
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_searchTermListXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_searchTermList element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _usersProxyingMeRadiobutton
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_usersProxyingMeRadiobuttonXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_usersProxyingMeRadiobutton element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _usersProxyingMeRadiobuttonLabel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_usersProxyingMeRadiobuttonLabelXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_usersProxyingMeRadiobuttonLabel element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _usersIProxyRadiobutton
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_usersIProxyRadiobuttonXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_usersIProxyRadiobutton element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _usersIProxyRadiobuttonLabel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_usersIProxyRadiobuttonLabelXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_usersIProxyRadiobuttonLabel element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _btnSearch
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_btnSearchXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_btnSearch element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _noCardsBeingProxiedFound
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_noCardsBeingProxiedFoundXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_noCardsBeingProxiedFound element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _lnkBackToUser
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_lnkBackToUserXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_lnkBackToUser element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _addNew
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_addNewXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_addNew element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _lnkCardProxies
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_lnkCardProxiesXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_lnkCardProxies element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        #endregion
        
        

        private GridControl _selectUserProxies;
        public GridControl SelectGridUserProxies
        {
            get
            {
                return _selectUserProxies ?? (_selectUserProxies = new GridControl("dgUserProxies", Driver));
            }
        }

		public void AddNew()
		{
			_addNew.JSClickWithFocus(Driver);
		}

        public bool VerifyNoRecordMessage
        {
            get
            {
                Driver.TryWaitForElementToBeVisible(By.XPath(noRecords_Xpath), out IWebElement _noCardsBeingProxiedFound);
                return Driver.IsElementPresent(By.XPath(_noCardsBeingProxiedFoundXPath));
            }
        }

        public string SearchTermValues
        {
            get
            {
                return _searchTermList.Text;
            }
        }

        public void PressSearchButton()
        {
            _btnSearch.JSClickWithFocus(Driver);
			Settings.EnCompassExtentTest.Info("Clicked on Search Button");
        }

        public void SelectUsersProxyingMe()
        {
			_usersProxyingMeRadiobutton.SetRadioButtonStateWithLabel(_usersProxyingMeRadiobuttonLabel, true);
			Settings.EnCompassExtentTest.Info("Selected Radio Button for Users Proxying me");
        }

        public void SelectUsersIProxy()
        {
			_usersIProxyRadiobutton.SetRadioButtonStateWithLabel(_usersIProxyRadiobuttonLabel, true);
        }

        public string GetBackToUserText()
        {
            return Settings.EnCompassWebDriver.WaitForVisible(By.XPath("//a[contains(@id,'lnkBackToUser')]")).GetAttribute("innerText");
        }

        public void ClickBackToUser()
        {
            Settings.EnCompassWebDriver.WaitForVisible(By.XPath("//a[contains(@id,'lnkBackToUser')]"));
            _lnkBackToUser.JSClickWithFocus(Driver);
        }

        public void ClickCardProxies()
        {
            Settings.EnCompassWebDriver.WaitForVisible(By.XPath("//a[contains(@id,'lnkCardProxies')]"));
            _lnkCardProxies.JSClickWithFocus(Driver);
        }

        public void VerifyLinksNamePresentFromEditAccount(string UserFirstLastName)
        {
            Settings.EnCompassWebDriver.WaitForVisible(By.XPath("//a[contains(@id,'lnkBackToUser')][contains(text(),'Back to " + UserFirstLastName + "')]"));
            Settings.EnCompassWebDriver.WaitForVisible(By.XPath("//a[contains(@id,'lnkCardProxies')][contains(text(),'" + UserFirstLastName + "')][contains(text(),'Card Proxies')]"));
        }

        public void VerifyRadioButtonsPresentFromEditAccount(string UserFirstLastName)
        {
            Settings.EnCompassWebDriver.WaitForVisible(By.XPath("//label[text()='All users']"));
            Settings.EnCompassWebDriver.WaitForVisible(By.XPath("//label[text()='" + UserFirstLastName + " is a proxy for these users']"));
            Settings.EnCompassWebDriver.WaitForVisible(By.XPath("//label[text()='Users that serve as a proxy for " + UserFirstLastName + "']"));
        }

        public void VerifySearchandAddNewButton()
        {
            Settings.EnCompassWebDriver.WaitForVisible(By.XPath("//a[contains(@class,'btn-primary') and text()=' Create']"));
            Settings.EnCompassWebDriver.WaitForVisible(By.XPath("//input[contains(@id,'btnSearch')]"));
        }

    }
}
