package com.framework.pages.Z;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.ExtentTest;
import com.framework.basepage.BasePage;
import com.framework.repo.Locator;

public class ZAccountsPage extends BasePage {
	
	@FindBy(how=How.ID ,using = Locator.SEARCH_CARDS)
	public WebElement searchCostCentre;
	
	@FindBy(how=How.ID,using = Locator.ACCOUNT_AT_FIND_COST_CENTRE)
	public WebElement selectCostCentreAccountNumber;
	
	@FindBy(how=How.ID,using = Locator.COST_CENTRE_RECORDS)
	public WebElement costCentreTable;
	
	@FindBy(how=How.ID,using = Locator.SEARCH_BTN)
	public WebElement searchVehicles;
	
	@FindBy(how=How.ID,using = Locator.ACCOUNT_NUMBER_DROPDOWN)
	public WebElement selectVehicleAccountNumber;
	
	@FindBy(how=How.ID,using = Locator.VEHICLES_TABLE)
	public WebElement vehiclesTable;
	
	@FindBy(how=How.ID,using = Locator.CONTACT_LIST_TABLE)
	public List<WebElement> contactListTable;
	
	
	private String costCentreCode = "";
	
	private String accountNo = "";
	
	private String cardNo = "";
	
	private String vehicleStatus = "";
	
	public ZAccountsPage(WebDriver driver, ExtentTest test) {
		super(driver, test);
		PageFactory.initElements(driver, this);
	}
	
	/**
	 * Go to - Accounts - Cost Centre 
	 */
	public void goToAccountsCostCentres() { 
		mouseHoverClickMenuAndSubMenu("Accounts", "Cost Centres");
	}
	
	/**
	 * Go to - Accounts - Vehicles
	 */
	public void goToAccountsVehicles() { 
		mouseHoverClickMenuAndSubMenu("Accounts", "Vehicles");
	}
	
	/**
	 * Cost Centre - Select All Accounts Option
	 */
	public void selectCostCentreAllAccountOption() {
		selectDropDownByVisibleText(selectCostCentreAccountNumber, "All Accounts");
		sleep(3);
	}
	
	/**
	 * Vehciles - Select All Account Option
	 */
	public void selectVehcileAllAccountOption() {
		selectDropDownByVisibleText(selectVehicleAccountNumber, "All Accounts");
		sleep(3);
	}
	
	/**
	 * Click on Search - Cost Centre
	 */
	public void clickCostCentreSearchButton() {
		isDisplayedThenActionClick(searchCostCentre, "Click Search Button");
		sleep(5);
	}
	
	/**
	 * Click on Search - Vehicle
	 */
	public void clickVehicleSearchButton() {
		isDisplayedThenActionClick(searchVehicles, "Click Search Button");
		sleep(5);
	}
	
	/**
	 * Cost Centre - Validating Search Result Exists 
	 */
	public void validateCostCentreExist() {
		setCellDataFromTable(costCentreTable, 4, false);
		costCentreCode = getCellDataFromTable(1, 0, false);
		System.out.println(costCentreCode);
		accountNo = getCellDataFromTable(1, 3, false);
		System.out.println(accountNo);
		if(!costCentreCode.isEmpty() || !accountNo.isEmpty()) {
			logPass("Cost Centre - Search Result Exists");
		} else {
			logFail("Cost Centre - Search Result Not found");
		}
		
	}
	
	/**
	 * Vehicle - Validating Search Result Exists
	 */
	public void validateVehicleExist() {
		setCellDataFromTable(vehiclesTable, 6, false);
		cardNo = getCellDataFromTable(1, 3, false);
		System.out.println(cardNo);
		vehicleStatus = getCellDataFromTable(1, 5, false);
		System.out.println(vehicleStatus);
		if(!cardNo.isEmpty() || !vehicleStatus.isEmpty()) {
			logPass("Vehicles - Search Result Exists");
		} else {
			logFail("Vehicles - Search Result Not found");
		}
		
	}
	
	public void goToContactsDetailScreen() {
		mouseHoverClickMenuAndSubMenu("Accounts", "Contacts");
		checkTextInPageAndValidate("Contacts", 30);
		if(contactListTable.size()>0) {
		isDisplayedThenActionClick(contactListTable.get(0),"Contact List");
		sleep(5);
		
		}
		else {
		logInfo("Contact Details are not Found");
		}

		}
	
	
	
	
}
