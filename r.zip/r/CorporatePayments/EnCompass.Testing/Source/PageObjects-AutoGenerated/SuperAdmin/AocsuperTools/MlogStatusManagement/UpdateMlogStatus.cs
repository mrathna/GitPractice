using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using Common;
using Common.PageObjects;
using Common.ScenarioConfigurations;
using Common.Utility;

namespace EnCompass.Testing.Source.PageObjects.SuperAdmin.AocsuperTools.MlogStatusManagement 
{
	/// <summary>
	/// Auto-generated Page Model Class
	/// Navigation Paths: 
		/// [Organization Home]->Super Admin Tools->Product Support Tools->Merchant Log Status
		/// </summary>
	[PageModel(@"/superAdmin/AOCSuperTools/MLogStatusManagement/UpdateMLogStatus.aspx")]
	public partial class UpdateMlogStatus : EnCompassSuperPageModel 
	{
		public override string RelativeUrl => @"/superAdmin/AOCSuperTools/MLogStatusManagement/UpdateMLogStatus.aspx";
		public override string PageIdentifierXPath_Generated => @"//li[contains(@class, 'breadcrumb-item active')][text() = 'Merchant Log Status']";

		#region Navigation
				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Workflow Analysis']")]
		private IWebElement _superAdminTools_ProductSupportTools_MerchantLogStatus_WorkflowAnalysis { get; set; }
		public void NavigateTo_SuperAdminTools_ProductSupportTools_MerchantLogStatus_WorkflowAnalysis()
		{
			NavigateToMenuItem(_superAdminTools_ProductSupportTools_MerchantLogStatus_WorkflowAnalysis);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Hierarchy Analysis']")]
		private IWebElement _superAdminTools_ProductSupportTools_MerchantLogStatus_HierarchyAnalysis { get; set; }
		public void NavigateTo_SuperAdminTools_ProductSupportTools_MerchantLogStatus_HierarchyAnalysis()
		{
			NavigateToMenuItem(_superAdminTools_ProductSupportTools_MerchantLogStatus_HierarchyAnalysis);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Merchant Log Status']")]
		private IWebElement _superAdminTools_ProductSupportTools_MerchantLogStatus_MerchantLogStatus { get; set; }
		public void NavigateTo_SuperAdminTools_ProductSupportTools_MerchantLogStatus_MerchantLogStatus()
		{
			NavigateToMenuItem(_superAdminTools_ProductSupportTools_MerchantLogStatus_MerchantLogStatus);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Exact Match Management']")]
		private IWebElement _superAdminTools_ProductSupportTools_MerchantLogStatus_ExactMatchManagement { get; set; }
		public void NavigateTo_SuperAdminTools_ProductSupportTools_MerchantLogStatus_ExactMatchManagement()
		{
			NavigateToMenuItem(_superAdminTools_ProductSupportTools_MerchantLogStatus_ExactMatchManagement);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Custom Fax Management']")]
		private IWebElement _superAdminTools_ProductSupportTools_MerchantLogStatus_CustomFaxManagement { get; set; }
		public void NavigateTo_SuperAdminTools_ProductSupportTools_MerchantLogStatus_CustomFaxManagement()
		{
			NavigateToMenuItem(_superAdminTools_ProductSupportTools_MerchantLogStatus_CustomFaxManagement);
		}

		
		private void NavigateToMenuItem(IWebElement element)
		{
			Driver.Url = element.GetAttribute("href");
		}
		#endregion

		public UpdateMlogStatus(GlobalSettings settings) : base(settings) { }
	}  
}
