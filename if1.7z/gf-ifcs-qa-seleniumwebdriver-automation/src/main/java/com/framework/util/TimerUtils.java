package com.framework.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.Assert;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;

public class TimerUtils {

	static long startTime;
	static long endTime;

	static Workbook workbook = null;
	static Sheet sheet = null;

	static int columnIndex = 0;
	// public static ExtentTest test;
	static String clientNameForFile = "";
	public static final String filePath = Constants.SCREEN_NAVIGATION_DIR;

	// public static final String fileName = "Test.xlsx";

	public static String fileName = "";
	public static final String sheetName = "Sheet1";

	static HashMap<String, Long> scenarios = new HashMap<String, Long>();

	public static void writeExcel(String key, Long value) throws IOException {

		int rowNo = TimerUtils.findRowNumberBasedOnKey(sheet, key);
		System.out.println("Row No::" + rowNo);
		Row newRow = sheet.getRow(rowNo);

		Cell cell = newRow.createCell(columnIndex);
		cell.setCellValue(value);
	}

	public static int findRowNumberBasedOnKey(Sheet sheet, String cellContent) {
		for (Row row : sheet) {
			for (Cell cell : row) {
				if (cell.getCellType() == Cell.CELL_TYPE_STRING) {
					if (cell.getRichStringCellValue().getString().trim().contains(cellContent)) {
						return row.getRowNum();
					}
				}
			}
		}
		return 0;
	}

	public static String findRowDescBasedOnKey(Sheet sheet, String cellContent) {
		for (Row row : sheet) {
			for (Cell cell : row) {

				if (cell.getCellType() == Cell.CELL_TYPE_STRING) {
					if (cell.getRichStringCellValue().getString().trim().contains(cellContent + " ")) {
						return cell.getRichStringCellValue().toString();
					}
				}
			}
		}
		return "";
	}

	public static int findColumn(Row row) {

		int columnNo = 0;

		Iterator<Cell> cells = row.cellIterator();
		Cell cellForCol;

		while (cells.hasNext()) {
			cellForCol = cells.next();

			if (cellForCol.getCellType() == 3) {
				columnNo = cellForCol.getColumnIndex();
				break;
			}
		}

		return columnNo;
	}

	public static String getTodayDate() {
		String datePattern = "%tm/%td/%tY";
		Date today = new Date();
		return String.format(datePattern, today, today, today);
	}

	/**
	 * Start Timer get system current time in millis
	 * 
	 * @param scenarioKey
	 */
	public static void startTimer(String scenarioKey, String clientName) {

		startTime = System.currentTimeMillis();
		clientNameForFile = clientName;

	}

	/**
	 * Stop Timer get the End time in current millis and caluculate time taken
	 * 
	 * @param scenarioKey
	 * @param test
	 */
	public static void stopTimer(String scenarioKey, ExtentTest test) {
		endTime = System.currentTimeMillis();
		calculateTimeDifferenceInSeconds(scenarioKey, test);
	}

	public static ExtentTest test1;

	public static void logInfo(String msg) {
		test1.info(MarkupHelper.createLabel(msg, ExtentColor.BLUE));
	}

	public static void logFail(String msg) {
		test1.fail(MarkupHelper.createLabel(msg, ExtentColor.RED));
		Assert.assertFalse(true, msg);
	}

	public static void calculateTimeDifferenceInSeconds(String key, ExtentTest test) {
		test1 = test;
		long timeDifference = endTime - startTime;
		scenarios.put(key, timeDifference / 1000);
	}

	/**
	 * Wite TImer data in Excel sheet
	 * 
	 * @throws IOException
	 */

	static String description = "";
	static int rowNo;

	public static void writeTimerData() {
		try {
			if (clientNameForFile.contains("Z Energy Limited")) {
				fileName = Constants.Z_ENERGY_SCREEN_NAVIGATION_REPORT_NAME;
			}
			File file = new File(filePath + "\\" + fileName);
			FileInputStream inputStream = new FileInputStream(file);

			String fileExtensionName = fileName.substring(fileName.indexOf("."));

			if (fileExtensionName.equals(".xls")) {
				workbook = new HSSFWorkbook(inputStream);

			} else if (fileExtensionName.equals(".xlsx")) {
				workbook = new XSSFWorkbook(inputStream);
			}

			sheet = workbook.getSheet(sheetName);

			columnIndex = TimerUtils.findColumn(sheet.getRow(0));
			// columnIndex = sheet.getRow(0).getLastCellNum();

			Cell heading = sheet.getRow(0).createCell(columnIndex);
			heading.setCellValue(System.getProperty("pomEnvironment").toUpperCase() + " " + TimerUtils.getTodayDate());

			System.out.println("Hash Data:" + scenarios);

			for (Map.Entry<String, Long> scenario : scenarios.entrySet()) {
				System.out.println("Key:: " + scenario.getKey());
				description = findRowDescBasedOnKey(sheet, scenario.getKey());
				System.out.println("Description:: " + description);
				TimerUtils.logInfo(description + " " + scenario.getValue());
				writeExcel(scenario.getKey(), scenario.getValue());
			}

			inputStream.close();

			FileOutputStream outputStream = new FileOutputStream(file);
			workbook.write(outputStream);
			outputStream.close();

		} catch (IOException exception) {
			logFail(exception.getMessage());
		}
	}
}
