using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using Common;
using Common.PageObjects;
using Common.ScenarioConfigurations;
using Common.Utility;

namespace EnCompass.Testing.Source.PageObjects.Organization.ReportStudio.MyAndStandard 
{
	/// <summary>
	/// Auto-generated Page Model Class
	/// Navigation Paths: 
		/// [Organization Home]->Reports->Organization Scheduled Reports
		/// </summary>
	[PageModel(@"/reportStudio/myAndStandard/ManageOrgScheduledReports.aspx")]
	public partial class ManageOrgScheduledReports : EnCompassOrgPageModel 
	{
		public override string RelativeUrl => @"/reportStudio/myAndStandard/ManageOrgScheduledReports.aspx";
		public override string PageIdentifierXPath_Generated => @"//li[contains(@class, 'breadcrumb-item active')][text() = 'Organization Scheduled Reports']";

		#region Navigation
		
		private void NavigateToMenuItem(IWebElement element)
		{
			Driver.Url = element.GetAttribute("href");
		}
		#endregion

		public ManageOrgScheduledReports(GlobalSettings settings) : base(settings) { }
	}  
}
