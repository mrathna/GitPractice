package com.framework.SundryAdjustmentPayment;

import java.io.File;
import java.io.FileInputStream;

import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelReader {
	
	public XSSFWorkbook xlfile;
	public XSSFSheet sh;
	public XSSFRow initialrow;
	public XSSFCell col;
	public int totalrows;
	public int totalcols;
	
	public ExcelReader(String xlfilepath,String xlsheetname) {
		try {		
		xlfile = new XSSFWorkbook(new FileInputStream(new File(xlfilepath)));
		}catch(Exception e) { e.printStackTrace(); }
		try {
		sh = xlfile.getSheet(xlsheetname);
		totalrows = sh.getLastRowNum();
		System.out.println("Total row:::"+totalrows);
		totalcols = sh.getRow(0).getLastCellNum();
		System.out.println("Total totalcols:::"+totalcols);
	}
		catch(NullPointerException e) {
			e.getMessage();
		}
	}
	
	public static String[][] getExcelData(ExcelReader xl) {
		String[][] excelArray = new String[xl.totalrows][xl.totalcols];
		int init = 0;

		for(int row = 1; row<=xl.totalrows; row++) {
			
			for(int col = 0; col<xl.totalcols; col++) {
				try {
//					if (xl.sh.getRow(row).getCell(col).getStringCellValue() != null &&  xl.sh.getRow(row).getCell(col).getStringCellValue() != "") {
					DataFormatter formatter = new DataFormatter();
					excelArray[init][col] = formatter.formatCellValue(xl.sh.getRow(row).getCell(col));
					
//					}
				}
				catch(NullPointerException e) {

					e.getMessage();
				}
			}
//			baseClass.logInfo("Completed Row Count::"+row);
//			System.out.println("Completed Row Count::::"+row);
			init++;
			
		}

		return excelArray;
	}

	
}
