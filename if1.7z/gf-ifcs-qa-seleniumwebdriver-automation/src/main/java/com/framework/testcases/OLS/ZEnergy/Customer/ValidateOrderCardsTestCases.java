package com.framework.testcases.OLS.ZEnergy.Customer;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.common.Common;
import com.framework.pages.OLS.common.LoginPage;
import com.framework.pages.Z.ZCardsPage;

public class ValidateOrderCardsTestCases extends BaseTest {

	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "Smoke" })
	public void verifyOrderCardPageDisplaysWithAllexpectedFeilds(@Optional("Z") String clientCountry,
			@Optional("ZEnergy") String clientName) {

		test = extent.createTest(
				"Verify Order Card Page displays with all expected feilds, Verfing Fleet Id, mandatory Fields Validation and Confirm Page ",
				"Verfing   Order Card Page displays with all expected feilds, mandatory Fields");

		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		ZCardsPage zCardPage = new ZCardsPage(driver, test);

		loginPage.Login("ZEnergy_URL", "ZEnergy_UN_Customer_" + clientCountry, "ZEnergy_PWD_Customer_" + clientCountry,
				clientName);
		zCardPage.goToCardMenuOrderCard();
		// All Expected Fields and Verifying Fleet Id
		zCardPage.verifyAllExpectedFeilds();
		// Mandatory field
		zCardPage.mandatoryFieldsValidation();
		loginPage.Logout();
	}

	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "Smoke" })
	public void verifyAllPurchaseAndVelocityLimitsFeildsAndOrderZBusinessCard(@Optional("Z") String clientCountry,
			@Optional("ZEnergy") String clientName) {

		test = extent.createTest(
				"Verfing that all Purchase and Velocity limits display as expected feilds, Order z card after clicking Confirm button and a success message will diaplay ",
				"Verify all Purchase and Velocity limits display as expected feilds");

		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		ZCardsPage zCardPage = new ZCardsPage(driver, test);

		loginPage.Login("ZEnergy_URL", "ZEnergy_UN_Customer_" + clientCountry, "ZEnergy_PWD_Customer_" + clientCountry,
				clientName);
		zCardPage.goToCardMenuOrderCard();
		zCardPage.validateProtectedFieldsAndOderZBusinessCard();
		zCardPage.clickOrderCardButtonAndValidateSuccessMsg();
		loginPage.Logout();
	}

	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "Smoke" })
	public void verifyAllPurchaseAndVelocityLimitsFeildsAndOrderGACard(@Optional("Z") String clientCountry,
			@Optional("ZEnergy") String clientName) {

		test = extent.createTest(
				"Verfing that all Purchase and Velocity limits display as expected feilds, Order GA card after clicking Confirm button and a success message will diaplay ",
				"Verify all Purchase and Velocity limits display as expected feilds");

		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		ZCardsPage zCardPage = new ZCardsPage(driver, test);

		loginPage.Login("ZEnergy_URL", "ZEnergy_UN_Customer_GA_" + clientCountry,
				"ZEnergy_PWD_Customer_GA_" + clientCountry, clientName);
		zCardPage.goToCardMenuOrderCard();
		zCardPage.validateProtectedFieldsAndOderZBusinessCard();
		//zCardPage.clickOrderCardButtonAndValidateSuccessMsg();
		loginPage.Logout();
	}

	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "Smoke" })
	public void verifyChangeStatusFromActiveToDifferentStatus(@Optional("Z") String clientCountry,
			@Optional("ZEnergy") String clientName) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  Verify Change status from Active todifferent status",
				"Verify Change status from Active todifferent status");

		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		ZCardsPage zCardPage = new ZCardsPage(driver, test);
		Common common = new Common(driver, test);

		loginPage.Login("ZEnergy_URL", "ZEnergy_UN_Customer_" + clientCountry, "ZEnergy_PWD_Customer_" + clientCountry,
				clientName);
		zCardPage.clickCardsFindCards();

		// select all accounts and Active cards
		zCardPage.selectAllAccountsAndCardStatus("Active");

		boolean isNoCardsPresent = zCardPage.waitForTextToAppear("No Cards found.", 30);

		if (!isNoCardsPresent) {
			// Select the Change status page
			// zCardPage.clickActiveCardAndSelectChangeStatus();
			zCardPage.checkCardStatusActiveToCardOnHoldCustomerRequest();

		}
		else
		{
			common.logForNoDataFound(this.getClass().getSimpleName(), "No Card recoed found");
		}
		
		loginPage.Logout();
	}

	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "Smoke" })
	public void verifyChangeStatusFromPinPendingToDifferentStatus(@Optional("Z") String clientCountry,
			@Optional("ZEnergy") String clientName) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  Verify Change status from Pin pending to different status",
				"Verify Change status from Pin pending to different status");

		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		ZCardsPage zCardPage = new ZCardsPage(driver, test);
		Common common = new Common(driver, test);
		loginPage.Login("ZEnergy_URL", "ZEnergy_UN_Customer_" + clientCountry, "ZEnergy_PWD_Customer_" + clientCountry,
				clientName);
		zCardPage.clickCardsFindCards();

		// select all accounts and Pin Pending cards
		zCardPage.selectAllAccountsAndCardStatus("PIN pending");

		boolean isNoCardsPresent = zCardPage.waitForTextToAppear("No Cards found.", 30);

		if (!isNoCardsPresent) {
			// change Card Status Pin Pending To Different Statu
			zCardPage.changeCardStatusPinPendingToDifferentStatus();

		}
		else
		{
			common.logForNoDataFound(this.getClass().getSimpleName(), "No Card recoed found");
		}
		loginPage.Logout();
	}

	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "Smoke" })
	public void verifyChangeStatusFromCardRequestedToCardCancelled(@Optional("Z") String clientCountry,
			@Optional("ZEnergy") String clientName) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  Verify Change status from  Card requested to Card cancelled",
				"Verify Change status from  Card requested to Card cancelled");

		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		ZCardsPage zCardPage = new ZCardsPage(driver, test);
		Common common = new Common(driver, test);
		loginPage.Login("ZEnergy_URL", "ZEnergy_UN_Customer_" + clientCountry, "ZEnergy_PWD_Customer_" + clientCountry,
				clientName);
		zCardPage.clickCardsFindCards();

		// select all accounts and Card Requested cards
		zCardPage.selectAllAccountsAndCardStatus("Card requested");

		boolean isNoCardsPresent = zCardPage.waitForTextToAppear("No Cards found.", 30);

		if (!isNoCardsPresent) {
			// change Card Status Card Requested To Card Cancelled
			zCardPage.changeCardStatusCardRequestedToCardCancelled();

		}
		else
		{
			common.logForNoDataFound(this.getClass().getSimpleName(), "No Card recoed found");
		}
		loginPage.Logout();
	}

	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "Smoke" })
	public void verifyChangeStatusfromCardOnHoldCustomerRequestToDifferentStatus(@Optional("Z") String clientCountry,
			@Optional("ZEnergy") String clientName) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  Verify Change status from Card on hold -customer request to different status",
				"Verifing Change status from Card on hold -customer request to different status");

		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		ZCardsPage zCardPage = new ZCardsPage(driver, test);
		Common common = new Common(driver, test);
		loginPage.Login("ZEnergy_URL", "ZEnergy_UN_Customer_" + clientCountry, "ZEnergy_PWD_Customer_" + clientCountry,
				clientName);
		zCardPage.clickCardsFindCards();

		// select all accounts and Card on hold - Customer request cards
		zCardPage.selectAllAccountsAndCardStatus("Card on hold - customer request");

		boolean isNoCardsPresent = zCardPage.waitForTextToAppear("No Cards found.", 30);

		if (!isNoCardsPresent) {
			//Change Card Status Card OnHold Customer Request To Active

			zCardPage.changeCardStatusCardOnHoldCustomerRequestToActive();

		}
		else
		{
			common.logForNoDataFound(this.getClass().getSimpleName(), "No Card recoed found");
		}
		loginPage.Logout();
	}
	
}
