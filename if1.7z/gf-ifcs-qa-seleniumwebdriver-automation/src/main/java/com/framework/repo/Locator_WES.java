package com.framework.repo;

public class Locator_WES {

	// Added by Ayub

	public static final String CRUISE_USERNAME = "//input[@id='userName']"; // id
	public static final String CRUISE_PASSWORD = "//input[@id='password']";
	public static final String CRUISE_SIGNIN = "//input[@name='login']"; // Xpath
	public static final String CRUISE_LOGO = "logo";
	public static final String CRUISE_FULE_CARD_APPLICATION = "//b[contains(text(),'Fuel Card Application')]";
	public static final String CRUISE_MONTHLY_DIESEL = "//input[@id='monthlyDiesel']";
	public static final String CRUISE_MONTHLY_PETROL = "//input[@id='monthlyPetrol']";
	public static final String CRUISE_NUMBER_OF_VEHICLES = " //input[@id='numberOfVehicles']";
	public static final String CRUISE_WES_CHECK_BOX = "//td[@class='reqBg currentMethodTD']//label[contains(.,'WES')]//input[@type='checkbox']";
	public static final String CRUISE_OBU_NO_RADIO_BUTTON = "//div[@id='valueAddedServiceQuestions']//label[contains(.,'OBU Device Required?')]/following::tr[1]//td[@class='reqBg'][contains(.,'No')]/input[@type='radio']";
	public static final String CRUISE_VAT_NO_RADIO_BUTTON = "//div[@id='valueAddedServiceQuestions']//label[contains(.,'VAT Reclaim?')]/following::tr[1]//td[@class='reqBg'][contains(.,'No')]/input[@type='radio']";
	public static final String CRUISE_ESSO_CHECK_BOX = "//div[@id='fuelRegion2PaymentType']//td[@class='reqBg'][contains(.,'ESSO')][not(contains(.,'Express'))]//input[@type='checkbox']";
	public static final String PROSPECT_TYPE_DROPDOWN = "//select[@id='legalEntityType']";
	public static final String PROSPECT_NAME = "//input[@id='prospectName']";
	public static final String BUSINESS_TYPE_DROPDOWN = "//select[@id='businessType']";
	public static final String BUSINESS_TYPE_NEWDROPDOWN ="//div[@id='businessType_chzn']//ul[@class='chzn-results']/li";
	public static final String TRADING_YEAR = "//input[@id='noOfYearsTrading']";
	public static final String COMPANY_REGO = "//input[@id='companyRegNo']";
	public static final String VEHICLES_TYPE_CARS = "//div[@class='tickArea']//td[@class='reqBg'][contains(.,'Cars')]//input[@type='checkbox']";
	public static final String CONTACT_TITILE = "//select[@id='title']";
	public static final String CONTACT_FIRST_NAME = "//input[@id='firstname']";
	public static final String CONTACT_SUR_NAME = "//input[@id='surname']";
	public static final String CONTACT_NUM = "//input[@id='phone']";
	public static final String CONTACT_FAX = "//input[@id='fax']";
	public static final String CONTACT_MOBILE = "//input[@id='mobile']";
	public static final String CONTACT_EMAIL = "//input[@id='email']";
	public static final String PROSPECT_ADDRESS1 = "//input[@id='address1']";
	public static final String PROSPECT_ADDRESS2 = "//input[@id='address2']";
	public static final String PROSPECT_ADDRESS3 = "//input[@id='address3']";
	public static final String PROSPECT_TOWN = "//input[@id='town']";
	public static final String PROSPECT_POST_CODE = "//input[@id='postcode']";
	public static final String PROSPECT_COUNTRY = "//select[@id='prospectCountry']";
	public static final String BESPOKE_CUSTOMER_COMMENT = "//textarea[@name='pricingCommentMapElement(BESPOKE_CUSTOMER_COMMENT)']";
	public static final String INVOICE_FORMATE = "//select[@id='invoiceFormat']";
	public static final String FULE_CARD_EMBOSS_NAME = "//input[@id='embossName']";
	public static final String FULE_CARD_NOCARDS = "//input[@id='noCards']";
	public static final String OUTSIDE_CARDLIST = "//div[@id='cardList']";
	public static final String VRN_DRIVER_EMBOSS_LINE1 = "//input[@name='cards[0].embossedLine3']";
	public static final String VELOCITY_EMAIL = "//input[@id='emailAddress']";
	public static final String FINAL_COMMENT_BOX = "//textarea[@name='creditComments']";
	public static final String PIN_BOX_1 = "//input[@id='cardProperties_1_2_pin']";
	public static final String PIN_BOX_2 = "//input[@id='cardProperties_2_2_pin']";
	public static final String SAVE_BUT = "complete";
	public static final String ESSO_CARD_CHECKBOX1 = "//div[@id='hierarchicalCardPropertiesMBTabs_card_1']//li[@class='ui-state-default ui-corner-left'][descendant::a[contains(text(),'Esso')]]//input";
	public static final String HOME_MENU_OPTION = "//ul[@id='nav']/li/a[contains(text(),'Home')]";
	public static final String OUTCOME = "//select[@id='outcome']";
	public static final String SAVE_NEXT_BUTTON = "//span[@id='saveNextButton_label']";
	public static final String CALL_NOTES = "//textarea[@id='notes']";
	public static final String PLACE_CALL_CAMPAIGN_NAME = "//table[@id='call-pd-tab']/tbody/tr[1]/td[4]";

	// Prakalpha-07/22/2019
	public static final String UNRETURNED_APPS = "//td[@id='appTab']";
	public static final String REF_COLUMNHEADER = "//th[@role='columnheader']//input[@id='gs_contactId']";
	public static final String REF_GETFIRSTROW = "//table[@id='pendingAppGrid']/tbody/tr[2]/td[1]";
	public static final String FUEL_APPLICATION_HEADERTEXT = "//b[contains(text(),'Fuel') and contains(text(),'Card') and contains(text(),'Application')]";
	public static final String CUSTOMER_RETURNED_PAPERWORK = "//input[@id='pwp']";

	public static final String APPLICATION_SIGNED_DATE = "//input[@id='appSignedDated']";
	public static final String DD_MANDATE_SIGNED = "//input[@id='ddsigned']";
	public static final String APP_COMPLETED = "//input[@id='appCompleted']";
	public static final String CREDIT_STATUS = "//td[@id='creditNewTab']";
	public static final String REF_CREDIT_STATUS = "//input[@id='gs_appRef']";
	public static final String CREDIT_APPLICATION_STATUS = "//table[@id='homeCreditChecksNewGrid']/tbody//tr[2]/td[4]";
	public static final String CREDIT_GET_REF = "//table[@id='homeCreditChecksNewGrid']/tbody//tr[2]//td[2]";

	public static final String APPLICATION_PASSED = "//input[@id='checkedPass']";
	public static final String MAINOPTION_LOGOUT = "//div[@id='bar']//li/a[contains(text(),'Log Out')]";
	public static final String SUBOPTION_LOGOUT = "//ul//form[@id='logout']";
	public static final String CAMPAIGN_CHECKBOX = "//table[@class='ui-jqgrid-htable']//input[@class='cbox']";
	public static final String CAMPAIGN_USER_TEXTBOX = "//table[@class='ui-jqgrid-htable']//input[@id='gs_username']";
	public static final String CAMPAIGN_BUSINESSNAME_TEXTBOX = "//table[@class='ui-jqgrid-htable']//input[@id='gs_businessName']";
	public static final String RECLAIM_PENDING_CALLS_LINK = "//div[@id='campaignActions']/a[contains(text(),'Reclaim') and contains(text(),'Pending') and contains(text(),'Calls')]";
	public static final String RECLAIM_BUTTON = "//input[@type='submit' and @value='Reclaim']";
	public static final String CAMPAIGN_FIRSTROW_CHECKBOX = "//table[@id='campaignLeadsGrid']/tbody/tr[2]//input[@role='checkbox']";
	public static final String FIRSTROW_BUSINESSNAME = "//table[@id='campaignLeadsGrid']/tbody/tr[2]//td[5]";
	public static final String GET_USER_FROM_FIRSTROW = "//table[@id='campaignLeadsGrid']/tbody/tr[2]//td[13]";
	public static final String GET_RECLAIM_BUSINESS = "//table[@id='campaignLeadsGrid']/tbody/tr[2]//td[4]";
	public static final String UNALLOCATED_CALLS = "//form[@action='assignStandard.do']//tr[1]/td[2]";

	public static final String CALLSHEET_TAB = "//td[@id='callsheetTab']";
	public static final String CALLSHEET_NAME_ROW = "//table[@class='ui-jqgrid-htable']//tr[2]//input[@id='gs_businessName']";
	public static final String CALLSHEET_CAMPAIGN_TEXTBOX = "//table[@class='ui-jqgrid-htable']//tr[2]//input[@id='gs_campaign']";
	public static final String CALLSHEETNAME_FIRSTROW = "//table[@id='callsheetCallsGrid']/tbody/tr[2]/td[2]";
	public static final String RECLAIM_CHECKBOX = "//div[@id='jqgh_campaignLeadsGrid_cb']//input";
	public static final String NO_RECORDS_CALLSHEET = "//td[@id='callsheetCallsPager_right']//div[contains(text(),'No records to view')]";
	public static final String ASSIGNCALLSRANDOMLY_LINK = "//div[@id='campaignActions']/a[contains(text(),'Assign')and contains(text(),'Calls') and contains(text(),'Randomly')]";
	public static final String CALLPERUSER_TEXTBOX = "//table[@class='paddedborderedtable']//input[@name='callsperuser']";
	public static final String ASSIGN_BUTTON = "//form[@action='assignStandard.do']//table[@class='paddedborderedtable']//input[@type='submit']";

	public static final String STRICKED_ALLOCATED = "//ul//li/s[contains(text(),'4. Allocate Calls')]";
	public static final String CALLSHEET_CAMPAIGN_ROW = "//table[@id='callsheetCallsGrid']/tbody/tr[2]/td[3]";

	// Added by sowmiya for credit user 22_07_19
	public static final String UNASSIGNED_CHECK = "unassignedCreditTab"; // id
	public static final String CRUISE_REF_NO = "//input[@name='appId']";
	public static final String ASSIGN_CHECKBOX = "//input[@name='appIdsToTransfer']";
	public static final String ASSIGN_SELECTED_APPLICATION = "//input[@value='Assign Selected Applications']";
	public static final String MY_CREDIT_CHECK = "myCreditTab"; // id
	public static final String MY_CREDIT_CHECK_REF = "//input[@name='appRef']";
	public static final String ASSIGN_TO_ANALYST_DROPDOWN = "//select[@name='toEmployeeId']";
	public static final String REF = "//table[@id='myCreditChecksGrid']//tbody//tr[2]//td[8]";
	public static final String ACTIONS = "//ul[@id='nav']/li/a[contains(text(),'Actions')]";
	public static final String ENTER_DECISION = "//a[contains(text(),'Enter Decision')]";
	public static final String INVOICE_FREQUENCY = "//select[@id='invoiceFrequencyID']";
	public static final String PAYMENT_TERMS = "//select[@id='paymentTermsID']";
	public static final String DECISION_SELECT = "//select[@id='decisionselect']";
	public static final String CREDIT_AUTHORISED_LIMIT = "//input[@name='creditAuthorisedLimit']";
	public static final String SECURITY_TYPE = "//select[@name='securityType']";
	public static final String SECURITY_DATE_RECEIVED = "//input[@name='securityDateReceivedString']";
	public static final String SECURITY_EXPIRY_DATE = "//input[@name='securityExpiryDateString']";
	public static final String RISK_CATEGORY = "//select[@name='riskCategory']";
	public static final String DUNNING_CLASSIFICATION = "//select[@name='dunningCode']";
	public static final String UNDERWRITINGTYPE = "//select[@name='underwritingType']";
	public static final String PERIODIC_ASSIGNMENT = "//input[@name='periodicAssessmentDateString']";
	public static final String OVERALL_FUEL_CREDIT_LIMIT = "//input[@name='givenFuelLimit']";
	public static final String COMMENTS = "//textarea[@name='comments']";
	public static final String RECORD_DECISION_BUTTON = "//input[@id='recordbutton']";// *[@id='recordbutton']";//input[@value='Record
																						// Decision']";
	public static final String DECISION_TITLE = "//strong[contains(text(),'Decision')]";
	public static final String WEX_CREDITSUP_TITLE = "//strong[contains(text(),'WEX Creditsup')]";
	public static final String MY_CRDEIT_CHECK_RECORD = "//td[@id='myCreditChecksPager_right']//div[contains(text(),'No records to view')]";
	public static final String MAINTENANCE_CALLSHEET_LIST_CAMPAIGN = "//ul[@id='nav']//a[contains(text(),'List Campaign')]";
	public static final String CUSTOMER_CAMPAIGN_LIST = "//input[@id='gs_campaignName']";
	public static final String MAINTENANCE = "//ul[@id='nav']/li/a[contains(text(),'Maintenance')]";
	public static final String MAINTENANCE_CALLSHEET = "//ul[@id='nav']//a[contains(text(),'Callsheet ->')]";
	public static final String WEXSALESSUP_USER = "//strong[contains(text(),'WexSales Sup')]";
	public static final String MAINTENANCE_CALLSHEET_CREATE_CAMPAIGN = "//ul[@id='nav']//a[contains(text(),'Create Campaign')]";
	public static final String CAMPAIGN_NAME_TEXT = "//input[@id='dijit_form_ValidationTextBox_0']";
	public static final String CAMPAIGN_TYPE_DROPDOWN = "//input[@id='campaignTypeField']";
	public static final String CAMPAIGN_START_DATE = "//input[@id='dijit_form_DateTextBox_0']";
	public static final String CAMPAIGN_END_DATE = "//input[@id='dijit_form_DateTextBox_1']";
	public static final String CREATE_BUTTON = "//button[@type='submit']";
	public static final String CREATE_CAMPAIGN_TEXT = "//h3[contains(text(),'Create Campaign')]";
	public static final String MANAGE_CAMPAIGN_USERS = "//div[@id='campaignActions']//a[contains(text(),'Manage Campaign Users')]";
	public static final String ASSIGN_SELECTED_CALLS = "//div[@id='campaignActions']//a[contains(text(),'Assign Selected Calls')]";
	public static final String ASSIGN_USERS_TO_CAMPAIGN = "//h3[contains(text(),'Assign Users To Campaign')]";
	public static final String CAMPAIGN_UPDATE_BUTTON = "//input[@value='Update']";
	public static final String SELECT_USERS_CAMPAIGN = "//input[@id='jqg_campaignLeadsGrid_122230']";
	public static final String SELECT_CURRENT_USERS = "//table[@class='paddedborderedtable']//tbody//td[contains(text(),'WexSales Sup')]/following-sibling::td/input[@type='checkbox']";
	public static final String BACK_TO_CAMPAIGN = "//a[contains(text(),'Back To Campaign')]";
	public static final String ASSIGN_SELECTED_CALLS_DROPDOWN = "//*[@id='assignSelectedCallsSelect']";
	public static final String ASSIGN_SELECTED_SAVE_BUTTON = "//div[@class='ui-dialog-buttonset']//span[contains(text(),'Save')]";
	public static final String UNASSIGNEDCHECK_SCROLLRIGHT = "//*[@id='gview_unassignedChecksGrid']/div[3]";
	public static final String CAMPAIGN_SUMMARY_SROLL_RIGHT = "//div[@id='gview_campaignLeadsGrid']";
	public static final String CAMPAIGN_SUMMARY_USER = "//input[@id='gs_username']";
	public static final String ADDITIONAL_INFO = "//input[@id='gs_additionalInfo']";
	public static final String HOMEPAGE = "//a[contains(text(),'Home Page')]";
	public static final String CALLSHEETIMPORT_DROPDOWN = "//div[@class='chzn-container chzn-container-single']";
	public static final String CALLSHEETIMPORT_DROPDOWN_TEXTBOX = "//div[@class='chzn-drop']//input";

	// Raxsana
	/*public static final String APP_FORM_PDF_DOCUMENT = "//html//body//embed[@id='plugin']";*/
	public static final String APP_FORM_PDF_DOCUMENT = "//html//body//embed";
	public static final String IFRAME_ID = "appFrame";
	public static final String RETURN_TO_HOMEPAGE_LINK = "//div[@class='letterheader']/a[@href='/cruise/sp/crmIndex']";
	public static final String FOLLOWUP_CAMPAIGN_START_DATE = "//table[@class='paddedtable']//label[text()='Start Date']/following::input[1]";
	public static final String FOLLOWUP_CAMPAIGN_END_DATE = "//table[@class='paddedtable']//label[text()='End Date']/following::input[1]";
	public static final String CREATE_FOLLOWUP_CAMPAIGN = "//div[@id='campaignActions']//a[contains(text(),'Create Follow-up Campaign')]";

	// Added by Sasi 23/07/2019
	public static final String CARDS_AWAITING_ORDER_TAB = "//tr/td[@id='awaitingorderTab']";
	public static final String RUN_ORDER_BUTTON = "//input[@name='generate']";
	public static final String VIEW_BUTTON = "//input[@name='view']";
	public static final String IMPORT_FAILED_MESSAGE = "//div/h1/span[contains(text(),'Import Failed')]";
	public static final String IMPORT_SUCCESSFUL_MESSAGE = "//div/h1/span[contains(text(),'Imported Successfully')]";
	public static final String CARDS_TEXT_PAGE_VALIDATION = "//div/strong[contains(text(),'Cards')]";
	public static final String WEX_CARDS_TEXT_PAGE_VALIDATION = "//a/strong[contains(text(),'WEX Cards')]";//updated xpath on 19/2/20 by senthil
	public static final String CHECK_TABLE_VICINITY = "//div[@class='dojoxGrid-master-view']";
	public static final String TABLE_DATA = "//div[@class='dojoxGrid-content']";
	public static final String CALL_SHEET_IMPORT_TAB = "//a[contains(text(),'Callsheet Import')]";
	public static final String CAMPAIGN_DROPDOWN = "//select[@id='campaign']";
	public static final String CHOOSE_FILE_BUTTON = "//div[@class='input']/input[@id='file']";
	public static final String CHECK_FILE_BUTTON = "//input[@id='checkFileButton']";
	public static final String IMPORT_BUTTON = "//input[@value='Import']";
	public static final String IMPORT_SUCCESS_MSG = "//div[@class='formSectionLabel'][contains(text(),'Callsheet Import')]";
	public static final String ASSIGN_SELECTED_CALLS_POPUP = "//span[@class='ui-dialog-title']";

	// Added by Sasi 16/09/2019
	public static final String BANK_TRANSFER = "bankTransfer";// Id
	public static final String PAY_BY_CHEQUE = "payByCheque";// Id
	public static final String LITE_APPLICATION = "liveApp";// Id
	public static final String LONG_APPLICATION = "input#longApp";// "longApp";
	public static final String SHORT_APPLICATION = "shortApp";// Id
	public static final String WARNING_PAY_BY_CHEQUE = "payByChequeWarning";// Id
	public static final String WARNING_PAY_BY_BANK_TRANS = "payByBankTransWarning";// Id

	public static final String BANK_ACC_NAME = "bankAccountName";// Id
	public static final String BANK_SORT_CODE_1 = "bankSort1";// Id
	public static final String BANK_SORT_CODE_2 = "bankSort2";// Id
	public static final String BANK_SORT_CODE_3 = "bankSort3";// Id
	public static final String BANK_ACC_NO = "bankAccountNo";// Id
	public static final String SIGNATORY_NAME = "nameOfSignatory";// Id
	public static final String BANK_NAME = "bankName";// Id
	public static final String BANK_ADDRESS1 = "bankAddress1";// Id
	public static final String BANK_TOWN = "bankTown";// Id
	public static final String BANK_POSTCODE = "bankPostcode";// Id
	public static final String ROLE_IN_CMPY = "//select[@class='reqdropdown nonSepaBankDetailsField']";// XPATH

	public static final String RUN_BUTTON = "input.searchbutton[value='Run >>']";// CSS Selector
	public static final String DD1_YES_Button = "input[name='dd1Choice'][value='N']";// CSS Selector
	public static final String APP_COMPLETED_CHECKBOX = "appCompleted";// Id
	public static final String PAYMENT_BY_CHEQUE = "//input[@id='checkAuthChqPayer']";// checkAuthBankTransPayer
	public static final String PAYMENT_BY_BankTrans = "checkAuthBankTransPayer";// Id

	// Velocity Locators

	// Added by Sasikumar 25/09/2019
	public static final String VELOCITY_USERNAME = "id_username"; // ID
	public static final String VELOCITY_PASSWORD = "id_password"; // ID
	public static final String VELOCITY_SIGNIN = "input[class*=login-image-button]"; // CSS Selector
	public static final String LOGIN_BUTTON = "a[class*=login-btn]";// CSS
	public static final String VELOCITY_LOGO = "a[class=logo]"; // CSS
	public static final String VELOCITY_LOGOUT = "//a[contains(text(),'Logout')]"; // Xpath

	public static final String DISTRIBUTOR_ACCESS = "distributor"; // ID
	public static final String CUSTOMER_SERVICE_ACCESS = "admin"; // ID
	public static final String CUSTOMER_SEARCH_BOX = "id_search_customers"; // ID
	public static final String MANAGE_CARDS = "//div[@class='menu_item_title'][contains(text(),'Manage Cards')]";
	public static final String ORDER_CARDS = "fuel-manage-cards-order-cards"; // ID
	public static final String NEW_CARD = "//img[@alt='New Card']";// Xpath
	public static final String NO_OF_CARD_HOLDERS = "id_number_of_cardholders"; // ID
	public static final String DRIVER_OR_VRN = "input[id*='vrn_driver']"; // CSS
	public static final String ADDITIONAL_EMBOSS_DETAILS = "input[id*='additional_embossed_line']"; // CSS
	public static final String TYPE_CHECKBOX = "span[class*='pretty-checkbox']";// CSS
	public static final String SUBMIT_BUTTON = "input[value='Submit']";// CSS
	public static final String ALERT_MSG = "div[class*='alert-box']";// CSS

	public static final String BLOCKING_CARDS = "fuel-manage-cards-put-cards-on-stop";// ID
	public static final String REASON_TEXTBOX = "input[name='reason']";// CSS
	public static final String SUBMIT_BUT = "button[class*='submit']";// CSS
	public static final String CARD_NO = "//td[@class='cardStopCell'][1]";// XPATH

	public static final String FIRST_ROW_CARDNO = "//tbody/tr[@class='table-row'][1]/td[1]";// XPATH

	public static final String PIN_REMINDER_BUTTON = "pin_reminder";// ID
	public static final String MANAGE_GROUPS = "fuel-manage-groups";// ID
	public static final String NEW_GROUPS = "fuel-manage-groups-new-group";// ID
	public static final String GROUP_NAME = "id_name";// ID
	public static final String OK_BUTTON = "button[type='submit']";// CSS
	public static final String ASSIGN_CARDS_TO_GRP = "fuel-manage-groups-assign-cards";// ID
	public static final String COSTCENTRE_NAME = "label[class='truncated-text']";// CSS
	public static final String SELECT_RADIO_BUTTON = "input[id*='radio']";// CSS
	public static final String NEXT_BTN = "button[class*='btn-primary']";// CSS
	public static final String CARD_PACK = "li[class='card-pack']";// CSS
	public static final String CARD_BRAND = "div[class='card-brand']";// CSS
	public static final String CARD_NUMBER = "div[class='card-brand'] > input";// CSS
	public static final String SORTABLE_CARDS = "assigned_sortable_cards";// ID
	public static final String UNASSIGNED_COUNTS = "//li/a[text()='Unassigned']/following::li[1]";// XPATH

	public static final String HOMEICON = "li#nav_main_home";// CSS
	public static final String TABLE_HEADER = "//thead/tr/th";// XPATH
	public static final String TABLE_DATA_VALUES = "//tr[@class='table-row'][1]/td";// XPATH
	public static final String FILTER_CARD_NUMBER = "id_pan_no";// ID
	public static final String TITLE = "h2.title";// CSS

	public static final String CUTOMER_NAME_HEADER = "div[class*='company-name']";// CSS
	public static final String REPORTS_MENU = "fuel-reports"; // ID
	public static final String REGULAR_TRANSREPORT = "regularTransReport"; // ID
	public static final String CARD_REPORT = "card_report"; // ID
	public static final String CARDS_SELECTED_BUTTON = "cards_selected_button"; // ID

	public static final String PREV_YEAR_BUTTON = "prevYearButton"; // ID
	public static final String DATE_RANGE_SUBMITBUTTON = "enterDateRangeSubmitButton"; // ID
	public static final String TRANSACTION_GRID = "transaction_grid"; // ID
	public static final String SELECT_ALL_CARDS = "select_all_cards";// ID
	public static final String ACCEPT_COOKIE = "a[class*='cookieAccept']";// CSS
	public static final String TRANS_SUMMARY = "transaction_summary";// ID
	public static final String TRANSACTION_INDIVIDUAL = "transaction_grid";// ID
	public static final String MKII_REPORT = "mkii-extract";// ID
	public static final String TRANSACTION_EXTRACT_REPORT = "wex-reports";// ID
	public static final String PREV_MONTH_BTN = "prevMonthButton";// ID
	public static final String DOWNLOAD_EXCEL = "downloadExcel";// ID;
	public static final String DOWNLOAD_CSV = "downloadCSV";// ID;
	public static final String INVOICES_MENU = "fuel-invoices";// ID
	public static final String INVOICES_SUBMENU = "a[href='/invoices/']";// CSS
	public static final String PAYMENT_INVOICE = "a[href^='/invoices/payment-advice']";// CSS
	public static final String SEARCH_INVOICE = "a[href$='/search/']";// CSS
	public static final String SEARCH_DATA_RANGE = "invoice-search-data-range";// ID
	public static final String START_DATE = "startDate";// ID
	public static final String END_DATE = "endDate";// ID
	public static final String SEARCH_INVOICE_BTN = "button[name='submit_number']";// CSS
	public static final String SUBMIT_DATE_BTN = "button[name='submit_date']";// CSS
	public static final String SEARCH_INVOICE_NUMBER = "invoice-search-invoice-number";// ID

	public static final String INVOICE_NUM_TXT_BOX = "id_invoice_number";
	public static final String QUANTITY_TEXTBOX = "id_quantity";
	public static final String SEARCH_HEADER = "tr[class*='table-row card-pan-pack-header']>td";

	public static final String EXCHANGE_BTN = "i[class*='exchange']";
	public static final String USER_BTN = "i[class*='user']";
	public static final String CHANGE_YOUR_DETAILS = "//div[@class='menu_item_title'][contains(text(),'Change Your Details')]";

	public static final String CITY_TXTBOX = "id_city";
	public static final String CONTACT_NO_TXTBOX = "id_contact_number";
	public static final String BUSINESS_TYPE_BUTTON = "//div[@id='businessType_chzn']";

}
