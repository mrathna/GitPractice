package com.framework.pages.WES.Cruise;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

import com.aventstack.extentreports.ExtentTest;
import com.framework.basepage.BasePage;
import com.framework.repo.Locator_WES;

public class CruiseCardsPage extends BasePage {

	ArrayList<String> expValues;
	ArrayList<String> actualValues;

	@FindBy(xpath = Locator_WES.CARDS_AWAITING_ORDER_TAB)
	public WebElement cardsAwaitingOrder;

	@FindBy(xpath = Locator_WES.VIEW_BUTTON)
	public WebElement viewButton;

	@FindBy(xpath = Locator_WES.CHECK_TABLE_VICINITY)
	public WebElement checkTableVicinity;

	@FindBy(xpath = Locator_WES.TABLE_DATA)
	public WebElement tableData;

	@FindBy(xpath = Locator_WES.CARDS_TEXT_PAGE_VALIDATION)
	public WebElement cardsText;

	@FindBy(xpath = Locator_WES.WEX_CARDS_TEXT_PAGE_VALIDATION)
	public WebElement wexCardsText;
	
	@FindBy(xpath = Locator_WES.RUN_ORDER_BUTTON)
	public WebElement runOrderButton;
	
	@FindBy(xpath = Locator_WES.IMPORT_SUCCESSFUL_MESSAGE)
	public WebElement importSuccessfulMessage;

	public CruiseCardsPage(WebDriver driver, ExtentTest test) {
		super(driver, test);
		PageFactory.initElements(new AjaxElementLocatorFactory(driver, 15), this);
	}

	public void validateCardsPage() {
		isDisplayed(cardsText, "Cards text presents");
		isDisplayed(wexCardsText, "WEX Cards text presents");
	}

	public String verifyRunCardOrder(String applNoExp) {
		String applicantName = null;
		String applicationNo = null;
		isDisplayedThenClick(cardsAwaitingOrder, "successfuly clicked cardsAwaitingOrder");
		System.out.println("attri: " + cardsAwaitingOrder.getAttribute("class"));
		if ("tabSelected".equalsIgnoreCase(cardsAwaitingOrder.getAttribute("class"))) {
			driver.switchTo().frame("awaitingorderFrame");
			isDisplayedThenActionClick(viewButton, "successfuly clicked view");
			System.out.println("viewButton");
			sleep(5);
			// Taking ScreenShots 
			takeScreenshot();
			sleep(2);
			boolean tablePresence = waitToCheckElementIsDisplayed(By.xpath("//div[@class='dojoxGrid-row'][1]"), 10);
			System.out.println("tablePresence : " + tablePresence);
			if (tablePresence) {
				setCellDataFromTable(tableData, 7, false);
				setCellDataFromTable(tableData, 7, false);
				List<WebElement> rowElements = driver
						.findElements(By.xpath("//div[contains(@class,'dojoxGrid-row')]//tr"));
				System.out.println("inside rowElements : " + rowElements.size());
				for (int j = 0; j < rowElements.size(); j++) {
					applicationNo = getCellDataFromTable(j, 1, false);
					System.out.println("applicationNo : " + applicationNo);
					if (applNoExp.equals(applicationNo)) {
						System.out.println("goin to run card order");
						applicantName = getCellDataFromTable(j, 3, false);
						System.out.println("applicantName : " + applicantName);
						
						  isDisplayedThenActionClick(runOrderButton,"successfuly clicked runOrderButton");
						  sleep(5);
						  System.out.println("runOrderButton"); 
						  isDisplayed(importSuccessfulMessage,"Success Msg presents");
						// Taking ScreenShots 
						takeScreenshot();
						sleep(2);
						logPass("Card ordered successfully");
						break;
					} else if (j == rowElements.size() - 1)
						logFail("expected application number not listed");
				}
			} else
				logFail("No data found");
		} else
			logFail("Not redirected to cardsAwaitingOrder tab");
		sleep(30);
		return applicantName;
	}
}
