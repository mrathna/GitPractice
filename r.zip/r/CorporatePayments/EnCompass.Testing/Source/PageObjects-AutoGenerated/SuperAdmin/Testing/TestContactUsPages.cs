using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using Common;
using Common.PageObjects;
using Common.ScenarioConfigurations;
using Common.Utility;

namespace EnCompass.Testing.Source.PageObjects.SuperAdmin.Testing 
{
	/// <summary>
	/// Auto-generated Page Model Class
	/// Navigation Paths: 
		/// [Organization Home]->General->Testing->Contact Us
		/// </summary>
	[PageModel(@"/superAdmin/testing/TestContactUsPages.aspx")]
	public partial class TestContactUsPages : EnCompassSuperPageModel 
	{
		public override string RelativeUrl => @"/superAdmin/testing/TestContactUsPages.aspx";
		public override string PageIdentifierXPath_Generated => @"//li[contains(@class, 'breadcrumb-item active')][text() = 'Contact Us']";

		#region Navigation
				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Create Organization']")]
		private IWebElement _general_Testing_ContactUs_CreateOrganization { get; set; }
		public void NavigateTo_General_Testing_ContactUs_CreateOrganization()
		{
			NavigateToMenuItem(_general_Testing_ContactUs_CreateOrganization);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Create Organization Profile']")]
		private IWebElement _general_Testing_ContactUs_CreateOrganizationProfile { get; set; }
		public void NavigateTo_General_Testing_ContactUs_CreateOrganizationProfile()
		{
			NavigateToMenuItem(_general_Testing_ContactUs_CreateOrganizationProfile);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Delete Test Organization']")]
		private IWebElement _general_Testing_ContactUs_DeleteTestOrganization { get; set; }
		public void NavigateTo_General_Testing_ContactUs_DeleteTestOrganization()
		{
			NavigateToMenuItem(_general_Testing_ContactUs_DeleteTestOrganization);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Create Test Company']")]
		private IWebElement _general_Testing_ContactUs_CreateTestCompany { get; set; }
		public void NavigateTo_General_Testing_ContactUs_CreateTestCompany()
		{
			NavigateToMenuItem(_general_Testing_ContactUs_CreateTestCompany);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Corporate Credit Limit']")]
		private IWebElement _general_Testing_ContactUs_CorporateCreditLimit { get; set; }
		public void NavigateTo_General_Testing_ContactUs_CorporateCreditLimit()
		{
			NavigateToMenuItem(_general_Testing_ContactUs_CorporateCreditLimit);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Create Bounce Notification']")]
		private IWebElement _general_Testing_ContactUs_CreateBounceNotification { get; set; }
		public void NavigateTo_General_Testing_ContactUs_CreateBounceNotification()
		{
			NavigateToMenuItem(_general_Testing_ContactUs_CreateBounceNotification);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Reset Merchant Log Error']")]
		private IWebElement _general_Testing_ContactUs_ResetMerchantLogError { get; set; }
		public void NavigateTo_General_Testing_ContactUs_ResetMerchantLogError()
		{
			NavigateToMenuItem(_general_Testing_ContactUs_ResetMerchantLogError);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Performance']")]
		private IWebElement _general_Testing_ContactUs_Performance { get; set; }
		public void NavigateTo_General_Testing_ContactUs_Performance()
		{
			NavigateToMenuItem(_general_Testing_ContactUs_Performance);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='AP Non-Card Payments Testing']")]
		private IWebElement _general_Testing_ContactUs_ApNonCardPaymentsTesting { get; set; }
		public void NavigateTo_General_Testing_ContactUs_ApNonCardPaymentsTesting()
		{
			NavigateToMenuItem(_general_Testing_ContactUs_ApNonCardPaymentsTesting);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Modify Merchant Log']")]
		private IWebElement _general_Testing_ContactUs_ModifyMerchantLog { get; set; }
		public void NavigateTo_General_Testing_ContactUs_ModifyMerchantLog()
		{
			NavigateToMenuItem(_general_Testing_ContactUs_ModifyMerchantLog);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Test Templates']")]
		private IWebElement _general_Testing_ContactUs_TestTemplates { get; set; }
		public void NavigateTo_General_Testing_ContactUs_TestTemplates()
		{
			NavigateToMenuItem(_general_Testing_ContactUs_TestTemplates);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Create Test Statements']")]
		private IWebElement _general_Testing_ContactUs_CreateTestStatements { get; set; }
		public void NavigateTo_General_Testing_ContactUs_CreateTestStatements()
		{
			NavigateToMenuItem(_general_Testing_ContactUs_CreateTestStatements);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Contact Us']")]
		private IWebElement _general_Testing_ContactUs_ContactUs { get; set; }
		public void NavigateTo_General_Testing_ContactUs_ContactUs()
		{
			NavigateToMenuItem(_general_Testing_ContactUs_ContactUs);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Dispute Transaction']")]
		private IWebElement _general_Testing_ContactUs_DisputeTransaction { get; set; }
		public void NavigateTo_General_Testing_ContactUs_DisputeTransaction()
		{
			NavigateToMenuItem(_general_Testing_ContactUs_DisputeTransaction);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Terms and Conditions']")]
		private IWebElement _general_Testing_ContactUs_TermsAndConditions { get; set; }
		public void NavigateTo_General_Testing_ContactUs_TermsAndConditions()
		{
			NavigateToMenuItem(_general_Testing_ContactUs_TermsAndConditions);
		}

		
		private void NavigateToMenuItem(IWebElement element)
		{
			Driver.Url = element.GetAttribute("href");
		}
		#endregion

		public TestContactUsPages(GlobalSettings settings) : base(settings) { }
	}  
}
