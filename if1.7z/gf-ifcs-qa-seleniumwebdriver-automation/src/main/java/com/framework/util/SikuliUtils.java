package com.framework.util;

import org.sikuli.script.FindFailed;
import org.sikuli.script.Key;
import org.sikuli.script.Screen;

public class SikuliUtils {
	static Screen screen = new Screen();
	/**
	 * Wait until the Object is Loaded
	 * @param targetTimeOut
	 */
	public static void waitUntilObjectisLoaded(double targetTimeOut) {
		screen.wait(targetTimeOut);
	}

	/**
	 * Click Action
	 * @param element
	 */
	public static  void clickElement(String element) {
		try {
			screen.click(element);
		}
		catch(FindFailed e) {
			System.out.println("Unable to Click The Element"+e);
		}
	}
	/**
	 * Enter Text
	 * @param element
	 * @param text
	 */
	public static void enterText(String element,String text) {
		screen.type(element, text);
	}

	/**
	 * Clear Text
	 * 
	 * @param element
	 * @param text
	 */
	
	public static void clearText(String element) {
		screen.type(Key.BACKSPACE);
	}

	
}


