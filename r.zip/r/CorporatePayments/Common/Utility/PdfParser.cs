﻿using Apitron.PDF.Kit;
using Apitron.PDF.Kit.Extraction;
using Apitron.PDF.Kit.FixedLayout;
using iTextSharp.text.pdf;
using iTextSharp.text.pdf.parser;
using Patagames.Ocr;
using Patagames.Ocr.Enums;
using System.IO;
using System.Text;

namespace Common.Utility
{
	/// <summary>
	/// Helper class to parse PDF files	
	/// </summary>
	public class PdfParser
	{
		/// <summary>
		/// Parses a PDF file and extracts the text content
		/// </summary>
		public static StringBuilder ParsePdfFileToText(string fPath, string fName)
		{
			StringBuilder pdfContent = new StringBuilder();
			using (PdfReader reader = new PdfReader(System.IO.Path.Combine(fPath, fName)))
			{
				// Read Pages and append the content in StringBuilder
				for (int page = 1; page <= reader.NumberOfPages; page++)
				{
					SimpleTextExtractionStrategy strat = new SimpleTextExtractionStrategy();
					string pageText = PdfTextExtractor.GetTextFromPage(reader, page, strat);	
					pdfContent.Append(pageText);
				}
			}
			return pdfContent;
		}

		/// <summary>
		/// Parses a pdf file, looks for all the images in the file and 
		/// converts them into text form.  Appends the texts in a StringBuilder
		/// object before returning the object
		/// </summary>
		public static StringBuilder ParsePdfFileImagesToText(string fPath, string fName)
		{
			StringBuilder pdfContent = new StringBuilder();			
			using (Stream stream = File.Open(System.IO.Path.Combine(fPath, fName), FileMode.Open))
			{
				// create document object
				FixedDocument doc = new FixedDocument(stream);

				// Check if Dir exists to store PDF converted images, if not create.
				string pdfDir = PathHelper.GetAbsolutePathRelativeToProjectPath("Resources\\Templates\\PdfImages");
				if (! Directory.Exists(pdfDir))
					Directory.CreateDirectory(pdfDir);

				// enumerate document's pages
				foreach (Page page in doc.Pages)
				{
					// extract images from PDF page
					foreach (ImageInfo info in page.ExtractImages())
					{
						// construct image file name
						string imageFileName = System.IO.Path.Combine(pdfDir, string.Format("{0}.{1}", System.Guid.NewGuid(), "bmp"));
						// save image to file
						using (Stream imageStream = File.Create(imageFileName))
						{
							info.SaveToBitmap(imageStream);
						}

						// Conver Image to text
						OcrApi.PathToEngine = System.IO.Path.Combine(PathHelper.GetSolutionDirectoryPath(), GlobalSettings.TessaractDllPath);
						using (OcrApi api = OcrApi.Create())
						{
							api.Init(Languages.English, System.IO.Path.Combine(PathHelper.GetSolutionDirectoryPath(), GlobalSettings.TessaractDataPath));
							string plainText = api.GetTextFromImage(imageFileName);
							pdfContent.Append(plainText);
						}
					}
				}
			}
			return pdfContent;
		}


	}
}
