package com.framework.testcases.AJS.BP.Interface;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.MaintainCustomerPage;
import com.framework.pages.AJS.common.Common;
import com.framework.pages.AJS.common.IFCSHomePage;
import com.framework.pages.AJS.common.IFCSLoginPage;

public class ValidateApplicationTypeTransferTestCase extends BaseTest {
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "Smoke","BusinessFlow" })
	public void validateApplicationTypeTransfer(@Optional("AU") String clientCountry,
			@Optional("BP") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  BPNZ14_Cust_NZ_004_Application type transfers",
				"BPNZ14_Cust_NZ_004_Application type transfers");
		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		Common common = new Common(driver, test);
		MaintainCustomerPage maintainCustomer = new MaintainCustomerPage(driver, test);
		// Calling Functions
		IFCSloginPage.login("IFCS_URL_BP", "IFCS_BP_SUPPORT_USERNAME", "IFCS_BP_SUPPORT_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, " ");
		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		// Changing Business Direct application customer to Premium Customer
		String customerNo = common.getActiveCustomerUsingApplicationType("Premium");
		if (customerNo.equals("")) {
			// need to call method to logfail
			common.logForNoDataFound(this.getClass().getSimpleName(), "Need to create active customers and rerun");
		} else {
			IFCSHomePage.gotoCustomerMenuCustomerDetails();
			maintainCustomer.chooseCustomerNoAndSearch(customerNo);
			maintainCustomer.addApplicationTypeTransfer();
			maintainCustomer.validateApplicationTypeTransferStatus("Registered");
			// Day End Execution
			IFCSHomePage.gotoCustomerMenuCustomerDetails();
			maintainCustomer.chooseCustomerNoAndSearch(customerNo);
			maintainCustomer.validateApplicationTypeTransferStatus("Completed");
		}
		IFCSHomePage.exitIFCS();
	}
}
