/*
 * 27-04-2018
 * Ayub Khan
 */
package com.framework.testcases.OLS.BP.Customer;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.BP.BPAccountDetailsPage;
import com.framework.pages.BP.BPHomePage;
import com.framework.pages.OLS.common.LoginPage;

public class ValidateAccountDetailsPage extends BaseTest {
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "Smoke", "Regression","BusinessFlow" })
	public void validate_Account_Details_Page(@Optional("AU") String clientCountry, @Optional("BP") String clientName)
	 {
		test = extent.createTest(clientName+ ":" +clientCountry+"  17 - Account Details Page", "Update Account details page");
		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		BPHomePage bpHomePage = new BPHomePage(driver, test);

		BPAccountDetailsPage bpAccountdetailsPage = new BPAccountDetailsPage(driver, test);
		// Calling Functions
		loginPage.Login("BP_URL", "BP_UN_Customer_" + clientCountry, "BP_PWD_Customer_" + clientCountry, clientName);
		bpHomePage.ValidateBPCustomerLogo();		
		bpAccountdetailsPage.selectAccountAndClickAndValidate();		
		bpAccountdetailsPage.clickViewContactInformationLink();
		bpAccountdetailsPage.clickEditAccountDetailsbutton();

		bpAccountdetailsPage.checkAccountDetailsPage();
		bpAccountdetailsPage.selectInputFromAlertThreshold(clientCountry);
		bpAccountdetailsPage.typeAccountName();
		bpAccountdetailsPage.typeAccountEmail();
		bpAccountdetailsPage.typeAccountPhoneNumber();
		bpAccountdetailsPage.clickSaveChangesButton();
		bpAccountdetailsPage.checkConfirmationMessage();
		bpAccountdetailsPage.clickReturnToAccountDetailButton();
		bpHomePage.ValidateBPCustomerLogo();
		bpAccountdetailsPage.clickUpdateCreditLimitLink(clientCountry);
		bpAccountdetailsPage.checkUpdatedInput(clientCountry); 

		loginPage.Logout();
		}
}
