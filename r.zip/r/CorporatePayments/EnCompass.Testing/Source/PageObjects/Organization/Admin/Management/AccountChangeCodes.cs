﻿using AventStack.ExtentReports;
using Common.Utility;
using NFluent;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Support.UI;
using System;

namespace EnCompass.Testing.Source.PageObjects.Organization.Admin.Management
{
    public partial class AccountChangeCodes
    {
        #region xpath page Elements

        private const string EDIT_BUTTON_LIMIT = "//tr[contains(@id, 'Limit')]//input[contains(@id,'btnEdit')]";
        private const string EDIT_BUTTON_RATING = "//tr[contains(@id, 'Rating')]//input[contains(@id,'btnEdit')]";
        private const string LIMIT_CHANGE_ERROR_MESSAGE = "//div[contains(@id,'ValidationSummaries_vscreditlimit')]";
        private const string RATING_CHANGE_ERROR_MESSAGE = "//div[contains(@id,'ValidationSummaries_vscreditrating')]";

        private const string _btnSaveXPath = @"//input[contains(@id,'btnSave')]";
        private const string _codeLimitXPath = @"//label[contains(@for,'Limit')]//following-sibling::input[contains(@id,'txtCode')]";
        private const string _codeRatingXPath = @"//label[contains(@for,'Rating')]//following-sibling::input[contains(@id,'txtCode')]";
        private const string _descriptionLimitXPath = @"//label[contains(@for,'Limit')]//following-sibling::input[contains(@id,'txtDescription')]";
        private const string _descriptionRatingXPath = @"//label[contains(@for,'Rating')]//following-sibling::input[contains(@id,'txtDescription')]";
        private const string _addCodeLimitXPath = @"//tr[contains(@id, 'Limit')]//input[contains(@id,'btnAddCode')]";
        private const string _addCodeRatingXPath = @"//tr[contains(@onclick, 'Rating')]//input[contains(@id,'btnAddCode')]";
        private const string _editLimitXPath = @"//tr[contains(@id, 'Limit')]//input[contains(@id,'btnEdit')]";
        private const string _editRatingXPath = @"//tr[contains(@id, 'Rating')]//input[contains(@id,'btnEdit')]";
        private const string _activeValueLimitXPath = @"//tr[contains(@id, 'Limit')]//input[contains(@id,'chkActive')]";
        private const string _activeValueRatingXPath = @"//tr[contains(@id, 'Rating')]//input[contains(@id,'chkActive')]";
        private const string _saveEditLimitXPath = @"//tr[contains(@id, 'Limit')]//input[contains(@id,'btnSave')]";
        private const string _saveEditRatingXPath = @"//tr[contains(@id, 'Rating')]//input[contains(@id,'btnSave')]";
        private const string _checkBoxValueLimitXPath = @"//div[contains(@id,'Limit')]//input[contains(@id,'gvCreditLimitChk')]";
        private const string _checkBoxValueRatingXPath = @"//div[contains(@id,'Rating')]//input[contains(@id,'gvCreditRatingChk')]";
        private const string _successMessageXPath = "//div[contains(@id,'SuccessMessage')]";
        private const string _errorMessageXPath = "//div[contains(@id,'divMessage')]";
        #endregion

        #region Page Elements

        private IWebElement _btnSave
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_btnSaveXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_btnSave element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _codeLimit
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_codeLimitXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_codeLimit element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _codeRating
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_codeRatingXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_codeRating element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _descriptionLimit
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_descriptionLimitXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_descriptionLimit element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _descriptionRating
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_descriptionRatingXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_descriptionRating element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _addCodeLimit
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_addCodeLimitXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_addCodeLimit element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _addCodeRating
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_addCodeRatingXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_addCodeRating element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _editLimit
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_editLimitXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_editLimit element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _editRating
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_editRatingXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_editRating element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _activeValueLimit
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_activeValueLimitXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_activeValueLimit element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _activeValueRating
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_activeValueRatingXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_activeValueRating element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _saveEditLimit
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_saveEditLimitXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_saveEditLimit element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _saveEditRating
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_saveEditRatingXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_saveEditRating element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _checkBoxValueLimit
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_checkBoxValueLimitXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_checkBoxValueLimit element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _checkBoxValueRating
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_checkBoxValueRatingXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_checkBoxValueRating element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _successMessage
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_successMessageXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_successMessage element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _errorMessage
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_errorMessageXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_errorMessage element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        #endregion

        public string CodeLimit
        {
            get { return _codeLimit.GetAttribute("innerText"); }
            set { _codeLimit.ForceDocumentLoadOnSendKeys(value, Driver); }
        }

        public string CodeRating
        {
            get { return _codeRating.GetAttribute("innerText"); }
            set { _codeRating.ForceDocumentLoadOnSendKeys(value, Driver); }
        }

        public string DescriptionLimit
        {
            get { return _descriptionLimit.GetAttribute("innerText"); }
            set { _descriptionLimit.ForceDocumentLoadOnSendKeys(value, Driver); }
        }

        public string DescriptionRating
        {
            get { return _descriptionRating.GetAttribute("innerText"); }
            set { _descriptionRating.ForceDocumentLoadOnSendKeys(value, Driver); }
        }

        public string ErrorMessage
        {
            get
            {
                return _errorMessage.Text;
            }
        }

        public void AddCodeLimit()
        {
            _addCodeLimit.JSClickWithFocus(Driver);
        }

        public void AddCodeRating()
        {
            _addCodeRating.JSClickWithFocus(Driver);
        }

        public void EditLimit()
        {
            _editLimit.JSClickWithFocus(Driver);
        }

        public void EditRating()
        {
            _editRating.JSClickWithFocus(Driver);
        }

        public void SaveEditLimit()
        {
            _saveEditLimit.JSClickWithFocus(Driver);
        }

        public void SaveEditRating()
        {
            _saveEditRating.JSClickWithFocus(Driver);
        }

        public void Save()
        {
            Settings.EnCompassWebDriver.WaitElementBeClickable(_btnSaveXPath);
			_btnSave.JSClickWithFocus(Driver);
			WebDriverWait wait = new WebDriverWait(Driver, TimeSpan.FromSeconds(5));
            wait.Until(ExpectedConditions.TextToBePresentInElement(_successMessage, "Required Code Options saved successfully."));
			this.AttachOnDemandScreenShot();
		}

        public void AddChangeReasonCodes(string creditType, string reasonCode, string description, ExtentTest test)
        {
            if (creditType.ToLowerInvariant().Equals("limit"))
            {
                CodeLimit = reasonCode;
                test.Info("Set code Limit information");
                DescriptionLimit = description;
                test.Info("Set description Limit information");
                AddCodeLimit();
                test.Info("Click add button");
                WaitForFormLoadingOverlay();
                Driver.WaitElementBeClickable(EDIT_BUTTON_LIMIT);
            }
            else if (creditType.ToLowerInvariant().Equals("rating"))
            {
                CodeRating = reasonCode;
                test.Info("Set code Rating information");
                DescriptionRating = description;
                test.Info("Set description Rating information");
                AddCodeRating();
                test.Info("Click add button");
                WaitForFormLoadingOverlay();
                Driver.WaitElementBeClickable(EDIT_BUTTON_RATING);
            }
            else
            {
                throw new NotFoundException("Option not found.");
            }
        }

        public void EditChangeReasonCodes(string creditType, string description, bool activeValue, ExtentTest test)
        {
            if (creditType.ToLowerInvariant().Equals("limit"))
            {
                EditLimit();
                test.Info("Click edit Limit button");
                WaitForFormLoadingOverlay();
                Settings.EnCompassWebDriver.WaitElementBeClickable($"//label[contains(@for,'{creditType}')]//following-sibling::input[contains(@id,'txtDescription')]");
                DescriptionLimit = description;
                test.Info("Set description Limit information");
                _activeValueLimit.SetCheckboxStateWithLabel(null, activeValue);
                test.Info("Edit active Limit information");
                SaveEditLimit();
                test.Info("Click icon save button to edit Limit");
                WaitForFormLoadingOverlay();
                Driver.WaitElementBeClickable(EDIT_BUTTON_LIMIT);
            }
            else if (creditType.ToLowerInvariant().Equals("rating"))
            {
                EditRating();
                test.Info("Click edit Rating button");
                WaitForFormLoadingOverlay();
                Settings.EnCompassWebDriver.WaitElementBeClickable($"//table/caption[contains(text(),'{creditType}')]/parent::table//tr//input[contains(@id,'txtDescription')]");
                DescriptionRating = description;
                test.Info("Set description Rating information");
                _activeValueLimit.SetCheckboxState(activeValue);
                test.Info("Edit active Rating information");
                SaveEditRating();
                test.Info("Click icon save button to edit Rating");
                WaitForModalLoadingOverlay();
                Driver.WaitElementBeClickable(EDIT_BUTTON_RATING);
            }
            else
            {
                throw new NotFoundException("Option not found.");
            }
        }

        public void CheckRequireCodeOptionsAndSave(bool checkBoxValue, string creditType, ExtentTest test)
        {
            if (creditType.ToLowerInvariant().Equals("limit"))
            {
                _checkBoxValueLimit.SetCheckboxStateWithLabel(null, checkBoxValue);
                test.Info("Check Require Code Limit Options");
            }
            else if (creditType.ToLowerInvariant().Equals("rating"))
            {
                _checkBoxValueRating.SetCheckboxStateWithLabel(null, checkBoxValue);
                test.Info("Check Require Code Rating Options");
                WaitForFormLoadingOverlay();
            }
            else
            {
                throw new NotFoundException("Option not found.");
            }
        }

        public void AddChangeReasonCodesWithoutRequiredValue(string creditType, ExtentTest test)
        {
            if (creditType.ToLowerInvariant().Equals("limit"))
            {
                AddCodeLimit();
                WaitForFormLoadingOverlay();
                test.Info("Click add button Limit");

            }
            else if (creditType.ToLowerInvariant().Equals("rating"))
            {
                AddCodeRating();
                _codeRating.WaitUntilElementIsInteractable();
                test.Info("Click add button Rating");
            }
            else
            {
                throw new NotFoundException("Option not found.");
            }

        }

        public string GetCredLimitChangeError
        {
            get { return Settings.EnCompassWebDriver.WaitForVisible(By.XPath(LIMIT_CHANGE_ERROR_MESSAGE)).Text; }
        }

        public string GetCredRangeChangeError
        {
            get { return Settings.EnCompassWebDriver.WaitForVisible(By.XPath(RATING_CHANGE_ERROR_MESSAGE)).Text; }
        }

    }
}
