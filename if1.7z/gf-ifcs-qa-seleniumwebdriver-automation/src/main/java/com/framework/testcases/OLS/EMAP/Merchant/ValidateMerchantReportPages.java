package com.framework.testcases.OLS.EMAP.Merchant;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;


import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.common.Common;
import com.framework.pages.BP.BPHomePage;
import com.framework.pages.CHEV.CHContactListPage;
import com.framework.pages.CHEV.CHHomePage;
import com.framework.pages.CHEV.CHStoredReportsPage;
import com.framework.pages.EMAP.EMAPHomePage;
import com.framework.pages.EMAP.EMAPReportsPage;
import com.framework.pages.OLS.common.LoginPage;
import com.framework.pages.OLS.common.MerchantReportsPage;

public class ValidateMerchantReportPages extends BaseTest {
	
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "Smoke", "Regression","BusinessFlow" })
	public void validate_Invoice_Report_Page(@Optional("TH") String clientCountry, @Optional("EMAP") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  TST-SC-101-OLS - Verify the Stored Reports",
				"Validate stored reports page for read-only, read/write and view-only");
		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		EMAPHomePage emapHomePage = new EMAPHomePage(driver, test);
		EMAPReportsPage reportsPage = new EMAPReportsPage(driver, test);
		MerchantReportsPage merchantReportsPage = new MerchantReportsPage(driver, test);
		// Creating Objects for the Pages
		loginPage.Login("EMAP_URL", "EMAP_UN_ReadWrite_Customer_" + clientCountry,
				"EMAP_PWD_ReadWrite_Customer_" + clientCountry, clientName);

		// Reports - Stored Reports
		emapHomePage.clickStoredReportsAndValidatePage();
		reportsPage.validateTheReportsPageFilterOptions();
		reportsPage.checkThePresenceOfExportAndSearchOptions();
		reportsPage.selectInvoiceReport("Card Transaction Invoice Report");
		merchantReportsPage.clickInvoiceReportExportLinkBtn("tableStoredRepList");
		
		loginPage.Logout();
   	}
	
	
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "Smoke", "Regression","BusinessFlow" })
	public void validateContactsExport(@Optional("SG") String clientCountry, @Optional("EMAP") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  Emap  Customer  Report Page", "Checking the Invoice Report Pages");

		// Creating Objects for the Login Pages
		LoginPage loginPage = new LoginPage(driver, test);
		
		CHHomePage chHomePage = new CHHomePage(driver, test);
		CHContactListPage chContactListPage = new CHContactListPage(driver, test);
		CHStoredReportsPage chStoredReportsPage = new CHStoredReportsPage(driver, test);
		loginPage.Login("EMAP_URL", "EMAP_UN_ReadWrite_Customer_" + clientCountry,
				"EMAP_PWD_ReadWrite_Customer_" + clientCountry, clientName);
		chHomePage.loadFindAndContactsPage();
		chContactListPage.verifyContactListPage();
		chContactListPage.verifyContactTableColumns();
		chContactListPage.verifyAddContactAndExportButton();
		chContactListPage.clickExportButton();
		
		//chStoredReportsPage.VerifystoreReports();
		
		chHomePage.clickOnHome();

		loginPage.Logout();
   	}
}
