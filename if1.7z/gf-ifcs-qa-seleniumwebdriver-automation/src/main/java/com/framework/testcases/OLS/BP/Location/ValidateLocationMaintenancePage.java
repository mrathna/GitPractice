package com.framework.testcases.OLS.BP.Location;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.BP.BPHomePage;
import com.framework.pages.BP.BPLocationPage;
import com.framework.pages.OLS.HomePage;
import com.framework.pages.OLS.common.LoginPage;

public class ValidateLocationMaintenancePage extends BaseTest {
	@Parameters({"clientCountry", "clientName"})
	@Test( groups = { "Smoke", "Regression" })
	public void Customer_Vehicle_Page_Validations(@Optional("AU") String clientCountry, @Optional("BP") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  BP Location Maintenance Page test cases",
				"Logging in to BP Online, Validate Location maintenance page test cases");
		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		BPHomePage bpHomePage = new BPHomePage(driver, test);
		HomePage homePage = new HomePage(driver, test);
		BPLocationPage bpLocPage = new BPLocationPage(driver, test);
		// Calling Functions
		loginPage.Login("BP_URL", "BP_UN_Location_" + clientCountry, "BP_PWD_Location_" + clientCountry, clientName);
		bpHomePage.ValidateBPLocOrMerchantLogo(clientCountry);
		bpHomePage.ValidateMerchantLocWelcomeText(clientCountry);
		homePage.HomePageValidation();
		bpLocPage.clickLocationSubMenuAndValidatePage();
		bpLocPage.getAccountDetailsAndValidate();
		bpLocPage.updateLocationDetailsForAccount(clientCountry);
		bpLocPage.saveDetailsAndValidate();
		
		loginPage.Logout();
	
	}

}
