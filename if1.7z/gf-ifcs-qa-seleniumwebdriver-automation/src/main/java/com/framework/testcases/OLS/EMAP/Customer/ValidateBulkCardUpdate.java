package com.framework.testcases.OLS.EMAP.Customer;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.EMAP.EMAPCardsPage;
import com.framework.pages.EMAP.EMAPHomePage;
import com.framework.pages.OLS.common.BulkOrderAndUpdatePage;
import com.framework.pages.OLS.common.CommonPage;
import com.framework.pages.OLS.common.LoginPage;

public class ValidateBulkCardUpdate extends BaseTest {
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "Regression" })
	public void validateBulkCardUpdate(@Optional("SP") String clientCountry, @Optional("EMAP") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  TST-SC-17 - OLS - Bulk Card Update",
				"Validate bulk card update page for read-only, read/write and view-only");
		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		EMAPHomePage emapHomePage = new EMAPHomePage(driver, test);
		EMAPCardsPage emapCardsPage = new EMAPCardsPage(driver, test);
		BulkOrderAndUpdatePage bulkOrderAndUpdatePage = new BulkOrderAndUpdatePage(driver, test);
		CommonPage commonPage = new CommonPage(driver, test);

		loginPage.Login("EMAP_URL", "EMAP_UN_ReadWrite_Customer_" + clientCountry,
				"EMAP_PWD_ReadWrite_Customer_" + clientCountry, clientName);

		// Bulk Card Update
		emapHomePage.clickBulkCardUpdateAndValidatePage();
		// emapCardsPage.checkThePresenceOfBulkCardUpdateDownloadAndUpload();
		// Card options check
		commonPage.selectAllAccountOptionFromAccountDropdown();
		emapCardsPage.clickSearchButtonInBulkCard();

		emapCardsPage.clickDownloadBulkCardUpdate();
		commonPage.isFileDownloaded("Bulk_Update_");

		// Need to update - Upload with Sikuli - Script
		// Click Upload Option
		emapCardsPage.clickUploadBulkCardUpload();
		
		// // Upload The File From the Local
		bulkOrderAndUpdatePage.uploadTheExcelSheetFromTheLocal("Bulk_Update");
		//
		// // Click On Upload Bulk Card Update
		bulkOrderAndUpdatePage.clickOnUploadBulkCardUpdate();
		//
		// // Check the Bulk Card Update Success Message
		//emapCardsPage.checkFileUploadedPopup();
		if(clientCountry.equals("SP") || clientCountry.equals("SG")) {
		emapCardsPage.clickClosePopupAndVerifyBulkCardMessage();
		}
		loginPage.Logout();
	}
}
