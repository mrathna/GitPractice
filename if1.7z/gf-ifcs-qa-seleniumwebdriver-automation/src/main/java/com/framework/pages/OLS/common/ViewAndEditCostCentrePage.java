package com.framework.pages.OLS.common;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.ExtentTest;
import com.framework.basepage.BasePage;
import com.framework.repo.Locator;

public class ViewAndEditCostCentrePage extends BasePage {

	CostCentrePage bpCreateCostCentrePage = new CostCentrePage(driver, test);

	// Added by Meenakshi Sundaram 30/04/2018
	@FindBy(how = How.XPATH, using = Locator.VIEW_AND_EDIT_COST_CENTRE_PAGE)
	public WebElement viewEditCostCentrePage;
	@FindBy(how = How.ID, using = Locator.ADD_COST_CENTRE_BUTTON)
	public WebElement addCostCentreButton;
	@FindBy(how = How.ID, using = Locator.ACCOUNT_AT_FIND_COST_CENTRE)
	public WebElement selectAccountFromFindCostCentre;
	@FindBy(how = How.CSS, using = Locator.ACCOUNT_DROP_DOWN_LIST_AT_FIND_COST_CENTRE)
	public List<WebElement> selectAccountDropDownListFromFindCostCentre;
	@FindBy(how = How.CSS, using = Locator.SEARCH_FOR_COST_CENTRE_BUTTON)
	public WebElement searchForCostCentreBtn;
	@FindBy(how = How.ID, using = Locator.COST_CENTRE_RECORDS)
	public WebElement costCentreRecordsDisplayed;
	@FindBy(how = How.ID, using = Locator.COST_CENTRE_NAME_IN_FIND_COST_CENTRE)
	public WebElement enterCostCentreName;
	@FindBy(how = How.ID, using = Locator.DESCRIPTION_COMMON)
	public WebElement enterCostCentreDesc;
	@FindBy(how = How.CSS, using = Locator.TABLE_COST_CENTRE_LIST)
	public WebElement tableCostCentreList;
	@FindBy(how = How.CSS, using = Locator.EDIT_DETAILS_LINK_BUTTON)
	public WebElement editDetailsLinkBtn;
	@FindBy(how = How.XPATH, using = Locator.EDIT_COST_CENTRE_PAGE)
	public WebElement editCostCentrePage;

	public ViewAndEditCostCentrePage(WebDriver driver, ExtentTest test) {
		super(driver, test);
		PageFactory.initElements(driver, this);
	}

	public void validateViewEditCostCentrePage() {
		isDisplayed(viewEditCostCentrePage, "View & Edit Cost Center Page");
	}

	public void clickAddCostCentreButton() {
		isDisplayedThenClick(addCostCentreButton, "Add Cost Center");
	}

	public void selectAccountFromFindCostCentre(String accountNumber) {

		if (selectAccountFromFindCostCentre.isDisplayed()) {
			actionClick(selectAccountFromFindCostCentre);
			int isize = selectAccountDropDownListFromFindCostCentre.size();
			System.out.println("Size of Dropdown" + isize);
			for (int i = 0; i < isize; i++) {
				String accountSelected = selectAccountDropDownListFromFindCostCentre.get(i).getText();
				System.out.println("accountname:::::" + accountSelected);
				System.out.println("Homepage accountname:::::" + accountNumber.trim());
				if (accountSelected.contains(accountNumber.trim())) {
					selectDropDownByVisibleText(selectAccountFromFindCostCentre, accountSelected);
					logPass("Clicked on selected account");
					break;

				}
			}
		} else {
			logFail("Account dropdown is Not Displayed");
		}
	}

	public void clickSearchForCostCentreButton() {
		isDisplayedThenActionClick(searchForCostCentreBtn, "Search Cost Center");
	}

	public void validateCostCentreRecordsDisplayed() {
		isDisplayed(costCentreRecordsDisplayed, "Cost Centre Records");
	}

	public void enterCostCentreNameEditPage(String costCenterName) {
		sleep(5);
		isDisplayedThenEnterText(enterCostCentreName, "Cost Center", costCenterName);
		// if (enterCostCentreName.isDisplayed()) {
		// actionClick(enterCostCentreName);
		// enterCostCentreName.sendKeys(costCenterName);
		// logPass("Clicked on Cost Centre and enter name");
		// } else {
		// logFail("Enter Cost Centre Button is Not Displayed");
		// }
	}

	public void clearCostCentreName() {
		if (enterCostCentreName.isDisplayed()) {
			actionClick(enterCostCentreName);
			enterCostCentreName.clear();
			logPass("Clicked on Cost Centre and clear name");
		} else {
			logFail("Enter Cost Centre Button is Not Displayed");
		}
	}

	public void enterCostCentreDesc() throws Exception {
		isDisplayedThenEnterText(enterCostCentreDesc, "Cost Center Desc",
				bpCreateCostCentrePage.getCostCentreDescription());
	}

	public void selectFirstRowFromFindCostCentreTable() {
		scrollDownPage();
		sleep(5);
		isDisplayedThenActionClick(tableCostCentreList, "Cost Center List");

	}

	public void clickEditDetails() {
		isDisplayedThenActionClick(editDetailsLinkBtn, "Edit Details Link Button");
		waitForPageLoad(3);
		// if (editDetailsLinkBtn.isDisplayed()) {
		// actionClick(editDetailsLinkBtn);
		// waitForPageLoad(3);
		// logPass("Clicked on Edit Details LinkButton");
		// } else {
		// logFail("Edit Details Link Button is Not Displayed");
		// }
	}

	public void validateEditCostCentrePage() {
		verifyText(editCostCentrePage, "Cost Centre Details");
	}

}
