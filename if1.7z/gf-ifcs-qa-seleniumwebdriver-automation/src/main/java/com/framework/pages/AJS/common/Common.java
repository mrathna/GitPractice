package com.framework.pages.AJS.common;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.math.RoundingMode;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.Set;
import java.util.TimeZone;

import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.PropertiesConfiguration;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDDocumentCatalog;
import org.apache.pdfbox.pdmodel.interactive.form.PDAcroForm;
import org.apache.pdfbox.pdmodel.interactive.form.PDField;
import org.apache.pdfbox.text.PDFTextStripper;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Row;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

import com.aventstack.extentreports.ExtentTest;
import com.framework.basepage.BasePage;
import com.framework.main.InitExecution;
import com.framework.pages.AJS.MaintainCustomerPage;
import com.framework.repo.Locator_IFCS;
import com.framework.util.Constants;
import com.framework.util.PropUtils;
import com.framework.util.SeleniumWrappers;

public class Common extends BasePage {

	private String changedFormat = "";
	private boolean isDateUpdated = false;

	@FindBy(xpath = Locator_IFCS.TORCH_SEARCH)
	public WebElement torchSearch;

	@FindBy(xpath = Locator_IFCS.TORCH_FINDS_RECORD)
	public WebElement findAndRecord;

	@FindBy(xpath = Locator_IFCS.FINDRECORD_CLOSE)
	public WebElement findRecordClose;

	@FindBy(xpath = Locator_IFCS.TORCH_SEARCH_LIST)
	public WebElement searchList;

	@FindBy(xpath = Locator_IFCS.DETAIL_SEARCH)
	public WebElement detailSearch;

	@FindBy(xpath = Locator_IFCS.TASKBAR_SUBMIT)
	public WebElement taskbarSubmit;

	@FindBy(xpath = Locator_IFCS.POPUP_MENUITEM_ADD)
	public WebElement popupMenuItemAdd;

	@FindBy(xpath = Locator_IFCS.POPUP_MENUITEM_CSVExport)
	public WebElement popupMenuCSVExport;

	@FindBy(xpath = Locator_IFCS.POPUP_MENUITEM_DELETE)
	public WebElement popupMenuItemDelete;

	@FindBy(xpath = Locator_IFCS.COMMON_MAIN_FRAME)
	public List<WebElement> mainFrameTitleBar;

	@FindBy(xpath = Locator_IFCS.POPUP_MENUITEM_ADD_CUSTOMER)
	public WebElement popupMenuItemAddCustomer;

	@FindBy(xpath = Locator_IFCS.POPUP_MENUITEM_SETDEFAULT)
	public WebElement popupMenuItemsetDefault;

	@FindBy(xpath = Locator_IFCS.SAVE_ICON)
	public WebElement saveIcon;

	@FindBy(xpath = Locator_IFCS.POPUP_MENUITEM_DETAILS)
	public WebElement poupMenuItemDetails;
	
	@FindBy(xpath = Locator_IFCS.POPUP_MENUITEM_SORT)
	public WebElement popupMenuItemSort;

	@FindBy(xpath = Locator_IFCS.APPROVE_ICON)
	public WebElement approveIcon;

	@FindBy(xpath = Locator_IFCS.VALIDATE_ICON)
	public WebElement validateIcon;

	@FindBy(xpath = Locator_IFCS.YES_BUTTON)
	public WebElement yesButton;

	@FindBy(xpath = Locator_IFCS.NO_BUTTON)
	public WebElement noButton;

	@FindBy(xpath = Locator_IFCS.OK_BUTTON)
	public WebElement okButton;
	@FindBy(xpath = Locator_IFCS.IFCS_DATE)
	public WebElement ifcsDate;

	@FindBy(xpath = Locator_IFCS.BOTTOM_LEFT_TEXT)
	public WebElement bottomLeftText;

	@FindBy(xpath = Locator_IFCS.SEARCH_RESULTS_TABLE)
	public List<WebElement> cardsTable;

	@FindBy(xpath = Locator_IFCS.REBATES_PROFILE_TABLE)
	public List<WebElement> rebateProfilesTable;
	
	@FindBy(xpath = Locator_IFCS.REBATES_PROFILE_TABLE)
	public WebElement profilesTable;

	@FindBy(xpath = Locator_IFCS.CARDS_TABLE_HEADER)
	public List<WebElement> cardsTableHeaders;

	@FindBy(xpath = Locator_IFCS.SEARCH_CARDS_TEXTBOX)
	public List<WebElement> textBoxes;

	@FindBy(xpath = Locator_IFCS.VALIDATE_ICON)
	public WebElement validateTaskBar;

	@FindBy(xpath = Locator_IFCS.CREATE_TASKBAR)
	public WebElement createTaskBar;

	@FindBy(xpath = Locator_IFCS.CANCEL_BUTTON)
	public WebElement cancelButton;

	@FindBy(xpath = Locator_IFCS.POST_TRANSACTION)
	public WebElement postTransaction;

	@FindBy(xpath = Locator_IFCS.CARD_REQUEST)
	public WebElement cardRequest;

	@FindBy(xpath = Locator_IFCS.POP_UP_MSG)
	public WebElement popUpMsg;

	@FindBy(xpath = Locator_IFCS.POP_UP_MSG_OK)
	public WebElement popUpOkBtn;

	@FindBy(xpath = Locator_IFCS.POPUP_MENUITEM_SELECT_PROFILE)
	public WebElement selectProfile;

	@FindBy(xpath = Locator_IFCS.POPUP_MENUITEM_CREATE_PRIVATE_PROFILE)
	public WebElement createPrivateProfile;

	@FindBy(xpath = Locator_IFCS.POPUP_MENUITEM_DELETE_PRIVATE_PROFILE)
	public WebElement deletePrivateProfile;
	@FindBy(xpath = Locator_IFCS.SECOND_POPUP_OK_BUTTON)
	public WebElement secondPopupOKButton;

	@FindBy(xpath = Locator_IFCS.CLOSE_BUTTON)
	public WebElement closeButton;

	@FindBy(xpath = Locator_IFCS.POPUP_MENUITEM_OPT_IN_OUT)
	public WebElement poupMenuOptInOut;

	@FindBy(xpath = Locator_IFCS.CLEAR_FORM)
	public WebElement clearForm;

	@FindBy(xpath = Locator_IFCS.DELETE_TRANSACTION)
	public WebElement deleteTransaction;

	@FindBy(xpath = Locator_IFCS.POPUP_DELETE_TRANSACTION)
	public WebElement deleteTransactionInPopup;
	@FindBy(xpath = Locator_IFCS.ADD_LOACTION_IN_POPUP)
	public WebElement addLocationInPopUP;
	@FindBy(xpath = Locator_IFCS.MANUAL_TRANSACTION_VALIDATE_ICON)
	public WebElement validateManualTransactionIcon;

	@FindBy(xpath = Locator_IFCS.POPUP_FORCE_POST_TRANSACTION)
	public WebElement forcePostTransaction;
	@FindBy(xpath = Locator_IFCS.POPUP_MENUITEM_SORTDESC)
	public WebElement popupMenuSortDesc;

	@FindBy(xpath = Locator_IFCS.POPUP_MENUITEM_ADD_CARDTRANSFER)
	public WebElement popupMenuItemAddCardTransfer;
	// Added by sowmiya

	@FindBy(xpath = Locator_IFCS.READ_NEXT_IN_TRANSACTION)
	public WebElement readNextInTransaction;
	@FindBy(xpath = Locator_IFCS.CLONE_RECORD)
	public WebElement cloneRecord;
	@FindBy(xpath = Locator_IFCS.CLONE_FORM)
	public WebElement cloneForm;

	@FindBy(xpath = Locator_IFCS.POPUP_POST_TRANSACTION)
	public WebElement postTransactionInPopup;
	@FindBy(xpath = Locator_IFCS.APPLY_ALL_CARDS_ICON)
	public WebElement applyAllCards;

	@FindBy(xpath = Locator_IFCS.IFCS_BACK_BUTTON)
	public WebElement backIcon;

	@FindBy(xpath = Locator_IFCS.YES_POPUP)
	public WebElement yesPopup;
	@FindBy(xpath = Locator_IFCS.REPLACED_CARD)
	public WebElement replaceCard;
	@FindBy(xpath = Locator_IFCS.PREVIOUS_CARD)
	public WebElement previousCard;

	@FindBy(xpath = Locator_IFCS.VALIDATION_RESULT)
	public WebElement validationResult;

	@FindBy(xpath = Locator_IFCS.INTERFACES)
	public WebElement interfaces;

	@FindBy(xpath = Locator_IFCS.JOB_EXECUTION)
	public WebElement executejob;

	@FindBy(xpath = Locator_IFCS.INCOMING_INTERFACES)
	public WebElement incominginterfaces;

	@FindBy(xpath = Locator_IFCS.OUTGOING_INTERFACES)
	public WebElement outgoinginterfaces;

	@FindBy(xpath = Locator_IFCS.CARDS_TABLE_HEADER)
	public List<WebElement> headerRender;

	@FindBy(xpath = Locator_IFCS.REFERENCE_TEXT_BOX)
	public WebElement transRef;

	@FindBy(xpath = Locator_IFCS.CUS_TAX_TOTAL_TEXT_BOX)
	public WebElement cusTaxTotal;

	@FindBy(xpath = Locator_IFCS.MERC_TAX_TOTAL_TEXT_BOX)
	public WebElement mercTaxTotal;

	@FindBy(xpath = Locator_IFCS.CUS_VALUE_TEXT_BOX)
	public WebElement cusValue;

	@FindBy(xpath = Locator_IFCS.MERC_VALUE_TEXT_BOX)
	public WebElement mercValue;

	@FindBy(xpath = Locator_IFCS.CLIENT_DROPDWON)
	public WebElement clientDropdown;

	@FindBy(xpath = Locator_IFCS.SELECT_CLIENT_AS_Z)
	public WebElement selectClient;

	@FindBy(xpath = Locator_IFCS.ADJUSTMENT_TYPE)
	public WebElement adjustmentTypeDropdown;

	@FindBy(xpath = Locator_IFCS.EXPORT_REPORT_BUTTON)
	public WebElement exportReportButton;
	@FindBy(xpath=Locator_IFCS.DISPUTE_TRANSACTION)
	public WebElement disputeTransaction;



	/*
	 * @FindBy(xpath = Locator_IFCS.POPUP_MENUITEM_DETAILS) public WebElement
	 * poupMenuItemDetails;
	 */
	private String cardNumberValue, driverNameValue, costCenterValue, VRNValue, VehicleDescriptionValue, VehicleIdValue,
			DriverIdValue, referenceValue, customerNumberValue, remittanceIDValue, billingNodeAccount,
			hierarchyCustomerNoHasTwoCards;

	String CurrentDBDate;

	public Common(WebDriver driver, ExtentTest test) {
		super(driver, test);
		PageFactory.initElements(new AjaxElementLocatorFactory(driver, 15), this);

	}

	public void searchTorch() {
		waitForElementTobeClickable(torchSearch, 20);
		// isDisplayedThenClick(torchSearch,"Clicked Search icon");
		torchSearch.click();
	}

	public void findRecordTorch() {
		for (int i = 0; i < 3; i++) {
			isDisplayedThenClick(findAndRecord, "Clicked Find and Record icon");
		}

	}

	public void closeFindRecordTorch() {
		waitForElementTobeClickable(findRecordClose, 10);
		isDisplayedThenClick(findRecordClose, "close the Find Record");
	}

	public void searchListTorch() {
		waitForElementTobeClickable(searchList, 10);
		isDisplayedThenClick(searchList, "Search list torch");
	}

	public void detailSearch() {
		waitForElementTobeClickable(detailSearch, 10);
		// isDisplayedThenClick(detailSearch,"Clicked Detail Search icon");
		isDisplayedThenClick(detailSearch, "Detail search");

	}

	public void clickAddLocationInPopUp() {
		waitForElementTobeClickable(addLocationInPopUP, 10);
		isDisplayedThenClick(addLocationInPopUP, "Add Location");
	}

	public void clearForm() {
		waitForElementTobeClickable(clearForm, 10);
		// isDisplayedThenClick(detailSearch,"Clicked Detail Search icon");
		isDisplayedThenClick(clearForm, "Clear Form");
		sleep(2);

	}

	public void taskbarSubmit() {
		waitForElementTobeClickable(taskbarSubmit, 10);
		// isDisplayedThenClick(detailSearch,"Clicked Detail Search icon");
		isDisplayedThenClick(taskbarSubmit, "taskbarSubmit");
	}

	public void clickCancelButton() {
		waitForElementTobeClickable(cancelButton, 10);
		isDisplayedThenClick(cancelButton, "Cancel Button");
	}

	public void addIteminPopup() {
		waitForElementTobeClickable(popupMenuItemAdd, 10);
		isDisplayedThenClick(popupMenuItemAdd, "Added item");
	}

	public void addCardTransferRequestPopup() {
		waitForElementTobeClickable(popupMenuItemAddCardTransfer, 10);
		isDisplayedThenClick(popupMenuItemAddCardTransfer, "Added Card Transfer Request item");
	}

	public void deleteIteminPopup() {
		waitForElementTobeClickable(popupMenuItemDelete, 10);
		isDisplayedThenClick(popupMenuItemDelete, "Delete item");
	}

	public void clickAddCustomerOptionInPopup() {
		waitForElementTobeClickable(popupMenuItemAddCustomer, 10);
		isDisplayedThenClick(popupMenuItemAddCustomer, "Add customer option");
	}

	public void setDefaultIteminPopup() {
		waitForElementTobeClickable(popupMenuItemsetDefault, 10);
		isDisplayedThenClick(popupMenuItemsetDefault, "Added item");
	}

	public void detailsIteminPopup() {
		waitForElementTobeClickable(poupMenuItemDetails, 10);
		isDisplayedThenClick(poupMenuItemDetails, "Details item");
	}

	public void clickApproveIcon() {
		waitForElementTobeClickable(approveIcon, 10);
		isDisplayedThenClick(approveIcon, "Approve icon");
	}

	public void clickCSVExportInPopup() {
		waitForElementTobeClickable(popupMenuCSVExport, 10);
		isDisplayedThenClick(popupMenuCSVExport, "CSV Export");
	}
	
	public void clickSortDescription() {
		waitForElementTobeClickable(popupMenuSortDesc, 10);
		isDisplayedThenClick(popupMenuSortDesc, "Sort");
	}

	public void clickReadNextButton() {

		waitForElementTobeClickable(readNextInTransaction, 10);
		isDisplayedThenClick(readNextInTransaction, "Read Next Transaction");

	}

	public void clickReplaceCardButton() {
		waitForElementTobeClickable(replaceCard, 10);
		isDisplayedThenClick(replaceCard, "Replace Card Button");

	}

	public void clickPreviousCardButton() {
		waitForElementTobeClickable(previousCard, 10);
		isDisplayedThenClick(previousCard, "Previous Card Button");

	}

	public void clickCloneIcon() {
		waitForElementTobeClickable(cloneForm, 20);
		isDisplayedThenClick(cloneForm, "Clicked Clone icon");

	}

	public String getCurrentIFCSDate(String userName) {
		WebElement ifcsDate = driver.findElement(
				By.xpath("//div[@class='JPanel']/div[@class='ExtLabel']/div[@class='htmlString'][contains(text(),'"
						+ PropUtils.getPropValue(configProp, userName) + "')]"));
		System.out.println("Split" + getText(ifcsDate));
		// System.out.println("Split" + getText(ifcsDate.get(0)).split("-")[2]);
		return getText(ifcsDate).split("-")[2];
	}

	/*
	 * public void checkRecordSaved() { verifyText(bottomLeftText,
	 * "Record saved OK"); }
	 */
	public void clearingAllTextBoxes(List<WebElement> allTextboxes) {
		for (WebElement textbox : allTextboxes) {
			textbox.clear();
		}
	}

	public void clickSaveIcon() {
		waitForElementTobeClickable(saveIcon, 30);
		isDisplayedThenClick(saveIcon, "Save Icon");
	}
	
	public void clickDisputeIcon() {
		waitForElementTobeClickable(disputeTransaction, 30);
		isDisplayedThenClick(disputeTransaction, "Dispute Icon");
	}

	public void clickYesButton() {
		// waitForElementTobeClickable(yesButton, 10);
		try {
			yesButton.isDisplayed();
			yesButton.click();
		} catch (Exception ex) {
			logInfo("Yes button not present");
		}

	}

	public void clickYesButtonInPopup() {
		waitForElementTobeClickable(yesPopup, 30);
		isDisplayedThenClick(yesPopup, "Yes Popup Button");
	}

	public void clickNoButton() {
		waitForElementTobeClickable(noButton, 10);
		isDisplayedThenClick(noButton, "No Button");
	}

	public void clickOkButton() {
		waitForElementTobeClickable(okButton, 10);
		isDisplayedThenClick(okButton, "Ok Button");

	}

	public void messagePopUpHandle() {
		// isDisplayed(popUpMsg, "Message Pop up");
		isDisplayedThenActionClick(popUpOkBtn, "OK button");
	}

	public void clickSecondPopupOkButton() {
		waitForElementTobeClickable(secondPopupOKButton, 10);
		isDisplayedThenClick(secondPopupOKButton, "Second Popup Ok Button");
	}

	public void clickValidateIcon() {

		waitForElementTobeClickable(validateIcon, 10);
		isDisplayedThenClick(validateIcon, "validation Icon");
	}

	public void clickValidateManualTransactionIcon() {

		waitForElementTobeClickable(validateManualTransactionIcon, 10);
		isDisplayedThenClick(validateManualTransactionIcon, "validation Icon");
	}

	public void clickPopupForcePostTransactionIcon() {

		waitForElementTobeClickable(forcePostTransaction, 10);
		isDisplayedThenClick(forcePostTransaction, "validation Icon");
	}

	public void clickPostTransaction() {
		waitForElementTobeClickable(postTransaction, 10);
		isDisplayedThenClick(postTransaction, "Post Transaction Icon");
	}

	public void clickCardRequest() {
		waitForElementTobeClickable(cardRequest, 30);
		isDisplayedThenClick(cardRequest, "Card Request Icon");
	}

	public void clickDeleteTransaction() {
		waitForElementTobeClickable(deleteTransaction, 10);
		isDisplayedThenClick(deleteTransaction, "Delete Transaction Icon");
	}

	public void clickDeleteTransactionInPopup() {
		waitForElementTobeClickable(deleteTransactionInPopup, 10);
		isDisplayedThenClick(deleteTransactionInPopup, "Delete Transaction Icon In popup ");
	}

	public void clickApplyAllCardsIcon() {
		waitForElementTobeClickable(applyAllCards, 30);
		isDisplayedThenClick(applyAllCards, "Apply All Cards Icon");
	}

	public void clickBackIcon() {
		waitForElementTobeClickable(backIcon, 30);
		isDisplayedThenClick(backIcon, "Back Icon");
	}

	public void chooseCardNo(String cardNo) {
		chooseSubMenuFromLeftPanel("Card Details", "Card Maintenance");
		chooseCardNoAndSearch(cardNo);
		/*searchTorch();
		chooseOptionFromComboPopup("Card Number", cardNo);
		findRecordTorch();
		sleep(5);
		closeFindRecordTorch();*/
	}

	// Prakalpha -->checkBox
	public void checkBoxForMonthAndYear(String seperatorLabelName, int num) {
		String seperator = " ";
		WebElement chechBoxElement;
		String checkBoxIsSelectedOrNot;
		try {
			seperator = splitStringAndGenerateXpath(seperatorLabelName);
			try {
				checkBoxIsSelectedOrNot = driver
						.findElement(By.xpath("//div[@class='JFALSeparator']//div[" + seperator
								+ "]/preceding::div[@class='JFALCompControlPanel'][" + num
								+ "]//div[@class='JFALCheckBox enabled']/child::div//div"))
						.getCssValue("border-right-color");
			} catch (Exception e) {
				checkBoxIsSelectedOrNot = null;
			}
			if (checkBoxIsSelectedOrNot == null) {
				logInfo("CheckBox is not Selected");
				chechBoxElement = driver.findElement(By.xpath("//div[@class='JFALSeparator']//div[" + seperator
						+ "]/preceding::div[@class='JFALCompControlPanel'][" + num
						+ "]//div[@class='JFALCheckBox enabled']"));
				chechBoxElement.click();
				logPass("checkBox is Selected");
			} else {
				logInfo("Check Box is already Selected");
			}
		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
	}

	public void checkBoxForApplication(String labelname) {
		String seperator = " ";
		WebElement chechBoxElement;
		String checkBoxIsSelectedOrNot;
		try {
			seperator = splitStringAndGenerateXpath(labelname);
			try {
				checkBoxIsSelectedOrNot = driver.findElement(By.xpath("//div[" + seperator
						+ "]/preceding::div[@class='JFALCompControlPanel']//div[@class='JFALCheckBox enabled']/child::div//div"))
						.getCssValue("border-right-color");
			} catch (Exception e) {
				checkBoxIsSelectedOrNot = null;
			}
			if (checkBoxIsSelectedOrNot == null) {
				logInfo("CheckBox is not Selected");
				chechBoxElement = driver.findElement(By.xpath("//div[@class='JFALLabel']//div[" + seperator
						+ "]/preceding::div[@class='JFALCompControlPanel'][1]//div[@class='JFALCheckBox enabled']"));
				chechBoxElement.click();
				logPass("checkBox is Selected");
			} else {
				logInfo("Check Box is already Selected");
			}
		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
	}

	public void checkBoxForApplicationDummy(String labelname) {
		try {
			labelname = splitStringAndGenerateXpath(labelname);
			driver.findElement(By.xpath("//div[" + labelname
					+ "]/preceding::div[@class='JFALCompControlPanel'][1]//div[@class='JFALCheckBox enabled']/child::div//div"));
			logInfo("Check Box :" + labelname + "is already choosen");
		} catch (Exception ex) {
			isDisplayedThenClick(driver.findElement(By.xpath("//div[" + labelname
					+ "]/preceding::div[@class='JFALCompControlPanel'][1]//div[@class='JFALCheckBox enabled']")),
					"Check box");
		}

	}

	public void verifyContainsInBottomLeftMessage(String expectedMsg) {
		if (getText(bottomLeftText).contains(expectedMsg)) {
			logPass("Bottom left text contains :" + expectedMsg);
		} else {
			logFail("Bottom left text not contains  :" + expectedMsg);
		}
	}

	public void checkRecordSaved() {
		sleep(5);
		// verifyText(bottomLeftText, "Record saved OK");
		verifyValidationResult("Record saved OK");
	}

	// Added by sasi on 14-02-19
	public String getCustomerNoHavingCardsUsingCardType() {
		String clientCountry, cardType, clientName;
		String cardTypeDesc = "";
		String customerNo = "";
		clientName = PropUtils.getPropValue(configProp, "clientName");
		clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		if (clientName.equals("SHELL")) {
			cardType = PropUtils.getPropValue(configProp, "cardType");
			if (clientCountry.contains("MY")) {
				cardTypeDesc = "Shell Pre-Paid Card";
			} else if (cardType.contains("APA")) {
				cardTypeDesc = "Shell Pre-Paid Card (" + clientCountry + ")";
			} else {
				cardTypeDesc = "Shell Partner Card (" + clientCountry + ")";
			}

			String queryToGetCustomer = "Select distinct mcu.customer_no from m_customers mcu inner join card_programs cp on mcu.card_program_oid = cp.card_program_oid where mcu.customer_mid In (select customer_mid from cards) "
					+ " and cp.description = '" + cardTypeDesc + "' and Rownum <=1";
			customerNo = connectDBAndGetValue(queryToGetCustomer,
					PropUtils.getPropValue(configProp, "sqlODSServerName"));
		} else {

			cardTypeDesc = "cp.client_mid=(select Client_mid from m_clients where name ='"
					+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountry) + "')";
			String queryToGetCustomer = "Select distinct mcu.customer_no from m_customers mcu inner join card_programs cp on mcu.card_program_oid = cp.card_program_oid where mcu.customer_mid In (select customer_mid from cards) and "
					+ cardTypeDesc + " and Rownum <=1";
			customerNo = connectDBAndGetValue(queryToGetCustomer,
					PropUtils.getPropValue(configProp, "sqlODSServerName"));

		}

		System.out.println("customerNo:: " + customerNo);

		return customerNo;
	}

	public String getCustomerNoHavingCardsWithVehicleDetailsUsingCardType() {
		String clientCountry, cardType;
		String cardTypeDesc = "";
		clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		cardType = PropUtils.getPropValue(configProp, "cardType");
		if (clientCountry.contains("MY")) {
			cardTypeDesc = "Shell Pre-Paid Card";
		} else if (cardType.contains("APA")) {
			cardTypeDesc = "Shell Pre-Paid Card (" + clientCountry + ")";
		} else {
			cardTypeDesc = "Shell Partner Card (" + clientCountry + ")";
		}

		String queryToGetCustomer = "Select distinct mcu.customer_no from m_customers mcu inner join card_programs cp on mcu.card_program_oid = cp.card_program_oid where mcu.customer_mid In (select customer_mid from cards where vehicle_oid is not null) and cp.description = '"
				+ cardTypeDesc + "' and Rownum <=1";
		String customerNo = connectDBAndGetValue(queryToGetCustomer,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));

		System.out.println("customerNo:: " + customerNo);
		return customerNo;
	}

	/** Query methods for Getting Search data - Customer with Card **/
	public String getACustomerWithCard(String clientCountry) {
		String valueGot;
		String queryToGetCustomerNumberWithCards = "Select customer_no from m_customers where client_mid = (select client_mid from m_clients where name='"
				+ clientCountry + "') and customer_mid in (select customer_mid from cards) and Rownum <=1";
		valueGot = connectDBAndGetValue(queryToGetCustomerNumberWithCards,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		System.out.println("Value Got:: " + valueGot);
		return valueGot;
	}

	/**
	 * Query methods for Getting Search data - Card No, Driver Name, VRN, Fleet ID
	 **/

	/*
	 * String cardNumberValue, driverNameValue, costCenterValue, VRNValue,
	 * fleetIdValue, VehicleDescriptionValue, VehicleIdValue, DriverIdValue;
	 */
	public String getPartialValue(String fieldValue) {
		int fieldLength = fieldValue.length();
		if (fieldLength > 0) {
			fieldValue = fieldValue.substring(0, fieldLength / 2);
		}
		return fieldValue.concat("*");
	}

	// Added by Ayub 13-02-2019
	public String getLocationNoHasTransaction(String clientCountry) {
		String locationvalueGot;
		// clientCountry = clientCountry.substring(0, 1).toUpperCase() +
		// clientCountry.substring(1);
		System.out.println(
				"Client Country:" + clientCountry.toLowerCase().substring(0).toUpperCase() + "test :" + clientCountry);
		String queryToGetLocationNumberHasTransaction = "Select location_no from m_locations ml inner join transactions tr on ml.location_mid = tr.location_mid where ml.client_mid = (Select client_mid from m_clients where name ='"
				+ clientCountry + "') and rownum <= 1";
		locationvalueGot = connectDBAndGetValue(queryToGetLocationNumberHasTransaction,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		System.out.println("Value Got:: " + locationvalueGot);
		return locationvalueGot;
	}

	public String getLocationNoHasNoRelationship(String clientCountry) {
		String locationvalueGot;

		System.out.println(
				"Client Country:" + clientCountry.toLowerCase().substring(0).toUpperCase() + "test :" + clientCountry);
		String queryToGetLocationNumberHasTransaction = "select location_no from m_locations where location_mid not in (select member_oid from relationships) and client_mid = (Select client_mid from m_clients where name ='"
				+ clientCountry + "') and rownum <= 1";
		locationvalueGot = connectDBAndGetValue(queryToGetLocationNumberHasTransaction,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		System.out.println("Value Got:: " + locationvalueGot);
		return locationvalueGot;
	}

	public String getTransactionDateFromTheDB(String clientCountry) {
		String transactionDate = "";
		try {
			String queryToGetTransactionDate = "Select tr.processed_at from transactions tr inner join m_customers mcu  on mcu.customer_mid = tr.customer_mid  inner join m_clients mcl on mcu.client_mid = mcl.client_mid  inner join accounts a on mcu.customer_mid = a.customer_mid inner join card_programs cp on mcu.card_program_oid = cp.card_program_oid where mcu.client_mid =(Select client_mid from m_clients where name ='"
					+ clientCountry + "') and rownum <= 1";
			transactionDate = connectDBAndGetValue(queryToGetTransactionDate,
					PropUtils.getPropValue(configProp, "sqlODSServerName"));
			System.out.println("Value Got:: " + transactionDate);

			transactionDate = transactionDate.substring(0, 10);

			DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");

			System.out.println("Transaction Date is very first time" + transactionDate);

			Date date = (Date) formatter.parse(transactionDate);

			SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy");
			transactionDate = simpleDateFormat.format(date);
			transactionDate = transactionDate.replaceAll("-", "/");

			System.out.println(transactionDate);

		} catch (Exception e) {
			logFail(e.getMessage());
		}
		return transactionDate;
	}

	public String getStoredInvoiceDateFromTheDB() {
		String invoiceDate = "";
		String customerInvoiceType = "";
		String clientCountry, cardType;
		String cardTypeDesc = "";

		clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		cardType = PropUtils.getPropValue(configProp, "cardType");

		if (clientCountry.contains("MY")) {
			if (cardType.contains("APA")) {
				cardTypeDesc = "Shell Pre-Paid Card";
			}

		} else {

			if (cardType.contains("APA")) {
				cardTypeDesc = "Shell Pre-Paid Card (" + clientCountry + ")";
			} else {
				cardTypeDesc = "Shell Partner Card (" + clientCountry + ")";
			}
		}

		if (clientCountry.contains("MY")) {
			customerInvoiceType = "'APA Invoice - Customer-related Financial Transactions'";
		} else {
			customerInvoiceType = "'Customer Invoice by ICP'";
		}
		try {
			/*
			 * String queryToGetTransactionDate =
			 * "Select sr.created_on from stored_reports sr inner join m_customers mc on sr.member_oid = mc.customer_mid inner join card_programs cp on mc.card_program_oid = cp.card_program_oid where sr.report_type_oid = (Select report_type_oid from report_types rt inner join m_clients mcl on rt.client_mid = mcl.client_mid where rt.description ="
			 * + customerInvoiceType
			 * +"and rt.client_mid = (Select client_mid from m_clients mcl where mcl.name ='"
			 * + clientCountry + "')) and rownum <= 1";
			 */

			String queryToGetTransactionDate = "Select sr.created_on from stored_reports sr inner join m_customers mc on sr.member_oid = mc.customer_mid inner join card_programs cp on mc.card_program_oid = cp.card_program_oid where sr.report_type_oid = (Select report_type_oid from report_types rt inner join m_clients mcl on rt.client_mid = mcl.client_mid where rt.description ="
					+ customerInvoiceType + "and cp.description = '" + cardTypeDesc + "') and rownum <= 1";
			invoiceDate = connectDBAndGetValue(queryToGetTransactionDate,
					PropUtils.getPropValue(configProp, "sqlODSServerName"));
			System.out.println("Value Got:: " + invoiceDate);

			invoiceDate = invoiceDate.substring(0, 10);

			DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");

			System.out.println("Transaction Date is very first time" + invoiceDate);

			Date date = (Date) formatter.parse(invoiceDate);

			SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy");
			invoiceDate = simpleDateFormat.format(date);
			invoiceDate = invoiceDate.replaceAll("-", "/");

			System.out.println(invoiceDate);

		} catch (Exception e) {
			logFail(e.getMessage());
		}
		return invoiceDate;
	}

	/**
	 * Query methods for Getting Search data - Card No, Driver Name, VRN, Fleet ID
	 **/

	/*
	 * String cardNumberValue, driverNameValue, costCenterValue, VRNValue,
	 * fleetIdValue, VehicleDescriptionValue, VehicleIdValue, DriverIdValue,
	 * ReferenceValue, customerNumberValue, RemittanceIDValue, BillingNodeAccount;
	 */

	public void searchDriverNameAndValidate(String partialOrFullSearch) {
		String driverName = getSHELLCardDriverName();
		if (driverName.equals(" ") && driverName.equals("NULL")) {
			logForNoDataFound(this.getClass().getSimpleName(), "Need to Create A Customer With Driver Name and rerun");
		} else {
			clearingAllTextBoxes(textBoxes);
			boolean partialOrFull = true;
			if (partialOrFullSearch.equalsIgnoreCase("partial")) {
				driverNameValue = getPartialValue(driverNameValue);
				partialOrFull = false;
			}
			enterValueInTextBox("Filter By", "Driver Name", driverNameValue);
			searchListTorch();
			sleep(5);
			validateSearchTable("Driver Name", driverNameValue, partialOrFull);
		}
	}

	public void searchCardnumberAndValidate(String partialOrFullSearch, String seperatorLabelName) {
		// String cardNumber = getSHELLCardNumber();
		String cardNumber = getClientSpecificCardNumber();
		if (cardNumber.equals(" ") && cardNumber.equals("NULL")) {
			logForNoDataFound(this.getClass().getSimpleName(), "Need to Create A Customer With Card Number and rerun");
		} else {
			clearingAllTextBoxes(textBoxes);
			boolean partialOrFull = true;
			if (partialOrFullSearch.equalsIgnoreCase("partial")) {
				cardNumberValue = getPartialValue(cardNumberValue);
				partialOrFull = false;
			}
			enterValueInTextBox(seperatorLabelName, "Card Number", cardNumberValue);
			searchListTorch();
			sleep(5);
			validateSearchTable("Card Number", cardNumberValue, partialOrFull);
		}
	}

	public String getCardNumberWithCustomerNo(String customerWithCards) {
		String getCardNoForCustomer = "Select c.card_no from cards c inner join m_customers mc on c.customer_mid = mc.customer_mid INNER JOIN CARD_STATUS ON c.card_status_oid = CARD_STATUS.card_status_oid where mc.customer_no = '"
				+ customerWithCards + "' and CARD_STATUS.DESCRIPTION like '% Normal Service' and Rownum <= 1";
		System.out.println("getCardNoForCustomer query ::::" + getCardNoForCustomer);
		return connectDBAndGetValue(getCardNoForCustomer, PropUtils.getPropValue(configProp, "sqlODSServerName"));
	}

	public String getCardNumberForCustomerNo(String customerWithCards) {
		String getCardNoForCustomer = "Select distinct c.card_no from cards c "
				+ "inner join m_customers mc on c.customer_mid = mc.customer_mid "
				+ "INNER JOIN CARD_STATUS cs ON c.card_status_oid = cs.card_status_oid "
				+ "inner join card_products cp on cp.card_type_cid=c.card_type_cid "
				+ "where mc.customer_no = '"+ customerWithCards + "' and cs.DESCRIPTION like '%Normal Service' ";
		System.out.println("getCardNoForCustomer query ::::" + getCardNoForCustomer);
		return connectDBAndGetValue(getCardNoForCustomer, PropUtils.getPropValue(configProp, "sqlODSServerName"));
	}
	
	public String getDriverNameOfCardWithCustomerNo(String customerWithCards) {
		String getDriverNameForCustomer = "Select c.driver_name from drivers c inner join m_customers mc on c.customer_mid = mc.customer_mid where mc.customer_no = '"
				+ customerWithCards + "' and c.driver_name is not null and Rownum <= 1";
		return connectDBAndGetValue(getDriverNameForCustomer, PropUtils.getPropValue(configProp, "sqlODSServerName"));
	}

	public String getCostCenterOfCardWithCustomerNo(String customerWithCards) {
		String getCostCenterForCustomer = "Select c.customer_cost_centre_code from customer_cost_centres c inner join m_customers mc on c.customer_mid = mc.customer_mid where mc.customer_no = '"
				+ customerWithCards + "' and Rownum <= 1";
		return connectDBAndGetValue(getCostCenterForCustomer, PropUtils.getPropValue(configProp, "sqlODSServerName"));
	}

	public String getVRNOfCardWithCustomerNo(String customerWithCards) {
		String getVRNForCustomer = "Select c.license_plate from vehicles c inner join m_customers mc on c.customer_mid = mc.customer_mid where mc.customer_no = '"
				+ customerWithCards + "' and Rownum <= 1";
		return connectDBAndGetValue(getVRNForCustomer, PropUtils.getPropValue(configProp, "sqlODSServerName"));
	}

	public String getVehicleIDOfCardWithCustomerNo(String customerWithCards) {
		String getVRNForCustomer = "Select c.vehicle_id from vehicles c inner join m_customers mc on c.customer_mid = mc.customer_mid where mc.customer_no='"
				+ customerWithCards + "' and Rownum <= 1";
		return connectDBAndGetValue(getVRNForCustomer, PropUtils.getPropValue(configProp, "sqlODSServerName"));
	}

	public String getVehicleDescOfCardWithCustomerNo(String customerWithCards) {
		String getVRNForCustomer = "Select c.description from vehicles c inner join m_customers mc on c.customer_mid =  mc.customer_mid where mc.customer_no='"
				+ customerWithCards + "' and Rownum <= 1";
		return connectDBAndGetValue(getVRNForCustomer, PropUtils.getPropValue(configProp, "sqlODSServerName"));
	}

	public String getDriverIDOfCardWithCustomerNo(String customerWithCards) {
		String getVRNForCustomer = "Select c.driver_id from drivers c inner join m_customers mc on c.customer_mid = mc.customer_mid where mc.customer_no='"
				+ customerWithCards + "' and c.driver_id is not null  and Rownum <= 1";
		return connectDBAndGetValue(getVRNForCustomer, PropUtils.getPropValue(configProp, "sqlODSServerName"));
	}

	public void searchCostCentreValueAndValidate(String partialOrFullSearch) {
		String costCenter = getSHELLCostCentre();
		if (costCenter.equals(" ") && costCenter.equals("NULL")) {
			logForNoDataFound(this.getClass().getSimpleName(), "Need to Create A Customer With Cost Center and rerun");
		} else {
			clearingAllTextBoxes(textBoxes);
			boolean partialOrFull = true;
			if (partialOrFullSearch.equalsIgnoreCase("partial")) {
				costCenterValue = getPartialValue(costCenterValue);
				partialOrFull = false;
			}
			enterValueInTextBox("Filter By", "Cost Centre", costCenterValue);
			searchListTorch();
			sleep(5);
			validateSearchTable("Cost Centre", costCenterValue, partialOrFull);
		}

	}

	public void searchVRNValueAndValidate(String partialOrFullSearch) {
		VRNValue = getSHELLVRN();

		if (VRNValue.equals(" ") && VRNValue.equals("NULL")) {
			logForNoDataFound(this.getClass().getSimpleName(), "Need to Create A Customer With VRN and rerun");
		} else {
			clearingAllTextBoxes(textBoxes);
			boolean partialOrFull = true;
			if (partialOrFullSearch.equalsIgnoreCase("partial")) {
				VRNValue = getPartialValue(VRNValue);
				partialOrFull = false;
			}
			enterValueInTextBox("Filter By", "VRN", VRNValue);
			searchListTorch();
			sleep(5);
			// validateSearchTable("VRN", VRNValue, partialOrFull);
		}

	}

	public void searchVehicleDescriptionAndValidate(String partialOrFullSearch) {
		String vehicleDescription = getSHELLVehicleDescription();
		if (vehicleDescription.equals(" ") && vehicleDescription.equals("NULL")) {
			logForNoDataFound(this.getClass().getSimpleName(),
					"Need to Create A Customer With Vehicle Description and rerun");
		} else {
			clearingAllTextBoxes(textBoxes);
			boolean partialOrFull = true;
			if (partialOrFullSearch.equalsIgnoreCase("partial")) {
				VehicleDescriptionValue = getPartialValue(VehicleDescriptionValue);
				partialOrFull = false;
			}
			enterValueInTextBox("Filter By", "Vehicle Desc", VehicleDescriptionValue);
			sleep(5);
			searchListTorch();
			sleep(5);
			validateSearchTable("Vehicle Desc", VehicleDescriptionValue, partialOrFull);
		}

	}

	public void searchDescriptionAndValidate(String partialOrFullSearch) {
		String vehicleDescription = getSHELLVehicleDescription();
		if (vehicleDescription.equals(" ") && vehicleDescription.equals("NULL")) {
			logForNoDataFound(this.getClass().getSimpleName(),
					"Need to Create A Customer With Vehicle Description and rerun");
		} else {
			clearingAllTextBoxes(textBoxes);
			boolean partialOrFull = true;
			if (partialOrFullSearch.equalsIgnoreCase("partial")) {
				VehicleDescriptionValue = getPartialValue(VehicleDescriptionValue);
				partialOrFull = false;
			}
			enterValueInTextBox("Filter By", "Description", VehicleDescriptionValue);
			searchListTorch();
			sleep(5);
			validateSearchTable("Description", VehicleDescriptionValue, partialOrFull);
		}

	}

	/*
	 * raxsana added on 07/07/2020
	 */
	/**
	 * @param status
	 */
	public void applicationStatusChangeToApproved(String status) {
		Common common = new Common(driver, test);
		// ApplicationsPage applicationPage=new ApplicationsPage(driver,test);
		chooseSubMenuFromLeftPanel("Applications", "");
		// common.chooseARandomDropdownOption("Application Type");
		common.chooseOptionFromDropdown("Status", status);
		common.searchListTorch();
		try {
			verifyValidationResult("Record Read OK - Page Size 200 Rows");
			common.selectFirstRowNumberInSearchList();
			sleep(3);
			common.clickSaveIcon();
			verifyValidationResult("Record saved OK");
			common.clickValidateIcon();
			verifyValidationResult("Validation successful");
			common.clickApproveIcon();
			verifyValidationResult("Application Approved");
		} catch (Exception e) {
			e.getMessage();
			logFail("No Pending/New Applications");
		}
	}

	public void searchDriverIdAndValidate(String partialOrFullSearch) {
		String driverId = getSHELLDriverId();
		if (driverId.equals(" ") && driverId.equals("NULL")) {
			logForNoDataFound(this.getClass().getSimpleName(), "Need to Create A Customer With Driver ID and rerun");
		} else {
			clearingAllTextBoxes(textBoxes);
			boolean partialOrFull = true;
			if (partialOrFullSearch.equalsIgnoreCase("partial")) {
				DriverIdValue = getPartialValue(DriverIdValue);
				partialOrFull = false;
			}
			enterValueInTextBox("Filter By", "Driver Id", DriverIdValue);
			searchListTorch();
			sleep(5);
			validateSearchTable("Driver Id", DriverIdValue, partialOrFull);
		}

	}

	public void searchVehicleIdAndValidate(String partialOrFullSearch) {
		String VehicleId = getSHELLVehicleId();
		if (VehicleId.equals(" ") && VehicleId.equals("NULL")) {
			logForNoDataFound(this.getClass().getSimpleName(), "Need to Create A Customer With Driver ID and rerun");
		} else {
			clearingAllTextBoxes(textBoxes);
			boolean partialOrFull = true;
			if (partialOrFullSearch.equalsIgnoreCase("partial")) {
				VehicleIdValue = getPartialValue(VehicleIdValue);
				partialOrFull = false;
			}
			enterValueInTextBox("Filter By", "Vehicle ID", VehicleIdValue);
			searchListTorch();
			sleep(5);
			validateSearchTable("Vehicle ID", VehicleIdValue, partialOrFull);
		}
	}

	public void searchReferenceValueAndValidate(String partialOrFullSearch) {
		String reference = getSHELLReferenceNumber();
		if (reference.equals(" ") && reference.equals("NULL")) {
			logForNoDataFound(this.getClass().getSimpleName(), "Need to Create A Customer With Driver ID and rerun");
		} else {
			clearingAllTextBoxes(textBoxes);
			boolean partialOrFull = true;
			if (partialOrFullSearch.equalsIgnoreCase("partial")) {
				referenceValue = getPartialValue(referenceValue);
				partialOrFull = false;
			}
			enterValueInTextBox("Transaction Filter Fields", "Reference No", referenceValue);
			searchListTorch();
			sleep(5);
			// validateSearchTable("Ref", ReferenceValue, partialOrFull);
		}
	}

	public String getSHELLCardNumber() {
		String clientName, clientCountry, cardType;
		clientName = PropUtils.getPropValue(configProp, "clientName");
		clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		cardType = PropUtils.getPropValue(configProp, "cardType");
		String cardTypeDesc = "";

		if (clientCountry.contains("MY")) {
			if (cardType.contains("APA")) {
				cardTypeDesc = "Shell Pre-Paid Card";
			}

		} else {
			if (cardType.contains("APA")) {
				cardTypeDesc = "Shell Pre-Paid Card (" + clientCountry + ")";
			} else {
				cardTypeDesc = "Shell Partner Card (" + clientCountry + ")";
			}
		}
		String queryToGetCardNo = "Select c.card_no from cards c inner join card_programs cp on c.card_program_oid = cp.card_program_oid where cp.client_mid = (Select client_mid from m_clients where name = '"
				+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountry).replaceAll("\"", "")
				+ "') and cp.description = '" + cardTypeDesc + "' and Rownum <=1";
		cardNumberValue = connectDBAndGetValue(queryToGetCardNo,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		System.out.println("Card Number" + cardNumberValue);
		return cardNumberValue;
	}

	public String getSHELLCardDriverName() {
		String clientCountry, cardType;
		String cardTypeDesc = "";
		clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		cardType = PropUtils.getPropValue(configProp, "cardType");

		if (clientCountry.contains("MY")) {
			if (cardType.contains("APA")) {
				cardTypeDesc = "Shell Pre-Paid Card";
			}

		} else {
			if (cardType.contains("APA")) {
				cardTypeDesc = "Shell Pre-Paid Card (" + clientCountry + ")";
			} else {
				cardTypeDesc = "Shell Partner Card (" + clientCountry + ")";
			}
		}
		String queryToGetCardDriverName = "Select d.driver_name from cards c inner join drivers d on c.driver_oid = d.driver_oid inner join card_programs cp on c.card_program_oid = cp.card_program_oid where cp.description = '"
				+ cardTypeDesc + "' and Rownum <=1";
		driverNameValue = connectDBAndGetValue(queryToGetCardDriverName,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		System.out.println("Driver Name" + driverNameValue);
		return driverNameValue;
	}

	public String getSHELLCostCentre() {
		String clientName, clientCountry, cardType;
		String cardTypeDesc = "";
		clientName = PropUtils.getPropValue(configProp, "clientName");
		clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		cardType = PropUtils.getPropValue(configProp, "cardType");

		if (clientCountry.contains("MY")) {
			if (cardType.contains("APA")) {
				cardTypeDesc = "Shell Pre-Paid Card";
			}

		} else {
			if (cardType.contains("APA")) {
				cardTypeDesc = "Shell Pre-Paid Card (" + clientCountry + ")";
			} else {
				cardTypeDesc = "Shell Partner Card (" + clientCountry + ")";
			}
		}

		String queryToGetCostCentreValue = "Select d.customer_cost_centre_code from cards c inner join customer_cost_centres d on c.customer_mid = d.customer_mid inner join card_programs cp on c.card_program_oid = cp.card_program_oid where cp.client_mid = (Select client_mid from m_clients where name = '"
				+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountry).replaceAll("\"", "")
				+ "') and cp.description = '" + cardTypeDesc + "' and Rownum <=1";
		costCenterValue = connectDBAndGetValue(queryToGetCostCentreValue,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		System.out.println("Cost Center" + costCenterValue);
		return costCenterValue;
	}

	public String getSHELLVRN() {
		String clientCountry, cardType;
		String cardTypeDesc = "";
		clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		cardType = PropUtils.getPropValue(configProp, "cardType");

		if (clientCountry.contains("MY")) {
			if (cardType.contains("APA")) {
				cardTypeDesc = "Shell Pre-Paid Card";
			}

		} else {
			if (cardType.contains("APA")) {
				cardTypeDesc = "Shell Pre-Paid Card (" + clientCountry + ")";
			} else {
				cardTypeDesc = "Shell Partner Card (" + clientCountry + ")";
			}
		}
		String queryToGetCostCentreValue = "Select d.LICENSE_PLATE from cards c inner join vehicles d on c.customer_mid = d.customer_mid inner join card_programs cp on c.card_program_oid = cp.card_program_oid where d.vehicle_id is not null and cp.description = '"
				+ cardTypeDesc + "' and Rownum <=1";
		VRNValue = connectDBAndGetValue(queryToGetCostCentreValue,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		System.out.println("VRN Value" + VRNValue);
		return VRNValue;
	}

	public String getHirarchyAccountNoHasTwoCards() {
		String clientCountry, cardType;
		String cardTypeDesc = "";
		String cardToCardTransaction = "";

		clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		cardType = PropUtils.getPropValue(configProp, "cardType");
		if (clientCountry.equals("MY")) {
			cardTypeDesc = "Shell Pre-Paid Card";
		} else if (cardType.contains("APA")) {
			cardTypeDesc = "Shell Pre-Paid Card (" + clientCountry + ")";
		} else {
			cardTypeDesc = "Shell Partner Card (" + clientCountry + ")";
		}
		String queryToGetCardToCardTransaction = "Select cards.card_no from cards where card_no in (select cards.card_no from cards inner join m_customers mc on mc.customer_mid = cards.customer_mid inner join card_programs cp on cp.card_program_oid=mc.card_program_oid inner join card_status on card_status.card_status_oid = cards.card_status_oid inner join card_balances on card_balances.card_balance_oid = cards.card_balance_oid where cards.is_balance_allowed = 'Y' and mc.customer_no = 'RU00000005' and cards.replace_card_oid IS NULL and card_status.description like '%Card Processed%' and card_balances.balance>0 and cp.description = '"
				+ cardTypeDesc + "' group by cards.card_no having count(cards.card_no)>=1)";
		cardToCardTransaction = connectDBAndGetValue(queryToGetCardToCardTransaction,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		System.out.println(" Fund Transfer" + cardToCardTransaction);

		return cardToCardTransaction;
	}

	public String getSHELLDriverId() {
		String clientCountry, cardType;
		String cardTypeDesc = "";
		clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		cardType = PropUtils.getPropValue(configProp, "cardType");

		if (clientCountry.contains("MY")) {
			if (cardType.contains("APA")) {
				cardTypeDesc = "Shell Pre-Paid Card";
			}

		} else {
			if (cardType.contains("APA")) {
				cardTypeDesc = "Shell Pre-Paid Card (" + clientCountry + ")";
			} else {
				cardTypeDesc = "Shell Partner Card (" + clientCountry + ")";
			}
		}

		String queryToGetDriverIdValue = "Select d.driver_id from cards c inner join drivers d on c.customer_mid = d.customer_mid inner join card_programs cp on c.card_program_oid = cp.card_program_oid where d.driver_id is not null and cp.description = '"
				+ cardTypeDesc + "' and Rownum <=1";
		DriverIdValue = connectDBAndGetValue(queryToGetDriverIdValue,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		System.out.println("Cost Center" + DriverIdValue);
		return DriverIdValue;
	}

	public String getSHELLVehicleId() {
		String clientCountry, cardType;
		String cardTypeDesc = "";
		clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		cardType = PropUtils.getPropValue(configProp, "cardType");

		if (clientCountry.contains("MY")) {
			if (cardType.contains("APA")) {
				cardTypeDesc = "Shell Pre-Paid Card";
			}

		} else {
			if (cardType.contains("APA")) {
				cardTypeDesc = "Shell Pre-Paid Card (" + clientCountry + ")";
			} else {
				cardTypeDesc = "Shell Partner Card (" + clientCountry + ")";
			}
		}
		String queryToGetVehicleIdValue = "Select d.vehicle_id from cards c inner join vehicles d on c.customer_mid = d.customer_mid inner join card_programs cp on c.card_program_oid = cp.card_program_oid where d.vehicle_id is not null and cp.description = '"
				+ cardTypeDesc + "' and Rownum <=1";
		VehicleIdValue = connectDBAndGetValue(queryToGetVehicleIdValue,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		System.out.println("Vehicle Id Value" + VehicleIdValue);
		return VehicleIdValue;
	}

	public String getSHELLVehicleDescription() {
		String clientCountry, cardType;
		String cardTypeDesc = "";
		clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		cardType = PropUtils.getPropValue(configProp, "cardType");

		if (clientCountry.contains("MY")) {
			if (cardType.contains("APA")) {
				cardTypeDesc = "Shell Pre-Paid Card";
			}

		} else {
			if (cardType.contains("APA")) {
				cardTypeDesc = "Shell Pre-Paid Card (" + clientCountry + ")";
			} else {
				cardTypeDesc = "Shell Partner Card (" + clientCountry + ")";
			}
		}

		String queryToGetVehicleDescriptionValue = "Select d.description from cards c inner join vehicles d on c.customer_mid = d.customer_mid inner join card_programs cp on c.card_program_oid = cp.card_program_oid where d.description is not null and  cp.description = '"
				+ cardTypeDesc + "' and Rownum <=1";
		VehicleDescriptionValue = connectDBAndGetValue(queryToGetVehicleDescriptionValue,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		System.out.println("Vehicle Description Value" + VehicleDescriptionValue);
		return VehicleDescriptionValue;
	}

	public String getSHELLReferenceNumber() {
		String clientCountry, cardType;
		clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		cardType = PropUtils.getPropValue(configProp, "cardType");
		String cardTypeDesc = "";

		if (clientCountry.contains("MY")) {
			if (cardType.contains("APA")) {
				cardTypeDesc = "Shell Pre-Paid Card";
			}

		} else {

			if (cardType.contains("APA")) {
				cardTypeDesc = "Shell Pre-Paid Card (" + clientCountry + ")";
			} else {
				cardTypeDesc = "Shell Partner Card (" + clientCountry + ")";
			}
		}

		String queryToGetReferenceNo = "Select d.REFERENCE from cards c inner join transactions d on c.customer_mid = d.customer_mid inner join card_programs cp on c.card_program_oid = cp.card_program_oid and cp.description = '"
				+ cardTypeDesc + "' and Rownum <=1";
		referenceValue = connectDBAndGetValue(queryToGetReferenceNo,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		System.out.println("Reference No" + referenceValue);
		return referenceValue;
	}

	public void validateTaskBar() {
		waitForElementTobeClickable(validateTaskBar, 10);
		isDisplayedThenClick(validateTaskBar, "Validate");
	}

	public void createTaskBar() {
		waitForElementTobeClickable(createTaskBar, 10);
		isDisplayedThenClick(createTaskBar, "Create");
	}
	
	// added by rathna to improve performance
		public void chooseNoAndSearch(String labelName, String option)
		{
			boolean isOptionPresent = false;
			try {

				WebElement textEditor = driver.findElement(
						By.xpath("//div[@class='BasicComboBoxEditor_BorderlessTextField JTextComponent']/input"));
				isDisplayedThenActionClick(textEditor, "Dropdown is displayed");
				textEditor.clear();
				textEditor.sendKeys(option);
				sleep(5);
				isOptionPresent = true;
			} catch (Exception ex) {
				// logFail(ex.getMessage());
				isOptionPresent = false;
			}
		}


	public void chooseCustomerNoAndSearch(String customerNo) {
		searchTorch();
		sleep(3);
		chooseNoAndSearch("Customer No", customerNo);
		//chooseOptionFromDropdown("Customer No", customerNo);
		findRecordTorch();
		closeFindRecordTorch();
		sleep(5);
	}

	public void chooseMerchantNoAndSearch(String merchantNo) {
		searchTorch();
		sleep(4);
		chooseNoAndSearch("Merchant No", merchantNo);
		//chooseOptionFromDropdown("Merchant No", merchantNo);
		findRecordTorch();
		closeFindRecordTorch();
	}

	public void chooseLocationNoAndSearch(String locationNo) {
		searchTorch();
		chooseNoAndSearch("Location No", locationNo);
		//chooseOptionFromDropdown("Location No", locationNo);
		findRecordTorch();
		closeFindRecordTorch();
	}

	public void chooseCardNoAndSearch(String cardNo) {
		searchTorch();
		chooseNoAndSearch("Card Number", cardNo);
		//chooseOptionFromDropdown("Card Number", cardNo);
		findRecordTorch();
		sleep(5);
		closeFindRecordTorch();
		sleep(5);
	}

	public String convertrgbColorToHex(String color) {
		// String color = driver.findElement(By.xpath("//div[@class='gb_e gb_f gb_g
		// gb_xb']/a")).getCssValue("color");
		String[] numbers = color.replace("rgba(", "").replace(")", "").split(",");
		int r = Integer.parseInt(numbers[0].trim());
		int g = Integer.parseInt(numbers[1].trim());
		int b = Integer.parseInt(numbers[2].trim());
		// int a = Integer.parseInt(numbers[3].trim());
		System.out.println("r: " + r + "g: " + g + "b: " + b);
		String hex = "#" + Integer.toHexString(r) + Integer.toHexString(g) + Integer.toHexString(b);
		System.out.println(hex);
		return hex;
	}

	public void validateAndGetTextFromTransferProtectedLabel() {
		int protectedcount = validateFieldType();
		System.out.println("Count for Protected :" + protectedcount);
		validateFieldIsProtected("From", "Name");
		String fromName = getValueFromProtectedTextBox("From", "Name");
		System.out.println("From Name:" + fromName);
		validateFieldIsProtected("From", "Available Balance");
		String fromAvailableBalance = getValueFromProtectedTextBox("From", "Available Balance");
		System.out.println("From Available Balance:" + fromAvailableBalance);
		validateFieldIsProtected("To", "Name");
		String toName = getValueFromProtectedTextBox("To", "Name");
		System.out.println("To Name:" + toName);
		validateFieldIsProtected("To", "Available Balance");
		String toAvailableBalance = getValueFromProtectedTextBox("To", "Available Balance");
		System.out.println("To Available Balance:" + toAvailableBalance);
	}
	
	/** Added by Davu
	 * @return VINCII Card number
	 */
	
public String getVinCiiActiveCard() {
		
		String query = "select cardnumber from card where badgenumber is not NULL";
		
		 String cardNumber = connectICPDBAndGetValue(query, PropUtils.getPropValue(configProp, "icpServerName"));
		return cardNumber;
	}

	public String getCustomerNoWithAccountSubStatusAsPaymentPending() {
		String clientCountry, cardType;
		String cardTypeDesc = "";
		clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		cardType = PropUtils.getPropValue(configProp, "cardType");
		if (clientCountry.contains("MY")) {
			if (cardType.contains("APA")) {
				cardTypeDesc = "Shell Pre-Paid Card";
			}
		} else {
			if (cardType.contains("APA")) {
				cardTypeDesc = "Shell Pre-Paid Card (" + clientCountry + ")";
			} else {
				cardTypeDesc = "Shell Partner Card (" + clientCountry + ")";
			}
		}
		String queryToGetCardDriverName = "select customer_no from m_customers mc inner join accounts acc on mc.customer_mid=acc.customer_mid inner join account_status accs on accs.account_status_oid=acc.account_status_oid inner join account_sub_status accss on acc.account_sub_status_oid=accss.account_sub_status_oid inner join card_programs cp on cp.card_program_oid=mc.card_program_oid where accs.description like '%Active' and accss.description='Payment Pending' and cp.description = '"
				+ cardTypeDesc + "' and ROWNUM <=1";
		String customerNoValue = connectDBAndGetValue(queryToGetCardDriverName,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		return customerNoValue;
	}

	public void performBlankSearchAndValidate() {
		clearingAllTextBoxes(textBoxes);
		searchListTorch();
		sleep(5);
		// verifyValidationResult("Record read OK");
		verifyValidationResult("Record Read OK - Page Size");
		if (SeleniumWrappers.getTotalNumberOfRows(cardsTable, driver) > 0) {
			logPass("Done Cards Search");
		} else {
			// logFail("No Cards after search");
			logInfo("No Cards after search");
		}
	}

	public void validateSearchTable(String colName, String expectedValue, Boolean checkEquals) {
		int totalRowsInTable = SeleniumWrappers.getTotalNumberOfRows(cardsTable, driver);
		int colIndex = SeleniumWrappers.getColumnNoForColumnHeader(colName, cardsTableHeaders);
		System.out.println("Column name ---" + colName);
		System.out.println("Expected value ---" + expectedValue);
		boolean validateCols = false;

		for (int i = 0; i <= totalRowsInTable - 1; i++) {
			expectedValue = expectedValue.toLowerCase().replaceAll("\\*", "");
			
			if (checkEquals) {
				validateCols = SeleniumWrappers.getTableDataWithRowAndColumnNumber(colIndex, i, driver)
						.equalsIgnoreCase(expectedValue);
				System.out.println("checkEquals ---" + validateCols);
			} else {
				if (!expectedValue.equals(" ")) {
					validateCols = SeleniumWrappers.getTableDataWithRowAndColumnNumber(colIndex, i, driver)
							.toLowerCase().contains(expectedValue);
				} else {
					validateCols = true;
				}
			}

			if (validateCols) {
				logPass("Expected value present in Row: " + i + " Col: " + colIndex + " Expected::" + expectedValue
						+ " Actual::" + SeleniumWrappers.getTableDataWithRowAndColumnNumber(colIndex, i, driver));
			} else {
				logFail("Expected value not present in Row: " + i + " Col: " + colIndex + " Expected::" + expectedValue
						+ " Actual::" + SeleniumWrappers.getTableDataWithRowAndColumnNumber(colIndex, i, driver));
			}
		}
	}

	// Added by Sasi on 20-02-19
	public void validateSearchTableWhenMultipleTablePresents(String seperatorLabelName, String colName,
			String expectedValue, Boolean checkEquals) {
		String seperator = splitStringAndGenerateXpath(seperatorLabelName);
		List<WebElement> tableDatasWithSeperator = driver.findElements(By.xpath("//div[@class='JFALSeparator']//div["
				+ seperator
				+ "]/preceding::div[@class='JFALCompControlPanel'][1]//div[starts-with(@class,'FALTableCellEditor_StrikeThru')]"));
		int totalRowsInTable = SeleniumWrappers.getTotalNumberOfRows(tableDatasWithSeperator, driver);

		List<WebElement> tableHeadersWithSeperator = driver.findElements(By.xpath("//div[@class='JFALSeparator']//div["
				+ seperator
				+ "]/preceding::div[@class='JFALCompControlPanel'][1]//div[@class='HeaderRenderer']//div[@class='htmlString']"));
		int colIndex = SeleniumWrappers.getColumnNoForColumnHeader(colName, tableHeadersWithSeperator);

		System.out.println("colIndex : " + colIndex);
		boolean validateCols;

		for (int i = 0; i < totalRowsInTable; i++) {
			if (checkEquals) {
				validateCols = SeleniumWrappers.getTableDataWithRowAndColumnNumber(colIndex, i, driver)
						.equalsIgnoreCase(expectedValue);
			} else {
				validateCols = SeleniumWrappers.getTableDataWithRowAndColumnNumber(colIndex, i, driver).toLowerCase()
						.contains(expectedValue.toLowerCase().replaceAll("\\*", ""));
			}

			if (validateCols) {
				logPass("Expected value present in Row: " + i + " Col: " + colIndex + " Expected::" + expectedValue
						+ " Actual::" + SeleniumWrappers.getTableDataWithRowAndColumnNumber(colIndex, i, driver));
			} else {
				logFail("Expected value not present in Row: " + i + " Col: " + colIndex + " Expected::" + expectedValue
						+ " Actual::" + SeleniumWrappers.getTableDataWithRowAndColumnNumber(colIndex, i, driver));
			}
		}
	}

	// prakalpha added getSHELLVehicleCardNumber

	public String getVehicleCardNumberFromDB(String client) {
		String clientCountry;
		String cardType;
		String vehicleCardNumber;
		String queryToGetVehicleCardNumber;
		String cardTypeDesc = "";
		String clientName = PropUtils.getPropValue(configProp, "clientName");
		clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		cardType = PropUtils.getPropValue(configProp, "cardType");
		System.out.println("************************" + clientName + "#####################");
		if (clientName.equals("SHELL")) {

			if (clientCountry.contains("MY")) {
				if (cardType.contains("APA")) {
					cardTypeDesc = "Shell Pre-Paid Card";
				}
			} else {
				if (cardType.contains("APA")) {
					cardTypeDesc = "Shell Pre-Paid Card (" + clientCountry + ")";
				} else {
					cardTypeDesc = "Shell Partner Card (" + clientCountry + ")";
				}
			}
			client = client.replace("SHELL", "SH ");
			queryToGetVehicleCardNumber = "select card_no,mc.CUSTOMER_NO from cards c inner join card_programs cp on c.card_program_oid = cp.card_program_oid inner join  m_customers mc on mc.customer_mid = c.customer_mid inner join accounts acc on mc.customer_mid=acc.customer_mid inner join account_status accs on accs.account_status_oid=acc.account_status_oid inner join account_sub_status accss on accss.account_status_oid = accs.account_status_oid Where accs.description like '%Active' and accss.description like '%Active' and c.driver_oid IS NULL and c.replace_card_oid IS NULL and mc.client_mid in (SELECT client_mid from M_CLIENTS where name ='"
					+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountry)
					+ "') and c.card_status_oid in (select card_status_oid from card_status where (description like '%Active' OR description like '%Card Processed')) and c.expires_on >=(SELECT PROCESSING_DATE from M_CLIENTS where name ='"
					+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountry)
					+ "')  and cp.description = '" + cardTypeDesc + "' and Rownum <=1";
			vehicleCardNumber = connectDBAndGetDBRowValue(queryToGetVehicleCardNumber,
					PropUtils.getPropValue(configProp, "sqlODSServerName"), 1);

			vehicleCardNumber = connectDBAndGetValue(queryToGetVehicleCardNumber,
					PropUtils.getPropValue(configProp, "sqlODSServerName"));

			vehicleCardNumber = connectDBAndGetValue(queryToGetVehicleCardNumber,
					PropUtils.getPropValue(configProp, "sqlODSServerName"));
		}else if (client.contains("WFE")){
			client = client.replace("WFE", "WFE ");
			String queryToGetCardDriverName = "select card_no from cards c inner join  m_customers mc on mc.customer_mid = c.customer_mid inner join card_programs cp on c.card_program_oid = cp.card_program_oid inner join card_status cs on cs.card_status_oid = c.card_status_oid inner join  m_customers mc on mc.customer_mid = c.customer_mid inner join accounts acc on mc.customer_mid=acc.customer_mid inner join account_status accs on accs.account_status_oid=acc.account_status_oid inner join account_sub_status accss on accss.account_status_oid = accs.account_status_oid	Where accs.description = 'Active' and accss.description = 'Active' and c.replace_card_oid IS NULL and (cs.description = 'Normal Service') and c.expires_on >=(SELECT PROCESSING_DATE from M_CLIENTS where SHORT_NAME='"
					+ client + "') and c.CARD_PRODUCT_OID in (select card_product_oid from card_products where description like '%Vehicle%')";
			vehicleCardNumber = connectDBAndGetDBRowValue(queryToGetCardDriverName,
					PropUtils.getPropValue(configProp, "sqlODSServerName"),2);
		} else {

			queryToGetVehicleCardNumber = "select card_no,mc.CUSTOMER_NO from cards c inner join  m_customers mc on mc.customer_mid = c.customer_mid inner join accounts acc on mc.customer_mid=acc.customer_mid inner join account_status accs on accs.account_status_oid=acc.account_status_oid inner join account_sub_status accss on accss.account_status_oid = accs.account_status_oid Where accs.description like '%Active' and accss.description like '%Active' and c.driver_oid IS NULL and c.replace_card_oid IS NULL and mc.client_mid in (SELECT client_mid from M_CLIENTS where name ='"
					+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountry)
					+ "') and c.card_status_oid in (select card_status_oid from card_status where (description like '%Active' OR description like '%Card Processed')) and c.expires_on >=(SELECT PROCESSING_DATE from M_CLIENTS where name ='"
					+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountry) + "') and Rownum <=1";
			System.out.println("Query: " + queryToGetVehicleCardNumber);
			vehicleCardNumber = connectDBAndGetValue(queryToGetVehicleCardNumber,
					PropUtils.getPropValue(configProp, "sqlODSServerName"));

		}

		System.out.println("card No::" + vehicleCardNumber);
		return vehicleCardNumber;

	}

	public void logForNoDataFound(String className, String logMessage) {
		logFail(className + " ------> " + logMessage);
	}
	
	public void getProfile(String seperatorLabelName, int row, String tableHeaderName)
	{
		WebElement cellElement;
		String seperator = " ";
		// String index="1";
		try {
			seperator = splitStringAndGenerateXpath(seperatorLabelName);
			System.out.println("Row Value---------->" + row);
			sleep(3);
		
			List<WebElement> tableHeaders = driver.findElements(By.xpath("//div[@class='JFALSeparator']//div["
					+ seperator
					+ "]/preceding::div[@class='JFALCompControlPanel']//div[@class='JViewport']/div[@class='JTableHeader']//div[@class='HeaderRenderer']//div[@class='htmlString']"));

			System.out.println(tableHeaders);
			SeleniumWrappers.setTotalTableHeaders(tableHeaders.size());

			int colIndex = SeleniumWrappers.getColumnNoForColumnHeader(tableHeaderName, tableHeaders);
			System.out.println("Column Index-->" + colIndex);
			cellElement = SeleniumWrappers.getTableDataWithCellElement(row, colIndex, driver);
			System.out.println("Cell Element--->" + cellElement);
			sleep(5);
			if (row == 1) {
				int col = 1;
				WebElement cellElement1 = driver.findElement(By.xpath(
						"//div[@class='JFALSeparator']//div[contains(text(),'Profile')]/preceding::div[@class='JFALCompControlPanel']["
								+ 1 + "]//div[@class='FALTableCellEditor_StrikeThruCheckBox enabled'][contains(@id,'_"
								+ row + "_" + col + "')]//div[@class='htmlImage']"));
				Click(cellElement1, "Table Cell");
			} else {
				int col = 0;
				WebElement cellElement1 = driver.findElement(By.xpath(
						"//div[@class='JFALSeparator']//div[contains(text(),'Profile')]/preceding::div[@class='JFALCompControlPanel']["
								+ 1 + "]//div[@class='FALTableCellEditor_StrikeThruCheckBox enabled'][contains(@id,'_"
								+ row + "_" + col + "')]//div[@class='htmlImage']"));
				Click(cellElement1, "Table Cell");
				
			}

		} catch (Exception e) {
			logFail(e.getMessage());
		}

	}
	

	public void rightClickAndSelectProfile(String seperatorLabelName, int row, String tableHeaderName) {
			// List<WebElement> table;
		WebElement cellElement;
		String seperator = " ";
		// String index="1";
		try {
			seperator = splitStringAndGenerateXpath(seperatorLabelName);
			System.out.println("Row Value---------->" + row);
			sleep(3);
			/*
			 * table = driver.findElements(By.xpath("//div[@class='JFALSeparator']//div[" +
			 * seperator +
			 * "]//preceding::div[@class='JFALCompControlPanel'][1]//div[@class='FALTableCellEditor_StrikeThruField JTextComponent'] or contains(@class,'FALTableCellEditor_StrikeThruCheckBox')]"
			 * ));
			 */
			List<WebElement> tableHeaders = driver.findElements(By.xpath("//div[@class='JFALSeparator']//div["
					+ seperator
					+ "]/preceding::div[@class='JFALCompControlPanel']//div[@class='JViewport']/div[@class='JTableHeader']//div[@class='HeaderRenderer']"));

			System.out.println(tableHeaders);
			SeleniumWrappers.setTotalTableHeaders(tableHeaders.size());

			int colIndex = SeleniumWrappers.getColumnNoForColumnHeader(tableHeaderName, tableHeaders);
			System.out.println("Column Index-->" + colIndex);
			cellElement = SeleniumWrappers.getTableDataWithCellElement(row, colIndex, driver);
			System.out.println("Cell Element--->" + cellElement);
			sleep(5);
//			Click(cellElement, "Table Cell");

			if (row == 1) {
				int col = 1;
				WebElement cellElement1 = driver.findElement(By.xpath(
						"//div[@class='JFALSeparator']//div[contains(text(),'Profile')]/preceding::div[@class='JFALCompControlPanel']["
								+ 1 + "]//div[@class='FALTableCellEditor_StrikeThruCheckBox enabled'][contains(@id,'_"
								+ row + "_" + col + "')]//div[@class='htmlImage']"));
				Click(cellElement1, "Table Cell");
				rightClick(cellElement1);
			} else {
				int col = 0;
				WebElement cellElement1 = driver.findElement(By.xpath(
						"//div[@class='JFALSeparator']//div[contains(text(),'Profile')]/preceding::div[@class='JFALCompControlPanel']["
								+ 1 + "]//div[@class='FALTableCellEditor_StrikeThruCheckBox enabled'][contains(@id,'_"
								+ row + "_" + col + "')]//div[@class='htmlImage']"));
				// Click(cellElement1, "Table Cell");
				sleep(5);
				rightClick(cellElement1);
			}

			sleep(5);
			Click(selectProfile, "Select Profile");
		} catch (Exception e) {
			logFail(e.getMessage());
		}
	}

	public void rightClickAndCreatePrivateProfile(WebElement locator) {
		try {
			rightClick(locator);
			sleep(5);
			Click(createPrivateProfile, "Create Private Profile");
			logPass("Profile created");
		} catch (Exception e) {
			logFail(e.getMessage());
		}
	}

	public void rightClickDeletePrivateProfileAndValidate(String seperatorLabelName, String tableHeaderName) {
		// WebElement cellElement;
		boolean deleteDefault = false;
		// List<WebElement> table;
		// String seperator = " ";
		try {
			// seperator = splitStringAndGenerateXpath(seperatorLabelName);
			/*
			 * int row = validateCheckBoxInTable(seperatorLabelName, "Private");
			 * System.out.println("Row Value---------->" + row); table =
			 * driver.findElements(By.xpath("//div[@class='JFALSeparator']//div[" +
			 * seperator +
			 * "]//preceding::div[@class='JFALCompControlPanel'][1]//div[@class='FALTableCellEditor_StrikeThruField JTextComponent']"
			 * ));
			 * 
			 * List<WebElement> tableHeaders =
			 * driver.findElements(By.xpath("//div[@class='JFALSeparator']//div[" +
			 * seperator +
			 * "]/preceding::div[@class='JFALCompControlPanel']//div[@class='JViewport']/div[@class='JTableHeader']//div[@class='HeaderRenderer']"
			 * )); int colIndex =
			 * SeleniumWrappers.getColumnNoForColumnHeader(tableHeaderName, tableHeaders);
			 * System.out.println("Column Index-->" + colIndex); sleep(3); cellElement =
			 * SeleniumWrappers.getTableDataWithCellElement(row, colIndex, driver);
			 * System.out.println("Cellelement----->" + cellElement); sleep(5);
			 */
			// Click(cellElement, "Table Cell");
			// sleep(5);
			WebElement cellElement1 = driver.findElement(By.xpath(
					"//div[@class='JFALSeparator']//div[contains(text(),'Profile')]/preceding::div[@class='JFALCompControlPanel']["
							+ 1
							+ "]//div[@class='FALTableCellEditor_StrikeThruCheckBox enabled'][contains(@id,'_1_1')]//div[@class='htmlImage']"));
			Click(cellElement1, "Table Cell");
			rightClick(cellElement1);
			sleep(5);
			Click(deletePrivateProfile, "Delete Private Profile");
			try {
				WebElement validateElement = driver
						.findElement(By.xpath("//div[@class='JPanel']/div[@class='JOptionPane']"));
				deleteDefault = true;
				if (deleteDefault == true) {
					Click(validateElement.findElement(
							By.xpath("//div[@class='JButton enabled']//div[@class='htmlString']")), "Ok button");
					sleep(2);
					logInfo("Cannot Delete the Private Profile");
				}
			} catch (Exception e) {

				logInfo("Private Profile Deleted");
			}

			sleep(5);
		} catch (Exception e) {
			logFail(e.getMessage());
		}
	}

	public String getCustomerNunmberWithNoHierarchy() {
		String clientCountry, cardType;
		String cardTypeDesc = "";
		// clientName = PropUtils.getPropValue(configProp, "clientName");
		clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		cardType = PropUtils.getPropValue(configProp, "cardType");
		if (clientCountry.equals("MY")) {
			cardTypeDesc = "Shell Pre-Paid Card";
		} else if (cardType.contains("APA")) {
			cardTypeDesc = "Shell Pre-Paid Card (" + clientCountry + ")";
		} else {
			cardTypeDesc = "Shell Partner Card (" + clientCountry + ")";
		}
		String CustomerNumber = "SELECT c.customer_no FROM m_customers c LEFT JOIN relationships r ON r.member_oid = c.customer_mid INNER JOIN Card_programs ON c.CARD_PROGRAM_OID = Card_programs.CARD_PROGRAM_OID WHERE r.relationship_oid IS NULL AND Card_programs.DESCRIPTION = '"
				+ cardTypeDesc + "' and rownum=1";
		CustomerNumber = connectDBAndGetValue(CustomerNumber, PropUtils.getPropValue(configProp, "sqlODSServerName"));
		System.out.println("Card Number" + CustomerNumber);
		return CustomerNumber;

	}

	public void validateNewValueAddedInTheTableList(String seperatorLabelName, String tableHeaderName,
			String expectedText) {

		List<WebElement> tableHeaders;
		List<WebElement> list;
		String seperator = " ";
		try {
			seperator = splitStringAndGenerateXpath(seperatorLabelName);

			System.out.println("Saparater " + seperator);

			tableHeaders = driver.findElements(By.xpath("//div[@class='JFALSeparator']//div[" + seperator
					+ "]/preceding::div[@class='JFALCompControlPanel'][1]//div[@class='JViewport']/div[@class='JTableHeader']//div[@class='HeaderRenderer']"));

			int colIndex = SeleniumWrappers.getColumnNoForColumnHeader(tableHeaderName, tableHeaders);
			System.out.println("Column Index" + colIndex);

			list = driver.findElements(By.xpath("//div[@class='JFALSeparator']//div[" + seperator
					+ "]//preceding::div[@class='JFALCompControlPanel'][1]//div[@class='FALTableCellEditor_StrikeThruField JTextComponent']"));

			int size = SeleniumWrappers.getTotalNumberOfRows(list, driver);
			System.out.println("Size" + size);
			// colIndex=0;
			for (int row = 0; row < size; row++) {

				String s="//div[@class='JFALSeparator']//div[" + seperator
						+ "]//preceding::div[@class='JFALCompControlPanel'][1]//div[@class='FALTableCellEditor_StrikeThruField JTextComponent'][contains(@id,'"
						+ row + "_" + colIndex + "')]//input";
				WebElement element = driver.findElement(By.xpath("//div[@class='JFALSeparator']//div[" + seperator
						+ "]//preceding::div[@class='JFALCompControlPanel'][1]//div[@class='FALTableCellEditor_StrikeThruField JTextComponent'][contains(@id,'"
						+ row + "_" + colIndex + "')]//input"));

				logPass("Got xpath of of first row");
				String actualText = element.getAttribute("submittedvalue");

				System.out.println("Actual text " + actualText);
				if (actualText.equals(expectedText)) {
					logPass(actualText + " and " + expectedText + "are same and Validated");
					break;
				} else {
					System.out.println(actualText + " and " + expectedText + "are not same");
				}
			}
		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
	}

	public void validateNewDateAddedInTheTableList(String seperatorLabelName, String tableHeaderName,
			String expectedText) {

		List<WebElement> tableHeaders;
		List<WebElement> list;
		String seperator = " ";
		try {
			seperator = splitStringAndGenerateXpath(seperatorLabelName);

			tableHeaders = driver.findElements(By.xpath("//div[@class='JFALSeparator']//div[" + seperator
					+ "]/preceding::div[@class='JFALCompControlPanel'][1]//div[@class='JViewport']/div[@class='JTableHeader']//div[@class='HeaderRenderer']"));
			int colIndex = SeleniumWrappers.getColumnNoForColumnHeader(tableHeaderName, tableHeaders);
			System.out.println("column Index" + colIndex);

			list = driver.findElements(By.xpath("//div[@class='JFALSeparator']//div[" + seperator
					+ "]//preceding::div[@class='JFALCompControlPanel'][1]//div[@class='FALTableCellEditor_StrikeThruDateField JTextComponent']"));

			int size = SeleniumWrappers.getTotalNumberOfRows(list, driver);
			System.out.println(size);
			for (int row = 0; row < size; row++) {
				WebElement element = driver.findElement(By.xpath("//div[@class='JFALSeparator']//div[" + seperator
						+ "]//preceding::div[@class='JFALCompControlPanel'][1]//div[@class='FALTableCellEditor_StrikeThruDateField JTextComponent'][contains(@id,'"
						+ row + "_" + colIndex + "')]//input"));
				String actualText = element.getAttribute("submittedvalue");
				if (actualText.equals(expectedText)) {
					logPass(actualText + " and " + expectedText + "are same and Validated");
					break;
				}
			}
		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
	}

	// Prakalpha-->11/05/2019
	public void validateNewItemAddedInTheTableList(String seperatorLabelName, String tableHeaderName,
			String expectedText) {

		List<WebElement> tableHeaders;
		List<WebElement> list;
		String seperator = " ";
		try {
			seperator = splitStringAndGenerateXpath(seperatorLabelName);
			tableHeaders = driver.findElements(By.xpath("//div[@class='JFALSeparator']//div[" + seperator
					+ "]/preceding::div[@class='JFALCompControlPanel'][1]//div[@class='JViewport']/div[@class='JTableHeader']//div[@class='HeaderRenderer']"));
			int colIndex = SeleniumWrappers.getColumnNoForColumnHeader(tableHeaderName, tableHeaders);
			System.out.println("Column Index" + colIndex);
			list = driver.findElements(By.xpath("//div[@class='JFALSeparator']//div[" + seperator
					+ "]//preceding::div[@class='JFALCompControlPanel'][1]//div[@class='FALTableCellEditor_StrikeThruField JTextComponent']"));

			int size = SeleniumWrappers.getTotalNumberOfRows(list, driver);
			System.out.println("Size" + size);
			for (int row = 0; row < size; row++) {
				WebElement element = driver.findElement(By.xpath("//div[@class='JFALSeparator']//div[" + seperator
						+ "]//preceding::div[@class='JFALCompControlPanel'][1]//div[@class='FALTableCellEditor_StrikeThruField JTextComponent'][contains(@id,'"
						+ "_" + row + "_" + colIndex + "')]//div[@class='htmlString']"));
				String actualText = element.getText();
				if (actualText.equals(expectedText)) {
					logPass(actualText + " and " + expectedText + "are same and Validated");
					break;
				} else {
					logInfo(actualText + " and " + expectedText + "are not same");
				}
			}
		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
	}

	/*
	 * Prakalpha-->11/05/2019 To Doubleclick the expected Row value
	 */
	public void validateExpectedRowValueAndDoubleClick(String seperatorLabelName, String tableHeaderName,
			String expectedText) {

		List<WebElement> tableHeaders;
		List<WebElement> list;
		String seperator = " ";
		try {
			seperator = splitStringAndGenerateXpath(seperatorLabelName);
			tableHeaders = driver.findElements(By.xpath("//div[@class='JFALSeparator']//div[" + seperator
					+ "]/preceding::div[@class='JFALCompControlPanel'][1]//div[@class='JViewport']/div[@class='JTableHeader']//div[@class='HeaderRenderer']"));
			int colIndex = SeleniumWrappers.getColumnNoForColumnHeader(tableHeaderName, tableHeaders);
			System.out.println("Column Index" + colIndex);
			list = driver.findElements(By.xpath("//div[@class='JFALSeparator']//div[" + seperator
					+ "]//preceding::div[@class='JFALCompControlPanel'][1]//div[@class='FALTableCellEditor_StrikeThruField JTextComponent']"));

			int size = SeleniumWrappers.getTotalNumberOfRows(list, driver);
			System.out.println("Size" + size);
			for (int row = 0; row < size; row++) {
				WebElement element = driver.findElement(By.xpath("//div[@class='JFALSeparator']//div[" + seperator
						+ "]//preceding::div[@class='JFALCompControlPanel'][1]//div[@class='FALTableCellEditor_StrikeThruField JTextComponent'][contains(@id,'"
						+ "_" + row + "_" + colIndex + "')]//div[@class='htmlString']"));
				String actualText = element.getText();
				if (actualText.equals(expectedText)) {
					logPass(actualText + " and " + expectedText + "are same and Validated");
					doubleClick(element);
					break;
				} else {
					logInfo(actualText + " and " + expectedText + "are not same");
				}
			}
		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
	}

	/*
	 * Prakalpha-->11/06/2019 Delete expected Row
	 */
	public void rightClickAndDeleteExpectedRow(String seperatorLabelName, String tableHeaderName, String expectedText) {

		List<WebElement> tableHeaders;
		List<WebElement> list;
		String seperator = " ";
		try {
			seperator = splitStringAndGenerateXpath(seperatorLabelName);
			tableHeaders = driver.findElements(By.xpath("//div[@class='JFALSeparator']//div[" + seperator
					+ "]/preceding::div[@class='JFALCompControlPanel'][1]//div[@class='JViewport']/div[@class='JTableHeader']//div[@class='HeaderRenderer']"));
			int colIndex = SeleniumWrappers.getColumnNoForColumnHeader(tableHeaderName, tableHeaders);
			System.out.println("Column Index" + colIndex);
			list = driver.findElements(By.xpath("//div[@class='JFALSeparator']//div[" + seperator
					+ "]//preceding::div[@class='JFALCompControlPanel'][1]//div[@class='FALTableCellEditor_StrikeThruField JTextComponent']"));
			SeleniumWrappers.setCellValue(list);
			int size = SeleniumWrappers.getTotalNumberOfRows(list, driver);
			System.out.println("Size" + size);
			for (int row = 0; row < size; row++) {
				WebElement element = driver.findElement(By.xpath("//div[@class='JFALSeparator']//div[" + seperator
						+ "]//preceding::div[@class='JFALCompControlPanel'][1]//div[@class='FALTableCellEditor_StrikeThruField JTextComponent'][contains(@id,'"
						+ "_" + row + "_" + colIndex + "')]//div[@class='htmlString']"));
				String actualText = element.getText();
				if (actualText.equals(expectedText)) {
					Click(element, "expected element is clicked");
					rightClick(element);
					deleteIteminPopup();
					logPass(expectedText + " Row value is Present and deleted the row Value");
					break;
				} else {
					logInfo(expectedText + " Row value is not present in a Table");
				}
			}
		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
	}

	public void rightClickAndOptInout(String seperatorLabelName, String tableHeaderName) {

		WebElement element;
		try {
			//int rowcount = validateCheckBoxInTable(seperatorLabelName, tableHeaderName);//rathna commented and added below
			int rowcount = SeleniumWrappers.getTotalNumberOfRows(rebateProfilesTable, driver) - 1;
			System.out.println("Row Size:" + rowcount);
			System.out.println("rowcount" + rowcount);
			String seperator = splitStringAndGenerateXpath(seperatorLabelName);
			element = driver.findElement(By.xpath("//div[@class='JFALSeparator']//div[" + seperator
					+ "]/preceding::div[@class='JFALCompControlPanel'][2]//div[@class='FALTableCellEditor_StrikeThruField JTextComponent'][contains(@id,'"
					+ rowcount + "_" + 2 + "')]//div[2]"));
			System.out.println("element" + element);
			Click(element, "Table Cell");
			rightClick(element);
		//	Click(element, "Table Cell"); rathna changed
			sleep(5);
			isDisplayedThenClick(poupMenuOptInOut, "opt in/Out");
			clickOkButtonIfMsgPopupAppears();
		} catch (Exception e) {
			logFail(e.getMessage());
		}
	}

	public String chooseARandomDropdownOption(String labelName) {
		return chooseOptionFromDropdown(labelName, "random");  //chooseOptionFromDropdownByJSClick
		//return chooseOptionFromDropdownByJSClick(labelName, "random"); // Parallel - Fix
	}

	public void validateCheckBoxInTableAndDoubleClick(String seperatorLabelName, String tableHeaderName,
			String tableHeaderDescription) {
		WebElement cellElement;
		String seperator = " ";
		int index = 1;
		if (seperatorLabelName.equals("Rebate Profiles")) {
			index = 2;
		}
		try {
			// System.out.println("**************");
			seperator = splitStringAndGenerateXpath(seperatorLabelName);

			List<WebElement> cardsTableHeaders = driver.findElements(By.xpath("//div[@class='JFALSeparator']//div["
					+ seperator + "]/preceding::div[@class='JFALCompControlPanel'][" + index
					+ "]//div[@class='JViewport']/div[@class='JTableHeader']//div[@class='HeaderRenderer']"));
			int colIndex = SeleniumWrappers.getColumnNoForColumnHeader(tableHeaderName, cardsTableHeaders);
			int colIndex1 = SeleniumWrappers.getColumnNoForColumnHeader(tableHeaderDescription, cardsTableHeaders);
			System.out.println("ColIndex" + colIndex);
			System.out.println("ColIndex1" + colIndex1);
			sleep(3);
			List<WebElement> list = driver.findElements(By.xpath("//div[@class='JFALSeparator']//div[" + seperator
					+ "]/preceding::div[@class='JFALCompControlPanel'][" + index
					+ "]//div[@class='FALTableCellEditor_StrikeThruField JTextComponent' or contains(@class,'FALTableCellEditor_StrikeThruCheckBox')]"));
			SeleniumWrappers.setTotalTableHeaders(cardsTableHeaders.size());
			// SeleniumWrappers.setCellValue(list);
			int size = SeleniumWrappers.getTotalNumberOfRows(list, driver);
			System.out.println("rowsize" + size);

			for (int row = 0; row < size; row++) {
				sleep(1);

		/*		String s="//div[@class='JFALSeparator']//div[contains(text(),'Profile')]/preceding::div[@class='JFALCompControlPanel']["
						+ index
						+ "]//div[@class='FALTableCellEditor_StrikeThruCheckBox enabled'][contains(@id,'_1_1')]//div[@class='htmlImage']";*/
				
				String s="//div[@class='JFALSeparator']//div[contains(text(),'Profile')]/preceding::div[@class='JFALCompControlPanel'][\"\r\n" + 
						"								+ index\r\n" + 
						"								+ \"]//div[@class='FALTableCellEditor_StrikeThruCheckBox enabled'][contains(@id,'_" + row +"_" + 1 +"')]//div[@class='htmlImage']";
				
						
		
				cellElement = driver.findElement(By.xpath(
						"//div[@class='JFALSeparator']//div[contains(text(),'Profile')]/preceding::div[@class='JFALCompControlPanel']["
								+ index
								+ "]//div[@class='FALTableCellEditor_StrikeThruCheckBox enabled'][contains(@id,'_" + row +"_" + 1 +"')]//div[@class='htmlImage']"));
				String value1 = "";

				String value = cellElement.getCssValue("background-image");
				System.out.println("value:" + value);
				System.out.println("value1:" + value1);
				/*
				 * if(value1== null) { value1=""; }
				 */
				if (value.contains("ok.gif") && value1.equals("")) {
					// System.out.println("Inside if");
					doubleClick(cellElement);
					sleep(2);
					logInfo("CheckBox Clicked");
					break;
				}

			}
		} catch (Exception e) {
			logFail(e.getMessage());
		}
	}

	public int validateCheckBoxInTable(String seperatorLabelName, String tableHeaderName) {
		// int countDefault = 0;
		int row = 0;
		String seperator = " ";
		int index = 1;
		if (seperatorLabelName.equals("Rebate Profiles")) {
			index = 2;
		}
		try {
			System.out.println("**************");
			seperator = splitStringAndGenerateXpath(seperatorLabelName);
			List<WebElement> tableHeaders = driver.findElements(By.xpath("//div[@class='JFALSeparator']//div["
					+ seperator + "]/preceding::div[@class='JFALCompControlPanel'][" + index
					+ "]//div[@class='JViewport']/div[@class='JTableHeader']//div[@class='HeaderRenderer']"));
			System.out.println(tableHeaders);
			int colIndex = SeleniumWrappers.getColumnNoForColumnHeader(tableHeaderName, tableHeaders);
			System.out.println("ColIndex--->" + colIndex);
			List<WebElement> list = driver.findElements(By.xpath("//div[@class='JFALSeparator']//div[" + seperator
					+ "]/preceding::div[@class='JFALCompControlPanel'][" + index
					+ "]//div[@class='FALTableCellEditor_StrikeThruField JTextComponent']"));
			SeleniumWrappers.setTotalTableHeaders(tableHeaders.size());

			int size = SeleniumWrappers.getTotalNumberOfRows(list, driver);
			System.out.println("Size of table" + size);
			for (row = 0; row < size; row++) {
				WebElement element = driver.findElement(By.xpath("//div[@class='JFALSeparator']//div[" + seperator
						+ "]/preceding::div[@class='JFALCompControlPanel'][" + index
						+ "]//div[@class='FALTableCellEditor_StrikeThruCheckBox enabled'][contains(@id,'_" + row + "_"
						+ colIndex + "')]//div[@class='htmlImage']"));
				System.out.println("Rebate element ::" + element);
				String value = element.getCssValue("background-image");
				System.out.println("Rebate value ::" + value);
				if (value.contains("ok.gif")) {
					// countDefault = countDefault + 1;
					logInfo("CheckBox Clicked");
					break;

				} else if (value.contains("unselected.gif")) {
					logInfo("CheckBox Unselected");
					continue;

				} else if (value.contains("delete.gif")) {
					System.out.println("Inside else if delete gif");
					logInfo("CheckBox Deleted");
					break;
				}
			}
			if (row == size) {
				row = 0;
				// row = -1;
				logInfo("No Rows in a table");
			}
		} catch (Exception e) {
			logFail(e.getMessage());
		}
		return row;
	}

	/* To pick country from dropdown for same label name in different separator */
	public void selectACountryFromDropdown(int index, String labelName) {
		WebElement comboDropDown = null;
		WebElement comboOptionForCountry = null;
		try {

			comboDropDown = driver.findElements(By.xpath(
					"//div[@class='JFALLabel']//div[text()='Country']//preceding::div[@class='JFALCompControlPanel'][1]/div[@class='JFALComboBox']//div[@class='MetalComboBoxButton enabled JButton']"))
					.get(index);
			sleep(2);
			System.out.println(comboDropDown);
			sleep(3);
			if(InitExecution.parallel_Mode.equalsIgnoreCase("yes")) {
				logInfo("Action Click to select dropdown");
				isDisplayedThenActionClick(comboDropDown, "Combo Dropdown"); 
				
				logInfo("ActionClick Done");
			}
			
			//isDisplayedThenClick(comboDropDown, "Combo Dropdown");
	
			comboOptionForCountry = driver
					.findElement(By.xpath("//div[@class='BasicComboPopup_1']/div/div[@class='htmlString']"));
			sleep(2);
			isDisplayedThenClick(comboOptionForCountry, "Country");
			sleep(2);
		} catch (Exception ex) {
			logFail("Country dropdown not present");
		}
	}

	public void selectAStateFromDropdown(int index, String labelName) {
		WebElement comboDropDown = null;
		List<WebElement> comboOptionForCountry = null;
		try {
			comboDropDown = driver.findElements(By.xpath(
					"//div[@class='JFALLabel']//div[text()='Country']//preceding::div[@class='JFALCompControlPanel'][1]/div[@class='JFALComboBox']//div[@class='MetalComboBoxButton enabled JButton']"))
					.get(index);
			sleep(2);
			System.out.println(comboDropDown);
			isDisplayedThenClick(comboDropDown, "Combo Dropdown");
			comboOptionForCountry = driver
					.findElements(By.xpath("//div[@class='BasicComboPopup_1']/div/div[@class='htmlString']"));
			String option = getText(comboOptionForCountry.get(0));
			// --Logic Issue //isDisplayedThenClick(option, "Country");
		} catch (Exception ex) {
			logFail("Country dropdown not present");
		}
	}

	/* To Enter Postal for same label name in different separator */
	public void enterPostalcodefromApplication(String seperatorLabelName, String labelName, String input, int index) {
		String seperator = " ";
		String label = " ";
		WebElement textBox;
		try {
			seperator = splitStringAndGenerateXpath(seperatorLabelName);
			label = splitStringAndGenerateXpath(labelName);
			textBox = driver.findElements(By.xpath(
					"//div[@class='JFALSeparator']//div[" + seperator + "]/preceding::div[@class='JFALLabel']/div["
							+ label + "]/preceding::div[@class='JFALCompControlPanel'][1]//input"))
					.get(index);
			textBox.clear();
			isDisplayedThenEnterText(textBox, "TextBox", input);
			logPass(input + " is entered in text field");
		} catch (Exception ex) {
			logFail("Post code text box not present");
		}
	}

	public String getCustomerNumberWithNoHierarchy() {
		String clientCountry, cardType, clientName;
		String clientSpecificQuery = "", CustomerNumber = "";
		clientName = PropUtils.getPropValue(configProp, "clientName");
		clientCountry = PropUtils.getPropValue(configProp, "clientCountry");

		cardType = PropUtils.getPropValue(configProp, "cardType");
		if (clientName.equals("SHELL")) {
			if (clientCountry.equals("MY")) {
				clientSpecificQuery = "Shell Pre-Paid Card";
			} else if (cardType.contains("APA")) {
				clientSpecificQuery = "Shell Pre-Paid Card (" + clientCountry + ")";
			} else {
				clientSpecificQuery = "Shell Partner Card (" + clientCountry + ")";
			}
			CustomerNumber = "SELECT c.customer_no FROM m_customers c LEFT JOIN relationships r ON r.member_oid = c.customer_mid INNER JOIN Card_programs ON c.CARD_PROGRAM_OID = Card_programs.CARD_PROGRAM_OID WHERE r.relationship_oid IS NULL AND Card_programs.DESCRIPTION = '"
					+ clientSpecificQuery + "' and rownum=1";
		} else if (clientName.equals("EMAP")) {

			clientSpecificQuery = "card_programs.client_mid=(select Client_mid from m_clients where name ='"
					+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountry) + "')";
			CustomerNumber = "SELECT c.customer_no FROM m_customers c LEFT JOIN relationships r ON r.member_oid = c.customer_mid INNER JOIN Card_Programs ON c.CARD_PROGRAM_OID = Card_programs.CARD_PROGRAM_OID WHERE r.relationship_oid IS NULL AND "
					+ clientSpecificQuery + " and rownum=1";
		}

		else if (clientName.equals("WFE")) {

			clientSpecificQuery = "card_programs.client_mid=(select Client_mid from m_clients where name ='"
					+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountry) + "')";
			CustomerNumber = "SELECT c.customer_no FROM m_customers c LEFT JOIN relationships r ON r.member_oid = c.customer_mid INNER JOIN Card_Programs ON c.CARD_PROGRAM_OID = Card_programs.CARD_PROGRAM_OID WHERE r.relationship_oid IS NULL AND "
					+ clientSpecificQuery + " and rownum=1";
		}

		CustomerNumber = connectDBAndGetValue(CustomerNumber, PropUtils.getPropValue(configProp, "sqlODSServerName"));
		System.out.println("Customer Number" + CustomerNumber);
		return CustomerNumber;
	}
	
	public String getCustomerNumberWithHierarchy() {
		String clientCountry, cardType, clientName;
		String clientSpecificQuery = "", CustomerNumber = "";
		clientName = PropUtils.getPropValue(configProp, "clientName");
		clientCountry = PropUtils.getPropValue(configProp, "clientCountry");

		cardType = PropUtils.getPropValue(configProp, "cardType");
		if (clientName.equals("SHELL")) {
			if (clientCountry.equals("MY")) {
				clientSpecificQuery = "Shell Pre-Paid Card";
			} else if (cardType.contains("APA")) {
				clientSpecificQuery = "Shell Pre-Paid Card (" + clientCountry + ")";
			} else {
				clientSpecificQuery = "Shell Partner Card (" + clientCountry + ")";
			}
			CustomerNumber = "SELECT c.customer_no FROM m_customers c LEFT JOIN relationships r ON r.member_oid = c.customer_mid INNER JOIN Card_programs ON c.CARD_PROGRAM_OID = Card_programs.CARD_PROGRAM_OID INNER JOIN RELATIONSHIP_ASSIGNMENTS ra on ra.RELATIONSHIP_OID = r.relationship_oid WHERE r.relationship_oid IS NOT NULL AND Card_programs.DESCRIPTION = '"
					+ clientSpecificQuery + "'  AND ra.EXPIRES_ON NOT like '%-99' and rownum=1";
		} else if (clientName.equals("EMAP")) {

			clientSpecificQuery = "card_programs.client_mid=(select Client_mid from m_clients where name ='"
					+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountry) + "')";
			CustomerNumber = "SELECT c.customer_no FROM m_customers c LEFT JOIN relationships r ON r.member_oid = c.customer_mid INNER JOIN Card_Programs ON c.CARD_PROGRAM_OID = Card_programs.CARD_PROGRAM_OID INNER JOIN RELATIONSHIP_ASSIGNMENTS ra on ra.RELATIONSHIP_OID = r.relationship_oid WHERE r.relationship_oid IS NOT NULL AND "
					+ clientSpecificQuery + "  AND ra.EXPIRES_ON NOT like '%-99' and rownum=1";
		}

		else if (clientName.equals("WFE")) {

			clientSpecificQuery = "card_programs.client_mid=(select Client_mid from m_clients where name ='"
					+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountry) + "')";
			CustomerNumber = "SELECT c.customer_no FROM m_customers c LEFT JOIN relationships r ON r.member_oid = c.customer_mid INNER JOIN Card_Programs ON c.CARD_PROGRAM_OID = Card_programs.CARD_PROGRAM_OID INNER JOIN RELATIONSHIP_ASSIGNMENTS ra on ra.RELATIONSHIP_OID = r.relationship_oid WHERE r.relationship_oid IS NOT NULL AND "
					+ clientSpecificQuery + "  AND ra.EXPIRES_ON NOT like '%-99' and rownum=1";
		}

		CustomerNumber = connectDBAndGetValue(CustomerNumber, PropUtils.getPropValue(configProp, "sqlODSServerName"));
		System.out.println("Customer Number" + CustomerNumber);
		return CustomerNumber;
	}

	public void getSHELLCustomerNumberHasInvoices() {
		String clientCountry, cardType;
		clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		cardType = PropUtils.getPropValue(configProp, "cardType");
		String cardTypeDesc = "";
		String customerInvoice = "";

		if (clientCountry.contains("MY")) {
			if (cardType.contains("APA")) {
				cardTypeDesc = "Shell Pre-Paid Card";
			}

		} else {

			if (cardType.contains("APA")) {
				cardTypeDesc = "Shell Pre-Paid Card (" + clientCountry + ")";
			} else {
				cardTypeDesc = "Shell Partner Card (" + clientCountry + ")";
			}
		} // 'Customer Invoice by ICP'

		if (clientCountry.contains("MY")) {
			customerInvoice = "'APA Invoice - Customer-related Financial Transactions'";
		} else {
			customerInvoice = "'Customer Invoice by ICP'";
		}

		String queryToGetInvoiceCustomer = "Select distinct mc.customer_no from stored_reports sr inner join m_customers mc on sr.member_oid = mc.customer_mid inner join card_programs cp on mc.card_program_oid = cp.card_program_oid where sr.report_type_oid = (Select report_type_oid from report_types rt where rt.description ="
				+ customerInvoice + "and rt.client_mid = cp.client_mid) and cp.description = '" + cardTypeDesc
				+ "' and Rownum <=1";
		customerNumberValue = connectDBAndGetValue(queryToGetInvoiceCustomer,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		System.out.println("Customer Number" + customerNumberValue);
	}

	public String getDriverCardNumberFromDB(String client) {
		String clientCountry, cardType;
		String cardTypeDesc = "";
		String cardNumber="";
		clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		String clientName=PropUtils.getPropValue(configProp, "clientName");
		cardType = PropUtils.getPropValue(configProp, "cardType");
		if (client.contains("SHELL")) {
			if (clientCountry.contains("MY")) {
				if (cardType.contains("APA")) {
					cardTypeDesc = "Shell Pre-Paid Card";
				}
			} else {
				if (cardType.contains("APA")) {
					cardTypeDesc = "Shell Pre-Paid Card (" + clientCountry + ")";
				} else {
					cardTypeDesc = "Shell Partner Card (" + clientCountry + ")";
				}
			}
			client = client.replace("SHELL", "SH ");
			String queryToGetCardDriverName = "select card_no from cards c inner join  m_customers mc on mc.customer_mid = c.customer_mid inner join card_programs cp on c.card_program_oid = cp.card_program_oid inner join card_status cs on cs.card_status_oid = c.card_status_oid inner join  m_customers mc on mc.customer_mid = c.customer_mid inner join accounts acc on mc.customer_mid=acc.customer_mid inner join account_status accs on accs.account_status_oid=acc.account_status_oid inner join account_sub_status accss on accss.account_status_oid = accs.account_status_oid Where accs.description like '%Active' and accss.description like '%Active' and c.vehicle_oid IS NULL and c.replace_card_oid IS NULL and (cs.description = 'Card Processed' OR cs.description like '%Active') and c.expires_on >=(SELECT PROCESSING_DATE from M_CLIENTS where IE_CLIENT_ID='"
					+ client + "') and cp.description = '" + cardTypeDesc + "' and Rownum <=1";
			cardNumber = connectDBAndGetValue(queryToGetCardDriverName,
					PropUtils.getPropValue(configProp, "sqlODSServerName"));
		} else if (client.contains("WFE")) {
			client = client.replace("WFE", "WFE ");
			String clientCountryName=PropUtils.getPropValue(configProp, clientName+"_"+clientCountry);
			String queryToGetCardDriverName = "select card_no from cards c inner join  m_customers mc on mc.customer_mid = c.customer_mid inner join card_programs cp on c.card_program_oid = cp.card_program_oid inner join card_status cs on cs.card_status_oid = c.card_status_oid inner join  m_customers mc on mc.customer_mid = c.customer_mid inner join accounts acc on mc.customer_mid=acc.customer_mid inner join account_status accs on accs.account_status_oid=acc.account_status_oid inner join account_sub_status accss on accss.account_status_oid = accs.account_status_oid	inner join cost_centres ccs on ccs.card_oid=c.card_oid Where accs.description = 'Active' and accss.description = 'Active' and c.replace_card_oid IS NULL and (cs.description = 'Normal Service') and c.expires_on >=(SELECT PROCESSING_DATE from M_CLIENTS where SHORT_NAME='"
					+ client + "') and mc.client_mid = (select client_mid from m_clients where name='"+clientCountryName+"')";
			cardNumber = connectDBAndGetValue(queryToGetCardDriverName,
					PropUtils.getPropValue(configProp, "sqlODSServerName"));
		}

		System.out.println("CardNumber : " + cardNumber);
		return cardNumber;
	}

	public String getCardNumberhavingNoCostCentreFromDB() {
		String clientCountry, cardType, clientName;
		String cardTypeDesc = "";
		String queryToGetCardDriverName;
		clientName = PropUtils.getPropValue(configProp, "clientName");
		clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		cardType = PropUtils.getPropValue(configProp, "cardType");
		if (clientCountry.contains("MY")) {
			if (cardType.contains("APA")) {
				cardTypeDesc = "Shell Pre-Paid Card";
			}
		} else {
			if (cardType.contains("APA")) {
				cardTypeDesc = "Shell Pre-Paid Card (" + clientCountry + ")";
			} else {
				cardTypeDesc = "Shell Partner Card (" + clientCountry + ")";
			}
		}
		if (clientName.equals("WFE")) {
			queryToGetCardDriverName = "select card_no from cards c  Where card_oid NOT IN (select card_oid from cost_centres) and replace_card_oid IS NULL and Rownum <=1";
		} else {
			queryToGetCardDriverName = "select card_no from cards c inner join card_programs cp on c.card_program_oid = cp.card_program_oid inner join card_status cs on cs.card_status_oid = c.card_status_oid Where c.card_oid NOT IN (select card_oid from cost_centres) and c.replace_card_oid IS NULL and (cs.description like '%Active') "
					+ " and cp.description = '" + cardTypeDesc + "' and Rownum <=1";
		}
		String CardNo = connectDBAndGetValue(queryToGetCardDriverName,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		System.out.println("CardNo : " + CardNo);
		return CardNo;
	}

	// Added by Sasi on 14/02/2019 --> to get validation msg in the pop up
	public void verifyValidationResultInPopUp(String expectedResult) {

		try {
			String element1 = splitStringAndGenerateXpath(expectedResult);
			// System.out.print(element1);
			waitToCheckElementIsDisplayed(By.xpath(
					"//div[@class='JPanel']//div[@class='JLabel'][2]//div[@class='htmlString'][" + element1 + "]"), 10);
			logPass("Expected results displayed");

		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
	}

	public void searchCustomerNumberHasInvoicesAndValidate(String partialOrFullSearch) {
		getSHELLCustomerNumberHasInvoices();
		clearingAllTextBoxes(textBoxes);
		boolean partialOrFull = true;
		if (partialOrFullSearch.equalsIgnoreCase("partial")) {
			customerNumberValue = getPartialValue(customerNumberValue);
			partialOrFull = false;
		}
		enterValueInTextBox("Filter By", "Customer No", customerNumberValue);
		searchListTorch();
		sleep(5);
		validateSearchTable("Customer No", customerNumberValue, partialOrFull);
	}

	public void getSHELLRemittanceIDHasInvoices() {
		String clientCountry, cardType;
		clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		cardType = PropUtils.getPropValue(configProp, "cardType");
		String cardTypeDesc = "";
		String customerInvoice = "";

		if (clientCountry.contains("MY")) {
			if (cardType.contains("APA")) {
				cardTypeDesc = "Shell Pre-Paid Card";
			}

		} else {
			if (cardType.contains("APA")) {
				cardTypeDesc = "Shell Pre-Paid Card (" + clientCountry + ")";
			} else {
				cardTypeDesc = "Shell Partner Card (" + clientCountry + ")";
			}
		}

		if (clientCountry.contains("MY")) {
			customerInvoice = "'APA Invoice - Customer-related Financial Transactions'";
		} else {
			customerInvoice = "'Customer Invoice by ICP'";
		}

		/*
		 * String queryToGetRemittanceID =
		 * "Select dg.remittance_id from stored_reports sr inner join detail_groups dg on sr.stored_report_oid = dg.stored_report_oid inner join m_customers mc on sr.member_oid = mc.customer_mid inner join card_programs cp on mc.card_program_oid = cp.card_program_oid where sr.report_type_oid = (Select report_type_oid from report_types rt inner join m_clients mcl on rt.client_mid = mcl.client_mid where rt.description = 'Customer Invoice by ICP' and rt.client_mid = (Select client_mid from m_clients mcl where mcl.name= '"
		 * + PropUtils.getPropValue(configProp, clientName + "_" +
		 * clientCountry).replaceAll("\"", "") + "')) and cp.description = '" +
		 * cardTypeDesc + "' and Rownum <=1";
		 */
		String queryToGetRemittanceID = "Select dg.remittance_id from stored_reports sr inner join detail_groups dg on sr.stored_report_oid = dg.stored_report_oid inner join m_customers mc on sr.member_oid = mc.customer_mid inner join card_programs cp on mc.card_program_oid = cp.card_program_oid where sr.report_type_oid = (Select report_type_oid from report_types rt where rt.description ="
				+ customerInvoice + " and rt.client_mid  = cp.client_mid) and cp.description = '" + cardTypeDesc
				+ "' and Rownum <=1";
		remittanceIDValue = connectDBAndGetValue(queryToGetRemittanceID,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		System.out.println("Remittance ID" + remittanceIDValue);
	}

	public void searchRemittanceIDHasInvoicesAndValidate(String partialOrFullSearch) {
		getSHELLRemittanceIDHasInvoices();
		// clearingAllTextBoxes(textBoxes);
		boolean partialOrFull = true;
		if (partialOrFullSearch.equalsIgnoreCase("partial")) {
			remittanceIDValue = getPartialValue(remittanceIDValue);
			partialOrFull = false;
		}
		enterValueInTextBox("Filter By", "Remittance ID", remittanceIDValue);
		searchListTorch();
		sleep(5);
		validateSearchTable("Remittance ID", remittanceIDValue, partialOrFull);
	}

	public void searchCustomerNumberAndPartRemittanceIDdValidate(String partialOrFullSearch) {
		getSHELLCustomerNumberHasInvoices();
		clearingAllTextBoxes(textBoxes);
		boolean partialOrFull = true;
		if (partialOrFullSearch.equalsIgnoreCase("partial")) {
			customerNumberValue = getPartialValue(customerNumberValue);
			partialOrFull = false;
		}
		enterValueInTextBox("Filter By", "Customer No", customerNumberValue);
		searchListTorch();
		sleep(5);
		searchRemittanceIDHasInvoicesAndValidate("Partial");
		validateSearchTable("Customer No", customerNumberValue, partialOrFull);
	}

	// Added by Sasi on 14/02/2019 --> to get current processing date from DB
	private String getDBDetailsFromProperties = "";

	public String getCurrentIFCSDateFromDB(String clientCountry) {
		String currentIFCSDate, queryToResetLogonCount = "";
		getDBDetailsFromProperties = PropUtils.getPropValue(configProp, "sqlODSServerName");
		String clientName = PropUtils.getPropValue(configProp, "clientName");
		String clientCountryValue = PropUtils.getPropValue(configProp, "clientCountry");
		if (clientCountry.contains("SHELL")) {
			clientCountry = clientCountry.replace("SHELL", "SH "); // SH CZ --> czech
			queryToResetLogonCount = "SELECT PROCESSING_DATE from M_CLIENTS where IE_CLIENT_ID='" + clientCountry + "'";
		} else if (clientCountry.contains("EMAP")) {
			clientCountry = clientCountry.replace("EMAP", "EX ");
			queryToResetLogonCount = "SELECT PROCESSING_DATE from M_CLIENTS where IE_CLIENT_ID='" + clientCountry + "'";
		} else if (clientCountry.contains("BP")) {

			queryToResetLogonCount = "SELECT PROCESSING_DATE from M_CLIENTS where Name ='"
					+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountryValue) + "'";
		}

		else if (clientCountry.contains("OTI")) {

			queryToResetLogonCount = "SELECT PROCESSING_DATE from M_CLIENTS where Name ='"
					+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountryValue) + "'";
		} else if (clientName.contains("CHEVRON") || clientName.contains("CHV")) {

			queryToResetLogonCount = "SELECT PROCESSING_DATE from M_CLIENTS where Name ='"
					+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountryValue) + "'";
		}

		else if (clientName.contains("ZEnergy")) {

			clientCountry = clientCountry.replace("ZEnergy", "ZE ");
			queryToResetLogonCount = "SELECT PROCESSING_DATE from M_CLIENTS where IE_CLIENT_ID='" + clientCountry + "'";
		}

		else if (clientName.contains("WFE")) {
			queryToResetLogonCount = "SELECT PROCESSING_DATE from M_CLIENTS where Name ='"
					+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountryValue) + "'";
		}

		currentIFCSDate = connectDBAndGetValue(queryToResetLogonCount, getDBDetailsFromProperties);
		System.out.println("Current Date: :" + currentIFCSDate);
		return currentIFCSDate;
	}

	public String enterADateValueInStatusBeginDateField(String beginDate, String currentIFCSDate) {

		String beginDateValue = "";
		try {
			DateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
			dateFormatter.parse(currentIFCSDate);
			Date newDate;
			Calendar cal = Calendar.getInstance();
			cal.setTime(dateFormatter.parse(currentIFCSDate));

			if (beginDate.equals("Past")) {
				cal.add(Calendar.MONTH, -3);

			} else if (beginDate.equals("PastSix")) {
				cal.add(Calendar.MONTH, -6);

			} else if (beginDate.equals("Current")) {
				newDate = cal.getTime();

			} else if (beginDate.equals("WayFuture")) {
				cal.add(Calendar.YEAR, +2);
			} else if (beginDate.equals("MaxCardProduct")) {
				cal.add(Calendar.YEAR, +5);
			}

			else if (beginDate.equals("NextYear")) {
				cal.add(Calendar.YEAR, +1);
			} else if (beginDate.equals("oneDayBefore")) {
				cal.add(Calendar.DATE, -1);
			} else if (beginDate.equals("oneDayAfter")) {
				cal.add(Calendar.DATE, +1);
			} else {
				cal.add(Calendar.MONTH, +3);
			}
			newDate = cal.getTime();
			DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
			beginDateValue = df.format(newDate);

		} catch (Exception e) {
			logFail(e.getMessage());
		}
		return beginDateValue;

	}

	// Added by sasi on 14-02-19
	public String getActiveCustomerNoUsingCardType() {
		String clientName, clientCountry, cardType;
		String cardTypeDesc = "";
		String customerNo = "";
		String queryToGetCustomerNumberHasTransaction;
		clientName = PropUtils.getPropValue(configProp, "clientName");
		clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		cardType = PropUtils.getPropValue(configProp, "cardType");
		if (clientName.equals("SHELL")) {
			if (clientCountry.contains("MY")) {
				if (cardType.contains("APA")) {

					cardTypeDesc = "Shell Pre-Paid Card";
				}
			} else {
				if (cardType.contains("APA")) {
					cardTypeDesc = "Shell Pre-Paid Card (" + clientCountry + ")";
				} else {
					cardTypeDesc = "Shell Partner Card (" + clientCountry + ")";
				}
			}

			queryToGetCustomerNumberHasTransaction = "Select distinct mcu.customer_no from m_customers mcu inner join accounts acc on mcu.customer_mid=acc.customer_mid inner join account_status accs on accs.account_status_oid=acc.account_status_oid inner join account_sub_status accss on acc.account_sub_status_oid=accss.account_sub_status_oid inner join card_programs cp on mcu.card_program_oid = cp.card_program_oid where accs.description like '%Active' and accss.description='Active' and mcu.client_mid =(Select client_mid from m_clients where name ='"
					+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountry).replaceAll("\"", "")
					+ "') and cp.description = '" + cardTypeDesc + "' and Rownum <=1";
			customerNo = connectDBAndGetValue(queryToGetCustomerNumberHasTransaction,
					PropUtils.getPropValue(configProp, "sqlODSServerName"));
		} else {
			System.out.println("Client name:: " + clientName);
			System.out.println("Country name :: " + clientCountry);
			
			System.out.println("Client  :: " + PropUtils.getPropValue(configProp, clientName + "_" + clientCountry).replaceAll("\"", ""));
			queryToGetCustomerNumberHasTransaction = "Select distinct mcu.customer_no from m_customers mcu inner join accounts acc on mcu.customer_mid=acc.customer_mid inner join account_status accs on accs.account_status_oid=acc.account_status_oid inner join account_sub_status accss on acc.account_sub_status_oid=accss.account_sub_status_oid inner join card_programs cp on mcu.card_program_oid = cp.card_program_oid where accss.description in ('Active','ACTIVE') and (accs.description in ('Active','ACTIVE') or accs.description in ('1 - Active','ACTIVE')) and mcu.client_mid =(Select client_mid from m_clients where name ='"
					+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountry).replaceAll("\"", "")
					+ "') and Rownum <=1";
			
			
			customerNo = connectDBAndGetValue(queryToGetCustomerNumberHasTransaction,
					PropUtils.getPropValue(configProp, "sqlODSServerName"));
		}
		System.out.println("customerNo:: " + customerNo);
		return customerNo;
	}

	// Added by sasi on 14-03-19
	public String getCustomerNoHavingNoBulkReissueRequestUsingCardType() {
		String clientCountry, cardType;
		String cardTypeDesc = "";
		clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		cardType = PropUtils.getPropValue(configProp, "cardType");
		if (clientCountry.contains("MY")) {
			if (cardType.contains("APA")) {
				cardTypeDesc = "Shell Pre-Paid Card";
			}
		} else {
			if (cardType.contains("APA")) {
				cardTypeDesc = "Shell Pre-Paid Card (" + clientCountry + ")";
			} else {
				cardTypeDesc = "Shell Partner Card (" + clientCountry + ")";
			}
		}

		String queryToGetCustomer = "Select distinct mc.customer_no from m_customers mc inner join card_programs cp on mc.card_program_oid = cp.card_program_oid where mc.customer_mid In (select customer_mid from cards) and mc.customer_mid Not In (select customer_mid from CARD_BULK_REISSUES) "
				+ " and cp.description = '" + cardTypeDesc + "' and Rownum <=1";
		String customerNo = connectDBAndGetValue(queryToGetCustomer,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));

		System.out.println("customerNo:: " + customerNo);
		return customerNo;
	}

	public String getCustomerNoHasTransaction(String clientCountry) {
		String valueGot;
		String queryToGetCustomerNumberHasTransaction = "Select distinct mcu.customer_no from m_customers mcu "
				+ "inner join m_clients mcl on mcu.client_mid = mcl.client_mid "
				+ "inner join transactions tr on mcu.customer_mid = tr.customer_mid "
				+ "inner join accounts a on mcu.customer_mid = a.customer_mid inner join account_status acs on acs.account_status_oid=a.account_status_oid "
				+ "where mcu.client_mid =(Select client_mid from m_clients where name ='" + clientCountry
				+ "') and tr.processed_at >= mcl.processing_date - 365 and acs.description like '%Active%' and mcu.customer_mid NOT IN (select member_oid from relationships)"
				+ "and tr.processed_at > a.LAST_BILLED_ON and rownum = 1";
		valueGot = connectDBAndGetValue(queryToGetCustomerNumberHasTransaction,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		System.out.println("Value Got:: " + valueGot);
		return valueGot;
	}

	// Added by sasi on 15-02-19 --> is to view and click the tabs in the menu
	public void verifyAndClickingTabs(String expectedResult, String action) {

		WebElement tabs = null;

		try {
			String element1 = splitStringAndGenerateXpath(expectedResult);
			// System.out.print(element1);
			tabs = driver.findElement(
					By.xpath("//div[@class='JFALTabbedPane']//div[@class='htmlString'][" + element1 + "]"));
			isDisplayed(tabs, expectedResult + " Expected tabs are displayed");

			if (action == "click") {
				isDisplayedThenClick(tabs, expectedResult + " Expected tab is clicked");
			} else if (action == "noClick") {
				logPass(expectedResult + " Expected tab is displayed and clicked action is not needed");
			} else {
				logFail(expectedResult + " Expected tab is displayed and unable to do click action");
			}

		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
	}

	public String getValueFromProtectedTextBox(String seperatorLabelName, String labelName) {
		String seperator = " ";
		String label = " ";
		WebElement textBox;
		String text = " ";
		try {
			seperator = splitStringAndGenerateXpath(seperatorLabelName);
			label = splitStringAndGenerateXpath(labelName);
			textBox = driver.findElement(By.xpath(
					"//div[@class='JFALSeparator']//div[" + seperator + "]/preceding::div[@class='JFALLabel']/div["
							+ label + "]/preceding::div[@class='JFALCompControlPanel'][1]//div[@class='htmlString']"));
			sleep(3);
			text = textBox.getText();
			logPass("Text value is " + text);
		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
		return text;
	}

	public void getFieldType() {
		try {
			List<WebElement> box = driver.findElements(By.xpath("//div[@class='JFALTextField JTextComponent']"));
			int boxSize = box.size();
			// System.out.println(boxSize);
			for (int i = 0; i < boxSize; i++) {
				String tagName = box.get(i).findElement(By.xpath("./*[@class='htmlInput'] OR [@class='htmlString']"))
						.getTagName();
				System.out.println(tagName);
				if (tagName.equals("div")) {
					logPass("Field are Protected");
				} else if (tagName.equals("input")) {
					logPass("Field are editable");
				} else
					logFail("Invalid Tag");
			}
		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
	}

	public String getActiveCardsWithNoBalance() {
		String clientCountry, cardType;
		String cardTypeDesc = "";
		// clientName = PropUtils.getPropValue(configProp, "clientName");
		clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		cardType = PropUtils.getPropValue(configProp, "cardType");

		if (clientCountry.equals("MY")) {
			cardTypeDesc = "Shell Pre-Paid Card";
		} else if (cardType.contains("APA")) {
			cardTypeDesc = "Shell Pre-Paid Card (" + clientCountry + ")";
		} else {
			cardTypeDesc = "Shell Partner Card (" + clientCountry + ")";
		}
		/*
		 * String cardNumber =
		 * "select CARDS.CARD_NO from Cards INNER JOIN CARD_PROGRAMS ON cards.card_program_oid = card_programs.card_program_oid INNER JOIN CARD_STATUS ON cards.card_status_oid = card_status.card_status_oid INNER JOIN CARD_BALANCES ON CARDS.CARD_BALANCE_OID = CARD_BALANCES.CARD_BALANCE_OID where card_programs.DESCRIPTION = '"
		 * + cardTypeDesc +
		 * "' AND  CARD_STATUS.DESCRIPTION = 'Active' AND cards.replace_card_oid IS NULL AND cards.is_balance_allowed = 'N' and rownum=1"
		 * ;
		 */

		String cardNumber = "select CARDS.CARD_NO from Cards inner join m_customers mc on mc.customer_mid = Cards.customer_mid INNER JOIN CARD_PROGRAMS ON cards.card_program_oid = card_programs.card_program_oid INNER JOIN CARD_STATUS ON cards.card_status_oid = card_status.card_status_oid INNER JOIN CARD_BALANCES ON CARDS.CARD_BALANCE_OID = CARD_BALANCES.CARD_BALANCE_OID inner join  m_customers mc on mc.customer_mid = Cards.customer_mid inner join accounts acc on mc.customer_mid=acc.customer_mid inner join account_status accs on accs.account_status_oid=acc.account_status_oid inner join account_sub_status accss on accss.account_status_oid = accs.account_status_oid Where accs.description like '%Active' and accss.description like '%Active' and card_programs.DESCRIPTION = '"
				+ cardTypeDesc
				+ "' AND  CARD_STATUS.DESCRIPTION = 'Active' AND cards.replace_card_oid IS NULL AND cards.is_balance_allowed = 'N' and rownum=1";
		cardNumber = connectDBAndGetValue(cardNumber, PropUtils.getPropValue(configProp, "sqlODSServerName"));
		System.out.println("Card Number" + cardNumber);
		return cardNumber;

	}

	// interface

	public String getActiveCardsforInterface() {
		String clientCountry, cardType;
		String cardTypeDesc = "";
		// clientName = PropUtils.getPropValue(configProp, "clientName");
		clientCountry = PropUtils.getPropValue(configProp, "clientCountry");

		cardType = PropUtils.getPropValue(configProp, "cardType");

		if (clientCountry.contains("MY")) {

			cardTypeDesc = "Shell Pre-Paid Card";

		} else {
			if (cardType.contains("APA")) {
				cardTypeDesc = "Shell Pre-Paid Card (" + clientCountry + ")";
			} else {
				cardTypeDesc = "Shell Partner Card (" + clientCountry + ")";
			}
		}
		String queryForcardNumber = "select CARDS.CARD_NO from Cards inner join m_customers mc on mc.customer_mid = Cards.customer_mid inner join accounts acc on mc.customer_mid=acc.customer_mid inner join account_status accs on accs.account_status_oid=acc.account_status_oid inner join account_sub_status accss on acc.account_sub_status_oid=accss.account_sub_status_oid INNER JOIN CARD_PROGRAMS ON cards.card_program_oid = card_programs.card_program_oid INNER JOIN CARD_STATUS ON cards.card_status_oid = card_status.card_status_oid INNER JOIN CARD_BALANCES ON CARDS.CARD_BALANCE_OID = CARD_BALANCES.CARD_BALANCE_OID where  accs.description like '%Active' and accss.description like '%Active' and card_programs.DESCRIPTION = '"
				+ cardTypeDesc
				+ "' AND  CARD_STATUS.DESCRIPTION = 'Active' AND cards.replace_card_oid IS NULL and rownum=1";
		String cardNumber = connectDBAndGetValue(queryForcardNumber,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));

		System.out.println("Card Number" + cardNumber);
		return cardNumber;

	}

	public String getClientSpecificCardNumber() {
		String clientName, clientCountry, cardType;
		clientName = PropUtils.getPropValue(configProp, "clientName");
		clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		String queryToGetCardNo;
		System.out.println("************************" + clientName + "#####################");
		if (clientName.equals("SHELL")) {
			cardType = PropUtils.getPropValue(configProp, "cardType");
			String cardTypeDesc = "";
			if (clientCountry.contains("MY")) {
				if (cardType.contains("APA")) {
					cardTypeDesc = "Shell Pre-Paid Card";
				}

			} else {
				if (cardType.contains("APA")) {
					cardTypeDesc = "Shell Pre-Paid Card (" + clientCountry + ")";
				} else {
					cardTypeDesc = "Shell Partner Card (" + clientCountry + ")";
				}
			}
			queryToGetCardNo = "Select c.card_no from cards c inner join card_programs cp on c.card_program_oid = cp.card_program_oid where cp.client_mid = (Select client_mid from m_clients where name = '"
					+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountry).replaceAll("\"", "")
					+ "') and cp.description = '" + cardTypeDesc + "' and Rownum <=1";
		}

		else {
			queryToGetCardNo = "Select c.card_no from cards c inner join card_programs cp on c.card_program_oid = cp.card_program_oid where cp.client_mid = (Select client_mid from m_clients where name = '"
					+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountry).replaceAll("\"", "")
					+ "') and Rownum <=1";

		}
		cardNumberValue = connectDBAndGetValue(queryToGetCardNo,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));

		System.out.println("Card Number" + cardNumberValue);
		return cardNumberValue;
	}

	// getActiveCardsWithBalance - Renamed as getCardsWithStatusAndWithBalance
	public String getCardsWithStatusAndWithBalance(String cardStatus) {
		String clientCountry, cardType, clientName;
		String cardTypeDesc = "";
		String cardNumber = "";
		clientName = PropUtils.getPropValue(configProp, "clientName");
		System.out.println(clientName);
		clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		System.out.println(clientCountry);

		System.out.println("************************" + clientName + "#####################");
		if (clientName.equals("SHELL")) {
			cardType = PropUtils.getPropValue(configProp, "cardType");
			if (clientCountry.equals("MY")) {
				cardTypeDesc = "Shell Pre-Paid Card";
			} else if (cardType.contains("APA")) {
				cardTypeDesc = "Shell Pre-Paid Card (" + clientCountry + ")";
			} else {
				cardTypeDesc = "Shell Partner Card (" + clientCountry + ")";
			}
			cardNumber = "select CARDS.CARD_NO from Cards inner join m_customers mc on mc.customer_mid = Cards.customer_mid INNER JOIN CARD_PROGRAMS ON cards.card_program_oid = card_programs.card_program_oid INNER JOIN CARD_STATUS ON cards.card_status_oid = card_status.card_status_oid INNER JOIN CARD_BALANCES ON CARDS.CARD_BALANCE_OID = CARD_BALANCES.CARD_BALANCE_OID inner join  m_customers mc on mc.customer_mid = Cards.customer_mid inner join accounts acc on mc.customer_mid=acc.customer_mid inner join account_status accs on accs.account_status_oid=acc.account_status_oid inner join account_sub_status accss on accss.account_status_oid = accs.account_status_oid Where accs.description like '%Active' and accss.description like '%Active' and card_programs.DESCRIPTION = '"
					+ cardTypeDesc + "' AND  CARD_STATUS.DESCRIPTION = '" + cardStatus + "'"
					+ " AND  cards.expires_on >=(SELECT PROCESSING_DATE from M_CLIENTS where name ='"
					+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountry).replaceAll("\"", "")
					+ "') AND cards.replace_card_oid IS NULL AND cards.is_balance_allowed = 'Y' AND BALANCE > 0 and rownum=1";
			/*
			 * cardNumber =
			 * "select CARDS.CARD_NO from Cards INNER JOIN CARD_PROGRAMS ON cards.card_program_oid = card_programs.card_program_oid inner join m_clients mcl on card_programs.client_mid = mcl.client_mid INNER JOIN CARD_STATUS ON cards.card_status_oid = card_status.card_status_oid INNER JOIN CARD_BALANCES ON CARDS.CARD_BALANCE_OID = CARD_BALANCES.CARD_BALANCE_OID where "
			 * + cardTypeDesc +
			 * " AND  CARD_STATUS.DESCRIPTION = 'Active' AND cards.replace_card_oid IS NULL AND cards.is_balance_allowed = 'Y' AND BALANCE > 0 and rownum=1"
			 * ;
			 */
			cardNumber = connectDBAndGetValue(cardNumber, PropUtils.getPropValue(configProp, "sqlODSServerName"));

		}

		else { // if(clientName.equals("EMAP"))
				// cardTypeDesc = "card_programs.DESCRIPTION = 'Shell Pre-Paid Card (" +
				// clientCountry + ")'";

			cardTypeDesc = "card_programs.client_mid=(select Client_mid from m_clients where name ='"
					+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountry) + "')";

			cardNumber = "select CARDS.CARD_NO from Cards INNER JOIN CARD_PROGRAMS ON cards.card_program_oid = card_programs.card_program_oid inner join m_clients mcl on card_programs.client_mid = mcl.client_mid INNER JOIN CARD_STATUS ON cards.card_status_oid = card_status.card_status_oid INNER JOIN CARD_BALANCES ON CARDS.CARD_BALANCE_OID = CARD_BALANCES.CARD_BALANCE_OID where "
					+ cardTypeDesc + " AND  cards.expires_on >=(SELECT PROCESSING_DATE from M_CLIENTS where name ='"
					+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountry) + "')"
					+ "and CARD_STATUS.DESCRIPTION = '" + cardStatus
					+ "' and cards.replace_card_oid IS NULL and rownum=1";// +
																			// "IE_CLIENT_ID='"+clientName.replace("EMAP",
																			// "EX ")+clientCountry + "') " + " "
			cardNumber = connectDBAndGetValue(cardNumber, PropUtils.getPropValue(configProp, "sqlODSServerName"));

		}
		System.out.println("Card Number::" + cardNumber);
		return cardNumber;

	}

	public String getActiveCardsWithBalanceAndRowIndex(int rowIndex) {
		String clientCountry, cardType, cardNumber;
		String cardTypeDesc = "";
		String clientName = PropUtils.getPropValue(configProp, "clientName");
		clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		System.out.println("************************" + clientName + "#####################");
		if (clientName.equals("SHELL")) {

			cardType = PropUtils.getPropValue(configProp, "cardType");
			if (clientCountry.equals("MY")) {
				cardTypeDesc = "Shell Pre-Paid Card";
			} else if (cardType.contains("APA")) {
				cardTypeDesc = "Shell Pre-Paid Card (" + clientCountry + ")";
			} else {
				cardTypeDesc = "Shell Partner Card (" + clientCountry + ")";
			}
			cardNumber = "select CARDS.CARD_NO from Cards inner join  m_customers mc on mc.customer_mid = Cards.customer_mid INNER JOIN CARD_PROGRAMS ON cards.card_program_oid = card_programs.card_program_oid INNER JOIN CARD_STATUS ON cards.card_status_oid = card_status.card_status_oid INNER JOIN CARD_BALANCES ON CARDS.CARD_BALANCE_OID = CARD_BALANCES.CARD_BALANCE_OID inner join  m_customers mc on mc.customer_mid = Cards.customer_mid inner join accounts acc on mc.customer_mid=acc.customer_mid inner join account_status accs on accs.account_status_oid=acc.account_status_oid inner join account_sub_status accss on accss.account_status_oid = accs.account_status_oid Where accs.description like '%Active' and accss.description like '%Active' and card_programs.DESCRIPTION = '"
					+ cardTypeDesc
					+ "' AND  CARD_STATUS.DESCRIPTION = 'Active' AND cards.replace_card_oid IS NULL AND cards.is_balance_allowed = 'Y' AND BALANCE > 0";

			cardNumber = connectDBAndGetDBRowValue(cardNumber, PropUtils.getPropValue(configProp, "sqlODSServerName"),
					rowIndex);
		}

		else {

			cardTypeDesc = "card_programs.client_mid=(select Client_mid from m_clients where name ='"
					+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountry) + "')";

			cardNumber = "select CARDS.CARD_NO from Cards INNER JOIN CARD_PROGRAMS ON cards.card_program_oid = card_programs.card_program_oid inner join m_clients mcl on card_programs.client_mid = mcl.client_mid INNER JOIN CARD_STATUS ON cards.card_status_oid = card_status.card_status_oid INNER JOIN CARD_BALANCES ON CARDS.CARD_BALANCE_OID = CARD_BALANCES.CARD_BALANCE_OID where cards.expires_on >=(SELECT PROCESSING_DATE from M_CLIENTS where name ='"
					+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountry)
					+ "') and CARD_STATUS.DESCRIPTION = 'Active' OR CARD_STATUS.DESCRIPTION like '%Normal Service' and "
					+ cardTypeDesc + " AND cards.replace_card_oid IS NULL";
			cardNumber = connectDBAndGetDBRowValue(cardNumber, PropUtils.getPropValue(configProp, "sqlODSServerName"),
					rowIndex);

		}
		System.out.println("Card Number::" + cardNumber);
		return cardNumber;

	}

	public void validateFieldIsProtected(String seperatorLabelName, String labelName) {
		String seperator = " ";
		String label = " ";
		WebElement comboBox;

		try {
			seperator = splitStringAndGenerateXpath(seperatorLabelName);
			label = splitStringAndGenerateXpath(labelName);
			comboBox = driver.findElement(By.xpath(
					"//div[@class='JFALSeparator']//div[" + seperator + "]/preceding::div[@class='JFALLabel']/div["
							+ label + "]/preceding::div[@class='JFALCompControlPanel'][1]//div[@class='htmlString']"));
			sleep(5);
			String color = comboBox.getCssValue("color");
			System.out.println(color);
			String hexColor = convertrgbColorToHex(color);
			System.out.println(hexColor);
			if (hexColor.equals("#b8cfe5")) {
				logPass("Field is Protected");
			} else
				logFail("Field is not Protected");
		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
	}

	// Added by Sasi on 20-02-19
	public String getSpecifiedColValueInSearchTable(String colName) {
		int colIndex = SeleniumWrappers.getColumnNoForColumnHeader(colName, cardsTableHeaders);
		System.out.println("colIndex :" + colIndex);

		int size = SeleniumWrappers.getTotalNumberOfRows(cardsTable, driver);
		String colValue = null;
		System.out.println("come out");
		for (int i = 0; i <= size;) {
			colValue = SeleniumWrappers.getTableDataWithRowAndColumnNumber(colIndex, i, driver);
			System.out.println("colValue : " + colValue);
			if (colValue.equals("")) {
				i++;
			} else {
				colValue = SeleniumWrappers.getTableDataWithRowAndColumnNumber(colIndex, i, driver);
				break;
			}
		}
		return colValue;
	}

	public void validateSearchTablePresence(String seperatorLabelName) {
		// TODO Auto-generated method stub
		String seperator = splitStringAndGenerateXpath(seperatorLabelName);
		List<WebElement> cardsTableWithSeperator = driver.findElements(By.xpath("//div[@class='JFALSeparator']//div["
				+ seperator
				+ "]/preceding::div[@class='JFALCompControlPanel'][1]//div[starts-with(@class,'FALTableCellEditor_StrikeThru')]"));
		System.out.println("cardsTableWithSeperator : " + cardsTableWithSeperator);
		if (cardsTableWithSeperator != null) {
			logPass("Tables appear as per search filter");
		} else {
			logFail("Tables not appear as per search filter");
		}

	}

	public String getActiveCardNumberFromDB() {
		String clientName, clientCountry;
		String cardNumberDB;
		clientName = PropUtils.getPropValue(configProp, "clientName");
		clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		if (clientName.equals("BP")) 
		{
		
			cardNumberDB = "Select c.card_no from m_customers mc inner join cards c on c.customer_mid = mc.customer_mid inner join card_status cs on c.card_status_oid=cs.card_status_oid inner join m_clients mcn on mcn.client_mid = mc.client_mid where (cs.description like ('%Normal Service%') OR cs.description like  ('%NORMAL SERVICE%')) and mcn.name = '"
					+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountry).replaceAll("\"", "")
					+ "' and rownum<=1";
		} else {
			cardNumberDB = "Select c.card_no from m_customers mc inner join cards c on c.customer_mid = mc.customer_mid inner join card_status cs on c.card_status_oid=cs.card_status_oid inner join m_clients mcn on mcn.client_mid = mc.client_mid where (cs.description like ('%Active%') OR cs.description like  ('%ACTIVE%') OR cs.description like ('Normal Service')) and mcn.name = '"
					+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountry).replaceAll("\"", "")
					+ "' and rownum<=1";
		}

		String cardNumber = connectDBAndGetValue(cardNumberDB, PropUtils.getPropValue(configProp, "sqlODSServerName"));
		System.out.println("Card Number" + cardNumber);

		return cardNumber;
	}

	/*
	 * public String getActiveCardNumberFromIFCSDB(String clientName,String
	 * clientCountry) { String clientCountryName; String cardNumberDB;
	 * 
	 * clientCountryName = PropUtils.getPropValue(configProp,
	 * clientName+"_"+clientCountry); System.out.println(clientCountryName);
	 * //clientCountry = PropUtils.getPropValue(configProp, "clientCountry"); if
	 * (clientName.equals("BP") || clientName.equalsIgnoreCase("CHEVRON")||
	 * clientName.equalsIgnoreCase("OTI")) { cardNumberDB =
	 * "Select t.card_no from m_customers mc inner join cards c on c.customer_mid = mc.customer_mid inner join transactions t on t.card_no=c.card_no inner join card_status cs on c.card_status_oid=cs.card_status_oid inner join m_clients mcn on mcn.client_mid = mc.client_mid inner join TRANSACTION_LINE_ITEMS tl on tl.transaction_oid = t.transaction_oid where (cs.description like ('%Normal Service%') OR cs.description like  ('%NORMAL SERVICE%')) and mcn.name = '"
	 * + clientCountryName.replaceAll("\"", "") + "' and rownum<=1"; } else {
	 * cardNumberDB =
	 * "Select t.card_no from m_customers mc inner join cards c on c.customer_mid = mc.customer_mid inner join transactions t on t.card_no=c.card_no inner join card_status cs on c.card_status_oid=cs.card_status_oid inner join m_clients mcn on mcn.client_mid = mc.client_mid inner join TRANSACTION_LINE_ITEMS tl on tl.transaction_oid = t.transaction_oid where (cs.description like ('%Active%') OR cs.description like  ('%ACTIVE%')) and mcn.name = '"
	 * + clientCountryName.replaceAll("\"", "") + "'";// and rownum<=1"; }
	 * //String[] cardNumber=connectDBAndGetDBResults(cardNumberDB,
	 * PropUtils.getPropValue(configProp, "sqlODSServerName")); String cardNumber =
	 * connectDBAndGetValue(cardNumberDB, PropUtils.getPropValue(configProp,
	 * "sqlODSServerName")); //System.out.println("Card Number" +
	 * cardNumber[0]+cardNumber[1]+cardNumber[2]+cardNumber[3]); /*for(int
	 * i=0;i<cardNumber.length;i++) { System.out.println("Card Number" +
	 * cardNumber[i]); }
	 * 
	 * return cardNumber; }
	 */

	public String getCardNumberFromIFCSDB(String clientName, String clientCountry, String cardStatus) {
		String clientCountryName;
		String cardNumberDB;

		System.out.println("++++Client name:" + clientName + "++++Client country " + clientCountry);

		clientCountryName = PropUtils.getPropValue(configProp, clientName + "_" + clientCountry);

		if (cardStatus.equalsIgnoreCase("Active")) {

			if (clientName.equals("BP") || clientName.equalsIgnoreCase("CHEVRON") || clientName.equalsIgnoreCase("OTI")) {
				cardNumberDB = "Select distinct t.card_no from m_customers mc "
						+ "inner join cards c on c.customer_mid = mc.customer_mid "
						+ "inner join transactions t on t.card_no=c.card_no "
						+ "inner join card_status cs on c.card_status_oid=cs.card_status_oid "
						+ "inner join m_clients mcn on mcn.client_mid = mc.client_mid "
						+ "inner join TRANSACTION_LINE_ITEMS tlt on tlt.transaction_oid = t.transaction_oid inner join card_controls cc on cc.card_control_profile_oid= c.card_control_profile_oid\r\n"
						+ "inner join time_limits tl on tl.time_limit_oid=cc.time_limit_oid inner join accounts a on a.customer_mid=mc.customer_mid\r\n"
						+ "inner join account_status acs on acs.account_status_oid=a.account_status_oid where (cs.description like ('%Normal Service%') OR cs.description like  ('%NORMAL SERVICE%')) and mcn.name = '"
						+ clientCountryName.replaceAll("\"", "")
						+ "' and c.expires_on >=(SELECT PROCESSING_DATE from M_CLIENTS where Name ='"
						+ clientCountryName
						+ "') and (acs.description like '%Active%' OR acs.description like '%ACTIVE%')";
			} else if(clientName.equalsIgnoreCase("WFE")){
				cardNumberDB = "Select distinct t.card_no from m_customers mc "
						+ "inner join cards c on c.customer_mid = mc.customer_mid "
						+ "inner join transactions t on t.card_no=c.card_no "
						+ "inner join card_status cs on c.card_status_oid=cs.card_status_oid "
						+ "inner join m_clients mcn on mcn.client_mid = mc.client_mid "
						+ "inner join TRANSACTION_LINE_ITEMS tlt on tlt.transaction_oid = t.transaction_oid inner join card_controls cc on cc.card_control_profile_oid= c.card_control_profile_oid\r\n"
						+ "inner join time_limits tl on tl.time_limit_oid=cc.time_limit_oid inner join accounts a on a.customer_mid=mc.customer_mid\r\n"
						+ "inner join account_status acs on acs.account_status_oid=a.account_status_oid where (cs.description like ('%Normal Service%') OR cs.description like  ('%NORMAL SERVICE%')) and mcn.name = '"
						+ clientCountryName.replaceAll("\"", "")
						+ "' and c.expires_on >=(SELECT PROCESSING_DATE from M_CLIENTS where Name ='"
						+ clientCountryName
						+ "') and tl.description='All days, all times' and acs.description like '%Active%'";
			}
				else {
				cardNumberDB = "Select t.card_no from m_customers mc inner join cards c on c.customer_mid = mc.customer_mid inner join transactions t on t.card_no=c.card_no inner join card_status cs on c.card_status_oid=cs.card_status_oid inner join m_clients mcn on mcn.client_mid = mc.client_mid inner join TRANSACTION_LINE_ITEMS tl on tl.transaction_oid = t.transaction_oid where (cs.description like ('%Active%') OR cs.description like  ('%ACTIVE%')) and mcn.name = '"
						+ clientCountryName.replaceAll("\"", "") + "'";// and rownum<=1";
			}
		} else {
			cardNumberDB = "Select distinct t.card_no from m_customers mc "
					+ "inner join cards c on c.customer_mid = mc.customer_mid "
					+ "inner join transactions t on t.card_no=c.card_no "
					+ "inner join card_status cs on c.card_status_oid=cs.card_status_oid "
					+ "inner join m_clients mcn on mcn.client_mid = mc.client_mid "
					+ "inner join TRANSACTION_LINE_ITEMS tl on tl.transaction_oid = t.transaction_oid inner join card_controls cc on cc.card_control_profile_oid= c.card_control_profile_oid\r\n"
					+ "inner join time_limits tl on tl.time_limit_oid=cc.time_limit_oid inner join accounts a on a.customer_mid=mc.customer_mid\r\n"
					+ "inner join account_status acs on acs.account_status_oid=a.account_status_oid "
					+ "where (cs.description like ('%" + cardStatus + "%') OR cs.description like  ('%" + cardStatus
					+ "%')) and mcn.name = '" + clientCountryName.replaceAll("\"", "")
					+ "' and c.expires_on >=(SELECT PROCESSING_DATE from M_CLIENTS where Name ='" + clientCountryName
					+ "') and tl.description='All days, all times' and acs.description like '%Active%'";
			/*
			 * cardNumberDB = "Select c.card_no from m_customers mc \r\n" +
			 * "inner join cards c on c.customer_mid = mc.customer_mid\r\n" +
			 * "inner join card_status cs on c.card_status_oid=cs.card_status_oid \r\n" +
			 * "inner join m_clients mcn on mcn.client_mid = mc.client_mid \r\n" +
			 * "where (cs.description like ('%" + cardStatus +
			 * "%') OR cs.description like ('%" + cardStatus +
			 * "%')) and mcn.client_mid = (Select client_mid from m_clients where name ='" +
			 * clientCountryName +
			 * "')  and c.expires_on >=(SELECT PROCESSING_DATE from M_CLIENTS where Name ='"
			 * + clientCountryName + "') and rownum=1";
			 */

		}

		String cardNumber = connectDBAndGetValue(cardNumberDB, PropUtils.getPropValue(configProp, "sqlODSServerName"));

		return cardNumber;
	}

public String getCardNumberFromIFCSDBWithNoTransaction(String clientName, String clientCountry, String cardStatus) {
		String clientCountryName;
		String cardNumberDB = "";

		System.out.println("++++Client name:" + clientName + "++++Client country " + clientCountry);

		clientCountryName = PropUtils.getPropValue(configProp, clientName + "_" + clientCountry);

		cardNumberDB = "Select c.card_no from m_customers mc inner join cards c on c.customer_mid = mc.customer_mid	inner join card_status cs on c.card_status_oid=cs.card_status_oid\r\n"
				+ "			inner join m_clients mcn on mcn.client_mid = mc.client_mid\r\n"
				+ "			where (cs.description like ('%" + cardStatus + "%') OR cs.description like ('%" + cardStatus
				+ "%')) and\r\n" + "            mcn.client_mid = (Select client_mid from m_clients where name ='"
				+ clientCountryName + "')\r\n"
				+ "            and c.card_no not in (select card_no from pos_transactions)";

		String cardNumber = connectDBAndGetValue(cardNumberDB, PropUtils.getPropValue(configProp, "sqlODSServerName"));

		return cardNumber;
	}

	/*
	 * Raxsana Added 18/09/2020
	 */
	public String getReplacedCardNumberFromIFCSDB(String clientName, String clientCountry, String cardStatus) {
		String clientCountryName;
		String queryToGetReplacedCardNo;

		clientCountryName = PropUtils.getPropValue(configProp, clientName + "_" + clientCountry);
		queryToGetReplacedCardNo = "Select distinct c.card_no from cards c  \r\n"
				+ "inner join m_customers mc on c.customer_mid = mc.customer_mid\r\n"
				+ "inner join accounts a on a.customer_mid=mc.customer_mid\r\n"
				+ "inner join account_status ass on ass.account_status_oid=a.account_status_oid\r\n"
				+ "inner join transactions t on t.card_no=c.card_no \r\n"
				+ "inner join card_status cs on c.card_status_oid=cs.card_status_oid \r\n"
				+ "inner join m_clients mcn on mcn.client_mid = mc.client_mid \r\n"
				+ "inner join TRANSACTION_LINE_ITEMS tl on tl.transaction_oid = t.transaction_oid inner join card_controls cc on cc.card_control_profile_oid= c.card_control_profile_oid\r\n"
				+ "inner join time_limits tl on tl.time_limit_oid=cc.time_limit_oid \r\n"
				+ "where (cs.description like ('%Normal Service%') OR cs.description like  ('%NORMAL SERVICE%'))\r\n"
				+ "and (ass.description like '%Active' OR ass.description like '%ACTIVE')\r\n" + "and mcn.name = '"
				+ clientCountryName + "' and c.expires_on >=(SELECT PROCESSING_DATE from M_CLIENTS where Name ='"
				+ clientCountryName + "')\r\n"
				+ "and c.previous_card_oid is not null and c.previous_card_oid is not null and tl.description='All days, all times'";

		String cardNumber = connectDBAndGetValue(queryToGetReplacedCardNo,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));

		return cardNumber;
	}

	public String getActiveCardWithFutureProcessDateFromDB(int rowIndex) {
		String clientName, clientCountry;
		clientName = PropUtils.getPropValue(configProp, "clientName");
		clientCountry = PropUtils.getPropValue(configProp, "clientCountry");

		String cardNumberDB = "select c.card_no from cards c where card_status_oid = 474 and rownum<=10 and c.expires_on >= (select processing_date from m_clients where name = '"
				+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountry).replaceAll("\"", "")
				+ "') order by c.expires_on desc";

		String cardNumber = connectDBAndGetDBRowValue(cardNumberDB,
				PropUtils.getPropValue(configProp, "sqlODSServerName"), rowIndex);
		System.out.println("Card Number" + cardNumber);

		return cardNumber;
	}

	public String getCustomerNumberWithNoHierarchyFromDB(int rowIndex) {
		String clientCountry, cardType, clientName;
		String clientSpecificQuery = "", customerNumber, customerNumberQuery = "";
		clientName = PropUtils.getPropValue(configProp, "clientName");
		clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		cardType = PropUtils.getPropValue(configProp, "cardType");
		if (clientName.equals("SHELL")) {
			if (clientCountry.equals("MY")) {
				clientSpecificQuery = "Shell Pre-Paid Card";
			} else if (cardType.contains("APA")) {
				clientSpecificQuery = "Shell Pre-Paid Card (" + clientCountry + ")";
			} else {
				clientSpecificQuery = "Shell Partner Card (" + clientCountry + ")";
			}
			customerNumberQuery = "SELECT c.customer_no FROM m_customers c LEFT JOIN relationships r ON r.member_oid = c.customer_mid INNER JOIN Card_programs ON c.CARD_PROGRAM_OID = Card_programs.CARD_PROGRAM_OID WHERE r.relationship_oid IS NULL AND Card_programs.DESCRIPTION = '"
					+ clientSpecificQuery + "'";
		} else if (clientName.equals("EMAP")) {
			clientSpecificQuery = "card_programs.client_mid =(select CLIENT_MID from m_clients where name='"
					+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountry) + "')";
			customerNumberQuery = "SELECT c.customer_no FROM m_customers c LEFT JOIN relationships r ON r.member_oid = c.customer_mid INNER JOIN Card_programs ON c.CARD_PROGRAM_OID = Card_programs.CARD_PROGRAM_OID WHERE r.relationship_oid IS NULL AND "
					+ clientSpecificQuery + "";
		}

		else if (clientName.equals("WFE")) {
			clientSpecificQuery = "card_programs.client_mid =(select CLIENT_MID from m_clients where name='"
					+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountry) + "')";
			customerNumberQuery = "SELECT c.customer_no FROM m_customers c LEFT JOIN relationships r ON r.member_oid = c.customer_mid INNER JOIN Card_programs ON c.CARD_PROGRAM_OID = Card_programs.CARD_PROGRAM_OID WHERE r.relationship_oid IS NULL AND "
					+ clientSpecificQuery + "";
		}

		customerNumber = connectDBAndGetDBRowValue(customerNumberQuery,
				PropUtils.getPropValue(configProp, "sqlODSServerName"), rowIndex);

		System.out.println("Customer Number" + customerNumber);
		return customerNumber;
	}

	public String getCustomerNumberWithCardsAndNoHierarchyFromDB(String cardStatus) {
		String clientCountry, cardType, clientName;
		String cardTypeDesc = "", customerNumber;
		String customerNumberQuery = "";
		clientName = PropUtils.getPropValue(configProp, "clientName");
		clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		cardType = PropUtils.getPropValue(configProp, "cardType");
		if (clientName.equals("SHELL")) {
			if (clientCountry.equals("MY")) {
				cardTypeDesc = "Shell Pre-Paid Card";
			} else if (cardType.contains("APA")) {
				cardTypeDesc = "Shell Pre-Paid Card (" + clientCountry + ")";
			} else {
				cardTypeDesc = "Shell Partner Card (" + clientCountry + ")";
			}
			customerNumberQuery = "select mc.customer_no from cards c inner join m_customers mc on mc.customer_mid = c.customer_mid inner join card_programs cp on cp.card_program_oid=mc.card_program_oid INNER JOIN CARD_STATUS cs on c.CARD_STATUS_OID = cs.CARD_STATUS_OID and mc.customer_mid NOT IN (select member_oid from relationships) and c.replace_card_oid IS NULL and cp.description = '"
					+ cardTypeDesc + "' and cs.DESCRIPTION = '" + cardStatus + "'";
		} else {
			customerNumberQuery = "select mc.customer_no from cards c inner join m_customers mc on mc.customer_mid = c.customer_mid inner join m_clients mcn on mcn.client_mid = mc.client_mid  INNER JOIN CARD_STATUS cs on c.CARD_STATUS_OID = cs.CARD_STATUS_OID and mc.customer_mid NOT IN (select member_oid from relationships) and c.replace_card_oid IS NULL and cs.DESCRIPTION like '%"
					+ cardStatus + "' and mcn.name = '"
					+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountry) + "' ";
		}
		customerNumber = connectDBAndGetValue(customerNumberQuery,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		System.out.println("Customer Number:" + customerNumber);
		return customerNumber;
	}

	/** Get Child Customer Having Card with expected status **/
	public String getParentAndChildCustomersHavingCardsWithExpectedStatus(String cardStatus) {

		String clientCountry, cardType;
		String cardTypeDesc = "", parentCustomerNumber, childCustomerNumber;
		Map<String, String> childCustomerNumberAndHierarchyId;
		clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		cardType = PropUtils.getPropValue(configProp, "cardType");
		if (clientCountry.equals("MY")) {
			cardTypeDesc = "Shell Pre-Paid Card";
		} else if (cardType.contains("APA")) {
			cardTypeDesc = "Shell Pre-Paid Card (" + clientCountry + ")";
		} else {
			cardTypeDesc = "Shell Partner Card (" + clientCountry + ")";
		}
		String childCustomerNumberQuery = "select mc.customer_no,rel.hierarchy_oid from cards c \r\n"
				+ "inner join m_customers mc on mc.customer_mid = c.customer_mid\r\n"
				+ "inner join card_programs cp on cp.card_program_oid=mc.card_program_oid\r\n"
				+ "INNER JOIN CARD_STATUS cs on c.CARD_STATUS_OID = cs.CARD_STATUS_OID\r\n"
				+ "inner join relationships rel on c.customer_mid = rel.member_oid\r\n"
				+ "where rel.relationship_oid<>rel.parent_relationship_oid \r\n"
				+ "and c.replace_card_oid IS NULL and\r\n" + "cp.description = '" + cardTypeDesc
				+ "' and cs.DESCRIPTION = '" + cardStatus + "' and rownum=1";
		childCustomerNumberAndHierarchyId = connectDBAndGetDBEntireRowValues(childCustomerNumberQuery,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		childCustomerNumber = childCustomerNumberAndHierarchyId.get("CUSTOMER_NO");
		String parentCustomerNumberQuery = "select mc.customer_no from relationships rel\r\n"
				+ "inner join relationship_assignments rels on rel.relationship_oid=rels.relationship_oid \r\n"
				+ "inner join accounts acc on acc.customer_mid=rel.member_oid \r\n"
				+ "inner join m_customers mc on mc.customer_mid=acc.customer_mid \r\n"
				+ "inner join hierarchies hc on rel.hierarchy_oid = hc.hierarchy_oid\r\n"
				+ "and rel.relationship_oid =rel.parent_relationship_oid where hc.hierarchy_oid='"
				+ childCustomerNumberAndHierarchyId.get("HIERARCHY_OID") + "'";
		parentCustomerNumber = connectDBAndGetValue(parentCustomerNumberQuery,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		System.out.println("Customer Number:" + childCustomerNumber);
		System.out.println("Parent Number:" + parentCustomerNumber);
		return parentCustomerNumber + ":" + childCustomerNumber;
	}

	public String getNotReplacedCardNumberWithCustomerNumber(String cardStatus, String customerNo) {
		String cardNumberNotReplaced;

		String cardNumberQuery = "select c.card_no from cards c\r\n"
				+ "inner join m_customers mc on mc.customer_mid = c.customer_mid \r\n"
				+ "inner join card_programs cp on cp.card_program_oid=mc.card_program_oid\r\n"
				+ "INNER JOIN CARD_STATUS cs on c.CARD_STATUS_OID = cs.CARD_STATUS_OID \r\n"
				+ "and c.replace_card_oid IS NULL and cs.DESCRIPTION = 'Stolen' and mc.customer_no = '" + customerNo
				+ "'";
		cardNumberNotReplaced = connectDBAndGetValue(cardNumberQuery,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		System.out.println("Customer Number:" + cardNumberNotReplaced);
		return cardNumberNotReplaced;
	}

	public String getProcessedIFCSDate(String futureOrPast, int monthsDiff, String userName) {
		String resultDate = null;

		SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");

		Date currentDate = null;
		Date currentDatePlusMonths;
		try {
			currentDate = new SimpleDateFormat("dd/MM/yyyy").parse(getCurrentIFCSDate(userName));
		} catch (ParseException e) {

			e.printStackTrace();
		}

		// convert date to calendar
		Calendar c = Calendar.getInstance();
		c.setTime(currentDate);
		if (futureOrPast.contains("future")) {
			// manipulate date
			c.add(Calendar.MONTH, monthsDiff); // same with c.add(Calendar.DAY_OF_MONTH, 1);
			// convert calendar to date
			currentDatePlusMonths = c.getTime();

			resultDate = dateFormat.format(currentDatePlusMonths);
		} else {
			c.add(Calendar.MONTH, -monthsDiff); // same with c.add(Calendar.DAY_OF_MONTH, 1);
			// convert calendar to date
			currentDatePlusMonths = c.getTime();
			resultDate = dateFormat.format(currentDatePlusMonths);
		}

		return resultDate;
	}

	public void clickDetailSearchIfFilterFieldsNotPresent() {
		boolean isFilterFieldsPresent = false;
		try {
			driver.findElement(
					By.xpath("//div[@class='SimpleInternalFrame_GradientPanel'][descendant::div[text()='Viewer']]"));
			isFilterFieldsPresent = true;
		} catch (NoSuchElementException ex) {
			logInfo("No Viewer present");
		}
		if (!isFilterFieldsPresent) {
			detailSearch();
		}
	}

	public void validateComboDropDownFieldIsProtected(String seperatorLabelName, String labelName) {
		String seperator = " ";
		String label = " ";
		WebElement comboBox;
		List<WebElement> comboBoxWithoutText;
		try {
			seperator = splitStringAndGenerateXpath(seperatorLabelName);
			label = splitStringAndGenerateXpath(labelName);
			comboBoxWithoutText = driver.findElements(By.xpath("//div[@class='JFALSeparator']//div[" + seperator
					+ "]/preceding::div[@class='JFALLabel']/div[" + label
					+ "]/preceding::div[@class='JFALCompControlPanel'][1]//div[@class='JFALComboBox_CustomComboboxRenderer']/div"));
			int size_comboBoxWithoutText = comboBoxWithoutText.size();
			System.out.println("Size without text :" + size_comboBoxWithoutText);
			if (size_comboBoxWithoutText >= 2) {
				comboBox = driver.findElement(By.xpath("//div[@class='JFALSeparator']//div[" + seperator
						+ "]/preceding::div[@class='JFALLabel']/div[" + label
						+ "]/preceding::div[@class='JFALCompControlPanel'][1]//div[@class='htmlString']"));
				sleep(5);
				String color = comboBox.getCssValue("color");
				System.out.println(color);
				String hexColor = convertrgbColorToHex(color);
				System.out.println(hexColor);
				if (hexColor.equals("#b8cfe5")) {
					logPass("Field is Protected");
				} else {
					logFail("Field is not Protected");
				}
			}

			else {
				logInfo("Field is Protected but text is not Present");
			}
		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
	}

	// added by sasi 20-02-19
	public void selectFirstRowNumberInSearchList() {
		// TODO Auto-generated method stub
		WebElement cellElement;
		try {
			/*
			 * List<WebElement> list = driver .findElements(By.
			 * xpath("//div[@class='FALTableCellEditor_StrikeThruField JTextComponent']"));
			 */
			SeleniumWrappers.setTotalTableHeaders(cardsTableHeaders.size());

			cellElement = SeleniumWrappers.getTableDataWithCellElement(0, 0, driver);
			doubleClick(cellElement);
			sleep(5);
		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
	}

	// added by Prakalpha using ajaxswing id's 19-08-19
	public void selectFirstRowNumberInApplicationSearchList() {
		// TODO Auto-generated method stub
		try {
			WebElement firstCellelement = driver.findElement(By.xpath("//div[@ajs_id='_1_0']"));

			doubleClick(firstCellelement);
			sleep(5);
		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
	}

	// Prakalpha -->Enter a Value in textBox With same label Name have in different
	// separator

	public void enterDetailsWithSameLabelName(String seperatorLabelName, String labelName, String input) {
		String seperator = " ";
		String label = " ";
		WebElement textField;
		try {
			seperator = splitStringAndGenerateXpath(seperatorLabelName);
			label = splitStringAndGenerateXpath(labelName);

			// driver.navigate().refresh();
			textField = driver.findElement(By.xpath(
					"//div[@class='JFALSeparator']//div[" + seperator + "]/preceding::div[@class='JFALLabel'][1]//div["
							+ label + "]/preceding::div[@class='JFALCompControlPanel'][1]//input"));
			sleep(5);
			// textField.click();
			textField.sendKeys(input);
			sleep(2);
			logPass(seperatorLabelName + " " + labelName + " " + input + " is entered in TextField");
		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
	}

	public void enterValueInTextBoxWithIndex(String seperatorLabelName, String labelName, String input, int index) {
		String seperator = " ";
		String label = " ";
		WebElement textBox;
		try {
			seperator = splitStringAndGenerateXpath(seperatorLabelName);
			label = splitStringAndGenerateXpath(labelName);
			textBox = driver.findElements(By.xpath(
					"//div[@class='JFALSeparator']//div[" + seperator + "]/preceding::div[@class='JFALLabel']/div["
							+ label + "]/preceding::div[@class='JFALCompControlPanel'][1]//input"))
					.get(index);
			isDisplayedThenEnterText(textBox, "TextBox", input);
			logPass(input + " is entered in text field");

		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
	}

	// Added by Sasi --> 27-02-19
	public String getActiveCardsInHierarcy(String accountNumber, String cardBalance, String balanceAllowed,
			String client, int rowIndex) {
		String cardNo;
		String clientCountry, cardType;
		String cardTypeDesc = "";
		String isBalanceAllowed = "";
		String actualBalance = "";
		clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		cardType = PropUtils.getPropValue(configProp, "cardType");
		if (clientCountry.contains("MY")) {
			if (cardType.contains("APA")) {
				cardTypeDesc = "Shell Pre-Paid Card";
			}
		} else {
			if (cardType.contains("APA")) {
				cardTypeDesc = "Shell Pre-Paid Card (" + clientCountry + ")";
			} else {
				cardTypeDesc = "Shell Partner Card (" + clientCountry + ")";
			}
		}

		if (balanceAllowed.equals("balanceAllowed")) {
			isBalanceAllowed = " c.is_balance_allowed = 'Y' ";
		} else {
			isBalanceAllowed = " c.is_balance_allowed = 'N' ";
		}

		if (cardBalance.equals("positive")) {
			actualBalance = " and cb.balance>0 ";

		} else if (cardBalance.equals("negative")) {
			actualBalance = " and cb.balance<0 ";

		} else if (cardBalance.equals("zero")) {
			actualBalance = " and cb.balance=0 ";

		} else {
			actualBalance = " ";
		}

		if (client.contains("SHELL")) {
			client = client.replace("SHELL", "SH ");
		} /*
			 * else {
			 * 
			 * }
			 */

		String queryToGetCardNumber = "select c.card_no from cards c inner join m_customers mc on mc.customer_mid = c.customer_mid inner join card_programs cp on cp.card_program_oid=mc.card_program_oid inner join card_status cs on cs.card_status_oid = c.card_status_oid inner join card_balances cb on cb.card_balance_oid = c.card_balance_oid where "
				+ isBalanceAllowed + " and mc.customer_no = '" + accountNumber
				+ "' and c.expires_on >=(SELECT PROCESSING_DATE from M_CLIENTS where IE_CLIENT_ID='" + client + "') "
				+ " and c.replace_card_oid IS NULL and (cs.description like '%Card Processed' OR cs.description like '%Active' OR cs.description like '%Card Ordered') "
				+ actualBalance + "and cp.description = '" + cardTypeDesc + "'";

		cardNo = connectDBAndGetDBRowValue(queryToGetCardNumber, PropUtils.getPropValue(configProp, "sqlODSServerName"),
				rowIndex);

		System.out.println("CardNo:: " + cardNo);

		return cardNo;
	}

	// Added by Sasi --> 26-02-19
	public String getActiveChildCustomerNoInSameHierarcy(String parentCusNo, String calculatedAvaliableBalance,
			String accountType, String cardBalanceAllowance) {
		String clientCountry, cardType;
		String cardTypeDesc = "";
		String avaliableBalance = "";
		String accountTypeDesc = "";
		String balanceAllowed = "";
		// clientName = PropUtils.getPropValue(configProp, "clientName");
		clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		cardType = PropUtils.getPropValue(configProp, "cardType");
		if (clientCountry.contains("MY")) {
			if (cardType.contains("APA")) {
				cardTypeDesc = "Shell Pre-Paid Card";
			}
		} else {
			if (cardType.contains("APA")) {
				cardTypeDesc = "Shell Pre-Paid Card (" + clientCountry + ")";
			} else {
				cardTypeDesc = "Shell Partner Card (" + clientCountry + ")";
			}
		}

		if (accountType.equals("nonBilling")) {
			accountTypeDesc = " and relass.IS_BILLING_ENTITY='N' and relass.IS_AUTHORISATION_ENTITY ='N' ";
		} else {
			accountTypeDesc = " and relass.IS_BILLING_ENTITY='Y' and relass.IS_AUTHORISATION_ENTITY ='Y' ";
		}

		if (calculatedAvaliableBalance.equals("positive")) {
			avaliableBalance = " and av.calculated_available_balance > 0 ";
		} else if (calculatedAvaliableBalance.equals("negative")) {
			avaliableBalance = " and av.calculated_available_balance < 0 ";
		} else {
			avaliableBalance = " and av.calculated_available_balance <> 0 ";
		}

		if (cardBalanceAllowance.equals("balanceAllowed")) {
			balanceAllowed = " cards.is_balance_allowed='Y' ";
		} else if (cardBalanceAllowance.equals("noBalanceAllowed")) {
			balanceAllowed = " cards.is_balance_allowed='N' ";
		}

		String queryToGetCustomerNumberParentRelationShipOid = "select rel.parent_relationship_oid from m_customers mc inner join accounts acc on mc.customer_mid=acc.customer_mid inner join relationships rel on acc.customer_mid=rel.member_oid inner join relationship_assignments relass on rel.relationship_oid=relass.relationship_oid where mc.customer_no ='"
				+ parentCusNo + "'";
		String parentRelationShipOid = connectDBAndGetValue(queryToGetCustomerNumberParentRelationShipOid,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		System.out.println("parentRelationShipOid:: " + parentRelationShipOid);

		String queryToGetChildCustomerNumberInSameHierarchy = "select mc.customer_no from m_customers mc inner join accounts acc on mc.customer_mid=acc.customer_mid inner join calc_avail_bal_account_view av on mc.customer_mid=av.customer_mid  inner join relationships rel on acc.customer_mid=rel.member_oid inner join relationship_assignments relass on rel.relationship_oid=relass.relationship_oid inner join account_status accs on accs.account_status_oid=acc.account_status_oid inner join account_sub_status accss on accss.account_status_oid = accs.account_status_oid inner join card_programs cp on cp.card_program_oid=mc.card_program_oid where mc.customer_mid In (select customer_mid from cards where "
				+ balanceAllowed + ") and accs.description like '%Active%'  and rel.parent_relationship_oid = '"
				+ parentRelationShipOid + "' and accss.description like '%Active%' " + avaliableBalance + "  "
				+ accountTypeDesc + " and rel.relationship_oid!=rel.parent_relationship_oid " + "and cp.description = '"
				+ cardTypeDesc + "' and Rownum <=1";
		String childCusNo = connectDBAndGetValue(queryToGetChildCustomerNumberInSameHierarchy,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		System.out.println("childCusNo:: " + childCusNo);

		return childCusNo;
	}

	// Added by Sasi --> 19-03-19

	public String getActiveChildCustomerNoInHierarcy(String accountType, String calculatedAvaliableBalance,
			String cardBalanceAllowance, boolean replaceCard, String cardBalance, String client) {
		String childCusNo, replace, balance;
		String clientCountry, cardType;
		String cardTypeDesc = "";
		String accountTypeDesc = null;
		String avaliableBalance, balanceAllowed = "";
		clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		cardType = PropUtils.getPropValue(configProp, "cardType");
		if (clientCountry.contains("MY")) {
			if (cardType.contains("APA")) {
				cardTypeDesc = "Shell Pre-Paid Card";
			}
		} else {
			if (cardType.contains("APA")) {
				cardTypeDesc = "Shell Pre-Paid Card (" + clientCountry + ")";
			} else {
				cardTypeDesc = "Shell Partner Card (" + clientCountry + ")";
			}
		}

		if (accountType.equals("nonBilling")) {
			accountTypeDesc = " and relass.IS_BILLING_ENTITY='N' and relass.IS_AUTHORISATION_ENTITY ='N' ";
		} else if (accountType.equals("billing")) {
			accountTypeDesc = " and relass.IS_BILLING_ENTITY='Y' and relass.IS_AUTHORISATION_ENTITY ='Y' ";
		}

		if (calculatedAvaliableBalance.equals("positive")) {
			avaliableBalance = " and av.calculated_available_balance > 0 ";
		} else if (calculatedAvaliableBalance.equals("negative")) {
			avaliableBalance = " and av.calculated_available_balance < 0 ";
		} else {
			avaliableBalance = " and av.calculated_available_balance <> 0 ";
		}

		if (cardBalanceAllowance.equals("balanceAllowed")) {
			balanceAllowed = " c.is_balance_allowed='Y' ";
		} else if (cardBalanceAllowance.equals("noBalanceAllowed")) {
			balanceAllowed = " c.is_balance_allowed='N' ";
		}

		if (replaceCard) {
			replace = "c.replace_card_oid IS NOT NULL and ";
		} else {
			replace = "c.replace_card_oid IS NULL and  ";
		} // and cb.balance>0

		if (cardBalance.equals("positive")) {
			balance = " and (cb.balance>0 OR cb.balance=0) ";
		} else if (cardBalance.equals("negative")) {
			balance = " and cb.balance<0 ";
		} else {
			balance = " ";
		}

		if (client.contains("SHELL")) {
			client = client.replace("SHELL", "SH ");
		}

		String queryToGetChildCustomerNumberInHierarchy = "select distinct mc.customer_no from m_customers mc inner join accounts acc on mc.customer_mid=acc.customer_mid inner join calc_avail_bal_account_view av on mc.customer_mid=av.customer_mid inner join relationships rel on acc.customer_mid=rel.member_oid inner join relationship_assignments relass on rel.relationship_oid=relass.relationship_oid inner join account_status accs on accs.account_status_oid=acc.account_status_oid inner join account_sub_status accss on accss.account_status_oid = accs.account_status_oid inner join card_programs cp on cp.card_program_oid=mc.card_program_oid where mc.customer_mid In (select customer_mid from cards c "
				+ "inner join card_status cs on cs.card_status_oid = c.card_status_oid inner join card_balances cb on cb.card_balance_oid = c.card_balance_oid where "
				+ replace + " " + balanceAllowed
				+ " and c.expires_on >= (SELECT PROCESSING_DATE from M_CLIENTS where IE_CLIENT_ID='" + client
				+ "') and (cs.description like '%Card Processed' OR cs.description like '%Active' OR cs.description like '%Card Ordered' ) "
				+ ") and accs.description like '%Active' and accss.description like '%Active' " + avaliableBalance
				+ accountTypeDesc + " and rel.relationship_oid!=rel.parent_relationship_oid "
				+ " and cp.description = '" + cardTypeDesc + "' and Rownum <=1 ";

		childCusNo = connectDBAndGetValue(queryToGetChildCustomerNumberInHierarchy,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));

		System.out.println("childCusNo:: " + childCusNo);

		return childCusNo;
	}

	public String getActiveParentCustomerNoInHierarcyAlone(String accountType, String calculatedAvaliableBalance,
			String cardBalanceAllowance, boolean replaceCard, String cardBalance, String client, int rowIndex) {
		String parentCusNo, replace, balance;
		String clientCountry, cardType;
		String cardTypeDesc = "";
		String avaliableBalance, balanceAllowed = "";
		clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		cardType = PropUtils.getPropValue(configProp, "cardType");
		if (clientCountry.contains("MY")) {
			if (cardType.contains("APA")) {
				cardTypeDesc = "Shell Pre-Paid Card";
			}
		} else {
			if (cardType.contains("APA")) {
				cardTypeDesc = "Shell Pre-Paid Card (" + clientCountry + ")";
			} else {
				cardTypeDesc = "Shell Partner Card (" + clientCountry + ")";
			}
		}

		// if (accountType.equals("nonBilling")) {
		// accountTypeDesc = " and rels.IS_BILLING_ENTITY='N' and
		// rels.IS_AUTHORISATION_ENTITY ='N') ";
		// } else {
		// accountTypeDesc = " and rels.IS_BILLING_ENTITY='Y' and
		// rels.IS_AUTHORISATION_ENTITY ='Y') ";
		// }

		if (calculatedAvaliableBalance.equals("positive")) {
			avaliableBalance = " and av.calculated_available_balance > 0 ";
		} else if (calculatedAvaliableBalance.equals("negative")) {
			avaliableBalance = " and av.calculated_available_balance < 0 ";
		} else {
			avaliableBalance = " and av.calculated_available_balance <> 0 ";
		}

		if (cardBalanceAllowance.equals("balanceAllowed")) {
			balanceAllowed = " c.is_balance_allowed='Y' ";
		} else if (cardBalanceAllowance.equals("noBalanceAllowed")) {
			balanceAllowed = " c.is_balance_allowed='N' ";
		}

		if (replaceCard) {
			replace = "c.replace_card_oid IS NOT NULL and ";
		} else {
			replace = "c.replace_card_oid IS NULL and  ";
		} // and cb.balance>0

		if (cardBalance.equals("positive")) {
			balance = "(and cb.balance>0 OR cb.balance=0) ";
		} else if (cardBalance.equals("negative")) {
			balance = "and cb.balance<0 ";
		} else {
			balance = " ";
		}

		if (client.contains("SHELL")) {
			client = client.replace("SHELL", "SH ");
		}

		String queryToGetParentCustomerNumberInHierarchy = "select distinct mc.customer_no from m_customers mc inner join accounts acc on mc.customer_mid=acc.customer_mid inner join calc_avail_bal_account_view av on mc.customer_mid=av.customer_mid inner join relationships rel on acc.customer_mid=rel.member_oid inner join relationship_assignments relass on rel.relationship_oid=relass.relationship_oid inner join account_status accs on accs.account_status_oid=acc.account_status_oid inner join account_sub_status accss on accss.account_status_oid = accs.account_status_oid inner join card_programs cp on cp.card_program_oid=mc.card_program_oid where mc.customer_mid In (select customer_mid from cards c "
				+ "inner join card_status cs on cs.card_status_oid = c.card_status_oid inner join card_balances cb on cb.card_balance_oid = c.card_balance_oid where "
				+ replace + " " + balanceAllowed
				+ " and c.expires_on >= (SELECT PROCESSING_DATE from M_CLIENTS where IE_CLIENT_ID='" + client
				+ "') and (cs.description like '%Card Processed' OR cs.description like '%Active' OR cs.description like '%Card Ordered') "
				+ ") and accs.description like '%Active' and accss.description like '%Active' " + avaliableBalance
				+ " and relass.IS_BILLING_ENTITY='Y' and relass.IS_AUTHORISATION_ENTITY = 'Y' and rel.relationship_oid=rel.parent_relationship_oid "
				+ " and cp.description = '" + cardTypeDesc + "' ";

		parentCusNo = connectDBAndGetDBRowValue(queryToGetParentCustomerNumberInHierarchy,
				PropUtils.getPropValue(configProp, "sqlODSServerName"), rowIndex);

		System.out.println("parentCusNo:: " + parentCusNo);

		return parentCusNo;
	}

	// Added by Sasi --> 27-02-19
	public String getActiveCardsNotInHierarcy(String cardBalance, String balanceAllowed, String client, int rowIndex) {
		String CardNo;
		String clientCountry, cardType;
		String cardTypeDesc = "";
		String actualBalance = "";
		String isBalanceAllowed = "";
		clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		cardType = PropUtils.getPropValue(configProp, "cardType");
		if (clientCountry.contains("MY")) {
			if (cardType.contains("APA")) {
				cardTypeDesc = "Shell Pre-Paid Card";
			}
		} else {
			if (cardType.contains("APA")) {
				cardTypeDesc = "Shell Pre-Paid Card (" + clientCountry + ")";
			} else {
				cardTypeDesc = "Shell Partner Card (" + clientCountry + ")";
			}
		}

		if (balanceAllowed.equals("balanceAllowed")) {
			isBalanceAllowed = "and c.is_balance_allowed = 'Y' ";
		} else {
			isBalanceAllowed = "and c.is_balance_allowed = 'N' ";
		}

		if (cardBalance.equals("positive")) {
			actualBalance = " and cb.balance>0 ";
		} else if (cardBalance.equals("negative")) {
			actualBalance = " and cb.balance<0 ";
		} else if (cardBalance.equals("zero")) {
			actualBalance = " and cb.balance=0 ";
		} else {
			actualBalance = " and cb.balance<>0 ";
		}

		if (client.contains("SHELL")) {
			client = client.replace("SHELL", "SH ");
		}
		String queryToGetParentCustomerNumberInHierarchy = "select c.card_no from cards c inner join m_customers mc on mc.customer_mid = c.customer_mid inner join card_programs cp on cp.card_program_oid=mc.card_program_oid inner join card_balances cb on cb.card_balance_oid = c.card_balance_oid inner join accounts acc on mc.customer_mid=acc.customer_mid inner join account_status accs on accs.account_status_oid=acc.account_status_oid inner join account_sub_status accss on accss.account_status_oid = accs.account_status_oid where c.expires_on >=(SELECT PROCESSING_DATE from M_CLIENTS where IE_CLIENT_ID='"
				+ client
				+ "') and accs.description like '%Active%' and accss.description like '%Active%' and acc.customer_mid NOT IN (select member_oid from relationships) and c.replace_card_oid IS NULL "
				+ isBalanceAllowed + " " + actualBalance + " " + "and cp.description = '" + cardTypeDesc
				+ "' and rownum=1 ";

		CardNo = connectDBAndGetDBRowValue(queryToGetParentCustomerNumberInHierarchy,
				PropUtils.getPropValue(configProp, "sqlODSServerName"), rowIndex);

		System.out.println("parentCusNo:: " + CardNo);

		return CardNo;
	}

	// Added by Sasi --> 27-02-19
	public String getActiveParentCustomerNoInHierarcy(String accountType, String calculatedAvaliableBalance,
			String cardBalanceAllowance, boolean replaceCard, String cardBalance, String client, int rowIndex) {
		String parentCusNo = "", replace, balance;
		String clientCountry, cardType;
		String cardTypeDesc = "";
		String accountTypeDesc, avaliableBalance, balanceAllowed = "";
		clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		cardType = PropUtils.getPropValue(configProp, "cardType");
		if (clientCountry.contains("MY")) {
			if (cardType.contains("APA")) {
				cardTypeDesc = "Shell Pre-Paid Card";
			}
		} else {
			if (cardType.contains("APA")) {
				cardTypeDesc = "Shell Pre-Paid Card (" + clientCountry + ")";
			} else {
				cardTypeDesc = "Shell Partner Card (" + clientCountry + ")";
			}
		}

		if (accountType.equals("nonBilling")) {
			accountTypeDesc = " and rels.IS_BILLING_ENTITY='N' and rels.IS_AUTHORISATION_ENTITY ='N') ";
		} else {
			accountTypeDesc = " and rels.IS_BILLING_ENTITY='Y' and rels.IS_AUTHORISATION_ENTITY ='Y') ";
		}

		if (calculatedAvaliableBalance.equals("positive")) {
			avaliableBalance = " and av.calculated_available_balance > 0 ";
		} else if (calculatedAvaliableBalance.equals("negative")) {
			avaliableBalance = " and av.calculated_available_balance < 0 ";
		} else {
			avaliableBalance = " and av.calculated_available_balance <> 0 ";
		}

		if (cardBalanceAllowance.equals("balanceAllowed")) {
			balanceAllowed = " c.is_balance_allowed='Y' ";
		} else if (cardBalanceAllowance.equals("noBalanceAllowed")) {
			balanceAllowed = " c.is_balance_allowed='N' ";
		}

		if (replaceCard) {
			replace = "c.replace_card_oid IS NOT NULL and ";
		} else {
			replace = "c.replace_card_oid IS NULL and  ";
		} // and cb.balance>0

		if (cardBalance.equals("positive")) {
			balance = "(and cb.balance>0 OR cb.balance=0) ";
		} else if (cardBalance.equals("negative")) {
			balance = "and cb.balance<0 ";
		} else {
			balance = " ";
		}

		if (client.contains("SHELL")) {
			client = client.replace("SHELL", "SH ");
		}

		String queryToGetParentCustomerNumberInHierarchy = "select distinct mc.customer_no from m_customers mc inner join accounts acc on mc.customer_mid=acc.customer_mid inner join calc_avail_bal_account_view av on mc.customer_mid=av.customer_mid inner join relationships rel on acc.customer_mid=rel.member_oid inner join relationship_assignments relass on rel.relationship_oid=relass.relationship_oid inner join account_status accs on accs.account_status_oid=acc.account_status_oid inner join account_sub_status accss on accss.account_status_oid = accs.account_status_oid inner join card_programs cp on cp.card_program_oid=mc.card_program_oid where mc.customer_mid In (select customer_mid from cards c "
				+ "inner join card_status cs on cs.card_status_oid = c.card_status_oid inner join card_balances cb on cb.card_balance_oid = c.card_balance_oid where "
				+ replace + " " + balanceAllowed
				+ " and c.expires_on >= (SELECT PROCESSING_DATE from M_CLIENTS where IE_CLIENT_ID='" + client
				+ "') and (cs.description like '%Card Processed' OR cs.description like '%Active' OR cs.description like '%Card Ordered') "
				+ ") and accs.description like '%Active' and accss.description like '%Active' " + avaliableBalance
				+ " and relass.IS_BILLING_ENTITY='Y' and relass.IS_AUTHORISATION_ENTITY = 'Y' and rel.relationship_oid=rel.parent_relationship_oid "
				+ " and cp.description = '" + cardTypeDesc + "' "
				+ " and parent_relationship_oid in (select distinct rel.parent_relationship_oid  from Relationships rel inner join relationship_assignments rels on  rel.relationship_oid=rels.relationship_oid where rel.relationship_oid !=rel.parent_relationship_oid  "
				+ accountTypeDesc;
		parentCusNo = connectDBAndGetDBRowValue(queryToGetParentCustomerNumberInHierarchy,
				PropUtils.getPropValue(configProp, "sqlODSServerName"), rowIndex);
		System.out.println("parentCusNo:: " + queryToGetParentCustomerNumberInHierarchy);

		return parentCusNo;
	}

	public String getLostCardNumberFromDB() {
		String clientName, clientCountry;
		clientName = PropUtils.getPropValue(configProp, "clientName");
		clientCountry = PropUtils.getPropValue(configProp, "clientCountry");

		String lostCardNumberDB = "Select c.card_no from m_customers MC inner join cards C on c.customer_mid = mc.customer_mid inner join card_status CS on c.card_status_oid=cs.card_status_oid inner join m_clients mcn on mcn.client_mid = mc.client_mid where cs.description like '%Lost%' and mcn.name = '"
				+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountry).replaceAll("\"", "")
				+ "' and C.REPLACE_CARD_OID is null and rownum<=1";

		String lostcardNumber = connectDBAndGetValue(lostCardNumberDB,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		System.out.println("Card Number" + lostcardNumber);

		return lostcardNumber;
	}

	/*
	 * // Prakalpha-->Updated Lost Card Using Card Type public String
	 * getLostCardNumberFromDB() { String clientCountry, cardType; String
	 * cardTypeDesc = ""; clientCountry = PropUtils.getPropValue(configProp,
	 * "clientCountry"); cardType = PropUtils.getPropValue(configProp, "cardType");
	 * if (clientCountry.contains("MY")) { if (cardType.contains("APA")) {
	 * cardTypeDesc = "Shell Pre-Paid Card"; }
	 * 
	 * } else { if (cardType.contains("APA")) { cardTypeDesc =
	 * "Shell Pre-Paid Card (" + clientCountry + ")"; } else { cardTypeDesc =
	 * "Shell Partner Card (" + clientCountry + ")"; } } String lostCardNumberDB =
	 * "select CARDS.CARD_NO from Cards INNER JOIN CARD_PROGRAMS ON cards.card_program_oid = card_programs.card_program_oid INNER JOIN CARD_STATUS ON cards.card_status_oid = card_status.card_status_oid INNER JOIN CARD_BALANCES ON CARDS.CARD_BALANCE_OID = CARD_BALANCES.CARD_BALANCE_OID where card_programs.DESCRIPTION = '"
	 * + cardTypeDesc +
	 * "' AND  CARD_STATUS.DESCRIPTION like '%Lost' AND cards.replace_card_oid IS NULL and rownum=1"
	 * ;
	 * 
	 * String lostcardNumber = connectDBAndGetValue(lostCardNumberDB,
	 * PropUtils.getPropValue(configProp, "sqlODSServerName"));
	 * System.out.println("Card Number" + lostcardNumber);
	 * 
	 * return lostcardNumber; }
	 */

	// Added by Sasi --> 25-02-19
	public String getActiveParentCustomerNoInHierarcyBasedOnClient() {
		String parentCusNo;
		String clientCountry, clientName;
		clientName = PropUtils.getPropValue(configProp, "clientName");
		clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		System.out.println("clientName : " + clientName + " " + "clientCountry : " + clientCountry);
		/*
		 * cardType = PropUtils.getPropValue(configProp, "cardType"); if
		 * (cardType.contains("APA")) { cardTypeDesc = "Shell Pre-Paid Card (" +
		 * clientCountry + ")"; } else { cardTypeDesc = "Shell Partner Card (" +
		 * clientCountry + ")"; }
		 */
		String queryToGetParentCustomerNumberInHierarchy = "select customer_no from m_customers mc inner join accounts acc on mc.customer_mid=acc.customer_mid inner join relationships rel on acc.customer_mid=rel.member_oid inner join relationship_assignments relass on rel.relationship_oid=relass.relationship_oid inner join account_status accs on accs.account_status_oid=acc.account_status_oid inner join account_sub_status accss on accss.account_status_oid = accs.account_status_oid inner join card_programs cp on cp.card_program_oid=mc.card_program_oid where accs.description like '%Active%' and accss.description like '%Active%' and acc.actual_balance<>0 and relass.IS_BILLING_ENTITY='Y' and relass.IS_AUTHORISATION_ENTITY = 'Y' and rel.relationship_oid=rel.parent_relationship_oid  and cp.client_mid = "
				+ "(select Client_mid from m_clients where name ='"
				+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountry) + "') and Rownum <=1";
		parentCusNo = connectDBAndGetValue(queryToGetParentCustomerNumberInHierarchy,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));

		System.out.println("parentCusNo:: " + parentCusNo);

		return parentCusNo;
	}

	// Added by Sasi --> 26-02-19
	public String getActiveChildCustomerNoInSameHierarcyWithBillingNode(String parentCusNo) {
		String clientCountry, cardType;
		String cardTypeDesc = "";

		clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		cardType = PropUtils.getPropValue(configProp, "cardType");
		if (cardType.contains("APA")) {
			cardTypeDesc = "Shell Pre-Paid Card (" + clientCountry + ")";
		} else {
			cardTypeDesc = "Shell Partner Card (" + clientCountry + ")";
		}
		String queryToGetCustomerNumberParentRelationShipOid = "select rel.parent_relationship_oid from m_customers mc inner join accounts acc on mc.customer_mid=acc.customer_mid inner join relationships rel on acc.customer_mid=rel.member_oid inner join relationship_assignments relass on rel.relationship_oid=relass.relationship_oid where mc.customer_no ='"
				+ parentCusNo + "'";
		String parentRelationShipOid = connectDBAndGetValue(queryToGetCustomerNumberParentRelationShipOid,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		System.out.println("parentRelationShipOid:: " + parentRelationShipOid);

		String queryToGetChildCustomerNumberInSameHierarchy = "select customer_no from m_customers mc inner join accounts acc on mc.customer_mid=acc.customer_mid inner join relationships rel on acc.customer_mid=rel.member_oid inner join relationship_assignments relass on rel.relationship_oid=relass.relationship_oid inner join account_status accs on accs.account_status_oid=acc.account_status_oid inner join account_sub_status accss on accss.account_status_oid = accs.account_status_oid inner join card_programs cp on cp.card_program_oid=mc.card_program_oid where accs.description like '%Active'  and rel.parent_relationship_oid = '"
				+ parentRelationShipOid
				+ "' and accss.description like '%Active' and acc.actual_balance<>0 and relass.IS_BILLING_ENTITY='Y' and relass.IS_AUTHORISATION_ENTITY = 'Y' and rel.relationship_oid!=rel.parent_relationship_oid  and cp.description = '"
				+ cardTypeDesc + "' and Rownum <=1";
		String childCusNo = connectDBAndGetValue(queryToGetChildCustomerNumberInSameHierarchy,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		System.out.println("childCusNo:: " + childCusNo);

		return childCusNo;
	}

	public void clickCardRequestButton() {
		waitForElementTobeClickable(cardRequest, 30);
		isDisplayedThenClick(cardRequest, "Card Request");
	}

	public String getActiveChildCustomerNoNotInSameHierarchyWithBillingNode(String parentCusNo) {
		String clientCountry, cardType;
		String cardTypeDesc = "";

		clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		cardType = PropUtils.getPropValue(configProp, "cardType");
		if (cardType.contains("APA")) {
			cardTypeDesc = "Shell Pre-Paid Card (" + clientCountry + ")";
		} else {
			cardTypeDesc = "Shell Partner Card (" + clientCountry + ")";
		}

		String queryToGetChildCustomerNumberNotInSameHierarchy = "select customer_no from m_customers mc inner join relationships r on r.member_oid = mc.customer_mid inner join relationship_assignments ra on ra.relationship_oid = r.relationship_oid inner join card_programs cp on cp.card_program_oid=mc.card_program_oid where r.hierarchy_oid not in (Select hierarchy_oid from relationships r inner join m_customers mc on r.member_oid = mc.customer_mid where mc.customer_no = '"
				+ parentCusNo
				+ "' and rownum=1) and r.relationship_oid!=r.parent_relationship_oid and ra.is_billing_entity = 'Y' and cp.DESCRIPTION='"
				+ cardTypeDesc + "' and Rownum <=1";
		String childCusNo = connectDBAndGetValue(queryToGetChildCustomerNumberNotInSameHierarchy,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		System.out.println("childCusNo:: " + childCusNo);

		return childCusNo;
	}

	public String getCardProcessedCardNoInSameHierarchyWithBillingNode(String childCusNo) {
		String clientCountry, cardType;
		String cardTypeDesc = "";

		clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		cardType = PropUtils.getPropValue(configProp, "cardType");
		if (cardType.contains("APA")) {
			cardTypeDesc = "Shell Pre-Paid Card (" + clientCountry + ")";
		} else {
			cardTypeDesc = "Shell Partner Card (" + clientCountry + ")";
		}
		String queryToGetCardNoInSameHierarchyWithBillingNode = "select CARDS.CARD_NO from Cards INNER JOIN CARD_PROGRAMS ON cards.card_program_oid = card_programs.card_program_oid inner join m_customers mc on cards.customer_mid = mc.customer_mid  inner join relationships r on r.member_oid = cards.customer_mid INNER JOIN CARD_STATUS ON cards.card_status_oid = card_status.card_status_oid INNER JOIN CARD_BALANCES ON CARDS.CARD_BALANCE_OID = CARD_BALANCES.CARD_BALANCE_OID  where mc.customer_no = '"
				+ childCusNo + "' and r.relationship_oid!=r.parent_relationship_oid and card_programs.DESCRIPTION='"
				+ cardTypeDesc
				+ "' AND  (CARD_STATUS.DESCRIPTION = 'Card Ordered' OR CARD_STATUS.DESCRIPTION = 'Card Processed') AND cards.replace_card_oid IS NULL AND cards.is_balance_allowed = 'Y' and rownum>=1";
		String billingCardNo = connectDBAndGetValue(queryToGetCardNoInSameHierarchyWithBillingNode,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		System.out.println("billingCardNo:: " + billingCardNo);

		return billingCardNo;
	}

	public String getCardProcessedCardNoInSameHierarchyWithNonBillingNode(String childCusNo) {
		String clientCountry, cardType;
		String cardTypeDesc = "";

		clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		cardType = PropUtils.getPropValue(configProp, "cardType");
		if (cardType.contains("APA")) {
			cardTypeDesc = "Shell Pre-Paid Card (" + clientCountry + ")";
		} else {
			cardTypeDesc = "Shell Partner Card (" + clientCountry + ")";
		}
		String queryToGetCardNoInSameHierarchyWithNonBillingNode = "select CARDS.CARD_NO from Cards INNER JOIN CARD_PROGRAMS ON cards.card_program_oid = card_programs.card_program_oid inner join m_customers mc on cards.customer_mid = mc.customer_mid  inner join relationships r on r.member_oid = cards.customer_mid INNER JOIN CARD_STATUS ON cards.card_status_oid = card_status.card_status_oid INNER JOIN CARD_BALANCES ON CARDS.CARD_BALANCE_OID = CARD_BALANCES.CARD_BALANCE_OID  where mc.customer_no = '"
				+ childCusNo + "' and r.relationship_oid!=r.parent_relationship_oid and card_programs.DESCRIPTION='"
				+ cardTypeDesc
				+ "' AND  CARD_STATUS.DESCRIPTION = 'Card Processed' AND cards.replace_card_oid IS NULL AND cards.is_balance_allowed = 'Y' and rownum>=1";
		String nonBillingCardNo = connectDBAndGetValue(queryToGetCardNoInSameHierarchyWithNonBillingNode,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		System.out.println("nonBillingCardNo:: " + nonBillingCardNo);

		return nonBillingCardNo;
	}

	public String getReplaceCardNoWithBalanceAllowedAndBillingNodeInSameHierarchy(String parentCusNo) {
		String clientCountry, cardType;
		String cardTypeDesc = "";

		clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		cardType = PropUtils.getPropValue(configProp, "cardType");
		if (clientCountry.contains("MY")) {
			if (cardType.contains("APA")) {
				cardTypeDesc = "Shell Pre-Paid Card";
			}
		} else {
			if (cardType.contains("APA")) {
				cardTypeDesc = "Shell Pre-Paid Card (" + clientCountry + ")";
			} else {
				cardTypeDesc = "Shell Partner Card (" + clientCountry + ")";
			}
		}
		String queryToGetReplaceCardNoWithBalanceAllowedInSameHierarchy = "select CARDS.CARD_NO from Cards INNER JOIN CARD_PROGRAMS ON cards.card_program_oid = card_programs.card_program_oid inner join m_customers mc on cards.customer_mid = mc.customer_mid INNER JOIN CARD_STATUS ON cards.card_status_oid = card_status.card_status_oid INNER JOIN CARD_BALANCES ON CARDS.CARD_BALANCE_OID = CARD_BALANCES.CARD_BALANCE_OID where mc.customer_no = '"
				+ parentCusNo + "' and card_programs.DESCRIPTION='" + cardTypeDesc
				+ "' AND (CARD_STATUS.DESCRIPTION like '%Card Processed' or CARD_STATUS.DESCRIPTION like '%Active' or CARD_STATUS.DESCRIPTION like '%Card Ordered') AND cards.replace_card_oid IS NOT NULL AND cards.is_balance_allowed = 'Y'";
		String replacedCardNo = connectDBAndGetValue(queryToGetReplaceCardNoWithBalanceAllowedInSameHierarchy,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		System.out.println("replacedCardNo:: " + replacedCardNo);

		return replacedCardNo;
	}

	public String getActiveChildCustomerNoInSameHierarcyWithNoBillingNode(String parentCusNo) {
		String clientCountry, cardType;
		String cardTypeDesc = "";

		clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		cardType = PropUtils.getPropValue(configProp, "cardType");
		if (cardType.contains("APA")) {
			cardTypeDesc = "Shell Pre-Paid Card (" + clientCountry + ")";
		} else {
			cardTypeDesc = "Shell Partner Card (" + clientCountry + ")";
		}
		String queryToGetCustomerNumberParentRelationShipOid = "select rel.parent_relationship_oid from m_customers mc inner join accounts acc on mc.customer_mid=acc.customer_mid inner join relationships rel on acc.customer_mid=rel.member_oid inner join relationship_assignments relass on rel.relationship_oid=relass.relationship_oid where mc.customer_no ='"
				+ parentCusNo + "'";
		String parentRelationShipOid = connectDBAndGetValue(queryToGetCustomerNumberParentRelationShipOid,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		System.out.println("parentRelationShipOid:: " + parentRelationShipOid);

		String queryToGetChildCustomerNumberInSameHierarchy = "select customer_no from m_customers mc inner join accounts acc on mc.customer_mid=acc.customer_mid inner join relationships rel on acc.customer_mid=rel.member_oid inner join relationship_assignments relass on rel.relationship_oid=relass.relationship_oid inner join account_status accs on accs.account_status_oid=acc.account_status_oid inner join account_sub_status accss on accss.account_status_oid = accs.account_status_oid inner join card_programs cp on cp.card_program_oid=mc.card_program_oid where accs.description like '%Active%'  and rel.parent_relationship_oid = '"
				+ parentRelationShipOid
				+ "' and accss.description like '%Active%' and acc.actual_balance<>0 and relass.IS_BILLING_ENTITY='N' and relass.IS_AUTHORISATION_ENTITY = 'N' and rel.relationship_oid!=rel.parent_relationship_oid and cp.description = '"
				+ cardTypeDesc + "' and Rownum <=1";
		String childCusNo = connectDBAndGetValue(queryToGetChildCustomerNumberInSameHierarchy,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		System.out.println("childCusNo:: " + childCusNo);

		return childCusNo;
	}

	public String getCardNumberInSameHierarchyAndBalancedAllowed(String parentCustNo) {
		String clientCountry, cardType;
		String cardTypeDesc = "";
		clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		cardType = PropUtils.getPropValue(configProp, "cardType");
		if (cardType.contains("APA")) {
			cardTypeDesc = "Shell Pre-Paid Card (" + clientCountry + ")";
		} else {
			cardTypeDesc = "Shell Partner Card (" + clientCountry + ")";
		}

		String queryToGetChildCustomerNumberInSameHierarchy = "select CARDS.CARD_NO from Cards INNER JOIN CARD_PROGRAMS ON cards.card_program_oid = card_programs.card_program_oid inner join m_customers mc on cards.customer_mid = mc.customer_mid inner join relationships r on r.member_oid = cards.customer_mid INNER JOIN CARD_STATUS ON cards.card_status_oid = card_status.card_status_oid INNER JOIN CARD_BALANCES ON CARDS.CARD_BALANCE_OID = CARD_BALANCES.CARD_BALANCE_OID where r.hierarchy_oid in (Select hierarchy_oid from relationships r inner join m_customers mc on r.member_oid = mc.customer_mid where mc.customer_no = '"
				+ parentCustNo
				+ "' and rownum=1) and card_balances.balance > 0 and r.relationship_oid!=r.parent_relationship_oid and card_programs.DESCRIPTION='"
				+ cardTypeDesc
				+ "'  AND  CARD_STATUS.DESCRIPTION = 'Card Processed' AND cards.replace_card_oid IS NULL AND cards.is_balance_allowed = 'Y' and rownum=1";
		String cardNoBalancedAllowed = connectDBAndGetValue(queryToGetChildCustomerNumberInSameHierarchy,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		System.out.println("cardNoBalancedAllowed:: " + cardNoBalancedAllowed);

		return cardNoBalancedAllowed;
	}

	// Added by Ayub 25-02-2019

	public String getHierarchyCustomerNunmberWithBillingNodeAndHasBalance() {
		String clientCountry, cardType;
		String cardTypeDesc = "";
		// clientName = PropUtils.getPropValue(configProp, "clientName");
		clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		cardType = PropUtils.getPropValue(configProp, "cardType");
		if (cardType.contains("APA")) {
			cardTypeDesc = "Shell Pre-Paid Card (" + clientCountry + ")";
		} else {
			cardTypeDesc = "Shell Partner Card (" + clientCountry + ")";
		}
		billingNodeAccount = "Select mc.customer_no from relationships r inner join relationship_assignments ra on ra.relationship_oid = r.relationship_oid inner join m_customers mc on r.member_oid = mc.customer_mid inner join cards c on c.customer_mid = mc.customer_mid  inner join card_programs cp on c.card_program_oid = cp.card_program_oid where ra.is_billing_entity = 'Y' and rownum=1 and c.is_balance_allowed = 'N' and cp.description = '"
				+ cardTypeDesc + "' order by mc.customer_no desc";
		billingNodeAccount = connectDBAndGetValue(billingNodeAccount,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		System.out.println("Customer Number" + billingNodeAccount);
		return billingNodeAccount;
	}

	public String getNotBalanceAllowedCardNumber(String billingNodeAccount) {
		String clientCountry, cardType;
		String cardTypeDesc = "";
		// clientName = PropUtils.getPropValue(configProp, "clientName");
		clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		cardType = PropUtils.getPropValue(configProp, "cardType");
		if (cardType.contains("APA")) {
			cardTypeDesc = "Shell Pre-Paid Card (" + clientCountry + ")";
		} else {
			cardTypeDesc = "Shell Partner Card (" + clientCountry + ")";
		}
		String noBalanceAllowedCardNumber = "Select cards.card_no from cards where card_no in (select cards.card_no from cards inner join m_customers mc on mc.customer_mid = cards.customer_mid  inner join card_programs cp on cp.card_program_oid=mc.card_program_oid inner join card_status on card_status.card_status_oid = cards.card_status_oid inner join card_balances on card_balances.card_balance_oid = cards.card_balance_oid where cards.is_balance_allowed = 'N' and mc.customer_no ='"
				+ billingNodeAccount
				+ "' and cards.replace_card_oid IS NULL and card_status.description like '%Card Processed%' and cp.description = '"
				+ cardTypeDesc + "' group by cards.card_no having count(cards.card_no)>=1) and rownum=1";
		noBalanceAllowedCardNumber = connectDBAndGetValue(noBalanceAllowedCardNumber,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		System.out.println("Card Number" + noBalanceAllowedCardNumber);
		return noBalanceAllowedCardNumber;
	}

	public String getBalanceAllowedCardNumber(String billingNodeAccount) {
		String clientCountry, cardType;
		String cardTypeDesc = "";
		// clientName = PropUtils.getPropValue(configProp, "clientName");
		clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		cardType = PropUtils.getPropValue(configProp, "cardType");
		if (cardType.contains("APA")) {
			cardTypeDesc = "Shell Pre-Paid Card (" + clientCountry + ")";
		} else {
			cardTypeDesc = "Shell Partner Card (" + clientCountry + ")";
		}
		String balanceAllowedCardNumber = "select CARDS.CARD_NO from Cards INNER JOIN CARD_PROGRAMS ON cards.card_program_oid = card_programs.card_program_oid inner join m_customers mc on cards.customer_mid = mc.customer_mid inner join relationships r on r.member_oid = cards.customer_mid INNER JOIN CARD_STATUS ON cards.card_status_oid = card_status.card_status_oid INNER JOIN CARD_BALANCES ON CARDS.CARD_BALANCE_OID = CARD_BALANCES.CARD_BALANCE_OID where r.hierarchy_oid not in (Select hierarchy_oid from relationships r  inner join m_customers mc on r.member_oid = mc.customer_mid  where mc.customer_no = '"
				+ billingNodeAccount
				+ "' and rownum=1) and r.relationship_oid!=r.parent_relationship_oid and card_programs.DESCRIPTION= '"
				+ cardTypeDesc
				+ "' AND  CARD_STATUS.DESCRIPTION = 'Active' AND cards.replace_card_oid IS NULL AND cards.is_balance_allowed = 'Y' and rownum=1 ";
		balanceAllowedCardNumber = connectDBAndGetValue(balanceAllowedCardNumber,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		System.out.println("Card Number" + balanceAllowedCardNumber);
		return balanceAllowedCardNumber;

	}

	public String getCardNumbersWithHierarchyFromDB(int rowIndex, String customerNoHasTwoCards) {
		String clientCountry, cardType;
		String cardTypeDesc = "", cardNumber;
		// clientName = PropUtils.getPropValue(configProp, "clientName");
		clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		cardType = PropUtils.getPropValue(configProp, "cardType");
		if (cardType.contains("APA")) {
			cardTypeDesc = "Shell Pre-Paid Card (" + clientCountry + ")";
		} else {
			cardTypeDesc = "Shell Partner Card (" + clientCountry + ")";
		}
		String cardNumberQuery = "Select cards.card_no from cards where card_no in (select cards.card_no from cards inner join m_customers mc on mc.customer_mid = cards.customer_mid  inner join card_programs cp on cp.card_program_oid=mc.card_program_oid inner join card_status on card_status.card_status_oid = cards.card_status_oid  inner join card_balances on card_balances.card_balance_oid = cards.card_balance_oid where cards.is_balance_allowed = 'Y' and mc.customer_no = '"
				+ customerNoHasTwoCards
				+ "' and cards.replace_card_oid IS NULL  and card_status.description like '%Card Processed%' and card_balances.balance>0 and cp.description = '"
				+ cardTypeDesc + "'group by cards.card_no having count(cards.card_no)>=1) and rownum >= 1";
		cardNumber = connectDBAndGetDBRowValue(cardNumberQuery, PropUtils.getPropValue(configProp, "sqlODSServerName"),
				rowIndex);
		System.out.println("Card Number" + cardNumber);
		return cardNumber;
	}

	public String getHierarchyCustomerNunmberHasTwoCardsWithBillingNodeAndHasBalance() {
		String clientCountry, cardType;
		String cardTypeDesc = "";
		// clientName = PropUtils.getPropValue(configProp, "clientName");
		clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		cardType = PropUtils.getPropValue(configProp, "cardType");
		if (cardType.contains("APA")) {
			cardTypeDesc = "Shell Pre-Paid Card (" + clientCountry + ")";
		} else {
			cardTypeDesc = "Shell Partner Card (" + clientCountry + ")";
		}
		hierarchyCustomerNoHasTwoCards = "select mc.customer_no from m_customers mc inner join accounts acc on mc.customer_mid=acc.customer_mid inner join relationships rel on acc.customer_mid=rel.member_oid inner join relationship_assignments relass on rel.relationship_oid=relass.relationship_oid inner join card_programs cp on cp.card_program_oid=mc.card_program_oid inner join account_status accs on accs.account_status_oid=acc.account_status_oid  inner join account_sub_status accss on accss.account_status_oid = accs.account_status_oid inner join cards on cards.customer_mid = mc.customer_mid where mc.customer_mid in (select cards.customer_mid from cards inner join card_status on card_status.card_status_oid = cards.card_status_oid  inner join card_balances on card_balances.card_balance_oid = cards.card_balance_oid  where cards.is_balance_allowed = 'Y' and card_status.description like '%Card Processed%' and card_balances.balance>0 and cp.description = '"
				+ cardTypeDesc
				+ "' group by cards.customer_mid having count(cards.customer_mid)>=2) and accs.description like '%Active%' and accss.description like '%Active%' and relass.IS_BILLING_ENTITY='Y' and relass.IS_AUTHORISATION_ENTITY = 'Y' and rownum=1";
		hierarchyCustomerNoHasTwoCards = connectDBAndGetValue(hierarchyCustomerNoHasTwoCards,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		System.out.println("Customer Number" + hierarchyCustomerNoHasTwoCards);
		return hierarchyCustomerNoHasTwoCards;
	}

	/**
	 * Is download file present
	 */
	public void isFileDownloaded(String fileName) {
		try {
			String downloadedFileName = getLatestDownloadedFileFromDir(fileName).getName();
			System.out.println("The Downloaded File Name is   " + downloadedFileName);
			logInfo("The Downloaded File Name is" + downloadedFileName);
			if (downloadedFileName.contains(fileName) || downloadedFileName.contains(fileName.replaceAll(" ", "_"))) {
				logPass(fileName + " file got downloaded");
			} else {
				logFail(fileName + " file not downloaded");
			}
		} catch (NullPointerException e) {
			logFail("Downloaded File does not exist" + e);
		}
	}

	public String getCustomerNoWithStoredReports(String processingDate) {
		String clientCountry, cardType;
		String cardTypeDesc = "";
		clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		cardType = PropUtils.getPropValue(configProp, "cardType");
		if (clientCountry.contains("MY")) {
			if (cardType.contains("APA")) {
				cardTypeDesc = "Shell Pre-Paid Card";
			}
		} else {
			if (cardType.contains("APA")) {
				cardTypeDesc = "Shell Pre-Paid Card (" + clientCountry + ")";
			} else {
				cardTypeDesc = "Shell Partner Card (" + clientCountry + ")";
			}
		}
		Date dateFormat = null;
		String dateFormatted = "";
		try {
			DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
			dateFormat = df.parse(processingDate);
			// dateFormat1 = new SimpleDateFormat("dd/MM/yyyy").parse(processingDate);
			System.out.println("Date Format" + dateFormat);
			dateFormatted = new SimpleDateFormat("dd-MMM-yy").format(dateFormat);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("After parsing" + dateFormatted);
		String queryToGetCustomerNoWithStoredReports = "Select distinct mcu.customer_no from m_customers mcu inner join accounts acc on mcu.customer_mid=acc.customer_mid inner join account_status accs on accs.account_status_oid=acc.account_status_oid inner join account_sub_status accss on acc.account_sub_status_oid=accss.account_sub_status_oid inner join card_programs cp on mcu.card_program_oid = cp.card_program_oid inner join stored_reports sr on mcu.customer_mid=sr.member_oid where accs.description like '%Active' and accss.description='Active' and sr.created_on>='"
				+ dateFormatted + "' and cp.description = '" + cardTypeDesc + "' and Rownum <=1";
		String customerNoWithStoredReports = connectDBAndGetValue(queryToGetCustomerNoWithStoredReports,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		System.out.println("CustomerNoWithStoredReports:: " + customerNoWithStoredReports);

		return customerNoWithStoredReports;
	}

	// Prakalpha-->To get Location Number and Merchant Number from Database
	public String getMerchantNoFromDB() {
		String merchantNo, clientName, clientCountry;

		clientName = PropUtils.getPropValue(configProp, "clientName");
		clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		String queryToGetMerchantNo = "Select merchant_no from m_Merchants ml where ml.client_mid = (Select client_mid from m_clients where name ='"
				+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountry).replaceAll("\"", "")
				+ "') and rownum <= 1";
		merchantNo = connectDBAndGetValue(queryToGetMerchantNo, PropUtils.getPropValue(configProp, "sqlODSServerName"));
		System.out.println("merchantNo:: " + merchantNo);
		return merchantNo;
	}

	// raxsana
	// Made changes in query for shell
	public String getLocationNoFromDB() {
		String locationNo, clientName, clientCountry;
		clientName = PropUtils.getPropValue(configProp, "clientName");
		clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		String queryToGetLocationNo;
		if (clientName.equalsIgnoreCase("SHELL")) {
			queryToGetLocationNo = "Select location_no from m_locations ml\r\n"
					+ " inner join products_sold_locations psl on ml.location_mid!=psl.location_mid\r\n"
					+ " where ml.client_mid = (Select client_mid from m_clients where " + "name ='"
					+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountry).replaceAll("\"", "")
					+ "') \r\n" + " and rownum <= 1";
		} else {
			queryToGetLocationNo = "Select distinct location_no from m_locations ml where ml.client_mid = (Select client_mid from m_clients where name ='"
					+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountry).replaceAll("\"", "")
					+ "') and rownum <= 1";
		}
		locationNo = connectDBAndGetValue(queryToGetLocationNo, PropUtils.getPropValue(configProp, "sqlODSServerName"));
		System.out.println("locationNo:: " + locationNo);
		return locationNo;
	}

	/*
	 * raxsana Added 28/09/2020
	 */

	public String getLocationNoWithMerchantAgreementFromIFCSDB() {
		String locationNo, clientName, clientCountry;
		clientName = PropUtils.getPropValue(configProp, "clientName");
		clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		String queryToGetLocNo = "select distinct location_no from m_locations ml \r\n"
				+ "inner join addresses ad on ml.postal_address_oid=ad.address_oid\r\n"
				+ "inner join countries c on c.country_oid=ad.country_oid \r\n"
				+ "where ml.location_mid in (select member_oid from relationships r\r\n"
				+ "inner join RELATIONSHIP_ASSIGNMENTS ra on r.relationship_oid=ra.relationship_oid \r\n"
				+ "where ra.expires_on >= (SELECT PROCESSING_DATE from M_CLIENTS where Name ='"
				+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountry) + "') and \r\n"
				+ "ra.effective_on <= (SELECT PROCESSING_DATE from M_CLIENTS where Name ='"
				+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountry) + "')) \r\n"
				+ "and ml.client_mid=(select client_mid from m_clients where name='"
				+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountry) + "') and c.country_code = '"
				+ clientCountry + "'";
		locationNo = connectDBAndGetValue(queryToGetLocNo, PropUtils.getPropValue(configProp, "sqlODSServerName"));
		return locationNo;
	}

		public String getLocationNoFromIFCSDB(String clientName, String clientCountry, String productCode) {

		String locationNo;

		String clientandcountry = PropUtils.getPropValue(configProp, clientName + "_" + clientCountry);
		String queryToGetLocationNo = null;
		if (clientName.equalsIgnoreCase("EMAP")) {
			queryToGetLocationNo = "select DISTINCT l.location_no FROM merchant_agreements ma "
					+ "INNER JOIN relationship_assignments ra ON ma.relationship_assignment_oid = ra.relationship_assignment_oid "
					+ "INNER JOIN relationships r ON r.relationship_oid = ra.relationship_oid "
					+ "INNER JOIN m_locations l ON r.member_oid = l.location_mid "
					+ "INNER JOIN m_clients mc ON l.client_mid = mc.client_mid  "
					+ "INNER JOIN location_reconciliations lr ON l.location_mid = lr.location_mid "
					+ "where l.client_mid=(Select client_mid from m_clients where name ='" + clientandcountry + "') "
					+ "and l.location_status_cid='4101' and  ra.EXPIRES_ON > mc.processing_date "
					+ "and l.location_mid NOT IN (SELECT location_mid FROM products_sold_locations)";
		} else if (clientName.equalsIgnoreCase("WFE")) {
			queryToGetLocationNo = "select location_no from m_locations ml inner join addresses ad on ml.postal_address_oid=ad.address_oid\r\n"
					+ "inner join countries c on c.country_oid=ad.country_oid where ml.location_mid in (select member_oid from relationships r\r\n"
					+ "inner join RELATIONSHIP_ASSIGNMENTS ra on r.relationship_oid=ra.relationship_oid \r\n"
					+ "where ra.expires_on >= (SELECT PROCESSING_DATE from M_CLIENTS where Name ='"
					+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountry) + "') and \r\n"
					+ "ra.effective_on <= (SELECT PROCESSING_DATE from M_CLIENTS where Name ='"
					+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountry) + "')) \r\n"
					+ "and ml.client_mid=(select client_mid from m_clients where name='"
					+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountry) + "') and c.country_code='"
					+ clientCountry + "'";

		}

		else {
			queryToGetLocationNo = "select DISTINCT l.location_no FROM merchant_agreements ma\r\n"
					+ "INNER JOIN relationship_assignments ra ON ma.relationship_assignment_oid = ra.relationship_assignment_oid\r\n"
					+ "INNER JOIN relationships r ON r.relationship_oid = ra.relationship_oid\r\n"
					+ "INNER JOIN m_locations l ON r.member_oid = l.location_mid\r\n"
					+ "INNER JOIN m_clients mc ON l.client_mid = mc.client_mid    \r\n"
					+ "INNER JOIN location_reconciliations lr ON l.location_mid = lr.location_mid\r\n"
					+ "inner join products_sold_locations pl on  pl.location_mid=l.location_mid \r\n"
					+ "inner join product_translations pt on pt.product_oid=pl.product_oid \r\n"
					+ "where l.location_status_cid='4101' and l.client_mid=(Select client_mid from m_clients where name ='"
					+ clientandcountry + "') " + "and pt.external_code='" + productCode
					+ "' and ra.EXPIRES_ON > mc.processing_date and pl.expires_on > mc.processing_date";
		}

		locationNo = connectDBAndGetValue(queryToGetLocationNo, PropUtils.getPropValue(configProp, "sqlODSServerName"));
		System.out.println("locationNo:: " + locationNo);
		return locationNo;

	}


	/*
	 * public String getExternalRefNoFromDB(String clientName,String clientCountry)
	 * {
	 * 
	 * String locationNo;
	 * 
	 * String queryToGetLocationNo =
	 * "Select external_code from m_locations  where client_mid = (Select client_mid from m_clients where name ='"
	 * +PropUtils.getPropValue(configProp, clientName + "_" +
	 * clientCountry).replaceAll("\"", "") +
	 * "') and location_status_cid='4101' and location_mid NOT IN (SELECT location_mid FROM products_sold_locations) and  rownum <= 1"
	 * ; locationNo = connectDBAndGetValue(queryToGetLocationNo,
	 * PropUtils.getPropValue(configProp, "sqlODSServerName"));
	 * System.out.println("externalRefNo:: " + locationNo); return locationNo; }
	 */

	public String getExternalRefNoFromDB(String clientName, String clientCountry) {
		// String locationNo, clientName, clientCountry;
		String locationNo;
		// clientName = PropUtils.getPropValue(configProp, "clientName");
		// clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		String clientandcountry = PropUtils.getPropValue(configProp, clientName + "_" + clientCountry);

		String queryToGetLocationNo = "select DISTINCT l.external_code FROM merchant_agreements ma\r\n"
				+ "INNER JOIN relationship_assignments ra ON ma.relationship_assignment_oid = ra.relationship_assignment_oid\r\n"
				+ "INNER JOIN relationships r ON r.relationship_oid = ra.relationship_oid\r\n"
				+ "INNER JOIN m_locations l ON r.member_oid = l.location_mid\r\n"
				+ "INNER JOIN m_clients mc ON l.client_mid = mc.client_mid    \r\n"
				+ "INNER JOIN location_reconciliations lr ON l.location_mid = lr.location_mid\r\n"
				+ "where l.client_mid=(Select client_mid from m_clients where name ='" + clientandcountry
				+ "') and l.location_status_cid='4101' and  ra.EXPIRES_ON > mc.processing_date and l.location_mid NOT IN (SELECT location_mid FROM products_sold_locations) ";

		locationNo = connectDBAndGetValue(queryToGetLocationNo, PropUtils.getPropValue(configProp, "sqlODSServerName"));
		System.out.println("externalRefNo:: " + locationNo);
		return locationNo;
	}

	// Sasi -> updated on 10-06-2019
	public String getLocationNoUsingProductCodeFromDB(String productName) {
		String locationNo, clientName, clientCountry;
		clientName = PropUtils.getPropValue(configProp, "clientName");
		clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		String shortName = "";
		// String productName="";

		if (clientName.equals("EMAP")) {
			shortName = clientName.replace("EMAP", "EX ");
			// productName ="SYNERGY DIESEL" ;
		}
		// Need to analyze with other clients
		/*
		 * else if(clientName.equals("SHELL")) {
		 * 
		 * }else if(clientName.equals("BP")) {
		 * 
		 * }
		 */
		String queryToGetLocationNo = "select location_no from m_locations ml"
				+ " inner join products_sold_locations psl on ml.location_mid = psl.location_mid"
				+ " where ml.client_mid =(Select client_mid from m_clients where name ='"
				+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountry).replaceAll("\"", "") + "') and"
				+ " (ml.closed_on >= (SELECT PROCESSING_DATE from M_CLIENTS where IE_CLIENT_ID='" + shortName
				+ clientCountry + "') or ml.closed_on is null) and"
				+ " psl.product_oid in (Select p.product_oid from products p"
				+ " inner join product_translations pt on p.product_oid = pt.product_oid"
				+ " where p.description like '%" + productName + "%'" + " and pt.external_code_client='" + shortName
				+ clientCountry + "')";
		locationNo = connectDBAndGetValue(queryToGetLocationNo, PropUtils.getPropValue(configProp, "sqlODSServerName"));
		System.out.println("locationNo:: " + locationNo);
		return locationNo;
	}
	// Prakalpha-->Emap -04/02/2019

	public void chooseApplicationNumberFromApplicationList(String option) {
		validateHeaderLabel("Viewer");
		chooseOptionFromDropdown("Status", option);
		searchListTorch();
		selectFirstRowNumberInSearchList();

	}

	public void chooseNameFromApplicationList(String option) {
		validateHeaderLabel("Viewer");
		enterValueInTextBox("Filter By", "Name", option);
		searchListTorch();
		sleep(5);
		// selectFirstRowNumberInSearchList();
		selectFirstRowNumberInApplicationSearchList();
	}

	public void chooseCustomerNumberFromCustomerList() {

		chooseSubMenuFromLeftPanel("Customers", "");
		validateHeaderLabel("Viewer");
		searchListTorch();
		sleep(5);
		selectFirstRowNumberInSearchList();
		sleep(5);
	}

	public void goToOnlineUsers() {
		chooseSubMenuFromLeftPanel("Client Group", "Security");
		chooseSubMenuFromLeftPanel("Security", "Online");
		chooseSubMenuFromLeftPanel("Online", "Users");
		sleep(10);
	}

	public void goToDesktopUsers() {
		chooseSubMenuFromLeftPanel("Client Group", "Security");
		chooseSubMenuFromLeftPanel("Security", "Desktop");
		chooseSubMenuFromLeftPanel("Desktop", "Users");
		sleep(10);
	}

	public void searchTheCurrentUserOnDesktopUsers(String userName) {
		clickDetailSearchIfFilterFieldsNotPresent();
		enterValueInTextBox("Users", "Logon Id", userName);
		searchListTorch();
	}

	public void searchTheCurrentUserOnOnlineUsers(String userName) {
		clickDetailSearchIfFilterFieldsNotPresent();
		enterValueInTextBox("Filter By", "Logon Id", userName);
		searchListTorch();
	}

	// Rax----> EMAP 04/11/2019

	public String getProfileNumber() {

		String profileNumber = "";
		String clientName, clientCountry;
		clientName = PropUtils.getPropValue(configProp, "clientName");
		System.out.println(clientName);
		clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		System.out.println(clientCountry);

		String profileNumberFromDB = "select profile_number from ext_velocity_ctrl_prof where client_mid=(select Client_mid from m_clients where name ='"
				+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountry) + "')";
		profileNumber = connectDBAndGetValue(profileNumberFromDB,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));

		return profileNumber;

	}

	// Added by Sasi 10-04-2019
	public void verifyValueInTables(String colName, String expectedValue, Boolean checkEquals) {
		int totalRowsInTable = SeleniumWrappers.getTotalNumberOfRows(cardsTable, driver);
		int colIndex = SeleniumWrappers.getColumnNoForColumnHeader(colName, cardsTableHeaders);
		boolean validateCols;

		for (int i = 0; i <= totalRowsInTable - 1; i++) {
			if (checkEquals) {
				System.out.println("value of i : " + i);
				validateCols = SeleniumWrappers.getTableDataWithRowAndColumnNumber(colIndex, i, driver)
						.equalsIgnoreCase(expectedValue);
			} else {
				validateCols = SeleniumWrappers.getTableDataWithRowAndColumnNumber(colIndex, i, driver).toLowerCase()
						.contains(expectedValue.toLowerCase().replaceAll("\\*", ""));
			}

			if (validateCols) {
				logPass("Expected value present in Row: " + i + " Col: " + colIndex + " Expected::" + expectedValue
						+ " Actual::" + SeleniumWrappers.getTableDataWithRowAndColumnNumber(colIndex, i, driver));
				break;
			}
		}
	}

	// Prakalpha

	public int validateCheckBoxOptedIn(String seperatorLabelName, String tableHeaderName, String anotherTableHeaderName,
			String expectedValue) {
		// int countDefault = 0;
		int row = 0;
		String seperator = " ";
		int index = 1;
		if (seperatorLabelName.equals("Rebate Profiles")) {
			index = 2;
		}
		try {
			System.out.println("**************");
			seperator = splitStringAndGenerateXpath(seperatorLabelName);
			List<WebElement> tableHeaders = driver.findElements(By.xpath("//div[@class='JFALSeparator']//div["
					+ seperator + "]/preceding::div[@class='JFALCompControlPanel'][" + index
					+ "]//div[@class='JViewport']/div[@class='JTableHeader']//div[@class='HeaderRenderer']"));
			int colIndex = SeleniumWrappers.getColumnNoForColumnHeader(tableHeaderName, tableHeaders);
			System.out.println("ColIndex--->" + colIndex);
			int colIndexNext = SeleniumWrappers.getColumnNoForColumnHeader(anotherTableHeaderName, tableHeaders);
			System.out.println("ColIndex--->" + colIndexNext);
			List<WebElement> list = driver.findElements(By.xpath("//div[@class='JFALSeparator']//div[" + seperator
					+ "]/preceding::div[@class='JFALCompControlPanel'][" + index
					+ "]//div[@class='FALTableCellEditor_StrikeThruField JTextComponent']"));

			int size = SeleniumWrappers.getTotalNumberOfRows(list, driver);
			System.out.println("Size of table" + size);
			for (row = 0; row < size; row++) {
				WebElement element = driver.findElement(By.xpath("//div[@class='JFALSeparator']//div[" + seperator
						+ "]/preceding::div[@class='JFALCompControlPanel'][" + index
						+ "]//div[@class='FALTableCellEditor_StrikeThruCheckBox enabled'][contains(@id,'" + row + "_"
						+ colIndex + "')]//div[@class='htmlImage']"));
				WebElement elementNext = driver.findElement(By.xpath("//div[@class='JFALSeparator']//div[" + seperator
						+ "]/preceding::div[@class='JFALCompControlPanel'][" + index
						+ "]//div[@class='FALTableCellEditor_StrikeThruField JTextComponent'][contains(@id,'" + row
						+ "_" + colIndexNext + "')]"));
				String value = element.getCssValue("background-image");
				String anotherValue = elementNext.getAttribute("submittedvalue");
				if (value.contains("delete.gif") && anotherValue.contains(expectedValue)) {
					System.out.println("Inside else if delete gif");
					logInfo("CheckBox Deleted");
					break;
				} else {
					System.out.println("Inside else delete gif is opted out");
					logInfo("CheckBox Deleted");
				}
			}
		} catch (Exception e) {
			logFail(e.getMessage());
		}
		return row;
	}

	// Added by Nithya - 15-04-2019
	public void goToIndividualReports() {
		chooseSubMenuFromLeftPanel("Customer Reporting", "Individual Reports");
		sleep(3);
		// verifyText(mainFrameTitleBar.get(0), "Individual Reports");
	}

	// Added by Nithya - 17.04.2019
	public String chooseANonFuelProductExtCodeInTheLocation(String locationNo, String fuelType, String required) {
		String clientName, clientCountry;
		String value = " ";
		clientName = PropUtils.getPropValue(configProp, "clientName");
		clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		if (required.equalsIgnoreCase("description")) {
			String nonFuelProductQuery = "select pt.description from products p inner join PRODUCTS_SOLD_LOCATIONS psl on p.product_oid = psl.product_oid inner join product_translations pt on p.product_oid = pt.product_oid where psl.location_mid = (select location_mid from m_locations where location_no = '"
					+ locationNo + "' and client_mid in (Select client_mid from m_clients where name ='"
					+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountry) + "')) and p.is_fuel = '"
					+ fuelType + "'";
			value = connectDBAndGetValue(nonFuelProductQuery, PropUtils.getPropValue(configProp, "sqlODSServerName"));
		} else {
			String externalCodeQuery = "select pt.external_code from products p inner join PRODUCTS_SOLD_LOCATIONS psl on p.product_oid = psl.product_oid inner join product_translations pt on p.product_oid = pt.product_oid where psl.location_mid = (select location_mid from m_locations where location_no = '"
					+ locationNo + "' and client_mid in (Select client_mid from m_clients where name ='"
					+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountry) + "')) and p.is_fuel = '"
					+ fuelType + "' and Rownum <=1";
			value = connectDBAndGetValue(externalCodeQuery, PropUtils.getPropValue(configProp, "sqlODSServerName"));
		}
		return value;
	}

	public String chooseALocationWithNonFuelProduct(String fuelType) {
		String clientName, clientCountry;
		clientName = PropUtils.getPropValue(configProp, "clientName");
		clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		String locationWithNonFuelProduct = "select location_no from m_locations ml inner join PRODUCTS_SOLD_LOCATIONS psl on ml.location_mid = psl.location_mid where ml.client_mid in (Select client_mid from m_clients where name ='"
				+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountry)
				+ "') And psl.product_oid in (select product_oid from products where is_fuel = '" + fuelType
				+ "') and Rownum <=1";
		return connectDBAndGetValue(locationWithNonFuelProduct, PropUtils.getPropValue(configProp, "sqlODSServerName"));
	}

	// Added by Sasi 16-04-2019
	public void clickOkButtonIfMsgPopupAppears() {
		boolean isPopupAppears = false;
		try {
			popUpOkBtn.isDisplayed();
			// isDisplayed(popUpMsg, "Message Popup Appears");
			// isDisplayed(popUpOkBtn, "Message Popup Appears");
			isPopupAppears = true;
		} catch (NoSuchElementException ex) {
			logInfo("No PopUp MSG Appears");
		}
		if (isPopupAppears) {
			messagePopUpHandle();
			// isDisplayedThenActionClick(popUpOkBtn, "OK button");
		}
	}

	public int totalRowsCount() {
		int totalRowsInTable = SeleniumWrappers.getTotalNumberOfRows(cardsTable, driver);
		return totalRowsInTable;
	}

	public void logPassWhenDataFound(String className, String logMessage) {
		logPass(className + " ------> " + logMessage);
	}

	public String getCardProgramOfCustomer(String cusNo) {
		String cardDes = "";
		String clientName, clientCountry;
		clientName = PropUtils.getPropValue(configProp, "clientName");
		System.out.println(clientName);
		clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		System.out.println(clientCountry);

		String profileNumberFromDB = "select cp.description from card_programs cp inner join m_customers mc on mc.card_program_oid = cp.card_program_oid where mc.customer_no='"
				+ cusNo + "'";
		cardDes = connectDBAndGetValue(profileNumberFromDB, PropUtils.getPropValue(configProp, "sqlODSServerName"));

		return cardDes;

	}

	public void cloneRecord() {
		waitForElementTobeClickable(cloneRecord, 10);
		// isDisplayedThenClick(detailSearch,"Clicked Detail Search icon");
		isDisplayedThenClick(cloneRecord, "Clone Record");
		sleep(2);

	}

	// Added by mamtha

	public void validateCardProductsInSearchTable() {
		int totalRowsInTable = SeleniumWrappers.getTotalNumberOfRows(cardsTable, driver);
		WebElement cellElement;
		String expectedValue = "L1 - Card(16),L2 - Customer,L3 - Card Name,L4 - Prod Rest Desc,L5 - VRN(18), Spaces(4), Expiry";
		//
		String Desc = "";
		for (int i = 0; i <= totalRowsInTable - 1; i++) {
			try {
				Desc = SeleniumWrappers.getTableDataWithRowAndColumnNumber(0, i, driver);
				if (!Desc.equals("Security Deposit")) {
					cellElement = SeleniumWrappers.getTableDataWithCellElement(i, 0, driver);
					doubleClick(cellElement);
					sleep(2);
					switchTabDetails("Embossing");
					sleep(2);
					verifyTextInDropDownForEditable("Embossing Details", "Emboss Rule", expectedValue);
					sleep(2);
					clickOkButton();
					sleep(5);
				}
			} catch (Exception ex) {
				logFail(ex.getMessage());
			}
		}
	}

	public void validateVersionNumberMaxLengthInSearchTable() {
		int totalRowsInTable = SeleniumWrappers.getTotalNumberOfRows(cardsTable, driver);
		WebElement cellElement;
		String maxLength = "";

		//

		for (int i = 0; i <= totalRowsInTable - 1; i++) {
			try {

				cellElement = SeleniumWrappers.getTableDataWithCellElement(i, 0, driver);
				doubleClick(cellElement);
				sleep(2);
				switchTabDetails("Embossing");
				sleep(2);
				maxLength = getValueFromTextBox("Embossing Details", "Version Number Max Length");
				System.out.println("Version Num:" + maxLength);
				sleep(2);
				clickOkButton();

			} catch (Exception ex) {
				logFail(ex.getMessage());
			}
		}
	}

	/**
	 * Get Active Customer having active cards which are expiring in 90 days
	 **/
	public String dateFrom = "", dateTo = "";

	public String getCustomerNoHavingNoBulkReissueAndCardsExpiringInFewDays(String manualOrAutomaticReissue) {

		String clientCountry, clientName, expiringDate;
		String customerNo = "";
		clientName = PropUtils.getPropValue(configProp, "clientName");
		clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		if (manualOrAutomaticReissue.equalsIgnoreCase("manual")) {
			expiringDate = getProcessedIFCSDate("future", 3, "IFCS_" + clientName + "_USERNAME"); // Fix Needed updated
																									// Davu - 30/05/2020
		} else {
			expiringDate = getProcessedIFCSDate("past", 3, "IFCS_" + clientName + "_USERNAME");
		}
		String currentIFCSDate = getCurrentIFCSDateFromDB(clientName + "_" + clientCountry).split(" ")[0];
		SimpleDateFormat parser = new SimpleDateFormat("yyyy-MM-dd");
		SimpleDateFormat parser2 = new SimpleDateFormat("dd/MM/yyyy");

		try {
			dateTo = getDateInFormat(parser2.parse(expiringDate), "dd-MMM-yy").toUpperCase();
			dateFrom = getDateInFormat(parser.parse(currentIFCSDate), "dd-MMM-yy").toUpperCase();
			System.out.println("Expiring Date: " + dateTo + "IFCS Date:" + dateFrom);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		// Query updated for WFE - Davu - 09/06/2020
		String queryToGetCustomer = "Select mcu.customer_no from m_customers mcu inner join card_programs cp on mcu.card_program_oid = cp.card_program_oid inner join accounts acc on mcu.customer_mid=acc.customer_mid inner join account_status accs on accs.account_status_oid=acc.account_status_oid inner join account_sub_status accss on acc.account_sub_status_oid=accss.account_sub_status_oid where cp.client_mid=(select Client_mid from m_clients where name ='"
				+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountry)
				+ "') and mcu.customer_mid Not In (select customer_mid from CARD_BULK_REISSUES)  and mcu.customer_mid In (select customer_mid from cards inner join card_status on card_status.card_status_oid = cards.card_status_oid where ((card_status.description = 'Normal Service') or (card_status.description = 'Active') or (card_status.description like '%Normal Service')) and expires_on between '"
				+ dateFrom + "' and '" + dateTo
				+ "') and accss.description='Active' and  (accs.description like '%Active' or  accs.description like '%ACTIVE') and Rownum <=1";
		customerNo = connectDBAndGetValue(queryToGetCustomer, PropUtils.getPropValue(configProp, "sqlODSServerName"));
		System.out.println("customerNo:: " + customerNo);

		return customerNo;

	}

	/**
	 * Returns the Expiry date for a card from cutomer number given - This method
	 * depends on the above
	 * method-getCustomerNoHavingNoBulkReissueAndCardsExpiringIn90Days to get the
	 * expiry dates
	 ***/
	public String getCardExpiryDateForReissueCard(String customerNo) {
		String expiryDate;
		String queryToGetExpiryDate = "select expires_on from cards inner join card_status on card_status.card_status_oid = cards.card_status_oid where customer_mid = (select customer_mid from m_customers where customer_no='"
				+ customerNo
				+ "') and ((card_status.description = '100 Normal Service') or (card_status.description = 'Active')) and expires_on between '"
				+ dateFrom + "' and '" + dateTo + "' and Rownum <=1";
		expiryDate = connectDBAndGetValue(queryToGetExpiryDate, PropUtils.getPropValue(configProp, "sqlODSServerName"));
		System.out.println("Expiry Dates:" + expiryDate);
		return expiryDate;
	}

	/*
	 * Added by Davu --11/06/2020
	 */
	public String getCustomerWithContactType(String clientFullName) {
		String clientName = PropUtils.getPropValue(configProp, clientFullName).trim().toString();
		String customerNo;
		/*
		 * String queryToGetCustWithContactType =
		 * "select mc.customer_no from m_customers mc \r\n" +
		 * "inner join applications a on mc.customer_no=a.customer_no inner join accounts ac on ac.customer_mid=mc.customer_mid "
		 * +
		 * "inner join account_status acs on acs.account_status_oid=ac.account_status_oid\r\n"
		 * +
		 * "inner join application_contacts ac on ac.application_oid = a.application_oid\r\n"
		 * +
		 * "inner join contact_types ct on ac.contact_type_oid=ct.contact_type_oid \r\n"
		 * + "where ct.client_mid=(select client_mid from m_clients where name='" +
		 * clientName + "')  and acs.description like '%Active' ";
		 */// and rownum=1 order by mc.created_on desc
		String queryToGetCustWithContactType = "\r\n" + "select mcu.customer_no from m_customers mcu\r\n"
				+ "inner join contacts con on mcu.Customer_mid = con.member_oid\r\n"
				+ "inner join m_clients mc on mcu.client_mid = mc.client_mid\r\n"
				+ "inner join accounts a on mcu.customer_mid = a.customer_mid\r\n"
				+ "inner join account_status acs on a.account_status_oid = acs.account_status_oid\r\n"
				+ "inner join account_sub_status ass on a.account_sub_status_oid = ass.account_sub_status_oid\r\n"
				+ "where mc.name = '" + clientName + "' and acs.description ='Active' and ass.description ='Active'\r\n"
				+ "";
		customerNo = connectDBAndGetValue(queryToGetCustWithContactType,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		return customerNo;
	}

	/*
	 * Added by Davu --11/06/2020 updated by raxsana 07/08/2020
	 */
	public String getCustomerWithOutContactType(String clientFullName) {
		String clientName = PropUtils.getPropValue(configProp, clientFullName).trim().toString();
		String customerNo;
		String queryToGetCustWithContactType = "select mc.customer_no from m_customers mc \r\n"
				+ "inner join applications a on mc.customer_no=a.customer_no inner join accounts ac on ac.customer_mid=mc.customer_mid\r\n"
				+ "inner join account_status acs on acs.account_status_oid=ac.account_status_oid\r\n"
				+ "where mc.client_mid=(select client_mid from m_clients where name='" + clientName + "')\r\n"
				+ "and a.application_oid not in (select application_oid from application_contacts) and acs.description like '%Active'\r\n"
				+ "";// and rownum=1 order by mc.created_on desc
		customerNo = connectDBAndGetValue(queryToGetCustWithContactType,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		return customerNo;
	}

	// Need to update - Direct Method for BP -- Logic Check
	public String getActiveCustomerNoHavingCardsWithExpiryDate() {

		String clientCountry, clientName;
		String customerNo = "";
		clientName = PropUtils.getPropValue(configProp, "clientName");
		clientCountry = PropUtils.getPropValue(configProp, "clientCountry");

		System.out.println(PropUtils.getPropValue(configProp, clientName + "_" + clientCountry));
		String queryToGetCustomer = "Select mcu.customer_no from m_customers mcu inner join card_programs cp on mcu.card_program_oid = cp.card_program_oid inner join accounts acc on mcu.customer_mid=acc.customer_mid inner join account_status accs on accs.account_status_oid=acc.account_status_oid inner join account_sub_status accss on acc.account_sub_status_oid=accss.account_sub_status_oid where cp.client_mid=(select Client_mid from m_clients where name ='BP Oil New Zealand Limited') and mcu.customer_mid In (select customer_mid from cards inner join card_status on card_status.card_status_oid = cards.card_status_oid where card_status.description = '100 Normal Service')and mcu.customer_mid Not In (select customer_mid from CARD_BULK_REISSUES)and accss.description='Active'";
		customerNo = connectDBAndGetValue(queryToGetCustomer, PropUtils.getPropValue(configProp, "sqlODSServerName"));
		System.out.println("customerNo:: " + customerNo);

		return customerNo;
	}

	// Added by Nithya 21/05/2019
	public String getTableValuesWithKey(String keyColumn, String keyValue, String expectedCol) {
		List<WebElement> list = driver
				.findElements(By.xpath("//div[@class='FALTableCellEditor_StrikeThruField JTextComponent']"));

		int keyColIndex = SeleniumWrappers.getColumnNoForColumnHeader(keyColumn,
				driver.findElements(By.xpath("//div[@class='HeaderRenderer']")));
		int rowSize = SeleniumWrappers.getTotalNumberOfRows(list, driver);
		int keyRowIndex = 0;
		for (int i = 0; i < rowSize; i++) {
			if (SeleniumWrappers.getTableDataWithRowAndColumnNumber(keyColIndex, i, driver).equals(keyValue)) {
				keyRowIndex = i;
			} else {
				if (i == rowSize) {
					logFail("Expected column value not present");
				}
			}

		}
		SeleniumWrappers.getColumnNoForColumnHeader(expectedCol, headerRender);
		return SeleniumWrappers.getTableDataWithRowAndColumnNumber(
				SeleniumWrappers.getColumnNoForColumnHeader(expectedCol, headerRender), keyRowIndex, driver);
	}

	String text = fakerAPI().name().firstName();

	public String getActiveCustomerNoHavingActiveCardsWithNoBulkReissue() {

		String clientCountry, cardType, clientName;
		String cardTypeDesc = "";
		String customerNo = "";
		String qureyForCardType;
		clientName = PropUtils.getPropValue(configProp, "clientName");
		clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		if (clientName.equals("SHELL")) {
			cardType = PropUtils.getPropValue(configProp, "cardType");
			if (clientCountry.contains("MY")) {
				cardTypeDesc = "Shell Pre-Paid Card";
			} else if (cardType.contains("APA")) {
				cardTypeDesc = "Shell Pre-Paid Card (" + clientCountry + ")";
			} else {
				cardTypeDesc = "Shell Partner Card (" + clientCountry + ")";
			}
			qureyForCardType = "cp.description = '" + cardTypeDesc + "' and Rownum <=1";
		} else {
			qureyForCardType = "Rownum <=1";
		}
		System.out.println(PropUtils.getPropValue(configProp, clientName + "_" + clientCountry));
		String queryToGetCustomer = "Select mcu.customer_no from m_customers mcu inner join accounts acc on mcu.customer_mid=acc.customer_mid inner join account_status accs on accs.account_status_oid=acc.account_status_oid inner join account_sub_status accss on acc.account_sub_status_oid=accss.account_sub_status_oid inner join card_programs cp on mcu.card_program_oid = cp.card_program_oid where mcu.customer_mid Not In (select customer_mid from CARD_BULK_REISSUES) and mcu.customer_mid In (select customer_mid from cards inner join card_status on card_status.card_status_oid = cards.card_status_oid where card_status.description = 'Active') and accs.description like '%Active' and accss.description='Active' and "
				+ qureyForCardType;
		customerNo = connectDBAndGetValue(queryToGetCustomer, PropUtils.getPropValue(configProp, "sqlODSServerName"));
		System.out.println("customerNo:: " + customerNo);

		return customerNo;

	}

	// Prakalpha-->Interface
	public String getActiveCustomerNoHavingCardsAndRowIndex(int rowIndex) {
		String clientCountry, cardType, clientName;
		String cardTypeDesc = "";
		String queryToGetCustomer;
		String customerNo = "";
		clientName = PropUtils.getPropValue(configProp, "clientName");
		clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		if (clientName.equals("SHELL")) {
			cardType = PropUtils.getPropValue(configProp, "cardType");
			if (clientCountry.contains("MY")) {
				cardTypeDesc = "Shell Pre-Paid Card";
			} else if (cardType.contains("APA")) {
				cardTypeDesc = "Shell Pre-Paid Card (" + clientCountry + ")";
			} else {
				cardTypeDesc = "Shell Partner Card (" + clientCountry + ")";
			}

			queryToGetCustomer = "Select distinct mcu.customer_no from m_customers mcu inner join card_programs cp on mcu.card_program_oid = cp.card_program_oid inner join accounts acc on mcu.customer_mid=acc.customer_mid inner join account_status accs on accs.account_status_oid=acc.account_status_oid inner join account_sub_status accss on acc.account_sub_status_oid=accss.account_sub_status_oid  where mcu.customer_mid In (select customer_mid from cards) and accs.description like '%Active' and accss.description='Active' "
					+ " and cp.description = '" + cardTypeDesc + "' and Rownum <=1";

		} else {

			cardTypeDesc = "cp.client_mid=(select Client_mid from m_clients where name ='"
					+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountry) + "')";
			queryToGetCustomer = "Select distinct mcu.customer_no from m_customers mcu inner join card_programs cp on mcu.card_program_oid = cp.card_program_oid inner join accounts acc on mcu.customer_mid=acc.customer_mid inner join account_status accs on accs.account_status_oid=acc.account_status_oid inner join account_sub_status accss on acc.account_sub_status_oid=accss.account_sub_status_oid  where mcu.customer_mid In (select customer_mid from cards) and accs.description like '%Active' and accss.description='Active' and "
					+ cardTypeDesc + " and Rownum <=1";

		}
		customerNo = connectDBAndGetDBRowValue(queryToGetCustomer,
				PropUtils.getPropValue(configProp, "sqlODSServerName"), rowIndex);
		System.out.println("customerNo:: " + customerNo);

		return customerNo;
	}
	// Added by sowmiya
	// For OTI To change the status temp block to active

	public String getActiveOrTemporaryBlockCustomerNoHavingCardsAndRowIndex(int rowIndex, String status) {
		String clientCountry, clientName;
		String queryToGetCustomer = "";
		String cardTypeDesc = "";
		String customerNo = "";
		clientName = PropUtils.getPropValue(configProp, "clientName");
		clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		if (status.equals("Temporary Lock")) {
			cardTypeDesc = "cp.client_mid=(select Client_mid from m_clients where name ='"
					+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountry) + "')";
			queryToGetCustomer = "Select distinct mcu.customer_no from m_customers mcu inner join card_programs cp on mcu.card_program_oid = cp.card_program_oid inner join accounts acc on mcu.customer_mid=acc.customer_mid inner join account_status accs on accs.account_status_oid=acc.account_status_oid inner join account_sub_status accss on acc.account_sub_status_oid=accss.account_sub_status_oid  where mcu.customer_mid In (select customer_mid from cards) and accs.description like '%Temporary Lock' and accss.description= 'Bad Debt' and "
					+ cardTypeDesc + "";
		} else if (status.equals("Active")) {
			cardTypeDesc = "cp.client_mid=(select Client_mid from m_clients where name ='"
					+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountry) + "')";
			queryToGetCustomer = "Select distinct mcu.customer_no from m_customers mcu inner join card_programs cp on mcu.card_program_oid = cp.card_program_oid inner join accounts acc on mcu.customer_mid=acc.customer_mid inner join account_status accs on accs.account_status_oid=acc.account_status_oid inner join account_sub_status accss on acc.account_sub_status_oid=accss.account_sub_status_oid  where mcu.customer_mid In (select customer_mid from cards) and (accs.description like '%Active'  or  accs.description like '%ACTIVE' ) and accss.description='Active' and "
					+ cardTypeDesc + "";
		}else if(status.equals("Temp Blocked")){
			cardTypeDesc = "cp.client_mid=(select Client_mid from m_clients where name ='"
					+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountry) + "')";
			queryToGetCustomer = "Select distinct mcu.customer_no from m_customers mcu inner join card_programs cp on mcu.card_program_oid = cp.card_program_oid inner join accounts acc on mcu.customer_mid=acc.customer_mid inner join account_status accs on accs.account_status_oid=acc.account_status_oid inner join account_sub_status accss on acc.account_sub_status_oid=accss.account_sub_status_oid  where mcu.customer_mid In (select customer_mid from cards) and accs.description like '%"+status+"' and accss.description= 'Other' and "
					+ cardTypeDesc + "";
		}else if(status.equals("Closed")){
			cardTypeDesc = "cp.client_mid=(select Client_mid from m_clients where name ='"
					+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountry) + "')";
			queryToGetCustomer = "Select distinct mcu.customer_no from m_customers mcu inner join card_programs cp on mcu.card_program_oid = cp.card_program_oid inner join accounts acc on mcu.customer_mid=acc.customer_mid inner join account_status accs on accs.account_status_oid=acc.account_status_oid inner join account_sub_status accss on acc.account_sub_status_oid=accss.account_sub_status_oid  where mcu.customer_mid In (select customer_mid from cards) and accs.description like '%"+status+"' and accss.description= 'Bad Debt' and "
					+ cardTypeDesc + "";
		}

		customerNo = connectDBAndGetDBRowValue(queryToGetCustomer,
				PropUtils.getPropValue(configProp, "sqlODSServerName"), rowIndex);
		System.out.println("customerNo:: " + customerNo);

		return customerNo;
	}

	public String getActiveCustomerNoHavingPCCardsType() {
		String clientCountry;
		String cardTypeDesc = "";
		String queryToGetCustomerForPC;
		String customerNo = "";
		clientCountry = PropUtils.getPropValue(configProp, "clientCountry");

		cardTypeDesc = "Shell Partner Card (" + clientCountry + ")";

		queryToGetCustomerForPC = "Select distinct mcu.customer_no from m_customers mcu inner join card_programs cp on mcu.card_program_oid = cp.card_program_oid inner join accounts acc on mcu.customer_mid=acc.customer_mid inner join account_status accs on accs.account_status_oid=acc.account_status_oid inner join account_sub_status accss on acc.account_sub_status_oid=accss.account_sub_status_oid  where mcu.customer_mid In (select customer_mid from cards) and accs.description like '%Active' and accss.description='Active' "
				+ " and cp.description = '" + cardTypeDesc + "' and Rownum <=1";
		customerNo = connectDBAndGetValue(queryToGetCustomerForPC,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		System.out.println("customerNo:: " + customerNo);
		return customerNo;
	}

	public String getExpiryDateFromDB() {
		String clientName, clientCountry;

		clientName = PropUtils.getPropValue(configProp, "clientName");
		clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		String expiryDateDB = "Select C.EXPIRES_ON from m_customers MC inner join cards C on c.customer_mid = mc.customer_mid inner join card_status CS on c.card_status_oid=cs.card_status_oid inner join m_clients mcn on mcn.client_mid = mc.client_mid where cs.description like '%Active%' and mcn.name = '"
				+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountry).replaceAll("\"", "")
				+ "' and rownum<=1";

		String expiryDate = connectDBAndGetValue(expiryDateDB, PropUtils.getPropValue(configProp, "sqlODSServerName"));
		System.out.println("Expiry Date" + expiryDate);
		return expiryDate;

	}

	public String getCustomerNoHavingMoreThan5ActiveCards() {
		String clientName, clientCountry;
		clientName = PropUtils.getPropValue(configProp, "clientName");
		clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		String customerNoHavingMoreThan5Cards = "Select distinct mcu.customer_no from m_customers mcu inner join cards on mcu.customer_mid = cards.customer_mid inner join card_programs cp on cp.card_program_oid=mcu.card_program_oid where cp.client_mid=(select Client_mid from m_clients where name ='"
				+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountry).replaceAll("\"", "") + "')"
				+ " and cards.card_no in (select cards.card_no from cards inner join card_status on card_status.card_status_oid = cards.card_status_oid where card_status.description like '%Normal Service') and mcu.customer_mid in (SELECT customer_mid FROM cards GROUP BY cards.customer_mid HAVING COUNT(cards.customer_mid) >= 3) and rownum<=1";
		String customerNo = connectDBAndGetValue(customerNoHavingMoreThan5Cards,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		System.out.println("Customer No" + customerNo);
		return customerNo;
	}

	// Sasi 26-04-2019
	public void clickPostTransactionInPopup() {
		waitForElementTobeClickable(postTransactionInPopup, 10);
		isDisplayedThenClick(postTransactionInPopup, "Post Transaction Icon");
	}

	public String enterDetailsInCardFeesPopUp() {
		String text = fakerAPI().name().firstName();
		validatePopupHeaderText("Card Fees");
		enterValueInTextBox("Description", "Description", text);
		chooseARandomDropdownOption("Card Fee 1");
		chooseARandomDropdownOption("Card Fee 2");
		chooseARandomDropdownOption("Card Fee 3");
		enterValueInTextBox("Details", "Months Delay", fakerAPI().number().digits(1));
		Click(okButton, "Ok Button");
		return text;
	}

	// Prakalpha -->05/29/2019
	public String getReceivedOnDateForMigratedCustomer() {

		String clientName, clientCountry;

		clientName = PropUtils.getPropValue(configProp, "clientName");
		clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		if (!isDateUpdated) {
			String queryToGetReceviedOnDateforMigratedCustomer = "select * from (select a.received_on, count(*) as counter from m_customers c inner join applications a on a.application_oid = c.application_oid where a.client_mid=(select Client_mid from m_clients where name ='"
					+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountry)
					+ "') group by a.received_on)order by counter desc";
			String receivedOn = connectDBAndGetDBRowValue(queryToGetReceviedOnDateforMigratedCustomer,
					PropUtils.getPropValue(configProp, "sqlODSServerName"), 1);
			System.out.println("receivedOn:: " + receivedOn);
			SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			SimpleDateFormat format2 = new SimpleDateFormat("dd/MM/yy");
			Date date = null;
			try {
				date = format1.parse(receivedOn);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			changedFormat = format2.format(date);

			if (!changedFormat.equals("")) {
				isDateUpdated = true;
			}

			System.out.println("------ IF changedFormat -----" + changedFormat);

		} else {
			System.out.println("------ Else changedFormat -----" + changedFormat);
		}

		return changedFormat;
	}

	// Prakalpha-->05/29/2019

	public String getMigratedCustomerNo(String receivedOnDate, String applicationType) {
		String clientName, clientCountry;

		clientName = PropUtils.getPropValue(configProp, "clientName");
		clientCountry = PropUtils.getPropValue(configProp, "clientCountry");

		String queryToGetMigratedCustomer = "Select a.customer_no,a.Name from APPLICATIONS a Where trunc(RECEIVED_ON) =TO_DATE('"
				+ receivedOnDate
				+ "','DD/MM/YY') and a.customer_no in (select customer_no from m_customers mc inner join accounts acc on mc.customer_mid=acc.customer_mid inner join account_status accs on accs.account_status_oid=acc.account_status_oid inner join account_sub_status accss on accss.account_status_oid = accs.account_status_oid where accs.description like '%Active' and accss.description like '%Active')and a.Client_MID =(select Client_mid from m_clients where name ='"
				+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountry)
				+ "') and a.application_type_oid =(select application_type_oid from application_types where description='"
				+ applicationType + "') and Rownum <=1";
		String migratedCustomerNo = connectDBAndGetValue(queryToGetMigratedCustomer,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		System.out.println("migratedCustomerNo:: " + migratedCustomerNo);

		return migratedCustomerNo;
	}

	// Prakalpha-->06/25/2019

	public String getMigratedCustomerHavingActiveCardsWithAccountBalance(String receivedOnDate,
			String applicationType) {

		String clientName, clientCountry;

		clientName = PropUtils.getPropValue(configProp, "clientName");
		clientCountry = PropUtils.getPropValue(configProp, "clientCountry");

		String queryToGetMigratedCustomerhavingCards = "Select a.customer_no,a.Name from APPLICATIONS a Where trunc(RECEIVED_ON) =TO_DATE('"
				+ receivedOnDate
				+ "','DD/MM/YY') and a.customer_no in (select customer_no from m_customers mc inner join accounts acc on mc.customer_mid=acc.customer_mid inner join account_status accs on accs.account_status_oid=acc.account_status_oid inner join account_sub_status accss on accss.account_status_oid = accs.account_status_oid where accs.description like '%Active' and accss.description like '%Active') and a.Client_MID =(select Client_mid from m_clients where name ='"
				+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountry)
				+ "') and a.application_type_oid =(select application_type_oid from application_types where description='"
				+ applicationType
				+ "') and a.customer_no in (select mcust.customer_no from m_customers mcust inner join cards c on mcust.customer_mid=c.customer_mid INNER JOIN CARD_BALANCES ON c.CARD_BALANCE_OID = CARD_BALANCES.CARD_BALANCE_OID INNER JOIN CARD_STATUS ON c.card_status_oid = card_status.card_status_oid inner join calc_avail_bal_account_view av on mcust.customer_mid=av.customer_mid where (CARD_STATUS.DESCRIPTION = 'Active' OR CARD_STATUS.DESCRIPTION like '%Normal Service')and av.calculated_available_balance > 100 ) and Rownum <=1";
		String migratedCustomerNohavingActiveCards = connectDBAndGetValue(queryToGetMigratedCustomerhavingCards,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		System.out.println("migratedCustomerNo:: " + migratedCustomerNohavingActiveCards);

		return migratedCustomerNohavingActiveCards;
	}

	// Prakalpha-->06/25/2019
	public String getActiveCardNoFromMigratedCustomer(String migrateCusNo, int rowIndex) {
		String queryToGetCardsForMigratedCus = "select c.CARD_NO from Cards c inner join m_customers mc on c.customer_mid = mc.customer_mid INNER JOIN CARD_STATUS ON c.card_status_oid = card_status.card_status_oid inner join calc_avail_bal_account_view av on mc.customer_mid=av.customer_mid where (CARD_STATUS.DESCRIPTION = 'Active' OR CARD_STATUS.DESCRIPTION like '%Normal Service')and mc.customer_no='"
				+ migrateCusNo + "' and av.calculated_available_balance > 100";
		String activeCardsfromMigratedCus = connectDBAndGetDBRowValue(queryToGetCardsForMigratedCus,
				PropUtils.getPropValue(configProp, "sqlODSServerName"), rowIndex);
		System.out.println("migratedCustomerNo:: " + activeCardsfromMigratedCus);
		return activeCardsfromMigratedCus;
	}

	// Prakalpha-->06/12/2019

	public String getRebateParentCustomerNoInHierarchy() {
		String clientName, clientCountry;
		clientName = PropUtils.getPropValue(configProp, "clientName");
		clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		String getRebateCustomerNo = "select distinct mc.customer_no,rel.hierarchy_oid,accs.description,accss.description from m_customers mc inner join accounts acc on mc.customer_mid=acc.customer_mid inner join account_status accs on accs.account_status_oid=acc.account_status_oid inner join account_sub_status accss on accss.account_status_oid = accs.account_status_oid inner join relationships rel on acc.customer_mid=rel.member_oid where rel.relationship_oid=rel.parent_relationship_oid and rel.hierarchy_oid in (select hierarchy_oid from hierarchies hc where hc.is_period_rebate like 'Y') and mc.client_mid =(select CLIENT_MID from m_clients where name='"
				+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountry)
				+ "') and parent_relationship_oid in (select distinct rel.parent_relationship_oid  from Relationships rel inner join relationship_assignments rels on  rel.relationship_oid=rels.relationship_oid where rel.relationship_oid !=rel.parent_relationship_oid ) and accs.description like '%Active' and accss.description like '%Active'";
		String rebateCustomerNo = connectDBAndGetValue(getRebateCustomerNo,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		System.out.println("migratedCustomerNo:: " + rebateCustomerNo);
		return rebateCustomerNo;
	}

	public String getChildCustomerNoInHierarchy(String parentCustomerNo) {
		String clientName, clientCountry;
		String getHierarchyChildCustomerNo = " ";
		clientName = PropUtils.getPropValue(configProp, "clientName");
		clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		if (clientName.contains("EMAP")) {
			clientName = clientName.replace("EMAP", "EX ");
			String queryToProcessingDate = "SELECT PROCESSING_DATE from M_CLIENTS where IE_CLIENT_ID='" + clientName
					+ clientCountry + "'";
			getHierarchyChildCustomerNo = "select customer_no,accs.description,accss.description  from m_customers mc inner join accounts acc on mc.customer_mid=acc.customer_mid inner join relationships rel on acc.customer_mid=rel.member_oid inner join account_status accs on accs.account_status_oid=acc.account_status_oid inner join account_sub_status accss on accss.account_status_oid = accs.account_status_oid where mc.customer_mid In (select customer_mid from cards c inner join card_status cs on cs.card_status_oid = c.card_status_oid where cs.description like '%Active' and c.expires_on >= ("
					+ queryToProcessingDate
					+ ")) and rel.parent_relationship_oid in (select rel.parent_relationship_oid from m_customers mc inner join accounts acc on mc.customer_mid=acc.customer_mid inner join relationships rel on acc.customer_mid=rel.member_oid inner join relationship_assignments relass on rel.relationship_oid=relass.relationship_oid where mc.customer_no ='"
					+ parentCustomerNo
					+ "') and rel.relationship_oid!=rel.parent_relationship_oid and accs.description like '%Active' and  accss.description like '%Active'";
		}
		String hierarchyChildCustomerNo = connectDBAndGetValue(getHierarchyChildCustomerNo,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		System.out.println("migratedCustomerNo:: " + hierarchyChildCustomerNo);

		return hierarchyChildCustomerNo;
	}

	// Naveen

	public String changingTheDateFormat() {
		Common common = new Common(driver, test);
		String expiryDateFromDB = common.getExpiryDateFromDB();
		String str = new String(expiryDateFromDB);
		String DBExpiryDate = str.split(" ")[0];
		String CurrentDBDate = DBExpiryDate;
		System.out.println(CurrentDBDate);
		try {
			SimpleDateFormat currentDateFormat = new SimpleDateFormat("yyyy-MM-dd");

			Date date = currentDateFormat.parse(CurrentDBDate);

			SimpleDateFormat formatToBeChanged = new SimpleDateFormat("dd/MM/yyyy");

			CurrentDBDate = formatToBeChanged.format(date);
			System.out.println(CurrentDBDate);

		} catch (Exception pe) {
			System.out.println("ParseException" + pe);
		}
		return CurrentDBDate;
	}

	public String addNewExpiryDate() {
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd/MM/yyyy");
		Calendar calendar = Calendar.getInstance();
		try {
			calendar.setTime(simpleDateFormat.parse(CurrentDBDate));
		} catch (Exception e) {
			e.printStackTrace();
		}

		calendar.add(Calendar.DAY_OF_MONTH, 10);

		String newExpiryDate = simpleDateFormat.format(calendar.getTime());

		System.out.println("After Adding new Expiry Date: " + newExpiryDate);

		return newExpiryDate;

	}

	// rax 31/05/2019

	public String getCardNumberWithDriverNameForVehicleCard() {

		String clientName, clientCountry;
		clientName = PropUtils.getPropValue(configProp, "clientName");
		clientCountry = PropUtils.getPropValue(configProp, "clientCountry");

		String queryCardNumberWithDriverName = "select distinct card_no from cards cd where cd.card_oid=(Select distinct d.card_oid from drivers d inner join cards c on d.card_oid=c.card_oid inner join card_programs cp on c.card_program_oid = cp.card_program_oid inner join card_status cs on cs.card_status_oid = c.card_status_oid inner join  m_customers mc on mc.customer_mid = c.customer_mid inner join accounts acc on mc.customer_mid=acc.customer_mid inner join account_status accs on accs.account_status_oid=acc.account_status_oid inner join account_sub_status accss on accss.account_status_oid = accs.account_status_oid where d.driver_name is not null and c.replace_card_oid IS NULL and c.vehicle_oid is not null and cp.client_mid = (Select client_mid from m_clients where name = '"
				+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountry)
				+ "') and c.expires_on >=(SELECT PROCESSING_DATE from M_CLIENTS where name ='"
				+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountry).replaceAll("\"", "")
				+ "') and c.card_type_cid ='701' and accs.description like '%Active' and accss.description like '%Active' and (cs.description like '%Active' OR cs.description like '%Normal Service') and rownum<=1)";
		String cardNumberWithDriverName = connectDBAndGetValue(queryCardNumberWithDriverName,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));

		return cardNumberWithDriverName;
	}

	public String getCustomerNoForCardNumber(String cardNumber) {

		String queryCustomerNoForCardNumber = "select customer_no from m_customers mc inner join cards c on mc.customer_mid=c.customer_mid where card_no='"
				+ cardNumber + "'";
		String customerNoForCardNumber = connectDBAndGetValue(queryCustomerNoForCardNumber,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		return customerNoForCardNumber;
	}

	// Added by rax 24/07/2019
	public String getDataFromLatestDownloadedPdfFile(String fileName) {

		// Loading an existing document
		String downloadedFileName = getLatestDownloadedFileFromDir(fileName).getName();
		String pdfFilePathLocal = System.getProperty("user.home") + System.getProperty("file.separator") + "Downloads"
				+ System.getProperty("file.separator") + downloadedFileName;
		System.out.println("file path local" + pdfFilePathLocal);
		File file = new File(pdfFilePathLocal);
		PDDocument document = null;
		String text = null;
		String referenceNum = null;
		try {
			document = PDDocument.load(file);

			if (fileName.contains("ApplicationCreation")) {
				document.getPage(3);
				PDDocumentCatalog catalog = document.getDocumentCatalog();
				PDAcroForm form = catalog.getAcroForm();

				List<PDField> fields = form.getFields();
				for (PDField obj : fields) {
					referenceNum = obj.getValueAsString();
					if (referenceNum.contains("App:")) {
						text = referenceNum.split(":")[1];
					}
				}
			} else {
				// Instantiate PDFTextStripper class
				PDFTextStripper pdfStripper = null;

				pdfStripper = new PDFTextStripper();
				// Retrieving text from PDF document
				text = pdfStripper.getText(document);

				System.out.print(text);

			}
			// System.out.println(text);
			// Closing the document
			document.close();
		} catch (Exception e) {
			e.getMessage();
		}
		return text;

	}

	public String getDriverOidForCardNumber(String cardNumber) {
		String queryForDriverOid = "select driver_oid from cards where card_no='" + cardNumber + "'";
		String driverOidForCardNumber = connectDBAndGetValue(queryForDriverOid,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		return driverOidForCardNumber;
	}

	// Added by Nithya on 07-06-2019
	public String getActiveCustomerUsingApplicationType(String applicationType) {
		String clientName, clientCountry, cardType;
		String cardTypeDesc = "";
		String customerNo = "";
		String queryToGetCustomerNumberHasTransaction;
		clientName = PropUtils.getPropValue(configProp, "clientName");
		clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		cardType = PropUtils.getPropValue(configProp, "cardType");
		if (clientName.equals("SHELL")) {
			if (clientCountry.contains("MY")) {
				if (cardType.contains("APA")) {
					cardTypeDesc = "Shell Pre-Paid Card";
				}
			} else {
				if (cardType.contains("APA")) {
					cardTypeDesc = "Shell Pre-Paid Card (" + clientCountry + ")";
				} else {
					cardTypeDesc = "Shell Partner Card (" + clientCountry + ")";
				}
			}
			queryToGetCustomerNumberHasTransaction = "Select distinct mcu.customer_no from m_customers mcu inner join accounts acc on mcu.customer_mid=acc.customer_mid inner join account_status accs on accs.account_status_oid=acc.account_status_oid inner join account_sub_status accss on acc.account_sub_status_oid=accss.account_sub_status_oid inner join card_programs cp on mcu.card_program_oid = cp.card_program_oid where (accs.description like '%Active' or accs.description like '%ACTIVE') and accss.description='Active' and mcu.client_mid =(Select client_mid from m_clients where name ='"
					+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountry).replaceAll("\"", "")
					+ "') and cp.description = '" + cardTypeDesc
					+ "' and   mcu.customer_no in (select customer_no from applications where application_type_oid = (select application_type_oid from application_types where description='"
					+ applicationType
					+ "')) and mcu.customer_mid not in (select customer_mid from appl_type_transfers) and Rownum <=1";
			customerNo = connectDBAndGetValue(queryToGetCustomerNumberHasTransaction,
					PropUtils.getPropValue(configProp, "sqlODSServerName"));
		} else {
			queryToGetCustomerNumberHasTransaction = "Select distinct mcu.customer_no from m_customers mcu inner join accounts acc on mcu.customer_mid=acc.customer_mid inner join account_status accs on accs.account_status_oid=acc.account_status_oid inner join account_sub_status accss on acc.account_sub_status_oid=accss.account_sub_status_oid inner join card_programs cp on mcu.card_program_oid = cp.card_program_oid where (accs.description like '%Active' or accs.description like '%ACTIVE') and accss.description='Active' and mcu.client_mid =(Select client_mid from m_clients where name ='"
					+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountry).replaceAll("\"", "")
					+ "') and   mcu.customer_no in (select customer_no from applications where application_type_oid = (select application_type_oid from application_types where description='"
					+ applicationType
					+ "')) and mcu.customer_mid not in (select customer_mid from appl_type_transfers) and Rownum <=1";
			customerNo = connectDBAndGetValue(queryToGetCustomerNumberHasTransaction,
					PropUtils.getPropValue(configProp, "sqlODSServerName"));
		}
		System.out.println("customerNo:: " + customerNo);
		return customerNo;
	}

	// Prakalpha-->06/28/2019
	public String getCustomerNoInHierarchy() {
		String clientName, clientCountry;
		clientName = PropUtils.getPropValue(configProp, "clientName");
		clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		String getHierarchyCustomerNo = "select distinct mc.customer_no,rel.hierarchy_oid,accs.description,accss.description from m_customers mc inner join accounts acc on mc.customer_mid=acc.customer_mid inner join account_status accs on accs.account_status_oid=acc.account_status_oid inner join account_sub_status accss on accss.account_status_oid = accs.account_status_oid inner join relationships rel on acc.customer_mid=rel.member_oid Where mc.client_mid =(select CLIENT_MID from m_clients where name='"
				+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountry)
				+ "') and parent_relationship_oid in (select distinct rel.parent_relationship_oid  from Relationships rel inner join relationship_assignments rels on  rel.relationship_oid=rels.relationship_oid where rel.relationship_oid !=rel.parent_relationship_oid ) and accs.description like '%Active' and accss.description like '%Active'";
		String hierarchyCustomerNo = connectDBAndGetValue(getHierarchyCustomerNo,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		System.out.println("migratedCustomerNo:: " + hierarchyCustomerNo);
		return hierarchyCustomerNo;
	}

	// getCards based on the products restriction (i.e) --> Fuel products -->
	// Synergy and All non fuel products
	public String getCardsBasedOnProductRestriction(String cardStatus) {
		String clientCountry, clientName;
		// String cardTypeDesc = "";
		String cardNumber = "";
		clientName = PropUtils.getPropValue(configProp, "clientName");
		System.out.println(clientName);
		clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		System.out.println(clientCountry);

		String queryToGetCardNumber = "Select distinct pc.card_no from produced_cards pc where product_restriction_oid in (Select product_restriction_oid from product_restrictions  "
				+ " where (PRODUCT_RESTRICTION_CODE = 'FA' OR PRODUCT_RESTRICTION_CODE = 'AA' OR PRODUCT_RESTRICTION_CODE = 'DB')) "
				+ " and pc.card_oid in ( select c.card_oid from Cards c INNER JOIN CARD_PROGRAMS cp ON c.card_program_oid = cp.card_program_oid inner join m_customers mc on mc.customer_mid = c.customer_mid "
				+ " INNER JOIN CARD_STATUS cs ON c.card_status_oid = cs.card_status_oid INNER JOIN CARD_BALANCES cb ON c.CARD_BALANCE_OID = cb.CARD_BALANCE_OID inner join calc_avail_bal_account_view av on c.customer_mid = av.customer_mid "
				+ " inner join accounts acc on mc.customer_mid=acc.customer_mid inner join account_status accs on accs.account_status_oid=acc.account_status_oid inner join account_sub_status accss on accss.account_status_oid = accs.account_status_oid "
				+ " Where accs.description like '%Active' and accss.description like '%Active' and av.calculated_available_balance > 0 and "
				+ " cp.client_mid=(select Client_mid from m_clients where name ='"
				+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountry).replaceAll("\"", "") + "') "
				+ " AND  c.expires_on >=(SELECT PROCESSING_DATE from M_CLIENTS where name ='"
				+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountry).replaceAll("\"", "") + "') "
				+ " and cs.DESCRIPTION = '" + cardStatus + "' and c.replace_card_oid IS NULL ) ";
		cardNumber = connectDBAndGetValue(queryToGetCardNumber, PropUtils.getPropValue(configProp, "sqlODSServerName"));
		System.out.println("customerNo:: " + cardNumber);
		return cardNumber;
	}

	// Added by Nithya 28-06-2019
	public String[] getCardsListOfTheCustomer(String customerNo) {
		String getCardNoForCustomer = "Select c.card_no from cards c inner join m_customers mc on c.customer_mid = mc.customer_mid where mc.customer_no = '"
				+ customerNo
				+ "'and c.card_status_oid in (select card_status_oid from card_status where description ='100 Normal Service')";
		return connectDBAndGetDBResults(getCardNoForCustomer, PropUtils.getPropValue(configProp, "sqlODSServerName"));
	}

	public String getActiveCardOfTheCustomer(String customerNo, String clientName, String clientCountry) {

		String clientFullName = PropUtils.getPropValue(configProp, clientName + "_" + clientCountry);

		String getCardNoForCustomer = "Select card_no from Cards where customer_mid = (select Customer_mid from m_customers where Customer_no ='"
				+ customerNo
				+ "') and card_status_oid = (select card_status_oid from card_status where description ='Normal Service' and client_mid=(select client_mid from m_clients where name='"
				+ clientFullName + "'))";

		return connectDBAndGetValue(getCardNoForCustomer, PropUtils.getPropValue(configProp, "sqlODSServerName"));
	}

	public String getCustomerWithLowCriditLimit(String clientName, String clientCountry) {
		String clientFullName = PropUtils.getPropValue(configProp, clientName + "_" + clientCountry);
		String getCustomerNo = "select customer_no from m_customers mc inner join cards c on c.customer_mid=mc.customer_mid where mc.customer_mid in (select customer_mid from Accounts where Credit_limit < 100) and mc.client_mid in (Select client_mid from m_clients where name ='"
				+ clientFullName + "') and \r\n" + 
						"c.card_status_oid in (select card_status_oid from card_status where description ='Normal Service')";
		return connectDBAndGetValue(getCustomerNo, PropUtils.getPropValue(configProp, "sqlODSServerName"));

	}


	public String getCardStatus(String cardNumber) {
		String getCardStatus = "select Description from card_status where card_status_oid= (select card_status_oid from cards where card_no = '"
				+ cardNumber + "') ";
		return connectDBAndGetValue(getCardStatus, PropUtils.getPropValue(configProp, "sqlODSServerName"));
	}

	public String getCardFeeProfileDescription(String customerNo) {
		String cardFeeProfileDescription = "";
		String cardFeeProfileDescriptionQuery = "";
		String cardFeeProfileDescriptionCountQuery = "select count(DESCRIPTION) from fee_profiles where fee_profile_oid in (select fee_profile_oid  from CARDS where (customer_mid=(select customer_mid from m_customers where customer_no ="
				+ customerNo + "))and driver_oid is not null )";
		String cardFeeProfileDescriptionCount = connectDBAndGetValue(cardFeeProfileDescriptionCountQuery,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		System.out.println(cardFeeProfileDescriptionCount);
		int cardFeeProfileCount = Integer.parseInt(cardFeeProfileDescriptionCount);
		System.out.println(cardFeeProfileCount);
		if (cardFeeProfileCount > 1) {
			logFail("More than one Card Fee Profile is Displaying");
		} else
			cardFeeProfileDescriptionQuery = "select DESCRIPTION from fee_profiles where fee_profile_oid in (select fee_profile_oid  from CARDS where (customer_mid=(select customer_mid from m_customers where customer_no ="
					+ customerNo + "))and driver_oid is not null )";
		cardFeeProfileDescription = connectDBAndGetValue(cardFeeProfileDescriptionQuery,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		System.out.println("Changed Card Fee Profile is:" + cardFeeProfileDescription);
		return cardFeeProfileDescription;
	}

	public Map<String, String> getValuesFromQueryForCardSalesAggregate() {
		String getValuesForCardSalesAggregate = "with" + "    product_group_data as" + "    (" + "        select"
				+ "            pg.*," + "            pgp.product_oid" + "        from" + "            product_groups pg"
				+ "        inner join product_group_products pgp on pg.product_group_oid = pgp.product_group_oid"
				+ "        where"
				+ "            pg.product_group_type_cid = 2907 and pg.external_client_code ='BP AU SAP' and pg.short_description = 'AUSAPNonfuel'"
				+ "    )" + "    ," + "    trans_data as" + "    (" + "        select"
				+ "            t.transaction_category_cid," + "            (" + "            case"
				+ "                when t.transaction_category_cid = 4714 and tr.orig_cust_mid <> cust.customer_mid"
				+ "                then trcust.ext_delivery_ref" + "                else cust.ext_delivery_ref"
				+ "            end) as cust_ext_ref ," + "            (" + "            case"
				+ "                when t.transaction_category_cid = 4714" + "                then trl.external_code"
				+ "                else l.external_code" + "            end) as loc_ext_ref ,"
				+ "            i.line_number," + "            curr.currency_code," + "            ("
				+ "            case" + "                when trunc (t.processed_at) > trunc (c.month_end_1_on)"
				+ "                then c.current_year || '-' || lpad(c.current_month, 2, '0')" + "                else"
				+ "                    case" + "                        when c.current_month=1"
				+ "                        then to_char(c.current_year - 1) || '-12'"
				+ "                        else c.current_year || '-' || lpad(to_char(c.current_month - 1), 2, '0')"
				+ "                    end" + "            end) as period_end_date," + "            ("
				+ "            case" + "                when t.transaction_category_cid = 4701" + "                then"
				+ "                    case " + "                        when ip.is_fuel = 'Y'"
				+ "                        then ipt.external_code" + "                        else ipdp.external_code"
				+ "                    end" + "                when t.transaction_category_cid = 4714"
				+ "                then" + "                    case" + "                        when trp.is_fuel = 'Y'"
				+ "                        then trpt.external_code" + "                        else trpdp.external_code"
				+ "                    end" + "            end) as external_product_code," + "            case"
				+ "                when t.transaction_category_cid = 4701" + "                then i.quantity"
				+ "                else 0" + "            end as quantity," + "            (" + "            case"
				+ "                when t.transaction_category_cid = 4701"
				+ "                then i.customer_value - i.customer_tax_amount" + "                else ("
				+ "                    case" + "                        when t.transaction_category_cid = 4714"
				+ "                        then (" + "                            case"
				+ "                                when upper(tt.is_debit) = 'N'"
				+ "                                then (trb.rebate_amount - trb.tax_amount) * -1"
				+ "                                else trb.rebate_amount - trb.tax_amount"
				+ "                            end)"
				+ "                        else t.customer_amount - t.customer_tax_amount" + "                    end)"
				+ "            end) as thevalue," + "            case"
				+ "                when t.transaction_category_cid in (4709, 4710, 4711, 4712, 4713)"
				+ "                then t.customer_amount - t.customer_tax_amount" + "                else 0"
				+ "            end as customer_fee ," + "            case"
				+ "                when t.transaction_category_cid = 4701 and i.line_number =1"
				+ "                then t.fee_total_amount - t.fee_total_tax" + "                else 0"
				+ "            end as fee_for_purchase_trans ,"
				+ "            nvl(i.merchant_service_fee_total + i.merchant_service_fee_adjust - i.merchant_service_fee_total_tax - i.merchant_service_fee_adj_tax,0) as merchant_service_fee,"
				+ "            case" + "                when t.transaction_category_cid = 4701" + "                then"
				+ "                    case"
				+ "                        when i.merchant_price_type_cid = 11301 and ip.is_fuel='Y'"
				+ "                        then round( i.original_value - (i.original_value * i.tax_rate/(i.tax_rate + 100)) , 4)"
				+ "                        else i.merchant_value - i.merchant_tax_amount" + "                    end"
				+ "                else t.merchant_amount - t.merchant_tax_amount"
				+ "            end as merchant_reimbursement" + "        from" + "            transactions t"
				+ "        inner join m_customers cust                 on t.customer_mid = cust.customer_mid"
				+ "        inner join m_clients c                      on c.client_mid = cust.client_mid"
				+ "        inner join trans_report_categories_view trc on t.transaction_type_oid = trc.transaction_type_oid and trc.client_mid = c.client_mid"
				+ "        inner join report_categories rc             on rc.report_category_oid = trc.report_category_oid and upper(rc.short_description) = upper( 'R4 Trans' )"
				+ "        inner join currencies curr                  on curr.currency_oid = c.currency_oid"
				+ "        left join transaction_line_items i          on i.transaction_oid = t.transaction_oid"
				+ "        left join m_locations l                     on l.location_mid = t.location_mid"
				+ "        left join transaction_types tt              on tt.transaction_type_oid = t.transaction_type_oid"
				+ "        left join product_translations ipt          on i.product_oid = ipt.product_oid and ipt.external_code_client = 'BP AU SAP'"
				+ "        left join products ip                       on ip.product_oid = i.product_oid"
				+ "        left join product_group_data ipdp           on ipdp.product_oid = i.product_oid"
				+ "        left join transaction_rebates tr            on tr.transaction_oid = t.transaction_oid"
				+ "        left join m_customers trcust                on tr.orig_cust_mid = trcust.customer_mid"
				+ "        left join trans_rebate_breakdowns trb       on trb.transaction_rebate_oid = tr.transaction_rebate_oid"
				+ "        left join m_locations trl                   on trl.location_mid = trb.location_mid"
				+ "        left join product_translations trpt         on trb.product_oid = trpt.product_oid and trpt.external_code_client = 'BP AU SAP'"
				+ "        left join products trp                      on trp.product_oid = trb.product_oid"
				+ "        left join product_group_data trpdp          on trpdp.product_oid = trb.product_oid"
				+ "        where"
				+ "            c.client_mid = '1' and t.processed_at >= (c.month_end_2_on + 1) and t.processed_at < (c.month_end_1_on + 1)"
				+ "    )" + "select" + "    period_end_date," + "    loc_ext_ref," + "    cust_ext_ref,"
				+ "    external_product_code," + "    trim(to_char(sum(quantity),'999999999990.99')) as quantity,"
				+ "    trim(to_char(sum(thevalue),'999999999990.99')) as thevalue,"
				+ "    trim(to_char(sum(customer_fee),'999999999990.99')) as customer_fee,"
				+ "    trim(to_char(sum(merchant_service_fee), '999999999990.99')) as merchant_service_fee,"
				+ "    trim(to_char(sum(merchant_reimbursement),'999999999990.99')) as merchant_reimbursement,"
				+ "    currency_code" + "   from" + "    (" + "        select" + "            period_end_date,"
				+ "            loc_ext_ref," + "            cust_ext_ref," + "            external_product_code,"
				+ "            quantity ," + "            thevalue," + "            customer_fee,"
				+ "            merchant_service_fee," + "            merchant_reimbursement,"
				+ "            currency_code" + "        from" + "            trans_data" + "        union all"
				+ "        select" + "            period_end_date," + "            loc_ext_ref,"
				+ "            cust_ext_ref," + "            null as external_product_code,"
				+ "            0 as quantity ," + "            fee_for_purchase_trans as thevalue ,"
				+ "            fee_for_purchase_trans as customer_fee ," + "            0 as merchant_service_fee ,"
				+ "            0 as merchant_reimbursement ," + "            currency_code" + "        from"
				+ "            trans_data" + "        where"
				+ "            transaction_category_cid = 4701 and line_number = 1 and fee_for_purchase_trans <> 0"
				+ "    )" + "     group by" + "    period_end_date," + "    cust_ext_ref," + "    loc_ext_ref,"
				+ "    external_product_code," + "    currency_code";

		return connectDBAndGetDBEntireRowValues(getValuesForCardSalesAggregate,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));

	}

	// Added by Sasi 27-08-2019
	public Map<String, String> getCustomerTransactions(String refNo) {
		String cusTransaDetailsQuery = "Select card_no,effective_at,posted_at,customer_amount,customer_rebate_total,merchant_amount,c.customer_no,l.location_no,m.merchant_no,acc.account_no from transactions t inner join m_customers c on c.customer_mid=t.customer_mid inner join m_locations l on l.location_mid=t.location_mid inner join m_merchants m on m.merchant_mid=t.merchant_mid inner join accounts acc on acc.customer_mid=t.customer_mid where reference='"
				+ refNo + "' order by POSTED_AT desc";
		Map<String, String> cusTransDetails = connectDBAndGetDBEntireRowValues(cusTransaDetailsQuery,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		System.out.println("cusTransaDetails : " + cusTransDetails);
		return cusTransDetails;
	}

	public void validateTheTextRetrievedFromPdfFile(String textFromPdfFile, String expectedValue) {

		if ((textFromPdfFile.toString()).contains(expectedValue)) {

			logPass("Pdf File contains the expected text");
		} else {
			logFail("Pdf File does not contains the expected text");
		}

	}

	// Prakalpha -->09/30/2019
	public Map<String, String> getSuspendedTransactionDetails(String refNo) {

		String getSuspendedCard = "select card_no,batch_no from pos_transactions where reference = '" + refNo + "'";
		Map<String, String> suspendedCardNo = connectDBAndGetDBEntireRowValues(getSuspendedCard,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		System.out.println("getSuspendedCard:: " + suspendedCardNo);
		return suspendedCardNo;
	}

	// Prakalpha -->10/08/2019
	public String getDeclinedApplicationNo() {
		String getDeclinedNo, getDeclinedAccNo, clientName, clientCountry;
		clientName = PropUtils.getPropValue(configProp, "clientName");
		clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		getDeclinedNo = "select a.application_no from application_status ast inner join applications a on a.application_status_oid=ast.application_status_oid where ast.DESCRIPTION LIKE '%declined%' and ast.client_mid =(Select client_mid from m_clients where name ='"
				+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountry) + "') ";
		getDeclinedAccNo = connectDBAndGetValue(getDeclinedNo, PropUtils.getPropValue(configProp, "sqlODSServerName"));
		System.out.println("Declined Account No:" + getDeclinedAccNo);
		return getDeclinedAccNo;
	}

	/*
	 * Prakalpha -->10/09/2019 Get Reimbursement Amount for Merchant
	 */
	public String getReimbursementAmountForMerchant(String merchantNo, String jobType) {
		String getReimbursementAmt;
		String getReimbursementAmount;
		String clientName;
		String clientCountry;
		String reportDate = "";
		clientName = PropUtils.getPropValue(configProp, "clientName");
		clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		if (jobType.equalsIgnoreCase("DayEnd")) {
			reportDate = getProcessingDateWithExpectedFormat("dd/MM/yy");
		} else if (jobType.equalsIgnoreCase("MonthEnd")) {
			reportDate = getPreviousProcessingDate("dd/MM/yy");
		}
		getReimbursementAmt = "Select merchant_amount,m.merchant_no from transactions inner join m_locations on transactions.location_mid= m_locations.location_mid inner join m_merchants m on m.merchant_mid=transactions.merchant_mid where m_locations.client_mid=(Select client_mid from m_clients where name ='"
				+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountry)
				+ "') and transactions.last_updated_by = 'Merc Settlement Non Purchase'and m.merchant_no='" + merchantNo
				+ "' and reference like '%MercReimb-" + reportDate + "-%'";
		getReimbursementAmount = connectDBAndGetValue(getReimbursementAmt,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		System.out.println("Declined Account No:" + getReimbursementAmount);
		return getReimbursementAmount;
	}

	public String getPreviousProcessingDate(String formatNeeded) {
		String clientName;
		String clientCountry;
		String previousIFCSDate = "";
		clientName = PropUtils.getPropValue(configProp, "clientName");
		clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		try {
			String processingDate = getCurrentIFCSDateFromDB(clientName + clientCountry);
			SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			Calendar cal = Calendar.getInstance();
			cal.setTime(format1.parse(processingDate));
			// manipulate date
			cal.add(Calendar.DATE, -1);
			Date currentDateMinusOne = cal.getTime();
			SimpleDateFormat formatter = new SimpleDateFormat(formatNeeded);
			previousIFCSDate = formatter.format(currentDateMinusOne).toString().toUpperCase();
			System.out.println("Previous Date::" + previousIFCSDate);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return previousIFCSDate;
	}

	public String getProcessingDateWithExpectedFormat(String formatNeeded) {
		String clientName;
		String clientCountry;
		String IFCSDate = "";
		clientName = PropUtils.getPropValue(configProp, "clientName");
		clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		try {
			String processingDate = getCurrentIFCSDateFromDB(clientName + clientCountry);
			SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			Calendar cal = Calendar.getInstance();
			cal.setTime(format1.parse(processingDate));
			Date currentDate = cal.getTime();
			SimpleDateFormat formatter = new SimpleDateFormat(formatNeeded);
			IFCSDate = formatter.format(currentDate);

			System.out.println("Current Date::" + IFCSDate);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return IFCSDate;
	}

	// Prakalpha -->10/11/2019
	public String getDirectDebitAmountForCustomer(String cusNo) {
		String debitAmount = "select customer_amount from transactions inner join m_customers c on c.customer_mid=transactions.customer_mid where c.customer_no='"
				+ cusNo + "' and  transactions.posted_by like'%Direct Debit%' order by transactions.last_updated_at";
		String debitAmountForCustomer = connectDBAndGetValue(debitAmount,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		double directDebit = Double.valueOf(debitAmountForCustomer);
		directDebit = Math.abs(directDebit);
		String debitCus = String.valueOf(directDebit);
		return debitCus;
	}

	// Sowmiya

	public String getApprovedCustomerNumberFromDB(String applicationStatus) {
		String clientName, clientCountry;
		clientName = PropUtils.getPropValue(configProp, "clientName");

		clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		String approvedCustomer = "select customer_no from applications where application_status_oid=(select application_status_oid from application_status where description='"
				+ applicationStatus + "' and client_mid=(select Client_mid from m_clients where name ='"
				+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountry)
				+ "'))  order by last_updated_at Desc";

		return connectDBAndGetValue(approvedCustomer, PropUtils.getPropValue(configProp, "sqlODSServerName"));

	}

	// Naveen
	public String validateCreditAmountForAdjustmentType(String desc, String ref) {
		String clientName, clientCountry;
		clientName = PropUtils.getPropValue(configProp, "clientName");
		clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		String creditAmount = "select customer_amount from transactions where transaction_oid in (select transaction_oid from trans_adjustment_items where adjustment_type_oid = (select adjustment_type_oid from adjustment_types where description = '"
				+ desc + "' and client_mid =(Select client_mid from m_clients where name ='"
				+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountry) + "'))) and reference ='" + ref
				+ "' ";
		String creditAmountForClient = connectDBAndGetValue(creditAmount,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));

		return creditAmountForClient;
	}

	/*
	 * Prakalpha-10/15/2019 converting CSV file to XLS file by default worksheet
	 * change to "sheet1"
	 */
	public String convertCsvToXLS(String fileName) {
		HSSFWorkbook workBook = new HSSFWorkbook();
		String localPath = System.getProperty("user.home") + "\\Documents\\";
		String csvFileAddress = localPath + fileName + ".csv"; // csv file address
		String xlsFileAddress = localPath + fileName + ".xls"; // xls file address
		HSSFSheet sheet = workBook.createSheet("sheet1");
		try {

			String currentLine = null;
			int RowNum = 0;

			BufferedReader br = new BufferedReader(new FileReader(csvFileAddress));

			while ((currentLine = br.readLine()) != null) {

				String str[] = currentLine.split(",");

				RowNum++;
				HSSFRow currentRow = sheet.createRow(RowNum);
				for (int i = 0; i < str.length; i++) {
					System.out.println("str[] :: " + str[i]);
					currentRow.createCell(i).setCellValue(str[i]);
				}
			}

			FileOutputStream fileOutputStream = new FileOutputStream(xlsFileAddress);
			workBook.write(fileOutputStream);
			fileOutputStream.close();
			System.out.println("Done");

		} catch (Exception ex) {
			System.out.println(ex.getMessage() + "Exception in try");
		}
		String[] splittedFileName = xlsFileAddress.split("\\\\");
		String xlsFile = splittedFileName[splittedFileName.length - 1];
		System.out.println("xlsFileAddress::" + xlsFile);

		return xlsFile;

	}

	/*
	 * Prakalpha-10/15/2019 converting CSV file to XLS file by default worksheet
	 * change to "sheet1"
	 */
	public String convertCsvToXLSWithFilepath(String fileName, String filePath) {
		HSSFWorkbook workBook = new HSSFWorkbook();
		String csvFileAddress = filePath + fileName + ".csv"; // csv file address
		String xlsFileAddress = filePath + fileName + ".xls"; // xls file address
		HSSFSheet sheet = workBook.createSheet("sheet1");
		try {
			String currentLine = null;
			int RowNum = 0;
			BufferedReader br = new BufferedReader(new FileReader(csvFileAddress));
			while ((currentLine = br.readLine()) != null) {
				String str[] = currentLine.split(",");
				HSSFRow currentRow = sheet.createRow(RowNum);
				for (int i = 0; i < str.length; i++) {
					System.out.println("str[] :: " + str[i]);
					currentRow.createCell(i).setCellValue(str[i]);
				}
				RowNum++;
			}
			FileOutputStream fileOutputStream = new FileOutputStream(xlsFileAddress);
			workBook.write(fileOutputStream);
			fileOutputStream.close();
			System.out.println("Done");
		} catch (Exception ex) {
			System.out.println(ex.getMessage() + "Exception in try");
		}
		return xlsFileAddress;
	}

	/*
	 * Prakalpha -->10/15/2019 Get Audit Action for a Customer
	 */
	public String getAuditActionForCustomer(String cusNo, String userName) {
		String clientName, clientCountry;
		clientName = PropUtils.getPropValue(configProp, "clientName");
		clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		String auditDetails = "select audit_action from audit_details ad inner join m_customers mc on mc.customer_mid= ad.customer_mid where mc.customer_no='"
				+ cusNo + "' and updated_by='" + userName
				+ "' and mc.client_mid=(select Client_mid from m_clients where name ='"
				+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountry) + "')";
		String auditActionforcusNo = connectDBAndGetValue(auditDetails,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));

		return auditActionforcusNo;
	}

	/*
	 * Prakalpha-->10/16/2019 Get A Audit Action for a Application
	 */
	public String getAuditActionForApplication(String applicationNo, String userName) {
		String clientName, clientCountry;
		clientName = PropUtils.getPropValue(configProp, "clientName");
		clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		String auditDetails = "select audit_action from audit_details ad inner join applications a on a.application_oid= ad.application_oid where a.application_no='"
				+ applicationNo + "'  and updated_by='" + userName
				+ "' and a.client_mid=(Select client_mid from m_clients where name ='"
				+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountry) + "')";
		String auditActionForAppNo = connectDBAndGetValue(auditDetails,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));

		return auditActionForAppNo;
	}

	/*
	 * Prakalpha -->10/16/2019 Get a audit Action for a Card
	 */
	public String getAuditActionForCard(String CardNo, String userName) {
		String clientName, clientCountry;
		clientName = PropUtils.getPropValue(configProp, "clientName");
		clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		String auditDetails = "select audit_action from audit_details ad inner join cards c on c.card_oid= ad.card_oid inner join m_customers mc on mc.customer_mid= c.customer_mid where c.card_no='"
				+ CardNo + "' and updated_by='" + userName
				+ "' and mc.client_mid=(Select client_mid from m_clients where name ='"
				+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountry) + "')";
		String auditActionForCardNo = connectDBAndGetValue(auditDetails,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));

		return auditActionForCardNo;
	}

	/*
	 * Prakalpha -->10/16/2019 Get a audit Action for a Account
	 */
	public String getAuditActionForAccount(String AccountNo, String userName) {
		String clientName, clientCountry;
		clientName = PropUtils.getPropValue(configProp, "clientName");
		clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		String auditDetails = "select audit_action from audit_details ad inner join accounts a on a.account_oid= ad.account_oid inner join m_customers mc on mc.customer_mid= a.customer_mid where a.account_no='"
				+ AccountNo + "' and updated_by='" + userName
				+ "' and mc.client_mid=(Select client_mid from m_clients where name ='"
				+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountry) + "')";
		String auditActionForCardNo = connectDBAndGetValue(auditDetails,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));

		return auditActionForCardNo;
	}
	/*
	 * Praklaph -->10/16/2019 Get client excessive Transaction value
	 */

	public String getClientTransactionValue(String refNo) {
		String getTransactionValue = "Select customer_amount+customer_rebate_total from transactions t where reference='"
				+ refNo + "' order by POSTED_AT desc";
		String transactionValue = connectDBAndGetValue(getTransactionValue,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));

		return transactionValue;
	}

	/*
	 * Prakalpha-->10/17/2019 get card Status description
	 */
	public String getCardStatusDesription(String cardNo) {
		String getCardStatus = "select description from card_status where card_status_oid = (select card_status_oid from cards where card_no='"
				+ cardNo + "')";
		String cardStatusDescription = connectDBAndGetValue(getCardStatus,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));

		return cardStatusDescription;
	}

	/*
	 * Prakalpha-->10/17/2019 get duty Summary Merchant No
	 */
	public String getDutySummaryMerchantNo(String previousDate) {

		String getMerchantNo = "select merchant_no from m_merchants where merchant_mid in (select merchant_mid from Transactions t inner join m_customers mc on mc.customer_mid=t.customer_mid where t.processed_at like '"
				+ previousDate
				+ "%' and mc.customer_no in (select customer_no from applications where application_type_oid = (select application_type_oid from application_types where description='Duty Free Customer')))";
		String dutySummaryMerchantNo = connectDBAndGetValue(getMerchantNo,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));

		return dutySummaryMerchantNo;
	}

	/*
	 * Prakalpha-->10/18/2019 get CardNo from merchant dutyFreeCustomer
	 */
	public String getDutyExemptionCardNo(String previousDate) {
		String getCardNo = "select card_no from cards where card_oid in (select card_oid from Transactions t inner join m_customers mc on mc.customer_mid=t.customer_mid where t.processed_at like '"
				+ previousDate
				+ "%' and mc.customer_no in (select customer_no from applications where application_type_oid = (select application_type_oid from application_types where description='Duty Free Customer')))";
		String dutyExemptionCardNo = connectDBAndGetValue(getCardNo,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));

		return dutyExemptionCardNo;
	}

	/*
	 * Prakalpha -->10/23/2019 Get a audit Action for a Account
	 */
	public String getAuditActionForMerchant(String merchantNo, String userName) {
		String clientName, clientCountry;
		clientName = PropUtils.getPropValue(configProp, "clientName");
		clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		String auditDetails = "select audit_action from audit_details ad inner join m_merchants m on m.merchant_mid= ad.merchant_mid where m.merchant_no='"
				+ merchantNo + "' and updated_by='" + userName
				+ "' and m.client_mid=(Select client_mid from m_clients where name ='"
				+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountry) + "')";
		String auditActionForMerchantNo = connectDBAndGetValue(auditDetails,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));

		return auditActionForMerchantNo;
	}

	public void verifyValidationMessage() {
		logInfo("Validation Message :" + getText(validationResult));
	}

	public String batchJobExecution(String JobSchedulers, String Jobs, String JobSteps) {
		sleep(3);
		WebElement JobSchedulerselement = driver.findElement(By.xpath(
				"//div[@class='JFALSeparator_1']//div[contains(text(),'Job') and contains(text(),'Schedulers')]//preceding::div[@class='FALTableCellEditor_StrikeThruField JTextComponent']//input[@submittedvalue='"
						+ JobSchedulers + "']"));
		isDisplayedThenClick(JobSchedulerselement, JobSchedulers);
		sleep(3);
		WebElement Jobselement = driver.findElement(By.xpath(
				"//div[@class='JFALSeparator_1']//div[contains(text(),'Jobs')]//preceding::div[@class='FALTableCellEditor_StrikeThruField JTextComponent']//input[@submittedvalue='"
						+ Jobs + "']"));
		isDisplayedThenClick(Jobselement, Jobs);
		sleep(3);
		WebElement JobStepselement = driver.findElement(By.xpath(
				"//div[@class='JFALSeparator_1']//div[contains(text(),'Job') and contains(text(),'Steps')]//preceding::div[@class='FALTableCellEditor_StrikeThruField JTextComponent']//input[@submittedvalue='"
						+ JobSteps + "']"));
		isDisplayedThenClick(JobStepselement, JobSteps);
		sleep(3);
		isDisplayedThenClick(executejob, "RunJob");
		verifyValidationResult("Job Executed Successfully");

		return null;
	}

	public String getUniqReferenceNumber() {
		SimpleDateFormat formatter = new SimpleDateFormat("MMDDHHmmss");
		Date date = new Date();
		String dd = formatter.format(date);
		return dd;
	}

	public String getTime() {
		SimpleDateFormat formatter = new SimpleDateFormat("HH:mm:ss");
		Date date = new Date();
		String dd = formatter.format(date);
		return dd;
	}

	public void clientBatchJobExecution(String JobSchedulers) {
		List<WebElement> list;
		isDisplayedThenClick(interfaces, "interfaces");
		sleep(3);
		isDisplayedThenClick(incominginterfaces, "incoming interfaces");
		sleep(3);
		validateHeaderLabel("Incoming Interfaces");
		try {
			int colNum = SeleniumWrappers.getColumnNoForColumnHeader("Id", cardsTableHeaders);
			list = driver.findElements(By.xpath(
					"//div[@class='JFALSeparator']//div[contains(text(),'Interface') and contains(text(),'Files')]//preceding::div[@class='JFALCompControlPanel'][1]//div[@class='FALTableCellEditor_StrikeThruField JTextComponent']"));
			int size = SeleniumWrappers.getTotalNumberOfRows(list, driver);
			System.out.println("Size" + size);
			for (int row = 0; row < size; row++) {
				WebElement JobSchedulerselement = driver.findElement(By.xpath(
						"//div[@class='JFALSeparator']//div[contains(text(),'Interface') and contains(text(),'Files')]//preceding::div[@class='JFALCompControlPanel'][1]//div[@class='FALTableCellEditor_StrikeThruField JTextComponent'][contains(@id,'"
								+ row + "_" + colNum + "')]//input"));
				String actualText = JobSchedulerselement.getAttribute("submittedvalue");
				// System.out.println("Actual text " + actualText);
				if (actualText.contains(JobSchedulers)) {
					logPass(actualText + " and " + JobSchedulers + "are same and Validated");
					// System.out.println("Actual text " + actualText);
					// WebElement JobSchedulerselement =
					// driver.findElement(By.xpath("//div[@class='FALTableCellEditor_StrikeThruField
					// JTextComponent']//input[@value='"+JobSchedulers+"']"));
					isDisplayedThenClick(JobSchedulerselement, JobSchedulers);
					sleep(3);
					isDisplayedThenClick(executejob, "RunJob");
					verifyValidationResult("File Processed successfully");
				}
			}
		} catch (Exception e) {
			e.getMessage();
		}
	}

	public String clientOutgoingBatchJobExecution(String JobSchedulers) {
		isDisplayedThenClick(interfaces, "interfaces");
		sleep(3);
		isDisplayedThenClick(outgoinginterfaces, "Outgoing interfaces");
		sleep(3);

		WebElement JobSchedulerselement = driver.findElement(
				By.xpath("//div[@class='FALTableCellEditor_StrikeThruField JTextComponent']//input[@value='"
						+ JobSchedulers + "']"));
		isDisplayedThenClick(JobSchedulerselement, JobSchedulers);
		sleep(3);
		isDisplayedThenClick(executejob, "RunJob");
		verifyValidationResult("File Processed successfully");
		return null;
	}

	public String getActiveAccountNumber(String clientNameInProp) {
		CommonInterfacePage commonInterfacePage = new CommonInterfacePage(driver, test);
		String CustomerNum = commonInterfacePage.funcFetchPaymentCustomerNoFromIFCSDB(configProp, clientNameInProp);
		return CustomerNum;
	}

	public String getAccAvailableBalance(Properties properties, String CustomerNum) {
		String availableBalance;
		logInfo(CustomerNum);
		getDBDetailsFromProperties = PropUtils.getPropValue(properties, "sqlODSServerName");

		String availableBalanceQuery = "select calculated_available_balance from calc_avail_bal_account_view "
				+ "where customer_mid=(select customer_mid from m_customers where customer_no='" + CustomerNum + "')";
		System.out.println(availableBalanceQuery);
		availableBalance = connectDBAndGetValue(availableBalanceQuery, getDBDetailsFromProperties);

		System.out.println("----- Account Balance -------" + availableBalance);
		logInfo(availableBalance);

		return availableBalance;
	}

	public void validatepaymentvalue(String PaymentAmount, float accBalAfter, float accBalBefore, String PaymentFee) {
		DecimalFormat decimalFormat = new DecimalFormat("#.##");
		logInfo("Availlable balance Before Payment:" + accBalBefore);
		logInfo("Availlable balance After Payment:" + accBalAfter);
		logInfo("Posted Payment Amount:" + PaymentAmount);
		logInfo("Posted Payment Fee Amount:" + PaymentFee);
		String postedPaymentwithwithoutfee = decimalFormat.format(accBalAfter - accBalBefore);
		logInfo("Posted Total Payment with substract paymentFee:" + postedPaymentwithwithoutfee);
		int postedPayment = Math.round(Float.parseFloat(postedPaymentwithwithoutfee) + Float.parseFloat(PaymentFee));
		String Payment = decimalFormat.format(postedPayment);
		logInfo("Posted Total Payment:" + Payment);
		if (PaymentAmount.equals(Payment)) {
			logPass("payments Sucessfully posted");
		} else {
			logFail("payments are not Sucessfully posted");
		}
	}

	public void validateDishonourvalue(String PaymentAmount, float accBalAfter, float accBalBefore, String PaymentFee) {
		DecimalFormat decimalFormat = new DecimalFormat("#.##");
		logInfo("Availlable balance Before Payment:" + accBalBefore);
		logInfo("Availlable balance After Payment:" + accBalAfter);
		logInfo("Posted Dishonour Payment Amount:" + PaymentAmount);
		logInfo("Posted Dishonour Payment Fee Amount:" + PaymentFee);
		String postedPaymentwithwithoutfee = decimalFormat.format(accBalBefore - accBalAfter);
		logInfo("Posted Total Dishonour Payment with substract paymentFee:" + postedPaymentwithwithoutfee);
		int postedPayment = Math.round(Float.parseFloat(postedPaymentwithwithoutfee) - Float.parseFloat(PaymentFee));
		String Payment = decimalFormat.format(postedPayment);
		logInfo("Posted Total DishonourPayment:" + Payment);
		if (PaymentAmount.equals(Payment)) {
			logPass("Dishonour payments Sucessfully posted");
		} else {
			logFail("Dishonour payments are not Sucessfully posted");
		}

	}

	public String getBPPrepaidCustomerNo() {
		String queryToGetCustomer;
		String customerNo = "";
		queryToGetCustomer = "Select distinct mcu.customer_no from m_customers mcu \r\n"
				+ "inner join card_programs cp on mcu.card_program_oid = cp.card_program_oid \r\n"
				+ "where cp.description='BP PrePay Cards' and Rownum <=1";
		customerNo = connectDBAndGetValue(queryToGetCustomer, PropUtils.getPropValue(configProp, "sqlODSServerName"));
		return customerNo;
	}

	public List<String> getExcelDataInList(String filePath, String sheetName, int colNumber) {
		List<String> data = new ArrayList<>();
		FileInputStream fis = null;
		HSSFWorkbook workbook = null;
		HSSFSheet sheet = null;
		try {
			fis = new FileInputStream(filePath);
			workbook = new HSSFWorkbook(fis);
			// sheet = workbook.getSheet(sheetName);
			sheet = workbook.getSheetAt(0);
		} catch (FileNotFoundException e) {
			logFail("Please correct the specified path  : " + filePath);
			e.printStackTrace();
		} catch (IOException e) {
			logFail("Please check the I/O of the file ");
			e.printStackTrace();
		} finally {
			if (fis != null) {
				try {
					fis.close();
				} catch (IOException e) {
					System.out.println("Not able to close fis object");
				}
			}
			if (workbook != null) {
				try {
					workbook.close();
				} catch (IOException e) {
					System.out.println("Not able to close workbook object");
				}
			}
		}
		Iterator<Row> rowIter = sheet.rowIterator();
		while (rowIter.hasNext()) {
			HSSFRow myRow = (HSSFRow) rowIter.next();
			HSSFCell cell = myRow.getCell(colNumber);
			data.add(cell.getStringCellValue());
		}
		Iterator<String> iterator = data.iterator();
		while (iterator.hasNext()) {
			System.out.println(iterator.next());
		}
		return data;
	}

	/*
	 * Added by Davu - 06/04/2020
	 */

	public List<String> getExcelDataInListByColName(String filePath, String colName) {
		List<String> data = new ArrayList<>();
		FileInputStream fis = null;
		HSSFWorkbook workbook = null;
		HSSFSheet sheet = null;
		int colNumber = 0;

		try {
			fis = new FileInputStream(filePath);
			workbook = new HSSFWorkbook(fis);
			// sheet = workbook.getSheet(sheetName);
			sheet = workbook.getSheetAt(0);
		} catch (FileNotFoundException e) {
			logFail("Please correct the specified path  : " + filePath);
			e.printStackTrace();
		} catch (IOException e) {
			logFail("Please check the I/O of the file ");
			e.printStackTrace();
		} finally {
			if (fis != null) {
				try {
					fis.close();
				} catch (IOException e) {
					System.out.println("Not able to close fis object");
				}
			}
			if (workbook != null) {
				try {
					workbook.close();
				} catch (IOException e) {
					System.out.println("Not able to close workbook object");
				}
			}
		}

		HSSFRow myRow = sheet.getRow(0);

		for (int i = 0; i < myRow.getLastCellNum(); i++) {
			if (myRow.getCell(i).getStringCellValue().trim().equals(colName)) {
				colNumber = i;
			}
		}

		Iterator<Row> rowIter = sheet.rowIterator();
		while (rowIter.hasNext()) {
			myRow = (HSSFRow) rowIter.next();
			HSSFCell cell = myRow.getCell(colNumber);
			data.add(cell.getStringCellValue());
		}
		Iterator<String> iterator = data.iterator();
		while (iterator.hasNext()) {
			System.out.println(iterator.next());
		}
		return data;
	}

	public void deleteFileFromSpecificLocation(String filePath) {
		File file = new File(filePath);
		if (file.delete()) {
			logInfo("File deleted successfully");
		} else {
			logInfo("Failed to delete the file");
		}
	}

	/*
	 * Verify the cell value based on description in Application Types
	 */
	public void verifyAccountStatusForPrepayDescription(String keyColumn, String keyValue, String expectedCol) {
		String actValue = getTableValuesWithKey(keyColumn, keyValue, expectedCol);
		if (actValue.equals("ACTIVE")) {
			logPass("Account status for prepay Description is displayed as expected");
		} else {
			logFail("Account status for prepay Description is not correct");
		}
	}

	// raxsana

	public String getCustomerNumberForConfiguredReports(String clientName, String clientCountry) {

		String cusTransaDetailsQuery = "Select customer_no from m_customers where customer_mid in (Select member_oid from report_assignments where report_type_oid in (Select report_type_oid from report_types where client_mid in (Select client_mid from m_clients where name ='"
				+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountry)
				+ "') and description in ('Card Transaction Report','Fleet Control Tax Invoice Detail','Management Transaction Card Report')) group by member_oid having count(*) = 3)";
		String cusTransDetails = connectDBAndGetValue(cusTransaDetailsQuery,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		System.out.println("cusTransaDetails : " + cusTransDetails);
		return cusTransDetails;
	}

	public String getLocationNumberForConfiguredReports(String clientName, String clientCountry) {

		String cusTransaDetailsQuery = "Select location_no from m_locations where location_mid in (Select member_oid from report_assignments ra inner join frequencies f on ra.frequency_oid = f.frequency_oid where report_type_oid in (Select report_type_oid from report_types where client_mid in (Select client_mid from m_clients where name ='"
				+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountry)
				+ "') and description in ('Merchant RCTI','Merchant Statement')) and f.description = 'Report End of Month' group by member_oid having count(*) = 2) order by last_updated_at desc";
		String cusTransDetails = connectDBAndGetValue(cusTransaDetailsQuery,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		System.out.println("cusTransaDetails : " + cusTransDetails);
		return cusTransDetails;
	}

	public Map<String, String> getMerchantStatementAmount(String locationNo, String changedDateFormat) {
		/*
		 * String merchantTransactionOid =
		 * "Select transaction_oid from transactions t inner join m_locations l on l.location_mid=t.location_mid where l.location_no='"
		 * +locationNo+"' order by t.posted_at desc "; String mercTransactionOid =
		 * connectDBAndGetValue(merchantTransactionOid,
		 * PropUtils.getPropValue(configProp, "sqlODSServerName"));
		 */
		// String cusTransaDetailsQuery = "select
		// original_value,merchant_value,merchant_service_fee_total,merchant_service_fee_adjust,merchant_reimbuse_adjust
		// from transaction_line_items where transaction_oid='320807419'";
		// "+mercTransactionOid+"'";
		String cusTransaDetailsQuery = "select sum(original_value),sum(merchant_value),sum(merchant_service_fee_total),sum(merchant_service_fee_adjust),sum(merchant_reimbuse_adjust) from transaction_line_items where transaction_oid in (Select distinct transaction_oid from transactions t inner join m_locations l on l.location_mid = t.location_mid where l.location_no = '"
				+ locationNo + "' and processed_at like '%" + changedDateFormat + "%' )";
		Map<String, String> mercTransDetails = connectDBAndGetDBEntireRowValues(cusTransaDetailsQuery,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		System.out.println("mercTransaDetails : " + mercTransDetails);
		return mercTransDetails;

	}

	public String getCardNumberForCustomerReports(String cusNumber, String ifcsDate) {
		String custTransDetails1 = "select card_no from transactions where processed_at like '%" + ifcsDate
				+ "%' and customer_mid in (select customer_mid from m_customers where customer_no='" + cusNumber
				+ "') order by last_updated_at desc";
		Map<String, String> custTransDetails = connectDBAndGetDBEntireRowValues(custTransDetails1,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		String value1 = "";
		int c = 0;
		for (String keyVal : custTransDetails.keySet()) {
			value1 = value1 + "'" + custTransDetails.get(keyVal) + "'";
			c++;
			if (!(c == custTransDetails.keySet().size())) {
				value1 = value1 + ",";
			}
		}
		System.out.println("Valuess::" + value1);
		String value = "select sum(customer_amount)  from transactions where card_no in (" + value1
				+ ") and processed_at like '%" + ifcsDate + "%' order by POSTED_AT desc";
		String cusTransDetails = connectDBAndGetValue(value, PropUtils.getPropValue(configProp, "sqlODSServerName"));
		return cusTransDetails;
	}

	public Map<String, String> getCardNumberForCardTransactionReport(String cusNumber, String ifcsDate) {
		Map<String, String> val = new HashMap<String, String>();
		String custTransDetails = "Select t.card_no from transactions t inner join m_customers mc on t.customer_mid = mc.customer_mid where mc.customer_no = '"
				+ cusNumber + "' and t.processed_at like '%" + ifcsDate + "%' order by t.last_updated_by desc";
		Map<String, String> custTransDetails1 = connectDBAndGetDBEntireRowValues(custTransDetails,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		for (String keyVal : custTransDetails1.keySet()) {
			String values = "select sum(mtd_value) from cost_centre_card_totals  where card_oid in (select card_oid from cards where card_no = '"
					+ custTransDetails1.get(keyVal) + "')";
			String cusTransDetails1 = connectDBAndGetValue(values,
					PropUtils.getPropValue(configProp, "sqlODSServerName"));
			val.put(custTransDetails1.get(keyVal), cusTransDetails1);
		}
		System.out.println("array values::" + val);
		return val;
	}

	public void validateOrderedCardNumberInIFCS(String cardNumber) {
		try {
			IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
			IFCSHomePage.gotoSearchAndClickCards();
			sleep(3);
			clearingAllTextBoxes(textBoxes);
			sleep(3);
			enterValueInTextBox("Filter By", "Card Number", cardNumber);
			searchListTorch();
			sleep(5);
			verifyValidationResult("Record Read OK - Page Size 200 Rows");

			int colIndex = SeleniumWrappers.getColumnNoForColumnHeader("Card Number", cardsTableHeaders);
			WebElement cardElement = driver.findElement(
					By.xpath("//div[@class='FALTableCellEditor_StrikeThruField JTextComponent'][contains(@id,'_0_"
							+ colIndex + "')]//div[@class='htmlString']"));
			String cardNo = cardElement.getText();
			if (cardNo.equals(cardNumber)) {
				logPass("Ordered card(" + cardNumber + ") is present in IFCS");
			} else {
				logFail("Ordered card(" + cardNumber + ") is not present in IFCS");
			}
		} catch (Exception e) {
			e.getMessage();
		}
	}

	public void validateUpdatedValuesInIFCS(String cardNumber, String expectedValue, String cardType) {
		try {
			IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
			IFCSHomePage.gotoSearchAndClickCards();
			sleep(3);
			clearingAllTextBoxes(textBoxes);
			sleep(3);
			enterValueInTextBox("Filter By", "Card Number", cardNumber);
			searchListTorch();
			sleep(5);
			verifyValidationResult("Record Read OK - Page Size 200 Rows");
			if (cardType.equals("Driver")) {
				int colIndex = SeleniumWrappers.getColumnNoForColumnHeader("Driver Name", cardsTableHeaders);
				WebElement cardElement = driver.findElement(
						By.xpath("//div[@class='FALTableCellEditor_StrikeThruField JTextComponent'][contains(@id,'_0_"
								+ colIndex + "')]//div[@class='htmlString']"));
				String driverName = cardElement.getText();
				System.out.println("driverName::" + driverName);
				if (driverName.equalsIgnoreCase(expectedValue)) {
					logPass("Updated card(" + expectedValue + ") is present in IFCS");
				} else {
					logFail("Updated card(" + expectedValue + ") is not present in IFCS");
				}
			} else {
				int colIndex = SeleniumWrappers.getColumnNoForColumnHeader("License Plate", cardsTableHeaders);
				WebElement cardElement = driver.findElement(
						By.xpath("//div[@class='FALTableCellEditor_StrikeThruField JTextComponent'][contains(@id,'_0_"
								+ colIndex + "')]//div[@class='htmlString']"));
				String regNumber = cardElement.getText();
				System.out.println("regNum::" + regNumber);
				if (regNumber.equals(expectedValue)) {
					logPass("Updated card(" + expectedValue + ") is present in IFCS");
				} else {
					logFail("Updated card(" + expectedValue + ") is not present in IFCS");
				}
			}

		} catch (Exception e) {
			e.getMessage();
		}
	}

	public void validateBulkOrderedCardNumbersInIFCS(ArrayList<String> cardNos) {
		try {
			IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
			IFCSHomePage.gotoSearchAndClickCards();
			sleep(3);
			clearingAllTextBoxes(textBoxes);
			sleep(3);

			for (int i = 0; i < cardNos.size(); i++) {
				String cardNumber = cardNos.get(i);
				enterValueInTextBox("Filter By", "Card Number", cardNumber);
				searchListTorch();
				sleep(5);
				verifyValidationResult("Record Read OK - Page Size 200 Rows");

				int colIndex = SeleniumWrappers.getColumnNoForColumnHeader("Card Number", cardsTableHeaders);
				WebElement cardElement = driver.findElement(
						By.xpath("//div[@class='FALTableCellEditor_StrikeThruField JTextComponent'][contains(@id,'_0_"
								+ colIndex + "')]//div[@class='htmlString']"));
				String cardNo = cardElement.getText();
				if (cardNo.equals(cardNumber)) {
					logPass("Ordered card(" + cardNumber + ") is present in IFCS");
				} else {
					logFail("Ordered card(" + cardNumber + ") is not present in IFCS");
				}
			}
		} catch (Exception e) {
			e.getMessage();
		}
	}

	/*
	 * Get current UTC time
	 */
	public String getCurrentUTCTime() {
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("HH:mm");
		simpleDateFormat.setTimeZone(TimeZone.getTimeZone("UTC"));
		// SimpleDateFormat localDateFormat = new SimpleDateFormat("HH:mm");
		return simpleDateFormat.format(new Date());
	}

	public void rightClickAndSelectProfileFirstApplication() {

		WebElement cellElement;
		try {

			cellElement = driver.findElement(By.xpath(
					"//div[@class='FALTableCellEditor_StrikeThruCheckBox enabled'][1]//div[@class='htmlImage']"));
			rightClick(cellElement);
			Click(cellElement, "Table Cell");
			sleep(5);
			Click(selectProfile, "Select Profile");
		} catch (Exception e) {
			logFail(e.getMessage());
		}
	}

	public void validateTwoString(String DBValue, String fileValue, String message) {

		logInfo("First String Value:" + DBValue);
		logInfo("Second String Value:" + fileValue);
		System.out.println("DB" + DBValue);
		if (DBValue == null) {
			DBValue = "";
		}
		if (fileValue.isEmpty() && DBValue.equals("null")) {
			fileValue = "Empty";
			DBValue = "Empty";
		}
		System.out.println(fileValue + "DB" + DBValue);
		if (DBValue.equalsIgnoreCase(fileValue)) {
			logPass(message + " successfully updated " + DBValue);
		} else {
			logFail(message + " not updated " + DBValue);
		}

	}

	/*
	 * Get active card number which does not have private profile
	 */
	public String getActiveCardNumberFromDBWhichDoesNotHavePrivateProfile() {
		String clientName, clientCountry;
		String cardNumberDB;
		clientName = PropUtils.getPropValue(configProp, "clientName");
		clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		if (clientName.equals("BP")) {
			cardNumberDB = "Select c.card_no from cards c inner join card_status cs on c.card_status_oid = cs.card_status_oid where c.card_control_profile_oid in (Select card_control_profile_oid from card_control_profiles where card_program_oid in (Select card_program_oid from card_programs where client_mid = (Select client_mid from m_clients where name = '"
					+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountry).replaceAll("\"", "")
					+ "')))and cs.description like('%Normal Service%') OR cs.description like ('%NORMAL SERVICE%')";
		} else {
			cardNumberDB = "Select c.card_no from cards c inner join card_status cs on c.card_status_oid = cs.card_status_oid where c.card_control_profile_oid in (Select card_control_profile_oid from card_control_profiles where card_program_oid in (Select card_program_oid from card_programs where client_mid = (Select client_mid from m_clients where name = '"
					+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountry).replaceAll("\"", "")
					+ "')))and cs.description like('%Active%') OR cs.description like ('%ACTIVE%')";
		}
		String cardNumber = connectDBAndGetValue(cardNumberDB, PropUtils.getPropValue(configProp, "sqlODSServerName"));
		System.out.println("Card Number" + cardNumber);

		return cardNumber;
	}

	/*
	 * Validate the newly created private profile description
	 */
	public void validatePrivateProfileDescription(String description) {
		List<WebElement> descriptions = driver.findElements(By.xpath(Locator_IFCS.READ_PROFILE_DESCRIPTION));
		for (WebElement desc : descriptions) {
			String actDesc = desc.getText();
			if (description.equals(actDesc)) {
				logFail("Newly created private profile is available in Mantain Card controls as well");
			} else {
				logPass("Newly created private profile is not added to Maintain Card Controls");
			}
		}
	}

	public void writeDataInPropertyFile(String key, String value, String fileName) {
		Map<String, String> keyValues = new HashMap<String, String>();
		try {
			keyValues.put(key, value);
			PropUtils.creatingTempPropFile(fileName, keyValues);
		} catch (Exception e) {
			e.getMessage();
		}
	}
	// Prakalpha
	/*
	 * public String getActiveCardsFromDB(String clientCountry, String clientName) {
	 * 
	 * String getActivecards =
	 * "select card_no from Cards c inner join m_customers mc on mc.customer_mid = c.customer_mid inner join card_status cs on c.card_status_oid=cs.card_status_oid where cs.description like '%Normal Service' and mc.client_mid=(select Client_mid from m_clients where name ='"
	 * + PropUtils.getPropValue(configProp, clientName + "_" + clientCountry) +
	 * "')"; String cardNo = connectDBAndGetValue(getActivecards,
	 * PropUtils.getPropValue(configProp, "sqlODSServerName"));
	 * System.out.println("cardNo : " + cardNo); return cardNo; }
	 */

	public String getCustomerNoForOLSUser(String olsUser) {
		String olsUserName = PropUtils.getPropValue(configProp, olsUser);
		System.out.println("olsUserName::" + olsUserName);
		String getCustomerNo = "Select customer_no from internet_user_access iua inner join m_customers mc on iua.member_oid = mc.customer_mid where internet_user_oid = (Select internet_user_oid from internet_users where logon_id = '"
				+ olsUserName + "') and mc.customer_mid in (select customer_mid from CARDS)";
		String customerNo = connectDBAndGetValue(getCustomerNo, PropUtils.getPropValue(configProp, "sqlODSServerName"));
		System.out.println("customerNo : " + customerNo);
		return customerNo;
	}

	public String getCardNumberForOLSUser(String CustomerNo, String cardStatus) {
		String getCardNo = "Select card_no from cards c inner join card_status cs on c.card_status_oid = cs.card_status_oid where c.customer_mid in (select customer_mid from m_customers mc where mc.customer_no='"
				+ CustomerNo + "' and cs.description = '" + cardStatus + "')";

		String cardNumber = connectDBAndGetValue(getCardNo, PropUtils.getPropValue(configProp, "sqlODSServerName"));
		System.out.println("cardNumber : " + cardNumber);
		return cardNumber;
	}

	public Map<String, String> readDataFromPropertyFile(String expectedKey, File propertyName) {
		Set<Entry<Object, Object>> keys = PropUtils.getProps(propertyName).entrySet();
		Map<String, String> expectedKeysValues = new HashMap<String, String>();
		for (Entry<Object, Object> expectedKeysAndValues : keys) {
			Object key = expectedKeysAndValues.getKey();
			String propKey = String.valueOf(key);
			if (propKey.contains(expectedKey)) {
				expectedKeysValues.put(propKey, expectedKeysAndValues.getValue().toString());

			}
		}
		System.out.println("keys and values::" + expectedKeysValues);
		return expectedKeysValues;
	}

	public void clearTemplateFileContents(File srcFile, File destFile) {
		FileOutputStream output = null;
		try {
			InputStream is = new FileInputStream(srcFile);
			@SuppressWarnings("resource")
			BufferedReader buf = new BufferedReader(new InputStreamReader(is));
			String line = buf.readLine();
			StringBuilder sb = new StringBuilder();

			while (line != null) {
				sb.append(line).append("\n");
				line = buf.readLine();
			}
			String textToAppend = sb.toString();
			// System.out.println("text from file::"+textToAppend);
			BufferedWriter writer = new BufferedWriter(new FileWriter(destFile, true));
			writer.newLine();
			writer.write(textToAppend);
			writer.close();
		} catch (Exception e) {
			e.getMessage();
		}
		try {
			// pop.load(new FileInputStream(srcFile));
			output = new FileOutputStream(srcFile);
			output.close();
			// PropUtils.clearProps(chevronEndToEndTemplateProp);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/*
	 * Raxsana Updated on 16/10/2020
	 */
	public void chooseRandomCheckbox() {
		
		List<WebElement> checkBox = driver.findElements(By.xpath("//*[starts-with(@id,'JFALCheckBox')]"));
		int size = checkBox.size();
		int checkBoxValue = getRandomNumber(0, size);// 14);
		System.out.println("Check box value is -->" + checkBoxValue);
		sleep(1);
		try
		{
		checkBox.get(checkBoxValue).click();
		}
		catch(Exception e)
		{
			isDisplayedThenActionClick(checkBox.get(checkBoxValue),"");
			System.out.println("Click failed and Action click performed");
		}

	}

	public String getCustomerValue() {
		validateHeaderLabel("Transaction Detail");
		System.out.println("getText(cusValue)  :  " + getText(cusValue));
		return getText(cusValue);
	}

	public String getMerchantValue() {
		validateHeaderLabel("Transaction Detail");
		System.out.println("getText(mercValue) :  " + getText(mercValue));
		return getText(mercValue);
	}

	public void customerAndMerchantBreakDown(String refNum, double expCustomerTax, double expMerchantTax) {

		validateHeaderLabel("Transaction Detail");
		System.out.println("getText(transRef) :  " + getText(transRef));

		if (getText(transRef).equals(refNum)) {

			switchTabDetails("Customer Breakdown");

			System.out.println("getText(cusTaxTotal) :  " + getText(cusTaxTotal));

			double actualCustTax = Double.parseDouble(getText(cusTaxTotal));

			if (actualCustTax == expCustomerTax) {
				logPass("expected Cus tax amount found");
			} else
				softFail("expected Cus tax amount not found");

			switchTabDetails("Merchant Breakdown");

			System.out.println("getText(mercTaxTotal) :  " + getText(mercTaxTotal));

			double actualMercTax = Double.parseDouble(getText(mercTaxTotal));

			if (actualMercTax == expMerchantTax) {
				logPass("expected Merc tax amount found");
			} else
				softFail("expected Merc tax amount not found");
		} else {
			logFail("Expected transaction not found");
		}
	}

	public double merchantTaxCalculations(String clientCountry, String merchantValue) {
		// Logic will come

		DecimalFormat df = new DecimalFormat("0.00");

		double calMerchantTax = 0;
		double merValue = Double.parseDouble(merchantValue);
		// double merValue = 37.2757;
		if (clientCountry.equals("MY") || clientCountry.equals("HK")) {
			calMerchantTax = 0.0000;
		} else if (clientCountry.equals("TH")) {
			calMerchantTax = -0.42;
		} else if (clientCountry.equals("PH")) {
			calMerchantTax = (merValue * 12) / 112;
		} else if (clientCountry.equals("SG")) {
			calMerchantTax = (merValue * 7) / 107;
		}
		df.setRoundingMode(RoundingMode.UP);
		System.out.println("calMerchantTax -->" + df.format(calMerchantTax));
		return Double.parseDouble(df.format(calMerchantTax));
	}

	public double customerTaxCalculations(String clientCountry, String customerValue) {
		// Logic will come

		DecimalFormat df = new DecimalFormat("0.00");

		double calCustomerTax = 0;
		double cusValue = Double.parseDouble(customerValue);
		// double cusValue = 37.275;
		if (clientCountry.equals("MY") || clientCountry.equals("HK")) {
			calCustomerTax = 0.00;
		} else if (clientCountry.equals("TH")) {
			calCustomerTax = 0.00;
		} else if (clientCountry.equals("PH")) {
			calCustomerTax = (cusValue * 12) / 112;
		} else if (clientCountry.equals("SG")) {
			calCustomerTax = (cusValue * 7) / 107;
		}
		df.setRoundingMode(RoundingMode.UP);
		System.out.println("calCustomerTax -->" + df.format(calCustomerTax));
		return Double.parseDouble(df.format(calCustomerTax));
	}

	public void validatingTaxValuesInDB(Map<String, String> taxValuesInDB, double customerTax, double merchantTax) {
		System.out.println("taxValuesInDB.get(\"TAX_RATE\") : " + taxValuesInDB.get("TAX_RATE"));
		System.out.println("taxValuesInDB.get(\"CUSTOMER_TAX_AMOUNT\") : " + taxValuesInDB.get("CUSTOMER_TAX_AMOUNT"));
		System.out.println("taxValuesInDB.get(\"MERCHANT_TAX_AMOUNT\") : " + taxValuesInDB.get("MERCHANT_TAX_AMOUNT"));

		double expCustomerTax = 0;
		double expMerchantTax = 0;
		double expTaxRate = 0;

		String clientCountry = PropUtils.getPropValue(configProp, "clientCountry");

		if (clientCountry.equals("SG")) {
			expTaxRate = 7;
		} else if (clientCountry.equals("PH")) {
			expTaxRate = 12;
		} else
			expTaxRate = 0;

		if (customerTax == 0.00 || merchantTax == 0.0000) {
			expCustomerTax = 0;
			expMerchantTax = 0;
		} else {
			expCustomerTax = customerTax;
			expMerchantTax = merchantTax;
		}

		double actualCustTax = Double.parseDouble(taxValuesInDB.get("CUSTOMER_TAX_AMOUNT"));
		double actualMercTax = Double.parseDouble(taxValuesInDB.get("MERCHANT_TAX_AMOUNT"));
		double actualTaxRate = Double.parseDouble(taxValuesInDB.get("TAX_RATE"));
		//
		// System.out.println("-------------------------------------------------------------------");
		//
		// System.out.println(expCustomerTax+" "+expMerchantTax+" "+expTaxRate);
		// System.out.println("-------------------------------------------------------------------");
		//
		// System.out.println(actualCustTax+" "+actualMercTax+" "+actualTaxRate);
		// System.out.println("-------------------------------------------------------------------");

		if (actualTaxRate == expTaxRate) {
			logPass("expected tax rate found in db");
		} else
			softFail("expected tax rate not found in db");

		if (actualCustTax == expCustomerTax) {
			logPass("expected Cus tax amount found in db");
		} else
			softFail("expected Cus tax amount not found in db");

		if (actualMercTax == expMerchantTax) {
			logPass("expected Merc tax amount found in db");
		} else
			softFail("expected Merc tax amount not found in db");
	}

	// Added by Sasi 27-08-2019
	public Map<String, String> getTaxAmountFromDB(String refNo, String clientCountry) {

		String parsedDate = getCurrentIFCSDateFromDB(clientCountry);
		String currentDate = "";

		Date dateFormat = null;
		// String dateFormatted = "";
		try {
			DateFormat df = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
			dateFormat = df.parse(parsedDate);
			// dateFormat1 = new SimpleDateFormat("dd/MM/yyyy").parse(processingDate);
			System.out.println("Date Format" + dateFormat);
			currentDate = new SimpleDateFormat("dd-MMM-yy").format(dateFormat);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		System.out.println("IFCSDate --> " + currentDate);
		// String currentDate = enterADateValueInStatusBeginDateField("Current",
		// parsedDate) ;
		String cusTaxAmountDetailsQuery = "select TAX_RATE,CUSTOMER_TAX_AMOUNT,MERCHANT_TAX_AMOUNT from TRANSACTION_LINE_ITEMS where transaction_oid = (select transaction_oid from transactions where REFERENCE='"
				+ refNo + "'" + " and POSTED_AT like '" + currentDate.toUpperCase() + "%')";
		Map<String, String> cusTaxDetails = connectDBAndGetDBEntireRowValues(cusTaxAmountDetailsQuery,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		System.out.println("cusTaxDetails : " + cusTaxDetails);
		return cusTaxDetails;
	}

	public void setClientInContext() {
		sleep(5);
		searchTorch();
		sleep(5);
		// driver.findElement(By.xpath(
		// "//div[@class='JFALLabel']//div['Client']//preceding::div[@class='JFALCompControlPanel'][1]/div[@class='JFALComboBox']//div[@class='MetalComboBoxButton
		// enabled JButton']"))
		// .click();

		isDisplayedThenClick(clientDropdown, "Client dropdown");
		sleep(5);
		// driver.findElement(By.xpath("//div[@class='BasicComboPopup_1']/div/div[@class='htmlString'
		// and contains(text(),'Z') and contains(text(),'Energy')and
		// contains(text(),'Limited')]")).click();
		// chooseOptionFromDropdown("Client", "Chevron Hong Kong Limited");
		isDisplayedThenClick(selectClient, "Client selected");
		sleep(2);
		findRecordTorch();
		sleep(5);
		closeFindRecordTorch();
		sleep(3);
	}

	public void gotoSundryAdjustMentAndSetClient(String clientName) {
		sleep(3);
		chooseSubMenuFromLeftPanel("Sundry", "Adjustment");
		validateHeaderLabel("Adjustment");
		sleep(5);
		searchTorch();
		sleep(5);
		// setClientInContext();
		System.out.println("Client name is  " + clientName);
		chooseOptionFromDropdown("Client", clientName);
		sleep(3);
		findRecordTorch();
		sleep(5);
		closeFindRecordTorch();
		sleep(3);
	}

	public void validatePostSundryAdjustmentTransaction(String custNo, String adjustmentType, String amount,
			String refno) {

		enterValueInTextBox("Customer Sundry Adjustment", "Account No", custNo);

		// enterValueInTextBox("Customer Sundry Adjustment", "Card Number", cardNo);

		// driver.findElement(By.xpath(
		// "//div[@class='JFALLabel']//div['Adjustment
		// Type']//preceding::div[@class='JFALCompControlPanel'][1]/div[@class='JFALComboBox']//div[@class='MetalComboBoxButton
		// enabled JButton']"))
		// .click();

		isDisplayedThenClick(adjustmentTypeDropdown, "adjustment type");
		sleep(2);

		JavascriptExecutor je = (JavascriptExecutor) driver;
		WebElement element = driver
				.findElement(By.xpath("//div[@class='BasicComboPopup_1']/div/div[@class='htmlString']["
						+ splitStringAndGenerateXpath(adjustmentType) + "]"));
		je.executeScript("arguments[0].scrollIntoView(true);", element);

		sleep(3);
		element.click();

		// enterValueInTextBox("Customer Sundry Adjustment", "Effective On",
		// effectiveOn);
		enterValueInTextBox("Customer Sundry Adjustment", "Amount", amount);
		sleep(1);
		enterValueInTextBox("Customer Sundry Adjustment", "Reference", refno);

		clickValidateIcon();
		sleep(1);
		verifyValidationResult("Validation successful");
		clickPostTransaction();
		sleep(1);
		verifyValidationResult("Record saved OK");
	}

	public void addCustomerToOLSLogin(String clientName, String clientCountry, String olsUserName, String customerNum) {
		IFCSLoginPage ifcsloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage ifcsHomePage = new IFCSHomePage(driver, test);
		Common common = new Common(driver, test);
		ifcsloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		// ifcsHomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);
		ifcsHomePage.gotoAdminMenuAndChooseClientGroup();
		common.goToOnlineUsers();
		common.searchTheCurrentUserOnOnlineUsers(olsUserName);
		ifcsHomePage.addCustomerToUser(customerNum);
		ifcsHomePage.exitIFCS();
	}

	public String timeStampToEpochMillisSec(String timestamp) {
		if (timestamp == null)
			return null;
		try {
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
			Date dt = sdf.parse(timestamp);
			long epoch = dt.getTime();
			int milliSeconds = (int) (epoch / 1000);
			String milliEpochSeconds = Integer.toString(milliSeconds);
			return milliEpochSeconds;
		} catch (ParseException e) {
			return null;
		}
	}

	public int validateTextInDescription(String seperatorLabelName, String tableHeaderName, String DescriptionValue) {
		// int countDefault = 0;
		int row = 0;
		String seperator = " ";
		int index = 1;
		if (seperatorLabelName.equals("Rebate Profiles")) {
			index = 2;
		}
		try {
			System.out.println("**************");
			seperator = splitStringAndGenerateXpath(seperatorLabelName);
			List<WebElement> tableHeaders = driver.findElements(By.xpath("//div[@class='JFALSeparator']//div["
					+ seperator + "]/preceding::div[@class='JFALCompControlPanel'][" + index
					+ "]//div[@class='JViewport']/div[@class='JTableHeader']//div[@class='HeaderRenderer']"));
			System.out.println(tableHeaders);
			int colIndex = SeleniumWrappers.getColumnNoForColumnHeader(tableHeaderName, tableHeaders);
			System.out.println("ColIndex--->" + colIndex);
			List<WebElement> list = driver.findElements(By.xpath("//div[@class='JFALSeparator']//div[" + seperator
					+ "]/preceding::div[@class='JFALCompControlPanel'][" + index
					+ "]//div[@class='FALTableCellEditor_StrikeThruField JTextComponent']"));
			SeleniumWrappers.setTotalTableHeaders(tableHeaders.size());

			int size = SeleniumWrappers.getTotalNumberOfRows(list, driver);
			System.out.println("Size of table" + size);
			for (row = 0; row < size; row++) {
				WebElement element = driver.findElement(By.xpath("//div[@class='JFALSeparator']//div[" + seperator
						+ "]/preceding::div[@class='JFALCompControlPanel'][" + index
						+ "]//div[@class='FALTableCellEditor_StrikeThruField JTextComponent'][contains(@id,'_" + row
						+ "_" + colIndex + "')]//div[@class='htmlString']"));
				System.out.println("Rebate element ::" + element);
				String value = element.getText();
				System.out.println("Rebate value ::" + value);
				if (value.contains(DescriptionValue)) {
					// countDefault = countDefault + 1;
					logInfo("CheckBox Clicked");
					break;

				}
			}
			if (row == size) {
				row = 0;
				// row = -1;
				logInfo("No Rows in a table");
			}
		} catch (Exception e) {
			logFail(e.getMessage());
		}
		return row;
	}

	public String getActiveCardNumberFromDBWFE(String clientName, String clientCountry) {
		String cardNumberDB = null;
		// clientName = PropUtils.getPropValue(configProp, clientName);
		// clientCountry = PropUtils.getPropValue(configProp, clientCountry);
		if (clientName.equals("WFE")) {
			cardNumberDB = "Select c.card_no from m_customers mc inner join cards c on c.customer_mid = mc.customer_mid inner join card_status cs on c.card_status_oid=cs.card_status_oid inner join m_clients mcn on mcn.client_mid = mc.client_mid where (cs.description like ('%Normal Service%') OR cs.description like  ('%NORMAL SERVICE%')) and mcn.name = '"
					+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountry).replaceAll("\"", "")
					+ "' and rownum<=1";
		}
		String cardNumber = connectDBAndGetValue(cardNumberDB, PropUtils.getPropValue(configProp, "sqlODSServerName"));
		System.out.println("Card Number" + cardNumber);

		return cardNumber;
	}

	public ArrayList<String> getActivedualCardNumberFromDBWFE(String clientName, String clientCountry) {
		String cardNumberDB = null;
		// Map<String, String> lineItem = null ;

		cardNumberDB = "Select distinct c.card_no from m_customers mc\r\n"
				+ "inner join cards c on c.customer_mid = mc.customer_mid \r\n"
				+ "inner join card_status cs on c.card_status_oid=cs.card_status_oid \r\n"
				+ "inner join m_clients mcn on mcn.client_mid = mc.client_mid \r\n"
				+ "inner join card_products cp on cp.CARD_TYPE_CID=c.CARD_TYPE_CID inner join card_controls cc on cc.card_control_profile_oid= c.card_control_profile_oid\r\n" + 
				"inner join time_limits tl on tl.time_limit_oid=cc.time_limit_oid\r\n"
				+ "where cp.description like '%Driver%' and (cs.description like ('%Normal Service%') OR cs.description like  ('%NORMAL SERVICE%')) and mcn.name ='"
				+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountry).replaceAll("\"", "")
				+ "' and c.expires_on >=(SELECT PROCESSING_DATE from M_CLIENTS where name = '"
				+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountry).replaceAll("\"", "") + "') and tl.description='All days, all times'";

		String DriverCardNO = connectDBAndGetValue(cardNumberDB,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		System.out.println("Driver Card Number" + DriverCardNO);

		String Customermidq = "select customer_mid from cards where card_no='" + DriverCardNO + "'";

		String Customermid = connectDBAndGetValue(Customermidq, PropUtils.getPropValue(configProp, "sqlODSServerName"));
		String cardNumber2DB = "Select distinct c.card_no,c.customer_mid from m_customers mc\r\n"
				+ "inner join cards c on c.customer_mid = mc.customer_mid \r\n"
				+ "inner join card_status cs on c.card_status_oid=cs.card_status_oid \r\n"
				+ "inner join m_clients mcn on mcn.client_mid = mc.client_mid \r\n"
				+ "inner join card_products cp on cp.CARD_TYPE_CID=c.CARD_TYPE_CID\r\n" + "where c.customer_mid='"
				+ Customermid
				+ "' and cp.description like '%Vehicle%' and (cs.description like ('%Normal Service%') OR cs.description like  ('%NORMAL SERVICE%')) and mcn.name ='"
				+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountry).replaceAll("\"", "")
				+ "' and c.expires_on >=(SELECT PROCESSING_DATE from M_CLIENTS where name = '"
				+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountry).replaceAll("\"", "") + "')";
		String vehiclecardNumber = connectDBAndGetValue(cardNumber2DB,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		System.out.println("Vehicle Card Number" + vehiclecardNumber);

		ArrayList<String> cardlist = new ArrayList<String>();
		cardlist.add(DriverCardNO);
		cardlist.add(vehiclecardNumber);
		return cardlist;
	}

	/** Added by Nithya - Vincii Card Badge number */

	public String getBadgeNumberForCardFromICPDB(String cardNumber) {
		String query = "select badgenumber from card where cardnumber = '" + cardNumber + "'";
		return connectICPDBAndGetValue(query, PropUtils.getPropValue(configProp, "icpServerName"));
	}

	public String[] getBadgeNumbersForNoOfCardFromICPDB(int noOfCards, String withStatus) {
		String query = "select cardnumber from card where badgenumber is not NULL";
		String[] returnedValues = connectICPDBAndGetDBResults(query, 50,
				PropUtils.getPropValue(configProp, "icpServerName"));
		String[] valuesNeeded = new String[10];
		int count = 0;
		for (int i = 0; i < returnedValues.length - 1; i++) {
			System.out.println("Length:" + valuesNeeded.length);
			if (getCardStatus(returnedValues[i]).contains(withStatus)) {
				if (count < noOfCards) {
					valuesNeeded[i] = getBadgeNumberForCardFromICPDB(returnedValues[i]);
					count++;
					System.out.println("Cards:" + valuesNeeded[i]);
				} else {
					break;
				}
			}
		}

		return valuesNeeded;
	}

	/** Added by Nithya - Vincii - Sequence Number */

	public String getSequenceNoForVinciiTransFromICPDB() {
		String query = "select ts.filesequencenumber + 1 as expectedVinciTrxSequenceNumber \r\n"
				+ "from icpms_wfe_uat_2.transferfileseq ts where ts.type = 'V01T' and ts.sourcesystem = 'VINCIMAP'";
		return connectICPDBAndGetValue(query, PropUtils.getPropValue(configProp, "icpServerName"));
	}

	/** Added by Nithya - Vincii - File Sequence Number */

	public String getLastProcessedFileNameForVincii() {

		return "";
	}

	/*
	 * Added by Davu - 10/06/2020
	 */

	public Properties readPropertiesFile(String fileName) throws IOException {
		FileInputStream fis = null;
		Properties prop = null;
		try {
			fis = new FileInputStream(Constants.CONFIG_DIR + fileName);
			prop = new Properties();
			prop.load(fis);
		} catch (FileNotFoundException fnfe) {
			fnfe.printStackTrace();
		} catch (IOException ioe) {
			ioe.printStackTrace();
		} finally {
			fis.close();
		}
		return prop;
	}

	/**
	 * @param menuItem
	 * @param tablelocator
	 * @param menuItemLocator
	 */
	public void rightClickAndSelectMenuItem(String menuItem, WebElement tablelocator, WebElement menuItemLocator) {
		try {
			rightClick(tablelocator);
			sleep(3);
			isDisplayed(menuItemLocator, menuItem);
			isDisplayedThenClick(menuItemLocator, menuItem);
			sleep(5);
//			Click(menuItemLocator, "menuItem");
			logPass("Menu Item selected");
		} catch (Exception e) {
			logFail(e.getMessage());
		}
	}
	
	/**
	 * @return Update Card
	 */
	public void updateCardDriverName(String cardNumber) {
		chooseSubMenuFromLeftPanel("Card Details", "Card Maintenance");
		chooseCardNoAndSearch(cardNumber);
		sleep(3);
		enterValueInTextBox("Driver Details", "Driver Name", fakerAPI().name().firstName());
		clickSaveIcon();
		sleep(2);
		verifyValidationResult("Record saved OK");
	}
	
	/**
	 * @return Update Card
	 */
	public void updateCardLicensePlate(String cardNumber) {
		chooseSubMenuFromLeftPanel("Card Details", "Card Maintenance");
		chooseCardNoAndSearch(cardNumber);
		sleep(3);
		enterValueInTextBox("Vehicle Details", "License Plate", fakerAPI().number().digits(4));
		clickSaveIcon();
		sleep(2);
		verifyValidationResult("Record saved OK");
	}

	/**
	 * @return Update Card
	 */
	public void updateCardExpiryDate(String clientName, String clientCOuntry, String cardNumber) {
		String getCurrentDate = getCurrentIFCSDateFromDB(clientName + clientCOuntry);
		String expiryDate = enterADateValueInStatusBeginDateField("WayFuture", getCurrentDate);
		chooseSubMenuFromLeftPanel("Card Details", "Card Maintenance");
		chooseCardNoAndSearch(cardNumber);
		sleep(3);
		enterDateInDropdown("Expiry Date", expiryDate);
		clickSaveIcon();
		sleep(2);
		clickYesButton();
		sleep(2);
		verifyValidationResult("Card Request submitted OK");

	}
	
	

	/**
	 * @return row index
	 */
	public int getRowNumberFromTable() {
		int rowNumber = SeleniumWrappers.getTotalNumberOfRows(
				driver.findElements(By.xpath("//div[@class='FALTableCellEditor_StrikeThruField JTextComponent']")),
				driver);
		return rowNumber;
	}

	/**
	 * @param Lable
	 * @param Option
	 */
	public void searchCardsWithDifferentFilters(String Lable, String Option) {

		chooseOptionFromDropdown(Lable, Option);
		searchListTorch();
		sleep(5);
		List<WebElement> cardsTable1 = driver.findElements(By.xpath(
				"//div[@class='JFALSeparator']//div[contains(text(),'Card') and contains(text(),'List')]//preceding::div[@class='JFALCompControlPanel'][1]//div[@class='FALTableCellEditor_StrikeThruField JTextComponent']"));
		if (SeleniumWrappers.getTotalNumberOfRows(cardsTable1, driver) > 0)
			logPass("Done Cards Search");
		else
			logInfo("Details not found");

		chooseBlankOptionFromDropdown(Lable);
	}

	/**
	 * 
	 * @param message
	 * @return added by rathna
	 */
	public boolean isValidationMessageNotExists(String expectedResult) {
		boolean status = true;
		;
		WebElement validateElement;
		try {
			String validationMsg = splitStringAndGenerateXpath(expectedResult);
			waitToCheckElementIsDisplayed(By.xpath(
					"//div[@class='JPanel']//div[@class='ExtLabel']//div[@class='htmlString'][" + validationMsg + "]"),
					10);
			validateElement = driver.findElement(By.xpath(
					"//div[@class='JPanel']//div[@class='ExtLabel']//div[@class='htmlString'][" + validationMsg + "]"));
			if (getText(validateElement).contains(expectedResult)) {
				logPass("Expected results not displayed: " + expectedResult);
			} else {
				logInfo("Expected results displayed ");
			}

		} catch (Exception ex) {
			logInfo(ex.getMessage());
			status = false;
		}
		return status;
	}




	
	
	/**
	 * 
	 * @param message
	 * @return added by rathna
	 */
	public boolean isValidationMessageExists(String expectedResult) {
		boolean status = true;
		;
		WebElement validateElement;
		try {
			String validationMsg = splitStringAndGenerateXpath(expectedResult);
			waitToCheckElementIsDisplayed(By.xpath(
					"//div[@class='JPanel']//div[@class='ExtLabel']//div[@class='htmlString'][" + validationMsg + "]"),
					10);
			validateElement = driver.findElement(By.xpath(
					"//div[@class='JPanel']//div[@class='ExtLabel']//div[@class='htmlString'][" + validationMsg + "]"));
			if (getText(validateElement).contains(expectedResult)) {
				logPass("Expected results displayed " + expectedResult);
			} else {
				logInfo("Expected results not displayed");
			}

		} catch (Exception ex) {
			logInfo(ex.getMessage());
			status = false;
		}
		return status;
	}

	// rathna added
	// Gets Get the time when the card moved from 'RequestedNot Issued' to 'Normal
	// Service'

	public String getStatusChangeTime(String cardNumber) {

		String queryForupdatedTime = "select distinct Card_Status_at from cards c\r\n"
				+ "inner join card_status cs on cs.card_status_oid=c.card_status_oid \r\n"
				+ "inner join CARD_STATUS_LOGS csc on csc.card_oid=c.card_oid\r\n" + "where c.card_no='" + cardNumber
				+ "'";
		String updatedTime = connectDBAndGetValue(queryForupdatedTime,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		System.out.println("updatedTime : " + updatedTime);

		return updatedTime;

	}

	/**
	 * Added by Rathna
	 * 
	 */
	public String getTimeBeforeStatusChange(String statusChangeTime, long hours) {
		String beforeTime = null;
		try {
			DateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
			dateFormatter.parse(statusChangeTime);
			Date newDate;
			Calendar cal = Calendar.getInstance();
			cal.setTime(dateFormatter.parse(statusChangeTime));
			newDate = cal.getTime();
			DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
			beforeTime= df.format(newDate);
			System.out.println("beforeTime++"+beforeTime+"--newDate++"+newDate);
			/*SimpleDateFormat actDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss a");
			//SimpleDateFormat expDateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss a");
			//String expDate = expDateFormat.format(actDateFormat.parse(statusChangeTime));

			//System.out.println(expDate);
			String currentTime = expDate;

			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
			System.out.println("Before subtraction of hours from date: " + expDate);
			LocalDateTime datetime = LocalDateTime.parse(expDate, formatter);
			datetime = datetime.minusHours(hours);
			beforeTime = datetime.format(formatter);
			System.out.println("Before time: " + beforeTime);*/

		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return beforeTime;

	}
		
	/*	*//**		
		 * Added by Rathna		
		 * 		
		 *//*		
			public  String getTimeBeforeStatusChange(String statucChangeTime, long hours) {	
				String beforeTime=null;
				try {
			
				SimpleDateFormat actDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss a");
				SimpleDateFormat expDateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss a");
				String expDate = expDateFormat.format(actDateFormat.parse(statucChangeTime));
				
				System.out.println(expDate);
				String currentTime = expDate;

				DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy hh:mm:ss a");
				System.out.println("Before subtraction of hours from date: " + expDate);
				LocalDateTime datetime = LocalDateTime.parse(expDate, formatter);
				datetime = datetime.minusHours(hours);
				 beforeTime = datetime.format(formatter);
				System.out.println("Before time: " + beforeTime);
				
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				return beforeTime;
				
			}	
	*/

			/**
	 * 
	 *
	 * added by Davu
	 */
	public String checkAndUncheckTheCheckBox(String labelname) {
		String seperator = " ";
		WebElement chechBoxElement = null;
		String checkBoxIsSelectedOrNot;
		String selectedOrNot = null;
		try {
			seperator = splitStringAndGenerateXpath(labelname);
			try {
				checkBoxIsSelectedOrNot = driver.findElement(By.xpath("//div[" + seperator
						+ "]/preceding::div[@class='JFALCompControlPanel']//div[@class='JFALCheckBox enabled']/child::div//div"))
						.getCssValue("border-right-color");
			} catch (Exception e) {
				checkBoxIsSelectedOrNot = null;
			}
			if (checkBoxIsSelectedOrNot == null) {
				selectedOrNot = "NotSelected";
				logInfo("CheckBox is not Selected");
				chechBoxElement = driver.findElement(By.xpath("//div[@class='JFALLabel']//div[" + seperator
						+ "]/preceding::div[@class='JFALCompControlPanel'][1]//div[@class='JFALCheckBox enabled']"));

				chechBoxElement.click();
				logPass("checkBox is Selected");
			} else {
				selectedOrNot = "Selected";
				logInfo("Check Box is already Selected");
				chechBoxElement = driver.findElement(By.xpath("//div[@class='JFALLabel']//div[" + seperator
						+ "]/preceding::div[@class='JFALCompControlPanel'][1]//div[@class='JFALCheckBox enabled']"));
				chechBoxElement.click();
				logPass("checkBox is Unchecked");
			}
		} catch (Exception ex) {
			logFail(ex.getMessage());
		}

		return selectedOrNot;

	}


		/*
	 * Added by Davu - 29/07/2020
	 * 
	 */

	public String getCustomerNowithPrivateRebate(String clientName, String clientCountry) {

		String queryForCustomerNo = "select customer_no from m_customers where customer_mid in (select customer_mid from rebate_profiles where profile_category_cid=503 and  description like '["
				+ clientName + "_" + clientCountry + "]%') order by DBMS_RANDOM.VALUE";
		String customerNo = connectDBAndGetValue(queryForCustomerNo,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		System.out.println("customerNo : " + customerNo);
		return customerNo;

	}

	/*
	 * Added by Davu - 29/07/2020
	 * 
	 */

	public String getCustomerNowithPrivateCardFee(String clientCountry) {
		String countryName = "";
		if (clientCountry.equals("NL")) {
			countryName = "Netherlands";
		} else if (clientCountry.equals("BE")) {
			countryName = "Belgium";
		} else if (clientCountry.equals("FR")) {
			countryName = "France";
		} else if (clientCountry.equals("LU")) {
			countryName = "Luxembourg";
		}

		String queryForCustomerNo = "select customer_no from m_customers where customer_mid = (select customer_mid from fee_profiles where profile_category_cid=503 and  description like '%"
				+ countryName + "%' and rownum<=1)";
		String customerNo = connectDBAndGetValue(queryForCustomerNo,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		System.out.println("customerNo : " + customerNo);
		return customerNo;

	}

	/*
	 * Added by Davu
	 */
	public void updatePropFile(String key, String value, String fileName) {

		PropertiesConfiguration config = null;
		try {

			config = new PropertiesConfiguration(Constants.CONFIG_DIR + fileName);
			config.setProperty(key, value);
			config.save();
		} catch (ConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public String getParentOrChildCustomersHavingCardsWithExpectedStatus(String clientFullName, String customerType,
			String cardStatus) {

		String customerNumber = null;
		Map<String, String> childCustomerNumberAndHierarchyId = null;
		clientFullName = PropUtils.getPropValue(configProp, clientFullName);

		if (customerType.equals("child")) {
			String childCustomerNumberQuery = "select mc.customer_no,rel.hierarchy_oid from cards c \r\n"
					+ "inner join m_customers mc on mc.customer_mid = c.customer_mid\r\n"
					+ "inner join card_programs cp on cp.card_program_oid=mc.card_program_oid\r\n"
					+ "INNER JOIN CARD_STATUS cs on c.CARD_STATUS_OID = cs.CARD_STATUS_OID\r\n"
					+ "inner join relationships rel on c.customer_mid = rel.member_oid\r\n"
					+ "inner join M_clients mcs on mc.client_mid = mcs.client_mid\r\n"
					+ "where rel.relationship_oid<>rel.parent_relationship_oid \r\n"
					+ "and c.replace_card_oid IS NULL and\r\n" + "mcs.name = '" + clientFullName
					+ "' and cs.DESCRIPTION = '" + cardStatus + "' and rownum=1";
			childCustomerNumberAndHierarchyId = connectDBAndGetDBEntireRowValues(childCustomerNumberQuery,
					PropUtils.getPropValue(configProp, "sqlODSServerName"));
			customerNumber = childCustomerNumberAndHierarchyId.get("CUSTOMER_NO");
			System.out.println("Child Customer Number:" + customerNumber);

		}
		if (customerType.equals("parent")) {

			String childCustomerNumberQuery = "select mc.customer_no,rel.hierarchy_oid from cards c \r\n"
					+ "inner join m_customers mc on mc.customer_mid = c.customer_mid\r\n"
					+ "inner join card_programs cp on cp.card_program_oid=mc.card_program_oid\r\n"
					+ "INNER JOIN CARD_STATUS cs on c.CARD_STATUS_OID = cs.CARD_STATUS_OID\r\n"
					+ "inner join relationships rel on c.customer_mid = rel.member_oid\r\n"
					+ "inner join M_clients mcs on mc.client_mid = mcs.client_mid\r\n"
					+ "where rel.relationship_oid<>rel.parent_relationship_oid \r\n"
					+ "and c.replace_card_oid IS NULL and\r\n" + "mcs.name = '" + clientFullName
					+ "' and cs.DESCRIPTION = '" + cardStatus + "' and rownum=1";
			childCustomerNumberAndHierarchyId = connectDBAndGetDBEntireRowValues(childCustomerNumberQuery,
					PropUtils.getPropValue(configProp, "sqlODSServerName"));

			String parentCustomerNumberQuery = "select mc.customer_no from relationships rel\r\n"
					+ "inner join relationship_assignments rels on rel.relationship_oid=rels.relationship_oid \r\n"
					+ "inner join accounts acc on acc.customer_mid=rel.member_oid \r\n"
					+ "inner join m_customers mc on mc.customer_mid=acc.customer_mid \r\n"
					+ "inner join hierarchies hc on rel.hierarchy_oid = hc.hierarchy_oid\r\n"
					+ "and rel.relationship_oid =rel.parent_relationship_oid where hc.hierarchy_oid='"
					+ childCustomerNumberAndHierarchyId.get("HIERARCHY_OID") + "'";
			customerNumber = connectDBAndGetValue(parentCustomerNumberQuery,
					PropUtils.getPropValue(configProp, "sqlODSServerName"));

			System.out.println("Parent Number:" + customerNumber);

		}

		return customerNumber;
	}


	public Map<String, String> getMerchantNoWithNotransactionLocation(String clientNameInProp,String ifcsPreviousDate) {
		Map<String, String> merchantNo;
		String queryToGetMerchantNo="select DISTINCT  m.merchant_no from m_merchants m\r\n" + 
				"inner join transactions t on t.merchant_mid<> m.merchant_mid\r\n" + 
				"where  m.client_mid in (select client_mid from m_clients where name='" + clientNameInProp+ "')  and posted_at like '" + ifcsPreviousDate + "%'";

	    merchantNo=connectDBAndGetDBEntireRowValues(queryToGetMerchantNo,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
	    
		 System.out.println(merchantNo);
		return merchantNo;
	}


}
