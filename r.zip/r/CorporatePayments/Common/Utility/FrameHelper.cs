﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Common.Utility
{
	public class FrameHelper : IDisposable
	{
		private IWebDriver _driver;
		private By _myFrame;

		public FrameHelper(IWebDriver driver, By myFrame = null)
		{
			_driver = driver;
			_myFrame = myFrame;
		}

		public IWebElement FindElement(By by, TimeSpan? tSpan = null)
		{
			if (_driver == null)
			{
				return null;
			}

			_driver.SwitchTo().DefaultContent();
			// Look for the default page here itself so that
			// IframeWithChild can look only into Iframes
			IWebElement element;
			try
			{
                // We expect the page to be loaded by now
                if (tSpan != null)
                    _driver.TryWaitForElementToBeVisible(by, out element, tSpan);
                else
				    element = _driver.FindElement(by);

				return element;
			}
			catch (Exception)
			{
				if (_driver.TrySwitchToIframeWithChild(by, out element, _myFrame, tSpan))
				{
					return element;
				}
			}
			return null;
		}

		/// <summary>
		/// Tries to Find the element *Strictly* on Iframe without attempting to look
		/// on the default page content first before switching to Iframe
		/// </summary>
		public IWebElement FindElementStrictlyOnIframe(By by, TimeSpan? tSpan = null)
		{
			if (_driver == null)
			{
				return null;
			}

			_driver.SwitchTo().DefaultContent();

			IWebElement element;
			if (_driver.TrySwitchToIframeWithChild(by, out element, _myFrame, tSpan))
			{
				return element;
			}
			
			return null;
		}

        /// <summary>
        /// Find Elements on Iframe
        /// </summary>
		public IReadOnlyCollection<IWebElement> FindElements(By by)
		{
			if (_driver == null)
			{
				return null;
			}
			
			if (_driver.TrySwitchToIframeWithChilds(by, out IReadOnlyCollection<IWebElement> elements, _myFrame))
			{
				return elements;
			}
			
			return null;
		}
                
        /// <summary>
        /// Switches to default window
        /// </summary>
		public virtual void Dispose()
		{
			if (_driver != null)
			{
				_driver.SwitchTo().DefaultContent();				
			}
		}
	}
}
