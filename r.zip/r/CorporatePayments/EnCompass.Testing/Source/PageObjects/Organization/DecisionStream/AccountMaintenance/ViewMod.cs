﻿using Common;
using Common.Utility;
using EnCompass.Testing.Source.PageObjects.Controls;
using NFluent;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EnCompass.Testing.Source.PageObjects.Organization.DecisionStream.AccountMaintenance
{
	[PageModel(@"/decisionStream/accountMaintenance/ViewMod.aspx")]
	public partial class ViewMod: EnCompassOrgPageModel
	{
		public override string RelativeUrl => @"/decisionStream/accountMaintenance/ViewMod.aspx";
		public override string PageIdentifierXPath_Override => @"//h1[normalize-space(text() = 'View Modifications' or text()='Summary of Edits')]";
		public ViewMod(GlobalSettings settings) : base(settings) { }

        #region XPath page Elements

        private const string _previousColumnTextXPath = @"//table[contains(@id, 'dgRealTimeChanges')]/tbody/tr/td[3]";
        private const string _newColumnTextXPath = @"//table[contains(@id, 'dgRealTimeChanges')]/tbody/tr/td[4]";
        private const string _newColumnCreditLimitXPath = @"//table[contains(@id, 'dgRealTimeChanges')]/tbody/tr[1]/td[4]";
        private const string _newColumnSinglePurchaseXPath = @"//table[contains(@id, 'dgRealTimeChanges')]/tbody/tr[2]/td[4]";
        private const string _closeBtnXPath = @"//input[contains(@id, 'btnOk')]";
        #endregion

        #region Page Elements
		private IWebElement _previousColumnText
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_previousColumnTextXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_previousColumnText element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _newColumnText
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_newColumnTextXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_newColumnText element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _newColumnCreditLimit
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_newColumnCreditLimitXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_newColumnCreditLimit element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _newColumnSinglePurchase
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_newColumnSinglePurchaseXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_newColumnSinglePurchase element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _closeBtn
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_closeBtnXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_closeBtn element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        #endregion

        public string PreviousColumnText
		{
			get { return _previousColumnText.Text; }
		}

		public string NewColumnText
		{
			get { return _newColumnText.Text; }
		}

        public string NewColumnCreditLimit
        {
            get { return _newColumnCreditLimit.Text; }
        }

        public string NewColumnSinglePurchaseLimit
        {
            get { return _newColumnSinglePurchase.Text; }
        }
        GridControl _realTimeChangesGrid;
		public GridControl RealTimeChangesGrid
		{
			get
			{
				return _realTimeChangesGrid ?? (_realTimeChangesGrid = new GridControl("dgRealTimeChanges", Driver));
			}
		}
       public void Close()
        {
            _closeBtn.JSClickWithFocus(Driver);
        }
    }
}
