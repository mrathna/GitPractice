package com.framework.testcases.OLS.ZEnergy.Customer;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.BP.BPHomePage;
import com.framework.pages.CHEV.CHContactListPage;
import com.framework.pages.CHEV.CHHomePage;
import com.framework.pages.CHEV.CHStoredReportsPage;
import com.framework.pages.OLS.common.LoginPage;
import com.framework.pages.OLS.common.MerchantReportsPage;
import com.framework.pages.Z.ZHomePage;
import com.framework.pages.Z.ZReportsPage;
import com.framework.util.PropUtils;

public class ValidateReportsAndInvoiceTestCases extends BaseTest {

	@Parameters({"clientCountry","clientName"})
	@Test( groups = { "Smoke" })
	public void validateViewReports(@Optional("Z") String clientCountry, @Optional("Z Energy Limited") String clientName) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  Verify that users should be able to view the following reports", "Validate users should be able to view the following reports ");

		//Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		ZReportsPage zReportPage = new ZReportsPage(driver, test);

		loginPage.Login("ZEnergy_URL", "ZEnergy_UN_Customer_" + clientCountry, "ZEnergy_PWD_Customer_" + clientCountry, clientName);

		String userID= PropUtils.getPropValue(configProp, "ZEnergy_UN_Customer_" + clientCountry);
		System.out.println(userID);
		// Go to Card List 

		zReportPage.goToFindReports();
		zReportPage.clickRequestAReport();
		//		zReportPage.ClickReportName();
		zReportPage.goToscheduleReport(userID);
		zReportPage.clickAddScheduleReport();

		// TC-08- Click a back to scheduled report list
		zReportPage.clickBackToScheduleReportList();
		zReportPage.goToInvoicesAndSearchInovices();

		loginPage.Logout();

	}
	 
	
	@Parameters({"clientCountry","clientName"})
	@Test( groups = { "Smoke" })
	
	public void testCustomerAhocReports(@Optional("Z") String clientCountry, @Optional("Z Energy Limited") String clientName) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  Verify report should have the adhoc report generate option and user should be able to generate the report", "report should have the adhoc report generate option and user should be able to generate the report");

			//Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		ZReportsPage zReportPage = new ZReportsPage(driver, test);
		ZHomePage zHomePage = new ZHomePage(driver, test);
		loginPage.Login("ZEnergy_URL", "ZEnergy_UN_Customer_" + clientCountry, "ZEnergy_PWD_Customer_" + clientCountry, clientName);
		
		//		commonPage.selectAccountFromDropdownAndValidate();	
		zReportPage.clickRequestAReport();
		zReportPage.clickOnAdhocReportsList();

		//Generate Adhoc report
		zReportPage.generateReportTypeAndValidate();
		zReportPage.verifyandClickGenerateButton();

		//verify report file is download or not
		zReportPage.verifyGenerateFileDownload();
		zReportPage.clickBackToAdhocReportsPage();

		//Export the Adhoc Reports List
		zReportPage.clickAdhocExportLinkBtn();
		zHomePage.verifyAccountNoForFileVerification();

		//Logout
		loginPage.Logout();


	} 

	@Parameters({"clientCountry","clientName"})
	@Test( groups = { "Smoke" })
	public void testGenerateAhocReports(@Optional("Z") String clientCountry, @Optional("Z Energy Limited") String clientName) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  Verify that user is able to send generated adhoc reports via email", "Verify that user is able to send generated adhoc reports via email");

		//Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		ZReportsPage zReportPage = new ZReportsPage(driver, test);

		loginPage.Login("ZEnergy_URL", "ZEnergy_UN_Customer_" + clientCountry, "ZEnergy_PWD_Customer_" + clientCountry, clientName);

		zReportPage.clickRequestAReport();
		zReportPage.clickOnAdhocReportsList();

		//Generate Adhoc report
		zReportPage.generateReportTypeAndValidate();
		
		zReportPage.enterDeliveryMailAdressAndClickGenerateButton();

		//Logout
		loginPage.Logout();


	}

	
	
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "Smoke", "Regression","BusinessFlow" })
	public void validate_Invoice_Report_Page(@Optional("Z") String clientCountry, @Optional("Z Energy Limited") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  BP Merchant Invoice Report Page", "Checking the Invoice Report Pages");

		// Creating Objects for the Login Pages
		LoginPage loginPage = new LoginPage(driver, test);
		ZReportsPage zReportPage = new ZReportsPage(driver, test);
		ZHomePage zHomePage = new ZHomePage(driver, test);
		loginPage.Login("ZEnergy_URL", "ZEnergy_UN_Customer_" + clientCountry, "ZEnergy_PWD_Customer_" + clientCountry, clientName);
		MerchantReportsPage merchantReportsPage = new MerchantReportsPage(driver, test);

//		commonPage.selectAccountFromDropdownAndValidate();	
		zReportPage.goToInvoicesAndSearchInovices();
		
		merchantReportsPage.selectCreatedFromDateUsingCalendarControl();
		merchantReportsPage.selectCreatedToDateUsingCalendarControl();
		merchantReportsPage.clickInvoiceReportSearchButton();
		//merchantReportsPage.validateInvoiceSearchRecords();

		
		  //Click Export Button & Partially Completed due to Windows handle Pop-up
		 
		merchantReportsPage.clickInvoiceReportExportLinkBtn("tableStoredRepList");
		
	

		//Logout
		loginPage.Logout();
	}
	
	
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "Smoke", "Regression","BusinessFlow" })
	public void validateContactsExport(@Optional("Z") String clientCountry, @Optional("Z Energy Limited") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  Z Energy  Customer  Report Page", "Checking the Invoice Report Pages");

		// Creating Objects for the Login Pages
		LoginPage loginPage = new LoginPage(driver, test);
		loginPage.Login("ZEnergy_URL", "ZEnergy_UN_Customer_" + clientCountry, "ZEnergy_PWD_Customer_" + clientCountry, clientName);

		CHHomePage chHomePage = new CHHomePage(driver, test);
		CHContactListPage chContactListPage = new CHContactListPage(driver, test);
		CHStoredReportsPage chStoredReportsPage = new CHStoredReportsPage(driver, test);
		
		chHomePage.loadFindAndContactsPage();
		chContactListPage.verifyContactListPage();
		chContactListPage.verifyContactTableColumns();
		chContactListPage.verifyAddContactAndExportButton();
		chContactListPage.clickExportButton();
		
		//chStoredReportsPage.VerifystoreReports();
		
		chHomePage.clickOnHome();

		loginPage.Logout();
   	}
	
}
