package com.framework.pages.AJS;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.ExtentTest;
import com.framework.basepage.BasePage;
import com.framework.pages.AJS.common.Common;
import com.framework.repo.Locator_IFCS;
import com.framework.util.PropUtils;
import com.framework.util.SeleniumWrappers;

public class ApplicationsPage extends BasePage {

	@FindBy(xpath = Locator_IFCS.SEARCH_RESULTS_TABLE)
	public List<WebElement> reportsTable;

	@FindBy(xpath = Locator_IFCS.BULK_REISSUE_TABLE)
	public WebElement tableContainer;

	@FindBy(xpath = Locator_IFCS.APPLICATION_CUSTOMER_PRICING_PROFILE)
	public WebElement applicationCustomerPricingProfile;

	@FindBy(xpath = Locator_IFCS.APPLICATION_CARD_CONTROL_PRIVATE_PROFILE)
	public WebElement applicationCardControlProfile;

	@FindBy(xpath = Locator_IFCS.CARDFEES_TABLE)
	public WebElement cardControlProfile;

	@FindBy(xpath = Locator_IFCS.OK_BUTTON)
	public WebElement okButton;
	@FindBy(xpath = Locator_IFCS.CLONE_FORM)
	public WebElement cloneForm;

	@FindBy(xpath = Locator_IFCS.CARD_OFFER_TABLE)
	public WebElement cardOfferTable;
	// Added by mamtha
	@FindBy(xpath = Locator_IFCS.CARD_OFFERS)
	public WebElement cardOffersAdd;

	@FindBy(xpath = Locator_IFCS.POPUP_MENUITEM_SELECT_PROFILE)
	public WebElement selectProfile;

	@FindBy(xpath = Locator_IFCS.CARD_CONTROLS)
	public WebElement cardControlsAdd;

	@FindBy(xpath = Locator_IFCS.APPROVE_ICON)
	public WebElement approveApplication;

	@FindBy(xpath = Locator_IFCS.CLONE_RECORD)
	public WebElement cloneRecord;

	@FindBy(xpath = Locator_IFCS.TAX_STATUS)
	public WebElement accountTaxStatus;
	@FindBy(xpath = Locator_IFCS.AACOUNT_TAXSTATUS)
	public WebElement taxStatusAccount;

	@FindBy(xpath = Locator_IFCS.DECLINE_ICON)
	public WebElement declineIcon;

	public ApplicationsPage(WebDriver driver, ExtentTest test) {
		super(driver, test);
		PageFactory.initElements(driver, this);
	}

	MaintainCustomerPage maintainCustomerPage = new MaintainCustomerPage(driver, test);

	//updated by raxsana on 25/06/2020 unused
	/*public void chooseApplicationsPage() {
		sleep(2);
		chooseSubMenuFromLeftPanel("Ad-Hoc Reports", "");
	}*/

	//updated by raxsana on 25/06/2020 covered in another method
	/*public void applicationFilterOptions(String applicationTypeValue, String statusValue) {
		Common common = new Common(driver, test);
		IFCSHomePage IFCShomePage = new IFCSHomePage(driver, test);
		validateLabelText("Application Type");

		// chooseOptionFromComboPopup("SG Deposit Customer", applicationTypeValue);
		chooseOptionFromDropdown("Application Type", applicationTypeValue);

		validateLabelText("Status");
		// chooseOptionFromComboPopup("Approved", statusValue);
		chooseOptionFromDropdown("Status", statusValue);
		common.searchListTorch();
		//common.selectFirstRowNumberInSearchList();
		IFCShomePage.searchApllicationandSelect();
		sleep(5);
		// common.searchTorch();

		// common.findRecordTorch();
		// chooseOptionFromDropdown
	}*/

	public void noReportLog() {
		logInfo("No Reports Assigned");
	}

	/*
	 * Click Clear Screen and create Application
	 * 
	 * @Meenakshi Sundaram
	 */
	public String clearExistingFormAndCreateNewApplicationWithMandatoryField(String setCreditLimit) {
		Common common = new Common(driver, test);
		String testName, tradingName, testAddress, creditLimit, getMarketingTerritory;
		String clientName = PropUtils.getPropValue(configProp, "clientName");
		String clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		if (clientName.equals("OTI") || clientName.equalsIgnoreCase("WFE")) {
			isDisplayedThenClick(cloneForm, "Clone Form");
			sleep(3);
			if (clientName.equalsIgnoreCase("WFE")) {
				verifyValidationResult("Cloned record, not saved yet");
			} else {
				verifyValidationResult("Cloned and saved record successfully.");
			}
		} else if (clientName.equals("EMAP")) {
			isDisplayedThenClick(cloneForm, "Clone Form");
			sleep(3);

		} else {
			common.clearForm();
			sleep(3);
			verifyValidationResult("New record, not saved yet");
		}

		testName = fakerAPI().name().fullName();

		common.enterValueInTextBoxWithIndex("Details", "Name", testName, 1);

		tradingName = fakerAPI().name().fullName();

		enterValueInTextBox("Details", "Trading Name", tradingName);

		testAddress = fakerAPI().address().fullAddress();

		sleep(3);
		// JavascriptExecutor js = (JavascriptExecutor)driver;
		enterValueInTextArea("Addresses/Contacts", "Physical Address", testAddress);
		/*
		 * WebElement DropDown = driver.findElement(By.xpath(
		 * "//div[@class='JFALLabel']//div[text()='Country']"));
		 * js.executeScript("arguments[0].scrollIntoView(true);", DropDown);
		 */
		if (!clientName.equalsIgnoreCase("WFE")) {
			common.selectACountryFromDropdown(1, "Country");
		}

		sleep(3);

		common.clickSaveIcon();

		sleep(3);
		if (setCreditLimit.equals("random")) {
			creditLimit = fakerAPI().number().digits(3);
		} else {
			creditLimit = "0.0";
		}

		common.switchTabDetails("Application-Account");
		if (clientName.equals("OTI")) {

			common.chooseOptionFromDropdown("Customer Type", "random");
			common.chooseOptionFromDropdown("Credit Plans", "random");
			common.chooseOptionFromDropdown("Billing Plans", "random");
			common.chooseOptionFromDropdown("Billing Frequency", "random");
			common.chooseOptionFromDropdown("Account Cycle", "random");

		} else {
			if (clientCountry.equals("SG") || clientCountry.equals("HK")) {
				// common.chooseOptionFromDropdown("Billing Plans","62 days after invoice date -
				// CHQ");
				common.chooseOptionFromDropdown("Billing Plans", "90 days after invoice date - CHQ");
			} else if (clientName.equalsIgnoreCase("WFE")) {
				common.chooseOptionFromDropdown("Billing Plans", "Cheque Payment -30 Days");
				common.chooseOptionFromDropdown("Denial Reason", "random");
			} else {

				common.chooseOptionFromDropdown("Billing Plans", "random");
			}

		}
		enterValueInTextBox("Account Details", "Credit Limit", creditLimit);
		common.clickSaveIcon();
		sleep(3);

		common.switchTabDetails("Business Details");

		common.chooseOptionFromDropdown("Business Type", "random");

		common.chooseOptionFromDropdown("Industry Type", "random");

		common.chooseOptionFromDropdown("Class of Buyer", "random");

		common.chooseOptionFromDropdown("Admin Territory", "random");

		getMarketingTerritory = common.chooseOptionFromDropdown("Marketing Territory", "random");

		System.out.println("clientcountry::" + clientCountry);

		if (!clientCountry.equals("HK") && !clientCountry.equals("SG") && !clientName.equalsIgnoreCase("WFE")) {
			String ExtDeliveryref = fakerAPI().number().digits(5);

			enterValueInTextBox("Misc Details", "Ext Delivery Ref", ExtDeliveryref);
			sleep(2);
		}
		common.clickSaveIcon();
		sleep(3);

		common.switchTabDetails("Application Checks");
		common.clickSaveIcon();
		verifyValidationResult("Record saved OK");
		sleep(3);

		if (clientName.equalsIgnoreCase("WFE")) {
			createCardOffersInApplication();
		}

		testName = testName + ":" + tradingName + ":" + getMarketingTerritory;

		// System.out.println("names::"+testName);
		return testName;
	}
	/*
	 * public void selectPricingProfile(String clientName, String clientCountry) {
	 * 
	 * maintainCustomerPage.verifyCustomerPricingProfile();
	 * maintainCustomerPage.popupForPricingProfiles(clientName, clientCountry,
	 * "Customer Pump Price Pricing Less Rebates");
	 * 
	 * }
	 */

	public void selectPricingProfile() {
		Common common = new Common(driver, test);
		MaintainCustomerPage maintainCustomerPage = new MaintainCustomerPage(driver, test);

		int row = maintainCustomerPage.getRowNumberForSelectProfile("Profiles", "Private");
		common.rightClickAndSelectProfile("Profiles", row, "Description");
		common.rightClickDeletePrivateProfileAndValidate("Profiles", "Description");

	}

	public void selectPendingApplicationAndApprove() {
		Common common = new Common(driver, test);
		sleep(3);
		chooseSubMenuFromLeftPanel("Applications", "");

		chooseOptionFromDropdown("Status", "Pending");
		common.searchListTorch();
		sleep(2);

		common.selectFirstRowNumberInSearchList();
		common.clickApproveIcon();

	}

	public void enterDetailsInNoteDetailsPopUp(String userName) {
		Common common = new Common(driver, test);

		validateCheckBoxToCheckOrUncheck("Diary Notes", "High Priority", "Checked");
		String shortNotes = fakerAPI().address().secondaryAddress();
		enterValueInTextBox("Diary Notes", "Short Note", shortNotes);

		String detailNotes = fakerAPI().address().fullAddress();
		enterValueInTextArea("Diary Notes", "Detailed Note", detailNotes);

		common.clickOkButton();

	}

	public void addNotesInApplicationMenu(String userName) {
		Common common = new Common(driver, test);

		chooseSubMenuFromLeftPanel("Notes", "");
		validateHeaderLabel("Notes");
		common.rightClick(tableContainer);
		common.addIteminPopup();
		validatePopupHeaderText("Note Details");
		enterDetailsInNoteDetailsPopUp(userName);
	}

	public void enterDetailsInAttachmentsPopup() {
		Common common = new Common(driver, test);
		String description = fakerAPI().name().title();
		enterValueInTextBox("Diary Notes", "Short Note", description);

		common.clickOkButton();
	}

	public void addStoredAttachmentInApplicationMenu() {
		Common common = new Common(driver, test);
		chooseSubMenuFromLeftPanel("Stored Attachments", "");
		validateHeaderLabel("Stored Attachments");
		common.rightClick(tableContainer);
		common.addIteminPopup();
		validatePopupHeaderText("Attachments");
		enterDetailsInAttachmentsPopup();

	}

	String text = fakerAPI().name().firstName();

	public void choosePricingFromCustomerProfile() {
		chooseSubMenuFromLeftPanel("Customer Profiles", "Pricing");
		validateHeaderLabel("Pricing");
		sleep(5);
	}

	public void createApplicationCustomerPricingProfile(String clientCountry) {
		Common common = new Common(driver, test);
		MaintainCustomerPage maintainCustomerPage = new MaintainCustomerPage(driver, test);

		common.rightClickAndCreatePrivateProfile(applicationCustomerPricingProfile);
		sleep(5);
		common.validateCheckBoxInTableAndDoubleClick("Available Profiles", "Private", "Description");
		sleep(5);
		validatePopupHeaderText("Pricing Profile Header Details");
		enterValueInTextBox("Details", "Description", text);
		sleep(5);
		int rownum = maintainCustomerPage.getRowNumberForSelectProfile("Available Profiles", "Private");
		maintainCustomerPage.rightClickAndSelectProfile("Available Profiles", rownum, "Description");
		sleep(5);
		maintainCustomerPage.validateCheckBoxInTable("Available Profiles", "Default");
		sleep(5);
		maintainCustomerPage.validateNewValueAddedInTheTableList("Available Profiles", "Description", text);

	}

	public void chooseCardControlFromCardProfile() {
		chooseSubMenuFromLeftPanel("Card Profiles", "Card Controls");
		validateHeaderLabel("Card Controls");
		sleep(5);
	}

	public void enterDetailsInApplicationCardControlsPopup() {
		Common common = new Common(driver, test);
		validatePopupHeaderText("Customer Card Control");
		enterValueInTextBox("Profile", "Description", text);
		sleep(3);
		common.chooseARandomDropdownOption("Product Restriction");
		common.chooseARandomDropdownOption("Time Limit");

		// common.chooseARandomDropdownOption("Trx Limit Amount Total");
		common.chooseARandomDropdownOption("Trx Limit Amount Fuel");
		// common.chooseARandomDropdownOption("Daily Limit Amount Total");
		common.chooseARandomDropdownOption("Daily Limit Amount Fuel");
		common.chooseARandomDropdownOption("Daily Limit No Of Trx");
		// common.chooseARandomDropdownOption("Weekly Limit Amount Fuel");
		common.chooseARandomDropdownOption("Monthly Limit Amount Total");
		common.chooseARandomDropdownOption("Monthly Limit Amount Fuel");

		enterValueInTextBox("Purchase Velocity Controls", "External Description", text);
		sleep(3);

		common.clickOkButton();
	}

	public void createCardControlProfile() {
		Common common = new Common(driver, test);
		MaintainCustomerPage maintainCustomerPage = new MaintainCustomerPage(driver, test);
		sleep(5);
		common.rightClick(cardControlProfile);
		common.addIteminPopup();
		validatePopupHeaderText("Card Control Profile");
		common.chooseARandomDropdownOption("Card Offer");
		common.chooseARandomDropdownOption("Card Product");
		common.clickOkButton();
		sleep(5);
		maintainCustomerPage.rightClickAndCreatePrivateProfile(applicationCardControlProfile);
		common.validateCheckBoxInTableAndDoubleClick("Available Profiles", "Private", "Description");
		enterDetailsInApplicationCardControlsPopup();
		sleep(2);
		int rownum = maintainCustomerPage.getRowNumberForSelectProfile("Available Profiles", "Private");
		maintainCustomerPage.rightClickAndSelectProfile("Available Profiles", rownum, "Description");
		sleep(5);

		maintainCustomerPage.validateCheckBoxInTable("Available Profiles", "Default");
		sleep(5);
		maintainCustomerPage.validateNewValueAddedInTheTableList("Available Profiles", "Description", text);

	}

	public String getCustomerNoAndSelectPricingProfile() {

		Common common = new Common(driver, test);
		String customerNo;
		common.clickValidateIcon();
		sleep(3);
		verifyValidationResult("Validation successful");
		sleep(3);
		chooseSubMenuFromLeftPanel("Customer Profiles", "Pricing");
		// int rownum = maintainCustomerPage.getRowNumberForSelectProfile("Available
		// Profiles", "Private");
		common.rightClickAndSelectProfileFirstApplication();

		common.clickSaveIcon();
		sleep(3);
		chooseSubMenuFromLeftPanel("Maintain Application", "");
		common.clickValidateIcon();
		sleep(3);
		verifyValidationResult("Validation successful");
		sleep(3);
		common.clickApproveIcon();
		sleep(3);
		verifyValidationResult("Application Approved");
		customerNo = common.getValueFromProtectedTextBox("Details", "Customer No");
		System.out.println(customerNo);

		return customerNo;
	}

	public void validateCustomerNoInCustomerDetails(String customerNo) {

		Common common = new Common(driver, test);
		common.chooseSubMenuFromLeftPanel("Customers", "");
		enterValueInTextBox("Filter By", "Customer No", customerNo);
		common.searchListTorch();
		sleep(2);
		List<WebElement> customerNoHeaders = driver.findElements(
				By.xpath("//div[@class='JViewport']/div[@class='JTableHeader']//div[@class='HeaderRenderer']"));
		int columnNo = SeleniumWrappers.getColumnNoForColumnHeader("Customer No", customerNoHeaders);
		System.out.println("*******columNo*****" + columnNo);

		int size;
		try {
			List<WebElement> list = driver
					.findElements(By.xpath("//div[@class='FALTableCellEditor_StrikeThruField JTextComponent']"));
			SeleniumWrappers.setTotalTableHeaders(customerNoHeaders.size());
			size = SeleniumWrappers.getTotalNumberOfRows(list, driver);
			System.out.println(size);
			for (int row = 0; row <= size; row++) {
				System.out.println(row + " " + columnNo);
				System.out.println(SeleniumWrappers.getTableDataWithRowAndColumnNumber(columnNo, row, driver));
				if (SeleniumWrappers.getTableDataWithRowAndColumnNumber(columnNo, row, driver).equals(customerNo)) {
					logPass("Customer number generated sucssfully");
					break;
				}
			}
		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
	}

	// Filtering application options by selecting valid values from the dropdowns
	public void applicationFilterOptionsForSG(String applicationTypeValue, String statusValue) {
		Common common = new Common(driver, test);

		validateLabelText("Application Type");
		chooseOptionFromDropdown("Application Type", "SG StarCard - Fleet");
		validateLabelText("Status");
		chooseOptionFromDropdown("Status", "Approved");
		// common.searchTorch();
		common.searchListTorch();
		sleep(3);
		common.selectFirstRowNumberInSearchList();

	}

	//updated by raxsana 25/06/2020
	
	public void applicationFilterOptions(String applicationTypeValue, String statusValue) {
		Common common = new Common(driver, test);
		validateLabelText("Application Type");
		chooseOptionFromDropdown("Application Type", applicationTypeValue);
		validateLabelText("Status");
		chooseOptionFromDropdown("Status", statusValue);
		// common.searchTorch();
		common.searchListTorch();
		sleep(3);
		common.selectFirstRowNumberInSearchList();
		if(applicationTypeValue.equalsIgnoreCase("PH StarCash - Customer")) {
			common.cloneRecord();
			sleep(3);
		}

	}
	
	//below commented methods are covered in above applicationFilterOptions method
	/*	// Application type for TH as TH StartCard-Staff
	public void applicationFilterOptions(String applicationTypeValue, String statusValue) {
		Common common = new Common(driver, test);
		validateLabelText("Application Type");
		chooseOptionFromDropdown("Application Type", "TH StarCard - Staff");
		validateLabelText("Status");
		chooseOptionFromDropdown("Status", "Approved");
		// common.searchTorch();
		common.searchListTorch();
		sleep(3);
		common.selectFirstRowNumberInSearchList();

	}

	// Application type for TH as PH StartCard-Fleet
	public void applicationFilterOptions(String applicationTypeValue, String statusValue) {
		Common common = new Common(driver, test);
		validateLabelText("Application Type");
		chooseOptionFromDropdown("Application Type", "PH StarCard - Fleet");
		validateLabelText("Status");
		chooseOptionFromDropdown("Status", "Approved");
		// common.searchTorch();
		common.searchListTorch();
		sleep(3);
		common.selectFirstRowNumberInSearchList();

	}

	// Application type for PH as PH StartCash-Customer
	public void applicationFilterOptions(String applicationTypeValue, String statusValue) {
		Common common = new Common(driver, test);
		validateLabelText("Application Type");
		chooseOptionFromDropdown("Application Type", "PH StarCash - Customer");
		validateLabelText("Status");
		chooseOptionFromDropdown("Status", "Approved");
		// common.searchTorch();
		common.searchListTorch();
		sleep(3);
		common.selectFirstRowNumberInSearchList();
		common.cloneRecord();
		sleep(3);

	}*/
	// Application Clone record

	public void applicationCloneRecord() {
		Common common = new Common(driver, test);
		common.cloneRecord();
		sleep(3);
		common.verifyContainsInBottomLeftMessage("Cloned record, not saved yet");
		List<WebElement> nameList = driver.findElements(By.xpath(
				"//div[@class='JFALSeparator']//div[text()='Details']/preceding::div[@class='JFALLabel']/div[text()='Name']/preceding::div[@class='JFALCompControlPanel'][1]//input"));
		System.out.println("Size: " + nameList.size());
		sleep(5);
		nameList.get(1).sendKeys(fakerAPI().name().firstName());
		enterValueInTextBox("Details", "Name", fakerAPI().name().firstName());
		sleep(5);
		switchTabDetails("Application-Account");
		enterValueInTextBox("Account Details", "Credit Limit", "0");
		common.clickSaveIcon();
		sleep(5);
	}

	// Application Clone record for PH

	public void applicationCloneRecordForPHStarCash() {

		Common common = new Common(driver, test);
		common.verifyContainsInBottomLeftMessage("Cloned record, not saved yet");
		List<WebElement> nameList = driver.findElements(By.xpath(
				"//div[@class='JFALSeparator']//div[text()='Details']/preceding::div[@class='JFALLabel']/div[text()='Name']/preceding::div[@class='JFALCompControlPanel'][1]//input"));
		System.out.println("Size: " + nameList.size());
		sleep(5);
		nameList.get(1).sendKeys(fakerAPI().name().firstName());
		enterValueInTextBox("Details", "Name", fakerAPI().name().firstName());
		chooseOptionFromDropdown("Dispatch Method", "Mail Direct to Card Holder");
		sleep(5);
		switchTabDetails("Business Details");
		chooseOptionFromDropdown("Industry Type", "Fleets - Bus and Truck");
		chooseOptionFromDropdown("Marketing Territory", "Card Sales Specialist 01");
		common.clickSaveIcon();
		sleep(5);
	}

	// To erase the details and create a new application by entering all the details
	// in the mandatory fields
	public void createNewApplicationForSG1(String name) {
		Common common = new Common(driver, test);
		common.clearForm();
		sleep(3);
		List<WebElement> nameList = driver.findElements(By.xpath(
				"//div[@class='JFALSeparator']//div[text()='Details']/preceding::div[@class='JFALLabel']/div[text()='Name']/preceding::div[@class='JFALCompControlPanel'][1]//input"));
		System.out.println("Size: " + nameList.size());
		sleep(5);
		nameList.get(1).sendKeys(fakerAPI().name().firstName());
		enterValueInTextBox("Details", "Name", fakerAPI().name().firstName());
		sleep(5);

		String address = fakerAPI().address().fullAddress() + "#";
		enterValueInTextArea("Addresses/Contacts", "Physical Address", address);
		switchTabDetails("Application-Account");
		// common.verifyAndClickingTabs("Application-Account","click");
		chooseOptionFromDropdown("Credit Plans", "Standard Plan");
		chooseOptionFromDropdown("Billing Plans", "Customer-initiated 45 days after invoice date");
		chooseOptionFromDropdown("Billing Frequency", "Bill End Of Month");
		chooseOptionFromDropdown("Account Cycle", "Bill End Of Month");
		// String creditLimit = fakerAPI().name().firstName();
		enterValueInTextBox("Account Details", "Credit Limit", "0");
		switchTabDetails("Business Details");
		chooseOptionFromDropdown("Business Type", "Company");
		chooseOptionFromDropdown("Industry Type", "Services");
		chooseOptionFromDropdown("Class of Buyer", "Card Reseller");
		chooseOptionFromDropdown("Admin Territory", "N/A");
		chooseOptionFromDropdown("Marketing Territory", "Card Sales Specialist 01");
		common.clickSaveIcon();
		sleep(5);

	}

	// To erase the details and create a new application by entering all the details
	// in the mandatory fields
	public void createNewApplicationForSG(String name) {
		Common common = new Common(driver, test);
		common.clearForm();
		sleep(3);
		List<WebElement> nameList = driver.findElements(By.xpath(
				"//div[@class='JFALSeparator']//div[text()='Details']/preceding::div[@class='JFALLabel']/div[text()='Name']/preceding::div[@class='JFALCompControlPanel'][1]//input"));
		System.out.println("Size: " + nameList.size());
		sleep(5);
		nameList.get(1).sendKeys(fakerAPI().name().firstName());
		enterValueInTextBox("Details", "Name", fakerAPI().name().firstName());
		sleep(5);

		String address = fakerAPI().address().fullAddress() + "#";
		enterValueInTextArea("Addresses/Contacts", "Physical Address", address);
		switchTabDetails("Application-Account");
		// common.verifyAndClickingTabs("Application-Account","click");
		chooseOptionFromDropdown("Credit Plans", "Standard Plan");
		chooseOptionFromDropdown("Billing Plans", "Customer-initiated 45 days after invoice date");
		chooseOptionFromDropdown("Billing Frequency", "Bill End Of Month");
		chooseOptionFromDropdown("Account Cycle", "Bill End Of Month");
		// String creditLimit = fakerAPI().name().firstName();
		enterValueInTextBox("Account Details", "Credit Limit", "0");
		switchTabDetails("Business Details");
		chooseOptionFromDropdown("Business Type", "Company");
		chooseOptionFromDropdown("Industry Type", "Services");
		chooseOptionFromDropdown("Class of Buyer", "Card Reseller");
		chooseOptionFromDropdown("Admin Territory", "CSC");
		chooseOptionFromDropdown("Marketing Territory", "CSC");
		common.clickSaveIcon();
		sleep(5);

	}

	// To add card offer for the application

	public void createCardOffersInApplication(String applicationType) {
		Common common = new Common(driver, test);
		chooseSubMenuFromLeftPanel("Maintain Application", "Card Offers");
		rightClick(cardOffersAdd);
		sleep(3);
		common.addIteminPopup();
		sleep(3);
		if (applicationType.contains("Discount Card - Taxi")) {
			chooseOptionFromDropdown("Card Offer", "Discount Card");
		} else if (applicationType.contains("Discount Card - Bus")) {
			chooseOptionFromDropdown("Card Offer", "Bus Diesel");
		} else {
			chooseOptionFromDropdown("Card Offer", "random");
		}
		chooseOptionFromDropdown("Default Card Product", "random");
		common.clickOkButton();
		sleep(5);
		common.clickSaveIcon();
		sleep(5);
		common.verifyValidationResult("Record saved OK");
	}

	
	//Updated done by raxsana on 25/06/2020
	
	public void createCardOffersInApplication(String cardOffer,String defaultCardProduct) {
		Common common = new Common(driver, test);
		chooseSubMenuFromLeftPanel("Maintain Application", "Card Offers");
		rightClick(cardOffersAdd);
		sleep(15);
		common.addIteminPopup();
		sleep(10);
		chooseOptionFromDropdown("Card Offer", cardOffer);
		chooseOptionFromDropdown("Default Card Product", defaultCardProduct);
		common.clickOkButton();
		sleep(5);
		common.clickSaveIcon();
		sleep(10);
	}
	//below commented methods are covered in above createCardOffersInApplication method
	
	// To add card offer for TH application Fleet
	/*public void createCardOffersInApplicationForTHFleet(String cardOffer,String defaultCardProduct) {
		Common common = new Common(driver, test);
		chooseSubMenuFromLeftPanel("Maintain Application", "Card Offers");
		rightClick(cardOffersAdd);
		sleep(5);
		common.addIteminPopup();
		sleep(5);
		chooseOptionFromDropdown("Card Offer", cardOffer);//"StarCard");
		chooseOptionFromDropdown("Default Card Product", defaultCardProduct);//"StarCard - Open");
		common.clickOkButton();
		sleep(5);
		common.clickSaveIcon();
		sleep(5);
	}

	// To add card offer for TH application Staff

	public void createCardOffersInApplicationForTHStaff(String cardOffer,String defaultCardProduct) {
		Common common = new Common(driver, test);
		chooseSubMenuFromLeftPanel("Maintain Application", "Card Offers");
		rightClick(cardOffersAdd);
		sleep(15);
		common.addIteminPopup();
		sleep(10);
		chooseOptionFromDropdown("Card Offer", "Personal");
		chooseOptionFromDropdown("Default Card Product", "StarCard Staff");
		common.clickOkButton();
		sleep(5);
		common.clickSaveIcon();
		sleep(10);
	}

	// To add card offer for PH application Fleet

	public void createCardOffersInApplicationForPHFleet(String cardOffer,String defaultCardProduct) {
		Common common = new Common(driver, test);
		chooseSubMenuFromLeftPanel("Maintain Application", "Card Offers");
		rightClick(cardOffersAdd);
		sleep(15);
		common.addIteminPopup();
		sleep(10);
		chooseOptionFromDropdown("Card Offer", "StarCard");
		chooseOptionFromDropdown("Default Card Product", "StarCard - Open");
		common.clickOkButton();
		sleep(5);
		common.clickSaveIcon();
		sleep(10);
	}

	// To add card offer for PH application StarCash Customer

	public void createCardOffersInApplicationForPHStarCashCustomer(String cardOffer,String defaultCardProduct) {
		Common common = new Common(driver, test);
		chooseSubMenuFromLeftPanel("Maintain Application", "Card Offers");
		rightClick(cardOffersAdd);
		sleep(15);
		common.addIteminPopup();
		sleep(10);
		chooseOptionFromDropdown("Card Offer", "StarCash");
		chooseOptionFromDropdown("Default Card Product", "StarCash - No initial value");
		common.clickOkButton();
		sleep(5);
		common.clickSaveIcon();
		sleep(10);
	}*/

	// To add pricing for Application
	public void addPricingInApplication() {
		Common common = new Common(driver, test);
		chooseSubMenuFromLeftPanel("Customer Profiles", "Pricing");
		common.rightClickAndSelectProfileFirstApplication();
		common.clickSaveIcon();
		common.verifyValidationResult("Record saved OK");
	}

	// To add "Card Controls" for Application

	public void addCardControlsInApplication() {
		Common common = new Common(driver, test);
		chooseSubMenuFromLeftPanel("Card Profiles", "Card Controls");
		rightClick(cardControlsAdd);
		sleep(5);
		common.addIteminPopup();
		sleep(3);
		chooseOptionFromDropdown("Card Offer", "random");
		chooseOptionFromDropdown("Card Product", "random");
		common.clickOkButton();
		common.rightClickAndSelectProfileFirstApplication();
		common.clickSaveIcon();
		sleep(5);
		common.verifyValidationResult("Record saved OK");
	}
	//updated by raxsana on 25/06/2020
	//below commented methods are covered in above addCardControlsInApplication method
	// To add "Card Controls" for TH Fleet
	/*public void addCardControlsForTHFleetApplication() {
		Common common = new Common(driver, test);
		chooseSubMenuFromLeftPanel("Card Profiles", "Card Controls");
		rightClick(cardControlsAdd);
		sleep(15);
		common.addIteminPopup();
		sleep(10);
		chooseOptionFromDropdown("Card Offer", "StarCard");
		chooseOptionFromDropdown("Card Product", "StarCard - Open");
		common.clickOkButton();
		sleep(5);
		common.rightClickAndSelectProfileForApplication("Available Profiles", 0, 2);
		common.clickSaveIcon();
		sleep(10);
	}

	// To add "Card Controls" for PH StarCash
	public void addCardControlsForPHStarCashApplication() {
		Common common = new Common(driver, test);
		chooseSubMenuFromLeftPanel("Card Profiles", "Card Controls");
		rightClick(cardControlsAdd);
		sleep(15);
		common.addIteminPopup();
		sleep(10);
		chooseOptionFromDropdown("Card Offer", "StarCash");
		chooseOptionFromDropdown("Card Product", "StarCash - No initial value");
		common.clickOkButton();
		sleep(5);
		common.rightClickAndSelectProfileForApplication("Available Profiles", 0, 2);
		common.clickSaveIcon();
		sleep(10);
	}

	// To add "Card Controls" for TH Staff
	public void addCardControlsForTHStaffApplication() {
		Common common = new Common(driver, test);
		chooseSubMenuFromLeftPanel("Card Profiles", "Card Controls");
		rightClick(cardControlsAdd);
		sleep(15);
		common.addIteminPopup();
		sleep(10);
		chooseOptionFromDropdown("Card Offer", "Personal");
		chooseOptionFromDropdown("Card Product", "StarCard Staff");
		common.clickOkButton();
		sleep(5);
		common.rightClickAndSelectProfileForApplication("Available Profiles", 0, 2);
		common.clickSaveIcon();
		sleep(10);
	}*/
	// To select "Card Reissue profiles" from card profiles

	public void addCardReissueProfiles() {
		Common common = new Common(driver, test);
		chooseSubMenuFromLeftPanel("Card Profiles", "Card Reissue Profiles");
		common.rightClickAndSelectProfileFirstApplication();
		common.clickSaveIcon();
		sleep(5);
		verifyValidationResult("Record saved OK");

	}

	// To validate opt-in/opt-out in Rebates section
	public void validateRebatesInApplication() {
		Common common = new Common(driver, test);
		chooseSubMenuFromLeftPanel("Customer Profiles", "Rebates");
		common.rightClickAndOptInout("Rebate Profiles", "Private");
		sleep(5);
		common.validateCheckBoxInTable("Rebate Profiles", "Opted Out");
		common.clickSaveIcon();
		common.clickOkButton();
	}

// To save and create the application
	public void validateAndCreateApplication() {
		Common common = new Common(driver, test);
		chooseSubMenuFromLeftPanel("Maintain Application", "");
		common.clickSaveIcon();
		sleep(5);
		verifyValidationResult("Record saved OK");
		common.clickValidateIcon();
		verifyValidationResult("Validation successful");
		common.clickApproveIcon();
		verifyValidationResult("Application Approved");
		String accountNumber=getValueFromTextBox("Details","Customer No");
		String methodName = Thread.currentThread().getStackTrace()[2].getMethodName();
		common.writeDataInPropertyFile("accNo_"+methodName+"_"+PropUtils.getPropValue(configProp, "clientCountry"),accountNumber,"chevronEndToEndTemplateFile.Properties");
		}

	// To save and create the application
	public void validateAndCreateApplication(String applicationType) {
		Common common = new Common(driver, test);
		chooseSubMenuFromLeftPanel("Maintain Application", "");
		common.clickSaveIcon();
		sleep(5);
		verifyValidationResult("Record saved OK");
		common.clickValidateIcon();
		verifyValidationResult("Validation successful");
		common.clickApproveIcon();
		verifyValidationResult("Application Approved");
		String accountNumber=getValueFromTextBox("Details","Customer No");
		common.writeDataInPropertyFile("cusNo_"+applicationType.replaceAll(" ", "").replaceAll("-", "_")+"_"+PropUtils.getPropValue(configProp, "clientCountry"),accountNumber,"chevronEndToEndTemplateFile.Properties");
	}

	// To save and create the application
	public void validateAndCreateApplicationForClonedRecord() {
		Common common = new Common(driver, test);
		chooseSubMenuFromLeftPanel("Maintain Application", "");
		sleep(5);
		String address = fakerAPI().address().fullAddress() + "#";
		enterValueInTextArea("Addresses/Contacts", "Physical Address", address);
		common.clickSaveIcon();
		sleep(5);
		// common.verifyValidationResult("Record saved OK");
		common.clickValidateIcon();
		verifyValidationResult("Validation successful");
		common.clickApproveIcon();
		sleep(5);

	}

	// Method to verify account details for Application
	public void validateAccountDetailsForApplication() {
		Common common = new Common(driver, test);
		chooseOptionFromDropdown("Billing Plan", "Customer-initiated Prepaid");
		chooseOptionFromDropdown("Billing Frequency", "Bill Monthly on 25th");
		chooseOptionFromDropdown("Account Cycle", "Bill Monthly on 25th");
		chooseOptionFromDropdown("Credit Plan", "StarCash Customer");
		common.clickSaveIcon();
		sleep(5);
	}

	// Method to add tax status in Account details
	public void addTaxDetailsForAccount(String userName) {
		Common common = new Common(driver, test);
		String ifcsDate;
		ifcsDate = common.getCurrentIFCSDate(userName);
		chooseSubMenuFromLeftPanel("Maintain Account", "Tax Status");
		rightClick(taxStatusAccount);
		common.addIteminPopup();
		chooseOptionFromDropdown("Tax Type", "Customer Withholding Tax");
		chooseOptionFromDropdown("Status", "Government");
		enterValueInTextBox("Tax Status", "Effective On", ifcsDate);
		common.clickOkButton();
		common.clickSaveIcon();
		sleep(5);
	}

	// To erase the details and create a new application by entering all the details
	// in the mandatory fields
	public void createNewApplicationForPH(String name) {
		Common common = new Common(driver, test);
		common.clearForm();
		sleep(3);
		List<WebElement> nameList = driver.findElements(By.xpath(
				"//div[@class='JFALSeparator']//div[text()='Details']/preceding::div[@class='JFALLabel']/div[text()='Name']/preceding::div[@class='JFALCompControlPanel'][1]//input"));
		System.out.println("Size: " + nameList.size());
		sleep(5);
		nameList.get(1).sendKeys(fakerAPI().name().firstName());
		enterValueInTextBox("Details", "Name", fakerAPI().name().firstName());
		sleep(5);

		String address = fakerAPI().address().fullAddress() + "#";
		enterValueInTextArea("Addresses/Contacts", "Physical Address", address);
		switchTabDetails("Application-Account");
		// common.verifyAndClickingTabs("Application-Account","click");
		chooseOptionFromDropdown("Credit Plans", "Standard Plan");
		chooseOptionFromDropdown("Billing Plans", "Customer-initiated 45 days after invoice date");
		chooseOptionFromDropdown("Billing Frequency", "Bill End Of Month");
		chooseOptionFromDropdown("Account Cycle", "Bill End Of Month");
		// String creditLimit = fakerAPI().name().firstName();
		enterValueInTextBox("Account Details", "Credit Limit", "0");
		switchTabDetails("Business Details");
		chooseOptionFromDropdown("Business Type", "Company");
		chooseOptionFromDropdown("Industry Type", "Services");
		chooseOptionFromDropdown("Class of Buyer", "Card Reseller");
		chooseOptionFromDropdown("Admin Territory", "N/A");
		chooseOptionFromDropdown("Marketing Territory", "Card Sales Specialist 01");
		common.clickSaveIcon();
		sleep(5);

	}

	// Method to add tax status in Account details
	public void addTaxDetailsForAccountStatusLargeCompany(String userName) {
		Common common = new Common(driver, test);
		String currentIFCSDate;
		chooseSubMenuFromLeftPanel("Maintain Account", "Tax Status");
		rightClick(cardControlsAdd);// (accountTaxStatus);
		common.addIteminPopup();
		chooseOptionFromDropdown("Tax Type", "Customer Withholding Tax");
		chooseOptionFromDropdown("Status", "Large Company");
		currentIFCSDate = common.getCurrentIFCSDate(userName);
		enterValueInTextBox("Tax Status", "Effective On", currentIFCSDate);
		common.clickOkButton();
		// common.clickSaveIcon();
		sleep(5);
	}

	// Method to add tax status in Account details
	public void addTaxDetailsForAccountStatusWVATGovt(String userName) {
		Common common = new Common(driver, test);
		String currentIFCSDate;
		chooseSubMenuFromLeftPanel("Maintain Account", "Tax Status");
		rightClick(cardControlsAdd);// (accountTaxStatus);
		common.addIteminPopup();
		chooseOptionFromDropdown("Tax Type", "Withheld VAT");
		chooseOptionFromDropdown("Status", "Government");
		currentIFCSDate = common.getCurrentIFCSDate(userName);
		enterValueInTextBox("Tax Status", "Effective On", currentIFCSDate);
		common.clickOkButton();
		sleep(5);
		// common.clickSaveIcon();
		sleep(5);
	}

	// Prakalpha

	public void verifyNewApplicationToApprove() {
		Common common = new Common(driver, test);
		chooseSubMenuFromLeftPanel("Maintain Application", "");
		common.clickSaveIcon();
		sleep(3);
		verifyValidationResult("Record saved OK");
		common.clickValidateIcon();
		sleep(3);
		verifyValidationResult("Validation successful");
		common.clickApproveIcon();
		sleep(3);
		verifyValidationResult("Application Approved");
	}

	public void createCardOfferForNewApplication(String clientCountry) {
		Common common = new Common(driver, test);

		chooseSubMenuFromLeftPanel("Maintain Application", "Card Offers");
		validateHeaderLabel("Card Offers");
		sleep(5);
		rightClick(cardOfferTable);
		common.addIteminPopup();
		enterDetailsInCardOfferPopup(clientCountry + " Fleet Card");
		sleep(5);
		if (clientCountry.equals("SG")) {
			rightClick(cardOfferTable);
			common.addIteminPopup();
			enterDetailsInCardOfferPopup(clientCountry + " Fleet Contactless Card");
		}
		common.clickSaveIcon();
		sleep(3);
		verifyValidationResult("Record saved OK");
	}

	public void enterDetailsInCardOfferPopup(String option) {
		Common common = new Common(driver, test);
		String clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		validatePopupHeaderText("Card Offers");
		sleep(5);
		System.out.println(option);
		chooseOptionFromDropdown("Card Offer", option);
		if (clientCountry.equals("HK")) {
			chooseOptionFromDropdown("Default Card Product", "random");
		}
		sleep(5);
		common.clickOkButton();
		sleep(2);
	}

	public void pricingProfileSetDefaultForNewApplication() {
		Common common = new Common(driver, test);
		maintainCustomerPage.rightClickAndSelectProfile("Available Profiles", 0, "Description");
		sleep(5);
		common.clickSaveIcon();
		sleep(3);
		verifyValidationResult("Record saved OK");
	}

	public void reissueProfileSetDefaultForNewApplication() {
		Common common = new Common(driver, test);
		maintainCustomerPage.rightClickAndSelectProfile("Card Reissue Profiles", 0, "Description");
		sleep(5);
		common.clickSaveIcon();
		sleep(3);
		verifyValidationResult("Record saved OK");
	}

	public void createNewApplicationForBP(String applicationType,String clientCountry) {
		Common common=new Common(driver,test);
		//chooseOptionFromDropdown("Application Type",applicationType);
		//common.selectACountryFromDropdown(1,"Country");
		//String address = fakerAPI().address().fullAddress() + "#";
		//enterValueInTextArea("Addresses/Contacts", "Physical Address", address );
		sleep(3);
		//common.enterPostalcodefromApplication("Addresses/Contacts", "Post Code", "9260",1 );
		if(clientCountry.equals("AU")) {
			common.enterPostalcodefromApplication("Addresses/Contacts", "Suburb",  fakerAPI().name().firstName(),1);
			common.selectAStateFromDropdown(1,"State");			
		}
		/*switchTabDetails("Application-Account"); 
		//common.verifyAndClickingTabs("Application-Account","click");
		common.chooseARandomDropdownOption("Customer Type");
		common.chooseARandomDropdownOption("Credit Plans");    
		//common.chooseARandomDropdownOption("Billing Plans");
		common.chooseARandomDropdownOption("Billing Frequency");
		common.chooseARandomDropdownOption("Account Cycle");
		//String creditLimit = fakerAPI().name().firstName();
		enterValueInTextBox("Account Details", "Credit Limit", "10000" );
		common.chooseARandomDropdownOption("GL Channel");
		switchTabDetails("Business Details");
		common.chooseARandomDropdownOption("Business Type");    
		common.chooseARandomDropdownOption("Industry Type");
		common.chooseARandomDropdownOption("Class of Buyer");
		common.chooseARandomDropdownOption("Admin Territory");
		common.chooseARandomDropdownOption("Marketing Territory");
		WebElement comboDropDown = null;
		JavascriptExecutor js = (JavascriptExecutor)driver;
		comboDropDown = driver.findElement(By.xpath("//div[@class='JFALLabel']//div[contains(text(),'Mobile')]//preceding::div[@class='JFALCompControlPanel'][1]/div[@class='JFALComboBox']//div[@class='MetalComboBoxButton enabled JButton']"));
		js.executeScript("arguments[0].scrollIntoView(true);", comboDropDown);		
		sleep(3);
		common.chooseARandomDropdownOption("Mobile Provisioning");	
		sleep(3);
		common.clickSaveIcon();
		sleep(5);*/

	}

	public void createCardOffersInApplicationForBP() {
		Common common = new Common(driver, test);
		chooseSubMenuFromLeftPanel("Maintain Application", "Card Offers");
		rightClick(cardOffersAdd);
		sleep(15);
		common.addIteminPopup();
		sleep(10);
		common.chooseARandomDropdownOption("Card Offer");
		common.chooseARandomDropdownOption("Default Card Product");
		common.clickOkButton();
		sleep(5);
		common.clickSaveIcon();
		sleep(10);

	}
	
	public void createNewApplicationInformationForCHV(String name) {
		Common common = new Common(driver, test);
		common.clearForm();
		sleep(3);
		chooseOptionFromDropdown("Application Type", "MY StarCard - Fleet");
		sleep(2);
		List<WebElement> nameList = driver.findElements(By.xpath(
				"//div[@class='JFALSeparator']//div[text()='Details']/preceding::div[@class='JFALLabel']/div[text()='Name']/preceding::div[@class='JFALCompControlPanel'][1]//input"));
		System.out.println("Size: " + nameList.size());
		sleep(5);
		nameList.get(1).sendKeys(fakerAPI().name().firstName());
		enterValueInTextBox("Details", "Name", fakerAPI().name().firstName());
		sleep(5);

		String address = fakerAPI().address().fullAddress() + "#";
		enterValueInTextArea("Addresses/Contacts", "Physical Address", address);		
		common.clickSaveIcon();
		sleep(5);

	}

	public void createNewApplicationForChevron(String applicationType) {
		Common common = new Common(driver, test);
		common.clearForm();
		sleep(3);
		List<WebElement> nameList = driver.findElements(By.xpath(
		"//div[@class='JFALSeparator']//div[text()='Details']/preceding::div[@class='JFALLabel']/div[text()='Name']/preceding::div[@class='JFALCompControlPanel'][1]//input"));
		System.out.println("Size: " + nameList.size());
		sleep(5);
		nameList.get(1).sendKeys(fakerAPI().name().firstName());
		enterValueInTextBox("Details", "Name", fakerAPI().name().firstName());
		chooseOptionFromDropdown("Application Type", applicationType);
		sleep(5);

		String address = fakerAPI().address().fullAddress() + "#";
		enterValueInTextArea("Addresses/Contacts", "Physical Address", address);
		common.selectACountryFromDropdown(1,"Country");
		switchTabDetails("Application-Account");
		
		// Checkbox
		sleep(3);
		common.checkBoxForApplicationDummy("Promotional Material");
		common.checkBoxForApplicationDummy("Electronic Marketing");
		fillBillingAndCreditPlanDetails(applicationType);
		driver.navigate().refresh();
		chooseOptionFromDropdown("Account Cycle","random");
		sleep(1);
		driver.navigate().refresh();
		sleep(1);
		if(!(applicationType.contains("StarCard - Debit") || applicationType.contains("StarCash - Chevron") || applicationType.contains("StarCash - Customer"))) {
			String creditLimit = fakerAPI().number().digits(3);
			enterValueInTextBox("Account Details", "Credit Limit", creditLimit);
		}
		switchTabDetails("Business Details");
		chooseOptionFromDropdown("Business Type", "random");
		chooseOptionFromDropdown("Industry Type", "random");
		chooseOptionFromDropdown("Class of Buyer", "random");
		chooseOptionFromDropdown("Admin Territory", "random");
		chooseOptionFromDropdown("Marketing Territory", "random");
		chooseOptionFromDropdown("Financial Year End", "random");
		common.switchTabDetails("Application Checks");
		common.chooseRandomCheckbox();
		common.clickSaveIcon();
		verifyValidationResult("Record saved OK");
		}
	
	public void fillBillingAndCreditPlanDetails(String applicationType) {
		String clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		String clientName= PropUtils.getPropValue(configProp, "clientName");
		if (applicationType.contains("Discount Card")) {
			chooseOptionFromDropdown("Credit Plans", "Discount Card Customer");
			sleep(2);
			driver.navigate().refresh();
			chooseOptionFromDropdown("Billing Plans", "Discount Card Customer");
			sleep(2);
		} else if (applicationType.contains("Debit")) {
			chooseOptionFromDropdown("Credit Plans", "Starcash Customer");
			sleep(2);
			driver.navigate().refresh();
			chooseOptionFromDropdown("Billing Plans", "Customer-initiated 1 month after invoice date");
			sleep(2);
		} else {
			chooseOptionFromDropdown("Credit Plans", "Standard Plan");
			sleep(2);
			driver.navigate().refresh();
			if(clientCountry.equals("TH")) {
				chooseOptionFromDropdown("Billing Plans", "Customer-initiated 30 days after invoice date");
			}
			else {
				chooseOptionFromDropdown("Billing Plans", "Customer-initiated 1 month after invoice date");
			}
			sleep(1);
		}
		if(clientName.equalsIgnoreCase("WFE")) {
			chooseOptionFromDropdown("Billing Frequency","Invoice Monthly");
		}else {
		chooseOptionFromDropdown("Billing Frequency","Bill End of Month");
		}
	}

	public void createCardOffersInApplication() {
		Common common = new Common(driver, test);
		chooseSubMenuFromLeftPanel("Maintain Application", "Card Offers");
		rightClick(cardOffersAdd);
		sleep(3);
		common.addIteminPopup();
		sleep(3);
		ajaxswingDropdownSelection("Card Offer", "random");
		sleep(3);
		ajaxswingDropdownSelection("Default Card Product", "random");
		sleep(3);
		common.clickOkButton();
		sleep(3);
		common.clickSaveIcon();
		sleep(5);
		common.verifyValidationResult("Record saved OK");
	}
	
	/**
	 * Add Card Offers for Application
	 */
	public void createCardOffersInApplicationAndDontSave() {
		Common common = new Common(driver, test);
		chooseSubMenuFromLeftPanel("Maintain Application", "Card Offers");
		rightClick(cardOffersAdd);
		sleep(15);
		common.addIteminPopup();
		sleep(10);
		chooseOptionFromDropdown("Card Offer", "random");
		chooseOptionFromDropdown("Default Card Product", "random");
		common.clickOkButton();
		sleep(5);
		common.clickSaveIcon();
		sleep(10);
	}


	/**
	 * Get Random Application and Clone
	 */
	public void searchRandomApplicationWithApprovedStatusAndClone() {
		Common common = new Common(driver, test);
		validateLabelText("Application Type");
		chooseOptionFromDropdown("Application Type", "random");
		validateLabelText("Status");
		chooseOptionFromDropdown("Status", "Approved");
		// common.searchTorch();
		common.searchListTorch();
		sleep(3);
		common.selectFirstRowNumberInSearchList();
		common.cloneRecord();
		sleep(3);

	}
	/**
	 * Add details in the Cloned application
	 */
	public void applicationCloneRecordAndProvideDetails() {

		Common common = new Common(driver, test);
		common.verifyContainsInBottomLeftMessage("Cloned record, not saved yet");
		List<WebElement> nameList = driver.findElements(By.xpath(
				"//div[@class='JFALSeparator']//div[text()='Details']/preceding::div[@class='JFALLabel']/div[text()='Name']/preceding::div[@class='JFALCompControlPanel'][1]//input"));
		System.out.println("Size: " + nameList.size());
		sleep(5);
		nameList.get(1).sendKeys(fakerAPI().name().firstName());
		enterValueInTextBox("Details", "Name", fakerAPI().name().firstName());
		chooseOptionFromDropdown("Mail Indicator", "random");
		sleep(5);
		switchTabDetails("Business Details");
		chooseOptionFromDropdown("Industry Type", "random");
		chooseOptionFromDropdown("Marketing Territory", "random");
		common.switchTabDetails("Application Checks");
		common.chooseRandomCheckbox();
		common.clickSaveIcon();
		sleep(5);
		verifyValidationResult("Record saved OK");

	}
	/**
	 * Validate current application status
	 * @param details
	 * @param currentStatus
	 * @param expValue
	 */
	public void validateApplicationStatus(String details, String currentStatus, String expValue) {
		verifyTextInDropDownForProtected(details, currentStatus, expValue);

	}


	/**
	 * Add details in the Cloned application
	 */
	public void applicationCloneRecordAndProvideDetails(String clientName) {

		Common common = new Common(driver, test);
		common.verifyContainsInBottomLeftMessage("Cloned record, not saved yet");
		List<WebElement> nameList = driver.findElements(By.xpath(
				"//div[@class='JFALSeparator']//div[text()='Details']/preceding::div[@class='JFALLabel']/div[text()='Name']/preceding::div[@class='JFALCompControlPanel'][1]//input"));
		System.out.println("Size: " + nameList.size());
		sleep(5);
		nameList.get(1).sendKeys(fakerAPI().name().firstName());
		enterValueInTextBox("Details", "Name", fakerAPI().name().firstName());
		if(clientName.equals("WFE")) {
			chooseOptionFromDropdown("Mail Indicator", "random");
		}
		sleep(5);
		switchTabDetails("Business Details");
		chooseOptionFromDropdown("Industry Type", "random");
		chooseOptionFromDropdown("Marketing Territory", "random");
		common.switchTabDetails("Application Checks");
		common.chooseRandomCheckbox();
		common.clickSaveIcon();
		sleep(5);
		verifyValidationResult("Record saved OK");

	}


	/**
	 * Validate current application status
	 * @param details
	 * @param currentStatus
	 * @param expValue
	 */
	public void validateApplicationStatus(String clientName, String details, String currentStatus, String status) {
		if(clientName.equalsIgnoreCase("WFE")) {
			verifyTextInDropDownForProtected(details, currentStatus, "New Application");
		}else {
			verifyTextInDropDownForProtected(details, currentStatus, status);
		}
	}
	

		/**
		 * Save cloned record and validate
		 */
		public void validateApplicationForClonedRecord() {
			Common common = new Common(driver, test);
			chooseSubMenuFromLeftPanel("Maintain Application", "");
			sleep(5);
			String address = fakerAPI().address().fullAddress() + "#";
			enterValueInTextArea("Addresses/Contacts", "Physical Address", address);
			common.clickSaveIcon();
			sleep(5);
			common.clickValidateIcon();
			verifyValidationResult("Validation successful");
			sleep(5);

		}
		
		/*
		 * Added by raxsana	
		 */
		/**
		 * @param labelName
		 */
		public void searchApplicationFilters(String labelName) {
			Common common = new Common(driver, test);
			String clientName=PropUtils.getPropValue(configProp, "clientName");
			String clientCountry=PropUtils.getPropValue(configProp, "clientCountry");
			String marketingValue=null;
			if(labelName.equalsIgnoreCase("Marketing Territory")) {		
				String queryToGetCustomerValues=" select tt.description from applications ap\r\n" +  
						" inner join territories tt on tt.territory_oid = ap.marketing_territory_oid\r\n" + 
						" where ap.client_mid=(select client_mid from m_clients where name='"+PropUtils.getPropValue(configProp, clientName+"_"+clientCountry)+"')";
				marketingValue=connectDBAndGetValue(queryToGetCustomerValues,PropUtils.getPropValue(configProp, "sqlODSServerName"));
			}
			chooseSubMenuFromLeftPanel("Applications", "");
			validateHeaderLabel("Viewer");
			if(labelName.equalsIgnoreCase("Marketing Territory")) {
			common.chooseOptionFromDropdown(labelName,marketingValue);}
			else {
			common.chooseARandomDropdownOption(labelName);}
			common.searchListTorch();
			sleep(3);
			verifyValidationResult("Record Read OK - Page Size");
			chooseBlankOptionFromDropdown(labelName);
		}


	

}
