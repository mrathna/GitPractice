﻿using AventStack.ExtentReports;
using Common;
using Common.Utility;
using EnCompass.Testing.Source.PageObjects.Controls;
using NFluent;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Support.UI;

namespace EnCompass.Testing.Source.PageObjects.Organization.Admin.MccGroupProfiles
{
    public partial class Cards
    {
        #region XPath page Elements

        private const string _searchTermXPath = @"//select[contains(@id, 'searchTermSelect')]";
        private const string _filterTypeXPath = @"//div[contains(@id, 'SearchOutput')]/select[2]";
        private const string _searchValueXPath = @"//input[contains(@id, 'SearchOutput_txt')]";
        private const string _searchCriteriaAddBtnXPath = @"//input[@type='button' and @value='Add']";
        private const string _searchBtnXPath = @"//input[contains(@id, 'btnSearch')]";
        private const string _selectCardProfileUserXPath = @"//select[contains(@id, '_DdlIncludeExcludeProfiles')][1]";
        private const string _saveButtonXPath = @"//input[@value = 'Save']";
        private const string _addTemporaryMCCGProfilesXPath = @"//a[contains(@id, 'actionLink0') and normalize-space(text()) ='Add Temporary Profiles']";
        private const string _successMessageXPath = "//div[contains(@id,'SuccessMessage')]";

        public const string _temporaryMCCGProfileModalIframe = @"//iframe[contains(@src,'AddTempMccgProfiles')]";
        #endregion

        #region Page Elements
        private IWebElement _searchTerm
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_searchTermXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_searchTerm element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _filterType
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_filterTypeXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_filterType element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _searchValue
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_searchValueXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_searchValue element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _searchCriteriaAddBtn
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_searchCriteriaAddBtnXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_searchCriteriaAddBtn element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _searchBtn
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_searchBtnXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_searchBtn element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _selectCardProfileUser
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_selectCardProfileUserXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_selectCardProfileUser element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _saveButton
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_saveButtonXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_saveButton element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _addTemporaryMCCGProfiles
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_addTemporaryMCCGProfilesXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_addTemporaryMCCGProfiles element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        #endregion

        // Grid control for the MCCG profiles Grid
        private GridControl _accountsGrid = null;
		public GridControl AccountsGrid
		{
			get
			{
				_accountsGrid = (_accountsGrid == null) ? new GridControl("_dgAccounts", Driver) : _accountsGrid;
				return _accountsGrid;
			}
		}

        public string SelectCardProfileUser
        {
           
            get { return new SelectElement(_selectCardProfileUser).SelectedOption.Text; }
            set {_selectCardProfileUser.SetListboxByText(value);  }
        }

        public void Add() { _searchCriteriaAddBtn.JSClickWithFocus(Driver);}

        public void SaveBtn() { _saveButton.JSClickWithFocus(Driver); this.AttachOnDemandScreenShot(); }

        public void SearchBtn()
        { _searchBtn.JSClickWithFocus(Driver);
          WaitForLoad();
        }

       public void scrollToBottom()
        {
            Driver.JsScrollToBottom();
        }
        public void AddTemporaryMCCGProfiles()
        {
            WaitForLoad();
            _addTemporaryMCCGProfiles.JSClickWithFocus(Driver);
        }

        private GridControl _cardProfileAssignment;

        public GridControl CardProfileAssignment
        {
            get
            {
                return _cardProfileAssignment ?? (_cardProfileAssignment = new GridControl("dgAccounts", Driver));
            }
        }

        public string GetSuccessMessage()
        {
            return Settings.EnCompassWebDriver.WaitForVisible(By.XPath(_successMessageXPath)).GetAttribute("innerText");
        }

        public string SearchTerm
        {
            get { return new SelectElement(_searchTerm).SelectedOption.Text; }
            set { _searchTerm.SetListboxByText(value); }
        }

        public string SearchValue
        {
            set
            {
                _searchValue.Clear();
                _searchValue.SendKeys(value);
            }
        }

        public string FilterType
        {
            get { return new SelectElement(_filterType).SelectedOption.Text; }
            set { _filterType.SetListboxByText(value); }
        }

        public void AddCardSearchItem(string searchTerm, string searchValue)
        {
            SearchTerm  = searchTerm;
            SearchValue = searchValue;
            this.Add();
        }

        public void SaveCardProfileAssignment()
        {
            WaitForLoad();
            this.SaveBtn();
            ConfirmOnModal();
			this.AttachOnDemandScreenShot();
		}

        public void WaitForTemporaryMCCGProfileModalIFrame()
        {
            Driver.WaitForVisible(By.XPath(_temporaryMCCGProfileModalIframe));
        }

        public TemporaryMCCGProfileModalIframe GetTemporaryMCCGProfileIframe
        {
            get
            {
                using (FrameHelper helper = new FrameHelper(Settings.EnCompassWebDriver, By.XPath(_temporaryMCCGProfileModalIframe)))
                {
                    return new TemporaryMCCGProfileModalIframe(helper, Settings);
                }
            }
        }

        /// <summary>
        /// Adding a seperate class for Each Iframe embedded within this Page Object model
        /// </summary>
        public class TemporaryMCCGProfileModalIframe : Cards
        {
            FrameHelper _helper;
            public const string _includeExcludeProfiles = @"//select[contains(@id, 'ctEditTemporaryMccgProfile')]";
            public const string _tbEmptyStartDate = @"//input[contains(@id, 'tbEmptyStartDate')]";
            public const string _tbEmptyEndDate = @"//input[contains(@id, 'tbEmptyEndDate')]";
            public const string _btnSave = @"//input[contains(@id, 'btnSave') and contains(@onclick,'btnSave')]";
            public const string _btnEmptyAdd = @"//input[contains(@id, 'btnEmptyAdd')]";
            public const string _btnConfirm = @"//input[contains(@id, 'btnConfirm')]";
            public const string _btnClose = @"//input[contains(@id, 'btnClose')]";
            public const string _btnSaveDisable = "//input[contains(@id,'btnSave') and @disabled='disabled']";

            public string IncludeExcludeProfiles
            {
                set
                {
                    SelectElement IncludeExcludeProfiles = new SelectElement(_helper.FindElement(By.XPath(_includeExcludeProfiles)));
                    IncludeExcludeProfiles.SelectByText(value);
                }
            }

            public void Save()
            {
                _helper.FindElement(By.XPath(_btnSave)).JSClickWithFocus(Driver);
				this.AttachOnDemandScreenShot();
			}

            public void Confirm()
            {
                _helper.FindElement(By.XPath(_btnConfirm)).JSClickWithFocus(Driver);
            }

            public void Close()
            {
                _helper.FindElement(By.XPath(_btnClose)).JSClickWithFocus(Driver);
            }

            public void EmptyAdd()
            {
                _helper.FindElement(By.XPath(_btnEmptyAdd)).JSClickWithFocus(Driver);
            }

            public string EmptyStartDate
            {
                set
                {
                    _helper.FindElement(By.XPath(_tbEmptyStartDate)).SendKeys(value);
                }
            }

            public string EmptyEndDate
            {
                set
                {
                    _helper.FindElement(By.XPath(_tbEmptyEndDate)).SendKeys(value);
                }
            }

            public void SetTemporaryMCCGProfile(string startDate, string endDate, string temporaryMCCGProfile, string sucessMessage, ExtentTest test)
            {
                EmptyStartDate = startDate;
                test.Info("Set the start Date to MCCG Profile Temporary via MCCG Profiles by Card");
                EmptyEndDate = endDate;
                test.Info("Set the end Date to MCCG Profile Temporary via MCCG Profiles by Card");
                IncludeExcludeProfiles = temporaryMCCGProfile;
                test.Info("Select MCCG Profile Temporary to apply via MCCG Profiles by Card");
                EmptyAdd();
                test.Info("Press button Add");
                Save();
                test.Info("Press button Save");
                Confirm();
                test.Info("Press button Confirm");
                Settings.EnCompassWebDriver.WaitForVisible(By.XPath(_btnSaveDisable));
                this.RefreshModel();
            }

           

            public TemporaryMCCGProfileModalIframe(FrameHelper helper, GlobalSettings settings) : base(settings)
            { _helper = helper; }
        }
    }
}
