using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using Common;
using Common.PageObjects;
using Common.ScenarioConfigurations;
using Common.Utility;

namespace EnCompass.Testing.Source.PageObjects.Organization.ExpenseManager.AllocationManagement 
{
	/// <summary>
	/// Auto-generated Page Model Class
	/// Navigation Paths: 
		/// [Organization Home]->Transactions->Financial Codes
		/// [Organization Home]->Transactions->Financial Codes->Create or Edit
		/// </summary>
	[PageModel(@"/expenseManager/allocationManagement/AllocationCodes.aspx")]
	public partial class AllocationCodes : EnCompassOrgPageModel 
	{
		public override string RelativeUrl => @"/expenseManager/allocationManagement/AllocationCodes.aspx";
		public override string PageIdentifierXPath_Generated => @"//li[contains(@class, 'breadcrumb-item active')][text() = 'Create or Edit']";

		#region Navigation
				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Create or Edit']")]
		private IWebElement _transactions_FinancialCodes_CreateOrEdit { get; set; }
		public void NavigateTo_Transactions_FinancialCodes_CreateOrEdit()
		{
			NavigateToMenuItem(_transactions_FinancialCodes_CreateOrEdit);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Profiles']")]
		private IWebElement _transactions_FinancialCodes_Profiles { get; set; }
		public void NavigateTo_Transactions_FinancialCodes_Profiles()
		{
			NavigateToMenuItem(_transactions_FinancialCodes_Profiles);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Map Codes']")]
		private IWebElement _transactions_FinancialCodes_MapCodes { get; set; }
		public void NavigateTo_Transactions_FinancialCodes_MapCodes()
		{
			NavigateToMenuItem(_transactions_FinancialCodes_MapCodes);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Priority']")]
		private IWebElement _transactions_FinancialCodes_Priority { get; set; }
		public void NavigateTo_Transactions_FinancialCodes_Priority()
		{
			NavigateToMenuItem(_transactions_FinancialCodes_Priority);
		}

		
		private void NavigateToMenuItem(IWebElement element)
		{
			Driver.Url = element.GetAttribute("href");
		}
		#endregion

		public AllocationCodes(GlobalSettings settings) : base(settings) { }
	}  
}
