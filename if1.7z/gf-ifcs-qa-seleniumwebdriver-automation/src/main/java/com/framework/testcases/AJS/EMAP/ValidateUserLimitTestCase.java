package com.framework.testcases.AJS.EMAP;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.common.Common;
import com.framework.pages.AJS.common.IFCSHomePage;
import com.framework.pages.AJS.common.IFCSLoginPage;
import com.framework.util.PropUtils;
import com.github.javafaker.Faker;

public class ValidateUserLimitTestCase extends BaseTest{
	
	 
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "Regression" })
	public void ValidateUserLimitsEditAndSave(@Optional("SG") String clientCountry,
			@Optional("EMAP") String clientName) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  TST-SC-06-Edit user limits of the user and save", "User limit");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCShomePage = new IFCSHomePage(driver, test);
		Common common = new Common(driver, test);
		IFCSloginPage.login("IFCS_URL_EMAP", "IFCS_EMAP_USERNAME", "IFCS_EMAP_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		IFCShomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);
		IFCShomePage.gotoAdminMenuAndChooseClientGroup();
		common.goToDesktopUsers();
		common.searchTheCurrentUserOnDesktopUsers(PropUtils.getPropValue(configProp, "IFCS_EMAP_USERLIMIT_USERNAME"));
		IFCShomePage.enterUserLimitsAndValidate(clientName + "_" + clientCountry);
		IFCShomePage.exitIFCS();

	}
	
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "Regression" })
	public void ValidateToCreateNewOlsMerchantReadOnlyUser(@Optional("SG") String clientCountry,
			@Optional("EMAP") String clientName){
		

		test = extent.createTest(clientName+ ":" +clientCountry+"  TST-SC-05-Create new ols merchant read only user in ols", "Create new ols merchant read only user");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCShomePage = new IFCSHomePage(driver, test);
		//LoginPage loginPage = new LoginPage(driver, test);
		Common common = new Common(driver, test);
		
	
		IFCSloginPage.login("IFCS_URL_EMAP", "IFCS_EMAP_USERNAME", "IFCS_EMAP_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		IFCShomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);
		IFCShomePage.gotoAdminMenuAndChooseClientGroup();
		common.goToOnlineUsers();
		Faker fakerN = new Faker();
		String testName = fakerN.name().firstName()+"_"+fakerN.name().lastName()+fakerN.number().digits(2);
		System.out.println(testName);
		String merchantNo = common.getMerchantNoFromDB();
		IFCShomePage.createNewOlsMerchantReadOnlyUser(testName,clientName + "_" + clientCountry,merchantNo);
	
		IFCShomePage.exitIFCS();
	
		// Login to the OLS Application
	//	loginPage.validateLoginPageFooterLinks(clientName, "EMAP_URL");
	//	IFCSloginPage.loginWithUsernameAndPwd(testName, testName);
		// Validate the 
	//	loginPage.validateAgreeAndLogonUser(merchantNo);
		
	//	loginPage.Logout();

	}
	
	// updated by Davu  - 01/04/2020
	
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "Regression" })
	public void ValidateToCreateNewOlsUserwithCustomerAssigned(@Optional("SG") String clientCountry,
			@Optional("EMAP") String clientName){
		

		test = extent.createTest(clientName+ ":" +clientCountry+"  Verify 02 Create new ols customer user with a customer assigned, TST-SC-68-OLS - DESKTOP - Change password in First login", "02 Create new ols customer user with a customer assigned, TST-SC-68-OLS - DESKTOP - Change password in First login");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCShomePage = new IFCSHomePage(driver, test);
		//LoginPage loginPage = new LoginPage(driver, test);
		Common common = new Common(driver, test);
		//HomePage homePage = new HomePage(driver, test);
	
		IFCSloginPage.login("IFCS_URL_EMAP", "IFCS_EMAP_USERNAME", "IFCS_EMAP_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		IFCShomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);
		IFCShomePage.gotoAdminMenuAndChooseClientGroup();
		common.goToOnlineUsers();
		Faker fakerN = new Faker();
		String testName = fakerN.name().firstName()+"_"+fakerN.name().lastName()+fakerN.number().digits(2);
		String testPwd = "Password"+fakerN.number().digits(2);
		//String testPwd1 = fakerN.name().firstName()+"_"+fakerN.name().lastName()+fakerN.number().digits(3);
		System.out.println(testName);
		System.out.println(testPwd);
		String customerNo = common.getCustomerNoHavingCardsUsingCardType();
		IFCShomePage.createNewOlsMerchantOrCustomerUser(testName,testPwd,"Standard Read / Write",customerNo,"Customer"," ");
	
		IFCShomePage.exitIFCS();
		
		// loginPage.validateLoginPageFooterLinks(clientName, "EMAP_URL");
		// loginPage.loginWithUsernameAndPwd(testName, testPwd);
		// Validate the 
		// homePage.validatePasswordMaintenancePage(testPwd, testPwd1, testPwd1);
		// loginPage.Logout();

	
	}
}
