using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using Common;
using Common.PageObjects;
using Common.ScenarioConfigurations;
using Common.Utility;

namespace EnCompass.Testing.Source.PageObjects.Organization.Payables.MerchantPayments 
{
	/// <summary>
	/// Auto-generated Page Model Class
	/// Navigation Paths: 
		/// [Organization Home]->Payables->Accounts Payable->AR-Exchange Invoices
		/// </summary>
	[PageModel(@"/payables/merchantPayments/ViewInvoices.aspx")]
	public partial class ViewInvoices : EnCompassOrgPageModel 
	{
		public override string RelativeUrl => @"/payables/merchantPayments/ViewInvoices.aspx";
		public override string PageIdentifierXPath_Generated => @"//li[contains(@class, 'breadcrumb-item active')][text() = 'View Invoices']";

		#region Navigation
				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Merchant Logs']")]
		private IWebElement _payables_AccountsPayable_ArExchangeInvoices_MerchantLogs { get; set; }
		public void NavigateTo_Payables_AccountsPayable_ArExchangeInvoices_MerchantLogs()
		{
			NavigateToMenuItem(_payables_AccountsPayable_ArExchangeInvoices_MerchantLogs);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Create Merchant Log']")]
		private IWebElement _payables_AccountsPayable_ArExchangeInvoices_CreateMerchantLog { get; set; }
		public void NavigateTo_Payables_AccountsPayable_ArExchangeInvoices_CreateMerchantLog()
		{
			NavigateToMenuItem(_payables_AccountsPayable_ArExchangeInvoices_CreateMerchantLog);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Merchant Log Reconciliation']")]
		private IWebElement _payables_AccountsPayable_ArExchangeInvoices_MerchantLogReconciliation { get; set; }
		public void NavigateTo_Payables_AccountsPayable_ArExchangeInvoices_MerchantLogReconciliation()
		{
			NavigateToMenuItem(_payables_AccountsPayable_ArExchangeInvoices_MerchantLogReconciliation);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Merchant Log Settings']")]
		private IWebElement _payables_AccountsPayable_ArExchangeInvoices_MerchantLogSettings { get; set; }
		public void NavigateTo_Payables_AccountsPayable_ArExchangeInvoices_MerchantLogSettings()
		{
			NavigateToMenuItem(_payables_AccountsPayable_ArExchangeInvoices_MerchantLogSettings);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Disputes']")]
		private IWebElement _payables_AccountsPayable_ArExchangeInvoices_Disputes { get; set; }
		public void NavigateTo_Payables_AccountsPayable_ArExchangeInvoices_Disputes()
		{
			NavigateToMenuItem(_payables_AccountsPayable_ArExchangeInvoices_Disputes);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Merchants']")]
		private IWebElement _payables_AccountsPayable_ArExchangeInvoices_Merchants { get; set; }
		public void NavigateTo_Payables_AccountsPayable_ArExchangeInvoices_Merchants()
		{
			NavigateToMenuItem(_payables_AccountsPayable_ArExchangeInvoices_Merchants);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Merchant Enrollment Status']")]
		private IWebElement _payables_AccountsPayable_ArExchangeInvoices_MerchantEnrollmentStatus { get; set; }
		public void NavigateTo_Payables_AccountsPayable_ArExchangeInvoices_MerchantEnrollmentStatus()
		{
			NavigateToMenuItem(_payables_AccountsPayable_ArExchangeInvoices_MerchantEnrollmentStatus);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='EnCircle Enrollment']")]
		private IWebElement _payables_AccountsPayable_ArExchangeInvoices_EncircleEnrollment { get; set; }
		public void NavigateTo_Payables_AccountsPayable_ArExchangeInvoices_EncircleEnrollment()
		{
			NavigateToMenuItem(_payables_AccountsPayable_ArExchangeInvoices_EncircleEnrollment);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='AR-Exchange Invoices']")]
		private IWebElement _payables_AccountsPayable_ArExchangeInvoices_ArExchangeInvoices { get; set; }
		public void NavigateTo_Payables_AccountsPayable_ArExchangeInvoices_ArExchangeInvoices()
		{
			NavigateToMenuItem(_payables_AccountsPayable_ArExchangeInvoices_ArExchangeInvoices);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Create Single-Use Accounts']")]
		private IWebElement _payables_AccountsPayable_ArExchangeInvoices_CreateSingleUseAccounts { get; set; }
		public void NavigateTo_Payables_AccountsPayable_ArExchangeInvoices_CreateSingleUseAccounts()
		{
			NavigateToMenuItem(_payables_AccountsPayable_ArExchangeInvoices_CreateSingleUseAccounts);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Create Test Transactions']")]
		private IWebElement _payables_AccountsPayable_ArExchangeInvoices_CreateTestTransactions { get; set; }
		public void NavigateTo_Payables_AccountsPayable_ArExchangeInvoices_CreateTestTransactions()
		{
			NavigateToMenuItem(_payables_AccountsPayable_ArExchangeInvoices_CreateTestTransactions);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Start CLU or ECLU']")]
		private IWebElement _payables_AccountsPayable_ArExchangeInvoices_StartCluOrEclu { get; set; }
		public void NavigateTo_Payables_AccountsPayable_ArExchangeInvoices_StartCluOrEclu()
		{
			NavigateToMenuItem(_payables_AccountsPayable_ArExchangeInvoices_StartCluOrEclu);
		}

		
		private void NavigateToMenuItem(IWebElement element)
		{
			Driver.Url = element.GetAttribute("href");
		}
		#endregion

		public ViewInvoices(GlobalSettings settings) : base(settings) { }
	}  
}
