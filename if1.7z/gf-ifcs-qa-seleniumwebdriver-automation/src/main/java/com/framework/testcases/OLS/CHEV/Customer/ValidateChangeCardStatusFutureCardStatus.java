package com.framework.testcases.OLS.CHEV.Customer;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.CHEV.CHCardListPage;
import com.framework.pages.CHEV.CHChangeCardStatusPage;
import com.framework.pages.CHEV.CHHomePage;
import com.framework.pages.OLS.common.LoginPage;

public class ValidateChangeCardStatusFutureCardStatus extends BaseTest {
	@Parameters({ "clientCountry", "clientName" })
	@Test(priority=5)
	public void validateChangeCardStatusForFutureCardStatus(@Optional("SG") String clientCountry, @Optional("CHV") String clientName) {
		
		test = extent.createTest(clientName+ ":" +clientCountry+"  05 Change Card Status page - Future Card Status", "Change Change Status Future Card Status");

		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		CHHomePage chHomePage = new CHHomePage(driver, test);
		CHCardListPage cardStatusPage = new CHCardListPage(driver, test);
		CHChangeCardStatusPage changeCardStatusPage = new CHChangeCardStatusPage(driver, test);
		
		loginPage.Login("CHV_URL", "CHV_Customer_UN_"+clientCountry, "CHV_Customer_PWD_"+clientCountry, clientName);
		chHomePage.loadFindAndUpdateCardPage();
		cardStatusPage.verifyCardPageTitle();
		String cardNumber = cardStatusPage.getActiveCardNumber();
		
		if(cardNumber!=null) {
			cardStatusPage.enterCardNumber(cardNumber);

			// Clicking the search card button
			cardStatusPage.clickSearchCard();

			// Checking Account Number
			cardStatusPage.checkAccountNumber();

			// Selecting the first card from the list
			cardStatusPage.clickFirstCardNumberFromCardsList();

			// Selecting the Change status open
			cardStatusPage.pickChangeStatusContextMenu();

			// Get the card number and change the Status
			changeCardStatusPage.verifyChangeCardStatusPage();
			changeCardStatusPage.verifyCountryDropDown();

			String actualValue = "Temporary Block - Customer Request";
			boolean isOptionValPresent = changeCardStatusPage.verifyValuePresentInNewStatus(actualValue);
			
			System.out.println("---- isOptionValPresent------- "+isOptionValPresent);
			
			if(isOptionValPresent) {
			
				changeCardStatusPage.changeCardStatusAndSave(actualValue);
				
				boolean isErrorHandled = changeCardStatusPage.errorMessageHandle();
				
				if(!isErrorHandled) {
		
				changeCardStatusPage.verifyPopUpTitle("Issue a replacement card?");
		
				changeCardStatusPage.clickPopUpDontReplaceBtn();
		
				changeCardStatusPage.checkStatusMessage(actualValue);		
		
				
			}
				else
				{
					cardStatusPage.logInfo("Invalid card status change combination for the cardNumber changed to Damaged "+cardNumber+" , Please check in IFCS desktop");
				}
			}
			
			else
			{
				cardStatusPage.logInfo(cardNumber+" already changed to "+actualValue+" but which is not reflected in the OLS, Please check in the IFCS Desktop application, So Checking the Next card");
				
				changeCardStatusPage.navigateBacktoCardList();
				cardStatusPage.verifyCardPageTitle();
				cardStatusPage.clearActiveNumberInTextBox();
				cardStatusPage.searchActiveCards();
				int numActiveCards = cardStatusPage.getNumberOfActiveCards();
				
				System.out.println("------ num Active cards ------"+numActiveCards);
				
				if(numActiveCards > 1)
				{
					if(numActiveCards > 2)
					{
						cardStatusPage.logInfo("We already iterated twice, So We don't need to iterate one more time.");
					}
					else
					{
						String secondCardNumber = cardStatusPage.getNextActiveCardNumber();
						
						System.out.println("---- secondCardNumber -----"+secondCardNumber);
						
						System.out.println("---- cardNumber -----"+cardNumber);
						
						
						if(!cardNumber.equals(secondCardNumber))
						{
							// Selecting the second card from the list
							cardStatusPage.clickSecondCardNumberFromCardsList();
							
							// Selecting the Change status open
							cardStatusPage.pickChangeStatusContextMenu();
							
							// Get the card number and change the Status
							changeCardStatusPage.verifyChangeCardStatusPage();
							changeCardStatusPage.verifyCountryDropDown();
							
							boolean isOptionValPresentforNextCard = changeCardStatusPage.verifyValuePresentInNewStatus(actualValue);
							
							System.out.println("---- isOptionValPresentforNextCard------- "+isOptionValPresentforNextCard);
							
							if(isOptionValPresentforNextCard) {
							
								changeCardStatusPage.changeCardStatusAndSave(actualValue);
								
								boolean isErrorHandled2 = changeCardStatusPage.errorMessageHandle();
								
								if(!isErrorHandled2)
								{
						
									changeCardStatusPage.verifyPopUpTitle("Issue a replacement card?");
							
									changeCardStatusPage.clickPopUpDontReplaceBtn();
							
									changeCardStatusPage.checkStatusMessage(actualValue);
								}
								else
								{
									cardStatusPage.logInfo("Invalid card status change combination for the cardNumber changed to Damaged "+secondCardNumber+" , Please check in IFCS desktop");
								}
							}
							
							else
							{
								cardStatusPage.logInfo(secondCardNumber+" also changed to "+actualValue+" already, but which is not reflected in the OLS, Please check in the IFCS Desktop application");
							}
						
						}
						
						else
						{
							cardStatusPage.logInfo("First "+cardNumber+" Second "+secondCardNumber+" are same");
						}
					}
				}
				
				else
				{				
					cardStatusPage.logInfo("Only one active card "+cardNumber+" already changed to "+actualValue+" but which is not reflected in the OLS, Please check in the IFCS Desktop application");
				}
				
				
			}
			

		} else {
			System.out.println("No Active Card");
		}

		loginPage.Logout();

	}

}
