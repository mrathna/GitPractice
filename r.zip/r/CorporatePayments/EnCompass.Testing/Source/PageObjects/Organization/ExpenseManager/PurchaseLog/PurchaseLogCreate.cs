﻿using Common;
using Common.Utility;
using NFluent;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace EnCompass.Testing.Source.PageObjects.Organization.ExpenseManager.PurchaseLog
{
    public partial class PurchaseLogCreate
    {
        public override string PageIdentifierXPath_Override => @"//li[contains(@class, 'breadcrumb-item active')][text() = 'Purchase Logs' or text() = 'Buyers Logs' or text() = 'Create Purchase Log' or text() = 'Create OTO Pay Log' or text() = 'Create Buyers Log' or text() = 'Edit Purchase Log' or text() = 'Edit OTO Pay Log' or text() = 'Edit Buyers Log' or text() = 'Create ActivePay Purchase Log' or text() = 'Edit ActivePay Purchase Log']";


        #region XPath page Elements
        private const string _nameXpath = @"//input[contains(@id, 'Udf0')]";
        private const string _dobReadOnlyXpath = @"//input[contains(@id, 'Udf1')]";
        private const string _ssnReadOnlyXpath = @"//input[contains(@id, 'Udf2')]";
        private const string _amountXpath = @"//input[contains(@id, 'AmountText')]";
        private const string _deliveryMethodDropdownXpath = @"//select[contains(@id, 'DeliveryMethodDropDown')]";
        private const string _deliveryByEmailXpath = @"//input[contains(@id, 'DeliveryAddressText')]";
        private const string _deliveryByFaxCountryDropdownXpath = "//select[contains(@id,'DeliveryAddressFax_ddlCountry')]";
        private const string _effectiveDateStartTextXpath = "//input[contains(@id,'EffectiveDateStartText')]";
        private const string _effectiveDateStopTextXpath = "//input[contains(@id,'EffectiveDateStopText')]";
        private const string _deliveryByFaxPhoneXpath = "//input[contains(@id,'DeliveryAddressFax_txtPhone')]";
        private const string _poolNameReadOnlyXpath = @"//span[contains(@id, 'PoolNameLabel')]";
        private const string _pLogIDXpath = @"//input[contains(@id, 'UniqueIdLabel')]";
        private const string _pLogIDNewXpath = @"//div[contains(@id, 'divMessage')]//strong";
        private const string _cardNumberTextXpath = @"//span[contains(@id, 'lblActNo')]";
        private const string _expirationDateXpath = @"//span[contains(@id, 'lblExpDt')]";
        private const string _cscXpath = @"//span[contains(@id, 'lblCVC2value')]";
        private const string _poolNameXpath = @"//select[contains(@id,'PoolDropdown')]";
        private const string _submitActionXpath =@"//input[contains(@id,'Save')]";
        private const string _currencyDropdownXpath = @"//select[contains(@id,'CurrencyDropdown')]";
        private const string _authAccumResetDropdownXpath = @"//select[contains(@id,'DropdownListAuthAccumReset')]";
        private const string _noOfAllowedAuthsXpath = @"//input[contains(@id,'TextBoxNumAllowedAuths')]";
        private const string _reconThreshPctAboveXpath = @"//input[contains(@id,'ReconciliationThresholdAboveText')]";
        private const string _reconThreshPctBelowXpath = @"//input[contains(@id,'ReconciliationThresholdBelowText')]";
        private const string _bookingIdXpath =@"//input[contains(@id,'apAddendum_Udf0DatePickerTextBox')]";
        private const string _payables_PurchaseLog_CreateTestTransactionsXpath = @"//div[@class='side_menu']//a[text()='Create Test Transactions']";
       
        #endregion

        #region Page Elements
        private IWebElement _name
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_nameXpath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_name element exist is " + found); Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _payables_PurchaseLog_CreateTestTransactions
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_payables_PurchaseLog_CreateTestTransactionsXpath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_payables_PurchaseLog_CreateTestTransactions element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _dobReadOnly
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_dobReadOnlyXpath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_dobReadOnly element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _ssnReadOnly
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_ssnReadOnlyXpath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_ssnReadOnly element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _amount
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_amountXpath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_amount element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _deliveryMethodDropdown
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_deliveryMethodDropdownXpath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_deliveryMethodDropdown element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _deliveryByEmail
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_deliveryByEmailXpath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_deliveryByEmail element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _deliveryByFaxCountryDropdown
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_deliveryByFaxCountryDropdownXpath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_deliveryByFaxCountryDropdown element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _effectiveDateStartText
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_effectiveDateStartTextXpath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_effectiveDateStartText element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _effectiveDateStopText
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_effectiveDateStopTextXpath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_effectiveDateStopText element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _deliveryByFaxPhone
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_deliveryByFaxPhoneXpath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_deliveryByFaxPhone element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _poolNameReadOnly
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_poolNameReadOnlyXpath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_poolNameReadOnly element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _pLogID
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_pLogIDXpath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_pLogID element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _pLogIDNew
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_pLogIDNewXpath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_pLogIDNew element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _cardNumber
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_cardNumberTextXpath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_cardNumber element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _expirationDate
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_expirationDateXpath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_expirationDate element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _csc
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_cscXpath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_csc element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _poolName
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_poolNameXpath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_poolName element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _submitAction
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_submitActionXpath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_submitAction element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _currencyDropdown
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_currencyDropdownXpath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_currencyDropdown element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _authAccumResetDropdown
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_authAccumResetDropdownXpath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_authAccumResetDropdown element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _noOfAllowedAuths
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_noOfAllowedAuthsXpath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_noOfAllowedAuths element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _reconThreshPctAbove
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_reconThreshPctAboveXpath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_reconThreshPctAbove element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _reconThreshPctBelow
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_reconThreshPctBelowXpath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_reconThreshPctBelow element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _bookingId
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_bookingIdXpath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_bookingId element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        #endregion




        public string faxNum = "//input[contains(@id,'DeliveryAddressFax_txtPhone')]";

        public string BookingId
        {
            get
            {
                return _bookingId.Text;
            }
            set
            {
                _bookingId.Clear();
                _bookingId.SendKeys(value);
                Settings.EnCompassExtentTest.Info($"Booking ID: {value}");
            }
        }


        public string CardNumber => _cardNumber.Text.Trim().Replace("-", "").Trim();
        public string CardNumberLast4 => _cardNumber.Text.Trim().Substring(_cardNumber.Text.Trim().Length - 4);
        public string ExpirationDate => _expirationDate.Text.Trim();
        public string CSC => _csc.Text.Trim();
        public string PLogId => _pLogIDNew.Text.Trim();


        #region Auth Accumulator Fields
        public bool IsAuthAccumResetPresent
        {
            get
            {
                if (_authAccumResetDropdown.Displayed)
                    return true;
                else
                    return false;
            }
        }

        public string AuthAccumuReset
        {
            get { return new SelectElement(_authAccumResetDropdown).SelectedOption.Text.Trim(); }
            set { _authAccumResetDropdown.SetListboxByText(value, SelectTextOptions.StartsWith); }
        }

        public List<IWebElement> AuthAccumResetOptions()
        {
            return new SelectElement(_authAccumResetDropdown).Options.ToList();
        }

        public bool IsNumberOfAllowedAuthsPresent
        {
            get
            {
                if (_noOfAllowedAuths.Displayed)
                    return true;
                else
                    return false;
            }
        }

        public string NumberOfAllowedAuths
        {
            get
            {
                if (_noOfAllowedAuths.GetAttribute("value") == "")
                    return _noOfAllowedAuths.GetAttribute("placeholder").Trim();
                else
                    return _noOfAllowedAuths.GetAttribute("value").Trim();
            }
            set { _noOfAllowedAuths.Clear(); _noOfAllowedAuths.SendKeys(value); }
        }

        #endregion

        #region ReconThresholdFields
        public bool IsReconThresholdPctAbovePresent()
        {
            if (_reconThreshPctAbove.Displayed)
                return true;
            else
                return false;
        }

        public bool IsReconThresholdPctBelowPresent()
        {
            if (_reconThreshPctBelow.Displayed)
                return true;
            else
                return false;
        }

        public string ReconThresholdPctAbove
        {
            get
            {
                if (_reconThreshPctAbove.Displayed)
                {
                    if (_reconThreshPctAbove.GetAttribute("value") == "")
                    {
                        return _reconThreshPctAbove.GetAttribute("placeholder").Trim();
                    }
                    else
                    {
                        return _reconThreshPctAbove.GetAttribute("value").Trim();
                    }
                }
                else
                    return "";
            }
            set
            {
               
                    _reconThreshPctAbove.Clear();
                    _reconThreshPctAbove.SendKeys(value);
                
            }
        }

        public string ReconThresholdPctBelow
        {
            get
            {
                if (_reconThreshPctBelow.Displayed)
                {
                    if (_reconThreshPctBelow.GetAttribute("value") == "")
                    {
                        return _reconThreshPctBelow.GetAttribute("placeholder").Trim();
                    }
                    else
                    {
                        return _reconThreshPctBelow.GetAttribute("value").Trim();
                    }
                }
                else
                    return "";
            }
            set
            {
                    _reconThreshPctBelow.Clear();
                _reconThreshPctBelow.SendKeys(value);
                    Settings.EnCompassExtentTest.Info("Entered valued is: " + value);
            }
        }

        #endregion

        public string PoolNameReadOnly
        {
            get
            {
                if (_poolName.Displayed)
                    return _poolNameReadOnly.Text;
                else
                    return string.Empty;
            }
        }

        public string Name
        {
            get { return _name.GetAttribute("value"); }
            set { _name.WaitUntilElementIsInteractable(); _name.Clear(); _name.SendKeys(value); }
        }

        public string Amount
        {
            get { return _amount.GetAttribute("value"); }
            set { _amount.Clear(); _amount.SendKeys(value); }
        }

        public string EffectiveDateStart
        {
            get { return _effectiveDateStartText.GetAttribute("value"); }
            set { _effectiveDateStartText.Clear(); _effectiveDateStartText.SendKeys(value); }
        }

        public string EffectDateStop
        {
            get { return _effectiveDateStopText.GetAttribute("value"); }
            set { _effectiveDateStopText.Clear(); _effectiveDateStopText.SendKeys(value); }
        }


		public string DeliveryMethod
        {
            get { return new SelectElement(_deliveryMethodDropdown).SelectedOption.Text; }
            set
            {
                var selElement = new SelectElement(_deliveryMethodDropdown);
                var selOption = selElement.Options.FirstOrDefault(o => o.Text.StartsWith(value));

                if (selOption != null)
                {
                    selElement.SelectByText(selOption.Text);
                    Settings.EnCompassExtentTest.Info("Selected option from the list: " + value);
                }
                else
                {
                    throw new Exception($"Select Option not present in the list.");
                }
            }
        }

        public string Currency
        {
            get { return new SelectElement(_currencyDropdown).SelectedOption.Text; }
            set
            {
                var selElement = new SelectElement(_currencyDropdown);
                var selOption = selElement.Options.FirstOrDefault(o => o.Text.StartsWith(value));

                if (selOption != null)
                {
                    selElement.SelectByText(selOption.Text);
                    Settings.EnCompassExtentTest.Info("Selected option from the list: " + value);
                }
                else
                {
                    throw new Exception($"Select Option not present in the list.");
                }
            }
        }

        public string SetDeliveryMethodDetails
        {
            set
            {
                if (DeliveryMethod.Equals("fax", StringComparison.InvariantCultureIgnoreCase) && _deliveryByFaxPhone.Displayed)
                {
                    _deliveryByFaxPhone.SendKeys(value);
                    Settings.EnCompassExtentTest.Info("Selected option from the list: " + value);
                }
                else if (DeliveryMethod.Equals("email", StringComparison.InvariantCultureIgnoreCase) && _deliveryByEmail.Displayed)
                {
                    _deliveryByEmail.SendKeys(value);
                    Settings.EnCompassExtentTest.Info("Selected option from the list: " + value);
                }
            }
        }

        public string PoolName
        {
            get { return new SelectElement(_poolName).SelectedOption.Text; }
            set
            {
                var selElement = new SelectElement(_poolName);
                var selOption = selElement.Options.FirstOrDefault(o => o.Text.StartsWith(value));

                if (selOption != null)
                {
                    selElement.SelectByText(selOption.Text);
                    Settings.EnCompassExtentTest.Info("Selected option from the list: " + value);

                }
                else
                {
                    throw new Exception($"Select Option not present in the list.");
                }
            }
        }

		public void Save()
		{
			_submitAction.JSClickWithFocus(Driver, _submitActionXpath, Settings);
			WaitForLoad();
			this.AttachOnDemandScreenShot();
			Settings.EnCompassExtentTest.Info("Clicked on Save Button");
		}

        public bool IsItMasterCard()
        {
            if (CardNumber.Substring(0, 1) == "5")
                return true;
            else return false;
        }

        public bool IsItVisa()
        {
            if (CardNumber.Substring(0, 1) == "4")
                return true;
            else return false;
        }

        public string GetCardNumber
        {
            get { return _cardNumber.Text; }
        }

       
        public void NavigateTo_Payables_PurchaseLog_CreateTestTransactions()
        {
            NavigateToMenuItem(_payables_PurchaseLog_CreateTestTransactions);
        }

        public bool IsEffectiveDateStartNotExist()
        {
            try
            {
                bool val = _effectiveDateStartText.Displayed;
                Settings.EnCompassExtentTest.Info("Effective date start field exists");
                return false;
            }
            catch (Exception e)
            {
                Settings.EnCompassExtentTest.Info("Effective date start field not exists");
                return true;
            }
        }
        public bool IsEffectiveDateStopNotExist()
        {
            try
            {
                bool val = _effectiveDateStopText.Displayed;
                Settings.EnCompassExtentTest.Info("Effective date stop field exists");
                return false;
            }
            catch (Exception e)
            {
                Settings.EnCompassExtentTest.Info("Effective date stop field not exists");
                return true;
            }
        }

        public string EmailAddress
        {
            get { return _deliveryByEmail.GetAttribute("value"); }
            set
            {
                _deliveryByEmail.Clear();
                _deliveryByEmail.SendKeys(value);
                Settings.EnCompassExtentTest.Info("Email set to:" + value);
                Settings.Scenario["PurchaseLogEmail"] = value;
                Settings.EnCompassExtentTest.Info("Storing PurchageLogEmail as:" + value);
            }
        }

        public string FaxNumber
        {
            get { return _deliveryByFaxPhone.GetAttribute("value"); }
            set
            {
                _deliveryByFaxPhone.Clear();
                _deliveryByFaxPhone.SendKeys(value);
                Settings.EnCompassExtentTest.Info("Fax set to:" + value);
                Settings.Scenario["PurchaseLogFax"] = value;
                Settings.EnCompassExtentTest.Info("Storing PurchaseLogFax as:" + FaxNumber);
            }
        }
    }
}

