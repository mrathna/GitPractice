package com.framework.pages.SHELL;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.ExtentTest;
import com.framework.basepage.BasePage;
import com.framework.repo.Locator;

public class EditUserProfile extends BasePage {
	
	@FindBy(id = Locator.EMAIL_FIELD)
	public WebElement emailAddressProfile;
	
	@FindBy(id = Locator.LOC_ACC_NAME)
	public WebElement nameProfile;	
	
	@FindBy(id = Locator.PHONE_FIELD)
	public WebElement phoneFldProfile;
	
	@FindBy(id = Locator.MOBILE_FIELD)
	public WebElement mobileFldProfile;
	
	@FindBy(id = Locator.SAVE_BT)
	public WebElement saveBTNProfile;
 
	@FindBy(id = Locator.HOME_MENU_BP)
	public WebElement homeMenuProfile;
	
	
	
	

	public EditUserProfile(WebDriver driver, ExtentTest test) {
		super(driver, test);
		PageFactory.initElements(driver, this);
		// TODO Auto-generated constructor stub
	} 
	
	public void verifyUserProfilePage() {
		
		checkTextInPageAndValidate("EDIT PROFILE", 20);
		
		checkTextInPageAndValidate("User ID", 20);
		
		checkTextInPageAndValidate("Email Address", 20);
		
		checkTextInPageAndValidate("Display Name", 20);
		
		checkTextInPageAndValidate("Phone", 20);
		
		checkTextInPageAndValidate("Mobile", 20);
		
		checkTextInPageAndValidate("Language", 20);
		
	}

	/*
	 * This method to edit the profile and validate
	 * 
	 * 
	 */
	public void editProfileAndValidate() {

		String phone = fakerAPI().phoneNumber().phoneNumber();

		String mobile = fakerAPI().phoneNumber().cellPhone();

		System.out.println(nameProfile);
		
		System.out.println("nameProfile"+nameProfile.getText());
		
		System.out.println("email address value"+emailAddressProfile.getText());
		
		isDisplayed(emailAddressProfile, "Email field");
		
		isDisplayed(nameProfile, "Name Field");

		isDisplayedThenEnterText(phoneFldProfile, "Phone for the New User", phone);

		isDisplayedThenEnterText(mobileFldProfile, "Mobile for the New User", mobile);

		sleep(3);

		isDisplayedThenActionClick(saveBTNProfile, "Save Button");

		sleep(5);

		//checkTextInPageAndValidate("Record updated OK", 30);
		
		checkTextInPageAndValidate("Record saved OK", 30);//Text has changed in regression 19.7.2

	}

	public void ProfileDetailsPage() {

		String phone = fakerAPI().phoneNumber().phoneNumber();

		isDisplayedThenEnterText(phoneFldProfile, "Phone for the New User", phone);

		sleep(3);
		
		isDisplayedThenActionClick(saveBTNProfile, "Save Button");
		
		sleep(5);
		
		//checkTextInPageAndValidate("Record updated OK", 30);
		checkTextInPageAndValidate("Record saved OK", 30);//Text has changed in regression 19.7.2
		
		isDisplayedThenActionClick(homeMenuProfile, "HomeMenu");		
		
	}

}
