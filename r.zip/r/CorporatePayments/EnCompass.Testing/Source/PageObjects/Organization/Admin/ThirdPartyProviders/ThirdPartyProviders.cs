﻿using Common;
using Common.Utility;
using EnCompass.Testing.Source.PageObjects.Controls;
using OpenQA.Selenium;

namespace EnCompass.Testing.Source.PageObjects.Organization.Admin.ThirdPartyProviders
{
    [PageModel(@"/admin/thirdPartyProviders/ThirdPartyProviders.aspx")]
	public partial class ThirdPartyProviders : EnCompassPageModel
	{

		public override string RelativeUrl => @"/admin/thirdPartyProviders/ThirdPartyProviders.aspx";
		public override string PageIdentifierXPath_Override => @"//li[contains(@class, 'active')][contains(@class, 'breadcrumb-item')][contains(text(), 'Third-Party Providers')]";

        private readonly string _addToListButton = @"//input[contains(@id,'btnAddtoList')]";
        private readonly string _recordsMessage = @"//tr[@class='no-records-found']";
        private readonly string _revokeButton = @"//button[text()='Revoke']";

        public void ClickAddToListButton()
        {
            Driver.TryWaitForElementToBeVisible(By.XPath(_addToListButton), out IWebElement addToListButton);
            addToListButton.BootstrapClick();
            Settings.EnCompassExtentTest.Info("Clicked on Add to List Button.");
        }

        public void ClickRevokeButton()
        {
            Driver.TryWaitForElementToBeVisible(By.XPath(_revokeButton), out IWebElement revokeButton);
            revokeButton.BootstrapClick();
            Settings.EnCompassExtentTest.Info("Clicked on Revoke Button.");
        }

        public string GetMessageDisplayed
        {
            get
            {
                return Settings.EnCompassWebDriver.WaitForVisible(By.XPath(_recordsMessage)).Text;
            }
        }

        private NewGridControl _listThirdPartyGrid;
        public NewGridControl ListThirdPartyGrid
        {
            get
            {
                NewGridControl grid = _listThirdPartyGrid ?? (_listThirdPartyGrid = new NewGridControl("etTPPList", Driver, Settings));
                grid.WaitForGrid();
                return grid;
            }
        }

        #region modalRevokeAccess
        public const string _revokeAccessModal = @"//div[contains(@id,'Modal_') and @data-focus='true']";

        public void WaitForRevokeAccessModal()
        {
            Driver.WaitForVisible(By.XPath(_revokeAccessModal));
        }

        public RevokeAccessModal GetRevokeAccessModal
        {
            get
            {
                using (FrameHelper helper = new FrameHelper(Settings.EnCompassWebDriver, By.XPath(_revokeAccessModal)))
                {
                    return new RevokeAccessModal(helper, Settings);
                }
            }
        }

        /// <summary>
        /// Adding a seperate class for Each Iframe embedded within this Page Object model
        /// </summary>
        public class RevokeAccessModal : ThirdPartyProviders
        {
            FrameHelper _helper;
            public const string _cancelButtonModal = @"//button[text()='Cancel']";
            public const string _revokeButtonModal = @"//button[text()='Revoke' and contains(@class,'danger')]";

            public void CancelButtonModal()
            {
                _helper.FindElement(By.XPath(_cancelButtonModal)).BootstrapClick();
                Settings.EnCompassExtentTest.Info("Clicked on Cancel Button in modal.");
            }

            public void RevokeButtonModal()
            {
                _helper.FindElement(By.XPath(_revokeButtonModal)).BootstrapClick();
                Settings.EnCompassExtentTest.Info("Clicked on Grant Button in modal.");
            }

            public RevokeAccessModal(FrameHelper helper, GlobalSettings settings) : base(settings)
            { _helper = helper; }
        }
        #endregion

        public ThirdPartyProviders(GlobalSettings settings) : base(settings) { }
	}
}
