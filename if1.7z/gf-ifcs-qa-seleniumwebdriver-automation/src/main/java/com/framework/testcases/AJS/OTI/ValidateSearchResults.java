package com.framework.testcases.AJS.OTI;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.SearchPage;
import com.framework.pages.AJS.common.Common;
import com.framework.pages.AJS.common.IFCSHomePage;
import com.framework.pages.AJS.common.IFCSLoginPage;


public class ValidateSearchResults extends BaseTest {
		
		/*
		Added by davu - 05/05/2020

		*/
		
		@Parameters({ "clientCountry", "clientName"})
		@Test( groups = { "Regression" })
		public void validateSearchCards(@Optional("BW") String clientCountry, @Optional("OTI") String clientName) {
			test = extent.createTest(clientName+ ":" +clientCountry+"  Verify Search Cards", "Verifying Search cards");
			// creating object for the Pages
			IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
			IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
			SearchPage searchInputs = new SearchPage(driver, test);
			Common common = new Common(driver, test);
			IFCSloginPage.login("IFCS_URL_OTI", "IFCS_OTI_USERNAME", "IFCS_OTI_PASSWORD");
			IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
			IFCSHomePage.gotoSearchAndClickCards();
			common.performBlankSearchAndValidate();
			// Select client from dropdown and validate
			searchInputs.selectClientInDropDownAndSearch("Client", clientName + "_" + clientCountry);
			// Search customer number
			searchInputs.enterCustomerNumberAndSearch(clientName + "_" + clientCountry);
			
			common.searchCardnumberAndValidate("Full", "Filter By");
			// Enter a Card Number and use the Wildcard (*) symbol and select the Search
			// button
			common.searchCardnumberAndValidate("Partial", "Filter By");
			
			// Enter does not exist driver name and validate
			searchInputs.enterUnknownDriverNameAndSearch();
			IFCSHomePage.exitIFCS();

		
		}
		
		
		@Parameters({ "clientCountry", "clientName"})
		@Test( groups = { "Regression" })
		public void validateSearchCustomers(@Optional("BW") String clientCountry, @Optional("OTI") String clientName) {
			
			test = extent.createTest(clientName+ ":" +clientCountry+"  Verify Search Cards", "Verifying Search cards");
			// creating object for the Pages
			IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
			IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
			SearchPage searchInputs = new SearchPage(driver, test);
			Common common = new Common(driver, test);
			IFCSloginPage.login("IFCS_URL_OTI", "IFCS_OTI_USERNAME", "IFCS_OTI_PASSWORD");
			IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
			IFCSHomePage.gotoCustomerMenuCustomer();
			IFCSHomePage.gotoCustomersMenuAndChooseClient(clientName + "_" + clientCountry);
			common.performBlankSearchAndValidate();
			// Search customer number
			searchInputs.enterCustomerNumberAndSearch(clientName + "_" + clientCountry);
			IFCSHomePage.exitIFCS();
			
		}
		
	

}
