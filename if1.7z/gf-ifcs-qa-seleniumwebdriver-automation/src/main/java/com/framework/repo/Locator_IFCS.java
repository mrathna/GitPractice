package com.framework.repo;

public class Locator_IFCS {
	// Login Page
	public static final String IFCS_USERNAME = "//input[contains(@id,'JTextField')]";
	public static final String IFCS_PASSWORD = "//input[contains(@id,'JPasswordField')]";
	public static final String IFCS_LOGIN = "//div[text()='Logon']";
	// public static final String WELCOMETEXT="//div[contains(text(),'Welcome')]";
	public static final String WELCOMETEXT = "//div[@class='JLabel']/div";

	// Customer
	
	public static final String CUSTOMER_MENU = "//div[@class='htmlString']/u[text()='C']";// u[text()='C']
	public static final String CUSTOMERS_DETAILS_SUBMENU = "//div[@class='JFALExtMenu_1 enabled JMenuItem']/div[contains(text(),'Details')]";
	public static final String CUSTOMER_MAINTENANCE = "//div[@class='JLabel']//div[contains(text(),'Customer') and contains(text(),'Maintenance')]";
	public static final String CARD_REIISUE_PROFILE = "//div[@class='JLabel']//div[contains(text(),'Card') and contains(text(),'Reissue') and contains(text(),'Profiles')]";

	// Utilies
	public static final String UTILITIES_MENU = "//div[u[text()='U']]";
	public static final String UTILITIES_SUBMENU = "//div[@class='JFALExtMenu_1 enabled JMenuItem']//div[text()='Utilities']";
	public static final String AVAILABLE_REPORTS = "//div[@class='JFALSeparator_1']//div[contains(text(),'Available') and contains(text(),'Reports')]";
	public static final String TASK_BAR_SUBMIT = "//div[@class='JFALExtToolBar']//div[@class='JFALToolBarButton enabled JButton'][contains(@title,'Submit') and contains(@title,'Alt') and contains(@title,'F10')]";
	public static final String DEFINE_PARAMETERS_IN_POPUP = "//div[@class='FALDynamicParameterDialog window modal v4init']//div[contains(text(),'Define')]";
	public static final String AD_HOC_REPORTS = "//div[@class='Navigator_NavigatorTreeCellRenderer']//div[contains(text(),'Ad-Hoc') and contains(text(), 'Reports')]";
	public static final String DATE_RANGE_FROM = "//div[@class='JFALDateComboBox'][2]//div[@class='JFALDateLocaleTextField JTextComponent']/input";
	public static final String DATE_RANGE_TO = "//div[@class='JFALDateComboBox'][1]//div[@class='JFALDateLocaleTextField JTextComponent']/input";
	public static final String OK_BUTTON_SHORTCUT_POPUP ="//div[@class='JButton enabled']//div[text()='K']/u[text()='O']";
	public static final String OK_BUTTON_POPUP = "//div[@class='JButton enabled']//div[contains(text(),'OK')]|//div[@class='JButton enabled']//div[text()='K']/u[text()='O']";
	public static final String DATE_RANGE="//div[@class='JFALDateComboBox']//div[@class='JFALDateLocaleTextField JTextComponent']/input";
	// Merchants
	public static final String MERCHANTS_MENU = "//div[u[text()='M']]";
	public static final String MERCHANT_DETAILS_SUBMENU = "//div[@class='JFALExtMenu_1 enabled JMenuItem']//div[contains(text(),'Merchant') and contains(text(),'Details')]";

	// Country
	public static final String COUNTRIES = "//div[text()='Countries']";

	// File
	public static final String FILE_MENU = "//div[u[text()='F']]";
	public static final String EXIT_SUBMENU = "//div[u[text()='x']]";

	// Transactions
	public static final String TRANSACTIONS_MENU = "//u[text()='T']";
	public static final String MANAGE_TRANSACTION_SUBMENU = "//div[contains(text(),'Manage') and contains(text(),'Transactions')]";
	// Transaction
	public static final String CLIENT_TRANSACTION_MAIN_FRAME = "//div[@class='JLabel']//div[contains(text(),'Client') and contains(text(),'Transactions')] ";
	public static final String CLIENT_TRANSACTION_LEFT_PANEL = "//div[@class='Navigator_NavigatorTreeCellRenderer']//div[contains(text(),'Client') and contains(text(),'Transactions')]";
	public static final String MANUAL_PAYMENT_LEFT_PANEL = "//div[@class='Navigator_NavigatorTreeCellRenderer']//div[contains(text(),'Manual') and contains(text(),'Payment')]";
	public static final String PAYMENT_LEFT_PANEL = "//div[@class='Navigator_NavigatorTreeCellRenderer']//div[text()='Payments']";
	// Merchants
	public static final String MAINTAIN_MERCHANTS_IN_LEFT_PANEL = "//div[@class='Navigator_NavigatorTreeCellRenderer']//div[contains(text(),'Maintain') and contains(text(),'Merchant')]";
	public static final String MAINTAIN_MERCHANTS_IN_MAIN_FRAME = " //div[@class='JLabel']//div[contains(text(),'Maintain') and contains(text(),'Merchant')]";
	// Accounts
	public static final String MAINTAIN_ACCOUNTS_IN_LEFT_PANEL = "//div[@class='Navigator_NavigatorTreeCellRenderer']//div[contains(text(),'Maintain') and contains(text(), 'Account')]";
	public static final String MAINTAIN_ACCOUNTS_IN_MAIN_FRAME = "//div[@class='ViewerPanel']//div[@class='JLabel']//div[contains(text(),'Maintain') and contains(text(),'Account')]";
	// customer
	public static final String MAINTAIN_CUSTOMER_IN_LEFTPANEL = "//div[@class='Navigator_NavigatorTreeCellRenderer']/div[contains(text(),'Maintain') and contains(text(),'Customer')]";
	public static final String MAINTAIN_CUSTOMER_IN_MAIN_FRAME = "//div[@class='JLabel']/div[contains(text(),'Maintain') and contains(text(),'Customer')]";
	public static final String Customer_Customer = "//div[@class='Navigator_NavigatorTreeCellRenderer']//div[text()='Customers']";
	// Application
	public static final String MAINTAIN_APPLICATION_LEFT_PANEL = "//div[@class='Navigator_NavigatorTreeCellRenderer']//div[contains(text(),'Maintain') and contains(text(),'Application')]";
	public static final String MAINTAIN_APPLICATION_MAIN_FRAME = "//div[@class='JLabel']//div[contains(text(),'Maintain') and contains(text(),'Application')]";
	public static final String APPLICATION_APPLICATIONS = "//div[@class='Navigator_NavigatorTreeCellRenderer']//div[text()='Applications']";
	// Utilities
	public static final String AD_HOC_REPORTS_LEFT_PANEL = "//div[@class='Navigator_NavigatorTreeCellRenderer']//div[contains(text(),'Ad-Hoc' ) and contains(text(),'Reports')]";
	public static final String AD_HOC_REPORTS__MAIN_FRAME = "//div[@class='JLabel']//div[contains(text(),'Ad-Hoc' ) and contains(text(),'Reports')]";
	
	
	public static final String CLIENT_CONFIG_MAIN_FRAME ="//div[@class='JLabel']//div[contains(text(),'Client') and contains(text(),'Config')] ";
	// System
	public static final String SYSTEM_MENU = "//div[text()='System']";

	public static final String fromAccount = "//div[@class='JFALSeparator']//div[contains(text(),'From')]/preceding::div[@class='JFALLabel'][1]/preceding::div[@class='JFALCompControlPanel'][1]//div[@class='JFALTextField JTextComponent']/input";
	// Admin
	public static final String ADMIN_MENU = "//div[@class='htmlString']/u[text()='d']";// div[u[text()='d']]
	public static final String CLIENT_SUBMENU = "//div[@class='JFALExtMenu_1 enabled JMenuItem']//div[text()='Client']";
	public static final String CLIENTCONFIG_LEFTPANEL = "//div[text()='Client Config']";
	public static final String ADMIN_BATCH = "//div[@class='JFALExtMenu_1 enabled JMenuItem']//div[contains(text(),'Batch')]";
	
	//Client
	public static final String INTERFACES = "//div[@class='Navigator_NavigatorTreeCellRenderer']//div[(text()='Interfaces')]";
	public static final String INCOMING_INTERFACES = "//div[@class='Navigator_NavigatorTreeCellRenderer']//div[contains(text(),'Incoming') and contains(text(),'Interfaces')]";
	public static final String OUTGOING_INTERFACES = "//div[@class='Navigator_NavigatorTreeCellRenderer']//div[contains(text(),'Outgoing') and contains(text(),'Interfaces')]";
	public static final String JOB_EXECUTION = "//div[contains(@title,'Run') and contains(@title,'Job')]//div[@class='htmlImage']";
	public static final String BATCH_SCHEDULING = "//div[@class='Navigator_NavigatorTreeCellRenderer']//div[contains(text(),'Scheduling')]";

	public static final String TORCH_SEARCH = "//div[@class='JFALToolBarButton enabled JButton'][contains(@title,'Search') and contains(@title,'F7')]/div[@class='htmlImage']";
	public static final String TORCH_FINDS_RECORD = "//div[@class='JViewport']//div[contains(@title,'Find') and contains(@title,'record')]/div[@class='htmlImage']";
	public static final String SAVE_ICON = "//div[@class='JFALToolBarButton enabled JButton'][contains(@title,'Save') and contains(@title,'Record:Alt') and contains(@title,'F2')]/div[@class='htmlImage']";
	public static final String FINDRECORD_CLOSE = "//div[@class='JFALToolBarButton enabled JButton'][contains(@title,'Close')]/div[@class='htmlImage']";
	public static final String DISPUTE_TRANSACTION = "//div[@class='JFALToolBarButton enabled JButton'][contains(@title,'Dispute') and contains(@title,'Transaction')]/div[@class='htmlImage']";

	
	public static final String OPTIONAL_FOR_CARD = "//div[contains(text(),'Optional') and contains(text(),'For') and contains(text(),'Cards')]";
	public static final String POPUP_IFCS = "//div[@class='IFCSPopupDialog window modal v4init']//div[text()='IFCS']";
	public static final String SECOND_POPUP_IFCS = "//div[@class='ajaxswingv4 v4init'][3]//div[text()='IFCS']";
	public static final String POPUP_CARDPRODUCTS = "//div[@class='IFCSPopupDialog window modal v4init']//div[contains(text(),'Card') and contains(text(),'Products')]";

	public static final String FUNDTRANSFER_LEFTPANEL = "//div[contains(text(),'Funds') and contains(text(),'Transfer')]";
	public static final String FUNDTRANSFER = "//div[@class='JLabel']//div[contains(text(),'Funds') and contains(text(),'Transfer')]";
	public static final String BOTTOM_LEFT_TEXT = "//div[@class='ExtLabel'][3]//div[@class='htmlString']";
	// ErrorExit - Anton
	public static final String CLIENTCONFIG = "//div[@class='JLabel']//div[contains(text(),'Client') and contains(text(),'Config')]";
	public static final String RESTARTBUTTON = "//input[@value='Restart' or @type='submit']";
	public static final String VALIDATE_ICON = "//div[@class='JFALToolBarButton enabled JButton'][contains(@title,'Validate:Alt') and contains(@title,'F10')]/div[@class='htmlImage']";
	
	public static final String SHELL_PARTNER_CARD = "//input[@value='Shell Partner Card (DE)']";
	public static final String EXTEND_EXPIRY_PERIOD_WITHIN = "//div[@class='JFALCompControlPanel']/following::div[@class='JFALLabel']//div[contains(text(),'Extend')]/preceding::div[@class='JFALTextField JTextComponent']/input";
	
	public static final String MERCHANT_ACCOUNT_NO = "//div[@class='JFALCompControlPanel']/div[@class='JFALTextField JTextComponent'][contains(@ajs_id,'account_no')]";
	// public static final String
	// OPTIONAL_FOR_CARD="//div[contains(text(),'Optional') and
	// contains(text(),'For') and contains(text(),'Cards')]";
	// public static final String POPUP_IFCS="//div[@class='IFCSPopupDialog window
	// modal v4init']//div[text()='IFCS']";
	// public static final String POPUP_CARDPRODUCTS="//div[@class='IFCSPopupDialog
	// window modal v4init']//div[contains(text(),'Card') and
	// contains(text(),'Products')]";
	
	public static final String SH_PC_OPEN = "//input[@submittedvalue='SH PC Open']";
	public static final String CARD_PRODUCTS = "//div[@class='ExtLabel']//div[contains(text(),'Card') and contains(text(),'Products')]";
	public static final String EMBOSSING_TAB = "//div[@class='JFALTabbedPane']//div[contains(text(), 'Embossing')]";
	public static final String OK_BUTTON = "//div[u[text()='O']]";
	public static final String SECOND_POPUP_OK_BUTTON = "//div[@class='ajaxswingv4 v4init'][3]//u[text()='O']";
	public static final String CANCEL_BUTTON = "//div[@class='IFCSPopupDialog window modal v4init']//u[text()='C']";

//	public static final String POPUP_POST_TRANSACTION="//div[@class='ToolBarButton enabled JButton'][contains(@title,'Post') and contains(@title,'Transaction')][2]/div[@class='htmlImage']";
	public static final String VALIDATE_POSTTRANSACTION="//div[@class='JFALToolBarButton enabled JButton'][contains(@title,'Validate:Alt') and contains(@title,'F10')]/div[@class='htmlImage']";
	public static final String DELETE_TRANSACTION="//div[@class='JFALToolBarButton enabled JButton'][contains(@title,'Delete') and contains(@title,'Transaction')]/div[@class='htmlImage']";
	public static final String POPUP_DELETE_TRANSACTION="//div[@class='ToolBarButton enabled JButton'][contains(@title,'Delete') and contains(@title,'Transaction')]/div[@class='htmlImage']";
	//change Card status
	public static final String TORCH_SEARCH_LIST="//div[@class='JFALExtToolBar']//div[contains(@title,'Find') and contains(@title,'record')]/div[@class='htmlImage']";
	public static final String DETAIL_SEARCH="//div[@class='JFALToolBarButton enabled JButton'][contains(@title,'Detail') and contains(@title,'Search:Alt') and contains(@title,'F8')]/div[@class='htmlImage']";

	// Card Transfer
	public static final String CARDTRANSFER_TABLE = "//div[@class='JIFCSCardTransferRequestsTable']//div[@class='JViewport'][2]/div";
	public static final String POPUP_MENUITEM_ADD_CARDTRANSFER = "//div[@class='JFALTablePopupMenuItem enabled JMenuItem']/div[contains(text(),'Add')]";

	public static final String ADHOC_REPORTS_TEXT = "//div[@class='JLabel']//div[text()='Ad-Hoc Reports']";
	public static final String TASKBAR_SUBMIT="//div[@class='JFALToolBarButton enabled JButton'][contains(@title,'Submit:Alt') and contains(@title,'F10')]/div[@class='htmlImage']";
	public static final String POPUP_MENUITEM_ADD = "//div[@class='JFALTablePopupMenuItem enabled JMenuItem']/div[contains(text(),'Add')]";
	public static final String POPUP_MENUITEM_CSVExport = "//div[@class='JFALTablePopupMenuItem enabled JMenuItem']/div[contains(text(),'CSV') and contains(text(),'Export')]";
	public static final String POPUP_MENUITEM_ADD_CUSTOMER = "//div[@class='JFALTablePopupMenuItem enabled JMenuItem']/div[contains(text(),'Add') and contains(text(),'Customer')]";
	public static final String POPUP_MENUITEM_DETAILS = "//div[@class='JFALTablePopupMenuItem enabled JMenuItem']/div[contains(text(),'Details')]";
	public static final String POPUP_MENUITEM_SORT = "//div[@class='JFALTablePopupMenuItem enabled JMenuItem']/div[(text()='Sort')]";//"//div[@class='JFALTablePopupMenuItem enabled JMenuItem']/div[contains(text(),'Shift-T')]";
	public static final String POPUP_MENUITEM_SORTDESC = "//div[@class='JFALTablePopupMenuItem enabled JMenuItem']/div[contains(text(),'Shift-Z')]";
	public static final String POPUP_MENUITEM_OPT_IN_OUT = "//div[@class='JFALTablePopupMenuItem enabled JMenuItem']/div[contains(text(),'Opt') and contains(text(),'In/Out')]";
	public static final String PRICING_TEXT = "//div[@class='JLabel']//div[text()='Pricing']";
	public static final String PRICING_TABLE = "//div[@class='JFALSeparator']//div[contains(text(),'Profiles')]/preceding::div[@class='JViewport'][1]/div[1]";
	public static final String CONTACTS_TABLE = "//div[@class='JIFCSContactsTable']//div[@class='JScrollPane']/div[@class='JViewport']/div[@style]";
	public static final String PRODUCT_SOLD_TEXT = "//div[@class='JLabel']//div[contains(text(),'Products') and contains(text(),'Sold')]";
	public static final String PRODUCT_SOLD_TABLE = "//div[@class='JFALCompControlPanel']//div[@class='JScrollPane']/div[@class='JViewport']/div[@style]";

	
	public static final String YES_BUTTON="//div[u[text()='Y']]";
	public static final String NO_BUTTON="//div[u[text()='N']]";
	public static final String LEFTPANEL_MAINTAIN_AGREEMENT = "//div[@class='Navigator_NavigatorTreeCellRenderer']//div[contains(text(),'Maintain') and contains(text(),'Agreement')]";
	public static final String HIERARCHY_TEXT = "//div[@class='JFALSeparator']//div[contains(text(),'Hierarchies')]";
	public static final String MAINTAIN_AGREEMENT_TEXT = "//div[@class='JLabel']//div[contains(text(),'Maintain') and contains(text(),'Agreement')]";
	// public static final String
	// AGREEMENTS_TABLE="//div[@class='JIFCSMerchAgreementTable']//div[@class='JViewport'][2]/div";
	public static final String CHILD_LOCATION_HIERARCHY = "//div[@class='FALTreeCellRenderer'][2]//div[@class='htmlString']";
	public static final String PRICING_PROFILE_TABLE_POPUP = "//div[@class='JFALSeparator']//div[starts-with(text(),'Pricing')]//preceding::div[@class='JViewport'][2]/div";
	public static final String PARENT_MERCHANT_HIERARCHY = "//div[@class='FALTreeCellRenderer'][1]//div[@class='htmlString']";
	// public static final String
	// LEFTPANEL_MAINTAIN_AGREEMENT="//div[@class='Navigator_NavigatorTreeCellRenderer']//div[contains(text(),'Maintain')
	// and contains(text(),'Agreement')]";
	// public static final String
	// PARENT_MERCHANT_HIERARCHY="//div[@class='FALTreeCellRenderer'][1]//div[contains(text(),'Shell')
	// and contains(text(),'CZ') and contains(text(),'Mer')]";
	public static final String MERCHANT_REPORT = "//div[@class='JFALSeparator_1']//div[contains(text(), 'Reports')]";
	public static final String CONTACTS_NAME = "//div[@class='JFALSeparator']//div['Contact Type']/preceding::div[@class='JFALLabel']/div[contains(text(),'Name')]/preceding::div[@class='JFALCompControlPanel'][1]";
	public static final String PHONE_NUMBER = "//div[@class='JFALSeparator']//div['Contact']/preceding::div[@class='JFALLabel']/div[contains(text(),'Phone')]/preceding::div[@class='JFALCompControlPanel'][1]";
	public static final String PHYSICAL_ADDRESS = "//div[@class='JFALSeparator']//div['Addresses/Contacts']/preceding::div[@class='JFALLabel']/div[contains(text(),'Physical')]/preceding::div[@class='JFALCompControlPanel'][1]";
	public static final String CUSTOMER_CONTACT = "//div[@class='ExtLabel']//div[contains(text(),'Customer') and contains(text(),'Contact')]";
	public static final String POPUP_MENUITEM_SETDEFAULT = "//div[@class='JFALTablePopupMenuItem enabled JMenuItem']/div[contains(text(),'Set')]";
	public static final String AGREEMENTS = "//div[@class='JFALSeparator_1']//div[contains(text(),'Agreements')]";
	public static final String POPUP_MERCHANT_AGREEMENT = "//div[@class='IFCSPopupDialog window modal v4init']//div[@class='JFALSeparator_1']//div[contains(text(),'Merchant')]";
	public static final String POPUP_AGREEMENTS = "//div[@class='IFCSPopupDialog window modal v4init']//div[@class='JFALSeparator_1']//div[contains(text(),'Agreements')]";
	public static final String POPUP_PRICING = "//div[@class='IFCSPopupDialog window modal v4init']//div[@class='JFALSeparator_1']//div[starts-with(text(),'Pricing')]";
	public static final String POPUP_EFFECTIVE_ON = "//div[@class='IFCSPopupDialog window modal v4init']//div[@class='JFALLabel'][descendant::div[contains(text(),'Effective') ]]/preceding::div[@class='JFALCompControlPanel'][1]//div[@class='JFALDateComboBox']//div[@class='JFALDateLocaleTextField JTextComponent']";
	public static final String POPUP_EXPIRES_ON = "//div[@class='IFCSPopupDialog window modal v4init']//div[@class='JFALLabel'][descendant::div[contains(text(),'Expires') ]]/preceding::div[@class='JFALCompControlPanel'][1]//div[@class='JFALDateComboBox']//div[@class='JFALDateLocaleTextField JTextComponent']";
	public static final String POPUP_PRICING_SCHEMES = " //div[@class='IFCSPopupDialog window modal v4init']//div[@class='JFALSeparator_1']//div[contains(text(),'Pricing') and contains(text(),'Scheme')]";
	public static final String POPUP_ASSIGNEDFROM = "//div[@class='IFCSPopupDialog window modal v4init']//div[@class='JFALLabel'][descendant::div[contains(text(),'Assigned') and contains(text(),'From')]]/preceding::div[@class='JFALCompControlPanel'][1]//div[@class='JFALDateComboBox']//div[@class='JFALDateLocaleTextField JTextComponent']";
	public static final String POPUP_ASSIGNEDTO = "//div[@class='IFCSPopupDialog window modal v4init']//div[@class='JFALLabel'][descendant::div[contains(text(),'Assigned') and contains(text(),'To')]]/preceding::div[@class='JFALCompControlPanel'][1]//div[@class='JFALDateComboBox']//div[@class='JFALDateLocaleTextField JTextComponent']";
	public static final String POPUP_HEADER_PRODUCT = "//div[@class='IFCSPopupDialog window modal v4init']//div[@class='HeaderRenderer']//div[contains(text(),'Product')]";
	public static final String POPUP_HEADER_PRICINGSCHEME = "//div[@class='IFCSPopupDialog window modal v4init']//div[@class='HeaderRenderer']//div[contains(text(),'Pricing') and contains(text(),'Scheme')]";
	public static final String POPUP_PRICING_DATE = "//div[@class='FALTableCellEditor_StrikeThruDateField JTextComponent']//input[@submittedvalue='04/01/2015']";
	public static final String AGREEMENTS_TABLE = "//div[@class='JIFCSMerchAgreementTable']//div[@class='JViewport'][1]/div";

	public static final String AGREEMENTS_TABLEs = "//div[@class='JFALSeparator']//div[ (text()='Agreements')]//preceding::div[@class='JFALCompControlPanel'][1]//div[@class='FALTableCellEditor_StrikeThruDateField JTextComponent']";
	
	public static final String MERCHANT_LOCATION_AGREEMENTS = "//div[@class='JLabel']//div[contains(text(),'Merchant/Location') and contains(text(),'Agreements')]";
	public static final String MERCHANT_REPORTS_TABLE = "//div[@class='JIFCSMerchReportsTable']//div[@class='JViewport'][2]/div";
	public static final String MERCHANT_LOCATION_GROUP = "//div[@class='JFALCompControlPanel'][descendant::div[@class='htmlString'][contains(text(),'Member')]]";
	public static final String MERCHANT_LOCATION_ASSIGNMENT = "//div[@class='JFALCompControlPanel'][descendant::div[@class='htmlString'][contains(text(),'Effective')]]//div[@class='JScrollPane']/div[@class='JViewport'][2]/div";
	public static final String CLEAR_FORM = "//div[@class='htmlImage'][contains(@style,'clear')]";
	public static final String CLONE_FORM  = "//div[@class='htmlImage'][contains(@style,'new.gif')]";
	public static final String POPUP_LOCATION_GROUP = "//div[contains(@id,'IFCSPopupDialog')][descendant::div[@class='htmlString'][contains(text(),'Location') and contains(text(),'Hierarchy') and contains(text(),'Node')]]";
	public static final String POPUP_HEADER = "//div[contains(@class,'IFCSPopupDialog')]//div[@class='UIFactory_3 JTextComponent']";
	public static final String IFCS_DATE = "//div[@class='JPanel'][1]/div[@class='ExtLabel']/div[@class='htmlString']";
	
	public static final String SEARCH_RESULTS_TABLE = "//div[starts-with(@class,'FALTableCellEditor_StrikeThru')]"; // updated
																													// on
																													// 14/02/19
	public static final String USER_LIMITS_TABLE = "//div[contains(@class,'General') and contains(@class,'Viewer')]/div[contains(@class,'General')]//div[starts-with(@class,'FALTableCellEditor_StrikeThru')]";
	public static final String CARDS_TABLE_HEADER = "//div[@class='HeaderRenderer']";
	// sasi --> Bulk Reissue
	public static final String BULK_REISSUE_TABLE = "//div[@class='JFALCompControlPanel']";
	public static final String CLICK_ADD = "//div[@class='htmlString'][contains(text(),'Add')]";
	public static final String POP_UP_APPEARS = "//div[starts-with(@id,'IFCSPopupDialog')]";
	public static final String AWAITING_CONFIRMATION = "//div[@class='VOTable']//div[contains(text(),'Awaiting')]";

	// Search Cards
	public static final String SEARCH_CARDS_SUBMENU = "//div[@class='JFALExtMenu_1 enabled JMenuItem']//div[text()='Cards']";
	public static final String SEARCH_VEHICLES_SUBMENU = "//div[@class='JFALExtMenu_1 enabled JMenuItem']//div[text()='Vehicles']";
	public static final String SEARCH_DRIVERS_SUBMENU = "//div[@class='JFALExtMenu_1 enabled JMenuItem']//div[text()='Drivers']";
	public static final String SEARCH_TRANSACTIONS_SUBMENU = "//div[@class='JFALExtMenu_1 enabled JMenuItem']//div[text()='Transactions']";
	public static final String SEARCH_DRIVERINVOICES_SUBMENU = "//div[@class='JFALExtMenu_1 enabled JMenuItem']//div[@class='htmlString'][contains(text(),'Customer Invoices')]";
	public static final String SEARCH_CARDS_TEXTBOX = "//div[@class='GeneralViewer'][descendant::div[contains(text(),'Filter')]]/div[@class='JFALCompControlPanel']//input";

	public static final String ORDER_CARD_CONTROL_TABLE = "//div[@class='JIFCSOrderCardCardControlsTable']//div[@class='JViewport'][2]/div[@style]";
	public static final String VALUE_ADDED_SERVICES_TABLE = "//div[@class='JFALTable']//div[@class='JViewport'][2]/div[@style]";
	public static final String CLICK_CREATE_PRIVATE_PROFILE = "//div[contains(text(),'Create Private Profile')]";
	public static final String CARDS_CONTROL_TABLE = "//input[starts-with(@name,'FALTableCellEditor_StrikeThruField')][starts-with(@value,'Private')]";
  
	// Subscription Table
	public static final String SUBSCRIPTION_TABLE = "//div[@class='JFALSeparator']//div[ (text()='Subscriptions')]//preceding::div[@class='JFALCompControlPanel'][1]//div";
	// Search Cards
	// public static final String SEARCH_CARDS_SUBMENU="//div[@class='JFALExtMenu_1
	// enabled JMenuItem']//div[text()='Cards']";
	// public static final String SEARCH_CARDS_TEXTBOX =
	// "//div[@class='GeneralViewer'][descendant::div[contains(text(),'Filter')]]/div[@class='JFALCompControlPanel']//input";
	// public static final String
	// POPUP_MENUITEM_ADD="//div[@class='JFALTablePopupMenuItem enabled
	// JMenuItem']/div[contains(text(),'Add')]";

	// public static final String SAVE_BUTTON="//div[@class='JFALToolBarButton
	// enabled JButton'][contains(@title,'Save') and contains(@title,'Record:Alt')
	// and contains(@title,'F2')]/div[2]";

	//public static final String VALIDATE_TASKBAR="//div[@class='JFALToolBarButton enabled JButton'][contains(@title,'Validate:Alt') and contains(@title,'F10')]/div[2]";
	public static final String CREATE_TASKBAR="//div[@class='JFALToolBarButton enabled JButton'][contains(@title,'Create:Alt') and contains(@title,'F9')]/div[@class='htmlImage']";
	public static final String VIEW_REPORT_BUTTON="//div[@class='JFALToolBarButton enabled JButton'][contains(@title,'View') and contains(@title,'Report')]/div[@class='htmlImage']";
	public static final String EXPORT_REPORT_BUTTON="//div[@class='JFALToolBarButton enabled JButton'][contains(@title,'Export') and contains(@title,'to') and contains(@title,'CSV:Alt') and contains(@title,'F12')]/div[@class='htmlImage']";

	public static final String ACCOUNT_MENU = "//div[@class='JFALExtMenu enabled JMenu JMenuItem']//u[text()='s']";
	public static final String ACCOUNT_DETAILS_SUBMENU = "//div[@class='JFALExtMenu_1 enabled JMenuItem']//div[@class='htmlString'][contains(text(),'Account') and contains(text(),'Details')]";
	// public static final String
	// CARDTRANSFER_TABLE="//div[@class='JIFCSCardTransferRequestsTable']";
	// public static final String
	// POPUP_MENUITEM_ADD_CARDTRANSFER="//div[@class='JFALTablePopupMenuItem enabled
	// JMenuItem']/div[contains(text(),'Add')]";
	// Sundry Adjustment:
	public static final String ADJUSTMENT = "//div[@class='JLabel']//div[contains(text(),'Adjustment')]";
	public static final String TRANSACTIONS = "//div[@class='JViewport']//div[@class='Navigator_NavigatorTreeCellRenderer']//div[starts-with(text(),'Transactions')]";
	public static final String POST_TRANSACTION = "//div[@class='JFALToolBarButton enabled JButton'][contains(@title,'Post') and  contains(@title,'Transaction')]/div[@class='htmlImage']";
	public static final String REPORT_TYPE_POPUP = "//div[@class='JLayeredPane']/div[contains(@class,'MetalTitlePane titlePane')]";

	public static final String REPORTS_SELECT_PANEL = "//div[@class='JIFCSCustReportAssignmentsTable']//div[@class='JScrollPane']/div[@class='JViewport']/div[@style]";
	public static final String POP_UP_MSG = "//div[@class='JDialog window modal v4init']//div[contains(text(),'Message')]";
	public static final String POP_UP_MSG_OK = "//div[@class='JDialog window modal v4init']//div[contains(text(),'OK')]";
	public static final String POPUP_MENUITEM_SELECT_PROFILE = "//div[@class='JFALTablePopupMenuItem enabled JMenuItem']//div[contains(text(),'Select') and contains(text(),'Profile')]";
	public static final String POPUP_MENUITEM_CREATE_PRIVATE_PROFILE = "//div[@class='JFALTablePopupMenuItem enabled JMenuItem']//div[contains(text(),'Create') and contains(text(),'Private')and contains(text(),'Profile')]";
	public static final String POPUP_MENUITEM_DELETE_PRIVATE_PROFILE = "//div[@class='JFALTablePopupMenuItem enabled JMenuItem']//div[contains(text(),'Delete') and contains(text(),'Private')and contains(text(),'Profile')]";

	public static final String MAINTAIN_CARDFEE_TEXT = "//div[@class='JLabel']//div[contains(text(),'Maintain') and contains(text(),'Card') and contains(text(),'Fees')]";
	public static final String CARDFEES_TABLE = "//div[@class='JFALTable']//div[@class='JViewport'][2]/div";
	public static final String AVAILABLES_PROFILE_CARDFEE_TABLE = "//div[@class='JIFCSCustomerCardFeesTable']//div[@class='JViewport'][2]/div[1]";
	public static final String AVAILABLE_PROFILE_CARDFEES_TABLE  ="//div[@class='JFALSeparator']//div[starts-with(text(),'Available')and contains(text(),'Profiles')]//preceding::div[@class='JFALCompControlPanel'][1]//div[@class='FALTableCellEditor_StrikeThruField JTextComponent']";
	public static final String CARDS_EMBOSSING_DETAILS = "//div[@class='JFALSeparator_1']//div[@class='htmlString'][contains(text(),'Card Details')]";
	// public static final String
	// SEARCH_CARD_IN_LEFT_PANEL="//div[@class='JLabel']//div[contains(text(),'Search')
	// and contains(text(),'Cards')]";
	
	public static final String ACCOUNT_CONTROLS_TABLE = "//div[@class='JIFCSCustomerAccountControlsTable']//div[@class='JViewport'][2]/div[1]";
	public static final String CARD_REISSUE_PROFILES_TABLE = "//div[@class='JIFCSCustomerCardReissueProfilesTable']//div[@class='JViewport'][2]/div[1]";
	public static final String AVAILABLES_PROFILE_CARDCONTROLS_TABLE = "//div[@class='JIFCSCustomerCardControlsTable']//div[@class='JViewport'][2]/div[1]";
	public static final String AVAILABLES_PROFILE_CARDCONTROLS_TABLE_WFE = "//div[@class='JIFCSOrderCardCardControlsTable']//div[@class='JViewport'][2]/div[1]";

	public static final String REBATE_TABLE = "//div[@class='JIFCSRebatesTable']//div[@class='JViewport'][2]/div";
	public static final String REBATE_HEADER_POPUP_TABLE = "//div[@class='ajaxswingv4 v4init'][2]//div[@class='JFALTable']";
	
	//public static final String REBATE_VALUES_POPUP_TABLE = "//div[@class='ajaxswingv4 v4init'][3]//div[@class='JFALSeparator']//div[contains(text(),'Rebate') and contains(text(),'Values')]/preceding::div[@class='JFALCompControlPanel'][1]";
	public static final String REBATE_VALUES_POPUP_TABLE = "//div[@class='ajaxswingv4 v4init'][3]//div[@class='JFALSeparator']//div[contains(text(),'Rebate') and contains(text(),'Values')]/preceding::div[@class='JFALCompControlPanel'][1]";//rathna changed
	//public static final String REBATE_CONTRIBUTIONS_POPUP_TABLE = "//div[@class='ajaxswingv4 v4init'][3]//div[@class='JFALSeparator']//div[contains(text(),'Rebate') and contains(text(),'Contributions')]/preceding::div[@class='JFALCompControlPanel'][1]";
	public static final String REBATE_CONTRIBUTIONS_POPUP_TABLE = "//div[@class='JFALSeparator']//div[contains(text(),'Rebate') and contains(text(),'Contributions')]//preceding::div[@class='JFALCompControlPanel'][1]"; //rathna changed
	
	
	
	public static final String PRICING_PROFILE_POPUP_TABLE = "//div[@class='ajaxswingv4 v4init'][2]//div[@class='JFALSeparator'][2]//div[contains(text(),'Pricing') and contains(text(),'Schemes')]/preceding::div[@class='JFALCompControlPanel'][1]";

	public static final String HIERARCHIES_TABLE = "//div[@class='JIFCSHierarchiesTable']//div[@class='JViewport'][2]/div";
	public static final String HIERARCHY_DETAIL_TABLE = "//div[@class='JIFCSMerchAgreementTable']//div[@class='JViewport'][2]/div[1]";
	public static final String TREE_PARENT_HIERARCHY = "//div[@class='JFALSeparator']//div[contains(text(),'Hierarchy') and contains(text(),'Structure')]/preceding::div[@class='JFALTree']//div[@class='htmlString']";
	public static final String BankingStatementsSubMenu = "//div[@class='ExtTree']//div[@class='htmlString'][contains(text(),'Banking') and contains(text(),'Statements')  ]";
	public static final String APPLICATION_MENU = "//div[@class='htmlString']/u[text()='A']";
	public static final String APPLICATION_SUBMENU = "//div[@class='JFALExtMenu_1 enabled JMenuItem']/div[contains(text(),'Application')]";
	// Nithya 20-02-2019
	public static final String APPROVE_ICON = "//div[@class='JFALToolBarButton enabled JButton'][contains(@title,'Approve')]/div[@class='htmlImage']";
	public static final String DECLINE_ICON = "//div[@class='JFALToolBarButton enabled JButton'][contains(@title,'Decline')]/div[@class='htmlImage']";

	// public static final String POPUP_MENUITEM_DETAILS =
	// "//div[@class='JFALTablePopupMenuItem enabled
	// JMenuItem']/div[contains(text(),'Details')]";
	// public static final String HIERARCHIES_TABLE =
	// "//div[@class='JIFCSHierarchiesTable']//div[@class='JViewport'][2]/div";
	// public static final String HIERARCHY_DETAIL_TABLE =
	// "//div[@class='JIFCSMerchAgreementTable']//div[@class='JViewport'][2]/div[1]";
	//
	public static final String SEARCH_CARD_IN_LEFT_PANEL = "//div[@class='JLabel']//div[contains(text(),'Search') and contains(text(),'Cards')]";
	// public static final String ACCOUNT_MENU = "//div[@class='JFALExtMenu enabled
	// JMenu JMenuItem']//u[text()='s']";
	// public static final String ACCOUNT_DETAILS_SUBMENU =
	// "//div[@class='JFALExtMenu_1 enabled
	// JMenuItem']//div[@class='htmlString'][contains(text(),'Account') and
	// contains(text(),'Details')]";
	public static final String LEFT_PANEL_LOCATION = "//div[@class='Navigator_NavigatorTreeCellRenderer']//div[contains(text(),'Locations')]";
	public static final String POPUP_HEADER_SEARCH = "//div[contains(@class,'IFCSPopupDialog')]//div[@class='ExtLabel']";
	public static final String SEARCH_MENU = "//div[@class='htmlString']/u[text()='e']";
	public static final String TRANSACTION_SUBMENU = "//div[@class='JFALExtMenu_1 enabled JMenuItem']/div[@class='htmlString'][text()='Transactions']";
	public static final String TRANSACTION_FILTER_FIELD = "//div[@class='JFALSeparator_1']/div[@class='htmlString'][contains(text(),'Filter')]";
	public static final String ADHOC_CELL = "//input[@value='Ad Hoc Batch']";
	public static final String BANKING_STATEMENTS_SUBMENU = "//div[@class='ExtTree']//div[@class='htmlString'][contains(text(),'Banking') and contains(text(),'Statements')  ]";
	public static final String SUSPENDED_TRANSACTION_SUBMENU = "//div[@class='Navigator_NavigatorTreeCellRenderer']//div[contains(text(),'Suspended') and contains(text(),'Transactions')]";
	
	public static final String TRANSACTIONS_SUBMENU = "//div[@class='Navigator_NavigatorTreeCellRenderer']//div[text()='Transactions']";
	public static final String IFCS_BACK_BUTTON = "//div[@class ='JFALToolBarButton enabled JButton'][@title='Back']//div[@class='htmlImage']";
	// Added by Nithya 27-02-2019
	// public static final String DATE_RANGE_FROM =
	// "//div[@class='JFALDateComboBox'][2]//div[@class='JFALDateLocaleTextField
	// JTextComponent']/input";
	// public static final String DATE_RANGE_TO =
	// "//div[@class='JFALDateComboBox'][1]//div[@class='JFALDateLocaleTextField
	// JTextComponent']/input";
	public static final String BANK_STATEMENT_NUMBER = "//div[@class='JLabel']/div[contains(text(),'Bank') and contains(text(),'Statement') and contains(text(),'Number')]/preceding::div[@class='JFALTextField JTextComponent'][1]//input";
	public static final String VALIDATION_RESULT = "//div[@class='JPanel']/div[@class='ExtLabel'][3]/div[@class='htmlString']";

	public static final String CARD_REQUEST = "//div[@class='JFALToolBarButton enabled JButton'][contains(@title,'CardRequest')]/div[@class='htmlImage'][contains(@style,'cardRequest')]";

	// Added by Sowmiya 27-02-2019
	// public static final String OK_BUTTON_POPUP = "//div[@class='JButton
	// enabled']//div[contains(text(),'OK')]";
	public static final String CARDFEES_TABLE_RIGHTCLICK="//div[@class='JIFCSOrderCardFeeProfilesTable']//div[@class='JViewport'][2]/div[@style]";
       public static final String CLOSE_BUTTON="//div[@class='JButton enabled']//img[contains(@src,'close.gif')]";
       public static final String MERCHANT_AGREEMENT_POPUP="//div[@class='ajaxswingv4 v4init'][2]//div[@class='FALTableCellEditor_StrikeThruField JTextComponent']";
	public static final String SELECT_ADD="//div[@class='JIFCSCustReportAssignmentsTable']//div[@class='JViewport'][2]/div[1]";	
//29-03-2019
	public static final String TEXTBOX_CLEAR="//div[@class='JFALTextField JTextComponent']//input";
	public static final String COST_CENTRE_TABLE="//div[@class='JFALTable']//div[@class='JScrollPane']/div[@class='JViewport']";///div[@style]";
	public static final String POPUP_MENUITEM_DELETE ="//div[@class='JFALTablePopupMenuItem enabled JMenuItem']/div[contains(text(),'Delete')]";
	//public static final String POPUP_MENUITEM_SORT = "//div[@class='JFALTablePopupMenuItem enabled JMenuItem']/div[(text()='Sort')]";
	//EMAP
	public static final String  ADD_LOACTION_IN_POPUP="//div[@class='JFALTablePopupMenuItem enabled JMenuItem']//div[contains(text(),'Add') and contains(text(), 'Location')]";
	public static final String LOCATION_HIERARCHY_IN_POPUP="//div[@class='UIFactory_3 JTextComponent']//div[contains(text(),'Location')]";
	public static final String MERCHANT_REPORT_OPTIONS_SPECIFICATION="//div[@class='UIFactory_3 JTextComponent']//div[contains(text(),'Merchant')]";
	public static final String MERCHANT_AGREEMENT_POPUP_IN_PROFILE="//div[@class='UIFactory_3 JTextComponent']//div[contains(text(),'Merchant')]";
	public static final String MAINTAIN_LOCATION_POPUP="//div[@class='ajaxswingv4 v4init']//div[@class='JLayeredPane']//div[@class='MetalTitlePane titlePane']";
	//Added by Ayub 4/4/2019
		//public static final String TRANSACTION_TABLE = "//div[@class='JFALSeparator']//div[contains(text(),'Transactions')]//preceding::div[@class='JFALCompControlPanel']//div[@class='JViewport'][2]/div";
	public static final String TRANSACTION_TABLE = "//div[@class='JFALSeparator']//div[contains(text(),'Transactions')]//preceding::div[@class='JFALCompControlPanel'][1]";
	public static final String LINE_ITEMS_TABLE = "//div[@class='JFALSeparator']//div[contains(text(),'Line') and contains(text(),'Items')]//preceding::div[@class='JFALCompControlPanel'][1]";
		//public static final String LINE_ITEMS_TABLE = "//div[@class='JFALSeparator']//div[contains(text(),'Line')]//preceding::div[@class='JFALCompControlPanel']//div[@class='JViewport'][2]/div[@style]";
		public static final String POPUP_FORCE_POST_TRANSACTION="//div[@class='ToolBarButton enabled JButton'][contains(@title,'Force') and contains(@title,'Transaction')]/div[@class='htmlImage']";
		public static final String MANUAL_TRANSACTION_VALIDATE_ICON = "//div[@class='JFALToolBarButton enabled JButton'][contains(@title,'Validate') and contains(@title,'Transaction')]/div[@class='htmlImage']";
		public static final String CLIENTGROUP_SUBMENU = "//div[@class='JFALExtMenu_1 enabled JMenuItem']//div[contains(text(),'Client') and contains(text(),'Group')]";
		public static final String USER_LIMITES="//div[@class='DefaultListCellRenderer_UIResource']//div[contains(text(),'User Override')]";	
		public static final String POPUP_CREATE_PRIVATE_PROFILE = "///div[@class='JFALTablePopupMenuItem enabled JMenuItem']//div[contains(text(),'Create Private Profile')]";
		public static final String INTERNET_USER_LOGON_ID="//div[@class='DefaultListCellRenderer_UIResource']//div[contains(text(),'Logon Id')]";
		public static final String INTERNET_USER_ACCESS_MEMBER_NO="//div[@class='DefaultListCellRenderer_UIResource']//div[contains(text(),'Member No')]";
		public static final String CLEAR_SCREEN = "//div[@class='JFALToolBarButton enabled JButton'][contains(@title,'Clear') and contains(@title,'Add:Alt') and contains(@title,'F6')]/div[@class='htmlImage']";
//	Added by sasi 09-04-2019
	public static final String SELECT_ADD_REPORT_HIER = "//div[@class='JIFCSCustomerReportsTable']//div[@class='JViewport'][2]/div[1]";
	public static final String SELECT_CHILD_ACCOUNT_IN_HIER = "//div[@class='FALTreeCellRenderer'][2]//div[2]";
//09-04-2019
	public static final String ACCOUNT_FEE_TABLE="//div[@class='JIFCSAccountFeeProfilesTable']//div[@class='JViewport'][2]/div[@style]";
//Added by Nithya 12/04/2019
	public static final String COMMON_MAIN_FRAME = "//div[contains(@class,'JScrollPane')][descendant::div[@class='GeneralViewer']]/following::div[@class='SimpleInternalFrame_GradientPanel']//div[@class='JLabel']//div[@class='htmlString']";
	public static final String REPORTS_TABLE_HEADER = "//div[@class='JFALSeparator']//div[contains(text(),'Reports')]/preceding::div[@class='JFALCompControlPanel'][1]//div[@class='JViewport']/div[@class='JTableHeader']//div[@class='HeaderRenderer']";
	public static final String REBATES_PROFILE_TABLE = "//div[@class='JFALSeparator']//div[contains(text(),'Rebate') and contains(text(),'Profiles')]/preceding::div[@class = 'JFALCompControlPanel'][2]//div[@class='FALTableCellEditor_StrikeThruField JTextComponent']";

//	Added by Meenakshi
	public static final String APPLICATION_CUSTOMER_PRICING_PROFILE = "//div[@class='JIFCSApplicationPricingProfilesTable']//div[@class='JViewport'][2]";
	public static final String APPLICATION_CARD_CONTROL_PRIVATE_PROFILE = "//div[@class='JIFCSApplicationCardControlsTable']//div[@class='JViewport'][2]/div";
	public static final String ADMIN_DESKTOP_USER_LIST = "//div[@class='JFALSeparator']//div[contains(text(),'Users')]//preceding::div[@class='JFALCompControlPanel'][1]//div[@class='JViewport'][2]";
	public static final String CARD_NUMBER_FROM_EMBOSSEDCARD = "//div[@class='JFALCompControlPanel'][6]//div[@class='htmlString']";
	public static final String EMBOSS_NAME_FROM_EMBOSSEDCARD = "//div[@class='JFALCompControlPanel'][4]//div[@class='htmlString']";
//BP  Added by sowmiya 22/04/19
	public static final String REPORT="//div[@class='JFALSeparator_1']//div[contains(text(),'Reports')]";
	public static final String READ_NEXT_IN_TRANSACTION="//div[@class='JFALToolBarButton enabled JButton'][contains(@title,'Read') and contains(@title,'Next')]/div[@class='htmlImage']";
	
	
	public static final String NOTES_TABLE="//div[@class='JFALSeparator']//div[contains(text(),'Diary') and contains(text(),'Notes')]/preceding::div[@class='JFALCompControlPanel'][1]//div[@class='JViewport'][2]//div[@style]";
 //public static final String USER_OVERRIDE = "//div[@class='DefaultListCellRenderer_UIResource']//div[contains(text(),'User Override')]";
 public static final String USER_OVERRIDE = "//div[@class='DefaultListCellRenderer_UIResource'][1]//div";
//	Added by Sasi 24-04-2019
	public static final String INTERNET_USER_ACCESS_TABLE_HEADER = "//div[@class='JFALSeparator']//div[contains(text(),'Users') and contains(text(),'Access')][not(contains(text(),'Alert'))]/preceding::div[@class='JFALCompControlPanel'][1]//div[@class='HeaderRenderer']//div[@class='htmlString']";
	public static final String INTERNET_USER_ACCESS_TABLE_DATA = "//div[@class='JFALSeparator']//div[contains(text(),'Users') and contains(text(),'Access')][not(contains(text(),'Alert'))]/preceding::div[@class='JFALCompControlPanel'][1]//div[starts-with(@class,'FALTableCellEditor_StrikeThru')]";
	//div[@class='JFALSeparator']//div[contains(text(),'Internet') and contains(text(),'Users')][not(contains(text(),'Access'))]/preceding::div[@class='JFALCompControlPanel'][1]//div[@class='HeaderRenderer']//div[@class='htmlString']
	
	public static final String INTERNET_USER_TABLE_HEADER = "//div[@class='JFALSeparator']//div[contains(text(),'Internet') and contains(text(),'Users')][not(contains(text(),'Access'))]/preceding::div[@class='JFALCompControlPanel'][1]//div[@class='HeaderRenderer']//div[@class='htmlString']";
	public static final String INTERNET_USER_TABLE_DATA = "//div[@class='JFALSeparator']//div[contains(text(),'Internet') and contains(text(),'Users')][not(contains(text(),'Access'))]/preceding::div[@class='JFALCompControlPanel'][1]//div[starts-with(@class,'FALTableCellEditor_StrikeThru')]";
	//Added by mamtha
	public static final String CARD_OFFERS="//div[@class='JFALTable']//div[@class='JScrollPane']/div[@class='JViewport']/div[@style]";
	public static final String CARD_CONTROLS="//div[@class='JFALTable']//div[@class='JScrollPane']/div[@class='JViewport']/div[@style]";
	public static final String TAX_STATUS="//div[@class='JFALTablePopupMenuItem enabled JMenuItem']/div[contains(text(),'Add')]";
	public static final String CLONE_RECORD = "//div[@class='JFALToolBarButton enabled JButton'][contains(@title,'Clone') and contains(@title,'F3')]/div[@class='htmlImage']";
	//Added by sowmiya  Chevron
	public static final String AACOUNT_TAXSTATUS="//div[@class='JFALTable']//div[@class='JScrollPane']/div[@class='JViewport']/div[@style]";
//	Added by Sasi 26-04-2019	
	public static final String POPUP_POST_TRANSACTION="//div[@class='ToolBarButton enabled JButton'][starts-with(@title,'Post') and contains(@title,'Transaction')]/div[@class='htmlImage']";

//05-10-2019
	public static final String APPLY_ALL_CARDS_ICON="//div[@class='JFALToolBarButton enabled JButton'][contains(@title,'Apply')]/div[@class='htmlImage'][contains(@style,'cardRequest')]";
    public static final String YES_POPUP="//div[@class='htmlString'][contains(text(),'Yes')]";
    //Added by sowmiya OTI Ajaxswing 
    public static final String ACCOUNT_STATUS="//div[@class='JFALSeparator_1']//div[contains(text(),'Account') and contains(text(),'Status')]";
//05/27/2019
    public static final String CARD_OFFER_TABLE="//div[@class='JFALSeparator']//div[contains(text(),'Card') and contains(text(),'Offer')]/preceding::div[@class='JViewport'][1]/div[1]";

//31/05/2019
    public static final String DRIVERNAME_CARDMAINTENANCE="//div[@class='JFALLabel']/div[contains(text(),'Driver') and contains(text(),'Name')]/preceding::div[@class='JFALCompControlPanel'][1]/div[@class='JFALTextField JTextComponent']/input";
    public static final String SHORTNAME_CARDMAINTENANCE="//div[@class='JFALLabel']/div[contains(text(),'Short') and contains(text(),'Name')]/preceding::div[@class='JFALCompControlPanel'][1]/div[@class='JFALTextField JTextComponent']/input";
    //Added by Nithya 27/05/2019
	public static final String REBATE_TABLE_HEADER = "//div[@class='JFALSeparator']//div[contains(text(),'Rebate') and contains(text(),'Profiles')]/preceding::div[@class = 'JFALCompControlPanel'][2]//div[@class='HeaderRenderer']";
	//Added by Nithya 03/06/2019
	public static final String APPLICATION_TYPE_TRANSFER ="//div[@class='JIFCSApplicationTypeTransferTable']//div[@class='JViewport']/div[@style]";
	public static final String CARD_FEE_PROFILE_APPL_TYPE_TRANS = "//div[@class='JFALCompControlPanel'][2]//div[contains(@class,'FALTableCellEditor_StrikeThru')]";
	public static final String CARD_CONTROl_PROFILE_APPL_TYPE_TRANS = "//div[@class='JFALSeparator']//div[@class='htmlString'][contains(text(),'Card') and contains(text(),'Control')]/preceding::div[@class='JFALTable']//div[contains(@class,'FALTableCellEditor_StrikeThru')]";
	public static final String CARD_PRODUCTS_TABLE = "//div[@class='FALTableCellEditor_StrikeThruField JTextComponent']";
	
	public static final String APPLICATION_TYPE_PREPAY = "input[value='PrePay']";
	
	//Prakalpha -->11/11/2019
	public static final String REPLACED_CARD="//div[@class ='JFALToolBarButton enabled JButton'][contains(@title,'Replace') and contains(@title,'Card') ]/div[@class='htmlImage']";
	public static final String PREVIOUS_CARD="//div[@class ='JFALToolBarButton enabled JButton'][contains(@title,'Previous') and contains(@title,'Card') ]/div[@class='htmlImage']";

//Nithya --> 14/11/2019
public static final String FEECONFIG_TABLE = "//div[@class='JFALSeparator'][2]//div[contains(text(),'Fees')]/preceding::div[@class='JFALCompControlPanel'][1]//div[starts-with(@class,'FALTableCellEditor_StrikeThru')]//input[contains(@id,'0_0')]";
	public static final String FEEAGREEMENT_TABLE = "//div[@class='JFALSeparator'][1]//div[contains(text(),'Fees')]/preceding::div[@class='JFALCompControlPanel'][1]";
	public static final String FEEVALUES_TABLE = "//div[@class='JFALSeparator']//div[contains(text(),'Fee') and contains(text(),'Values')]/preceding::div[@class='JFALCompControlPanel'][1]";
        public static final String EXTERNALREF_NUM_APP = "//div[@class='JLabel']/div[contains(text(),'Viewer')]/preceding::div[@class='JFALCompControlPanel'][8]/div[@class='JFALTextField JTextComponent']/input";
	public static final String APPLICATION_SEARCH_FIRST ="//div[@class='VOTable']//div[@class='FALTableCellEditor_StrikeThruField JTextComponent'][1]//div[@class='htmlString']";
	public static final String Customer_SEARCH_FIRST ="//div[@class='VOTable']//div[@class='FALTableCellEditor_StrikeThruField JTextComponent'][1]//input";
	
	
	//Srilatha --> 18/11/2019 
	public static final String ACCOUNTTYPE_SELECTED = "(//div[@class='JFALComboBox_CustomComboboxRenderer']/div[@class='htmlString'])[7]";
	public static final String CARDPROGRAMS_BPPREPAID_CARDS = "input[value='BP PrePay Cards']";
	public static final String DRIVER_NAME ="//div[@ajs_id='driverVO.driver_name']//input";

		 public static final String LOGON_ID_TEXT_BOX = "(//div[@class='JFALTextField JTextComponent']/input)[5]";
	    public static final String SEARCH_TORCH_USERS = "(//div[@class='JFALToolBarButton enabled JButton']/div[2])[2]";
	    public static final String INTERNET_USERS_ACCESS_TABLE_VALUES = "//div[@class='JFALCompControlPanel']/div/div/div[@class='JViewport']/div/div[@class='FALTableCellEditor_StrikeThruField JTextComponent']/input";
	    public static final String MEMBERTYPE_INTERNET_USER_ACCESS_POPUP = "(//div[@class='GeneralViewer']/div[@class='JFALCompControlPanel'])[24]";
	    
	    //Nithya --> 29/22/2019
	    public static final String PRICING_PROFILE_HEADER  = "//div[@class='JFALSeparator']//div[contains(text(),'Pricing') and contains (text(),'Profile') and not(contains(text(),'Customer'))]/preceding::div[@class='JFALCompControlPanel'][1]//div[@class='JViewport']/div[@class='JTableHeader']//div[@class='HeaderRenderer']";
	    public static final String CARD_MAINTENANCE_PROFILE_TAB = "//div[@class='JFALTabbedPane']/div[contains(text(),'Profiles')]";
	    public static final String PROFILE_TABLE_FROM_CARD_MAITENANCE = "((//div[@class='VOTable'])[1]/div[@class='FALTableCellEditor_StrikeThruField JTextComponent'])[1]/input";
	    public static final String READ_PROFILE_DESCRIPTION = "//div[@class='FALTableCellEditor_StrikeThruField JTextComponent']/div[@class='htmlString']";
	    public static final String PROFILE_DESCRIPTION = "//div[@class='JFALTextField JTextComponent']/input";
//Sasi --> 20/12/2019
	public static final String CALENDAR_FREQUENCIES = "//div[@class='JFALSeparator']//div[@class='htmlString'][contains(text(),'Frequencies')]/preceding::div[@class='JFALCompControlPanel']";
	public static final String REFERENCE_TEXT_BOX = "//div[@ajs_id='reference']//div[@class='htmlString']";
	public static final String CUS_TAX_TOTAL_TEXT_BOX = "//div[@ajs_id='customer_tax_amount']//div[@class='htmlString']";
	public static final String MERC_TAX_TOTAL_TEXT_BOX = "//div[@ajs_id='merchant_tax_amount']//div[@class='htmlString']";

	public static final String CUS_VALUE_TEXT_BOX = "//div[@ajs_id='customer_amount_with_currency']//div[@class='htmlString']";
	public static final String MERC_VALUE_TEXT_BOX = "//div[@ajs_id='merchant_amount']//div[@class='htmlString']";
//Naveen
	public static final String MERCHANT_NUMBER = "//div[@class='JFALLabel']//div[starts-with(text(),'Merchant')and contains(text(),'No')]//preceding::div[@class='JFALCompControlPanel'][1]//div[@class='BasicComboBoxEditor_BorderlessTextField JTextComponent']/input";
	public static final String LOCATION_NUMBER = "//div[@class='JFALLabel']//div[starts-with(text(),'Location')and contains(text(),'No')]//preceding::div[@class='JFALCompControlPanel'][1]//div[@class='BasicComboBoxEditor_BorderlessTextField JTextComponent']/input";
// sundry transaction posting	
	public static final String SUNDRY_POST_TRANSACTION = "//div[@class='JFALToolBarButton enabled JButton'][contains(@title,'Post') and  contains(@title,'Transaction')]/div[@class='htmlImage']";
	public static final String CLIENT_DROPDWON = "//div[@class='JFALLabel']//div['Client']//preceding::div[@class='JFALCompControlPanel'][1]/div[@class='JFALComboBox']//div[@class='MetalComboBoxButton enabled JButton']";
	public static final String SELECT_CLIENT_AS_Z = "//div[@class='BasicComboPopup_1']/div/div[@class='htmlString' and contains(text(),'Z') and contains(text(),'Energy')and contains(text(),'Limited')]";
	public static final String ADJUSTMENT_TYPE = "//div[@class='JFALLabel']//div['Adjustment Type']//preceding::div[@class='JFALCompControlPanel'][1]/div[@class='JFALComboBox']//div[@class='MetalComboBoxButton enabled JButton']";
	
	//raxsana
	public static final String PROCESS_ALLOCATION_ICON="//div[@class='JFALExtToolBar']//div[contains(@title,'Process') and contains(@title,'allocations')]//div[@class='htmlImage']";
}
