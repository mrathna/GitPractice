package com.framework.testcases.OLS.ZEnergy.Customer;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.OLS.common.LoginPage;
import com.framework.pages.Z.ZLoginPage;

public class VerifyContactUsPage extends BaseTest {

	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "Smoke" })
	public void verifyContactUsPageDetails(@Optional("Z") String clientCountry,
			@Optional("ZEnergy") String clientName) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  Verify Contact Us Page", "Verifying the Contact Us Page");

		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		ZLoginPage zLoginPage = new ZLoginPage(driver, test);
		// launch login page
		loginPage.validateLoginPageFooterLinks(clientName, "ZEnergy_URL");
		// Click on ContactUs link
		zLoginPage.clickContactUsAndValidateTitle();
		// Logo validation
		zLoginPage.validateClientLogo();
		// Mandatory field validation
		zLoginPage.clickSubmitWithEmptyFieldAndValidate();
		// All fields validation
		// zLoginPage.validateContactUsFieldsPresence(); // Need to remove
		// Enter contactUs details
		zLoginPage.enterContactUsDetails();
		// Click on Submit button
		zLoginPage.clickContactUsSubmit();
	}
}
