package com.framework.pages.OLS.common;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.ExtentTest;
import com.framework.basepage.BasePage;
import com.framework.pages.AJS.common.Common;
import com.framework.repo.Locator;

public class FindAndExportTransactionPage extends BasePage {

	@FindBy(how = How.ID, using = Locator.TRANSACTIONS_MENU)
	public WebElement transactionMenu;
	@FindBy(how = How.ID, using = Locator.FIND_EXPORT_TRANSC)
	public WebElement findExportTransactionSubmenu;
	@FindBy(how = How.XPATH, using = Locator.TRANSACTION_PAGE_TITLE)
	public WebElement transactionPageTitle;
	@FindBy(how = How.ID, using = Locator.FROM_DATE)
	public WebElement fromDateField;
	@FindBy(how = How.ID, using = Locator.TO_DATE)
	public WebElement toDateField;
	@FindBy(how = How.ID, using = Locator.SEARCH_BTN)
	public WebElement searchButton;
	@FindBy(how = How.XPATH, using = Locator.TRANSACTION_LIST_TABLE)
	public WebElement transactionListPage;
	@FindBy(how = How.ID, using = Locator.SET_LOCATION_NUM)
	public WebElement locationNumberField;
	@FindBy(how = How.ID, using = Locator.EXPORT_BATCHES)
	public WebElement transactionListExportButton;
	@FindBy(how = How.ID, using = Locator.TRANSACTION_LIST_SELECT_ROW)
	public WebElement selectRowFromTransactionList;
	@FindBy(how = How.ID, using = Locator.TRANSACTION_LINE_ITEM_PAGE_TITLE)
	public WebElement transactioLineItemTable;
	@FindBy(how = How.ID, using = Locator.TRANSACTION_LINE_ITEM_FIRSTROW)
	public WebElement transactioLineItemFirstRow;
	@FindBy(how = How.ID, using = Locator.BACK_TO_ADHOC_REPORT_LINK)
	public WebElement backToTransactionList;
	@FindBy(how = How.ID, using = Locator.TRANSACTION_DETAILS_BUTTON)
	public WebElement transactionDetailsButton;
@FindBy(how = How.XPATH, using = Locator.RESULT_FOUND)
	public WebElement resultFound;
	
	@FindBy(how = How.XPATH, using = Locator.TRANSACTION_TABLE_EXCLUDING_HEADER)
	public WebElement transactionTableExcludingHeader;


	public FindAndExportTransactionPage(WebDriver driver, ExtentTest test) {
		super(driver, test);
		PageFactory.initElements(driver, this);
	}

	@FindBy(id = Locator.SEARCH_ALL_PAGE)
	public WebElement searchTransactions;

	@FindBy(id = Locator.TRA_DETAILS_TBL)
	public WebElement transactionTable;

	@FindBy(id = Locator.ADV_SEARCH_LINK)
	public WebElement advancedSearchOptions;

	@FindBy(id = Locator.RECEIPT_NUM)
	public WebElement receiptValueField;

	@FindBy(id = Locator.DATE_RANGE)
	public WebElement dateRangeDropdown;

	@FindBy(id = Locator.TO_DATE)
	public WebElement dateRangeToDate;

	@FindBy(id = Locator.FROM_DATE)
	public WebElement dateRangeFromDate;

	@FindBy(id = Locator.EXPORT_TRA_TOP)
	public WebElement exportTransactions;

	@FindBy(xpath = Locator.TRANSACTION_TABLE_CONTENT)
	public List<WebElement> transactionsInTable;

	@FindBy(css = Locator.TRANSACTION_TABLE_ROWS)
	public List<WebElement> transactionTableRows;

	@FindBy(xpath = Locator.VIEW_TRANSACTION)
	public WebElement viewTransaction;

	@FindBy(xpath = Locator.GO_TO_CARD)
	public WebElement goToCard;

	@FindBy(xpath = Locator.PAGE_TITLE_DP)
	public WebElement commonTitle;

	@FindBy(xpath = Locator.RETURN_TO_TRANSACTION_LIST)
	public WebElement returnToTransactionList;
	
	@FindBy(xpath = Locator.TABLE_PAGINATION)
	public List<WebElement> tablePaginationCheck;
	
	@FindBy(xpath = Locator.TABLE_PAGINATION)
	public WebElement tablePagination;

	String receiptValue, transactionDate,accountNo, searchResultReceiptValue, fromDateString = "";
	boolean isTransactionFound = true;
	int transactionWithNoProduct, transactionWithCardNumber;
	Common common=new Common(driver,test);
	
	public void clickSearchTransactions() {
		isDisplayedThenClick(searchTransactions, "Search Transactions");
		sleep(3);
	}

	public void setReceiptValueAndDateFromSearchResults() {
		try {
			if (transactionTable.isDisplayed()) {
				setCellDataFromTable(transactionTable, 8, false);
				receiptValue = getCellDataFromTable(1, 3, false);
				transactionDate = getCellDataFromTable(1, 0, false).split(" ")[0];
				accountNo = getCellDataFromTable(1, 2, false);
				
				System.out.println("receiptValue : "+receiptValue);
				System.out.println("transactionDate : "+transactionDate);
				System.out.println("accountNo : "+accountNo);
			}
		} catch (Exception ex) {
			logInfo(ex.getMessage());
			logInfo("No transactions found");
			isTransactionFound = false;
		}
	}

	public boolean isTransactionFound() {

		return isTransactionFound;
	}

	public void clickAdvancedSearchOptions() {
		isDisplayedThenClick(advancedSearchOptions, "Advanced Search Options");
		sleep(3);
	}

	public void enterReceiptValue() {
		isDisplayedThenEnterText(receiptValueField, "Receipt Value", receiptValue);
	}

	public void selectADateRangeFropDropdown(String dateRange) {
		selectDropDownByVisibleText(dateRangeDropdown, dateRange);
		sleep(3);
	}

	public void selectADateRangeInSearchTransaction(String currentIFCSDate) {
		fromDateString=common.enterADateValueInStatusBeginDateField("PastSix",currentIFCSDate);
		//transactionDate="26/03/2018";
		isDisplayedThenEnterText(dateRangeFromDate, "From Date", fromDateString);
		//isDisplayedThenEnterText(dateRangeToDate, "To Date", transactionDate);
	}

	public void verifySearchTransactionTable() {
		setCellDataFromTable(transactionTable, 8, false);
		searchResultReceiptValue = getCellDataFromTable(1, 3, false);
		if (searchResultReceiptValue.contains(receiptValue)) {
			logPass("Search transaction returns relevant transaction for receipt value");
		} else {
			logFail("Search transaction doenot having relevant transaction");
		}
	}

	public void clickExportTransaction() {
		isDisplayedThenClick(exportTransactions, "Export transaction");
	}

	public void chooseTransactionWithNoProduct() {
		try {
			if (transactionTable.isDisplayed()) {
				setCellDataFromTable(transactionTable, 8, false);
				for (int i = 1; i <= getRowSize(transactionTable); i++) {
					if (getCellDataFromTable(i, 5, false).contains("")) {
						transactionWithNoProduct = i;
						break;
					}
				}
			}
		} catch (Exception ex) {
			logInfo(ex.getMessage());
			logInfo("No transactions found");
			isTransactionFound = false;
		}
	}

	public void chooseTransactionWithCardNumber() {
		try {
			if (transactionTable.isDisplayed()) {
				setCellDataFromTable(transactionTable, 8, false);
				for (int i = 1; i <= getRowSize(transactionTable); i++) {
					if (getCellDataFromTable(i, 1, false).length() > 0) {
						transactionWithCardNumber = i;
						break;
					}
				}
			}
		} catch (Exception ex) {
			logInfo(ex.getMessage());
			logInfo("No transactions found");
			isTransactionFound = false;
		}
	}

	public void clickOnTransactionWithNoProduct() {
		if (transactionWithNoProduct >= 0) {
			isDisplayedThenClick(transactionsInTable.get(transactionWithNoProduct - 1), "Transaction With No Product");
			sleep(3);
		} else {
			logFail("No transactions without product is present");
		}
	}

	public void clickOnTransactionWithCardNumber() {
		if (transactionWithCardNumber >= 0) {
			isDisplayedThenClick(transactionsInTable.get(transactionWithCardNumber - 1), "Transaction With No Product");
			sleep(3);
		} else {
			logFail("No transactions with card number");
		}
	}

	public void clickViewTransaction() {
		isDisplayedThenClick(viewTransaction, "View Transaction");
		sleep(3);
	}

	public void clickGoToCard() {
		isDisplayedThenClick(goToCard, "Go to card");
		sleep(3);
	}

	public void verifyTransactionPageTitle(String expectedTitle) {
		if (getText(commonTitle).contains(expectedTitle)) {
			logPass("View Transaction Detail page loaded");
		} else {
			logFail("View Transaction Detail page not loaded");
		}
	}

	public void clickReturnToTransactionList() {
		isDisplayedThenClick(returnToTransactionList, "Return to transaction list");
		sleep(3);
	}

	public void selectFindAndExportTransactionPage() {

		clickSubMenuAndValidate(transactionMenu, findExportTransactionSubmenu, transactionPageTitle);

	}

	public void enterFromAndToDate() {

		isDisplayedThenEnterText(fromDateField, "Enter From Date", "07/11/2012");
		sleep(1);
		isDisplayedThenEnterText(toDateField, "Enter To Date", "06/02/2013");

	}

	public void clickSearchAndValidate() {

		isDisplayedThenActionClick(searchButton, "Click Search Button");
		sleep(3);
		isDisplayed(transactionListPage, "Transaction List displayed");
	}

	public void clickSearch() {

		isDisplayedThenActionClick(searchButton, "Click Search Button"); 
		
	}
	
	public boolean validateTheSearchResults()
	{		 
		
		boolean isNoTransactionFound = waitForTextToAppear("No transactions found", 30);	
		
		System.out.println("isNoTransactionFound"+isNoTransactionFound);
		
		if(isNoTransactionFound)
		{
			logInfo("No transactions found for the search filter provided - It depends on IFCS desktop");
		}
		else
		{
			isDisplayed(transactionListPage, "Transaction List displayed");
			sleep(10);
		}
		
		return isNoTransactionFound;
	}

	public void enterLocationNumber() {

		isDisplayedThenEnterText(locationNumberField, "Set the Location Number", "00005354");

	}

	public void clickExportButton() {

		isDisplayedThenActionClick(transactionListExportButton, "Click the Transaction List Export Button");
		sleep(3);
	}

	public void selectTransactionAndValidate() {

		isDisplayedThenActionClick(selectRowFromTransactionList, "Select First Row from the table");
		sleep(1);
		if (transactionDetailsButton.isDisplayed()) {
			System.out.println("Inside IF");
			isDisplayedThenActionClick(transactionDetailsButton, "Click Transaction Details");
		}
		sleep(5);
		verifyText(transactionPageTitle, "Transaction Detail");
	}

	public void validateAndSelectTransactionLineItem() {
		scrollDownPage();
		sleep(3);
		isDisplayed(transactioLineItemTable, "Transaction Line Items Displayed");
		isDisplayedThenClick(transactioLineItemFirstRow, "Click the First Row from Transaction Line Item");
		sleep(5);
		verifyText(transactionPageTitle, "Line Item Detail");

	}

	public void clickBackToTransactionList() {

		isDisplayedThenActionClick(backToTransactionList, "Click Back To Transaction List");
		sleep(3);
		verifyText(transactionPageTitle, "Transaction Detail");
		isDisplayedThenActionClick(backToTransactionList, "Click Back To Transaction List");
		sleep(3);
		verifyText(transactionPageTitle, "Transaction List");
	}
	
	//Sasi 17-04-2019
	public String gettingAccountNoFromSearchTableResults() {
		try {
			if (transactionTable.isDisplayed()) {
				setCellDataFromTable(transactionTable, 8, false);
				accountNo = getCellDataFromTable(1, 2, false);
			
				System.out.println("accountNo : "+accountNo);
			}
		} catch (Exception ex) {
			logInfo(ex.getMessage());
			logInfo("No transactions found");
			isTransactionFound = false;
		}
		return accountNo;
	}
	
	public String gettingDateFromSearchTableResults() {
		try {
			if (transactionTable.isDisplayed()) {
				setCellDataFromTable(transactionTable, 8, false);
				transactionDate = getCellDataFromTable(1, 0, false).split(" ")[0];
				
				System.out.println("transactionDate : "+transactionDate);
			}
		} catch (Exception ex) {
			logInfo(ex.getMessage());
			logInfo("No transactions found");
			isTransactionFound = false;
		}
		return transactionDate;
	}
	
	public int totalResultsFound() {
		String com = getText(resultFound);
		String results = com.split(" ")[0];
		int counts = Integer.parseInt(results);			
		System.out.println(counts);
		return counts;
	}

	public int totalRowSizeExcludingHeader() {
		int rowFound = getRowSize(transactionTableExcludingHeader);
		return rowFound;
	}
	
	public boolean validateIfPaginationPresents()
	{		 
		boolean isNoTransactionFound=false; 
		scrollDownPage();
		int size=tablePaginationCheck.size();
		for(int i=1;i<=size;i++) {
		isNoTransactionFound = waitToCheckElementIsDisplayed(By.xpath("//a[contains(@class,'rf-ds-nmb-btn')]["+i+"]"),30);
		}
		scrollUpPage();
		sleep(3);
		return isNoTransactionFound;
	}


}
