using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using Common;
using Common.PageObjects;
using Common.ScenarioConfigurations;
using Common.Utility;

namespace EnCompass.Testing.Source.PageObjects.Organization.ExpenseManager.Transactions 
{
	/// <summary>
	/// Auto-generated Page Model Class
	/// Navigation Paths: 
		/// [Organization Home]->Transactions->Financial Codes->Priority
		/// </summary>
	[PageModel(@"/expenseManager/transactions/assignPriorities.aspx")]
	public partial class AssignPriorities : EnCompassOrgPageModel 
	{
		public override string RelativeUrl => @"/expenseManager/transactions/assignPriorities.aspx";
		public override string PageIdentifierXPath_Generated => @"//li[contains(@class, 'breadcrumb-item active')][text() = 'Priority']";

		#region Navigation
				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Create or Edit']")]
		private IWebElement _transactions_FinancialCodes_Priority_CreateOrEdit { get; set; }
		public void NavigateTo_Transactions_FinancialCodes_Priority_CreateOrEdit()
		{
			NavigateToMenuItem(_transactions_FinancialCodes_Priority_CreateOrEdit);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Profiles']")]
		private IWebElement _transactions_FinancialCodes_Priority_Profiles { get; set; }
		public void NavigateTo_Transactions_FinancialCodes_Priority_Profiles()
		{
			NavigateToMenuItem(_transactions_FinancialCodes_Priority_Profiles);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Map Codes']")]
		private IWebElement _transactions_FinancialCodes_Priority_MapCodes { get; set; }
		public void NavigateTo_Transactions_FinancialCodes_Priority_MapCodes()
		{
			NavigateToMenuItem(_transactions_FinancialCodes_Priority_MapCodes);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Priority']")]
		private IWebElement _transactions_FinancialCodes_Priority_Priority { get; set; }
		public void NavigateTo_Transactions_FinancialCodes_Priority_Priority()
		{
			NavigateToMenuItem(_transactions_FinancialCodes_Priority_Priority);
		}

		
		private void NavigateToMenuItem(IWebElement element)
		{
			Driver.Url = element.GetAttribute("href");
		}
		#endregion

		public AssignPriorities(GlobalSettings settings) : base(settings) { }
	}  
}
