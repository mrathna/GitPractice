﻿using Common.Utility;
using EnCompass.Testing.Source.PageObjects.Controls;
using NFluent;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EnCompass.Testing.Source.PageObjects.Organization.ExpenseManager.TransactionEnvelope
{
	public partial class View
	{
        #region XPath page Elements

        private const string _searchCriteriaSearchTermXPath = @"//div[contains(@id, 'SearchOutput')]//following-sibling::select[contains(@id, 'searchTermSelect')]";
        private const string _searchCriteriaFilterTypeXPath = @"//select[contains(@id, 'SearchOutput_searchTermSelect')]";
        private const string _searchCriteriaTextSearchValueXPath = @"//select[contains(@id, 'SearchOutput_searchTermSelect')]";
        private const string _searchCriteriaListboxSearchValueXPath = @"//select[contains(@id, 'SearchOutput_values')]";
        private const string _searchCriteriaResetBtnXPath = @"//button[@type='button' and text()='Clear']";
        private const string _searchCriteriaAddBtnXPath = @"//input[@type='button' and @value='Add']";
        private const string _searchXPath = @"//input[contains(@id, 'btnSearch')]";
        private const string _pagingXPath = @"//select[contains(@id, 'Top_pageSizesDropdown')]";
        private const string _dateRangeOptionXPath = @"//select[contains(@id, 'DateRanges_ddlOptions')]";
        private const string _dateRangePeriodXPath = @"//select[contains(@id, 'DateRanges_ddlPeriod')]";
        private const string _addNewLinkXPath = @"//a[@href='create.aspx']";
        private const string _noRecordsMessageXPath = @"//td[@class='gridNoRecordsMessage']";
        private const string _actionLinkDeleteXPath = @"//a[contains(@id,'actionLink')][text()='Delete']";
        private const string _viewHistoryRespondXPath = @"//a[contains(@id,'actionLink') and text()='Transactions']";
        private const string _trDgEnvelopesXPath = "//tr[contains(@id,'dgEnvelopes') and contains(@onclick,'dgEnvelopes')]";
        private const string _actionLinkTransXPath = "//a[contains(@id,'actionLink')][text()='Transactions']";
        private const string _actionLinkPrintXPath = "//a[contains(@id,'actionLink')][text()='Print']";
        private const string _actionLinkReceiptsXPath = "//a[contains(@id,'actionLink')][text()='Receipts']";
        #endregion

        #region Page Elements

        private IWebElement _searchCriteriaSearchTerm
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_searchCriteriaSearchTermXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_searchCriteriaSearchTerm element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _searchCriteriaFilterType
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_searchCriteriaFilterTypeXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_searchCriteriaFilterType element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _searchCriteriaTextSearchValue
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_searchCriteriaTextSearchValueXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_searchCriteriaTextSearchValue element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _searchCriteriaListboxSearchValue
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_searchCriteriaListboxSearchValueXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_searchCriteriaListboxSearchValue element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _searchCriteriaResetBtn
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_searchCriteriaResetBtnXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_searchCriteriaResetBtn element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _searchCriteriaAddBtn
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_searchCriteriaAddBtnXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_searchCriteriaAddBtn element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _search
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_searchXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_search element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _paging
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_pagingXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_paging element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _dateRangeOption
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_dateRangeOptionXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_dateRangeOption element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _dateRangePeriod
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_dateRangePeriodXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_dateRangePeriod element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _addNewLink
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_addNewLinkXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_addNewLink element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _noRecordsMessage
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_noRecordsMessageXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_noRecordsMessage element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _actionLinkDelete
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_actionLinkDeleteXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_actionLinkDelete element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _viewHistoryRespond
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_viewHistoryRespondXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_viewHistoryRespond element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        #endregion

        //New Method
        private GridControl _envelopesItemsGrid;
        public GridControl EnvelopesItemsGrid
        {
            get
            {
                _envelopesItemsGrid = new GridControl("dgEnvelopes", Driver);
                _envelopesItemsGrid.WaitForGrid();

                return _envelopesItemsGrid;
            }
        }

        //New Method
        public void SelectFirstRowEnvelopeItems(string envelopeName)
        {
            Settings.EnCompassWebDriver.WaitForVisible(By.XPath("//td[text()='" + envelopeName + "']"));
            EnvelopesItemsGrid.SelectFirstRow();
        }

        //New Method
        public void ViewHistoryRespond() { _viewHistoryRespond.JSClickWithFocus(Driver); }

        public void SetSearchCriteriaSearchTerm(string whichText)
		{
			var selectElement = new SelectElement(_searchCriteriaSearchTerm);
			selectElement.SelectByText(whichText);
		}

		public void SetSearchCriteriaSearchTermByValue(string whichText)
		{
			var selectElement = new SelectElement(_searchCriteriaSearchTerm);
			selectElement.SelectByValue(whichText);
		}

		public string SearchCriteriaTextSearchValue
		{
			set
			{
				_searchCriteriaTextSearchValue.SendKeys(value);
			}
		}

		public void SetSearchCriteriaListboxSearchValue(string whichText)
		{
			var selectElement = new SelectElement(_searchCriteriaListboxSearchValue);
			selectElement.SelectByText(whichText);
		}

		public void Reset()
		{
			_searchCriteriaResetBtn.JSClickWithFocus(Driver);
		}
		public void Add()
		{
			_searchCriteriaAddBtn.JSClickWithFocus(Driver);
		}

		public void Search()
		{
			_search.JSClickWithFocus(Driver);
			WaitForLoad();
		}

		private GridControl _txnEnvelopeGrid;
		public GridControl TransactionEnvelopeGrid
		{
			get
			{
                _txnEnvelopeGrid = new GridControl("dgEnvelopes", Driver);
                _txnEnvelopeGrid.WaitForGrid();

                return _txnEnvelopeGrid;
			}
		}

        public void VerifyTransactionEnvelopeByEnvNameandMenus(string EnvName)
        {
            SetSearchCriteriaSearchTerm("Envelope Name");
            SearchCriteriaTextSearchValue = EnvName;
            Search();
            WaitForLoad();
            Settings.EnCompassWebDriver.WaitForVisible(By.XPath(_trDgEnvelopesXPath));            
            TransactionEnvelopeGrid.SelectFirstRow();
            Settings.EnCompassWebDriver.WaitForVisible(By.XPath(_actionLinkTransXPath));
            Settings.EnCompassWebDriver.WaitForVisible(By.XPath(_actionLinkPrintXPath));
            Settings.EnCompassWebDriver.WaitForVisible(By.XPath(_actionLinkDeleteXPath));
            Settings.EnCompassWebDriver.WaitForVisible(By.XPath(_actionLinkReceiptsXPath));
        }

		public void SetPaging(string size)
		{
			TransactionEnvelopeGrid.SetPageSize(200);
		}

		public string SetDateRangeOption
		{
			get { return new SelectElement(_dateRangeOption).SelectedOption.Text; }
			set { _dateRangeOption.SetListboxByText(value); }
		}

		public string SetDateRangePeriod
		{
			get { return new SelectElement(_dateRangePeriod).SelectedOption.Text; }
			set { _dateRangePeriod.SetListboxByText(value); }
		}

		public void AddNew()
		{
			_addNewLink.JSClickWithFocus(Driver);
		}

        public string NoTransactionEnvelopesMessage
        {
            get { return _noRecordsMessage.Text; }
        }
        public void SearchWithoutCriteria(string noEnvelopeMessage)
        {
            Reset();
            Search();
            WaitForLoad();
            Check.That(NoTransactionEnvelopesMessage).Contains(noEnvelopeMessage);
        }
        public void DeleteandAccept()
        {
            _actionLinkDelete.JSClickWithFocus(Driver);
            DeleteOnModal();
            WaitForLoad();
        }
    }
}
