package com.framework.pages.AJS;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

import com.aventstack.extentreports.ExtentTest;
import com.framework.basepage.BasePage;
import com.framework.pages.AJS.common.Common;
import com.framework.pages.AJS.common.IFCSHomePage;
import com.framework.repo.Locator_IFCS;
import com.framework.util.PropUtils;
import com.framework.util.SeleniumWrappers;

@SuppressWarnings("rawtypes")
public class CardMaintenancePage extends BasePage {

	String expiryDateChangedCard;
	String ActiveCardNumber;
	String CurrentDBDate;
	String lostCardNumber;

	@FindBy(xpath = Locator_IFCS.REPORT_TYPE_POPUP)
	public WebElement reportTypePopUp;
	@FindBy(xpath = Locator_IFCS.CARDS_EMBOSSING_DETAILS)
	public WebElement cradEmbossingDetails;
	private String cardNumberValue = "";

	@FindBy(xpath = Locator_IFCS.SELECT_ADD)
	public WebElement reportsSelectAdd;

	@FindBy(xpath = Locator_IFCS.BULK_REISSUE_TABLE)
	public WebElement bulkReissueTable;

	@FindBy(xpath = Locator_IFCS.CLICK_ADD)
	public WebElement clickAdd;

	@FindBy(xpath = Locator_IFCS.CLICK_CREATE_PRIVATE_PROFILE)
	public WebElement clickCreatePrivateProfile;

	@FindBy(xpath = Locator_IFCS.POP_UP_APPEARS)
	public WebElement popUP;

	@FindBy(xpath = Locator_IFCS.OK_BUTTON)
	public WebElement okButton;

	@FindBy(xpath = Locator_IFCS.AWAITING_CONFIRMATION)
	public WebElement clickingAwaitingConfirmation;

	@FindBy(xpath = Locator_IFCS.ORDER_CARD_CONTROL_TABLE)
	public WebElement orderCardCardControlsTable;

	@FindBy(xpath = Locator_IFCS.SEARCH_RESULTS_TABLE)
	public WebElement searchResultsTable;

	@FindBy(xpath = Locator_IFCS.CARDS_CONTROL_TABLE)
	public WebElement cardsControlTable;

	@FindBy(xpath = Locator_IFCS.SEARCH_RESULTS_TABLE)
	public List<WebElement> cardsTable;

	@FindBy(xpath = Locator_IFCS.POPUP_MENUITEM_SELECT_PROFILE)
	public WebElement selectProfile;

	@FindBy(xpath = Locator_IFCS.POPUP_MENUITEM_CREATE_PRIVATE_PROFILE)
	public WebElement createPrivateProfile;

	@FindBy(xpath = Locator_IFCS.POPUP_MENUITEM_DELETE_PRIVATE_PROFILE)
	public WebElement deletePrivateProfile;

	@FindBy(xpath = Locator_IFCS.CARDFEES_TABLE_RIGHTCLICK)
	public WebElement cardFeesTableRightClick;

	// Added by Sasi on 10-04-19
	@FindBy(xpath = Locator_IFCS.SELECT_ADD_REPORT_HIER)
	public WebElement reportHierarchySelectAdd;

	@FindBy(xpath = Locator_IFCS.SELECT_CHILD_ACCOUNT_IN_HIER)
	public WebElement selectChildAccountInHier;

	@FindBy(xpath = Locator_IFCS.INTERNET_USER_ACCESS_TABLE_HEADER)
	public List<WebElement> internetUserAccessTableHeader;

	@FindBy(xpath = Locator_IFCS.INTERNET_USER_ACCESS_TABLE_DATA)
	public List<WebElement> internetUserAccessTableData;

	@FindBy(xpath = Locator_IFCS.INTERNET_USER_TABLE_HEADER)
	public List<WebElement> internetUserTableHeader;

	@FindBy(xpath = Locator_IFCS.INTERNET_USER_TABLE_DATA)
	public List<WebElement> internetUserTableData;
	
	@FindBy(xpath = Locator_IFCS.VALUE_ADDED_SERVICES_TABLE)
	public WebElement valueAddedServicesTable;
	
	@FindBy(xpath = Locator_IFCS.POPUP_MENUITEM_DETAILS)
	public WebElement poupMenuItemDetails;

	public CardMaintenancePage(WebDriver driver, ExtentTest test) {
		super(driver, test);
		PageFactory.initElements(new AjaxElementLocatorFactory(driver, 15), this);
	}

	Common common = new Common(driver, test);

	public void chooseCustomerNumberAndValidateOrderNewCarPage(String clientCountry) {
		Common common = new Common(driver, test);
		// TODO Auto-generated method stub
		chooseSubMenuFromLeftPanel("Card Details", "Order New Card");

		String customerNo = common
				.getCustomerNoHasTransaction(PropUtils.getPropValue(configProp, clientCountry).replaceAll("\"", ""));
		common.chooseCustomerNoAndSearch(customerNo);
		sleep(5);
		// common.verifyAndClickingTabs("Profiles", "click"); // options --> are 1.click
		// 2.noClick
		// rightClick(orderCardCardControlsTable);
		// //div[@class='JIFCSOrderCardCardControlsTable']

	}

	public void validateCardDetailsPage(String clientName) {
		Common common = new Common(driver, test);
		// Validate Protected fields
		common.validateFieldIsProtected("Card Offer", "Card Type");
		common.validateFieldIsProtected("Card Offer", "Geographical Coverage");
		common.validateFieldIsProtected("Card Offer", "Card Status");
		common.validateFieldIsProtected("Card Offer", "Reciprocity Option");
		common.validateFieldIsProtected("Card Offer", "PIN Control");

		// Validate Text fields
		common.validateLabelText("Card Offer");

		validateFieldisPresent("Card Offer", "Card Offer");

		// validateFieldisPresent("Card Offer", "Card Number");

		validateFieldisPresent("Card Offer", "Card Group");

		validateFieldisPresent("Card Offer", "Emboss Name");

		if (!(clientName.equalsIgnoreCase("MY"))) {
			validateFieldisPresent("Card Offer", "Pump Control");
		}
		// Driver Details
		// validateLabelText("Driver Details");

		if (!clientName.equalsIgnoreCase("RU")) {
			validateFieldisPresent("Driver Details", "Driver Name");

			validateFieldisPresent("Driver Details", "Short Name");

			validateFieldisPresent("Driver Details", "Driver Id");
		}
		// Vehicle Details

		validateFieldisPresent("Vehicle Details", "Description");

		validateFieldisPresent("Vehicle Details", "VRN");

		validateFieldisPresent("Vehicle Details", "Vehicle Id");
		// Balance

		validateFieldisPresent("Balance", "Balance Allowed");

		// Requested By

		validateFieldisPresent("Requested By", "Phone");

		validateFieldisPresent("Requested By", "Order Method");
	}

	public void switchTabAndValidatePageTable(String tabname, String seperatorLabelName, String tableHeaderName) {
		Common common = new Common(driver, test);
		switchTabDetails(tabname);
		common.validateCheckBoxInTable(seperatorLabelName, tableHeaderName);

	}

	public void validateCardProfilePage() {
		// common.verifyAndClickingTabs("Profiles", "click");
		Common common = new Common(driver, test);
		switchTabDetails("Profiles");
		int rowSize = common.validateCheckBoxInTable("Profile Selection", "Default");
		if (rowSize == 0) {
			logPass("In Card Fee Table Row Size " + rowSize);
		} else {
			common.validateCheckBoxInTable("Profiles", "Default");
		}

	}

	public void validateCardFeesPage() {
		Common common = new Common(driver, test);
		// common.verifyAndClickingTabs("Card Fees", "click");
		switchTabDetails("Card Fees");

		int rowSize = common.validateCheckBoxInTable("Profile Selection", "Default");
		if (rowSize == 0) {
			logPass("In Card Fee Table Row Size " + rowSize);
		} else {
			common.validateCheckBoxInTable("Profile Selection", "Default");
			sleep(2);

		}
	}

	/*
	 * public void validateCardEmbossingDetailsPage() {
	 * switchTabDetails("Embossing Details"); //
	 * common.verifyAndClickingTabs("Embossing Details", "click");
	 * 
	 * isDisplayed(cradEmbossingDetails, "Card Embossing Details");
	 * 
	 * }
	 */
	public void validateCardDeliveryAddressPage() {
		// common.verifyAndClickingTabs("Card Delivery Address", "click");
		switchTabDetails("Card Delivery Address");
		// Permanent Address
		validateFieldisPresent("Permanent Address", "Contact Name");

		validateFieldisPresent("Permanent Address", "Permanent Address");

		validateFieldisPresent("Permanent Address", "City");

		validateFieldisPresent("Permanent Address", "Post code");

		validateFieldisPresent("Permanent Address", "State");

		validateFieldisPresent("Permanent Address", "Country");

		validateFieldisPresent("Permanent Address", "Email");

		validateFieldisPresent("Permanent Address", "Phone");

		validateFieldisPresent("Permanent Address", "Mobile 1");

		validateFieldisPresent("Permanent Address", "Title");

		// Temporary Address
		validateFieldisPresent("Temporary Address", "Contact Name");

		validateFieldisPresent("Temporary Address", "Temp Address");

		validateFieldisPresent("Temporary Address", "City");

		validateFieldisPresent("Temporary Address", "Post code");

		validateFieldisPresent("Temporary Address", "State");

		validateFieldisPresent("Temporary Address", "Country");

		validateFieldisPresent("Temporary Address", "Email");

		validateFieldisPresent("Temporary Address", "Phone");

		validateFieldisPresent("Temporary Address", "Mobile 1");

		validateFieldisPresent("Temporary Address", "Title");
	}

	public void validateCardEmbossingDetailsPage() {
		switchTabDetails("Embossing Details");
		// common.verifyAndClickingTabs("Embossing Details", "click");

		isDisplayed(cradEmbossingDetails, "Card Embossing Details");

	}

	public void chooseCardNumberAndValidateOrderNewCarPage(String clientCountry) {
		Common common = new Common(driver, test);
		// TODO Auto-generated method stub
		switchTabDetails("Card Details");
		chooseSubMenuFromLeftPanel("Card Details", "Card Maintenance");
		cardNumberValue = common.getClientSpecificCardNumber();
		common.chooseCardNoAndSearch(cardNumberValue);
		sleep(5);

	}

	public void validateRequestDetailsPage() {
		switchTabDetails("Request Details");
		// common.verifyAndClickingTabs("Request Details", "click");

		validateFieldisPresent("New Request Details", "Card Fee");

		validateFieldisPresent("New Request Details", "PIN Mailer");

	}
	

	public void requestForNewSystemPIN() {
		
		switchTabDetails("Request Details");
		// common.verifyAndClickingTabs("Request Details", "click");

		validateFieldisPresent("New Request Details", "Card Fee");

		validateFieldisPresent("New Request Details", "PIN Mailer");
		
		common.checkAndUncheckTheCheckBox("Request New System Generated PIN");
		
		common.clickSaveIcon();
		common.verifyValidationResult("Record saved OK");
		
		

	}

	// public WebElement reportsSelectAdd;

	// Update the Card Requested By Field and Save
	public void chooseCardAndUpdateRequestedByField(String cardNumber, String name, String phoneNo) {
		Common common = new Common(driver, test);
		chooseSubMenuFromLeftPanel("Card Details", "Card Maintenance");
		// String customerNumber=common.getCustomerNoHavingCardsUsingCardType();
		// common.chooseCustomerNoAndSearch(customerNumber);
		// chooseSubMenuFromLeftPanel("Card Transfers","Cards");
		common.chooseCardNoAndSearch(cardNumber);

		// common.selectFirstRowNumberInSearchList();
		sleep(5);
		common.enterValueInTextBox("Requested By", "Name", name);
		common.enterValueInTextBox("Requested By", "Phone", phoneNo);
		common.clickSaveIcon();
		common.verifyValidationResult("Record read OK");

	}

	public void UpdateAndValidateDriverCard(String seperatorLabelName, String labelName, String input) {
		Common common = new Common(driver, test);

		enterValueInTextBox(seperatorLabelName, labelName, input);
		sleep(3);
		common.clickSaveIcon();
		verifyValidationResult("Record saved OK");
		verifyValueInTextBox(seperatorLabelName, labelName, input);
	}

	public void chooseCardAndUpdateDriverNameInDriverCard(String driverCardNumber) {
		Common common = new Common(driver, test);

		String drivername = fakerAPI().name().firstName();
		chooseSubMenuFromLeftPanel("Card Details", "Card Maintenance");
		common.chooseCardNoAndSearch(driverCardNumber);
		common.enterValueInTextBox("Driver Details", "Driver Name", drivername);
		common.clickSaveIcon();
		common.clickYesButton();
		verifyReplaceCard();
		verifyValueInTextBox("Driver Details", "Driver Name", drivername.toUpperCase());
	}

	// Update the DriverId in Card Details and Save
	public void chooseCardAndUpdateDriverIdInDriverCard(String driverCardNumber) {
		common = new Common(driver, test);
		String driverId = fakerAPI().number().digits(3);
		System.out.println("driverId : " + driverId);
		chooseSubMenuFromLeftPanel("Card Details", "Card Maintenance");
		common.chooseCardNoAndSearch(driverCardNumber);
		UpdateAndValidateDriverCard("Driver Details", "Driver Id", driverId);
		System.out.println("driverId : " + driverId);
	}

	// Update the Driver ShortName in Card Details and Save
	public void chooseCardAndUpdateShortNameInDriverCard(String driverCardNumber) {
		Common common = new Common(driver, test);

		String shortName = fakerAPI().name().firstName();
		chooseSubMenuFromLeftPanel("Card Details", "Card Maintenance");
		common.chooseCardNoAndSearch(driverCardNumber);
		sleep(3);
		UpdateAndValidateDriverCard("Driver Details", "Short Name", shortName);

	}

	// Verify updated values in newly created card
	public String verifyReplaceCard() {
		Common common = new Common(driver, test);
		String replaceCardNumber;
		String validateReplaceCardNumber;
		replaceCardNumber = getValueFromProtectedTextBox("Other Details", "Replace Card Number");
		validateReplaceCardNumber = "Card " + replaceCardNumber + " ordered";
		System.out.println("Replace Card Number is " + validateReplaceCardNumber);
		verifyValidationResult(validateReplaceCardNumber);
		common.chooseCardNoAndSearch(replaceCardNumber);
		return replaceCardNumber;
	}

	public void getIndividualReport() {
		chooseSubMenuFromLeftPanel("Customer Reporting", "Individual Reports");

		rightClick(reportsSelectAdd);
	}

	public void chooseReportTypeFromPopUpAndSaveTheReport() {
		Common common = new Common(driver, test);
		isDisplayed(reportTypePopUp, "Pop up");
		common.chooseARandomDropdownOption("Report Type");
		// chooseOptionFromDropdown("Report Type","Bulk Card Order");
		common.clickOkButton();

		common.clickSaveIcon();

		verifyValidationResult("Record saved OK");

	}

	public void chooseCardAndUpdateCardGroup(String driverCardNumber) {
		Common common = new Common(driver, test);
		String costCentreCode = fakerAPI().number().digits(4);
		chooseSubMenuFromLeftPanel("Card Details", "Card Maintenance");
		// String driverCardNumber=common.getDriverCardNumberFromDB();
		common.chooseCardNoAndSearch(driverCardNumber);// "7018321020000006507"
		sleep(3);
		
		common.enterValueInTextBox("Card Offer", "Cost Centre", costCentreCode);

		common.clickSaveIcon();

		common.verifyValidationResult("Record read OK");
		sleep(2);
		common.clickYesButton();

		chooseSubMenuFromLeftPanel("Card Maintenance", "Cost Centre");

		common.validateSearchTable("Cost Centre", costCentreCode, true);
	}
	

	public void chooseCardAndUpdateCostCenterDropdown(String driverCardNumber) {
		Common common = new Common(driver, test);
		chooseSubMenuFromLeftPanel("Card Details", "Card Maintenance");
		common.chooseCardNoAndSearch(driverCardNumber);
		sleep(3);
		
		common.chooseOptionFromDropdown("Cost Centre", "random");

		common.clickSaveIcon();

		common.verifyValidationResult("Record saved OK");
		}
	
	
	// Prakalpha
	public void enterCustomerPostCodeWithSpecialCharactersAndValidate(String customerNumber, String clientCountry) {
		Common common = new Common(driver, test);
		try {
			common.chooseCustomerNoAndSearch(customerNumber);
			if (clientCountry.equals("RU")) {
				logInfo("For RU Country Special Characters not allowed ,9999-9999 Post Code Format is invalid");
				enterValueInPostCodeTextBox("Addresses", "Post Code", "1258");
				common.clickSaveIcon();
				verifyValidationResult("Record saved OK");
			} else {
				enterValueInPostCodeTextBox("Addresses", "Post Code", "9999-9999");
				common.clickSaveIcon();

				verifyValidationResult("Record saved OK");

				verifyValueInPostCodeTextBox("Addresses", "Post Code", "9999-9999");

			}
		} catch (Exception ex) {
			logFail(ex.getMessage());
		}

	}

	public void enterCardPostCodeWithSpecialCharactersAndValidate(String driverCardNumber, String clientCountry) {
		Common common = new Common(driver, test);
		try {
			chooseSubMenuFromLeftPanel("Card Details", "Card Maintenance");
			common.chooseCardNoAndSearch(driverCardNumber);
			sleep(5);
			switchTabDetails("Card Delivery Address");
			if (clientCountry.equals("CZ") || clientCountry.equals("RU")) {

				enterValueInTextBox("Permanent Address", "Post code", "9999-9999");
				enterValueInTextBox("Temporary Address", "Post code", "9999-9999");
				common.clickSaveIcon();
				verifyValidationResult("Record saved OK");
				verifyValueInTextBox("Permanent Address", "Post code", "9999-9999");
				verifyValueInTextBox("Temporary Address", "Post code", "9999-9999");

			} else {
				logInfo("For MY and PH country,Must be maximum of 10 alphabetical, numeric characters");
				enterValueInTextBox("Permanent Address", "Post code", "ABC123");

				enterValueInTextBox("Temporary Address", "Post code", "ABC123");
				common.clickSaveIcon();

				verifyValidationResult("Record saved OK");
				verifyValueInTextBox("Permanent Address", "Post code", "ABC123");

				verifyValueInTextBox("Temporary Address", "Post code", "ABC123");
			}
		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
	}

	public void updatePostCodeWithSpecialCharacters(String clientCountry) {
		Common common = new Common(driver, test);
		try {
			chooseSubMenuFromLeftPanel("Maintain Merchant", "Locations");
			common.searchListTorch();

			common.selectFirstRowNumberInSearchList();
			if (clientCountry.equals("MY")) {
				logInfo("For MY country PostCode Field is protected");
				getValueFromProtectedTextBox("Addresses", "Post Code");

			} else {
				enterValueInPostCodeTextBox("Addresses", "Post Code", "123-45");
				common.clickSaveIcon();
				verifyValidationResult("Record saved OK");
				verifyValueInPostCodeTextBox("Addresses", "Post Code", "123-45");

			}
		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
	}

	public String getValueFromPostCodeTextBox(String seperatorLabelName, String labelName) {
		String seperator = " ";
		String label = " ";
		List<WebElement> textBox;
		String text = " ";
		try {
			seperator = splitStringAndGenerateXpath(seperatorLabelName);
			label = splitStringAndGenerateXpath(labelName);
			textBox = driver.findElements(By.xpath(
					"//div[@class='JFALSeparator']//div[" + seperator + "]/preceding::div[@class='JFALLabel']/div["
							+ label + "]/preceding::div[@class='JFALCompControlPanel'][1]//input"));

			// text = textBox.getText();
			text = textBox.get(1).getAttribute("submittedvalue");
			logPass("Text value is " + text);
		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
		return text;
	}

	public void verifyValueInPostCodeTextBox(String seperatorLabelName, String labelName, String expectedValue) {
		try {

			String actualValue = getValueFromPostCodeTextBox(seperatorLabelName, labelName);
			System.out.println(actualValue);
			if (actualValue.equals(expectedValue)) {
				logPass(actualValue + " and " + expectedValue + "Matched");
			} else {
				logFail(actualValue + " and " + expectedValue + "Not Matched");
			}
		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
	}

	public void enterValueInPostCodeTextBox(String seperatorLabelName, String labelName, String input) {
		String seperator = " ";
		String label = " ";
		List<WebElement> textBox;
		try {
			seperator = splitStringAndGenerateXpath(seperatorLabelName);
			label = splitStringAndGenerateXpath(labelName);
			textBox = driver.findElements(By.xpath(
					"//div[@class='JFALSeparator']//div[" + seperator + "]/preceding::div[@class='JFALLabel']/div["
							+ label + "]/preceding::div[@class='JFALCompControlPanel'][1]//input"));
			textBox.get(1).clear();
			sleep(5);
			textBox.get(1).sendKeys(input);
			logPass(input + " is entered in text field");

		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
	}

	public void enterCustomerAddressAndCardWithSpecialCharactersAndValidate(String customerNumber,
			String clientCountry) {
		Common common = new Common(driver, test);
		String name = fakerAPI().name().firstName() + "#";
		// String customerNumber=common.getCustomerNoHavingCardsUsingCardType();
		common.chooseCustomerNoAndSearch(customerNumber);
		sleep(2);
		String address = fakerAPI().address().fullAddress() + "#";
		if (clientCountry.equals("MY")) {
			validateFieldIsProtected("Addresses", "Physical Address");
			validateFieldIsProtected("Addresses", "Postal Address");
			logInfo("Address field on card maintenance/customer address--> Pass");
			validateFieldIsProtected("Contact", "Name");
			logInfo("Name with special chars case--> Pass");
		} else {
			enterValueInTextArea("Addresses", "Physical Address", address);
			enterValueInTextArea("Addresses", "Postal Address", address);
			enterValueInTextBox("Contact", "Name", name);
			common.selectACountryFromDropdown(0, "Country");
			common.selectACountryFromDropdown(1, "Country");
			common.clickSaveIcon();
			verifyValidationResult("Record saved OK");
			sleep(5);
			verifyValueInTextArea("Addresses", "Physical Address", address);
			logInfo("Special Characters added in Address Field");
			verifyValueInTextArea("Addresses", "Postal Address", address);
			logInfo("Special Characters added in Address Field");
			verifyValueInTextBox("Contact", "Name", name);
			logInfo("Special Characters added in Name Field");

		}

	}

	public void enterCardAddressAndNameWithSpecialCharactersAndValidate(String cardNo) {
		Common common = new Common(driver, test);
		chooseSubMenuFromLeftPanel("Card Details", "Card Maintenance");
		common.chooseCardNoAndSearch(cardNo);

		String name = fakerAPI().name().firstName() + "#";
		enterValueInTextBox("Requested By", "Name", name);
		common.clickSaveIcon();
		common.verifyValidationResult("Record read OK");
		enterValueInTextBox("Requested By", "Name", name);

		switchTabDetails("Card Delivery Address");
		String tempAddress = fakerAPI().address().fullAddress() + "#";

		enterValueInTextArea("Temporary Address", "Temp Address", tempAddress);
		sleep(3);
		common.enterDetailsWithSameLabelName("Temporary Address", "Contact Name", name);

		common.selectACountryFromDropdown(0, "Country");
		System.out.println("Temporary Address completed");

		String permanentAddress = fakerAPI().address().fullAddress() + "#";
		enterValueInTextArea("Permanent Address", "Permanent Address", permanentAddress);
		sleep(3);
		common.enterDetailsWithSameLabelName("Permanent Address", "Contact Name", name);
		common.selectACountryFromDropdown(1, "Country");

		common.clickSaveIcon();
		verifyValidationResult("Record saved OK");

		verifyValueInTextArea("Temporary Address", "Temp Address", tempAddress);
		verifyValueInTextBox("Temporary Address", "Contact Name", name);
		verifyValueInTextArea("Permanent Address", "Permanent Address", permanentAddress);
		logInfo("Special Characters added in Address and Name Field");

	}

	/*
	 * public void chooseCardAndCreateBulkReissueRequest(String currentIFCSDate,
	 * String futureIFCSDate) { Common common = new Common(driver, test); // TODO
	 * Auto-generated method stub
	 * chooseSubMenuFromLeftPanel("Card Maintenance","Bulk Reissue");
	 * 
	 * 
	 * rightClick(bulkReissueTable); common.addIteminPopup();
	 * common.enterValueInTextBox("Card Status & Expiry Dates", "Expiring From",
	 * currentIFCSDate);
	 * 
	 * common.enterValueInTextBox("Card Status & Expiry Dates", "Expiring To",
	 * futureIFCSDate);
	 * 
	 * common.enterValueInTextBox("Card Status & Expiry Dates", "Reissue On",
	 * futureIFCSDate);
	 * 
	 * common.enterValueInTextBox("Card Status & Expiry Dates", "Confirm On",
	 * futureIFCSDate);
	 * 
	 * common.enterValueInTextBox("New Request Details", "Requested By", "test");
	 * 
	 * common.enterValueInTextBox("New Request Details", "Phone Number",
	 * "0123456789");
	 * 
	 * }
	 */

	public void chooseCardAndCreateBulkReissueRequest(String currentProcessingDate, String futureIFCSDate,
			String nextDateIFCSDate) {
		// TODO Auto-generated method stub

		Common common = new Common(driver, test);

		chooseSubMenuFromLeftPanel("Card Details", "Bulk Reissue");
		// CZA0000123

		rightClick(bulkReissueTable);
		common.addIteminPopup();
		common.enterValueInTextBox("Card Status & Expiry Dates", "Expiring From", currentProcessingDate);

		common.enterValueInTextBox("Card Status & Expiry Dates", "Expiring To", futureIFCSDate);

		common.enterValueInTextBox("Card Status & Expiry Dates", "Reissue On", currentProcessingDate);

		common.enterValueInTextBox("Card Status & Expiry Dates", "Confirm On", currentProcessingDate);

		common.enterValueInTextBox("New Request Details", "Requested By", "test");

		common.enterValueInTextBox("New Request Details", "Phone Number", "0123456789");

	}

	public void bulkReissueRequestWithInvalidDate(String currentIFCSDate, String futureIFCSDate,
			String maxCardProductIFCSDate) {
		// giving invalid date
		bulkReissueErrorMessageInvalidDate("Date is not a valid date.");
		bulkReissueErrorMessage(currentIFCSDate, "The reissue date must be less than the new expiry date");

		bulkReissueErrorMessage(futureIFCSDate, "New Expiry Date cannot be less than the Current Expiry Date");
		bulkReissueErrorMessage(maxCardProductIFCSDate, "Validation failed ");
	}

	public void bulkReissueRequestWithValidDate(String wayFutureIFCSDate) {
		Common common = new Common(driver, test);
		// giving valid date
		common.enterValueInTextBox("Card Status & Expiry Dates", "New Expiry Date", wayFutureIFCSDate);
		sleep(1);
		common.clickOkButton();
		sleep(2);
		common.clickSaveIcon();
		common.verifyValidationResult("Record saved OK");
	}

	// Date is not a valid date
	public void bulkReissueErrorMessageInvalidDate(String errorMsg) {
		Common common = new Common(driver, test);
		String invalidDate = "54/22/4910";
		common.enterValueInTextBox("Card Status & Expiry Dates", "New Expiry Date", invalidDate);

		common.clickOkButton();
		common.verifyValidationResultInPopUp(errorMsg);
		logInfo(errorMsg + " - Error msg appeared");
	}

	// The reissue date must be less than the new expiry date
	public void bulkReissueErrorMessage(String invalidDate, String errorMsg) {
		Common common = new Common(driver, test);
		// invalidDate = "03/08/2018";
		common.enterValueInTextBox("Card Status & Expiry Dates", "New Expiry Date", invalidDate);
		sleep(1);
		common.clickOkButton();
		sleep(2);
		common.clickSaveIcon();

		isDisplayedThenDoubleClick(clickingAwaitingConfirmation, "double click on awaiting confirmation");

		common.verifyValidationResultInPopUp(errorMsg);
		logInfo(errorMsg + " - Error msg appeared");

	}

	/*
	 * // Added by sasi on 15/02/19 --> may be in future public void
	 * chooseCardAndCreateCardControlProfile() { // TODO Auto-generated method stub
	 * chooseSubMenuFromLeftPanel("Card Details","Card Maintenance"); String
	 * driverCardNumber=common.getSHELLDriverCardNumberFromDB();
	 * common.chooseCardNoAndSearch(driverCardNumber);//7018321010000002697
	 * 
	 * 
	 * common.verifyAndClickingTabs("Profiles", "click"); // options --> are 1.click
	 * 2.noClick rightClick(orderCardCardControlsTable);
	 * 
	 * isDisplayedThenClick(clickCreatePrivateProfile,
	 * "clickCreatePrivateProfile button is clicked");
	 * 
	 * common.clickSaveIcon();
	 * 
	 * doubleClick(cardsControlTable);
	 * 
	 * isDisplayed(popUP,"pop up appears as expected");
	 * 
	 * 
	 * }
	 */
	public void updateCardMaintenanceCardFeeProfile(String cardNumber) {
		Common common = new Common(driver, test);
		MaintainCustomerPage maintainCustomerPage = new MaintainCustomerPage(driver, test);
		WebElement cellElement;

		try {

			chooseSubMenuFromLeftPanel("Card Details", "Card Maintenance");

			common.chooseCardNoAndSearch(cardNumber);

			switchTabDetails("Card Fees");

			int rowNumber = SeleniumWrappers.getTotalNumberOfRows(
					driver.findElements(By.xpath("//div[@class='FALTableCellEditor_StrikeThruField JTextComponent']")),
					driver);
			System.out.println("Row number" + rowNumber);
			if (rowNumber == 0) {
				common.rightClickAndCreatePrivateProfile(cardFeesTableRightClick);
				common.validateCheckBoxInTableAndDoubleClick("Profile Selection", "Private", "Description");
				maintainCustomerPage.enterDetailsInCardFeesPopUp();

			}

			else {
				List<WebElement> tableHeaders = driver.findElements(By.xpath(
						"//div[@class='JFALSeparator']//div[contains(text(),'Profile') and contains(text(),'Selection')]/preceding::div[@class='JFALCompControlPanel']//div[@class='JViewport']/div[@class='JTableHeader']//div[@class='HeaderRenderer']"));
				int colIndex = SeleniumWrappers.getColumnNoForColumnHeader("Description", tableHeaders);
				cellElement = SeleniumWrappers.getTableDataWithCellElement(0, colIndex, driver);
				doubleClick(cellElement);
				validatePopupHeaderText("Card Fees");
				common.clickCancelButton();

				rightClick(cardFeesTableRightClick);

				common.rightClickAndCreatePrivateProfile(cardFeesTableRightClick);
				common.validateCheckBoxInTableAndDoubleClick("Profile Selection", "Private", "Description");
				maintainCustomerPage.enterDetailsInCardFeesPopUp();
			}
		} catch (Exception e) {
			logFail(e.getMessage());
		}
	}

	/*
	 * public void DBDate(String clientCountry) { String expiringFrom = " ";
	 * //"03/08/2018";//currentIFCSDate String expiringTo = " "; //"03/08/2019";
	 * String newExpiryDate = " "; //"03/08/2020"; String pastDate = " ";
	 * expiringFrom =
	 * common.enterADateValueInStatusBeginDateField("Current",clientCountry);
	 * expiringTo =
	 * common.enterADateValueInStatusBeginDateField("Future",clientCountry);
	 * newExpiryDate =
	 * common.enterADateValueInStatusBeginDateField("WayFuture",clientCountry);
	 * pastDate =
	 * common.enterADateValueInStatusBeginDateField("Past",clientCountry);
	 * System.out.println("current  :" +expiringFrom);
	 * System.out.println("Future  :" +expiringTo); System.out.println("Past  :"
	 * +pastDate); System.out.println("WayFuture  :" +newExpiryDate);
	 * 
	 * }
	 */

	public void updateCardMaintenanceCardControlProfile(String cardnumber) {
		Common common = new Common(driver, test);
		try {

			chooseSubMenuFromLeftPanel("Card Details", "Card Maintenance");
			common.chooseCardNoAndSearch(cardnumber);// 7018321010000002697
			sleep(5);
			switchTabDetails("Profiles");
			sleep(5);
		  //common.validateCheckBoxInTable("", "Default");

		} catch (Exception e) {
			logFail(e.getMessage());
		}
	}

	public void enterCustomerAddressWithSpecialCharactersAndValidate(String customerNumber, String clientCountry) {
		Common common = new Common(driver, test);
		String name = fakerAPI().name().firstName() + "#";
		// String customerNumber=common.getCustomerNoHavingCardsUsingCardType();
		common.chooseCustomerNoAndSearch(customerNumber);
		sleep(2);
		String address = fakerAPI().address().fullAddress() + "#";
		enterValueInTextArea("Addresses", "Physical Address", address);
		enterValueInTextArea("Addresses", "Postal Address", address);
		common.selectACountryFromDropdown(0, "Country");
		if (clientCountry.equals("CZ")) {
			enterValueInTextBox("Addresses", "Post Code", "9999-9999");
		} else {
			logInfo("Post code with hypens is not allowed for " + clientCountry);
		}
		// enterValueInTextBox("Addresses","Post Code","9999-9999");
		enterValueInTextBox("Contact", "Name", name);
		common.clickSaveIcon();
		verifyValidationResult("Record saved OK");
		verifyValueInTextBox("Addresses", "Physical Address", address);
		logInfo("Special Characters added in Address Field");
		verifyValueInTextBox("Addresses", "Postal Address", address);
		logInfo("Special Characters added in Address Field");
		verifyValueInTextBox("Contact", "Name", name);
		logInfo("Special Characters added in Name Field");
		if (clientCountry.equals("CZ")) {
			verifyValueInTextBox("Addresses", "Post Code", "9999-9999");
			logInfo("Special Characters HYPEN is added in Post code");
		}

	}

	public void activeCardNumber() {
		Common common = new Common(driver, test);
		chooseSubMenuFromLeftPanel("Card Details", "Card Maintenance");
		// ActiveCardNumber = common.getActiveCardWithFutureProcessDateFromDB(4);
		ActiveCardNumber = common.getCardsWithStatusAndWithBalance("Active");
		sleep(3);
		common.chooseCardNo(ActiveCardNumber);
	}

	public void UpdateAndValidateVehicleCard(String seperatorLabelName, String labelName, String input) {
		Common common = new Common(driver, test);
		enterValueInTextBox(seperatorLabelName, labelName, input);
		common.clickSaveIcon();

		verifyValidationResult("Record saved OK");

		verifyValueInTextBox(seperatorLabelName, labelName, input);
	}

	public void validateUpdateVehicleID(String vehicleCardNo) {
		Common common = new Common(driver, test);
		chooseSubMenuFromLeftPanel("Card Details", "Card Maintenance");
		common.chooseCardNoAndSearch(vehicleCardNo);
		UpdateAndValidateVehicleCard("Vehicle Details", "Vehicle Id", "123");

	}

	public void validateUpdateVehicleDescription(String vehicleCardNo) {
		Common common = new Common(driver, test);
		chooseSubMenuFromLeftPanel("Card Details", "Card Maintenance");
		common.chooseCardNoAndSearch(vehicleCardNo);
		UpdateAndValidateVehicleCard("Vehicle Details", "Description", fakerAPI().name().fullName());

	}

	public void validateUpdateVehicleVRN(String vehicleCardNo) {
		Common common = new Common(driver, test);
		String vehicleVRN = fakerAPI().number().digits(5);
		chooseSubMenuFromLeftPanel("Card Details", "Card Maintenance");
		common.chooseCardNoAndSearch(vehicleCardNo);
		enterValueInTextBox("Vehicle Details", "VRN", vehicleVRN);
		common.clickSaveIcon();
		common.clickYesButton();
		verifyReplaceCard();
		verifyValueInTextBox("Vehicle Details", "VRN", vehicleVRN);
	}

	public void chooseAndSearchCustomerNo(String customerNumber) {
		Common common = new Common(driver, test);
		chooseSubMenuFromLeftPanel("Card Details", "Customers");
		enterValueInTextBox("Filter By", "Customer No", customerNumber);
		common.searchListTorch();
		sleep(3);
		common.selectFirstRowNumberInSearchList();
	}

	public void addIndividualReports() {
		// TODO Auto-generated method stub
		chooseSubMenuFromLeftPanel("Customer Reporting", "Individual Reports");
		// rightClick(reportsSelectAdd);
		// sleep(5);

	}

	public void addReportHier() {
		// TODO Auto-generated method stub
		chooseSubMenuFromLeftPanel("Hierarchies", "Report Hierarchy");
		// rightClick(reportHierarchySelectAdd);
		// sleep(5);

	}

	public void addReportFinancialHier() {
		// TODO Auto-generated method stub
		chooseSubMenuFromLeftPanel("Hierarchies", "Financial Hierarchy");
		// rightClick(reportHierarchySelectAdd);
		// sleep(5);

	}

	public void clickingChildCusInHier() {
		// TODO Auto-generated method stub
		Click(selectChildAccountInHier, "clicking child account");
		sleep(2);

	}

	public void chooseReportTypeFrequencyAndSaveTheReport(String reportName, String frequency,
			String reportAssignment) {
		Common common = new Common(driver, test);
		if (reportAssignment.equals("Report Hierarchy")) {
			rightClick(reportHierarchySelectAdd);

		} else if (reportAssignment.equals("Financial Hierarchy")) {
			rightClick(reportHierarchySelectAdd);

		} else if (reportAssignment.equals("Individual Reports")) {
			rightClick(reportsSelectAdd);
		}

		sleep(5);
		// Add to Report
		common.addIteminPopup();
		// Handle message pop up

		isDisplayed(reportTypePopUp, "Pop up");

		chooseOptionFromDropdown("Report Type", reportName);

		if (frequency.equals(""))
			common.chooseARandomDropdownOption("Frequency");
		else
			chooseOptionFromDropdown("Frequency", frequency);

		common.clickOkButton();
		sleep(3);

		common.clickSaveIcon();
		logInfo(reportName + " is assigned to the customer");

	}

	public String cardExpiryDateChange() {
		Common common = new Common(driver, test);
		common.changingTheDateFormat();
		String ExpiryDate = common.addNewExpiryDate();
		enterValueInTextBox("Card Offer", "Expiry Date", ExpiryDate);
		common.clickSaveIcon();
		sleep(2);
		common.clickYesButton();
		sleep(3);
		verifyValidationResult("Card Request submitted OK");
		return ActiveCardNumber;

	}

	public void gotoSecurityAndClickOnline() {
		Common common = new Common(driver, test);
		// TODO Auto-generated method stub
		chooseSubMenuFromLeftPanel("Security", "");
		chooseSubMenuFromLeftPanel("Online", "Users");
		common.clickDetailSearchIfFilterFieldsNotPresent();

	}

	public void verifyingMembersUnderAUserID(String olsUserID, String customerType) {
		Common common = new Common(driver, test);
		common.clickDetailSearchIfFilterFieldsNotPresent();
		common.enterValueInTextBox("Filter By", "Logon Id", olsUserID);
		sleep(3);
		common.searchListTorch();
		sleep(10);
		// common.validateSearchTableWhenMultipleTablePresents("Internet Users", "Logon
		// Id", olsUserID, true);
		validateInternetUserTable("Logon Id", olsUserID, true);
		validateInternetUserTable("Role", "Customer Administrator", true);
		validateInternetUserAccessTable("Account Status", "A - Active", true);
		validateInternetUserAccessTable("Member Type", "Customer", true);
		validateCustomerType("Member No", customerType);
		// validateInternetUserAccessTable("Account Status", "", true);

	}

	public void validateUpdateLicensePlate(String vehicleCardNo) {
		Common common = new Common(driver, test);
		String licencePlate = fakerAPI().number().digits(5);
		chooseSubMenuFromLeftPanel("Card Details", "Card Maintenance");
		common.chooseCardNoAndSearch(vehicleCardNo);
		enterValueInTextBox("Vehicle Details", "License Plate", licencePlate);
		common.clickSaveIcon();
		common.clickYesButton();
		verifyReplaceCard();
		verifyValueInTextBox("Vehicle Details", "License Plate", licencePlate);
	}

	public String replaceToStolenStatus() {
		Common common = new Common(driver, test);
		chooseSubMenuFromLeftPanel("Maintain Customer", "Card Status");
		chooseOptionFromDropdown("New status", "Stolen");
		common.clickSaveIcon();
		sleep(2);
		common.clickYesButton();
		sleep(2);
		verifyValidationResult("Card Reissue submitted OK");

		chooseSubMenuFromLeftPanel("Card Details", "Card Maintenance");
		sleep(3);
		String newCardNumber = getValueFromProtectedTextBox("Other Details", "Replace Card Number");
		return newCardNumber;

	}

	public String replaceTheLostCardNumber() {
		Common common = new Common(driver, test);
		common.clickCardRequestButton();
		common.clickYesButton();
		sleep(3);
		String newCardNumber = getValueFromProtectedTextBox("Other Details", "Replace Card Number");
		System.out.println("newCardNumber :::" + newCardNumber);
		sleep(2);
		verifyValidationResult("Card " + newCardNumber + " ordered");

		return newCardNumber;
	}

	// Lost Card from DB
	public void getLostCardNumber() {
		Common common = new Common(driver, test);
		chooseSubMenuFromLeftPanel("Card Details", "Card Maintenance");
		lostCardNumber = common.getLostCardNumberFromDB();
		sleep(2);
		common.chooseCardNo(lostCardNumber);
	}

	public void chooseAndSearchCardNo(String cardNo) {
		Common common = new Common(driver, test);
		chooseSubMenuFromLeftPanel("Card Details", "Card Maintenance");
		common.chooseCardNoAndSearch(cardNo);
		sleep(5);
	}

	// Added by Sasi on 24-04-19
	public void validateInternetUserAccessTable(String colName, String expectedValue, Boolean checkEquals) {
		System.out.println("inside");
		int totalRowsInTable = SeleniumWrappers.getTotalNumberOfRows(internetUserAccessTableData, driver);

		int colIndex = SeleniumWrappers.getColumnNoForColumnHeader(colName, internetUserAccessTableHeader);

		System.out.println("colIndex : " + colIndex);
		boolean validateCols;
		for (int i = 0; i < totalRowsInTable; i++) {
			if (checkEquals) {
				validateCols = SeleniumWrappers.getTableDataWithRowAndColumnNumber(colIndex, i, driver)
						.equalsIgnoreCase(expectedValue);
			} else {
				validateCols = SeleniumWrappers.getTableDataWithRowAndColumnNumber(colIndex, i, driver).toLowerCase()
						.contains(expectedValue.toLowerCase().replaceAll("\\*", ""));
			}

			if (validateCols) {
				logPass("Expected value present in Row: " + i + " Col: " + colIndex + " Expected::" + expectedValue
						+ " Actual::" + SeleniumWrappers.getTableDataWithRowAndColumnNumber(i, colIndex, driver));
			} else {
				logFail("Expected value not present in Row: " + i + " Col: " + colIndex + " Expected::" + expectedValue
						+ " Actual::" + SeleniumWrappers.getTableDataWithRowAndColumnNumber(colIndex, i, driver));
			}
		}
	}

	// Added by Sasi on 24-04-19
	public void validateInternetUserTable(String colName, String expectedValue, Boolean checkEquals) {
		System.out.println("inside");

		int totalRowsInTable = SeleniumWrappers.getTotalNumberOfRows(internetUserTableData, driver);

		int colIndex = SeleniumWrappers.getColumnNoForColumnHeader(colName, internetUserTableHeader);

		System.out.println("colIndex : " + colIndex);
		boolean validateCols;
		for (int i = 0; i < totalRowsInTable; i++) {
			if (checkEquals) {
				validateCols = SeleniumWrappers.getTableDataWithRowAndColumnNumber(colIndex, i, driver)
						.equalsIgnoreCase(expectedValue);
			} else {
				validateCols = SeleniumWrappers.getTableDataWithRowAndColumnNumber(i, colIndex, driver).toLowerCase()
						.contains(expectedValue.toLowerCase().replaceAll("\\*", ""));
			}

			if (validateCols) {
				logPass("Expected value present in Row: " + i + " Col: " + colIndex + " Expected::" + expectedValue
						+ " Actual::" + SeleniumWrappers.getTableDataWithRowAndColumnNumber(colIndex, i, driver));
			} else {
				logFail("Expected value not present in Row: " + i + " Col: " + colIndex + " Expected::" + expectedValue
						+ " Actual::" + SeleniumWrappers.getTableDataWithRowAndColumnNumber(colIndex, i, driver));
			}
		}
	}

	// Added by Sasi on 24-04-19
	public void validateCustomerType(String colName, String customertype) {
		Common common = new Common(driver, test);
		System.out.println("inside");

		int totalRowsInTable = SeleniumWrappers.getTotalNumberOfRows(internetUserAccessTableData, driver);

		int colIndex = SeleniumWrappers.getColumnNoForColumnHeader(colName, internetUserAccessTableHeader);

		System.out.println("colIndex : " + colIndex);
		String cusNo;
		for (int i = 0; i < totalRowsInTable; i++) {

			cusNo = SeleniumWrappers.getTableDataWithRowAndColumnNumber(colIndex, i, driver);
			System.out.println("cusNo : " + cusNo);

			String cardDescription = common.getCardProgramOfCustomer(cusNo);
			System.out.println("cardDescription : " + cardDescription);

			if (cardDescription.contains(customertype)) {
				logPass("All members are comes under same type");

			} else {
				logFail("All members are not comes under same type");

			}
		}
	}

	public void validateBulkReissuedCardsExpiryDate(String dateBeforeReissue, String dateAfterReissue,
			int maximumCardExpiryMonths) {
		Date currentDate = null, expectedDate = null;
		String dateExpected;
		try {
			currentDate = new SimpleDateFormat("yyyy-MM-dd").parse(dateBeforeReissue);
			expectedDate = new SimpleDateFormat("yyyy-MM-dd").parse(dateAfterReissue);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		Calendar c = Calendar.getInstance();
		c.setTime(currentDate);
		c.add(Calendar.MONTH, maximumCardExpiryMonths);
		currentDate = c.getTime();
		dateExpected = getDateInFormat(currentDate, "dd-MMM-yy");
		dateAfterReissue = getDateInFormat(expectedDate, "dd-MMM-yy");
		logInfo("Expiry Date Expected: " + dateExpected);
		if (dateExpected.equalsIgnoreCase(dateAfterReissue)) {
			logPass("Expected expiry date got updated in card reissued");
		} else {
			logFail("Expected expiry date not updated in card reissued Expected: " + dateExpected + " Actual: "
					+ dateAfterReissue);
		}
	}

	public void validateBulkReissueStatus(String customerNo, String reissueStatus) {
		Common common = new Common(driver, test);
		IFCSHomePage ifcsHomePage = new IFCSHomePage(driver, test);
		ifcsHomePage.gotoCustomerMenuCustomerDetails();
		chooseSubMenuFromLeftPanel("Card Maintenance", "Bulk Reissue");
		common.chooseCustomerNoAndSearch(customerNo); // CZA0000123
		int colNum = SeleniumWrappers.getColumnNoForColumnHeader("Reissue Status", common.cardsTableHeaders);
		String currentReissueStatus = SeleniumWrappers.getTableDataWithRowAndColumnNumber(colNum, 0, driver);
		if (currentReissueStatus.contains(reissueStatus)) {
			logPass("Bulk Reissue status got changed afer job execution, Reissue status is : " + currentReissueStatus);
		} else {
			logFail("Bulk reissue status not changed after job execution, Reissue status is : " + currentReissueStatus);
		}
	}

	// Prakalpha-->Emap

	public String validatUpdateFieldsInCard(String cardNumber, String expiryDate) {
		Common common = new Common(driver, test);
		String name = fakerAPI().name().firstName();
		String licencePlate = fakerAPI().number().digits(5);
		chooseSubMenuFromLeftPanel("Card Details", "Card Maintenance");
		common.chooseCardNoAndSearch(cardNumber);
		sleep(5);
		enterValueInTextBox("Card Offer", "Expiry Date", expiryDate);
		enterValueInTextBox("Card Offer", "Emboss Name", name);
		enterValueInTextBox("Vehicle Details", "License Plate", licencePlate);
		common.clickSaveIcon();
		sleep(2);
		common.clickYesButton();
		sleep(5);
		String replaceCard = verifyReplaceCard();
		return replaceCard;
	}

	// Prakalpha-->BP 11/11/2019
	public String getReplacedCardDetails(String expectedCardStatus) {
		String replacedCardNo = "";
		chooseSubMenuFromLeftPanel("Card Details", "Card Maintenance");
		String expiryDate = getValueFromTextBox("Card Offer", "Expiry Date");
		String actualCardStatus = getValueFromProtectedTextBox("Card Offer", "Card Status");
		if (actualCardStatus.equalsIgnoreCase(expectedCardStatus)) {
			logPass("Card Status are Equal");
			replacedCardNo = getValueFromProtectedTextBox("Other Details", "Replace Card Number");
			System.out.println("Replace Card Number::" + replacedCardNo);
		} else {
			logFail("Card Status are not Equal");
		}
		return expiryDate;
	}

	public void clickNextAndValidateReplacedCardDetails(String expectedCardStatus, String expiryDate) {
		common.clickReplaceCardButton();
		sleep(5);
		verifyValueInTextBox("Card Offer", "Expiry Date", expiryDate);
		verifyTextInDropDownForProtected("Card Offer", "Card Status", expectedCardStatus);

	}

	// Prakalpha-->11/20/2019
	public ArrayList<String> bulkCardStatusChange(String newCardStatus, String popupOption) {
		List<WebElement> tableHeaders;
		WebElement cellValue;

		ArrayList<String> cardNumber = new ArrayList<String>();
		chooseSubMenuFromLeftPanel("Card Details", "Card Bulk Status");
		sleep(2);
		validateHeaderLabel("Card Bulk Status");
		List<WebElement> list = driver.findElements(By.xpath(
				"//div[@class='JFALSeparator']//div[contains(text(),'Card') and contains(text(),'Bulk') and contains(text(),'Status')]/preceding::div[@class='JFALCompControlPanel'][3]//div[@class='FALTableCellEditor_StrikeThruField JTextComponent']"));
		int rowsize = SeleniumWrappers.getTotalNumberOfRows(list, driver);
		System.out.println("Size of table" + rowsize);
		for (int row = 0; row < rowsize; row++) {
			tableHeaders = driver.findElements(By.xpath(
					"//div[@class='JFALSeparator']//div[contains(text(),'Card') and contains(text(),'Bulk') and contains(text(),'Status')]/preceding::div[@class='JFALCompControlPanel'][3]//div[@class='JViewport']/div[@class='JTableHeader']//div[@class='HeaderRenderer']"));
			int colIndex = SeleniumWrappers.getColumnNoForColumnHeader("Status", tableHeaders);
			System.out.println("column Index::" + colIndex);
			cellValue = driver.findElement(By.xpath(
					"//div[@class='JFALSeparator']//div[contains(text(),'Card') and contains(text(),'Bulk') and contains(text(),'Status')]/preceding::div[@class='JFALCompControlPanel']/preceding::div[@class='FALTableCellEditor_StrikeThruField JTextComponent'][contains(@id,'_"
							+ row + "_" + colIndex + "')]//div[@class='htmlString']"));
			String getCardStatus = cellValue.getText();
			System.out.println("getCardStatus::" + getCardStatus);
			if (getCardStatus.equals("100 Normal Service")) {
				validateCheckBoxToCheckOrUncheckInTableRow("Card Bulk Status", "Change?", row, "Checked");
				// tableHeaders =
				// driver.findElements(By.xpath("//div[@class='JFALSeparator']//div[contains(text(),'Card')
				// and contains(text(),'Bulk') and
				// contains(text(),'Status')]/preceding::div[@class='JFALCompControlPanel'][3]//div[@class='JViewport']/div[@class='JTableHeader']//div[@class='HeaderRenderer']"));
				int columnIndex = SeleniumWrappers.getColumnNoForColumnHeader("Card Number", tableHeaders);
				cellValue = driver.findElement(By.xpath(
						"//div[@class='JFALSeparator']//div[contains(text(),'Card') and contains(text(),'Bulk') and contains(text(),'Status')]/preceding::div[@class='JFALCompControlPanel']/preceding::div[@class='FALTableCellEditor_StrikeThruField JTextComponent'][contains(@id,'_"
								+ row + "_" + columnIndex + "')]//div[@class='htmlString']"));
				String card = cellValue.getText();
				System.out.println("card::" + card);
				cardNumber.add(card);
			}
		}

		chooseOptionFromDropdown("New status", newCardStatus);
		common.clickSaveIcon();

		if (popupOption.equalsIgnoreCase("No")) {
			common.clickNoButton();
		} else if (popupOption.equalsIgnoreCase("Yes")) {
			common.clickYesButton();
		}
		return cardNumber;
	}

	// Prakalpha-->11/21/2019
	public void changeLostCardToInvalidStatusInCardBulkStatus(String newCardStatus) {
		List<WebElement> tableHeaders;
		WebElement cellValue;
		chooseSubMenuFromLeftPanel("Card Details", "Card Bulk Status");
		validateHeaderLabel("Card Bulk Status");
		int totalRowsInTable = SeleniumWrappers.getTotalNumberOfRows(cardsTable, driver);
		System.out.println("rowsize" + totalRowsInTable);
		for (int row = 0; row < totalRowsInTable - 1; row++) {
			tableHeaders = driver.findElements(By.xpath(
					"//div[@class='JFALSeparator']//div[contains(text(),'Card') and contains(text(),'Bulk') and contains(text(),'Status')]/preceding::div[@class='JFALCompControlPanel'][3]//div[@class='JViewport']/div[@class='JTableHeader']//div[@class='HeaderRenderer']"));
			int colIndex = SeleniumWrappers.getColumnNoForColumnHeader("Status", tableHeaders);
			cellValue = driver.findElement(By.xpath(
					"//div[@class='JFALSeparator']//div[contains(text(),'Card') and contains(text(),'Bulk') and contains(text(),'Status')]/preceding::div[@class='JFALCompControlPanel']/preceding::div[@class='FALTableCellEditor_StrikeThruField JTextComponent'][contains(@id,'_"
							+ row + "_" + colIndex + "')]//div[@class='htmlString']"));
			String getCardStatus = cellValue.getText();
			System.out.println("getCardStatus::" + getCardStatus);
			if (getCardStatus.contains("Lost")) {
				validateCheckBoxToCheckOrUncheckInTableRow("Card Bulk Status", "Change?", row, "Checked");
			}
		}
		chooseOptionFromDropdown("New status", newCardStatus);
		common.clickSaveIcon();
		common.clickYesButton();
		verifyValidationResult("Invalid card status change combination");
	}

	// Prakalpha -->11/22/2019
	public void validateNewCardStatusIsChanged(String expectedStatus, ArrayList<String> cardNumbers) {
		for (int i = 0; i < cardNumbers.size(); i++) {
			chooseSubMenuFromLeftPanel("Card Maintenance", "Cards");
			common.clickDetailSearchIfFilterFieldsNotPresent();
			enterValueInTextBox("Filter By", "Card Number", cardNumbers.get(i));
			sleep(2);
			common.searchListTorch();
			sleep(2);
			WebElement firstRow = driver.findElement(By.xpath(
					"//div[@class='FALTableCellEditor_StrikeThruField JTextComponent'][contains(@id,'_0_0')]//div[@class]"));
			doubleClick(firstRow);
			sleep(2);
			common.clickReplaceCardButton();
			sleep(2);
			verifyTextInDropDownForProtected("Card Offer", "Card Status", expectedStatus);

		}
	}

	// Prakalpha -->11/22/2019
	public void validateNewCardStatusIsNotChanged(String expectedStatus, ArrayList<String> cardNumbers) {

		for (int i = 0; i < cardNumbers.size(); i++) {
			chooseSubMenuFromLeftPanel("Card Maintenance", "Cards");
			common.clickDetailSearchIfFilterFieldsNotPresent();
			enterValueInTextBox("Filter By", "Card Number", cardNumbers.get(i));
			sleep(2);
			common.searchListTorch();
			sleep(2);
			WebElement firstRow = driver.findElement(By.xpath(
					"//div[@class='FALTableCellEditor_StrikeThruField JTextComponent'][contains(@id,'_0_0')]//div[@class]"));
			doubleClick(firstRow);
			sleep(2);
			verifyTextInDropDownForProtected("Card Offer", "Card Status", expectedStatus);

		}
	}

	/*
	 * Create a private profile in card maintenance
	 */
	public void createPrivateProfileForACard() {
		// MaintainCustomerPage maintainCustomerPage = new
		// MaintainCustomerPage(driver,test);
		// isDisplayedThenClick(cardMaintenanceProfileTab,"Clicking on profile tab");
		// common.rightClickAndCreatePrivateProfile(profileTable);
		// sleep(3);
		// maintainCustomerPage.setPrivateProfileAsDefault("Profiles");
		// common.validateCheckBoxInTableAndDoubleClick("Profiles", "Private",
		// "Description");
		// sleep(3);
		scrollDownPage();
		
	}

	/*
	 * Enter private profile description in pop up
	 */
	public void enterPrivateProfileDescription(String description) {
		// enterText(profileDescription,description);
		// sleep(1);
		scrollDownPage();
	}

	/*
	 * Save private profile and validate the message
	 */
	public void saveProfileAndValidateMessage() {
		scrollDownPage();
		common.clickOkButton();
		sleep(5);
		common.clickSaveIcon();
		verifyValidationResult("Record saved OK");
	}

	/**
	 * @vdavu Validating the mandatory fields on Order Card Page as per the Card
	 *        type
	 */
	public void validateMandatoryFieldsInCardCreationPage() {
		MaintainCustomerPage maintainCustomerPage = new MaintainCustomerPage(driver, test);
		chooseSubMenuFromLeftPanel("Card Details", "Order New Card");
		common.chooseARandomDropdownOption("Card Offer");
		String cardProduct = common.chooseARandomDropdownOption("Card Product");
		switchTabDetails("Profiles");
		common.rightClickAndCreatePrivateProfile(orderCardCardControlsTable);
		sleep(2);
		common.clickValidateIcon();
		sleep(2);
		verifyValidationResult("Default Card Control Profile not defined for Card Offer.");
		sleep(5);
		common.rightClickAndSelectMenuItem("Select Profile", orderCardCardControlsTable, selectProfile);
		sleep(5);
		common.rightClickAndSelectMenuItem("Details", orderCardCardControlsTable, poupMenuItemDetails);
		sleep(5);
		validatePopupHeaderText("Card Controls");
		sleep(2);
		maintainCustomerPage.enterDetailsInCardControlProfile();
		sleep(5);
		common.clickOkButton();
		sleep(2);
		switchTabDetails("Card Details");
		sleep(5);
		//String cardProduct = common.getValueFromTextBox("Card Offer", "Card Product");
		common.clickValidateIcon();

		if (cardProduct.contains("Driver")) {
			verifyValidationResult("Some mandatory fields have not been completed");
			sleep(2);
			enterValueInTextBox("Driver Details", "Driver Name", fakerAPI().name().fullName());
			sleep(2);
			common.clickValidateIcon();

		}

		verifyValidationResult("Validation successful");

	}

	/**
	 * @return Reissue Profile Name
	 */
	public String getCardReissueProfileName() {
		chooseSubMenuFromLeftPanel("Customer Profiles", "Card Reissue Profiles");

		WebElement cellElement = SeleniumWrappers.getTableDataWithCellElement(0, 2, driver);
		String profileName = cellElement.getText();
		return profileName;
	}

	/**
	 * @return Card Number from Reissue Table
	 */
	public String getCardNumberFromBulkReissueTable() {
		sleep(5);
		WebElement cellElement = SeleniumWrappers.getTableDataWithCellElement(0, 1, driver);
		String cardNumber = cellElement.getText();

		common.clickOkButton();
		sleep(2);
		return cardNumber;
	}

	/**
	 * @param cardOffer
	 * @param cardType
	 * @param CardStatus
	 */
	public void searchCardByFilters(String cardOffer, String cardType, String CardStatus) {
		ScrollToElement("Filter By", cardOffer);
		common.searchCardsWithDifferentFilters(cardOffer, "random");
		ScrollToElement("Filter By", cardType);
		common.searchCardsWithDifferentFilters(cardType, "random");
		ScrollToElement("Filter By", CardStatus);
		common.searchCardsWithDifferentFilters(CardStatus, "random");

		}

	/**
	 * Download the search results
	 */
	public void downloadCSVForCards() {
		common.searchListTorch();
		sleep(5);
		verifyValidationResult("Record Read OK - Page Size");
		try {
			if (SeleniumWrappers.getTotalNumberOfRows(cardsTable, driver) > 0) {
				sleep(5);
				WebElement firstRow = driver.findElement(By.xpath(
						"//div[@class='FALTableCellEditor_StrikeThruField JTextComponent'][contains(@id,'_0_0')]//div[@class]"));
				rightClick(firstRow);
				sleep(5);
				common.clickCSVExportInPopup();

			} else {
				logInfo("no cards found");
			}
		} catch (Exception ex) {
			logInfo("no cards found");
		}
	}
	
	public void validateBulkReissueCardsWithInvalidCard(int beforeNoOfcard, String cardNumber)
	{
		//int afterbeforeNoOfcard = common.getRowNumberFromTable();
		
		if (beforeNoOfcard >1) {
			List<WebElement> elements = driver
					.findElements(By.xpath("//div[@class='FALTableCellEditor_StrikeThruField JTextComponent']"));
			List<String> Cardnumbers = SeleniumWrappers.getTableDataWithColumnNumber(1, elements,
					driver);
			
			System.out.println(Cardnumbers);
			
			for (String i : Cardnumbers )
			{
				if(i.equals(cardNumber))
				{
					System.out.println("Invalid Card present in Bulk reissue cards list");
					logFail("Invalid Card present in Bulk reissue cards list");
				}
				else
				{
					System.out.println("Invalid Card not present in Bulk reissue cards list");
					logPass("Invalid Card not present in Bulk reissue cards list");
				}
			}
		}else 
		{
			List<WebElement> elements = driver
					.findElements(By.xpath("//div[@class='FALTableCellEditor_StrikeThruField JTextComponent']"));
			
			System.out.println("Elements values: "+elements);
			
			if (elements.isEmpty())
			{
				System.out.println("Invalid Card not present in Bulk reissue cards list");
				logPass("Invalid Card not present in Bulk reissue cards list");
			}
			else {
				System.out.println("Invalid Card present in Bulk reissue cards list");
				logFail("Invalid Card present in Bulk reissue cards list");
			}
		}
		
		sleep(2);
		
	}
	
	public void updateEnableVINCIFee()
	{
		switchTabDetails("Value Added Services");
		sleep(2);
		common.rightClickAndSelectMenuItem("Details", valueAddedServicesTable, poupMenuItemDetails);
		sleep(2);
		String selectedOrNot = common.checkAndUncheckTheCheckBox("Opt In");
		sleep(2);
		common.clickOkButton();
		sleep(3);
		
		common.clickSaveIcon();
		
		if(selectedOrNot.equals("Selected"))
		{
			sleep(2);
			common.rightClickAndSelectMenuItem("Details", valueAddedServicesTable, poupMenuItemDetails);
			 common.checkAndUncheckTheCheckBox("Opt In");
			 sleep(2);
				common.clickOkButton();
				sleep(3);
				switchTabDetails("Card Details");
				sleep(2);
				common.clickSaveIcon();
		}
		
	}
	
	public void updateCostCentreForCard(String costCenter) {
		sleep(3);
		common.enterValueInTextBox("Card Offer", "Cost Centre", costCenter);
		sleep(3);
		common.clickSaveIcon();
		sleep(5);
		common.verifyValidationResult("Record Saved OK");
	}

public void validateAutoBulkReissueStatus(String statusExpected)
	{
		
		chooseSubMenuFromLeftPanel("Card Details", "Bulk Reissue");
		sleep(5);
		 String status = SeleniumWrappers.getTableDataWithRowAndColumnNumber(0, 0, driver);
		 
		 if(status.equals(statusExpected)) {
			 System.out.println("Bulk reissue status updated as expected:"+status);
			 	 
		 }
		 else {
			 System.out.println("Bulk reissue status not updated as expected:"+status);
		 }
		 
	}

}
