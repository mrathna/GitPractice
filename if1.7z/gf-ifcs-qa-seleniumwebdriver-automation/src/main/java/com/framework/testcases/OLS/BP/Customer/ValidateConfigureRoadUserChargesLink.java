package com.framework.testcases.OLS.BP.Customer;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.BP.BPHomePage;
import com.framework.pages.BP.BPOrderCard;
import com.framework.pages.OLS.common.LoginPage;

public class ValidateConfigureRoadUserChargesLink extends BaseTest {
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "Regression" })

	public void ConfigureRoadUserChargesLink(@Optional("AU") String clientCountry, @Optional("BP") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  BP Configure RoadUser Charges Link", "Checking Configure RoadUser Charges Link");

		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		BPHomePage bpHomePage = new BPHomePage(driver, test);
		BPOrderCard bpOrderAndEditCard = new BPOrderCard(driver, test);		
		// Call Function
		loginPage.Login("BP_URL", "BP_UN_Customer_" + clientCountry, "BP_PWD_Customer_" + clientCountry, clientName);
		bpHomePage.ValidateBPCustomerLogo();

		// Load Find And Update Card Page
		bpHomePage.loadFindAndUpdateCardPage();

		// Search Cards
		bpOrderAndEditCard.clickSearchButton();

		bpOrderAndEditCard.pickActiveCardAndEdit();
//		bpOrderAndEditCard.clickEditCardFromCardListAndValidate();

		bpOrderAndEditCard.verifyEditCardPageTitle("Edit Card");
		
		//  select Configure Road User change link and validate in-side the page fields 
		bpOrderAndEditCard.validateConfigureRoadUserChargeslinkPage();
		
		loginPage.Logout();

}
}
