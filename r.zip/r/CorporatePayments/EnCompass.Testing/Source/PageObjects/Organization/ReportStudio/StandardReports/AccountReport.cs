﻿using Common;
using Common.Utility;
using NFluent;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Support.UI;
using System;
using System.IO;
using System.Threading;

namespace EnCompass.Testing.Source.PageObjects.Organization.ReportStudio.StandardReports
{
    [PageModel(@"/ReportStudio/standardReports/AccountReport.aspx")]
    public class AccountReport : EnCompassPageModel
    {
        public AccountReport(GlobalSettings settings) : base(settings) { ScheduleReport = new ScheduleReport(Driver, settings); }

        public override string RelativeUrl => @"/reportStudio/standardReports/AccountReport.aspx";
        public override string PageIdentifierXPath_Override => @"//li[@class='breadcrumb-item active'][text() = 'Accounts']";
        public ScheduleReport ScheduleReport { get; set; }

        #region XPath page Elements
        private const string _firstNameTextXPath = @"//input[contains(@id, 'FirstNameText')]";
        private const string _formatListXPath = @"//select[contains(@id, 'FormatList')]";
        private const string _progressLockXPath = @"//div[contains(@id, 'upProgress')]";
        private const string _executeRunXPath = @"//input[contains(@id,'StdReport_RunButton')]";
        private const string _formatXPath = @".//select[contains(@id, 'StdReport_FormatList')]";
        private const string _toggleAllCheckboxXPath = @"//label[contains(@for, 'toggleAll')]//preceding-sibling::input[@type='checkbox']";
        private const string _toggleAllCheckboxLabelXPath = @"//label[contains(@for, 'toggleAll')]";
        private const string _activeCheckboxXPath = @"//label[contains(text(),'Active')]//preceding-sibling::input[@type='checkbox']";
        private const string _activeCheckboxLabelXPath = @"//label[contains(text(),'Active')]";
        private const string _frequencyListXPath = @"//select[contains(@id,'frequency')]";
        private const string _emailDeliveryXPath = @"//textarea[contains(@id,'email')]";
        #endregion


        #region Page Elements
        private IWebElement _firstNameText
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_firstNameTextXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_firstNameText element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _formatList
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_formatListXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_formatList element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _progressLock
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_progressLockXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_progressLock element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _executeRun
        {
           get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_executeRunXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_executeRun element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _format
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_formatXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_format element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _toggleAllCheckbox
        {
            get
            {
                bool found = Driver.TryFindElement(By.XPath(_toggleAllCheckboxXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_toggleAllCheckbox element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _toggleAllCheckboxLabel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_toggleAllCheckboxLabelXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_toggleAllCheckboxLabel element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _activeCheckbox
        {
            get
            {
                bool found = Driver.TryFindElement(By.XPath(_activeCheckboxXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_activeCheckbox element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _activeCheckboxLabel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_activeCheckboxLabelXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_activeCheckboxLabel element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _frequencyList
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_frequencyListXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_frequencyList element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _emailDelivery
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_emailDeliveryXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_emailDelivery element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        #endregion

        public void Run()
        {
            _executeRun.JSClickWithFocus(Driver);
        }

        public void SetActiveCheckboxState(bool state)
        {
            _activeCheckbox.SetCheckboxStateWithLabel(_activeCheckboxLabel, state);
            Settings.EnCompassExtentTest.Info($"'Active' Checkbox state set to {state}.");
        }

        public void SetToggleAllCheckboxState(bool state)
        {
            _toggleAllCheckbox.SetCheckboxStateWithLabel(_toggleAllCheckboxLabel, state);
            Settings.EnCompassExtentTest.Info($"'Toggle All' Checkbox state set to {state}. All 'Status' Checkboxes set to {state}");
        }

        public void SetFrequencyList(string whichText)
        {
            var selectElement = new SelectElement(_frequencyList);
            selectElement.SelectByText(whichText);
        }


        public void SetEmailDelivery(string value)
        {
            _emailDelivery.ForceDocumentLoadOnSendKeys(value, Driver);
            Settings.EnCompassExtentTest.Info($"EmailDelivery is set to " + value);
        }

        public string FirstNameText
        {
            set
            {
                _firstNameText.Clear();
                _firstNameText.SendKeys(value);
            }
        }

        public void SetFormatList(string whichText)
        {
            var selectElement = new SelectElement(_formatList);
            selectElement.SelectByText(whichText);
        }

        public string Format
        {
            set
            {
                _format.SetListboxByText(value, SelectTextOptions.Contains);
                Settings.EnCompassExtentTest.Info("Selected User Report download format as :" + value);
            }
            get
            {
                SelectElement _elem = new SelectElement(_format);
                return _elem.SelectedOption.Text;
            }
        }

        public void SearchCriteriaFirstNameAndRun(string reportFormat)
        {
            SetActiveCheckboxState(true);

            if (StringKeys.FIsCardsUpdateBlocked.Contains(GlobalSettings.FI))
                FirstNameText = "Fake";
            else
                FirstNameText = Settings.CeatedOrgId;
            SetFormatList(reportFormat);
            Run();

            var fileName = @"Account";

            string absPathToTemplateDir = PathHelper.GetAbsolutePathRelativeToProjectPath(GlobalSettings.TemplateRelativePath);
            string fileAbsPath = Path.Combine(absPathToTemplateDir, fileName);

            if (reportFormat == "Adobe PDF (.PDF)")
                fileAbsPath += ".pdf";
            else if (reportFormat == "Excel 97-2003 (.XLS)")
                fileAbsPath += ".xls";
            else if (reportFormat == "Comma-Separated Values (.CSV)")
                fileAbsPath += ".txt";

            new WebDriverWait(Driver, TimeSpan.FromSeconds(60)).Until(d => File.Exists(fileAbsPath));
        }
    }
}
