﻿using Common;
using Common.Utility;
using EnCompass.Testing.Source.PageObjects.Controls;
using NFluent;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.PageObjects;

namespace EnCompass.Testing.Source.PageObjects.Organization.Admin.Proxy
{
    public partial class CardProxy
	{
        #region XPATH

        private const string _searchTermListXPath = @"//div[contains(@id, 'SearchOutput')]/select[1]";
        private const string _userAccountsProxyingCardRadiobuttonXPath = @"//input[contains(@id, 'ProxySearchOptions_1')]";
        private const string _userAccountsProxyingCardRadiobuttonLabelXPath = @"//label[contains(@for, 'ProxySearchOptions_1')]";
        private const string _usersProxyingMyCardsRadiobuttonXPath = @"//input[contains(@id, 'UserAccountsProxyingCards_1')]";
        private const string _usersProxyingMyCardsRadiobuttonLabelXPath = @"//label[contains(@for, 'UserAccountsProxyingCards_1')]";
        private const string _cardsBeingProxiedRadiobuttonXPath = @"//input[contains(@id, 'ProxySearchOptions_0')]";
        private const string _cardsBeingProxiedRadiobuttonLabelXPath = @"//label[contains(@for, 'ProxySearchOptions_0')]";
        private const string _cardsIproxyRadiobuttonXPath = @"//input[contains(@id, 'CardsBeingProxied_2')]";
        private const string _cardsIproxyRadiobuttonLabelXPath = @"//label[contains(@for, 'CardsBeingProxied_2')]";
        private const string _btnSearchXPath = @"//input[contains(@id, 'btnSearch')]";
        private const string _noCardsBeingProxiedFoundXPath = @"//td[@class='gridNoRecordsMessage']";
        private const string _allCardsRadiobuttonXPath = @"//input[contains(@id, 'rblCardsBeingProxied_0')]";
        private const string _allCardsRadiobuttonLabelXPath = @"//label[contains(@for, 'rblCardsBeingProxied_0')]";
        private const string _addNewXPath = @"//div[contains(@class, 'actionItemTextDiv')]";
        public const string _deleteButton = "//a[contains(@id,'actionLink')][text()='Delete']";

        #endregion

        #region IWebElements Props

        public IWebElement _searchTermList
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_searchTermListXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_searchTermList element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _userAccountsProxyingCardRadiobutton
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_userAccountsProxyingCardRadiobuttonXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_userAccountsProxyingCardRadiobutton element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _userAccountsProxyingCardRadiobuttonLabel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_userAccountsProxyingCardRadiobuttonLabelXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_userAccountsProxyingCardRadiobuttonLabel element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _usersProxyingMyCardsRadiobutton
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_usersProxyingMyCardsRadiobuttonXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_usersProxyingMyCardsRadiobutton element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _usersProxyingMyCardsRadiobuttonLabel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_usersProxyingMyCardsRadiobuttonLabelXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_usersProxyingMyCardsRadiobuttonLabel element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _cardsBeingProxiedRadiobutton
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_cardsBeingProxiedRadiobuttonXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_cardsBeingProxiedRadiobutton element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _cardsBeingProxiedRadiobuttonLabel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_cardsBeingProxiedRadiobuttonLabelXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_cardsBeingProxiedRadiobuttonLabel element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _cardsIproxyRadiobutton
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_cardsIproxyRadiobuttonXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_cardsIproxyRadiobutton element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _cardsIproxyRadiobuttonLabel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_cardsIproxyRadiobuttonLabelXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_cardsIproxyRadiobuttonLabel element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _btnSearch
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_btnSearchXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_btnSearch element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _allCardsRadiobutton
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_allCardsRadiobuttonXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_allCardsRadiobutton element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _allCardsRadiobuttonLabel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_allCardsRadiobuttonLabelXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_allCardsRadiobuttonLabel element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _addNew
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_addNewXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_addNew element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        #endregion


        

        private GridControl _selectCardProxies;
        public GridControl SelectGridCardProxies
        {
            get
            {
                return _selectCardProxies ?? (_selectCardProxies = new GridControl("dgCardProxies", Driver));
            }
        }

        public bool VerifyNoRecordMessage
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_noCardsBeingProxiedFoundXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_noCardsBeingProxiedFoundXPath is found " + found);
                return found;
            }
        }

        public string SearchTermValues
		{
			get
			{
				return _searchTermList.Text;
			}
		}

		public void AddNew()
		{
			_addNew.JSClickWithFocus(Driver);
			Settings.EnCompassExtentTest.Info("Clicked on Add New Button");
		}
        public void SelectCardsIProxy()
        {
            _cardsIproxyRadiobutton.SetRadioButtonStateWithLabel(_cardsIproxyRadiobuttonLabel, true);
			Settings.EnCompassExtentTest.Info("Selected Radio Button for Cards Proxy");
		}

		public void SelectUserAccountsProxyingACard()
		{
			_userAccountsProxyingCardRadiobutton.SetRadioButtonStateWithLabel(_userAccountsProxyingCardRadiobuttonLabel, true);
		}

        public void SelectUsersProxyingMyCards()
        {
			_userAccountsProxyingCardRadiobutton.SetRadioButtonStateWithLabel(_userAccountsProxyingCardRadiobuttonLabel, true);
			_usersProxyingMyCardsRadiobutton.SetRadioButtonStateWithLabel(_usersProxyingMyCardsRadiobuttonLabel, true);
            WaitForFormLoadingOverlay();
        }

        public void PressSearchButton()
        {
            _btnSearch.JSClickWithFocus(Driver);
			Settings.EnCompassExtentTest.Info("Clicked on Search Button");
            WaitForLoad();
		}

        public void SelectCardsBeingProxied()
        {
			_cardsBeingProxiedRadiobutton.SetRadioButtonStateWithLabel(_cardsBeingProxiedRadiobuttonLabel, true);
		}

        public void SelectAllCards()
        {
			_allCardsRadiobutton.SetRadioButtonStateWithLabel(_allCardsRadiobuttonLabel, true);
        }
        public void CheckCardLastNameOnGrid(string cardName)
        {
            if (!StringKeys.FIsCardsUpdateBlocked.Contains(GlobalSettings.FI))
            {
                Driver.ScrollToXPATH("//a[text()='" + cardName + "']");
                Settings.EnCompassWebDriver.WaitForVisible(By.XPath("//a[text()='" + cardName + "']"));
            }
            else
            {
                Driver.ScrollToXPATH("//td[text()='" + cardName + "']");
                Settings.EnCompassWebDriver.WaitForVisible(By.XPath("//td[text()='" + cardName + "']"));
            }
        }
        public void VerifyDeleteButton()
        {
            Settings.EnCompassWebDriver.WaitForVisible(By.XPath(_deleteButton));
        }

        public string GetRecordsMessage()
        {
            return Settings.EnCompassWebDriver.WaitForVisible(By.XPath("//td[@class='gridNoRecordsMessage']")).GetAttribute("innerText");
        }
    }
}
