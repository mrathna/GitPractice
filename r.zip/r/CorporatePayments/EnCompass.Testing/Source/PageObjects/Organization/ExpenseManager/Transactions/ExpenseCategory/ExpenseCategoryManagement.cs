﻿using Common;
using Common.Utility;
using EnCompass.Testing.Source.PageObjects.Controls;
using NFluent;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EnCompass.Testing.Source.PageObjects.Organization.ExpenseManager.Transactions.ExpenseCategory
{
	public class ExpenseCategoryManagement : EnCompassPageModel
	{
		public ExpenseCategoryManagement(GlobalSettings settings) : base(settings) { }

        #region XPATH

        public override string RelativeUrl => @"/expenseManager/transactions/expenseCategory/expenseCategoryManagement.aspx";
		public override string PageIdentifierXPath_Override => @"//li[@class='breadcrumb-item active'][text() = 'Expense Categories']";

        private const string _addNewXPath = @"//div[contains(@id, 'actionAddItem')]";

        private const string _exportTypeDdlXPath = @"//Select[contains(@id, '_ddlExportType')]";

        private const string _exportXPath = @"//input[contains(@id, 'btnExportGridText')]";

        #endregion

        #region IWebElements Props

        public IWebElement _addNew
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_addNewXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_addNew element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _exportTypeDdl
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_exportTypeDdlXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_exportTypeDdl element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _export
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_exportXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_export element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        #endregion
        
		public void AddNewExpenseCategory()
		{
            //JSClickWithFocus is not working for that element
            _addNew.BootstrapClick();
			Settings.EnCompassExtentTest.Info("Clicked on Add New Expense Category button.");
		}
		
		public GridControl ExpenseCategoriesGrid
		{
			get
			{
				GridControl _expCat = new GridControl("dgExpenseCategories", Driver);
				_expCat.WaitForGrid();
				return _expCat;
			}
		}

		public string SetTypeAndExport
		{
			set
			{
				new SelectElement(_exportTypeDdl).SelectByText(value);
				_export.JSClickWithFocus(Driver);
			}			
		}

		

	}
}
