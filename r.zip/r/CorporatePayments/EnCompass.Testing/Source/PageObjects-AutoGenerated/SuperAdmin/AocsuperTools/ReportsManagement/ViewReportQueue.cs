using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using Common;
using Common.PageObjects;
using Common.ScenarioConfigurations;
using Common.Utility;

namespace EnCompass.Testing.Source.PageObjects.SuperAdmin.AocsuperTools.ReportsManagement 
{
	/// <summary>
	/// Auto-generated Page Model Class
	/// Navigation Paths: 
		/// [Organization Home]->Super Admin Tools->Reports->View Report Queue History
		/// </summary>
	[PageModel(@"/superAdmin/AOCSuperTools/ReportsManagement/ViewReportQueue.aspx")]
	public partial class ViewReportQueue : EnCompassSuperPageModel 
	{
		public override string RelativeUrl => @"/superAdmin/AOCSuperTools/ReportsManagement/ViewReportQueue.aspx";
		public override string PageIdentifierXPath_Generated => @"//li[contains(@class, 'breadcrumb-item active')][text() = 'View Report Queue History']";

		#region Navigation
				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='All Reports']")]
		private IWebElement _superAdminTools_Reports_ViewReportQueueHistory_AllReports { get; set; }
		public void NavigateTo_SuperAdminTools_Reports_ViewReportQueueHistory_AllReports()
		{
			NavigateToMenuItem(_superAdminTools_Reports_ViewReportQueueHistory_AllReports);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Scheduled Reports Viewer']")]
		private IWebElement _superAdminTools_Reports_ViewReportQueueHistory_ScheduledReportsViewer { get; set; }
		public void NavigateTo_SuperAdminTools_Reports_ViewReportQueueHistory_ScheduledReportsViewer()
		{
			NavigateToMenuItem(_superAdminTools_Reports_ViewReportQueueHistory_ScheduledReportsViewer);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='View Scheduled Reports' History']")]
		private IWebElement _superAdminTools_Reports_ViewReportQueueHistory_ViewScheduledReportsHistory { get; set; }
		public void NavigateTo_SuperAdminTools_Reports_ViewReportQueueHistory_ViewScheduledReportsHistory()
		{
			NavigateToMenuItem(_superAdminTools_Reports_ViewReportQueueHistory_ViewScheduledReportsHistory);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='View Report Queue History']")]
		private IWebElement _superAdminTools_Reports_ViewReportQueueHistory_ViewReportQueueHistory { get; set; }
		public void NavigateTo_SuperAdminTools_Reports_ViewReportQueueHistory_ViewReportQueueHistory()
		{
			NavigateToMenuItem(_superAdminTools_Reports_ViewReportQueueHistory_ViewReportQueueHistory);
		}

		
		private void NavigateToMenuItem(IWebElement element)
		{
			Driver.Url = element.GetAttribute("href");
		}
		#endregion

		public ViewReportQueue(GlobalSettings settings) : base(settings) { }
	}  
}
