package com.framework.testcases.AJS.CHEVRON;

import java.util.List;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.AdminPage;
import com.framework.pages.AJS.ClientConfigPage;
import com.framework.pages.AJS.common.Common;
import com.framework.pages.AJS.common.CommonInterfacePage;
import com.framework.pages.AJS.common.IFCSCommonPage;
import com.framework.pages.AJS.common.IFCSHomePage;
import com.framework.pages.AJS.common.IFCSLoginPage;

public class DEValidationForE2EScenario extends BaseTest{
	//Need to add this method in Validation Part
		@Parameters({ "clientCountry", "clientName" })
		@Test(groups = { "Regression" },enabled=false)
		public void verifyTheClientDayEndReportsInIFCS(@Optional("SG") String clientCountry,
				@Optional("CHEVRON") String clientName) {
			test = extent.createTest(clientName+ ":" +clientCountry+"  DayEnd Reports", "Verify the ClientDayEnd reports");

			// creating object for the Pages
			IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
			IFCSHomePage IFCShomePage = new IFCSHomePage(driver, test);
			AdminPage adminPage = new AdminPage(driver, test);
			ClientConfigPage clientConfigPage = new ClientConfigPage(driver, test);
			IFCSloginPage.login("IFCS_URL_CHEVRON", "IFCS_CHEVRON_USERNAME", "IFCS_CHEVRON_PASSWORD");
			IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
			IFCShomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);
			// Get Assigned Daily Reports
			List<String> dailyReports = adminPage.getClientReportAssignments("Report Daily");
			// Get Assigned Monthly Reports
			List<String> monthlyReports = adminPage.getClientReportAssignments("Report Monthly");
			clientConfigPage.goToStoredReportsAndFilterCurrentDate();
			clientConfigPage.validateReportsInStoredReports(dailyReports);
			// Monthly Report Validation 
			clientConfigPage.validateReportsInStoredReports(monthlyReports);
			IFCShomePage.exitIFCS();

		}
		
		//Need to add this method in Validation Part
		@Parameters({ "clientCountry", "clientName" })
		@Test(groups = { "Regression" },enabled=false)
		public void validateDailyReconciliationReport(@Optional("HK") String clientCountry, @Optional("CHEVRON") String clientName) {
			
			test = extent.createTest(clientName+ ":" +clientCountry+"  Validate Daily Reconciliation Report", "Validate Daily Reconciliation Report");
			IFCSCommonPage ifcsCommonPage = new IFCSCommonPage(driver, test);
			CommonInterfacePage commonInterfacePage = new CommonInterfacePage(driver, test);
			IFCSLoginPage ifcsLoginPage = new IFCSLoginPage(driver, test);
			ifcsLoginPage.setClientCountryCardTypeDetails(clientName, clientCountry," ");
			
			String fileName=commonInterfacePage.getRecentProcessedReportFiles(clientName, clientCountry,
					"Daily Reconciliation Report","");
			String dayEndDatePath=commonInterfacePage.getFolderPathUsingPreviousProcessingDate(clientName, clientCountry,"IFCS_DAYEND_OUTPUTFILE_AU");
					System.out.println("dayEndDatePath::" +dayEndDatePath);
			ifcsCommonPage.establishThePuttyConnection("incomingFile", "PUTTY_HOST", "PUTTY_USERNAME", "PUTTY_PASSWORD", dayEndDatePath, fileName);		
			
			System.out.println("fileName::" + fileName);
			
			ifcsCommonPage.validateDailyReconciliationPDFReport(fileName);//"63-Daily Reconciliation Report 03.02.2020.pdf");
			
			
		}
		
		//Need to add After Validation Part
			@Parameters({ "clientCountry", "clientName" })
			@Test(groups = { "Regression" })
			public void clearTemplateFile(@Optional("HK") String clientCountry, @Optional("CHEVRON") String clientName) {
				
				test = extent.createTest(clientName+ ":" +clientCountry+"  delete template file", "Delete Template File");
				
				Common common=new Common(driver,test);
				common.clearTemplateFileContents(chevronEndToEndTemplateFile, duplicateTemplateFile);
			
			}
}
