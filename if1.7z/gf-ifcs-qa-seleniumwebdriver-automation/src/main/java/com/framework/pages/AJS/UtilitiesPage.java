package com.framework.pages.AJS;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

import com.aventstack.extentreports.ExtentTest;
import com.framework.pages.AJS.common.Common;
import com.framework.repo.Locator_IFCS;
import com.framework.util.SeleniumWrappers;

public class UtilitiesPage extends Common {

	@FindBy(xpath = Locator_IFCS.SEARCH_RESULTS_TABLE)
	public List<WebElement> reportsTable;

	@FindBy(xpath = Locator_IFCS.TASKBAR_SUBMIT)
	public WebElement taskBarSubmit;

	@FindBy(xpath = Locator_IFCS.REPORT_TYPE_POPUP)
	public WebElement reportTypePopup;
	@FindBy(xpath = Locator_IFCS.AVAILABLE_REPORTS)
	public WebElement availableReports;

	@FindBy(xpath = Locator_IFCS.DEFINE_PARAMETERS_IN_POPUP)
	public WebElement defineParametersInPopup;
	@FindBy(xpath = Locator_IFCS.AD_HOC_REPORTS)
	public WebElement adhocReports;
	@FindBy(xpath = Locator_IFCS.DATE_RANGE_FROM)
	public WebElement dateRangeFrom;
	@FindBy(xpath = Locator_IFCS.DATE_RANGE_TO)
	public WebElement dateRangeTo;
	@FindBy(xpath = Locator_IFCS.IFCS_DATE)
	public WebElement ifcsDate;
	@FindBy(xpath = Locator_IFCS.OK_BUTTON_POPUP)
	public WebElement okButtonPopup;
	@FindBy(xpath = Locator_IFCS.VALIDATION_RESULT)
	public WebElement validationMsg;
	private String dateFromValue, dateToValue;

	public UtilitiesPage(WebDriver driver, ExtentTest test) {
		super(driver, test);
		PageFactory.initElements(new AjaxElementLocatorFactory(driver, 15), this);
	}

	Common common = new Common(driver, test);

	public void chooseAdhocReportsFromUtilities() {
		sleep(2);
		chooseSubMenuFromLeftPanel("Ad-Hoc Reports", "");
	}

	public String getRandomTableValueForAdhocReports(String userName) {
		int totalReportsCount = SeleniumWrappers.getNumberOfRows(driver);
		String choosenReportType, choosenReport;
		if (totalReportsCount > 0) {
			dateFromValue = getProcessedIFCSDate("past", 1, userName);
			dateToValue = getCurrentIFCSDate(userName);
			int randomReportIndex = getRandomNumber(0, totalReportsCount - 1);
			choosenReport = SeleniumWrappers.getTableDataWithRowAndColumnNumber(0, randomReportIndex, driver);
			choosenReportType = SeleniumWrappers.getTableDataWithRowAndColumnNumber(1, randomReportIndex, driver);
			isDisplayedThenClick(SeleniumWrappers.getTableDataWithCellElement(randomReportIndex, 0, driver),
					"Reports Table - Report");
			sleep(2);  
			isDisplayedThenClick(taskBarSubmit, "Submit For Report Generation");
			if (!choosenReportType.contains("VAT Liability Report")) {
				isDisplayed(reportTypePopup, "Report Popup");
			}

		} else {
			choosenReportType = "None";
			choosenReport = "No reports added";
		}
		return choosenReportType + "_" + choosenReport;
	}

	public void generateReportForClientWhichHasNoData(String userName) { 
		isDisplayedThenClick(SeleniumWrappers.getTableDataWithCellElement(7, 0, driver), "Reports Table - Report");
		sleep(2);
		isDisplayedThenClick(taskBarSubmit, "Submit For Report Generation");
		isDisplayed(reportTypePopup, "Report Popup");
		dateFromValue = getProcessedIFCSDate("past", 1, userName);
		dateToValue = getCurrentIFCSDate(userName);
		System.out.println("Date Range:" + dateFromValue + ":" + dateToValue);
		enterText(dateRangeTo, dateToValue);
		enterText(dateRangeFrom, dateFromValue);
		enterValuesInTextBoxReportsPopup("Bank Statement Number", fakerAPI().number().digits(8));
		isDisplayedThenClick(okButtonPopup, "Okay Button");
		sleep(3);
		verifyValidationResult("No report data");
		sleep(3);
	}

	public void enterValuesInTextBoxReportsPopup(String elementLabel, String textValue) {
		elementLabel = splitStringAndGenerateXpath(elementLabel);
		WebElement textBoxElement = driver.findElement(By.xpath("//div[@class='JLabel']/div[" + elementLabel
				+ "]/preceding::div[@class='JFALTextField JTextComponent'][1]//input"));
		enterText(textBoxElement, textValue);
	}

	public void enterDataForReportAndGenerate(String chosenReportType, String clientCountry) {
		if (chosenReportType.contains("Customer")) {
			if (chosenReportType.contains("Odometer Report")) {
				enterValuesInTextBoxReportsPopup("Account Number",
						getCustomerNumberWithCardsAndNoHierarchyFromDB("Active"));
			} else {
				enterValuesInTextBoxReportsPopup("Customer Number",
						getCustomerNumberWithCardsAndNoHierarchyFromDB("Active"));
				if (chosenReportType.contains("Card Group Summary")
						|| chosenReportType.contains("Customer Transaction Extract Report")) {
					enterText(dateRangeTo, dateToValue);
					enterText(dateRangeFrom, dateFromValue);
				}
			}
			isDisplayedThenClick(okButtonPopup, "Okay Button");
			sleep(3);
			String validationResult = getText(validationMsg);
			if (validationResult.contains("Report Created Successfully")) {
				isFileDownloaded(chosenReportType.split("_")[1].replaceAll(" ", ""));
			} else if (validationResult.contains("No report data")) {
				logInfo("Report not available");
			} else {
				logInfo("Message:" + validationResult);
			}

		} else if (chosenReportType.contains("Client")) {
			if (chosenReportType.contains("Day Trans List Sundries")) {
				enterText(dateRangeTo, dateToValue);
				isDisplayedThenClick(okButtonPopup, "Okay Button");
				sleep(3);
				verifyValidationResult("Report Created Successfully");
			} else if (!chosenReportType.contains("VAT Liability Report")) {
				enterText(dateRangeTo, dateToValue);
				enterText(dateRangeFrom, dateFromValue);
				isDisplayedThenClick(okButtonPopup, "Okay Button");
				sleep(5);
				String validationResult = getText(validationMsg);
				if (validationResult.contains("Report Created Successfully")) {
					isFileDownloaded(chosenReportType.split("_")[1].replaceAll(" ", ""));
				} else if (validationResult.contains("No report data")) {
					logInfo("Report not available");
				} else {
					logInfo("Message:" + validationResult);
				}
			}
		}
	}

	public void noReportLog() {
		logInfo("No Reports Assigned");
	}

	public void validateAdhocReportsInUtilities(String reportType) { 
		int columnNo = 0;
		WebElement cellElement;
		int size;
		try {
			isDisplayedThenClick(adhocReports, "Ad Hoc Reports Text");  
			// chooseSubMenuFromLeftPanel("Ad-Hoc Reports"," ");
			isDisplayed(availableReports, "Available Report text");
			List<WebElement> list = driver
					.findElements(By.xpath("//div[@class='FALTableCellEditor_StrikeThruField JTextComponent']"));
			size = SeleniumWrappers.getTotalNumberOfRows(list, driver);
			System.out.println(size);
			for (int row = 0; row <= size; row++) {
				System.out.println(row + " " + columnNo);
				System.out.println("New Wrapper: " + SeleniumWrappers.getTableDataWithRowAndColumnNumber(columnNo, row, driver));
				if (SeleniumWrappers.getTableDataWithRowAndColumnNumber(columnNo, row, driver).equals(reportType)) { 
					cellElement = SeleniumWrappers.getTableDataWithCellElement(row, columnNo, driver);
					isDisplayedThenClick(cellElement, "Card Group summary");
					sleep(5);
					break;
				}
			}

		} catch (Exception ex) {
			
			
		}
	}

	public void validateAdhocReportsInDateRange(String userName) {
		/*
		 * String dateRangefrom; String dateRangeTo;
		 */
		common.taskbarSubmit();
		sleep(5);
		isDisplayed(defineParametersInPopup, "Define Parameters Popup");
		enterText(dateRangeTo, getCurrentIFCSDate(userName));
		enterText(dateRangeFrom, getProcessedIFCSDate("past", 4, userName));
		sleep(3);
		isDisplayedThenClick(okButtonPopup, "OK Button");
		sleep(3);
		verifyValidationResult("Date exceeds maximum range.");

	}
}
