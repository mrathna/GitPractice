package com.framework.pages.AJS;
//rr
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

import com.aventstack.extentreports.ExtentTest;
import com.framework.pages.AJS.common.Common;
import com.framework.pages.AJS.common.IFCSHomePage;
import com.framework.pages.OLS.common.CommonPage;
import com.framework.repo.Locator_IFCS;
import com.framework.util.PropUtils;
import com.framework.util.SeleniumWrappers;

public class MaintainCustomerPage extends Common {

	@FindBy(xpath = Locator_IFCS.PRICING_TEXT)
	public WebElement pricingText;

	@FindBy(xpath = Locator_IFCS.PRICING_TABLE)
	public WebElement pricingTable;

	@FindBy(xpath = Locator_IFCS.NOTES_TABLE)
	public WebElement notesTable;

	@FindBy(xpath = Locator_IFCS.CUSTOMER_MAINTENANCE)
	public WebElement customerMaintenance;

	@FindBy(xpath = Locator_IFCS.CONTACTS_TABLE)
	public WebElement contactsTable;
	@FindBy(xpath = Locator_IFCS.CONTACTS_NAME)
	public WebElement contactName;
	@FindBy(xpath = Locator_IFCS.PHONE_NUMBER)
	public WebElement phoneNumber;

	@FindBy(xpath = Locator_IFCS.PHYSICAL_ADDRESS)
	public WebElement physicalAddress;
	@FindBy(xpath = Locator_IFCS.CUSTOMER_CONTACT)
	public WebElement customerContact;

	@FindBy(xpath = Locator_IFCS.CARDS_TABLE_HEADER)
	public List<WebElement> cardsTableHeaders;

	@FindBy(xpath = Locator_IFCS.REBATE_TABLE_HEADER)
	public List<WebElement> rebatesTableHeaders;
	@FindBy(xpath = Locator_IFCS.OK_BUTTON_POPUP)
	public WebElement okButtonPopup;

	@FindBy(xpath = Locator_IFCS.REPORTS_TABLE_HEADER)
	public List<WebElement> reportsTableHeader;
	@FindBy(xpath = Locator_IFCS.SEARCH_CARDS_TEXTBOX)
	public List<WebElement> textBoxes;
	@FindBy(xpath = Locator_IFCS.VIEW_REPORT_BUTTON)
	public WebElement viewReportButton;
	@FindBy(xpath = Locator_IFCS.EXPORT_REPORT_BUTTON)
	public WebElement exportReportButton;

	@FindBy(xpath = Locator_IFCS.POPUP_HEADER_SEARCH)
	public WebElement popupHeader;
	@FindBy(xpath = Locator_IFCS.HIERARCHIES_TABLE)
	public WebElement hierarchiesTable;

	@FindBy(xpath = Locator_IFCS.HIERARCHY_DETAIL_TABLE)
	public WebElement hierarchyDetailTable;

	@FindBy(xpath = Locator_IFCS.TREE_PARENT_HIERARCHY)
	public WebElement treeParentHierarchy;

	@FindBy(xpath = Locator_IFCS.TREE_PARENT_HIERARCHY)
	public List<WebElement> treeChildHierarchy;

	@FindBy(xpath = Locator_IFCS.ACCOUNT_MENU)
	public WebElement accountsMenu;
	@FindBy(xpath = Locator_IFCS.ACCOUNT_DETAILS_SUBMENU)
	public WebElement accountDetailsSubMenu;
	@FindBy(xpath = Locator_IFCS.CARDFEES_TABLE)
	public WebElement cardFeesTable;
	@FindBy(xpath = Locator_IFCS.AVAILABLES_PROFILE_CARDFEE_TABLE)
	public WebElement availablesProfileCardFeeTable;
	@FindBy(xpath = Locator_IFCS.AVAILABLE_PROFILE_CARDFEES_TABLE)
	public WebElement availableProfileCardFeesTable;
	@FindBy(xpath = Locator_IFCS.ACCOUNT_CONTROLS_TABLE)
	public WebElement accountControlsTable;
	@FindBy(xpath = Locator_IFCS.CARD_REISSUE_PROFILES_TABLE)
	public WebElement cardReissueProfilesTable;
	@FindBy(xpath = Locator_IFCS.AVAILABLES_PROFILE_CARDCONTROLS_TABLE)
	public WebElement availablesProfileCardControlsTable;
	@FindBy(xpath = Locator_IFCS.AVAILABLES_PROFILE_CARDCONTROLS_TABLE_WFE)
	public WebElement availablesProfileCardControlsTableWFE;
	@FindBy(xpath = Locator_IFCS.REBATE_TABLE)
	public WebElement rebateTable;
	@FindBy(xpath = Locator_IFCS.REBATE_HEADER_POPUP_TABLE)
	public WebElement rebateHeaderPopupTable;
	@FindBy(xpath = Locator_IFCS.REBATE_VALUES_POPUP_TABLE)
	public WebElement rebateValuesPopupTable;
	@FindBy(xpath = Locator_IFCS.REBATE_CONTRIBUTIONS_POPUP_TABLE)
	public WebElement rebateContributionsPopupTable;
	@FindBy(xpath = Locator_IFCS.PRICING_PROFILE_POPUP_TABLE)
	public WebElement pricingProfilePopupTable;
	@FindBy(xpath = Locator_IFCS.CARDFEES_TABLE_RIGHTCLICK)
	public WebElement cardFeesTableRightClick;

	@FindBy(xpath = Locator_IFCS.COST_CENTRE_TABLE)
	public WebElement costCentreTable;

	@FindBy(xpath = Locator_IFCS.APPLICATION_TYPE_TRANSFER)
	public WebElement applicationTypeTransfer;

	@FindBy(xpath = Locator_IFCS.ORDER_CARD_CONTROL_TABLE)
	public WebElement orderCardCardControlsTable;
	
	@FindBy(xpath = Locator_IFCS.VALUE_ADDED_SERVICES_TABLE)
	public WebElement valueAddedServicesTable;
	

	@FindBy(xpath = Locator_IFCS.TEXTBOX_CLEAR)
	public List<WebElement> textboxclear;

	@FindBy(xpath = Locator_IFCS.CARD_PRODUCTS)
	public List<WebElement> cardProductsTable;

	@FindBy(xpath = Locator_IFCS.CARD_CONTROl_PROFILE_APPL_TYPE_TRANS)
	public List<WebElement> cardsControlProfileTable;

	@FindBy(xpath = Locator_IFCS.CARD_FEE_PROFILE_APPL_TYPE_TRANS)
	public List<WebElement> cardsFeeProfileTable;

	@FindBy(xpath = Locator_IFCS.SEARCH_RESULTS_TABLE)
	public List<WebElement> searchResultsTable;

	@FindBy(xpath = Locator_IFCS.DRIVER_NAME)
	public WebElement driverName;

	@FindBy(xpath = Locator_IFCS.REBATES_PROFILE_TABLE)
	public WebElement profilesTable;

	@FindBy(xpath = Locator_IFCS.POPUP_MENUITEM_DETAILS)
	public WebElement popupMenuItemDetails;
	
	@FindBy(xpath = Locator_IFCS.POPUP_MENUITEM_SORT)
	public WebElement popupMenuItemSort;
	
	@FindBy(xpath = Locator_IFCS.POPUP_MENUITEM_SORTDESC)
	public WebElement popupMenuItemSortDesc;
	

	CommonPage commonPage = new CommonPage(driver, test);
	CardMaintenancePage cardMaintenancePage = new CardMaintenancePage(driver, test);

	public MaintainCustomerPage(WebDriver driver, ExtentTest test) {
		super(driver, test);
		PageFactory.initElements(new AjaxElementLocatorFactory(driver, 15), this);
	}

	public void verifyCustomerPricingProfile() {
		sleep(5);
		chooseSubMenuFromLeftPanel("Customer Profiles", "Pricing");
		validateHeaderLabel("Pricing");
		waitForElementTobeClickable(pricingTable, 10);
		rightClick(pricingTable);
		addIteminPopup();
	}
	
	public void verifyComplexCustomerPricingProfile() {
		sleep(5);
		chooseSubMenuFromLeftPanel("Customer Profiles", "Complex Pricing");
		validateHeaderLabel("Complex Pricing");
		waitForElementTobeClickable(pricingTable, 10);
		rightClick(pricingTable);
		addIteminPopup();
	}

	public void popupForPricingProfiles(String clientName, String clientCountry, String pricingProfileName) {
		 Common common=new Common(driver,test);

		validatePopupHeaderText("Pricing Profiles");
		/*String date=common.getCurrentIFCSDateFromDB(clientCountry);
		List<WebElement> element=driver.findElements(By.xpath("//div[@class='JFALSeparator_1']//div[contains(text(),'Pricing') and contains(text(),'Profiles')]//preceding::div[@class='FALTableCellEditor_StrikeThruDateField JTextComponent']"));
		int size=element.size();
		for(int i=0;i<size;i++) {
			String ele=driver.findElement(By.xpath("//div[@class='JFALSeparator_1']//div[contains(text(),'Pricing') "
					+ "and contains(text(),'Profiles')]//preceding::div[@class='FALTableCellEditor_StrikeThruDateField JTextComponent']"
					+ "//input[contains(@id,'_0_1Input')]")).getAttribute("submittedvalue");
		if(ele.equalsIgnoreCase(date)) {
			break;
		}*/
		//chooseOptionFromDropdown("Pricing Profile", "NewPrivateProfile");
		chooseOptionFromDropdown("Pricing Profile", pricingProfileName);
		String processingDate = getCurrentIFCSDateFromDB(clientName + clientCountry);
		String effDate = enterADateValueInStatusBeginDateField("Current", processingDate);
		enterValueInTextBox("Pricing Profile", "Assigned From", effDate);
		sleep(5);
		dropdownInPopupTable(Locator_IFCS.PRICING_PROFILE_POPUP_TABLE, "Pricing Scheme", "random");
		sleep(10);
		clickOkButton();
		sleep(5);
		validateNewDateAddedInTheTableList("Pricing Profiles", "Assigned From", effDate);
		sleep(3);
		common.clickSaveIcon();
		common.clickOkButtonIfMsgPopupAppears();
		common.verifyValidationResult("Record saved OK");
	}

	public void popupForComplexPricingProfiles(String clientName, String clientCountry) {
		// Common common=new Common(driver,test);

		validatePopupHeaderText("Pricing Profiles");
		chooseARandomDropdownOption("Client");
		chooseARandomDropdownOption("Card Product Group");
		chooseARandomDropdownOption("Pricing Profile");
		String processingDate = getCurrentIFCSDateFromDB(clientName + clientCountry);
		String effDate = enterADateValueInStatusBeginDateField("Current", processingDate);
		enterValueInTextBox("Pricing Profile", "Assigned From", effDate);

		sleep(10);
		clickOkButton();
		sleep(5);
		validateNewDateAddedInTheTableList("Pricing Profiles", "Assigned From", effDate);
	}

	public void orderCardForBlockedAccountAndValidate() {
		String driveName = fakerAPI().name().firstName();
		chooseSubMenuFromLeftPanel("Card Details", "Order New Card");
		isDisplayedThenEnterText(driverName, "Driver Name", driveName);
		clickValidateIcon();
		sleep(3);
		verifyValidationResult("Account status does not permit cards to be ordered");
	}

	// added Prakalpha
	public void addAndDeleteCostCentreFromCustomer() {

		validateHeaderLabel("Maintain Customer");
		chooseCostCentre();
		String code = fakerAPI().number().digits(4);
		addCostCentreAndValidate(code);

		validateMandatoryMessageInCostCentrePopup(code);

		rightClick(costCentreTable);
		deleteIteminPopup();

		/*
		 * rightClick(costCentreTable); deleteIteminPopup();
		 */
		clickSaveIcon();
		verifyValidationResult("Record saved OK");
	}

	public void chooseCostCentre() {
		chooseSubMenuFromLeftPanel("Maintain Customer", "Cost Centres");
		validateHeaderLabel("Cost Centres");
	}

	public void addCostCentreAndValidate(String code) {
		sleep(2);
		rightClick(costCentreTable);
		sleep(5);
		addIteminPopup();
		String costCenter = enterDetailsInCustomerCostCenterPopUp(code);
		sleep(5);
		validateNewValueAddedInTheTableList("Details", "Code", costCenter);
		sleep(2);

	}

	public void validateMandatoryMessageInCostCentrePopup(String code) {

		rightClick(costCentreTable);
		detailsIteminPopup();
		validatePopupHeaderText("Customer Cost Centre");
		clearingAllTextBoxes(textboxclear);
		clickOkButton();
		sleep(5);
		clickSaveIcon();
		sleep(5);
		verifyValidationResult("Validation failed");
		sleep(5);
		WebElement cellElement = SeleniumWrappers.getTableDataWithCellElement(0, 0, driver);
		doubleClick(cellElement);
		validatePopupHeaderText("Customer Cost Centre");
		verifyPopupValidationResult("Must not be blank");
		enterDetailsInCustomerCostCenterPopUp(code);
		sleep(5);
		clickSaveIcon();
		sleep(5);
		verifyValidationResult("Record saved OK");
		addCostCentreAndValidate(code);
		sleep(10);
		clickSaveIcon();
		sleep(5);
		verifyValidationResult("Must be unique");

	}

	/*
	 * public String enterDetailsInCustomerCostCenterPopUp() {
	 * validatePopupHeaderText("Customer Cost Centre"); String code =
	 * String.valueOf(fakerAPI().number().digits(4));
	 * enterValueInTextBox("Application Details", "Code", code);
	 * enterValueInTextBox("Application Details", "Description",
	 * fakerAPI().name().fullName()); enterValueInTextBox("Application Details",
	 * "Short Description", fakerAPI().name().lastName());
	 * isDisplayedThenClick(okButton, "Ok Button"); return code; }
	 */

	public String enterDetailsInCustomerCostCenterPopUp(String code) {
		validatePopupHeaderText("Customer Cost Centre");
		// String.valueOf(fakerAPI().number().digits(4));
		enterValueInTextBox("Application Details", "Code", code);
		enterValueInTextBox("Application Details", "Description", fakerAPI().name().fullName());
		enterValueInTextBox("Application Details", "Short Description", fakerAPI().name().lastName());
		isDisplayedThenClick(okButton, "Ok Button");
		sleep(5);
		clickSaveIcon();
		return code;
	}

	public void enterDetailsInBalanceAllowed(String clientCountry) {

		chooseSubMenuFromLeftPanel("Card Details", "Order New Card");
		enterValueInTextBox("Driver Details", "Driver Name", fakerAPI().name().fullName());
		String expiryDate = enterADateValueInStatusBeginDateField("WayFuture", clientCountry);
		enterValueInTextBox("Card Offer", "Expiry Date", expiryDate);
		// sleep(3);
	}

	public void enterDetailsInCardDetailsTab(String clientName, String clientCountry) {
		sleep(3);
		chooseSubMenuFromLeftPanel("Card Details", "Order New Card");

		if (clientName.equals("WFE")) {
			chooseARandomDropdownOption("Card Offer");
			chooseARandomDropdownOption("Card Product");
		}

		if (clientCountry.equals("RU")) {
			enterValueInTextBox("Vehicle Details", "VRN", fakerAPI().number().digits(4));
		} else {
			enterValueInTextBox("Driver Details", "Driver Name", fakerAPI().name().fullName());
		}

	}

	public void enterDetailsInCardGroup() {
		enterValueInTextBox("Card Offer", "Card Group", fakerAPI().name().firstName());
		sleep(3);
	}

	public void enterDetailsInCardDelivaryAddressTab() {
		switchTabDetails("Card Delivery Address");
		enterValueInTextBox("Temporary Address", "Contact Name", fakerAPI().name().name());
		enterValueInTextArea("Temporary Address", "Temp Address", fakerAPI().address().fullAddress());
		ScrollToElement("Temporary Address", "Country");
		selectACountryFromDropdown(0, "Country");
	}

	public void verifyExistingCustomerHasACardProgram(String customerNo) {
		searchTorch();
		chooseOptionFromDropdown("Customer No", customerNo);
		findRecordTorch();
		sleep(3);
		closeFindRecordTorch();
		sleep(3);
		String clientCountry, cardType;
		String cardTypeDesc = "";
		clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		cardType = PropUtils.getPropValue(configProp, "cardType");
		if (clientCountry.equals("MY")) {
			cardTypeDesc = "Shell Pre-Paid Card";
		} else if (cardType.contains("APA")) {
			cardTypeDesc = "Shell Pre-Paid Card (" + clientCountry + ")";
		} else {
			cardTypeDesc = "Shell Partner Card (" + clientCountry + ")";
		}
		verifyTextInDropDownForProtected("Customer Details", "Card Program", cardTypeDesc);
	}

	/*
	 * public void verifyContactsInPopup() {
	 * isDisplayed(customerMaintenance,"Customer Maintenance text"); String
	 * customerNo=getActiveCustomerNoUsingCardType();
	 * chooseCustomerNoAndSearch(customerNo);
	 * chooseSubMenuFromLeftPanel("Maintain Customer","Contacts");
	 * rightClick(contactsTable); addIteminPopup(); sleep(3);
	 * isDisplayed(customerContact,"Customer Contact text is displayed");
	 * chooseARandomDropdownOption("Contact Type");
	 * enterValueInTextBox("Details","Name",fakerAPI().name().fullName());
	 * enterValueInTextBox("Contact","Phone","7638268448");
	 * enterValueInTextArea("Addresses/Contacts","Physical Address",fakerAPI().
	 * address().fullAddress()); selectACountryFromDropdown(0); sleep(5);
	 * clickOkButton(); List<WebElement> list=driver.findElements(By.
	 * xpath("//div[@class='FALTableCellEditor_StrikeThruField JTextComponent']"));
	 * SeleniumWrappers.setCellValue(list); WebElement
	 * cellElement=SeleniumWrappers.getTableCellElement(0,0,driver);
	 * rightClick(cellElement); sleep(5);
	 * 
	 * }
	 */
	public void verifyContactsInPopup(String customerNo) {
		validateHeaderLabel("Maintain Customer");
		chooseCustomerNoAndSearch(customerNo);
		chooseSubMenuFromLeftPanel("Maintain Customer", "Contacts");
		validateHeaderLabel("Contacts");
		rightClick(contactsTable);
		addIteminPopup();
		sleep(3);
		enterDetailsInContactsPopUp();
		List<WebElement> list = driver
				.findElements(By.xpath("//div[@class='FALTableCellEditor_StrikeThruField JTextComponent']"));
		SeleniumWrappers.setCellValue(list);
		// WebElement cellElement=SeleniumWrappers.getTableCellElement(0,0,driver);
		// rightClick(cellElement);
		sleep(5);

	}

	public List<String> validateContactsTypeValueInTable() {
		List<WebElement> cellElement;
		String seperator = " ";
		List<String> listStrings = new LinkedList<String>();
		try {

			cellElement = driver.findElements(By.xpath(
					"//div[@class='JFALSeparator']//div[contains(text(),'Details')]/preceding::div[@class='JFALCompControlPanel'][1]//div[@class='JViewport']/div[@class='JTableHeader']//div[@class='HeaderRenderer']"));
			int colIndex = SeleniumWrappers.getColumnNoForColumnHeader("Contact Type", cellElement);
			List<WebElement> list = driver.findElements(By.xpath("//div[@class='JFALSeparator']//div[" + seperator
					+ "]/preceding::div[@class='JFALCompControlPanel'][1]//div[@class='FALTableCellEditor_StrikeThruField JTextComponent']"));

			int size = SeleniumWrappers.getTotalNumberOfRows(list, driver);
			System.out.println("rowsize" + size);
			for (int row = 0; row < size; row++) {
				String value = SeleniumWrappers.getTableDataWithRowAndColumnNumber(colIndex, row, driver);
				listStrings.add(value);
				System.out.println(listStrings);
			}

		} catch (Exception e) {
			logFail(e.getMessage());
		}
		return listStrings;
	}
	/*
	 * List<String>contactValues=validateContactsTypeValueInTable(); String
	 * optionValue=chooseOptionFromDropdown("Contact Type","random"); for (int i=0;i
	 * < contactValues.size();i++) {
	 * 
	 * if(contactValues.get(i).equals(optionValue)) {
	 * 
	 * chooseOptionFromDropdown("Contact Type","random"); } }
	 */

	public void validateAddAndDeleteContacts() {
		validateHeaderLabel("Maintain Customer");
		chooseSubMenuFromLeftPanel("Maintain Customer", "Contacts");
		validateHeaderLabel("Contacts");
		rightClick(contactsTable);
		addIteminPopup();
		verifyContactsPopupFieldsType();
		sleep(5);
		enterDetailsInContactsPopUp();
		sleep(5);
		// validateNewValueAddedInTheTableList("Details", "Contact Type", "Accounts
		// Payable");
		validateNewValueAddedInTheTableList("Details", "Contact Type", "Cards Address");
		validateMandatoryMessageInContactsPopup();
		sleep(10);
		WebElement cellElement = SeleniumWrappers.getTableDataWithCellElement(1, 0, driver);
		Click(cellElement, "Element");
		rightClick(contactsTable);
		deleteIteminPopup();
		sleep(5);
		WebElement cellElement1 = SeleniumWrappers.getTableDataWithCellElement(0, 0, driver);
		Click(cellElement1, "Element1");
		rightClick(contactsTable);
		deleteIteminPopup();
		sleep(5);
		clickSaveIcon();
		sleep(5);
		verifyValidationResult("Record saved OK");

	}

	public int getContactsCount() {

		List<WebElement> list;

		list = driver.findElements(By.xpath(
				"//div[@class='JFALSeparator']//div[ (text()='Details')]//preceding::div[@class='JFALCompControlPanel'][1]//div[@class='FALTableCellEditor_StrikeThruField JTextComponent']"));
		int size = SeleniumWrappers.getTotalNumberOfRows(list, driver);
		return size;
	}

	public void deleteContact() {

		// Select contact(first) and deleted it
		WebElement cellElement = SeleniumWrappers.getTableDataWithCellElement(0, 0, driver);
		Click(cellElement, "Element");
		rightClick(contactsTable);
		deleteIteminPopup();
		sleep(5);
		clickSaveIcon();
		sleep(5);
		verifyValidationResult("Record saved OK");

	}

	public void addcontact() {

		rightClick(contactsTable);
		addIteminPopup();
		verifyContactsPopupFieldsType();
		sleep(5);
		// chooseOptionFromDropdown("Contact Type","Invoice Address");

		chooseARandomDropdownOption("Contact Type");

		sleep(2);
		enterValueInTextBox("Details", "Name", fakerAPI().name().fullName());
		enterValueInTextBox("Contact", "Phone", "7638268448");
		enterValueInTextArea("Addresses/Contacts", "Physical Address", fakerAPI().address().fullAddress());
		selectACountryFromDropdown(0, "Country");
		sleep(5);
		clickOkButton();
		sleep(2);
		sleep(5);
	}

	public void validateDeleteContact() {
		validateHeaderLabel("Maintain Customer");
		chooseSubMenuFromLeftPanel("Maintain Customer", "Contacts");
		validateHeaderLabel("Contacts");
		sleep(10);
		WebElement cellElement1 = SeleniumWrappers.getTableDataWithCellElement(0, 0, driver);
		Click(cellElement1, "Element1");
		rightClick(contactsTable);
		deleteIteminPopup();
		sleep(5);
		clickSaveIcon();
		sleep(5);
		verifyValidationResult("Record saved OK");

	}

	public void ValidateAddContacts() {
		//validateHeaderLabel("Maintain Customer");
		chooseSubMenuFromLeftPanel("Maintain Customer", "Contacts");
		validateHeaderLabel("Contacts");
		rightClick(contactsTable);
		addIteminPopup();
		verifyContactsPopupFieldsType();

	}

	public void validateMandatoryMessageInContactsPopup() {

		clickSaveIcon();
		sleep(5);
		verifyValidationResult("Record saved OK");
		rightClick(contactsTable);
		addIteminPopup();
		enterDetailsInContactsPopUp();
		sleep(5);
		clickSaveIcon();
		sleep(5);
		verifyValidationResult("Validation failed");
		WebElement cellElement = SeleniumWrappers.getTableCellElement(1, 0, driver);
		doubleClick(cellElement);
		validatePopupHeaderText("Customer Contact");
		verifyPopupValidationResult("Contact Types must be unique");
		chooseOptionFromDropdown("Contact Type", "Renewal Address");
		clickOkButton();
		sleep(5);
		clickSaveIcon();
		sleep(5);
		verifyValidationResult("Record saved OK");
		sleep(5);
		validateNewValueAddedInTheTableList("Details", "Contact Type", "Renewal Address");

	}

	public void verifyContactsPopupFieldsType() {
		validatePopupHeaderText("Customer Contact");
		dropdownFieldisPresentForLabel("Details", "Contact Type");
		// verifyFieldIsMandatory("Details","Contact Type");
		textFieldisPresentForLabel("Details", "Name");
		// verifyFieldIsMandatory("Details","Name");
		textAreaFieldisPresentForLabel("Addresses/Contacts", "Physical Address");
		// verifyFieldIsMandatory("Addresses/Contacts","Physical Address");
		textFieldisPresentForLabel("Addresses/Contacts", "Suburb");
		textFieldisPresentForLabel("Addresses/Contacts", "Postal Code");
		dropdownFieldisPresentForLabel("Addresses/Contacts", "Country");
		// verifyFieldIsMandatory("Addresses/Contacts","Country");
		textAreaFieldisPresentForLabel("Addresses/Contacts", "Postal Address");
		textFieldisPresentForLabel("Contact", "Email");
		textFieldisPresentForLabel("Contact", "Phone");
		textFieldisPresentForLabel("Contact", "Fax");
		textFieldisPresentForLabel("Contact", "Mobile 1");
		textFieldisPresentForLabel("Contact", "Mobile 2");

	}

	public void enterDetailsInContactsPopUp() {
		validatePopupHeaderText("Customer Contact");
		// chooseOptionFromDropdown("Contact Type","Accounts Payable");
		// chooseOptionFromDropdown("Contact Type","Account Balance Alert");

		chooseOptionFromDropdown("Contact Type", "Cards Address");
		// chooseARandomDropdownOption("Contact Type");
		sleep(2);
		enterValueInTextBox("Details", "Name", fakerAPI().name().fullName());
		enterValueInTextBox("Contact", "Phone", "7638268448");
		enterValueInTextArea("Addresses/Contacts", "Physical Address", fakerAPI().address().fullAddress());
		selectACountryFromDropdown(0, "Country");
		sleep(5);
		clickOkButton();
		sleep(2);
	}

	public void verifyNotesPopupFieldsType() {

		dropdownFieldisPresentForLabel("Diary Notes", "Work Queue");
		checkBoxFieldisPresentForLabel("Diary Notes", "High Priority");
		textFieldisPresentForLabel("Diary Notes", "Short Note");
		textAreaFieldisPresentForLabel("Diary Notes", "Detailed Note");
		dateFieldisPresentForLabel("Diary Notes", "Bring Up Date");
		validateFieldIsProtected("Diary Notes", "Date Occurred");
	}

	public String enterDetailsInNotesPopup() {
		String detailedNotes = fakerAPI().name().toString();
		validatePopupHeaderText("Note Details");
		validateCheckBoxToCheckOrUncheck("Diary Notes", "High Priority", "Checked");
		chooseOptionFromDropdown("Work Queue", "random");
		enterValueInTextBox("Diary Notes", "Short Note", fakerAPI().name().fullName());
		enterValueInTextArea("Diary Notes", "Detailed Note", detailedNotes);
		sleep(5);
		clickOkButton();
		return detailedNotes;
	}

	public void validateAddAndDeleteNotes() {
		validateHeaderLabel("Maintain Customer");
		chooseSubMenuFromLeftPanel("Customer Transactions", "Notes");
		validateHeaderLabel("Notes");
		rightClick(notesTable);
		addIteminPopup();
		verifyNotesPopupFieldsType();
		sleep(5);
		String notes = enterDetailsInNotesPopup();
		sleep(5);
		validateNewValueAddedInTheTableList("Diary Notes", "Detailed Note", notes);
		sleep(5);
		clickSaveIcon();
		sleep(5);
		verifyValidationResult("Record saved OK");
		rightClick(notesTable);
		deleteIteminPopup();
		sleep(5);
		clickSaveIcon();
		sleep(5);
		verifyValidationResult("Record saved OK");

	}

	public void moveToCardsInCustomerMaintanence() {
		chooseSubMenuFromLeftPanel("Card Details", "Cards");
	}

	/**
	 * Move to 'Card Details-> Vehicles'
	 * 
	 */
	public void moveToVehiclesInCustomerMaintanence() {
		chooseSubMenuFromLeftPanel("Card Details", "Vehicles");
	}

	/**
	 * Move to 'Card Details-> Drivers'
	 * 
	 */
	public void moveToDriversInCustomerMaintanence() {
		chooseSubMenuFromLeftPanel("Card Details", "Drivers");
	}

	String cardNumberValue, driverNameValue, costCenterValue, VRNValue, fleetIdValue, vehicleId, vehicle_desc, driverId;

	public void searchDriverNameAndValidate() {
		clearingAllTextBoxes(textBoxes);
		enterValueInTextBox("Name", "", driverNameValue);
		searchListTorch();
		sleep(3);
		verifyValidationResult("Record Read OK - Page Size 250 Rows");
		validateSearchTable("Driver Name", driverNameValue, true);
	}

	public void searchCardNumberAndValidate() {
		clearingAllTextBoxes(textBoxes);
		enterValueInTextBox("Card Number", "", cardNumberValue);
		searchListTorch();
		sleep(3);
		verifyValidationResult("Record Read OK - Page Size 250 Rows");
		validateSearchTable("Card Number", cardNumberValue, true);
	}

	public void searchVRNAndValidate() {
		clearingAllTextBoxes(textBoxes);
		enterValueInTextBox("VRN", "", VRNValue);
		searchListTorch();
		sleep(3);
		verifyValidationResult("Record Read OK - Page Size 250 Rows");
		validateSearchTable("Vehicl...", VRNValue, true);
	}

	public void searchFleetIDAndValidate() {
		clearingAllTextBoxes(textBoxes);
		enterValueInTextBox("ID", "", fleetIdValue);
		searchListTorch();
		sleep(3);
		verifyValidationResult("Record Read OK - Page Size 250 Rows");
		validateSearchTable("License...", fleetIdValue, true);
	}

	public void searchCostCenterAndValidate() {
		clearingAllTextBoxes(textBoxes);
		enterValueInTextBox("Cost Centre", "", costCenterValue);
		searchListTorch();
		sleep(3);
		verifyValidationResult("Record Read OK - Page Size 250 Rows");
		validateSearchTable("Cost Centre", costCenterValue, true);
	}

	public void searchCustomerAndValidate(String customerNo) {
		chooseSubMenuFromLeftPanel("Customers", "");
		validateHeaderLabel("Viewer");
		clearingAllTextBoxes(textBoxes);
		ScrollToElement("Filter By", "Customer No");
		enterValueInTextBox("Filter By", "Customer No", customerNo);
		searchListTorch();
		sleep(3);
		verifyValidationResult("Record Read OK - Page Size");
		sleep(3);
		validateSearchTable("Customer No", customerNo, true);
	}

	public void getDataForSearch() {

		cardNumberValue = SeleniumWrappers.getTableDataWithRowAndColumnNumber(0, 0, driver);
		logInfo("Card Number" + cardNumberValue);
		driverNameValue = SeleniumWrappers.getTableDataWithRowAndColumnNumber(6, 0, driver);
		logInfo("Driver Name" + driverNameValue);
		costCenterValue = SeleniumWrappers.getTableDataWithRowAndColumnNumber(5, 0, driver);
		logInfo("Cost Center" + costCenterValue);
		VRNValue = SeleniumWrappers.getTableDataWithRowAndColumnNumber(7, 0, driver);
		logInfo("VRN" + VRNValue);
		fleetIdValue = SeleniumWrappers.getTableDataWithRowAndColumnNumber(8, 0, driver);
	}

	public String cardNo;

	public void orderNewCardWithOrNoBalanceAllowedAndValidate(String meassageValidate) {

		switchTabDetails("Card Details");
		sleep(3);
		ScrollToElement("Balance", "Balance Allowed");
		validateCheckBoxToCheckOrUncheck("Balance", "Balance Allowed", meassageValidate);
		switchTabDetails("Profiles");
		validateCheckBoxInTable("", "Default");
		switchTabDetails("Card Details");
		clickValidateIcon();
		verifyValidationResult("Validation successful");
		createTaskBar();
		cardNo = getValueFromProtectedTextBox("Card Offer", "Card Number");
		System.out.println(cardNo);
		verifyValidationResult("Card " + text + " ordered");

	}

	public void enterExpiryDateAndValidate(String input, String validationMessage, String validationMessage1) {
		try {
			chooseSubMenuFromLeftPanel("Card Details", "Order New Card");
			enterValueInTextBox("Card Offer", "Expiry Date", input);
			clickValidateIcon();
			sleep(3);
			verifyValidationResult(validationMessage);
			verifyValidationResult(validationMessage1);
		} catch (Exception e) {
			logFail(e.getMessage());
		}
	}

	public void getStoredReport() {
		chooseSubMenuFromLeftPanel("Customer Reporting", "Stored Reports");
	}

	public void verifyStoredReportAfterJob(String confirmReissueDate, String reportType, String fileProcessed) {

	}

	public void viewAndExportStoredReport() {
		CommonPage commonPage = new CommonPage(driver, test);

		String value, color, hexColor;
		WebElement cellElement;
		WebElement colorElement;
		try {
			chooseSubMenuFromLeftPanel("Customer Reporting", "Stored Reports");
			List<WebElement> list = driver
					.findElements(By.xpath("//div[@class='FALTableCellEditor_StrikeThruField JTextComponent']"));

			int size = SeleniumWrappers.getTotalNumberOfRows(list, driver);
			for (int i = 0; i <= size; i++) {
				cellElement = SeleniumWrappers.getTableDataWithCellElement(i, 0, driver);
				value = SeleniumWrappers.getTableDataWithRowAndColumnNumber(0, i, driver);
				System.out.println("FileNameFromTable---------->" + value);
				colorElement = driver.findElement(
						By.xpath("//div[@class='FALTableCellEditor_StrikeThruField JTextComponent']//div"));
				color = colorElement.getCssValue("background-color");
				hexColor = convertrgbColorToHex(color);
				if (hexColor.equals("#b8cfe5")) { // rgba(184, 207, 229, 1)
					Click(cellElement, "Cell Element in the table");
					sleep(5);
					Click(viewReportButton, "View Report Button");
					verifyValidationResult("Report Created Successfully");
					System.out.println("file name for view report" + value);
					commonPage.isFileDownloaded(value);
					Click(exportReportButton, "Export Report Button");
					verifyValidationResult("Data exported successfully");
					commonPage.isFileDownloaded("wexdownload");
					logPass("Report is Viewed and Exported");
					break;
				}
			}
		} catch (Exception e) {
			logFail(e.getMessage());
		}
	}

	public void checkAccountSubStatusAsPaymentPending() {
		sleep(3);
		verifyTextInDropDownForEditable("Account Status", "Sub Status", "Payment Pending");
		logInfo("Sub Status Payment Pending Dropdown Validated");
	}

	public void validateSubStatusDoesNotPermitMessage(String clientName, String clientCountry) {

		sleep(3);
		enterDetailsInCardDetailsTab(clientName, clientCountry);
		clickValidateIcon();
		verifyValidationResult("Account sub status does not permit cards to be ordered");

	}

	public void updateOrderNewCardCardFeeProfile1() {
		WebElement cellElement;
		try {
			chooseSubMenuFromLeftPanel("Card Details", "Order New Card");
			switchTabDetails("Card Fees");
			validateHeaderLabel("Order New Card");
			int rowNumber = SeleniumWrappers.getTotalNumberOfRows(
					driver.findElements(By.xpath("//div[@class='FALTableCellEditor_StrikeThruField JTextComponent']")),
					driver);
			System.out.println("Row number" + rowNumber);
			sleep(1);
			if (rowNumber == 0) {
				rightClickAndCreatePrivateProfile(cardFeesTableRightClick);
				validateCheckBoxInTableAndDoubleClick("", "Private", "Description");
				enterDetailsInCardFeesPopUp();

			} else {
				List<WebElement> tableHeaders = driver.findElements(By.xpath(
						"//div[@class='JFALSeparator']//div[contains(text(),'Profile') and contains(text(),'Selection')]/preceding::div[@class='JFALCompControlPanel']//div[@class='JViewport']/div[@class='JTableHeader']//div[@class='HeaderRenderer']"));
				int colIndex = SeleniumWrappers.getColumnNoForColumnHeader("Description", tableHeaders);
				/*
				 * List<WebElement> list = driver .findElements(By.
				 * xpath("//div[@class='FALTableCellEditor_StrikeThruField JTextComponent']"));
				 */

				cellElement = SeleniumWrappers.getTableDataWithCellElement(0, colIndex, driver);
				doubleClick(cellElement);
				validatePopupHeaderText("Card Fees");
				sleep(2);
				clickCancelButton();
				sleep(5);
				rightClickAndCreatePrivateProfile(driver.findElement(By
						.xpath("//div[@class='JFALCompControlPanel']//div[@class='JIFCSOrderCardFeeProfilesTable']")));
				validateCheckBoxInTableAndDoubleClick("Profile Selection", "Private", "Description");
				enterDetailsInCardFeesPopUp();

			}
		} catch (Exception e) {
			logFail(e.getMessage());
		}
	}

	public String enterDetailsInCardFeesPopUp() {
		validatePopupHeaderText("Card Fees");
		enterValueInTextBox("Description", "Description", text);
		chooseARandomDropdownOption("Card Fee 1");
		chooseARandomDropdownOption("Card Fee 2");
		chooseARandomDropdownOption("Card Fee 3");
		enterValueInTextBox("Details", "Months Delay", fakerAPI().number().digits(1));
		Click(okButton, "Ok Button");
		return text;
	}

	public int getRowNumberForSelectProfile(String seperatorLabelName, String tableHeaderName) {
		int row = validateCheckBoxInTable(seperatorLabelName, tableHeaderName);
		System.out.println("Select Profile row " + row);
		return row;
	}

	// Praklapha-->06/12/2019
	public void setPrivateProfileAsDefault(String seperatorName) {
		int row = getRowNumberForSelectProfile(seperatorName, "Private");
		rightClickAndSelectProfile(seperatorName, row, "Description");
	}

	public void updateOrderNewCardCardControlProfile() {
		try {
			chooseSubMenuFromLeftPanel("Card Details", "Order New Card");
			switchTabDetails("Profiles");
			validateCheckBoxInTable("Profiles", "Default");
			sleep(5);
		} catch (Exception e) {
			logFail(e.getMessage());
		}
	}

	public void enterDetailsInCardControlsPopUp(String clientCountry) {
		sleep(5);
		if (clientCountry.contains("WFE")) {
			try {
				isDisplayedThenDoubleClick(driver.findElement(By.xpath("//input[contains(@id,'_0_2Input')]")),
						"Profile");

			} catch (Exception ex) {
				logFail("Profile not found");
			}
		} else {
			rightClickAndCreatePrivateProfile(orderCardCardControlsTable);
			sleep(5);
			validateCheckBoxInTableAndDoubleClick("", "Private", "Description");
			sleep(2);
		}
		validatePopupHeaderText("Card Controls");
		enterValueInTextBox("Card Control Profile", "Description", text);
		sleep(2);
		// validateCheckBoxToCheckOrUncheck("Required at POS?","CRN","Checked");
		// validateCheckBoxToCheckOrUncheck("Required at POS?","Odometer","Checked");
		chooseARandomDropdownOption("Product Restriction");
		chooseARandomDropdownOption("Time Limit");
		// Click(okButton, "Ok Button");
		enterDetailsInCardControlPopup(clientCountry);
		sleep(2);
		clickSaveIcon();
		sleep(5);
		verifyValidationResult("Record saved OK");
	}

	public String enterDetailsInCardControlsPopUp() {
		String text = fakerAPI().name().firstName();
		rightClickAndCreatePrivateProfile(orderCardCardControlsTable);
		sleep(5);
		validateCheckBoxInTableAndDoubleClick("Profiles", "Private", "Description");
		sleep(2);
		validatePopupHeaderText("Card Controls");
		enterValueInTextBox("Card Control Profile", "Description", text);
		sleep(2);
		// validateCheckBoxToCheckOrUncheck("Required at POS?","CRN","Checked");
		// validateCheckBoxToCheckOrUncheck("Required at POS?","Odometer","Checked");
		/*
		 * chooseARandomDropdownOption("Product Restriction");
		 * chooseARandomDropdownOption("Time Limit");
		 */
		// Click(okButton, "Ok Button");
		// enterDetailsInCardControlPopup(clientCountry);
		return text;
	}

	public void chooseMaintainCardFeesFromCustomerProfile() {
		chooseSubMenuFromLeftPanel("Customer Profiles", "Maintain Card Fees");
		validateHeaderLabel("Maintain Card Fees");
	}

	public void createCardFeePrivateProfile() {

		rightClick(cardFeesTable);
		addIteminPopup();
		validatePopupHeaderText("Card Fee Profile");
		chooseARandomDropdownOption("Card Offer");
		chooseARandomDropdownOption("Card Product");
		clickOkButton();
		sleep(5);
		rightClickAndCreatePrivateProfile(availablesProfileCardFeeTable);
		//validateCheckBoxInTableAndDoubleClick("Available Profiles", "Private", "Description");
		clickSaveIcon();
		rightClickAndSelectMenuItem("Details",availablesProfileCardFeeTable, poupMenuItemDetails);
		enterDetailsInCardFeesPopUp();
		sleep(2);
		//int rownum = getRowNumberForSelectProfile("Available Profiles", "Private");
		//rightClickAndSelectProfile("Available Profiles", rownum, "Description");
		rightClickAndSelectMenuItem("Select Profile",availablesProfileCardFeeTable, selectProfile);
		sleep(5);

		//validateCheckBoxInTable("Available Profiles", "Default");
		//sleep(5);
		validateNewValueAddedInTheTableList("Card Fees", "Card Fee Profile", text);
		clickSaveIcon();

	}

	public void chooseAccountVelocityControlsFromCustomerProfile() {
		chooseSubMenuFromLeftPanel("Customer Profiles", "Maintain Account Velocity Controls");
		validateHeaderLabel("Maintain Account Velocity Controls");
	}

	public void createMaintainAccountVelocityControlsProfile(String clientCountry) {

		rightClickAndCreatePrivateProfile(accountControlsTable);
		sleep(5);
		validateCheckBoxInTableAndDoubleClick("Account Controls", "Private", "Description");
		sleep(5);
		validatePopupHeaderText("Customer Account Control");
		enterDetailsInAccountControlPopup(clientCountry);
		sleep(5);
		int rownum = getRowNumberForSelectProfile("Account Controls", "Private");
		rightClickAndSelectProfile("Account Controls", rownum, "Description");
		sleep(5);
		validateCheckBoxInTable("Account Controls", "Default");
		sleep(5);
		validateNewValueAddedInTheTableList("Account Controls", "Description", text);
	}

	public void chooseCardReissueProfileFromCustomerProfile() {
		chooseSubMenuFromLeftPanel("Card Profiles", "Card Reissue Profiles");
		validateHeaderLabel("Card Reissue Profiles");
	}

	public void createCardReissueProfile() {
		rightClickAndCreatePrivateProfile(cardReissueProfilesTable);
		sleep(5);
		validateCheckBoxInTableAndDoubleClick("Card Reissue Profiles", "Private", "Description");
		sleep(3);
		validatePopupHeaderText("Card Reissue Profiles");
		enterValueInTextBox("Description", "Description", text);
		Click(okButton, "Ok Button");
		sleep(5);
		int rownum = getRowNumberForSelectProfile("Card Reissue Profiles", "Private");
		rightClickAndSelectProfile("Card Reissue Profiles", rownum, "Description");
		sleep(5);
		validateCheckBoxInTable("Card Reissue Profiles", "Default");
		sleep(5);
		validateNewValueAddedInTheTableList("Card Reissue Profiles", "Description", text);
	}
	
	public void setCardReissueProfileAsDefalt(String profileType)
	{
		int row=getProfileAndSelectAsDefault("Card Reissue Profiles", "Description",profileType);
		getProfile("Card Reissue Profiles", row, "Description");
		sleep(5);
		rightClickAndSelectMenuItem("Select Profile", cardReissueProfilesTable, selectProfile);
		validateCheckBoxInTable("Card Reissue Profiles", "Default");
	}
	
	
	
	public void chooseMaintainCardControlsFromCustomerProfile() {
		chooseSubMenuFromLeftPanel("Customer Profiles", "Maintain Card Controls");
		validateHeaderLabel("Maintain Card Controls");
		sleep(5);
	}

	public void createMaintainCardControlsProfile(String clientCountry) {

		rightClickAndCreatePrivateProfile(availablesProfileCardControlsTable);
		sleep(5);
		validateCheckBoxInTableAndDoubleClick("Available Profiles", "Private", "Description");
		sleep(5);
		validatePopupHeaderText("Customer Card Control");
		enterValueInTextBox("Profile", "Description", text);
		enterDetailsInCardControlPopup(clientCountry);
		sleep(5);

		int rownum = getRowNumberForSelectProfile("Available Profiles", "Private");
		rightClickAndSelectProfile("Available Profiles", rownum, "Description");
		sleep(5);
		validateCheckBoxInTable("Available Profiles", "Default");
		sleep(5);
		validateNewValueAddedInTheTableList("Available Profiles", "Description", text);

	}

	// Prakalpha
	/* create New Hierarchy */
	public void createNewHierarchy(String clientName, String clientCountry) {
		sleep(5);
		chooseSubMenuFromLeftPanel("Hierarchies", "Hierarchy Structure");
		sleep(5);
		validateHeaderLabel("Hierarchy Structure");
		rightClick(hierarchiesTable);
		addIteminPopup();
		enterValueInTextBox("Hierarchy", "Name", text);
		// String cardType = PropUtils.getPropValue(configProp, "cardType");
		validateCheckBoxToCheckOrUncheck("Hierarchy Roles", "Financial Management", "Checked");
		// if (!clientCountry.equals("MY") && !(clientCountry +
		// cardType).equals("RUPC")) {
		if (!clientCountry.equals("MY") && !clientCountry.equals("RU")) {
			validateCheckBoxToCheckOrUncheck("Hierarchy Roles", "Rebates", "Checked");
		}
		if (!clientCountry.equals("MY") && !clientCountry.equals("RU")) {
			validateCheckBoxToCheckOrUncheck("Hierarchy Roles", "Reporting", "Checked");
		}
		sleep(2);
		clickOkButton();
		sleep(2);
		validateNewValueAddedInTheTableList("Hierarchies", "Name", text);
		sleep(2);
		rightClick(hierarchyDetailTable);
		addIteminPopup();
		sleep(5);
		String processingDate = getCurrentIFCSDateFromDB(clientName + clientCountry);
		String effDate = enterADateValueInStatusBeginDateField("Past", processingDate);
		String expiryDate = enterADateValueInStatusBeginDateField("WayFuture", processingDate);
		enterValueInTextBox("Customer in Hierarchy Detail", "Effective On", effDate);// "05/08/2019"
		sleep(2);
		enterValueInTextBox("Customer in Hierarchy Detail", "Expires On", expiryDate);// "05/11/2019"
		sleep(2);
		validateCheckBoxToCheckOrUncheck("Customer in Hierarchy Detail", "Billing Node", "Checked");
		clickOkButton();
		sleep(5);
		clickSaveIcon();
		sleep(5);
		verifyValidationResult("Record saved OK");
	}
	
	public void expireChildHierarchy(String clientName, String clientCountry) {
		sleep(2);
		chooseSubMenuFromLeftPanel("Hierarchies", "Hierarchy Structure");
		sleep(2);
		String processingDate = getCurrentIFCSDateFromDB(clientName + clientCountry);
		validateHeaderLabel("Hierarchy Structure");
		String  expiryDate = enterADateValueInStatusBeginDateField("Past", processingDate);
		Click(treeChildHierarchy.get(1), "Child Hierarchy");
		doubleClick(hierarchyDetailTable);
		sleep(2);
		enterValueInTextBox("Customer in Hierarchy Detail", "Expires On", expiryDate);
		clickOkButton();
		sleep(2);
		clickSaveIcon();
		sleep(2);
		verifyValidationResult("Record saved OK");
	}

	public void createRebateProfile() {
		sleep(5);
		chooseSubMenuFromLeftPanel("Customer Profiles", "Rebates");
		detailSearch();
		validateHeaderLabel("Rebates");
		int privateRow = validateCheckBoxInTable("Rebate Profiles", "Private");
		System.out.println("Private Row Number ::" + privateRow);
		if (privateRow != 0) {
			scrollDownPage();
			int rowSize = SeleniumWrappers.getTotalNumberOfRows(rebateProfilesTable, driver) - 1;
			System.out.println("Row Size:" + rowSize);
			
			String s="//div[@class='JFALSeparator']//div[contains(text(),'Rebate') and contains(text(),'Profiles')]/preceding::div[@class='JFALCompControlPanel'][2]//input[contains(@id,'_"
					+ rowSize + "_3')]";
			Click(driver.findElement(By.xpath(
					"//div[@class='JFALSeparator']//div[contains(text(),'Rebate') and contains(text(),'Profiles')]/preceding::div[@class='JFALCompControlPanel'][2]//input[contains(@id,'_"
							+ rowSize + "_3')]")),
					"Private profile");
			doubleClick(driver.findElement(By.xpath(
					"//div[@class='JFALSeparator']//div[contains(text(),'Rebate') and contains(text(),'Profiles')]/preceding::div[@class='JFALCompControlPanel'][2]//input[contains(@id,'_"
							+ rowSize + "_3')]")));
			sleep(5);
			rightClick(rebateHeaderPopupTable);
			addIteminPopup();
			sleep(10);
			enterDetailsInRebateDetailsPopup();
			sleep(5);
			clickOkButton();
		} else {
			rightClickAndCreatePrivateProfile(rebateTable);
			sleep(5);
			validateCheckBoxInTableAndDoubleClick("Rebate Profiles", "Private", "Description");
			sleep(10);
			enterDetailsInRebateProfilePopup();
		}
		sleep(5);
		rightClickAndOptInout("Rebate Profiles", "Private");
		sleep(5);
		validateCheckBoxInTable("Rebate Profiles", "Opted Out");
	}

	/**
	 * Opt in a random rebate profile
	 **/
	public String optInARebateProfile() {
		chooseSubMenuFromLeftPanel("Maintain Customer", "");
		chooseSubMenuFromLeftPanel("Customer Profiles", "Rebates");
		validateHeaderLabel("Rebates");
		detailSearch();
		int rowSize = SeleniumWrappers.getTotalNumberOfRows(rebateProfilesTable, driver) - 1;
		// int optedOutRebate = validateCheckBoxInTable("Rebate Profiles", "Opted Out");
		// Fix Needed
		int optedOutRebate = 1;
		optedOutRebate = 0;
		String optedOutRebateDes = "";
		if (rowSize > 0) {
			if (optedOutRebate == -1) {
				optedOutRebate = getRandomNumber(0, rowSize);
			}
			/*
			 * int descriptionColNo =
			 * SeleniumWrappers.getColumnNoForColumnHeader("Description",
			 * rebatesTableHeaders); optedOutRebateDes =
			 * SeleniumWrappers.getTableCellValue(optedOutRebate, descriptionColNo);
			 */

			Click(driver.findElement(By.xpath(
					"//div[@class='JFALSeparator']//div[contains(text(),'Rebate') and contains(text(),'Profiles')]/preceding::div[@class='JFALCompControlPanel'][2]//div[@class='FALTableCellEditor_StrikeThruField JTextComponent']//input[contains(@id,'_"
							+ optedOutRebate + "_3')]")),
					"Private profile");
			rightClickAndOptInout("Rebate Profiles", "Private");
			clickSaveIcon();
			sleep(5);
			clickOkButtonIfMsgPopupAppears();
			verifyValidationResult("Record saved OK");
		}
		return optedOutRebateDes;
	}

	/**
	 * Opt out a random rebate profile
	 **/
	public String optOutARebateProfile() {

		chooseSubMenuFromLeftPanel("Maintain Customer", "");
		chooseSubMenuFromLeftPanel("Customer Profiles", "Rebates");
		validateHeaderLabel("Rebates");
		detailSearch();
		int rowSize = SeleniumWrappers.getTotalNumberOfRows(rebateProfilesTable, driver) - 1;
		// int optedInRebate = validateCheckBoxInTable("Rebate Profiles", "Opted Out");
		// // Fix Needed
		int optedInRebate = 2;

		String optedInRebateDes = "";
		int randomNo;
		if (rowSize > 0) {
			if (optedInRebate > 0) {
				randomNo = getRandomNumber(0, optedInRebate);
			} else {
				randomNo = getRandomNumber(0, rowSize);
			}
			/*
			 * int descriptionColNo =
			 * SeleniumWrappers.getColumnNoForColumnHeader("Description",
			 * rebatesTableHeaders); optedInRebateDes =
			 * SeleniumWrappers.getTableCellValue(randomNo, descriptionColNo);
			 */
			Click(driver.findElement(By.xpath(
					"//div[@class='JFALSeparator']//div[contains(text(),'Rebate') and contains(text(),'Profiles')]/preceding::div[@class='JFALCompControlPanel'][2]//div[@class='FALTableCellEditor_StrikeThruField JTextComponent']//input[contains(@id,'_"
							+ randomNo + "_3')]")),
					"Private profile");
			rightClickAndOptInout("Rebate Profiles", "Private");
			clickSaveIcon();
			sleep(5);
			clickOkButtonIfMsgPopupAppears();
			verifyValidationResult("Record saved OK");
		}

		return optedInRebateDes;
	}

	public void optInOutRebateProfile() {
		chooseSubMenuFromLeftPanel("Maintain Customer", "");
		chooseSubMenuFromLeftPanel("Customer Profiles", "Rebates");
		validateHeaderLabel("Rebates");
		sleep(3);
		detailSearch();
		sleep(8);
		
		WebElement location = driver.findElement(By.xpath(
				"//div[@class='JFALSeparator']//div[contains(text(),'Rebate') and contains(text(),'Profiles')]/preceding::div[@class = 'JFALCompControlPanel'][2]//div[contains(@id,'_0_3')]//*[2]"));

		rightClickAndSelectMenuItem("Details", location, popupMenuItemSortDesc);
		rightClickAndSelectMenuItem("Opt In/Out", profilesTable, poupMenuOptInOut);

		sleep(5);
		clickSaveIcon();
		sleep(5);
		clickOkButtonIfMsgPopupAppears();
		verifyValidationResult("Record saved OK");

	}

	public void updateRebateDetails() {
		chooseOptionFromDropdown("Client", "random");
		chooseOptionFromDropdown("Rebate Category", "random");
		chooseBlankOptionFromDropdown("Product");
		sleep(3);
		chooseOptionFromDropdown("Product Group", "random");
		clickSecondPopupOkButton();
		sleep(3);

	}

	/**
	 * 
	 * Verify Audit Details in card
	 *
	 **/
	public void validateAuditDetailsForCard(String optInProfile, String optOutProfile) {
		String clientName = PropUtils.getPropValue(configProp, "clientName");
		String userID = PropUtils.getPropValue(configProp, "IFCS_" + clientName + "_USERNAME");
		chooseSubMenuFromLeftPanel("Audit Details", "");
		Date date = new Date();
		String currentDate = getDateInFormat(date, "dd/MM/yyyy");
		enterValueInTextBox("Filter By", "Date From", currentDate);
		enterValueInTextBox("Filter By", "Date To", currentDate);
		enterValueInTextBox("Filter By", "User ID", userID);
		searchListTorch();
		sleep(5);
		verifyValidationResult("Record Read OK - Page Size");
		String optOutAction = getTableValuesWithKey("Table", "Rebate Out Options-->" + optOutProfile, "Action");
		String optOutUser = getTableValuesWithKey("Table", "Rebate Out Options-->" + optOutProfile, "User ID");

		if (optOutUser.equals(userID) && optOutAction.equals("I")) {
			logPass("Opt out action added in audit details");
		} else {
			logFail("Opt out action not added in audit details, Opt Out User Expected: " + userID + " Actual:"
					+ optOutUser + ", Opt Out Action Expected: I Actual:" + optOutAction);
		}
		enterValueInTextBox("Filter By", "User ID", "ifcs");
		searchListTorch();
		sleep(5);
		verifyValidationResult("Record Read OK - Page Size");
		String optInAction = getTableValuesWithKey("Table", "Rebate Out Options-->" + optInProfile, "Action");
		String optInUser = getTableValuesWithKey("Table", "Rebate Out Options-->" + optInProfile, "User ID");

		if (optInAction.equals("D") && optInUser.equals("ifcs")) {
			logPass("Opt in action added in audit details");
		} else {
			logFail("Opt in action not added in audit details, Opt in User Expected: ifcs Actual:" + optInUser
					+ ", Opt Out Action Expected: D Actual:" + optInAction);
		}

	}

	public void enterDetailsInRebateProfilePopup() {
		sleep(5);
		validatePopupHeaderText("Rebate Profile Header Details");
		enterValueInTextBox("Details", "Description", text);
		String clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		String clientName = PropUtils.getPropValue(configProp, "clientName");
		String processingDate = getCurrentIFCSDateFromDB(clientName + clientCountry);
		String effDate = enterADateValueInStatusBeginDateField("Current", processingDate);
		String expiryDate = enterADateValueInStatusBeginDateField("WayFuture", processingDate);
		sleep(5);
		enterValueInTextBox("Details", "Effective On", effDate);
		sleep(5);
		enterValueInTextBox("Details", "Expires On", expiryDate);
		rightClick(rebateHeaderPopupTable);
		addIteminPopup();
		sleep(10);
		enterDetailsInRebateDetailsPopup();
		sleep(5);
		clickOkButton();

	}

	public void enterDetailsInRebateDetailsPopup() {
		String locationWithNonFuel = "", noFuelproduct = "";
		sleep(2);
		enterValueInRepeatedPopup("Details", "Description", text);

		String clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		String clientName = PropUtils.getPropValue(configProp, "clientName");
		System.out.println(clientCountry+"---"+clientName);
		String processingDate = getCurrentIFCSDateFromDB(clientName + clientCountry);
		String effDate = enterADateValueInStatusBeginDateField("Current", processingDate);
		String expiryDate = enterADateValueInStatusBeginDateField("Current", processingDate);
		
		if(clientName.equalsIgnoreCase("WFE")) {
			if(clientCountry.equalsIgnoreCase("BE") || clientCountry.equalsIgnoreCase("FR") || clientCountry.equalsIgnoreCase("LU")) {
				ScrollToElement("Details","Client");
			chooseOptionFromDropdown("Client", PropUtils.getPropValue(configProp,clientName + "_NL"));
			}else {
				ScrollToElement("Details","Client");
				chooseOptionFromDropdown("Client", PropUtils.getPropValue(configProp,clientName + "_BE"));
			}
		}

		if (clientName.contains("EMAP")) {
			chooseOptionFromDropdown("Rebate Category", "CPL All Sites - Net Off");
			sleep(5);
		} else if(clientName.contains("WFE")){
			ScrollToElement("Details","Rebate Category");
			chooseOptionFromDropdown("Rebate Category", "Network CPL Disc");
			sleep(5);
		}else {
			chooseOptionFromDropdown("Rebate Category", "random");
			sleep(5);
		}
		
		enterValueInTextBox("Details", "3rd Party No", fakerAPI().number().digits(4));
		sleep(5);
		enterValueInRepeatedPopup("Details", "Effective On", effDate);
		sleep(5);
		enterValueInRepeatedPopup("Details", "Expires On", expiryDate);
		if (clientName.contains("BP")) {
			locationWithNonFuel = chooseALocationWithNonFuelProduct("N");
			noFuelproduct = chooseANonFuelProductExtCodeInTheLocation(locationWithNonFuel, "N", "description");

			// Choosing Non Fuel Product
			chooseOptionFromDropdown("Product", noFuelproduct);

		} else {
			chooseARandomDropdownOption("Product");
			chooseARandomDropdownOption("Product Group");
		}
		if(!clientName.equalsIgnoreCase("WFE")) {
		rightClick(rebateContributionsPopupTable);
		addIteminPopup();
		sleep(5);
		dropdownInPopupTable(Locator_IFCS.REBATE_CONTRIBUTIONS_POPUP_TABLE, "Member Type", "Location");

		if (clientName.contains("BP")) {
			enterRateInRebateValueTablePopup(Locator_IFCS.REBATE_CONTRIBUTIONS_POPUP_TABLE, "Member No",
					locationWithNonFuel);
		} else if (clientName.contains("EMAP")) {
			enterRateInRebateValueTablePopup(Locator_IFCS.REBATE_CONTRIBUTIONS_POPUP_TABLE, "Member No", "875968");
		}
		}
		sleep(5);
		rightClick(rebateValuesPopupTable);
		addIteminPopup();
		sleep(5);
		if (clientName.contains("BP")) {
			enterRateInRebateValueTablePopup(Locator_IFCS.REBATE_VALUES_POPUP_TABLE, "Value Range From", "0");
			enterRateInRebateValueTablePopup(Locator_IFCS.REBATE_VALUES_POPUP_TABLE, "Value Range To", "100");
		} else if (clientName.contains("EMAP")) {
			enterRateInRebateValueTablePopup(Locator_IFCS.REBATE_VALUES_POPUP_TABLE, "Value Range From", "3");
			enterRateInRebateValueTablePopup(Locator_IFCS.REBATE_VALUES_POPUP_TABLE, "Rate", "1");
		} else if(clientName.contains("WFE")){
			WebElement ele=driver.findElement(By.xpath("//div[@class='JFALSeparator_1']//div[@class='htmlString'][contains(text(),'Rebate') and contains(text(),'Values')]//preceding::div[@class='FALTableCellEditor_StrikeThruField JTextComponent']//input[contains(@id,'_0_0')]"));
			isDisplayed(ele,"range element");
			doubleClick(ele);
			sleep(3);
			ele.sendKeys("0");
			sleep(5);
			WebElement ele1=driver.findElement(By.xpath("//div[@class='JFALSeparator_1']//div[@class='htmlString'][contains(text(),'Rebate') and contains(text(),'Values')]//preceding::div[@class='FALTableCellEditor_StrikeThruField JTextComponent']//input[contains(@id,'_0_2')]"));
			isDisplayed(ele1,"rate element");
			doubleClick(ele1);
			sleep(3);
			ele1.sendKeys("5");
			sleep(5);
			
		}else {
			enterRateInRebateValueTablePopup(Locator_IFCS.REBATE_VALUES_POPUP_TABLE, "Value Range From", "0");
			enterRateInRebateValueTablePopup(Locator_IFCS.REBATE_VALUES_POPUP_TABLE, "Rate", "10");
		}

		sleep(5);

		clickSecondPopupOkButton();

	}

	public void enterRateInRebateValueTablePopup(String locator, String headerName, String value) {
		try {
			WebElement WebLocator = driver.findElement(By.xpath(locator));
			int colHeaderIndex = SeleniumWrappers.getColumnNoForColumnHeader(headerName,
					WebLocator.findElements(By.xpath(".//div[@class='HeaderRenderer']")));
			System.out.println("Column header" + colHeaderIndex);
			List<WebElement> tableList = WebLocator
					.findElements(By.xpath(".//div[@class='FALTableCellEditor_StrikeThruField JTextComponent']"));
			tableList = WebLocator
					.findElements(By.xpath(".//div[@class='FALTableCellEditor_StrikeThruField JTextComponent']"));
			System.out.println("table list" + tableList);
			SeleniumWrappers.setCellValueforPopup(tableList, locator, driver);
			WebElement cellElement = SeleniumWrappers.getTableDataWithCellElement(0, colHeaderIndex, driver);
			System.out.println("cell element" + cellElement);
			cellElement.sendKeys(value);
			sleep(2);
			logPass("Value entered in the cell");
		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
	}

	// Prakalpha
	/* Enter Details In CardControl Popup */
	public void enterDetailsInCardControlPopup(String clientCountry) {

		// validateCheckBoxToCheckOrUncheck("Required at POS?","CRN","Checked");
		// validateCheckBoxToCheckOrUncheck("Required at POS?","Odometer","Checked");
		/*
		 * chooseARandomDropdownOption("Product Restriction");
		 * chooseARandomDropdownOption("Time Limit");
		 */
		if (clientCountry.contains("WFE")) {
			ScrollToElement("Purchase Velocity Controls", "Daily Tran Limit");
			chooseOptionFromDropdown("Daily Tran Limit", "1");
		} else if (clientCountry.contains("MY")) {
			chooseARandomDropdownOption("Transaction Purchase Limit");
			chooseARandomDropdownOption("Transaction Monthly Limit");
			chooseARandomDropdownOption("Daily Transaction Limit");
			chooseARandomDropdownOption("Weekly Transaction Limit");
			chooseARandomDropdownOption("Monthly Value Limit");

		} else {
			chooseARandomDropdownOption("Daily Usage Limit");
			chooseARandomDropdownOption("Daily Value Limit");
			chooseARandomDropdownOption("Weekly Usage Limit");
			chooseARandomDropdownOption("Weekly Value Limit");
			chooseARandomDropdownOption("Monthly Usage Limit");
			ScrollToElement(okButton, "Ok Button");
			chooseARandomDropdownOption("Monthly Value Limit");
			chooseARandomDropdownOption("Transaction Value Limit");

		}
		clickOkButton();
	}

	// Prakalpha
	/* Enter Details In Account Control Popup */
	public void enterDetailsInAccountControlPopup(String clientCountry) {

		enterValueInTextBox("Account Controls", "Description", text);
		if (clientCountry.contains("MY")) {
			chooseARandomDropdownOption("Account Transaction Purchase Limit");
			chooseARandomDropdownOption("Account Transaction Monthly Limit");
			chooseARandomDropdownOption("Account Daily Transaction Limit");
			chooseARandomDropdownOption("Account Weekly Transaction Limit");
			chooseARandomDropdownOption("Account Monthly Value Limit");
			chooseARandomDropdownOption("Daily Transaction Count Limit");

		} else if (clientCountry.contains("CZ") || clientCountry.contains("RU") || clientCountry.contains("PH")) {
			chooseARandomDropdownOption("A Daily Usage Limit");
			chooseARandomDropdownOption("A Daily Value Limit");
			chooseARandomDropdownOption("A Weekly Usage Limit");
			chooseARandomDropdownOption("A Weekly Value Limit");
			chooseARandomDropdownOption("A Monthly Usage Limit");
			chooseARandomDropdownOption("A Monthly Value Limit");
			chooseARandomDropdownOption("A Transaction Value Limit");
			// if (clientCountry.contains("RU")) {
			// chooseARandomDropdownOption("Daily Service Limit");
			// }
		} else {
			chooseARandomDropdownOption("Daily Usage Limit");
			chooseARandomDropdownOption("Daily Value Limit");
			chooseARandomDropdownOption("Weekly Usage Limit");
			chooseARandomDropdownOption("Weekly Value Limit");
			chooseARandomDropdownOption("Monthly Usage Limit");
			chooseARandomDropdownOption("Monthly Value Limit");
			chooseARandomDropdownOption("Transaction Value Limit");
		}
		clickOkButton();
	}

	public void enterValueInRepeatedPopup(String seperatorLabelName, String labelName, String input) {
		String seperator = " ";
		String label = " ";
		List<WebElement> textBoxs;
		List<WebElement> popUps = driver.findElements(By.xpath("//div[contains(@id,'IFCSPopupDialog_')]"));
		try {
			seperator = splitStringAndGenerateXpath(seperatorLabelName);
			label = splitStringAndGenerateXpath(labelName);
			textBoxs = driver.findElements(By.xpath(
					"//div[@class='JFALSeparator']//div[" + seperator + "]/preceding::div[@class='JFALLabel']/div["
							+ label + "]/preceding::div[@class='JFALCompControlPanel'][1]//input"));
			textBoxs.get(popUps.size() - 1).clear();
			textBoxs.get(popUps.size() - 1).sendKeys(input);
			logPass("date is entered in text field");

		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
	}

	public void searchFieldValueAndValidate(String partialOrFull, String searchFieldName, String validationFieldName,
			String fieldValue) {
		clearingAllTextBoxes(textBoxes);
		boolean partialOrFullValidation = true;
		if (partialOrFull.equalsIgnoreCase("Partial")) {
			fieldValue = getPartialValue(fieldValue);
			partialOrFullValidation = false;
		}
		enterValueInTextBox("Filter By", searchFieldName, fieldValue);
		searchListTorch();
		sleep(5);
		verifyValidationResult("Record Read OK - Page Size");
		validateSearchTable(validationFieldName, fieldValue, partialOrFullValidation);
	}

	// Added by nithya
	public void customerMaintenanceSearchAndValidation(String labelName, String partialOrFull,
			String cardsOrDriverOrVehicleSearchs) {
		if (labelName.equalsIgnoreCase("Driver Name") || labelName.equalsIgnoreCase("Name")) {
			if (!driverNameValue.equals("")) {
				searchFieldValueAndValidate(partialOrFull, labelName, "Driver Name", driverNameValue);
			}
		} else if (labelName.equalsIgnoreCase("Card Number")) {
			searchFieldValueAndValidate(partialOrFull, "Card Number", labelName, cardNumberValue);
		} else if (labelName.equalsIgnoreCase("Cost Centre")) {
			if (!costCenterValue.equals(""))
				searchFieldValueAndValidate(partialOrFull, "Cost Centre", labelName, costCenterValue);
		} else if (labelName.equalsIgnoreCase("VRN")) {
			if (cardsOrDriverOrVehicleSearchs.equalsIgnoreCase("cards")) {
				if (!VRNValue.equals(""))
					searchFieldValueAndValidate(partialOrFull, labelName, "License...", VRNValue);
			} else {
				if (!VRNValue.equals(""))
					searchFieldValueAndValidate(partialOrFull, labelName, "License Plate", VRNValue);
			}

		} else if (labelName.equalsIgnoreCase("Description")) {
			if (vehicle_desc != null) {
				searchFieldValueAndValidate(partialOrFull, "Description", labelName, vehicle_desc);
			}
		} else if (labelName.equalsIgnoreCase("Vehicle ID")) {
			if (vehicleId != null && !vehicleId.equals("")) {
				searchFieldValueAndValidate(partialOrFull, "Vehicle ID", labelName, vehicleId);
			}
		} else if (labelName.equalsIgnoreCase("Driver Id")) {
			if (!driverId.equals(""))
				searchFieldValueAndValidate(partialOrFull, "Driver Id", labelName, driverId);
		} else if (labelName.equalsIgnoreCase("ID")) {
			searchFieldValueAndValidate(partialOrFull, labelName, "License...", fleetIdValue);
		} else {
			logFail("Given field name is invalid");
		}

	}

	public void clickDetailSearchIfFilterFieldsNotPresent() {
		boolean isFilterFieldsPresent = false;
		try {
			driver.findElement(
					By.xpath("//div[@class='SimpleInternalFrame_GradientPanel'][descendant::div[text()='Viewer']]"));
			isFilterFieldsPresent = true;
		} catch (NoSuchElementException ex) {
			logInfo("No Viewer present");
		}
		if (!isFilterFieldsPresent) {
			detailSearch();
		}
	}

	public void selectACardAndVeifyContext(String searchCategory) {

		WebElement firstRow = SeleniumWrappers.getTableDataWithCellElement(0, 0, driver);
		isDisplayedThenDoubleClick(firstRow, "Selected a row from search result");
		verifyText(popupHeader, searchCategory);
		clickOkButton();
	}

	String text = fakerAPI().name().firstName();
	// Added by nithya

	public void createNewCustomerProfileInApplicationAndMakeitDefault(String applicationOrCustomer,
			String clientCountry) {
		int defaultRow;
		if (applicationOrCustomer.equalsIgnoreCase("application")) {

			chooseSubMenuFromLeftPanel("Maintain Application", "Customer Profiles");
			chooseSubMenuFromLeftPanel("Customer Profiles", "Account Velocity Controls");
		} else {

			chooseSubMenuFromLeftPanel("Customer Profiles", "Maintain Account Velocity Controls");
			changeDefaultProfileAndDeletePrivateProfile();
		}

		/*
		 * int privateRow = validateCheckBoxInTable("Account Controls", "Private");
		 * System.out.println("Private Row: " + privateRow); if (privateRow >= 0) {
		 * changeDefaultProfileAndDeletePrivateProfile(); }
		 */
		rightClickAndCreatePrivateProfile(driver.findElement(By.xpath(
				"//div[@class='JFALCompControlPanel']//div[@class='JIFCSCustomerAccountControlsTable' or @class='JIFCSApplicationCardControlsTable']")));

		validateCheckBoxInTableAndDoubleClick("Account Controls", "Private", "Description");

		enterDetailsInAccountControlPopup(clientCountry);

		rightClickAndSelectProfile("Account Controls", SeleniumWrappers.getNumberOfRows(driver) - 1, "Description");

		if (!applicationOrCustomer.equalsIgnoreCase("application")) {
			if (!clientCountry.equals("MY")) {
				clickSaveIcon();

				verifyValidationResult("Record saved OK");

			}
			defaultRow = validateCheckBoxInTable("Account Controls", "Default");
			System.out.println("Default Row: " + getAttribute(
					SeleniumWrappers.getTableDataWithCellElement(defaultRow, 2, driver), "submittedvalue"));
			if (getAttribute(SeleniumWrappers.getTableDataWithCellElement(defaultRow, 2, driver), "submittedvalue")
					.equals(text)) {
				logPass("Private profile set as default");
			} else {
				logFail("Private profile not set as default");
			}
		} else {

			defaultRow = validateCheckBoxInTable("Account Controls", "Default");
			if (defaultRow == SeleniumWrappers.getNumberOfRows(driver) - 1) {
				logPass("Private profile set as default");
			} else {
				logFail("Private profile not set as default");
			}
		}
	}

	/**
	 * Perform Search in Customer Maintenance - With Status
	 * 
	 * @param Partial or Full Search
	 */
	public void searchStatusAndValidate() {
		clearingAllTextBoxes(textBoxes);
		boolean partialOrFullValidation = true;
		String randomOptionChoosen = chooseARandomDropdownOption("Status");
		searchListTorch();
		sleep(3);
		verifyValidationResult("Record Read OK - Page Size ");
		validateSearchTable("Status", randomOptionChoosen, partialOrFullValidation);
		// For setting back to empty value
		chooseBlankOptionFromDropdown("Status");
	}

	/**
	 * Perform Search in Customer Maintenance - With Cost Center and Partial Driver
	 * Name
	 * 
	 *
	 */
	public void searchCostCenterAndPartialDriverName() {
		clearingAllTextBoxes(textBoxes);
		enterValueInTextBox("Filter By", "Cost Centre", costCenterValue);
		enterValueInTextBox("Filter By", "Name", getPartialValue(driverNameValue));
		searchListTorch();
		sleep(3);
		verifyValidationResult("Record Read OK - Page Size ");
		validateSearchTable("Cost Centre", costCenterValue, true);
		validateSearchTable("Driver Name", driverNameValue, false);

	}

	// Added by nithya
	public void createNewApplicationAndSave() {
		sleep(3);
		enterValueInTextBox("Details", "Legal Name", fakerAPI().name().firstName());
		enterValueInTextBox("Details", "Trading Name", fakerAPI().name().lastName());
		enterValueInTextArea("Addresses/Contacts", "Physical Address", fakerAPI().address().fullAddress());
		enterValueInTextArea("Addresses/Contacts", "Postal Address", fakerAPI().address().fullAddress());
		enterValueInTextBox("Details", "Embossing Name", fakerAPI().name().fullName());
		selectACountryFromDropdown(0, "Country");
		clickSaveIcon();
		sleep(3);
		verifyValidationResult("Record saved OK");
	}

	// Added by nithya
	public void selectExisitingApplication() {
		sleep(3);
		chooseSubMenuFromLeftPanel("Maintain Application", "Applications");
		sleep(3);
		searchListTorch();
		sleep(3);
		/*
		 * List<WebElement> list = driver .findElements(By.
		 * xpath("//div[@class='FALTableCellEditor_StrikeThruField JTextComponent']"));
		 */

		isDisplayedThenDoubleClick(SeleniumWrappers.getTableDataWithCellElement(0, 0, driver), "Select Application");
		/*
		 * enterValueInTextBox("Details", "Legal Name", fakerAPI().name().firstName());
		 * enterValueInTextBox("Details", "Trading Name", fakerAPI().name().lastName());
		 * enterValueInTextArea("Addresses/Contacts", "Physical Address",
		 * fakerAPI().address().fullAddress()); enterValueInTextBox("Details",
		 * "Embossing Name", fakerAPI().name().fullName());
		 * selectACountryFromDropdown(); clickSaveIcon();
		 */
		sleep(5);
		// verifyValidationResult("Record saved OK");
	}

	public void selectApplicationWithStatus(String applicationStatus) {
		sleep(3);
		chooseSubMenuFromLeftPanel("Maintain Application", "Applications");
		sleep(3);
		chooseOptionFromDropdown("Status", applicationStatus);
		searchListTorch();
		sleep(3);
		List<WebElement> list = driver
				.findElements(By.xpath("//div[@class='FALTableCellEditor_StrikeThruField JTextComponent']"));
		doubleClick(list.get(0).findElement(By.xpath(".//*[@class='htmlString']")));
		/*
		 * 
		 * isDisplayedThenDoubleClick(SeleniumWrappers.getTableDataWithCellElement(0, 0,
		 * driver), "Select Application");
		 */
		sleep(5);
	}

	String appName, appPhyAddress, creditLimit, applicationTypeChosen;

	public void createNewApplication(String applicationType) {
		// Application Information Details
		applicationTypeChosen = applicationType;
		chooseOptionFromDropdown("Application Type", applicationType);
		appName = fakerAPI().name().firstName();
		appPhyAddress = fakerAPI().address().fullAddress();
		creditLimit = fakerAPI().number().digits(2);
		enterValueInTextBox("Details", "Name", appName);
		enterValueInTextArea("Details", "Physical Address", appPhyAddress);
		selectACountryFromDropdown(0, "Country");
		sleep(2);
		// Application Account Tab Details
		switchTabDetails("Application-Account");
		chooseARandomDropdownOption("Customer Type");
		chooseARandomDropdownOption("Credit Plans");
		chooseARandomDropdownOption("Billing Plans");
		chooseARandomDropdownOption("Billing Frequency");
		chooseARandomDropdownOption("Account Cycle");
		enterValueInTextBox("Account Details", "Credit Limit", creditLimit);
		sleep(2);
		// Application Business Details
		switchTabDetails("Business Details");
		chooseARandomDropdownOption("Business Type");
		chooseARandomDropdownOption("Industry Type");
		chooseARandomDropdownOption("Class of Buyer");
		chooseARandomDropdownOption("Financial Year End");
		chooseARandomDropdownOption("Admin Territory");
		chooseARandomDropdownOption("Marketing Territory");
		sleep(2);
	}

	public void validateClonedApplication() {
		// if(getValueFromTextBox("Details", "Name").equals(appName)) {
		// logFail("Name got cloned");
		// }else {
		// logPass("Name not cloned");
		// }
		switchTabDetails("Application Information");
		if (getValueFromTextArea("Details", "Physical Address").equals(appPhyAddress)) {
			logPass("Physical Address is cloned");
		} else {
			logFail("Physical Address is not cloned");
		}
	}

	// Added by nithya
	public void validateAndApproveApplication() {
		clickSaveIcon();
		clickValidateIcon();
		clickApproveIcon();
	}

	// Added by nithya
	public void changeDefaultProfileAndDeletePrivateProfile() {

		int noOfRows = SeleniumWrappers.getTotalNumberOfRows(cardsTable, driver);
		int privateProfileRow = validateCheckBoxInTable("Account Controls", "Private");
		int defaultProfileRow = validateCheckBoxInTable("Account Controls", "Default");

		if (privateProfileRow == defaultProfileRow && noOfRows > 1) {
			isDisplayedThenClick(SeleniumWrappers.getTableDataWithCellElement(privateProfileRow - 1, 2, driver),
					"Default");
			rightClick(SeleniumWrappers.getTableDataWithCellElement(privateProfileRow - 1, 2, driver));
			isDisplayedThenClick(selectProfile, "Select Private Profile");
			clickSaveIcon();
			sleep(3);
			isDisplayedThenClick(SeleniumWrappers.getTableDataWithCellElement(privateProfileRow, 2, driver), "Private");
			rightClick(SeleniumWrappers.getTableDataWithCellElement(privateProfileRow, 2, driver));
			isDisplayedThenClick(deletePrivateProfile, "Delete Private Profile");
			clickSaveIcon();
		} else if (privateProfileRow == defaultProfileRow && noOfRows == 1) {
			logFail("Having only one profile in Account Controls");
		} else if (privateProfileRow != defaultProfileRow && noOfRows > 1 && privateProfileRow >= 0) {
			isDisplayedThenClick(SeleniumWrappers.getTableDataWithCellElement(privateProfileRow, 2, driver), "Private");
			rightClick(SeleniumWrappers.getTableDataWithCellElement(privateProfileRow, 2, driver));
			isDisplayedThenClick(deletePrivateProfile, "Delete Private Profile");
			clickSaveIcon();
			sleep(3);
		}
		System.out.println("No Of Rows:" + noOfRows);
	}

	/**
	 * Perform Search in Customer Maintenance - With Status And VRN Name
	 * 
	 *
	 */
	public void searchPartialVRNAndStatus() {
		clearingAllTextBoxes(textBoxes);
		enterValueInTextBox("Filter By", "VRN", getPartialValue(VRNValue));
		searchStatusAndValidate();
		validateSearchTable("License Plate", VRNValue, false);
	}

	/**
	 * Perform Search in Customer Maintenance - With Status And VRN Name
	 * 
	 *
	 */
	public void searchPartialDriverNameAndStatus() {
		clearingAllTextBoxes(textBoxes);
		enterValueInTextBox("Filter By", "Driver Name", getPartialValue(driverNameValue));
		searchStatusAndValidate();
		validateSearchTable("Driver Name", driverNameValue, false);
	}

	/**
	 * Perform Search in Customer Maintenance - In correct value
	 * 
	 * 
	 * @param
	 */
	public void searchWithInCorrectValue(String fieldName) {
		clearingAllTextBoxes(textBoxes);
		enterValueInTextBox("Filter By", fieldName, fakerAPI().book().publisher());
		searchListTorch();
		sleep(3);
		verifyValidationResult("Details not found");
	}

	/**
	 * Get Data from DB for Search
	 * 
	 * @param Customer Number With Cards
	 */
	public void getDataForSearch(String customerWithCards) {
		cardNumberValue = getCardNumberWithCustomerNo(customerWithCards);
		driverNameValue = getDriverNameOfCardWithCustomerNo(customerWithCards);
		costCenterValue = getCostCenterOfCardWithCustomerNo(customerWithCards);
		VRNValue = getVRNOfCardWithCustomerNo(customerWithCards);
		vehicleId = getVehicleIDOfCardWithCustomerNo(customerWithCards);
		vehicle_desc = getVehicleDescOfCardWithCustomerNo(customerWithCards);
		driverId = getDriverIDOfCardWithCustomerNo(customerWithCards);
		logInfo("Card Number" + cardNumberValue);
		logInfo("Driver Name" + driverNameValue);
		logInfo("Cost Center" + costCenterValue);
		logInfo("VRN" + VRNValue);
		logInfo("Vehicle ID" + vehicleId);
		logInfo("Vehicle Desc" + vehicle_desc);
		logInfo("Driver ID" + driverId);
	}

	public String mainAccount, subAccount;

	/**
	 * Gets Customer Having Cards
	 * 
	 * @param Client Country, Card Type
	 */

	// Added by nithya
	public String createHierarchyWithChild() {
		CardMaintenancePage cardMaintenancePage = new CardMaintenancePage(driver, test);
		mainAccount = getCustomerNumberWithNoHierarchy();
		PropUtils.setProps(configProp, "MAIN_ACCOUNT_NO", mainAccount);
		subAccount = getCustomerNumberWithNoHierarchyFromDB(2);
		if (subAccount.length() > 0 && mainAccount.length() > 0) {
			String clientName = PropUtils.getPropValue(configProp, "clientName");
			String clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
			if (clientName.equals("EMAP")) {
				cardMaintenancePage.chooseAndSearchCustomerNo(mainAccount);
				validateSearchTable("Customer No", mainAccount, true);
				// Adding Report for StandAloneCustomer
			} else if (clientName.equals("SHELL")) {
				chooseCustomerNoAndSearch(mainAccount);
			}

			// WFE
			else if (clientName.equals("WFE")) {
				chooseCustomerNoAndSearch(mainAccount);
			}

			createNewHierarchy(clientName, clientCountry);
			rightClick(treeParentHierarchy);
			clickAddCustomerOptionInPopup();
			enterValueInTextBox("Details", "Customer No", subAccount);
			clickOkButton();
			sleep(2);
			rightClick(hierarchyDetailTable);
			addIteminPopup();
			sleep(5);
			String ifcsDate = getCurrentIFCSDateFromDB(clientName + clientCountry);
			String effDate = enterADateValueInStatusBeginDateField("Past", ifcsDate);
			String expiryDate = enterADateValueInStatusBeginDateField("WayFuture", ifcsDate);
			enterValueInTextBox("Customer in Hierarchy Detail", "Effective On", effDate);// "05/08/2019"
			sleep(2);
			enterValueInTextBox("Customer in Hierarchy Detail", "Expires On", expiryDate);// "05/11/2019"
			sleep(2);
			clickOkButton();
			sleep(5);
			clickSaveIcon();
			sleep(5);
			verifyValidationResult("Record saved OK");

			sleep(5);
		} else {
			mainAccount = "No Data";
		}
		return mainAccount;
	}

	public String createHierarchyWithChildHavingCards(String cardStatus) {
		mainAccount = getCustomerNumberWithNoHierarchy();
		subAccount = getCustomerNumberWithCardsAndNoHierarchyFromDB(cardStatus);
		if (subAccount.length() > 0) {
			chooseCustomerNoAndSearch(mainAccount);
			String clientName = PropUtils.getPropValue(configProp, "clientName");
			String clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
			createNewHierarchy(clientName, clientCountry);
			rightClick(treeParentHierarchy);
			clickAddCustomerOptionInPopup();
			enterValueInTextBox("Details", "Customer No", subAccount);
			clickOkButton();
			sleep(2);
			rightClick(hierarchyDetailTable);
			addIteminPopup();
			sleep(5);
			String ifcsDate = getCurrentIFCSDateFromDB(clientName + clientCountry);
			String effDate = enterADateValueInStatusBeginDateField("Current", ifcsDate);
			String expiryDate = enterADateValueInStatusBeginDateField("WayFuture", ifcsDate);
			enterValueInTextBox("Customer in Hierarchy Detail", "Effective On", effDate);// "05/08/2019"
			sleep(2);
			enterValueInTextBox("Customer in Hierarchy Detail", "Expires On", expiryDate);// "05/11/2019"
			sleep(2);
			clickOkButton();
			sleep(5);
			clickSaveIcon();
			sleep(5);
			verifyValidationResult("Record saved OK");
			sleep(5);
		} else {
			System.out.println("Verifying already existing Customer in Hierarchy");
			mainAccount = getParentAndChildCustomersHavingCardsWithExpectedStatus(cardStatus);
			subAccount = mainAccount.split(":")[1];
			mainAccount = mainAccount.split(":")[0];
			System.out.println("Sub Account:" + subAccount);
			System.out.println("Main Account:" + mainAccount);
		}
		return mainAccount;
	}

	// Added by Nithya 16.04.2019
	public void deleteAHierarchyAndCheckErrorMessage() {
		rightClick(treeChildHierarchy.get(1));
		deleteIteminPopup();
		clickYesButton();
		sleep(3);
		clickSaveIcon();
		verifyValidationResult("Validation failed");
		sleep(5);
		Click(treeChildHierarchy.get(1), "Child Hierarchy");
		verifyValidationResult("Cannot delete current or past relationship assignments");
	}

	/**
	 * Gets Customer Having Cards
	 * 
	 * @param Client Country, Card Type
	 */

	// Added by nithya
	public String expireHierarchyWithChild() {
		CardMaintenancePage cardMaintenancePage = new CardMaintenancePage(driver, test);
		mainAccount = getCustomerNumberWithHierarchy();
		PropUtils.setProps(configProp, "MAIN_ACCOUNT_NO", mainAccount);
		if (mainAccount.length() > 0) {
			String clientName = PropUtils.getPropValue(configProp, "clientName");
			String clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
			if (clientName.equals("EMAP")) {
				cardMaintenancePage.chooseAndSearchCustomerNo(mainAccount);
				validateSearchTable("Customer No", mainAccount, true);
				// Adding Report for StandAloneCustomer
			} else if (clientName.equals("SHELL")) {
				chooseCustomerNoAndSearch(mainAccount);
			}

			// WFE
			else if (clientName.equals("WFE")) {
				chooseCustomerNoAndSearch(mainAccount);
			}

			expireChildHierarchy(clientName, clientCountry);
		} else {
			mainAccount = "No Data";
		}
		return mainAccount;
	}

	public void changeMainAccountStatus(String accountStatus) {
		chooseCustomerNoAndSearch(mainAccount);
		sleep(3);
		isDisplayedThenClick(accountsMenu, "Accounts Menu");
		isDisplayedThenClick(accountDetailsSubMenu, "Account Details SubMenu");
		sleep(3);
		chooseOptionFromDropdown("Status", accountStatus);
		clickSaveIcon();
	}

	public void setSubAccountStatusActive() {
		chooseCustomerNoAndSearch(subAccount);
		sleep(3);
		isDisplayedThenClick(accountsMenu, "Accounts Menu");
		isDisplayedThenClick(accountDetailsSubMenu, "Account Details SubMenu");
		sleep(3);
		chooseOptionFromDropdown("Status", "A - Active");
		clickSaveIcon();
	}

	public void changeCardStatusForBlockedAccountAndValidate(String replaceOrNoReplace) {
		chooseSubMenuFromLeftPanel("Card Details", "Cards");
		clickDetailSearchIfFilterFieldsNotPresent();
		chooseOptionFromDropdown("Card Status", "Active");
		searchListTorch();
		isDisplayedThenDoubleClick(searchResultsTable.get(0).findElement(By.xpath(".//div[@class]")),
				"Selected a row from search result");
		/*
		 * WebElement firstRow = SeleniumWrappers.getTableDataWithCellElement(0, 0,
		 * driver); isDisplayedThenDoubleClick(firstRow,
		 * "Selected a row from search result");
		 */
		sleep(3);
		chooseSubMenuFromLeftPanel("Card Maintenance", "Card Status");
		sleep(2);
		chooseOptionFromDropdown("New status", "Stolen");
		clickSaveIcon();
		sleep(2);
		if (replaceOrNoReplace.equalsIgnoreCase("replace")) {
			clickYesButton();
			sleep(2);
			verifyValidationResult("Account status does not permit cards to be ordered");
		} else {
			clickNoButton();
			sleep(2);
			verifyValidationResult("Card status changed OK");
		}
	}

	public void reissueACardForBlockedAccount() {
		String cardNo = getNotReplacedCardNumberWithCustomerNumber("Stolen", subAccount);
		chooseSubMenuFromLeftPanel("Card Details", "Cards");
		clickDetailSearchIfFilterFieldsNotPresent();
		enterValueInTextBox("Filter By", "Card Number", cardNo);
		searchListTorch();
		// WebElement firstRow = SeleniumWrappers.getTableDataWithCellElement(0, 0,
		// driver);
		isDisplayedThenDoubleClick(searchResultsTable.get(0).findElement(By.xpath(".//div[@class]")),
				"Selected a row from search result");
		sleep(2);
		clickCardRequest();
		clickYesButton();
		verifyValidationResult("Account status does not permit cards to be ordered");
	}

	public void popupForPricingProfiles(String clientName, String clientCountry) {
		Common common = new Common(driver, test);

		validatePopupHeaderText("Pricing Profiles");
		chooseOptionFromDropdown("Pricing Profile", "NewPrivateProfile");
		String processingDate = getCurrentIFCSDateFromDB(clientName + clientCountry);
		String effDate = common.enterADateValueInStatusBeginDateField("Current", processingDate);
		enterValueInTextBox("Pricing Profile", "Assigned From", effDate);
		dropdownInPopupTable(Locator_IFCS.PRICING_PROFILE_POPUP_TABLE, "Pricing Scheme", "random");
		sleep(10);
		clickOkButton();
		sleep(5);
		validateNewDateAddedInTheTableList("Pricing Profiles", "Assigned From", effDate);
	}

	public void verifyCardControlProfile() {
		Common common = new Common(driver, test);

		int size = 0;
		chooseSubMenuFromLeftPanel("Card Details", "Order New Card");
		switchTabDetails("Profiles");
		try {
			driver.findElement(By.xpath("//div[starts-with(@class,'FALTableCellEditor_StrikeThru')]"));
			size = 1;
		} catch (Exception e) {
			size = 0;
		}
		System.out.println("rows count" + size);
		if (size == 0) {
			String profileNumber = common.getProfileNumber();
			rightClickAndCreatePrivateProfile(driver.findElement(
					By.xpath("//div[@class='JFALCompControlPanel']//div[@class='JViewport']/div[@style]")));
			sleep(3);
			validateCheckBoxInTableAndDoubleClick("Profiles", "Private", "Description");
			validatePopupHeaderText("Card Controls");
			enterValueInTextBox("Card Control Profile", "Description", fakerAPI().name().fullName());
			enterValueInTextBox("Purchase Velocity Controls", "External Code", profileNumber);
			Click(okButton, "Ok Button");
			sleep(3);
			rightClickAndSelectProfile("Profiles", 0, "Description");
			logInfo("Profile set");
		} else {
			logInfo("Profile is already set");
		}
	}

	public void verifyMaximumCardExpiryDate(String clientName, String clientCountry) {
		Common common = new Common(driver, test);
		switchTabDetails("Card Details");
		String currentIFCSDate = common.getCurrentIFCSDateFromDB(clientName + clientCountry);
		String expiryDate = enterADateValueInStatusBeginDateField("NextYear", currentIFCSDate);
		enterValueInTextBox("Card Offer", "Expiry Date", expiryDate);
		enterValueInTextBox("Vehicle Details", "License Plate", fakerAPI().name().prefix());
		enterValueInTextBox("Requested By", "Name", fakerAPI().name().firstName());
		common.clickValidateIcon();
		verifyValidationResult("Validation successful");
	}

	public void chooseCardDetailsMenuCardMaintenanceAndEmbossHistory() {

		chooseSubMenuFromLeftPanel("Card Details", "Card Maintenance");

		chooseSubMenuFromLeftPanel("Card Maintenance", "Emboss History");
		sleep(3);
	}

	public void chooseCardDetailsMenuCardMaintenance() {

		chooseSubMenuFromLeftPanel("Card Details", "Card Maintenance");
		sleep(3);
	}

	public void chooseCardDetailsMenuEmbossHistory() {

		chooseSubMenuFromLeftPanel("Card Maintenance", "Emboss History");
		sleep(3);
		validateHeaderLabel("Current");
	}

	public void selectIndividualReportsForCustomer(String customerReports) {

		int colIndex = SeleniumWrappers.getColumnNoForColumnHeader("Report Type", reportsTableHeader);
		for (int i = 0; i < SeleniumWrappers.getTotalNumberOfRows(cardsTable, driver); i++) {
			if (customerReports.contains(SeleniumWrappers.getTableDataWithRowAndColumnNumber(colIndex, i, driver))) {
				Click(SeleniumWrappers.getTableDataWithCellElement(i, colIndex, driver), "Already Report Type Present");
				rightClick(SeleniumWrappers.getTableDataWithCellElement(i, colIndex, driver));
				deleteIteminPopup();
				clickSaveIcon();
			}
		}
		int size;
		String reportsToAdd[] = new String[10];
		if (customerReports.contains(",")) {
			reportsToAdd = customerReports.split(",");
			size = reportsToAdd.length;
		} else {
			reportsToAdd[0] = customerReports;
			size = 1;
		}
		System.out.println("Length-->" + size);
		for (int i = 0; i < size; i++) {
			rightClick(reportsTableHeader.get(0));
			addIteminPopup();
			// messagePopUpHandle();
			sleep(3);
			chooseOptionFromDropdown("Report Type", reportsToAdd[i].trim());
			clickOkButton();
			sleep(5);
			clickSaveIcon();
			verifyValidationResult("Record saved OK");
			// verifyContainsInBottomLeftMessage("Record saved OK");
		}
	}

	public void validateNewlyCreatedCustomerNumber(String customerNumber) {
		chooseCustomerNoAndSearch(customerNumber);
		sleep(3);
		validateHeaderLabel("Maintain Customer");
		sleep(3);
		verifySearchResultCustomerNumber(customerNumber);

	}

	public void checkPublicRebateOptedIn() {
		validateCheckBoxOptedIn("Rebate Profiles", "Opted Out", "Description", "Net Off Rebates");

	}

	public void exportReports() {
		CommonPage commonPage = new CommonPage(driver, test);

		String value, color, hexColor;
		WebElement cellElement;
		WebElement colorElement;
		try {
			List<WebElement> list = driver
					.findElements(By.xpath("//div[@class='FALTableCellEditor_StrikeThruField JTextComponent']"));

			int size = SeleniumWrappers.getTotalNumberOfRows(list, driver);
			for (int i = 0; i <= size; i++) {
				cellElement = SeleniumWrappers.getTableDataWithCellElement(i, 0, driver);
				value = SeleniumWrappers.getTableDataWithRowAndColumnNumber(0, i, driver);
				System.out.println("FileNameFromTable---------->" + value);
				colorElement = driver.findElement(
						By.xpath("//div[@class='FALTableCellEditor_StrikeThruField JTextComponent']//div"));
				color = colorElement.getCssValue("background-color");
				hexColor = convertrgbColorToHex(color);
				if (hexColor.equals("#b8cfe5")) { // rgba(184, 207, 229, 1)
					Click(cellElement, "Cell Element in the table");
					sleep(5);
					/*
					 * Click(viewReportButton, "View Report Button");
					 * verifyValidationResult("Report Created Successfully");
					 */
					System.out.println("file name for view report" + value);
					commonPage.isFileDownloaded(value);
					Click(exportReportButton, "Export Report Button");
					verifyValidationResult("Data exported successfully");
					commonPage.isFileDownloaded("wexdownload");
					logPass("Report is Viewed and Exported");
					break;
				}
			}
		} catch (Exception e) {
			logFail(e.getMessage());
		}
	}

	// Prakalpha - 05/10/2019

	public String getCardFeeProfileForCardsFromTable(String seperatorLabelName, String tableHeaderCol1,
			String tableHeaderCol2, String cardOfferType) {
		List<WebElement> tableHeaders;
		List<WebElement> list;
		String seperator = " ";
		String value = " ";
		WebElement cellElement;
		try {

			seperator = splitStringAndGenerateXpath(seperatorLabelName);
			tableHeaders = driver.findElements(By.xpath("//div[@class='JFALSeparator']//div[" + seperator
					+ "]/preceding::div[@class='JFALCompControlPanel'][1]//div[@class='JViewport']/div[@class='JTableHeader']//div[@class='HeaderRenderer']"));
			int colIndex1 = SeleniumWrappers.getColumnNoForColumnHeader(tableHeaderCol1, tableHeaders);
			int colIndex2 = SeleniumWrappers.getColumnNoForColumnHeader(tableHeaderCol2, tableHeaders);
			System.out.println("Column Index for " + tableHeaderCol1 + "::" + colIndex1);
			System.out.println("Column Index for " + tableHeaderCol2 + "::" + colIndex2);
			list = driver.findElements(By.xpath("//div[@class='FALTableCellEditor_StrikeThruField JTextComponent']"));

			int rowSize = SeleniumWrappers.getTotalNumberOfRows(list, driver);
			System.out.println("rowSize:: " + rowSize);
			for (int row = 0; row < rowSize; row++) {
				if (SeleniumWrappers.getTableDataWithRowAndColumnNumber(colIndex1, row, driver)
						.equalsIgnoreCase(cardOfferType)) {
					value = SeleniumWrappers.getTableDataWithRowAndColumnNumber(colIndex2, row, driver);
					cellElement = SeleniumWrappers.getTableDataWithCellElement(row, colIndex1, driver);
					System.out.println(cellElement);
					sleep(2);
					Click(cellElement, cardOfferType + "Element is Clicked");
					sleep(2);
					logPass(cardOfferType + " CardFee Profile is " + value);
					break;
				}

			}

		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
		return value;
	}

	public void updateCardFeeProfile() {
		chooseSubMenuFromLeftPanel("Maintain Customer", "");
		chooseSubMenuFromLeftPanel("Customer Profiles", "Maintain Card Fees");
		validateHeaderLabel("Maintain Card Fees");
		List<WebElement> list = driver.findElements(By.xpath(
				"//div[@class='JFALSeparator']//div[starts-with(text(),'Available')and contains(text(),'Profiles')]//preceding::div[@class='JFALCompControlPanel'][1]//div[@class='FALTableCellEditor_StrikeThruField JTextComponent']"));
		// validateNewValueAddedInTheTableList("Card Fees", "Card Fee Profile", text);
		int rows = SeleniumWrappers.getTotalNumberOfRows(list, driver) - 1;

		System.out.println("No Of rows" + rows);

		Click(driver.findElement(By.xpath(
				"//div[@class='JFALSeparator']//div[starts-with(text(),'Available')and contains(text(),'Profiles')]//preceding::div[@class='JFALCompControlPanel'][1]//div[@class='FALTableCellEditor_StrikeThruField JTextComponent']//input[contains(@id,'_"
						+ rows + "_3')]")),
				"Card fee");
		sleep(5);
		rightClickAndSelectMenuItem("Details", availableProfileCardFeesTable, poupMenuItemDetails);
		enterDetailsInCardFeesPopUp();
		sleep(5);
		// rightClickAndSelectMenuItem("Add",cardFeesTable , menuItemLocator);
		clickSaveIcon();
		sleep(2);
		verifyValidationResult("Record saved OK");
	}

	public String validateAndSetCardFeeProfileForCustomer() {
		String driverCardFeeProfile = getCardFeeProfileForCardsFromTable("Card Fees", "Card Offer", "Card Fee Profile",
				"BP Fuelcard Driver");
		System.out.println(driverCardFeeProfile);
		/*
		 * String vehicleCardFeeProfile =
		 * getCardFeeProfileForCardsFromTable("Card Fees", "Card Offer",
		 * "Card Fee Profile", "BP Fuelcard Vehicle");
		 * System.out.println(vehicleCardFeeProfile);
		 */
		validateDefaultCardFeeProfileForAllCards("Available Profiles", driverCardFeeProfile, "BeforeDayEnd");
		clickSaveIcon();
		sleep(5);
		verifyValidationResult("Record saved OK");
		clickApplyAllCardsIcon();
		sleep(2);
		clickYesButtonInPopup();
		verifyValidationResult("Request created. All cards will be updated tonight.");
		return driverCardFeeProfile;
	}

	/*
	 * public void validateDefaultCardFeeProfileForAllCards() { int
	 * defaultCheckBoxRow; int descriptionColIndex; List<WebElement> tableHeaders;
	 * String driverCardFeeProfile = getCardFeeProfileForCardsFromTable("Card Fees",
	 * "Card Offer", "Card Fee Profile", "BP Fuelcard Driver");
	 * System.out.println(driverCardFeeProfile); String vehicleCardFeeProfile =
	 * getCardFeeProfileForCardsFromTable("Card Fees", "Card Offer",
	 * "Card Fee Profile", "BP Fuelcard Vehicle");
	 * System.out.println(vehicleCardFeeProfile); try { defaultCheckBoxRow =
	 * validateCheckBoxInTable("Available Profiles", "Default"); tableHeaders =
	 * driver.findElements(By.xpath(
	 * "//div[@class='JFALSeparator']//div[contains(text(),'Available') and contains(text(),'Profiles')]/preceding::div[@class='JFALCompControlPanel'][1]//div[@class='JViewport']/div[@class='JTableHeader']//div[@class='HeaderRenderer']"
	 * )); descriptionColIndex =
	 * SeleniumWrappers.getColumnNoForColumnHeader("Description", tableHeaders);
	 * String cardFeeValue = SeleniumWrappers.getTableCellValue(defaultCheckBoxRow,
	 * descriptionColIndex);
	 * 
	 * if (driverCardFeeProfile.equals(cardFeeValue)) { logPass(driverCardFeeProfile
	 * + "and" + cardFeeValue + "value is equal"); List<WebElement> list = driver
	 * .findElements(By.
	 * xpath("//div[@class='FALTableCellEditor_StrikeThruField JTextComponent']"));
	 * SeleniumWrappers.setCellValue(list); int totalRowCount =
	 * SeleniumWrappers.getTotalNumberOfRows(list, driver); if (defaultCheckBoxRow
	 * == totalRowCount) { int previousRow = defaultCheckBoxRow - 1;
	 * rightClickAndSelectProfile("Available Profiles", previousRow, "Description");
	 * } else { int nextRow = defaultCheckBoxRow + 1;
	 * rightClickAndSelectProfile("Available Profiles", nextRow, "Description"); } }
	 * } catch (Exception ex) { logFail(ex.getMessage()); } clickSaveIcon();
	 * sleep(5); verifyValidationResult("Record saved OK");
	 * clickApplyAllCardsIcon(); sleep(2); clickYesButton();
	 * verifyValidationResult("Request created. All cards will be updated tonight."
	 * );
	 * 
	 * }
	 */

	public void validateDefaultCardFeeProfileForAllCards(String seperatorLabelName, String expectedLabel,
			String processType) {
		int defaultCheckBoxRow;
		int descriptionColIndex;
		List<WebElement> tableHeaders;
		String seperator = " ";
		try {
			seperator = splitStringAndGenerateXpath(seperatorLabelName);
			defaultCheckBoxRow = validateCheckBoxInTable(seperatorLabelName, "Default");
			System.out.println("Default CheckBox::" + defaultCheckBoxRow);
			tableHeaders = driver.findElements(By.xpath("//div[@class='JFALSeparator']//div[" + seperator
					+ "]/preceding::div[@class='JFALCompControlPanel'][1]//div[@class='JViewport']/div[@class='JTableHeader']//div[@class='HeaderRenderer']"));
			descriptionColIndex = SeleniumWrappers.getColumnNoForColumnHeader("Description", tableHeaders);
			String cardFeeValue = SeleniumWrappers.getTableDataWithRowAndColumnNumber(descriptionColIndex,
					defaultCheckBoxRow, driver);
			System.out.println("Card Fee Value:: " + cardFeeValue);
			if (processType.equalsIgnoreCase("BeforeDayEnd")) {
				if (expectedLabel.equals(cardFeeValue)) {
					logPass(expectedLabel + "and" + cardFeeValue + "value is equal");
					List<WebElement> list = driver.findElements(By.xpath("//div[@class='JFALSeparator']//div["
							+ seperator
							+ "]/preceding::div[@class='JFALCompControlPanel'][1]//div[@class='FALTableCellEditor_StrikeThruField JTextComponent']"));

					int totalRowCount = SeleniumWrappers.getTotalNumberOfRows(list, driver);
					System.out.println("Row Count ::" + totalRowCount);
					if (defaultCheckBoxRow < totalRowCount) {
						int nextRow = defaultCheckBoxRow + 1;
						rightClickAndSelectProfile(seperatorLabelName, nextRow, "Description");
					} else {
						int previousRow = defaultCheckBoxRow - 1;
						rightClickAndSelectProfile(seperatorLabelName, previousRow, "Description");
					}

				}
			}

			else if (processType.equalsIgnoreCase("AfterDayEnd")) {
				if (cardFeeValue.equals(expectedLabel)) {
					System.out.println("****After Day End Process CardFee Profile has Updated*****");
					logPass(expectedLabel + "and" + cardFeeValue + "value is equal");

				} else {
					System.out.println("****After Day End CardFee Profile has not Updated*****");
					logInfo(expectedLabel + "and" + cardFeeValue + "value is not equal");
				}
			} else {
				logFail("Provide Correct Process Type");
			}
		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
	}

	public void validateCardFeeProfileAppliedToAllCards(String seperatorLabelName, String tableHeaderName,
			String seperatorName, String expectedValue, String processType) {
		List<WebElement> tableHeaders;
		List<WebElement> list;
		String seperator = " ";
		WebElement cellElement;
		int rowSize = 0;
		chooseSubMenuFromLeftPanel("Card Maintenance", "Cards");
		clickDetailSearchIfFilterFieldsNotPresent();
		list = driver.findElements(By.xpath("//div[@class='FALTableCellEditor_StrikeThruField JTextComponent']"));

		rowSize = SeleniumWrappers.getTotalNumberOfRows(list, driver);
		tableHeaders = driver.findElements(By.xpath("//div[@class='JFALSeparator']//div[" + seperator
				+ "]/preceding::div[@class='JFALCompControlPanel'][1]//div[@class='JViewport']/div[@class='JTableHeader']//div[@class='HeaderRenderer']"));
		int colIndex1 = SeleniumWrappers.getColumnNoForColumnHeader(tableHeaderName, tableHeaders);
		for (int row = 0; row < rowSize; row++) {
			String cardNo = SeleniumWrappers.getTableDataWithRowAndColumnNumber(colIndex1, row, driver);
			System.out.println("CardNo::" + cardNo);
			cellElement = SeleniumWrappers.getTableDataWithCellElement(row, colIndex1, driver);
			doubleClick(cellElement);
			sleep(5);

			validateHeaderLabel("Card Maintenance");
			switchTabDetails("Card Fees");
			validateDefaultCardFeeProfileForAllCards(seperatorName, expectedValue, processType);
			clickBackIcon();

		}

	}

	// prakalpha

	public void fillMandatoryFieldsAndCreateProfile(String cardProductName, String externalCode, String expireDate,
			boolean value, boolean offervalue) {
		String driverName = fakerAPI().name().firstName();
		String licencePlate = fakerAPI().number().digits(5);
		String name = fakerAPI().name().firstName();
		chooseSubMenuFromLeftPanel("Card Details", "Order New Card");
		validateHeaderLabel("Order New Card");
		if (offervalue == true) {
			String clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
			chooseOptionFromDropdown("Card Offer", clientCountry + " Fleet Card");
		}
		chooseOptionFromDropdown("Card Product", cardProductName);

		if (cardProductName.equals("Dual Card Driver")) {
			enterValueInTextBox("Driver Details", "Driver Name", driverName);
		} else if (cardProductName.equals("Dual Card Vehicle") || cardProductName.equals("Fleet Card Vehicle")
				|| cardProductName.equals("Fleet Card")) {
			driver.navigate().refresh();
			sleep(5);
			enterValueInTextBox("Vehicle Details", "License Plate", licencePlate);
		} else {
			System.out.println("Card Product::" + cardProductName);
			driver.navigate().refresh();
			sleep(5);
			enterValueInTextBox("Vehicle Details", "License Plate", licencePlate);
		}
		sleep(5);
		if (value == true) {

			enterValueInTextBox("Card Offer", "Expiry Date", expireDate);
		}

		enterValueInTextBox("Requested By", "Name", name);
		sleep(2);
		switchTabDetails("Profiles");
		sleep(2);
		int defaultRow = validateCheckBoxInTable("", "Private");
		System.out.println("Private row::" + defaultRow);
		if (defaultRow < 0) {
			enterDetailsInCardControlsPopUp();
			enterValueInTextBox("Purchase Velocity Controls", "External Code", externalCode);
			sleep(2);
			clickOkButton();
			sleep(2);
			setPrivateProfileAsDefault("Profiles");
		}

	}

	// Prakalpha
	public void validateNewCardStatus(String cardNo) {
		chooseSubMenuFromLeftPanel("Card Maintenance", "Cards");
		clickDetailSearchIfFilterFieldsNotPresent();
		clearingAllTextBoxes(textBoxes);
		sleep(2);
		enterValueInTextBox("Filter By", "Card Number", cardNo);
		searchListTorch();
		sleep(5);
		validateSearchTable("Card Number", cardNo, true);
	}

	// Prakalpha
	public String getStatusforCard(String seperatorLabelName, String columnHeader) {
		List<WebElement> tableHeaders;
		String seperator = " ";
		String status = "";
		try {
			seperator = splitStringAndGenerateXpath(seperatorLabelName);

			tableHeaders = driver.findElements(By.xpath("//div[@class='JFALSeparator']//div[" + seperator
					+ "]/preceding::div[@class='JFALCompControlPanel'][1]//div[@class='JViewport']/div[@class='JTableHeader']//div[@class='HeaderRenderer']"));
			int statusColIndex = SeleniumWrappers.getColumnNoForColumnHeader(columnHeader, tableHeaders);
			// status = SeleniumWrappers.getTableCellValue(0, statusColIndex);
			WebElement statuscellValue = driver.findElement(By.xpath("//div[@class='JFALSeparator']//div[" + seperator
					+ "]/preceding::div[@class='JFALCompControlPanel']/preceding::div[@class='FALTableCellEditor_StrikeThruField JTextComponent'][contains(@id,'_0_"
					+ statusColIndex + "')]//div[@class='htmlString']"));
			System.out.println("statuscellValue::" + statuscellValue);
			status = statuscellValue.getText();
		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
		return status;
	}

	// Prakalpha
	public String getCardNumberandValidateOrderedCard() {
		sleep(5);
		switchTabDetails("Card Details");
		clickValidateIcon();
		verifyValidationResult("Validation successful");
		createTaskBar();
		sleep(10);
		String newOrderedcardNumber = getValueFromProtectedTextBox("Card Offer", "Card Number");
		System.out.println(newOrderedcardNumber);
		sleep(2);
		verifyValidationResult("Card " + newOrderedcardNumber + " ordered");
		return newOrderedcardNumber;
	}

	// Prakalpha-->Updated 06/12/2019

	public int getRownumberAndCreateRebateProfile() {
		sleep(5);
		chooseSubMenuFromLeftPanel("Customer Profiles", "Rebates");
		detailSearch();
		validateHeaderLabel("Rebates");

		int privateRow = validateCheckBoxInTable("Rebate Profiles", "Private");// returns 0 or -1: 0 indicates chekcbox
																				// selected, -1 indicates not selected
		System.out.println("Private Row Number ::" + privateRow);
		// if (privateRow != -1)
		if (privateRow != 0) {
			scrollDownPage();
			int rowSize = SeleniumWrappers.getTotalNumberOfRows(rebateProfilesTable, driver) - 1;
			System.out.println("Row Size:" + rowSize);
			Click(driver.findElement(By.xpath(
					"//div[@class='JFALSeparator']//div[contains(text(),'Rebate') and contains(text(),'Profiles')]/preceding::div[@class='JFALCompControlPanel'][2]//input[contains(@id,'_"
							+ rowSize + "_3')]")),
					"Private profile");
			doubleClick(driver.findElement(By.xpath(
					"//div[@class='JFALSeparator']//div[contains(text(),'Rebate') and contains(text(),'Profiles')]/preceding::div[@class='JFALCompControlPanel'][2]//input[contains(@id,'_"
							+ rowSize + "_3')]")));
			sleep(5);
			rightClick(rebateHeaderPopupTable);
			addIteminPopup();

		} else {
			rightClickAndCreatePrivateProfile(rebateTable);
			sleep(5);
			validateCheckBoxInTableAndDoubleClick("Rebate Profiles", "Private", "Description");

		}
		return privateRow;
	}

	public void enterDetailsInRebateProfilePopup(String effDate, String expDate) {
		sleep(5);
		validatePopupHeaderText("Rebate Profile Header Details");
		enterValueInTextBox("Details", "Description", text);
		sleep(5);
		enterValueInTextBox("Details", "Effective On", effDate);
		sleep(5);
		enterValueInTextBox("Details", "Expires On", expDate);
		rightClick(rebateHeaderPopupTable);
		addIteminPopup();
		sleep(10);

	}

	public void enterDetailsInRebateDetailsPopup(String rebateCategory, String effDate, String expDate, String product,
			String productgroup, String rangeFrom, String rangeTo, String rate, String memberNo) {

		sleep(2);
		enterValueInRepeatedPopup("Details", "Description", fakerAPI().name().firstName());
		sleep(5);
		enterValueInTextBox("Details", "3rd Party No", fakerAPI().number().digits(4));

		chooseOptionFromDropdown("Rebate Category", "random");// rathna changed
		sleep(2);
		enterValueInRepeatedPopup("Details", "Effective On", effDate);
		sleep(5);
		enterValueInRepeatedPopup("Details", "Expires On", expDate);
		if (product.equals(" ")) {
			chooseBlankOptionFromDropdown("Product");
		} else {
			chooseOptionFromDropdown("Product", "randaom");// rathna changed
		}
		if (productgroup.equals(" ")) {
			chooseBlankOptionFromDropdown("Product");
		} else {
			chooseOptionFromDropdown("Product Group", "random");// rathna changed
		}
		rightClick(rebateContributionsPopupTable);
		addIteminPopup();
		sleep(5);
		selectValueFromDropDownInRebateTable(Locator_IFCS.REBATE_CONTRIBUTIONS_POPUP_TABLE, "Member Type", "Location");
		// enterValueInRebateTableTextField(Locator_IFCS.REBATE_CONTRIBUTIONS_POPUP_TABLE,
		// "Member No", memberNo);
		rightClick(rebateValuesPopupTable);
		addIteminPopup();
		enterValueInRebateTableTextField(Locator_IFCS.REBATE_VALUES_POPUP_TABLE, "Value Range From", rangeFrom);
		enterValueInRebateTableTextField(Locator_IFCS.REBATE_VALUES_POPUP_TABLE, "Rate", rate);
		sleep(2);
		clickSecondPopupOkButton();
		sleep(5);

	}
	// added by rathna

	public void enterValueInRebateTableTextField(String locator, String headerName, String value) {
		int colHeaderIndex = 0;
		try {
			WebElement WebLocator = driver.findElement(By.xpath(locator));
			colHeaderIndex = SeleniumWrappers.getColumnNoForColumnHeader(headerName,
					WebLocator.findElements(By.xpath(".//div[@class='HeaderRenderer']")));
			System.out.println("Column header" + colHeaderIndex);
			List<WebElement> tableList = WebLocator
					.findElements(By.xpath(".//div[@class='FALTableCellEditor_StrikeThruField JTextComponent']"));
			tableList = WebLocator
					.findElements(By.xpath(".//div[@class='FALTableCellEditor_StrikeThruField JTextComponent']"));
			SeleniumWrappers.setCellValueforPopup(tableList, locator, driver);
			WebElement cellElement = driver
					.findElement(By.xpath(locator + "//input[contains(@id,'_" + 0 + "_" + colHeaderIndex + "')]"));
			doubleClick(cellElement);
			sleep(2);
			new Actions(driver).sendKeys(value).perform();
			// cellElement.sendKeys(value);
			sleep(2);

			logPass("Value entered in the cell");
		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
	}

	// added by rathna
	public void selectValueFromDropDownInRebateTable(String locator, String headerName, String option) {
		int size;
		int colHeaderIndex;
		WebElement webLocator;
		List<WebElement> tabledropdownList;
		try {
			List<WebElement> comboOptions = null;
			webLocator = driver.findElement(By.xpath(locator));
			System.out.println("WebLocator" + webLocator);
			// System.out.println("Dropdown For Table");
			tabledropdownList = webLocator
					.findElements(By.xpath(".//div[@class='FALTableCellEditor_StrikeThruField JTextComponent']"));
			SeleniumWrappers.setCellValueforPopup(tabledropdownList, locator, driver);
			size = SeleniumWrappers.getTotalNumberOfRows(tabledropdownList, driver);
			colHeaderIndex = SeleniumWrappers.getColumnNoForColumnHeader(headerName,
					webLocator.findElements(By.xpath(".//div[@class='HeaderRenderer']")));
			System.out.println("Column header" + colHeaderIndex);
			for (int row = 0; row < size; row++) {
				tabledropdownList = webLocator
						.findElements(By.xpath(".//div[@class='FALTableCellEditor_StrikeThruField JTextComponent']"));
				SeleniumWrappers.setCellValueforPopup(tabledropdownList, locator, driver);

				// updated rathna
				String s = locator + "//input[contains(@id,'_0_0')]";
				String s1 = locator + "//input[contains(@id,'_" + row + "_" + colHeaderIndex + "')]";
				WebElement cellElement = driver.findElement(
						By.xpath(locator + "//input[contains(@id,'_" + row + "_" + colHeaderIndex + "')]"));

				SeleniumWrappers.getTableDataWithRowAndColumnNumber(colHeaderIndex, row, driver);// commeted now
				cellElement.click();
				sleep(2);

				// Select valud from drop down
				comboOptions = driver
						.findElements(By.xpath("//div[@class='BasicComboPopup_1']/div/div[@class='htmlString']"));
				System.out.println("Option size" + comboOptions.size());
				if (option.equalsIgnoreCase("random")) {
					if (comboOptions.size() == 1) {
						option = getText(comboOptions.get(0));
					} else {
						System.out.println("comboOptions size:" + comboOptions.size());
						int randomNo = getRandomNumber(0, comboOptions.size() - 1);
						option = getText(comboOptions.get(randomNo));
					}
				}
				for (int i = 0; i < comboOptions.size(); i++) {
					if (option.toLowerCase().equals(getText(comboOptions.get(i)).toLowerCase())) {

						isDisplayedThenActionClick(comboOptions.get(i), "->" + option);
						sleep(5);
						break;
					}
				}

			}

		} catch (Exception ex) {
			logFail(ex.getMessage());
		}

	}

		
	public void createRebateProfileWithRequiredRebateDetails(String cusNo, String effDate, String expiryDate) {
		chooseCustomerNoAndSearch(cusNo);
		int rownum = getRownumberAndCreateRebateProfile();
		if (rownum != 0) {
			enterDetailsInRebateDetailsPopup("PCT All Sites - Net Off", effDate, expiryDate, " ", "02 - Fuels", "100",
					"15", "100", "123");
		} else {
			enterDetailsInRebateProfilePopup(effDate, expiryDate);
			enterDetailsInRebateDetailsPopup("PCT All Sites - Net Off", effDate, expiryDate, " ", "02 - Fuels", "100",
					"15", "100", "123");
		}
		rightClick(rebateHeaderPopupTable);
		addIteminPopup();
		sleep(10);
		enterDetailsInRebateDetailsPopup("Period - CPL - Agg Child - Tier Single Rate - All Sites", effDate, expiryDate,
				" ", "02 - Fuels", "100", "15", "100", "123");
		clickOkButton();
		sleep(2);
		rightClickAndOptInout("Rebate Profiles", "Private");
		validateCheckBoxInTable("Rebate Profiles", "Opted Out");
	}

	// Added by Nithya - 03/06/2019
	public void addApplicationTypeTransfer() {
		chooseSubMenuFromLeftPanel("Maintain Customer", "Application Type Transfers");
		rightClick(applicationTypeTransfer);
		addIteminPopup();
		sleep(3);
		validateHeaderLabel("Application Type Transfer");
		// Transfer Details - Tab
		chooseOptionFromDropdown("To Application Type", "Business Direct");
		int tableSize = SeleniumWrappers.getNumberOfRows(driver);
		for (int i = 0; i < tableSize; i++) {
			try {
				doubleClick(driver.findElement(By.xpath(".//input[contains(@id,'_" + i + "_0')]")));
				sleep(3);
				chooseARandomDropdownOption("New Card Product");
				validateCheckBoxToCheckOrUncheck("Card Products", "Use as Default", "Checked");
				clickOkButton();
				sleep(5);
			} catch (Exception ex) {
				System.out.println(ex);
			}
		}
		// Customer Profiles - Tab
		switchTabDetails("Customer Profiles");
		chooseOptionFromDropdown("Pricing Transfer Option", "Create Private Profile");
		chooseOptionFromDropdown("Account Fee Transfer Option", "Create Private Profile");
		chooseOptionFromDropdown("Card Reissue Transfer Option", "Keep Profile");

		// Card Profiles - Tab
		switchTabDetails("Card Profiles");
		tableSize = SeleniumWrappers.getTotalNumberOfRows(cardsFeeProfileTable, driver);

		// Card Fee Profile
		for (int i = 0; i < tableSize; i++) {
			doubleClick(driver.findElement(
					By.xpath("//div[@class='JFALCompControlPanel'][2]//input[contains(@id,'_" + i + "_0')]")));
			sleep(3);
			chooseOptionFromDropdown("Transfer Option", "Create Private Profile");
			clickOkButton();
			sleep(5);
		}

		tableSize = SeleniumWrappers.getTotalNumberOfRows(cardsControlProfileTable, driver);
		// Card Control Profile
		for (int i = 0; i < tableSize; i++) {
			doubleClick(SeleniumWrappers.getTableDataWithCellElement(i, 0, driver));
			sleep(3);
			chooseOptionFromDropdown("Transfer Option", "Create Private Profile");
			clickOkButton();
			sleep(5);
		}

		clickSaveIcon();
		verifyValidationResult("Record saved OK");
	}

	public void validateApplicationTypeTransferStatus(String expectedStatus) {
		chooseSubMenuFromLeftPanel("Maintain Customer", "Application Type Transfers");

		int colNo = SeleniumWrappers.getColumnNoForColumnHeader("Status", cardsTableHeaders);
		String applicationRequestStatus = SeleniumWrappers.getTableDataWithRowAndColumnNumber(colNo, 0, driver);
		System.out.println("Current Request Status:" + applicationRequestStatus);
		if (applicationRequestStatus.equals(expectedStatus)) {
			logPass("Application Type Transfer Status created succesfully");
		} else {
			logFail("Application type transfer status is :" + applicationRequestStatus);
		}
	}

	public String validateAndOrderCardsForAllCustomers(ArrayList<String> AllCustomers, String clientCountry) {

		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		String orderedCardNumber = "";
		String cardsList = "";
		for (int i = 0; i < AllCustomers.size(); i++) {

			IFCSHomePage.gotoCustomerMenuCustomerDetails();
			chooseCustomerNoAndSearch(AllCustomers.get(i));

			if (clientCountry.equals("SG") && i == 0) {
				fillMandatoryFieldsAndCreateProfile("Fleet Card", "0001", " ", false, true);

			} else if (clientCountry.equals("SG") && i > 0) {
				fillMandatoryFieldsAndCreateProfile("Duty Free", "0001", " ", false, true);
			}
			if (clientCountry.equals("SP") || clientCountry.equals("GU")) {
				fillMandatoryFieldsAndCreateProfile("Fleet Card", "1501", " ", false, false);
			}
			if (clientCountry.equals("HK")) {
				fillMandatoryFieldsAndCreateProfile("Fleet Card Vehicle", "0001", " ", false, true);
			}

			// setPrivateProfileAsDefault("Profiles");
			orderedCardNumber = getCardNumberandValidateOrderedCard();
			validateNewCardStatus(orderedCardNumber);
			String NewcardStatus = getStatusforCard("Card List", "Status");
			System.out.println(NewcardStatus);
			validateSearchTable("Status", "Requested Not Issued", true);

			if (i == 0) {
				cardsList = cardsList + orderedCardNumber;
			} else {
				cardsList = cardsList + "," + orderedCardNumber;
			}
		}
		return cardsList;
	}

	public ArrayList<String> getAllCustomerNumbers(String clientCountry) {

		ArrayList<String> customers = new ArrayList<String>();
		if (clientCountry.equals("SG")) {

			String receivedOnFleetCard = getReceivedOnDateForMigratedCustomer();
			String migratedFleetCardCustomerNo = getMigratedCustomerNo(receivedOnFleetCard, clientCountry + " General");
			String receivedOnDutyFree = getReceivedOnDateForMigratedCustomer();
			String migratedDutyFreeCustomerNo = getMigratedCustomerNo(receivedOnDutyFree, "Duty Free Customer");
			String dutyFreeCustomerNo = getActiveCustomerUsingApplicationType("Duty Free Customer");
			customers.add(migratedFleetCardCustomerNo);
			customers.add(migratedDutyFreeCustomerNo);
			customers.add(dutyFreeCustomerNo);
		} else if (clientCountry.equals("SP")) {
			String customerNo = getActiveCustomerUsingApplicationType(clientCountry + " General");
			String PeriodicRebateInHierarchy = getRebateParentCustomerNoInHierarchy();
			String hierarchyCustomer = getCustomerNoInHierarchy();
			customers.add(customerNo);
			customers.add(PeriodicRebateInHierarchy);
			customers.add(hierarchyCustomer);

		} else if (clientCountry.equals("GU")) {
			String customerNumber = getActiveCustomerUsingApplicationType(clientCountry + " General");
			String hierarchyCustomerNo = getCustomerNoInHierarchy();
			customers.add(customerNumber);
			customers.add(hierarchyCustomerNo);
		} else if (clientCountry.equals("HK")) {
			String receivedOn = getReceivedOnDateForMigratedCustomer();
			String migratedDutyFreeCusNo = getMigratedCustomerNo(receivedOn, "HK Duty Free Customer");
			String PeriodicRebateHierarchy = getRebateParentCustomerNoInHierarchy();
			String dutyFreeCusNo = getActiveCustomerUsingApplicationType("HK Duty Free Customer");
			customers.add(migratedDutyFreeCusNo);
			customers.add(PeriodicRebateHierarchy);
			customers.add(dutyFreeCusNo);
		}
		return (customers);
	}

	public void verifyCardFeeProfile(String actualFeeProfile, String expectedFeeProfile) {
		if (actualFeeProfile.equals(expectedFeeProfile)) {
			logPass("CardFeeProfile Successfully updated");
		} else
			logFail("CardFeeProfile is not changed");
	}

	public void validateAndAddCardControlProfile() {

		switchTabDetails("Profiles");
		String desc = enterDetailsInCardControlsPopUp();
		chooseARandomDropdownOption("Product Restriction");
		chooseARandomDropdownOption("Time Limit");
		chooseARandomDropdownOption("Location Restriction");
		chooseARandomDropdownOption("Transaction Purchase Limit");
		chooseARandomDropdownOption("Transaction Volume Limit - Fuel");
		chooseARandomDropdownOption("Transaction Purchase Soft Limit");
		chooseARandomDropdownOption("Transaction Volume Soft Limit");
		chooseARandomDropdownOption("Transaction Purchase Soft Limit - Non Fuel");
		chooseARandomDropdownOption("Daily Volume Soft Limit");
		chooseARandomDropdownOption("Daily Transaction Soft Limit");
		chooseARandomDropdownOption("Monthly Volume Soft Limit");
		clickOkButton();
		sleep(5);
		clickSaveIcon();
		sleep(5);
		verifyValidationResult("Record saved OK");
		chooseMaintainCardControlsFromCustomerProfile();
		validateProfileNotAvailableInTable("Available Profiles", "Description", desc);

	}

	/*
	 * Prakalpha->11/07/2019 negative Scenario
	 */
	public void validateProfileNotAvailableInTable(String seperatorLabelName, String tableHeaderName,
			String expectedText) {

		List<WebElement> tableHeaders;
		List<WebElement> list;
		String seperator = " ";
		try {
			seperator = splitStringAndGenerateXpath(seperatorLabelName);
			tableHeaders = driver.findElements(By.xpath("//div[@class='JFALSeparator']//div[" + seperator
					+ "]/preceding::div[@class='JFALCompControlPanel'][1]//div[@class='JViewport']/div[@class='JTableHeader']//div[@class='HeaderRenderer']"));
			int colIndex = SeleniumWrappers.getColumnNoForColumnHeader(tableHeaderName, tableHeaders);
			System.out.println("Column Index" + colIndex);
			list = driver.findElements(By.xpath("//div[@class='JFALSeparator']//div[" + seperator
					+ "]//preceding::div[@class='JFALCompControlPanel'][1]//div[@class='FALTableCellEditor_StrikeThruField JTextComponent']"));

			int size = SeleniumWrappers.getTotalNumberOfRows(list, driver);
			System.out.println("Size" + size);
			for (int row = 0; row < size; row++) {
				WebElement element = driver.findElement(By.xpath("//div[@class='JFALSeparator']//div[" + seperator
						+ "]//preceding::div[@class='JFALCompControlPanel'][1]//div[@class='FALTableCellEditor_StrikeThruField JTextComponent'][contains(@id,'"
						+ "_" + row + "_" + colIndex + "')]//div[@class='htmlString']"));
				String actualText = element.getText();
				if (actualText.equalsIgnoreCase(expectedText)) {
					logFail(actualText + " and " + expectedText + "are same, Hence present in a customer Profile");

				} else {
					logPass(expectedText
							+ "is not present in customer Profile,hence Card Control Profile is not reflected in Customer Control Profiles");

				}
			}
		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
	}

	// Prakalpha
	public void viewExistingStatusFromCardTransfer() {
		moveToCardsInCustomerMaintanence();
		searchTorch();
		sleep(5);
		ArrayList<String> cardsStatus = getStatusforAllCards("Card List", "Status");
		System.out.println("Card  Status::" + cardsStatus);
	}

	// Prakalpha
	public ArrayList<String> getStatusforAllCards(String seperatorLabelName, String columnHeader) {
		List<WebElement> tableHeaders;
		List<WebElement> list;
		String seperator = " ";
		ArrayList<String> status = new ArrayList<String>();
		try {
			seperator = splitStringAndGenerateXpath(seperatorLabelName);

			tableHeaders = driver.findElements(By.xpath("//div[@class='JFALSeparator']//div[" + seperator
					+ "]/preceding::div[@class='JFALCompControlPanel'][1]//div[@class='JViewport']/div[@class='JTableHeader']//div[@class='HeaderRenderer']"));
			int statusColIndex = SeleniumWrappers.getColumnNoForColumnHeader(columnHeader, tableHeaders);
			list = driver.findElements(By.xpath("//div[@class='JFALSeparator']//div[" + seperatorLabelName
					+ "]//preceding::div[@class='JFALCompControlPanel'][1]//div[@class='FALTableCellEditor_StrikeThruField JTextComponent']"));

			int size = SeleniumWrappers.getTotalNumberOfRows(list, driver);
			System.out.println("Size" + size);
			for (int row = 0; row < size; row++) {
				WebElement element = driver.findElement(By.xpath("//div[@class='JFALSeparator']//div["
						+ seperatorLabelName
						+ "]//preceding::div[@class='JFALCompControlPanel'][1]//div[@class='FALTableCellEditor_StrikeThruField JTextComponent'][contains(@id,'"
						+ "_" + row + "_" + statusColIndex + "')]//div[@class='htmlString']"));
				String cellvalue = element.getText();
				status.add(cellvalue);

			}
		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
		return status;
	}

	public void deletePrivateFeeProfileInCardMaintenance(String cardNo) {
		chooseCardDetailsMenuCardMaintenance();
		chooseCardNoAndSearch(cardNo);
		switchTabDetails("Card Fees");
		sleep(5);
		rightClickDeletePrivateProfileAndValidate("Profile Selection", "Description");
		clickSaveIcon();
		verifyValidationResult("Record saved OK");
	}

	public void createMaintainCardControlsProfileWFE() {

		rightClickAndCreatePrivateProfile(availablesProfileCardControlsTableWFE);
		sleep(5);
		validateCheckBoxInTableAndDoubleClick("Profiles", "Private", "Description");
		sleep(5);
		// validatePopupHeaderText("Customer Card Control");
		enterValueInTextBox("Card Control Profile", "Description", text);
		enterDetailsInCardControlPopupWFE();
		sleep(5);

		int rownum = getRowNumberForSelectProfile("Profiles", "Private");
		rightClickAndSelectProfile("Profiles", rownum, "Description");
		sleep(5);
		validateCheckBoxInTable("Profiles", "Default");
		sleep(5);
		// validateNewValueAddedInTheTableList("Profiles", "Private", text);

	}

	public void enterDetailsInCardControlPopupWFE() {

		// validateCheckBoxToCheckOrUncheck("Required at POS?","CRN","Checked");
		// validateCheckBoxToCheckOrUncheck("Required at POS?","Odometer","Checked");
		/*
		 * chooseARandomDropdownOption("Product Restriction");
		 * chooseARandomDropdownOption("Time Limits");
		 * ScrollToElement(okButtonPopup,"Ok Button");
		 * 
		 * chooseARandomDropdownOption("Monthly Amt Limit");
		 * chooseARandomDropdownOption("Daily Amt Limit");
		 * chooseARandomDropdownOption("Weekly Amt Limit");
		 * chooseARandomDropdownOption("Daily Tran Limit");
		 * chooseARandomDropdownOption("Weekly Tran Limit");
		 * chooseARandomDropdownOption("Monthly Tran Limit");
		 * chooseARandomDropdownOption("Amt Per Transaction");
		 * chooseARandomDropdownOption("Daily Transaction Count");
		 */

		clickOkButton();
	}

	/**
	 * Fill Card Control Profile with random values
	 */
	public void enterDetailsInCardControlProfile() {

		Common common = new Common(driver, test);
		enterValueInTextBox("Card Control Profile", "Description", text);
		chooseARandomDropdownOption("Time Limits");
		chooseARandomDropdownOption("Location Restriction");
		chooseARandomDropdownOption("Monthly Amt Limit");
		chooseARandomDropdownOption("Daily Amt Limit");
		chooseARandomDropdownOption("Weekly Amt Limit");
		common.ScrollToElement("Purchase Velocity Controls", "Monthly Tran Limit");
		chooseARandomDropdownOption("Daily Tran Limit");
		chooseARandomDropdownOption("Weekly Tran Limit");
		chooseARandomDropdownOption("Monthly Tran Limit");

	}

	/**
	 * Create Card Control Profile and Select
	 */
	public void createCardControlProfile() {
		switchTabDetails("Profiles");
		rightClickAndCreatePrivateProfile(orderCardCardControlsTable);
		sleep(5);

		clickValidateIcon();

		sleep(5);
		rightClickAndSelectMenuItem("Select Profile", orderCardCardControlsTable, selectProfile);
		sleep(2);
		rightClickAndSelectMenuItem("Details", orderCardCardControlsTable, poupMenuItemDetails);
		sleep(2);
		validatePopupHeaderText("Card Controls");
		sleep(2);
		enterDetailsInCardControlProfile();
		sleep(5);
		clickOkButton();

		sleep(2);
		switchTabDetails("Card Details");
		sleep(2);
	}

	public void updateCardControlProfile() {
		sleep(5);
		switchTabDetails("Profiles");
		sleep(5);
		WebElement cellElement = SeleniumWrappers.getTableDataWithCellElement(0, 2, driver);
		doubleClick(cellElement);
		sleep(5);
		enterDetailsInCardControlProfile();
		sleep(5);
		clickOkButton();
		sleep(5);
		clickSaveIcon();

	}

	/**
	 * @param contactType - Add New Contact for the Customer in context
	 */
	public String addContactType(String contactType) {
		validatePopupHeaderText("Customer Contact");
		chooseOptionFromDropdown("Contact Type", contactType);
		String name = fakerAPI().name().fullName();
		enterValueInTextBox("Details", "Name", name);
		enterValueInTextBox("Contact", "Phone", "7638268448");
		enterValueInTextArea("Addresses/Contacts", "Physical Address", fakerAPI().address().fullAddress());
		selectACountryFromDropdown(0, "Country");
		sleep(5);
		clickOkButton();
		sleep(2);
		clickSaveIcon();
		sleep(5);
		verifyValidationResult("Record saved OK");
		sleep(5);
		return name;
	}

	/**
	 * Update Contact details
	 */
	public String updateContact() {
		String name = fakerAPI().name().fullName();
		validateHeaderLabel("Maintain Customer");
		chooseSubMenuFromLeftPanel("Maintain Customer", "Contacts");
		validateHeaderLabel("Contacts");
		sleep(5);
		WebElement cellElement = SeleniumWrappers.getTableDataWithCellElement(0, 0, driver);
		doubleClick(cellElement);
		sleep(2);
		enterValueInTextBox("Details", "Name", fakerAPI().name().fullName());
		enterValueInTextBox("Contact", "Phone", "7638268448");
		enterValueInTextArea("Addresses/Contacts", "Physical Address", fakerAPI().address().fullAddress());
		selectACountryFromDropdown(0, "Country");
		sleep(5);
		clickOkButton();
		//sleep(5);
		clickSaveIcon();
		//sleep(5);
		verifyValidationResult("Record saved OK");
		return name;
	}

	/*
	 * Added by Raxsana 03/07/2020
	 */

	/**
	 * Search Validation for Customers Page
	 */
	public void searchCustomerFiltersAndValidate() {
		String clientName = PropUtils.getPropValue(configProp, "clientName");
		String clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		String queryToGetCustomerValues = " select mc.customer_no,name,mc.trading_name,mc.ext_account_ref,ad.address_line,tt.description from m_customers mc\r\n"
				+ " inner join addresses ad on ad.address_oid=mc.street_address_oid\r\n"
				+ " inner join accounts a on a.customer_mid=mc.customer_mid\r\n"
				+ " inner join account_status acc on acc.account_status_oid=a.account_status_oid\r\n"
				+ " inner join territories tt on tt.territory_oid = mc.marketing_territory_oid\r\n"
				+ " where mc.trading_name!='null' and mc.ext_account_ref!='null' and acc.description like '%Active%'\r\n"
				+ " and mc.client_mid=(select client_mid from m_clients where name='"
				+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountry) + "')";
		Map<String, String> customerValues = connectDBAndGetDBEntireRowValues(queryToGetCustomerValues,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		System.out.println("customerValues::" + customerValues);

		chooseSubMenuFromLeftPanel("Customers", "");
		validateHeaderLabel("Viewer");
		clearingAllTextBoxes(textBoxes);
		enterValueInTextBox("Filter By", "Customer No", customerValues.get("CUSTOMER_NO"));
		searchListTorch();
		sleep(3);
		verifyValidationResult("Record Read OK - Page Size");
		validateSearchTable("Customer No", customerValues.get("CUSTOMER_NO"), true);
		// -------------------
		clearingAllTextBoxes(textBoxes);
		ScrollToElement("Filter By", "Admin Territory");
		chooseARandomDropdownOption("Admin Territory");
		searchListTorch();
		sleep(3);
		verifyValidationResult("Record Read OK - Page Size");
		ScrollToElement("Filter By", "Admin Territory");
		chooseBlankOptionFromDropdown("Admin Territory");
		// ----------------------------
		clearingAllTextBoxes(textBoxes);
		ScrollToElement("Filter By", "Marketing Territory");
		chooseOptionFromDropdown("Marketing Territory", customerValues.get("DESCRIPTION"));
		searchListTorch();
		sleep(3);
		verifyValidationResult("Record Read OK - Page Size");
		ScrollToElement("Filter By", "Marketing Territory");
		chooseBlankOptionFromDropdown("Marketing Territory");
		// ------------------------
		clearingAllTextBoxes(textBoxes);
		ScrollToElement("Filter By", "Customer Type");
		chooseARandomDropdownOption("Customer Type");
		searchListTorch();
		sleep(3);
		verifyValidationResult("Record Read OK - Page Size");
		ScrollToElement("Filter By", "Customer Type");
		chooseBlankOptionFromDropdown("Customer Type");
		// ---------------------------
		clearingAllTextBoxes(textBoxes);
		enterValueInTextBox("Filter By", "Name", customerValues.get("NAME"));
		searchListTorch();
		sleep(3);
		verifyValidationResult("Record Read OK - Page Size");
		validateSearchTable("Name", customerValues.get("NAME"), true);
		// ---------------------------
		clearingAllTextBoxes(textBoxes);
		enterValueInTextBox("Filter By", "Trading Name", customerValues.get("TRADING_NAME"));
		searchListTorch();
		sleep(3);
		verifyValidationResult("Record Read OK - Page Size");
		// -------------------------
		clearingAllTextBoxes(textBoxes);
		enterValueInTextBox("Filter By", "Ext Account Ref", customerValues.get("EXT_ACCOUNT_REF"));
		searchListTorch();
		sleep(3);
		verifyValidationResult("Record Read OK - Page Size");
		// -------------------
		clearingAllTextBoxes(textBoxes);
		enterValueInTextArea("Filter By", "Street Address", customerValues.get("ADDRESS_LINE"));
		searchListTorch();
		sleep(3);
		verifyValidationResult("Record Read OK - Page Size");
		validateSearchTable("Street Address", customerValues.get("ADDRESS_LINE"), true);
	}

	public void enableVINCIFee() {
		switchTabDetails("Value Added Services");
		sleep(2);
		rightClickAndSelectMenuItem("Details", valueAddedServicesTable, poupMenuItemDetails);
		sleep(2);
		checkBoxForApplication("Opt In");
		sleep(2);
		clickOkButton();
		sleep(3);
		switchTabDetails("Card Details");
		sleep(2);
	}

	/**
	 * Implemented byRathna
	 * 
	 * @param clientCountry
	 * @param clientName
	 */
	public void updateCustomerFromChequePayToSEPA(String clientName, String clientCountry) {
		Common common = new Common(driver, test);
		common.switchTabDetails("Financial Information");
		String bankNo = fakerAPI().number().digits(4);
		// String bankAccNo = fakerAPI().number().digits(4);
		String processingDate = common.getCurrentIFCSDateFromDB(clientName + clientCountry);
		String effDate = common.enterADateValueInStatusBeginDateField("Current", processingDate);
		String accName = fakerAPI().name().firstName();
		// String mandateId = fakerAPI().number().digits(4);
		chooseOptionFromDropdown("Bank", "random");
		enterValueInTextBox("Bank Details", "Bank No", bankNo);
		enterValueInTextBox("Bank Details", "Created On", effDate);
		enterValueInTextBox("Bank Details", "Account Name", accName);
		enterValueInTextBox("Bank Details", "IBAN", "BE20435202582157");
		enterValueInTextBox("Bank Details", "BIC", "KREDBEBC");
		enterValueInTextBox("Bank Details", "UMR No", "WEXBEB2B001299");
		common.clickSaveIcon();
		sleep(5);
		verifyValidationResult("Record saved OK");
		common.switchTabDetails("Account Information");
		ScrollToElement("Billing Details", "Billing Plan");
		chooseOptionFromDropdown("Billing Plan", "SEPA_DD -1 Days");
		sleep(5);
		verifyValidationResult("Record saved OK");
	}

	public void updateFrequencyToDaily() {
		Common common = new Common(driver, test);

		// set monthly --- use query to get customer with frequency : monthly
		ScrollToElement("Billing Details", "Billing Frequency");
		chooseOptionFromDropdown("Billing Frequency", "Invoice Monthly");
		chooseOptionFromDropdown("Account Cycle", "Invoice Monthly");
		common.clickSaveIcon();
		sleep(5);
		verifyValidationResult("Record saved OK");

		// change to daily from monthly
		ScrollToElement("Billing Details", "Billing Frequency");
		chooseOptionFromDropdown("Billing Frequency", "Invoice Daily");
		chooseOptionFromDropdown("Account Cycle", "Invoice Daily");
		common.clickSaveIcon();
		sleep(5);

		verifyValidationResult("Record saved OK");
	}

	
	//davu added
	public void updateRebateProfile() {

		chooseSubMenuFromLeftPanel("Maintain Customer", "");
		chooseSubMenuFromLeftPanel("Customer Profiles", "Rebates");
		validateHeaderLabel("Rebates");
		detailSearch();
		sleep(10);

		WebElement element = SeleniumWrappers.getTableDataWithCellElement(0, 3, driver);

		WebElement location = driver.findElement(By.xpath(
				"//div[@class='JFALSeparator']//div[contains(text(),'Rebate') and contains(text(),'Profiles')]/preceding::div[@class = 'JFALCompControlPanel'][2]//div[contains(@id,'_0_3')]//*[2]"));

		System.out.println("Element value :++++ " + element);
		rightClickAndSelectMenuItem("Sort", location, popupMenuItemSort);
		//sleep(5);
		try {
		WebElement privateElement=driver.findElement(By.xpath("//div[@class='htmlImage'][contains(@style,'ok.gif')]"));
		isDisplayedThenClick(privateElement,"Element");
		rightClickAndSelectMenuItem("Details", privateElement, poupMenuItemDetails);//profilesTable
		sleep(5);
		WebElement cellElement = SeleniumWrappers.getTableDataWithCellElement(0, 0, driver);
		sleep(2);
		doubleClick(cellElement);
		sleep(2);
		updateRebateDetails();
		clickOkButton();
		sleep(3);
		clickSaveIcon();
		sleep(5);
		clickOkButtonIfMsgPopupAppears();
		verifyValidationResult("Record saved OK");
		}catch(Exception e) {
			e.getMessage();
		}
	}

	
	public void SelectBillingPlanAndFrequency(String frequency) {

		Common common = new Common(driver, test);
		ScrollToElement("Billing Details", "Billing Plan");

		if (frequency.equalsIgnoreCase("Bi-Weekly")) {
			chooseOptionFromDropdown("Billing Plan", "SEPA_DD -1 Days");
			chooseOptionFromDropdown("Billing Frequency", "Invoice Bi-Weekly");
			chooseOptionFromDropdown("Account Cycle", "Invoice Bi-Weekly");
		} else {
			chooseOptionFromDropdown("Billing Plan", "SEPA_DD -1 Days");
			chooseOptionFromDropdown("Billing Frequency", "Invoice Daily");
		}
		common.clickSaveIcon();
		sleep(5);
		verifyValidationResult("Record saved OK");
	}

	public String getCardNumber(String seperatorLabelName, String columnHeader) {
		List<WebElement> tableHeaders;
		String seperator = " ";
		String cardNo = "";
		chooseOptionFromDropdown("Card Status", "Normal Service");
		searchListTorch();
		sleep(5);

		try {
			seperator = splitStringAndGenerateXpath(seperatorLabelName);
			tableHeaders = driver.findElements(By.xpath("//div[@class='JFALSeparator']//div[" + seperator
					+ "]/preceding::div[@class='JFALCompControlPanel'][1]//div[@class='JViewport']/div[@class='JTableHeader']//div[@class='HeaderRenderer']"));
			int statusColIndex = SeleniumWrappers.getColumnNoForColumnHeader(columnHeader, tableHeaders);
			String s = "//div[@class='JFALSeparator']//div[" + seperator
					+ "]/preceding::div[@class='JFALCompControlPanel']/preceding::div[@class='FALTableCellEditor_StrikeThruField JTextComponent'][contains(@id,'_0_"
					+ statusColIndex + "')]//div[@class='htmlString']";
			// status = SeleniumWrappers.getTableCellValue(0, statusColIndex);
			WebElement cardNumber = driver.findElement(By.xpath(
					"//div[@class='JFALSeparator']//div[contains(text(),'Card') and contains(text(),'List')]//preceding::div[@class='JFALCompControlPanel'][1]//div[contains(@id,'_0_0')]"));
			System.out.println("statuscellValue::" + cardNumber);
			cardNo = cardNumber.getText();
		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
		return cardNo;
	}

	public int getProfileAndSelectAsDefault(String seperatorLabelName, String tableHeaderName, String expectedText) {
		int rowIndex = 0;
		List<WebElement> tableHeaders;
		List<WebElement> list;
		String seperator = " ";
		try {
			seperator = splitStringAndGenerateXpath(seperatorLabelName);
			tableHeaders = driver.findElements(By.xpath("//div[@class='JFALSeparator']//div[" + seperator
					+ "]/preceding::div[@class='JFALCompControlPanel'][1]//div[@class='JViewport']/div[@class='JTableHeader']//div[@class='HeaderRenderer']"));
			int colIndex = SeleniumWrappers.getColumnNoForColumnHeader(tableHeaderName, tableHeaders);
			System.out.println("Column Index" + colIndex);
			list = driver.findElements(By.xpath("//div[@class='JFALSeparator']//div[" + seperator
					+ "]//preceding::div[@class='JFALCompControlPanel'][1]//div[@class='FALTableCellEditor_StrikeThruField JTextComponent']"));

			int size = SeleniumWrappers.getTotalNumberOfRows(list, driver);
			System.out.println("Size" + size);

			for (int row = 0; row < size; row++) {
				rowIndex = row;
				WebElement element = driver.findElement(By.xpath("//div[@class='JFALSeparator']//div[" + seperator
						+ "]//preceding::div[@class='JFALCompControlPanel'][1]//div[@class='FALTableCellEditor_StrikeThruField JTextComponent'][contains(@id,'"
						+ "_" + row + "_" + colIndex + "')]//div[@class='htmlString']"));
				String actualText = element.getText();
				System.out.println("actual profile is:" + actualText);
				if (actualText.contains(expectedText)) {
					break;

				
				}
			}
		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
		return rowIndex;
	}

	public int getRowCount(String seperatorLabelName) {
		String seperator = " ";

		seperator = splitStringAndGenerateXpath(seperatorLabelName);

		String s = "//div[@class='JFALSeparator']//div[" + seperator
				+ "]//preceding::div[@class='JFALCompControlPanel'][1]//div[@class='FALTableCellEditor_StrikeThruField JTextComponent']";
		List<WebElement> list = driver.findElements(By.xpath("//div[@class='JFALSeparator']//div[" + seperator
				+ "]//preceding::div[@class='JFALCompControlPanel'][1]//div[@class='FALTableCellEditor_StrikeThruField JTextComponent']"));

		int rowCount = SeleniumWrappers.getTotalNumberOfRows(list, driver);
		System.out.println("Size" + rowCount);
		return rowCount;
	}

	// added by Rathna
	public int wfeGetRownumberAndCreateRebateProfile() {
		int privateRow = 1;
		sleep(5);
		chooseSubMenuFromLeftPanel("Customer Profiles", "Rebates");
		detailSearch();
		validateHeaderLabel("Rebates");

		// sort diescription
		sortDescriptionColumn();// this method added
		// Click(driver.findElement(By.xpath(
		// . "//div[@class='JFALSeparator']//div[contains(text(),'Rebate') and
		// contains(text(),'Profiles')]/preceding::div[@class='JFALCompControlPanel'][2]//div[contains(@id,'_0_2')]//div")),"click");

		doubleClick(driver.findElement(By.xpath(
				"//div[@class='JFALSeparator']//div[contains(text(),'Rebate') and contains(text(),'Profiles')]/preceding::div[@class='JFALCompControlPanel'][2]//div[contains(@id,'_0_2')]//div")));

		sleep(5);
		rightClick(rebateHeaderPopupTable);
		addIteminPopup();

		return privateRow;
	}

	public void sortDescriptionColumn() {
		try {
			Click(driver.findElement(By.xpath(
					"//div[@class='JFALSeparator']//div[contains(text(),'Rebate') and contains(text(),'Profiles')]/preceding::div[@class='JFALCompControlPanel'][2]//div[contains(@id,'_0_2')]//div")),
					"click");

			rightClick(driver.findElement(By.xpath(
					"//div[@class='JFALSeparator']//div[contains(text(),'Rebate') and contains(text(),'Profiles')]/preceding::div[@class='JFALCompControlPanel'][2]//div[contains(@id,'_0_2')]//div")));
			sleep(5);
			clickSortDescription();// added this newly
			sleep(5);
		} catch (Exception ex) {

			logFail("Sort not performed :" + ex.getMessage());
		}

	}

	public void wfeCreateRebateProfileWithRequiredRebateDetails(String cusNo, String effDate, String expiryDate) {
		chooseCustomerNoAndSearch(cusNo);
		Common common = new Common(driver, test);
		int rownum = wfeGetRownumberAndCreateRebateProfile();// this method added
		if (rownum != 0) {
			enterDetailsInRebateDetailsPopup("PCT All Sites - Net Off", effDate, expiryDate, " ", "02 - Fuels", "100",
					"15", "100", "123");
		} else {
			enterDetailsInRebateProfilePopup(effDate, expiryDate);
			enterDetailsInRebateDetailsPopup("PCT All Sites - Net Off", effDate, expiryDate, " ", "02 - Fuels", "100",
					"15", "100", "123");
		}
		clickOkButton();
		sleep(2);

		// select opt
		// rightClickAndOptInout("Rebate Profiles", "Private");
		// Click(driver.findElement(By.xpath(
		// "//div[@class='JFALSeparator']//div[contains(text(),'Rebate') and
		// contains(text(),'Profiles')]/preceding::div[@class='JFALCompControlPanel'][2]//div[contains(@id,'_0_2')]//div")),"click");

		rightClick(driver.findElement(By.xpath(
				"//div[@class='JFALSeparator']//div[contains(text(),'Rebate') and contains(text(),'Profiles')]/preceding::div[@class='JFALCompControlPanel'][2]//div[contains(@id,'_0_2')]//div")));

		sleep(5);

		// rightClickAndOptInout("Rebate Profiles", "Private");
		
	//	rightClickAndOptInout("Rebate Profiles", "Private");
		isDisplayedThenClick(poupMenuOptInOut, "opt in/Out");
		/*WebElement element=driver.findElement(By.xpath("//div[@class='JFALSeparator']//div[contains(text(),'Rebate') and contains(text(),'Profiles')]/preceding::div[@class='JFALCompControlPanel'][2]//div[contains(@id,'_0_2')]//div"));
		rightClickAndSelectMenuItem("Opt In/Out", element, poupMenuOptInOut);*/
		clickOkButtonIfMsgPopupAppears();

		// validateCheckBoxInTable("Rebate Profiles", "Opted Out");

		common.clickSaveIcon();
		common.checkRecordSaved();

	}

	public void undoCheboxOptedOut() {
		Common common = new Common(driver, test);
		sleep(5);
		/*
		 * int privateRow = validateCheckBoxInTable("Rebate Profiles", "Private");//
		 * returns 0 or -1: 0 indicates ehckbox selected, -1 indicates not selected
		 * System.out.println("Private Row Number ::" + privateRow); if (privateRow !=
		 * -1) //if (privateRow != 0) { scrollDownPage(); int rowSize =
		 * SeleniumWrappers.getTotalNumberOfRows(rebateProfilesTable, driver) - 1;
		 * System.out.println("Row Size:" + rowSize); Click(driver.findElement(By.xpath(
		 * "//div[@class='JFALSeparator']//div[contains(text(),'Rebate') and contains(text(),'Profiles')]/preceding::div[@class='JFALCompControlPanel'][2]//input[contains(@id,'_"
		 * + rowSize + "_3')]")),"Private profile"); WebElement
		 * element=driver.findElement(By.xpath(
		 * "//div[@class='JFALSeparator']//div[contains(text(),'Rebate') and contains(text(),'Profiles')]/preceding::div[@class='JFALCompControlPanel'][2]//input[contains(@id,'_"
		 * + rowSize + "_3')]")); rightClick(element); // Click(element, "Table Cell");
		 * rathna changed sleep(5); isDisplayedThenClick(poupMenuOptInOut,
		 * "opt in/Out");
		 */
		rightClick(driver.findElement(By.xpath(
				"//div[@class='JFALSeparator']//div[contains(text(),'Rebate') and contains(text(),'Profiles')]/preceding::div[@class='JFALCompControlPanel'][2]//div[contains(@id,'_0_2')]//div")));

		sleep(5);

		// rightClickAndOptInout("Rebate Profiles", "Private");
		isDisplayedThenClick(poupMenuOptInOut, "opt in/Out");
		clickOkButtonIfMsgPopupAppears();
		common.clickSaveIcon();
		common.checkRecordSaved();
		// }

	}
	/*
	 * updated by raxsana 02/11/2020
	 */
	public void setProfileAsDefault(String profileType) {

		int row = getProfileAndSelectAsDefault("Available Profiles", "Description", profileType);
		String element = driver.findElement(By.xpath(
				"//div[@class='JFALSeparator_1']//div[contains(text(),'Available') and contains(text(),'Profiles')]//preceding::div[contains(@id,'_0_0')]//div[@class='htmlImage']"))
				.getAttribute("style");
		if (element.contains("/ajaxswing/Light_docs/images/images/ok.gif")) {
			logInfo("Profile already selected");
		} else {
			rightClickAndSelectProfile("Available Profiles", row, "Description");
			sleep(5);
			//rightClickAndSelectMenuItem("Select Profile", cardReissueProfilesTable, selectProfile);
			validateCheckBoxInTable("Available Profiles", "Default");
		}

	}

	public void createCardFees() {

		rightClick(cardFeesTable);
		addIteminPopup();
		validatePopupHeaderText("Card Fee Profile");
		chooseARandomDropdownOption("Card Offer");
		chooseARandomDropdownOption("Card Product");
		clickOkButton();
		sleep(5);
	}

	public void SaveAndDeleteProfile() {
		Common common = new Common(driver, test);
		common.clickSaveIcon();
		common.verifyValidationResult("Record saved OK");
		rightClick(cardFeesTable);
		deleteIteminPopup();
		common.clickSaveIcon();
	}
	
	public void setCardFeeProfileAsDefalt(String profileType) {

		/*
		int row=getProfileAndSelectAsDefault("Available Profiles", "Description",profileType);
		rightClickAndSelectProfile("Available Profiles", row, "Description");
		sleep(5);
		validateCheckBoxInTable("Available Profiles", "Default");*/


		int row=getProfileAndSelectAsDefault("Available Profiles", "Description",profileType);
		getProfile("Available Profiles", row, "Description");
		sleep(5);
		rightClickAndSelectMenuItem("Select Profile", cardReissueProfilesTable, selectProfile);
		validateCheckBoxInTable("Available Profiles", "Default");
	}

	public void createPrivateCardFeeProfile(String cardFeeType,String clientCountry) {
		Common common = new Common(driver, test);
		validateTextInDescriptionInAvailableProfiles("Available Profiles", "Description");
		validateCheckBoxInTableAndDoubleClick("Available Profiles", "Private", "Description");
		enterValueInTextBox("Description", "Description", cardFeeType);// text param replaced with cardFeeType
		if (cardFeeType.equalsIgnoreCase("Annual Card Fee"))
		common.chooseOptionContainsFromDropdown("Card Fee 1", "Annual");
		else if (cardFeeType.equalsIgnoreCase("Monthly Card Fee"))
		common.chooseOptionContainsFromDropdown("Card Fee 1", "Monthly");
		else
		chooseARandomDropdownOption("Card Fee 1");
		// common.chooseOptionFromDropdown("Card Fee 1", "Monthly Vinci Fee 0.80");
		Click(okButton, "Ok Button");
		sleep(2);
		int rownum = getRowNumberForSelectProfile("Available Profiles", "Private");
		if (rownum > 0)
		logInfo(cardFeeType + " Profile is created successfully");
		else
		logFail(cardFeeType + " Profile is not created successfully");


		/*rightClickAndSelectProfile("Available Profiles", rownum, "Description");
		sleep(5);

		validateCheckBoxInTable("Available Profiles", "Default");
		sleep(5);
		validateNewValueAddedInTheTableList("Card Fees", "Card Fee Profile", cardFeeType);//text param replaced with cardFeeType
		*/ }



	public int validateTextInDescriptionInAvailableProfiles(String seperatorLabelName, String tableHeaderName) {
		// int countDefault = 0;
		int row = 0;
		String seperator = " ";
		int index = 1;
		if (seperatorLabelName.equals("Rebate Profiles")) {
			index = 2;
		}
		try {
			System.out.println("**************");
			seperator = splitStringAndGenerateXpath(seperatorLabelName);
			List<WebElement> tableHeaders = driver.findElements(By.xpath("//div[@class='JFALSeparator']//div["
					+ seperator + "]/preceding::div[@class='JFALCompControlPanel'][" + index
					+ "]//div[@class='JViewport']/div[@class='JTableHeader']//div[@class='HeaderRenderer']"));////div[@class='htmlString']
			System.out.println(tableHeaders);
			int colIndex = SeleniumWrappers.getColumnNoForColumnHeader(tableHeaderName, tableHeaders);
			System.out.println("ColIndex--->" + colIndex);
			List<WebElement> list = driver.findElements(By.xpath("//div[@class='JFALSeparator']//div[" + seperator
					+ "]/preceding::div[@class='JFALCompControlPanel'][" + index
					+ "]//div[@class='FALTableCellEditor_StrikeThruField JTextComponent']"));
			SeleniumWrappers.setTotalTableHeaders(tableHeaders.size());

			int size = SeleniumWrappers.getTotalNumberOfRows(list, driver);
			System.out.println("Size of table" + size);
			for (row = 0; row < size; row++) {
				WebElement element = driver.findElement(By.xpath("//div[@class='JFALSeparator']//div[" + seperator
						+ "]/preceding::div[@class='JFALCompControlPanel'][" + index
						+ "]//div[@class='FALTableCellEditor_StrikeThruField JTextComponent'][contains(@id,'_" + row
						+ "_" + colIndex + "')]//div[@class='htmlString']"));
				System.out.println("Rebate element ::" + element);
				String value = element.getText();
				System.out.println("Rebate value ::" + value);
				//if (value.contains(DescriptionValue)) {
				 //Click(element,"click");
				sleep(2);
				rightClick(element);
				sleep(5);
				Click(createPrivateProfile, "Select Profile");
				break;

			//}
		 }
			if (row == size) {
				row = 0;
				// row = -1;
				logInfo("No Rows in a table");
			}
		} catch (Exception e) {
			logFail(e.getMessage());
		}
		return row;
	}
	
	/**
	 * Update Contact details
	 */
	public void updatePrimaryContact() {
		validateHeaderLabel("Maintain Customer");
		chooseSubMenuFromLeftPanel("Maintain Customer", "Contacts");
		validateHeaderLabel("Contacts");
		sleep(5);
		
		WebElement cellElement = SeleniumWrappers.getTableDataWithCellElement(0, 0, driver);
		doubleClick(cellElement);
		sleep(2);
		//chooseOptionFromDropdown("Contact Type", "Renewal Address");
		chooseARandomDropdownOption("Contact Type");
		
		enterValueInTextBox("Details", "Name", fakerAPI().name().fullName());
		enterValueInTextBox("Contact", "Phone", "7638268448");
		enterValueInTextArea("Addresses/Contacts", "Physical Address", fakerAPI().address().fullAddress());
		sleep(5);
		clickOkButton();
		sleep(2);
		clickSaveIcon();
		sleep(5);
		verifyValidationResult("Record saved OK");

	}
	

}
