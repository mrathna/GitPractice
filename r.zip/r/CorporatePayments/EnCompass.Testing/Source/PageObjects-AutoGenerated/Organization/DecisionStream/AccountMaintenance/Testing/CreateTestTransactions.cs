using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using Common;
using Common.PageObjects;
using Common.ScenarioConfigurations;
using Common.Utility;

namespace EnCompass.Testing.Source.PageObjects.Organization.DecisionStream.AccountMaintenance.Testing 
{
	/// <summary>
	/// Auto-generated Page Model Class
	/// Navigation Paths: 
		/// [Organization Home]->Cards->Card Maintenance->Create Test Transactions
		/// </summary>
	[PageModel(@"/decisionStream/accountMaintenance/Testing/CreateTestTransactions.aspx")]
	public partial class CreateTestTransactions : EnCompassOrgPageModel 
	{
		public override string RelativeUrl => @"/decisionStream/accountMaintenance/Testing/CreateTestTransactions.aspx";
		public override string PageIdentifierXPath_Generated => @"//li[contains(@class, 'breadcrumb-item active')][text() = 'Create Test Transactions']";

		#region Navigation
				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Cards']")]
		private IWebElement _cards_CardMaintenance_CreateTestTransactions_Cards { get; set; }
		public void NavigateTo_Cards_CardMaintenance_CreateTestTransactions_Cards()
		{
			NavigateToMenuItem(_cards_CardMaintenance_CreateTestTransactions_Cards);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='History']")]
		private IWebElement _cards_CardMaintenance_CreateTestTransactions_History { get; set; }
		public void NavigateTo_Cards_CardMaintenance_CreateTestTransactions_History()
		{
			NavigateToMenuItem(_cards_CardMaintenance_CreateTestTransactions_History);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Activate Cards']")]
		private IWebElement _cards_CardMaintenance_CreateTestTransactions_ActivateCards { get; set; }
		public void NavigateTo_Cards_CardMaintenance_CreateTestTransactions_ActivateCards()
		{
			NavigateToMenuItem(_cards_CardMaintenance_CreateTestTransactions_ActivateCards);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Review Card Edits']")]
		private IWebElement _cards_CardMaintenance_CreateTestTransactions_ReviewCardEdits { get; set; }
		public void NavigateTo_Cards_CardMaintenance_CreateTestTransactions_ReviewCardEdits()
		{
			NavigateToMenuItem(_cards_CardMaintenance_CreateTestTransactions_ReviewCardEdits);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Create Test Cards']")]
		private IWebElement _cards_CardMaintenance_CreateTestTransactions_CreateTestCards { get; set; }
		public void NavigateTo_Cards_CardMaintenance_CreateTestTransactions_CreateTestCards()
		{
			NavigateToMenuItem(_cards_CardMaintenance_CreateTestTransactions_CreateTestCards);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Create Test Transactions']")]
		private IWebElement _cards_CardMaintenance_CreateTestTransactions_CreateTestTransactions { get; set; }
		public void NavigateTo_Cards_CardMaintenance_CreateTestTransactions_CreateTestTransactions()
		{
			NavigateToMenuItem(_cards_CardMaintenance_CreateTestTransactions_CreateTestTransactions);
		}

		
		private void NavigateToMenuItem(IWebElement element)
		{
			Driver.Url = element.GetAttribute("href");
		}
		#endregion

		#region Side Navigation

		[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//li[1]")]
		private IWebElement _testing_Cards { get; set; }
		public void NavigateTo_Cards()
		{
			NavigateToMenuItem(_testing_Cards);
		}

		[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//li[2]")]
		private IWebElement _testing_CreateCardTransactions { get; set; }
		public void NavigateTo_CreateCardTransactions()
		{
			NavigateToMenuItem(_testing_CreateCardTransactions);
		}

		[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//li[3]")]
		private IWebElement _testing_SingleUseAccounts { get; set; }
		public void NavigateTo_SingleUseAccounts()
		{
			NavigateToMenuItem(_testing_SingleUseAccounts);
		}

		[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//li[4]")]
		private IWebElement _testing_SingleUseAccountTransactions { get; set; }
		public void NavigateTo_SingleUseAccountTransactions()
		{
			NavigateToMenuItem(_testing_SingleUseAccountTransactions);
		}

		[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//li[5]")]
		private IWebElement _testing_CreditLimitUpdate { get; set; }
		public void NavigateTo_CreditLimitUpdate()
		{
			NavigateToMenuItem(_testing_CreditLimitUpdate);
		}

		[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//li[6]")]
		private IWebElement _testing_DailyExtractFiles { get; set; }
		public void NavigateTo_DailyExtractFiles()
		{
			NavigateToMenuItem(_testing_DailyExtractFiles);
		}

		#endregion

		public CreateTestTransactions(GlobalSettings settings) : base(settings) { }
	}  
}
