package com.framework.testcases.OLS.EMAP.Customer;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.EMAP.EMAPLoginPage;
import com.framework.pages.OLS.common.LoginPage;

public class ValidateForgotPasswordPageRW extends BaseTest {
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "Regression" })
	public void validateForgorPasswordPage(@Optional("SP") String clientCountry, @Optional("EMAP") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  TST-SC-76- OLS - Forgot password", "Validate the forgot password links");
		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		loginPage.validateLoginPageFooterLinks(clientName, "EMAP_URL");
		EMAPLoginPage emapLoginPage = new EMAPLoginPage(driver, test);
		emapLoginPage.clickForgotPasswordAndValidateTitle();
		emapLoginPage.validateClientLogo();
		emapLoginPage.enterForgotPasswordUserId();
		emapLoginPage.clickSubmitInForgotPassword();
		emapLoginPage.verifyTheSuccessMessage();
		//loginPage.Logout();
	}
}
