using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using Common;
using Common.PageObjects;
using Common.ScenarioConfigurations;
using Common.Utility;

namespace EnCompass.Testing.Source.PageObjects.SuperAdmin 
{
	/// <summary>
	/// Auto-generated Page Model Class
	/// Navigation Paths: 
		/// [Organization Home]->
		/// </summary>
	[PageModel(@"")]
	public partial class EnCompassSuperPageModel : EnCompassPageModel 
	{
		public override string RelativeUrl => @"";
		public override string PageIdentifierXPath_Generated => @"";

		#region Navigation
				[FindsBy(How = How.XPath, Using = @"//li[contains(@id, 'cluHistory')]/a")]
		private IWebElement _superAdminTools_CreditLimitUpdateHistory { get; set; }
		public void NavigateTo_SuperAdminTools_CreditLimitUpdateHistory()
		{
			NavigateToMenuItem(_superAdminTools_CreditLimitUpdateHistory);
		}

				[FindsBy(How = How.XPath, Using = @"//li[contains(@id, 'allReports')]/a")]
		private IWebElement _superAdminTools_Reports { get; set; }
		public void NavigateTo_SuperAdminTools_Reports()
		{
			NavigateToMenuItem(_superAdminTools_Reports);
		}

				[FindsBy(How = How.XPath, Using = @"//li[contains(@id, 'defDataLoad')]/a")]
		private IWebElement _superAdminTools_DefImportStatus { get; set; }
		public void NavigateTo_SuperAdminTools_DefImportStatus()
		{
			NavigateToMenuItem(_superAdminTools_DefImportStatus);
		}

				[FindsBy(How = How.XPath, Using = @"//li[contains(@id, 'disableCompany')]/a")]
		private IWebElement _superAdminTools_DisableOrganization { get; set; }
		public void NavigateTo_SuperAdminTools_DisableOrganization()
		{
			NavigateToMenuItem(_superAdminTools_DisableOrganization);
		}

				[FindsBy(How = How.XPath, Using = @"//li[contains(@id, 'createAuthorizations')]/a")]
		private IWebElement _superAdminTools_CreateAuthorizations { get; set; }
		public void NavigateTo_SuperAdminTools_CreateAuthorizations()
		{
			NavigateToMenuItem(_superAdminTools_CreateAuthorizations);
		}

				[FindsBy(How = How.XPath, Using = @"//li[contains(@id, 'renderEmail')]/a")]
		private IWebElement _superAdminTools_Messages { get; set; }
		public void NavigateTo_SuperAdminTools_Messages()
		{
			NavigateToMenuItem(_superAdminTools_Messages);
		}

				[FindsBy(How = How.XPath, Using = @"//li[contains(@id, 'jobTestAutomation')]/a")]
		private IWebElement _superAdminTools_JobTestAutomation { get; set; }
		public void NavigateTo_SuperAdminTools_JobTestAutomation()
		{
			NavigateToMenuItem(_superAdminTools_JobTestAutomation);
		}

				[FindsBy(How = How.XPath, Using = @"//li[contains(@id, 'manageBrands')]/a")]
		private IWebElement _superAdminTools_Branding { get; set; }
		public void NavigateTo_SuperAdminTools_Branding()
		{
			NavigateToMenuItem(_superAdminTools_Branding);
		}

				[FindsBy(How = How.XPath, Using = @"//li[contains(@id, 'manageOrgSettings')]/a")]
		private IWebElement _superAdminTools_OrganizationSettings { get; set; }
		public void NavigateTo_SuperAdminTools_OrganizationSettings()
		{
			NavigateToMenuItem(_superAdminTools_OrganizationSettings);
		}

				[FindsBy(How = How.XPath, Using = @"//li[contains(@id, 'userscripts')]/a")]
		private IWebElement _superAdminTools_UserScripts { get; set; }
		public void NavigateTo_SuperAdminTools_UserScripts()
		{
			NavigateToMenuItem(_superAdminTools_UserScripts);
		}

				[FindsBy(How = How.XPath, Using = @"//li[contains(@id, 'viewSettings')]/a")]
		private IWebElement _superAdminTools_EncompassSettings { get; set; }
		public void NavigateTo_SuperAdminTools_EncompassSettings()
		{
			NavigateToMenuItem(_superAdminTools_EncompassSettings);
		}

				[FindsBy(How = How.XPath, Using = @"//li[contains(@id, 'aocProdSupportTools')]/a")]
		private IWebElement _superAdminTools_ProductSupportTools { get; set; }
		public void NavigateTo_SuperAdminTools_ProductSupportTools()
		{
			NavigateToMenuItem(_superAdminTools_ProductSupportTools);
		}

				[FindsBy(How = How.XPath, Using = @"//li[contains(@id, 'fileUploads')]/a")]
		private IWebElement _general_FileUploads { get; set; }
		public void NavigateTo_General_FileUploads()
		{
			NavigateToMenuItem(_general_FileUploads);
		}

				[FindsBy(How = How.XPath, Using = @"//li[contains(@id, 'npe')]/a")]
		private IWebElement _general_NonPostedExceptions { get; set; }
		public void NavigateTo_General_NonPostedExceptions()
		{
			NavigateToMenuItem(_general_NonPostedExceptions);
		}

				[FindsBy(How = How.XPath, Using = @"//li[contains(@id, 'unmatchedReceipts')]/a")]
		private IWebElement _general_UnmatchedReceipts { get; set; }
		public void NavigateTo_General_UnmatchedReceipts()
		{
			NavigateToMenuItem(_general_UnmatchedReceipts);
		}

				[FindsBy(How = How.XPath, Using = @"//li[contains(@id, 'testing')]/a")]
		private IWebElement _general_Testing { get; set; }
		public void NavigateTo_General_Testing()
		{
			NavigateToMenuItem(_general_Testing);
		}

				[FindsBy(How = How.XPath, Using = @"//li[contains(@id, 'remitFiles')]/a")]
		private IWebElement _general_RemitFiles { get; set; }
		public void NavigateTo_General_RemitFiles()
		{
			NavigateToMenuItem(_general_RemitFiles);
		}

				[FindsBy(How = How.XPath, Using = @"//li[contains(@id, 'unpaidTransactions')]/a")]
		private IWebElement _general_UnpaidTransactions { get; set; }
		public void NavigateTo_General_UnpaidTransactions()
		{
			NavigateToMenuItem(_general_UnpaidTransactions);
		}

				[FindsBy(How = How.XPath, Using = @"//li[contains(@id, 'productSubProduct')]/a")]
		private IWebElement _general_Products { get; set; }
		public void NavigateTo_General_Products()
		{
			NavigateToMenuItem(_general_Products);
		}

				[FindsBy(How = How.XPath, Using = @"//li[contains(@id, 'curManagement')]/a")]
		private IWebElement _general_Currency { get; set; }
		public void NavigateTo_General_Currency()
		{
			NavigateToMenuItem(_general_Currency);
		}

				[FindsBy(How = How.XPath, Using = @"//li[contains(@id, 'DEFFiles')]/a")]
		private IWebElement _general_DefFiles { get; set; }
		public void NavigateTo_General_DefFiles()
		{
			NavigateToMenuItem(_general_DefFiles);
		}

				[FindsBy(How = How.XPath, Using = @"//li[contains(@id, 'accountMonitorGroup')]/a")]
		private IWebElement _general_AccountMonitorService { get; set; }
		public void NavigateTo_General_AccountMonitorService()
		{
			NavigateToMenuItem(_general_AccountMonitorService);
		}

				[FindsBy(How = How.XPath, Using = @"//li[contains(@id, 'manageSupers')]/a")]
		private IWebElement _usersAndOrganizations_AdminUsers { get; set; }
		public void NavigateTo_UsersAndOrganizations_AdminUsers()
		{
			NavigateToMenuItem(_usersAndOrganizations_AdminUsers);
		}

				[FindsBy(How = How.XPath, Using = @"//li[contains(@id, 'manageSubSuperOrgGroups')]/a")]
		private IWebElement _usersAndOrganizations_MultiOrganizations { get; set; }
		public void NavigateTo_UsersAndOrganizations_MultiOrganizations()
		{
			NavigateToMenuItem(_usersAndOrganizations_MultiOrganizations);
		}

				[FindsBy(How = How.XPath, Using = @"//li[contains(@id, 'managePrivileges')]/a")]
		private IWebElement _usersAndOrganizations_Privileges { get; set; }
		public void NavigateTo_UsersAndOrganizations_Privileges()
		{
			NavigateToMenuItem(_usersAndOrganizations_Privileges);
		}

				[FindsBy(How = How.XPath, Using = @"//li[contains(@id, 'manageOrgs')]/a")]
		private IWebElement _usersAndOrganizations_OrganizationSettings { get; set; }
		public void NavigateTo_UsersAndOrganizations_OrganizationSettings()
		{
			NavigateToMenuItem(_usersAndOrganizations_OrganizationSettings);
		}

				[FindsBy(How = How.XPath, Using = @"//li[contains(@id, 'manageOrgGroups')]/a")]
		private IWebElement _usersAndOrganizations_Organizations { get; set; }
		public void NavigateTo_UsersAndOrganizations_Organizations()
		{
			NavigateToMenuItem(_usersAndOrganizations_Organizations);
		}

				[FindsBy(How = How.XPath, Using = @"//li[contains(@id, 'manageSecuritySettings')]/a")]
		private IWebElement _usersAndOrganizations_SecuritySettings { get; set; }
		public void NavigateTo_UsersAndOrganizations_SecuritySettings()
		{
			NavigateToMenuItem(_usersAndOrganizations_SecuritySettings);
		}

				[FindsBy(How = How.XPath, Using = @"//li[contains(@id, 'manageIPRestrictions')]/a")]
		private IWebElement _usersAndOrganizations_IpAddressRestrictions { get; set; }
		public void NavigateTo_UsersAndOrganizations_IpAddressRestrictions()
		{
			NavigateToMenuItem(_usersAndOrganizations_IpAddressRestrictions);
		}

				[FindsBy(How = How.XPath, Using = @"//li[contains(@id, 'userEmulatorSearch')]/a")]
		private IWebElement _usersAndOrganizations_UserEmulator { get; set; }
		public void NavigateTo_UsersAndOrganizations_UserEmulator()
		{
			NavigateToMenuItem(_usersAndOrganizations_UserEmulator);
		}

				[FindsBy(How = How.XPath, Using = @"//li[contains(@id, 'purchaseLog')]/a")]
		private IWebElement _payables_PurchaseLogs { get; set; }
		public void NavigateTo_Payables_PurchaseLogs()
		{
			NavigateToMenuItem(_payables_PurchaseLogs);
		}

				[FindsBy(How = How.XPath, Using = @"//li[contains(@id, 'ap')]/a")]
		private IWebElement _payables_AccountsPayable { get; set; }
		public void NavigateTo_Payables_AccountsPayable()
		{
			NavigateToMenuItem(_payables_AccountsPayable);
		}

				[FindsBy(How = How.XPath, Using = @"//li[contains(@id, 'manageSugaPools')]/a")]
		private IWebElement _payables_Inventory { get; set; }
		public void NavigateTo_Payables_Inventory()
		{
			NavigateToMenuItem(_payables_Inventory);
		}

				[FindsBy(How = How.XPath, Using = @"//li[contains(@id, 'envelopePaymentexcEptions')]/a")]
		private IWebElement _payables_EnvelopePayments { get; set; }
		public void NavigateTo_Payables_EnvelopePayments()
		{
			NavigateToMenuItem(_payables_EnvelopePayments);
		}

				[FindsBy(How = How.XPath, Using = @"//li[contains(@id, 'globalMcc')]/a")]
		private IWebElement _merchantCategoryCodes_GlobalGroups { get; set; }
		public void NavigateTo_MerchantCategoryCodes_GlobalGroups()
		{
			NavigateToMenuItem(_merchantCategoryCodes_GlobalGroups);
		}

				[FindsBy(How = How.XPath, Using = @"//li[contains(@id, 'companyMcc')]/a")]
		private IWebElement _merchantCategoryCodes_CompanyGroups { get; set; }
		public void NavigateTo_MerchantCategoryCodes_CompanyGroups()
		{
			NavigateToMenuItem(_merchantCategoryCodes_CompanyGroups);
		}

				[FindsBy(How = How.XPath, Using = @"//a[contains(@class, 'dropdown-item')][contains(@id, 'lnkUserAccount')]")]
		private IWebElement _useraccount_ { get; set; }
		public void NavigateTo_Useraccount_()
		{
			NavigateToMenuItem(_useraccount_);
		}

		
		private void NavigateToMenuItem(IWebElement element)
		{
			Driver.Url = element.GetAttribute("href");
		}
		#endregion

		public EnCompassSuperPageModel(GlobalSettings settings) : base(settings) { }
	}  
}
