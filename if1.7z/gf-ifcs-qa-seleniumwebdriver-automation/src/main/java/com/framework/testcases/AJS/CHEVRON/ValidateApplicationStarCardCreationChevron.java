package com.framework.testcases.AJS.CHEVRON;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.ApplicationsPage;
import com.framework.pages.AJS.CardOfferClientLevelPage;
import com.framework.pages.AJS.ClientConfigPage;
import com.framework.pages.AJS.common.IFCSHomePage;
import com.framework.pages.AJS.common.IFCSLoginPage;
import com.framework.util.PropUtils;

public class ValidateApplicationStarCardCreationChevron extends BaseTest {


	@Parameters({"clientName"})
	@Test(groups = { "Regression" })
	public void createStarCardForSG(@Optional("CHEVRON") String clientName) {

		test = extent.createTest(clientName+ ": Pre-requisite Chevron setting calendar frequency for reports ",
				"Chevron setting calendar frequency for reports ");
		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);

		
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		ClientConfigPage clientConfigPage = new ClientConfigPage(driver, test);
		
		String clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		
		// Calling Functions
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		IFCSloginPage.login("IFCS_URL_CHEVRON", "IFCS_CHEVRON_USERNAME", "IFCS_CHEVRON_PASSWORD");

		IFCSHomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);
		IFCSHomePage.clickingCalendarSubMenu();
		clientConfigPage.creatingCalendar("Frequency","Merchant Statement Frequency");
		clientConfigPage.creatingCalendar("Frequency","Merchant Statement Frequency");
		
		
	}
	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test(groups = { "Regression" })
	public void createStarCardForSG(@Optional("SG") String clientCountry,
			@Optional("CHEVRON") String clientName, @Optional("APA") String cardType) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  Chevron SG StarCard",
				"TC001 Creating SG StarCard Staff application ");
		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);

		
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		ApplicationsPage IFCSApplicationsPage = new ApplicationsPage(driver, test);

		// Calling Functions
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, cardType);
		IFCSloginPage.login("IFCS_URL_CHEVRON", "IFCS_CHEVRON_USERNAME", "IFCS_CHEVRON_PASSWORD");
		
		//IFCSHomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);
		
		IFCSHomePage.gotoApplicationAndClickApplicationMenu();
		IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);
		IFCSApplicationsPage.applicationFilterOptionsForSG("applicationTypeValue", "statusValue");
		IFCSApplicationsPage.createNewApplicationForSG("name");
		//IFCSApplicationsPage.createCardOffersInApplication();
		IFCSApplicationsPage.addPricingInApplication();
		IFCSApplicationsPage.addCardControlsInApplication();
		IFCSApplicationsPage.addCardReissueProfiles();
		//IFCSApplicationsPage.validateAndCreateApplication();
		IFCSHomePage.exitIFCS();

	}
	
	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test(groups = { "Regression" })
	public void createStarCardFleetForTH(@Optional("TH") String clientCountry,
			@Optional("CHEVRON") String clientName, @Optional("APA") String cardType) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  Chevron TH StarCard Fleet",
				"TC001 Create New Application for TH StarCardFleet Customer ");
		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);

		
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		ApplicationsPage IFCSApplicationsPage = new ApplicationsPage(driver, test);

		// Calling Functions
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, cardType);
		IFCSloginPage.login("IFCS_URL_CHEVRON", "IFCS_CHEVRON_USERNAME", "IFCS_CHEVRON_PASSWORD");
		
		//IFCSHomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);
		
		IFCSHomePage.gotoApplicationAndClickApplicationMenu();
		IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);
		IFCSApplicationsPage.applicationFilterOptions(clientCountry+"StarCard - Fleet", "Approved");
		IFCSApplicationsPage.applicationCloneRecord();
		IFCSApplicationsPage.createCardOffersInApplication("StarCard","StarCard - Open");
		IFCSApplicationsPage.addPricingInApplication();
		IFCSApplicationsPage.addCardControlsInApplication();
		IFCSApplicationsPage.addCardReissueProfiles();
		IFCSApplicationsPage.validateAndCreateApplicationForClonedRecord();
		IFCSHomePage.exitIFCS();

	}
	
	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test(groups = { "Regression" })
	public void createStarCardStaffForTH(@Optional("TH") String clientCountry,
			@Optional("CHEVRON") String clientName, @Optional("APA") String cardType) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  Chevron TH StarCard Staff",
				"TC002 Create New Application for TH StarCardStaff Customer ");
		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);

		
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		ApplicationsPage IFCSApplicationsPage = new ApplicationsPage(driver, test);

		// Calling Functions
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, cardType);
		IFCSloginPage.login("IFCS_URL_CHEVRON", "IFCS_CHEVRON_USERNAME", "IFCS_CHEVRON_PASSWORD");
		
		//IFCSHomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);
		
		IFCSHomePage.gotoApplicationAndClickApplicationMenu();
		IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);
		IFCSApplicationsPage.applicationFilterOptions("TH StarCard - Staff", "Approved");
		IFCSApplicationsPage.applicationCloneRecord();
		IFCSApplicationsPage.createCardOffersInApplication("Personal","StarCard Staff");
		IFCSApplicationsPage.addPricingInApplication();
		IFCSApplicationsPage.addCardControlsInApplication();
		IFCSApplicationsPage.addCardReissueProfiles();
		//IFCSApplicationsPage.validateAndCreateApplication();
		IFCSApplicationsPage.validateAndCreateApplicationForClonedRecord();
		IFCSHomePage.exitIFCS();

	}
	
	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test(groups = { "Regression" })
	public void createStarCardFleetForPH(@Optional("PH") String clientCountry,
			@Optional("CHEVRON") String clientName, @Optional("APA") String cardType) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  Chevron PH StarCard Fleet",
				"Create New Application for StarCard - Fleet Customer");
		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);

		
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		ApplicationsPage IFCSApplicationsPage = new ApplicationsPage(driver, test);

		// Calling Functions
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, cardType);
		IFCSloginPage.login("IFCS_URL_CHEVRON", "IFCS_CHEVRON_USERNAME", "IFCS_CHEVRON_PASSWORD");
		
		//IFCSHomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);
		
		IFCSHomePage.gotoApplicationAndClickApplicationMenu();
		IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);
		IFCSApplicationsPage.applicationFilterOptions("PH StarCard - Fleet", "Approved");
		IFCSApplicationsPage.applicationCloneRecord();
		IFCSApplicationsPage.createCardOffersInApplication("StarCard","StarCard - Open");
		IFCSApplicationsPage.addPricingInApplication();
		//IFCSApplicationsPage.validateRebatesInApplication();
		IFCSApplicationsPage.addCardControlsInApplication();
		IFCSApplicationsPage.addCardReissueProfiles();
		IFCSApplicationsPage.validateAndCreateApplicationForClonedRecord();
		IFCSHomePage.exitIFCS();

	}
	
	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test(groups = { "Regression" })
	public void createStarCashCustomerForPH(@Optional("PH") String clientCountry,
			@Optional("CHEVRON") String clientName, @Optional("APA") String cardType) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  Chevron PH StarCash Customer",
				"Create New Application for StarCash-Chevron Customer");
		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);

		
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		ApplicationsPage IFCSApplicationsPage = new ApplicationsPage(driver, test);

		// Calling Functions
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, cardType);
		IFCSloginPage.login("IFCS_URL_CHEVRON", "IFCS_CHEVRON_USERNAME", "IFCS_CHEVRON_PASSWORD");

		IFCSHomePage.gotoApplicationAndClickApplicationMenu();
		IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);
		IFCSApplicationsPage.applicationFilterOptions("PH StarCash - Customer", "Approved");
		IFCSApplicationsPage.applicationCloneRecordForPHStarCash();
		IFCSApplicationsPage.createCardOffersInApplication("StarCash","StarCash - No initial value");
		//IFCSHomePage.gotoAccountAndClickAccountDetails();
		IFCSApplicationsPage.addPricingInApplication();
		//IFCSApplicationsPage.validateRebatesInApplication();
		IFCSApplicationsPage.addCardControlsInApplication();
		IFCSApplicationsPage.addCardReissueProfiles();
		IFCSApplicationsPage.validateAndCreateApplicationForClonedRecord();
		IFCSHomePage.gotoAccountAndClickAccountDetails();
		IFCSApplicationsPage.validateAccountDetailsForApplication();
		IFCSHomePage.exitIFCS();

	}
	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test(groups = { "Regression" })
	public void createStarCardFleetForPHCWTGovtCustomer(@Optional("PH") String clientCountry,
			@Optional("CHEVRON") String clientName, @Optional("APA") String cardType) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  Chevron PH StarCard Fleet CWT Govt Customer",
				"Create New CWT Government Customer ");
		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);

		
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		ApplicationsPage IFCSApplicationsPage = new ApplicationsPage(driver, test);

		// Calling Functions
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, cardType);
		IFCSloginPage.login("IFCS_URL_CHEVRON", "IFCS_CHEVRON_USERNAME", "IFCS_CHEVRON_PASSWORD");
		IFCSHomePage.gotoApplicationAndClickApplicationMenu();
		IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);
		IFCSApplicationsPage.applicationFilterOptions("PH StarCard - Fleet", "Approved");
		IFCSApplicationsPage.createNewApplicationForSG1("name");
		IFCSApplicationsPage.createCardOffersInApplication("StarCard","StarCard - Open");
		IFCSApplicationsPage.addPricingInApplication();
		IFCSApplicationsPage.addCardControlsInApplication();
		IFCSApplicationsPage.addCardReissueProfiles();
		//IFCSApplicationsPage.validateAndCreateApplication();
		IFCSHomePage.gotoAccountAndClickAccountDetails();
		IFCSApplicationsPage.addTaxDetailsForAccount("IFCS_CHEVRON_USERNAME");
		IFCSHomePage.exitIFCS();

	}
	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test(groups = { "Regression" })
	public void createStarCardFleetForPHCWTCustomer(@Optional("PH") String clientCountry,
			@Optional("CHEVRON") String clientName, @Optional("APA") String cardType) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  Chevron PH StarCard Fleet CWT Large Company Customer",
				"Create New CWT Large Company Customer");
		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);

		
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		ApplicationsPage IFCSApplicationsPage = new ApplicationsPage(driver, test);

		// Calling Functions
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, cardType);
		IFCSloginPage.login("IFCS_URL_CHEVRON", "IFCS_CHEVRON_USERNAME", "IFCS_CHEVRON_PASSWORD");
		IFCSHomePage.gotoApplicationAndClickApplicationMenu();
		IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);
		IFCSApplicationsPage.applicationFilterOptions("PH StarCard - Fleet", "Approved");
		IFCSApplicationsPage.createNewApplicationForPH("name");
		IFCSApplicationsPage.createCardOffersInApplication("StarCard","StarCard - Open");
		IFCSApplicationsPage.addPricingInApplication();
		IFCSApplicationsPage.addCardControlsInApplication();
		IFCSApplicationsPage.addCardReissueProfiles();
		//IFCSApplicationsPage.validateAndCreateApplication();
		IFCSHomePage.gotoAccountAndClickAccountDetails();
		IFCSApplicationsPage.addTaxDetailsForAccountStatusLargeCompany("IFCS_CHEVRON_USERNAME");
		IFCSHomePage.exitIFCS();

	}
	
	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test(groups = { "Regression" })
	public void createStarCardFleetForPHWVATGovtCustomer(@Optional("PH") String clientCountry,
			@Optional("CHEVRON") String clientName, @Optional("APA") String cardType) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  Chevron PH StarCard Fleet WVAT Government Customer",
				"Create New WVAT Government Customer");
		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);

		
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		ApplicationsPage IFCSApplicationsPage = new ApplicationsPage(driver, test);

		// Calling Functions
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, cardType);
		IFCSloginPage.login("IFCS_URL_CHEVRON", "IFCS_CHEVRON_USERNAME", "IFCS_CHEVRON_PASSWORD");
		IFCSHomePage.gotoApplicationAndClickApplicationMenu();
		IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);
		IFCSApplicationsPage.applicationFilterOptions("PH StarCard - Fleet", "Approved");
		IFCSApplicationsPage.createNewApplicationForPH("name");
		IFCSApplicationsPage.createCardOffersInApplication("StarCard","StarCard - Open");
		IFCSApplicationsPage.addPricingInApplication();
		IFCSApplicationsPage.addCardControlsInApplication();
		IFCSApplicationsPage.addCardReissueProfiles();
		//IFCSApplicationsPage.validateAndCreateApplication();
		IFCSHomePage.gotoAccountAndClickAccountDetails();
		IFCSApplicationsPage.addTaxDetailsForAccountStatusWVATGovt("IFCS_CHEVRON_USERNAME");
		IFCSHomePage.exitIFCS();
	}
    @Parameters({ "clientCountry", "clientName", "cardType" })
	@Test(groups = { "Regression" })
	public void createStarCard(@Optional("SG") String clientCountry,
			@Optional("CHEVRON") String clientName, @Optional("APA") String cardType) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  Chevron SG Card Products",
				"TC006 Embossing Rules Client Level ");
		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
        IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		
		// Calling Functions
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, cardType);
		IFCSloginPage.login("IFCS_URL_CHEVRON", "IFCS_CHEVRON_USERNAME", "IFCS_CHEVRON_PASSWORD");

		IFCSHomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);
				
		CardOfferClientLevelPage CardOfferClientLevelPage=new CardOfferClientLevelPage(driver,test);
		CardOfferClientLevelPage.chooseCardProductsFromClient();
		CardOfferClientLevelPage.validateCardProductValuesInClient();
		IFCSHomePage.exitIFCS();
	}
	
	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test( groups = { "Regression" })
	public void createStarCardInVersionNumberMaxLength(@Optional("SG") String clientCountry,
			@Optional("CHEVRON") String clientName, @Optional("APA") String cardType) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  Chevron SG Card Products",
				"TC009 Version Number Max Length Client Level SG");
		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
        IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		
		// Calling Functions
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, cardType);
		IFCSloginPage.login("IFCS_URL_CHEVRON", "IFCS_CHEVRON_USERNAME", "IFCS_CHEVRON_PASSWORD");

		IFCSHomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);
		CardOfferClientLevelPage CardOfferClientLevelPage=new CardOfferClientLevelPage(driver,test);
		CardOfferClientLevelPage.chooseCardProductsFromClient();
		CardOfferClientLevelPage.validateVersionNumberMaxLength();
		IFCSHomePage.exitIFCS();
}
	
}
