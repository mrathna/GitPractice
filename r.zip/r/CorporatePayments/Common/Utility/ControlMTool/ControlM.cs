﻿extern alias cpt;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using cpt.Newtonsoft.Json;
using cpt.Newtonsoft.Json.Linq;

namespace Common.Utility.ControlMTool
{
    public class ControlM
    {
		
		public string RunJob(string whichEnv, string smartFolderJobName)
		{
			// Log in First to get the TOKEN. 
			var login = Task.Run(() => HttpLoginClient(whichEnv.Trim()));
			login.Wait();

			// Retrieved the Token.
			var loginToken = JsonConvert.DeserializeObject<AuthorizationResponse>(login.Result).LoginToken;
			Debug.WriteLine("The retrieved login token is: " + loginToken);

			if (loginToken.Equals("NO_LOGIN_TOKEN", StringComparison.InvariantCultureIgnoreCase))
				return "Could Not Contact Server to get a Login Token.";

			// Run the specific Job.
			var submitJob = Task.Run(() => SubmitJob(whichEnv.Trim(), loginToken, smartFolderJobName));
			submitJob.Wait();

			var runId = JsonConvert.DeserializeObject<RunDetails>(submitJob.Result).JobRunId;
			var statusUrl = JsonConvert.DeserializeObject<RunDetails>(submitJob.Result).JobRunStatusURL;

			Debug.WriteLine("The RUN ID of the submitted job is: " + runId);
			Debug.WriteLine("The Status URL of the submitted job is: " + statusUrl);

			// Get the Second Level Details of the Job by posting the statusURL and then reading its response to get the status.
			var secondLevelOutput = Task.Run(() => GetURI(statusUrl));
			secondLevelOutput.Wait();

			var sLevelData = new Stage2RunDetails(secondLevelOutput.Result);

			// Assign the values of the Result to variables.
			//var s2JobId = JsonConvert.DeserializeObject<Stage2RunDetails>(secondLevelOutput.Result).SLJobId;


			var s2JobId = sLevelData.SLJobId;
			var s2FolderId = sLevelData.SLfolderId;
			var s2NumberOfRuns = (sLevelData.SLNumOfRuns);
			var s2JobName = (sLevelData.SLJobName);
			var s2Folder = (sLevelData.SLJobFolder);
			var s2JobType = (sLevelData.SLJobType);
			var s2JobStatus = (sLevelData.SLJobStatus);
			var s2Held = (sLevelData.SLJobHeld);
			var s2Deleted = (sLevelData.SLJobDeleteStatus);
			var s2StartTime = (sLevelData.SLJobStartTime);
			var s2EndTime = (sLevelData.SLJobEndTime);
			var s2AnyOutput = (sLevelData.SLOutputURI);
			var s2JobLogURI = (sLevelData.SLLogURI);

			int x = 0;
			do
			{
				Thread.Sleep(TimeSpan.FromSeconds(15));
				secondLevelOutput = Task.Run(() => GetURI(statusUrl));
				secondLevelOutput.Wait();

				sLevelData = new Stage2RunDetails(secondLevelOutput.Result);
				s2JobStatus = (sLevelData.SLJobStatus);
				Debug.WriteLine($"\nSleeping for 15 seconds before checking the Job status. Loop #: {x+1}");
			} while (!s2JobStatus.ToString().Equals("Ended Ok", StringComparison.InvariantCultureIgnoreCase) && x++ < 30);

			return s2JobStatus.ToString();
		}

		public static async Task<string> HttpLoginClient(string whichEnv)
		{
			Debug.WriteLine("\nThis method uses HttpClient object for all communication.");
			
			//Setting the Singleton Class ENVIRONMENT from which other details like BaseUrl, AgentName etc are determined.
			Options.Instance.Environment = whichEnv.ToString().Trim();

			var serverBaseUrl = Options.Instance.ServerBaseUrl;
			var agent = Options.Instance.AgentName;

			var hClient = new HttpClient();
			hClient.BaseAddress = new Uri(serverBaseUrl);


			ServicePointManager.ServerCertificateValidationCallback += (message, cert, chain, errors) => { return true; };

			var jsonCreds = cpt.Newtonsoft.Json.JsonConvert.SerializeObject(Options.Instance.Credentials);

			var response = await hClient.PostAsync(@"session/login", new StringContent(jsonCreds, Encoding.UTF8, "application/json"));

			if (response.IsSuccessStatusCode)
			{
				string contentReturned = await response.Content.ReadAsStringAsync();
				return contentReturned;
			}
			else
			{
				return "NO_LOGIN_TOKEN";
			}
		}

		public static async Task<string> SubmitJob(string env, string token, string smartFolderName)
		{
			Debug.WriteLine("\nThis method submits the actual job based on the chosen Smart Folder name.");

			//Setting the Singleton Class ENVIRONMENT from which other details like BaseUrl, AgentName etc are determined.
			Options.Instance.Environment = env.ToString().Trim();

			var serverBaseUrl = Options.Instance.ServerBaseUrl;
			var agent = Options.Instance.AgentName;
			var customer = GlobalSettings.FI.ToString().Trim().ToUpper();

			var hClient = new HttpClient();
			hClient.BaseAddress = new Uri(serverBaseUrl);
			ServicePointManager.ServerCertificateValidationCallback += (message, cert, chain, errors) => { return true; };
			hClient.DefaultRequestHeaders.Add("Authorization", "Bearer" + token);

			// Read the standard template file and replace the values in it, before submitting it.
			//var prepareJobContent = JobContentJson(smartFolderName);

			// Putting the preparation of JSON here itself instead of having separate method. Its not working as intended as the control from the method is not returning here.
			string jsonJobTemplatePath = PathHelper.GetAbsolutePathRelativeToProjectPath(GlobalSettings.TemplateRelativePath) + "ControlMJobSubmit.json";
			//var jsonJobTemplatePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, @"Templates\ControlMJobSubmit.json");
			Debug.WriteLine("\nThe path to the current directory where TestJTAClient is located is: " + jsonJobTemplatePath);

			dynamic deserializeObject = null;
			using (var r = new StreamReader(jsonJobTemplatePath))
			{
				var content = r.ReadToEnd();
				deserializeObject = JObject.Parse(content);
			}

			switch (smartFolderName.ToString().ToLowerInvariant().Trim())
			{
				// CASE FOR ANY EXTRA WORK TO BE DONE FOR SOME JOBS.
				//case "aggregate test batch":
				//break;

				default:
					deserializeObject.ctm = Options.Instance.AgentName.Trim();
					deserializeObject.createDuplicate = false;
					deserializeObject.folder = customer+"."+smartFolderName;
					deserializeObject.hold = false;
					deserializeObject.ignoreCriteria = true;
					deserializeObject.independentFlow = false;
					deserializeObject.orderintofolder = "OrderID";
					deserializeObject.orderDate = System.DateTime.Now.ToString("yyyyMMdd");
					deserializeObject.variables[0].JMJobName = customer + "." + smartFolderName;
					break;
			}

			var response = await hClient.PostAsync(@"run/order", new StringContent(
				cpt.Newtonsoft.Json.JsonConvert.SerializeObject(deserializeObject)
				, Encoding.UTF8, "application/json"));

			if (response.IsSuccessStatusCode)
			{
				string runId = await response.Content.ReadAsStringAsync();
				return runId;
			}
			else
			{
				return "ERROR: THE JOB WAS NOT SUBMITTED CORRECTLY OR THERE WAS NO PROPER RESPONSE.";
			}
		}

		public static async Task<string> GetURI(string uri)
		{
			Debug.WriteLine("\nThis method does a POST to the given URI.");
			var hClient = new HttpClient();

			var response = await hClient.GetAsync(uri.ToString().Trim());

			if (response.IsSuccessStatusCode)
			{
				string sLevelOutput = await response.Content.ReadAsStringAsync();
				return sLevelOutput;
			}
			else
			{
				return "ERROR: The Second Level Run did not happen correctly.";
			}
		}

	}
}
