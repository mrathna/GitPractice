package com.framework.testcases.AJS.BP.Interface;

import javax.xml.transform.TransformerException;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.common.IFCSHomePage;
import com.framework.pages.AJS.common.IFCSLoginPage;

public class ValidateCreateAndUpdateLocationTestCase extends BaseTest{
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "Smoke","BusinessFlow" })
	public void validateCreateAndUpdateLocationUsingCA10TestCase(@Optional("AU") String clientCountry,
			@Optional("BP") String clientName) throws TransformerException {
		//In Progress
		test = extent.createTest(clientName+ ":" +clientCountry+"  Merch_AU_001_Create location from CA10 UpdateLocation",
				"Create/Update location from CA10 file");
		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		// Calling Functions
		IFCSloginPage.login("IFCS_URL_BP", "IFCS_BP_USERNAME", "IFCS_BP_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry,"");
		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		//commoninterface.funcFetchLastSeqNoFromWithIFCSDB(configProp, "BP Australia Pty Ltd", "CA10 - Update Location Details");
		//ifcsCommonPage.updateValuesAndUploadToXMLFileGeneric(updatelocationca10Prop, "BP Australia Pty Ltd","UpdateLocation_AU_0003.xml");
		
	}
}
