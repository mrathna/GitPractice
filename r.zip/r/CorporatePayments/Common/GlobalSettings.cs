﻿using AventStack.ExtentReports;
using Common.PageObjects;
using Common.ScenarioConfigurations;
using Common.Utility;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using TechTalk.SpecFlow;

namespace Common
{
	public enum DataSourceType { None, Taco }

	public class GlobalSettings
	{

		#region Private member vars

		private IWebDriver _encompassWebDriver;
		private ICollection<StepException> _scenarioErrors;
		private static string _screenshotFolder;
		private static string _screencastFolder;
		private static string _uiReportPath;
		private static string _reportConfigPath;
		private PageModel _currentModel;
		private static string _chromeBinaryPath;
        private static string _firefoxBinaryPath;
        private static string _winappDriverPath;
        private static string _awsRegion;
		private static string _awsAccessKeyId;
		private static string _awsAccessKey;
		private static string _browser;
		private static string _proxyServer;
		private static string _apiReportPath;
		private static string _environment;
		private IEnumerable<PageModelIndex> _pageModelCatalog;
		private ExtentTest _extentTest;
		private static string _superAdminUser;
		private static string _superAdminPwd;
		private static string _superOrgId;
		private static string _baseEncompassUrl;
		private static string _baseEncompassServiceUrl;
		private string _createdOrgName;
		private static string _baseTemplatePath;
		private static string _fi;
		private static bool _delOrgs;
		private static string _killAllProcess;
		private string _reportWizardFocus;
		private static string _daysToScheduleOrgsForDeletion;
		private static string _superUserCount;
		private static string _newSuperUser;
		private static string _newSuperPwd;
		private static string _newSuperEmail;
		private static string _mobileDeviceName;
		private static string _mobileOSVersion;
		private static string _mobileOS;
		private static string _deviceType;
		private static string _browserStackKey;
		private static string _browserStackUser;
		private static string _browserStackHubUrl;
		private static string _bambooPlanKey;
		private static string _bambooBuildResultKey;
		private static string _browserStackApiUrl;
		private static string _tessaractDataPath;
		private static string _tessaractDllPath;

		#endregion


		public GlobalSettings()
		{
			ScenarioConfiguration = new StandardScenarioConfiguration();
			InitializePageModelCatalog();
			ScenarioErrors = new List<StepException>();
		}

		#region Public member vars

		public ScenarioContext Scenario { get; set; }
		public FeatureContext Feature { get; set; }

		public enum Browsers
		{
			CHROME,
			FIREFOX,
			IE,
			MOBILECHROMELOCAL
		};

		public enum MobileBrowsers
		{
			CHROME,
			SAFARI
		};

		public enum MobileOSList
		{
			ANDROID,
			IOS
		};

		public enum Device
		{
			MOBILE,
			DESKTOP
		};

		public string ReportWizardFocus
		{
			get { return _reportWizardFocus; }
			set { _reportWizardFocus = value; }
		}

		public string CreatedOrgName
		{
			get { return _createdOrgName; }
			set
			{
				_createdOrgName = value;
				AllOrgsCreated.Add(_createdOrgName);
			}
		}

		public string CeatedOrgId { get; set; }
		public string ProductType { get; set; }
		public string ProductName { get; set; }
		public string CreatedOrgCompanyNumber { get; set; }
		public string CeatedOrgBankNumber { get; set; }
		public string OrgLevelUserName { get; set; }
		public string OrgLevelUserPwd { get; set; }
		public string OrgLevelUserSecurityCode { get; set; }
		public bool IsEmulationModeOn { get; set; }
		public string NameOnCard { get; set; }
		public string CreditCardNumber { get; set; }
		public string SSN { get; set; }
		public List<string> AllOrgsCreated { get; set; } = new List<string>();
		public string MLogId { get; set; }
		public string PLogId { get; set; }
		public string MerchantName { get; set; }

		public string Processor { get; set; }

		public Queue<string> MLogIdList { get; set; } = new Queue<string>();
		public Queue<string> TrxDataLoadList { get; set; } = new Queue<string>();

		public DateTime EffectiveDateFrom { get; set; }

		public DateTime EffectiveDateTo { get; set; }
		public bool? EditClientProfile { get; set; }

		public int AvailableCardsOnSUGAPool { get; set; }

		public IWebDriver EnCompassWebDriver
		{
			get { return _encompassWebDriver; }
			set { _encompassWebDriver = value; }
		}

		public ExtentTest EnCompassExtentTest
		{
			get { return _extentTest; }
			set { _extentTest = value; }
		}

		#endregion

		/// <summary>
		/// Dictionary of all Mlog Ids created by API suite which needs to be
		/// Cancelled and Closed as a part of Scenario Cleanup, along with a bool
		/// value indicating if it has been Closed or not.
		/// </summary>
		public Dictionary<string, bool> Api_MlogIds_ToBeClosed = new Dictionary<string, bool>();

		/// <summary>
		/// Path to "tessdata" folder as specified in app config
		/// </summary>
		public static string TessaractDataPath
		{
			get
			{
				if (string.IsNullOrWhiteSpace(_tessaractDataPath))
				{
					_tessaractDataPath = ConfigurationManager.AppSettings["TessData.path"];
				}
				return _tessaractDataPath;
			}
		}

		/// <summary>
		/// Path to Tessaract DLL as specified in appconfig
		/// </summary>
		public static string TessaractDllPath
		{
			get
			{
				if (string.IsNullOrWhiteSpace(_tessaractDllPath))
				{
					_tessaractDllPath = ConfigurationManager.AppSettings["TessaractDll.path"];
				}
				return _tessaractDllPath;
			}
		}

		public static string REG_SS_PREFIX = "RegAUT_";
		public static string GetSecretServerUsernameForRegression
        {

			get
			{
				return REG_SS_PREFIX + FI + "_" + Environment.ToUpperInvariant();
			}
		}

		public static bool KillProcessPostExecution
		{
			get
			{
				try
				{
					_killAllProcess = System.Environment.GetEnvironmentVariable("bamboo_KillProcessPostExecution").ToUpperInvariant();

					if (string.IsNullOrWhiteSpace(_killAllProcess))
					{
						_killAllProcess = ConfigurationManager.AppSettings["KillAllProcess"];
					}
				}
				catch (Exception)
				{
					_killAllProcess = ConfigurationManager.AppSettings["KillAllProcess"].ToUpperInvariant();
				}

				if (_killAllProcess.Equals("ON"))
					return true;
				else
					return false;
			}
		}

		#region Binary/Folder Paths From App Config

		public static string ScreenshotFolder
		{
			get
			{
				if (string.IsNullOrWhiteSpace(_screenshotFolder))
				{
					_screenshotFolder = ConfigurationManager.AppSettings["Screenshots.Path"];
				}
				return _screenshotFolder;
			}
			set
			{
				_screenshotFolder = value;
			}
		}


		public static string ScreencastFolder
		{
			get
			{
				if (string.IsNullOrWhiteSpace(_screenshotFolder))
				{
					_screencastFolder = ConfigurationManager.AppSettings["Screencasts.Path"];
				}
				return _screencastFolder;
			}
			set
			{
				_screencastFolder = value;
			}
		}

		public static string UiReportPath
		{
			get
			{
				if (string.IsNullOrWhiteSpace(_uiReportPath))
				{
					_uiReportPath = PathHelper.GetAbsolutePathRelativeToProjectPath(ConfigurationManager.AppSettings["UiExtentReport.Path"]);
				}
				return _uiReportPath;
			}
			set
			{
				_uiReportPath = PathHelper.GetAbsolutePathRelativeToProjectPath(value);
			}
		}

		public static string ApiReportPath
		{
			get
			{
				if (string.IsNullOrWhiteSpace(_apiReportPath))
				{
					_apiReportPath = PathHelper.GetAbsolutePathRelativeToProjectPath(ConfigurationManager.AppSettings["ApiExtentReport.Path"]);
				}
				return _apiReportPath;
			}
			set
			{
				_apiReportPath = PathHelper.GetAbsolutePathRelativeToProjectPath(value);
			}
		}

		public static string ReportConfigPath
		{
			get
			{
				if (string.IsNullOrWhiteSpace(_reportConfigPath))
				{
					_reportConfigPath = PathHelper.GetAbsolutePathRelativeToProjectPath(ConfigurationManager.AppSettings["ExtentReportsConfig.Path"]);
				}
				return _reportConfigPath;
			}
			set
			{
				_reportConfigPath = PathHelper.GetAbsolutePathRelativeToProjectPath(value);
			}
		}

		public static string ChromeBinaryPath
		{
			get
			{
				if (string.IsNullOrWhiteSpace(_chromeBinaryPath))
				{
					_chromeBinaryPath = ConfigurationManager.AppSettings["Chrome.binary.path"];
				}
				return _chromeBinaryPath;
			}
			set
			{
				_chromeBinaryPath = value;
			}
		}

        public static string FirefoxBinaryPath
		{
			get
			{
				if (string.IsNullOrWhiteSpace(_firefoxBinaryPath))
				{
					_firefoxBinaryPath = ConfigurationManager.AppSettings["Firefox.binary.path"];
				}
				return _firefoxBinaryPath;
			}
			set
			{
				_firefoxBinaryPath = value;
			}
		}

        /// <summary>
        /// to retireve the path to the winappdriver.exe 
        /// </summary>
        public static string WinAppDriverPath
        {
            get
            {
                if (string.IsNullOrWhiteSpace(_winappDriverPath))
                {
                    _winappDriverPath = ConfigurationManager.AppSettings["WinApp.exe.path"];
                }
                return _winappDriverPath;
            }
            set
            {
                _winappDriverPath = value;
            }
        }

        public static string TemplateRelativePath
		{
			get
			{
				if (string.IsNullOrWhiteSpace(_baseTemplatePath))
				{
					_baseTemplatePath = ConfigurationManager.AppSettings["TemplateRelativePath"];
				}
				return _baseTemplatePath;
			}
			set
			{
				_baseTemplatePath = value;
			}
		}

		#endregion


		public static string Browser
		{
			get
			{
				try
				{
					{
						_browser = System.Environment.GetEnvironmentVariable("bamboo_Browser").ToUpperInvariant();
						if (string.IsNullOrWhiteSpace(_browser))
						{
							_browser = ConfigurationManager.AppSettings["Browser"].ToUpperInvariant();
						}
					}
				}
				catch (Exception)
				{
					_browser = ConfigurationManager.AppSettings["Browser"].ToUpperInvariant();
				}
				return _browser;
			}
			set
			{
				_browser = value;
			}
		}

		#region AWS

		public static string AWSAccessKeyId
		{
			get
			{
				_awsAccessKeyId = System.Environment.GetEnvironmentVariable("bamboo_AWSAccessKeyId");
				//_awsAccessKeyId = System.Environment.GetEnvironmentVariable("AWSAccessKeyId");
				if (string.IsNullOrWhiteSpace(_awsAccessKeyId))
				{
					_awsAccessKeyId = ConfigurationManager.AppSettings["AWSAccessKeyId"];

				}

				return _awsAccessKeyId;
			}
			set
			{
				_awsAccessKeyId = value;
			}
		}

		public static string AWSAccessKey
		{
			get
			{
				_awsAccessKey = System.Environment.GetEnvironmentVariable("bamboo_AWSAccessKey");
				//_awsAccessKey = System.Environment.GetEnvironmentVariable("AWSAccessKey");
				if (string.IsNullOrWhiteSpace(_awsAccessKey))
				{
					_awsAccessKey = ConfigurationManager.AppSettings["AWSAccessKey"];

				}

				return _awsAccessKey;
			}
			set
			{
				_awsAccessKey = value;
			}
		}

		public static string AWSRegion
		{
			get
			{
				_awsRegion = System.Environment.GetEnvironmentVariable("bamboo_AWSRegion");
				//_awsRegion = System.Environment.GetEnvironmentVariable("AWSRegion");
				if (string.IsNullOrWhiteSpace(_awsRegion))
				{
					_awsRegion = ConfigurationManager.AppSettings["AWSRegion"];

				}

				return _awsRegion;
			}
			set
			{
				_awsRegion = value;
			}
		}

		#endregion

		public static string Proxy
		{
			get
			{
				if (string.IsNullOrWhiteSpace(_proxyServer))
				{
					_proxyServer = ConfigurationManager.AppSettings["Proxy"];
				}
				return _proxyServer;
			}
			set
			{
				_proxyServer = value;
			}
		}

		public static string FI
		{
			get
			{
				try
				{
					_fi = System.Environment.GetEnvironmentVariable("bamboo_FI").ToUpperInvariant();
					if (string.IsNullOrWhiteSpace(_fi))
					{
						_fi = ConfigurationManager.AppSettings["Customer"].ToUpperInvariant();
					}
				}
				catch (Exception)
				{
					_fi = ConfigurationManager.AppSettings["Customer"].ToUpperInvariant();
				}
				return _fi;
			}
			set
			{
				_fi = value;
			}
		}

		public static string Environment
		{
			get
			{
				try
				{
					_environment = System.Environment.GetEnvironmentVariable("bamboo_Environment").ToUpperInvariant();

					if (string.IsNullOrWhiteSpace(_environment))
					{
						_environment = ConfigurationManager.AppSettings["Environment"];
					}
				}
				catch (Exception)
				{
					_environment = ConfigurationManager.AppSettings["Environment"].ToUpperInvariant();
				}
				return _environment.ToLower();
			}
			set
			{
				_environment = value;
			}
		}		

		#region Super Admin User Log In

		public static string SuperAdminUser
		{
			get
			{
				// Read the value to return only if the static string has not be set before
				//  else return the existing value set. (This should be a one time read for the entire test suite execution)
				if (String.IsNullOrEmpty(_superAdminUser))
				{
					try
					{
						_fi = _superAdminUser = System.Environment.GetEnvironmentVariable("bamboo_SuperAdminUser");
						if (string.IsNullOrWhiteSpace(_superAdminUser))
						{
							_superAdminUser = ConfigurationManager.AppSettings["SuperAdminUser"];
						}
					}
					catch (Exception)
					{
						_superAdminUser = ConfigurationManager.AppSettings["SuperAdminUser"];
					}
				}

				return _superAdminUser;
			}
			set
			{
				_superAdminUser = value;
			}
		}

		public static string SuperAdminPwd
		{
			get
			{
				// Read the value to return only if the static string has not be set before
				//  else return the existing value set. (This should be a one time read for the entire test suite execution)
				if (String.IsNullOrEmpty(_superAdminPwd))
				{
					try
					{
						_superAdminPwd = System.Environment.GetEnvironmentVariable("bamboo_SuperAdminPassword");
						if (string.IsNullOrWhiteSpace(_superAdminPwd))
						{
							_superAdminPwd = ConfigurationManager.AppSettings["SuperAdminPwd"];
						}
					}
					catch (Exception)
					{
						_superAdminPwd = ConfigurationManager.AppSettings["SuperAdminPwd"];
					}
				}

				return _superAdminPwd;
			}
			set
			{
				_superAdminPwd = value;
			}
		}

		public static string SuperOrgId
		{
			get
			{
				// Read the value to return only if the static string has not be set before
				//  else return the existing value set. (This should be a one time read for the entire test suite execution)
				if (String.IsNullOrEmpty(_superOrgId))
				{
					try
					{
						_superOrgId = System.Environment.GetEnvironmentVariable("bamboo_SuperOrgId");
						if (string.IsNullOrWhiteSpace(_superOrgId))
						{
							_superOrgId = ConfigurationManager.AppSettings["SuperOrgId"];
						}
					}
					catch (Exception)
					{
						_superOrgId = ConfigurationManager.AppSettings["SuperOrgId"];
					}
				}
				return _superOrgId;
			}
			set
			{
				_superOrgId = value;
			}
		}

		#endregion

		#region Super User Related

		public static string SuperUserCount
		{
			get
			{
				// Read the value to return only if the static string has not be set before
				//  else return the existing value set. (This should be a one time read for the entire test suite execution)
				if (String.IsNullOrEmpty(_superUserCount))
				{
					try
					{
						_fi = _superUserCount = System.Environment.GetEnvironmentVariable("bamboo_SuperUserCount");
						if (string.IsNullOrWhiteSpace(_superUserCount))
						{
							_superUserCount = ConfigurationManager.AppSettings["SuperUserCount"];
						}
					}
					catch (Exception)
					{
						_superUserCount = ConfigurationManager.AppSettings["SuperUserCount"];
					}
				}

				return _superUserCount;
			}
			set
			{
				_superUserCount = value;
			}
		}

		public static string NewSuperUser
		{
			get
			{
				// Read the value to return only if the static string has not be set before
				//  else return the existing value set. (This should be a one time read for the entire test suite execution)
				if (String.IsNullOrEmpty(_newSuperUser))
				{
					try
					{
						_fi = _newSuperUser = System.Environment.GetEnvironmentVariable("bamboo_NewSuperUser");
						if (string.IsNullOrWhiteSpace(_newSuperUser))
						{
							_newSuperUser = ConfigurationManager.AppSettings["NewSuperUser"];
						}
					}
					catch (Exception)
					{
						_newSuperUser = ConfigurationManager.AppSettings["NewSuperUser"];
					}
				}

				return _newSuperUser;
			}
			set
			{
				_newSuperUser = value;
			}
		}

		public static string NewSuperPwd
		{
			get
			{
				// Read the value to return only if the static string has not be set before
				//  else return the existing value set. (This should be a one time read for the entire test suite execution)
				if (String.IsNullOrEmpty(_newSuperPwd))
				{
					try
					{
						_newSuperPwd = System.Environment.GetEnvironmentVariable("bamboo_NewSuperPassword");
						if (string.IsNullOrWhiteSpace(_newSuperPwd))
						{
							_newSuperPwd = ConfigurationManager.AppSettings["NewSuperPwd"];
						}
					}
					catch (Exception)
					{
						_newSuperPwd = ConfigurationManager.AppSettings["NewSuperPwd"];
					}
				}

				return _newSuperPwd;
			}
			set
			{
				_newSuperPwd = value;
			}
		}
		public static string NewSuperEmail
		{
			get
			{
				// Read the value to return only if the static string has not be set before
				//  else return the existing value set. (This should be a one time read for the entire test suite execution)
				if (String.IsNullOrEmpty(_newSuperEmail))
				{
					try
					{
						_newSuperEmail = System.Environment.GetEnvironmentVariable("bamboo_NewSuperEmail");
						if (string.IsNullOrWhiteSpace(_newSuperEmail))
						{
							_newSuperEmail = ConfigurationManager.AppSettings["NewSuperEmail"];
						}
					}
					catch (Exception)
					{
						_newSuperEmail = ConfigurationManager.AppSettings["NewSuperEmail"];
					}
				}

				return _newSuperEmail;
			}
			set
			{
				_newSuperEmail = value;
			}
		}

		#endregion

		#region Org Deletion

		public static bool AreOrgsToBeDeleted
		{
			get
			{
				try
				{
					string val = System.Environment.GetEnvironmentVariable("bamboo_DeleteOrgs");
					_delOrgs = (val.Equals("No", StringComparison.InvariantCultureIgnoreCase)) ? false : true;
					if (string.IsNullOrWhiteSpace(val))
					{
						_delOrgs = true;
					}
				}
				catch (Exception)
				{
					_delOrgs = true;
				}
				return _delOrgs;
			}
			set
			{
				_delOrgs = value;
			}
		}
		/// <summary>
		/// Get the Days to schedule the orgs for deletion while creating test org.
		/// If not found set it to 1 by default
		/// </summary>
		public static string DaysBeforeOrgDeletion
		{
			get
			{
				try
				{
					_daysToScheduleOrgsForDeletion = System.Environment.GetEnvironmentVariable("bamboo_DaysBeforeOrgDeletion").ToUpperInvariant();
					if (string.IsNullOrWhiteSpace(_daysToScheduleOrgsForDeletion))
					{
						_daysToScheduleOrgsForDeletion = "1";
					}
				}
				catch (Exception)
				{
					_daysToScheduleOrgsForDeletion = "1";
				}
				return _daysToScheduleOrgsForDeletion.ToLower();
			}
			set
			{
				_daysToScheduleOrgsForDeletion = value;
			}
		}

		#endregion

		private static string _releaseNumber = null;
		/// <summary>
		/// Make sure this never exceeds 4 Chars. Since this is used in First Names of Card Order tests amd 
		/// we've a 23 char limit for names. The tests internally appends current timestamp to make it unique
		/// </summary>
		public static string CardOrderReleaseNumber
		{
			get
			{
				// Read the value to return only if the static string has not be set before
				//  else return the existing value set. (This should be a one time read for the entire test suite execution)
				if (String.IsNullOrEmpty(_releaseNumber))
				{
					try
					{
						_releaseNumber = System.Environment.GetEnvironmentVariable("bamboo_CardOrderReleaseNumber");
						if (string.IsNullOrWhiteSpace(_releaseNumber))
						{
							_releaseNumber = "";
						}
					}
					catch (Exception)
					{
						_releaseNumber = "";
					}
				}

				// ensure its always 4 chars in length
				_releaseNumber = (_releaseNumber.Length > 4) ? _releaseNumber.Substring(0, 4) : _releaseNumber;
				return _releaseNumber;
			}
			set
			{
				// ensure its always 4 chars in length
				value = (value.Length > 4) ? value.Substring(0, 4) : value;
				_releaseNumber = value;
			}
		}

		#region Mobile Testing

        /// <summary>
        /// Returns Device Type set in Bamboo or App Config in Upper Case
        /// </summary>
		public static string DeviceType
		{
			get
			{
				// Read the value to return only if the static string has not be set before
				//  else return the existing value set. (This should be a one time read for the entire test suite execution)
				if (String.IsNullOrEmpty(_deviceType))
				{
					try
					{
						_deviceType = System.Environment.GetEnvironmentVariable("bamboo_DeviceType");
						if (string.IsNullOrWhiteSpace(_deviceType))
						{
							_deviceType = ConfigurationManager.AppSettings["DeviceType"].ToString();
						}
					}
					catch (Exception)
					{
						_deviceType = ConfigurationManager.AppSettings["DeviceType"].ToString();
					}
				}
				return _deviceType.Trim().ToUpperInvariant();
			}
		}

		public static string MobileDeviceName
		{
			get
			{
				// Read the value to return only if the static string has not be set before
				//  else return the existing value set. (This should be a one time read for the entire test suite execution)
				if (String.IsNullOrEmpty(_mobileDeviceName))
				{
					try
					{
						_mobileDeviceName = System.Environment.GetEnvironmentVariable("bamboo_MobileDeviceName");
						if (string.IsNullOrWhiteSpace(_mobileDeviceName))
						{
							_mobileDeviceName = ConfigurationManager.AppSettings["MobileDeviceName"].ToString();
						}
					}
					catch (Exception)
					{
						_mobileDeviceName = ConfigurationManager.AppSettings["MobileDeviceName"].ToString();
					}
				}
				return _mobileDeviceName.Trim();
			}
		}		

		public static string MobileOSVersion
		{
			get
			{
				// Read the value to return only if the static string has not be set before
				//  else return the existing value set. (This should be a one time read for the entire test suite execution)
				if (String.IsNullOrEmpty(_mobileOSVersion))
				{
					try
					{
						_mobileOSVersion = System.Environment.GetEnvironmentVariable("bamboo_MobileOSVersion");
						if (string.IsNullOrWhiteSpace(_mobileOSVersion))
						{
							_mobileOSVersion = ConfigurationManager.AppSettings["MobileOSVersion"].ToString();
						}
					}
					catch (Exception)
					{
						_mobileOSVersion = ConfigurationManager.AppSettings["MobileOSVersion"].ToString();
					}
				}
				return _mobileOSVersion.Trim();
			}
			set
			{
				_mobileOSVersion = value;
			}
		}

		public static string MobileOS
		{
			get
			{
				// Read the value to return only if the static string has not be set before
				//  else return the existing value set. (This should be a one time read for the entire test suite execution)
				if (String.IsNullOrEmpty(_mobileOS))
				{
					try
					{
						_mobileOS = System.Environment.GetEnvironmentVariable("bamboo_MobileOS");
						if (string.IsNullOrWhiteSpace(_mobileOS))
						{
							_mobileOS = ConfigurationManager.AppSettings["MobileOS"].ToString();
						}
					}
					catch (Exception)
					{
						_mobileOS = ConfigurationManager.AppSettings["MobileOS"].ToString();
					}
				}
				return _mobileOS.Trim().ToUpperInvariant();
			}
		}

		#region BrowserStack

		/// <summary>
		/// Username for the account in Browser Stack
		/// </summary>
		public static string BrowserStackUser
		{
			get
			{
				// Read the value to return only if the static string has not be set before
				//  else return the existing value set. (This should be a one time read for the entire test suite execution)
				if (String.IsNullOrEmpty(_browserStackUser))
				{
					try
					{
						_browserStackUser = System.Environment.GetEnvironmentVariable("bamboo_BrowserStackUser");
						if (string.IsNullOrWhiteSpace(_browserStackUser))
						{
							_browserStackUser = ConfigurationManager.AppSettings["BrowserStackUser"].ToString();
						}
					}
					catch (Exception)
					{
						_browserStackUser = ConfigurationManager.AppSettings["BrowserStackUser"].ToString();
					}
				}
				return _browserStackUser;
			}
		}

		/// <summary>
		/// Access Key for the account in Browser Stack
		/// </summary>
		public static string BrowserStackKey
		{
			get
			{
				// Read the value to return only if the static string has not be set before
				//  else return the existing value set. (This should be a one time read for the entire test suite execution)
				if (String.IsNullOrEmpty(_browserStackKey))
				{
					try
					{
						_browserStackKey = System.Environment.GetEnvironmentVariable("bamboo_BrowserStackKey");
						if (string.IsNullOrWhiteSpace(_browserStackKey))
						{
							_browserStackKey = ConfigurationManager.AppSettings["BrowserStackKey"].ToString();
						}
					}
					catch (Exception)
					{
						_browserStackKey = ConfigurationManager.AppSettings["BrowserStackKey"].ToString();
					}
				}
				return _browserStackKey;
			}
		}

		/// <summary>
		/// Hub Url exposed by Browser Stack
		/// </summary>
		public static string BrowserStackHubUrl
		{
			get
			{
				// Read the value to return only if the static string has not be set before
				//  else return the existing value set. (This should be a one time read for the entire test suite execution)
				if (String.IsNullOrEmpty(_browserStackHubUrl))
				{
					try
					{
						_browserStackHubUrl = System.Environment.GetEnvironmentVariable("bamboo_BrowserStackHubUrl");
						if (string.IsNullOrWhiteSpace(_browserStackHubUrl))
						{
							_browserStackHubUrl = ConfigurationManager.AppSettings["BrowserStackHubUrl"].ToString();
						}
					}
					catch (Exception)
					{
						_browserStackHubUrl = ConfigurationManager.AppSettings["BrowserStackHubUrl"].ToString();
					}
				}
				return _browserStackHubUrl;
			}
		}

		/// <summary>
		/// Url to invoke any REST API in Browser Stack
		/// </summary>
		public static string BrowserStackAPIUrl
		{
			get
			{
				// Read the value to return only if the static string has not be set before
				//  else return the existing value set. (This should be a one time read for the entire test suite execution)
				if (String.IsNullOrEmpty(_browserStackApiUrl))
				{
					try
					{
						_browserStackApiUrl = System.Environment.GetEnvironmentVariable("bamboo_BrowserStackAPIUrl");
						if (string.IsNullOrWhiteSpace(_browserStackApiUrl))
						{
							_browserStackApiUrl = ConfigurationManager.AppSettings["BrowserStackHubUrl"].ToString();
						}
					}
					catch (Exception)
					{
						_browserStackApiUrl = ConfigurationManager.AppSettings["BrowserStackHubUrl"].ToString();
					}
				}
				return _browserStackApiUrl;
			}
		}

		#endregion

		#endregion

		#region Encompass Urls

		public static string BaseEncompassWebSerivceUrl
		{
			get
			{
                if (Environment.Equals("PROD", StringComparison.InvariantCultureIgnoreCase))
                {
                    try
                    {
                        switch (FI)
                        {
                            case "WEX":
                                _baseEncompassServiceUrl = ConfigurationManager.AppSettings["Wex.services.prod.url"];
                                break;
                            case "COMMERCE":
                                _baseEncompassServiceUrl = ConfigurationManager.AppSettings["CommerceBank.services.prod.url"];
                                break;
                            case "CENTRAL":
                                _baseEncompassServiceUrl = ConfigurationManager.AppSettings["CentralBank.services.prod.url"];
                                break;
                            case "KEYBANK":
                                _baseEncompassServiceUrl = ConfigurationManager.AppSettings["KeyBank.services.prod.url"];
                                break;
                            case "PNC":
                                _baseEncompassServiceUrl = ConfigurationManager.AppSettings["PNCBank.services.prod.url"];
                                break;
                            case "USBANK":
                                _baseEncompassServiceUrl = ConfigurationManager.AppSettings["USBank.services.prod.url"];
                                break;
                            case "AMEX":
                                _baseEncompassServiceUrl = ConfigurationManager.AppSettings["Amex.services.prod.url"];
                                break;
                            default: break;
                        }
                    }
                    catch (ConfigurationErrorsException)
                    {
                        return String.Empty;
                    }
                }
                else
                {
                    if (FI.Equals("COMMERCE"))
                        _baseEncompassServiceUrl = String.Format(ConfigurationManager.AppSettings["WebServiceBaseUrl"], "cbkc", Environment.ToLowerInvariant());
                    else
                        _baseEncompassServiceUrl = String.Format(ConfigurationManager.AppSettings["WebServiceBaseUrl"], FI.ToLowerInvariant(), Environment.ToLowerInvariant());
                }
				return _baseEncompassServiceUrl;
			}
		}

		/// <summary>
		///  Retruns after forming the final base url.
		///  It looks for bamboo variables first for values on FI and Environment
		///  otherwise follows the config in app.config
		/// </summary>
		public static string BaseEncompassUrl
		{
			get
			{
				if (Environment.Equals("PROD", StringComparison.InvariantCultureIgnoreCase))
				{
					// If its Prod then get the production urls directly from App config
					_baseEncompassUrl = GetProdUrl();
				}
				else if (Environment.Equals("DEMO", StringComparison.InvariantCultureIgnoreCase))
				{
					// If its Demo then get the production urls directly from App config
					_baseEncompassUrl = GetDemoUrl();
				}
                else if (Environment.Equals("QAAWS", StringComparison.InvariantCultureIgnoreCase))
                {
                    // If its Demo then get the production urls directly from App config
                    _baseEncompassUrl = GetQAAWSUrl();
                }
                else
				{
					// For any other Env, get urls from app config and replace with apr environment value
					_baseEncompassUrl = String.Format(GetUrlWithoutEnvironment(), Environment);
				}
				return _baseEncompassUrl;
			}
			set
			{
				_baseEncompassUrl = value;
			}
		}

		/// <summary>
		///  Gets the URL without environment specified.
		/// </summary>
		private static string GetUrlWithoutEnvironment()
		{
			try
			{
				switch (FI)
				{
					case "WEX":
						_baseEncompassUrl = ConfigurationManager.AppSettings["Wex.url"];
						break;
					case "AKUSA":
						_baseEncompassUrl = ConfigurationManager.AppSettings["Akusa.url"];
						break;
					case "COMMERCE":
						_baseEncompassUrl = ConfigurationManager.AppSettings["CommerceBank.url"];
						break;
					case "CENTRAL":
						_baseEncompassUrl = ConfigurationManager.AppSettings["CentralBank.url"];
						break;
					case "KEYBANK":
						_baseEncompassUrl = ConfigurationManager.AppSettings["KeyBank.url"];
						break;
					case "PNC":
						_baseEncompassUrl = ConfigurationManager.AppSettings["PNCBank.url"];
						break;
					case "REGIONS":
						_baseEncompassUrl = ConfigurationManager.AppSettings["RegionsBank.url"];
						break;
					case "SYNOVUS":
						_baseEncompassUrl = ConfigurationManager.AppSettings["SynovusBank.url"];
						break;
					case "USBANK":
						_baseEncompassUrl = ConfigurationManager.AppSettings["USBank.url"];
						break;
					case "IBERIABANK":
						_baseEncompassUrl = ConfigurationManager.AppSettings["IberiaBank.url"];
						break;
					case "AMEX":
						_baseEncompassUrl = ConfigurationManager.AppSettings["Amex.url"];
						break;
					case "GENERIC":
						_baseEncompassUrl = ConfigurationManager.AppSettings["Generic.url"];
						break;
					default: break;
				}
			}
			catch (ConfigurationErrorsException)
			{
				return String.Empty;
			}
			return _baseEncompassUrl;
		}

		/// <summary>
		///  Gets the URL without environment specified.
		/// </summary>
		private static string GetProdUrl()
		{
			try
			{
				switch (FI)
				{
					case "WEX":
						_baseEncompassUrl = ConfigurationManager.AppSettings["Wex.prod.url"];
						break;
					case "AKUSA":
						_baseEncompassUrl = ConfigurationManager.AppSettings["Akusa.prod.url"];
						break;
					case "COMMERCE":
						_baseEncompassUrl = ConfigurationManager.AppSettings["CommerceBank.prod.url"];
						break;
					case "CENTRAL":
						_baseEncompassUrl = ConfigurationManager.AppSettings["CentralBank.prod.url"];
						break;
					case "KEYBANK":
						_baseEncompassUrl = ConfigurationManager.AppSettings["KeyBank.prod.url"];
						break;
					case "PNC":
						_baseEncompassUrl = ConfigurationManager.AppSettings["PNCBank.prod.url"];
						break;
					case "REGIONS":
						_baseEncompassUrl = ConfigurationManager.AppSettings["RegionsBank.prod.url"];
						break;
					case "SYNOVUS":
						_baseEncompassUrl = ConfigurationManager.AppSettings["SynovusBank.prod.url"];
						break;
					case "USBANK":
						_baseEncompassUrl = ConfigurationManager.AppSettings["USBank.prod.url"];
						break;
					case "IBERIABANK":
						_baseEncompassUrl = ConfigurationManager.AppSettings["IberiaBank.prod.url"];
						break;
					case "AMEX":
						_baseEncompassUrl = ConfigurationManager.AppSettings["Amex.prod.url"];
						break;
					case "GENERIC":
						_baseEncompassUrl = ConfigurationManager.AppSettings["Generic.url"];
						break;
					default: break;
				}
			}
			catch (ConfigurationErrorsException)
			{
				return String.Empty;
			}
			return _baseEncompassUrl;
		}


		/// <summary>
		///  Gets the URL without environment specified for DEMO, read it from app config
		/// </summary>
		private static string GetDemoUrl()
		{
			try
			{
				switch (FI)
				{
					case "WEX":
						_baseEncompassUrl = ConfigurationManager.AppSettings["Wex.demo.url"];
						break;
					case "AKUSA":
						_baseEncompassUrl = ConfigurationManager.AppSettings["Akusa.demo.url"];
						break;
					case "COMMERCE":
						_baseEncompassUrl = ConfigurationManager.AppSettings["CommerceBank.demo.url"];
						break;
					case "CENTRAL":
						_baseEncompassUrl = ConfigurationManager.AppSettings["CentralBank.demo.url"];
						break;
					case "KEYBANK":
						_baseEncompassUrl = ConfigurationManager.AppSettings["KeyBank.demo.url"];
						break;
					case "PNC":
						_baseEncompassUrl = ConfigurationManager.AppSettings["PNCBank.demo.url"];
						break;
					case "REGIONS":
						_baseEncompassUrl = ConfigurationManager.AppSettings["RegionsBank.demo.url"];
						break;
					case "SYNOVUS":
						_baseEncompassUrl = ConfigurationManager.AppSettings["SynovusBank.demo.url"];
						break;
					case "USBANK":
						_baseEncompassUrl = ConfigurationManager.AppSettings["USBank.demo.url"];
						break;
					case "IBERIABANK":
						_baseEncompassUrl = ConfigurationManager.AppSettings["IberiaBank.demo.url"];
						break;
					case "AMEX":
						_baseEncompassUrl = ConfigurationManager.AppSettings["Amex.demo.url"];
						break;
					default: break;
				}
			}
			catch (ConfigurationErrorsException)
			{
				return String.Empty;
			}
			return _baseEncompassUrl;
		}

        /// <summary>
        ///  Gets the URL without environment specified for QA AWS, read it from app config
        /// </summary>
        private static string GetQAAWSUrl()
        {
            try
            {
                switch (FI)
                {
                    case "WEX":
                        _baseEncompassUrl = ConfigurationManager.AppSettings["Wex.qaaws.url"];
                        break;
                    case "AKUSA":
                        _baseEncompassUrl = ConfigurationManager.AppSettings["Akusa.qaaws.url"];
                        break;
                    default: break;
                }
            }
            catch (ConfigurationErrorsException)
            {
                return String.Empty;
            }
            return _baseEncompassUrl;
        }

        #endregion

        #region Bamboo Build Variables

        public static string BambooPlanKey
		{
			get
			{
				if (String.IsNullOrEmpty(_bambooPlanKey))
				{
					try
					{
						_bambooPlanKey = System.Environment.GetEnvironmentVariable("bamboo_planKey");
						if (string.IsNullOrWhiteSpace(_bambooPlanKey))
						{
							_bambooPlanKey = "";
						}
					}
					catch (Exception)
					{
						_bambooPlanKey = "";
					}
				}
				return _bambooPlanKey;
			}
		}

		public static string BambooResultKey
		{
			get
			{
				if (String.IsNullOrEmpty(_bambooBuildResultKey))
				{
					try
					{
						_bambooBuildResultKey = System.Environment.GetEnvironmentVariable("bamboo_buildResultKey");
						if (string.IsNullOrWhiteSpace(_bambooBuildResultKey))
						{
							_bambooBuildResultKey = "";
						}
					}
					catch (Exception)
					{
						_bambooBuildResultKey = "";
					}
				}
				return _bambooBuildResultKey;
			}
		}

		#endregion

		public ICollection<StepException> ScenarioErrors
		{
			get { return _scenarioErrors; }
			set { _scenarioErrors = value; }
		}

		public IScenarioConfiguration ScenarioConfiguration { get; set; }

		public PageModel CurrentModel
		{
			get
			{
				if (_currentModel == null || !_currentModel.RelativeUrl.Equals(EnCompassWebDriver.GetRelativeUrl(), StringComparison.InvariantCultureIgnoreCase))
				{
					var index = _pageModelCatalog.FirstOrDefault(m => m.Attributes.Any(a => a.RelativeURL.Equals(EnCompassWebDriver.GetRelativeUrl(), StringComparison.InvariantCultureIgnoreCase)));
					if (index == null) { return null; }
					_currentModel = Activator.CreateInstance(index.ClassType, this) as PageModel;
				}
				_currentModel.WaitForLoad();
				return _currentModel;
			}
			set
			{
				_currentModel = value;
			}
		}

		private void InitializePageModelCatalog()
		{
			_pageModelCatalog =
					from a in AppDomain.CurrentDomain.GetAssemblies()
					from t in a.GetTypes()
					let attributes = t.GetCustomAttributes(typeof(PageModelAttribute), true)
					where attributes != null && attributes.Length > 0
					select new PageModelIndex() { ClassType = t, Attributes = attributes.Cast<PageModelAttribute>() };
		}
	}

	public class PageModelIndex
	{
		public Type ClassType { get; set; }
		public IEnumerable<PageModelAttribute> Attributes { get; set; }
	}

	[AttributeUsage(AttributeTargets.Class, AllowMultiple = false)]
	public class PageModelAttribute : Attribute
	{
		/// <summary>
		/// Relative URL for the page that this page model represents.
		/// Should not include URL query string parameters.
		/// </summary>
		public string RelativeURL { get; set; }

		public PageModelAttribute(string relativeUrl)
		{
			RelativeURL = relativeUrl;
		}
	}
}