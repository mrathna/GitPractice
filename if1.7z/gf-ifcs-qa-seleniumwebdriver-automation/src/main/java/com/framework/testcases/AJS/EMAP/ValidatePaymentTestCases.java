package com.framework.testcases.AJS.EMAP;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.MerchantLocationPage;
import com.framework.pages.AJS.common.Common;
import com.framework.pages.AJS.common.IFCSCommonPage;
import com.framework.pages.AJS.common.IFCSHomePage;
import com.framework.pages.AJS.common.IFCSLoginPage;
import com.github.javafaker.Faker;

	
	public class ValidatePaymentTestCases extends BaseTest {
		
		/**
		 * Implemented by Nithya
		 * 
		 * @param clientCountry
		 * @param clientName    Business Flow ID:BF-102
		 */
		@Parameters({ "clientCountry", "clientName" })
		@Test( groups = { "BusinessFlow" })
		public void postManualPaymentFromIFCS(@Optional("HK") String clientCountry, @Optional("EMAP") String clientName) {

			test = extent.createTest(clientName + ":" + clientCountry + " TC_01_EMAP_Payments_Cheque_Payment",
					"RQ-144 Customer is paying using cheque payment");
			IFCSLoginPage ifcsLoginPage = new IFCSLoginPage(driver, test);
			IFCSHomePage ifcsHomePage = new IFCSHomePage(driver, test);
			IFCSCommonPage ifcsCommonPage = new IFCSCommonPage(driver, test);
			Common common = new Common(driver, test);
			ifcsLoginPage.login("IFCS_URL_EMAP", "IFCS_EMAP_USERNAME", "IFCS_EMAP_PASSWORD");
		      // ifcsHomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);
			ifcsLoginPage.setClientCountryCardTypeDetails(clientName, clientCountry, " ");
			// Selecting client from Application Menu
			ifcsHomePage.gotoApplicationAndClickApplicationMenu();
			ifcsHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);
			String customerNumber = common.getActiveOrTemporaryBlockCustomerNoHavingCardsAndRowIndex(1, "Active");
			//ifcsCommonPage.postManualPayments(customerNumber, "Other Payments", clientName + "_" + clientCountry);
			ifcsCommonPage.postManualPayments(customerNumber, "Manual Cheque - Payment", clientName + "_" + clientCountry);

			ifcsHomePage.exitIFCS();
		}
		
	
	
		
}
