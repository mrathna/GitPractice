package com.framework.testcases.AJS.EMAP;

import org.testng.annotations.Optional;


import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.CardMaintenancePage;

import com.framework.pages.AJS.common.Common;
import com.framework.pages.AJS.common.IFCSHomePage;
import com.framework.pages.AJS.common.IFCSLoginPage;
import com.framework.pages.OLS.common.BPCommonPage;
import com.framework.pages.OLS.common.FindAndUpdateCardPage;

public class ValidateCardTestCases extends BaseTest {
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "Regression" })
	public void updateAndValidateLicencePlate(@Optional("SG") String clientCountry,
			@Optional("EMAP") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  EMAP IFCS Update Licence Plate",
				"TST-SC-06-Card Reissue (Update licence plate and some other fields)");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		CardMaintenancePage cardMaintenancePage=new CardMaintenancePage(driver,test);
		
		Common common = new Common(driver, test);

		IFCSloginPage.login("IFCS_URL_EMAP", "IFCS_EMAP_USERNAME", "IFCS_EMAP_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, " ");
		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		String vehicleCardNumber=common.getVehicleCardNumberFromDB(clientName+clientCountry);
		if(vehicleCardNumber.equals("")) {
		//need to call method to logfail
		common.logForNoDataFound(this.getClass().getSimpleName(),"Need to Create A Card and rerun");	
		}
		else {	

		cardMaintenancePage.validateUpdateLicensePlate(vehicleCardNumber);
		}
		
		IFCSHomePage.exitIFCS();
		
		}
	
	
	/**
	 * Implemented by Nithya
	 * 
	 * @param clientCountry
	 * @param clientName    Business Flow ID:BF-090
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "BusinessFlow" })
	public void validateCardExpiry(@Optional("SG") String clientCountry, @Optional("EMAP") String clientName) {

		test = extent.createTest(clientName + ":" + clientCountry + " ID:BF-090 Validate Card Expiry",
				"Cards should reach the status as Expired on the expiry date");
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCShomePage = new IFCSHomePage(driver, test);
		BPCommonPage bpCommonPage = new BPCommonPage(driver, test);
		Common common = new Common(driver, test);
		IFCSloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		CardMaintenancePage cardMaintenancePage = new CardMaintenancePage(driver, test);

		// Serch Cutomer
		IFCShomePage.gotoApplicationAndClickApplicationMenu();
		IFCShomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, " ");
		//String cardNo = common.getVinCiiActiveCard();
		String cardNo = common.getActiveCardNumberFromDB();
		IFCShomePage.gotoCustomerMenuCustomerDetails();

		cardMaintenancePage.chooseAndSearchCardNo(cardNo);
		cardMaintenancePage.cardExpiryDateChange();

		IFCShomePage.exitIFCS();
	}
	
	/**
	 * Added by Nithya
	 * 
	 * @param clientCountry
	 * @param clientName    Busienss Flow ID:RQ-840
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "BusinessFlow" })
	public void remailPINRequestFromIFCS(@Optional("HK") String clientCountry, @Optional("EMAP") String clientName) {
		test = extent.createTest(clientName + ":" + clientCountry + "RQ-840,RQ-819 TC-1610 TC02_CardMgmt_Remail PIN request, TC-799 TC04_CardMgmt_Ord_System generated PIN cards with existing PIN_IFCS",
				"Remail PIN Request, Remail PIN Request and DB Validation");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		Common common = new Common(driver, test);
		FindAndUpdateCardPage findAndUpdate = new FindAndUpdateCardPage(driver, test);
		CardMaintenancePage cardMaintenancePage = new CardMaintenancePage(driver, test);
		IFCSloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		IFCSHomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);
		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		String cardNoForRemailPIN = common.getActiveCardNumberFromDBWFE(clientName, clientCountry);
		common.chooseCustomerNoAndSearch(common.getCustomerNoForCardNumber(cardNoForRemailPIN));
		common.chooseCardNo(cardNoForRemailPIN);
		String pinBeforeJob = ""; 
			//	findAndUpdate.getPINValuesFromDB(cardNoForRemailPIN);
		cardMaintenancePage.requestForNewSystemPIN();
		common.updatePropFile("EmbossReMailPIN_" + clientName + "_" + clientCountry, cardNoForRemailPIN,
				"EmbossIdemiaValidation.properties");
		common.updatePropFile("RemailPINAndDBValdiation_" + clientName + "_" + clientCountry, pinBeforeJob,
				"EmbossIdemiaValidation.properties");
		IFCSHomePage.exitIFCS();
	}

}


