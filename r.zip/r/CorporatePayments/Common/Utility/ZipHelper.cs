﻿using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;


namespace Common.Utility
{
	public static class ZipHelper
	{
		public static IEnumerable<string> ReadTextFileFromZip(string zipFile, string innerFilePattern)
		{
			List<string> output = null;
			using (var zip = new ZipArchive(File.OpenRead(zipFile), ZipArchiveMode.Read))
			{
				var file = zip.Entries.FirstOrDefault(e => Regex.IsMatch(e.Name, innerFilePattern));
				if (file != null)
				{
					using (var reader = new StreamReader(file.Open()))
					{
						output = reader.ReadToEnd()?.Split(new[] { "\r\n", "\r", "\n" }, StringSplitOptions.None).ToList();
					}
				}
				return output;
			}
		}

		public static string FileNameInTheZipFile(string zipFile, string filePattern)
		{
			using (var zip = new ZipArchive(File.OpenRead(zipFile), ZipArchiveMode.Read))
			{
				var file = zip.Entries.FirstOrDefault(f => Regex.IsMatch(f.Name, filePattern));
					if (file != null)
					return file.Name;
				else
					return "";
			}
		}
	}
}
