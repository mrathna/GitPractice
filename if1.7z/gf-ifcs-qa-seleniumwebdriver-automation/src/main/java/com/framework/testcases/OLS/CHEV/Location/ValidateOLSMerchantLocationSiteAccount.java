package com.framework.testcases.OLS.CHEV.Location;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.CHEV.CHAccountMaintenancePage;
import com.framework.pages.CHEV.CHContactListPage;
import com.framework.pages.CHEV.CHHomePage;
import com.framework.pages.CHEV.CHTransactionPage;
import com.framework.pages.OLS.common.CommonPage;
import com.framework.pages.OLS.common.LoginPage;


public class ValidateOLSMerchantLocationSiteAccount extends BaseTest {
	@Parameters({ "clientCountry", "clientName" })
	@Test
	public void testOLSMerchantLocationSiteAccount(@Optional("SG") String clientCountry, @Optional("CHV") String clientName) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  OLS - All Location Site - Account", "Chevron Merchant Screens Location Site Read Only");

		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		CHHomePage chHomePage = new CHHomePage(driver, test);
		CHTransactionPage chTransactionPage = new CHTransactionPage(driver, test);
		CHAccountMaintenancePage accountMaintenancePage = new CHAccountMaintenancePage(driver, test);
		CHContactListPage chContactListPage = new CHContactListPage(driver, test);
		CommonPage commonPage = new CommonPage(driver, test);
		if (clientCountry.equals("SG")||clientCountry.equals("MY")||clientCountry.equals("HK")) {
			loginPage.Login("CHV_URL", "CHV_Location_UN_"+clientCountry, "CHV_Location_PWD_"+clientCountry, clientName);			
			
		} else if (clientCountry.equals("TH")) {
			loginPage.Login("CHV_URL", "CHV_Location_UN_"+clientCountry, "CHV_Location_PWD_"+clientCountry, clientName);

		} else if (clientCountry.equals("PH")) {
			loginPage.Login("CHV_URL", "CHV_Location_UN_"+clientCountry, "CHV_Location_PWD_"+clientCountry, clientName);

		}

	//	chHomePage.verifyMerchantQuickLinks();
		// Home Page Links
		chHomePage.clickOnLocationTransactionLink();
		chTransactionPage.verifyTransactionPage();
		chHomePage.clickOnHome();
		chHomePage.clickOnExportTransactionLink();
		chHomePage.checkForFileDownload(1);
		String checkFileDate=chHomePage.validateDateInDownloadedFile();
		commonPage.isFileDownloaded(checkFileDate);

		commonPage.isFileDownloaded("tableStoredRepList");
		chHomePage.clickOnSuspendedTransactionsTransactionLink();
		chHomePage.checkForFileDownload(1);
		commonPage.isFileDownloaded("201904");
		commonPage.isFileDownloaded("_MerchantExportSuspendedTransactions");
		 checkFileDate=chHomePage.validateDateInDownloadedFile();
		commonPage.isFileDownloaded(checkFileDate);
		//Below Location actions are commented - Due to Location Menu not displaying in Account 
		// Location
		chHomePage.loadFindAndLocationsPage();
		accountMaintenancePage.verifyLocationMaintenancePage();
		accountMaintenancePage.verifyAddressTitles();
		accountMaintenancePage.verifyIfFieldsAreEditable();
		accountMaintenancePage.verifyIfSaveIsEnabled();
		accountMaintenancePage.verifyContactTableColumns(); 
		
		//Contacts
		chHomePage.loadFindAndContactsPage();
		chContactListPage.verifyContactListPage();
		chContactListPage.verifyContactTableColumns();
		chContactListPage.verifyAddContactAndExportButton();
		chHomePage.verifyFooterLinks();
		
		loginPage.Logout();
	}
}
