package com.framework.testcases.AJS.BP;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.TransactionListPage;
import com.framework.pages.AJS.common.IFCSHomePage;
import com.framework.pages.AJS.common.IFCSLoginPage;

public class ValidateTransactionSearchTestCases extends BaseTest {
	@Parameters({ "clientCountry", "clientName"})
	@Test(groups = { "Regression" })
	public void validateTransactionSearch(@Optional("AU") String clientCountry,
			@Optional("BP") String clientName) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  Sys_AU_005_Transaction Search,Transcation Search");
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		TransactionListPage transactionListPage=new TransactionListPage(driver,test);
		
		IFCSloginPage.login("IFCS_URL_BP", "IFCS_BP_USERNAME", "IFCS_BP_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry," ");
		IFCSHomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);
		IFCSHomePage.gotoTransactionAndClickManageTransaction();
		transactionListPage.validateFullDayTransactionSearch();
		transactionListPage.validateNextPageIsDisplayed();
		IFCSHomePage.exitIFCS();

}
}
