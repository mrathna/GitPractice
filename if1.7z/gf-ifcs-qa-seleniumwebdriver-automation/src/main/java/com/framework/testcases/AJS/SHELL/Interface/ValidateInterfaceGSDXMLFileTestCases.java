package com.framework.testcases.AJS.SHELL.Interface;


import java.util.ArrayList;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.MerchantLocationPage;
import com.framework.pages.AJS.common.IFCSCommonPage;
import com.framework.pages.AJS.common.IFCSHomePage;
import com.framework.pages.AJS.common.IFCSLoginPage;
import com.framework.pages.AJS.common.InterfacePage;

public class ValidateInterfaceGSDXMLFileTestCases extends BaseTest{

	
	@Parameters({ "clientCountry", "clientName"})
	@Test(groups = {"Smoke"})
	public void ValidateAddNewLocationMerchantAgreement(@Optional("CZ") String clientCountry, @Optional("SH") String clientName) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  SHELL Interface Add new Location- Merchant-Agreement", "01 add new Location- Merchant-Agreement");
		//creating object for the Pages
		IFCSLoginPage ifcsloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage ifcsHomePage = new IFCSHomePage(driver, test);
		IFCSCommonPage ifcsCommonPage = new IFCSCommonPage(driver, test);
		InterfacePage interfacePage = new InterfacePage(driver,test);
		MerchantLocationPage merchantLocationPage =  new MerchantLocationPage(driver, test);
//		String locNumberUpdated = "";
		ArrayList <String> locNumberUpdated = new ArrayList<String>();
		
		locNumberUpdated = interfacePage.updateOrValidateFlatFile(gsdconfigProp, "OutgoingXMLFile", "IE_INPUTFILE_FOLDER_LOADCARDTRANSACTIONS", "", clientName, clientCountry, "GSD.APAPC_20180531_124756.xml");
		System.out.println("locNumberUpdatedlocNumberUpdated  "+locNumberUpdated);
		
		if(!locNumberUpdated.contains(" ")) {
		String folderName = ifcsCommonPage.getControlMFolder(clientName, clientCountry, "jobA_GSD");
		
		String jobsInOrder =  ifcsCommonPage.getJobsOfFolderInOrder("jobA_GSD");
	   
		interfacePage.establishAndExecuteControlMJobs("ControlM_AWS_UAT","ContorlM_AWS_userName","ContorlM_AWS_password",folderName, jobsInOrder);

		 // Calling Functions
		ifcsloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");
		
		ifcsHomePage.gotoMerchantAndClickMerchantDetails();

		merchantLocationPage.validateNewlyAddedLocationNumber(locNumberUpdated.get(0));
		
		}
		else
		{
			System.out.println("Interface is not updated correctly");
		}
		
	}
}
