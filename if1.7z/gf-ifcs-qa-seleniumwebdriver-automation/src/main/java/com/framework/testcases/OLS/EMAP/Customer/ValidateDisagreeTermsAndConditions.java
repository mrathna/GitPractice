package com.framework.testcases.OLS.EMAP.Customer;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.OLS.common.LoginPage;

public class ValidateDisagreeTermsAndConditions extends BaseTest {
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "Regression" })
	public void validateDisagreeTermsAndConditions(@Optional("SP") String clientCountry,
			@Optional("EMAP") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  TST-SC-75-OLS - Disagree Terms and Conditions", "Login to EMAP Customer - Read");
		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);

		loginPage.validateLoginPageFooterLinks(clientName, "EMAP_URL");
		// LoginAndDisagree
		loginPage.loginAndDisagree("EMAP_UN_ReadWrite_Customer_" + clientCountry,
				"EMAP_PWD_ReadWrite_Customer_" + clientCountry);
	}
}
