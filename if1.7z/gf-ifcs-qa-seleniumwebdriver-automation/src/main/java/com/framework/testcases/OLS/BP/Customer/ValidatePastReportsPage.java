package com.framework.testcases.OLS.BP.Customer;

import java.text.ParseException;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.BP.BPHomePage;
import com.framework.pages.BP.BPRecurringReportPage;
import com.framework.pages.OLS.common.LoginPage;
import com.framework.pages.OLS.common.PastReportsPage;

public class ValidatePastReportsPage extends BaseTest {

	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = {"Regression"})
	public void checkZipReportFileDownload(@Optional("AU") String clientCountry, @Optional("BP") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  BP Customer Past Reports ", "Past Reports download as zip file");

		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		BPHomePage bpHomePage = new BPHomePage(driver, test);
		PastReportsPage pastReportsPage = new PastReportsPage(driver, test);

		// Calling Functions for Login
		loginPage.Login("BP_URL", "BP_UN_Customer_" + clientCountry, "BP_PWD_Customer_" + clientCountry, clientName);

		bpHomePage.ValidateBPCustomerLogo();

		bpHomePage.loadPastReportsPage();

		pastReportsPage.selectViewAllInGenerateReportTable();

		if (pastReportsPage.isGenerateReportTablePresent()) {

			pastReportsPage.verifyReportPageTitle("View All Reports");

			pastReportsPage.clickDownloadReportsAsZip();

			pastReportsPage.checkReportAvailability();

			pastReportsPage.returnToPastReportsPage();

			pastReportsPage.verifyReportPageTitle("Past Reports");
		}

		pastReportsPage.selectViewAllInRecurringReportTable();

		if (pastReportsPage.isMyRecurringReportTablePresent()) {

			pastReportsPage.verifyReportPageTitle("View All Reports");

			pastReportsPage.clickDownloadReportsAsZip();

			pastReportsPage.checkReportAvailability();

			pastReportsPage.returnToPastReportsPage();

			pastReportsPage.verifyReportPageTitle("Past Reports");
		}

		loginPage.Logout();

	}

	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = {"Regression"})
	public void checkFilterOptions(@Optional("AU") String clientCountry, @Optional("BP") String clientName)
			throws ParseException {
		test = extent.createTest(clientName+ ":" +clientCountry+"  BP Customer Past Reports", "Filter Options validation");

		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		BPHomePage bpHomePage = new BPHomePage(driver, test);
		PastReportsPage pastReportsPage = new PastReportsPage(driver, test);

		// Calling Functions for Login
		loginPage.Login("BP_URL", "BP_UN_Customer_" + clientCountry, "BP_PWD_Customer_" + clientCountry, clientName);

		bpHomePage.ValidateBPCustomerLogo();

		bpHomePage.loadPastReportsPage();

		pastReportsPage.selectViewAllInGenerateReportTable();

		if (pastReportsPage.isGenerateReportTablePresent()) {

			pastReportsPage.verifyReportPageTitle("View All Reports");

			pastReportsPage.setDateAndReportFileName();

			pastReportsPage.enterFileNameFilter();

			pastReportsPage.enterDateFromFilter();

			pastReportsPage.enterDateToFilter();

			pastReportsPage.clickFilterButton();

			pastReportsPage.validateSearchResultsWithFileNameFilter();

			pastReportsPage.validateSearchResultsWithDateFilter();

			pastReportsPage.validateClearFilterOptionsAndShowAll();
		}

		loginPage.Logout();

	}

	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = {"Regression"})
	public void navigateThroughPastAndRecurringReports(@Optional("AU") String clientCountry,
			@Optional("BP") String clientName) throws ParseException {
		test = extent.createTest(clientName+ ":" +clientCountry+"  BP Customer Past Reports", "Filter Options validation");

		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		BPHomePage bpHomePage = new BPHomePage(driver, test);
		PastReportsPage pastReportsPage = new PastReportsPage(driver, test);
		BPRecurringReportPage bpRecurringReportPage = new BPRecurringReportPage(driver, test);

		// Calling Functions for Login
		loginPage.Login("BP_URL", "BP_UN_Customer_" + clientCountry, "BP_PWD_Customer_" + clientCountry, clientName);

		bpHomePage.ValidateBPCustomerLogo();

		bpHomePage.loadPastReportsPage();

		pastReportsPage.selectViewAllInGenerateReportTable();

		if (pastReportsPage.isGenerateReportTablePresent()) {

			pastReportsPage.verifyReportPageTitle("View All Reports");

			pastReportsPage.returnToPastReportsPage();

			pastReportsPage.verifyReportPageTitle("Past Reports");
		}

//		bpRecurringReportPage.selectFilterForRecurringReportsList("On Hold");

//		bpRecurringReportPage.verifyTheListedReportsStatus("On Hold");

		bpRecurringReportPage.selectFilterForRecurringReportsList("Active");

		bpRecurringReportPage.verifyTheListedOptionsInRecurringReport();

		bpRecurringReportPage.verifyTheRecurringReportsArePresentAndDownloadLatestCopy();

		loginPage.Logout();

	}
}
