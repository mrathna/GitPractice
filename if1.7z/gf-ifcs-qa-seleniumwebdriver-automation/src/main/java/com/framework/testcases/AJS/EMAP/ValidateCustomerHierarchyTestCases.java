package com.framework.testcases.AJS.EMAP;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.MaintainCustomerPage;
import com.framework.pages.AJS.common.IFCSHomePage;
import com.framework.pages.AJS.common.IFCSLoginPage;

public class ValidateCustomerHierarchyTestCases extends BaseTest{
	

	
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "Regression" })
	public void validateHierarchyStructureDeleteAHierarchy(@Optional("SG") String clientCountry,
			@Optional("EMAP") String clientName) {
		test = extent.createTest(
				"TST-SC-49.2- Maintain Customer -  Hierarchies - Hierarchy Structure - Delete a Hierarchy-Manual,TST-SC-47-Parent Child Hierarchy _ Parent With Auth & Billing- Child with Auth& Billing Node",
				"Maintain Customer -  Hierarchies - Hierarchy Structure - Delete a Hierarchy-Manual,Parent Child Hierarchy _ Parent With Auth & Billing- Child with Auth& Billing Node");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		MaintainCustomerPage maintainCustomerPage = new MaintainCustomerPage(driver, test);
		IFCSloginPage.login("IFCS_URL_EMAP", "IFCS_EMAP_USERNAME", "IFCS_EMAP_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, " ");
		
		IFCSHomePage.gotoAdminMenuAndChooseClient(clientName+"_"+clientCountry);
		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		
		String mainAccount = maintainCustomerPage.createHierarchyWithChild();
		if (!mainAccount.equals(null)) {
			maintainCustomerPage.deleteAHierarchyAndCheckErrorMessage();
			maintainCustomerPage.createRebateProfile();
		} else {
			maintainCustomerPage.logForNoDataFound(this.getClass().getSimpleName(),
					"No Standalone customer for creating hierarchy");
		}

		IFCSHomePage.exitIFCS();

	}

/*@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "Regression" })
	public void validateCardMaintenanceEmbossHistory(@Optional("SG") String clientCountry,
			@Optional("EMAP") String clientName) {
		test = extent.createTest(
				"Maintain Customer -  Card Details -  Card Maintenance - Emboss History - Velocity Values-Manual",
				"TST-SC-50-Maintain Customer -  Card Details -  Card Maintenance - Emboss History - Velocity Values-Manual");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		MaintainCustomerPage maintainCustomerPage = new MaintainCustomerPage(driver, test);
		IFCSloginPage.login("IFCS_URL_EMAP", "IFCS_EMAP_USERNAME", "IFCS_EMAP_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, " ");
		String mainAccount = maintainCustomerPage.createHierarchyWithChild();
		if (!mainAccount.equals(null)) {
			maintainCustomerPage.deleteAHierarchyAndCheckErrorMessage();
		} 
		IFCSHomePage.exitIFCS();

	}*/


/*@Parameters({ "clientCountry", "clientName"})
@Test( groups = { "Regression" })
public void validateParentCustomerHierarchyAddRebateProfile(@Optional("SG") String clientCountry,
		@Optional("EMAP") String clientName) {
	test = extent.createTest(clientName+ ":" +clientCountry+"  Parent Child Hierarchy _ Parent With Auth & Billing- Child with Auth& Billing Node",
			"TST-SC-47-Parent Child Hierarchy _ Parent With Auth & Billing- Child with Auth& Billing Node");
	// creating object for the Pages
	IFCSLoginPage ifcsloginPage = new IFCSLoginPage(driver, test);
	IFCSHomePage ifcsHomePage = new IFCSHomePage(driver, test);
	MaintainCustomerPage maintainCustomerPage = new MaintainCustomerPage(driver, test);
	CardMaintenancePage cardMaintenancePage = new CardMaintenancePage(driver, test);
	IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);

	ifcsloginPage.login("IFCS_URL_EMAP", "IFCS_EMAP_USERNAME", "IFCS_EMAP_PASSWORD");
	ifcsloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, " ");
	IFCSHomePage.gotoApplicationAndClickApplicationMenu();
	IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);
	IFCSHomePage.gotoCustomerMenuCustomerDetails();
	cardMaintenancePage.chooseAndSearchCustomerNo("0016372");
	// Get Parent Customer no with hierarchy

//	maintainCustomerPage.createHierarchyWithChild();

	maintainCustomerPage.createRebateProfile();
	
	IFCSHomePage.exitIFCS();
}*/

	

}
