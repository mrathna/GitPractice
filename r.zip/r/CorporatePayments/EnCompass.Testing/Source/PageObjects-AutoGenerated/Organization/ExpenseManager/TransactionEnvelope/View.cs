using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using Common;
using Common.PageObjects;
using Common.ScenarioConfigurations;
using Common.Utility;

namespace EnCompass.Testing.Source.PageObjects.Organization.ExpenseManager.TransactionEnvelope 
{
	/// <summary>
	/// Auto-generated Page Model Class
	/// Navigation Paths: 
		/// [Organization Home]->Transactions->Transaction Envelopes
		/// </summary>
	[PageModel(@"/expenseManager/transactionEnvelope/view.aspx")]
	public partial class View : EnCompassOrgPageModel 
	{
		public override string RelativeUrl => @"/expenseManager/transactionEnvelope/view.aspx";
		public override string PageIdentifierXPath_Generated => @"//li[contains(@class, 'breadcrumb-item active')][text() = 'Transaction Envelopes']";

		#region Navigation
		
		private void NavigateToMenuItem(IWebElement element)
		{
			Driver.Url = element.GetAttribute("href");
		}
		#endregion

		public View(GlobalSettings settings) : base(settings) { }
	}  
}
