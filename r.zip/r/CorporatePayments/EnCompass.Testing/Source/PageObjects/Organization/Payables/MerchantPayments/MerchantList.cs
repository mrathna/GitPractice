﻿using Common;
using Common.Utility;
using EnCompass.Testing.Source.PageObjects.Controls;
using NFluent;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EnCompass.Testing.Source.PageObjects.Organization.Payables.MerchantPayments
{
	public partial class MerchantList : EnCompassOrgPageModel
	{
		public override string PageIdentifierXPath_Override => @"//li[@class='breadcrumb-item active'][normalize-space(text())='Merchants']";

        #region XPath page Elements
        private const string _editMerchantsXPath = @"//a[contains(@id,'actionLink0')]";
        private const string _merchantSettingsXPath = @"//a[contains(@id,'actionLink3')]";
        private const string _searchCategoryXPath = @"//select[contains(@id, 'searchTermSelect')]";
        private const string _searchConstraintXPath = @"//select[contains(@id, 'searchTermFilter')]";
        private const string _searchStartDateXPath = @"//input[contains(@id, 'txtLower')]";
        private const string _searchEndDateXPath = @"//input[contains(@id, 'txtUpper')]";
        private const string _searchTermListboxXPath = @"//select[contains(@id, 'SearchOutput_values')]";
        private const string _searchTermTextboxXPath = @"//div[contains(@id,'_searchTermValueInputGroup')]//input[contains(@id, 'SearchOutput_txt')]";
        private const string _searchCriteriaClearButtonXPath = @"//button[@type='button' and normalize-space(text())='Clear']";
        private const string _searchCriteriaAddButtonXPath = @"//input[@value='Add' and not(ancestor-or-self::div[contains(@style,'display: none')])]";
        private const string _searchButtonXPath = @"//input[contains(@id, 'btnSearch')]";
        private const string _overrideButtonXPath = @"//a[contains(@id, 'actionLink3')]";
        private const string _cardInformationXPath = @"//a[contains(@id,'actionLink') and text()='Card Information']";
        private const string _cardInfoNonModalCloseBtnXPath = "//button[contains(@id,'ContinueButton') and text()='Close']";
        private const string _cardNumberXPath = @"//span[contains(@id,'CardNumberPara')]";
        private const string _btnCreateXPath = "//a[contains(@role,'button') and contains (@href,'EditMerchant')]";
        private static string _noMerchantInGridXPath = ".//td[contains(@class,'gridNoRecordsMessage')]";
        #endregion

        #region Page Elements
        private IWebElement _editMerchants
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_editMerchantsXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_editMerchants element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        
        private IWebElement _searchCategory
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_searchCategoryXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_searchCategory element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _searchConstraint
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_searchConstraintXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_searchConstraint element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _searchStartDate
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_searchStartDateXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_searchStartDate element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _searchEndDate
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_searchEndDateXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_searchEndDate element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _searchTermListbox
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_searchTermListboxXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_searchTermListbox element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _searchTermTextbox
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_searchTermTextboxXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_searchTermTextbox element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _searchCriteriaClearButton
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_searchCriteriaClearButtonXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_searchCriteriaClearButton element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _searchCriteriaAddButton
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_searchCriteriaAddButtonXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_searchCriteriaAddButton element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _searchButton
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_searchButtonXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_searchButton element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _overrideButton
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_overrideButtonXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_overrideButton element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _cardInformation
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_cardInformationXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_cardInformation element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _cardInfoNonModalCloseBtn
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_cardInfoNonModalCloseBtnXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_cardInfoNonModalCloseBtn element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _cardNumber
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_cardNumberXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_cardNumber element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _btnCreate
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_btnCreateXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_btnCreate element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _noMerchantInGrid
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_noMerchantInGridXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_noMerchantInGrid element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        #endregion

        public void ClickCreateCard()
        {
            _btnCreate.JSClickWithFocus(Driver);
        }
        
        public void SetSearchCriteriaSearchTerm(string whichText)
		{
			var selectElement = new SelectElement(_searchCategory);
			selectElement.SelectByText(whichText);
		}

		public void SetSearchFilterType(String whichText)
		{
			var selectElement = new SelectElement(_searchConstraint);
			selectElement.SelectByText(whichText);
		}

		public string FilterTypeLowerLimit
		{
			get { return _searchStartDate.GetAttribute("value"); }
			set { _searchStartDate.Clear(); _searchStartDate.SendKeys(value); }
		}

		public string FilterTypeUpperLimit
		{
			get { return _searchEndDate.GetAttribute("value"); }
			set { _searchEndDate.Clear(); _searchEndDate.SendKeys(value); }
		}

		public string SearchCriteriaTextSearchValue
		{
			set
			{
				_searchTermTextbox.SendKeys(value);
			}
		}

		private GridControl _mGrid;
		public GridControl MerchantsListGrid
		{
			get
			{
				GridControl grid = _mGrid ?? (_mGrid = new GridControl("dgMerchantList", Driver));
				grid.WaitForGrid();
				return grid;
			}
		}

		public void ResetClick()
		{
			_searchCriteriaClearButton.JSClickWithFocus(Driver);
		}
        public void ClickCardInfo()
        {
            _cardInformation.JSClickWithFocus(Driver);
        }
        public void Add()
		{
			_searchCriteriaAddButton.JSClickWithFocus(Driver);
		}

		//public void Add()
		//{
		//	if (SearchFilterType.Equals("between", StringComparison.InvariantCultureIgnoreCase))
		//	{
		//		if (Driver.TryFindElement(By.XPath(@"//input[@value='Add'][not(contains(@style, 'display: none'))][2]"), out IWebElement element))
		//		{
		//			if (element.Displayed)
		//				element.JSClickWithFocus(Driver);
		//		}
		//		else
		//		{
		//			if (Driver.TryFindElement(By.XPath(@"//input[@value='Add'][not(contains(@style, 'display: none'))][1]"), out IWebElement element1))
		//				if (element1.Displayed)
		//					_searchCriteriaAddButton1.JSClickWithFocus(Driver);
		//				else
		//			if (Driver.TryFindElement(By.XPath(@"(//input[@value='Add'][not(contains(@style, 'display: none'))][1])[2]"), out IWebElement element2))
		//					element2.JSClickWithFocus(Driver);
		//		}
		//	}
		//	else
		//	{
		//		if (Driver.TryFindElement(By.XPath(@"//input[@value='Add'][not(contains(@style, 'display: none'))][1]"), out IWebElement element))
		//		{
		//			if (element.Displayed)
		//				element.JSClickWithFocus(Driver);
		//		}
		//		else
		//		{
		//			_searchCriteriaAddButton2.JSClickWithFocus(Driver);
		//		}
		//	}
		//}

		public void Search()
		{
			_searchButton.JSClickWithFocus(Driver);
			WaitForLoad();
		}

		/// <summary>
		/// Search a specific MLog
		/// </summary>
		public void SearchMerchant(string searchTerm, string searchVal)
		{
			ResetClick();
			SetSearchCriteriaSearchTerm(searchTerm);
			RefreshModel();
			SearchCriteriaTextSearchValue = searchVal;
			Add();
			Search();
			RefreshModel();
		}

		public void SearchAndEditMerchant(string searchTerm, string searchVal)
		{
			SearchMerchant(searchTerm, searchVal);
			MerchantsListGrid.SelectFirstRow();
			MerchantsListGrid.PerformActionByText("Edit");
		}

		public void EditMerchants()
		{
			_editMerchants.JSClickWithFocus(Driver);
			Settings.EnCompassExtentTest.Debug("Clicked on Edit Merchants");
		}

		public void SelectMerchantSettings()
		{
			MerchantsListGrid.PerformActionByText("Override Settings");
			Settings.EnCompassExtentTest.Debug("Clicked on Merchant Override Settings");
		}

        public void OverrideMerchantSettings()
        {
            _overrideButton.JSClickWithFocus(Driver);
			Settings.EnCompassExtentTest.Debug("Clicked on Override Merchant Settings");
		}

		/// <summary>
		/// This method searches the Merchant List in the landing page for 'Last Payment Date' column value.
		/// </summary>
		/// <param name="rowIndex"></param>
		/// <returns></returns>
		public string LastPaymentDateValue(int rowIndex = 1)
		{
			return Driver.FindElement(By.XPath($@"//tr[contains(@id, 'dgMerchantList_ctl')][{rowIndex}]/td[11]")).Text;
		}

		/// <summary>
		/// This method checks if options in the Search Criteria -> FIRST list box are present.
		/// </summary>
		/// <param name="whichOption"></param>
		/// <returns></returns>
		public bool IsFirstSearchCriteriaOptionPresent(string whichOption)
		{
			var searchTerm = new SelectElement(_searchCategory);
			return searchTerm.Options.Any(o => string.Compare(o.Text, whichOption) == 0);
		}

		/// <summary>
		/// This method checks if options in the Search Criteria -> SECOND list box are present.
		/// </summary>
		/// <param name="whichOption"></param>
		/// <returns></returns>
		public bool IsSecondSearchCriteriaOptionPresent(string whichOption)
		{
			var searchTerm = new SelectElement(_searchConstraint);
			return searchTerm.Options.Any(o => string.Compare(o.Text, whichOption) == 0);
		}

		/// <summary>
		/// This method checks if options in the Search Criteria -> THIRD list box are present.
		/// </summary>
		/// <param name="whichOption"></param>
		/// <returns></returns>
		public bool IsThirdSearchCriteriaOptionPresent(string whichOption)
		{
			var searchTerm = new SelectElement(_searchTermListbox);
			return searchTerm.Options.Any(o => string.Compare(o.Text, whichOption) == 0);
		}

		public void SetSearchTermDDLByText(string text)
		{
			var selectElement = new SelectElement(_searchTermListbox);
			selectElement.SelectByText(text);
		}

		public string NoMerchantsFound
		{
			get
			{
				return _noMerchantInGrid.GetAttribute("innerText");
			}
		}
        public void CardInformationDialogClose()
        {
            _cardInfoNonModalCloseBtn.JSClickWithFocus(Driver);
        }
    }
}
