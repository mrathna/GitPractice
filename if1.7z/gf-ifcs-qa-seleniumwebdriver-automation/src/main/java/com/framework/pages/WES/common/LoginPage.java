package com.framework.pages.WES.common;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

import com.aventstack.extentreports.ExtentTest;
import com.framework.basepage.BasePage;
import com.framework.repo.Locator_WES;
import com.framework.util.PropUtils;

public class LoginPage extends BasePage {

	@FindBy(how = How.XPATH, using = Locator_WES.CRUISE_USERNAME)
	public WebElement cruiseUsername;

	@FindBy(how = How.XPATH, using = Locator_WES.CRUISE_PASSWORD)
	public WebElement cruisePassword;

	@FindBy(how = How.XPATH, using = Locator_WES.CRUISE_SIGNIN)
	public WebElement cruiseSignin;

	@FindBy(how = How.ID, using = Locator_WES.CRUISE_LOGO)
	public WebElement cruiselogo;

	@FindBy(xpath = Locator_WES.SUBOPTION_LOGOUT)
	public WebElement logOut_subOption;

	@FindBy(xpath = Locator_WES.MAINOPTION_LOGOUT)
	public WebElement logOut_mainOption;

	@FindBy(how = How.ID, using = Locator_WES.VELOCITY_USERNAME)
	public WebElement velocityUsername;

	@FindBy(how = How.ID, using = Locator_WES.VELOCITY_PASSWORD)
	public WebElement velocityPassword;

	@FindBy(how = How.CSS, using = Locator_WES.VELOCITY_SIGNIN)
	public WebElement velocitySignin;

	@FindBy(how = How.CSS, using = Locator_WES.VELOCITY_LOGO)
	public WebElement velocityLogo;

	@FindBy(how = How.CSS, using = Locator_WES.LOGIN_BUTTON)
	public WebElement loginButton;

	@FindBy(how = How.XPATH, using = Locator_WES.VELOCITY_LOGOUT)
	public WebElement logoutButton;

	public WebElement clientLogo;

	public LoginPage(WebDriver driver, ExtentTest test) {
		super(driver, test);
		PageFactory.initElements(new AjaxElementLocatorFactory(driver, 15), this);
	}

	// Login the Cruise & Velocity application
	public void loginWES(String url, String uname, String pwd, String ClientName) {

		driver.get(PropUtils.getPropValue(configProp, url));
		System.out.println("URL: " + url);
		if (ClientName.equals("CRUISE")) {
			clientLogo = cruiselogo;
			enterUserNamePasswordAndSignIn(cruiseUsername, uname, cruisePassword, pwd, cruiseSignin);
		} else if (ClientName.equals("VELOCITY")) {
			clientLogo = velocityLogo;
			enterUserNamePasswordAndSignIn(velocityUsername, uname, velocityPassword, pwd, velocitySignin);
		}

	}

	private void enterUserNamePasswordAndSignIn(WebElement userNameElement, String userName, WebElement pwdElement,
			String password, WebElement signIn) {

		if (userName.contains("Velocity")) {
			isDisplayedThenActionClick(loginButton, "Login Button");
			sleep(2);
		}
		isDisplayed(clientLogo, "Client Logo");
		isDisplayedThenEnterText(userNameElement, "User Name Field is Displayed",
				PropUtils.getPropValue(configProp, userName));
		sleep(2);
		isDisplayedThenEnterText(pwdElement, "Password Field is Displayed",
				PropUtils.getPropValue(configProp, password));
		isDisplayedThenClick(signIn, "LoginButton ");

	}

	// LogOut the Cruise Application
	public void logoutTheApplication(String type) {
		if (type.equals("Cruise")) {
			driver.navigate().refresh();
			mouseHover(logOut_mainOption);
			Click(logOut_subOption, "LogOut submenu");
		} else {
			isDisplayedThenActionClick(logoutButton, "Logout Button");
		}

	}
}
