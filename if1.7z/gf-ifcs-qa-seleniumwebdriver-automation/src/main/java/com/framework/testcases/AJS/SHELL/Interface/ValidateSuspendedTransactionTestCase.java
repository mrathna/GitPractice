package com.framework.testcases.AJS.SHELL.Interface;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.TransactionListPage;
import com.framework.pages.AJS.common.Common;
import com.framework.pages.AJS.common.IFCSHomePage;
import com.framework.pages.AJS.common.IFCSLoginPage;

public class ValidateSuspendedTransactionTestCase extends BaseTest{
	
	//prakal
	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test( groups = {"Regression"})
	public void validateAccountToAccountFundTransferWithSameHierarchy(@Optional("RU") String clientCountry,
			@Optional("SHELL") String clientName, @Optional("APA") String cardType)
	{

		test = extent.createTest(clientName+ ":" +clientCountry+"  SHELL IFCS Fund Transfer", "01 Account to Account where both are Billing Nodes");
		//creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);

		TransactionListPage transactionListPage=new TransactionListPage(driver,test);
		Common common=new Common(driver,test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);

		//TansactionListPage transactionlistPage=new TansactionListPage(driver,test);
		// Calling Functions
		IFCSloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, cardType);
		
		IFCSHomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);
		IFCSHomePage.gotoTransactionAndClickManageTransaction();
//		String parentWithBilling=common.getActiveParentCustomerNoInHierarcy("Billing","positive",""," ");
//		String childWithBillingSameHierarchy=common.getActiveChildCustomerNoInSameHierarcy(parentWithBilling,"Billing","positive","");
		
		String parentCusNumber = common.getActiveParentCustomerNoInHierarcy("billing", "positive","balanceAllowed", false, " ", clientName + clientCountry,1);
		String childCusNumber = common.getActiveChildCustomerNoInSameHierarcy(parentCusNumber, " ","billing", "balanceAllowed");
		 
		if(parentCusNumber.equals("") && childCusNumber.equals("")) {
			common.logForNoDataFound(this.getClass().getSimpleName(),"Need to Create Customer Account with balance and Cards with Balance allowed and rerun");
		}
		else {
			
		transactionListPage.verifyFundTransferAccountToAccount(parentCusNumber,childCusNumber,"Validation successful",false);
		common.clickPostTransaction();
		transactionListPage.verifyFundTransferSuccessfulMessage("Account No","Account No","AccToAcc");
		transactionListPage.validateCreditAndDebitAmount("Account No","Account No",parentCusNumber,childCusNumber,"Account to Account");
		}
	    IFCSHomePage.exitIFCS();
	
	} 
	
	//prakal
	
	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test( groups = {"Regression"})
	public void validateAccountToAccountFundTransferNotInSameHierarchy(@Optional("RU") String clientCountry,
			@Optional("SHELL") String clientName, @Optional("APA") String cardType)
	{

	test = extent.createTest(clientName+ ":" +clientCountry+"  SHELL IFCS Fund Transfer Not in Same Hierarchy", "05 Account to Account where both Accounts are Billing but not in the same hierarchy");
	//creating object for the Pages
	IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);

	TransactionListPage transactionListPage=new TransactionListPage(driver,test);
	Common common=new Common(driver,test);
	IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);

	//TansactionListPage transactionlistPage=new TansactionListPage(driver,test);
	 // Calling Functions
	IFCSloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");
    IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, cardType);
	IFCSHomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);
	IFCSHomePage.gotoTransactionAndClickManageTransaction();
	//String parentWithBilling=common.getActiveParentCustomerNoInHierarcy(); 
	 
	String parentCusNoA=common.getActiveParentCustomerNoInHierarcyAlone("billing", "positive","balanceAllowed", false, " ", clientName + clientCountry,1);
	String parentCusNoB=common.getActiveParentCustomerNoInHierarcyAlone("billing", " ","balanceAllowed", false, " ", clientName + clientCountry,2);

	if(parentCusNoA.equals("") && parentCusNoB.equals("")) {
		common.logForNoDataFound(this.getClass().getSimpleName(),"Need to Create Customer Account with balance and Cards with Balance allowed and rerun");
	}
	else {
		
	//String childWithBillingNotSameHierarchy=common.getActiveChildCustomerNoNotInSameHierarchyWithBillingNode(parentWithBilling);
	transactionListPage.verifyFundTransferAccountToAccount(parentCusNoA,parentCusNoB,"Not in the same Hierarchy.",false);
	}
	IFCSHomePage.exitIFCS();

	
	} 
		
	//prakal
	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test(priority =70, groups = {"Regression"})
	public void fundTransferAccountToReplaceCardWithBalancedallowedInSameHierarchy(@Optional("RU") String clientCountry,
	@Optional("SHELL") String clientName, @Optional("APA") String cardType)
	{

	test = extent.createTest(clientName+ ":" +clientCountry+"  SHELL IFCS Account to card","15 Account to Replaced Card  where Account is Billing & card is Balance Allowed");
	//creating object for the Pages
	IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);

	TransactionListPage transactionListPage=new TransactionListPage(driver,test);

	IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
	Common common=new Common(driver,test);

	// Calling Functions
	IFCSloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");

    IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, cardType);

	IFCSHomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);
	IFCSHomePage.gotoTransactionAndClickManageTransaction();
//	String parentWithBilling=common.getActiveParentCustomerNoInHierarcy("Billing"," ","balanceAllowed","replacedCard");
	String parentWithBilling=common.getActiveParentCustomerNoInHierarcyAlone("billing", " ","balanceAllowed",true, " ", clientName + clientCountry,1);
	String replacedCardNo=common.getReplaceCardNoWithBalanceAllowedAndBillingNodeInSameHierarchy(parentWithBilling);
	if(parentWithBilling.equals("") && replacedCardNo.equals("")) {
		common.logForNoDataFound(this.getClass().getSimpleName(),"Need to Create Customer Account with balance and Cards with Balance allowed and rerun");
	}
	else {
	transactionListPage.verifyFundTransferAccountToCard(parentWithBilling,replacedCardNo,"Cannot transfer funds to a card that is already replaced.");
	}
	IFCSHomePage.exitIFCS();
	}
	
	//prakal
	
	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test( groups = {"Regression"})
	public void validateAccountToCardWithBalanceAllowedAndBillingInSameHierarchy(@Optional("RU") String clientCountry,
	@Optional("SHELL") String clientName, @Optional("APA") String cardType)
	{

	test = extent.createTest(clientName+ ":" +clientCountry+"  SHELL IFCS Account to Card where both Account is Billing  & card is Balance Allowed  ", "14 Account to Card where both Account is Billing & card is Balance Allowed & is belonging to this account");
	//creating object for the Pages
	IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);

	TransactionListPage transactionListPage=new TransactionListPage(driver,test);

	IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
	Common common=new Common(driver,test);

	// Calling Functions
	IFCSloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");

IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, cardType);

	IFCSHomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);
	IFCSHomePage.gotoTransactionAndClickManageTransaction();
//	String parentWithBilling=common.getActiveParentCustomerNoInHierarcy("Billing","positive", "", "");

	
	//String childWithBillingSameHierarchy=common.getActiveChildCustomerNoInSameHierarcyWithBillingNode(parentWithBilling);
	//String cardWithBillingAccountAndBalancesAllowed=common.getCardProcessedCardNoInSameHierarchyWithBillingNode(childWithBillingSameHierarchy);
	 
	 String parentCusNumber = common.getActiveParentCustomerNoInHierarcy("billing", " ","balanceAllowed", false, " ", clientName + clientCountry,1);
	 String childCusNumber = common.getActiveChildCustomerNoInSameHierarcy(parentCusNumber, " ","billing", "balanceAllowed");
	 String childCardNo=common.getActiveCardsInHierarcy(childCusNumber," ","balanceAllowed",clientName+clientCountry,1);
		 
	if(parentCusNumber.equals("") && childCardNo.equals("")) {
		common.logForNoDataFound(this.getClass().getSimpleName(),"Need to Create Customer Account with balance and Cards with Balance allowed and rerun");
	}
	else {
	transactionListPage.verifyFundTransferAccountToCard(parentCusNumber,childCardNo,"Validation successful");
	common.clickPostTransaction();
	transactionListPage.verifyFundTransferSuccessfulMessage("Account No","Card No","AccToCard");
	transactionListPage.validateCreditAndDebitAmount("Account No","Card No",parentCusNumber,childCardNo,"Account to Card");
	}
	IFCSHomePage.exitIFCS();
	} 
	
	
 //rax
    @Parameters({ "clientCountry", "clientName", "cardType" })
	@Test( groups = {"Regression"}, enabled=false)
	public void fundTransferCardToAccountBillingNodeAndBalancedAllowed(@Optional("RU") String clientCountry,
	@Optional("SHELL") String clientName, @Optional("APA") String cardType)
	{

	test = extent.createTest(clientName+ ":" +clientCountry+"  SHELL IFCS Card to Account where Account is Billing node,Card is Balance Allowed  ", "03 Card to Account where Account is Billing node,Card is Balance Allowed  ");
	//creating object for the Pages
	IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);

	TransactionListPage transactionListPage=new TransactionListPage(driver,test);

	IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
	Common common=new Common(driver,test);

	// Calling Functions
	IFCSloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");
	IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, cardType);
	// Set the Client 
	IFCSHomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);
	// Select the Manage Transaction from Transaction menu
	IFCSHomePage.gotoTransactionAndClickManageTransaction();
	// Get Active hierarchy customer number 
//	String parentWithBilling =common.getActiveParentCustomerNoInHierarcy("Billing", "positive", "balanceAllowed" , " ");
	// Get same hierarchy balance allowed card number 
//	String cardNoInSameHierarchyAndBalancedAllowed=common.getCardNumberInSameHierarchyAndBalancedAllowed(parentWithBilling);
	
    String parentCusNumber=common.getActiveParentCustomerNoInHierarcy("billing"," ","balanceAllowed",false,"positive",clientName+clientCountry,1);
	String parentCardNo=common.getActiveCardsInHierarcy(parentCusNumber,"positive","balanceAllowed",clientName+clientCountry,1);
	if(parentCusNumber.equals("") && parentCardNo.equals("")) {
		common.logForNoDataFound(this.getClass().getSimpleName(),"Need to Create Customer Account with balance and Cards with Balance allowed and rerun");
	}
	else {
	// Validate fund transfer functionality from Card to Account 
	transactionListPage.verifyFundTransferCardToAccount(parentCardNo,parentCusNumber,"Validation successful");
	common.clickPostTransaction();
	transactionListPage.verifyFundTransferSuccessfulMessage("Card No","Account No","CardToAcc");  
	transactionListPage.validateCreditAndDebitAmount("Card No","Account No",parentCardNo,parentCusNumber,"Card To Account");
	}
	IFCSHomePage.exitIFCS();
	}

	//rax
  @Parameters({ "clientCountry", "clientName", "cardType" })
	@Test( groups = {"Regression"})
	public void fundTransferAccountToCardBillingNodeAndBalancedAllowed(@Optional("RU") String clientCountry,
	@Optional("SHELL") String clientName, @Optional("APA") String cardType)
	{

	test = extent.createTest(clientName+ ":" +clientCountry+"  SHELL IFCS Account to Card where Account is Billing node , Card is Balance Allowed  ", "02 Account to Card where Account is Billing node , Card is Balance Allowed  ");
	//creating object for the Pages
	IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);

	TransactionListPage transactionListPage=new TransactionListPage(driver,test);

	IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
	Common common=new Common(driver,test);

	// Calling Functions
	IFCSloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");
   IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, cardType);

	IFCSHomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);
	IFCSHomePage.gotoTransactionAndClickManageTransaction();
//	String parentCusNumber =common.getActiveParentCustomerNoInHierarcy("billing","positive","balanceAllowed"," ");
//	String cardTo=common.getActiveCardsInHierarcy(parentCusNumber," ","balanceAllowed",clientName+clientCountry,1);
	
	String parentCusNumber=common.getActiveParentCustomerNoInHierarcy("billing","positive","balanceAllowed",false,"positive",clientName+clientCountry,1);
	String cardTo=common.getActiveCardsInHierarcy(parentCusNumber," ","balanceAllowed",clientName+clientCountry,1);
	if(parentCusNumber.equals("") && cardTo.equals("")) {
		//need to call method to logfail
		common.logForNoDataFound(this.getClass().getSimpleName(),"Need to Create Customer Account with balance and Cards with Balance allowed and rerun");	
	}
	else {	
		transactionListPage.verifyFundTransferAccountToCard(parentCusNumber,cardTo,"Validation successful");
		common.clickPostTransaction();
		transactionListPage.verifyFundTransferSuccessfulMessage("Account No","Card No","AccToCard");
		transactionListPage.validateCreditAndDebitAmount("Account No","Card No",parentCusNumber,cardTo,"Account to Card");
	}
	
	IFCSHomePage.exitIFCS();
	}

//rax
	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test( groups = {"Regression"}, enabled=false)
	public void fundTransferCardToAccountNoBillingNodeAndBalancedAllowed(@Optional("RU") String clientCountry,
	@Optional("SHELL") String clientName, @Optional("APA") String cardType)
	{

	test = extent.createTest(clientName+ ":" +clientCountry+"  SHELL IFCS Card to Account where  Account is NOT Billing  but card is Balance Allowed", "11 Card to Account where  Account is NOT Billing  but card is Balance Allowed");
	//creating object for the Pages
	IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);

	TransactionListPage transactionListPage=new TransactionListPage(driver,test);

	IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
	Common common=new Common(driver,test);

	// Calling Functions
	IFCSloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");
	IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, cardType);
	IFCSHomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);
	IFCSHomePage.gotoTransactionAndClickManageTransaction();
//	  String childCustomerNonBilling = common.getActiveChildCustomerNoInHierarcy("nonBilling", " ","balanceAllowed", false, "positive", clientName + clientCountry);
	  String parentCusNumber=common.getActiveParentCustomerNoInHierarcy("nonBilling"," ","balanceAllowed",false,"positive",clientName+clientCountry,1);
	  String childCustomer = common.getActiveChildCustomerNoInSameHierarcy(parentCusNumber, " ","nonBilling", "balanceAllowed");
	  String parentCardNo = common.getActiveCardsInHierarcy(parentCusNumber, "positive", "balanceAllowed",clientName + clientCountry, 1);
	if(childCustomer.equals("") && parentCardNo.equals("")) {
		//need to call method to logfail
		common.logForNoDataFound(this.getClass().getSimpleName(),"Need to Create NonBilling Customer and Balance allowed card and rerun");	
	}
	else {	
		transactionListPage.verifyFundTransferCardToAccount(parentCardNo,childCustomer,"Account is not an Authorisation node");
	}

	IFCSHomePage.exitIFCS();
	} 

	// sasi

	@Parameters({ "clientCountry", "clientName", "cardType" })

	@Test( groups = { "Regression" })
	public void fundTransferAccountToAccountInSameHierarchyWithInsufficientBalance(@Optional("RU") String clientCountry,

			@Optional("SHELL") String clientName, @Optional("APA") String cardType) {

		test = extent.createTest(
				"SHELL IFCS Account to Account where both Accounts are Billing  for Insufficient Funds",
				"Account to Account where both Accounts are Billing  for Insufficient Funds"); // creating object for
																								// the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);

		TransactionListPage transactionListPage = new TransactionListPage(driver, test);

		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		Common common = new Common(driver, test);

		// Calling Functions
		IFCSloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");

		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, cardType);

		IFCSHomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);
		IFCSHomePage.gotoTransactionAndClickManageTransaction();
		 
		 String parentCusNumber = common.getActiveParentCustomerNoInHierarcy("billing", "positive","balanceAllowed", false, " ", clientName + clientCountry,1);
			String childCusNumber = common.getActiveChildCustomerNoInSameHierarcy(parentCusNumber, " ","billing", "balanceAllowed");
		if(parentCusNumber.equals("") && childCusNumber.equals("")) {
			//need to call method to logfail
			common.logForNoDataFound(this.getClass().getSimpleName(),"Need to Create Customer With Negative Balance and rerun");	
		}
		else {	
			transactionListPage.verifyFundTransferAccountToAccount(parentCusNumber,childCusNumber,"Insufficient funds in from account",true);
		}

		IFCSHomePage.exitIFCS();
	}

	// sasi

	@Parameters({ "clientCountry", "clientName", "cardType" })

	@Test( groups = { "Regression" }, enabled=false)
	public void fundTransferCardToCardInSameHierarchyWithInsufficientBalance(@Optional("RU") String clientCountry,

			@Optional("SHELL") String clientName, @Optional("APA") String cardType) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  SHELL IFCS Card to Card where both Cards are Balance Allowed for Insufficient Funds",
				"Card to Card where both Cards are Balance Allowed for Insufficient Funds");
		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);

		TransactionListPage transactionListPage = new TransactionListPage(driver, test);

		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		Common common = new Common(driver, test);

		// Calling Functions
		IFCSloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");

		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, cardType);

		IFCSHomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);
		IFCSHomePage.gotoTransactionAndClickManageTransaction();
		
		String parentCusNumber=common.getActiveParentCustomerNoInHierarcy("billing"," ","balanceAllowed",false,"positive",clientName+clientCountry,1);
		 String cardFrom = common.getActiveCardsInHierarcy(parentCusNumber, "positive","balanceAllowed", clientName + clientCountry, 1);
		  String cardTo = common.getActiveCardsInHierarcy(parentCusNumber, "positive","balanceAllowed", clientName + clientCountry, 2);
		if(cardFrom.equals("") && cardTo.equals("")) {
			//need to call method to logfail
			common.logForNoDataFound(this.getClass().getSimpleName(),"Need to Create Cards With Negative Balance and rerun");	
		}
		else {	
			transactionListPage.validateFundTransferInCardToCard(cardFrom,cardTo ,"Insufficient funds in from card",true);	
		}

		IFCSHomePage.exitIFCS();
	}

	// sasi

	@Parameters({ "clientCountry", "clientName", "cardType" })

	@Test( groups = { "Regression" })
	public void verifyColumnsOnBankingStatementScreen(@Optional("RU") String clientCountry,

			@Optional("SHELL") String clientName, @Optional("APA") String cardType) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  SHELL IFCS Verify the columns on the banking statements screen ",
				"04 Verify the columns on the screen");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		TransactionListPage transactionListPage = new TransactionListPage(driver, test);

		IFCSloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, cardType);
		IFCSHomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry); // Calling Functions
		IFCSHomePage.gotoTransactionAndClickManageTransaction();
		transactionListPage.verifyColumnsOnScreenforBankingStatements();
		IFCSHomePage.exitIFCS();

	}

	@Parameters({ "clientCountry", "clientName", "cardType" })

	@Test( groups = { "Regression" })
	public void verifyDrillDownDetailsOfStatement(@Optional("RU") String clientCountry,

			@Optional("SHELL") String clientName, @Optional("APA") String cardType) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  SHELL IFCS Verify Drill down to details of Banking Statement ",
				"06 Drill down to details of Statement");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		TransactionListPage transactionListPage = new TransactionListPage(driver, test);

		IFCSloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, cardType);
		IFCSHomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry); // Calling Functions
		IFCSHomePage.gotoTransactionAndClickManageTransaction();
		transactionListPage.verifyingTheDetailsOfBankingStatements();
		IFCSHomePage.exitIFCS();

	}

	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test( groups = {"Regression"})
	public void verifyTheFilterConditionForTransactions(@Optional("RU") String clientCountry,
			@Optional("SHELL") String clientName, @Optional("APA") String cardType) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  SHELL IFCS Transactions-06 Verify the Filter conditions",
				"06 Verify the Filter conditions");
		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);

		TransactionListPage transactionListPage = new TransactionListPage(driver, test);

		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		// Calling Functions
		IFCSloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, cardType);
		// Verify the filter condition for Transaction
		IFCSHomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);
		IFCSHomePage.gotoTransactionAndClickManageTransaction();
		transactionListPage.verifyFilterConditionforTransactions(clientName, clientCountry);
		IFCSHomePage.exitIFCS();
	}

	@Parameters({ "clientCountry", "clientName", "cardType" })

	@Test( groups = { "Regression" })
	public void verifyFilterConditionsOnBankingStatementScreen(@Optional("RU") String clientCountry,

			@Optional("SHELL") String clientName, @Optional("APA") String cardType) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  SHELL IFCS Verify the Filter conditions on the banking statements screen ",
				"05 Verify the Filter conditions");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		TransactionListPage transactionListPage = new TransactionListPage(driver, test);

		IFCSloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, cardType);
		IFCSHomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry); // Calling Functions
		IFCSHomePage.gotoTransactionAndClickManageTransaction();
		transactionListPage.verifyFilterConditionforBankingSatements();
		IFCSHomePage.exitIFCS();

	}

	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test( groups = {"Regression"})
	public void verifyColumnsForTransactions(@Optional("RU") String clientCountry,
			@Optional("SHELL") String clientName, @Optional("APA") String cardType)
	{

		test = extent.createTest(clientName+ ":" +clientCountry+"  SHELL IFCS Verify the columns on the screen", "04 Verify the columns on the screen");
		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);

		TransactionListPage transactionListPage = new TransactionListPage(driver, test);

		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);

		// Calling Functions
		IFCSloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");
		// Verify Columns For Transaction
		IFCSHomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);
		IFCSHomePage.gotoTransactionAndClickManageTransaction();
		transactionListPage.verifyColumnDetailsInTableForTransaction();
		IFCSHomePage.exitIFCS();
	}

	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test( groups = {"Regression"})
	public void DrillDownToDetailsOfTransaction(@Optional("RU") String clientCountry,
			@Optional("SHELL") String clientName, @Optional("APA") String cardType) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  SHELL IFCS Transaction details drill down", "07 Transaction details drill down");
		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);

		TransactionListPage transactionListPage = new TransactionListPage(driver, test);

		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		Common common = new Common(driver, test);
		// TansactionListPage transactionlistPage=new TansactionListPage(driver,test);
		// Calling Functions
		IFCSloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, cardType);

		IFCSHomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);

		// Getting Active Customer No From DB
		String customerNoUsingCardType = common.getActiveCustomerNoUsingCardType();
		if (customerNoUsingCardType.equals(" ")) {
			common.logForNoDataFound(this.getClass().getSimpleName(),
					"Need to Create A Customer using card Type and rerun");
		} else {
			// Drill Down To Details Of Transaction
			IFCSHomePage.gotoCustomerMenuCustomerDetails();
			common.chooseCustomerNoAndSearch(customerNoUsingCardType);
			transactionListPage.drillDownToDetailsOfTransaction();
			transactionListPage.verifyDetailsInTransactionInformationTab();
			transactionListPage.verifyDetailsInCustomerBreakdown();
			transactionListPage.verifyDetailsInMerchantBreakdown();

		}
		IFCSHomePage.exitIFCS();
	}

	@Parameters({ "clientCountry", "clientName", "cardType" })
		@Test( groups = {"Regression"})
		public void validateSuspendedTransColumnOnTheScreen(@Optional("RU") String clientCountry,
		@Optional("SHELL") String clientName, @Optional("APA") String cardType)
		{

		test = extent.createTest(clientName+ ":" +clientCountry+"  SHELL IFCS Suspended Transaction", "05 Verify the columns on the screen");
		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);

		TransactionListPage transactionListPage = new TransactionListPage(driver, test);

		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);

		
		// Calling Functions
		IFCSloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");

		IFCSHomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);
		IFCSHomePage.gotoTransactionAndClickManageTransaction();
		transactionListPage.verifyColumnsOnScreenforSuspendedTran();
		IFCSHomePage.exitIFCS();

		}
	
      @Parameters({ "clientCountry", "clientName", "cardType" })
		@Test( groups = {"Regression"}, enabled=false)
		public void validateSuspendedTransFilterCondition(@Optional("RU") String clientCountry,
		@Optional("SHELL") String clientName, @Optional("APA") String cardType)
		{

		test = extent.createTest(clientName+ ":" +clientCountry+"  SHELL IFCS Suspended Transaction", "06 Verify the Filter conditions");
		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);

		TransactionListPage transactionListPage = new TransactionListPage(driver, test);

		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);

		// TansactionListPage transactionlistPage=new TansactionListPage(driver,test);
		// Calling Functions
		IFCSloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");
		
		IFCSHomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);
		IFCSHomePage.gotoTransactionAndClickManageTransaction();
		transactionListPage.verifyFilterConditionforSuspendedTran();
		IFCSHomePage.exitIFCS();

		}

		
		@Parameters({ "clientCountry", "clientName", "cardType" })
		@Test( groups = {"Regression"}, enabled=false)
		public void validateSuspendedTransaction(@Optional("RU") String clientCountry,
		@Optional("SHELL") String clientName, @Optional("APA") String cardType)
		{

		test = extent.createTest(clientName+ ":" +clientCountry+"  SHELL IFCS Suspended Transaction", "07 Validate a suspended Transaction");
		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);

		TransactionListPage transactionListPage = new TransactionListPage(driver, test);

		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);

		
		// Calling Functions
		IFCSloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");

		IFCSHomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);
		IFCSHomePage.gotoTransactionAndClickManageTransaction();
		transactionListPage.verifySuspendedTransactionLabelsInPopup();
		IFCSHomePage.exitIFCS();
		}
		
		@Parameters({ "clientCountry", "clientName", "cardType" })
		@Test( groups = {"Regression"}, enabled=false)
		public void validateDeleteTransaction(@Optional("RU") String clientCountry,
		@Optional("SHELL") String clientName, @Optional("APA") String cardType)
		{

		test = extent.createTest(clientName+ ":" +clientCountry+"  SHELL IFCS Suspended Transaction", "09 Delete the suspended transactions");
		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);

		TransactionListPage transactionListPage = new TransactionListPage(driver, test);

		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);

		
		// Calling Functions
		IFCSloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");

		IFCSHomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);
		IFCSHomePage.gotoTransactionAndClickManageTransaction();
		transactionListPage.deleteTheSuspendedTransaction();
		IFCSHomePage.exitIFCS();

	}

	// Added by Ayub 26-02-2019

	@Parameters({ "clientCountry", "clientName", "cardType" })

	@Test( groups = { "Regression" })
	public void validateBillingAccountToNotBalanceAllowedCardFundTransfer(@Optional("RU") String clientCountry,

			@Optional("SHELL") String clientName, @Optional("APA") String cardType) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  Verify 09 Account to Card where  Accounts is Billing but Card is NOT Balance Allowed",
				"Accounts is Billing but Card is NOT Balance Allowed"); // creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);

		Common common = new Common(driver, test);

		TransactionListPage transactionListPage = new TransactionListPage(driver, test);

		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);

		// TansactionListPage transactionlistPage=new TansactionListPage(driver,test);
		// Calling Functions
		IFCSloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, cardType);
		// IFCSHomePage.gotoAdminMenuAndChooseClient();
		IFCSHomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);
		// Go to ManageTransaction
		IFCSHomePage.gotoTransactionAndClickManageTransaction();
		// Get the Hierarchy CustomerNunmber With BillingNode And HasBalance from DB
		String parentCusNumber=common.getActiveParentCustomerNoInHierarcy("billing"," ","noBalanceAllowed",false," ",clientName+clientCountry,1);
		String parentCardNo=common.getActiveCardsInHierarcy(parentCusNumber," ","noBalanceAllowed",clientName+clientCountry,1);
		if(parentCusNumber.equals("") && parentCardNo.equals("")) {
				common.logForNoDataFound(this.getClass().getSimpleName(),"Need to Create Customer Account with balance and Cards with Balance allowed and rerun");
		}else {
		// Get the Not Balance Allowed CardNumber in the same Hierarchy customer form DB
//		String notBalanceCardNumber = common.getNotBalanceAllowedCardNumber(parentWithBilling);
		// Fund Transfer Account to Card where  Accounts is Billing but Card is NOT Balance Allowed and validation 
		transactionListPage.verifyFundTransferAccountToCard(parentCusNumber,parentCardNo,"Card is not allowed to have balance");
		} 
		IFCSHomePage.exitIFCS();		

	} // Added by Ayub 27-02-2019

	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test( groups = { "Regression" })
	public void validateFundTransferAccountToCardWhereCardDoesNotBelongToTheAccount(
			@Optional("RU") String clientCountry, @Optional("SHELL") String clientName,
			@Optional("APA") String cardType) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  Verify 12 Account to Card where card does not belong to the Account",
				"Accounts is Billing but Card is Balance Allowed but not belong to the account");
		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		Common common = new Common(driver, test);

		TransactionListPage transactionListPage = new TransactionListPage(driver, test);

		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);

		// TansactionListPage transactionlistPage=new TansactionListPage(driver,test);
		// Calling Functions
		IFCSloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, cardType); // IFCSHomePage.gotoAdminMenuAndChooseClient();
		IFCSHomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);
		IFCSHomePage.gotoTransactionAndClickManageTransaction();
		// Get the Hierarchy CustomerNunmber With BillingNode And HasBalance from DB
//		String parentWithBilling = common.getHierarchyCustomerNunmberWithBillingNodeAndHasBalance();
		// Get the Balance Allowed CardNumber in the not same Hierarchy customer form DB
//		String balanceCardNumber = common.getBalanceAllowedCardNumber(parentWithBilling);
		
		String parentCusNumber1=common.getActiveParentCustomerNoInHierarcy("billing"," ","balanceAllowed",false," ",clientName+clientCountry,1);
		String parentCusNumber2=common.getActiveParentCustomerNoInHierarcy("billing"," ","balanceAllowed",false," ",clientName+clientCountry,2);
		String parent2CardNo=common.getActiveCardsInHierarcy(parentCusNumber2," ","balanceAllowed",clientName+clientCountry,1);
		if(parentCusNumber1.equals("") && parent2CardNo.equals("")) {
			common.logForNoDataFound(this.getClass().getSimpleName(),"Need to Create A Customer with Account SubStatus as Payment Pending and rerun");
		} else {
		// Fund Transfer Account to Card where Accounts is Billing but Card is Balance Allowed and validation & Protected fields 
//		transactionListPage.verifyFundTransferAccountToCard(parentCusNumber1, parent2CardNo,"No Hierarchy found for this card");
		
		transactionListPage.verifyFundTransferAccountToCard(parentCusNumber1, parent2CardNo,"Not in the same Hierarchy.");
		}
		IFCSHomePage.exitIFCS();
		
	}

	@Parameters({ "clientCountry", "clientName", "cardType" })

	@Test( groups = { "Regression" })
	public void validateAccountToAccountFundTransferTheNonBillingChildWithSameHierarchy(
			@Optional("RU") String clientCountry,

			@Optional("SHELL") String clientName, @Optional("APA") String cardType) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  Verify 10 Account to Account where only parent Account is Billing", "10 Account to Account where only parent Account is Billing");
		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);

		TransactionListPage transactionListPage = new TransactionListPage(driver, test);
		Common common = new Common(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);

		// TansactionListPage transactionlistPage=new TansactionListPage(driver,test);
		// Calling Functions
		IFCSloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");
		// IFCSHomePage.gotoAdminMenuAndChooseClient("SHELL Czech Republic");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, cardType);
		IFCSHomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);
		// Go to Manage Transaction
		IFCSHomePage.gotoTransactionAndClickManageTransaction();
		// Get the Parent Account Number with billing node
//		String parentWithBilling = common.getActiveParentCustomerNoInHierarcy("billing","positive","balanceAllowed"," ");
//		String childWithBillingSameHierarchy = common.getActiveChildCustomerNoInSameHierarcy(parentWithBilling," ","nonBilling","balanceAllowed");
		
		String parentCusNumber=common.getActiveParentCustomerNoInHierarcy("nonBilling"," ","balanceAllowed",false," ",clientName+clientCountry,1);
		String childCustomer = common.getActiveChildCustomerNoInSameHierarcy(parentCusNumber, " ","nonBilling", "balanceAllowed");
		if(parentCusNumber.equals("") && childCustomer.equals("")) {
			common.logForNoDataFound(this.getClass().getSimpleName(),"Need to Create A Customer with Account SubStatus as Payment Pending and rerun");
		} else {
		transactionListPage.verifyFundTransferAccountToAccount(parentCusNumber, childCustomer,"Account is not an Authorisation node",false);
		}

		 IFCSHomePage.exitIFCS();
	}

	@Parameters({ "clientCountry", "clientName", "cardType" })

	@Test( groups = { "Regression" })
	public void validateCardToCardFundTransferInHirearchy(@Optional("RU") String clientCountry,
			@Optional("SHELL") String clientName, @Optional("APA") String cardType) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  04 Card to Card where both Cards are Balance Allowed","Verify Card to Card where both Cards are Balance Allowed");
		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);

		TransactionListPage transactionListPage = new TransactionListPage(driver, test);

		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		Common common = new Common(driver, test);

		// Calling Functions
		IFCSloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, cardType);
		IFCSHomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);
		// Go to Manage Transaction page
		IFCSHomePage.gotoTransactionAndClickManageTransaction();
		// Get the customer number has two cards
//		String customerNoHasTwoCards = common.getHierarchyCustomerNunmberHasTwoCardsWithBillingNodeAndHasBalance();
		// Get hierarchy Active card
//		String fromCard = common.getActiveCardsInHierarcy(customerNoHasTwoCards, "positive", "balanceAllowed",clientName + clientCountry, 1);
		// Get same hierarchy Active card
//		String toCard = common.getActiveCardsInHierarcy(customerNoHasTwoCards, "positive", "balanceAllowed",clientName + clientCountry, 2);
		
		String parentCusNumber=common.getActiveParentCustomerNoInHierarcy("billing"," ","balanceAllowed",false,"positive",clientName+clientCountry,2);
		String cardNo1=common.getActiveCardsInHierarcy(parentCusNumber,"positive","balanceAllowed",clientName+clientCountry,1);
		String cardNo2=common.getActiveCardsInHierarcy(parentCusNumber,"positive","balanceAllowed",clientName+clientCountry,2);
		if(cardNo1.equals("") && cardNo2.equals("")) {
			common.logForNoDataFound(this.getClass().getSimpleName(),"Need to Create A Customer with Account SubStatus as Payment Pending and rerun");
		} else {
		// fund transfer from hierarchy card to non hierarchy card
		transactionListPage.validateFundTransferInCardToCard(cardNo1, cardNo2, "Validation successful",false);
		// Validate successful message
		transactionListPage.verifyFundTransferSuccessfulMessage("Card No","Card No","CardToCard");
		// To check the credit amount
		transactionListPage.validateCreditAndDebitAmount("Card No","Card No",cardNo1,cardNo2,"Card to Card");
		}
		IFCSHomePage.exitIFCS();
	} 

	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test( groups = { "Regression" }, enabled=false)
	public void validateCardToCardFundTransferInNoHirearchy(@Optional("RU") String clientCountry,
			@Optional("SHELL") String clientName, @Optional("APA") String cardType) {

		test = extent.createTest(
				"Verify 06 Card to Card where both Cards are Balance Allowed but not in the same hierarchy",
				"Verifying 06 Card to Card where both Cards are Balance Allowed  but not in the same hierarchy");
		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);

		TransactionListPage transactionListPage = new TransactionListPage(driver, test);

		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		Common common = new Common(driver, test);

		// Calling Functions
		IFCSloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, cardType);
		// Set the client
		IFCSHomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);
		// Go to Manage Transaction page
		IFCSHomePage.gotoTransactionAndClickManageTransaction();
		 		
		// Get Active hierarchy customer number
//		String parentWithBilling = common.getActiveParentCustomerNoInHierarcy(" ", "positive", "balanceAllowed" ," ");
		// Get same hierarchy balance allowed card number
//		String fromCard = common.getActiveCardsInHierarcy(parentWithBilling,"positive","balanceAllowed",clientName+clientCountry,1);
		// Get the Non hierarchy Active balance allowed card
		
		String parentCusNumber=common.getActiveParentCustomerNoInHierarcy("billing"," ","balanceAllowed",false,"positive",clientName+clientCountry,2);
		String cardNo1=common.getActiveCardsInHierarcy(parentCusNumber,"positive","balanceAllowed",clientName+clientCountry,1);
		String cardNo2 = common.getActiveCardsNotInHierarcy("zero", "balanceAllowed", clientName+clientCountry , 1);
		if(cardNo1.equals("") && cardNo2.equals("")) {
			common.logForNoDataFound(this.getClass().getSimpleName(),"Need to Create A Customer with Account SubStatus as Payment Pending and rerun");
		} else {
		// Fund Transfer from hierarchy card to Non hierarchy Active balance allowed card and validate
		transactionListPage.validateFundTransferInCardToCard(cardNo1, cardNo2, "No Hierarchy found for this card",false);
		}
		IFCSHomePage.exitIFCS();

	} 
			
			@Parameters({ "clientCountry", "clientName", "cardType" })
			@Test( groups = {"Regression"})
			public void validatePostTransaction(@Optional("RU") String clientCountry,
					@Optional("SHELL") String clientName, @Optional("APA") String cardType)
			{

				test = extent.createTest(clientName+ ":" +clientCountry+"  SHELL IFCS Suspended Transaction", "09 Delete the suspended transactions");
				// creating object for the Pages
				IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);

				TransactionListPage transactionListPage = new TransactionListPage(driver, test);

				IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);


				// Calling Functions
				IFCSloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");

				IFCSHomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);
				IFCSHomePage.gotoTransactionAndClickManageTransaction();
				transactionListPage.validatePostSuspendedtransaction("refernceNo");
				transactionListPage.clickingPostAndValidate();
				IFCSHomePage.exitIFCS();

			}

			@Parameters({ "clientCountry", "clientName", "cardType" })
			@Test( groups = {"Regression"})
			public void validateForcePostTransaction(@Optional("RU") String clientCountry,
					@Optional("SHELL") String clientName, @Optional("APA") String cardType)
			{

				test = extent.createTest(clientName+ ":" +clientCountry+"  SHELL IFCS Suspended Transaction", "09 Delete the suspended transactions");
				// creating object for the Pages
				IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);

				TransactionListPage transactionListPage = new TransactionListPage(driver, test);

				IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);


				// Calling Functions
				IFCSloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");

				IFCSHomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);
				IFCSHomePage.gotoTransactionAndClickManageTransaction();
				transactionListPage.validatePostSuspendedtransaction("refernceNo");
				transactionListPage.clickingForcePostAndValidate();
				IFCSHomePage.exitIFCS();

			}
	}
	
/*	
	 * // Sasi // trying to increase column width
	 * 
	 * @Parameters({ "clientCountry", "clientName", "cardType" })
	 * 
	 * @Test(groups = { "Regression" }) public void
	 * verifyDrillDownDetailsOfStatement(@Optional("CZ") String clientCountry,
	 * 
	 * @Optional("SHELL") String clientName, @Optional("APA") String cardType) {
	 * test =
	 * extent.createTest(clientName+ ":" +clientCountry+"  SHELL IFCS Verify Drill down to details of Statement ",
	 * "Verify Drill down to details of Statement");
	 * 
	 * // creating object for the Pages IFCSLoginPage IFCSloginPage = new
	 * IFCSLoginPage(driver, test); IFCSHomePage IFCSHomePage = new
	 * IFCSHomePage(driver, test); TransactionListPage transactionListPage = new
	 * TransactionListPage(driver, test); Common common = new Common(driver, test);
	 * 
	 * IFCSloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME",
	 * "IFCS_SHELL_PASSWORD");
	 * IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry,
	 * cardType); IFCSHomePage.gotoAdminMenuAndChooseClient(clientName + "_" +
	 * clientCountry); // Calling Functions //
	 * transactionListPage.verifyingTheDetailsOfBankingStatements();
	 * transactionListPage.verifyingOfBankingStatements();
	 * 
	 * IFCSHomePage.exitIFCS();
	 * 
	 * }*/
	 


