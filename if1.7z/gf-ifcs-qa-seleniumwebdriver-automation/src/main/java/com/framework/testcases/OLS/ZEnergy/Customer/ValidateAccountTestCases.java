//package com.framework.testcases.OLS.ZEnergy.Customer;
package com.framework.testcases.OLS.ZEnergy.Customer;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.OLS.common.CommonPage;
import com.framework.pages.OLS.common.LoginPage;
import com.framework.pages.Z.ZHomePage;

public class ValidateAccountTestCases extends BaseTest {

	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "Smoke" })
	public void validateAccountStatusSubAccount(@Optional("Z") String clientCountry,
			@Optional("Z Energy Limited") String clientName) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  Verify that the user account should be visible on each submenu.", "Verify that the user account should be visible on each submenu.");

		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);

		ZHomePage zHomePage = new ZHomePage(driver, test);
		CommonPage commonPage = new CommonPage(driver, test);

		loginPage.Login("ZEnergy_URL", "ZEnergy_UN_Customer_" + clientCountry, "ZEnergy_PWD_Customer_" + clientCountry,
				clientName);

		commonPage.validateClientLogo();

		// Changing the Account in home page
		zHomePage.selectAccountFromDropdownAndValidate();
		zHomePage.verifyCustomerNameInHomePage();

		// Logout
		loginPage.Logout();

	}

	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "Smoke" })
	public void validateParentStandaloneAccountDetailsSubAccount(@Optional("Z") String clientCountry,
			@Optional("Z Energy Limited") String clientName) {

		test = extent.createTest(
				"Verify that user can view the Account status and Credit limit in OLS home page for selected account",
				"Verify that user can view the Account status and Credit limit in OLS home page for selected account");

		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		ZHomePage zHomePage = new ZHomePage(driver, test);
		CommonPage commonPage = new CommonPage(driver, test);

		loginPage.Login("ZEnergy_URL", "ZEnergy_Parent_Standalone_Customer_" + clientCountry,
				"ZEnergy_PWD_Parent_Standalone_Customer_" + clientCountry, clientName);

		commonPage.validateClientLogo();

		// Changing the Account in home page
		zHomePage.selectAccountFromDropdownAndValidate();
		zHomePage.verifyCustomerNameInHomePage();
		commonPage.verifyAccountStatusDetails("parent");
		commonPage.validateClientLogo();

		// Logout
		loginPage.Logout();

	}

	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "Smoke" })
	public void validateChildAccountDetailsSubAccount(@Optional("Z") String clientCountry,
			@Optional("Z Energy Limited") String clientName) {

		test = extent.createTest(
				"Verify that available balance, Last invoice date and next invoice date should display in the home page",
				"Verify that available balance, Last invoice date and next invoice date should display in the home page");

		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		ZHomePage zHomePage = new ZHomePage(driver, test);
		CommonPage commonPage = new CommonPage(driver, test);

		loginPage.Login("ZEnergy_URL", "ZEnergy_Child_Customer_" + clientCountry,
				"ZEnergy_PWD_Child_Customer_" + clientCountry, clientName);

		commonPage.validateClientLogo();

		// Changing the Account in home page
		zHomePage.selectAccountFromDropdownAndValidate();
		zHomePage.verifyCustomerNameInHomePage();
		commonPage.verifyAccountStatusDetails("child");
		commonPage.validateClientLogo();

		// Logout
		loginPage.Logout();

	}

}
