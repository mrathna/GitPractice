﻿using Common;
using Common.Utility;
using EnCompass.Testing.Source.PageObjects.Controls;
using NFluent;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Support.UI;
using System.Collections.Generic;

namespace EnCompass.Testing.Source.PageObjects.Organization.ExpenseManager.Transactions
{
    [PageModel(@"/expenseManager/transactions/FinancialCodeProfileAssigntoCards.aspx")]
    public class FinancialCodeProfileAssigntoCards : EnCompassOrgPageModel
    {
        public override string RelativeUrl => @"/expenseManager/transactions/FinancialCodeProfileAssigntoCards.aspx";
        public override string PageIdentifierXPath_Override => @"//h1[contains(@id,'h1title')]";

        #region XPath page Elements
        private const string _availableProfilesXPath = @"//select[contains(@id,'From')]";
        private const string _assignAllProfileAvailableXPath = @"//button[contains(@id,'AddAll')]";
        private const string _availableAllProfileAssignedXPath = @"//button[contains(@id,'RemoveAll')]";
        private const string _saveXPath = @"//input[contains(@id,'btnsave')]";
        private const string _successMessageXPath = ".//div[contains(@id,'divMessage')]";
        private const string _cancelXPath = @"//*[normalize-space(text())='Cancel']";
        private const string _allowHierarchyXPath = ".//input[@type ='checkbox' and contains(@id,'chbAllowHierarchy')]";
        #endregion

        #region Page Elements
        private IWebElement _availableProfiles
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_availableProfilesXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_availableProfiles element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _assignAllProfileAvailable
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_assignAllProfileAvailableXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_assignAllProfileAvailable element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _availableAllProfileAssigned
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_availableAllProfileAssignedXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_availableAllProfileAssigned element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _save
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_saveXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_save element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _successMessage
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_successMessageXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_successMessage element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _cancel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_cancelXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_cancel element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _allowHierarchy
        {
            get
            {
                //TryWaitForElementToBeVisible is not working hence replaced with TryWaitForElement
                bool found = Driver.TryWaitForElement(By.XPath(_allowHierarchyXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_allowHierarchy element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        #endregion

        public void CheckAvailableProfiles()
		{
			Check.That(_availableProfiles).IsNotNull();
		}

		public void AssignAllProfileAvailable()
		{
			_assignAllProfileAvailable.JSClickWithFocus(Driver);
		}

		public void AvailableAllProfileAssigned()
		{
			_availableAllProfileAssigned.JSClickWithFocus(Driver);
		}

		public void AssignProfileAvailable(List<string> CodeProfilesList)
		{
			foreach (string profileName in CodeProfilesList)
			{
                Driver.TryWaitForElement(By.XPath("//select[contains(@id,'ThisToThat1_From')]"), out IWebElement swebelement);
                SelectElement sElement = new SelectElement(swebelement);
                sElement.SelectByText(profileName);
                Settings.EnCompassExtentTest.Info("Clicked on Profile Name:" + profileName);
            }
            this.AttachOnDemandScreenShot();
            AddProfileAvailable();
        }

		public void AddProfileAvailable()
		{
            Driver.TryWaitForElementToBeVisible(By.XPath("//button[contains(@id,'Add') and @title='Move selected to assigned']/span"),
             out IWebElement _addProfileAvailable);
            _addProfileAvailable.JSClickWithFocus(Driver);
			Settings.EnCompassExtentTest.Info("Clicked on '>' to move Selected to Assigned");
            this.AttachOnDemandScreenShot();
		}

		public void AvailableProfileAssigned(string CodeProfiles)
		{
			WaitForLoad(); Driver.TryWaitForElement(By.XPath("//select[contains(@id,'ThisToThat1_To')]"), out IWebElement swebelement);
            SelectElement sElement = new SelectElement(swebelement);
            sElement.SelectByText(CodeProfiles);
            Settings.EnCompassExtentTest.Info("Clicked on Profile Name:" + CodeProfiles + " under Assigned Profiles section");
            this.AttachOnDemandScreenShot();    
            RemoveProfileAssigned();
		}

		public void RemoveProfileAssigned()
		{
            Driver.TryWaitForElementToBeVisible(By.XPath("//button[contains(@id,'Remove') and @title='Move selected to available']/span"),
                out IWebElement _removeProfileAssigned);
			_removeProfileAssigned.JSClickWithFocus(Driver);
            Settings.EnCompassExtentTest.Info("Clicked on '<' button to Remove Profile.");
            this.AttachOnDemandScreenShot();
        }

		public string CardFinancialCodeProfilesSuccessMessage
		{
			get
			{
				return _successMessage.Text;
			}
		}

		public void PressSave()
		{
			_save.JSClickWithFocus(Driver);
			this.AttachOnDemandScreenShot();
		}

        public void WaitForSuccessMsg()
        {
            Driver.WaitForVisible(By.XPath("//div[contains(@id,'SuccessMessage')]"));
        }

        public void PressCancel()
		{
			_cancel.JSClickWithFocus(Driver);
		}

		public FinancialCodeProfileAssigntoCards(GlobalSettings settings) : base(settings) { }
	}
}
