﻿using AventStack.ExtentReports;
using Common.Utility;
using EnCompass.Testing.Source.PageObjects.Controls;
using NFluent;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace EnCompass.Testing.Source.PageObjects.Organization.DecisionStream.AccountManagement
{
	public partial class Main
	{
        #region xpath

        public override string PageIdentifierXPath_Override => @"//li[contains(@class, 'breadcrumb-item active')][text() = 'Card Maintenance']";
        public const string FullAccount = @"//iframe[contains(@id, 'viewFullAccount')]";
        private const string _searchTermXPath = @"//select[contains(@id,'searchTermSelect')]";
        private const string _searchValueXPath = @"//select[contains(@id,'SearchOutput_values')]";
        private const string _searchtxtXPath = @"//div[contains(@id,'searchTermValueInputGroup')]//input[contains(@id, 'SearchOutput_txt')]";
        private const string _addBtnXPath = @"//div[@class='input-group-append']//input[@value='Add']";
        private const string _resetBtnXPath = @"//div[@class='btn-row']//button[text()='Clear']";
        private const string _searchBtnXPath = @"//input[contains(@id, 'btnSearch')]";
        private const string _editBtnXPath = @"//a[contains(@id,'actionLink') and text()='Edit']";
        private const string _historyBtnXPath = @"//a[contains(@id,'actionLink') and text()='History']";
        private const string createCardsBtnXPath = @"//a[contains(@role,'button') and contains(@href,'AddSingle')]";
        private const string _viewBtnXPath = @"//a[contains(@id, 'actionLink3')]";
        private const string _accountNumberXPath = @"//div[contains(@class, 'card-body text-center')]/h2";
        private const string _closeBtnXPath = @"//input[contains(@name, 'footerContent') and @value= 'Close']";
        private const string _cardStatusViewBtnXPath = @"//span[contains(@id, 'popStatusCount')]";
        private const string _nToggleXPath = "//h2[contains(@id,'acpVelocityLimits')]/button[@data-toggle='collapse']";
        private string _chkMyCardsLabelXpath = ".//label[contains(@for,'chkMyCards')] ";
        private string _chkMyCardsCBXpath = ".//input[contains(@id,'chkMyCards')] ";

        #endregion

        #region IWebElements Props

        public IWebElement _searchTerm
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_searchTermXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_searchTerm element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _searchValue
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_searchValueXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_searchValue element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _searchtxt
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_searchtxtXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_searchtxt element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _addBtn
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_addBtnXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_addBtn element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _resetBtn
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_resetBtnXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_resetBtn element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _searchBtn
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_searchBtnXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_searchBtn element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _editBtn
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_editBtnXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_editBtn element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _historyBtn
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_historyBtnXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_historyBtn element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement createCardsBtn
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(createCardsBtnXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("createCardsBtn element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _viewBtn
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_viewBtnXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_viewBtn element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _accountNumber
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_accountNumberXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_accountNumber element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _closeBtn
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_closeBtnXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_closeBtn element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _cardStatusViewBtn
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_cardStatusViewBtnXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_cardStatusViewBtn element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public IWebElement _nToggle
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_nToggleXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_nToggle element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }


        #endregion

        #region MyRegion

        private const string AC_MAINFORM = "content_contents_acMainForm";
        private const string AP_LIMITS = "acpVelocityLimits";
        #endregion

        private GridControl _cardGrid;
		public GridControl CardGrid
		{
			get
			{
				_cardGrid = new GridControl("dgAccounts", Driver);
				_cardGrid.WaitForGrid();
				return _cardGrid;
			}
		}

		/// <summary>
		/// Set Search Term Value
		/// </summary>
		public void SetSearchTermByValue(string whichText)
		{
			_searchTerm.SetListboxByText(whichText, SelectTextOptions.Exact, Driver, Settings, _searchTermXPath);
			Settings.EnCompassExtentTest.Info($"Setting Search Term to: {whichText}");
        }

		/// <summary>
		/// Set the Search Category Option in the DDL
		/// </summary>
        public void SetSearchValueByValue(string whichText)
		{
			_searchValue.SetListboxByText(whichText, SelectTextOptions.Exact, Driver, Settings, _searchValueXPath);
			Settings.EnCompassExtentTest.Debug("Search Category Set to: " + whichText);
		}

		public void AddBtn()
		{
			_addBtn.JSClickWithFocus(Driver);
			Settings.EnCompassExtentTest.Info("Clicked on Add Button.");
        }

        public void ResetBtn()
		{
			_resetBtn.JSClickWithFocus(Driver);
			Settings.EnCompassExtentTest.Info("Clicked on Reset Button.");
        }

        public string SearchTxt
		{
			set
			{
				_searchtxt.SendKeys(value);
				Settings.EnCompassExtentTest.Info("Setting Search Text to: " + value);
			}
		}

		public void SearchAccountWith(string searchOption, string searchValue)
		{
			ResetBtn();
			SetSearchTermByValue(searchOption);
			SearchTxt = searchValue;
			AddBtn();
			SearchBtn();
			WaitForLoad();
		}

		public void EditBtn()
		{
			_editBtn.JSClickWithFocus(Driver);
			Settings.EnCompassExtentTest.Info("Clicked on Edit button.");
		}

		public void SearchBtn()
		{
			_searchBtn.JSClickWithFocus(Driver);
            WaitForLoad();
			Settings.EnCompassExtentTest.Info("Clicked on Search button.");
		}

		public void HistoryBtn()
		{
			_historyBtn.JSClickWithFocus(Driver);
			Settings.EnCompassExtentTest.Info("Clicked on History button.");
		}

		public void CreateCardBtn()
		{
			createCardsBtn.JSClickWithFocus(Driver);
			Settings.EnCompassExtentTest.Info("Clicked on Create button to create test cards.");
		}

		public void GetCardNumbersForCurrentSearch()
		{
			var count = CardGrid.GetColumnText("Card Number").Count();
			Dictionary<string, string> currencyTypeAccountNumbers = new Dictionary<string, string>();
			var billingCurrency = CardGrid.GetColumnText("Billing Currency");
			for (int i = 0; i < count; i++)
			{
				//Driver.WaitForDocumentLoadToComplete();
				CardGrid.SelectRow(i + 1);

				_viewBtn.Click();

				using (var helper = new FrameHelper(Driver, By.XPath(FullAccount)))
				{
					Driver.WaitForDocumentLoadToComplete();
					RefreshModel();
					var element = helper.FindElement(By.XPath("//div[contains(@class, 'card-body text-center')]/h2"));

					if (element != null)
					{
						currencyTypeAccountNumbers.Add(billingCurrency.ToList()[i].ToString(), element.Text.ToString().Replace("-", ""));
						_closeBtn.WaitUntilElementIsInteractable();
						_closeBtn.JSClickWithFocus(Driver);
						Driver.WaitForAbsence(By.XPath(FullAccount), TimeSpan.FromSeconds(3));
						Thread.Sleep(2000);
					}
					else
					{
						throw new Exception("Could not locate Account Numbers.");
					}
				}
			}

			Settings.Scenario["CorpAccountNumbers"] = currencyTypeAccountNumbers;
		}

        public void GetCardNumbersForLastNameSearch()
        {
            ExtentTest test = Settings.EnCompassExtentTest;
            Logger.StartStepLog(Settings.Scenario.StepContext.StepInfo.Text);

            var count = CardGrid.GetColumnText("Card Number").Count();
            Dictionary<string, string> lastNameAccountNumbers = new Dictionary<string, string>();
            var lastName = CardGrid.GetColumnText("Last Name");
            for (int i = 0; i < count; i++)
            {
                //Driver.WaitForDocumentLoadToComplete();
                CardGrid.SelectRow(i + 1);

                _viewBtn.Click();

                using (var helper = new FrameHelper(Driver, By.XPath(FullAccount)))
                {
                    Driver.WaitForDocumentLoadToComplete();
                    RefreshModel();
                    var element = helper.FindElement(By.XPath("//div[contains(@class, 'card-body text-center')]/h2"));

                    if (element != null)
                    {
                        lastNameAccountNumbers.Add(lastName.ToList()[i].ToString(), element.Text.ToString().Replace("-", ""));
                        _closeBtn.WaitUntilElementIsInteractable();
                        _closeBtn.BootstrapClick();
                        Driver.WaitForAbsence(By.XPath(FullAccount), TimeSpan.FromSeconds(3));
                        Thread.Sleep(2000);
                    }
                    else
                    {
                        throw new Exception("Could not locate Account Numbers.");
                    }
                }
            }

            Settings.Scenario["CorpAccountNumbersByLastName"] = lastNameAccountNumbers;
            test.Info("Corp Account Numbers By Last Name " + lastNameAccountNumbers);
        }

        public void GetCardNumbersAndCreditLimitsForCurrentSearch()
		{
			ExtentTest test = Settings.EnCompassExtentTest;
			Logger.StartStepLog(Settings.Scenario.StepContext.StepInfo.Text);

			var cardNumber = string.Empty;
			var count = CardGrid.GetColumnText("Card Number").Count();
			var billingCurrency = CardGrid.GetColumnText("Billing Currency");

			CardGrid.SelectFirstRow();
			CardGrid.PerformActionByText("Card Number(s)");

			using (var helper = new FrameHelper(Driver, By.XPath(FullAccount)))
			{
				Driver.WaitForDocumentLoadToComplete();
				RefreshModel();
				var element = helper.FindElement(By.XPath("//div[contains(@class, 'card-body text-center')]/h2"));

				if (element != null)
				{
					cardNumber = element.Text.ToString().Replace("-", "");
					_closeBtn.WaitUntilElementIsInteractable();
					_closeBtn.JSClickWithFocus(Driver);
					Driver.WaitForAbsence(By.XPath(FullAccount), TimeSpan.FromSeconds(3));
					Thread.Sleep(2000);
				}
				else
				{
					throw new Exception("Could not locate Account Numbers.");
				}
			}

			CardGrid.SelectFirstRow();
			CardGrid.PerformActionByText("Edit");

			var editAccout = new EditAccount(Settings);
			editAccout.WaitForLoad();

			editAccout.ExpandLimits();
			var creditLimit = editAccout.CreditLimit;
			test.Info($"Card Number {cardNumber.Substring(cardNumber.Length - 4)} has a credit limit of {creditLimit}");

			Settings.Scenario["CorpAccountNumber"] = cardNumber;
		}

		public void ExpandLimits()
		{
            //Changed to the generic method
            ExpandCardHeader(AC_MAINFORM, AP_LIMITS);
            Settings.EnCompassExtentTest.Info("Expanded Limits Section.");
        }

        public void CardStatusViewBtn()
		{
			_cardStatusViewBtn.Click();
			Driver.WaitForDocumentLoadToComplete();
        }

		public string GetStatusContent()
		{
			return Driver.FindElement(By.XPath("//a[contains(@id, 'popStatuses')]")).Text;
		}

		
		/// <summary>
		/// MyCards Checkbox set to true or false
		/// </summary>
		public bool SetCheckMyCardsOption
		{
			set
			{
				Driver.TryWaitForElementToBeVisible(By.XPath(_chkMyCardsLabelXpath), out IWebElement chkLabel);
				Driver.TryWaitForElement(By.XPath(_chkMyCardsCBXpath), out IWebElement chkCBox);
				chkCBox.SetCheckboxStateWithLabel(chkLabel, value);
				Settings.EnCompassExtentTest.Info("My Cards Checkbox is set to:" + value);
				this.WaitForLoad();
			}
		}
	}
}
