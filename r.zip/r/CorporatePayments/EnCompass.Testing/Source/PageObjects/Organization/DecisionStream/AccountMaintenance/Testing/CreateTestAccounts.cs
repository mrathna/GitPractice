﻿using Common.Utility;
using NFluent;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EnCompass.Testing.Source.PageObjects.Organization.DecisionStream.AccountMaintenance.Testing
{
	public partial class CreateTestAccounts
	{
		public override string PageIdentifierXPath_Override => @"//h1[normalize-space(text())='Create Test Cards' or text()='Cards']";

        #region XPath page Elements

        private const string _createBtnXPath = @"//input[contains(@id,'CreateButton')]";
        private const string _cardProductXPath = @"//select[contains(@id, 'ddlCardProduct')]";
        private const string _companyXPath = @"//select[contains(@id, 'CompanyDropdown')]";
        private const string _cardNumberXPath = @"//li[text()='Credit Card Number: ']//following-sibling::strong";
        private const string _nameOnCardXPath = @"//li[text()='Name on Card: ']//following-sibling::strong";
        private const string _ssnXPath = @"//abbr[@title='Social Security Number']//parent::li//following-sibling::strong";
        private const string _activationIdXPath = @"//li[normalize-space(text())='Unique identifier:' or normalize-space(text())='Activation ID:']/strong";
        private const string _zipXPath = @"//li[text()='Zip Code: ']//following-sibling::strong";
        private const string _testing_CardsXPath = @"//ul[contains(@id, 'sideNav')]//li[1]";
        private const string _testing_CreateCardTransactionsXPath = @"//ul[contains(@id, 'sideNav')]//li[2]";
        private const string _testing_SingleUseAccountsXPath = @"//ul[contains(@id, 'sideNav')]//li[3]";
        private const string _testing_SingleUseAccountTransactionsXPath = @"//ul[contains(@id, 'sideNav')]//li[4]";
        private const string _testing_CreditLimitUpdateXPath = @"//ul[contains(@id, 'sideNav')]//li[5]";
        private const string _testing_DailyExtractFilesXPath = @"//ul[contains(@id, 'sideNav')]//li[6]";
        #endregion

        #region Page Elements
		private IWebElement _createBtn
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_createBtnXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_createBtn element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

		private IWebElement _cardProduct
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_cardProductXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_cardProduct element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _company
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_companyXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_company element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _cardNumber
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_cardNumberXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_cardNumber element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _nameOnCard
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_nameOnCardXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_nameOnCard element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _ssn
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_ssnXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_ssn element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _activationId
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_activationIdXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_activationId element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _zip
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_zipXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_zip element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        #endregion

        #region Side Navigation

		private IWebElement _testing_Cards
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_testing_CardsXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_testing_Cards element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        public void NavigateTo_Cards()
		{
			NavigateToMenuItem(_testing_Cards);
		}

		private IWebElement _testing_CreateCardTransactions
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_testing_CreateCardTransactionsXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_testing_CreateCardTransactions element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        public void NavigateTo_CreateCardTransactions()
		{
			NavigateToMenuItem(_testing_CreateCardTransactions);
		}

		private IWebElement _testing_SingleUseAccounts
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_testing_SingleUseAccountsXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_testing_SingleUseAccounts element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        public void NavigateTo_SingleUseAccounts()
		{
			NavigateToMenuItem(_testing_SingleUseAccounts);
		}

		private IWebElement _testing_SingleUseAccountTransactions
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_testing_SingleUseAccountTransactionsXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_testing_SingleUseAccountTransactions element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        public void NavigateTo_SingleUseAccountTransactions()
		{
			NavigateToMenuItem(_testing_SingleUseAccountTransactions);
		}

		private IWebElement _testing_CreditLimitUpdate
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_testing_CreditLimitUpdateXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_testing_CreditLimitUpdate element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        public void NavigateTo_CreditLimitUpdate()
		{
			NavigateToMenuItem(_testing_CreditLimitUpdate);
		}

		private IWebElement _testing_DailyExtractFiles
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_testing_DailyExtractFilesXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_testing_DailyExtractFiles element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        public void NavigateTo_DailyExtractFiles()
		{
			NavigateToMenuItem(_testing_DailyExtractFiles);
		}

		#endregion


		public void SetCardProduct(string whichText)
		{
			bool cardProductsRequired = Driver.IsElementPresent(By.XPath(_cardProductXPath));
			if (cardProductsRequired)
			{
				var selectElement = new SelectElement(_cardProduct);
				var cardProduct = selectElement.Options.First(c => c.Text.ToLower().Contains(whichText.ToLower()));
				selectElement.SelectByText(cardProduct.Text);
			}
		}

		public void SetCompany(string whichText)
		{
			var selectElement = new SelectElement(_company);
			var company = selectElement.Options.First(c => c.Text.ToLower().Contains(whichText.ToLower()));
			selectElement.SelectByText(company.Text);
            Settings.EnCompassExtentTest.Info($"Selected company {whichText}.");
        }

        public void CreateBtn()
		{
			_createBtn.JSClickWithFocus(Driver);
            AttachOnDemandScreenShot();
            Settings.EnCompassExtentTest.Info("Clicked on Create Button.");
        }

        public string CardNumber
		{
			get
			{
				return Settings.EnCompassWebDriver.WaitForVisible(By.XPath(_cardNumberXPath)).Text;
			}
		}

		public string NameOnCard
		{
			get
			{
				return Settings.EnCompassWebDriver.WaitForVisible(By.XPath(_nameOnCardXPath)).Text;
			}
		}

		public string SSN
		{
			get
			{
				return Settings.EnCompassWebDriver.WaitForVisible(By.XPath(_ssnXPath)).Text;
			}
		}

		public string Zip
		{
			get
			{
				return Settings.EnCompassWebDriver.WaitForVisible(By.XPath(_zipXPath)).Text;
			}
		}
        //This field replaces the SSN on AKUSA, Commerce and PNC.
        public string ActivationId
        {
            get
            {
                return _activationId.Text;
            }

        }

        
    }
}
