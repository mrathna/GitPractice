package com.framework.testcases.API;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.common.IFCSLoginPage;
import com.framework.pages.API.common.PaymentsAPIMethods;

public class ValidateAndDoPayments extends BaseTest {
	/**
	 * Implemented by Raxsana Babu
	 * @param clientCountry
	 * @param clientName 
	 * RQ-903
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "BusinessFlow" })
	public void validateChequePaymentViaTwikey(@Optional("BE") String clientCountry, @Optional("WFE") String clientName) {

		test = extent.createTest(clientName + ":" + clientCountry + " TC-1495 TC01_Pymt_chkpymt_Write On_Cheque  payments", "RQ-903 Customer is paying using cheque payment");
		//CommonAPI commonAPI = new CommonAPI(driver, test);
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		PaymentsAPIMethods paymentsAPIMethods = new PaymentsAPIMethods(driver, test);
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
	
		paymentsAPIMethods.paymentsViaAPI(clientName, clientCountry, "Twikey Payment Check","N");

	}

	/**
	 * Implemented by Raxsana Babu
	 * @param clientCountry
	 * @param clientName 
	 * RQ-905
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "BusinessFlow" })
	public void validateDishonourPaymentViaTwikey(@Optional("BE") String clientCountry, @Optional("WFE") String clientName) {

		test = extent.createTest(clientName + ":" + clientCountry + "TC-1766 TC01_Manual_Payment_DD_Dishonour", "RQ-905 Payment is dishonoured because of insufficient fund or any other reason (DD Dishonour from Manual Payment)");
		//CommonAPI commonAPI = new CommonAPI(driver, test);
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		PaymentsAPIMethods paymentsAPIMethods = new PaymentsAPIMethods(driver, test);
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		paymentsAPIMethods.paymentsViaAPI(clientName, clientCountry, "Twikey Payment Check","Y");

	}
}
