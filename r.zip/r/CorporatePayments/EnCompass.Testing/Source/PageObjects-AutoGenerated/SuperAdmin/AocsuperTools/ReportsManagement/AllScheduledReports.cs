using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using Common;
using Common.PageObjects;
using Common.ScenarioConfigurations;
using Common.Utility;

namespace EnCompass.Testing.Source.PageObjects.SuperAdmin.AocsuperTools.ReportsManagement 
{
	/// <summary>
	/// Auto-generated Page Model Class
	/// Navigation Paths: 
		/// [Organization Home]->Super Admin Tools->Reports
		/// [Organization Home]->Super Admin Tools->Reports->Scheduled Reports Viewer
		/// </summary>
	[PageModel(@"/superAdmin/AOCSuperTools/ReportsManagement/AllScheduledReports.aspx")]
	public partial class AllScheduledReports : EnCompassSuperPageModel 
	{
		public override string RelativeUrl => @"/superAdmin/AOCSuperTools/ReportsManagement/AllScheduledReports.aspx";
		public override string PageIdentifierXPath_Generated => @"//li[contains(@class, 'breadcrumb-item active')][text() = 'View Scheduled Reports']";

		#region Navigation
				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='All Reports']")]
		private IWebElement _superAdminTools_Reports_AllReports { get; set; }
		public void NavigateTo_SuperAdminTools_Reports_AllReports()
		{
			NavigateToMenuItem(_superAdminTools_Reports_AllReports);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Scheduled Reports Viewer']")]
		private IWebElement _superAdminTools_Reports_ScheduledReportsViewer { get; set; }
		public void NavigateTo_SuperAdminTools_Reports_ScheduledReportsViewer()
		{
			NavigateToMenuItem(_superAdminTools_Reports_ScheduledReportsViewer);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='View Scheduled Reports' History']")]
		private IWebElement _superAdminTools_Reports_ViewScheduledReportsHistory { get; set; }
		public void NavigateTo_SuperAdminTools_Reports_ViewScheduledReportsHistory()
		{
			NavigateToMenuItem(_superAdminTools_Reports_ViewScheduledReportsHistory);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='View Report Queue History']")]
		private IWebElement _superAdminTools_Reports_ViewReportQueueHistory { get; set; }
		public void NavigateTo_SuperAdminTools_Reports_ViewReportQueueHistory()
		{
			NavigateToMenuItem(_superAdminTools_Reports_ViewReportQueueHistory);
		}

		
		private void NavigateToMenuItem(IWebElement element)
		{
			Driver.Url = element.GetAttribute("href");
		}
		#endregion

		public AllScheduledReports(GlobalSettings settings) : base(settings) { }
	}  
}
