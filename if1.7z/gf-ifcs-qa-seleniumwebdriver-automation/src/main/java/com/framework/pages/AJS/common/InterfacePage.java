package com.framework.pages.AJS.common;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Scanner;
import java.util.Set;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.ExtentTest;
import com.framework.basepage.BasePage;
import com.framework.util.Constants;
import com.framework.util.ControlMUtils;
import com.framework.util.PdfUtils;
import com.framework.util.PropUtils;
import com.framework.util.PuttyUtils;

public class InterfacePage extends BasePage {
	IFCSCommonPage ifcsCommonPage = new IFCSCommonPage(driver,test);
	
	ArrayList <String> verifyUniqueNo = new ArrayList<String>();
	
	public InterfacePage(WebDriver driver, ExtentTest test) {
		
		super(driver, test);
		PageFactory.initElements(driver, this);
		// TODO Auto-generated constructor stub
	}
	
	public ArrayList<String> updateOrValidateFlatFile(Properties properties, String type, String remoteDir, String cardNumber, String clientName, String clientCountry, String inputTemplateFileName) {
	
			//String client = getClientFullName(clientName, clientCountry);
			verifyUniqueNo = ifcsCommonPage.updateOrValidateInterfaceFile(properties, type, remoteDir,
					cardNumber, clientName, inputTemplateFileName);
			return verifyUniqueNo;
	}  
		
	public void establishAndExecuteControlMJobs(String urlKey, String unKey, String pwdKey, String folderName, String jobsOrder) { 
		
		 //System.out.println("urlKey ----- "+urlKey);		
		 
		 String status;
		
		 String controlMBaseUrl=null,controlMUN=null,controlMPWD=null, jobsInOrder=null;	
		 
		 controlMBaseUrl = PropUtils.getPropValue(configProp, urlKey);
		 controlMUN = PropUtils.getPropValue(configProp, unKey);
		 controlMPWD= PropUtils.getPropValue(configProp, pwdKey);
		// controlMPWD= decryptText(PropUtils.getPropValue(configProp, pwdKey), "lockUnlock");		 
	 if(controlMBaseUrl != null && controlMUN != null && controlMPWD!= null )
		 {
			 logInfo("Control M execution starts ....");
			 // setting the login token to token variable.
			 ControlMUtils.setSessionLoginToken(controlMBaseUrl,controlMUN, controlMPWD);
			 
			 logInfo("*** Logged into Contrl M ***");
			 // Trigger Folder jobs and Get runId
			 String runID = ControlMUtils.triggerJobFolderandGetRunId(controlMBaseUrl,folderName);
			 logInfo("The jobs under the "+folderName+ " are ordered sucessfully");
//		 		String runID = controlM.triggerJobFolderandGetRunId("SHCZSU1-ProcessTransactionDASS");
		 		// Get the Status of jobs which got triggered
		 		ControlMUtils.setRunStatus(controlMBaseUrl,runID); 
		 		// set the Status and Name of each job with jobid
		 	ControlMUtils.setJobStatus();		 	
		 	ControlMUtils.setJobName();		 	
		 	HashSet<String> actualJobSet =ControlMUtils.getJobName();
		 	
		 	int actualjobSize = actualJobSet.size();
		 	
		 	String[] expJobsArr =  jobsOrder.split(";");
		 	
		 	int expJobsSize = expJobsArr.length;
		 	
		 	System.out.println("----- arrSize -----"+expJobsSize);
		 	
		 	if(actualjobSize == expJobsSize)
		 	{
		 		for(int i=0;i<expJobsSize;i++)
		 		{
		 			jobsInOrder = expJobsArr[i];
		 			//System.out.println("Actual job set is"+actualJobSet);
		 			//System.out.println("Jobs in order is"+jobsInOrder);
		 			if(actualJobSet.contains(jobsInOrder))
		 			{
		 				logInfo(jobsInOrder+" job is executed");
		 				status=ControlMUtils.setJobStatusRunNow(controlMBaseUrl,jobsInOrder,folderName);
//		 				ControlMUtils.setJobStatusRunNow(controlMBaseUrl,jobsInOrder);
		 				System.out.println("----status---- :" +status);
		 				
		 				if(status.equals("Ended Not OK")) {
		 					logFail("The Job Got Failed: "+expJobsArr[i]);
						}
		 				
		 				//ControlMUtils.setJobStatusSetToOk(controlMBaseUrl);
		 			}
		 			else
		 			{
		 				logFail("The Job is not present inside the: "+folderName);
		 			}
		 			
		 		}
		 	}
		 	
		 	else
		 	{
		 		logFail("Jobs are not matched inside the job folder: "+folderName);
		 	} 
		 		
		 	logInfo("Successfully executed ControlM jobs inside the folder "+folderName);
		 }
	}
	
	String file = null;
	Sheet workSheet=null;
	Workbook workBook=null;
	Row row =null;
	int rowCount;

	public Sheet readExcelSheet(String fileName, String sheetName)
			throws EncryptedDocumentException, InvalidFormatException, IOException {

		try {
			// file = System.getProperty("user.home") + System.getProperty("file.separator")
			// + "Documents"
			// + System.getProperty("file.separator") + fileName;
			System.out.println("File Path is" + fileName);
			FileInputStream inputStream = new FileInputStream(new File(fileName));
			workBook = WorkbookFactory.create(inputStream);
			workSheet = workBook.getSheet(sheetName);
			System.out.println("Sheet is " + workSheet);
			// Row
			rowCount = workSheet.getLastRowNum();
		//	 rowCount = workSheet.getPhysicalNumberOfRows();
			
			System.out.println("Number of updated details in  row count is " + rowCount);
			row = workSheet.createRow(++rowCount);
		} catch (FileNotFoundException e) {

			e.printStackTrace();
		}
		return workSheet;

	}

	public void onboardCustomerDetails(String filePathName) {

		String clientName, clientCountry;
		String cardTypeDesc = "";
		String customerNo = "";
		String incrementedCustomerNo = "";
		long onBoardingCustomerNo;
		clientName = PropUtils.getPropValue(configProp, "clientName");
		clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		try {
			// Customer Cross Reference tab
			Sheet customerDetailsSheet = readExcelSheet(filePathName, "Customer Cross Reference");
			
			// Getting customer name for both customer and customer cross reference tab
			String customerName = fakerAPI().name().fullName();
			System.out.println("Customer Name is " + customerName);
			
			// Ext account ref value
			Cell account = customerDetailsSheet.getRow(1).getCell(1);
			String extAccountRefValue = account.toString();
			System.out.println("EXT Account Ref Value is " + extAccountRefValue);

			// Ext Delivery ref
			Cell deliveryAccount = customerDetailsSheet.getRow(1).getCell(2);
			String extDeliveryValue = deliveryAccount.toString();
			System.out.println("EXT Account Ref Value is " + extDeliveryValue);

			// To get new customer no
			cardTypeDesc = "cp.client_mid=(select Client_mid from m_clients where name ='"
					+ PropUtils.getPropValue(configProp, clientName + "_" + clientCountry) + "')";
			String queryToGetCustomer = "Select distinct mcu.customer_no from m_customers mcu inner join card_programs cp on mcu.card_program_oid = cp.card_program_oid inner join accounts acc on mcu.customer_mid=acc.customer_mid inner join account_status accs on accs.account_status_oid=acc.account_status_oid inner join account_sub_status accss on acc.account_sub_status_oid=accss.account_sub_status_oid where mcu.customer_mid In (select customer_mid from cards) and accs.description like '%Active' and accss.description='Active' and "
					+ cardTypeDesc + "and Rownum <=1 ORDER BY mcu.customer_no DESC";

			customerNo = connectDBAndGetValue(queryToGetCustomer,
					PropUtils.getPropValue(configProp, "sqlODSServerName"));
			System.out.println(customerNo);
			onBoardingCustomerNo = Long.parseLong(customerNo) + 1l;
			customerNo = String.valueOf(onBoardingCustomerNo);
			System.out.println("New Customer Number is " + customerNo);

			HashMap<String, String> customerReferenceHeaderValues = new HashMap<String, String>();

			//Adding customer values in customer cross reference tab 
			customerReferenceHeaderValues.put("Customer Name", customerName);
			customerReferenceHeaderValues.put("Ext Account Ref", extAccountRefValue);
			customerReferenceHeaderValues.put("Ext Delivery Ref", extDeliveryValue);
			customerReferenceHeaderValues.put("Customer Number", customerNo);
			System.out.println("Hash map Values " + customerReferenceHeaderValues);
			
			//Write functions

			updateCustomerDetailsInExcelSheet(customerDetailsSheet, customerReferenceHeaderValues, filePathName);
			

			// For Customer tab
			Sheet customerSheet = readExcelSheet(filePathName, "Customer");
			HashMap<String, String> customerHeaderValues = new HashMap<String, String>();

			for (int k = 0; k <= rowCount - 1; k++) {
				System.out.println(k);
				if (k == rowCount - 1) {
					Cell customerID = customerSheet.getRow(k).getCell(0);
					incrementedCustomerNo = customerID.toString();
					int cusNo = Integer.parseInt(incrementedCustomerNo) + 1;
					incrementedCustomerNo = Integer.toString(cusNo);
					break;
				} else {        
					System.out.println("Customer ID is not present in expected row");
					// logInfo("Customer ID is not present in expected row");

				}
			}
			System.out.println("Sequence customer ID is " + incrementedCustomerNo);
			
			// Trading Name
			String tradeName = "Onboard Regression Test_" + customerName;
			System.out.println("Trading Name is" + tradeName);
			// OnoardName
			String onboardEmbossName = "Onboard name_" + customerName;
			System.out.println("Onboard Emboss Name is " + onboardEmbossName);
			
			//Adding customer details in hash map
			customerHeaderValues.put("customerID", incrementedCustomerNo);
			if(clientCountry.equals("BW")) {
				customerHeaderValues.put("couponCode", clientCountry+"_COUPON");
				customerHeaderValues.put("clientID", "3");
			}
			else if(clientCountry.equals("NA")){
				customerHeaderValues.put("couponCode", clientCountry+"_COUPON");
				customerHeaderValues.put("clientID", "2");
			}
			
			customerHeaderValues.put("name", customerName);
			customerHeaderValues.put("tradingName", tradeName);
			customerHeaderValues.put("embossingName", onboardEmbossName);
			customerHeaderValues.put("postalAddressID", "2");
			customerHeaderValues.put("streetAddressID", "2");
			customerHeaderValues.put("extDeliveryRef", extDeliveryValue);
			customerHeaderValues.put("extAccountRef", extAccountRefValue);
			customerHeaderValues.put("customerContactID", "2");
			
			//Write functions
			updateCustomerDetailsInExcelSheet(customerSheet, customerHeaderValues, filePathName);

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.getMessage();
		}

	}
//Sowmiya
	public void updateCustomerDetailsInExcelSheet(Sheet customerDetailsSheet, HashMap<String, String> customerValues,
			String fileName) throws IOException {
		System.out.println("FileNme is " + fileName);
		int noOfColumns = customerDetailsSheet.getRow(0).getLastCellNum();
		System.out.println("Number of columns is  " + noOfColumns);
		String[] columnHeaders = new String[noOfColumns];
		for (int j = 0; j < noOfColumns; j++) {

			columnHeaders[j] = customerDetailsSheet.getRow(0).getCell(j).getStringCellValue();
			System.out.println(columnHeaders[j]);

		}
		for (int i = 0; i < noOfColumns; i++) {
			for (String entry : customerValues.keySet()) {
				System.out.println("Hash map is " + entry);

				if (columnHeaders[i].equals(entry)) {
					String columnValue = customerValues.get(entry);
					System.out.println("Column Value is " + columnValue);
					row.createCell(i).setCellValue(columnValue);
					System.out.println("Row is " + rowCount + " Column Value is " + columnValue + "entered");
				}

				else {
					System.out.println("Expected  column header is not present");
				}

			}
		}
		FileOutputStream outputStream = new FileOutputStream(fileName);
		workBook.write(outputStream);
		outputStream.close();

	}

	public String getOutgoingCopyExcelFilePath(String type, String inputTemplateFileName) throws IOException {
		String filePathName = "";
		
		// String fileName="";
		if (type.equals("OutgoingFile")) {
			String inputFileTemplateCopy = Constants.INPUTFILE_DIR + inputTemplateFileName;
			System.out.println(" Input Template File is " + inputFileTemplateCopy);
			// Local Directory
			outgoingFileName = System.getProperty("user.home") + "\\Documents\\" + inputTemplateFileName;
			System.out.println("Created outgoing fileName is" + outgoingFileName);

			FileInputStream excelFile = new FileInputStream(new File(inputFileTemplateCopy));
			Workbook workbook = new XSSFWorkbook(excelFile);
			FileOutputStream outputStream = new FileOutputStream(outgoingFileName);
			workbook.write(outputStream);
			workbook.close();

			// System.out.println("File Path is" + outputStream);

			File destinationFilePath = new File(outgoingFileName);
			System.out.println("Destination file is " + destinationFilePath);
			filePathName = destinationFilePath.toString();
			// System.out.println("String file Path is " + filePathName);
			// Path path = Paths.get(filePathName);
			// fileName = path.getFileName().toString();
			// System.out.println("File Name is " + fileName);

		} else {
			logFail("Not Valid file");
		}

		return filePathName;

	}
	
 	public void validateEmbossXMLFile() {
 		String clientCountry, fileType = "", clientName,fileName="";
		clientName = PropUtils.getPropValue(configProp, "clientName");
		clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		CommonInterfacePage commonInterfacePage = new CommonInterfacePage(driver, test);
		if(clientName.contains("BP")) {
		String[] orderedDriverAndVehicleCardNumber = PropUtils
				.getPropValue(configProp, "orderedDriverAndVehicleCardNumber").split(",");
		
		if (clientCountry.equals("NZ")) {
			fileType = "RM_G1_0236_BPFUEL";
		} else {
			fileType = "RM_G1_0236_BPPLUS";
		}
		
		fileName = commonInterfacePage.getRecentProcessedFileNames(clientName, clientCountry, fileType);
		System.out.println("---fileNamRecent ::" + fileName);
		ifcsCommonPage.establishThePuttyConnection("unzip file to xml", "PUTTY_HOST", "PUTTY_USERNAME",
				"PUTTY_PASSWORD", "IFCS_OUTPUTFILE_FOLDER", fileName);
		fileName = fileName.split("\\.")[0];
		String cardEmbossFilePathLocal = System.getProperty("user.home") + System.getProperty("file.separator")
				+ "Documents" + System.getProperty("file.separator") + fileName + ".xml";

		ifcsCommonPage.validateIncomingXMLFile(cardEmbossFilePathLocal, orderedDriverAndVehicleCardNumber,
				"ifcs:EmbossingDetails", "ifcs:EmbossLine1");
		}
		else if(clientName.contains("WFE")) {
			String hostName = PropUtils.getPropValue(configProp, "PUTTY_HOST");
			String userName = PropUtils.getPropValue(configProp, "PUTTY_USERNAME");
			String passwordPutty = PropUtils.getPropValue(configProp, "PUTTY_PASSWORD");
			fileName = PuttyUtils.puttyConnectionAndGetLastProcessedFileName(hostName, userName, passwordPutty, PropUtils.getPropValue(configProp, "IFCS_EMBOSS_FILE_"+clientCountry),"Emboss");
			PropUtils.setProps(configProp, "IFCS_EMBOSS_FILE_"+clientCountry, fileName.substring(0, fileName.length()-25));
			fileName= fileName.substring(fileName.length()-25, fileName.length());
			System.out.println("Embpss:::"+"IFCS_EMBOSS_FILE_"+clientCountry);
			System.out.println("Embpss:::"+PropUtils.getPropValue(configProp, "IFCS_EMBOSS_FILE_"+clientCountry));
	 		ifcsCommonPage.establishThePuttyConnection("unzip file to xml", "PUTTY_HOST", "PUTTY_USERNAME",
					"PUTTY_PASSWORD", "IFCS_EMBOSS_FILE_"+clientCountry, fileName);
	 		
			String cardEmbossFilePathLocal = System.getProperty("user.home") + System.getProperty("file.separator")
					+ "Documents" + System.getProperty("file.separator") + fileName.replace(".zip", "") + ".xml";
			Map<String, String> cardDetail = new HashMap<String, String>();
			cardDetail.putAll(PropUtils.getPropsAsMap(embossAndIdemiaFile));
			Set<String> set = cardDetail.keySet();
			String[] orderedDriverAndVehicleCardNumber=new String[10];
			int n =0;
			for (Object obj : set) {
				String str = obj.toString();
				if (str.startsWith("Emboss")) {
					orderedDriverAndVehicleCardNumber[n] = cardDetail.get(str);
					System.out.println("Card Number:"+cardDetail.get(str));
				}
			}
			ifcsCommonPage.validateIncomingXMLFile(cardEmbossFilePathLocal, orderedDriverAndVehicleCardNumber,
					"ifcs:CardDetails", "ifcs:CardNumber");
		}

	}

	public void validateEmbossBulkXMLFile() {

		String clientCountry, fileType, clientName;
		clientName = PropUtils.getPropValue(configProp, "clientName");
		clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		if (clientCountry.equals("NZ")) {
			fileType = "RM_G1_0236_BPFUEL_BR";
		} else {
			fileType = "RM_G1_0236_BPPLUS_BR";
		}
		CommonInterfacePage commonInterfacePage = new CommonInterfacePage(driver, test);
		String fileName = commonInterfacePage.getRecentProcessedFileNames(clientName, clientCountry, fileType);
		System.out.println("---fileNamRecent ::" + fileName);

		ifcsCommonPage.establishThePuttyConnection("unzip file to xml", "PUTTY_HOST", "PUTTY_USERNAME",
				"PUTTY_PASSWORD", "IFCS_OUTPUTFILE_FOLDER_BR", fileName);

	}

	public void validatePINMailerFile() {

		String clientCountry, fileType, clientName;
		clientName = PropUtils.getPropValue(configProp, "clientName");
		clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		String fileName;
		CommonInterfacePage commonInterfacePage = new CommonInterfacePage(driver, test);
		if(clientName.contains("BP")) {
		fileType = "RM_G1_0237";
		fileName = commonInterfacePage.getRecentProcessedFileNames(clientName, clientCountry, fileType);
		System.out.println("---fileNamRecent ::" + fileName);

		ifcsCommonPage.establishThePuttyConnection("unzip file to xml", "PUTTY_HOST", "PUTTY_USERNAME",
				"PUTTY_PASSWORD", "IFCS_OUTPUTFILE_FOLDER_PM", fileName);
		}else if(clientName.contains("WFE")){
			String hostName = PropUtils.getPropValue(configProp, "PUTTY_HOST");
			String userName = PropUtils.getPropValue(configProp, "PUTTY_USERNAME");
			String passwordPutty = PropUtils.getPropValue(configProp, "PUTTY_PASSWORD");
			fileName = PuttyUtils.puttyConnectionAndGetLastProcessedFileName(hostName, userName, passwordPutty, PropUtils.getPropValue(configProp, "IFCS_PINMAILER_FILE_"+clientCountry),"PinMailer");
			PropUtils.setProps(configProp, "IFCS_PINMAILER_FILE_"+clientCountry, fileName.substring(0, fileName.length()-23));
			fileName= fileName.substring(fileName.length()-23, fileName.length());
	 		ifcsCommonPage.establishThePuttyConnection("unzip file to xml", "PUTTY_HOST", "PUTTY_USERNAME",
					"PUTTY_PASSWORD", "IFCS_PINMAILER_FILE_"+clientCountry, fileName);
			String cardPINMailerFilePathLocal = System.getProperty("user.home") + System.getProperty("file.separator")
					+ "Documents" + System.getProperty("file.separator") + fileName.replace(".zip", "") + ".xml";
			Map<String, String> cardDetail = new HashMap<String, String>();
			cardDetail.putAll(PropUtils.getPropsAsMap(embossAndIdemiaFile));
			Set<String> set = cardDetail.keySet();
			String[] orderedDriverAndVehicleCardNumber=new String[10];
			int n =0;
			for (Object obj : set) {
				String str = obj.toString();
				if (str.startsWith("Pin")) {
					orderedDriverAndVehicleCardNumber[n] = cardDetail.get(str);
					System.out.println("Card Number:"+cardDetail.get(str));
				}
			}
			ifcsCommonPage.validateIncomingXMLFile(cardPINMailerFilePathLocal, orderedDriverAndVehicleCardNumber,
					"ifcs:PinMailerDetail", "core:CardNumber");
		}
	

	}

	public void validateCardStatusAfterCardEmboss() {
		Common common = new Common(driver, test);
		if (common.getCardStatus(PropUtils.getPropValue(configProp, "orderedDriverAndVehicleCardNumber"))
				.equals("700 No Transactions")) {
			logPass("Card Status changed");
		} else {
			logFail("Card Status not changed after job executionF");
		}

	}
	
	public void validatePeriodicRebateAmountFromPDF(String rebateAmount, String calculatedRebateAmount, String fileName,
			int fromPage, int toPages) {
		// Database validations
		if (rebateAmount.equals(calculatedRebateAmount)) {
			logInfo("Calculated rebate amount and  rebate amount from DB is equal");
		} else {
			logFail("Calculated rebate amount and  rebate amount from DB is not equal");
		}
			int count = 0;
			String pdfFileFromDocument = System.getProperty("user.home") + "\\Documents\\" + fileName;
			System.out.println("PDF File from document " + pdfFileFromDocument);

			List<String> textFromPDF = new ArrayList<String>();
			textFromPDF = PdfUtils.getTextPageWise(pdfFileFromDocument,fromPage,toPages);
			
			int expectedReportPageSize = textFromPDF.size();
			System.out.println("Expected report page size "+expectedReportPageSize);
			for (int i = 0; i < expectedReportPageSize; i++) {
				// System.out.println("PDF Report size"+textFromPDF.size());
				String textFromEachPDFPage = textFromPDF.get(i);
				System.out.print("To get Text from each PDF page " + textFromEachPDFPage);
				if (!textFromEachPDFPage.isEmpty()) {
					if (textFromEachPDFPage.contains(rebateAmount)) {
						logPass("Value is found in generated PDF Report Page");
						System.out.print("Value is found in generated PDF Report");
					} else {
						logInfo("Value is not found in  generated  PDF Report Page");
						System.out.print("Value is not found in  generated  PDF Report");
					}

				} else {
					count++;
					System.out.println("Count is " + count);
					if (count == expectedReportPageSize)
						logFail("Generated report Page  has no datas");

				}

			}
		

	}
	 
	public void runCtrlmJobs(String jobKeyName) {

		IFCSCommonPage ifcsCommonPage = new IFCSCommonPage(driver, test);
		InterfacePage interfacePage = new InterfacePage(driver, test);

		String clientName = PropUtils.getPropValue(configProp, "clientName");

		String clientCountry = PropUtils.getPropValue(configProp, "clientCountry");

		System.out.println("clientName -->"+clientName  +"////"+"clientCountry--->"+clientCountry);

		String folderName = ifcsCommonPage.getControlMFolder(clientName, clientCountry, jobKeyName);

		String jobsInOrder = ifcsCommonPage.getJobsOfFolderInOrder(jobKeyName);

		interfacePage.establishAndExecuteControlMJobs("ControlM_AWS_UAT", "ContorlM_AWS_userName",
		"ContorlM_AWS_password", folderName, jobsInOrder);

		}
	
	/*
	 * Validate data in the XML file Author Meenakshi Sundaram
	 * 
	 */

	public void validateIdemiaFile() {
		Map<String, String> cardDetail = new HashMap<String, String>();
		cardDetail.putAll(PropUtils.getPropsAsMap(embossAndIdemiaFile));
		Set<String> set = cardDetail.keySet();
		List<String> orderedDriverAndVehicleCardNumber=new ArrayList<>();
		for (Object obj : set) {
			String str = obj.toString();
			if (str.startsWith("Idemia")) {
				orderedDriverAndVehicleCardNumber.add(cardDetail.get(str));
				System.out.println("Card Number:"+cardDetail.get(str));
			}
		}
		try {
			System.out.println("Dir:"+Constants.IDEMIA_DIR+Constants.IDEMIA);
			readLargerTextFile(Constants.IDEMIA_DIR+Constants.IDEMIA, orderedDriverAndVehicleCardNumber);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	  final static Charset ENCODING = StandardCharsets.ISO_8859_1;

	  void readLargerTextFile(String fileName, List<String> cardList) throws IOException {
		  List<String> cardNotPresent = new ArrayList<>();
		  boolean cardPresence=false;
		  for (int i=0;i<cardList.size();i++) {
		    Path path = Paths.get(fileName);
		    try (BufferedReader reader = Files.newBufferedReader(path, ENCODING)){
		    	String line = null;
		       while ((line = reader.readLine()) != null) {
		        if(line.replaceAll("-", "").contains(cardList.get(i).toString())) {
		        	cardPresence=true;
		        	logPass("Card Added in Idemia");   
		        	break;
		        }
		        else {
		        	logInfo("Card Not in line");
		        }
		      }     
		    }
		    if(!cardPresence) {
				  cardNotPresent.add(cardList.get(i).toString());
			  }
		  }
		  if(cardNotPresent.size()>0) {
			  logFail("Listed Cards not added in Idemia:"+cardNotPresent);
		  }
		  }
 
	
}
