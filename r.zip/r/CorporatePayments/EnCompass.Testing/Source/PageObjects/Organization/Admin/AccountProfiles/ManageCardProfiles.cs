﻿using Common;
using Common.Utility;
using EnCompass.Testing.Source.PageObjects.Controls;
using NFluent;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Support.UI;
using System;

namespace EnCompass.Testing.Source.PageObjects.Organization.Admin.AccountProfiles
{
    [PageModel(@"/admin/accountProfiles/manageCardProfiles.aspx")]
    public class ManageCardProfiles : EnCompassOrgPageModel
    {
        public override string RelativeUrl => @"/admin/accountProfiles/manageCardProfiles.aspx";
        public override string PageIdentifierXPath_Override => @"//li[contains(@class, 'breadcrumb-item active')][text() = 'Card']";

        #region XPath page Elements

        private const string _addNewCardProfileXPath = @"//a[contains(@class,'primary') and contains(text(),'Create')]";
        private const string _viewXPath = @"//a[contains(@id,'actionLink0')]";
        private const string _editXPath = @"//a[contains(@id,'actionLink1')]";
        private const string _historyXPath = @"//a[contains(@id,'actionLink3')]";
        private const string _applyXPath = @"//a[contains(@id,'actionLink2')]";
        private const string _deleteXPath = @"//a[contains(@id,'actionLink4')]";
        private const string _cardProfileNotFoundXPath = "//td[contains(@class,'NoRecordsMessage')]";
        private const string _successMessageXPath = ".//div[contains(@id,'SuccessMessage')]";
        #endregion

        #region Page Elements
        private IWebElement _addNewCardProfile
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_addNewCardProfileXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Info("Found _addNewCardProfile");
                return element;
            }
        }

        private IWebElement _view
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_viewXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Info("Found _view");
                return element;
            }
        }

        private IWebElement _edit
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_editXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Info("Found _edit");
                return element;
            }
        }

        private IWebElement _history
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_historyXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Info("Found _history");
                return element;
            }
        }

        private IWebElement _apply
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_applyXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Info("Found _apply");
                return element;
            }
        }

        private IWebElement _delete
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_deleteXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Info("Found _delete");
                return element;
            }
        }

        private IWebElement _cardProfileNotFound
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_cardProfileNotFoundXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Info("Found _cardProfileNotFound");
                return element;
            }
        }
       
        #endregion

        public void AddNewCardProfile()
        {
            _addNewCardProfile.JSClickWithFocus(Driver);
        }

        private GridControl _mGrid;
        public GridControl CardProfileGrid
        {
            get
            {
                GridControl grid = _mGrid ?? (_mGrid = new GridControl("profilesDataGrid", Driver));
                grid.WaitForGrid();
                return grid;
            }
        }

        public void PressEdit()
        {
            _edit.JSClickWithFocus(Driver);
        }

        public void PressDelete()
        {
            _delete.JSClickWithFocus(Driver);
            DeleteOnModal();
            WaitForLoad();
            Check.That(_cardProfileNotFound).IsNotNull();
        }

        public void PressView()
        {
            _view.JSClickWithFocus(Driver);
        }

		public void PressHistory()
		{
			_history.JSClickWithFocus(Driver);
		}

		public void PressApply()
		{
			_apply.JSClickWithFocus(Driver);
		}

		public string GetSuccessMessageDelete
        {
            get
            {
                return Settings.EnCompassWebDriver.WaitForVisible(By.XPath(".//div[contains(@id,'SuccessMessage')]"), TimeSpan.FromSeconds(5)).GetAttribute("innerText");
            }
        }

        public ManageCardProfiles(GlobalSettings settings) : base(settings) { }
    }
}