package com.framework.testcases.OLS.CHEV.Customer.ReadWrite;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.CHEV.CHLogonPage;
import com.framework.pages.CHEV.CHRequestLogonPage;
import com.framework.pages.OLS.common.LoginPage;

public class ValidateOLSRequestLogon extends BaseTest {
	@Parameters({ "clientCountry", "clientName" })
	@Test(priority = 1)
	public void testCustomerReadWriteOLSRequestLogon(@Optional("AU") String clientCountry,
			@Optional("CHV") String clientName) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  OLS - Request a Logon",
				"Chevron Customer Screens Read / Write Only");

		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		CHLogonPage chLogonPage = new CHLogonPage(driver, test);
		CHRequestLogonPage chRequestLogonPage = new CHRequestLogonPage(driver, test);
		loginPage.OpenOLSApplicationWithoutLogin("CHV_URL");
		chLogonPage.clickOnRequestLogOn();
		chRequestLogonPage.verifyTitle();
		chRequestLogonPage.enterDetailsAndVerifyMessage();
		
	 // Below functions are commented - due to page fields changed 
		/*chRequestLogonPage.enterDetails(); 
		chRequestLogonPage.clickSubmitBtn();
		chRequestLogonPage.verifyConfirmationMessage();
		chLogonPage.sleep(10);
		loginPage.Logout(); */
	}
}
 
