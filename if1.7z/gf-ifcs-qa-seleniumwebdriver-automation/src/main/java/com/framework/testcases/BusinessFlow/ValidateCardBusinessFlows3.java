package com.framework.testcases.BusinessFlow;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.LineIterator;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basepage.BasePage;
import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.ApplicationsPage;
import com.framework.pages.AJS.CardMaintenancePage;
import com.framework.pages.AJS.ChangeCardStatus;
import com.framework.pages.AJS.MaintainAccountPage;
import com.framework.pages.AJS.MaintainCustomerPage;
import com.framework.pages.AJS.MerchantLocationPage;
import com.framework.pages.AJS.OrderCardPage;
import com.framework.pages.AJS.SearchPage;
import com.framework.pages.AJS.TransactionListPage;
import com.framework.pages.AJS.common.Common;
import com.framework.pages.AJS.common.IFCSCommonPage;
import com.framework.pages.AJS.common.IFCSHomePage;
import com.framework.pages.AJS.common.IFCSLoginPage;
import com.framework.pages.AJS.common.InterfacePage;
import com.framework.pages.BusinessFlow.WFECommon;
import com.framework.util.Constants;
import com.framework.util.PropUtils;
import com.framework.util.TextFileUtils;
//import com.gargoylesoftware.htmlunit.javascript.host.file.FileReader;
import com.github.javafaker.Faker;
import com.framework.util.PuttyUtils;
import com.framework.pages.API.common.CardAPIMethods;


public class ValidateCardBusinessFlows3 extends BaseTest {


	/**
	 * Implemented by Rathna
	 * 
	 * @param clientCountry
	 * @param clientName    Business Flow ID:BF-017
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow" })
	public void addSubscriptonForAccountsInIFCS(@Optional("BE") String clientCountry,
			@Optional("WFE") String clientName) {

		test = extent.createTest(
				clientName + ":" + clientCountry
						+ " TC-1113 TC01_AcctMgmt_Subp_Add Subcription_existing Customer from IFCS as a Sales User",
				"RQ-813 : Able to create Subscription for customers");
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		Common common = new Common(driver, test);
		IFCSloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");

		// Serch Cutomer
		IFCSHomePage.gotoApplicationAndClickApplicationMenu();
		IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);
		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		common.chooseCustomerNumberFromCustomerList();
		// Add subcription
		MaintainAccountPage maintainAccountPage = new MaintainAccountPage(driver, test);
		IFCSHomePage.gotoAccountAndClickAccountDetails();
		maintainAccountPage.addSubScriptionToAccount();

		IFCSHomePage.exitIFCS();
	}

	/**
	 * Implemented by Rathna
	 * 
	 * @param clientCountry
	 * @param clientName   RQ-800
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "BusinessFlow" })
	public void updateExistingCardFeeProfileOfcard(@Optional("BE") String clientCountry,
			@Optional("WFE") String clientName) {

		test = extent.createTest(clientName + ":" + clientCountry + " TC-1735 TC06_CustMgmt_Upd_Card fee profiles",
				"RQ-800 Able to update existing card fee profile of a card");
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		ChangeCardStatus changeCardSatatus = new ChangeCardStatus(driver, test);
		Common common = new Common(driver, test);
		IFCSloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");

		// Serch Cutomer

		IFCSHomePage.gotoApplicationAndClickApplicationMenu();
		IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);
		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		common.chooseCustomerNumberFromCustomerList();

		changeCardSatatus.updateExistingCardFeeProfile();
		IFCSHomePage.exitIFCS();
	}

	/**
	 * Implemented by Rathna
	 * 
	 * @param clientCountry
	 * @param clientName    Business Flow ID:BF-077
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "BusinessFlow" })
	public void createCostCentreInIFCS(@Optional("BE") String clientCountry, @Optional("WFE") String clientName) {

		test = extent.createTest(clientName + ":" + clientCountry + " RQ-786 - TC-793 TC01_CustMgmt_CostCentre_Cust_Add",
				"Able to create cost centre in IFCS");
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		MaintainCustomerPage maintainCustomerPage = new MaintainCustomerPage(driver, test);
		Common common = new Common(driver, test);

		IFCSloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");

		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");

		// getting Active Customer No from DB/
		String customerNumberUsingCardType = common.getActiveCustomerNoUsingCardType();
		if (customerNumberUsingCardType.equals(" ")) {
			common.logForNoDataFound(this.getClass().getSimpleName(),
					"Need to Create A Customer with Card Type and rerun");
		} else {
			// Add a Cost Centre
			IFCSHomePage.gotoCustomerMenuCustomerDetails();
			common.chooseCustomerNoAndSearch(customerNumberUsingCardType);
			maintainCustomerPage.chooseCostCentre();
			String costCenterCode = Faker.instance().number().digits(4);
			maintainCustomerPage.addCostCentreAndValidate(costCenterCode);

		}
		IFCSHomePage.exitIFCS();

	}

	/**
	 * Implemented by Venkata Davu
	 * 
	 * @param clientCountry
	 * @param clientName    Business Flow ID:BF-052
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "BusinessFlow" })
	public void orderNewCardWithInvalidDataAndValidate(@Optional("NL") String clientCountry,
			@Optional("WFE") String clientName) {

		test = extent.createTest(
				clientName + ":" + clientCountry + "RQ-817 - TC-1636 TC01_CardMgmt_Ord_User request_Card_Declined",
				"User requests for a new card and it is being declined");
		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);

		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		//ApplicationsPage IFCSApplicationsPage = new ApplicationsPage(driver, test);
		OrderCardPage ChevronCardOrderPage = new OrderCardPage(driver, test);
		Common common = new Common(driver, test);

		// Calling Functions
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		IFCSloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		/*
		 * IFCSHomePage.gotoApplicationAndClickApplicationMenu();
		 * IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" +
		 * clientCountry); IFCSApplicationsPage.applicationFilterOptions(clientCountry +
		 * " GO Cards", "Approved");
		 */
		//String customerNo = common.getCustomerWithOutContactType(clientName + "_" + clientCountry);
		String customerNo=common.getCustomerNowithPrivateRebate(clientName, clientCountry);
		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		common.chooseCustomerNoAndSearch(customerNo);
		ChevronCardOrderPage.orderNewCardWithInvalidDataWFE(clientCountry);
		IFCSHomePage.exitIFCS();

	}

	/**
	 * Added by Venkata Davu
	 * 
	 * @param clientCountry
	 * @param clientName
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "BusinessFlow" })
	public void createBulkReissueRequest(@Optional("NL") String clientCountry, @Optional("WFE") String clientName) {

		test = extent.createTest(clientName + ":" + clientCountry + "  Bulk Reissue Manual",
				"Bulk Reissue Manual Request");
		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		CardMaintenancePage cardMaintenancePage = new CardMaintenancePage(driver, test);
		Common common = new Common(driver, test);
		// Calling Functions
		IFCSloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, " ");

		// choose Client from Application Page
		IFCSHomePage.gotoApplicationAndClickApplicationMenu();
		IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);

		
		// Getting Customer number havign card expiry in 90 days
		String customerNo = common.getCustomerNoHavingNoBulkReissueAndCardsExpiringInFewDays("Manual");

		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		common.chooseCustomerNoAndSearch(customerNo);
		// Getting IFCS Date
		String currentIFCSDate = common.getCurrentIFCSDateFromDB(clientName + clientCountry);
		String currentProcessingDate = common.enterADateValueInStatusBeginDateField("Current", currentIFCSDate);
		String futureIFCSDate = common.enterADateValueInStatusBeginDateField("Future", currentIFCSDate);
		String wayFutureIFCSDate = common.enterADateValueInStatusBeginDateField("WayFuture", currentIFCSDate);

		IFCSloginPage.logInfo("current IFCS date:::::" + currentIFCSDate);
		IFCSloginPage.logInfo("Current proccessing date:::::" + currentProcessingDate);
		IFCSloginPage.logInfo("Future IFCS date:::::" + futureIFCSDate);
		IFCSloginPage.logInfo("Way Future IFCS date:::::" + wayFutureIFCSDate);

		if (customerNo.equals("")) {
			// need to call method to logfail
			common.logForNoDataFound(this.getClass().getSimpleName(), "Need to Create A Cards For Customers and rerun");
		} else {
			common.chooseCustomerNoAndSearch(customerNo);
			// Calling Functions
			cardMaintenancePage.chooseCardAndCreateBulkReissueRequest(currentProcessingDate, futureIFCSDate,
					wayFutureIFCSDate);
			cardMaintenancePage.bulkReissueRequestWithValidDate(wayFutureIFCSDate);
		}

		PropUtils.setProps(configProp, "customerNo", customerNo);

		Map<String, String> cusNo = new HashMap<String, String>();
		cusNo.put("customerNo", customerNo);
		System.out
				.println("Created Customer Stored in Properties : " + customerNo + "--> TempCustomerNumber.properties");
		PropUtils.creatingTempPropFile(clientCountry + "TempCustomerNumber.properties", cusNo);

		// Execute Control-M - Day End
		// Validate in IFCS - Reissue Request

		IFCSHomePage.exitIFCS();

	}

	/**
	 * Added by Venkata Davu
	 * 
	 * @param clientCountry
	 * @param clientName
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "BusinessFlow" })
	public void validateBulkReissueRequest(@Optional("NL") String clientCountry, @Optional("WFE") String clientName) {

		test = extent.createTest(clientName + ":" + clientCountry + "  Bulk Reissue Manual",
				"Validation Bulk Reissue Manual");
		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);

		CardMaintenancePage cardMaintenancePage = new CardMaintenancePage(driver, test);
		Common common = new Common(driver, test);
		// Calling Functions
		IFCSloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, " ");
		IFCSHomePage ifcsHomePage = new IFCSHomePage(driver, test);
		Properties prop = null;
		try {
			prop = common.readPropertiesFile(clientCountry + "TempCustomerNumber.properties");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		String customerNo = prop.getProperty("customerNo");

		System.out.println("Customer number from property file " + customerNo);

		String expiringDateBeforeDayEnd = common.getCardExpiryDateForReissueCard(customerNo);
		cardMaintenancePage.validateBulkReissueStatus(customerNo, "Reissue Complete");

		String expiringDateAfterDayEnd = common.getCardExpiryDateForReissueCard(customerNo);
		// Validate in IFCS - Reissue Cards Expiry Date
		cardMaintenancePage.validateBulkReissuedCardsExpiryDate(expiringDateBeforeDayEnd, expiringDateAfterDayEnd, 48);
		ifcsHomePage.exitIFCS();
	}

	/**
	 * Implemented by Karuppasamy
	 * 
	 * @param clientCountry
	 * @param clientName    Busienss Flow ID:BF-075
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "BusinessFlow" })
	public void validateOrderNewCardWithMonthlyCardFeeEnabled(@Optional("CZ") String clientCountry,
			@Optional("SH") String clientName) {
		String orderedCardNumber = null;
		test = extent.createTest(clientName + ":" + clientCountry + "RQ-818 - TC-842 TC03_CardMgmt_Ord_Card creation_IFCS",
				"Able to order card with Monthly card Fee enabled");
		// creating object for the Pages
		IFCSLoginPage ifcsloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage ifcsHomePage = new IFCSHomePage(driver, test);
		Common common = new Common(driver, test);
		OrderCardPage orderCardpage = new OrderCardPage(driver, test);

		// Calling Functions
		ifcsloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		ifcsHomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);
		String clientNameInProp = PropUtils.getPropValue(configProp, clientName + "_" + clientCountry);
		String customerNumber = common.getCustomerNoHasTransaction(clientNameInProp);
		ifcsHomePage.gotoCustomerMenuCustomerDetails();
		common.chooseCustomerNoAndSearch(customerNumber);
		orderedCardNumber = orderCardpage.orderNewCardWithMonthlyFeeWFE();

		ifcsloginPage.logPass("Newly ordered card:: :: " + orderedCardNumber);
		ifcsHomePage.exitIFCS();

	}

	/**
	 * Implemented by Venkata Davu
	 * 
	 * @param clientCountry
	 * @param clientName    Busienss Flow ID:BF-080
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow" })
	public void createAndValidateNewCardWithPrivateProfile(@Optional("BL") String clientCountry,
			@Optional("WFE") String clientName) {

		test = extent.createTest(
				clientName + ":" + clientCountry + "RQ-820 - TC-775 TC05_CardMgmt_Ord_Card order_New private profile",
				"A new card ordered is ordered with private profile");

		// creating object for the Pages
		IFCSLoginPage ifcsLoginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage ifcsHomePage = new IFCSHomePage(driver, test);
		OrderCardPage orderCardpage = new OrderCardPage(driver, test);
		Common common = new Common(driver, test);

		MaintainCustomerPage maintainCustomerPage = new MaintainCustomerPage(driver, test);

		ApplicationsPage IFCSApplicationsPage = new ApplicationsPage(driver, test);

		ifcsLoginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		ifcsLoginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");

		String customerNo = common.getCustomerWithOutContactType(clientName + "_" + clientCountry);
		ifcsHomePage.gotoCustomerMenuCustomerDetails();
		common.chooseCustomerNoAndSearch(customerNo);

		maintainCustomerPage.enterDetailsInCardDetailsTab(clientName, clientCountry);
		maintainCustomerPage.createCardControlProfile();

		common.clickValidateIcon();
		orderCardpage.verifyValidationResult("Validation successful");
		common.createTaskBar();

		String cardNumber;
		cardNumber = orderCardpage.getValueFromProtectedTextBox("Card Offer", "Card Number");
		String validateCardNumber = "Card " + cardNumber + " ordered";
		System.out.println("Card Number is " + validateCardNumber);
		ifcsHomePage.exitIFCS();

	}

	/**
	 * Implemented by Venkata Davu
	 * 
	 * @param clientCountry
	 * @param clientName    Busienss Flow ID:BF-081
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow" })
	public void ValidateMandatoryFieldsInCardCreation(@Optional("BL") String clientCountry,
			@Optional("WFE") String clientName) {

		test = extent.createTest(
				clientName + ":" + clientCountry + "RQ-821 - TC-792 TC06_CardMgmt_Ord_error occurs on mandatory missing",
				"Validation check if not entered any mandatory fields while creating card");

		// creating object for the Pages
		IFCSLoginPage ifcsLoginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage ifcsHomePage = new IFCSHomePage(driver, test);

		CardMaintenancePage cardmaintenancepage = new CardMaintenancePage(driver, test);

		//ApplicationsPage IFCSApplicationsPage = new ApplicationsPage(driver, test);
		Common common = new Common(driver, test);

		ifcsLoginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		ifcsLoginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");

		String customerNo = common.getCustomerWithOutContactType(clientName + "_" + clientCountry);
		ifcsHomePage.gotoCustomerMenuCustomerDetails();
		common.chooseCustomerNoAndSearch(customerNo);

		
		cardmaintenancepage.validateMandatoryFieldsInCardCreationPage();
		ifcsHomePage.exitIFCS();

	}

	/**
	 * Implemented by Rathna
	 * 
	 * @param clientCountry
	 * @param clientName    Busienss Flow ID:BF-091
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow" })
	public void validateSearchCardsWithDifferentFilters(@Optional("BE") String clientCountry,
			@Optional("WFE") String clientName) {

		test = extent.createTest(
				clientName + ":" + clientCountry + "MD-341 - TC-1710 TC02_CardMgmt_search based on Card_status and Offer",
				"EQ-854 : Able to Search by Card Type / Status / Card Offer");
		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		Common common = new Common(driver, test);
		CardMaintenancePage cardMaintenancePage = new CardMaintenancePage(driver, test);

		// Calling Functions
		IFCSloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");

		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		String customerNumber = common.getActiveOrTemporaryBlockCustomerNoHavingCardsAndRowIndex(1, "Active");
		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		common.chooseCustomerNoAndSearch(customerNumber);
		cardMaintenancePage.chooseSubMenuFromLeftPanel("Card Details", "Cards");
		// Search cards - Apply filters
		cardMaintenancePage.searchCardByFilters("Card Offer", "Card Type", "Card Status");

		IFCSHomePage.exitIFCS();

	}

	/**
	 * Implemented by Rathna
	 * 
	 * @param clientCountry
	 * @param clientName    Business Flow ID:BF-092
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow" })
	public void downloadCSVReportFromTheListOfCards(@Optional("BE") String clientCountry,
			@Optional("WFE") String clientName) {

		test = extent.createTest(
				clientName + ":" + clientCountry + "TC-1711 TC03_CardMgmt_Search card with Expire IFCS",
				"RQ-855:Able to download the CSV report from the list of cards");
		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		Common common = new Common(driver, test);
		CardMaintenancePage cardMaintenancePage = new CardMaintenancePage(driver, test);
		// Calling Functions
		IFCSloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");

		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		String customerNumber = common.getActiveOrTemporaryBlockCustomerNoHavingCardsAndRowIndex(1, "Active");
		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		common.chooseCustomerNoAndSearch(customerNumber);
		cardMaintenancePage.chooseSubMenuFromLeftPanel("Card Details", "Cards");
		cardMaintenancePage.downloadCSVForCards();
		String fileName = "wexdownload";
		common.isFileDownloaded(fileName);
		IFCSHomePage.exitIFCS();

	}

	/**
	 * Implemented by Venkata Davu
	 * 
	 * @param clientCountry
	 * @param clientName    In Progress
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow" })
	public void testDataforBulkReissueCardsWithReissueProfile(@Optional("NL") String clientCountry,
			@Optional("WFE") String clientName) {

		test = extent.createTest(
				clientName + ":" + clientCountry + " RQ-838 - TC-778 TC04_CardMgmt_BlkReiss_Not include inactive card",
				"Bulk reissue should not include cards with Card Re-issue profile as Auto Renew and card status not in Normal Services");
		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		ChangeCardStatus changecardstatus = new ChangeCardStatus(driver, test);
		CardMaintenancePage cardMaintenancePage = new CardMaintenancePage(driver, test);
		Common common = new Common(driver, test);
		// Calling Functions
		IFCSloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, " ");

		// choose Client from Application Page
		IFCSHomePage.gotoApplicationAndClickApplicationMenu();
		IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);

		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		// Getting Customer number havign card expiry in 90 days
		String customerNo = common.getCustomerNoHavingNoBulkReissueAndCardsExpiringInFewDays("Manual");
		// Getting IFCS Date
		String currentIFCSDate = common.getCurrentIFCSDateFromDB(clientName + clientCountry);
		String currentProcessingDate = common.enterADateValueInStatusBeginDateField("Current", currentIFCSDate);
		String futureIFCSDate = common.enterADateValueInStatusBeginDateField("Future", currentIFCSDate);
		String wayFutureIFCSDate = common.enterADateValueInStatusBeginDateField("WayFuture", currentIFCSDate);

		System.out.println("current IFCS date:::::" + currentIFCSDate);
		System.out.println("Current proccessing date:::::" + currentProcessingDate);
		System.out.println("Future IFCS date:::::" + futureIFCSDate);
		System.out.println("Way Future IFCS date:::::" + wayFutureIFCSDate);

		if (customerNo.equals("")) {
			// need to call method to logfail
			common.logForNoDataFound(this.getClass().getSimpleName(), "Need to Create A Cards For Customers and rerun");
		} else {
			common.chooseCustomerNoAndSearch(customerNo);
			String reissueProfile = cardMaintenancePage.getCardReissueProfileName();

			System.out.println("reissueProfile name : " + reissueProfile);

			if (reissueProfile.equals("Auto-renew")) {
				// Calling Functions
				cardMaintenancePage.chooseCardAndCreateBulkReissueRequest(currentProcessingDate, futureIFCSDate,
						wayFutureIFCSDate);
				int beforeNoOfcard = common.getRowNumberFromTable();
				String beforeNoOfcard1 = Integer.toString(beforeNoOfcard);
				String cardNumber = cardMaintenancePage.getCardNumberFromBulkReissueTable();
				System.out.println("Card number : " + cardNumber);
				cardMaintenancePage.chooseAndSearchCardNo(cardNumber);
				changecardstatus.changeCardStatusAndClickNoAndValidate("Card Stolen");

				String fileName = Constants.BULK_REISSUE_TEMP_FILE;

				common.updatePropFile("CURRENT_PROCESSING_DATE_" + clientName + "_" + clientCountry,
						currentProcessingDate, fileName);
				common.updatePropFile("FUTURE_IFCS_DATE_" + clientName + "_" + clientCountry, futureIFCSDate, fileName);
				common.updatePropFile("WAY_FUTURE_IFCS_DATE_" + clientName + "_" + clientCountry, wayFutureIFCSDate,
						fileName);
				common.updatePropFile("BEFORE_NO_OF_CARDS_" + clientName + "_" + clientCountry, beforeNoOfcard1,
						fileName);
				common.updatePropFile("CARD_NUMBER_" + clientName + "_" + clientCountry, cardNumber, fileName);

			}
		}

		// Execute Control-M - Day End

	}

	/**
	 * Implemented by Venkata Davu
	 * 
	 * @param clientCountry
	 * @param clientName    In Progress
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow" })
	public void validateBulkReissueCardsWithReissueProfile(@Optional("NL") String clientCountry,
			@Optional("WFE") String clientName) {

		test = extent.createTest(clientName + ":" + clientCountry + " Bulk Reissue Manual",
				"Bulk reissue should not include cards with Card Re-issue profile as Do not Renew");
		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		//ChangeCardStatus changecardstatus = new ChangeCardStatus(driver, test);
		CardMaintenancePage cardMaintenancePage = new CardMaintenancePage(driver, test);
		//Common common = new Common(driver, test);
		// Calling Functions
		IFCSloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, " ");

		String currentProcessingDate = PropUtils.getPropValue(bulkReissueTempFileProp,
				"CURRENT_PROCESSING_DATE_" + clientName + "_" + clientCountry);
		String wayFutureIFCSDate = PropUtils.getPropValue(bulkReissueTempFileProp,
				"WAY_FUTURE_IFCS_DATE_" + clientName + "_" + clientCountry);
		String beforeNoOfcard1 = PropUtils.getPropValue(bulkReissueTempFileProp,
				"BEFORE_NO_OF_CARDS_" + clientName + "_" + clientCountry);
		String cardNumber = PropUtils.getPropValue(bulkReissueTempFileProp,
				"BEFORE_NO_OF_CARDS_" + clientName + "_" + clientCountry);
		String futureIFCSDate = PropUtils.getPropValue(bulkReissueTempFileProp,
				"FUTURE_IFCS_DATE_" + clientName + "_" + clientCountry);

		int beforeNoOfcard = Integer.parseInt(beforeNoOfcard1);
		cardMaintenancePage.chooseCardAndCreateBulkReissueRequest(currentProcessingDate, futureIFCSDate,
				wayFutureIFCSDate);
		System.out.println("No ofCards : " + beforeNoOfcard);

		cardMaintenancePage.validateBulkReissueCardsWithInvalidCard(beforeNoOfcard, cardNumber);
		IFCSHomePage.exitIFCS();
	}


	/**
	 * Implemented by Venkata Davu
	 * 
	 * @param clientCountry
	 * @param clientName    Busienss Flow ID:BF-073, BF-086
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow" })
	public void orderNewCardWithVINCIFeeEnabled(@Optional("BL") String clientCountry,
			@Optional("WFE") String clientName) {

		test = extent.createTest(clientName + ":" + clientCountry + " RQ-822 - TC-1114 TC07_CardMgmt_Ord_Subscription customer",
				"A new card ordered for Subscription enabled customer");

		// creating object for the Pages
		IFCSLoginPage ifcsLoginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage ifcsHomePage = new IFCSHomePage(driver, test);
		OrderCardPage orderCardpage = new OrderCardPage(driver, test);
		CardMaintenancePage cardMaintenancePage = new CardMaintenancePage(driver, test);
		Common common = new Common(driver, test);

		MaintainCustomerPage maintainCustomerPage = new MaintainCustomerPage(driver, test);

		ifcsLoginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		ifcsLoginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");

		// ifcsHomePage.gotoApplicationAndClickApplicationMenu();
		// ifcsHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" +
		// clientCountry);

		// IFCSApplicationsPage.applicationFilterOptions(clientCountry + " Go Cards",
		// "Approved");

		String cardNo = common.getVinCiiActiveCard();
		ifcsHomePage.gotoCustomerMenuCustomerDetails();

		cardMaintenancePage.chooseAndSearchCardNo(cardNo);

		ifcsHomePage.gotoCustomerMenuCustomerDetails();

		maintainCustomerPage.enterDetailsInCardDetailsTab(clientName, clientCountry);
		maintainCustomerPage.createCardControlProfile();
		maintainCustomerPage.enableVINCIFee();

		common.clickValidateIcon();
		orderCardpage.verifyValidationResult("Validation successful");
		common.createTaskBar();

		String cardNumber;
		cardNumber = orderCardpage.getValueFromProtectedTextBox("Card Offer", "Card Number");
		String validateCardNumber = "Card " + cardNumber + " ordered";
		System.out.println("Card Number is " + validateCardNumber);
		ifcsHomePage.exitIFCS();

	}

	/**
	 * Implemented by Venkata Davu
	 * 
	 * @param clientCountry
	 * @param clientName    Business Flow ID:BF-074
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow" })
	public void updateExistingCardWithVINCIFeeEnabled(@Optional("BL") String clientCountry,
			@Optional("WFE") String clientName) {

		test = extent.createTest(clientName + ":" + clientCountry + " ID:BF-074 Update Existing card with VINCII Fee",
				"Update Existing card with VINCII Fee ");

		// creating object for the Pages
		IFCSLoginPage ifcsLoginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage ifcsHomePage = new IFCSHomePage(driver, test);
		OrderCardPage orderCardpage = new OrderCardPage(driver, test);
		CardMaintenancePage cardMaintenancePage = new CardMaintenancePage(driver, test);
		Common common = new Common(driver, test);

		ifcsLoginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		ifcsLoginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");

		String cardNo = common.getVinCiiActiveCard();
		ifcsHomePage.gotoCustomerMenuCustomerDetails();

		cardMaintenancePage.chooseAndSearchCardNo(cardNo);

		cardMaintenancePage.updateEnableVINCIFee();

		orderCardpage.verifyValidationResult("Record saved OK");

		ifcsHomePage.exitIFCS();

	}

	/**
	 * Implemeted by Rathna
	 * 
	 * @param clientCountry
	 * @param clientName
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "Regression" })
	public void validateFundTransferCardToAccountBillingNodeAndBalancedAllowed(@Optional("BE") String clientCountry,
			@Optional("WFE") String clientName) {

		test = extent.createTest("validateFundTransferCardToAccountBillingNodeAndBalancedAllowed",
				"validateFundTransferCardToAccountBillingNodeAndBalancedAllowed");
		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);

		TransactionListPage transactionListPage = new TransactionListPage(driver, test);

		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		Common common = new Common(driver, test);
		//OrderCardPage orderCardpage = new OrderCardPage(driver, test);
		//MaintainCustomerPage maintainCustomerPage = new MaintainCustomerPage(driver, test);

		// Calling Functions
		IFCSloginPage.login("IFCS_URL_WFE", "IFCS_WFE_USERNAME", "IFCS_WFE_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		// Set the Client
		IFCSHomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);
		// Select the Manage Transaction from Transaction menu
		IFCSHomePage.gotoTransactionAndClickManageTransaction();

		String parentCusNumber = common.getActiveParentCustomerNoInHierarcy("billing", " ", "balanceAllowed", false,
				"positive", clientName + clientCountry, 1);
		String parentCardNo = common.getActiveCardsInHierarcy(parentCusNumber, "positive", "balanceAllowed",
				clientName + clientCountry, 1);

		if (parentCusNumber.equals("") && parentCardNo.equals("")) {

			// String cardNumber = "71021523797300040";
			// String customerNumber = "3237973";
			String cardNumber = common.getCardNumberFromIFCSDB(clientName, clientCountry, "Active");// Normal Service
			String customerNumber = common.getActiveCustomerNoUsingCardType();

			transactionListPage.verifyFundTransferCardToAccount(cardNumber, customerNumber, "Validation successful");
			// updated rathna
			if (common.isValidationMessageExists("Validation successful"))// in sufficient funds in from card msg
																			// dispaying for few cards
			{

				transactionListPage.validateTransactionMessage();
				common.clickPostTransaction();
				// transactionListPage.validateTransactionMessage(); //new method written
				transactionListPage.verifyFundTransferSuccessfulMessage("Card No", "Account No", "CardToAcc");
				transactionListPage.validateCreditAndDebitAmount("Card No", "Account No", cardNumber, customerNumber,
						"Card To Account");
			} else {
				common.logInfo("Insufficient funds in from card");
			}
			

		}
		IFCSHomePage.exitIFCS();
	}
	





	/**
	 * Implemeted by Rathna
	 * 
	 * @param clientCountry
	 * @param clientName    BF: 172,173
	 */

	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "Regression" })
	public void validateAccountToAccountFundTransferWithSameHierarchy(@Optional("BE") String clientCountry,
			@Optional("WFE") String clientName) {

		test = extent.createTest(clientName + ":" + clientCountry + " TC-1705 TC01_TxnMgmt_FTr_Parent to Child",
				"RQ-898:CSR able to transfer fund from Parent to Child");
		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		TransactionListPage transactionListPage = new TransactionListPage(driver, test);
		MaintainCustomerPage maintainCustomerPage = new MaintainCustomerPage(driver, test);
		Common common = new Common(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);

		// Calling Functions
		IFCSloginPage.login("IFCS_URL_WFE", "IFCS_WFE_USERNAME", "IFCS_WFE_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		IFCSHomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);
		String customerNumberUsingCardType = common.getActiveCustomerNoUsingCardType();
		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		common.chooseCustomerNoAndSearch(customerNumberUsingCardType);
		// Get Parent Customer no with hierarchy
		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		String parentCusNumber = maintainCustomerPage.createHierarchyWithChild();
		String childCusNumber = maintainCustomerPage.subAccount;
		// Fund Transfer: Parent to child
		IFCSHomePage.gotoTransactionAndClickManageTransaction();
		transactionListPage.verifyFundTransferAccountToAccount(parentCusNumber, childCusNumber, "Validation successful",
				false);
		common.clickPostTransaction();
		transactionListPage.verifyFundTransferSuccessfulMessage("Account No", "Account No", "AccToAcc");
		// Fund Transfer:Child to Parent
		IFCSHomePage.gotoTransactionAndClickManageTransaction();
		transactionListPage.verifyFundTransferAccountToAccount(childCusNumber, parentCusNumber, "Validation successful",
				false);
		common.clickPostTransaction();
		transactionListPage.verifyFundTransferSuccessfulMessage("Account No", "Account No", "AccToAcc");

		IFCSHomePage.exitIFCS();

	}


	/**
	 * Added by Nithya - NA
	 * 
	 * @param clientCountry
	 * @param clientName    Busienss Flow ID:BF-059
	 *//*
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "BusinessFlow" })
	public void cardMaintenanceUpdateCardReissueProfile(@Optional("AU") String clientCountry,
			@Optional("BP") String clientName) {
		test = extent.createTest(clientName + ":" + clientCountry + " ID:BF-059 Update Card Reissue Profile",
				" Card reissue profiles is updated for a existing customer based on customer request  from IFCS");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		// Common common = new Common(driver, test);
		// CardMaintenancePage cardMaintenancePage = new CardMaintenancePage(driver,
		// test);
		// MaintainCustomerPage customerPage = new MaintainCustomerPage(driver, test);
		// String cardNumber;

		IFCSloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");

		IFCSHomePage.exitIFCS();
	}*/

	/**
	 * Added by Rathna
	 * 
	 * @param clientCountry
	 * @param clientName    Busienss Flow ID:045
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "Regression" })
	public void createPrivateAnualCardFeeProfile(@Optional("BE") String clientCountry,
			@Optional("WFE") String clientName) {
		test = extent.createTest(
				clientName + ":" + clientCountry + "TC-1731 TC03_CustMgmt_create private Annual Card fee",
				"RQ-799 : Able to create a private Monthly/Annual card fee profile");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		Common common = new Common(driver, test);
		MaintainCustomerPage maintainCustomerPage = new MaintainCustomerPage(driver, test);

		IFCSloginPage.login("IFCS_URL_WFE", "IFCS_WFE_USERNAME", "IFCS_WFE_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");

		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		// Need to select customer no which has no private card fee profile
		String customerNo = common.getCustomerNoHavingCardsUsingCardType();
		if (customerNo.equals(" ")) {
			common.logForNoDataFound(this.getClass().getSimpleName(), "Need to Create A Customer with Cards and rerun");
		} else {
			common.chooseCustomerNoAndSearch(customerNo);
			maintainCustomerPage.chooseMaintainCardFeesFromCustomerProfile();
			if (maintainCustomerPage.getRowCount("Card Fees") == 0) {
				// create card fee
				maintainCustomerPage.createCardFees();
				maintainCustomerPage.createPrivateCardFeeProfile("Annual Card Fee",clientCountry);

				maintainCustomerPage.SaveAndDeleteProfile();
			} else {
				common.logInfo("Card fees contains private profile already ");
			}

		}
		IFCSHomePage.exitIFCS();
	}

	/**
	 * Added by Rathna
	 * 
	 * @param clientCountry
	 * @param clientName    Busienss Flow ID:045
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "Regression" })
	public void createPrivateMonthlyCardFeeProfile(@Optional("BE") String clientCountry,
			@Optional("WFE") String clientName) {
		test = extent.createTest(
				clientName + ":" + clientCountry + "TC-1732 TC04_CustMgmt_create private Monthly card fee",
				"RQ-799 : Able to create a private Monthly/Annual card fee profile");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		Common common = new Common(driver, test);
		MaintainCustomerPage maintainCustomerPage = new MaintainCustomerPage(driver, test);

		IFCSloginPage.login("IFCS_URL_WFE", "IFCS_WFE_USERNAME", "IFCS_WFE_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");

		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		// Need to select customer no which has no private card fee profile
		String customerNo = common.getCustomerNoHavingCardsUsingCardType();
		if (customerNo.equals(" ")) {
			common.logForNoDataFound(this.getClass().getSimpleName(), "Need to Create A Customer with Cards and rerun");
		} else {
			common.chooseCustomerNoAndSearch(customerNo);
			maintainCustomerPage.chooseMaintainCardFeesFromCustomerProfile();
			if (maintainCustomerPage.getRowCount("Card Fees") == 0) {
				// create card fee
				maintainCustomerPage.createCardFees();
				maintainCustomerPage.createPrivateCardFeeProfile("Monthly Card Fee",clientCountry);

				maintainCustomerPage.SaveAndDeleteProfile();
			} else {
				common.logInfo("Card fees cotnains private profile ");
			}

		}
		IFCSHomePage.exitIFCS();
	}

	/**
	 * Added by Rathna
	 * 
	 * @param clientCountry
	 * @param clientName    Busienss Flow ID:045
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "Regression" })
	public void createPrivateMonthlyVinciCardFeeProfile(@Optional("BE") String clientCountry,
			@Optional("WFE") String clientName) {
		test = extent.createTest(
				clientName + ":" + clientCountry + "TC-1734 TC05_CustMgmt_create private Vinci card fee",
				"RQ-799 : Able to create a private Monthly/Annual card fee profile");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		Common common = new Common(driver, test);
		MaintainCustomerPage maintainCustomerPage = new MaintainCustomerPage(driver, test);

		IFCSloginPage.login("IFCS_URL_WFE", "IFCS_WFE_USERNAME", "IFCS_WFE_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");

		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		// Need to select customer no which has no private card fee profile
		String customerNo = common.getCustomerNoHavingCardsUsingCardType();
		if (customerNo.equals(" ")) {
			common.logForNoDataFound(this.getClass().getSimpleName(), "Need to Create A Customer with Cards and rerun");
		} else {
			common.chooseCustomerNoAndSearch(customerNo);
			maintainCustomerPage.chooseMaintainCardFeesFromCustomerProfile();
			if (maintainCustomerPage.getRowCount("Card Fees") == 0) {
				// create card fee
				maintainCustomerPage.createCardFees();
				maintainCustomerPage.createPrivateCardFeeProfile("Monthly Vinci Fee",clientCountry);

				maintainCustomerPage.SaveAndDeleteProfile();
			} else {
				common.logInfo("Card fees cotnains private profile ");
			}

		}
		IFCSHomePage.exitIFCS();
	}

	/**
	 * Added by Rathna
	 * 
	 * @param clientCountry
	 * @param clientName    Busienss Flow ID:797
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "Regression" })
	public void defaultPublicMonthlyCardFeeProfile(@Optional("BE") String clientCountry,
			@Optional("WFE") String clientName) {
		test = extent.createTest(
				clientName + ":" + clientCountry + "TC-1730 TC02_CUstMgmt_default Public Monthly card fee",
				"RQ-797- Able to default public Monthly/Annual card fee");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		Common common = new Common(driver, test);
		MaintainCustomerPage maintainCustomerPage = new MaintainCustomerPage(driver, test);

		IFCSloginPage.login("IFCS_URL_WFE", "IFCS_WFE_USERNAME", "IFCS_WFE_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");

		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		// Need to select who has no private card fee profile
		String customerNo = common.getCustomerNoHavingCardsUsingCardType();
		if (customerNo.equals(" ")) {
			common.logForNoDataFound(this.getClass().getSimpleName(), "Need to Create A Customer with Cards and rerun");
		} else {
			common.chooseCustomerNoAndSearch(customerNo);
			maintainCustomerPage.chooseMaintainCardFeesFromCustomerProfile();

			if (maintainCustomerPage.getRowCount("Card Fees") == 0) {
				System.out.println("row count is : " + maintainCustomerPage.getRowCount("Card Fees"));
				maintainCustomerPage.createCardFees();
			}

			maintainCustomerPage.setProfileAsDefault("Monthly");
			// maintainCustomerPage.SaveAndDeleteProfile();

		}
		IFCSHomePage.exitIFCS();
	}

	

	/**
	 * Added by Rathna
	 * 
	 * @param clientCountry
	 * @param clientName    Busienss Flow ID:797
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "Regression" })
	public void defaultPublicAnnualCardFeeProfile(@Optional("BE") String clientCountry,
			@Optional("WFE") String clientName) {
		test = extent.createTest(
				clientName + ":" + clientCountry + "TC-1729 TC01_CustMgmt_default Public Annual Card fee",
				"RQ-797- Able to default public Monthly/Annual card fee");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		Common common = new Common(driver, test);
		MaintainCustomerPage maintainCustomerPage = new MaintainCustomerPage(driver, test);

		IFCSloginPage.login("IFCS_URL_WFE", "IFCS_WFE_USERNAME", "IFCS_WFE_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");

		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		// Need to select who has no private card fee profile
		String customerNo = common.getCustomerNoHavingCardsUsingCardType();
		if (customerNo.equals(" ")) {
			common.logForNoDataFound(this.getClass().getSimpleName(), "Need to Create A Customer with Cards and rerun");
		} else {
			common.chooseCustomerNoAndSearch(customerNo);
			maintainCustomerPage.chooseMaintainCardFeesFromCustomerProfile();

			if (maintainCustomerPage.getRowCount("Card Fees") == 0) {
				System.out.println("row count is : " + maintainCustomerPage.getRowCount("Card Fees"));
				maintainCustomerPage.createCardFees();
			}

			maintainCustomerPage.setProfileAsDefault("Annual");
			// maintainCustomerPage.SaveAndDeleteProfile();

		}
		IFCSHomePage.exitIFCS();
	}
	


	/**
	 * Implemented by Nithya
	 * 
	 * @param clientCountry
	 * @param clientName    Business Flow ID:BF-090
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "BusinessFlow" })
	public void validateCardExpiry(@Optional("BE") String clientCountry, @Optional("WFE") String clientName) {

		test = extent.createTest(clientName + ":" + clientCountry + " ID:BF-090 Validate Card Expiry",
				"Cards should reach the status as Expired on the expiry date");
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCShomePage = new IFCSHomePage(driver, test);
		Common common = new Common(driver, test);
		IFCSloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		CardMaintenancePage cardMaintenancePage = new CardMaintenancePage(driver, test);

		// Serch Cutomer
		IFCShomePage.gotoApplicationAndClickApplicationMenu();
		IFCShomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);

		String cardNo = common.getVinCiiActiveCard();
		IFCShomePage.gotoCustomerMenuCustomerDetails();

		cardMaintenancePage.chooseAndSearchCardNo(cardNo);
		cardMaintenancePage.cardExpiryDateChange();

		IFCShomePage.exitIFCS();
	}

	/**
	 * Implemented by Nithya
	 * 
	 * @param clientCountry
	 * @param clientName    Business Flow ID:RQ-818
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow" })
	public void orderCardviaAPI(@Optional("AU") String clientCountry, @Optional("BP") String clientName) {

		test = extent.createTest(
				clientName + ":" + clientCountry + "RQ-818 - TC-1241 TC02_CardMgmt_Ord_Cards_able to order via API",
				"Create new card via API ");

		CardAPIMethods cardAPIMethods = new CardAPIMethods(driver, test);

		IFCSLoginPage ifcsLoginPage = new IFCSLoginPage(driver, test);
		Common common = new Common(driver, test);
		ifcsLoginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");

		cardAPIMethods.loginToAPIUser(
				PropUtils.getPropValue(configProp, "UserNameAPI" + "_" + clientName + "_" + clientCountry),
				PropUtils.getPropValue(configProp, "PassWordAPI" + "_" + clientName + "_" + clientCountry));
		String customerNumber = common.getActiveOrTemporaryBlockCustomerNoHavingCardsAndRowIndex(1, "Active");
		cardAPIMethods.orderCard(clientName, clientCountry, customerNumber, "BE D-truck - Driver", "Open");

		cardAPIMethods.logoutAPIUser();

	}
	

	
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "BusinessFlow" })
	public void updateExistingCardWithCostCentre(@Optional("BE") String clientCountry,
			@Optional("WFE") String clientName) {

		test = extent.createTest(clientName + ":" + clientCountry + " ID:BF-034 IFCS Customer Cost Center",
				"Able to add more than one cost center");
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		MaintainCustomerPage maintainCustomerPage = new MaintainCustomerPage(driver, test);
		CardMaintenancePage cardMaintenancePage = new CardMaintenancePage(driver, test);
		Common common = new Common(driver, test);

		IFCSloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");

		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");

		// getting Card No from DB/
		String cardNo = common.getCardNumberhavingNoCostCentreFromDB();
		String costCenterCode = Faker.instance().number().digits(4);
		if (cardNo.equals(" ")) {
			common.logForNoDataFound(this.getClass().getSimpleName(),
					"Need to Create A Customer with Card Type and rerun");
		} else {

			IFCSHomePage.gotoCustomerMenuCustomerDetails();
			cardMaintenancePage.chooseAndSearchCardNo(cardNo);
			maintainCustomerPage.chooseCostCentre();

			maintainCustomerPage.addCostCentreAndValidate(costCenterCode);
		}

		cardMaintenancePage.chooseAndSearchCardNo(cardNo);

		cardMaintenancePage.updateCostCentreForCard(costCenterCode);

		IFCSHomePage.exitIFCS();

	}

	/**
	 * Implemented by Venkata Davu
	 * 
	 * @param clientCountry
	 * @param clientName    Busienss Flow ID:BF-
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow" })
	public void orderNewCardForWhiteListFile(@Optional("BE") String clientCountry, @Optional("WFE") String clientName) {

		test = extent.createTest(clientName + ":" + clientCountry + "MD-342 - TC-860 TC01_CardMgmt_Full whitelist file",
				"Able to generate Full whitelist file which containts new cards details ");

		// creating object for the Pages

		IFCSLoginPage ifcsLoginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage ifcsHomePage = new IFCSHomePage(driver, test);
		OrderCardPage orderCardpage = new OrderCardPage(driver, test);
		Common common = new Common(driver, test);
		IFCSCommonPage ifcsCommonPage = new IFCSCommonPage(driver, test);
		InterfacePage interfacePage = new InterfacePage(driver, test);

		MaintainCustomerPage maintainCustomerPage = new MaintainCustomerPage(driver, test);

		ApplicationsPage IFCSApplicationsPage = new ApplicationsPage(driver, test);

		ifcsLoginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		ifcsLoginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");

		ifcsHomePage.gotoApplicationAndClickApplicationMenu();
		ifcsHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);

		IFCSApplicationsPage.applicationFilterOptions(clientCountry + " Go Cards", "Approved");

		ifcsHomePage.gotoCustomerMenuCustomerDetails();

		maintainCustomerPage.enterDetailsInCardDetailsTab(clientName, clientCountry);
		maintainCustomerPage.createCardControlProfile();

		common.clickValidateIcon();
		orderCardpage.verifyValidationResult("Validation successful");
		common.createTaskBar();

		String cardNumber = orderCardpage.getValueFromProtectedTextBox("Card Offer", "Card Number");
		String validateCardNumber = "Card " + cardNumber + " ordered";
		System.out.println("Card Number is " + validateCardNumber);

		// PropUtils.setProps(cardForWhitelistFileProp,
		// "NEW_CARD"+clientName+"_"+clientCountry, cardNumber);

		String filename = "Constants.CARD_FOR_WHITELIST_FILE";

		common.updatePropFile("NEW_CARD_" + clientName + "_" + clientCountry, cardNumber, filename);

		String folderName = ifcsCommonPage.getControlMFolder(clientName, clientCountry, "job_wfe_CardEmboss");
		ifcsLoginPage.logInfo("folderName order::" + folderName);
		String jobsInOrder = ifcsCommonPage.getJobsOfFolderInOrder("job_wfe_CardEmboss");
		ifcsLoginPage.logInfo("jobsin order::" + jobsInOrder);

		// Executing control-m jobs
		interfacePage.establishAndExecuteControlMJobs("ControlM_AWS_UAT", "ContorlM_AWS_userName",
				"ContorlM_AWS_password", folderName, jobsInOrder);

		String folderName1 = ifcsCommonPage.getControlMFolder(clientName, clientCountry, "job_wfe_CardChanges");
		ifcsLoginPage.logInfo("folderName order::" + folderName);

		String jobsInOrder1 = ifcsCommonPage.getJobsOfFolderInOrder("job_wfe_CardChanges");
		ifcsLoginPage.logInfo("jobsin order::" + jobsInOrder);

		// Executing control-m jobs
		interfacePage.establishAndExecuteControlMJobs("ControlM_AWS_UAT", "ContorlM_AWS_userName",
				"ContorlM_AWS_password", folderName1, jobsInOrder1);

	}

	
	
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "BusinessFlow" })
	public void validateNewlyOrderedCardInWhiteListFile(@Optional("BE") String clientCountry,
			@Optional("WFE") String clientName) {

		test = extent.createTest(clientName + ":" + clientCountry + " TC-860 TC01_CardMgmt_Full whitelist file",
				"Able to generate Full whitelist file which containts new cards details");

		String cardNumber = PropUtils.getPropValue(cardForWhitelistFileProp,
				"NEW_CARD_" + clientName + "_" + clientCountry);
		String fileName;
		TextFileUtils textFileUtils = new TextFileUtils();

		fileName = Constants.WHITELISTFILE_DIR + "019400340658.txt";

		textFileUtils.validateTextFileWithString(fileName, cardNumber);

	}

	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow" })
	public void updateExistingCardForWhiteListFile(@Optional("BL") String clientCountry,
			@Optional("WFE") String clientName) {

		test = extent.createTest(clientName + ":" + clientCountry + "MD-342 - TC-1022 TC02_CardMgmt_Partial whitelist file",
				"Able to generate Partial whitelist file which containts updated cards details ");

		// creating object for the Pages
		IFCSLoginPage ifcsLoginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage ifcsHomePage = new IFCSHomePage(driver, test);
		OrderCardPage orderCardpage = new OrderCardPage(driver, test);
		MaintainCustomerPage maintainCustomerPage = new MaintainCustomerPage(driver, test);

		CardMaintenancePage cardMaintenancePage = new CardMaintenancePage(driver, test);
		Common common = new Common(driver, test);
		IFCSCommonPage ifcsCommonPage = new IFCSCommonPage(driver, test);
		InterfacePage interfacePage = new InterfacePage(driver, test);

		ifcsLoginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		ifcsLoginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");

		String cardNo = common.getActiveCardNumberFromDBWFE(clientName, clientCountry);
		ifcsHomePage.gotoCustomerMenuCustomerDetails();

		cardMaintenancePage.chooseAndSearchCardNo(cardNo);

		maintainCustomerPage.updateCardControlProfile();

		orderCardpage.verifyValidationResult("Record saved OK");
		
		//String filename =  "Constants.CARD_FOR_WHITELIST_FILE";

		String filename = "Constants.CARD_FOR_WHITELIST_FILE";

		common.updatePropFile("UPDATE_CARD_" + clientName + "_" + clientCountry, cardNo, filename);

		String folderName1 = ifcsCommonPage.getControlMFolder(clientName, clientCountry, "job_wfe_CardChanges");
		ifcsLoginPage.logInfo("folderName order::" + folderName1);

		String jobsInOrder1 = ifcsCommonPage.getJobsOfFolderInOrder("job_wfe_CardChanges");
		ifcsLoginPage.logInfo("jobsin order::" + jobsInOrder1);

		// Executing control-m jobs
		interfacePage.establishAndExecuteControlMJobs("ControlM_AWS_UAT", "ContorlM_AWS_userName",
				"ContorlM_AWS_password", folderName1, jobsInOrder1);



	}

	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "BusinessFlow" })
	public void validateUpdatedCardInWhiteListFile(@Optional("BE") String clientCountry,
			@Optional("WFE") String clientName) {

		test = extent.createTest(clientName + ":" + clientCountry + "  TC-1022 TC02_CardMgmt_Partial whitelist file",
				"Validate the updated card in White list file");

		String cardNumber = PropUtils.getPropValue(cardForWhitelistFileProp,
				"UPDATE_CARD_" + clientName + "_" + clientCountry);
		String fileName;
		TextFileUtils textFileUtils = new TextFileUtils();

		fileName = Constants.WHITELISTFILE_DIR + "019400340658.txt";

		textFileUtils.validateTextFileWithString(fileName, cardNumber);

	}

	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "Regression" })
	public void changeCardStatusForWhiteListFile(@Optional("BE") String clientCountry,
			@Optional("WFE") String clientName) {

		test = extent.createTest(clientName + ":" + clientCountry + "  Change Card status for White List file",
				"Change Card status for White List file");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		ChangeCardStatus changeCardStatus = new ChangeCardStatus(driver, test);
		CardMaintenancePage cardMaintenancePage = new CardMaintenancePage(driver, test);
		Common common = new Common(driver, test);
		//IFCSCommonPage ifcsCommonPage = new IFCSCommonPage(driver, test);
		//InterfacePage interfacePage = new InterfacePage(driver, test);

		IFCSloginPage.login("IFCS_URL_WFE", "IFCS_WFE_USERNAME", "IFCS_WFE_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, " ");
		// Click search cards
		

		String cardNo = common.getActiveCardNumberFromDBWFE(clientName, clientCountry);
		IFCSHomePage.gotoCustomerMenuCustomerDetails();

		cardMaintenancePage.chooseAndSearchCardNo(cardNo);
		changeCardStatus.changeCardStatusAndClickYesAndValidate("Temporary Card Close");
		String filename = "Constants.CARD_FOR_WHITELIST_FILE";

		common.updatePropFile("UPDATE_CARD_" + clientName + "_" + clientCountry, cardNo, filename);

		/*String folderName1 = ifcsCommonPage.getControlMFolder(clientName, clientCountry, "job_wfe_CardChanges");
		IFCSloginPage.logInfo("folderName order::" + folderName1);

		String jobsInOrder1 = ifcsCommonPage.getJobsOfFolderInOrder("job_wfe_CardChanges");
		IFCSloginPage.logInfo("jobsin order::" + jobsInOrder1);

		// Executing control-m jobs
		interfacePage.establishAndExecuteControlMJobs("ControlM_AWS_UAT", "ContorlM_AWS_userName",
				"ContorlM_AWS_password", folderName1, jobsInOrder1);*/

	}

	/**
	 * Added by Venkata Davu
	 * 
	 * @param clientCountry
	 * @param clientName    Execute this case after run auto bulk reissue jobs from
	 *                      Control M
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "BusinessFlow" })
	public void testDataForAutoBulkReissueAwaitingConfirmation(@Optional("NL") String clientCountry,
			@Optional("WFE") String clientName) {

		test = extent.createTest(
				clientName + ":" + clientCountry + "RQ-836 TC-781 TC01_CardMgmt_BlkReiss_ Auto Bulk Reissue_Await_confirm",
				"Card reissue profiles is updated for a existing customer based on customer request");
		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		WFECommon wfecommon = new WFECommon(driver, test);
		Common common = new Common(driver, test);
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, " ");
		String customerNo = wfecommon.getCustomerNoBasedOnBulkReissueStatus(clientName + "_" + clientCountry,
				"Awaiting Confirmation");
		String filename = Constants.BULK_REISSUE_TEMP_FILE;

		common.updatePropFile("AUTO_BULK_REISSUE_CUSTOMER_" + clientName + "_" + clientCountry, customerNo, filename);

	}

	/**
	 * Added by Venkata Davu
	 * 
	 * @param clientCountry
	 * @param clientName    Execute this case after run month end jobs from Control
	 *                      M
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "BusinessFlow" })
	public void validateAutoBulkReissueForConfirmedReissuePending(@Optional("NL") String clientCountry,
			@Optional("WFE") String clientName) {

		test = extent.createTest(
				clientName + ":" + clientCountry + "RQ-834 TC-1706 TC02_CardMgmt_BlkReiss_Auto Bulk reissue_Reissue Pending",
				"Automatic bulk Reissue request raised automatically for the cards , those are going to expire within specified time limit");
		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		//WFECommon wfecommon = new WFECommon(driver, test);
		Common common = new Common(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		//ChangeCardStatus changecardstatus = new ChangeCardStatus(driver, test);
		CardMaintenancePage cardMaintenancePage = new CardMaintenancePage(driver, test);

		String customerNo = PropUtils.getPropValue(bulkReissueTempFileProp,
				"AUTO_BULK_REISSUE_CUSTOMER_" + clientName + "_" + clientCountry);

		// Calling Functions
		IFCSloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, " ");

		// choose Client from Application Page
		IFCSHomePage.gotoApplicationAndClickApplicationMenu();
		IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);

		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		common.chooseCustomerNoAndSearch(customerNo);

		cardMaintenancePage.validateAutoBulkReissueStatus("Confirmed Reissue Pending");

		IFCSHomePage.exitIFCS();

		
	}

	/**
	 * Added by Venkata Davu
	 * 
	 * @param clientCountry
	 * @param clientName    Execute this case after run month end jobs from Control
	 *                      M
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "BusinessFlow" })
	public void validateAutoBulkReissueForReissueComplete(@Optional("NL") String clientCountry,
			@Optional("WFE") String clientName) {

		test = extent.createTest(
				clientName + ":" + clientCountry + "RQ-835 TC-1707 TC03_CardMgmt_BlkReiss_Bulk reissue Completed",
				"Bulk Reissue request raised for the cards that comes under the time period mentioned in the Customer's Request for reissue");
		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		//WFECommon wfecommon = new WFECommon(driver, test);
		Common common = new Common(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		//ChangeCardStatus changecardstatus = new ChangeCardStatus(driver, test);
		CardMaintenancePage cardMaintenancePage = new CardMaintenancePage(driver, test);

		String customerNo = PropUtils.getPropValue(bulkReissueTempFileProp,
				"AUTO_BULK_REISSUE_CUSTOMER_" + clientName + "_" + clientCountry);

		// Calling Functions
		IFCSloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, " ");

		// choose Client from Application Page
		IFCSHomePage.gotoApplicationAndClickApplicationMenu();
		IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);

		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		common.chooseCustomerNoAndSearch(customerNo);

		cardMaintenancePage.validateAutoBulkReissueStatus("Reissue Complete");

		IFCSHomePage.exitIFCS();

		
	}

	/**
	 * Added by Nithya
	 * 
	 * @param clientCountry
	 * @param clientName    Busienss Flow ID:RQ-843
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "BusinessFlow" })
	public void updateCardCostCenter(@Optional("AU") String clientCountry, @Optional("BP") String clientName) {
		test = extent.createTest(clientName + ":" + clientCountry + "RQ-843 TC-1737 TC03_CardMgmt_Upd_Costcentre_existing card",
				"A card department (cost centre) is changed for existing customer for card");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		Common common = new Common(driver, test);
		CardMaintenancePage cardMaintenancePage = new CardMaintenancePage(driver, test);
		//MaintainCustomerPage customerPage = new MaintainCustomerPage(driver, test);
		IFCSloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");

		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		// Serch Cutomer
		IFCSHomePage.gotoApplicationAndClickApplicationMenu();
		IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);
		String cardNo = common.getDriverCardNumberFromDB(clientName + clientCountry);
		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		common.chooseCustomerNoAndSearch(common.getCustomerNoForCardNumber(cardNo));
		cardMaintenancePage.chooseCardAndUpdateCostCenterDropdown(cardNo);

		IFCSHomePage.exitIFCS();
	}
	
	/**
	 * Added by Nithya
	 * 
	 * @param clientCountry
	 * @param clientName    Busienss Flow ID:RQ-846
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "BusinessFlow" })
	public void changeCardStatusAsLost(@Optional("AU") String clientCountry, @Optional("BP") String clientName) {
		test = extent.createTest(clientName + ":" + clientCountry + "RQ-846 TC-1355 TC01_CardMgmt_Status change_Active to Lost/Stolen",
				"Change card status to Lost");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		Common common = new Common(driver, test);
		ChangeCardStatus changeStatusPage = new ChangeCardStatus(driver, test);
		//MaintainCustomerPage customerPage = new MaintainCustomerPage(driver, test);
		IFCSloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");

		IFCSHomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);
		String customerNumber = common.getActiveOrTemporaryBlockCustomerNoHavingCardsAndRowIndex(1, "Active");
		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		common.chooseCustomerNoAndSearch(customerNumber);
		String cardNoForReplaceIdemia = common.getActiveCardNumberFromDBWFE(clientName, clientCountry);
		common.chooseCardNo(cardNoForReplaceIdemia);
		changeStatusPage.changeCardStatusAndClickYesAndValidate("Card Lost");

		IFCSHomePage.exitIFCS();
	}

	/**
	 * Added by Raxsana Babu
	 * 
	 * @param clientCountry
	 * @param clientName    RQ-853
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "Regression", "BusinessFlow" })
	public void validateSearchCards(@Optional("BE") String clientCountry, @Optional("WFE") String clientName) {
		test = extent.createTest(clientName + ":" + clientCountry + " TC-1709 TC01_CardMgmt_Search Cards ",
				"RQ-853 Able to Search Cards");
		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		SearchPage searchInputs = new SearchPage(driver, test);
		Common common = new Common(driver, test);
		IFCSloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, " ");

		IFCSHomePage.gotoSearchAndClickCards();

		// common.performBlankSearchAndValidate();
		searchInputs.selectClientInDropDownAndSearch("Client", clientName + "_" + clientCountry);
		common.searchCardnumberAndValidate("Full", "Filter By");
		// Enter a Card Number and use the Wildcard (*) symbol and select the Search
		// button
		common.searchCardnumberAndValidate("Partial", "Filter By");

		IFCSHomePage.exitIFCS();
	}

}
