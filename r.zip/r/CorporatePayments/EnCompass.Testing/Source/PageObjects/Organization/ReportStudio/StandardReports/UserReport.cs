﻿using Common;
using Common.Utility;
using NFluent;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Support.UI;
using System.Collections.Generic;
using System.Linq;

namespace EnCompass.Testing.Source.PageObjects.Organization.ReportStudio.StandardReports
{
    [PageModel(@"/reportStudio/standardReports/UserReport.aspx")]
    public class UserReport : EnCompassOrgPageModel
    {
        public UserReport(GlobalSettings settings) : base(settings) { ScheduleReport = new ScheduleReport(Driver, settings); }
        public override string RelativeUrl => @"/reportStudio/standardReports/UserReport.aspx";

		public override string PageIdentifierXPath_Override => @"//li[contains(@class, 'breadcrumb-item active')][text() = 'Users']";

        public ScheduleReport ScheduleReport { get; set; }


        #region XPath page Elements
        private const string _userNameTextFieldXPath = @".//input[contains(@id,'UserNameText')]";
        private const string _formatXPath = @".//select[contains(@id, 'StdReport_FormatList')]";
        private const string _runButtonPath = @".//input[contains(@id,'RunButton')]";
        #endregion

        #region Page Elements
        private IWebElement _userNameTextField
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_userNameTextFieldXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_userNameTextField element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _format
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_formatXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_format element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _runButton
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_runButtonPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_runButton element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        #endregion

		public string UserName
		{
			set
			{
				_userNameTextField.SendKeys(value);
				Settings.EnCompassExtentTest.Info("Username set for reprot as :" + value);
			}
			get
			{
				return _userNameTextField.GetAttribute("value");
			}
		}

        /// <summary>
        /// Select the format from the DDL doing a partial string match. The actual options matched against are : 
        ///		Adobe PDF (.PDF)
        ///		Excel 97-2003(xls)
        ///		Comma-Separated Values(.CSV)
        /// </summary>
        public string Format
        {
            set
            {
                _format.SetListboxByText(value, SelectTextOptions.Contains);
                Settings.EnCompassExtentTest.Info("Selected User Report download format as :" + value);
            }
            get
            {
                SelectElement _elem = new SelectElement(_format);
                return _elem.SelectedOption.Text;
            }
        }

        public void RunReport()
        {
            _runButton.JSClickWithFocus(Driver);
			Settings.EnCompassExtentTest.Info("Clicked on Run Report button.");

			// Mobile specific change
			if (GlobalSettings.DeviceType.Equals(GlobalSettings.Device.MOBILE.ToString()))
				Driver.AllowPopUpsOnMobileBrowsersOnActualDevices(Settings.EnCompassExtentTest);
		}        
    }
    
}
