package com.framework.pages.SHELL;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.ExtentTest;
import com.framework.basepage.BasePage;
import com.framework.repo.Locator;
import com.framework.util.PropUtils;

public class SHELLAdminPages extends BasePage {
	
	@FindBy(id = Locator.SEARCH_BUTTON)
	public WebElement searchButton;

	@FindBy(xpath = Locator.PAGE_HEADER)
	public WebElement pageTitle;
	
	@FindBy(id = Locator.EMAIL_FIELD)
	public WebElement emailField;

	@FindBy(xpath = Locator.USER_ID)
	public WebElement userIdTB;
	
	@FindBy(id = Locator.CARD_CONFIGURATION_PROFILE_NAME_FIELD)
	public WebElement displayNameTB;
	
	@FindBy(id = Locator.PHONE_FIELD)
	public WebElement phoneTB;
	
	@FindBy(id = Locator.MOBILE_FIELD)
	public WebElement mobileTB;
	
	@FindBy(xpath = Locator.ROLE)
	public WebElement roleSB;
	
	@FindBy(id=Locator.SAVE_BUTTON)
	public WebElement saveButton; 
	

	@FindBy(id = Locator.USERS_LIST_TABLE)
	public WebElement usersListTable;

	@FindBy(xpath = Locator.LIST_OF_DISPLAY_NAME)
	public List<WebElement> listOfDisplayUsers;

	@FindBy(id = Locator.EDIT_PROFILE)
	public WebElement editProfile;

	@FindBy(id = Locator.LANGUAGE_FORM)
	public WebElement languageDropdown;

	@FindBy(xpath = Locator.DISPLAY_LANGUAGE)
	public WebElement displayLanguage;

	@FindBy(xpath = Locator.CHANGE_ROLE)
	public WebElement changeRole;
	
	
	@FindBy(id = Locator.CHANGE_ROLE_SAVE_BUTTON)
	public WebElement changeRoleSaveBtn;
	
	@FindBy(xpath = Locator.BACK_TO_CARD_LIST)
	public WebElement backToCardList;
	
	@FindBy(xpath=Locator.ACCOUNTS_PROFILE_USER)
	public WebElement acctsProfile;
	
	@FindBy(id=Locator.MULTIFIELD_SEARCH)
	public WebElement multipleSearchField;
	
	@FindBy(id=Locator.ACCOUNT_DROPDOWN)
	public WebElement accountDropdownField;
	
	@FindBy(id=Locator.FIRST_USER_FROM_LIST)
	public WebElement selectFirstUserFromList;
	
	@FindBy(id=Locator.EXPORT_BUTTON)
	public WebElement clickExportButton;
	
	@FindBy(id=Locator.SAVE_BT)
	public WebElement clickSaveButton;
	
	@FindBy(id=Locator.SELECTALL_CB)
	public WebElement selectAllC;
	
	@FindBy(xpath=Locator.EDIT_PROFILE_SMENU)
	public WebElement editProfileSubMenu;
	
	@FindBy(id=Locator.CONFIRMATIONMESSAGE)
	public WebElement successMsg;
	
	@FindBy(xpath=Locator.ERR_MSG)
	public WebElement errorMsg;
	
	
	private String selectedLanguage = "";

	private String allUserId = "";
	
	private String roleCol = "";

	public SHELLAdminPages(WebDriver driver, ExtentTest test) {

		super(driver, test);
		PageFactory.initElements(driver, this);
	}
	
	public void clickSearchButtonAndValidate(String userId) {
		
		isDisplayedThenActionClick(searchButton, "Search Button click");
		
		sleep(5);
		
		boolean error = waitForTextToAppear("A Processing Error has Occured", 30);
		
		if(!error)
		{
			String userName = PropUtils.getPropValue(configProp, userId);
		
			System.out.println("userName -----"+userName);		
		
			checkTextInPageAndValidate(userName, 30);
		}
		
		else
		{
			//System.out.println("boolean ------ "+error);
			logFail("A Processing Error has Occured  -- WBPT-21155");
		}

	}
	
	public void validateUserListPage() {
		System.out.println("inside user list validate");
		sleep(5);
		checkTextInPageAndValidate("USER LIST", 20);

	}


	public void validateNewUserPage() {
		driver.findElement(By.xpath("//span[@class='highlighter']"));
		// waitForTextToAppear("New User", 20);
		checkTextInPageAndValidate("New User", 20);
	}

	public void validateAllAPAUsers(String userId) {
		checkTextInPageAndValidate("List of Users Found", 20);
		driver.findElement(By.xpath("//table[@id='lform:tableList']")).isDisplayed();
		System.out.println("inside apa metho");
		setCellDataFromTable(usersListTable, 5, false);
		System.out.println("inside apa methos 1");
		int s = getRowSize(usersListTable);
		System.out.println("inside apa methos 2--" + s);
		for (int j = 0; j < s; j++) {
			String getUserId = PropUtils.getPropValue(configProp, "SHLAPA_UN_Customer_Admin_AT");
			System.out.println("inside apa for methos 2--" + s);
			allUserId = getCellDataFromTable(j, 3, false);
			if (getUserId.equals(allUserId)) {
				System.out.println("inside apa IF methos 2--" + s);
				logPass("User ID was APA customer user");
			} else {
				System.out.println("inside apa Else methos 2--" + s);
				logInfo("User ID is not APA User");
			}
		}
	}
	
	public void clickCardTableMenuOption(WebElement option) {
		isDisplayedThenActionClick(option, "Card Table Menu");
		sleep(5);
		// verifyHeaderTitle(titleTOCheck);
	}

	public boolean selectUserFromUserList(String country, String role) {
		boolean isUserSelected = false;
		scrollDownPage();
			setCellDataFromTable(usersListTable, 5, false);
			System.out.println("inside apa methos 1");
			List<WebElement> rowElements =  usersListTable.findElements(By.xpath("./tbody[contains(@id,'lform:tableList:tb')]/tr"));
//			int tableListSize = listOfDisplayUsers.size();
			System.out.println("inside apa methos 2--" + rowElements.size());
			for (int j = 0; j < rowElements.size(); j++) {
				System.out.println("inside apa for methos 2--");
				String getUserId = PropUtils.getPropValue(configProp, "SHLAPA_UN_Customer_"+role+"_"+country);
				allUserId = getCellDataFromTable(j+1, 2, false);
				System.out.println("allUserId =="+allUserId);
				System.out.println("userId =="+getUserId);
				roleCol = getCellDataFromTable(j+1, 4, false);
				System.out.println("roleCol =="+roleCol);
				System.out.println("role =="+role);
				if (/*getUserId.equals(allUserId)*/ role.equals(roleCol)) {
					System.out.println("inside apa IF methos 1-");
					clickDisplayName(j+1);
					sleep(3);
					if(!waitForTextToAppear("Change Role", 20)) {
						clickDisplayName(j+2);
						logPass("Display name was selected");
					} else {
						logInfo("User don't have access to change role");
					}
					clickCardTableMenuOption(changeRole);
					isUserSelected = true;
					logPass("User ID was APA customer user");
					break;
				} else {
					System.out.println("inside apa Else methos 2--");
					logInfo("User ID is not APA User");
				}
			}
			if(!isUserSelected) {
				logInfo("No User available to change the role to "+role);
			}
			return isUserSelected;
	    
	}
	
	public void selectUserFromUserListAndEditProfile(String country, String role) {
		scrollDownPage();
			setCellDataFromTable(usersListTable, 5, false);
			System.out.println("inside apa methos 1");
			List<WebElement> rowElements =  usersListTable.findElements(By.xpath("./tbody[contains(@id,'lform:tableList:tb')]/tr"));
			System.out.println("inside apa methos 2--" + rowElements.size());
			for (int j = 0; j < rowElements.size(); j++) {
				System.out.println("inside apa for methos 2--");
				String getUserId = PropUtils.getPropValue(configProp, "SHLAPA_UN_Customer_"+role+"_"+country);
				allUserId = getCellDataFromTable(j+1, 2, false);
				System.out.println("allUserId =="+allUserId);
				System.out.println("userId =="+getUserId);
				roleCol = getCellDataFromTable(j+1, 4, false);
				System.out.println("roleCol =="+roleCol);
				System.out.println("role =="+role);
				if (/*getUserId.equals(allUserId)*/ role.equals(roleCol)) {
					System.out.println("inside apa IF methos 1-");
					clickDisplayName(j+1);
					sleep(3);
					clickCardTableMenuOption(editProfileSubMenu);
					verifyText(pageTitle, "EDIT PROFILE");
					logPass("User ID was APA customer user");
					break;
				} else {
					System.out.println("inside apa Else methos 2--");
					logInfo("User ID is not APA User");
				}
			}
	    
	}

	public void clickDisplayName(int index) {
		try {
			actionClick(listOfDisplayUsers.get(index - 1));
			// System.out.println("Get Text for element"+ expAccount.getr);
			sleep(5);

		} catch (Exception e) {
			logInfo(e.getMessage());

		}

	}

	
	public void verifyNewUserPageIsLoaded() {
		
		checkTextInPageAndValidate("New User", 20);
		
		checkTextInPageAndValidate("Email Address", 20);
		
		checkTextInPageAndValidate("User ID", 20);
		
		checkTextInPageAndValidate("Display Name", 20);
		
		checkTextInPageAndValidate("Role", 20);
		
		checkTextInPageAndValidate("Phone", 20);
		
		checkTextInPageAndValidate("Mobile", 20);
		
		checkTextInPageAndValidate("Language", 20);
		
	}

	public void validateChangeUserRolePage() {
//		isDisplayedThenClick(changeRole, "Click Change Role");
		sleep(3);
		verifyText(pageTitle, "CHANGE USER ROLE");
//		checkTextInPageAndValidate("Change User Role", 20);
		
	}

	public void createNewUser(String clientName, String role) {
		// TODO Auto-generated method stub

		String email = fakerAPI().internet().emailAddress();

		String userId = "customer_" + clientName + "_" + fakerAPI().random().nextInt(1000);

		System.out.println("---- User ID ------" + userId);

		String displayName = fakerAPI().name().fullName();

		String phone = fakerAPI().phoneNumber().cellPhone();

		String mobile = fakerAPI().phoneNumber().cellPhone();

		isDisplayedThenEnterText(emailField, "Email Address for New User", email);
		
		isDisplayedThenEnterText(userIdTB, "User ID for New User", userId);
		
		isDisplayedThenEnterText(displayNameTB, "Display Name for New User", displayName);
		
		isDisplayedThenEnterText(phoneTB, "Phone for the New User",phone);
		
		isDisplayedThenEnterText(mobileTB, "Mobile for the New User",mobile);
		
		selectDropDownByVisibleText(roleSB, role);
		
		sleep(5);
		
		checkanyAccountIsSelected();
		
		isDisplayedThenClick(saveButton, "Save Button for New User");
		
		sleep(8);
		
		checkTextInPageAndValidate("Record saved OK", 30);
		
	}

	/*
	 * Make sure Any of the account is selected
	 */
	
	private void checkanyAccountIsSelected() {
		
		//isDisplayedThenClickRadioBTN(selectAllC, "Select All check box");
		selectIfEnabledOrNotSelect(selectAllC, "Select All check box");		
		sleep(10);
		
	}

	public void validateUpdatedLanguage(String actualLanguage) {
		String expectedLang = displayLanguage.getText();
		if (actualLanguage.equals(expectedLang)) {
			logPass("Language is validated successfully");
		} else {
			logInfo("Language is not validated");
		}

	}

	public String validateChangeLanguage() {
		isDisplayedThenActionClick(languageDropdown, "Select the language dropdown");
		int randomIndex = getRandomNumber(1, 10);
		selectDropDownByIndex(languageDropdown, randomIndex);
		selectedLanguage = languageDropdown.getText();
		return selectedLanguage;
	}

	public void verifyUserId(String expectedUserId) {

		String actualUserId = driver.findElement(By.xpath("//*[@id='userdrop']/a[@class='name']")).getText();
		//userIdTB.getText();
		if (actualUserId.equals(expectedUserId)) {
			logPass("User ID is Verified successfully");
		} else {
			logInfo("User ID is Mismatched");
		}
	}
	
	public void selectRoleForCustomer(String actRole) {
		selectDropDownByVisibleText(roleSB, actRole);
		sleep(3);
		isDisplayedThenActionClick(changeRoleSaveBtn, "Click Save Button");
		sleep(3);
		if(waitToCheckElementIsDisplayed(By.xpath("//div[contains(@id,'errorMsg-')]"), 20)) {
			logInfo("Display name should be mandate to update");
		} else {
			isDisplayed(successMsg, "Success Msg Displayed");
			logPass("Success message was displayed");
		}
		
	}
	
	public void clickBackToUserList() {
		isDisplayedThenActionClick(backToCardList, "Clicked Role Dropdown Field");
		//isDisplayedThenActionClick(backToCardList, "Clicked Role Dropdown Field");
		sleep(15); 
		verifyText(pageTitle, "USER LIST");		
	}
	
	public void validateCustomerRoleUpdated(String country, String actRole) {
		
		scrollDownPage();
		setCellDataFromTable(usersListTable, 5, false);
		System.out.println("inside apa methos 1");
		List<WebElement> rowElements =  usersListTable.findElements(By.xpath("./tbody[contains(@id,'lform:tableList:tb')]/tr"));
		System.out.println("inside apa methos 2--" + rowElements.size());
		for (int j = 0; j < rowElements.size(); j++) {
			System.out.println("inside apa for methos 2--"+country);
			String getUserId = PropUtils.getPropValue(configProp, country);
			allUserId = getCellDataFromTable(j+1, 2, false);
			System.out.println("allUserId =="+allUserId);
			System.out.println("userId =="+getUserId);
			roleCol = getCellDataFromTable(j+1, 4, false);
			System.out.println("roleCol =="+roleCol);
			System.out.println("role =="+actRole);
				if (getUserId.equals(allUserId) && actRole.equals(roleCol) ) {
					System.out.println("inside IF21");
					logPass("Customer Role has changed successfully");
				} else {
					System.out.println("inside apa Else methos 2--" );
					logInfo("Customer Role has not changed");
				}
			}
		}

	 
	/*
	 * This method select the User from User list and Navigate to the user profile
	 * 
	 */

	public void selectUserAndGotoUserProfile() {
		// TODO Auto-generated method stub
		
		isDisplayed(usersListTable, "User List Table");	 
		
		selectFirstColumnAndChooseMenu(usersListTable, acctsProfile, "ACCOUNTS PROFILE", true);
		
	}
	
	public void selectUserAndGotoEditProfile() {
		// TODO Auto-generated method stub
		
		isDisplayed(usersListTable, "User List Table");	 
		
		selectFirstColumnAndChooseMenu(usersListTable, editProfileSubMenu, "EDIT PROFILE", true);
		
	}

	public void verifyOtherCardCustomersNotPresent(String prepaidUserId) {
		// TODO Auto-generated method stub
		
		sleep(3);
		
		String prepaidUserName = PropUtils.getPropValue(configProp, prepaidUserId);
		
		checkTextNotInPageAndValidate(prepaidUserName, 30);
		
	}
	
	public void searchWithUserIDRoleAndAccountNumber(String userId, String roleUser) {
		
		String userName = PropUtils.getPropValue(configProp, userId);
		
		isDisplayedThenEnterText(multipleSearchField, "Enter the User ID", userName);
		sleep(3);
		selectDropDownByVisibleText(roleSB, roleUser);
		sleep(3);
		selectDropDownByIndex(accountDropdownField, 1);
//		selectInputFromDropdown(accountDropdownField, 1);
		
	}
	
	
	public void clickExportButton() {
		
		isDisplayedThenActionClick(clickExportButton, "Click Export Button");
		
	}
	
	
	public void updatePhoneNoAndSaveAndValidate() {

		String phoneNo = fakerAPI().phoneNumber().phoneNumber();

		String mobileNo = fakerAPI().phoneNumber().cellPhone();
		sleep(3);
		isDisplayedThenEnterText(phoneTB, "Enter the Phone Number", phoneNo);
		
		isDisplayedThenEnterText(mobileTB, "Enter the Mobile Number", mobileNo);
		
		isDisplayedThenActionClick(clickSaveButton, "Click Save Button");
		sleep(3);
		
	}
	
	public void FillFieldsWithExistingEmailAndValidate(String clientName, String role) {
		
		// TODO Auto-generated method stub

		String userId = "customer_" + clientName + "_" + fakerAPI().random().nextInt(1000);

		String displayName = fakerAPI().name().fullName();

		String phone = fakerAPI().phoneNumber().phoneNumber();

		String mobile = fakerAPI().phoneNumber().cellPhone();

		sleep(3);
		
		isDisplayedThenEnterText(emailField, "Email Address", fakerAPI().internet().emailAddress());
		
		isDisplayedThenEnterText(userIdTB, "User ID", userId);
		
		isDisplayedThenEnterText(displayNameTB, "Display Name for New User", displayName);
		
		isDisplayedThenEnterText(phoneTB, "Phone for the New User",phone);
		
		isDisplayedThenEnterText(mobileTB, "Mobile for the New User",mobile);
		
		selectDropDownByVisibleText(roleSB, role);
		
		sleep(15);
		
		checkanyAccountIsSelected(); 
		
		isDisplayedThenClick(saveButton, "Save Button for New User");
		
		sleep(7);
		
		checkTextInPageAndValidate("Record saved OK", 30); // Need to Check
		
	}
	
}
