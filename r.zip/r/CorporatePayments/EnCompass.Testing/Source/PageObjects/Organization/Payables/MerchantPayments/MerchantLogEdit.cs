﻿using Common;
using Common.Utility;
using EnCompass.Testing.Source.PageObjects.Controls;
using NFluent;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace EnCompass.Testing.Source.PageObjects.Organization.Payables.MerchantPayments
{
	public partial class MerchantLogEdit
	{
        #region XPath page Elements
        private const string _merchantSelectorXPath = "//select[contains(@id,'MerchantDropDown')]";
		private const string _merchantTxtFieldXPath = "//input[contains(@id,'MerchantTextBox')]";
        private const string _effectiveFromXPath = "//input[contains(@id,'EffectiveDateStartText')]";
        private const string _effectiveToXPath = "//input[contains(@id,'EffectiveDateStopText')]";
        private const string CARDINFORMATION_BTN = "//input[contains(@id,'btnCardInfo')]";
        private static string _merchantClearBtn = ".//button[contains(@id,'ClearMerchant')]";
        private const string _merchantNoteXPath = "//input[contains(@id,'MerchantNote')]";
        private const string _authCodeXPath = ".//input[contains(@id,'Udf0')]";
        private const string _transIdXPath = ".//input[contains(@id,'Udf1')]";
        private const string _numMlogsForAuthXPath = ".//input[contains(@id,'Udf2')]";
        private const string _invoiceNumberXPath = ".//input[contains(@id,'Udf3')]";
        private const string _currencyXPath = "//select[contains(@id,'CurrencyDropdown')]";
        private const string _deliveryMethodXPath = "//select[contains(@id,'DeliveryMethodDropDown')]";
        private const string _deliveryByFaxPhoneXPath = "//input[contains(@id,'DeliveryAddressFax_txtPhone')]";
        private const string _amountXPath = "//input[contains(@id,'AmountText')]";
        private const string _poolNameXPath = "//select[contains(@id,'PoolDropdown')]";
        private const string _invoiceNumberReadOnlyXPath = "//span[contains(@id,'_Label2')]";
        private const string _invoiceDateReadOnlyXPath = "//span[contains(@id,'_Label1')]";
        private const string _invoiceAmountReadOnlyXPath = "//table[contains(@id, 'InvoiceGridView')]/tbody/tr/td[3]";
        private const string _addInvoiceButtonXPath = "//*[contains(@id,'AddInvoiceButton')]";
        private const string _submitActionXPath = "//input[contains(@id,'SaveButton')]";
        private const string _cardNumberXPath = "//span[contains(@id,'CardNumberPara')]";
        private const string _merchantPINXPath = ".//span[contains(@id,'_PinPara')]";
        private const string _expirationDateXPath = "//span[contains(@id,'ExpirationPara')]";
        private const string _cscXPath = "//span[contains(@id,'Cvc2Para')]";
        private const string _authAccumResetXPath = "//select[contains(@id,'DropdownListAuthAccumReset')]";
        private const string _noOfAllowedAuthsXPath = "//input[contains(@id,'TextBoxNumAllowedAuths')]";
        private const string _customerCodeXPath = "//input[contains(@id,'CustomerCodeTextBox')]";
        private const string _paymentMethodXPath = "//select[contains(@id,'PaymentMethodDropDown')]";
        private const string _addNewMLogXPath = "//input[contains(@id,'NewButton')]";
        private const string _merchantTextBoxXPath = "//input[contains(@name,'MerchantTextBox')]";
        private const string _bankAccountNumberXPath = "//input[contains(@id,'BankAccountNumberTextbox')]";
        private const string _routingNumberXPath = "//input[contains(@id,'BankRoutingNumberTextbox')]";
        private const string _merchantNameXPath = "//input[contains(@id,'MerchantNameTextbox')]";
        private const string _addressLine1XPath = "//input[contains(@id,'txtAddressLine1')]";
        private const string _cityXPath = "//input[contains(@id,'txtCity')]";
        private const string _zipCodeXPath = "//input[contains(@id,'txtZip')]";
        private const string _firstAddendumInputXPath = "(//div[contains(@id, 'apAddendum')]//input)[1]";
        private const string _achCreditFormatXPath = ".//select[contains(@id,'AchCreditFormatDropDown')]";
        private const string _invoiceNumbersXPath = "//input[contains(@id,'InvoiceNumber')]";
        private const string _invoiceAmountsXPath = "//input[contains(@id,'_AmountTextBox')]";
        #endregion

        #region Page Elements
        private IWebElement _merchantSelector
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_merchantSelectorXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_merchantSelector element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _merchantTxtField
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_merchantTxtFieldXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_merchantTxtField element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _merchantNote
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_merchantNoteXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_merchantNote element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _authCode
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_authCodeXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_authCode element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _transId
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_transIdXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_transId element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _numMlogsForAuth
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_numMlogsForAuthXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_numMlogsForAuth element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _invoiceNumber
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_invoiceNumberXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_InvoiceNumber element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _currency
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_currencyXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_currency element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _deliveryMethod
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_deliveryMethodXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_deliveryMethod element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _deliveryByFaxPhone
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_deliveryByFaxPhoneXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_deliveryByFaxPhone element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _amount
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_amountXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_amount element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _poolName
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_poolNameXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_poolName element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _invoiceNumberReadOnly
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_invoiceNumberReadOnlyXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_invoiceNumberReadOnly element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _invoiceDateReadOnly
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_invoiceDateReadOnlyXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_invoiceDateReadOnly element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _invoiceAmountReadOnly
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_invoiceAmountReadOnlyXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_invoiceAmountReadOnly element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _addInvoiceButton
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_addInvoiceButtonXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_addInvoiceButton element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _submitButton
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_submitActionXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_submitAction element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _cardNumber
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_cardNumberXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_cardNumber element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _merchantPIN
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_merchantPINXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_merchantPIN element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _expirationDate
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_expirationDateXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_expirationDate element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _csc
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_cscXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_csc element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _effectiveFrom
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_effectiveFromXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_effectiveFrom element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _effectiveTo
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_effectiveToXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_effectiveTo element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _authAccumReset
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_authAccumResetXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_authAccumReset element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _noOfAllowedAuths
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_noOfAllowedAuthsXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_noOfAllowedAuths element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _customerCode
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_customerCodeXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_customerCode element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _paymentMethod
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_paymentMethodXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_paymentMethod element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _addNewMLog
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_addNewMLogXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_addNewMLog element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _bankAccountNumber
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_bankAccountNumberXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_bankAccountNumber element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _routingNumber
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_routingNumberXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_routingNumber element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _merchantName
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_merchantNameXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_merchantName element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _addressLine1
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_addressLine1XPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_addressLine1 element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _city
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_cityXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_city element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _zipCode
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_zipCodeXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_zipCode element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _firstAddendumInput
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_firstAddendumInputXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_firstAddendumInput element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _achCreditFormat
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_achCreditFormatXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_achCreditFormat element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IList<IWebElement> _invoiceNumbers
        {
            get
            {
                bool found = Driver.TryWaitForElementsToBeVisible(By.XPath(_invoiceNumbersXPath), out IList<IWebElement> elements);
                Settings.EnCompassExtentTest.Info($"_invoiceNumbers element exist is {found}");
                Check.That(found).IsTrue();
                return elements;
            }
        }
        private IList<IWebElement> _invoiceAmounts
        {
            get
            {
                bool found = Driver.TryWaitForElementsToBeVisible(By.XPath(_invoiceAmountsXPath), out IList<IWebElement> elements);
                Settings.EnCompassExtentTest.Info($"_invoiceAmounts element exist is {found}");
                Check.That(found).IsTrue();
                return elements;
            }
        }
        #endregion

        #region Expand Elements

        private const string AC_MAIN = "acMain";
        private const string AP_ADDENDUM = "_apAddendum";
        #endregion

        // Firefox specific change
        public override string PageIdentifierXPath_Override => @"//li[@class='breadcrumb-item active'][normalize-space(text())='Edit Merchant' or normalize-space(text())='Create Merchant Log' or normalize-space(text())='Edit Merchant Log']";

		#region Auth Accumulator Fields
		public bool IsAuthAccumResetPresent
		{
			get
			{
				if (Driver.TryFindElement(By.XPath(@"//select[contains(@id,'DropdownListAuthAccumReset')]"), out IWebElement element))
				{
					return element.Displayed;
				}
				else
				{
					return false;
				}
			}
		}

		public string BankAccountNumber
		{
			get
			{
				return _bankAccountNumber.GetAttribute("value");
			}
			set
			{
				_bankAccountNumber.Clear(); _bankAccountNumber.SendKeys(value);
			}
		}

		public string RoutingNumber
		{
			get
			{
				return _routingNumber.GetAttribute("value");
			}
			set
			{
				_routingNumber.Clear();_routingNumber.SendKeys(value);
			}
		}

        public string ACHCreditFormat
        {
            get
            {
                return new SelectElement(_achCreditFormat).SelectedOption.Text;
            }
            set
            {
                new SelectElement(_achCreditFormat).SelectByText(value);
                Settings.EnCompassExtentTest.Info("ACH Credt Format:" + value);
            }
        }

        public string MerchantName
		{
			get
			{
				return _merchantName.GetAttribute("value");
			}
			set
			{
				_merchantName.Clear(); _merchantName.SendKeys(value);
			}
		}

		public string AddressLine1
		{
			get
			{
				return _addressLine1.GetAttribute("value");
			}
			set
			{
				_addressLine1.Clear(); _addressLine1.SendKeys(value);
			}
		}

		public string City
		{
			get
			{
				return _city.GetAttribute("value");
			}
			set
			{
				_city.Clear(); _city.SendKeys(value);
			}
		}

		public string ZipCode
		{
			get
			{
				return _zipCode.GetAttribute("value");
			}
			set
			{
				_zipCode.Clear(); _zipCode.SendKeys(value);
			}
		}

		public string AuthAccumuReset
		{
			get { return new SelectElement(_authAccumReset).SelectedOption.Text.Trim(); }
			set { _authAccumReset.SetListboxByText(value, SelectTextOptions.StartsWith); }
		}

		public List<IWebElement> AuthAccumResetOptions()
		{
			return new SelectElement(_authAccumReset).Options.ToList();
		}

		public bool IsNumberOfAllowedAuthsPresent
		{
			get
			{
				if (Driver.TryFindElement(By.XPath(@"//input[contains(@id,'TextBoxNumAllowedAuths')]"), out IWebElement element))
				{
					return element.Displayed;
				}
				else
				{
					return false;
				}
			}
		}

		public string NumberOfAllowedAuths
		{
			get
			{
				if (_noOfAllowedAuths.GetAttribute("value") == "")
				{
					return _noOfAllowedAuths.GetAttribute("placeholder").Trim();
				}
				else
				{
					return _noOfAllowedAuths.GetAttribute("value").Trim();
				}
			}
			set { _noOfAllowedAuths.Clear(); _noOfAllowedAuths.SendKeys(value); }
		}

		#endregion

		public string Currency
		{
			get { return new SelectElement(_currency).SelectedOption.Text; }
			set
			{
				var selElement = new SelectElement(_currency);
				var selOption = selElement.Options.FirstOrDefault(o => o.Text.StartsWith(value));

				if (selOption != null)
				{
					selElement.SelectByText(selOption.Text);
                    Settings.EnCompassExtentTest.Info($"Currency DDL set to {value}.");
                }

                else
				{
					throw new Exception($"Select Option not present in the list.");
				}
			}
		}

		public string CustomerCode
		{
			get { return _customerCode.GetAttribute("value"); }
			set { _customerCode.Clear(); _customerCode.SendKeys(value); }
		}

		public string AuthCode
		{
			get { return _authCode.GetAttribute("value"); }
			set { _authCode.Clear(); _authCode.SendKeys(value); }
		}

        public bool IsCardInfoBtnPresent
        {
            get
            {
                if (Driver.TryFindElement(By.XPath(CARDINFORMATION_BTN), out IWebElement element))
                {
                    return element.Displayed;
                }
                else
                    return false;
            }
        }

        public string TransactionId
		{
			get { return _transId.GetAttribute("value"); }
			set { _transId.Clear(); _transId.SendKeys(value); }
		}

		public string NumMlogsForAuth
		{
			get { return _numMlogsForAuth.GetAttribute("value"); }
			set { _numMlogsForAuth.Clear(); _numMlogsForAuth.SendKeys(value); }
		}

		public string InvoiceNumber
		{
			get { return _invoiceNumber.GetAttribute("value"); }
			set { _invoiceNumber.Clear(); _invoiceNumber.SendKeys(value); }
		}

		public string PaymentMethod
		{
			get { return new SelectElement(_paymentMethod).SelectedOption.Text.Trim(); }
			set { _paymentMethod.SetListboxByText(value, SelectTextOptions.StartsWith); }
		}

		private static string _merchantNameListBoxXpath = "//ul[@role='listbox']";
        private static string _merchantNameListBoxItemXpath = _merchantNameListBoxXpath + "//a";
      
        /// <summary>
        /// Merchant Text Box 
        /// </summary>
        public string MerchantTextBox
		{
			get
			{
				if (_merchantTxtField.GetAttribute("placeholder").StartsWith("Merchant results will filter"))
				{
					return _merchantTxtField.GetAttribute("value");
				}
				else
				{
					return _merchantTxtField.GetAttribute("placeholder").Trim();
				}
			}
			set
			{
				if (value != "*")
				{
                    try
                    {
                        Driver.TryWaitForElement(By.XPath(_merchantClearBtn), out IWebElement _merchantClearButton, TimeSpan.FromSeconds(5));
                        _merchantClearButton.JSClickWithFocus(Driver);
                        Settings.EnCompassExtentTest.Info("Clicked on _merchantClearButton");

                        // JSSendKeys sometimes does not work for Chrome so we created this validation to handle separately using the normal sendkeys for it
                        if (GlobalSettings.Browser.Equals(GlobalSettings.Browsers.CHROME.ToString()))
                        {
                            _merchantTxtField.SendKeys(value);
                            Settings.EnCompassExtentTest.Info("Entered merchant name");
                            bool attrChanged = Driver.WaitForElementAttributeToChange(_merchantNameListBoxXpath, "style", "display: block");
                            if (attrChanged)
                            {
                                Settings.EnCompassExtentTest.Debug("Merchant DD Listbox attribute changes to display: true");
                                _merchantTxtField.SendKeys(Keys.Tab);
                                this.WaitForFormLoadingOverlay();
                                Settings.EnCompassExtentTest.Info("Select Merchant Name option in the listbox");
                            }
                            else
                                Settings.EnCompassExtentTest.Warning("Merchant DD Listbox attribute has Display set to : false");
                        }
                        else
                        {
                            _merchantTxtField.JSSendKeys(Driver, value, _merchantTxtFieldXPath);
                            Settings.EnCompassExtentTest.Info("Entered merchant name");
                            // We need to ensure that the "display" property is not 'none' 
                            bool attrChanged = Driver.WaitForElementAttributeToChange(_merchantNameListBoxXpath, "style", "display: block");
                            if (attrChanged)
                                Settings.EnCompassExtentTest.Debug("Merchant DD Listbox attribute changes to display: true");
                            else
                                Settings.EnCompassExtentTest.Warning("Merchant DD Listbox attribute has Display set to : false");
                            Driver.TryWaitForElement(By.XPath(_merchantNameListBoxXpath), out IWebElement _merchantListBox);
                            // Capturing  items count from the populated merchant dropdown and verifying the existence  given merchant name in the list
                            //  if merchant name exists  then it selects from the list
                            this.RefreshModel();
                            var Elements = _merchantListBox.FindElements(By.TagName("li")).Select(ele => ele.FindElement(By.TagName("a"))).Select(ele => ele).ToList();
                            Settings.EnCompassExtentTest.Info("No. of items in merchant listbox:" + Elements.Count);
                            IWebElement Element = Elements.Where(ele => ele.Text.Contains(value)).Select(ele => ele).First();
                            Element.Click();
                            Settings.EnCompassExtentTest.Info("Clicked on Merchant Name option in the listbox");
                            this.WaitForFormLoadingOverlay();
                            Settings.EnCompassExtentTest.Info("Entered new merchant name in textbox " + value);
                        }
                    }
                    catch (WebDriverException ex)
                    {
                        Settings.EnCompassExtentTest.Error("Attempt to create/edit Mlog: Unable to enter value in Merchant Text Box or searched Merchant Name not found. " +
                            " Original string : " + value);
                        throw ex;
                    }
                }
			}
		}

		public string DeliveryMethod
		{
			get { return new SelectElement(_deliveryMethod).SelectedOption.Text; }
			set
			{
				var selElement = new SelectElement(_deliveryMethod);
				var selOption = selElement.Options.FirstOrDefault(o => o.Text.StartsWith(value));

				if (selOption != null)
				{
					selElement.SelectByText(selOption.Text);
                    Settings.EnCompassExtentTest.Info($"Delivery Method DDL set to {value}.");
                }
                else
				{
					throw new Exception($"Select Option not present in the list.");
				}
			}
		}

		private string _remitTemplateDdlXpath = ".//select[contains(@id,'apHow_RemitDropDown')]";
		public string RemitTemplate
		{
			set
			{
				IWebElement _remitTemplateDDL = Driver.WaitForVisible(By.XPath(_remitTemplateDdlXpath));
				_remitTemplateDDL.SetListboxByText(value, SelectTextOptions.Contains);
				Settings.EnCompassExtentTest.Info("Remit Template =" + value);
			}
		}

		public bool CompareListWithDeliveryMethodOptions(IList<string> listToCompare)
		{
			var selElement = new SelectElement(_deliveryMethod);
			bool result = true;

			foreach (string item in listToCompare)
				if (selElement.Options.FirstOrDefault(o => o.Text.Contains(item)) == null)
					return false;

			Settings.EnCompassExtentTest.Info("Verify the existing elements in Delivery Method DDL");

			return result;
		}

		public string SetDeliveryMethodDetails
		{
			set
			{
				if (DeliveryMethod.Equals("fax", StringComparison.InvariantCultureIgnoreCase) && _deliveryByFaxPhone.Displayed)
				{
					_deliveryByFaxPhone.SendKeys(value);
				}
				else if (DeliveryMethod.Equals("email", StringComparison.InvariantCultureIgnoreCase))
				{
					IWebElement _deliveryByEmail = Driver.WaitForVisible(By.XPath("//input[contains(@id,'DeliveryAddressText')]"));
					if (_deliveryByEmail.Displayed)
					{
						_deliveryByEmail.SendKeys(Settings.CeatedOrgId + value);
						Settings.Scenario["DeliveryEmail"] = Settings.CeatedOrgId + value;
					}
				}

				Settings.EnCompassExtentTest.Info($"Delivery Method Details for {DeliveryMethod}: {value}");
			}
		}

		public string PoolName
		{
			get { return new SelectElement(_poolName).SelectedOption.Text; }
			set
            {
                // Mobile specific change   
                try
                {
                    _poolName.WaitUntilElementIsInteractable();
                    _poolName.SetListboxByText(value, SelectTextOptions.StartsWith, Driver, Settings, _poolNameXPath);
                }
                catch(Exception ex)
                {
                    Settings.EnCompassExtentTest.Warning("Pool name selection failed..Retrying again");
                    _poolName.SetListboxByText(value, SelectTextOptions.StartsWith, Driver, Settings, _poolNameXPath);
                }
			}
		}


		private string _localCurrCheckboxXpath = "//input[contains(@id,'chkUseLocalCurrency')]";
		public string EnableLocalCurrency
		{
			set
			{
				if(value.ToLowerInvariant().Equals("on"))
				{
					IWebElement _lclCurrCheckBox = Driver.WaitFor(By.XPath(_localCurrCheckboxXpath));
					// This type of CheckBox do not allow click on label
					_lclCurrCheckBox.SetCheckboxStateWithLabel(null,true);
				}
				else
				{
					IWebElement _lclCurrCheckBox = Driver.WaitFor(By.XPath(_localCurrCheckboxXpath));
					// This type of CheckBox do not allow click on label
					_lclCurrCheckBox.SetCheckboxStateWithLabel(null, false);
				}
			}
		}


		private string _localCurrDDLXpath = "//select[contains(@id,'_ddlLocalCurrency')]";
		public string SetLocalCurrencyValue
		{
			get
			{
				IWebElement _lclCurrDDL = Driver.WaitFor(By.XPath(_localCurrDDLXpath));
				return new SelectElement(_lclCurrDDL).SelectedOption.Text;

			}
			set
			{
				IWebElement _lclCurrDDL = Driver.WaitFor(By.XPath(_localCurrDDLXpath));
				var selElement = new SelectElement(_lclCurrDDL);
				var selOption = selElement.Options.FirstOrDefault(o => o.Text.StartsWith(value));

				if (selOption != null)
				{
					selElement.SelectByText(selOption.Text);
				}
				else
				{
					throw new Exception($"Select Option not present in the list.");
				}

				Settings.EnCompassExtentTest.Info("Local Currency = " + selOption.Text);
			}
		}

		private string _localCurrAmtXpath = "//input[contains(@id,'LocalAmountText_currencyTextBox')]";
		public string SetLocalCurrencyAmount
		{
			set
			{
				IWebElement _lclCurrAmt = Driver.WaitFor(By.XPath(_localCurrAmtXpath));
				_lclCurrAmt.Clear();
				_lclCurrAmt.SendKeys(value);
				Settings.EnCompassExtentTest.Info("Local Currency Amt = " + value);
			}
		}

        private string _mlogTotalAmtNoInvoiceXpath = "//input[contains(@id,'AmountText_currencyTextBox')]";
        public string TotalMlogAmount_WithoutInvoice
        {
            get
            {
                IWebElement _totalMlogAmt = Driver.WaitFor(By.XPath(_mlogTotalAmtNoInvoiceXpath));
                Settings.EnCompassExtentTest.Info("Total Merchant Log amount in Billing Currency = " + _totalMlogAmt.GetAttribute("value"));
                return _totalMlogAmt.GetAttribute("value");
            }
            set
            {
                IWebElement _totalMlogAmt = Driver.WaitFor(By.XPath(_mlogTotalAmtNoInvoiceXpath));
                _totalMlogAmt.SendKeys(value);
                Settings.EnCompassExtentTest.Info("Total Mlog Amount Set to : " + value);
            }
        }


        private string _mlogTotalAmtXpath = "//input[contains(@id,'merchantLogAmountTextBox_currencyTextBox')]";
		private string _mlogInvoiceAmtXpath = ".//input[contains(@id,'AmountTotalTextBox_currencyTextBox')]";
		public string TotalMlogCurrencyAmount
		{
			get
			{
                IWebElement _invoiceAmt = Driver.WaitFor(By.XPath(_mlogInvoiceAmtXpath));
                _invoiceAmt.Click();
                IWebElement _totalMlogAmt = Driver.WaitFor(By.XPath(_mlogTotalAmtXpath));				
				Settings.EnCompassExtentTest.Info("Total Merchant Log amount in Billing Currency = " + _totalMlogAmt.GetAttribute("value"));
				return _totalMlogAmt.GetAttribute("value");
			}
			set
			{
				IWebElement _totalMlogAmt = Driver.WaitFor(By.XPath(_mlogTotalAmtXpath));
				_totalMlogAmt.SendKeys(value);
				Settings.EnCompassExtentTest.Info("Total Mlog Amount Set to : " + value);
			}
		}

		private string _lclCurrAmtShortNameXpath = ".//span[contains(@id,'LocalAmountText_currencyTextBox_CurrencyShortName')]";
		public string LocalCurrencyAmountShortName
		{
			get
			{
				IWebElement _localCurrAmtShortName = Driver.WaitFor(By.XPath(_lclCurrAmtShortNameXpath));
				Settings.EnCompassExtentTest.Info("Local Currency Amt Short Name = " + _localCurrAmtShortName.GetAttribute("value"));
				return _localCurrAmtShortName.Text;
			}
		}

		private string _totalMlogAmtShortNameXpath = ".//span[contains(@id,'merchantLogAmountTextBox_currencyTextBox_CurrencyShortName')]";
		public string TotalMlogAmountShortName
		{
			get
			{
				IWebElement _totalMlogAmtShortName = Driver.WaitFor(By.XPath(_totalMlogAmtShortNameXpath));
				Settings.EnCompassExtentTest.Info("Total Mlog Amt Short Name = " + _totalMlogAmtShortName.GetAttribute("value"));
				return _totalMlogAmtShortName.Text;
			}
		}

		public string MerchantSelectionValue
		{
			get
			{
				if (_merchantTxtField.GetAttribute("placeholder").StartsWith("Merchant results will filter"))
				{
					return _merchantTxtField.GetAttribute("value");
				}
				else
				{
					return _merchantTxtField.GetAttribute("placeholder").Trim();
				}
			}
			set
			{
				if (value != "*")
				{
					_merchantTxtField.Clear();
                    _merchantTxtField.SendKeys(value);
					Thread.Sleep(2000); // This wait is needed to make sure the dynamic search of text input in the text field is shown for sure.
                    _merchantTxtField.SendKeys(Keys.ArrowDown);
                    _merchantTxtField.SendKeys(Keys.Enter);
					RefreshModel();
				}
			}
		}

		public string CardNumber => _cardNumber.Text.Trim().Replace("-", "").Trim();
		public string CardNumberLast4 => _cardNumber.Text.Trim().Substring(_cardNumber.Text.Trim().Length - 4);
		public string ExpirationDate => _expirationDate.Text.Trim();
		public string CSC => _csc.Text.Trim();
		public string PIN => _merchantPIN.Text.Trim();

		private string _mlogIdXpath = "//input[contains(@id,'MerchantLogId')]";
		public string MerchantLogId
        {
            get
            {
				IWebElement _merchantLogId = Driver.WaitForVisible(By.XPath(_mlogIdXpath));
				_merchantLogId.JsScrollToElement(Driver);
                return _merchantLogId.GetAttribute("value");
            }
        }

		public string MerchantNote
		{
			set { _merchantNote.ForceDocumentLoadOnSendKeys(value, Driver); }
			get { return _merchantNote.GetAttribute("value"); }
		}

		public string Amount
		{
			set
			{
				_amount.SendKeys(value);
				Settings.EnCompassExtentTest.Info("Amount = " + value);
            }
			get { return _amount.GetAttribute("value"); }
		}

		public string EffectiveFrom
		{
			set { _effectiveFrom.WaitUntilElementIsInteractable(); _effectiveFrom.Clear(); _effectiveFrom.ForceDocumentLoadOnSendKeys(value, Driver); }
			get { return _effectiveFrom.GetAttribute("value"); }
		}

		public string EffectiveTo
		{
			set { _effectiveTo.WaitUntilElementIsInteractable(); _effectiveTo.Clear(); _effectiveTo.ForceDocumentLoadOnSendKeys(value, Driver); }
			get { return _effectiveTo.GetAttribute("value"); }
		}

		/// <summary>
		/// Set the Invoice number as unique string for the index, starts from 0
		/// </summary>
		public void SetInvoiceNumber(int index = 0)
		{
			var uniqueString = $"zz{DateTime.Now.ToString("yyyyMMddhhmmss")}";
            Settings.Scenario["InvoiceNumber"] = uniqueString;
            SetInvoiceNumber(uniqueString, index);
		}

		/// <summary>
		///  Set the specified Invoice number for the index, starts from 0
		/// </summary>
		public void SetInvoiceNumber(string invoiceNumber, int index = 0)
		{
			// mobile specific change
			(_invoiceNumbers)[index].JSSendKeys(Settings.EnCompassWebDriver, invoiceNumber);
			Settings.EnCompassExtentTest.Info("Invoice Number set to :" + invoiceNumber);
		}

		/// <summary>
		/// Set specified Invoice Amount
		/// </summary>
		public void SetInvoiceAmount(string amount, int index = 0)
		{
            (_invoiceAmounts)[index].Clear();
            Settings.Scenario["MLogAmount"] = amount;

            if (GlobalSettings.Browser.Equals(GlobalSettings.Browsers.CHROME.ToString()) &&
                !GlobalSettings.DeviceType.Equals(GlobalSettings.Device.MOBILE.ToString()))
            {
                (_invoiceAmounts)[index].SendKeys(amount);
            }
            else
            {
                // mobile specific change
                (_invoiceAmounts)[index].JSSendKeys(Settings.EnCompassWebDriver, amount);
            }

			Settings.EnCompassExtentTest.Info("Invoice Amt set to :" + amount);
		}

		public string ReadOnlyInvoiceAmount
		{
			get { return _invoiceAmountReadOnly.Text.Substring(0, _invoiceAmountReadOnly.Text.IndexOf(" ")); } // Replace("USD", string.Empty).Trim(); }
		}

		public string ReadOnlyInvoiceNumber
		{
			get { return _invoiceNumberReadOnly.Text; }
		}

		public string ReadOnlyInvoiceDate
		{
			get { return _invoiceDateReadOnly.Text; }
		}

        public bool IsEffectiveDateStartPresent
        {
            get
            {
                if (Driver.TryFindElement(By.XPath(_effectiveFromXPath), out IWebElement element))
                {
                    return element.Displayed;
                }
                else
                    return false;
            }
        }

        public bool IsEffectiveDateStopPresent
        {
            get
            {
                if (Driver.TryFindElement(By.XPath(_effectiveToXPath), out IWebElement element))
                {
                    return element.Displayed;
                }
                else
                    return false;
            }
        }

        public void Submit()
		{
            // Mobile specific change 
            _submitButton.JSClickWithFocus(Driver, _submitActionXPath, Settings);
			Settings.EnCompassExtentTest.Info("Clicked on Submit button");
			AttachOnDemandScreenShot();
			this.WaitForLoad();
			Settings.EnCompassExtentTest.Info("Waited for page to load after clicking submit button.");
		}

		private GridControl _mLogInvoiceGrid;

		// You might have noticed that in the following 'get' there is no WaitForGrid.
		// Strangely, for this specific case it is not working. This is exceptional and should not be the norm.

		public GridControl MLogInvoiceGrid =>
			_mLogInvoiceGrid = new GridControl("InvoiceGridView", Driver);

        //The XPATH (_addInvoiceButton) have (*) for a quick solution because the XPTH change after clicking on the button to add value
        public void AddNewInvoice()
		{
            _addInvoiceButton.JSClickWithFocus(Driver, _addInvoiceButtonXPath,Settings);
            Settings.EnCompassExtentTest.Info("Clicked on Add Invoice");
		}

        public void CreateMlogWithMerchNo(string amount, int merchantno)
        {
            if (merchantno == 0)
                CreateMlogWithMerchNo("Test_Merchant", amount, (merchantno + 1).ToString());
            else
                CreateMlogWithMerchNo("Test_Merchant" + merchantno, amount, merchantno.ToString());
		}

		public void CreateMlogWithMerchNo(string merchantName, string amount, string merchantno)
		{
            if(merchantno == "*")
                MerchantTextBox = "*";
            else
                MerchantTextBox = merchantName + " (0000" + merchantno + ")";

            WaitForLoad();
            Settings.EnCompassExtentTest.Info("Setting Merchant Name while creating Mlog as :" + MerchantTextBox);
            SetInvoiceNumber();
            SetInvoiceAmount(amount);
            Submit();
		}

		public int GetColumnIndex(string columnName)
		{
			string path = $"//tr[contains(@id,'InvoiceGridView')]/th[text()='{columnName}']/preceding-sibling::th";
			return Driver.FindElements(By.XPath(path)).Count() + 1;
		}

		/// <summary>
		/// Insert Invoice Number and Amount values in a row (XPATH indexing)
		/// </summary>
		/// <param name="row">Row position (XPATH indexing)</param>
		/// <param name="invoiceNumber"></param>
		/// <param name="amount"></param>
		public void InsertInvoiceNumberAndAmount(int row, string invoiceNumber, string amount)
		{
			int invNumIndex = this.GetColumnIndex("Invoice Number");
			int amountIndex = this.GetColumnIndex("Amount");

			string pathInvNum = "//td[" + invNumIndex.ToString() + "]//input[contains(@id,'InvoiceNumberTextBox')]";
			string pathAmount = "//td[" + amountIndex.ToString() + "]//input[contains(@id,'AmountTextBox_currencyTextBox')]";

			if (!String.IsNullOrEmpty(invoiceNumber))
			{
				IWebElement _invNumInput = this.MLogInvoiceGrid.GetSpecificColInRowIdentifiedByXpath(row, pathInvNum);
				_invNumInput.Clear();
				_invNumInput.SendKeys(invoiceNumber + row.ToString());
				Settings.EnCompassExtentTest.Info("Inserted values of Invoice Number as : " + invoiceNumber + " on row: " + row);
			}

			if (!String.IsNullOrEmpty(amount))
			{
				IWebElement amountInput = this.MLogInvoiceGrid.GetSpecificColInRowIdentifiedByXpath(row, pathAmount);
				amountInput.Clear();
				amountInput.SendKeys(amount);
				Settings.EnCompassExtentTest.Info("Inserted values of Invoice Amount as : " + amount  + " on row: " + row);
			}

			Settings.EnCompassExtentTest.Info("Inserted values of Invoice Number and Amount on row: " + row);
		}

		public void AddNewMLog()
		{
			_addNewMLog.JSClickWithFocus(Driver);
		}

		public void SendFilePathAndVerifyName(String fileAbsPath, string fileName)
		{
			ExpandAddendumCategory();
			Driver.FindElement(By.XPath("//input[contains(@type,'file')][@id='newfile_0']")).SendKeys(fileAbsPath);
			var Name = fileName.Substring(fileName.LastIndexOf("\\") + 1);
			Settings.EnCompassWebDriver.WaitForVisible(By.XPath("//button[text()='" + Name + "']"));
			var NameOnScreen = Settings.EnCompassWebDriver.FindElement(By.XPath("//button[text()='" + Name + "']"));
			Check.That(NameOnScreen).IsNotNull();
		}

		public void SendAboveSizeLimitAndCheckAlertMsg(String fileAbsPath, string fileName)
		{
			ExpandAddendumCategory();
			Driver.FindElement(By.XPath("//input[contains(@type,'file')][@id='newfile_0']")).SendKeys(fileAbsPath);
			var Name = fileName.Substring(fileName.LastIndexOf("\\") + 1);
			WaitForAlertModalIFrame();
			string text = GetAlertModalIframe.GetAlertModalText;
			GetAlertModalIframe.Close();
			Check.That(text).Contains(Name);
			Check.That(text).Contains("cannot exceed 4096 KB.");
		}

		public void SendInvalidAndCheckAlertMsg(String fileAbsPath, string fileName)
		{
			ExpandAddendumCategory();
			Driver.FindElement(By.XPath("//input[contains(@type,'file')][@id='newfile_0']")).SendKeys(fileAbsPath);
			var Name = fileName.Substring(fileName.LastIndexOf("."));
			WaitForAlertModalIFrame();
			string text = GetAlertModalIframe.GetAlertModalText;
			GetAlertModalIframe.Close();
			Check.That(text).Contains(Name);
			Check.That(text).Contains("Please upload a valid file for " + Name);
		}

		public void RemoveUploadedDoc(string fileName)
		{
			RefreshModel();
			var Name = fileName.Substring(fileName.LastIndexOf("\\") + 1);
			var DeleteButton = Driver.FindElement(By.XPath("//button[contains(text(),'" + Name + "')]/following-sibling::span/button[@title='Remove']"));
			DeleteButton.JSClickWithFocus(Driver);
			GetAlertModalIframe.WaitForModalToAppear();
			GetAlertModalIframe.Delete();
			GetAlertModalIframe.WaitForModalToDisappear();			
		}

		public void SetInvoiceNumAndAmmount(string amount)
		{
			var uniqueString = $"zz{DateTime.Now.ToString("yyyyMMddhhmmss")}";
			_invoiceNumbers[0].ForceDocumentLoadOnSendKeys(uniqueString, Settings.EnCompassWebDriver);
			_invoiceAmounts[0].ForceDocumentLoadOnSendKeys(amount, Settings.EnCompassWebDriver);
		}

		public void ExpandAddendumCategory()
		{
            //Changed to the generic method
            ExpandCardHeader(AC_MAIN, AP_ADDENDUM);
            Settings.EnCompassExtentTest.Info("Expanded Addendum Section");
			//DO NOT REMOVE THIS. This is needed to wait for the record to be expaned. 
			_firstAddendumInput.WaitUntilElementIsInteractable();
		}

        public const string _alertModal = "//div[contains(@id,'Modal') and contains(@aria-labelledby,'ModalTitle_Modal')]";


		public void WaitForAlertModalIFrame()
		{
			Driver.WaitForVisible(By.XPath(_alertModal));
		}

        /// <summary>
        /// Check if the Pool Name is Visible
        /// </summary>
        /// <returns></returns>
        public bool IsPoolNameVisible()
        {
            Settings.EnCompassExtentTest.Info($"Verifying if Pool Name element is visible");
            bool status = Driver.TryWaitForElementToBeVisible(By.XPath(_poolNameXPath), out IWebElement element);
            Settings.EnCompassExtentTest.Info($"_poolName element exist is {status}");
            return status;
        }

        #region Alert Modal

        public AlertModal GetAlertModalIframe
		{
			get
			{
				using (FrameHelper helper = new FrameHelper(Settings.EnCompassWebDriver, By.XPath(_alertModal)))
				{
					return new AlertModal(helper, Settings);
				}
			}
		}

		public class AlertModal : MerchantLogEdit
		{
			FrameHelper _helper;
			public const string _closeButtonInModal = "//div[contains(@id,'Modal') and contains(@aria-labelledby,'ModalTitle_Modal')]//button[contains(@type,'button') and text()='Close']";
			public const string _alertModalText = "//div[contains(@id,'Modal') and contains(@aria-labelledby,'ModalTitle_Modal')]//div[@class='modal-body']/p";
			public const string _alertModalTitle = "//h1[contains(@id, 'ModalTitle_Modal')]";
			public const string _deleteButtonInModal = "//div[contains(@id,'Modal') and contains(@aria-labelledby,'ModalTitle_Modal')]//button[contains(@type,'button') and text()='Delete']";

			public void Close()
			{
				_helper.FindElement(By.XPath(_closeButtonInModal)).JSClickWithFocus(Driver);
			}

			public void Delete()
			{
				_helper.FindElement(By.XPath(_deleteButtonInModal)).JSClickWithFocus(Driver);
			}

			public string GetAlertModalText
			{
				get { return _helper.FindElement(By.XPath(_alertModalText)).Text; }
			}

			public string GetAlertModalTitle
			{
				get { return _helper.FindElement(By.XPath(_alertModalTitle)).Text; }
			}

			public AlertModal(FrameHelper helper, GlobalSettings settings) : base(settings)
			{ _helper = helper; }
		}
        #endregion

        #region CardInformationModal

        public string CardInfoModalBaseXpath = ".//div[contains(@id,'cardInfoModal') and contains(@class, 'show')]";
        /// <summary>
        /// Opens the Card Info Modal from Create Mlog Page
        /// </summary>
        public void OpenCardInformationModal()
        {
            Driver.TryFindElement(By.XPath(CARDINFORMATION_BTN), out IWebElement button);
            button.JSClickWithFocus(Driver);
            Settings.EnCompassExtentTest.Info("Clicked on Card Information Button");
            this.WaitForModalToAppear(CardInfoModalBaseXpath);
            //Driver.WaitForVisible(By.XPath(CardInfoModalBaseXpath), TimeSpan.FromMilliseconds(10000));
            Settings.EnCompassExtentTest.Info("Card Info Modal is being showed.");
        }

        /// <summary>
        /// Closes the Card Info Modal from Create Mlog Page
        /// </summary>
        public void CardInformationModalClose()
        {
            Driver.TryWaitForElementToBeVisible(By.XPath(CardInfoModalBaseXpath + "//button[contains(@id,'ContinueButton') and text()='Close']"),
                 out IWebElement element);
            element.JSClickWithFocus(Driver);
            Settings.EnCompassExtentTest.Info("Clicked on Close button on Card Info Modal.");
            this.WaitForModalToDisappear(CardInfoModalBaseXpath);
        }

        public string CardNumberOnCardInfoModal
        {
            get
            {
                Driver.TryWaitForElementToBeVisible(By.XPath(CardInfoModalBaseXpath + "//span[contains(@id,'CardInfo1_CardNumber')]"),
                     out IWebElement element);
                return element.Text;
            }
        }

        public string ExpirationDateOnCardInfoModal
        {
            get
            {
                Driver.TryWaitForElementToBeVisible(By.XPath(CardInfoModalBaseXpath + "//span[contains(@id,'CardInfo1_Expiration')]"),
                     out IWebElement element);
                return element.Text;
            }
        }

        public string CSCOnCardInfoModal
        {
            get
            {
                Driver.TryWaitForElementToBeVisible(By.XPath(CardInfoModalBaseXpath + "//span[contains(@id,'CardInfo1_Cvc2')]"),
                     out IWebElement element);
                return element.Text;
            }
        }

        #endregion
    }
}
