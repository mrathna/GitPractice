package com.framework.pages.AJS;

import java.text.DecimalFormat;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

import com.aventstack.extentreports.ExtentTest;
import com.framework.basepage.BasePage;
import com.framework.pages.AJS.common.Common;
import com.framework.pages.AJS.common.IFCSHomePage;
import com.framework.repo.Locator_IFCS;
import com.framework.util.PropUtils;
import com.framework.util.SeleniumWrappers;

public class MaintainAccountPage extends BasePage {
	
		@FindBy(xpath = Locator_IFCS.SUBSCRIPTION_TABLE)
		public WebElement subScriptionTable;
	
	    @FindBy(xpath = Locator_IFCS.SEARCH_RESULTS_TABLE)
		public List<WebElement> cardsTable;
	   
	    @FindBy(xpath = Locator_IFCS.OK_BUTTON)
		public WebElement okButton;

	    @FindBy(xpath=Locator_IFCS.ADJUSTMENT)
                public WebElement adjustment;

	   
	    @FindBy(xpath = Locator_IFCS.ACCOUNT_FEE_TABLE)
		public WebElement accountFeeTable;
	    
	    @FindBy(xpath = Locator_IFCS.MAINTAIN_ACCOUNTS_IN_LEFT_PANEL)
		public WebElement  maintainAccountsInLeftPanel ;
	    
	    public String ifcsVal;
	    
	public MaintainAccountPage(WebDriver driver, ExtentTest test) {
		super(driver, test);
		PageFactory.initElements(new AjaxElementLocatorFactory(driver, 15), this);
		 }

	Common common=new Common(driver,test);
	String referenceNo=String.valueOf(fakerAPI().number().digits(5));
	
	public void validateSundryAdjustment(String customerNumber, String effDate) {
		
	//	String effDate;
		sleep(5);
		chooseSubMenuFromLeftPanel("Sundry","Adjustment");
		isDisplayed(adjustment,"Adjustment Text");
		verifyTextFromAttributeFields("Customer Sundry Adjustment","Account No",customerNumber);//"CZ00001818"
		getValueFromProtectedTextBox("Customer Sundry Adjustment","Customer Name");
		common.chooseARandomDropdownOption("Adjustment Type");		 
	//	String currentIFCSDateforEffAt=common.getCurrentIFCSDateFromDB(clientName+clientCountry);
	//	effDate=common.enterADateValueInStatusBeginDateField("Current",currentIFCSDateforEffAt);
		enterValueInTextBox("Customer Sundry Adjustment","Effective On",effDate);//"25/01/2018"
		common.chooseARandomDropdownOption("Sundry Type");
		common.chooseARandomDropdownOption("GL Account Code");
		enterValueInTextBox("Customer Sundry Adjustment","Amount","2400");
		sleep(2);
		System.out.println("Reference Number is "+referenceNo);
		enterValueInTextBox("Customer Sundry Adjustment","Reference",referenceNo);
		sleep(2);
		enterValueInTextBox("Customer Sundry Adjustment","Updated GL Description","Sundry Description");
		sleep(3);
		common.clickValidateIcon();
		sleep(10);
		verifyValidationResult("Validation successful");
		common.clickPostTransaction();
		sleep(5);
		}
	
			
		
	
	public void verifySundryCreditTransaction() {
		
		try {
		chooseSubMenuFromLeftPanel("Client Transactions","Transactions");
		enterValueInTextBox("Transaction Filter Fields","Reference No",referenceNo);
		common.searchListTorch();
		verifyReferenceNoInTransaction();
	
		}
		 catch (Exception ex) {
				logFail(ex.getMessage());
			}
	}
		
	public void verifyReferenceNoInTransaction() {
		
		WebElement  textElement;
		String transactionReferenceNo;
		 int column;
		int size;
        try {
        	List<WebElement> list=driver.findElements(By.xpath("//div[@class='FALTableCellEditor_StrikeThruField JTextComponent']"));
            List<WebElement> cardsTableHeaders=driver.findElements(By.xpath("//div[@class='JViewport']/div[@class='JTableHeader']//div[@class='HeaderRenderer']"));
            column=SeleniumWrappers.getColumnNoForColumnHeader("Ref", cardsTableHeaders);
            size=SeleniumWrappers.getTotalNumberOfRows(list,driver); 
             System.out.println(size);
            for(int row=0;row<=size;row++) {
			System.out.println(row+" "+column);
			System.out.println(SeleniumWrappers.getTableDataWithRowAndColumnNumber(column, row, driver));
			textElement=SeleniumWrappers.getTableDataWithCellElement(row,column,driver); 
			    System.out.println(textElement);
			    transactionReferenceNo=  textElement.getAttribute("submittedvalue");
			    System.out.println(transactionReferenceNo);
			    if(transactionReferenceNo.equals(referenceNo)) {
			      logPass("Expected Reference Number is displayed in transaction");
				   break;
			    }
			   else{
				   logFail("Expected Reference Number is not displayed in transaction");
			   }
				}
			
            }catch (Exception ex) {
            	logFail(ex.getMessage());
            	}
        }

	public void attachAFeeProfile() {
		//List<WebElement> table;
		WebElement cellElement;
		chooseSubMenuFromLeftPanel("Account Profiles", "Account Fees");
		common.clearingAllTextBoxes(driver.findElements(
				By.xpath("//div[@class='JFALLabel']//preceding::div[@class='JFALCompControlPanel'][1]//input")));
		int rowNumber = SeleniumWrappers.getTotalNumberOfRows(
				driver.findElements(By.xpath("//div[@class='FALTableCellEditor_StrikeThruField JTextComponent']")),
				driver);
		System.out.println("Row number" + rowNumber);
		if (rowNumber == 0) {
			common.rightClickAndCreatePrivateProfile(accountFeeTable);
			common.validateCheckBoxInTableAndDoubleClick("Available Profiles", "Private", "Description");
			sleep(5);
			String desc = fakerAPI().name().firstName();
			enterValueInTextBox("Description", "Description", desc);
			common.clickOkButton();
			sleep(3);
			common.rightClickAndSelectProfile("Available Profiles", 0, "Description");
			common.clickSaveIcon();
			sleep(2);
			verifyValidationResult("Record saved OK");
		} else {

			/*table = driver.findElements(By.xpath("//div[@class='FALTableCellEditor_StrikeThruField JTextComponent']"));*/

			cellElement = SeleniumWrappers.getTableDataWithCellElement(0, 2, driver);
			rightClick(cellElement);
			sleep(5);
			try {
				WebElement selectProfileElement = driver.findElement(By.xpath(
						"//div[@class='JFALTablePopupMenuItem enabled JMenuItem']//div[contains(text(),'Select') and contains(text(),'Profile')]"));
				Click(selectProfileElement, "Select Profile");
			} catch (Exception e) {
				logInfo("Select Profile is already clicked");
			}
			sleep(3);
			common.clickSaveIcon();
			verifyValidationResult("Record saved OK");
		}
	}
	public void validateDateAssignedOnUpdate(){
		sleep(3);
		String dateFromText=getValueFromTextBox("Activation Date","Date Assigned On");
		System.out.println("date from text"+dateFromText);
		System.out.println(getCurrentDate());
		if(getCurrentDate().equals(dateFromText)){
			logPass("Date Assigned On is Updated");
		}
		else{
			logFail("Date Assigned On is not Updated");
		}
	}

	public void createAPrivateFeeProfile() {
		
		chooseSubMenuFromLeftPanel("Account Profiles", "Account Fees");
		
		validateHeaderLabel("Account Fees");
		
		common.rightClickAndCreatePrivateProfile(accountFeeTable);
		common.validateCheckBoxInTableAndDoubleClick("Available Profiles", "Private", "Description");
		
	}
		
	public void enterDetailsToCreatePrivateFeeProfile(){
		String desc=fakerAPI().name().firstName();
		enterValueInTextBox("Description","Description",desc);
		common.chooseARandomDropdownOption("Admin Fee 1");
		sleep(2);
		enterValueInTextBox("Account Fees","Months Delay",fakerAPI().number().digits(3));
		common.clickOkButton();
		String cellValue;
		int size=SeleniumWrappers.getTotalNumberOfRows(cardsTable,driver);
		System.out.println("total number of rows"+ size);
		List<WebElement> headerElement=driver.findElements(By.xpath("//div[@class='JViewport']/div[@class='JTableHeader']//div[@class='HeaderRenderer']"));
		int colIndex=SeleniumWrappers.getColumnNoForColumnHeader("Description",headerElement);
		 System.out.println("ColIndex"+ colIndex);
		for(int row=0;row<size;row++){
			System.out.println("inside for");
			cellValue=SeleniumWrappers.getTableDataWithRowAndColumnNumber(colIndex, row, driver);
			System.out.println("CellValue"+ cellValue);
			if(cellValue.equals(desc)){
			
				common.validateCheckBoxInTable("Available Profiles","Def...");
			}
		}
	}
	
	public void addSubScriptionToAccount()
	{
		sleep(5);
		chooseSubMenuFromLeftPanel("Maintain Account", "Subscriptions");
		sleep(5);
		rightClick(subScriptionTable);
		common.addIteminPopup();
		chooseOptionFromDropdown("Subscription","Vinci");
		enterValueInTextBox("Details","Toll Account","1234");
		//common.clickSecondPopupOkButton();
	       common.clickOkButton();
	       sleep(5);
	       common.clickSaveIcon();
		
	}
	
	public void editAndSaveCustomerAccountDetailsAndValidate() {

		if (PropUtils.getPropValue(configProp, "clientName").equals("WFE")) {
			sleep(3);
			validateHeaderLabel("Maintain Account");
			String optionValue = ajaxswingDropdownRandomSelection("Credit Plan");
			common.clickSaveIcon();
			sleep(1);
			verifyValidationResult("Record saved OK");
			String billingPlan = chooseOptionFromDropdown("Billing Plan", "random");
			common.clickSaveIcon();
			ScrollToElement("Billing Details", "Billing Frequency");
			verifyValidationResult("Record saved OK");
			String billingFrequency = ajaxswingDropdownRandomSelection("Billing Frequency");
			common.clickSaveIcon();
			sleep(1);
			verifyValidationResult("Record saved OK");
			String accountCycle = chooseOptionFromDropdown("Account Cycle", "random");

			common.clickSaveIcon();
			sleep(1);
			verifyValidationResult("Record saved OK");
			switchTabDetails("Financial Information");
			switchTabDetails("Account Information");
			sleep(3);
			verifyTextInDropDownForEditable("Credit / Alert Details", "Credit Plan", optionValue);
			sleep(2);
			verifyTextInDropDownForEditable("Billing Details", "Billing Plan", billingPlan);
			sleep(2);
			verifyTextInDropDownForEditable("Billing Details", "Billing Frequency", billingFrequency);
			sleep(2);
			verifyTextInDropDownForEditable("Billing Details", "Account Cycle", accountCycle);

			logInfo("Credit Plan " + optionValue + "Billing Plan " + billingPlan + "Billing Frequency "
					+ billingFrequency + "Account Cycle " + accountCycle);
		} else {
			/*
			 * switchTabDetails("Financial Information"); //validateLabelText("Bank");
			 * validateLabelText("Branch No"); validateLabelText("Created On");
			 * validateLabelText("Mandate ID"); String bankNo=fakerAPI().number().digits(4);
			 * String bankAccNo=fakerAPI().number().digits(4); String processingDate =
			 * common.getCurrentIFCSDateFromDB(clientName + clientCountry); String effDate
			 * =common.enterADateValueInStatusBeginDateField("Current", processingDate);
			 * String accName=fakerAPI().name().firstName(); String
			 * mandateId=fakerAPI().number().digits(4);
			 * chooseOptionFromDropdown("Bank","Bank of India");
			 * enterValueInTextBox("Bank Details","Bank No",bankNo);
			 * enterValueInTextBox("Bank Details","Branch No","001");
			 * enterValueInTextBox("Bank Details","Bank Acc No",bankAccNo);
			 * enterValueInTextBox("Bank Details","Created On",effDate);
			 * enterValueInTextBox("Bank Details","Account Name",accName);
			 * enterValueInTextBox("Bank Details","Mandate ID",mandateId);
			 * common.clickSaveIcon(); sleep(5); verifyValidationResult("Record saved OK");
			 * verifyTextInDropDownForEditable("Bank Details","Bank","Bank of India");
			 * verifyValueInTextBox("Bank Details","Bank No",bankNo );
			 * verifyValueInTextBox("Bank Details","Branch No","001");
			 * verifyValueInTextBox("Bank Details","Bank Acc No",bankAccNo);
			 * verifyValueInTextBox("Bank Details","Created On",effDate);
			 * verifyValueInTextBox("Bank Details","Account Name",accName);
			 * verifyValueInTextBox("Bank Details","Mandate ID",mandateId);
			 */
		}

	}

public void editAndSaveCustomerBillingFrequency(String billingFrequency) {

		validateHeaderLabel("Maintain Account");
		ScrollToElement("Billing Details", "Billing Frequency");
		chooseOptionFromDropdown("Billing Frequency", billingFrequency);
		common.clickSaveIcon();
		sleep(1);
		verifyValidationResult("Record saved OK");
		switchTabDetails("Financial Information");
		switchTabDetails("Account Information");

		verifyTextInDropDownForEditable("Billing Details", "Billing Frequency", billingFrequency);

		logInfo("Billing Frequency " + billingFrequency);
	}	
	
// Added by Ayub 2/4/2019 - Updated - 26/12/2019
	
	public void validatePostSundryAdjustmentTransaction(String clientName,String AccNum, String referenceNo) {

		chooseSubMenuFromLeftPanel("Sundry", "Adjustment");
		sleep(5);
		validateHeaderLabel("Adjustment");
		
		if(clientName.equals("EMAP")) {
		chooseOptionFromDropdown("Adjustment Type", "Late Payment Fee Adj");
		chooseOptionFromDropdown("GL Account Code", "Late Payment Fee (CR)");
		sleep(5);
		//enterValueInTextBox("Customer Sundry Adjustment", "Effective On", ifcsDate);
		//sleep(5);
		chooseOptionFromDropdown("Sundry Type", "Account Credit");
		sleep(2);
		enterValueInTextBox("Customer Sundry Adjustment", "Amount", "2");

		sleep(2);
		}
		else if(clientName.equals("CHEVRON")) {
		enterValueInTextBox("Customer Sundry Adjustment", "Account No", AccNum);	
		sleep(2);
		chooseOptionFromDropdown("Adjustment Type", "Customer Adj CR");	
		sleep(2);
		enterValueInTextBox("Customer Sundry Adjustment", "Amount", "10000");	
		sleep(2);

		}
		
		else if(clientName.equals("ZEnergy")) {
			enterValueInTextBox("Customer Sundry Adjustment", "Effective On", AccNum);	
			sleep(2);
			chooseOptionFromDropdown("Adjustment Type", "Customer CR");	
			sleep(2);
			enterValueInTextBox("Customer Sundry Adjustment", "Amount", "10000");	
			sleep(2);

			}
		
		else if (clientName.equals("WFE")) {
			
			chooseOptionFromDropdown("Adjustment Type", "Entrance Fee");
			chooseOptionFromDropdown("GL Account Code", "Entrance Fee");
			chooseOptionFromDropdown("Sundry Type", "Account Credit");
			sleep(2);
			enterValueInTextBox("Customer Sundry Adjustment", "Amount", "100");
			enterValueInTextBox("Customer Sundry Adjustment", "Payment Reference", referenceNo);
		}
		
		else {
		sleep(2);
		String accountNumber=getValueFromTextBox("Customer Sundry Adjustment","Account No");
		System.out.println(accountNumber);

		chooseOptionFromDropdown("Adjustment Type", "Customer Sundry Adjustment");	
		sleep(2);
		chooseOptionFromDropdown("GL Account Code", "random");
		sleep(5);
		/*enterValueInTextBox("Customer Sundry Adjustment", "Effective On", ifcsDate);
		sleep(5);*/
		chooseOptionFromDropdown("Sundry Type", "Account Credit");
		sleep(2);
		enterValueInTextBox("Customer Sundry Adjustment", "Amount", "2");	
		sleep(2);
		}

		if (!clientName.equals("WFE")) {
		enterValueInTextBox("Customer Sundry Adjustment", "Reference", referenceNo);
		sleep(5);
		}

		common.clickValidateIcon();
		sleep(5);
		verifyValidationResult("Validation successful");
		sleep(5);
		common.clickPostTransaction();
		sleep(5);
		verifyValidationResult("Record saved OK");
		}


	public String getfakernumber() {
		String f_number = fakerAPI().number().digits(3);
		return f_number;

	}
	
	//Prakalpha
	public double getAccountBalance(String seperatorLabelName, String labelName) {
		double balValue = 0.0;
		try {
			sleep(2);
			String balance = getValueFromProtectedTextBox(seperatorLabelName, labelName);
			balValue = Double.parseDouble(balance);
			logPass(balValue + "For" +labelName);
		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
		return balValue;
	}
	
	public void validateBalanceCreditedForAnAccount(double beforeAvailable) {
		double amountvalue = 0.0;
		double afterAvaliable = 0.0;
		double credit = 0.0;
		try {
			String amount = getValueFromTextBox("Customer Sundry Adjustment", "Amount");
			amountvalue = Double.parseDouble(amount);
			System.out.println(amountvalue);
			credit = beforeAvailable - amountvalue;
			System.out.println(credit);
			sleep(5);
			checkElementPresenceAndClick(maintainAccountsInLeftPanel, " Maintain Account");
			// chooseSubMenuFromLeftPanel("Maintain Account", " ");
			sleep(5);
			validateHeaderLabel("Maintain Account");
			String availablebal = getValueFromProtectedTextBox("Account Status", "Available Balance");
			afterAvaliable = Double.parseDouble(availablebal);
			if (credit == afterAvaliable) {
				logPass(afterAvaliable + " Amount is Credited");
			} else {
				logFail(afterAvaliable + " Amount is Not Credited");
			}
		} catch (Exception ex) {
			logFail(ex.getMessage());
		}

	}
	
	public void validateTheFinancialBalance(double beforeActualBal, double afterActualBal, double customerValue) {
		try {
		double CurrentAccountBalance = beforeActualBal + customerValue;
		System.out.println(CurrentAccountBalance);
        System.out.println(
				"Current Account Bal:: " + CurrentAccountBalance + "Actual Account Balance::" + afterActualBal);

		if (CurrentAccountBalance==afterActualBal) {
			logPass(CurrentAccountBalance +" Current Actual balance and  Actual Account Balance " +afterActualBal +"are Same");
		} else {
			logFail("Balance is not reflected correctly");
		}
	} catch (Exception ex) {
		logFail(ex.getMessage());
	}
		
}	
	public void validateSundryAdjustmentWFE(String customerNumber, String effDate,String Type,String adjType) {
		
		//	String effDate;
			sleep(5);
			chooseSubMenuFromLeftPanel("Sundry","Adjustment");
			sleep(5);
			isDisplayed(adjustment,"Adjustment Text");
			verifyTextFromAttributeFields("Customer Sundry Adjustment","Account No",customerNumber);//"CZ00001818"
			getValueFromProtectedTextBox("Customer Sundry Adjustment","Customer Name");
			//common.chooseARandomDropdownOption("Adjustment Type");
			common.chooseOptionFromDropdown("Adjustment Type", adjType);
		//	String currentIFCSDateforEffAt=common.getCurrentIFCSDateFromDB(clientName+clientCountry);
		//	effDate=common.enterADateValueInStatusBeginDateField("Current",currentIFCSDateforEffAt);
			enterValueInTextBox("Customer Sundry Adjustment","Effective On",effDate);//"25/01/2018"
			//common.chooseARandomDropdownOption("Sundry Type");
			common.chooseOptionFromDropdown("Sundry Type", Type);
			common.chooseARandomDropdownOption("GL Account Code");
			enterValueInTextBox("Customer Sundry Adjustment","Amount","10");
			sleep(2);
			System.out.println("Reference Number is "+referenceNo);
			enterValueInTextBox("Customer Sundry Adjustment","Payment Reference",referenceNo);
			sleep(2);
			enterValueInTextBox("Customer Sundry Adjustment","Updated GL Description","Sundry Description");
			sleep(3);
			common.clickValidateIcon();
			sleep(10);
			verifyValidationResult("Validation successful");
			common.clickPostTransaction();
			sleep(5);
			verifyValidationResult("Record saved OK");
			}
	  
/*
	 * Raxsana added on 13/10/2020
	 */
	public void validateActualAndAvailableBalanceForCredit(String ActBal,String AvaiBal) {
		IFCSHomePage IFCSHomePage=new IFCSHomePage(driver,test); 
		Common common =new Common(driver,test);
		DecimalFormat decimalFormat=new DecimalFormat("#.#");
		System.out.println("referenceNo"+referenceNo);
		String queryToGetTransactionAmount="select customer_amount from transactions where reference='"+referenceNo+"' order by processed_at desc";
		String transactionAmountFromDB=connectDBAndGetValue(queryToGetTransactionAmount, PropUtils.getPropValue(configProp, "sqlODSServerName"));
		System.out.println("transactionAmount::"+transactionAmountFromDB);
		IFCSHomePage.gotoAccountAndClickAccountDetails();
		String ActBalAft = common.getValueFromProtectedTextBox("Account Status", "Actual Balance");
		String AvaiBalAft = common.getValueFromProtectedTextBox("Account Status", "Available Balance");
		common.logInfo("Actual Balance After Sundry" + ActBalAft);
		common.logInfo("Available Balance After Sundry" + AvaiBalAft);
		double actbalance = Double.parseDouble(ActBal) - Double.parseDouble(ActBalAft);
		double avaibalance = Double.parseDouble(AvaiBalAft) - Double.parseDouble(AvaiBal);
		common.logInfo("actbalnce" + decimalFormat.format(actbalance));
		common.logInfo("avaibalnce" + decimalFormat.format(avaibalance));
		String transactionAmount; 
		if(transactionAmountFromDB.equals("10")) {
			transactionAmount = transactionAmountFromDB.replace("-", "").concat(".0");
		}else {
			transactionAmount = transactionAmountFromDB.replace("-", "");
		}
		System.out.println("transactionAmount::"+transactionAmount);
		if ((String.valueOf(decimalFormat.format(actbalance)).equals(transactionAmount) && String.valueOf(decimalFormat.format(avaibalance)).equals(transactionAmount))) {
			common.logPass("Credit Sundry Adjusment successfully posted");
		} else {
			common.logFail("Credit Sundry Adjusment NOT successfully posted");
		}
	}
	
	/*
	 * Raxsana added on 16/10/2020
	 */
	public void validateActualAndAvailableBalanceForDebit(String ActBal,String AvaiBal) {
		IFCSHomePage IFCSHomePage=new IFCSHomePage(driver,test); 
		Common common =new Common(driver,test);
		DecimalFormat decimalFormat=new DecimalFormat("#.#");
		System.out.println("referenceNo"+referenceNo);
		String queryToGetTransactionAmount="select customer_amount from transactions where reference='"+referenceNo+"' order by processed_at desc";
		String transactionAmountFromDB=connectDBAndGetValue(queryToGetTransactionAmount, PropUtils.getPropValue(configProp, "sqlODSServerName"));
		System.out.println("transactionAmount::"+transactionAmountFromDB);
		IFCSHomePage.gotoAccountAndClickAccountDetails();
		String ActBalAft = common.getValueFromProtectedTextBox("Account Status", "Actual Balance");
		String AvaiBalAft = common.getValueFromProtectedTextBox("Account Status", "Available Balance");
		common.logInfo("Actual Balance After Sundry" + ActBalAft);
		common.logInfo("Available Balance After Sundry" + AvaiBalAft);
		double actbalance = Double.parseDouble(ActBal) - Double.parseDouble(ActBalAft);
		double avaibalance = Double.parseDouble(AvaiBalAft) - Double.parseDouble(AvaiBal);
		common.logInfo("actbalnce" + decimalFormat.format(actbalance));
		common.logInfo("avaibalnce" + decimalFormat.format(avaibalance));
		if ((String.valueOf(decimalFormat.format(actbalance).replace("-", "")).equals(transactionAmountFromDB) && String.valueOf(decimalFormat.format(avaibalance).replace("-", "")).equals(transactionAmountFromDB))) {
			common.logPass("Debit Sundry Adjusment successfully posted");
		} else {
			common.logFail("Debit Sundry Adjusment NOT successfully posted");
		}
	}
}
