﻿using Common;
using Common.Utility;
using NFluent;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EnCompass.Testing.Source.PageObjects.Organization.ExpenseManager.Transactions
{
    [PageModel(@"/expenseManager/transactions/viewTransactions.aspx")]
    class ViewTransactions : EnCompassPageModel
    {
        public override string RelativeUrl => @"/expenseManager/transactions/viewTransactions.aspx";
        //public override string PageIdentifierXPath_Override => @"//div[@class='crumb_selected_content'][text() = 'Transactions']";

        #region XPath page Elements
        private const string _manageReceiptsXPath = @"//input[contains(@id, 'btnManageReceipt')]";
        #endregion

        #region Page Elements
        private IWebElement _manageReceipts
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_manageReceiptsXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_manageReceipts element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        #endregion

        public void CheckManageReceiptButtonDisplayed()
        {
            Settings.EnCompassWebDriver.WaitForVisible(By.XPath(_manageReceiptsXPath));
        }

        public ViewTransactions(GlobalSettings settings) : base(settings) { }
    }
}
