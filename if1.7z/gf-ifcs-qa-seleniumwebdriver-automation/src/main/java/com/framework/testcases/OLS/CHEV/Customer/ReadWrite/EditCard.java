package com.framework.testcases.OLS.CHEV.Customer.ReadWrite;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.CHEV.CHEditCardPage;
import com.framework.pages.CHEV.CHHomePage;
import com.framework.pages.OLS.common.CommonPage;
import com.framework.pages.OLS.common.LoginPage;

public class EditCard extends BaseTest {
	@Parameters({ "clientCountry", "clientName"})
	@Test(priority = 1)
	public void testCustomerReadWriteEditCardDetails(@Optional("PH") String clientCountry, @Optional("CHV") String clientName) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  OLS - Edit Card Details", "Chevron Customer Screens Read Only");

		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		if (clientCountry.equals("SG")||clientCountry.equals("MY")||clientCountry.equals("HK")) {
			loginPage.Login("CHV_URL", "CHV_Customer_UN_RW_ONLY_"+clientCountry, "CHV_Customer_PWD_RW_ONLY_"+clientCountry, "CHV");
		} else if (clientCountry.equals("TH")) {
			loginPage.Login("CHV_URL", "CHV_Customer_UN_"+clientCountry, "CHV_Customer_PWD_"+clientCountry, "CHV");
		} else if (clientCountry.equals("PH")) {
			loginPage.Login("CHV_URL", "CHV_Customer_UN_"+clientCountry, "CHV_Customer_PWD_"+clientCountry, "CHV");
		}
		CHHomePage chHomePage= new CHHomePage(driver,test);
		CHEditCardPage chEditCardPage=new CHEditCardPage(driver,test);
		CommonPage commonPage=new CommonPage(driver,test);
		
		//Home Page verification
		chHomePage.verifyHomePageText();
		chHomePage.verifyUserNameAndLogoutLink();
		commonPage.selectAccountFromDropdownAndValidate();
		chHomePage.loadFindValidateAndUpdateCardPage();
		
		//Find Cards Page
		chEditCardPage.selectAccountFromDropdownAndValidateCard();
		chEditCardPage.clickSearchButtonAndValidate();
		chEditCardPage.cardStatusInFindCards();
		chEditCardPage.getACardNumberFromTable();
		chEditCardPage.cardNoPickEnterandValidate();
		chEditCardPage.clickSearchButtonAndValidate();
		chEditCardPage.getVehRegNoFromTableAndSearch();
		chEditCardPage.verifySearchResults();
		chEditCardPage.editPageInCardTable();
		
		//Edit Card
		chEditCardPage.verifyEditCardText();
		chEditCardPage.disableFields();
		chEditCardPage.purchaseControlsTimeLimit();
		
		//Permanent Address fillup using fakerAPI and submitting
		chEditCardPage.permanentAddressFill();
		chEditCardPage.updateClick();
		chEditCardPage.clickOnCancelButtonIneditStatusPopup();
		chEditCardPage.verifyEditCardText();
		chEditCardPage.updateClick();
		chEditCardPage.clickOnAcceptButtonIneditStatusPopup();
		chEditCardPage.verifyEditCardText();
		chEditCardPage.successMsg();
		chEditCardPage.backToCardListLink();
		
		//Cards Page for clicking View card in pop up from table
		chEditCardPage.cardsPageValidatePageTitle();
		chEditCardPage.viewCardDetailsInTable();
		
		//View Card
		chEditCardPage.viewCardValidateTitle();
		chEditCardPage.deliveryAddressUpdatedCheck();
		
		//logout
		loginPage.Logout();
		
				
	}
}
