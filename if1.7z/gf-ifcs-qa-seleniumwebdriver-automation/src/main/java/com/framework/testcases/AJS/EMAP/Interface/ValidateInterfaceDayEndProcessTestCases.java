package com.framework.testcases.AJS.EMAP.Interface;

import java.util.ArrayList;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.ClientConfigPage;
import com.framework.pages.AJS.MaintainCustomerPage;
import com.framework.pages.AJS.TransactionListPage;
import com.framework.pages.AJS.common.Common;
import com.framework.pages.AJS.common.IFCSCommonPage;
import com.framework.pages.AJS.common.IFCSHomePage;
import com.framework.pages.AJS.common.IFCSLoginPage;
import com.framework.pages.AJS.common.InterfacePage;
import com.github.javafaker.Faker;

public class ValidateInterfaceDayEndProcessTestCases  extends BaseTest{
	
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "Smoke" })
	public void ValidateMigratedCustomerWithPeroidicRebate(@Optional("SG") String clientCountry,
			@Optional("EMAP") String clientName) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  TST-SC-23-Migrated customer with Periodic rebate","Migrated customer with Periodic rebate via DayEnd and MonthEnd");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
        Common common = new Common(driver, test);
        TransactionListPage transactionListPage = new TransactionListPage(driver, test);
        ClientConfigPage clientConfigPage = new ClientConfigPage(driver, test);
        IFCSCommonPage ifcsCommonPage = new IFCSCommonPage(driver, test);
        InterfacePage interfacePage = new InterfacePage(driver, test);
        MaintainCustomerPage maintaincustomerPage=new MaintainCustomerPage(driver, test);
        
		IFCSloginPage.login("IFCS_URL_EMAP", "IFCS_EMAP_USERNAME", "IFCS_EMAP_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry," ");
		Faker fakerN = new Faker();
		String f_referenceNo = fakerN.number().digits(3);
		String currentDate = common.getCurrentIFCSDateFromDB(clientName+clientCountry);
		// Get the IFCS current date
		String ifcsCurrentDate = common.enterADateValueInStatusBeginDateField("Current", currentDate);
		System.out.println("Date ::"+ifcsCurrentDate);
		String expiryDate = common.enterADateValueInStatusBeginDateField("WayFuture", currentDate);
		
		//To get Migrate customer number 
		String receivedOn = common.getReceivedOnDateForMigratedCustomer();
		String migratedCustomerNo = common.getMigratedCustomerHavingActiveCardsWithAccountBalance(receivedOn, "Duty Free Customer");
		
		//data Creation for migrate customer with Periodic rebates
		IFCSHomePage.gotoApplicationAndClickApplicationMenu();
		IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);
		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		common.chooseCustomerNoAndSearch(migratedCustomerNo);
	    int rownum =maintaincustomerPage.getRownumberAndCreateRebateProfile();
				 if(rownum==0){
					 maintaincustomerPage.enterDetailsInRebateProfilePopup(ifcsCurrentDate, expiryDate);
					 }
					
				maintaincustomerPage.enterDetailsInRebateDetailsPopup("Period - PCT Value - No Parent - Tier Single Rate -All Sites", ifcsCurrentDate, expiryDate, " ", "02 - Fuels", "1",
									"", "1", "");
						
			      common.clickOkButton();
			      common.rightClickAndOptInout("Rebate Profiles", "Private");
				  common.validateCheckBoxInTable("Rebate Profiles", "Opted Out");
				  common.clickSaveIcon();
				  common.checkRecordSaved();
		
		String cardNo = common.getActiveCardNoFromMigratedCustomer(migratedCustomerNo,1);
		String cardNo2 = common.getActiveCardNoFromMigratedCustomer(migratedCustomerNo,2);
        String locationNo=common.chooseALocationWithNonFuelProduct("Y");
		String productCode=common.chooseANonFuelProductExtCodeInTheLocation(locationNo,"Y","externalCode");
		if (cardNo.equals(" ") && cardNo2.equals(" ") && locationNo.equals(" ") && productCode.equals(" ")){
			common.logForNoDataFound(this.getClass().getSimpleName(),
					"Need to Create A Cards with Account and rerun");
		} else {
		
		//Roll a date
		IFCSHomePage.gotoAdminAndClickClient();
		common.changingTheDateFormat();
		String dayEndDate =common.addNewExpiryDate();
		clientConfigPage.changeProcessingDateFromInstitutePage(dayEndDate);
			
	    //Manual Transaction 
		IFCSHomePage.gotoTransactionAndClickManageTransaction();
	    //transactionListPage.validateToPostManualTransactionEntry(ifcsCurrentDate,f_referenceNo,clientCountry,cardNo,cardNo2,locationNo,productCode,false);
	    transactionListPage.enterTransactionBatchDetails(false,"160","1",clientName);
		transactionListPage.enterManualTransactionDetails(ifcsCurrentDate,f_referenceNo,cardNo,"","","160","");
		transactionListPage.enterTransactionLineItems(productCode,"160","100","160");
		transactionListPage.validatePostManualTransaction("Validation successful");
		transactionListPage.validatePostSuspendedtransaction(f_referenceNo);
		
		//get UnitPrice Value before dayEnd and MonthEnd 
		IFCSHomePage.gotoTransactionAndClickManageTransaction();
	    double beforeUnitPriceValue=transactionListPage.getUnitPriceFromCustomerBreakdown(f_referenceNo);
	    
	   // DayEnd Jobs
	    String folderName = "";
		String jobsInOrder = "";
		folderName = ifcsCommonPage.getControlMFolder(clientName, clientCountry, "jobS_emap_Dayend");

		jobsInOrder = ifcsCommonPage.getJobsOfFolderInOrder("jobS_emap_Dayend");
		
		// Executing the Control-M Jobs
				interfacePage.establishAndExecuteControlMJobs("ControlM_AWS_UAT", "ContorlM_AWS_userName",
						"ContorlM_AWS_password", folderName, jobsInOrder);
		
		// MonthEnd Jobs
		folderName = ifcsCommonPage.getControlMFolder(clientName, clientCountry, "jobS_emap_Monthend");
		jobsInOrder = ifcsCommonPage.getJobsOfFolderInOrder("jobS_emap_Monthend");
		
		// Executing the Control-M Jobs
		interfacePage.establishAndExecuteControlMJobs("ControlM_AWS_UAT", "ContorlM_AWS_userName",
				"ContorlM_AWS_password", folderName, jobsInOrder);
		
		//get UnitPrice Value after dayEnd and MonthEnd 
				IFCSHomePage.gotoTransactionAndClickManageTransaction();
			    transactionListPage.validateUnitPriceIsUpdated(beforeUnitPriceValue);
				
		}
		IFCSHomePage.exitIFCS();
	
	}

	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "Smoke" })
	public void ValidateAndCalculatePeriodRebateManualTransaction(@Optional("SG") String clientCountry,
			@Optional("EMAP") String clientName) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  TST-SC-104-CR112 -Period Rebates to be calculated off Customer Pump Price - Manual Transaction","Manual Transaction-Calculate Periodic rebate via DayEnd and MonthEnd");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
        Common common = new Common(driver, test);
        TransactionListPage transactionListPage = new TransactionListPage(driver, test);
        ClientConfigPage clientConfigPage = new ClientConfigPage(driver, test);
        MaintainCustomerPage maintainCustomerPage = new MaintainCustomerPage(driver, test);
        IFCSCommonPage ifcsCommonPage = new IFCSCommonPage(driver, test);
        InterfacePage interfacePage = new InterfacePage(driver, test);
        

		IFCSloginPage.login("IFCS_URL_EMAP", "IFCS_EMAP_USERNAME", "IFCS_EMAP_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry," ");
		Faker fakerN = new Faker();
		String f_referenceNo = fakerN.number().digits(3);
		String currentDate = common.getCurrentIFCSDateFromDB(clientName+clientCountry);
		
		
		// Get the IFCS  date
		String effDate =common.enterADateValueInStatusBeginDateField("Current", currentDate);
		String expiryDate =common.enterADateValueInStatusBeginDateField("WayFuture", currentDate);
		System.out.println("Date ::"+effDate);
		
		//Parent with Periodic rebate 
		String rebateParentCusNo=common.getRebateParentCustomerNoInHierarchy();
        String childCusNo=common.getChildCustomerNoInHierarchy(rebateParentCusNo);
        
	
		String cardNo = common.getActiveCardNoFromMigratedCustomer(childCusNo,1);
		String cardNo2 = common.getActiveCardNoFromMigratedCustomer(childCusNo,2);
        String locationNo=common.chooseALocationWithNonFuelProduct("Y");
		String productCode=common.chooseANonFuelProductExtCodeInTheLocation(locationNo,"Y","externalCode");
		if (cardNo.equals(" ") && cardNo2.equals(" ") && locationNo.equals(" ") && productCode.equals(" ")){
			common.logForNoDataFound(this.getClass().getSimpleName(),
					"Need to Create A Cards with Account and rerun");
		} else {
		
			IFCSHomePage.gotoApplicationAndClickApplicationMenu();
			IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);
			IFCSHomePage.gotoCustomerMenuCustomerDetails();
			maintainCustomerPage.createRebateProfileWithRequiredRebateDetails(rebateParentCusNo,effDate,expiryDate);
			IFCSHomePage.gotoCustomerMenuCustomerDetails();
			maintainCustomerPage.createRebateProfileWithRequiredRebateDetails(childCusNo,effDate,expiryDate);
		
			//Roll a date
			IFCSHomePage.gotoAdminAndClickClient();
			common.changingTheDateFormat();
			String dayEndDate =common.addNewExpiryDate();
			clientConfigPage.changeProcessingDateFromInstitutePage(dayEndDate);
			
	    //Post the Manual Transaction
	    IFCSHomePage.gotoTransactionAndClickManageTransaction();
	    //transactionListPage.validateToPostManualTransactionEntry(effDate,f_referenceNo,clientCountry,cardNo,cardNo2,locationNo,productCode,true);
	    transactionListPage.enterTransactionBatchDetails(true,"160","1",clientName);
		transactionListPage.enterManualTransactionDetails(effDate,f_referenceNo,cardNo,cardNo2,locationNo,"160","");
		transactionListPage.enterTransactionLineItems(productCode,"160","100","160");
		transactionListPage.validatePostManualTransaction("Validation successful");
		transactionListPage.validatePostSuspendedtransaction(f_referenceNo);
		
		//get UnitPrice Value before dayEnd and MonthEnd 
				IFCSHomePage.gotoTransactionAndClickManageTransaction();
			    double beforeUnitPriceValue=transactionListPage.getUnitPriceFromCustomerBreakdown(f_referenceNo);
			    
	    
	    
	    // DayEnd jobs
		String folderName = "";
		String jobsInOrder = "";
		folderName = ifcsCommonPage.getControlMFolder(clientName, clientCountry, "jobS_emap_Dayend");

		jobsInOrder = ifcsCommonPage.getJobsOfFolderInOrder("jobS_emap_Dayend");
		
		// Executing the Control-M Jobs
				interfacePage.establishAndExecuteControlMJobs("ControlM_AWS_UAT", "ContorlM_AWS_userName",
						"ContorlM_AWS_password", folderName, jobsInOrder);
	    
		// MonthEnd Jobs
		folderName = ifcsCommonPage.getControlMFolder(clientName, clientCountry, "jobS_emap_Monthend");
		jobsInOrder = ifcsCommonPage.getJobsOfFolderInOrder("jobS_emap_Monthend");
		
		// Executing the Control-M Jobs
		interfacePage.establishAndExecuteControlMJobs("ControlM_AWS_UAT", "ContorlM_AWS_userName",
				"ContorlM_AWS_password", folderName, jobsInOrder);
		
		//get UnitPrice Value after dayEnd and MonthEnd 
		IFCSHomePage.gotoTransactionAndClickManageTransaction();
	    transactionListPage.validateUnitPriceIsUpdated(beforeUnitPriceValue);
						
		}	
	
		IFCSHomePage.exitIFCS();
	
	}	
	
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "Smoke" })
	public void ValidateFEPFileInboundAndCalculatePeriodRebateForCustomerPumpPrice(@Optional("SG") String clientCountry,
			@Optional("EMAP") String clientName) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  TST-SC-105-CR112 -Period Rebates to be calculated off Customer Pump Price - FEP File- Inbound- TXN","Customer Pump Price-Calculate Periodic rebate via DayEnd and MonthEnd");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
        Common common = new Common(driver, test);
        TransactionListPage transactionListPage = new TransactionListPage(driver, test);
        ClientConfigPage clientConfigPage = new ClientConfigPage(driver, test);
        MaintainCustomerPage maintainCustomerPage = new MaintainCustomerPage(driver, test);
        InterfacePage interfacePage = new InterfacePage(driver,test);
        IFCSCommonPage ifcsCommonPage = new IFCSCommonPage(driver, test);
        
        ArrayList<String> refNumberUpdated;
        
		IFCSloginPage.login("IFCS_URL_EMAP", "IFCS_EMAP_USERNAME", "IFCS_EMAP_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry," ");
		Faker fakerN = new Faker();
		String f_referenceNo = fakerN.number().digits(3);
		String currentDate = common.getCurrentIFCSDateFromDB(clientName+clientCountry);
		
		
		// Get the IFCS  date
		String effDate =common.enterADateValueInStatusBeginDateField("Current", currentDate);
		String expiryDate =common.enterADateValueInStatusBeginDateField("WayFuture", currentDate);
		System.out.println("Date ::"+effDate);
		
		//Required Data from DB 
		String rebateParentCusNo=common.getRebateParentCustomerNoInHierarchy();
        String childCusNo=common.getChildCustomerNoInHierarchy(rebateParentCusNo);
        
	
		
		
			IFCSHomePage.gotoApplicationAndClickApplicationMenu();
			IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);
			IFCSHomePage.gotoCustomerMenuCustomerDetails();
			maintainCustomerPage.createRebateProfileWithRequiredRebateDetails(rebateParentCusNo,effDate,expiryDate);
			IFCSHomePage.gotoCustomerMenuCustomerDetails();
			maintainCustomerPage.createRebateProfileWithRequiredRebateDetails(childCusNo,effDate,expiryDate);
		
			//Roll a date
			IFCSHomePage.gotoAdminAndClickClient();
			common.changingTheDateFormat();
			String dayEndDate =common.addNewExpiryDate();
			clientConfigPage.changeProcessingDateFromInstitutePage(dayEndDate);
			
			//get UnitPrice Value before dayEnd and MonthEnd 
			IFCSHomePage.gotoTransactionAndClickManageTransaction();
		    double beforeUnitPriceValue=transactionListPage.getUnitPriceFromCustomerBreakdown(f_referenceNo);
			
			refNumberUpdated = interfacePage.updateOrValidateFlatFile(emapLoadcardflatconfigPropOnlySG, "OutgoingFile", "IE_INPUTFILE_FOLDER_LOADCARDTRANSACTIONS",childCusNo, clientName, clientCountry, "FLTRAN_20190528.txt"); 
			
			if(!refNumberUpdated.equals("")) {
				String folderName = ifcsCommonPage.getControlMFolder(clientName, clientCountry, "jobS_TransProc");
				
				String jobsInOrder =  ifcsCommonPage.getJobsOfFolderInOrder("jobS_TransProc");
			   
				interfacePage.establishAndExecuteControlMJobs("ControlM_AWS_UAT","ContorlM_AWS_userName","ContorlM_AWS_password",folderName, jobsInOrder);
		
			
		

}else
{
	System.out.println("Interface is not updated correctly");
}
			// DayEnd jobs
			String folderName = "";
			String jobsInOrder = "";
			folderName = ifcsCommonPage.getControlMFolder(clientName, clientCountry, "jobS_emap_Dayend");

			jobsInOrder = ifcsCommonPage.getJobsOfFolderInOrder("jobS_emap_Dayend");
			
			// Executing the Control-M Jobs
					interfacePage.establishAndExecuteControlMJobs("ControlM_AWS_UAT", "ContorlM_AWS_userName",
							"ContorlM_AWS_password", folderName, jobsInOrder);
		    
			// MonthEnd Jobs
			folderName = ifcsCommonPage.getControlMFolder(clientName, clientCountry, "jobS_emap_Monthend");
			jobsInOrder = ifcsCommonPage.getJobsOfFolderInOrder("jobS_emap_Monthend");
			
			// Executing the Control-M Jobs
			interfacePage.establishAndExecuteControlMJobs("ControlM_AWS_UAT", "ContorlM_AWS_userName",
					"ContorlM_AWS_password", folderName, jobsInOrder);
			
			//get UnitPrice Value after dayEnd and MonthEnd 
			IFCSHomePage.gotoTransactionAndClickManageTransaction();
		    transactionListPage.validateUnitPriceIsUpdated(beforeUnitPriceValue);
			
			//Exit the Application
			IFCSHomePage.exitIFCS();
}
}
