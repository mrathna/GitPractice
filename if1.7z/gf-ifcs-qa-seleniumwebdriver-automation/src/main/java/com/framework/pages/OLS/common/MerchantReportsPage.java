package com.framework.pages.OLS.common;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Date;
import java.util.List;

import org.monte.media.ParseException;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.ExtentTest;
import com.framework.basepage.BasePage;
import com.framework.repo.Locator;

public class MerchantReportsPage extends BasePage {

	@FindBy(how = How.ID, using = Locator.REPORTS_MENU)
	public WebElement reportMenu;
	@FindBy(how = How.ID, using = Locator.ADHOC_REPORTS)
	public WebElement adhocReportSubMenu;
	@FindBy(how = How.XPATH, using = Locator.ADHOC_REPORTS_TITLE)
	public WebElement adhocReportTitle;
	@FindBy(how = How.ID, using = Locator.ADHOC_REPORTS_EXPORT)
	public WebElement adhocReportExportLink;
	@FindBy(how = How.ID, using = Locator.STORED_REPORTS)
	public WebElement storedReportPage;
	@FindBy(how = How.XPATH, using = Locator.REPORTS_TITLE_HEADER)
	public WebElement reportTitleHeader;
	@FindBy(how = How.ID, using = Locator.SEARCH_ALL_PAGE)
	public WebElement ReportSearchBtn;
	@FindBy(how = How.ID, using = Locator.SEARCH)
	public WebElement searchButton;
	@FindBy(how = How.XPATH, using = Locator.STORED_REPORTS_EXPORT)
	public WebElement storedReportExportLink;
	@FindBy(how = How.ID, using = Locator.INVOICE_REPORTS)
	public WebElement invoicesReportPage;
	@FindBy(how = How.XPATH, using = Locator.INVOICE_REPORTS_EXPORT)
	public WebElement invoicesReportExportBtn;
	@FindBy(how = How.ID, using = Locator.STATEMENTS_REPORTS)
	public WebElement statementReportPage;
	@FindBy(how = How.ID, using = Locator.STATEMENT_REPORTS_EXPORT)
	public WebElement statementReportExportLink;
	@FindBy(how = How.XPATH, using = Locator.REPORT_TABLE_LIST)
	public List<WebElement> adhocReportTableList;
	@FindBy(how = How.XPATH, using = Locator.ADHOC_REPORT_RUN_PAGE_HEADER)
	public WebElement adhocReportRunPageHeader;
	@FindBy(how = How.ID, using = Locator.BACK_TO_ADHOC_REPORT_LINK)
	public WebElement backToAdhocReportLink;
	@FindBy(how = How.ID, using = Locator.SCHEDULED_REPORT_SUB_MENU)
	public WebElement scheduledReportMenu;
	@FindBy(how = How.ID, using = Locator.ADD_SCHEDULE_REPORT_BUTTON)
	public WebElement addScheduledReportBtn;
	@FindBy(how = How.XPATH, using = Locator.SCHEDULE_REPORT_MAINTENANCE_PAGE)
	public WebElement scheduledReportMaintenancePage;
	@FindBy(how = How.ID, using = Locator.SCHEDULE_REPORT_TYPE)
	public WebElement scheduledReportType;
	@FindBy(how = How.XPATH, using = Locator.SCHEDULE_REPORT_TYPE_DROPDOWN)
	public WebElement scheduledReportTypeDropdown;
	@FindBy(how = How.ID, using = Locator.DESCRIPTION_COMMON)
	public WebElement scheduleName;
	@FindBy(how = How.XPATH, using = Locator.SCHEDULE_FREQUENCY_DROPDOWN)
	public WebElement scheduleFrequency;
	@FindBy(how = How.XPATH, using = Locator.SCHEDULE_DELIVERY_TYPE)
	public WebElement scheduleDeliveryType;
	@FindBy(how = How.XPATH, using = Locator.SCHEDULE_CONTACT_RANKING_TYPE)
	public WebElement scheduleContactRankingDropDown;
	@FindBy(how = How.ID, using = Locator.EMAIL_FIELD)
	public WebElement emailField;
	@FindBy(how = How.ID, using = Locator.SCHEDULE_SAVE_BUTTON)
	public WebElement scheduleSaveBtn;
	@FindBy(how = How.ID, using = Locator.CONFIRMATIONMESSAGE)
	public WebElement successMsg;
	@FindBy(how = How.ID, using = Locator.BACK_TO_SCHEDULE_REPORT_LINK)
	public WebElement backToScheduleReportLink;
	@FindBy(how = How.XPATH, using = Locator.SCHEDULED_REPORT_RUN_PAGE_HEADER)
	public WebElement scheduleReportHeader;
	@FindBy(how = How.XPATH, using = Locator.SELECT_REPORT_TYPE_FROM_SCHEDULED_REPORT_PAGE)
	public WebElement selectReportFromScheduleReportPage;
	@FindBy(how = How.XPATH, using = Locator.SELECT_FREQUENCY_FROM_SCHEDULED_REPORT_PAGE)
	public WebElement selectFrequencyFromScheduleReportPage;
	@FindBy(how = How.ID, using = Locator.EMAIL_FIELD_FROM_SCHEDULED_REPORT_PAGE)
	public WebElement emailFieldFromScheduleReportPage;
	@FindBy(how = How.ID, using = Locator.CHECK_ENABLE_CHECKBOX)
	public WebElement checkEnableCheckBox;
	@FindBy(how = How.ID, using = Locator.SEARCH_BTN)
	public WebElement scheduleReportPageSearchBtn;
	@FindBy(how = How.ID, using = Locator.SEARCH_RESULT_DISPLAYED)
	public WebElement searchResultsDisplayed;
	@FindBy(how = How.ID, using = Locator.SCHEDULE_REPORT_EXPORT_BUTTON)
	public WebElement scheduleReportExportBtn;
	@FindBy(how = How.ID, using = Locator.SEARCH_CARDS)
	public WebElement storedReportSearchBtn;
	@FindBy(how = How.XPATH, using = Locator.STORED_REPORT_TYPE_DROPDOWN)
	public WebElement storedReportTypeDropDown;
	@FindBy(how = How.ID, using = Locator.DATE_PICKER_CREATED_FROM_CALENDAR_BUTTON)
	public WebElement createFromDatePickerBtn;
	@FindBy(how = How.ID, using = Locator.DATE_PICKER_CREATED_TO_CALENDAR_BUTTON)
	public WebElement createToDatePickerBtn;
	@FindBy(how = How.CSS, using = Locator.CALENDAR_HANDLE_DIALOG_BOX_FROM)
	public WebElement calendarDialogBoxFrom;
	@FindBy(how = How.CSS, using = Locator.CALENDAR_HANDLE_DIALOG_BOX_TO)
	public WebElement calendarDialogBoxTo;
	@FindBy(how = How.XPATH, using = Locator.STORED_REPORT_HEADER)
	public WebElement storedReportHeader;
	@FindBy(how = How.ID, using = Locator.ACCOUNTS_DROPDOWN)
	public WebElement selectAccountDropdown;
	@FindBy(how = How.XPATH, using = Locator.TABLE_EMPTY)
	public WebElement validateTableEmptyRecords;
	@FindBy(how = How.ID, using = Locator.SEARCH_RESULTS)
	public WebElement validateSearchRecords;
	@FindBy(xpath = Locator.COMMON_TITLE_SEC)
    public WebElement commonTitleSec;
	
	@FindBy(how = How.XPATH, using = Locator.DATE_TO)
    public WebElement dateTO;
    @FindBy(how = How.XPATH, using = Locator.DATE_FROM)
    public WebElement dateFrom;
    
    @FindBy(id = Locator.EMAIL_OR_PHONENO_TEXT_BOX)
	public WebElement emailOrPhoneTextBox;
	@FindBy(xpath = Locator.NEXT_BUTTON_GMAIL)
	public WebElement nextButtonInGmail;
	@FindBy(name = Locator.USER_NAME_GMAIL)
	public WebElement userNameInGmail;
	@FindBy(name = Locator.PASS_WORD_GMAIL)
	public WebElement passWordInGmail;
	@FindBy(id = Locator.SIGN_IN_BUTTON_GMAIL)
	public WebElement signInButtonGmail;

    
    @FindBy(xpath = Locator.MERCHANT_RECONCILIATION_REPORT)
	public WebElement merchantReconciliationReport;
    
    @FindBy(how = How.XPATH, using = Locator.Z_DELIVERY_ADDRESS) 
	public WebElement deliveryEmailAddress;
	
	@FindBy(how = How.XPATH, using = Locator.Z_DELIVERY_SUCCESS_MSG) 
	public WebElement deliverySuccessMsg;
	
	@FindBy(how = How.ID, using = Locator.REPORT_GENERATE)
	public WebElement reportGenerate;
	
	public MerchantReportsPage(WebDriver driver, ExtentTest test) {
		super(driver, test);
		// TODO Auto-generated constructor stub
		PageFactory.initElements(driver, this);
	}

	public void clickAdhocReportPageAndValidate() {
		clickSubMenuAndValidate(reportMenu, adhocReportSubMenu, adhocReportTitle);

	}

	public void clickAdhocExportLinkBtn(String text) {
		isDisplayedThenActionClick(adhocReportExportLink, "Export Button Link");
		sleep(5);
		verifyTheDownloadedFile(text);
	}

	public void clickStoredReportPageAndValidate() {
		clickSubMenuAndValidate(reportMenu, storedReportPage, reportTitleHeader);
	}

	public void clickStoredReportSearchBtn() {
		isDisplayedThenActionClick(ReportSearchBtn, "Search Button");
	}

	public void clickStoredReportExportLinkBtn(String text) {
		isDisplayedThenActionClick(storedReportExportLink, "Export Button Link");
		sleep(5);
		verifyTheDownloadedFile(text);
	}

	public void clickInvoiceReportPageAndValidate() {
		sleep(3);
		clickSubMenuAndValidate(reportMenu, invoicesReportPage, reportTitleHeader);
	}
	
	public void clickInvoiceReports() {
		sleep(3);
		driver.findElement(By.xpath("//a[text()='Reports']")).click();
		sleep(3);
		WebElement element=driver.findElement(By.xpath("//a[text()='Invoices']"));
		isDisplayedThenClick(element, "Invoices");
	}

	public void clickInvoiceReportSearchBtn() {
		isDisplayedThenActionClick(ReportSearchBtn, "Search Button");
		sleep(3);
	}
	
	public void clickInvoiceReportSearchButton() {
		isDisplayedThenClick(searchButton, "Search Button");
		sleep(3);
	}

	public void clickInvoiceReportExportLinkBtn(String text) {
		isDisplayedThenActionClick(invoicesReportExportBtn, "Export Button Link");
		sleep(5);
		verifyTheDownloadedFile(text);
	}

	public void clickStatementPageAndValidate() {
		clickSubMenuAndValidate(reportMenu, statementReportPage, reportTitleHeader);
		sleep(3);
	}

	public void clickMercStatementPageSearchBtn() {
		isDisplayedThenActionClick(scheduleReportPageSearchBtn, "Search Button");
		scrollUpPage();
		sleep(3);
	}

	public void clickLocStatementPageSearchBtn() {
		isDisplayedThenActionClick(storedReportSearchBtn, "Search Button");
		scrollUpPage();
		sleep(3);
	}

	public void clickStatementPageExportLinkBtn(String text) {
		isDisplayedThenActionClick(statementReportExportLink, "Export Button Link");
		sleep(5);
		verifyTheDownloadedFile(text);
	}

	public void iterateAndClickFromAdhocReportTable() {
		int listSize = adhocReportTableList.size();
		System.out.println("Size of Dropdown" + listSize);
		for (WebElement selectReport : adhocReportTableList) {
			String reportDescription = selectReport.getText();
			System.out.println("ReportDescription:::::" + reportDescription);
			if (reportDescription.contains("Merchant Reconciliation Report")) {
				isDisplayedThenActionClick(selectReport, "Report selected");
				break;
			}
		}
	}

	public void validateAdhocReportRunPage() {
		//verifyText(adhocReportRunPageHeader, "Ad Hoc Report List");
		try {
			WebDriverWait wait = new WebDriverWait(driver, 10);
			wait.until(ExpectedConditions.textToBePresentInElement(adhocReportRunPageHeader,"Ad Hoc Report"));
			if(adhocReportRunPageHeader.getText().trim().contains("Ad Hoc Report")){
				logPass("Ad Hoc Report Test Present");
			}else {
				logPass("Ad Hoc Report Text not Present");	
			}
		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
	//verifyText(adhocReportRunPageHeader, "Ad Hoc Report Run");
	}

	public void clickBackToAdhocReportLinkAndValidate() {
		isDisplayedThenActionClick(backToAdhocReportLink, "Back to Adhoc Report Link");
		sleep(1);
		isDisplayed(adhocReportTitle, "Adhoc Report Page");

	}

	public void clickScheduledReportPageAndValidate() {

		clickSubMenuAndValidate(reportMenu, scheduledReportMenu, reportTitleHeader);
		sleep(1);

	}

	public void clickAddScheduledReportButtonAndValidate() {
		isDisplayedThenActionClick(addScheduledReportBtn, "Add a Scheduled Report Button");
		isDisplayed(scheduledReportMaintenancePage, "Scheduled Reports Maintenance Page");

	}

	/**
	 * Check all Fields in Schedule Maintenance Page
	 * 
	 * @return
	 */

	public void selectAllFieldsFromScheduledMaintenancePage() {
		selectDropDownByVisibleText(scheduledReportTypeDropdown, "Merchant Reconciliation Report");
		sleep(3);
		isDisplayedThenEnterText(scheduleName, "Enter Schedule Name", fakerAPI().name().name());
		selectInputFromDropdown(scheduleFrequency, 1);
		selectInputFromDropdown(scheduleDeliveryType, 1);
		selectInputFromDropdown(scheduleContactRankingDropDown, 1);
		sleep(3);
		/*
		 * String emailId = FakerAPI().internet().emailAddress();
		 * isDisplayedThenEnterText(emailField, "Enter Email field", emailId); return
		 * emailId;
		 */
	}

	public void clickScheduledSaveButtonAndValidate() {

		isDisplayedThenClick(scheduleSaveBtn, "Click Scheduled Save Button");
		sleep(3);
		isDisplayed(successMsg, "Success Message Displayed");
	}

	public void clickBackToScheduledReportLinkAndValidate() {
		isDisplayedThenActionClick(backToScheduleReportLink, "Click Back To Schedule Report Link");
		sleep(3);
		isDisplayed(scheduleReportHeader, "Scheduled Report Page");
	}

	public void selectAllFieldsFromScheduledReportPage(String createdEmailAddress) {
		selectDropDownByVisibleText(selectReportFromScheduleReportPage, "Merchant Reconciliation Report");
		sleep(3);
		selectInputFromDropdown(selectFrequencyFromScheduleReportPage, 1);
		isDisplayedThenEnterText(emailFieldFromScheduleReportPage, "Enter Schedule Report Email field",
				createdEmailAddress);
	}

	/**
	 * Check the Enabled Check Box
	 * 
	 * @throws Exception
	 */
	public void checkEnabledCheckbox() {
		try {
			if (!(checkEnableCheckBox.isSelected())) {
				actionClick(checkEnableCheckBox);
			}
			if (checkEnableCheckBox.isSelected()) {
				logPass("Contact set as default");
			} else {
				logFail("Contact not set as default");
			}
		} catch (Exception e) {
			logFail(e.getMessage());
		}
	}

	public void clickScheduledReportSearchBtnAndValidate() {
		isDisplayedThenActionClick(scheduleReportPageSearchBtn, "Click Search Button");
		sleep(3);
		scrollDownPage();
		sleep(1);
		boolean textCheck = waitForTextToAppear("No scheduled report found.", 20);
		if(textCheck) {
			logInfo("There is no scheduled report for this report type");
		} else {
			isDisplayed(searchResultsDisplayed, "Table Results displayed");
			
		}	
	}

	public void clickScheduledReportExportBtnAndValidate() throws Exception {
		isDisplayedThenActionClick(scheduleReportExportBtn, "Click Search Button");
		sleep(3);
	}

	public void selectReportFromTableAndValidate() {
		isDisplayedThenActionClick(searchResultsDisplayed, "Select search results");
		sleep(5);
		verifyText(scheduledReportMaintenancePage, "Scheduled Reports Maintenance");
	}

	public void validateStoredReportHeader() {
		verifyText(storedReportHeader, "Stored Reports");
	}

	public void editScheduleNameSaveAndValidate() {
		isDisplayedThenEnterText(scheduleName, "Enter Schedule Name", fakerAPI().name().name());
		clickScheduledSaveButtonAndValidate();

	}

	public void selectReportTypeSearchFromStoredReportAndValidate() {

		selectDropDownByVisibleText(storedReportTypeDropDown, "Merchant Reconciliation Report");
		isDisplayedThenActionClick(storedReportSearchBtn, " Click Search Button");
		sleep(3);

	}

	/**
	 * Select Date using Calendar control - Added by Meenakshi
	 * 
	 * @throws Exception
	 */

	public void selectCreatedFromDateUsingCalendarControl() {
		sleep(3);
		selectDateFromCalendarControl(createFromDatePickerBtn, calendarDialogBoxFrom, "11/June/2012");

	}

	public void selectCreatedToDateUsingCalendarControl() {
		selectDateFromCalendarControl(createToDatePickerBtn, calendarDialogBoxTo, "12/August/2012");

	}

	public void selectDateFromCalendarControl(WebElement datePicketButton, WebElement calenderDialogBox, String date) {
		try {
			DateFormat simpleDateFormat = new SimpleDateFormat("dd/MMM/yyyy");
			Date selectDate = simpleDateFormat.parse(date);

			pickDate(selectDate, datePicketButton, calenderDialogBox);
			sleep(1);

		}

		catch (ParseException pe) {
			logFail(pe.getMessage());
		} catch (Exception e) {
			logFail(e.getMessage());
		}

	}

	public void enterEmailAddressSaveAndValidate() {

		String emailId = fakerAPI().internet().emailAddress();
		isDisplayedThenEnterText(emailField, "Enter Email field", emailId);
		sleep(3);
		/*
		 * isDisplayed(emailField, "Enter Email field"); emailField.sendKeys(emailId);
		 */
		clickScheduledSaveButtonAndValidate();
		clickBackToScheduledReportLinkAndValidate();
		selectAllFieldsFromScheduledReportPage(emailId);
	}

	public void selectStaticAccount() {

		selectDropDownByVisibleText(selectAccountDropdown, " L.V. DOHNT & CO. PTY. LIMITED  (9000000471)");
		sleep(3);

	}

	public void validateInvoiceSearchRecords() {
		try {
			validateSearchRecords.isDisplayed();
			// isDisplayed(validateSearchRecords, "Search Results");
			logPass("Search Result displayed in the table");
		} catch (Exception ex) {
			verifyText(validateTableEmptyRecords, "No stored report found.");
			logPass("No Records Displayed as it dependent towards IFCS Desktop");
		}
	}
	
	public ArrayList<String> validateAdhocTableDescription() {
		ArrayList<String> listOfDescription =new ArrayList<String>();
		List<WebElement> adhoctable=driver.findElements(By.xpath("//tbody[@id='lform:avaliableReport:tb']//tr"));
		String adhocDescription;
		for(int i=0;i<adhoctable.size();i++) {
			adhocDescription=driver.findElement(By.xpath("//tr[@id='lform:avaliableReport:"+i+"']//p")).getText();
			//System.out.println("Adhoc Description ::"+adhocDescription);
			listOfDescription.add(adhocDescription);
		}
		return listOfDescription;
	}
	
	public String getSheetNameForAdhocReport() {
		
		 String dateFormat=getDateInFormat( new Date(),"yyyyMM");
		String sheetName="00007618"+"_avaliableReport_"+dateFormat;
		System.out.println("sheetName::"+sheetName);
		return sheetName;
	}
	
	public void clickRunAReport(){
		clickSubMenuAndValidate(reportMenu,adhocReportSubMenu,commonTitleSec);
	}
	
	public void clickMerchantReconciliationReport(){
	    isDisplayedThenClick(merchantReconciliationReport,"Clicking on Merchant Reconciliation Report");
    }
	
	public void enterFromAndToDates(String fromDate, String toDate){
        enterText(dateFrom,fromDate);
        enterText(dateTO,toDate);
    }
	
	/*
	   Method to convert the encoded password to decode
	    */
		private String getDecodePassword(String encodedPassword){
			byte[] decyptedPasswordBytes = Base64.getDecoder().decode(encodedPassword);
			return new String(decyptedPasswordBytes);
		}
	
	/*
	  Method to login gmail using valid username and password
	   */
		public void loginToGmail(String userName, String passWord){
			driver.navigate().to("https://www.gmail.com");
			sleep(2);
			enterText(emailOrPhoneTextBox,userName);
			isDisplayedThenClick(nextButtonInGmail,"Next Button in Gmail");
			enterText(userNameInGmail,userName);
			enterText(passWordInGmail,getDecodePassword(passWord));
			isDisplayedThenClick(signInButtonGmail,"Click Sign in button in gmail");
		}
		
		public void clickOnGeneratedEmailMerchatReconciliationReport(String[] subjectContains){
			        List<WebElement> a = driver.findElements(By.cssSelector("div[class='xS']>div>div>span"));
			        System.out.println(a.size());
			        for(int i=0;i<a.size();i++) {
						System.out.println(a.get(i).getText());
						for (String subject : subjectContains) {
							if (a.get(i).getText().contains(subject)) {  // if u want to click on the specific mail then here u can pass it
								logInfo("Email is generated");
								a.get(i).click();
							}
						}
					}
			        isDisplayed(driver.findElement(By.cssSelector("div[id=':10h']")),"Checking report is attached to generated email or not");
				}
		
		public void enterDeliveryMailAdressAndClickGenerateButton(String emailAddress) {
			
			isDisplayedThenEnterText(deliveryEmailAddress, "Delivery Adress is displayed",emailAddress );

			isDisplayedThenClick(reportGenerate,"Generate Report is Displayed and Clicked");	
			
			isDisplayed(deliverySuccessMsg, "Report send successfully");
			
			logInfo("Report send successfully");
		}
}
