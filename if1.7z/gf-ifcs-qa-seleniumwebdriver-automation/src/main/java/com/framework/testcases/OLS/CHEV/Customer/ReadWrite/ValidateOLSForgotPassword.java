package com.framework.testcases.OLS.CHEV.Customer.ReadWrite;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.CHEV.CHForgotPasswordPage;
import com.framework.pages.CHEV.CHLogonPage;
import com.framework.util.PropUtils;

public class ValidateOLSForgotPassword extends BaseTest {
	@Parameters({ "clientCountry", "clientName" })
	@Test(priority = 1)
	public void testCustomerReadWriteOLSForgotPassword(@Optional("TH") String clientCountry, @Optional("CHV") String clientName) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  Read / Write Only Forgot Password", "Chevron Customer Screens Read / Write Only");
			
		// Creating Objects for the Pages
		CHLogonPage chLogonPage = new CHLogonPage(driver, test);
		CHForgotPasswordPage chForgotPasswordPage = new CHForgotPasswordPage(driver, test);

		driver.get(PropUtils.getPropValue(configProp, "CHV_URL"));
		chLogonPage.clickOnForgotPwd();
		chForgotPasswordPage.verifyInstructions();
		if (clientCountry.equals("SG")||clientCountry.equals("MY")||clientCountry.equals("HK")) {
			chForgotPasswordPage.enterUserId(PropUtils.getPropValue(configProp, "CHV_Customer_UN_RW_FP_"+clientCountry));
		} else if (clientCountry.equals("TH")) {
			chForgotPasswordPage.enterUserId(PropUtils.getPropValue(configProp, "CHV_Customer_UN_RW_FP_"+clientCountry));
		} else if (clientCountry.equals("PH")) {
			chForgotPasswordPage.enterUserId(PropUtils.getPropValue(configProp, "CHV_Customer_UN_RW_FP_"+clientCountry));
		}
		chForgotPasswordPage.clickSubmitBtn();
		chForgotPasswordPage.checkConfirmationMessage();		
	}
}
