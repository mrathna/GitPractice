﻿using Common;
using Common.Utility;
using EnCompass.Testing.Source.PageObjects;
using EnCompass.Testing.Source.PageObjects.Controls;
using NFluent;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace EnCompass.Testing.Source.PageObjects.Organization.Admin.Announcements
{
    [PageModel(@"/Announcements/Admin.aspx?bank=1")]
    public class Admin : EnCompassPageModel
    {
        #region xpath 

        public override string RelativeUrl => @"/Announcements/Admin.aspx";
        public override string PageIdentifierXPath_Override => @"//li[contains(@class, 'breadcrumb-item active')][contains(text(), 'Announcements')]";

        private const string _noAnnouncementMessageXPath = "//td[contains(@class,'NoRecords')][text()='No Announcements found.']";
        private const string _createBtnXPath = "//a[@role='button']/i[contains(@class,'actionItemImage')]";
        private const string _headerTextXPath = "//h1[@role='banner']";
        private const string _tblTableXPath = "//table[contains(@id,'dgCurrent')]";
        private const string _btnAnnouncementXPath = @"//a[contains(@id,'actionLink0')]";
        private const string _successTextXPath = @"//div[contains(@id,'SuccessMessage')]/p";
        private const string _emailTextXPath = @"//div[contains(@id,'SuccessMessage')]/ul/li[contains(text(),'email')]";
        private const string _emailHistoryXPath = @"//a[text()='Email History']";
        private const string _emailUserNameXPath = @"//table[contains(@id,'BroadcastHistory')]//tbody/tr/td[1]";
        private const string _lnkReplaceXPath = "//a[contains(.,'Replace')]";
        private const string _lnkBackXPath = "//a[contains(@id,'lnkBack')]";

        #endregion


        #region IWebElements Props

        public IWebElement _noAnnouncementMessage
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_noAnnouncementMessageXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Debug("Found _noAnnouncementMessage");
                return element;
            }
        }

        public IWebElement _createBtn
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_createBtnXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Debug("Found _createBtn");
                return element;
            }
        }

        public IWebElement _headerText
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_headerTextXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Debug("Found _headerText");
                return element;
            }
        }

        public IWebElement _tblTable
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_tblTableXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Debug("Found _tblTable");
                return element;
            }
        }

        public IWebElement _btnAnnouncement
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_btnAnnouncementXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Debug("Found _btnAnnouncement");
                return element;
            }
        }

        public IWebElement _successText
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_successTextXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Debug("Found _successText");
                return element;
            }
        }

        public IWebElement _emailText
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_emailTextXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Debug("Found _emailText");
                return element;
            }
        }

        public IWebElement _emailHistory
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_emailHistoryXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Debug("Found _emailHistory");
                return element;
            }
        }

        public IWebElement _emailUserName
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_emailUserNameXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Debug("Found _emailUserName");
                return element;
            }
        }

        public IWebElement _lnkReplace
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_lnkReplaceXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Debug("Found _lnkReplace");
                return element;
            }
        }

        #endregion
        
        public void ClickOnReplace()
        {
            _lnkReplace.JSClickWithFocus(Driver);
            Settings.EnCompassExtentTest.Info("Clicked Replace button");
        }

        private GridControl _announcementGrid;
        public GridControl AnnouncementGrid
        {
            get
            {
                _announcementGrid = new GridControl("dgCurrent", Driver);
                _announcementGrid.WaitForGrid();
                return _announcementGrid;
            }
        }
        public void ClickEmaiHistory()
        {
            _emailHistory.JSClickWithFocus(Driver);
            Settings.EnCompassExtentTest.Info("Clicked Email history button");
            Driver.WaitElementBeClickable("//a[contains(@id,'lnkBack')]");
            this.AttachOnDemandScreenShot();
        }


        public string EmailHistoryTestName
        {
            get
            {
                return _emailUserName.Text;
            }
        }

        public String EmailEnabledSuccessmessage
        {
            get{

                return _emailText.Text;
            }
        }       

        public void NavigateToOrganizationSpecificAnnouncementPage()
        {
            string orgName = Settings.Scenario["OrganizationName"].ToString();
             IWebElement _orgAnnouncement = Driver.FindElement(By.XPath("//ul[contains(@id,'menuItems')]/li/a[text()='"+orgName+"']"));
            _orgAnnouncement.JSClickWithFocus(Driver);
            Settings.EnCompassExtentTest.Info("Selected organization specific announcement");
            Driver.WaitForDocumentLoadToComplete();                      
        }            

        public void ClickOnEdit()
        {
            _btnAnnouncement.JSClickWithFocus(Driver);
            Settings.EnCompassExtentTest.Info("Clicked on Edit Button for edit Announcement");
        }     
    
        public bool IsNoAnnouncementTextPreset()
        {
            return _noAnnouncementMessage.Displayed;
        }

        public void NavigateToCreateAnnouncementPage()
        {            
            _createBtn.JSClickWithFocus(Driver);            
            Settings.EnCompassExtentTest.Info("Clicked create button");
        }

        public string HeaderText
        {
            get
            {
                return _headerText.Text.ToLower();                
            }
        }        
        
        public Admin(GlobalSettings settings) : base(settings){}
     
    }
}
