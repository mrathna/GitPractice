using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using Common;
using Common.PageObjects;
using Common.ScenarioConfigurations;
using Common.Utility;

namespace EnCompass.Testing.Source.PageObjects.Organization.ExpenseManager.FiscalCalendar 
{
	/// <summary>
	/// Auto-generated Page Model Class
	/// Navigation Paths: 
		/// [Organization Home]->Transactions->Fiscal Calendar
		/// </summary>
	[PageModel(@"/expenseManager/fiscalCalendar/FiscalCalendar.aspx")]
	public partial class FiscalCalendar : EnCompassOrgPageModel 
	{
		public override string RelativeUrl => @"/expenseManager/fiscalCalendar/FiscalCalendar.aspx";
		public override string PageIdentifierXPath_Generated => @"//li[contains(@class, 'breadcrumb-item active')][text() = 'Fiscal Calendar']";

		#region Navigation
		
		private void NavigateToMenuItem(IWebElement element)
		{
			Driver.Url = element.GetAttribute("href");
		}
		#endregion

		public FiscalCalendar(GlobalSettings settings) : base(settings) { }
	}  
}
