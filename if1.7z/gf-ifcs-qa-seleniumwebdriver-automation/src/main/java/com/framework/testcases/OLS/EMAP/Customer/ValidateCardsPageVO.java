package com.framework.testcases.OLS.EMAP.Customer;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.EMAP.EMAPCardsPage;
import com.framework.pages.EMAP.EMAPHomePage;
import com.framework.pages.OLS.common.CommonPage;
import com.framework.pages.OLS.common.FindAndUpdateCardPage;
import com.framework.pages.OLS.common.LoginPage;

public class ValidateCardsPageVO extends BaseTest {
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "Regression" })
	public void validateCardsMenuPageForViewOnlyStatusChangeCustomer(@Optional("SP") String clientCountry,
			@Optional("EMAP") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  TST-SC-82-OLS - cards menu,TST-SC-92-OLS-Card List-View Card",
				"Login to EMAP Customer - View Only Status Change - Search and View Card");
		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		loginPage.Login("EMAP_URL", "EMAP_UN_ViewOnly_Customer_" + clientCountry,
				"EMAP_PWD_ViewOnly_Customer_" + clientCountry, clientName);

		EMAPHomePage emapHomePage = new EMAPHomePage(driver, test);
		EMAPCardsPage emapCardsPage = new EMAPCardsPage(driver, test);
		CommonPage commonPage = new CommonPage(driver, test);

		emapHomePage.validateEMAPCustomerLogo();
		emapHomePage.validateCustomerWelcomeText();
		emapCardsPage.checkThePresenceOfSubmenuItemsInCardsMenu("View-Only");

		// Card List
		emapHomePage.clickCardListAndValidatePage();
		emapCardsPage.checkThePresenceOfExportCardOption();
		emapCardsPage.checkThePresenceOfSearchCardButton();
		commonPage.selectAllAccountOptionFromAccountDropdown();
		commonPage.clickSearchButton();
		emapCardsPage.verifyTheListOfCardsFoundTableColumn(clientCountry);
		emapCardsPage.checkThePresenceOfCardFilterCriteria(clientCountry);

		// Context menu options - View Card
		emapHomePage.clickCardListAndValidatePage();
		commonPage.selectAllAccountOptionFromAccountDropdown();
		commonPage.clickSearchButton();
		emapCardsPage.selectACardFromCardListTable(true);

		emapCardsPage.clickContextMenuOptionAndVerifyCardNumberInNavigatedPage("View Card");
		emapCardsPage.verifySubCategoriesOnViewCardPage("View Card");
		emapCardsPage.verifyTheCardDetailsAreInViewMode(clientCountry);
		emapCardsPage.verifyTheVelocityControlFieldValues();

		emapCardsPage.validateBackToCardListPageLink();

		// Bulk Card Update
		emapHomePage.clickBulkCardUpdateAndValidatePage();
		emapCardsPage.checkThePresenceOfBulkCardUpdateDownloadAndUpload();

		loginPage.Logout();
	}

	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "Regression" })
	public void validateCardsMenuPageChangeCardStatus(@Optional("SP") String clientCountry,
			@Optional("EMAP") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  TST-SC-95-OLS-Card List-Change Pin,TST-SC-94-OLS-Card List-Change Status",
				"Login to EMAP Customer - View Only Status Change - Change Card Status");
		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		loginPage.Login("EMAP_URL", "EMAP_UN_ViewOnly_Customer_" + clientCountry,
				"EMAP_PWD_ViewOnly_Customer_" + clientCountry, clientName);

		EMAPHomePage emapHomePage = new EMAPHomePage(driver, test);
		EMAPCardsPage emapCardsPage = new EMAPCardsPage(driver, test);
		CommonPage commonPage = new CommonPage(driver, test);
		FindAndUpdateCardPage findCardPage = new FindAndUpdateCardPage(driver, test);

		emapHomePage.validateEMAPCustomerLogo();
		emapHomePage.validateCustomerWelcomeText();
		emapCardsPage.checkThePresenceOfSubmenuItemsInCardsMenu("View-Only");

		emapHomePage.clickCardListAndValidatePage();
		commonPage.selectAllAccountOptionFromAccountDropdown();
		// Context menu options - Change Status - Future begin date
		emapCardsPage.selectACardStatus("Active");
		commonPage.clickSearchButton();
		emapCardsPage.selectACardFromCardListTable(true);
		emapCardsPage.clickContextMenuOptionAndVerifyCardNumberInNavigatedPage("Change Card Status");
		emapCardsPage.chooseANewCardStatus("Lost");
		emapCardsPage.clickSaveStatusChange();
		emapCardsPage.checkReplaceCardPopupContent("Lost");
		emapCardsPage.verifyCardStatusChangedSuccessMessage("Lost");
		emapCardsPage.validateBackToCardListPageLink();

		// Context menu options - Change Status - Future begin date
		emapHomePage.clickCardListAndValidatePage();
		commonPage.selectAllAccountOptionFromAccountDropdown();
		emapCardsPage.selectACardStatus("Active");
		commonPage.clickSearchButton();
		emapCardsPage.selectACardFromCardListTable(true);
		emapCardsPage.clickContextMenuOptionAndVerifyCardNumberInNavigatedPage("Change Card Status");
		emapCardsPage.chooseANewCardStatus("Stolen");
		emapCardsPage.clickSaveStatusChange();
		emapCardsPage.checkReplaceCardPopupContent("Stolen");// Anton updated 08.08.2018
		emapCardsPage.verifyCardStatusChangedSuccessMessage("Stolen");
		emapCardsPage.validateBackToCardListPageLink();

		// Change PIN - WBPT - 21227
		// Context menu options - ChangePin
		emapHomePage.clickCardListAndValidatePage();
		commonPage.selectAllAccountOptionFromAccountDropdown();
		emapCardsPage.selectACardStatus("Active");
		commonPage.clickSearchButton();
		// Select Card with PIN - card number chosen
		String cardNumberChoosen = emapCardsPage.selectACardWithPINFromCardListTable("Change PIN");
		emapCardsPage.clickContextMenuOptionAndVerifyCardNumberInNavigatedPage("Change PIN");

		findCardPage.getPINValuesFromDB(cardNumberChoosen);
		commonPage.typeNewPin();
		commonPage.typeconfirmPIN();
		// Save Change Button
		emapCardsPage.clickSaveNewPIN();
		// Handle Reissue Popup if present
		findCardPage.comparePINValues("Change PIN");

		// Resend PIN
		// Context menu options - Resend PIN
		emapHomePage.clickCardListAndValidatePage();
		commonPage.selectAllAccountOptionFromAccountDropdown();
		commonPage.clickSearchButton();
		emapCardsPage.selectACardWithPINFromCardListTable("Resend PIN");
		emapCardsPage.clickContextMenuOptionAndVerifyCardNumberInNavigatedPage("Resend PIN");
		emapCardsPage.validateBackToCardListPageLink();

		loginPage.Logout();

	}
}
