package com.framework.testcases.OLS.EMAP.Merchant;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.EMAP.EMAPHomePage;
import com.framework.pages.EMAP.EMAPSupportPage;
import com.framework.pages.OLS.common.LoginPage;
import com.framework.util.PropUtils;

public class ValidateHomePage extends BaseTest {
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "Regression" })
	public void validateHomePage(@Optional("SP") String clientCountry, @Optional("EMAP") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  TST-SC-88-OLS Merchant Site - Home Page",
				"Login to EMAP Merchant - Read Only User and check the home and change password page");
		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		EMAPHomePage emapHomePage = new EMAPHomePage(driver, test);
		loginPage.Login("EMAP_URL", "EMAP_UN_ReadOnly_Merchant_" + clientCountry,
				"EMAP_PWD_ReadOnly_Merchant_" + clientCountry, clientName);
		EMAPSupportPage supportPage = new EMAPSupportPage(driver, test);

		//emapHomePage.checkThePresenceOfQuickLinksOnHomePage("Merc-Read-Only");
		emapHomePage.checkThePresenceOfLoginUserNameAndLogoutLink();
		emapHomePage.checkThePresenceOfAccountInformationsOnHomePage();
		emapHomePage.clickChangePasswordUsernameDropdown();

		supportPage.checkTheLogonIdInPasswordMaintenance(
				PropUtils.getPropValue(configProp, "EMAP_UN_ReadOnly_Merchant_" + clientCountry));
		//supportPage.checkThePasswordResetFieldsAreEnabled();
		supportPage.validateThePasswordMaintenanceFields();

		// Validate Error Message - Without entering old password field
		supportPage.enterEmptyPwdValidNewPwdConfirmPwdAndValidate();
		supportPage.validateChangePasswordErrorMessage("password");

		// Validate Error Message - Without entering confirm password field
		supportPage.enterValidPwdNewPwdEmptyConfirmPwdAndValidate(
				PropUtils.getPropValue(configProp, "EMAP_PWD_ReadOnly_Merchant_" + clientCountry));
		supportPage.validateChangePasswordErrorMessage("confirm password");

		// Validate Error Message - Invalid confirm password field
		supportPage.enterValidPwdNewPwdInvalidConfirmPwdAndValidate(
				PropUtils.getPropValue(configProp, "EMAP_PWD_ReadOnly_Merchant_" + clientCountry));
		supportPage.validateChangePasswordErrorMessage("invalid confirm password");

		// Validate Success Message - Valid New Password
		// supportPage
		// .enterValidPwdNewPwdConfirmPwdAndValidateSuccessMessage("EMAP_PWD_ReadOnly_Location_"
		// + clientCountry);

		// Footer Links - Exxon Mobil Corporation link
		 //emapHomePage.clickExxonMobilCorporationInFooterAndValidatePage();

		// Footer Links - Contact Us
		emapHomePage.clickContactUsInFooterAndValidatePage();

		// Footer Links - Copyright
		emapHomePage.clickCopyRightAndValidatePage(clientName);

		// Footer Links - Terms And Condition
		emapHomePage.checkThePresenceOfTermsAndConditionInFooter();

		// Footer Links - Privacy Statement
		//emapHomePage.clickPrivacyPolicyAndValidatePage();

		// Footer Links - Client Logos
		emapHomePage.clickExxonMobilLogoAndValidatePage();
		//emapHomePage.clickEssoLogoAndValidatePage();
		emapHomePage.clickMobilLogoAndValidatePage();

		// Logout
		loginPage.Logout();

	}
}
