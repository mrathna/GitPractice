package com.framework.testcases.API;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basepage.BasePage;
import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.common.Common;
import com.framework.pages.AJS.common.IFCSHomePage;
import com.framework.pages.AJS.common.IFCSLoginPage;
import com.framework.pages.API.common.CardAPIMethods;
import com.framework.util.PropUtils;
import com.framework.util.PuttyUtils;
import com.github.javafaker.Faker;

public class ValidateCreateOrUpdateCardAPI extends BaseTest {

	/**
	 * Implemented by Nithya
	 * @param clientCountry
	 * @param clientName
	 * @param cardType
	 * @param cardProduct
	 * @param customerNo
	 * Business Flow ID:BF-053
	 */
	@Parameters({ "clientCountry", "clientName", "cardType", "carProduct", "customerNo" })
	@Test( groups = { "BusinessFlow" })
	public void orderCardComponent(@Optional("AU") String clientCountry, @Optional("BP") String clientName,
			@Optional("BP Plus cards") String cardType, @Optional("Fuelcard") String cardProduct,
			@Optional("Random") String customerNo) {

		test = extent.createTest(clientName+ ":" +clientCountry+" ID:BF-053 Create Card",
				"Create new card via API for " + "_" + cardProduct);
		
		CardAPIMethods cardAPIMethods = new CardAPIMethods(driver, test);

		IFCSLoginPage ifcsLoginPage = new IFCSLoginPage(driver, test);
		//Common common = new Common(driver, test);
		ifcsLoginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");

		cardAPIMethods.loginToAPIUser(
				PropUtils.getPropValue(configProp, "UserNameAPI" + "_" + clientName + "_" + clientCountry),
				PropUtils.getPropValue(configProp, "PassWordAPI" + "_" + clientName + "_" + clientCountry));
		cardAPIMethods.orderCard(clientName, clientCountry, customerNo, cardProduct, cardType);
		
		//BasePage bp = new BasePage(driver, test);
		String hostName = PropUtils.getPropValue(configProp, "PUTTY_HOST");
		String userName = PropUtils.getPropValue(configProp, "PUTTY_USERNAME");
		String passwordPutty = PropUtils.getPropValue(configProp, "PUTTY_PASSWORD");
		//PuttyUtils.puttyConnectionAndGetLastProcessedFileName(hostName, userName, bp.decryptText(passwordPutty,"lockUnlock"), PropUtils.getPropValue(configProp, "vinciiFileLocation"),"ARDis");
		//cardAPIMethods.runEmbossingJobinControlM(clientName, clientCountry);
		//cardAPIMethods.validateCardStatus();
		cardAPIMethods.logoutAPIUser();

	}
	
	

	/**
	 * Implemented by Nithya
	 * @param clientCountry
	 * @param clientName
	 * @param cardNo
	 * @param fromStatus
	 * @param toStatus
	 * @param replaceCard
	 */
	@Parameters({ "clientCountry", "clientName", "cardNo", "fromStatus", "toStatus","replaceCard" })
	@Test( groups = { "BusinessFlow" })
	public void updateCardStatusComponent(@Optional("AU") String clientCountry, @Optional("BP") String clientName,
			@Optional("Random") String cardNo, @Optional("Active") String fromStatus,
			@Optional("Lost") String toStatus,@Optional("No")String replaceCard) {

		/*test = extent.createTest(clientName+ ":" +clientCountry+"  Update Card Status",
				"Update card status via API for " + "_" + cardNo);*/
		CardAPIMethods cardAPIMethods = new CardAPIMethods(driver, test);
		IFCSLoginPage ifcsLoginPage = new IFCSLoginPage(driver, test);
		ifcsLoginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");

		cardAPIMethods.loginToAPIUser(
				PropUtils.getPropValue(configProp, "UserNameAPI" + "_" + clientName + "_" + clientCountry),
				PropUtils.getPropValue(configProp, "PassWordAPI" + "_" + clientName + "_" + clientCountry));
		cardAPIMethods.updateCardStatus(cardNo, fromStatus, toStatus, clientName, clientCountry,replaceCard);
		cardAPIMethods.logoutAPIUser();

	}
	
	/**
	 * @param clientCountry
	 * @param clientName
	 * Business Flow ID:BF-061
	 */
	
	@Parameters({ "clientCountry", "clientName"})
	@Test( groups = { "BusinessFlow" })
	public void updateCardStatusForBlockAndReplace(@Optional("AU") String clientCountry, @Optional("BP") String clientName) {

		test = extent.createTest(clientName+ ":" +clientCountry+" ID:BF-061 Update Card Status",
				"Customer raises a request to block the card in case of Block and Replace from salesforce");
		Common common = new Common(driver, test);
		IFCSHomePage ifcsHomePage = new IFCSHomePage(driver, test);
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		ifcsHomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);
		ifcsHomePage.gotoAdminMenuAndChooseClientGroup();
		common.goToOnlineUsers();
		common.searchTheCurrentUserOnOnlineUsers(
				PropUtils.getPropValue(configProp, "UserNameAPI" + "_" + clientName + "_" + clientCountry));
		String cardNo= common.getDriverCardNumberFromDB(clientName+clientCountry);
		System.out.println("Card No:"+cardNo);
		ifcsHomePage.addCustomerToUser(common.getCustomerNoForCardNumber(cardNo));
		updateCardStatusComponent(clientCountry, clientName, cardNo, "Normal Service", "Card Lost", "Yes");

	}
	
	
	
	
	/**
	 * @param clientCountry
	 * @param clientName
	 * Business Flow ID:BF-062
	 */
	
	@Parameters({ "clientCountry", "clientName"})
	@Test( groups = { "BusinessFlow" })
	public void updateCardStatusAsStolenAndReplace(@Optional("AU") String clientCountry, @Optional("BP") String clientName) {

		test = extent.createTest(clientName+ ":" +clientCountry+" ID:BF-062 Update Card Status",
				"Customer raises a request to block the card in case of  stolen (Temporary block) from salesforce");
		updateCardStatusComponent(clientCountry, clientName, "random", "Normal Service", "Stolen", "Yes");

	}
	
	/**
	 * @param clientCountry
	 * @param clientName
	 * Business Flow ID:BF-063
	 */
	
	@Parameters({ "clientCountry", "clientName"})
	@Test( groups = { "BusinessFlow" })
	public void updateCardStatusAsDamagedAndReplace(@Optional("AU") String clientCountry, @Optional("BP") String clientName) {

		test = extent.createTest(clientName+ ":" +clientCountry+" ID:BF-063 Update Card Status",
				"Customer raises a request to block the card in case of damaged (Permanent block)");
		updateCardStatusComponent(clientCountry, clientName, "random", "Normal Service", "Damaged", "Yes");

	}
	
	/**
	 * @param clientCountry
	 * @param clientName
	 * Business Flow ID:BF-063
	 */
	
	@Parameters({ "clientCountry", "clientName"})
	@Test( groups = { "BusinessFlow" })
	public void updateCardStatusAsDeletedAndNoReplace(@Optional("AU") String clientCountry, @Optional("BP") String clientName) {

		test = extent.createTest(clientName+ ":" +clientCountry+" ID:BF-063 Update Card Status",
				"");
		updateCardStatusComponent(clientCountry, clientName, "random", "100 Normal Service", "901 Destroyed", "No");

	}

	/**
	 * Implemented by Nithya
	 * @param clientCountry
	 * @param clientName
	 * @param cardNo
	 * @param fieldName
	 * @param value
	 * @param replaceCard
	 */
	@Parameters({ "clientCountry", "clientName", "cardNo", "fieldName", "value","replaceCard" })
	@Test( groups = { "BusinessFlow" })
	public void updateCardComponent(@Optional("AU") String clientCountry, @Optional("BP") String clientName,
			@Optional("Random") String cardNo, @Optional("No Transactions") String cardStatus,@Optional("Random") String fieldName, @Optional("Random") String value, @Optional("No")String replaceCard) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  Update Card " + cardNo,
				"Update card via API for " + "_" + cardNo);

		CardAPIMethods cardAPIMethods = new CardAPIMethods(driver, test);
		IFCSLoginPage ifcsLoginPage = new IFCSLoginPage(driver, test);

		ifcsLoginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");

		cardAPIMethods.loginToAPIUser(
				PropUtils.getPropValue(configProp, "UserNameAPI" + "_" + clientName + "_" + clientCountry),
				PropUtils.getPropValue(configProp, "PassWordAPI" + "_" + clientName + "_" + clientCountry));
		cardAPIMethods.updateCardValue(cardNo, fieldName, value, "No Transactions", clientName, clientCountry,replaceCard);
		cardAPIMethods.logoutAPIUser();
	}
	
	

	/**
	 * Implemented by Nithya
	 * @param clientCountry
	 * @param clientName
	 * @param cardNo
	 * @param fromCustomer
	 * @param toCustomer
	 */
	@Parameters({ "clientCountry", "clientName", "cardNo", "fromCustomer", "toCustomer" })
	@Test( groups = { "BusinessFlow" })
	public void cardTransfer(@Optional("AU") String clientCountry, @Optional("BP") String clientName,
			@Optional("Random") String cardNo, @Optional("Random") String fromCustomer,
			@Optional("Random") String toCustomer) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  Transfer Card " + cardNo ,
				"Transfer card via API for " + "_" + cardNo);

		CardAPIMethods cardAPIMethods = new CardAPIMethods(driver, test);
		IFCSLoginPage ifcsLoginPage = new IFCSLoginPage(driver, test);

		ifcsLoginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");

		cardAPIMethods.loginToAPIUser(
				PropUtils.getPropValue(configProp, "UserNameAPI" + "_" + clientName + "_" + clientCountry),
				PropUtils.getPropValue(configProp, "PassWordAPI" + "_" + clientName + "_" + clientCountry));
		cardAPIMethods.transferCards(clientName, clientCountry, cardNo, fromCustomer, toCustomer);
		cardAPIMethods.logoutAPIUser();
	}
}
