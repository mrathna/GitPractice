﻿using Common.Utility;
using EnCompass.Testing.Source.PageObjects.Controls;
using NFluent;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;

namespace EnCompass.Testing.Source.PageObjects.Organization.ReportStudio.MyAndStandard
{
    public partial class ManageOrgScheduledReports
    {
        #region XPATH

        private const string _btnSearchXPath = @"//input[contains(@id,'btnSearch')]";
        private const string _viewQueueHistoryXPath = @"//a[contains(@id,'actionLink0')]";
        private const string _backScheduledReportsXPath = @"//a[contains(@id,'lnkShowScheduledReports')]";

        #endregion

        #region IWebElements

        public IWebElement _btnSearch
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_btnSearchXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_btnSearch element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        public IWebElement _viewQueueHistory
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_viewQueueHistoryXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_viewQueueHistory element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        public IWebElement _backScheduledReports
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_backScheduledReportsXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_backScheduledReports element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }


        #endregion
        
        public void Search()
        {
            _btnSearch.JSClickWithFocus(Driver);
        }

        public void BackScheduledReports()
        {
            _backScheduledReports.JSClickWithFocus(Driver);
            WaitForLoad();
        }

        public void ViewQueueHistory()
        {
            _viewQueueHistory.JSClickWithFocus(Driver);
            WaitForLoad();
        }

        private GridControl _reportScheduledResults;
        public GridControl ReportScheduledResults
        {
            get
            {
                var grid = _reportScheduledResults ?? (_reportScheduledResults = new GridControl("dgOrgScheduledReports", Driver));
                grid.WaitForGrid();
                return grid;
            }
        }
    }
}
