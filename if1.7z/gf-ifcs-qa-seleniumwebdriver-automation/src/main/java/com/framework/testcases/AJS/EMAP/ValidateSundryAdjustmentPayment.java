package com.framework.testcases.AJS.EMAP;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.CardMaintenancePage;
import com.framework.pages.AJS.MaintainAccountPage;
import com.framework.pages.AJS.TransactionListPage;
import com.framework.pages.AJS.common.Common;
import com.framework.pages.AJS.common.IFCSHomePage;
import com.framework.pages.AJS.common.IFCSLoginPage;
import com.github.javafaker.Faker;

public class ValidateSundryAdjustmentPayment extends BaseTest {
	
	@Parameters({ "clientCountry", "clientName"})
	@Test(groups = { "Regression" })
	public void ValidateSundryAdjustmentPostPayment(@Optional("SG") String clientCountry,
			@Optional("EMAP") String clientName) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  2-Verfiy that the sundry adjustment payment can be posted and seen in the transaction list",
				"2-Verfiy that the sundry adjustment payment can be posted and seen in the transaction list");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		
	
		Common common = new Common(driver, test);
		MaintainAccountPage maintainAccountPage=new MaintainAccountPage(driver,test);
		
		TransactionListPage transactionListPage=new TransactionListPage(driver,test);
		
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		
		IFCSloginPage.login("IFCS_URL_"+clientName, "IFCS_"+clientName+"_USERNAME", "IFCS_"+clientName+"_PASSWORD");
		IFCSHomePage.gotoApplicationAndClickApplicationMenu();
		IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);
		common.chooseApplicationNumberFromApplicationList("Approved");  // changed to Approved from TL APP approved
		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		common.chooseCustomerNumberFromCustomerList();
		IFCSHomePage.gotoAccountAndClickAccountDetails();
		// Get current Date
				 String currentDate = common.getCurrentIFCSDateFromDB(clientName+clientCountry);
				 // Get the IFCS current date 
				 String ifcsCurrentDate = common.enterADateValueInStatusBeginDateField("Current", currentDate);
				 Faker fakerN = new Faker();
				 String f_referenceNo = fakerN.number().digits(3);
				 maintainAccountPage.validatePostSundryAdjustmentTransaction(clientName,ifcsCurrentDate,f_referenceNo);
				 IFCSHomePage.gotoTransactionAndClickManageTransaction();
				 transactionListPage.validatePostedSundryadjustmentTransaction(ifcsCurrentDate,f_referenceNo);
				 IFCSHomePage.exitIFCS();
		
	}
	
	
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "Regression" })
	public void ValidateToCreateManualTransaction(@Optional("SG") String clientCountry,
			@Optional("EMAP") String clientName) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  TST-SC-10-Create a manual transaction without authorization request",
				"Verify TST-SC-10-Create a manual transaction without authorization request");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);

		Common common = new Common(driver, test);

		TransactionListPage transactionListPage = new TransactionListPage(driver, test);

		IFCSloginPage.login("IFCS_URL_EMAP", "IFCS_EMAP_USERNAME", "IFCS_EMAP_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry," ");
		Faker fakerN = new Faker();
		String f_referenceNo = fakerN.number().digits(3);
		String currentDate = common.getCurrentIFCSDateFromDB(clientName+clientCountry);
		// Get the IFCS current date
		String ifcsCurrentDate = common.enterADateValueInStatusBeginDateField("Current", currentDate);
		System.out.println("Date ::"+ifcsCurrentDate);
		String cardNo = common.getActiveCardsWithBalanceAndRowIndex(1);
		String cardNo2 = common.getActiveCardsWithBalanceAndRowIndex(2);
        String locationNo=common.chooseALocationWithNonFuelProduct("Y");
		String productCode=common.chooseANonFuelProductExtCodeInTheLocation(locationNo,"Y","externalCode");
		if (cardNo.equals(" ") && cardNo2.equals(" ") && locationNo.equals(" ") && productCode.equals(" ")){
			common.logForNoDataFound(this.getClass().getSimpleName(),
					"Need to Create A Cards with Account and rerun");
		} else {
			
		
			
		IFCSHomePage.gotoApplicationAndClickApplicationMenu();
		IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);
		IFCSHomePage.gotoTransactionAndClickManageTransaction();
		
		//transactionListPage.validateToPostManualTransactionEntry(ifcsCurrentDate,f_referenceNo,clientCountry,cardNo,cardNo2,locationNo,productCode,true);
		transactionListPage.enterTransactionBatchDetails(true,"160","1",clientName);
		transactionListPage.enterManualTransactionDetails(ifcsCurrentDate,f_referenceNo,cardNo,cardNo2,locationNo,"160","");
		transactionListPage.enterTransactionLineItems(productCode,"160","100","160");
		transactionListPage.validatePostManualTransaction("Validation successful");
		transactionListPage.validatePostSuspendedtransaction(f_referenceNo);
		IFCSHomePage.gotoCustomerMenuCustomerDetails();	
	    transactionListPage.validateCustomerTransaction(cardNo,ifcsCurrentDate,f_referenceNo);
		}
		IFCSHomePage.exitIFCS();
	
	}
	
	
	
	
	
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "Regression" })
	public void ValidateCustomerEnquiryFinancialSummaryAndState(@Optional("SG") String clientCountry,
			@Optional("EMAP") String clientName) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  TST-SC-08-Verify that other Account screens like Customer Enquiry,Financial summary,Financial State  work correctly",
				"Verify TST-SC-08-Verify that other Account screens like Customer Enquiry,Financial summary,Financial State  work correctly");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);

		Common common = new Common(driver, test);

		TransactionListPage transactionListPage = new TransactionListPage(driver, test);
		CardMaintenancePage cardMaintenancePage=new CardMaintenancePage(driver,test);

		MaintainAccountPage maintainAccountPage = new MaintainAccountPage(driver, test);

		IFCSloginPage.login("IFCS_URL_EMAP", "IFCS_EMAP_USERNAME", "IFCS_EMAP_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry," ");
		
		IFCSHomePage.gotoApplicationAndClickApplicationMenu();
		IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);
		Faker fakerN = new Faker();
		String f_referenceNo = fakerN.number().digits(3);
		String currentDate = common.getCurrentIFCSDateFromDB(clientName+clientCountry);
		// Get the IFCS current date
		String ifcsCurrentDate = common.enterADateValueInStatusBeginDateField("Current", currentDate);
		System.out.println("Date ::"+ifcsCurrentDate);
		String cardNo = common.getActiveCardsWithBalanceAndRowIndex(1);
		String cardNo2 = common.getActiveCardsWithBalanceAndRowIndex(2);
		String locationNo=common.chooseALocationWithNonFuelProduct("Y");
		String productCode=common.chooseANonFuelProductExtCodeInTheLocation(locationNo,"Y","externalCode");
		if (cardNo.equals(" ") && cardNo2.equals(" ") && locationNo.equals(" ") && productCode.equals(" ")){
			common.logForNoDataFound(this.getClass().getSimpleName(),
					"Need to Create A Cards with Account and rerun");
		} else {		
		}
			IFCSHomePage.gotoCustomerMenuCustomerDetails();	
//			cardMaintenancePage.chooseAndSearchCardNo("7800709900037450005");
			cardMaintenancePage.chooseAndSearchCardNo(cardNo);
			// Go to Account Details page
			IFCSHomePage.gotoAccountAndClickAccountDetails();
			double beforeActualAccountBalance = maintainAccountPage.getAccountBalance("Account Status","Actual Balance");
			
			
			IFCSHomePage.gotoTransactionAndClickManageTransaction();
			
//			transactionListPage.validateToPostManualTransactionEntry(ifcsCurrentDate,f_referenceNo,clientCountry,"7800709900037450005",cardNo2,locationNo);
			//transactionListPage.validateToPostManualTransactionEntry(ifcsCurrentDate,f_referenceNo,clientCountry,cardNo,cardNo2,locationNo,productCode,true);
			transactionListPage.enterTransactionBatchDetails(true,"160","1",clientName);
			transactionListPage.enterManualTransactionDetails(ifcsCurrentDate,f_referenceNo,cardNo,cardNo2,locationNo,"160","");
			transactionListPage.enterTransactionLineItems(productCode,"160","100","160");
			transactionListPage.validatePostManualTransaction("Validation successful");
			transactionListPage.validatePostSuspendedtransaction(f_referenceNo);
			IFCSHomePage.gotoCustomerMenuCustomerDetails();	
//		    transactionListPage.validateCustomerTransaction("7800709900037450005",ifcsCurrentDate,f_referenceNo);
			transactionListPage.validateCustomerTransaction(cardNo,ifcsCurrentDate,f_referenceNo);
		    transactionListPage.financialState();
		    double customerValue = maintainAccountPage.getAccountBalance("Header Details","Customer Value");
		    IFCSHomePage.gotoAccountAndClickAccountDetails();
		    transactionListPage. financialState();
			double afterActualAccountBalance = maintainAccountPage.getAccountBalance("Account Status","Actual Balance");//changeCardStatus.getActualAccountBalance();
			 transactionListPage. financialState();
			maintainAccountPage.validateTheFinancialBalance(beforeActualAccountBalance, afterActualAccountBalance,customerValue);
			IFCSHomePage.exitIFCS();
		
		}	
}


