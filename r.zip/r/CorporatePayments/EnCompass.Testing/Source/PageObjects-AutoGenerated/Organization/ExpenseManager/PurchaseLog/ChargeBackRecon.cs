using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using Common;
using Common.PageObjects;
using Common.ScenarioConfigurations;
using Common.Utility;

namespace EnCompass.Testing.Source.PageObjects.Organization.ExpenseManager.PurchaseLog 
{
	/// <summary>
	/// Auto-generated Page Model Class
	/// Navigation Paths: 
		/// [Organization Home]->Payables->Purchase Log->Chargeback Reconciliation
		/// </summary>
	[PageModel(@"/expenseManager/PurchaseLog/ChargeBackRecon.aspx")]
	public partial class ChargeBackRecon : EnCompassOrgPageModel 
	{
		public override string RelativeUrl => @"/expenseManager/PurchaseLog/ChargeBackRecon.aspx";
		public override string PageIdentifierXPath_Generated => @"//li[contains(@class, 'breadcrumb-item active')][text() = 'Chargeback Reconciliation']";

		#region Navigation
				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Purchase Logs']")]
		private IWebElement _payables_PurchaseLog_ChargebackReconciliation_PurchaseLogs { get; set; }
		public void NavigateTo_Payables_PurchaseLog_ChargebackReconciliation_PurchaseLogs()
		{
			NavigateToMenuItem(_payables_PurchaseLog_ChargebackReconciliation_PurchaseLogs);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Create Purchase Log']")]
		private IWebElement _payables_PurchaseLog_ChargebackReconciliation_CreatePurchaseLog { get; set; }
		public void NavigateTo_Payables_PurchaseLog_ChargebackReconciliation_CreatePurchaseLog()
		{
			NavigateToMenuItem(_payables_PurchaseLog_ChargebackReconciliation_CreatePurchaseLog);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Purchase Log Settings']")]
		private IWebElement _payables_PurchaseLog_ChargebackReconciliation_PurchaseLogSettings { get; set; }
		public void NavigateTo_Payables_PurchaseLog_ChargebackReconciliation_PurchaseLogSettings()
		{
			NavigateToMenuItem(_payables_PurchaseLog_ChargebackReconciliation_PurchaseLogSettings);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Chargeback Reconciliation']")]
		private IWebElement _payables_PurchaseLog_ChargebackReconciliation_ChargebackReconciliation { get; set; }
		public void NavigateTo_Payables_PurchaseLog_ChargebackReconciliation_ChargebackReconciliation()
		{
			NavigateToMenuItem(_payables_PurchaseLog_ChargebackReconciliation_ChargebackReconciliation);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Disputes']")]
		private IWebElement _payables_PurchaseLog_ChargebackReconciliation_Disputes { get; set; }
		public void NavigateTo_Payables_PurchaseLog_ChargebackReconciliation_Disputes()
		{
			NavigateToMenuItem(_payables_PurchaseLog_ChargebackReconciliation_Disputes);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Create Single-Use Accounts']")]
		private IWebElement _payables_PurchaseLog_ChargebackReconciliation_CreateSingleUseAccounts { get; set; }
		public void NavigateTo_Payables_PurchaseLog_ChargebackReconciliation_CreateSingleUseAccounts()
		{
			NavigateToMenuItem(_payables_PurchaseLog_ChargebackReconciliation_CreateSingleUseAccounts);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Create Test Transactions']")]
		private IWebElement _payables_PurchaseLog_ChargebackReconciliation_CreateTestTransactions { get; set; }
		public void NavigateTo_Payables_PurchaseLog_ChargebackReconciliation_CreateTestTransactions()
		{
			NavigateToMenuItem(_payables_PurchaseLog_ChargebackReconciliation_CreateTestTransactions);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Daily Extract Files']")]
		private IWebElement _payables_PurchaseLog_ChargebackReconciliation_DailyExtractFiles { get; set; }
		public void NavigateTo_Payables_PurchaseLog_ChargebackReconciliation_DailyExtractFiles()
		{
			NavigateToMenuItem(_payables_PurchaseLog_ChargebackReconciliation_DailyExtractFiles);
		}

		
		private void NavigateToMenuItem(IWebElement element)
		{
			Driver.Url = element.GetAttribute("href");
		}
		#endregion

		public ChargeBackRecon(GlobalSettings settings) : base(settings) { }
	}  
}
