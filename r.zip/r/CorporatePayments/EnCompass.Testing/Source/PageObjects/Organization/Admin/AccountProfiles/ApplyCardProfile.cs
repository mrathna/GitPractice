﻿using Common;
using Common.Utility;
using EnCompass.Testing.Source.PageObjects.Controls;
using NFluent;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Support.UI;
using System;

namespace EnCompass.Testing.Source.PageObjects.Organization.Admin.AccountProfiles
{
    [PageModel(@"/admin/accountProfiles/applyCardProfile.aspx")]
    public class ApplyCardProfile : EnCompassOrgPageModel
    {
        public override string RelativeUrl => @"/admin/accountProfiles/applyCardProfile.aspx";
        public override string PageIdentifierXPath_Override => @"//h1[contains(@id,'title')]";

        #region XPath page Elements

        private const string _saveXPath = @"//input[contains(@id,'saveButton')]";
        private const string _successMessageXPath = "//div[contains(@id,'SuccessMessage')]";
        private const string _cancelXPath = @"//input[contains(@id,'cancelButton')]";
        private const string _searchTermXPath = @"//select[contains(@id,'searchTermSelect')]";
        private const string _searchValueXPath = @"//select[contains(@id,'searchTermFilter')]";
        private const string _searchtxtXPath = @"//div[contains(@id,'searchTermValueInputGroup')]//input[contains(@id, 'SearchOutput_txt')]";
        private const string _searchCriteriaAddBtnXPath = @"//div[contains(@class,'append')]//input[@type='button' and @value='Add']";
        private const string _searchBtnXPath = @"//input[contains(@id, 'btnSearch')]";
        private const string _applyProfileChkXPath = @"//input[contains(@id,'CheckboxColumnBoxActual')]";
        private const string _applyProfileLabelXPath = @"//label[contains(@for,'CheckboxColumnBoxActual')]";
        #endregion

        #region Page Elements
        private IWebElement _save
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_saveXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_save element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

		private IWebElement _cancel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_cancelXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Info("Found _cancel");
                return element;
            }
        }

        private IWebElement _searchTerm
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_searchTermXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Info("Found _searchTerm");
                return element;
            }
        }

        private IWebElement _searchValue
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_searchValueXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Info("Found _searchValue");
                return element;
            }
        }

        private IWebElement _searchtxt
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_searchtxtXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Info("Found _searchtxt");
                return element;
            }
        }

        private IWebElement _searchCriteriaAddBtn
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_searchCriteriaAddBtnXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Info("Found _searchCriteriaAddBtn");
                return element;
            }
        }

        private IWebElement _searchBtn
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_searchBtnXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Info("Found _searchBtn");
                return element;
            }
        }

        private IWebElement _applyProfileChk
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_applyProfileChkXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Info("Found _applyProfileChk");
                return element;
            }
        }

        private IWebElement _applyProfileLabel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_applyProfileLabelXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Info("Found _applyProfileLabel");
                return element;
            }
        }
        #endregion

        public void SetCheckBox(IWebElement chkBox)
		{
			
			if (!chkBox.Selected) 
			{
				Driver.ScrollToXPATH(_applyProfileChkXPath);
				chkBox.JSClickWithFocus(Driver);
				this.RefreshModel();
			}
		}     

		public void Save()
		{
			_save.JSClickWithFocus(Driver);
			new WebDriverWait(Settings.EnCompassWebDriver, TimeSpan.FromSeconds(3)).Until(ExpectedConditions.ElementIsVisible(By.XPath(_successMessageXPath)));
			this.AttachOnDemandScreenShot();
		}
		
		public void PressCancel()
		{
			_cancel.JSClickWithFocus(Driver);
		}

        /*public void ApplyCardsSelection()
		{
			Settings.EnCompassWebDriver.WaitForVisible(By.XPath("//input[contains(@id,'CheckboxColumnBoxActual')]"));
			_applyCardsSelection.JSClickWithFocus(Driver);
		}*/

        public void SetSearchTermByValue(string whichText)
        {
            var selectElement = new SelectElement(_searchTerm);
            selectElement.SelectByText(whichText);
        }

        public string SearchValue
        {
            set
            {
                _searchtxt.ForceDocumentLoadOnSendKeys(value, Settings.EnCompassWebDriver);
            }
        }

        public void SearchCriteriaAddBtn()
        {
            _searchCriteriaAddBtn.JSClickWithFocus(Driver);
        }

        public void SearchBtn()
        {
            Settings.EnCompassWebDriver.WaitForVisible(By.XPath(_searchBtnXPath));
            _searchBtn.JSClickWithFocus(Driver);
        }

        private GridControl _cardGrid;
        public GridControl CardGrid
        {
            get
            {
                _cardGrid = new GridControl("dgCards", Driver);
                _cardGrid.WaitForGrid();
                return _cardGrid;
            }
        }

        public void SelectApplyProfileforAllSearchedCards()
        {
            _applyProfileChk.SetCheckboxStateWithLabel(_applyProfileLabel, true);
        }

        public ApplyCardProfile(GlobalSettings settings) : base(settings) { }
    }
}