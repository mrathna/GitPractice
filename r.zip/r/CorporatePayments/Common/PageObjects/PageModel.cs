﻿using Common.Utility;
using Flurl;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using TechTalk.SpecFlow;
using NFluent;
using OpenQA.Selenium.Interactions;
using AventStack.ExtentReports;
using System.Linq;
using System.Diagnostics;
using System.Threading;

namespace Common.PageObjects
{
	[Binding]
	public abstract class PageModel
	{
		private readonly GlobalSettings _settings;

		// Indicating that if the 'data-enc-page-ref-tkn' GUID is present or not
		// There are pages where its not expected to be present like  - Help Center, ARX pages
		public bool isGuidPresentOnPage = true;
		public string pageLoadGuid = null;
		private string newGridTableXpath = ".//table[@data-encompass-table]";
		private string spinnerXpath = ".//div[contains(@class,'fa-spin')]";

		public bool isNewGridPresentOnPage { get { return Driver.IsElementPresent(By.XPath(newGridTableXpath)); } }

		public IWebDriver Driver => _settings.EnCompassWebDriver;
		public GlobalSettings Settings => _settings;

		public virtual string PageIdentifierXPath_Generated { get; }

		public virtual string PageIdentifierXPath_Override { get; }

		public string PageIdentifierXPath { get { return PageIdentifierXPath_Override ?? PageIdentifierXPath_Generated; } }

		public abstract string RelativeUrl { get; }

		[FindsBy(How = How.XPath, Using = ".//input[@type ='radio' and contains(@id,'rblTermsConditions') and @value='Accept']")]
		public IWebElement _acceptTermRadiobutton { get; set; }

		[FindsBy(How = How.XPath, Using = ".//label[contains(@for,'rblTermsConditions')]")]
		public IWebElement _acceptTermRadiobuttonLabel { get; set; }

		[FindsBy(How = How.XPath, Using = ".//label[contains(@for,'rblTermsConditions') and text()='Accept']")]
		public IWebElement _acceptTermRadioLabel { get; set; }

		[FindsBy(How = How.XPath, Using = @".//input[contains(@id,'btnOK')]")]
		private IWebElement _continueButton { get; set; }

		[FindsBy(How = How.XPath, Using = ".//input[@type ='submit' and @value ='Save']")]
		private IWebElement _saveButton { get; set; }

		public PageModel(GlobalSettings settings)
		{
			_settings = settings;
		}

		/// <summary>
		/// Navigates to the specified url.
		/// "Force" is default set to true to address the side nav link updates for Testing menu. There are PO's with diff
		/// urls but same bread crumb and navigation fails on them if not forced
		/// </summary>
		public virtual void Navigate(bool force = true, string paramString = null)
		{
			bool onPage = false;
            Settings.EnCompassExtentTest.Info("Try to Get Full URL ");
            String RootURL = null;
            try
            {
                RootURL = Driver.GetRootUrl();
            }
            catch(Exception ex)
            {
                //IE specific change - Driver.URL throws exception hence adding 10 seconds to resolve the issue
                Settings.EnCompassExtentTest.Info("Driver.GetRootUrl failed hence waiting for 10 secs and try -> " + ex.Message);
                Thread.Sleep(10000);
            }
            var fullUrl = Url.Combine(RootURL ?? Driver.GetRootUrl(), RelativeUrl + (paramString ?? string.Empty));
			Settings.EnCompassExtentTest.Info("Contructed Full Url to navigate to: " + fullUrl);
			// do not like using exceptions but this appears to be the accepted practice for Selenium element detection
			if (!force)
			{
				try
				{
					Driver.FindElement(By.XPath(PageIdentifierXPath));
					onPage = true;
					Settings.EnCompassExtentTest.Info("The PageIdentifierXPath expected to be on page matched :  " + PageIdentifierXPath);
				}
				catch
				{
					Settings.EnCompassExtentTest.Info("The PageIdentifierXPath expected to be on page did not match, will now try with Url match.");
				}
			}

			onPage = onPage || Driver.Url.StartsWith(Url.Combine(Driver.GetRootUrl(), RelativeUrl), StringComparison.InvariantCultureIgnoreCase);

			if (!onPage)
			{
				if (RelativeUrl != null)
				{
					Settings.EnCompassExtentTest.Info("Navigating to the page with url :" + fullUrl);
					Driver.Url = fullUrl;
					Settings.EnCompassExtentTest.Info("Driver.Url is set to: " + fullUrl);
					//Driver.Navigate().GoToUrl(fullUrl);
				}
				else { throw new Exception($"Unable to navigate, we do not appear to be on the expected page based on this XPATH, {PageIdentifierXPath_Generated ?? "[null]"} and the RelativeUrl is [null]."); }
			}
			else if (force)
			{
				Settings.EnCompassExtentTest.Info("Force flag = true, hence refreshing the page");
				Driver.BrowserRefresh(Settings.EnCompassExtentTest);				
				Settings.EnCompassExtentTest.Info("Now, navigating to the page with url :" + fullUrl);
				Driver.Url = fullUrl;
				Settings.EnCompassExtentTest.Info("Driver.Url is set to: " + fullUrl);
			}
			else
				Settings.EnCompassExtentTest.Info("The Url matched for the expected page, already on the page, hence not navigating.");

			WaitForLoad();
			Settings.EnCompassExtentTest.Info("Waited for page to load and Navigated to : " + Driver.Url);
		}

		public virtual void RefreshModel()
		{
			Settings.EnCompassExtentTest.Info("Calling RefreshModel");
			PageFactory.InitElements(Driver, this);
			Settings.EnCompassExtentTest.Info("RefreshModel executed");
		}


		private static string _pageRefreshTokenXpath = ".//div[contains(@id,'PageRefreshPanel')]//input[contains(@id,'PageRefreshTokenTxt')]";
		public virtual void WaitForLoad(TimeSpan? waitTime = null)
        {
            Settings.EnCompassExtentTest.Debug("Inside WaitForLoad");
            try
            {
                int _timeOut = 20;
                if (GlobalSettings.Browser.Equals(GlobalSettings.Browsers.FIREFOX.ToString()) ||
                     GlobalSettings.Browser.Equals(GlobalSettings.Browsers.IE.ToString()) || 
                     GlobalSettings.DeviceType.Equals(GlobalSettings.Device.MOBILE.ToString()))
                {
                    _timeOut = 30;
                    Settings.EnCompassExtentTest.Debug("Global Timeout set to 30 secs");
                }
                WebDriverWait wait = new WebDriverWait(Driver, waitTime ?? TimeSpan.FromSeconds(_timeOut));

                // We need the below additional check for all Browsers except Chrome due to timing issue on them
                if ( (!GlobalSettings.Browser.Equals(GlobalSettings.Browsers.CHROME.ToString())) ||
                    GlobalSettings.DeviceType.Equals(GlobalSettings.Device.MOBILE.ToString()) )
                {
                    // First we expect the Page Load Identifier will not be present on the page, hence we look for 
                    // wait for disappearance. This is esp needed when we do multiple search on same page
                    try
                    {
                        Driver.WaitForAbsence(By.XPath(PageIdentifierXPath), TimeSpan.FromSeconds(10));
                        Settings.EnCompassExtentTest.Debug("Page Identifier disappeared from UI. Xpath : " + PageIdentifierXPath);
                    }
                    catch(WebDriverTimeoutException)
                    {
                        Settings.EnCompassExtentTest.Debug("Page Identifier did not disappear from UI. Xpath : " + PageIdentifierXPath);
                    }
                }

                // Wait for the javascript invokation to ensure "Done" status on page
                // Masking WaitForDocumentLoadToComplete method to skip the javascript exectuion error in IE browser
                if (!GlobalSettings.Browser.Equals(GlobalSettings.Browsers.IE.ToString()))
                {
                    Driver.WaitForDocumentLoadToComplete(null, Settings.EnCompassExtentTest);
                }


                Settings.EnCompassExtentTest.Info("DocumentLoadComplete executed");

                // Wait for PageIdentifier Xpath first - this will ensure that GUID change is in effect for Firefox
                wait.Until(ExpectedConditions.ElementIsVisible(By.XPath(PageIdentifierXPath)));
                Settings.EnCompassExtentTest.Debug("Waited for page to load with Page Identifier Xpath : " + PageIdentifierXPath);

                // If its Firefox or if device is Mobile then only look for the page refresh token Guid. This makes the test case slow
                if (GlobalSettings.Browser.Equals(GlobalSettings.Browsers.FIREFOX.ToString()) || 
                    GlobalSettings.Browser.Equals(GlobalSettings.Browsers.IE.ToString()) ||
                     GlobalSettings.DeviceType.Equals(GlobalSettings.Device.MOBILE.ToString()) )
                {
                    Settings.EnCompassExtentTest.Info("Waiting for page to load for :" + GlobalSettings.Browser);
                    IWebElement pageRefreshToken = null;
                    // If the page calling WaitForLoad has a GUID associated then evaluate it
                    if (isGuidPresentOnPage)
                    {
                        Settings.EnCompassExtentTest.Info("The POM has GUID, proceeding to evaluate the GUID value change upon page load completion.");
                        // Look for the GUID in page refresh token for a new value
                        if (String.IsNullOrEmpty(pageLoadGuid))
                        {
                            // First time page load as there is no existing GUID set
                            pageRefreshToken = Driver.WaitFor(By.XPath(_pageRefreshTokenXpath));
                            Settings.EnCompassExtentTest.Info("Found page refresh token.");
                            pageLoadGuid = pageRefreshToken.GetAttribute("data-enc-page-ref-tkn");
                            Settings.EnCompassExtentTest.Info("Fetched page load guid.");
                            Settings.EnCompassExtentTest.Info("First time page load, GUID value stored : " + pageLoadGuid);
                        }
                        else
                        {
                            string newGuidVal = null;
                            int counter = 1;
                            Settings.EnCompassExtentTest.Info("Waiting for GUID value to change for Page Load completion.");
                            // Wait until the GUI value has not changed to a new value
                         try
                            {
                                do
                                {
                                Settings.EnCompassExtentTest.Info("Attempt no : " + counter + " Existing GUID value : " + pageLoadGuid);
                                pageRefreshToken = Driver.WaitFor(By.XPath(_pageRefreshTokenXpath));                
                                newGuidVal = pageRefreshToken.GetAttribute("data-enc-page-ref-tkn");
                                Settings.EnCompassExtentTest.Info("Attempt no : " + counter + " New GUID value : " + newGuidVal);
                                if (!newGuidVal.Equals(pageLoadGuid))
                                {
                                    // reset the value to the newly found GUID value
                                    pageLoadGuid = newGuidVal;
                                    break;
                                }
                                counter++;
                                System.Threading.Thread.Sleep(1000);
                                } while (newGuidVal.Equals(pageLoadGuid) && counter <= 5);
                            }
                            catch (Exception ex)
                            {
                                // Here we are not  throwing the exception  caught to proceed with the flow "even if token is not refreshed", just we are logging as warning message
                                Settings.EnCompassExtentTest.Warning("Page refresh token waitFor is failed " + ex.Message);
                            }
                        }
                    }
                    else
                        Settings.EnCompassExtentTest.Info("The POM do not have GUID, thus skipping GUID value change evaluation upon page load completion.");                    
                }

                // For any other browser - like Chrome the below logic would ensure a page is loaded or not.
                // The below call is forced as now every page that has a Grid loads up with 
                // a Overlay per the new Grid changes
                if (isNewGridPresentOnPage)
                {
                    Settings.EnCompassExtentTest.Info("Page has New Grid control, waiting for overlay to load.");
					WaitForGridsToLoad();
				}
                RefreshModel();
                Settings.CurrentModel = this;
				Settings.EnCompassExtentTest.Info("Waited for page to load with Page Identifier Xpath : " + PageIdentifierXPath);
			}
			catch (Exception ex)
            {
                Logger.LogError($"Exception caught in '{Settings.Scenario.StepContext.StepInfo.Text}', {ex.Message}");
                Settings.EnCompassExtentTest.Info("WaitForLoad Failed with exception - " + ex.Message);
                if (GlobalSettings.Browser == "IE")
                    Settings.EnCompassExtentTest.Info("WaitForLoad Failed for IE");
                else
                    throw ex;
            }
		}

		/// <summary>
		/// This method waits for the form overlay for appearance and disappearance
		/// thus ensuring the form update is completed and its available again for interaction.
		/// </summary>
		virtual public void WaitForGridsToLoad(TimeSpan? tSpan = null)
		{
			Settings.EnCompassExtentTest.Info("Inside WaitForGridsToLoad");

			//certain pages (like JTA) the spiner dosen't appear
			var newGrids = Driver.WaitForElements(By.XPath(newGridTableXpath));
			Settings.EnCompassExtentTest.Debug($"Count of new grids:" + newGrids.Count());

			bool newGridsLoaded = newGrids.All(g => g.WaitForElements(Driver, By.XPath("//thead/tr")).Any());
			Settings.EnCompassExtentTest.Debug($"New Grids loaded :" + newGridsLoaded.ToString());

			if (newGrids.Any() && !newGridsLoaded)
			{
				// Wait for Spinner to appear ONLY if "new grids" are present and they are not yet loaded.
				Driver.WaitForVisible(By.XPath(spinnerXpath), tSpan ?? TimeSpan.FromSeconds(20));
				Settings.EnCompassExtentTest.Debug($"Found {newGrids.Count} Grids and at least one was not loaded. Waited for all grids to load");
			}
			else
				Settings.EnCompassExtentTest.Debug($"New Grid seems to have been already loaded!!");

			Driver.WaitForAbsence(By.XPath(spinnerXpath), tSpan ?? TimeSpan.FromSeconds(30));//changed to 30 seconds because CBKC in PAT is bit slow than usual
            Settings.EnCompassExtentTest.Debug($"Waited for spinner icon to disappear");
		}

		/// <summary>
		/// Wait for the Spinner element to appear and then disappear
		/// </summary>
		virtual public void WaitForFormLoadingOverlay(TimeSpan? tSpan = null)
		{
			Settings.EnCompassExtentTest.Info("Inside WaitForFormLoadingOverlay");
			//certain pages (like JTA) the spiner dosen't appear
			try
			{
                if (tSpan == null)
                {
					// Adjust the timeout as per browser needs
					if (GlobalSettings.Browser == GlobalSettings.Browsers.FIREFOX.ToString())
					{
						tSpan = TimeSpan.FromSeconds(20);
						Settings.EnCompassExtentTest.Debug("WaitForFormLoadingOverlay Timeout set to 20 secs");
					}
					else if (GlobalSettings.Browser == GlobalSettings.Browsers.IE.ToString() ||
						 GlobalSettings.DeviceType.Equals(GlobalSettings.Device.MOBILE.ToString()))
					{
						tSpan = TimeSpan.FromSeconds(30);
						Settings.EnCompassExtentTest.Debug("WaitForFormLoadingOverlay Timeout set to 30 secs");
					}
					else
					{
						tSpan = TimeSpan.FromSeconds(10);
						Settings.EnCompassExtentTest.Debug("WaitForFormLoadingOverlay Timeout set to 10 secs");
					}
				}

				Driver.WaitForVisible(By.XPath(spinnerXpath), tSpan ?? TimeSpan.FromSeconds(20));
				Settings.EnCompassExtentTest.Info($"Waited for spinner icon to appear");
			}
			catch (Exception)
			{
				Settings.EnCompassExtentTest.Warning($"spinner icon did not appear");
			}

			try
			{
				Driver.WaitForAbsence(By.XPath(spinnerXpath), tSpan ?? TimeSpan.FromSeconds(20));
			}
            catch (Exception e)
			{
				Settings.EnCompassExtentTest.Warning("The spinner icon did not disappear!!");
				throw e;
			}

            Settings.EnCompassExtentTest.Info($"Waited for spinner icon to disappear");
        }

		public virtual bool IsCurrentPage
		{
			get
			{
				if (!string.IsNullOrWhiteSpace(RelativeUrl))
				{
					return Settings.EnCompassWebDriver.GetRelativeUrl().Equals(RelativeUrl, StringComparison.InvariantCultureIgnoreCase);
				}
				return Driver.IsElementPresent(By.XPath(PageIdentifierXPath));
			}
		}

		public void PressContinueButton()
		{
			_continueButton.JSClickWithFocus(Driver);
			System.Threading.Thread.Sleep(2000);
		}

		public void ScrollToXPATH(string xpath)
		{
			var element = Driver.WaitFor(By.XPath(xpath));
			// Trying luck on javascript injection
			((IJavaScriptExecutor)_settings.EnCompassWebDriver).ExecuteScript("arguments[0].scrollIntoView(true);", element);
			Settings.EnCompassExtentTest.Info("Scrolled to Xpath using javascript executor: " + xpath);

			// now fallback using selenium actions scroll
			Actions actions = new Actions(Settings.EnCompassWebDriver);
			actions.MoveToElement(element);
			actions.Build().Perform();
			Settings.EnCompassExtentTest.Info("Scrolled to Xpath using selenium actions: " + xpath);
		}

        /// <summary>
        /// This method perform the action hover an element 
        /// It is used to show the elements that could appear after stop the cursor on a element
        /// </summary>
        public void ClickAndHold(string xpath)
        {
            var element = Driver.WaitFor(By.XPath(xpath));
            Actions actions = new Actions(Settings.EnCompassWebDriver);
            actions.ClickAndHold(element);
            actions.Build().Perform();
            Settings.EnCompassExtentTest.Info($"Clicked and Hold to XPath {xpath} using selenium actions.");
        }

        /// <summary>
        /// On Demand Helper to take screenshot in the middle of any flow. Custom Helper to attach screenshots to a sub step.
        /// ***DO NOT*** use it for attaching screenshot for a Step Failure, that's already taken care in Global Hooks automatically.
        /// </summary>
        public void AttachOnDemandScreenShot()
		{
			string scenarioTitle = Settings.Scenario.ScenarioInfo.Title;
			string stepText = Settings.Scenario.StepContext.StepInfo.Text;
			string scrnSht = ScreenshotHelper.TakeScreenshot(_settings.EnCompassWebDriver, _settings, scenarioTitle, stepText);
			scrnSht = "./Screenshots/" + scrnSht;
			Settings.EnCompassExtentTest.Info("Custom Captured Screenshot: ", MediaEntityBuilder.CreateScreenCaptureFromPath(scrnSht).Build());
		}

		protected By GetBy<T>(Expression<Func<T>> propertyExpression)
		{
			return SeleniumSupportHelper.GetBy(propertyExpression);
		}
	}
}
