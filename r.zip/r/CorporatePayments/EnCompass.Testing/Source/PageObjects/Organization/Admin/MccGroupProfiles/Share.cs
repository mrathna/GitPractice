﻿using AventStack.ExtentReports;
using Common;
using Common.Utility;
using EnCompass.Testing.Source.PageObjects.Controls;
using NFluent;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;

namespace EnCompass.Testing.Source.PageObjects.Organization.Admin.MccGroupProfiles
{

    [PageModel(@"/admin/mccGroupProfiles/Share.aspx")]
    public class Share : EnCompassOrgPageModel
    {
        public override string RelativeUrl => @"/admin/mccGroupProfiles/Share.aspx";
        public override string PageIdentifierXPath_Override => @"//h1[normalize-space(text())='Share']";

        #region XPath page Elements

        private const string _closeButtonXPath = @"//input[contains(@id,'btnClose')]";
        private const string _cbkCompanyXPath = "//div[contains(@id,'cbkCompanyAssignmentSaved')]";
        #endregion

        private IWebElement _closeButton
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_closeButtonXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_closeButton element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private GridControl _companiesGrid;
        public GridControl CompaniesGrid
        {
            get
            {
                var grid = _companiesGrid ?? (_companiesGrid = new GridControl("dgCompanies", Driver));
                grid.WaitForGrid();
                return grid;
            }
        }

        public void ClickCloseButton()
        {
            _closeButton.WaitUntilElementIsInteractable();
            _closeButton.JSClickWithFocus(Driver);
        }

        public string ShareFirstRowCompany(ExtentTest test)
        {
            IEnumerable<string> columns = CompaniesGrid.GetColumnText("Company Name");
            string shareCompanyName = columns.FirstOrDefault();
            int index = CompaniesGrid.GetColumnHeaderIndex("Share");
            string path = "td//input";
            string pathLabel = "td//label";

            IWebElement el = CompaniesGrid.GetRow(0).FindElement(By.XPath(path));
            IWebElement label = CompaniesGrid.GetRow(0).FindElement(By.XPath(pathLabel));
            el.SetCheckboxStateWithLabel(label, true);
            Driver.WaitForVisible(By.XPath(_cbkCompanyXPath));

            test.Info("Share the first company on the grid");


            return shareCompanyName;
        }

        public Share(GlobalSettings settings) : base(settings) { }
    }
}
