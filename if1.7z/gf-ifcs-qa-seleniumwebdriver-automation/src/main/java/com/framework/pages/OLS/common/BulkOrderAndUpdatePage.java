package com.framework.pages.OLS.common;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Random;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.ExtentTest;
import com.framework.basepage.BasePage;
import com.framework.repo.Locator;
import com.framework.util.ExcelUtils;
import com.framework.util.PropUtils;

//Added by Nithya - 04-05-2018
public class BulkOrderAndUpdatePage extends BasePage {

	public BulkOrderAndUpdatePage(WebDriver driver, ExtentTest test) {
		super(driver, test);
		PageFactory.initElements(driver, this);
	}

	@FindBy(how = How.ID, using = Locator.BULKCARD_ORDER_DOWNLOAD)
	public WebElement bulkCardOrderDownload;

	@FindBy(how = How.ID, using = Locator.DOWNLOAD_CARDS_TO_EXCEL)
	public WebElement cardsToExcelDownload;

	@FindBy(how = How.XPATH, using = Locator.UPLOAD_BULKCARD_ORDER)
	public WebElement uploadBulkCardOrder;

	@FindBy(how = How.ID, using = Locator.BULK_CARD_ORDER_POPUP)
	public WebElement bulkOrderPopup;

	@FindBy(how = How.ID, using = Locator.BULK_CARD_UPDATE_POPUP)
	public WebElement bulkUpdatePopup;

	@FindBy(how = How.ID, using = Locator.VIEW_CARD_RESUTLS_POPUP)
	public WebElement viewCardResultsPopup;

	@FindBy(how = How.XPATH, using = Locator.VIEW_CARD_RESUTLS_POPUP_CLOSE)
	public WebElement viewCardResultsPopupCancel;

	@FindBy(how = How.XPATH, using = Locator.BULK_CARD_ORDER_POPUP_CANCEL)
	public WebElement bulkOrderPopupCancel;

	@FindBy(how = How.XPATH, using = Locator.BULK_CARD_UPDATE_POPUP_CANCEL)
	public WebElement bulkUpdatePopupCancel;

	@FindBy(how = How.XPATH, using = Locator.BULK_CARD_ACTIONS)
	public List<WebElement> bulkCardOperations;

	@FindBy(how = How.ID, using = Locator.BCU_UPLOAD_EXCEL_FILE)
	public WebElement bulkUploadExcel;

	@FindBy(how = How.ID, using = Locator.BCS_SEARCH)
	public WebElement searchCards;

	@FindBy(how = How.XPATH, using = Locator.BCS_ADVANCED_SEARCH)
	public WebElement advancedSearchCards;

	@FindBy(how = How.XPATH, using = Locator.BCS_UPDATE_CARDTYPE)
	public List<WebElement> bulkUpdateCardType;

	@FindBy(how = How.XPATH, using = Locator.BCS_CARDTYPE)
	public List<WebElement> bulkCardType;

	@FindBy(how = How.XPATH, using = Locator.BCS_SEARCH_RESULT)
	public WebElement searchResult;

	@FindBy(how = How.ID, using = Locator.SEARCH_CARDS)
	public WebElement bulkCArdUpdateSearch;

	@FindBy(how = How.ID, using = Locator.VIEW_CARD_SEARCH_RESULTS)
	public WebElement viewCardSearchResults;

	@FindBy(how = How.ID, using = Locator.BCS_CARD_STATUS)
	public WebElement bulkCardStatus;

	@FindBy(how = How.XPATH, using = Locator.BCS_CARD_STATUS_VALUE)
	public WebElement bulkCardStatusValue;

	@FindBy(how = How.ID, using = Locator.BCS_CARD_UPDATE_STATUS)
	public WebElement bulkCardUpdateStatus;

	@FindBy(how = How.XPATH, using = Locator.BULKCARD_STATUS_SELECT_ALL)
	public WebElement bulkCardSelectAll;

	@FindBy(how = How.XPATH, using = Locator.BULKCARD_STATUS_DESELECT_ALL)
	public WebElement bulkCardDeSelectAll;

	@FindBy(how = How.ID, using = Locator.BCS_LIST_CARDS_TABLE)
	public WebElement bulkCardStatusCardSearchList;

	@FindBy(how = How.XPATH, using = Locator.BCS_SELECT_CARD_CHECKBOX)
	public List<WebElement> bulkCardSelectCheckBox;

	@FindBy(how = How.ID, using = Locator.BCS_NEW_STATUS_DROPDOWN)
	public WebElement newStatusDropDown;

	@FindBy(how = How.ID, using = Locator.AU_SAVE)
	public WebElement reviewChanges;

	@FindBy(how = How.ID, using = Locator.BCS_SAVE_NEW_CARD_STATUS)
	public WebElement saveNewCardStatus;

	@FindBy(how = How.ID, using = Locator.CARDSTATUSCHANGE_POPUP_YESBUTTON)
	public WebElement cardStatusChangePopupYes;

	@FindBy(how = How.XPATH, using = Locator.BCS_PRINT_THIS_PAGE)
	public WebElement bcsPrintThisPage;

	@FindBy(how = How.ID, using = Locator.BCS_RETURN_TO_BULK_CARD_SEARCH)
	public WebElement bcsReturnToBulkCardSearch;

	@FindBy(how = How.XPATH, using = Locator.PAGE_TITLE_DP)
	public WebElement pageTitle;

	@FindBy(how = How.ID, using = Locator.ACCOUNT_LIST)
	public WebElement accountList;
	
	@FindBy(how = How.XPATH, using = Locator.ACCOUNT_LIST_BOX)
	public WebElement accountListbox;

	@FindBy(how = How.ID, using = Locator.BCS_ACCOUNT_LIST)
	public WebElement bcsAccountList;

	//Added by Anton

	@FindBy(how = How.ID,using = Locator.BULK_CARD_UPDATE_FILE_FIELD)
	public WebElement bcuUpdateFileField;

	@FindBy(how = How.XPATH,using = Locator.UPLOAD_BULK_CARD_UPDATE)
	public WebElement uploadBulkCardUpdate;
	
	@FindBy(how = How.XPATH,using = Locator.UPLOAD_BULK_CARD_UPLOAD)
	public WebElement uploadBulkCardUpload;

	@FindBy(how = How.XPATH,using = Locator.BULK_CARD_UPDATE_SUCCESSMESSAGE)
	public WebElement bulkCardUpdateSuccessMessage;
	
	@FindBy(how = How.ID, using = Locator.AN_EXISTING_MULTICARD_SEARCH)
	public WebElement multiCardSearch;
	
	@FindBy(how = How.ID, using = Locator.SEARCH_CARDS)
	public WebElement searchCardsButton;
	
	@FindBy(how = How.XPATH, using = Locator.LIST_OF_DRIVER_NAME)
	public List<WebElement> listOfDriverName;
	
	@FindBy(how = How.XPATH, using = Locator.LIST_OF_REG_NUMBER)
	public List<WebElement> listOfRegNumber;

	/**
	 * Checks the presence of Bulk Card Order template download
	 */
	public void checkBulkCardOrderDownloadLink() {
		if (getTagNameForLocators(bulkCardOrderDownload).equals("a")) {
			logPass("Bulk card order link is available");
		} else {
			logFail("Bulk card order link not available");
		}
	}

	/**
	 * Checks the presence of Card Search Results download
	 */
	public void checkCardsToExcelDownloadLink() {
		if (getTagNameForLocators(cardsToExcelDownload).equals("a")) {
			logPass("Download cards to excel link is available");
		} else {
			logFail("Download cards to excel link not available");
		}
	}

	/**
	 * Click On Download Cards To Excel
	 */
	public void clickOnDownloadCardsToExcel(String downloadOption) {
		if(downloadOption.equals("Download the Bulk Card Order template")) {
			isDisplayedThenClick(bulkCardOrderDownload,"Download the Bulk Card Order template");
			//sleep(5);
		} else {
			isDisplayedThenClick(cardsToExcelDownload,"Download Cards to Excel" );
			//sleep(5);
		}
	}

	/*public void clickOnBrowse() {
		isDisplayedThenClick();

	}*/
	public void clickOnBrowseButtonToUploadTheExcelFile() {
		/*	boolean isDisplayed = waitForElementTobeClickable(bcuUpdateFileField,60);
    	System.out.println("Element is Displaying or Not I am checking this"+isDisplayed);
    	if(isDisplayed) */
		isDisplayedThenActionClick(bcuUpdateFileField,"File Upload Option");
		sleep(7);


	}

	/**
	 * Added by Anton
	 * Click On Upload Bulk Card Update
	 */
	public void clickOnUploadBulkCardUpdate() {
		isDisplayedThenClick(uploadBulkCardUpdate,"Upload Bulk Card update");
		sleep(10);
	}

	public void bulkCardUpdateSuccessInfo() {
		if(bulkCardUpdateSuccessMessage.isDisplayed()) {
			
		logPass("Bulk Card Update Completed Scucessfully");
		}
		else {
			logFail("Bulk Card Update not completed sucessfully");
		}
	}

	/**
	 * Click upload bulk card order button
	 * 
	 */
	public void clickUploadBulkCardOrder() {
		isDisplayedThenActionClick(uploadBulkCardOrder, "Upload Bulk Card Order");
		sleep(5);
	}

	/**
	 * Click close on upload bulk card order popup and check popup closed
	 */
	public void clickCloseInBulkOrderUpload() {
		isDisplayed(bulkOrderPopup, "Upload bulk card order popup");
		actionClick(bulkOrderPopupCancel);
		sleep(2);
		if (bulkOrderPopup.isDisplayed()) {
			logFail("Upload bulk card order popup present after clicking close popup option");
		}
	}

	/**
	 * Select the given Bulk Card Operation
	 */
	public void selectBulkCardOperation(String optionToSelect) {
		boolean isRadioButtonSelected = selectRadioButtonFromList(bulkCardOperations, optionToSelect,
				"data-summary-value");
		sleep(3);
		if (isRadioButtonSelected) {
			logPass("Option selected");
		} else {
			logFail("Option not selected");
		}
		waitForPageLoad(5);
	}

	/**
	 * Click upload bulk card update button
	 * 
	 */
	public void clickUploadBulkUpdate() {
		isDisplayedThenActionClick(bulkUploadExcel, "Bulk Upload Excel");
		sleep(2);
	}

	/**
	 * Click close on upload bulk card update popup and check popup closed
	 */
	public void clickCloseInBulkCardUpdatePopup() {
		if (bulkUpdatePopup.isDisplayed()) {
			logPass("Upload bulk card update popup present");
			actionClick(bulkUpdatePopupCancel);
			sleep(5);
			if (bulkUpdatePopup.isDisplayed()) {
				logFail("Upload bulk card update popup present after clicking close popup option");
			}
		} else {
			logFail("Upload bulk card update popup not present");
		}
	}

	/**
	 * Select Search Card Button
	 * 
	 */
	public void clickSearchCard(String bulkCardOperation) {
		if (bulkCardOperation.equals("Bulk Card Status")) {
			isDisplayedThenActionClick(searchCards, "Search Cards");

		} else {
			isDisplayedThenActionClick(bulkCArdUpdateSearch, "Bulk Card Update Search");
		}
		sleep(5);
	}
	
	/**
	 * Check Card Presence
	 * 
	 */
	public boolean checkNoCardMessage() {
		boolean isCardsNotPresent = waitForTextToAppear("No Cards found", 20);
		return isCardsNotPresent;
	}


	/**
	 * Bulk Card Status - All Option Search
	 */
	public void bulkCardStatusSearch() {
		List<WebElement> dropdownValues= selectDropdownOptionValues(bulkCardStatus);
		boolean cardResultNotFound,cardTable,cardStatusTable;
		WebElement cardValue;
		if(dropdownValues.size()>0) {
			for(WebElement dropdownValue:dropdownValues) {
				dropdownValue.click();
				clickSearchCard("Bulk Card Status");
				cardResultNotFound = waitForTextToAppear("No Cards found",60);
				cardTable = waitToCheckElementIsDisplayed(By.xpath("//div[@id='change_status_card_list']"),60);
				cardStatusTable = waitToCheckElementIsDisplayed(By.xpath("//tbody[@id='lform:change_status_tableCardList:tb']"),60);
				if(!cardResultNotFound && cardTable && cardStatusTable) {
					cardValue = bulkCardStatusValue;  
					String cardStatus = cardValue.getText();
					if(dropdownValue.getText().equals("--Select All--")) {
						logInfo("Select All Option - Shows all card status result");
					} else if(dropdownValue.getText().equals(cardStatus)) {
						logInfo("Bulk Card Status shows --> "+dropdownValue.getText()+" Search Result exists");
					} else {
						logInfo("Search Pass");	
					}
				} else {
					logInfo("No Card Found --> nothing to check");
				}
				sleep(2);
			}
			logPass("Bulk Card Status - Search - All Options done");
		} else {
			logFail("Bulk Card Status Search Fails");
		}
	}

	/**
	 * Bulk Card Status - Advance Search 
	 */
	public void bulkCardAdvanceSearch() {
		selectBulkCardStatus("Bulk Card Status","Active");
		clickAdvancedSearchOption();
		List<WebElement> radioValues= bulkCardType;
		boolean cardResultNotFound,cardTable,cardStatusTable;
		WebElement cardValue;
		String cardStatus;
		if(radioValues.size()>0) {
			for(WebElement radioValue:radioValues) {
				radioValue.click();
				clickSearchCard("Bulk Card Status");
				cardResultNotFound = waitForTextToAppear("No Cards found",60);
				cardTable = waitToCheckElementIsDisplayed(By.xpath("//div[@id='change_status_card_list']"),60);
				cardStatusTable = waitToCheckElementIsDisplayed(By.xpath("//tbody[@id='lform:change_status_tableCardList:tb']"),60);
				if(!cardResultNotFound && cardTable && cardStatusTable) {
					cardValue = bulkCardStatusValue;  
					cardStatus = cardValue.getText();
					if("Active".equals(cardStatus)) {
						logInfo("Shows Active Card");
					}
				} else {
					logInfo("No Card Found --> nothing to check");		
				}
			}
			logPass("Bulk Card Advance Status - Search - Success");
		} else {
			logFail("Bulk Card Advance Status Search Fails");
		}
	}


	/**
	 * Click view card results button
	 */
	public void clickViewCardSearchResults() {
		try {
			isDisplayedThenActionClick(viewCardSearchResults, "View Card Search Results");
			//sleep(3);
		} catch (NoSuchElementException ex) {
			selectInputFromDropdown(accountList, 0);
			//sleep(3);
			clickSearchCard("Bulk Card Update");
			isDisplayedThenActionClick(viewCardSearchResults, "View Card Search Results");

		}
	}

	/**
	 * Select a bulk card status
	 */
	public void selectBulkCardStatus(String statusOption,String cardStatus) {
		if(statusOption.equals("Bulk Card Update")) {
			selectDropDownByVisibleText(bulkCardUpdateStatus, cardStatus);
			verifyTextFromDropdown(bulkCardUpdateStatus, cardStatus);
			sleep(3);
		} else {
			selectDropDownByVisibleText(bulkCardStatus, cardStatus);
			verifyTextFromDropdown(bulkCardStatus, cardStatus);
			sleep(3);
		}
	}

	/**
	 * Bulk Card Update Search - Card Status and Card Type - All Options 
	 */
	public void bulkCardUpdateSearch() {
		List<WebElement> optionValues= selectDropdownOptionValues(bulkCardUpdateStatus);
		List<WebElement> radioValues= bulkUpdateCardType;
		if(optionValues.size()>0) {
			for(WebElement optionValue:optionValues) {
				for(WebElement radioValue:radioValues) {
					optionValue.click();
					radioValue.click();
					clickSearchCard("Bulk Card Update");
					boolean cardResultEmpty = waitForTextToAppear("No Cards found",60);
					if(!cardResultEmpty) {
						logInfo("Search Result - Cards Exsit");
						clickViewCardSearchResults();
						clickCloseInViewCardResultsPopup();
						clickOnDownloadCardsToExcel("Download Cards to Excel");
					} else  {
						logInfo("No Cards Found");
					} 
					//sleep(3);
				}
			}
			logPass("Search - All Options of Card Type and Card Status done");
		} else  {
			logFail("Card Status Options are not available");
		}
	}


	/**
	 * Click Advanced Search Option
	 */
	public void clickAdvancedSearchOption() {
		isDisplayedThenActionClick(advancedSearchCards, "Advanced Search Options");
		sleep(5);
	}

	/**
	 * Click close on view card results popup and check popup closed
	 */
	public void clickCloseInViewCardResultsPopup() {
		if (viewCardResultsPopup.isDisplayed()) {
			logPass("View card results popup present");
			isDisplayedThenActionClick(viewCardResultsPopupCancel,"Cancel Button");
			sleep(2);
			if (viewCardResultsPopup.isDisplayed()) {
				//logFail("View card results popup present after clicking close popup option");
				logInfo("View card results popup present after clicking close popup option");
				isDisplayedThenActionClick(viewCardResultsPopupCancel,"Cancel Button");
			}
		} else {
			logFail("View card results popup not present");
		}
	}

	/**
	 * Click select all option and check all cards are selected
	 */
	public void clickSelectAllOptionAndCheckAllCardsSelected() {
		scrollDownPage();
		isDisplayedThenActionClick(bulkCardSelectAll, "Select All");
		sleep(5);
		boolean checkBox;
		try {
			if (bulkCardSelectCheckBox.size() > 0) {
				for (int i = 0; i < bulkCardSelectCheckBox.size(); i++) {
					checkBox = isSelectCheckBoxChecked(i);
					if (checkBox) {
						logPass("CheckBox selected");
					} else {
						logFail("CheckBox not selected");
					}
				}
			} else {
				logFail("No Cards for this Status");
			}
		} catch (NoSuchElementException ex) {
			selectInputFromDropdown(accountList, 0);
			sleep(3);
			clickSearchCard("Bulk Card Status");
			if (bulkCardSelectCheckBox.size() > 0) {
				for (int i = 0; i < bulkCardSelectCheckBox.size(); i++) {
					checkBox = isSelectCheckBoxChecked(i);
					if (checkBox) {
						logPass("CheckBox selected");
					} else {
						logFail("CheckBox not selected");
					}
				}
			} else {
				logFail("No Cards for this Status");
			}
		}
	}

	/**
	 * Click deselect all option and check all cards are deselected
	 */
	public void clickDeselectAllOptionAndCheckAllCardsDeselected() {
		isDisplayedThenActionClick(bulkCardDeSelectAll, "Deselect All");
		sleep(5);
		boolean checkBox;
		for (int i = 0; i < bulkCardSelectCheckBox.size(); i++) {
			checkBox = isSelectCheckBoxChecked(i);
			if (!checkBox) {
				logPass("CheckBox deselected");
			} else {
				logFail("CheckBox not deselected");
			}
		}
	}

	/**
	 * Select a card from list
	 */
	public void selectACardFromList(int cardSeqNo) {
		if (bulkCardSelectCheckBox.size() - 1 >= cardSeqNo) {
			isDisplayedThenActionClick(bulkCardSelectCheckBox.get(cardSeqNo), "Select a Card");
		} else {
			logFail("Mentioned card index not present");
		}
		sleep(3);
	}

	/**
	 * Check is card selected
	 */
	public boolean isSelectCheckBoxChecked(int checkBoxSeqNo) {
		boolean isSelected = false;
		try {
			if (bulkCardSelectCheckBox.size() > checkBoxSeqNo) {
				if (bulkCardSelectCheckBox.get(checkBoxSeqNo).getAttribute("checked").equals("true")
						|| bulkCardSelectCheckBox.get(checkBoxSeqNo).getAttribute("checked").equals("checked")) {
					isSelected = true;
				} else {
					isSelected = false;
				}
			}
		} catch (NullPointerException ex) {
			return false;
		}
		return isSelected;
	}

	/**
	 * Select a new bulk card status
	 */
	public void selectNewStatus(String newStatus) {
		selectDropDownByVisibleText(newStatusDropDown, newStatus);
		verifyTextFromDropdown(newStatusDropDown, newStatus);
	}


	/**
	 * Bulk Card - Status Change
	 * @param statusOption
	 */
	public void bulkCardChangeStatus(String statusOption) {
		selectBulkCardStatus("Bulk Card Status","Active");
		clickSearchCard("Bulk Card Status");
		boolean cardSearchEmpty = waitForTextToAppear("No Cards found",60);
		if(!cardSearchEmpty) {
			List<WebElement> dropdownNewValues= selectDropdownOptionValues(newStatusDropDown);
			
			if(dropdownNewValues.size()>0) {
				boolean statusChangePopupYes,invalidStatus;
				int randomPosition;
				Random randomSelect;
				for(WebElement dropdownNewValue:dropdownNewValues) {
					if(dropdownNewValue.getText().equals(statusOption)) {
						selectACardFromList(0);
						dropdownNewValue.click();
						clickReviewChanges();
						int checkBox = bulkCardSelectCheckBox.size();
						for(int i=0;i<3;i++) {
							invalidStatus = waitToCheckElementIsDisplayed(By.xpath("//h4[contains(text(),'Invalid card status change combination')]"),60);
							if(invalidStatus) {
								logInfo("Card Status Change Shows - Invalid Card Status Change Combination");
								clickDeselectAllOptionAndCheckAllCardsDeselected();
								randomSelect=new Random();
								randomPosition=randomSelect.nextInt(checkBox);
								selectACardFromList(randomPosition);	
								clickReviewChanges();	
								//sleep(3);
							} else {
								logInfo("Card Status Change Not Shows - Invalid Card Status Change Combination");
								clickSaveNewCardStatus();
								statusChangePopupYes = waitToCheckElementIsDisplayed(By.id("lform:saveCardStatusAndReissueCardBtnFullAccess"),60);
								if(statusChangePopupYes) {
									clickYesOnCardStatusChange();
									//sleep(2);
								} 
								checkPrintThisPageLinkText();
								//sleep(3);
								returnToBulkCardSearchAndCheckTitle();
								break;
							}
							logInfo("Card Status Change Shows - Invalid Card Status Change Combination - Tried for 3 times. Need to change Configuration manually in IFCS");							
						}
						break;

					}	else {
						System.out.println("Current Option ->"+dropdownNewValue.getText() + "Skips");
						logInfo("Current Option ->"+dropdownNewValue.getText() + "Skips");
					}
				}

			} else {
				System.out.println("No Options available");
				logInfo("No Options available");
			}
			logPass("Bulk Card Status Change from Active to -"+statusOption+"Done");
		} else {
			System.out.println("No Cards Found");
			logInfo("No Cards Found");
			logFail("No card found - Search Result Empty - Nothing to Change");
		}
	}

	/**
	 * Click review changes
	 */
	public void clickReviewChanges() {
		isDisplayedThenActionClick(reviewChanges, "Review Changes");
	}

	/**
	 * Click save new card status
	 */
	public void clickSaveNewCardStatus() {
		isDisplayedThenActionClick(saveNewCardStatus, "Save New Card Status");
		sleep(3);
	}

	/**
	 * Click yes on card status change popup
	 */
	public void clickYesOnCardStatusChange() {
		isDisplayedThenActionClick(cardStatusChangePopupYes, "Card Status Change Reissue Popup :: YES");
		sleep(3);
	}

	/**
	 * Check the print this page link text
	 */
	public void checkPrintThisPageLinkText() {
		if (getTagNameForLocators(bcsPrintThisPage).equals("a")) {
			logPass("Print this page link text present");
		} else {
			logFail("Print this page link text not present");
		}
	}

	/**
	 * Return to bulk card search and check title
	 */
	public void returnToBulkCardSearchAndCheckTitle() {
		isDisplayedThenActionClick(bcsReturnToBulkCardSearch, "Return To Bulk Card Search");
		sleep(3);
	}

	/**
	 * Check bulk card page title
	 */
	public void checkBulkCardPageTitle() {
		if (getText(pageTitle).contains("Bulk Order and Update Cards")) {
			logPass("Bulk order and update cards title present");
		} else {
			logFail("Bulk order and update cards title not present");
		}

	}

	public void selectAllAccountFromBulkCardOperation(String updateOrStatus) {
		if (updateOrStatus.contains("Update")) {
			selectDropDownByVisibleText(accountListbox, "All Accounts");
		} else {
			selectDropDownByVisibleText(bcsAccountList, "All Accounts");
		}
		sleep(3);
	}

	
// Added by Raxsana
	public String getCardNumberToUpdateExcel(String downloadedFileName, String accountNumber, String cardType) {
		String cardNumberToUpdate;
		String cardNumber = null;
		try {
			if (cardType.equals("Driver")) {
				cardNumberToUpdate = "select Card_no from cards inner join card_status on card_status.card_status_oid = cards.card_status_oid where driver_oid = (select driver_oid from drivers where customer_mid in (select customer_mid from m_customers where customer_no='"
						+ accountNumber + "') and rownum=1) and card_status.description in ('100 Normal Service','600 Requested Not Issued','700 No Transactions') and replace_card_oid is null";
				cardNumber = connectDBAndGetValue(cardNumberToUpdate,
						PropUtils.getPropValue(configProp, "sqlODSServerName"));
			} else {
				cardNumberToUpdate = "select Card_no from cards inner join card_status on card_status.card_status_oid = cards.card_status_oid where vehicle_oid = (select vehicle_oid from vehicles where customer_mid in (select customer_mid from m_customers where customer_no='"
						+ accountNumber + "') and rownum=1) and card_status.description in ('100 Normal Service','600 Requested Not Issued','700 No Transactions') and replace_card_oid is null";
				cardNumber = connectDBAndGetValue(cardNumberToUpdate,
						PropUtils.getPropValue(configProp, "sqlODSServerName"));
			}
		}catch (Exception e) {
			e.getMessage();
		}
		return cardNumber;
	}
		public String updateExcelValues(String downloadedFileName,String cardNumber, String cardType) {
			String updatedValue=null;
			try {
			enterText(multiCardSearch,cardNumber);
			isDisplayedThenActionClick(searchCardsButton, "Search Cards");
			clickOnDownloadCardsToExcel("Bulk Card Update");
			verifyTheDownloadedFile(downloadedFileName);
			sleep(3);
			String fileName = getLatestDownloadedFileFromDir(downloadedFileName).getName();
			String downloadedFilePath = System.getProperty("user.home") + "\\Downloads\\" + fileName;
			//System.out.println("path::"+downloadedFilePath);
			
			SimpleDateFormat formatter = new SimpleDateFormat("YYMMmmss");
			Date date = new Date();
			String currentDate = formatter.format(date);
			if (cardType.equals("Driver")) {
				HSSFSheet hssfWorkSheet = ExcelUtils.readExcel(downloadedFilePath, "BULKCARD");
				updatedValue=fakerAPI().name().firstName() + currentDate;
				//System.out.println("value::"+updatedValue);
				ExcelUtils.cardUpdateInExcel(hssfWorkSheet, "DriverName", updatedValue,
						2);
				ExcelUtils.writeExcel(downloadedFilePath);
				//logPass("passed");
			} else {
				HSSFSheet hssfWorkSheet = ExcelUtils.readExcel(downloadedFilePath, "BULKCARD");
				updatedValue=currentDate;
				//System.out.println("value1::"+ updatedValue);
				ExcelUtils.cardUpdateInExcel(hssfWorkSheet, "RegoNumber", updatedValue, 2);
				ExcelUtils.writeExcel(downloadedFilePath);
				//logPass("passed1");
			}
			

		} catch (Exception e) {
			e.getMessage();
		}
			return updatedValue;
	}

		public void validateUpdatedValuesInOLS(String cardNo,String cardType,String expectedValue) {
			FindAndUpdateCardPage findAndUpdateCardPage = new FindAndUpdateCardPage(driver, test);
			try {
				multiCardSearch.clear();
				enterText(multiCardSearch, cardNo);
				findAndUpdateCardPage.clickSearchButtonInFindUpdateCardPage();
				iterateAndSearch(expectedValue,cardType);
			} catch (Exception e) {
				e.getMessage();
			}
		}
		
		public boolean iterateAndSearch(String expectedValue,String cardType) {
			if(cardType.equals("Driver")) {
			int listSize = listOfDriverName.size();
			//System.out.println("Size of Dropdown" + listSize);
			for (int i = 0; i < listSize; i++) {
				String searchValue = listOfDriverName.get(i).getText();
				//System.out.println("accountname:::::" + searchValue);
				//System.out.println("Homepage accountname:::::" + expectedValue);
				if (searchValue.contains(expectedValue)) {
					logPass("Search Value("+searchValue+") is present");
					break;
				}
			}
			}
			else {
				int listSize = listOfRegNumber.size();
				//System.out.println("Size of Dropdown" + listSize);
				for (int i = 0; i < listSize; i++) {
					String searchValue = listOfRegNumber.get(i).getText();
					//System.out.println("accountname:::::" + searchValue);
					//System.out.println("Homepage accountname:::::" + expectedValue);
					if (searchValue.contains(expectedValue)) {
						logPass("Search Value("+searchValue+") is present");
						break;
					}
				}	
			}
			return true;
		}
		
		public void updateNegativeExcelValues(String downloadedFileName,String cardNumber) {
			try {
			enterText(multiCardSearch,cardNumber);
			isDisplayedThenActionClick(searchCardsButton, "Search Cards");
			clickOnDownloadCardsToExcel("Bulk Card Update");
			verifyTheDownloadedFile(downloadedFileName);
			sleep(3);
			String fileName = getLatestDownloadedFileFromDir(downloadedFileName).getName();
			String downloadedFilePath = System.getProperty("user.home") + "\\Downloads\\" + fileName;
			HSSFSheet hssfWorkSheet = ExcelUtils.readExcel(downloadedFilePath, "BULKCARD");
			ExcelUtils.cardUpdateInExcel(hssfWorkSheet, "CardNumber", fakerAPI().name().firstName(), 2);
			ExcelUtils.writeExcel(downloadedFilePath);
			}
			catch(Exception e) {
				e.getMessage();
			}
		}
	 

}
