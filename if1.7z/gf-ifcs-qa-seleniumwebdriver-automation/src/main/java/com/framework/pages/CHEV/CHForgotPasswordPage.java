package com.framework.pages.CHEV;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.ExtentTest;
import com.framework.basepage.BasePage;
import com.framework.repo.Locator;

public class CHForgotPasswordPage extends BasePage {

	@FindBy(how = How.XPATH, using = Locator.SCHEDULE_REPORT_MAINTENANCE_PAGE)
	public WebElement forgotPasswordTitle;

	@FindBy(how = How.XPATH, using = Locator.CH_CONFIRMATION_MSG)
	public WebElement confirmationMessage;

	@FindBy(how = How.ID, using = Locator.CH_REPORTS_USER_ID)
	public WebElement userId;

	@FindBy(how = How.ID, using = Locator.CH_FORGOT_PWD_SUBMIT_BTN)
	public WebElement submitBtn;

	@FindBy(how = How.XPATH, using = Locator.CH_FORGOT_PWD_INSTRUCTIONS)
	public WebElement instructionsText;

	public CHForgotPasswordPage(WebDriver driver, ExtentTest test) {
		super(driver, test);
		// TODO Auto-generated constructor stub
		PageFactory.initElements(driver, this);
	}

	public void verifyInstructions() {
		System.out.println(instructionsText.getText());
		verifyText(instructionsText, "Please complete the fields marked with *.");
	}

	public void checkConfirmationMessage() {
		sleep(10);
		System.out.println(confirmationMessage.getText()); 
		verifyText(confirmationMessage, "Password sent");

	}

	public void enterUserId(String propValue) {
		//enterText(userId, "hi");
		Actions actions = new Actions(driver);
		actions.moveToElement(userId);
		actions.click();
		actions.sendKeys(propValue);
		actions.build().perform();
		
//		if (userId.isDisplayed()) {
//			enterText(userId, propValue);
//		}else {
//			logFail("User Id not found");
//		}

	}

	public void clickSubmitBtn() {
		if(submitBtn.isDisplayed()) {
			actionClick(submitBtn);
		}else {
			logFail("Submit button is missing");
		}
	}
}
