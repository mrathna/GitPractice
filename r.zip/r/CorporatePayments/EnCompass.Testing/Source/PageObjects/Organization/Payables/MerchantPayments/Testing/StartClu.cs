﻿using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Common.Utility;
using NFluent;

namespace EnCompass.Testing.Source.PageObjects.Organization.Payables.MerchantPayments.Testing
{
    public partial class StartClu
    {
        public override string PageIdentifierXPath_Override => @"//label[contains(@id, 'lblCycleDate')]";

        #region XPath page Elements
        private const string _ecluCycleDateXPath = @"//input[contains(@id, 'txtCycleDate')]";
        private const string _enableLiveCreditLimitUpdatesXPath = @"//input[contains(@id,'cbEnableLiveUpdates')]";
        private const string _startECLUCLUXPath = @"//input[contains(@id, 'StartECLUButton')]";
        private const string _testingCardsXPath = @"//ul[contains(@id, 'sideNav')]//li[1]";
        private const string _testingCreateCardTransactionsXPath = @"//ul[contains(@id, 'sideNav')]//li[2]";
        private const string _testingSingleUseAccountsXPath = @"//ul[contains(@id, 'sideNav')]//li[3]";
        private const string _testingSingleUseAccountTransactionsXPath = @"//ul[contains(@id, 'sideNav')]//li[4]";
        private const string _testingCreditLimitUpdateXPath = @"//ul[contains(@id, 'sideNav')]//li[5]";
        private const string _testing_DailyExtractFilesXPath = @"//ul[contains(@id, 'sideNav')]//li[6]";

        #endregion
       

        #region Page Elements
        private IWebElement _ecluCycleDate
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_ecluCycleDateXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_ecluCycleDate element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _enableLiveCreditLimitUpdates
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_enableLiveCreditLimitUpdatesXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_enableLiveCreditLimitUpdates element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _startECLUCLU
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_startECLUCLUXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_startECLUCLU element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _testingCards
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_testingCardsXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_testingCards element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _testingCreateCardTransactions
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_testingCreateCardTransactionsXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_testingCreateCardTransactions element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }

        }
        private IWebElement _testingSingleUseAccounts
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_testingSingleUseAccountsXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_testingSingleUseAccountsXPath element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _testingSingleUseAccountTransactions
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_testingSingleUseAccountTransactionsXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_testingSingleUseAccountTransactions element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _testingCreditLimitUpdate
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_testingCreditLimitUpdateXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_testingCreditLimitUpdate element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _testingDailyExtractFiles
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_testing_DailyExtractFilesXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_testing_DailyExtractFiles element exist is " + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        #endregion
        
        public void NavigateTo_DailyExtractFiles()
		{
			NavigateToMenuItem(_testingDailyExtractFiles);
		}

		public string ECLUCycleDate
        {
            set
            {
                _ecluCycleDate.SendKeys(value);
            }
        }

        public void SetCheckboxState(bool checkStatus)
        {
            bool isChecked = _enableLiveCreditLimitUpdates.Selected;
            if (isChecked != checkStatus)
            {
                _enableLiveCreditLimitUpdates.JSClickWithFocus(Driver);
            }
        }

        public void StartECLUCLU()
        {
            _startECLUCLU.JSClickWithFocus(Driver);
            WaitForLoad();
        }

        public void NavigateTo_Cards()
        {
            NavigateToMenuItem(_testingCards);
        }

        public void NavigateTo_CreateCardTransactions()
        {
            NavigateToMenuItem(_testingCreateCardTransactions);
        }

        public void NavigateTo_SingleUseAccounts()
        {
            NavigateToMenuItem(_testingSingleUseAccounts);
        }
        public void NavigateTo_SingleUseAccountTransactions()
        {
            NavigateToMenuItem(_testingSingleUseAccountTransactions);
        }
        public void NavigateTo_CreditLimitUpdate()
        {
            NavigateToMenuItem(_testingCreditLimitUpdate);
        }
    }
}
