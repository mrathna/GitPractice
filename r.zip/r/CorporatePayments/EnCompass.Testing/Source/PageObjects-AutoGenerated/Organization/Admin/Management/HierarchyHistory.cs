using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using Common;
using Common.PageObjects;
using Common.ScenarioConfigurations;
using Common.Utility;

namespace EnCompass.Testing.Source.PageObjects.Organization.Admin.Management 
{
	/// <summary>
	/// Auto-generated Page Model Class
	/// Navigation Paths: 
		/// [Organization Home]->Administration->Card Hierarchy->History
		/// </summary>
	[PageModel(@"/admin/management/HierarchyHistory.aspx")]
	public partial class HierarchyHistory : EnCompassOrgPageModel 
	{
		public override string RelativeUrl => @"/admin/management/HierarchyHistory.aspx";
		public override string PageIdentifierXPath_Generated => @"//li[contains(@class, 'breadcrumb-item active')][text() = 'History']";

		#region Navigation
				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Create or Edit']")]
		private IWebElement _administration_CardHierarchy_History_CreateOrEdit { get; set; }
		public void NavigateTo_Administration_CardHierarchy_History_CreateOrEdit()
		{
			NavigateToMenuItem(_administration_CardHierarchy_History_CreateOrEdit);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Move Cards']")]
		private IWebElement _administration_CardHierarchy_History_MoveCards { get; set; }
		public void NavigateTo_Administration_CardHierarchy_History_MoveCards()
		{
			NavigateToMenuItem(_administration_CardHierarchy_History_MoveCards);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='History']")]
		private IWebElement _administration_CardHierarchy_History_History { get; set; }
		public void NavigateTo_Administration_CardHierarchy_History_History()
		{
			NavigateToMenuItem(_administration_CardHierarchy_History_History);
		}

		
		private void NavigateToMenuItem(IWebElement element)
		{
			Driver.Url = element.GetAttribute("href");
		}
		#endregion

		public HierarchyHistory(GlobalSettings settings) : base(settings) { }
	}  
}
