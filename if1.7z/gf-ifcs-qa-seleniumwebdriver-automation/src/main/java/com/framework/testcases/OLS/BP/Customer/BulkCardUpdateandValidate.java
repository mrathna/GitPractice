package com.framework.testcases.OLS.BP.Customer;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.common.Common;
import com.framework.pages.AJS.common.IFCSLoginPage;

public class BulkCardUpdateandValidate extends BaseTest{
	@Parameters({"clientCountry","clientName"})
	@Test( groups = { "Smoke", "Regression" })
	public void Validate_Bulk_Card_Order(@Optional("AU") String clientCountry, @Optional("BP") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  BP Bulk Card Order/Update/Status Validation", "Validate the Bulk Card Operation");
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		//IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		//CardMaintenancePage cardMaintenancePage = new CardMaintenancePage(driver, test);
		Common common = new Common(driver, test);
		// Calling Functions
		IFCSloginPage.login("IFCS_URL_BP", "IFCS_BP_USERNAME", "IFCS_BP_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		//IFCSHomePage.gotoAdminMenuAndChooseClient();
		//IFCSHomePage.gotoAdminBatchMenuAndChooseClient(clientName + "_" + clientCountry);
		//IFCSHomePage.gotoCustomerMenuCustomerDetails();
		common.batchJobExecution("Card Processing", "Online Card Management Request", "Online Card Detail Update Request Processor");
		common.searchCardnumberAndValidate("Full", "Filter By");
		
		
		
		
		
		/*LoginPage loginPage = new LoginPage(driver, test);
		BPHomePage bpHomePage = new BPHomePage(driver, test);
		if(clientName.equals("BP")) {
			loginPage.Login("BP_URL", "BP_UN_Customer_" + clientCountry, "BP_PWD_Customer_" + clientCountry, clientName);
		} else {
			loginPage.Login("BPPREPAID_URL", "BPPREPAID_UN_Customer_" + clientCountry, "BPPREPAID_PWD_Customer_" + clientCountry, clientName);
		}
		bpHomePage.ValidateBPCustomerLogo();
        CommonPage commonPage = new CommonPage(driver,test);
		BPCommonPage bpCommonPage = new BPCommonPage(driver, test);
		BulkOrderAndUpdatePage bulkOrdeAndUpdatePage = new BulkOrderAndUpdatePage(driver, test);
// ** Bulk Card Order
		// Choose a Account
		bpCommonPage.selectAccount();

				// Load Bulk Order and Update Page
		bpHomePage.loadBulkOrderAndUpdateCardPage();

		// Select Bulk Card Order radio button
		bulkOrdeAndUpdatePage.selectBulkCardOperation("Bulk Card Update");

		// Click Upload Option
		bulkOrdeAndUpdatePage.clickUploadBulkUpdate();

		// Click Upload Option and check popup
		bulkOrdeAndUpdatePage.clickCloseInBulkCardUpdatePopup(); 

		bulkOrdeAndUpdatePage.selectAllAccountFromBulkCardOperation("Update");

		bulkOrdeAndUpdatePage.clickAdvancedSearchOption();

		bulkOrdeAndUpdatePage.bulkCardUpdateSearch();

		// ** Below commented Actions are covered in bulkCardUpdateSearch()

		bulkOrdeAndUpdatePage.selectBulkCardStatus("Bulk Card Update","Active");

		// Search Cards
		bulkOrdeAndUpdatePage.clickSearchCard("Bulk Card Update");


		// Click View Card Results and check popup
		bulkOrdeAndUpdatePage.clickViewCardSearchResults();

		// Click view card results and check popup
		bulkOrdeAndUpdatePage.clickCloseInViewCardResultsPopup();

		// Check cards to excel option
		bulkOrdeAndUpdatePage.checkCardsToExcelDownloadLink(); */

		

				

	}

}
