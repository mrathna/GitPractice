package com.framework.testcases.AJS.EMAP;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.MerchantLocationPage;
import com.framework.pages.AJS.common.Common;
import com.framework.pages.AJS.common.IFCSHomePage;
import com.framework.pages.AJS.common.IFCSLoginPage;
import com.github.javafaker.Faker;

public class ValidateLocationTestCases extends BaseTest{
	@Parameters({ "clientCountry", "clientName"})
	@Test( groups = { "Regression" })
	public void ValidateToCreateLocation(@Optional("SG") String clientCountry,
			@Optional("EMAP") String clientName) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  TST-SC-25-Create Location",
				"TST-SC-25-Create Location");
		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		Common common=new Common(driver,test);
		MerchantLocationPage  merchantLocation=new MerchantLocationPage(driver,test);
		IFCSloginPage.login("IFCS_URL_EMAP", "IFCS_EMAP_USERNAME", "IFCS_EMAP_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry," ");
		IFCSHomePage.gotoApplicationAndClickApplicationMenu();
		IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);
		IFCSHomePage.gotoMerchantAndClickMerchantDetails();
		String locationNoFromDB=common.getLocationNoFromDB();
		merchantLocation.chooseLocationNoFromListAndDoubleClick(locationNoFromDB);
		//common.chooseLocationNoAndSearch(location);
		Faker fakerNumber = new Faker();
		String f_locationNo = fakerNumber.number().digits(6);
		merchantLocation.createNewLocation(f_locationNo);	
		IFCSHomePage.exitIFCS();
	}
}
