package com.framework.pages.SHELL;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.ExtentTest;
import com.framework.basepage.BasePage;
import com.framework.pages.OLS.HomePage;
import com.framework.repo.Locator;
import com.framework.util.PropUtils;

public class SHELLChangePasswordPage extends BasePage {

	@FindBy(xpath = Locator.PAGETITLE)
	public WebElement pageTitle;

	@FindBy(xpath = Locator.USER_ID)
	public WebElement adminUserId;

	@FindBy(xpath = Locator.SHELL_CHANGE_PASSWORD)
	public WebElement adminChangePassword;

	@FindBy(xpath = Locator.CHANGE_NEW_PASSWORD)
	public WebElement adminChangeNewPassword;

	@FindBy(xpath = Locator.CHANGE_CONFIRM_PASSWORD)
	public WebElement adminChangeConfirmPassword;

	@FindBy(xpath = Locator.CHANGE_PASSWORD_ERROR_MESSAGE)
	public WebElement errorMessage;

	@FindBy(xpath = Locator.CHANGE_PASSWORD_SUCCESS_MESSAGE)
	public WebElement successMessage;

	@FindBy(xpath = Locator.PAGETITLE)
	public WebElement titleHeader;
	
	@FindBy(id = Locator.CARD_INFORMATION_SAVECHANGES)
	public WebElement saveBtn;
	
	@FindBy(xpath = Locator.DISPLAYED_LOGON_ID)
	public WebElement displayedLogonId;
	
	HomePage homePage = new HomePage(driver, test);
	
	
	public SHELLChangePasswordPage(WebDriver driver, ExtentTest test) {

		super(driver, test);
		PageFactory.initElements(driver, this);

	}

	public void verifyCustomerAdminUserId() {

		String displayedUserId = getText(displayedLogonId);
		/* getText(adminUserId) */;
		if (displayedUserId.equals("spccat")) {
			logPass("User ID was successful");

		} else {
			logInfo("User ID mismatched");
		}

	}

	/*public void changePassword(String password, String newPassword) {

		System.out.println("change pwd 1");
		isDisplayedThenEnterText(adminChangePassword, "Enter Existing Password", password);
		System.out.println("change pwd 2");
		isDisplayedThenEnterText(adminChangeNewPassword, "Enter New Password", newPassword);
		isDisplayedThenEnterText(adminChangeConfirmPassword, "Enter Confirm Password", newPassword);
		isDisplayedThenActionClick(saveBtn, "click save Btn");
		sleep(3);

	}*/

	public void enterInvalidPwdValidNewPwdConfirmPwdAndValidate() {

		homePage.changePassword("Pass", "Password01#");
		sleep(3);
		isDisplayed(errorMessage, "Error Message Displayed");

	}

	public void enterPwdInvalidNewPwdConfirmPwdAndValidate() {

		homePage.changePassword("Password02#", "password");
		sleep(3);
		isDisplayed(errorMessage, "Error Message Displayed");

	}

	public void enterPwdLessThanNewPwdConfirmPwdAndValidate() {

		homePage.changePassword("Password02#", "Pass");
		sleep(3);
		isDisplayed(errorMessage, "Error Message Displayed");

	}

	public void enterValidPwdNewPwdConfirmPwdAndValidate(String currentPassword) {
		driver.get(PropUtils.getPropValue(configProp, currentPassword));
		System.out.println("---currentPassword---"+currentPassword);
		homePage.changePassword(currentPassword, currentPassword+"#");
		sleep(3);
		isDisplayed(successMessage, "Success Message Displayed");
	}

	public void validatePasswordMaintenancePage() {
		
//			checkTextInPageAndValidate("Password Maintenance", 20);
		verifyText(titleHeader, "PASSWORD MAINTENANCE");
//			checkTextInPageAndValidate("PASSWORD MAINTENANCE", 20);
		
		

	}
}
