package com.framework.pages.OLS.common;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.ExtentTest;
import com.framework.basepage.BasePage;
import com.framework.repo.Locator;

public class PastReportsPage extends BasePage {

	public PastReportsPage(WebDriver driver, ExtentTest test) {
		super(driver, test);
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = Locator.VIEW_ALL_IN_GENERATE_REPORT_TABLE)
	public List<WebElement> viewAllInGenerateReportTable;

	@FindBy(id = Locator.DOWNLOAD_LISTED_REPORTS_AS_ZIP)
	public WebElement downloadReportsAsZip;

	@FindBy(xpath = Locator.PAGE_TITLE_DP)
	public WebElement commonTitle;

	@FindBy(xpath = Locator.ERR_MSG)
	public WebElement errorMessage;

	@FindBy(id = Locator.RETURN_PAST_REPORT_BUTTON)
	public WebElement returnToPastReports;

	@FindBy(xpath = Locator.VIEW_ALL_IN_RECURRING_REPORT_TABLE)
	public List<WebElement> viewAllInRecurringReportTable;

	@FindBy(id = Locator.STORED_REPORTS_TABLE)
	public WebElement storedReportsTable;

	@FindBy(id = Locator.REPORTS_FILENAME)
	public WebElement reportsFileName;

	@FindBy(id = Locator.REPORTS_CREATED_FROM)
	public WebElement reportsCreatedFrom;

	@FindBy(id = Locator.REPORTS_CREATED_TO)
	public WebElement reportsCreatedTo;

	@FindBy(id = Locator.FILTER_BTN)
	public WebElement filterButton;

	
	@FindBy(how = How.ID, using = Locator.ACCOUNTS_DROPDOWN)
	public WebElement accountsDropDown;
	@FindBy(how = How.XPATH, using = Locator.REPORT_TYPE_LINK)
	public WebElement reportTypeLink;
	@FindBy(how = How.ID, using = Locator.DOWNLOAD_GENREPORT)
	public WebElement downLoadGenReport;
	@FindBy(id=Locator.GEN_REPORTS_TABLE)
	public WebElement genReportsTable; 

	@FindBy(xpath = Locator.REPORT_COUNT)
	public WebElement reportCount;

	@FindBy(id = Locator.CLEAR_FILTER_AND_SHOW_ALL)
	public WebElement clearFilterAndShowAll;
	
	@FindBy(how = How.ID, using = Locator.REPORTS_MENU)
	public WebElement reportsMenu;

	@FindBy(how = How.ID, using = Locator.STORED_REPORTS)
	public WebElement storedReports;
	
	@FindBy(how = How.XPATH, using = Locator.PAGE_TITLE1)
	public WebElement accountPageTitle;
	
	@FindBy(how = How.ID, using = Locator.ADHOC_REPORTS_SUBMENU)
	public WebElement adhocReportsSubmenu;
	
	@FindBy(how = How.XPATH, using = Locator.PAGE_TITLE_REISSUECARD)
	public WebElement pageTitle;

	private String accountname = "";
//	private String expAccount= "";

	boolean generateReportTablePresent = true, recurringReportTable = true;
	boolean noReport;
	String dateGenerated, dateTo, fileName;

	public void selectViewAllInGenerateReportTable() {
		try {
			if (viewAllInGenerateReportTable.size() > 0) {
				int randomNo;
				if (viewAllInGenerateReportTable.size() == 1) {
					randomNo = 0;
				} else {
					randomNo = getRandomNumber(0, viewAllInGenerateReportTable.size() - 1);
				}
				isDisplayedThenClick(viewAllInGenerateReportTable.get(randomNo), "View all in generate report table");
				sleep(3);

			} else {
				generateReportTablePresent = false;
				logInfo("Generate report table not present");
			}
		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
	}

	public void selectViewAllInRecurringReportTable() {
		try {
			if (viewAllInRecurringReportTable.size() > 0) {
				int randomNo;
				if (viewAllInRecurringReportTable.size() == 1) {
					randomNo = 0;
				} else {
					randomNo = getRandomNumber(0, viewAllInRecurringReportTable.size() - 1);
				}
				isDisplayedThenClick(viewAllInRecurringReportTable.get(randomNo), "View all in recurring report table");
				sleep(3);

			} else {
				recurringReportTable = false;
				logInfo("My Recurring report table not present");
			}
		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
	}

	public void verifyReportPageTitle(String expectedTitle) {
		System.out.println("Page Title::" + getText(commonTitle));
		if (getText(commonTitle).contains(expectedTitle)) {
			logPass("View All Report Detail page loaded");
		} else {
			logFail("View All Report Detail page not loaded");
		}
	}

	public boolean isGenerateReportTablePresent() {
		return generateReportTablePresent;
	}

	public boolean isMyRecurringReportTablePresent() {
		return recurringReportTable;
	}

	public void clickDownloadReportsAsZip() {
		noReport = waitForTextToAppear("0 Reports", 10);
		if (!noReport) {
			isDisplayedThenClick(downloadReportsAsZip, "Download reports as zip");
			sleep(2);
		} else {
			logInfo("No Reports to download as zip");
		}
	}

	public void checkReportAvailability() {
		try {
			if (errorMessage.isDisplayed() && !noReport) {
				logInfo(getText(errorMessage));
			}
		} catch (Exception ex) {
			logInfo("No error message");
		}
	}

	public void returnToPastReportsPage() {
		isDisplayedThenClick(returnToPastReports, "Return to past report page");
		sleep(3);
	}

	public void setDateAndReportFileName() {
		setCellDataFromTable(storedReportsTable, 2, false);
		dateGenerated = getCellDataFromTable(1, 0, false);
		fileName = getCellDataFromTable(1, 1, false);
	}

	public void enterFileNameFilter() {
		isDisplayedThenEnterText(reportsFileName, "Filename for report", fileName);
	}

	public void enterDateFromFilter() {
		isDisplayedThenEnterText(reportsCreatedFrom, "Report Created From Date", dateGenerated);
	}

	public void enterDateToFilter() {
		try {
			Date dateGen = new SimpleDateFormat("dd/MM/yyyy").parse(dateGenerated);
			Date newDate;
			Calendar cal = Calendar.getInstance();
			cal.setTime(dateGen);
			cal.add(Calendar.MONTH, +3);
			newDate = cal.getTime();
			DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
			dateTo = df.format(newDate);
			isDisplayedThenEnterText(reportsCreatedTo, "Report Created From To", dateTo);
		} catch (Exception e) {
			logFail(e.getMessage());
		}
	}

	public void validateSearchResultsWithFileNameFilter() {
		boolean fileNameFound = false;
		setCellDataFromTable(storedReportsTable, 2, true);
		int rowSize = getRowSize(storedReportsTable);
		for (int i = 1; i < rowSize - 1; i++) {
			System.out.println("Filename Got::" + getCellDataFromTable(i, 1, true));
			if (getCellDataFromTable(i, 1, true).contains(fileName)) {
				fileNameFound = true;
			} else {
				fileNameFound = false;
				break;
			}
		}
		if (fileNameFound) {
			logPass("Filename used in the filter present in the search results");
		} else {
			logFail("Filename used in the filter not present in the search results");
		}
	}

	public void validateSearchResultsWithDateFilter() {
		boolean dateFilterWork = false;
		setCellDataFromTable(storedReportsTable, 2, true);
		int rowSize = getRowSize(storedReportsTable);
		try {
			Date dateFrom = new SimpleDateFormat("dd/MM/yyyy").parse(dateGenerated);
			Date dateToValue = new SimpleDateFormat("dd/MM/yyyy").parse(dateTo);
			for (int i = 1; i < rowSize - 1; i++) {
				Date dateActual = new SimpleDateFormat("dd/MM/yyyy").parse(getCellDataFromTable(i, 0, true));
				if ((dateActual.after(dateFrom) || dateActual.equals(dateFrom))
						&& (dateActual.before(dateToValue) || dateActual.equals(dateToValue))) {
					dateFilterWork = true;
				} else {
					dateFilterWork = false;
					break;
				}
			}
		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
		if (dateFilterWork) {
			logPass("Generated dates in the search results matches the filter 'Date From'");
		} else {
			logFail("Generated dates in the search results does not matches the filter 'Date From'");
		}
	}

	public void validateClearFilterOptionsAndShowAll() {
		int searchResultsCountBefore, searchResultsCountAfter;
		searchResultsCountBefore = Integer.parseInt(getText(reportCount).split(" Reports")[0]);
		isDisplayedThenClick(clearFilterAndShowAll, "Clear Filter");
		sleep(3);
		clickFilterButton();
		sleep(3);
		searchResultsCountAfter = Integer.parseInt(getText(reportCount).split(" Reports")[0]);
		if (searchResultsCountAfter >= searchResultsCountBefore) {
			logPass("Clear Filter and Show all returns all reports");
		} else {
			logFail("Clear Filter and Show all doesn't returns all reports");
		}
	}

	public void clickFilterButton() {
		isDisplayedThenClick(filterButton, "Filter Button");
		sleep(2);
	}

	
	public boolean checkReportTypeDetailLink() {
		try {
			isDisplayedThenActionClick(reportTypeLink, "Report Type Table");
			return true;
		} catch (Exception ex) {
			ex.printStackTrace();
			return false;
		}
	}
	

	public void selectAccountFromDropDownAndDownloadTheReport() {
		
		int dropDownSize = getDropdownSize(accountsDropDown);
		
		boolean temp =false;
		
		for (int i = 0; i < dropDownSize; i++) {
			selectDropDownByIndex(accountsDropDown, i);
			accountname = selectedStringFrmDropDown(accountsDropDown);
			System.out.println(accountname);
			
			sleep(5);
			
			System.out.println(accountname);
			
						
			boolean noBPReports = waitForTextToAppear("Your account has no system generated reports", 15);
					
			System.out.println("---- no Reports ---"+noBPReports);
					
			if (noBPReports) {
						
				logInfo("No Bp Plus Report Table present for the Account = "+accountname);
						
						
			} else {
						
				System.out.println("Comes in here ---- "+accountname);
						
				isDisplayed(genReportsTable, "Generate Reports Table is present");
						
				WebElement firstRow = genReportsTable.findElement(By.xpath("./tbody[contains(@id,'lform:genRepTable:tb')]/tr[1]"));
						
				isDisplayed(firstRow, "First Row in Gen Reports Table");
						
				WebElement reportTypeDetail = firstRow.findElement(By.xpath("./td[1]/div/a"));
						
				isDisplayedThenClick(reportTypeDetail, "ReportType Detail in first Row");
						
				sleep(4);
									
				WebElement downloadReport = firstRow.findElement(By.xpath(".//a[contains(@id,'mnuDownloadGenReport')]"));
														
				isDisplayedThenActionClick(downloadReport, "Downloaded genReports copy");
						
				logPass("Clicked download Report link");
						
				temp = true;
						
				break;
				
			}
			
			
					
			if(temp)
				break;
		}
	}

}
