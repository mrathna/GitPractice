﻿using Common;
using Common.PageObjects;
using Common.Utility;
using NFluent;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using System;

namespace EnCompass.Testing.Source.PageObjects.Organization.Admin.Management
{
    [PageModel(@"/admin/management/MoveCardAccounts.aspx")]
    class MoveCards :EnCompassOrgPageModel
    {
        public override string RelativeUrl => @"/admin/management/MoveCardAccounts.aspx";
        public override string PageIdentifierXPath_Override => @"//h1[text()='Move Cards']";

        #region XPath page Elements

        private string _parentHierarchyList = "//li[contains(@class,'orgParent')]/div";
        private string _hierarchyModalXpath = "//div[contains(@id,'hierachyExplorer_modal')]";
        private string _moveCardSuccMsgXpath = @"//div[contains(@class,'alert-success')]//p";

        private const string _moveCardAlertXPath = @"//div[contains(@class,'alert-warning')]/p";
        private const string _moveCardsToFindOptionXPath = @"//a[contains(@id,'hierarchyExplorerTo')]";
        private const string _moveCardsFromFindOptionXPath = @"//a[contains(@id,'hierarchyExplorerFrom')]";
        private const string _modalFinishXPath = @"//modal[contains(@id,'finish')]";

        private const string _selectedToHierarchyXPath = @"//div[contains(@id,'hierarchyExplorerTo')]//button[contains(@data-original-title,'Level')]";
        private const string _selectedFromHierarchyXPath = @"//div[contains(@id,'hierarchyExplorerFrom')]//button[contains(@data-original-title,'Level')]";
        private const string _moveAllCardsXPath = @"//input[contains(@id,'rdoMoveAll')]";
        private const string _moveCardsSaveBtnXPath = @"//input[@type='submit']";
        private const string _moveAllCardsTextXPath = @"//div[contains(@id,'MoveAlllabel')]//label";
        private const string _selectIndividualCardXPath = @"//label[text()='Select individual cards ']";
        private const string _cardOneCheckBoxXPath = @"//tbody/tr[1]//label";
        private const string _cardOneNoXPath = @"//tbody//tr[1]//td[1]";
        private const string _saveBtn = "//input[@value='Save']";
        #endregion

        #region Page Elements

        private IWebElement _moveCardAlert
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_moveCardAlertXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_moveCardAlert element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _moveCardsToFindOption
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_moveCardsToFindOptionXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_moveCardsToFindOption element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _moveCardsFromFindOption
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_moveCardsFromFindOptionXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_moveCardsFromFindOption element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _modalFinish
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_modalFinishXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_modalFinish element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _selectedToHierarchy
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_selectedToHierarchyXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_selectedToHierarchy element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _selectedFromHierarchy
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_selectedFromHierarchyXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_selectedFromHierarchy element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _moveAllCards
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_moveAllCardsXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_moveAllCards element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _moveCardsSaveBtn
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_moveCardsSaveBtnXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_moveCardsSaveBtn element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _moveAllCardsText
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_moveAllCardsTextXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_moveAllCardsText element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _selectIndividualCard
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_selectIndividualCardXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_selectIndividualCard element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _cardOneCheckBox
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_cardOneCheckBoxXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_save element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _cardOneNo
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_cardOneNoXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_cardOneNo element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        #endregion

        public string DefaultAlert
        {
            get
            {
                return _moveCardAlert.Text;
            }
        }

        public string SelectedToHierarchyText
        {
            get
            {
                return _selectedToHierarchy.Text;
            }
        }
      
        public string SelectedFromHierarchyText
        {
            get
            {
                return _selectedFromHierarchy.Text;
            }
        }

        public void ClickMoveCardsFromSearchIcon()
        {
            _moveCardsFromFindOption.JSClickWithFocus(Driver);
        }

        public void ClickMoveCardsToSearchIcon()
        {
            _moveCardsToFindOption.JSClickWithFocus(Driver);
        }

        public void ClickSaveButton()
        {
            Driver.TryWaitForElementToBeVisible(By.XPath(_saveBtn), out IWebElement element);
            _moveCardsSaveBtn.JSClickWithFocus(Driver);
            this.AttachOnDemandScreenShot();
            Settings.EnCompassExtentTest.Info("Clicked on Save button");
        }

        /**
         * wait for the expected hierarchy to load from the modal and click the hierarchy
         * wait until the modal is closed.
         */

		public void SelectHierarchyFromModal(string hierarchyName)
        {
			IWebElement _hierarchyCheckBox, _hierarchyCheckBoxLabel;
            //Wait for hierarchy list to be rendered
            WaitForModalToAppear(_hierarchyModalXpath);
            if (hierarchyName.ToLowerInvariant().Equals("toplevel"))
            {
                _hierarchyCheckBox = Settings.EnCompassWebDriver.WaitFor(By.XPath(_parentHierarchyList + "//input"));
                _hierarchyCheckBoxLabel = Settings.EnCompassWebDriver.WaitForVisible(By.XPath(_parentHierarchyList + "//span"));
                _hierarchyCheckBoxLabel.WaitUntilElementIsInteractable();
            }                
            else
            {
                _hierarchyCheckBox = Settings.EnCompassWebDriver.WaitFor(By.XPath("//div[descendant::span[contains(text(),'" + hierarchyName + "')]]/input"));
                _hierarchyCheckBoxLabel = Settings.EnCompassWebDriver.WaitForVisible(By.XPath("//div[descendant::span[contains(text(),'" + hierarchyName + "')]]/label"));
                _hierarchyCheckBoxLabel.WaitUntilElementIsInteractable();
            }
                //Expected hierarchy selected from the dropdown.
                _hierarchyCheckBoxLabel.JSClickWithFocus(Driver);                                      
                WaitForModalToDisappear(_hierarchyModalXpath);
                WaitForFormLoadingOverlay(TimeSpan.FromSeconds(60));         
        }       

        public string GetMoveAllText
        {            
            get
            {                
                return _moveAllCardsText.Text.Split(new[] { "all cards" }, StringSplitOptions.None)[1];
            }
        }
	
		public string MoveCardsSuccessMessage
        {           
            get
            {
                Driver.WaitForDocumentLoadToComplete();
                IWebElement _moveCardsSuccessMsg = Driver.WaitForVisible(By.XPath(_moveCardSuccMsgXpath));
                return _moveCardsSuccessMsg.Text;
            }
        }

        public void SelectIndividualCard()
        {           
            _selectIndividualCard.JSClickWithFocus(Driver);
            Settings.EnCompassExtentTest.Info("Clicked move individual cards checkbox.");
            Driver.WaitElementBeClickable(_cardOneCheckBoxXPath);
            _cardOneCheckBox.JSClickWithFocus(Driver, _cardOneCheckBoxXPath,Settings);
        }
        
        public string GetFirstCardNo
        {            
            get
            {
                //Return last four digits of the card number
                return _cardOneNo.Text.Substring(_cardOneNo.Text.Length - 4);
            }
        }

        public MoveCards(GlobalSettings settings) : base(settings) { }
    }

}
