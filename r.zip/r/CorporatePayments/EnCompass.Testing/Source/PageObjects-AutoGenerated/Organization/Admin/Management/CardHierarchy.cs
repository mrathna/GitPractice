using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using Common;
using Common.PageObjects;
using Common.ScenarioConfigurations;
using Common.Utility;

namespace EnCompass.Testing.Source.PageObjects.Organization.Admin.Management 
{
	/// <summary>
	/// Auto-generated Page Model Class
	/// Navigation Paths: 
		/// [Organization Home]->Administration->Card Hierarchy
		/// [Organization Home]->Administration->Card Hierarchy->Create or Edit
		/// </summary>
	[PageModel(@"/Admin/Management/CardHierarchy.aspx")]
	public partial class CardHierarchy : EnCompassOrgPageModel 
	{
		public override string RelativeUrl => @"/Admin/Management/CardHierarchy.aspx";
		public override string PageIdentifierXPath_Generated => @"//li[contains(@class, 'breadcrumb-item active')][text() = 'Create or Edit']";

		#region Navigation
				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Create or Edit']")]
		private IWebElement _administration_CardHierarchy_CreateOrEdit { get; set; }
		public void NavigateTo_Administration_CardHierarchy_CreateOrEdit()
		{
			NavigateToMenuItem(_administration_CardHierarchy_CreateOrEdit);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Move Cards']")]
		private IWebElement _administration_CardHierarchy_MoveCards { get; set; }
		public void NavigateTo_Administration_CardHierarchy_MoveCards()
		{
			NavigateToMenuItem(_administration_CardHierarchy_MoveCards);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='History']")]
		private IWebElement _administration_CardHierarchy_History { get; set; }
		public void NavigateTo_Administration_CardHierarchy_History()
		{
			NavigateToMenuItem(_administration_CardHierarchy_History);
		}

		
		private void NavigateToMenuItem(IWebElement element)
		{
			Driver.Url = element.GetAttribute("href");
		}
		#endregion

		public CardHierarchy(GlobalSettings settings) : base(settings) { }
	}  
}
