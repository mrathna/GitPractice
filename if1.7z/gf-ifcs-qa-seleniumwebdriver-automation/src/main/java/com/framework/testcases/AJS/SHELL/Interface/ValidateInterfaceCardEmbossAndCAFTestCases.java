package com.framework.testcases.AJS.SHELL.Interface;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.CardMaintenancePage;
import com.framework.pages.AJS.OrderCardPage;
import com.framework.pages.AJS.common.Common;
import com.framework.pages.AJS.common.CommonInterfacePage;
import com.framework.pages.AJS.common.IFCSCommonPage;
import com.framework.pages.AJS.common.IFCSHomePage;
import com.framework.pages.AJS.common.IFCSLoginPage;
import com.framework.pages.AJS.common.InterfacePage;
import com.framework.pages.OLS.HomePage;
import com.framework.pages.OLS.common.LoginPage;
import com.framework.pages.SHELL.SHELLHomePage;

public class ValidateInterfaceCardEmbossAndCAFTestCases extends BaseTest {
	//Execution-->1
    @Parameters({ "clientCountry", "clientName","cardType"})
	@Test(groups = {"Smoke"})
	public void validateOrderNewCardAndGenerateFile(@Optional("CZ") String clientCountry, @Optional("SH") String clientName, @Optional("APA") String cardType) {
		String orderedCardNumber = null;
		String fileName = "";
		String folderName="";
		String jobsInOrder="";
        test = extent.createTest(clientName+ ":" +clientCountry+"  SHELL Interface Order New Card and CardEmbossing Job via ControlM", "Order Card and Card Embossing");
		//creating object for the Pages
		IFCSLoginPage ifcsloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage ifcsHomePage = new IFCSHomePage(driver, test);
		Common common = new Common(driver, test);
		OrderCardPage orderCardpage = new OrderCardPage(driver, test);
		IFCSCommonPage ifcsCommonPage = new IFCSCommonPage(driver, test);
		CommonInterfacePage commonInterfacePage = new CommonInterfacePage(driver, test);
		InterfacePage interfacePage = new InterfacePage(driver,test);
		
		// Calling Functions
		ifcsloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");
		ifcsloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, cardType);
		ifcsHomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);
		String customerNumber = common.getActiveCustomerNoUsingCardType();
		
		ifcsHomePage.gotoCustomerMenuCustomerDetails();
		common.chooseCustomerNoAndSearch(customerNumber);
		orderedCardNumber=orderCardpage.orderNewCardAndValidate();
		
		System.out.println("Newly ordered card:: :: "+orderedCardNumber);
		
		if(clientCountry.equals("PH")) {
			fileName = commonInterfacePage.getRecentProcessedFileName(configProp, clientName, clientCountry, 1,"EmbossCards");
			folderName = ifcsCommonPage.getControlMFolder(clientName, clientCountry, "jobS_emboss_PH");
			jobsInOrder =  ifcsCommonPage.getJobsOfFolderInOrder("jobS_emboss_PH");
		}else {
			fileName = commonInterfacePage.getRecentProcessedFileName(configProp, clientName, clientCountry, 1,"PinMailer");
			folderName = ifcsCommonPage.getControlMFolder(clientName, clientCountry, "jobS_emboss");
			jobsInOrder =  ifcsCommonPage.getJobsOfFolderInOrder("jobS_emboss");
		}
		interfacePage.establishAndExecuteControlMJobs("ControlM_AWS_UAT","ContorlM_AWS_userName","ContorlM_AWS_password",folderName,jobsInOrder);
		
		ifcsCommonPage.establishThePuttyConnection("incomingFile", "PUTTY_HOST", "PUTTY_USERNAME", "PUTTY_PASSWORD", "IE_OUTPUTFILE_FOLDER_CAF", fileName);
		System.out.println("fileNamefileName::"+fileName);
		String localFolder = System.getProperty("user.home")+"\\Documents\\"+fileName;
		interfacePage.updateOrValidateFlatFile(cardembossconfigProp, "incomingFile", localFolder, orderedCardNumber, clientName, clientCountry, "");
				
	}
     
    //Execution-->2
	@Parameters({ "clientCountry", "clientName","cardType"})
	@Test(groups = {"Smoke"},enabled=false)
	public void validateReissuePINAndGenerateFile(@Optional("CZ") String clientCountry, @Optional("SH") String clientName, @Optional("APA") String cardType) {
		String fileName = "";
		String folderName="";
		String jobsInOrder="";
		test = extent.createTest(clientName+ ":" +clientCountry+"  SHELL Interface Reissue PIN and CardEmbossing Job via ControlM", "Reissue PIN and Card Embossing");
		//creating object for the Pages
		IFCSLoginPage ifcsloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage ifcsHomePage = new IFCSHomePage(driver, test);
		IFCSCommonPage ifcsCommonPage = new IFCSCommonPage(driver, test);
		OrderCardPage orderCardPage = new OrderCardPage(driver, test);
		CommonInterfacePage commonInterfacePage = new CommonInterfacePage(driver, test);
		InterfacePage interfacePage = new InterfacePage(driver,test);

		// Calling Functions
		ifcsloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");
		
		ifcsloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, cardType);
		
		ifcsHomePage.gotoCustomerMenuCustomerDetails();
		
		// Store the reissue card number3
		String reissueCardNumber = orderCardPage.reissuePINCardRequest();
		System.out.println("successfully reissueCardNumber::"+reissueCardNumber);
		
		fileName = commonInterfacePage.getRecentProcessedFileName(configProp, clientName, clientCountry, 1,"PinMailer"); 
		System.out.println("Embose File::"+fileName);
		folderName = ifcsCommonPage.getControlMFolder(clientName, clientCountry, "jobS_emboss");
		jobsInOrder =  ifcsCommonPage.getJobsOfFolderInOrder("jobS_emboss");
		// Executing the Control-M Jobs
		interfacePage.establishAndExecuteControlMJobs("ControlM_AWS_UAT","ContorlM_AWS_userName","ContorlM_AWS_password",folderName,jobsInOrder);	
		
		ifcsCommonPage.establishThePuttyConnection("incomingFile", "PUTTY_HOST", "PUTTY_USERNAME", "PUTTY_PASSWORD", "IE_OUTPUTFILE_FOLDER_CAF", fileName);
		
		// Moving the file into Local Directory
		String localFolder = System.getProperty("user.home")+"\\Documents\\"+fileName;
		interfacePage.updateOrValidateFlatFile(cardembossconfigProp, "incomingFile", localFolder,reissueCardNumber, clientName, clientCountry, "");
		
	}
	
	//Updated
	@Parameters({ "clientCountry", "clientName","cardType"})
	@Test(groups = {"Smoke"})
	public void validateCAFAndPVVFileGeneration(@Optional("CZ") String clientCountry, @Optional("SH") String clientName, @Optional("APA") String cardType) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  04-Desktop reissue PIN via Card Maintenance screen & 02 CAF load the new PVV & 01 CAF Activate the card at first time", "SHELL Interface Reissue PIN and Card Embossing and PVV and CAF to Active");
		//creating object for the Pages
		IFCSLoginPage ifcsloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage ifcsHomePage = new IFCSHomePage(driver, test);
		IFCSCommonPage ifcsCommonPage = new IFCSCommonPage(driver, test);
		OrderCardPage orderCardPage = new OrderCardPage(driver, test);
		CommonInterfacePage commonInterfacePage = new CommonInterfacePage(driver, test);
		InterfacePage interfacePage = new InterfacePage(driver,test);

		// Calling Functions
		ifcsloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");
		
		ifcsloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		
		ifcsHomePage.gotoCustomerMenuCustomerDetails();
		
		// Store the reissue card number
		String reissueCardNumber = orderCardPage.reissuePINCardRequest();
		System.out.println("successfully reissueCardNumber::"+reissueCardNumber);
		
		String embossFileName = commonInterfacePage.getRecentProcessedFileName(configProp, clientName, clientCountry, 1,"PinMailer");
		
		String folderName = ifcsCommonPage.getControlMFolder(clientName, clientCountry, "jobS_emboss");
		String jobsInOrder =  ifcsCommonPage.getJobsOfFolderInOrder("jobS_emboss");	
		// Executing the Control-M Jobs
		interfacePage.establishAndExecuteControlMJobs("ControlM_AWS_UAT","ContorlM_AWS_userName","ContorlM_AWS_password",folderName,jobsInOrder);
		 
		ifcsCommonPage.establishThePuttyConnection("incomingFile", "PUTTY_HOST", "PUTTY_USERNAME", "PUTTY_PASSWORD", "IE_OUTPUTFILE_FOLDER_CAF", embossFileName);
		
		// Moving the file into Local Directory
		String localFolder = System.getProperty("user.home")+"\\Documents\\"+embossFileName;
		interfacePage.updateOrValidateFlatFile(cardembossconfigProp, "incomingFile", localFolder, reissueCardNumber, clientName, clientCountry, "");
		
		System.out.println("Start PVV process");
		// Update and placing PVV file in IE server 
		interfacePage.updateOrValidateFlatFile(pvvconfigProp, "OutgoingFile",
				"IE_INPUTFILE_FOLDER_LOADCARDTRANSACTIONS", reissueCardNumber, clientName, clientCountry,
				"ruj09.txt");
		
		System.out.println("Start PVV Control M Jobs");
//		String folderNamePVV = ifcsCommonPage.getControlMFolder(clientName, clientCountry, "jobS_PVV");
//		String jobsInOrderPVV =  ifcsCommonPage.getJobsOfFolderInOrder("jobS_PVV");
		
		// Executing the PVV Control-M Jobs
		interfacePage.establishAndExecuteControlMJobs("ControlM_AWS_UAT","ContorlM_AWS_userName","ContorlM_AWS_password",folderName,jobsInOrder);
//		interfacePage.establishAndExecuteControlMJobs("ControlM_AWS_UAT","ContorlM_AWS_userName","ContorlM_AWS_password",folderNamePVV,jobsInOrderPVV);
		
		System.out.println("Start CAF process");
		String folderNameCAF = ifcsCommonPage.getControlMFolder(clientName, clientCountry, "jobS_CAF");
		String jobsInOrderCAF =  ifcsCommonPage.getJobsOfFolderInOrder("jobS_CAF");
		
		// Executing the CAF Control-M Jobs
		interfacePage.establishAndExecuteControlMJobs("ControlM_AWS_UAT","ContorlM_AWS_userName","ContorlM_AWS_password",folderNameCAF,jobsInOrderCAF);
		
		String cafFileName = commonInterfacePage.createFileNameFormatforCAFShell(configProp, clientCountry);
		ifcsCommonPage.establishThePuttyConnection("incomingFile", "PUTTY_HOST", "PUTTY_USERNAME", "PUTTY_PASSWORD", "IE_OUTPUTFILE_FOLDER_CAF", cafFileName);

		String localCAFFolder = System.getProperty("user.home")+System.getProperty("file.separator")+"Documents"+System.getProperty("file.separator")+cafFileName;
		ifcsCommonPage.validateCSVFormatIncomingFile(configProp, localCAFFolder, reissueCardNumber);
		
	}
	
	//Execution-->3
	@Parameters({ "clientCountry", "clientName","cardType"})
	@Test(groups = {"Smoke"},enabled=false)
	public void validateActiveCardAndChangedExpiryDate(@Optional("CZ") String clientCountry, @Optional("SH") String clientName, @Optional("APA") String cardType) {

		String fileName = "";
		String folderName="";
		String jobsInOrder="";
		test = extent.createTest(clientName+ ":" +clientCountry+"  SHELL Interface Expiry Date and CardEmbossing Job via ControlM", "Expiry Date Card Number and Card Embossing");
		//creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		IFCSCommonPage ifcsCommonPage = new IFCSCommonPage(driver, test);
		CardMaintenancePage cardMaintenancePage=new CardMaintenancePage(driver,test);
		CommonInterfacePage commonInterfacePage = new CommonInterfacePage(driver, test);
		InterfacePage interfacePage = new InterfacePage(driver,test);
		
		// Calling Functions
		IFCSloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName,clientCountry,cardType);

		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		
		//getting Active Number from DB and Pass
		cardMaintenancePage.activeCardNumber();
		
		//Get exp date from DB and pass
		String expiryDateCardNumber=cardMaintenancePage.cardExpiryDateChange();
		
		if(clientCountry.equals("PH")) {
			 fileName = commonInterfacePage.getRecentProcessedFileName(configProp, clientName, clientCountry, 1,"EmbossCards");
			 System.out.println("Embose File::"+fileName);
			 folderName = ifcsCommonPage.getControlMFolder(clientName, clientCountry, "jobS_emboss_PH");
			jobsInOrder =  ifcsCommonPage.getJobsOfFolderInOrder("jobS_emboss_PH");
		}else {
		
		
		 fileName = commonInterfacePage.getRecentProcessedFileName(configProp, clientName, clientCountry, 1,"EmbossCards");
		 folderName = ifcsCommonPage.getControlMFolder(clientName, clientCountry, "jobS_emboss");
		 jobsInOrder =  ifcsCommonPage.getJobsOfFolderInOrder("jobS_emboss");
		}
		// Executing the Control-M Jobs
		interfacePage.establishAndExecuteControlMJobs("ControlM_AWS_UAT","ContorlM_AWS_userName","ContorlM_AWS_password",folderName,jobsInOrder);
		
		
		ifcsCommonPage.establishThePuttyConnection("incomingFile", "PUTTY_HOST", "PUTTY_USERNAME", "PUTTY_PASSWORD", "IE_OUTPUTFILE_FOLDER_CAF", fileName);				
		String localFolder = System.getProperty("user.home")+"\\Documents\\"+fileName;
		interfacePage.updateOrValidateFlatFile(cardembossconfigProp, "IncomingFile", localFolder,expiryDateCardNumber, clientName, clientCountry, ""); 
		
	}
	//Execution-->4
	@Parameters({ "clientCountry", "clientName","cardType"})
	@Test(groups = {"Smoke"})
	public void validateLostCardAndReplaceNewOne(@Optional("CZ") String clientCountry, @Optional("SH") String clientName, @Optional("APA") String cardType) {

		String fileName = "";
		String folderName="";
		String jobsInOrder="";
		
		test = extent.createTest(clientName+ ":" +clientCountry+"  SHELL Interface Lost Card Validate and CardEmbossing Job via ControlM", "Replace Lost Card and Card Embossing");
		//creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		IFCSCommonPage ifcsCommonPage = new IFCSCommonPage(driver, test);
		CardMaintenancePage cardMaintenancePage=new CardMaintenancePage(driver,test);
		CommonInterfacePage commonInterfacePage = new CommonInterfacePage(driver, test);
		InterfacePage interfacePage = new InterfacePage(driver,test);
		
		// Calling Functions
		IFCSloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName,clientCountry,cardType);

		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		
		//getting lost Number from DB and Pass
		cardMaintenancePage.getLostCardNumber();
		
		//Get exp date from DB and pass
		String replaceCardNumber = cardMaintenancePage.replaceTheLostCardNumber();
		if(clientCountry.equals("PH")) {
			 fileName = commonInterfacePage.getRecentProcessedFileName(configProp, clientName, clientCountry, 1,"EmbossCards");
			 System.out.println("Embose File::"+fileName);
 			 folderName = ifcsCommonPage.getControlMFolder(clientName, clientCountry, "jobS_emboss_PH");
			jobsInOrder =  ifcsCommonPage.getJobsOfFolderInOrder("jobS_emboss_PH");
		}else {
		
		 fileName = commonInterfacePage.getRecentProcessedFileName(configProp, clientName, clientCountry, 1,"EmbossCards");
		 folderName = ifcsCommonPage.getControlMFolder(clientName, clientCountry, "jobS_emboss");
		 jobsInOrder =  ifcsCommonPage.getJobsOfFolderInOrder("jobS_emboss");
		}
		// Executing the Control-M Jobs
		interfacePage.establishAndExecuteControlMJobs("ControlM_AWS_UAT","ContorlM_AWS_userName","ContorlM_AWS_password",folderName,jobsInOrder);
		
	
		System.out.println("---fileNamRecent"+fileName);
		ifcsCommonPage.establishThePuttyConnection("incomingFile", "PUTTY_HOST", "PUTTY_USERNAME", "PUTTY_PASSWORD", "IE_OUTPUTFILE_FOLDER_CAF", fileName);				
		String localFolder = System.getProperty("user.home")+"\\Documents\\"+fileName;
		interfacePage.updateOrValidateFlatFile(cardembossconfigProp, "IncomingFile", localFolder,replaceCardNumber, clientName, clientCountry, ""); 
	}
	//Execution-->5
	@Parameters({ "clientCountry", "clientName","cardType"})
	@Test(groups = {"Smoke"}, enabled = false)
	public void validateActiveCardAndReplaceToStolen(@Optional("CZ") String clientCountry, @Optional("SH") String clientName, @Optional("APA") String cardType) {

		String fileName = "";
		String folderName="";
		String jobsInOrder="";
		test = extent.createTest(clientName+ ":" +clientCountry+"  SHELL Interface Active Card To Stolen Validate and CardEmbossing Job via ControlM", "Replace Active Card To Stolen and Card Embossing");
		//creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		IFCSCommonPage ifcsCommonPage = new IFCSCommonPage(driver, test);
		CardMaintenancePage cardMaintenancePage=new CardMaintenancePage(driver,test);
		CommonInterfacePage commonInterfacePage = new CommonInterfacePage(driver, test);
		InterfacePage interfacePage = new InterfacePage(driver,test);
		
		// Calling Functions
		IFCSloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName,clientCountry,cardType);

		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		
		//getting active Number from DB and Pass
		cardMaintenancePage.activeCardNumber();	
		
		//Get  date from DB and pass
		String replaceToStolen = cardMaintenancePage.replaceToStolenStatus();
		if(clientCountry.equals("PH")) {
			 fileName = commonInterfacePage.getRecentProcessedFileName(configProp, clientName, clientCountry, 1,"EmbossCards");
			 System.out.println("Embose File::"+fileName);
			 folderName = ifcsCommonPage.getControlMFolder(clientName, clientCountry, "jobS_emboss_PH");
			jobsInOrder =  ifcsCommonPage.getJobsOfFolderInOrder("jobS_emboss_PH");
		} else {
		
		 fileName = commonInterfacePage.getRecentProcessedFileName(configProp, clientName, clientCountry, 1,"EmbossCards");
		 folderName = ifcsCommonPage.getControlMFolder(clientName, clientCountry, "jobS_emboss");
		 jobsInOrder =  ifcsCommonPage.getJobsOfFolderInOrder("jobS_emboss");
		}
		// Executing the Control-M Jobs
		interfacePage.establishAndExecuteControlMJobs("ControlM_AWS_UAT","ContorlM_AWS_userName","ContorlM_AWS_password",folderName,jobsInOrder);
		
		
		System.out.println("---fileNamRecent ::"+fileName);

		ifcsCommonPage.establishThePuttyConnection("incomingFile", "PUTTY_HOST", "PUTTY_USERNAME", "PUTTY_PASSWORD", "IE_OUTPUTFILE_FOLDER_CAF", fileName);				
		String localFolder = System.getProperty("user.home")+"\\Documents\\"+fileName;
		interfacePage.updateOrValidateFlatFile(cardembossconfigProp, "IncomingFile", localFolder,replaceToStolen, clientName, clientCountry, ""); 
	}
	
	@Parameters({ "clientCountry", "clientName","cardType"})
	@Test(groups = {"Regression"})
	public void validateNewCardGenerationViaOLS(@Optional("CZ") String clientCountry, @Optional("SH") String clientName,@Optional("APA") String cardType) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  Shell Interfaces Generate New Card","Order card,Edit Card,Reissue Card,ReplaceCard with card embossing");
		
		String fileName = "";
		String folderName="";
		String jobsInOrder="";
		String fileNamePinMailer = "";
		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		HomePage homePage = new HomePage(driver, test);
		SHELLHomePage shellHomePage = new SHELLHomePage(driver, test);
		CommonInterfacePage commonInterfacePage = new CommonInterfacePage(driver, test);
		IFCSCommonPage ifcsCommonPage = new IFCSCommonPage(driver, test);
		InterfacePage interfacePage = new InterfacePage(driver,test);


		// Calling Login Functions And Validate
		 if(cardType.equals("PC"))
	     {
	       loginPage.Login("SHLPC_URL", "SHLPC_UN_Customer_Admin_" + clientCountry, "SHLPC_PWD_Customer_Admin_" + clientCountry, clientName);
	     }
	     else if(cardType.equals("APA"))
	     {
	       loginPage.Login("SHLAPA_URL", "SHLAPA_UN_Customer_Admin_" + clientCountry, "SHLAPA_PWD_Customer_Admin_" + clientCountry, clientName);
	     }
		homePage.ValidateLogoutLink();
		homePage.ValidateHelpShellLink();
		homePage.ValidateWelcomeText(clientName+"#"+cardType);
		homePage.ValidateQuickLinks();
		shellHomePage.ValidateHeaderMenus("Admin");
		shellHomePage.ValidateFooterMenus();
		String orderCard = commonInterfacePage.cardGenerationWithCardEmbossing("order card");
		String editOrderCard = commonInterfacePage.cardGenerationWithCardEmbossing("Edit Card");
		String reissueOrderCard = commonInterfacePage.cardGenerationWithCardEmbossing("Reissue Card");
		String replaceOrderCard = commonInterfacePage.cardGenerationWithCardEmbossing("Replace Card");
	
		String getCardNumbers = orderCard + "," + editOrderCard + "," + reissueOrderCard + "," + replaceOrderCard;
		
		fileName = commonInterfacePage.getRecentProcessedFileName(configProp, clientName, clientCountry, 1,"EmbossCards");
		fileNamePinMailer = commonInterfacePage.getRecentProcessedFileName(configProp, clientName, clientCountry, 1,"EmbossCards");

		folderName = ifcsCommonPage.getControlMFolder(clientName, clientCountry, "jobS_emboss");
		jobsInOrder =  ifcsCommonPage.getJobsOfFolderInOrder("jobS_emboss");
		
		// Executing the Control-M Jobs
		interfacePage.establishAndExecuteControlMJobs("ControlM_AWS_UAT","ContorlM_AWS_userName","ContorlM_AWS_password",folderName,jobsInOrder);
				  
		System.out.println("---fileNamRecent ::"+fileName);

		ifcsCommonPage.establishThePuttyConnection("incomingFile", "PUTTY_HOST", "PUTTY_USERNAME", "PUTTY_PASSWORD", "IE_OUTPUTFILE_FOLDER_CAF", fileName);
		ifcsCommonPage.establishThePuttyConnection("incomingFile", "PUTTY_HOST", "PUTTY_USERNAME", "PUTTY_PASSWORD", "IE_OUTPUTFILE_FOLDER_CAF", fileNamePinMailer);				

		String localFolder = System.getProperty("user.home")+"\\Documents\\"+fileName;
		interfacePage.updateOrValidateFlatFile(cardembossconfigProp, "IncomingFile", localFolder, getCardNumbers, clientName, clientCountry, "");
		
		}

}
