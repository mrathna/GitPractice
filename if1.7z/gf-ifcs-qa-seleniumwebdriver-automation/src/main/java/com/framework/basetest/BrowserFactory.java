package com.framework.basetest;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Arrays;
import java.util.Properties;

import org.openqa.selenium.Capabilities;
import org.openqa.selenium.UnexpectedAlertBehaviour;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.framework.main.InitExecution;
import com.framework.util.Constants;
import com.framework.util.PropUtils;


public class BrowserFactory {
	public static String browserNameAndVersion;
	public static File configFile = PropUtils.getPropFile(Constants.CONFIG_DIR, Constants.CONFIG_FILE_NAME);
	public static Properties configProp = PropUtils.getProps(configFile);
	@SuppressWarnings({ "unused", "deprecation" })
	public static WebDriver getDriver() throws MalformedURLException {
       //InitExecution initExecution=new InitExecution();
	
		
		WebDriver driver = null;
		
		
		System.setProperty("webdriver.ie.driver", Constants.DRIVER_DIR + "IEDriver/IEDriverServer.exe");
		System.setProperty("webdriver.gecko.driver", Constants.DRIVER_DIR + "GeckoDriver/geckodriver.exe");
		System.setProperty("webdriver.chrome.driver", Constants.DRIVER_DIR + "ChromeDriver/Windows/chromedriver.exe");
		
		if(InitExecution.browser.equalsIgnoreCase("chrome"))
      {
			
		
		ChromeOptions options = new ChromeOptions();
		options.setProxy(null);
		options.addArguments("chrome.switches", "--disable-extensions");
		options.addArguments("chrome.switches", "test-type");
		options.addArguments("chrome.switches", "start-maximized");
		options.addArguments("chrome.switches", "no-sandbox");
		if (PropUtils.getPropValue(configProp, "Headless").equals("True")) {			
		options.addArguments("--headless");
		}
		
		options.setExperimentalOption("useAutomationExtension", false);
		options.addArguments("chrome.switches", "--incognito"); // For Starting a

	    options.setExperimentalOption("useAutomationExtension", false);
		if(InitExecution.parallel_Mode.equalsIgnoreCase("yes"))
			{
			try
			{
				DesiredCapabilities desiredCapabilities = DesiredCapabilities.chrome();
			//	desiredCapabilities.setAcceptInsecureCerts(true);
	
				desiredCapabilities.setCapability(ChromeOptions.CAPABILITY, options);
				//desiredCapabilities.setCapability("chrome.switches", Arrays.asList("--incognito"));
				
		    	 driver = new RemoteWebDriver(new URL("http://"+InitExecution.node+"/wd/hub"),desiredCapabilities);//instead of local host use node url 10.78.51.180:7777
			
			}
			catch(Exception e)
			{
				
				e.printStackTrace();
			}
			}
			else
    		driver = new ChromeDriver(options);
      }
		else if(InitExecution.browser.equalsIgnoreCase("firefox"))
		{
			FirefoxProfile fp = new FirefoxProfile();
			fp.setAcceptUntrustedCertificates(true);
			fp.setPreference("browser.tabs.remote.autostart", false);
			fp.setPreference("browser.tabs.remote.autostart.1", false);
			fp.setPreference("browser.tabs.remote.autostart.2", false);
			fp.setPreference("browser.tabs.remote.force-enable", "false");
			/*
			 * fp.setPreference("browser.download.manager.showWhenStarting",false);
			 * fp.setPreference("browser.download.dir",downloadPath);
			 * fp.setPreference("browser.helperApps.neverAsk.saveToDisk",
			 * "text/csv,application/x-msexcel,application/excel,application/x-excel,application/vnd.ms-excel,image/png,image/jpeg,text/html,text/plain,application/msword,application/xml"
			 * );
			 */
			DesiredCapabilities firefoxCapabilities = DesiredCapabilities.firefox();
			firefoxCapabilities.setCapability(CapabilityType.ACCEPT_INSECURE_CERTS, true);
			firefoxCapabilities.setCapability(FirefoxDriver.PROFILE, fp);
			firefoxCapabilities.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
			firefoxCapabilities.setCapability(CapabilityType.ELEMENT_SCROLL_BEHAVIOR, 1);
			firefoxCapabilities.setCapability("marionette", true);
			
			if(InitExecution.parallel_Mode.equalsIgnoreCase("yes"))
			{
			 DesiredCapabilities capabilities = DesiredCapabilities.firefox();
			// capabilities.setCapability(ChromeOptions.CAPABILITY, firefoxCapabilities);
			 String nodeURL="http://"+InitExecution.node+"/wd/hub";
	    	 driver = new RemoteWebDriver(new URL("http://"+InitExecution.node+"/wd/hub"),capabilities);//instead of local host use node url 10.78.51.180:7777
			}
			else
			{
    		driver = new FirefoxDriver(firefoxCapabilities);
			//driver.manage().window().maximize();
    		}
		}
		else if(InitExecution.browser.equalsIgnoreCase("ie"))
		{
			DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
			capabilities.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
			capabilities.setCapability(CapabilityType.HAS_NATIVE_EVENTS, false);
			capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS,
					true);
			capabilities.setCapability(CapabilityType.UNEXPECTED_ALERT_BEHAVIOUR, UnexpectedAlertBehaviour.DISMISS);
			capabilities.setCapability("ignoreZoomSetting", true);
			capabilities.setCapability("requireWindowFocus", true);
			capabilities.setCapability("ignoreProtectedModeSettings", true);
			capabilities.setCapability("disable-popup-blocking", true);
			capabilities.setCapability("enablePersistentHover", true);
			capabilities.setCapability("requireWindowFocus", true);
			capabilities.setJavascriptEnabled(true);
			if(InitExecution.parallel_Mode.equalsIgnoreCase("yes"))
			{
			
			// capabilities.setCapability(ChromeOptions.CAPABILITY, firefoxCapabilities);
			 String nodeURL="http://"+InitExecution.node+"/wd/hub";
	    	 driver = new RemoteWebDriver(new URL("http://"+InitExecution.node+"/wd/hub"),capabilities);//instead of local host use node url 10.78.51.180:7777
			}
			else
			{
    		driver = new InternetExplorerDriver(capabilities);
			driver.manage().window().maximize();
    		}
		}
				
			
// this copied from frameworkUtil
	Capabilities caps = ((RemoteWebDriver)driver).getCapabilities();
	String browserName = caps.getBrowserName();
	String browserVersion = caps.getVersion();
	browserNameAndVersion = (browserName + " " + browserVersion).toUpperCase();
	
	return driver;
		
		
		
	}
	



}
