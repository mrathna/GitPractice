package com.framework.testcases.OLS.BP.Customer;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.BP.BPAccountDetailsPage;
import com.framework.pages.BP.BPHomePage;
import com.framework.pages.OLS.HomePage;
import com.framework.pages.OLS.common.LoginPage;

public class ValidateCustomerVehiclePage extends BaseTest {
	@Parameters({"clientCountry","clientName"})
	@Test( groups = { "Smoke", "Regression" })
	public void Customer_Vehicle_Page_Validations(@Optional("AU") String clientCountry, @Optional("BP") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  19 - Customer Vehicle Page",
				"Logging in to BP Online, Validate  and Log Out from Homepage");

		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		BPHomePage bpHomePage = new BPHomePage(driver, test);
		HomePage homePage = new HomePage(driver, test);
		BPAccountDetailsPage bpAccDetailsPage = new BPAccountDetailsPage(driver, test);
		// Calling Functions
		loginPage.Login("BP_URL", "BP_UN_Customer_" + clientCountry, "BP_PWD_Customer_" + clientCountry, clientName);
		bpHomePage.ValidateBPCustomerLogo();
		bpHomePage.ValidateCustomerWelcomeText();
		homePage.HomePageValidation();
		bpHomePage.clickAccountsDetailsAndValidate();
		bpAccDetailsPage.clickViewEditVehiclesAndValidate();
		bpAccDetailsPage.selectAllAccountsAndValidate();
		bpAccDetailsPage.setCellDataFromVehicleTable(7);
		bpAccDetailsPage.searchCardNumberAndValidate();
		bpAccDetailsPage.searchDriverNameAndValidate();
		bpAccDetailsPage.searchVehicleRegAndValidate();
		bpAccDetailsPage.searchwithEmptyStringAndValidate();
		bpAccDetailsPage.searchwithDescAndValidate();
		bpAccDetailsPage.searchEmptyDescAndValidate();
		bpAccDetailsPage.clearData();
		bpAccDetailsPage.updateTheODAMeterValueAndValidate();
		bpAccDetailsPage.goToCardAndValidate();
		
		loginPage.Logout();
	}
}
