﻿using AventStack.ExtentReports;
using Common.Utility;
using EnCompass.Testing.Source.PageObjects.Controls;
using NFluent;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Support.UI;

namespace EnCompass.Testing.Source.PageObjects.Organization.Admin.MccGroupProfiles
{
    public partial class Hierarchy
    {
        #region XPath page Elements

        private const string _ddlIncludeExcludeProfilesXPath = @"//select[contains(@id,'DdlIncludeExcludeProfiles')]";
        private const string _ddlActionXPath = @"//select[contains(@id,'ddlAction')]";
        private const string _cbOverrideXPath = @"//input[contains(@id,'cbOverride')]";
        private const string _cbOverrideLabelXPath = @"//label[contains(@for,'cbOverride')]";
        private const string _cbOverrideConfirmXPath = @"//input[contains(@id,'cbOverrideConfirm')]";
        private const string _btnSubmitXPath = @"//input[contains(@id,'btnSubmit')]";
        private const string _btnConfirmXPath = @"//input[contains(@id,'btnConfirm')]";
        private const string _hierarchyLinkXPath = @"//a[contains(@id, 'hierarchyExplorer')]";
        #endregion

        #region Page Elements

        private IWebElement _ddlIncludeExcludeProfiles
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_ddlIncludeExcludeProfilesXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_ddlIncludeExcludeProfiles element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _ddlAction
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_ddlActionXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_ddlAction element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _cbOverride
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_cbOverrideXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_cbOverride element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _cbOverrideLabel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_cbOverrideLabelXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_cbOverrideLabel element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _cbOverrideConfirm
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_cbOverrideConfirmXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_cbOverrideConfirm element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _btnSubmit
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_btnSubmitXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_btnSubmit element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _btnConfirm
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_btnConfirmXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_btnConfirm element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        IWebElement _hierarchyLink
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_hierarchyLinkXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_hierarchyLink element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        #endregion

        public string DdlIncludeExcludeProfiles
        {
            get { return new SelectElement(_ddlIncludeExcludeProfiles).SelectedOption.Text; }
            set { _ddlIncludeExcludeProfiles.SetListboxByText(value); }
        }

        public string DdlAction
        {
            get { return new SelectElement(_ddlAction).SelectedOption.Text; }
            set { _ddlAction.SetListboxByText(value); }
        }

        public void Submit()
        {
            _btnSubmit.JSClickWithFocus(Driver, _btnSubmitXPath, Settings);
            WaitForLoad();
        }

        public void Confirm()
        {
            _btnConfirm.JSClickWithFocus(Driver, _btnConfirmXPath, Settings);
        }

        public void AssignMCCGProfilesHierarchy(string mccgProfileName, string action, bool overrideProfiles, ExtentTest test)
        {
            bool isElementPresent = Driver.TryWaitForElement(By.XPath("//select[contains(@id,'DdlIncludeExcludeProfiles')]"), out IWebElement IncludeExcludeProfile);
            Settings.EnCompassExtentTest.Info("IncludeExcludeProfile is present - " +isElementPresent);
            DdlIncludeExcludeProfiles = mccgProfileName;
            test.Info("Select MCCG Profile to Assign via Hierarchy");
            DdlAction = action;
            test.Info("Select action to Assign MCCG Profile via Hierarchy");
            _cbOverride.SetCheckboxStateWithLabel(_cbOverrideLabel, overrideProfiles);
            test.Info("Set chechbox Override All Profiles");
            if (overrideProfiles)
            {
                Submit();
                test.Info("Press button submit");
                WaitForLoad();
                _cbOverride.SetCheckboxStateWithLabel(_cbOverrideLabel, overrideProfiles);
                test.Info("Set chechbox Confirm Override");
                Confirm();
                test.Info("Press button Confirm");
                ConfirmOnModal();
            }
            else
            {
                Submit();
                test.Info("Press button submit");
                WaitForLoad();
                Confirm();
                test.Info("Press button Confirm");
            }
            
        }

        //Accessing OrgHierarchy object which has the common functionality of Choosing the TOP Org as its Hierarchy Option.
        private OrgHierarchy _hierarchy;
        public OrgHierarchy HierarchyAssign
        {
            get
            {
                return _hierarchy ?? (_hierarchy = new OrgHierarchy(_hierarchyLink, Driver, Settings));
            }
        }
    }
}
