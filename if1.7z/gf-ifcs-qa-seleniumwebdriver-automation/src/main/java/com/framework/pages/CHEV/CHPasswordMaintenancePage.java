package com.framework.pages.CHEV;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.ExtentTest;
import com.framework.basepage.BasePage;
import com.framework.repo.Locator;

public class CHPasswordMaintenancePage extends BasePage {

	@FindBy(how = How.XPATH, using = Locator.SCHEDULE_REPORT_MAINTENANCE_PAGE)
	public WebElement transactionPageTitle;

	@FindBy(how = How.ID, using = Locator.CH_REPORTS_USER_ID)
	public WebElement userIdTitle;

	@FindBy(how = How.ID, using = Locator.CH_REPORTS_OLD_PWD_FIELD)
	public WebElement oldPwdTitle;

	@FindBy(how = How.ID, using = Locator.CH_REPORTS_NEW_PWD_FIELD)
	public WebElement newPwdTitle;

	@FindBy(how = How.ID, using = Locator.CH_REPORTS_CONFIRM_PWD_FIELD)
	public WebElement confirmPwdTitle;

	public CHPasswordMaintenancePage(WebDriver driver, ExtentTest test) {
		super(driver, test);
		PageFactory.initElements(driver, this);
	}

	public void verifyPageTitle() {
		sleep(10);
		if (transactionPageTitle.isDisplayed()) {
			logPass("Password Maintenance is displayed");
		} else {
			logFail("Password Maintenance is not displayed");
		}
	}

	public void verifyPageSubtitles() {
		verifyText(userIdTitle, "User ID");
		verifyText(oldPwdTitle, "Password");
		verifyText(newPwdTitle, "New Password");
		verifyText(confirmPwdTitle, "Confirm Password");
	}
}