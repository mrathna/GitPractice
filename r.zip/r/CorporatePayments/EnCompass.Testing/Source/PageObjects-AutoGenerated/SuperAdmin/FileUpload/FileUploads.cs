using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using Common;
using Common.PageObjects;
using Common.ScenarioConfigurations;
using Common.Utility;

namespace EnCompass.Testing.Source.PageObjects.SuperAdmin.FileUpload 
{
	/// <summary>
	/// Auto-generated Page Model Class
	/// Navigation Paths: 
		/// [Organization Home]->General->File Uploads
		/// </summary>
	[PageModel(@"/superAdmin/FileUpload/FileUploads.aspx")]
	public partial class FileUploads : EnCompassSuperPageModel 
	{
		public override string RelativeUrl => @"/superAdmin/FileUpload/FileUploads.aspx";
		public override string PageIdentifierXPath_Generated => @"//li[contains(@class, 'breadcrumb-item active')][text() = 'File Uploads']";

		#region Navigation
		
		private void NavigateToMenuItem(IWebElement element)
		{
			Driver.Url = element.GetAttribute("href");
		}
		#endregion

		public FileUploads(GlobalSettings settings) : base(settings) { }
	}  
}
