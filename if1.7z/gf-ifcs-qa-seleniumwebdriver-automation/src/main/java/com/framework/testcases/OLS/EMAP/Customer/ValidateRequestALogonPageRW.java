package com.framework.testcases.OLS.EMAP.Customer;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.EMAP.EMAPHomePage;
import com.framework.pages.EMAP.EMAPLoginPage;
import com.framework.pages.OLS.common.LoginPage;

public class ValidateRequestALogonPageRW extends BaseTest {
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "Regression" })
	public void validateRequestLogonPage(@Optional("SP") String clientCountry, @Optional("EMAP") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  TST-SC-77-OLS - Request a Logon", "Validate the request a logon page fields");
		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);

		// Login and get account number - Only If not running in APAC_AUTO
		String validAccountNumber = "";
		loginPage.Login("EMAP_URL", "EMAP_UN_ReadWrite_Customer_" + clientCountry,
				"EMAP_PWD_ReadWrite_Customer_" + clientCountry, clientName);
		EMAPHomePage homePage = new EMAPHomePage(driver, test);
		validAccountNumber = homePage.setAccountNumberChoosen();
		loginPage.Logout();

		loginPage.validateLoginPageFooterLinks(clientName, "EMAP_URL");
		EMAPLoginPage emapLoginPage = new EMAPLoginPage(driver, test);
		emapLoginPage.clickRequestALogonAndValidateTitle();
		emapLoginPage.validateClientLogo();
		emapLoginPage.checkCustomerRequestLogonTypeIsChoosenByDefault();
		emapLoginPage.enterRequestLogonDetails(validAccountNumber);
		emapLoginPage.clickRequestALogonSubmit();
		emapLoginPage.checkTheConfirmationMessage();
		emapLoginPage.closeTheRequestLogonTab();
	}

}
