package com.framework.pages.Z;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.ExtentTest;
import com.framework.basepage.BasePage;
import com.framework.repo.Locator;

public class ZHomePage extends BasePage {

	@FindBy(id = Locator.SHELL_ACCOUNT_DROPDOWN)
	public WebElement accountDropdown;
	

	@FindBy(xpath=Locator.ACCOUNT_NAME_IN_HOME_PAGE)
	public WebElement accountNameInHomePage;

	@FindBy(how=How.ID,using = Locator.ORDER_NEW_CARD_QUICK_LINK)
	public WebElement orderACard;

	@FindBy(how=How.ID,using = Locator.Z_USER_GUIDE)
	public WebElement userGuide;
	@FindBy(how = How.ID, using = Locator.REQUEST_LOGON)
	public WebElement requestALogon;

	/*@FindBy(id=Locator.HOME_MENU_BP)
	public WebElement homeMenu;*/

	/*@FindBy(id=Locator.CHANGE_CARD_STATUS_QUICK_LINK)
	public WebElement changeCardQuicklink;*/

	@FindBy(xpath = Locator.ACCOUNT_NAME_IN_HEADER)
	public WebElement accountNameInHeader;

	@FindBy(xpath = Locator.CARD_SEARCH_QUICK_LINK)
	public WebElement searchCardQuickLink;

	@FindBy(xpath = Locator.XERO_QUICK_LINK)
	public WebElement xeroQuickLink;

	@FindBy(xpath = Locator.Z_QUICK_LINK)
	public WebElement zCardQuickLink;
	
	@FindBy(xpath = Locator.Z_MANAGE_LOYALITY_QUICK_LINK)
	public WebElement zManageLoyalityQuickLink;

	@FindBy(xpath = Locator.CALTEX_QUICK_LINK)
	public WebElement caltexQuickLink;

	@FindBy(xpath = Locator.TC_QUICK_LINK)
	public WebElement tcQuickLink;

	@FindBy(xpath = Locator.EDIT_CARD_QUICK_LINK)
	public WebElement editCardQuickLink;

	@FindBy(xpath = Locator.XERO_TC_QUICK_LINK)
	public WebElement xeroTCQuickLink;

	@FindBy(xpath = Locator.INVOICE_QUICK_LINK)
	public WebElement invoiceQuickLink;

	@FindBy(xpath = Locator.RUN_REPORT_QUICK_LINK)
	public WebElement runReportQuickLink;

	@FindBy(xpath = Locator.LOCATION_SITE_QUICK_LINK) 
	public WebElement locationFinderQuickLink;

	@FindBy(xpath=Locator.TRANSACTION_SEARCH_QUICK_LINK)
	public WebElement transactionSearchQuicklink;
@FindBy(xpath=Locator.Z_FOOTER_QUICK_LINK)
	public WebElement zFooterQuickLink;
	
	@FindBy(how = How.XPATH, using = Locator.CUSTOMER_NAME_COMBO)
	public WebElement accountNumber;
	
	@FindBy(how = How.ID, using = Locator.ACCOUNTS_MENU)
	public WebElement accountMenu;
	
	@FindBy(how = How.ID, using = Locator.STATUS_MENU)
	public WebElement statusMenu;
	
	@FindBy(how = How.ID, using = Locator.ACCOUNT_MAINTENANCE_MENU)
	public WebElement accountMaintenanceMenu;
	
	
	@FindBy(how = How.XPATH, using = Locator.CONTACTS_MENU)
	public WebElement ContactMenu;
	
	
	@FindBy(how = How.ID, using = Locator.DRIVERS_MENU)
	public WebElement DriversMenu;
	
	@FindBy(how = How.ID, using = Locator.VEHICLES_MENU)
	public WebElement VehiclesMenu;
	
	
	@FindBy(how = How.ID, using = Locator.COST_CENTERS_MENU)
	public WebElement costCentesMenu;
	
	@FindBy(how = How.ID, using = Locator.Z_CONNECT_TO_XERO)
	public WebElement connectToXeroMenu;
		
	@FindBy(how = How.ID, using = Locator.CARDS_MENU)
	public WebElement cardMenu;
	
	@FindBy(how = How.ID, using = Locator.FINDANDUPDATECARDS)
	public WebElement findCards;
	
	@FindBy(how = How.ID, using = Locator.ORDER_A_CARD)
	public WebElement orderCards;
	
	@FindBy(how = How.ID, using = Locator.CH_REISSUE_CONTROL)
	public WebElement reissueControl;
	
	@FindBy(how = How.ID, using = Locator.BULK_CARD_STATUS_SUB_MENU)
	public WebElement bulkCardStatusChange;
	
	@FindBy(how = How.ID, using = Locator.BULKORDER_UPDATECARDS)
	public WebElement bulkcardOrder;
	
	@FindBy(how = How.ID, using = Locator.BULK_CARD_UPDATE_SM)
	public WebElement bulkcardUpdate;
	
	@FindBy(how = How.ID, using = Locator.TRANSACTIONS_MENU)
	public WebElement transactionMenu;
	
	@FindBy(how = How.ID, using = Locator.FIND_EXPORT_TRANSC)
	public WebElement findTransactionMenu;
	
	@FindBy(how = How.ID, using = Locator.EXPORT_TRANSACTION)
	public WebElement exportTransactionMenu;
	
	@FindBy(how = How.ID, using = Locator.REPORTS_MENU)
	public WebElement reportsMenu;
	
	@FindBy(how = How.ID, using = Locator.PAST_REPORTS)
	public WebElement findReportsMenu;
	
	@FindBy(how = How.ID, using = Locator.ADHOC_REPORTS_SUBMENU)
	public WebElement requestReportsMenu;
	
	@FindBy(how = How.ID, using = Locator.SCHEDULED_REPORT)
	public WebElement scheduledReportsMenu;
	
	@FindBy(how = How.ID, using = Locator.SHELL_INVOICES)
	public WebElement invoicesMenu;
	
	@FindBy(how = How.ID, using = Locator.SUPPORT_MENU)
	public WebElement SupportMenu;
	
	
	@FindBy(how = How.ID, using = Locator.CH_REPORTS_CHANGE_PWD)
	public WebElement chnagePasswordMenu;
	
	@FindBy(how = How.ID, using = Locator.CONTACT_US_SUBMENU)
	public WebElement contactUsMenu;
	
	@FindBy(how = How.ID, using = Locator.PROFILE)
	public WebElement myProfileMenu;
		@FindBy(id=Locator.HOME_MENU_BP)
	public WebElement homeMenu;
	
	@FindBy(id=Locator.CHANGE_CARD_STATUS_QUICK_LINK)
	public WebElement changeCardQuicklink;
	
//	@FindBy(id=Locator.CHANGE_CARD_STATUS_QUICK_LINK)
//	public WebElement changeCardQuicklink;	
	
//	@FindBy(how = How.XPATH, using = Locator.CUSTOMER_NAME_LABEL)
//	public WebElement accountProfile;
	
	@FindBy(how = How.XPATH, using = Locator.ACCOUNT_NAME_IN_HEADER)
	public WebElement accountProfile;

	private String selectedAccount = "";
	
	String firstName, lastName, parentWindow;

	public ZHomePage(WebDriver driver, ExtentTest test) {

		super(driver, test);
		PageFactory.initElements(driver, this);

	}
	// Added on 10/01/2019
	public void selectAccountFromDropdownAndValidate() {

		isDisplayed(accountDropdown, "Account Drop down in home page");

		int size = getDropdownSize(accountDropdown);

		if (size > 1) {
			String accountName = selectedStringFrmDropDown(accountDropdown);
			System.out.println("accountNAme ---- " + accountName);
			sleep(5);
			selectDifferentValueInsteadOfDefault(accountDropdown, accountName, "");
			sleep(3);
			String accname2 = selectedStringFrmDropDown(accountDropdown);
			sleep(5);
			if (!accountName.contains(accname2)) {
				logInfo("Account 1 = " + accountName + " Different Account selected ---=" + accname2);
				logPass("Different Account Selected");
			}

			else {
				logInfo("Account 1 = " + accountName + " Different Account selected ---=" + accname2);
				logFail("Different Account is not selected");
			}
		} else {
			logInfo("accountDropdown in home page has only one option");
		}
		sleep(5);
	}

	public void verifyCustomerNameInHomePage() {
		String customerNameAndNo = selectedStringFrmDropDown(accountDropdown);
		if (customerNameAndNo.contains(getText(accountNameInHomePage))) {
			logPass("Same account name present in dropdown and details section");
		} else {
			logInfo("Same account name not present in dropdown and details section");
		}
	}

	/**
	 * Validate Order A card from Quick Links
	 */
	public void clickOrderACard() {
//		clickLinkAndValidateNavigation(orderACard, Click Order A Card);
//		Changed as per new requirement
//		validateClickableLinkRedirectionContains(orderACard, "cardNew");
		isDisplayedThenActionClick(orderACard, "Order A Card");
		checkTextInPageAndValidate("Order New Card", 5);
		checkTextInPageAndValidate("Card Details", 5);
		checkTextInPageAndValidate("Driver Details", 5);
		checkTextInPageAndValidate("Vehicle Details", 5);
		clickHomeMenu();
	}
	
	/**
	 * Validate Order A card from Quick Links
	 */
	public void changeCardStatus() {
		isDisplayedThenActionClick(orderACard, "Change a Card Status");
		checkTextInPageAndValidate("Order New Card", 5);
		checkTextInPageAndValidate("Card Details", 5);
		checkTextInPageAndValidate("Driver Details", 5);
		checkTextInPageAndValidate("Vehicle Details", 5);
	}
/**
	 * Validate Search Card from Quick Links
	 */
	public void clickCardSearchQuickLink() {
		isDisplayedThenActionClick(searchCardQuickLink, "search cards");
		checkTextInPageAndValidate("Cards", 5);
		clickHomeMenu();
//		checkTextInPageAndValidate("Card Details", 20);
//		checkTextInPageAndValidate("Driver Details", 20);
//		checkTextInPageAndValidate("Vehicle Details", 20);
	}

	/**
	 * Validate Edit card from Quick Links
	 */
	public void clickEditCardQuickLink() {
		isDisplayedThenActionClick(editCardQuickLink, "edit cards");
		checkTextInPageAndValidate("Cards", 5);
		clickHomeMenu();
	}

	/**
	 * Validate Transaction search from Quick Links
	 */
	public void clickTransactionSearchQuickLink() {
		isDisplayedThenActionClick(transactionSearchQuicklink, "trans search");
		checkTextInPageAndValidate("Transactions", 5);
		clickHomeMenu();
	}

	/**
	 * Validate Run a report from Quick Links
	 */
	public void clickRunAReportsQuickLink() {
		isDisplayedThenActionClick(runReportQuickLink, "run a report"); 
		checkTextInPageAndValidate("On demand Reports", 5);
		clickHomeMenu();
	}

	/**
	 * Validate invoice and report from Quick Links
	 */
	public void clickUrInvoicesAndReportsQuickLink() {
		isDisplayedThenActionClick(invoiceQuickLink, "invoice"); 
		checkTextInPageAndValidate("Stored Reports", 5);
		clickHomeMenu();
	}

	/**
	 * Validate connect to xero from Quick Links
	 */
	public void clickConnectToZeroQuickLink() {
		isDisplayedThenActionClick(xeroQuickLink, "connectToZero");
		checkTextInPageAndValidate("Terms and Conditions", 5);
		clickHomeMenu();
	}

	/**
	 * Validate z.co.nz from Quick Links
	 */
	public void clickZQuickLink() {
		validateClickableLinkRedirectionContains(zCardQuickLink, "z");
	}

	/**
	 * Validate caltex link from Quick Links
	 */
	public void clickCaltexQuickLink() {
		validateClickableLinkRedirectionContains(caltexQuickLink, "caltex");
	}

	/**
	 * Validate LocationAndSiteFinder from Quick Links
	 */
	public void clickLocationAndSiteFinderQuickLink() {
		validateClickableLinkRedirectionContains(locationFinderQuickLink, "z");
	}

	/**
	 * Validate TermsAndConditions from Quick Links
	 */
	public void clickTermsAndConditionsQuickLink() {
		validateClickableLinkRedirectionContains(tcQuickLink, "z-card-online-terms-of-access");
	}

	/**
	 * Validate XeroTermsAndConditions from Quick Links
	 */
	public void clickXeroTermsAndConditionsQuickLink() {
		validateClickableLinkRedirectionContains(xeroTCQuickLink, "z-card-feed-into-xero-terms-and-conditions");
	}

	/**
	 * Validate User Guide from Quick Links
	 */
	/*public void clickUserGuide() {
		//		validateClickableLinkRedirectionContains(userGuide,"Z-Card-Online-user-guide");
		validateClickableLinkRedirectionContains(userGuide,"Z-Card-Online-user-guide-May-2018");
		//		https://z.co.nz/assets/Z-Card-Online-user-guide-May-2018.pdf
		sleep(3);
	}*/

	/**
	 * Validate Quick Links
	 */
	public void checkQuickLinksPresents() {
		checkTextInPageAndValidate("Quick links", 5);
		checkTextInPageAndValidate("Card search", 5);
		checkTextInPageAndValidate("Order new card", 5);
		checkTextInPageAndValidate("Edit card", 5);	
		checkTextInPageAndValidate("Transaction search", 5);
		checkTextInPageAndValidate("Your invoices & reports", 5);
		checkTextInPageAndValidate("Run a report", 5);
		checkTextInPageAndValidate("Connect to Xero", 5);
		checkTextInPageAndValidate("Z.co.nz", 5);
		checkTextInPageAndValidate("Caltex.co.nz", 5);
		checkTextInPageAndValidate("Location/Site finder", 5);
		checkTextInPageAndValidate("Terms and conditions", 5);
		checkTextInPageAndValidate("Manage your loyalty", 5);
		
/*		checkTextInPageAndValidate("Xero Terms and Conditions", 20);
		checkTextInPageAndValidate("Privacy Statement", 20);
		checkTextInPageAndValidate("User Guide", 20);
		checkTextInPageAndValidate("Scheduled Reports", 20);*/
		
		logPass("checkQuickLinksPresents Passed");
	}
	/*public void clickHomeMenu() {

		isDisplayedThenActionClick(homeMenu, "Home Menu");
	}
	//	Sasi
	public void verifyCardListPage() {

		checkTextInPageAndValidate("Find Cards", 10);
	}

	public void goToCardMenuCardList() { 

		mouseHoverClickMenuAndSubMenu("Cards", "Find Cards");
	}*/
	//	 Sasi (31-01-2019)
	public void goToCardMenuBulkCardOrder() {

		mouseHoverClickMenuAndSubMenu("Cards", "Bulk Order");
	}

	public void goToCardMenuBulkCardUpdate() { 
		mouseHoverClickMenuAndSubMenu("Cards", "Bulk Update");
	}

	//Added by Naveen
	public void verifyAccountNoForFileVerification() {
		//String s = selectedStringFrmDropDown(accountNameInHeader).split("\\(")[1];
		isDisplayed(accountNameInHeader,"Displayed");
		String s = accountNameInHeader.getText().split("\\(")[1];
		String store=s.split("\\)")[0];
		verifyTheDownloadedFile(store);
	}

	//	public void goToCardMenuCardList() { 
	//
	//		mouseHoverClickMenuAndSubMenu("Cards", "Find Cards");
	//	}
	//	
	//	public void goToCardMenuCardList() { 
	//
	//		mouseHoverClickMenuAndSubMenu("Cards", "Find Cards");
	//	}
	//	
	//	public void goToCardMenuCardList() { 
	//
	//		mouseHoverClickMenuAndSubMenu("Cards", "Find Cards");
	//	}


/**
	 * Validate User Guide from Quick Links
	 */
	/*public void clickUserGuide() {
		validateClickableLinkRedirectionContains(userGuide, "Z-Card-Online-user-guide");
		sleep(3);
	}*/

	/**
	 * Validate User Guide from Quick Links
	 */
	public void clickUserGuide() {
//		validateClickableLinkRedirectionContains(userGuide,"Z-Card-Online-user-guide");
		validateClickableLinkRedirectionContains(userGuide,"Z-Card-Online-user-guide-May-2018");
//		https://z.co.nz/assets/Z-Card-Online-user-guide-May-2018.pdf
		sleep(3);
	}
	public void clickRequestALogonAndValidateTitle() {
		parentWindow = clickAndSwitchToNewWindow(requestALogon);
		//verifyRequestALogonTitleText();
	}
	
	// Added by Ayub 24/01/2019
	public String setAccountNumberChoosen() {
		
		String validAccountNumber = selectedStringFrmDropDown(accountNumber).split("\\(")[1];

		System.out.println(validAccountNumber.split("\\)")[0] + "=== valid account number");
	
		validAccountNumber = validAccountNumber.split("\\)")[0];
		
		return validAccountNumber;
	}
	
	public void ValidateHeaderMenus(String role) {
		// TODO Auto-generated method stub
		
		checkTextInPageAndValidate("Home", 10);
		checkTextInPageAndValidate("Account", 10);
		checkTextInPageAndValidate("Cards", 10);	
		checkTextInPageAndValidate("Support", 10);
		if(role.equals("Full Access Group User"))
		{
			checkTextInPageAndValidate("Transactions", 10);
			checkTextInPageAndValidate("Reports", 10); //In some countries this is Reports
		}
	}
	
	public void validateAccountSubMenus(String accessType) {
		mouseHover(accountMenu);
		isDisplayed(statusMenu, "Status sub menu");
		isDisplayed(accountMaintenanceMenu, "Account Maintenanc Sub Menu");
		isDisplayed(ContactMenu, "Contact Sub Menu");
		isDisplayed(DriversMenu, "Driver Sub menu");
		isDisplayed(VehiclesMenu, "Vehicles Sub Menu");
		isDisplayed(costCentesMenu, "Cost Centes Sub Menu");
		if(accessType.equals("cardAccess")||accessType.equals("fullAccess")){
			isDisplayed(connectToXeroMenu, "Connect ToXero sub Menu");
		}
		
		
	}
	
	public void validateCardsSubMenus(String accessType) {
		mouseHover(cardMenu);
		isDisplayed(findCards, "Find Cards sub menu");
		if(accessType.equals("cardAccess")||accessType.equals("fullAccess")) {
		isDisplayed(orderCards, "Order A Crad Sub Menu");
		isDisplayed(reissueControl, "Rissue Control Sub Menu");
		isDisplayed(bulkCardStatusChange, "Bulk Card Status Change Sub menu");
		isDisplayed(bulkcardUpdate, "Bulk card Updates Sub Menu");
		isDisplayed(bulkcardOrder, "BulkcardOrder Sub Menu");
		}
	}
	
	public void validateTransactionSubMenus() {
		mouseHover(transactionMenu);
		isDisplayed(findTransactionMenu, "Find Transaction sub menu");
		isDisplayed(exportTransactionMenu, "Export Transaction Sub Menu");
		
	}

	public void validateReportsSubMenus() {
		mouseHover(reportsMenu);
		isDisplayed(findReportsMenu, "Find Resports sub menu");
		isDisplayed(requestReportsMenu, "RequestReports Sub Menu");
		isDisplayed(scheduledReportsMenu, "Schedule dReports Sub Menu");
		isDisplayed(invoicesMenu, "Invoice Sub Menu");
		
	}
	
	public void validateSupportSubMenus() {
		mouseHover(SupportMenu);
		isDisplayed(chnagePasswordMenu, "Change Password sub menu");
		isDisplayed(contactUsMenu, "ContactUs Sub Menu");
//		isDisplayed(myProfileMenu, "My Profile Sub Menu");
				
	}
public void validateUserAccountShouldBeVisibleOnSubmenu() {

		selectedAccount = selectedStringFrmDropDown(accountNumber);
		String[] splited = selectedAccount.split("\\s{2,}");
		selectedAccount = splited[0] + " " + splited[1];
		System.out.println("------------" + selectedAccount + "---------------");
		String AP = getText(accountProfile);
		System.out.println("*******" + AP + "*********");
		// validate Accounts sub menus
		
		mouseHoverClickMenuAndSubMenu("Accounts", "Status");
		if (accountProfile.getText().trim().contentEquals(selectedAccount)) {

			logPass("Selected account is same in Status sub menu page");
		} else {
			logFail("Selected account is not same in Status sub menu page");
		}

		mouseHoverClickMenuAndSubMenu("Accounts", "Account Maintenance");

		if (accountProfile.getText().trim().contentEquals(selectedAccount)) {

			logPass("Selected account is same in Account Maintenance sub menu page");
		} else {
			logFail("Selected account is not sam in Account Maintenance sub menu page");
		}

		mouseHoverClickMenuAndSubMenu("Accounts", "Contacts");
		if (accountProfile.getText().trim().contentEquals(selectedAccount)) {

			logPass("Selected account is same in Contacts sub menu page");
		} else {
			logFail("Selected account is not sam in Contacts sub menu page");
		}

		mouseHoverClickMenuAndSubMenu("Accounts", "Drivers");
		if (accountProfile.getText().trim().contentEquals(selectedAccount)) {

			logPass("Selected account is same in Drivers sub menu page");
		} else {
			logFail("Selected account is not sam in Drivers sub menu page");
		}
		// validate Cards sub menus
		mouseHoverClickMenuAndSubMenu("Cards", "Find Cards");
		if (accountProfile.getText().trim().contentEquals(selectedAccount)) {

			logPass("Selected account is same in Find Cards sub menu page");
		} else {
			logFail("Selected account is not sam in Find Cards sub menu page");
		}
		
		mouseHoverClickMenuAndSubMenu("Cards", "Order a Card");
		if (accountProfile.getText().trim().contentEquals(selectedAccount)) {

			logPass("Selected account is same in Order a Card sub menu page");
		} else {
			logFail("Selected account is not sam in Order a Card sub menu page");
		}
		
		// validate Transactions sub menus
		mouseHoverClickMenuAndSubMenu("Transactions", "Find Transactions");
		if (accountProfile.getText().trim().contentEquals(selectedAccount)) {

			logPass("Selected account is same in Find Transactions sub menu page");
		} else {
			logFail("Selected account is not sam in Find Transactions sub menu page");
		}
		
		mouseHoverClickMenuAndSubMenu("Transactions", "Export Transactions");
		if (accountProfile.getText().trim().contentEquals(selectedAccount)) {

			logPass("Selected account is same in Export Transactions sub menu page");
		} else {
			logFail("Selected account is not sam in Export Transactionss sub menu page");
		}
		mouseHoverClickMenuAndSubMenu("Reports", "Find Reports");
		if (accountProfile.getText().trim().contentEquals(selectedAccount)) {

			logPass("Selected account is same in Find Reports sub menu page");
		} else {
			logFail("Selected account is not sam in Find Reports sub menu page");
		}
		
		mouseHoverClickMenuAndSubMenu("Support", "Change Password");
		if (accountProfile.getText().trim().contentEquals(selectedAccount)) {

			logPass("Selected account is same in Change Password sub menu page");
		} else {
			logFail("Selected account is not sam in Change Password sub menu page");
		}
		//My Profile is removed as per new requirement
	/*	mouseHoverClickMenuAndSubMenu("Support", "My Profile");
		if (accountProfile.getText().trim().contentEquals(selectedAccount)) {

			logPass("Selected account is same in Contact Us sub menu page");
		} else {
			logFail("Selected account is not sam in Contact Us sub menu page");
		}
		
		mouseHoverClickMenuAndSubMenu("Support", "My Profile");
		if (accountProfile.getText().trim().contentEquals(selectedAccount)) {

			logPass("Selected account is same in My Profile sub menu page");
		} else {
			logFail("Selected account is not sam in My Profile sub menu page");
		}*/

	}

/**
	 * Validate Quick Links
	 */
	/*public void checkQuickLinksPresents() {
		checkTextInPageAndValidate("Quick links", 20);
		checkTextInPageAndValidate("Order a Card", 20);
		checkTextInPageAndValidate("Change a Card Status", 20);
		checkTextInPageAndValidate("Cards", 20);
		checkTextInPageAndValidate("Transactions", 20);
		checkTextInPageAndValidate("Export Transactions", 20);
		checkTextInPageAndValidate("Connect to Xero", 20);
		checkTextInPageAndValidate("Z.co.nz", 20);
		checkTextInPageAndValidate("Caltex.co.nz", 20);
		checkTextInPageAndValidate("Location/Site Finder", 20);
		checkTextInPageAndValidate("Terms and Conditions", 20);
		checkTextInPageAndValidate("Xero Terms and Conditions", 20);
		checkTextInPageAndValidate("Privacy Statement", 20);
		checkTextInPageAndValidate("User Guide", 20);
		checkTextInPageAndValidate("Scheduled Reports", 20);
		
	}*/
	public void clickHomeMenu() {
		
		isDisplayedThenActionClick(homeMenu, "Home Menu");
	}
//	Sasi
	public void verifyCardListPage() {
		
		checkTextInPageAndValidate("Find Cards", 10);
	}
	
	public void goToCardMenuCardList() { 
		
		mouseHoverClickMenuAndSubMenu("Cards", "Find Cards");
	}
	public void clickManageUrLoyalityQuickLink() {
		validateClickableLinkRedirectionContains(zManageLoyalityQuickLink, "rewards");
		
		
	}



}
