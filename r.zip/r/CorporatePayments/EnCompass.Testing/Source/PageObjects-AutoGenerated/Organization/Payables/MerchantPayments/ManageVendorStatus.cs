using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using Common;
using Common.PageObjects;
using Common.ScenarioConfigurations;
using Common.Utility;

namespace EnCompass.Testing.Source.PageObjects.Organization.Payables.MerchantPayments 
{
	/// <summary>
	/// Auto-generated Page Model Class
	/// Navigation Paths: 
		/// [Organization Home]->Payables->Accounts Payable->Merchant Enrollment Status
		/// </summary>
	[PageModel(@"/payables/merchantPayments/ManageVendorStatus.aspx")]
	public partial class ManageVendorStatus : EnCompassOrgPageModel 
	{
		public override string RelativeUrl => @"/payables/merchantPayments/ManageVendorStatus.aspx";
		public override string PageIdentifierXPath_Generated => @"//li[contains(@class, 'breadcrumb-item active')][text() = 'Merchant Enrollment Status']";

		#region Navigation
				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Merchant Logs']")]
		private IWebElement _payables_AccountsPayable_MerchantEnrollmentStatus_MerchantLogs { get; set; }
		public void NavigateTo_Payables_AccountsPayable_MerchantEnrollmentStatus_MerchantLogs()
		{
			NavigateToMenuItem(_payables_AccountsPayable_MerchantEnrollmentStatus_MerchantLogs);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Create Merchant Log']")]
		private IWebElement _payables_AccountsPayable_MerchantEnrollmentStatus_CreateMerchantLog { get; set; }
		public void NavigateTo_Payables_AccountsPayable_MerchantEnrollmentStatus_CreateMerchantLog()
		{
			NavigateToMenuItem(_payables_AccountsPayable_MerchantEnrollmentStatus_CreateMerchantLog);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Merchant Log Reconciliation']")]
		private IWebElement _payables_AccountsPayable_MerchantEnrollmentStatus_MerchantLogReconciliation { get; set; }
		public void NavigateTo_Payables_AccountsPayable_MerchantEnrollmentStatus_MerchantLogReconciliation()
		{
			NavigateToMenuItem(_payables_AccountsPayable_MerchantEnrollmentStatus_MerchantLogReconciliation);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Merchant Log Settings']")]
		private IWebElement _payables_AccountsPayable_MerchantEnrollmentStatus_MerchantLogSettings { get; set; }
		public void NavigateTo_Payables_AccountsPayable_MerchantEnrollmentStatus_MerchantLogSettings()
		{
			NavigateToMenuItem(_payables_AccountsPayable_MerchantEnrollmentStatus_MerchantLogSettings);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Disputes']")]
		private IWebElement _payables_AccountsPayable_MerchantEnrollmentStatus_Disputes { get; set; }
		public void NavigateTo_Payables_AccountsPayable_MerchantEnrollmentStatus_Disputes()
		{
			NavigateToMenuItem(_payables_AccountsPayable_MerchantEnrollmentStatus_Disputes);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Merchants']")]
		private IWebElement _payables_AccountsPayable_MerchantEnrollmentStatus_Merchants { get; set; }
		public void NavigateTo_Payables_AccountsPayable_MerchantEnrollmentStatus_Merchants()
		{
			NavigateToMenuItem(_payables_AccountsPayable_MerchantEnrollmentStatus_Merchants);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Merchant Enrollment Status']")]
		private IWebElement _payables_AccountsPayable_MerchantEnrollmentStatus_MerchantEnrollmentStatus { get; set; }
		public void NavigateTo_Payables_AccountsPayable_MerchantEnrollmentStatus_MerchantEnrollmentStatus()
		{
			NavigateToMenuItem(_payables_AccountsPayable_MerchantEnrollmentStatus_MerchantEnrollmentStatus);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='EnCircle Enrollment']")]
		private IWebElement _payables_AccountsPayable_MerchantEnrollmentStatus_EncircleEnrollment { get; set; }
		public void NavigateTo_Payables_AccountsPayable_MerchantEnrollmentStatus_EncircleEnrollment()
		{
			NavigateToMenuItem(_payables_AccountsPayable_MerchantEnrollmentStatus_EncircleEnrollment);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='AR-Exchange Invoices']")]
		private IWebElement _payables_AccountsPayable_MerchantEnrollmentStatus_ArExchangeInvoices { get; set; }
		public void NavigateTo_Payables_AccountsPayable_MerchantEnrollmentStatus_ArExchangeInvoices()
		{
			NavigateToMenuItem(_payables_AccountsPayable_MerchantEnrollmentStatus_ArExchangeInvoices);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Create Single-Use Accounts']")]
		private IWebElement _payables_AccountsPayable_MerchantEnrollmentStatus_CreateSingleUseAccounts { get; set; }
		public void NavigateTo_Payables_AccountsPayable_MerchantEnrollmentStatus_CreateSingleUseAccounts()
		{
			NavigateToMenuItem(_payables_AccountsPayable_MerchantEnrollmentStatus_CreateSingleUseAccounts);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Create Test Transactions']")]
		private IWebElement _payables_AccountsPayable_MerchantEnrollmentStatus_CreateTestTransactions { get; set; }
		public void NavigateTo_Payables_AccountsPayable_MerchantEnrollmentStatus_CreateTestTransactions()
		{
			NavigateToMenuItem(_payables_AccountsPayable_MerchantEnrollmentStatus_CreateTestTransactions);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Start CLU or ECLU']")]
		private IWebElement _payables_AccountsPayable_MerchantEnrollmentStatus_StartCluOrEclu { get; set; }
		public void NavigateTo_Payables_AccountsPayable_MerchantEnrollmentStatus_StartCluOrEclu()
		{
			NavigateToMenuItem(_payables_AccountsPayable_MerchantEnrollmentStatus_StartCluOrEclu);
		}

		
		private void NavigateToMenuItem(IWebElement element)
		{
			Driver.Url = element.GetAttribute("href");
		}
		#endregion

		public ManageVendorStatus(GlobalSettings settings) : base(settings) { }
	}  
}
