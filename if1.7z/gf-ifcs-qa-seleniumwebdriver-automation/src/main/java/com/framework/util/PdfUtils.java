package com.framework.util;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDDocumentCatalog;
import org.apache.pdfbox.pdmodel.interactive.form.PDAcroForm;
import org.apache.pdfbox.pdmodel.interactive.form.PDField;
import org.apache.pdfbox.text.PDFTextStripper;

public class PdfUtils {

	static PDDocument document = null;
	static PDFTextStripper pdfStripper = null;

	/* Read Whole text from Pdf file*/
	public static String readDocument(String pdfFilePathLocal) {
		File file = new File(pdfFilePathLocal);
		String text = null;
		try {

			document = PDDocument.load(file);
			// Instantiate PDFTextStripper class
			pdfStripper = new PDFTextStripper();
			// Retrieving text from PDF document
			text = pdfStripper.getText(document);
			// Closing the document
			document.close();
		} catch (Exception e) {
			e.getMessage();
		}
		return text;
	}

	/*
	 * Read text from Pdf file page wise
	 * Page Number starts from 1
	 */
	public static List<String> getTextPageWise(String pdfFilePathLocal, int fromPage, int toPages) {
		File file = new File(pdfFilePathLocal);
		String text = null;

		List<String> textFromPdf = new ArrayList<String>();
		try {
			document = PDDocument.load(file);
			/*int count = document.getNumberOfPages();
			System.out.print("Pages Count::" + count);*/
			// Instantiate PDFTextStripper class
			pdfStripper = new PDFTextStripper();
			do {
				pdfStripper.setStartPage(fromPage);
				pdfStripper.setEndPage(fromPage);
				// Retrieving text from PDF document
				text = pdfStripper.getText(document);
				// System.out.print(text);
				textFromPdf.add(text);
				fromPage++;
			} while (fromPage <= toPages);
			// Closing the document
			document.close();
		} catch (Exception e) {
			e.getMessage();
		}
		return textFromPdf;
	}

	/* Read Text from Form in PDF*/
	public static List<String> getTextFromForm(String pdfFilePathLocal, int pageNumber) {
		String text = null;
		File file = new File(pdfFilePathLocal);
		List<String> textList = new ArrayList<String>();
		try {
			document = PDDocument.load(file);
			document.getPage(pageNumber);
			PDDocumentCatalog catalog = document.getDocumentCatalog();
			PDAcroForm form = catalog.getAcroForm();

			List<PDField> fields = form.getFields();
			for (PDField obj : fields) {
				text = obj.getValueAsString();
				textList.add(text);
			}
		} catch (Exception e) {
			e.getMessage();
		}
		return textList;
	}

	/* Read text from expected page*/
	public static String getTextFromExpectedPage(String pdfFilePathLocal, int pageNumber) {
		File file = new File(pdfFilePathLocal);
		String text = null;
		try {
			document = PDDocument.load(file);
			// Instantiate PDFTextStripper class
			pdfStripper = new PDFTextStripper();
			pdfStripper.setStartPage(pageNumber);
			pdfStripper.setEndPage(pageNumber);
			// Retrieving text from PDF document
			text = pdfStripper.getText(document);
			// Closing the document
			document.close();
		} catch (Exception e) {
			e.getMessage();
		}
		return text;
	}
	
	public static int getNumberOfPages(String pdfFilePathLocal) {
		int pageSize=0;
		File file = new File(pdfFilePathLocal);
		try {
			document = PDDocument.load(file);
			pageSize=document.getNumberOfPages();
			document.close();
		}  catch (Exception e) {
			e.getMessage();
		}
		return pageSize;
	}
}

