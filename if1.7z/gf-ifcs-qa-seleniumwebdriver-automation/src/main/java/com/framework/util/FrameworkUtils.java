package com.framework.util;

import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.InetAddress;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.framework.basetest.BaseTest;
public class FrameworkUtils {
	
	/******************************************************************************************
	 * Name: getBrowserDetails | Description: Gets Browser Name and Version
	 ******************************************************************************************/
	/*public static String getBrowserDetails() throws Exception {
		Capabilities caps = ((RemoteWebDriver)BaseTest.driver).getCapabilities();
		String browserName = caps.getBrowserName();
		String browserVersion = caps.getVersion();
		String browser = (browserName + " " + browserVersion).toUpperCase();
		return browser;
	}*/

	/******************************************************************************************
	 * Name: getOSDetails | Description: Gets OS Name and Version
	 ******************************************************************************************/
	public static String getOSDetails() throws Exception {
		String OS = System.getProperty("os.name");
		OS = (OS).toUpperCase();
		//System.out.println(OS);
		return OS;
	}

	/******************************************************************************************
	 * Name: getHostDetails | Description: Gets HOST Name
	 ******************************************************************************************/
	public static String getHostDetails() throws Exception {
		String myHost = InetAddress.getLocalHost().getHostName().toUpperCase().trim();
		//System.out.println(myHost);
		return myHost;

	}

	/******************************************************************************************
	 * Name: capture | Description: Take Screenshot
	 ******************************************************************************************/
	public static String capture(WebDriver driver) throws IOException {
		TakesScreenshot takesScreenshot = (TakesScreenshot) driver;
		File source = takesScreenshot.getScreenshotAs(OutputType.FILE);
		String dest = BaseTest.ssFolder + "/" + getCurrentDateTime() + ".png";
		File destination = new File(dest);
		FileUtils.copyFile(source, destination);
		return dest;
	}

	/******************************************************************************************
	 * Name: getCurrentDateTime | Description: Captures current Date and Time
	 ******************************************************************************************/
	public static String getCurrentDateTime() {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
		Date date = new Date();
		return sdf.format(date);
	}

	
	public static void executeFromTerminal() {
		 
		System.out.println("----Coming here ------");
		String directory =  "Resources/Drivers/ChromeDriver/Linux"  ; 

        try {
            int ch;
	    // run the Unix "ps -ef" command
            // using the Runtime exec method:
        	ProcessBuilder pb = new ProcessBuilder("bash", "-c","chmod 755 chromedriver"); 
        	pb.directory(new File(directory)); 
            
            Process shellProcess = pb.start();
             
         
            shellProcess.waitFor(); 
              
            InputStreamReader myIStreamReader = new 
            InputStreamReader(shellProcess.getInputStream()); 
                   
            while ((ch = myIStreamReader.read()) != -1) { 
                System.out.print((char)ch); 
                    } 
            
            System.out.println("----Ending here ------");
            
            
        }
        catch (IOException e) {
         
            e.printStackTrace();
           
        }
        catch (InterruptedException e) {
            
            e.printStackTrace();
            
        } 
		
	}
	
	public static void loadLibraries(){
	        try {
	        	System.out.println("-----coming in---------");
	        	String downloadedFilePath=System.getProperty("user.dir") + "/Resources/Libraries/tess-lib";
	        	//System.out.println(downloadedFilePath);
	        	System.load(downloadedFilePath+"/liblept.so.4");
	        	System.load(downloadedFilePath+"/liblept.so.4.0.1");
	        	System.load(downloadedFilePath+"/libtesseract.so.3");
	        	System.load(downloadedFilePath+"/libtesseract.so.3.0.3");    	
	        } catch (UnsatisfiedLinkError e) {
	        	 e.printStackTrace();
	          
	        }
	      }
	}
