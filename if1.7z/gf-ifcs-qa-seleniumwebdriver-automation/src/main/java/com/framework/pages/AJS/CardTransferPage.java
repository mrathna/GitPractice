package com.framework.pages.AJS;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.ExtentTest;
import com.framework.basepage.BasePage;
import com.framework.pages.AJS.common.Common;
import com.framework.repo.Locator_IFCS;

public class CardTransferPage extends BasePage {
	
	@FindBy(xpath=Locator_IFCS.CARDTRANSFER_TABLE)
	public WebElement cardTable;
	
	@FindBy(xpath=Locator_IFCS.POPUP_MENUITEM_ADD_CARDTRANSFER)
	public WebElement popupMenuItemAddCardTransfer;
	

	public CardTransferPage(WebDriver driver, ExtentTest test) {
		super(driver, test);
		PageFactory.initElements(driver, this);
		 }

	Common common=new Common(driver,test);
	
	public void verifyCard() {
		chooseSubMenuFromLeftPanel("Card Details","Card Transfers");
		rightClick(cardTable);
		common.addCardTransferRequestPopup();
	}
	
	
	
	public void cardTransferRequestForm(String cardNumber,String effectiveDate) {
		String reqBy=fakerAPI().name().firstName(); 
		String phoneNo=fakerAPI().phoneNumber().cellPhone();
		chooseSubMenuFromLeftPanel("Card Details","Card Transfers");
		validateHeaderLabel("Card Transfers");
		sleep(5);
		rightClick(cardTable);
		common.addCardTransferRequestPopup();
		chooseOptionFromDropdown("Card Offer","random");
		sleep(2);
		enterValueInTextBox("Card Transfer Requests","New Customer",cardNumber);
		sleep(2);
		enterValueInTextBox("Card Transfer Requests","Requested By",reqBy);
		sleep(2);
		enterValueInTextBox("Card Transfer Requests","Phone Number",phoneNo);
		sleep(2);
		enterValueInTextBox("Card Transfer Requests","Effective Date",effectiveDate);
		sleep(2);
		validateCheckBoxToCheckOrUncheckInTableRow("Cards","Transfer?",0,"Checked");
		sleep(2);
		getValueFromProtectedTextBox("Card Transfer Requests","New Customer Name");
		sleep(2);
		System.out.println("popup info done..........................");
	}
	
	
	public void validateCardTransferForPublicAndPrivateFeeProfile() {
		sleep(2);
		chooseOptionFromDropdown("Card Product","random");
		sleep(2);
		chooseOptionFromDropdown("New Card Product","random");
		sleep(2);
		chooseOptionFromDropdown("New Card Profile","random");
		sleep(2);
		chooseOptionFromDropdown("New Fee Profile","random");
		sleep(2);
		validateCheckBoxToCheckOrUncheck("Card Transfer Requests","Create Private Card Profile?","Checked");
		sleep(2);
		common.clickSaveIcon();
		sleep(5);
		verifyValidationResult("Only one value must be set");
		
	}
	
	public void validateCardTransferForSameCardType() {
		sleep(2);
		chooseOptionFromDropdown("Card Product","random");
		sleep(2);
		chooseOptionFromDropdown("New Card Product","random");
		sleep(2);
		chooseOptionFromDropdown("New Card Profile","random");
		sleep(2);
		chooseOptionFromDropdown("New Fee Profile","random");
		sleep(2);
		common.clickSaveIcon();
		sleep(5);
		verifyValidationResult("Validation successful");
	}
	
public void validateCardTransferAPAtoPCCustomer() {
		
		sleep(5);
		common.clickSaveIcon();
		sleep(5);
		verifyValidationResult("New Customer has a different Card Program to Old Customer.");
		
	}
	}
		
		
		
		
		
	
	
	

