package com.framework.testcases.AJS.CHEVRON;

import java.util.HashMap;
import java.util.Map;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.MerchantLocationPage;
import com.framework.pages.AJS.common.Common;
import com.framework.pages.AJS.common.IFCSCommonPage;
import com.framework.pages.AJS.common.IFCSHomePage;
import com.framework.pages.AJS.common.IFCSLoginPage;
import com.framework.pages.AJS.common.InterfacePage;
import com.framework.util.PropUtils;

public class ValidateMerchantAgreementTestcases  extends BaseTest {
	
	@Parameters({ "clientCountry", "clientName"})
	@Test( groups = { "Regression" })
	public void CreateMerchantAndMerchantAgreementCORO(@Optional("TH") String clientCountry,
			@Optional("CHEVRON") String clientName) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  Create Merchant and Merchant Agreement of type CORO",
				"TC005 Create Merchant and Merchant Agreement of type CORO");
		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		Common common=new Common(driver,test);
		MerchantLocationPage  merchantLocation=new MerchantLocationPage(driver,test);
		IFCSloginPage.login("IFCS_URL_CHEVRON", "IFCS_CHEVRON_USERNAME", "IFCS_CHEVRON_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry,"");
		IFCSHomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);
		IFCSHomePage.gotoMerchantAndClickMerchantDetails();
		String merchant=common.getMerchantNoFromDB();
		common.chooseMerchantNoAndSearch(merchant);
		merchantLocation.createNewMerchantForChevronTH(merchant,"CORO");
		merchantLocation.merchantMaintainAgreements();
		merchantLocation.validateAddNewAgreementInAgreementList("Giro");
		//merchantLocation.createMerchantAgreementPublicAndPrivateProfile();
		IFCSHomePage.exitIFCS();
	}
	
	/*@Test( groups = { "Regression" },enabled=false)
	public void CreateMerchantAndMerchantAgreementRORO(@Optional("TH") String clientCountry,
			@Optional("CHEVRON") String clientName) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  Create Merchant and Merchant Agreement of type RORO",
				"TC006 Create Merchant and Merchant Agreement of type RORO");
		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		Common common=new Common(driver,test);
		MerchantLocationPage  merchantLocation=new MerchantLocationPage(driver,test);
		IFCSloginPage.login("IFCS_URL_CHEVRON", "IFCS_CHEVRON_USERNAME", "IFCS_CHEVRON_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry,"");
		IFCSHomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);
		IFCSHomePage.gotoMerchantAndClickMerchantDetails();
		//String merchant=common.getMerchantNoFromDB();
		//common.chooseMerchantNoAndSearch(merchant);
		Faker fakerNumber = new Faker();
		String merchantNo = fakerNumber.number().digits(6);
		merchantLocation.createNewMerchantForChevronTH(merchantNo,"RORO");
		merchantLocation.merchantMaintainAgreements();
		//merchantLocation.createMerchantAgreementPublicAndPrivateProfile();
		IFCSHomePage.exitIFCS();
	}	*/
	
	
	@Parameters({ "clientCountry", "clientName" })
	@Test(priority = 42, groups = { "BusinessFlow" })
	public void validateMerchantReportIsNotGeneratedWhenNoTransactionAndEmptyReport(@Optional("BE") String clientCountry,
			@Optional("WFE") String clientName) {

		test = extent.createTest(
				clientName + ":" + clientCountry + "TC04_CHEV_Merchant Reports_ NoTransaction_EmptyReport ",
				"Merchant Report is nOt generated");

		// creating object for the Pages
		IFCSLoginPage ifcsloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		Common common = new Common(driver, test);
		IFCSCommonPage ifcsCommonPage=new IFCSCommonPage(driver, test);
		InterfacePage interfacePage =new InterfacePage(driver, test);
		Map<String, String> inputvalues = new HashMap<String, String>();
		String clientNameInProp;
		String currentDate,ifcsPreviousDate,queryDate;
		ifcsloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");

		// Calling Functions
		ifcsloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		IFCSHomePage.gotoApplicationAndClickApplicationMenu();
		IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);

		clientNameInProp = PropUtils.getPropValue(configProp, clientName + "_" + clientCountry);
		currentDate = common.getCurrentIFCSDateFromDB(clientNameInProp);
		ifcsPreviousDate = common.enterADateValueInStatusBeginDateField("oneDayBefore", currentDate);         
		System.out.println("Date ::" + ifcsPreviousDate);	
		/*queryDate=common.changeDateFormat(ifcsPreviousDate);
		System.out.println("Query Date: \t"+queryDate);*/
		inputvalues=common.getMerchantNoWithNotransactionLocation(clientNameInProp, "01-JAN-22");
	    System.out.println(inputvalues.get("MERCHANT_NO"));


	}


}
