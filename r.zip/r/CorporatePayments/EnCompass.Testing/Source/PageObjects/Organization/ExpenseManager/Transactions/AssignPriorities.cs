﻿using Common.Utility;
using NFluent;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using System.Collections.Generic;
using System.Linq;

namespace EnCompass.Testing.Source.PageObjects.Organization.ExpenseManager.Transactions
{
	public partial class AssignPriorities
	{
        #region XPath page Elements
        private const string _savePrioritiesXPath = @"//input[contains(@id,'btSave')]";
        #endregion

        #region Page Elements
        private IWebElement _savePriorities
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_savePrioritiesXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Info("Found _savePriorities");
                return element;
            }
        }
        #endregion

        public void MovePrioritizationFromLastToFirst()
		{
			IReadOnlyCollection<IWebElement> arrows = Driver.FindElements(By.XPath("//button[contains(@name,'arrow') and not(contains(@style,'hidden'))]"));
			if(arrows.Count > 0)
			{
				int counter = 1;
				foreach (IWebElement arrow in arrows)
				{
					if (arrow.Enabled)
					{
						counter++;
						arrow.JSClickWithFocus(Driver);
						string value = Driver.FindElement(By.XPath("//span[@id='counter" + counter + "']")).Text;
						Check.That(value).Contains((counter - 1).ToString());
					}					
				}
			}
		}
		
		public void PressSave()
		{
			_savePriorities.JSClickWithFocus(Driver);
			this.AttachOnDemandScreenShot();
		}

	}
}
