using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using Common;
using Common.PageObjects;
using Common.ScenarioConfigurations;
using Common.Utility;

namespace EnCompass.Testing.Source.PageObjects.Organization.SecurityManager.Alerts 
{
	/// <summary>
	/// Auto-generated Page Model Class
	/// Navigation Paths: 
		/// [Organization Home]->Security->Alerts and Notifications
		/// [Organization Home]->Security->Alerts and Notifications->Alert Settings
		/// </summary>
	[PageModel(@"/securityManager/alerts/manageAlerts.aspx")]
	public partial class ManageAlerts : EnCompassOrgPageModel 
	{
		public override string RelativeUrl => @"/securityManager/alerts/manageAlerts.aspx";
		public override string PageIdentifierXPath_Generated => @"//li[contains(@class, 'breadcrumb-item active')][text() = 'Alert Settings']";

		#region Navigation
				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Alert Settings']")]
		private IWebElement _security_AlertsAndNotifications_AlertSettings { get; set; }
		public void NavigateTo_Security_AlertsAndNotifications_AlertSettings()
		{
			NavigateToMenuItem(_security_AlertsAndNotifications_AlertSettings);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Card Notifications']")]
		private IWebElement _security_AlertsAndNotifications_CardNotifications { get; set; }
		public void NavigateTo_Security_AlertsAndNotifications_CardNotifications()
		{
			NavigateToMenuItem(_security_AlertsAndNotifications_CardNotifications);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Notification Settings']")]
		private IWebElement _security_AlertsAndNotifications_NotificationSettings { get; set; }
		public void NavigateTo_Security_AlertsAndNotifications_NotificationSettings()
		{
			NavigateToMenuItem(_security_AlertsAndNotifications_NotificationSettings);
		}

		
		private void NavigateToMenuItem(IWebElement element)
		{
			Driver.Url = element.GetAttribute("href");
		}
		#endregion

		public ManageAlerts(GlobalSettings settings) : base(settings) { }
	}  
}
