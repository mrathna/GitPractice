﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using Common;
using Common.PageObjects;
using Common.ScenarioConfigurations;
using Common.Utility;
using System;
using NFluent;
using AventStack.ExtentReports.Model;

namespace EnCompass.Testing.Source.PageObjects.Organization.Admin.Management
{
    public partial class CardHierarchy
    {       
        public override string PageIdentifierXPath_Override => @"//li[contains(@class, 'breadcrumb-item active')][text() = 'Create or Edit']/preceding-sibling::*[text()='Card Hierarchy']";

        #region xpath page Elements

        private const string _HierarchyNumberXPath = @"//div[contains(@class,'selectionNodeNumber')]";
        private const string _createNewHierarchiesXPath = @"//input[contains(@id, 'optNew')]";
        private const string _hierarchyNumberXPath = @"//input[contains(@id, 'txtNewNumber')]";
        private const string _hierarchyNameXPath = @"//input[contains(@id, 'txtNewName')]";
        private const string _saveXPath = @"//input[contains(@id, 'btnNew')]";
        private const string _editSaveXPath = @"//input[contains(@id, 'btnEdit')]";
        private const string _editHierarchyXPath = @"//button[contains(@id, 'tabEdit')]";
        private const string _findOptionXPath = @"//a[contains(@id,'hierarchyExplorer')]";
        private const string _editNameXPath = @"//input[contains(@id,'EditName')]";
        private const string _successMessageXPath = "//div[contains(@id,'SuccessMessage')]";
        private const string _lblEditNumberXPath = @"//span[contains(@id,'lblEditNumber')]";
        #endregion

        #region Page Elements

        private IWebElement _HierarchyNumber
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_HierarchyNumberXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_HierarchyNumber element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _createNewHierarchies
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_createNewHierarchiesXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_createNewHierarchies element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _hierarchyNumber
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_hierarchyNumberXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_hierarchyNumber element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _hierarchyName
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_hierarchyNameXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_hierarchyName element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _save
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_saveXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_save element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _editSave
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_editSaveXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_editSave element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _editHierarchy
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_editHierarchyXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_editHierarchy element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _findOption
        {
            get
            {
                //trytowaitforlementvisible is not working so replaceed with trytowaitforlement
                bool found = Driver.TryWaitForElement(By.XPath(_findOptionXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_findOption element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _editName
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_editNameXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_editName element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        #endregion

        public string GetHierarchyNumber
        {
            get
            {
                return _hierarchyNumber.GetAttribute("innerText");
            }
        }

        public void ClickEditHierarchy()
        {
            _editHierarchy.JSClickWithFocus(Driver);
            Settings.EnCompassExtentTest.Info("Clicked Edit Hierarchy section");
        }

        public void ClickFindOption()
        {
            _findOption.JSClickWithFocus(Driver);
            Settings.EnCompassExtentTest.Info("Clicked Find Option");
        }

        public string UpdatedHierarchyName
        {            
            set{
                _editName.Clear();
                _editName.SendKeys(value);
                Settings.Scenario["updatedHierarchy"] = value;
                Settings.EnCompassExtentTest.Info("Updated hierarchy name to:-"+value);
            }
        }

        public void ClickSaveFromEditPage()
        {
            _editSave.JSClickWithFocus(Driver, _editSaveXPath,Settings);
            this.AttachOnDemandScreenShot();
            Settings.EnCompassExtentTest.Info("clicked save from edit page");
            
        }

        public void SelectRadioNewHierarchies()
		{
			_createNewHierarchies.JSClickWithFocus(Driver);
		}

		public string HierarchyNumber
		{
			set
			{
				_hierarchyNumber.Clear();
				_hierarchyNumber.SendKeys(value);
                Settings.EnCompassExtentTest.Info("Entered Hierarchy Number:-"+value);
            }
		}

		public string HierarchyName
		{
			set
			{
				_hierarchyName.Clear();
				_hierarchyName.SendKeys(value);
                Settings.EnCompassExtentTest.Info("Entered Hierarchy Name:-" + value);
            }
		}

		public void Save()
		{
			_save.JSClickWithFocus(Driver);
			this.AttachOnDemandScreenShot();
		}

        public void WaitForSuccessMsg()
        {
            Driver.WaitForVisible(By.XPath(_successMessageXPath));
        }

        public bool CompareHierarchyNumLength(int numLength)
        {
            if (_hierarchyNumber.GetAttribute("value").Length == numLength)
                return true;
            else
                return false;
        }
        public bool CompareHierarchyNameLength(int nameLength)
        {
               if (_hierarchyName.GetAttribute("value").Length <= nameLength)
                return true;
            else
                return false;            
        }
        public void VerifyErrorMsg(string strMsg)
        {
            Driver.WaitForDocumentLoadToComplete();
            Check.That(GetErrorMessagesAsList[1].Contains(strMsg));          
        }
    }
}
