﻿extern alias cpt;
using AventStack.ExtentReports;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net;
using TechTalk.SpecFlow;

namespace Common.Utility
{
    public class RestClientHelper 
    {
        private ScenarioContext ScenarioContext;

        public RestClientHelper(ScenarioContext scenarioContext)
        {
            this.ScenarioContext = scenarioContext;
        }
		
		/// <summary>
		/// Rest Client helper to trigger Rest based request and return IRestResponse object
		/// </summary>
		public static IRestResponse CreateAndExecuteRestRequest(string baseUrl, string resource, string requestType, string jsonBody,
			ExtentTest test,Dictionary<string,string>parameters = null, Dictionary<string, string> Cookies = null)
		{
			// Get Rest Client 
			RestClient client = new RestClient();
			client.BaseUrl = new Uri(baseUrl);
			test.Info("RestClient Base url set to : " + baseUrl);

			// Set cookies
			client.CookieContainer = new CookieContainer();
			if (Cookies != null)
			{
				Cookies.ToList().ForEach(f => {
					client.CookieContainer.Add(new Uri(baseUrl), new Cookie(f.Key, f.Value));
					test.Info("RestClient Cookie Container updated with cookie " + f.Key + " value : " + f.Value);});
			}
			test.Info("RestClient Cookie Container updated with all the cookies");

			// Create Request
			Method.TryParse(requestType.ToUpper(), out Method reqType);
			RestRequest request = new RestRequest(resource, reqType);
			test.Info("RestClient Request created for method with resource: " + request.Resource + " and Method: " + request.Method.ToString());

            // Add Headers to request
            request.AddParameter("Accept", "application/json, text/javascript, */*; q=0.01", ParameterType.HttpHeader);
            //request.AddHeader("Accept", "application/json, text/javascript, */*; q=0.01");
			test.Info("RestClient Request Headers updated for 'Accept'");

			// Add query parameters if present
			if (parameters != null)
			{
				parameters.ToList().ForEach(p => {
					request.AddParameter(p.Key, p.Value, ParameterType.QueryString);
					test.Info("RestClient request query parameter updated with queryID: " + p.Key + " value : " + p.Value);
				});
			}

            // Add the Json body to request
            if (!string.IsNullOrEmpty(jsonBody))
            {
                request.AddParameter("application/json", jsonBody, ParameterType.RequestBody);
                //request.AddJsonBody(cpt.Newtonsoft.Json.JsonConvert.DeserializeObject(jsonBody));
                test.Info("RestClient Request Json Body below :");
				test.Info("<textarea>" + jsonBody + "</textarea>");
			}

			// Execute Request
			IRestResponse response = client.Execute(request);
			test.Info("RestClient successfully executed Request, Response Content below:");
			test.Info("<textarea>" +  response.Content +  "</textarea>");
			return response;
		}

		/*
         * Helper to create a RestClient object and store it in the ScenarioContext for steps to use.
         * This method is called ONLY once per scenario.
         */
		public void createRestClientInstance()
        {
            RestClient client = new RestClient();
            string uname = ConfigurationManager.AppSettings.Get("proxyuser");
            string pwd = ConfigurationManager.AppSettings.Get("proxypass");
            client.Proxy = new WebProxy("172.19.39.239", 80)
            {
                Credentials = new NetworkCredential(uname,pwd)
            };
            this.ScenarioContext.Add("restClient", client);
        }

        /*
         * Posts a json string as a part of request to the Rest Api (url + resourceName).
         * Also stores the IRestResponse object in Scenario Context for next steps to use.
         * NOTE - This method can be called MULTIPLE times within a scenario
         */
        public void postRestClient(string url, string postString, string resourceName)
        {
            this.ScenarioContext.Get<RestClient>("restClient").BaseUrl = new Uri(url);
            RestRequest request = new RestRequest(resourceName, Method.POST);
            request.AddHeader("Content-type", "application/json; charset=UTF-8");
            request.AddParameter("application/json; charset=utf-8", postString, ParameterType.RequestBody);
            IRestResponse response = ScenarioContext.Get<RestClient>("restClient").Execute(request);
            // Remove any pre-existing key with same name before adding a new one.
            this.ScenarioContext.Remove("restResponse");
            this.ScenarioContext.Add("restResponse", response);
        }

        /*
         * Invokes a GET to the Rest Api (url + resourceName).
         * Also stores the IRestResponse object in Scenario Context for next steps to use.
         * NOTE - This method can be called MULTIPLE times within a scenario
         */
        public void getRestClient(string url, string resourceName)
        {
            this.ScenarioContext.Get<RestClient>("restClient").BaseUrl = new Uri(url);
            RestRequest request = new RestRequest(resourceName, Method.GET);
            IRestResponse response = ScenarioContext.Get<RestClient>("restClient").Execute(request);
            // Remove any pre-existing key with same name before adding a new one.
            this.ScenarioContext.Remove("restResponse");
            this.ScenarioContext.Add("restResponse", response);
        }

        /*
         * Invokes a GET to the Rest Api (url + resourceName + query Parameters).
         * Also stores the IRestResponse object in Scenario Context for next steps to use.
         * NOTE - This method can be called MULTIPLE times within a scenario
         */
        public void getRestClient(string url, string resourceName, Dictionary<String,String> queryParams)
        {
            this.ScenarioContext.Get<RestClient>("restClient").BaseUrl = new Uri(url);
            RestRequest request = new RestRequest(resourceName, Method.GET);
            Dictionary<String,String>.Enumerator enm =  queryParams.GetEnumerator();
            while (enm.MoveNext())
            {
                request.AddParameter(enm.Current.Key, enm.Current.Value, ParameterType.UrlSegment);
            }
           
            IRestResponse response = ScenarioContext.Get<RestClient>("restClient").Execute(request);
            // Remove any pre-existing key with same name before adding a new one.
            this.ScenarioContext.Remove("restResponse");
            this.ScenarioContext.Add("restResponse", response);
        }

    }
}
