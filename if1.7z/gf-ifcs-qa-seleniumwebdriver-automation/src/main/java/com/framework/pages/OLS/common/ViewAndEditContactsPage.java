package com.framework.pages.OLS.common;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.ExtentTest;
import com.framework.basepage.BasePage;
import com.framework.repo.Locator;

public class ViewAndEditContactsPage extends BasePage {

	@FindBy(how = How.ID, using = Locator.ADD_CONTACT_BUTTON)
	public WebElement addContactButton;
	@FindBy(how = How.ID, using = Locator.ADD_CONTACT_PAGE_HEADER)
	public WebElement addContactPageHeader;
	@FindBy(how = How.LINK_TEXT, using = Locator.VIEW_AND_EDIT_CONTACT_PAGE)
	public WebElement viewEditContactPage;
	@FindBy(how = How.XPATH, using = Locator.VIEW_AND_EDIT_CONTACTS_PAGE)
	public WebElement viewEditContactsPage;
	

	// Added by Nithya - 30-04-2018
	@FindBy(how = How.ID, using = Locator.CONTACT_CD_CONTACT_TYPE)
	public WebElement contactType;

	@FindBy(how = How.ID, using = Locator.CONTACT_CD_CONTACT_DEFAULT)
	public WebElement setAsDefault;

	@FindBy(how = How.ID, using = Locator.CONTACT_NAME)
	public WebElement contactNameField;

	@FindBy(how = How.ID, using = Locator.PHONE_FIELD)
	public WebElement phoneNoField;

	@FindBy(how = How.ID, using = Locator.JOBTITLE_FIELD)
	public WebElement jobTitleField;

	@FindBy(how = How.ID, using = Locator.MOBILE_FIELD)
	public WebElement mobileNoField;

	@FindBy(how = How.ID, using = Locator.FAX_FIELD)
	public WebElement faxNoField;

	@FindBy(how = How.ID, using = Locator.EMAIL_FIELD)
	public WebElement emailAddressField;

	@FindBy(how = How.ID, using = Locator.PHYSICAL_ADDRESS)
	public WebElement physicalAddressField;

	@FindBy(how = How.ID, using = Locator.PHYSICAL_SUBURB)
	public WebElement physicalSuburbField;

	@FindBy(how = How.ID, using = Locator.POSTALCODE)
	public WebElement postalCodeField;

	@FindBy(how = How.ID, using = Locator.STATE_PHY)
	public WebElement stateField;

	@FindBy(how = How.ID, using = Locator.MERCHANT_PHYSICAL_COUNTRY)
	public WebElement merchantCountryField;
	@FindBy(how = How.ID, using = Locator.RETURN_TO_CONTACT)
	public WebElement returnToContact;

	@FindBy(how = How.ID, using = Locator.CONTACT_SAVE_BUTTON)
	public WebElement contactSaveButton;

	// Merchant/Location - Nithya - 08-05-2018
	@FindBy(id = Locator.CONTACT_SAVE)
	public WebElement contactSaveInMercOrLoc;

	@FindBy(id = Locator.CONTACT_ADD_A_CONTACT)
	public WebElement addAContactInMercOrLoc;

	// Added by Nithya - 02-05-2018
	@FindBy(how = How.XPATH, using = Locator.CONTACTS_LIST)
	public List<WebElement> contactsList;

	@FindBy(how = How.XPATH, using = Locator.VIEW_AND_EDIT_CONTACT_DETAILS)
	public List<WebElement> viewAndEditContactDetails;

	@FindBy(how = How.ID, using = Locator.CONFIRMATIONMESSAGE)
	public WebElement confirmationMsg;

	@FindBy(how = How.ID, using = Locator.DELETE_CONTACT_BUTTON)
	public WebElement deleteContactButton;

	@FindBy(how = How.ID, using = Locator.REQUESTSENTPOPUPOK)
	public WebElement deleteContactOK;

	@FindBy(how = How.ID, using = Locator.RESENDPINPOPUPCANCEL)
	public WebElement deleteContactCancel;

	@FindBy(how = How.ID, using = Locator.EXPORT_CONTACT_LIST)
	public WebElement exportContactButton;

	@FindBy(how = How.XPATH, using = Locator.CONTACT_TYPES)
	public List<WebElement> contactsAlreadyHave;

	// Merchant/Location - Nithya - 08-05-2018
	@FindBy(xpath = Locator.CONTACT_TYPES_FOR_MERCORLOC)
	public List<WebElement> contactTypesAlreadyHaveForMercOrLoc;

	@FindBy(id = Locator.CONTACT_ADD_A_CONTACT_BACK_CONTACTLIST)
	public WebElement backToContactList;

	@FindBy(how = How.XPATH, using = Locator.MERCORLOC_CONTACT_TITLE)
	public WebElement mercOrLocContactPageTitle;

	@FindBy(how = How.XPATH, using = Locator.CONTACT_LIST_IN_MERCORLOC)
	public List<WebElement> contactsListForMercOrLoc;

	@FindBy(id = Locator.CONTACT_EXPORT)
	public WebElement contactExport;

	@FindBy(how = How.XPATH, using = Locator.CONTACT_TYPES_DROP_DOWN)
	public List<WebElement> availableContactTypes;

	public ViewAndEditContactsPage(WebDriver driver, ExtentTest test) {
		super(driver, test);
		PageFactory.initElements(driver, this);
	}

	/**
	 * Click Add New Contact Button
	 */
	public void clickAddContactButton(String merchantorCustomer) {
		if (merchantorCustomer.contains("Customer")) {
			isDisplayedThenActionClick(addContactButton, "Add New Contact");
		} else {
			isDisplayedThenActionClick(addAContactInMercOrLoc, "Add New Contact");
		}
	}

	/**
	 * Validates Add New Contact Page
	 */
	public void validateAddContactPage() {
		isDisplayed(addContactPageHeader, "Add Contact Page Header");
	}

	/**
	 * Validates View And Edit Contact Page
	 */
	public void validateViewEditContactPage() {
		isDisplayed(viewEditContactsPage, "View and Edit Contact");
	}

	// Updated By Nithya 03-05-2018
	/**
	 * Get Contacts Already added
	 */
	ArrayList<String> contactsListAlreadyHave = new ArrayList<String>();

	public void getContactsAlreadyHave(String merchantOrCustomer) {
		contactsListAlreadyHave.clear();
		if (merchantOrCustomer.contains("Customer")) {
			for (int i = 0; i < contactsAlreadyHave.size(); i++) {
				contactsListAlreadyHave.add(getText(contactsAlreadyHave.get(i)));
			}
		} else {
			for (int i = 0; i < contactTypesAlreadyHaveForMercOrLoc.size(); i++) {
				contactsListAlreadyHave.add(getText(contactTypesAlreadyHaveForMercOrLoc.get(i)));
			}
		}
	}

	/**
	 * Choose a unique contact type for add contact
	 * 
	 * with Try Catch Exception
	 */
	boolean noUniqueContact;

	public void chooseUniqueContactType(String merOrLoc) {

		try {
			boolean anyMatch = false;
			String textToChoose = "";
			for (int i = 0; i < availableContactTypes.size(); i++) {
				for (int j = 0; j < contactsListAlreadyHave.size(); j++) {
					if ((getText(availableContactTypes.get(i)).equalsIgnoreCase(contactsListAlreadyHave.get(j)))) {
						anyMatch = true;
						break;
					} else {
						anyMatch = false;
					}
				}
				if (!anyMatch) {
					textToChoose = getText(availableContactTypes.get(i));
					chooseContactType(textToChoose);
					break;
				} else {

					if (anyMatch && i == availableContactTypes.size() - 1) {
						noUniqueContact = changeAccountAndCheckData("Unique Contact", merOrLoc);
					}
				}
			}
		} catch (Exception e) {
			logFail(e.getMessage());
		}

	}

	/**
	 * Choose a contact type
	 */
	public void chooseContactType(String textToChoose) {
		selectDropDownByVisibleText(contactType, textToChoose);
		verifyTextFromDropdown(contactType, textToChoose);
		sleep(3);
	}

	/**
	 * Choose the contact as default for that particular contact type
	 */
	public void setContactAsDefault() {
		if (!(setAsDefault.isSelected())) {
			actionClick(setAsDefault);
		}
		if (setAsDefault.isSelected()) {
			logPass("Contact set as default");
		} else {
			logFail("Contact not set as default");
		}
	}

	/**
	 * Selects a Contact from the Contact List
	 * 
	 * @throws Exception
	 */
	public void selectAContactFromListOfContact() {
		int randomNo;
		if (contactsList.size() > 0) {
			if (contactsList.size() == 1) {
				randomNo = 0;
			} else {
				randomNo = getRandomNumber(0, contactsList.size() - 1);
			}
			isDisplayedThenClick(contactsList.get(randomNo), "Choose a Contact");
			logPass("Contact chosen");
			isDisplayedThenClick(viewAndEditContactDetails.get(randomNo), "View And Edit Contact");
		} else {
			logFail("No Contacts To Edit");
		}

	}

	/**
	 * Selects a Contact from the Merchant contact list
	 * 
	 * @throws Exception
	 */
	public void selectAContactFromMercOrLocContacts(String merOrLoc) {
		try {
			int randomNo;
			if (contactsListForMercOrLoc.size() > 0) {
				if (contactsListForMercOrLoc.size() == 1) {
					randomNo = 0;
				} else {
					randomNo = getRandomNumber(0, contactsListForMercOrLoc.size() - 1);
				}
				isDisplayedThenClick(contactsListForMercOrLoc.get(randomNo), "Choose a Contact");
				logPass("Contact chosen");
			} else {
				changeAccountAndCheckData("Contact", merOrLoc);
			}
		} catch (Exception e) {
			logFail(e.getMessage());
		}

	}

	public boolean changeAccountAndCheckData(String noContactOrNoUniqueContact, String merchantOrLocation) {
		BPCommonPage commonPage = new BPCommonPage(driver, test);
		int randomNo;
		boolean noUniqueContact = false;
		if (noContactOrNoUniqueContact.equals("Unique Contact")) {
			System.out.println("No unique contact, so changing the account");
			isDisplayedThenActionClick(backToContactList, "Back to Contact List");
			sleep(2);
			commonPage.selectAccount();
			getContactsAlreadyHave(merchantOrLocation);
			clickAddContactButton(merchantOrLocation);
		} else {
			commonPage.selectAccount();
		}
		logPass("Account chosen");
		if (noContactOrNoUniqueContact.equals("Contact")) {
			if (contactsListForMercOrLoc.size() > 0) {
				if (contactsListForMercOrLoc.size() == 1) {
					randomNo = 0;
				} else {
					randomNo = getRandomNumber(0, contactsListForMercOrLoc.size() - 1);
				}
				isDisplayedThenClick(contactsListForMercOrLoc.get(randomNo), "Choose a Contact");
				logPass("Contact chosen");
			} else {
				logFail("No Contacts Found");
			}
		} else {
			boolean anyMatch = false;
			String textToChoose = "";
			for (int i = 0; i < availableContactTypes.size(); i++) {
				for (int j = 0; j < contactsListAlreadyHave.size(); j++) {
					if ((getText(availableContactTypes.get(i)).equalsIgnoreCase(contactsListAlreadyHave.get(j)))) {
						anyMatch = true;
						break;
					} else {
						anyMatch = false;
					}
				}
				if (!anyMatch) {
					textToChoose = getText(availableContactTypes.get(i));
					chooseContactType(textToChoose);
					break;
				} else {
					if (anyMatch && i == availableContactTypes.size() - 1) {
						// Changed to log info as this scenario is also a valid realtime scenario
						logInfo("No Unique Contact Type");
						noUniqueContact = true;
					}
				}
			}
		}
		return noUniqueContact;
	}

	public boolean isUniqueContactPresent() {
		return !noUniqueContact;
	}

	/**
	 * Enters Contact Information
	 */
	public void enterContactInformationDetails() {
		String contactName = fakerAPI().name().fullName();
		String phoneNo = fakerAPI().phoneNumber().phoneNumber().toString();
		String jobTitle = fakerAPI().job().title();
		String mobileNo = fakerAPI().phoneNumber().cellPhone().toString();
		String faxNo = fakerAPI().idNumber().valid().replaceAll("-", "");
		String emailAddress = fakerAPI().internet().emailAddress();

		isDisplayedThenEnterText(contactNameField, "Contact Name", contactName);
		isDisplayedThenEnterText(phoneNoField, "Phone Number", phoneNo);
		isDisplayedThenEnterText(jobTitleField, "Job Title", jobTitle);
		isDisplayedThenEnterText(mobileNoField, "Mobile Number", mobileNo);
		isDisplayedThenEnterText(faxNoField, "Fax Number", faxNo);
		isDisplayedThenEnterText(emailAddressField, "Email Address", emailAddress);

	}

	/**
	 * Enters Contact Address Information
	 */
	public void enterContactAddressDetails(String clientCountry, String customerOrLocMer) {
		
		String physicalAddress = fakerAPI().address().streetAddress();
		isDisplayedThenEnterText(physicalAddressField, "Physical Address", physicalAddress);
        
		String postalCode = countrySpecificFakerAPI(clientCountry).address().zipCode();
		isDisplayedThenEnterText(postalCodeField, "Postal Address", postalCode);

		if (clientCountry.contains("AU")) {
			String physicalSuburb = fakerAPI().address().cityName();
			isDisplayedThenEnterText(physicalSuburbField, "Physical Suburb ", physicalSuburb);
			selectInputFromDropdown(stateField, 1);
		} else if (clientCountry.contains("NZ")
				&& (customerOrLocMer.equalsIgnoreCase("Location") || customerOrLocMer.equalsIgnoreCase("Merchant"))) {
			selectInputFromDropdown(merchantCountryField, 1);
		}

	}

	/**
	 * Saves the Contact Information
	 * 
	 * @throws Exception
	 */
	public void saveContactDetails(String merchantOrCustomer) {
		if (merchantOrCustomer.contains("Customer")) {
			isDisplayedThenActionClick(contactSaveButton, "Contact Save");
		} else {
			isDisplayedThenActionClick(contactSaveInMercOrLoc, "Contact Save");
		}
		try {
			if (getText(confirmationMsg).contains("Congratulations. You have successfully")) {
				logPass("Contact added successfully" + getText(confirmationMsg));
			}
		} catch (Exception e) {
			if (!noUniqueContact) {
				logFail("Contact not added/updated to the contact list");
			} else {
				logInfo("No unique contact type to add");
			}
		}

	}

	/**
	 * Edit Contact Details
	 */
	public void editContactPhoneAndAddress(String clientCountry) {
		String phoneNo = fakerAPI().phoneNumber().phoneNumber().toString();
		isDisplayedThenEnterText(phoneNoField, "Phone No", phoneNo);

		String physicalAddress = fakerAPI().address().streetAddress();
		isDisplayedThenEnterText(physicalAddressField, "Physical Address", physicalAddress);

		if (clientCountry.contains("AU")) {

			String emailAddress = fakerAPI().internet().emailAddress();
			isDisplayedThenEnterText(emailAddressField, "Email Address", emailAddress);
			
			String physicalSuburb = fakerAPI().address().cityName();
			isDisplayedThenEnterText(physicalSuburbField, "Physical Suburb", physicalSuburb);

		}

		if (clientCountry.contains("NZ")) {
			String emailAddress = fakerAPI().internet().emailAddress();
			isDisplayedThenEnterText(emailAddressField, "Email Address", emailAddress);

			String faxNo = fakerAPI().idNumber().valid().replaceAll("-", "");
			isDisplayedThenEnterText(faxNoField, "Fax No", faxNo);

		}

		String postalCode = countrySpecificFakerAPI(clientCountry).address().zipCode();
		isDisplayedThenEnterText(postalCodeField, "Postal Code Field", postalCode);

	}

	/**
	 * Edit Contact Name
	 */
	public void editContactName() {
		String contactName = fakerAPI().name().fullName();
		isDisplayedThenEnterText(contactNameField, "Contact name", contactName);

	}

	/**
	 * Delete a contact from the contact list
	 */
	public void deleteAContact() {
		isDisplayedThenClick(deleteContactButton, "Delete Contact");
		sleep(2);
		isDisplayedThenClick(deleteContactOK, "Delete Contact OK");
		if (getText(confirmationMsg).contains("Congratulations. You have successfully deleted your ")) {
			logPass("Contact deleted successfully" + getText(confirmationMsg));
		} else {
			logFail("Contact not deleted from the contact list");
		}
	}

	public void clickDeleteAndClickCancelInConfirmation() {
		isDisplayedThenClick(deleteContactButton, "Delete Contact");
		sleep(2);
		isDisplayedThenClick(deleteContactCancel, "Delete Contact Cancel");
		sleep(2);
		isDisplayedThenClick(returnToContact, "Return To Contacts");
		sleep(5);
		validateViewEditContactPage();
	}

	/**
	 * Checks the presence of Export Contact Links
	 */
	public void checkAvailabiltyOfExportContact() {
		isDisplayed(exportContactButton, "Export Contact");
	}

	/**
	 * Click back to contact list
	 */
	public void clickBackToContactList() {
		isDisplayedThenActionClick(backToContactList, "Back To Contact List");
		sleep(2);
		isDisplayed(mercOrLocContactPageTitle, "Merchant Contact Page Title");
	}

	/**
	 * Check the presence of contact export option in merchant contact
	 */
	public void checkContactExportOptionInMercOrLoc() {
		if (getTagNameForLocators(contactExport).equals("a")) {
			logPass("Export Contacts link present");
		} else {
			logFail("Export Contacts link not present");
		}
	}
   public void clickOnContactExportOptionInMercOrLoc(String text) {
	   isDisplayedThenActionClick(contactExport,"Export Contact Link");
	   sleep(5);
	   verifyTheDownloadedFile(text);
   }
}
