package com.framework.testcases.AJS.SHELL;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.UtilitiesPage;
import com.framework.pages.AJS.common.IFCSHomePage;
import com.framework.pages.AJS.common.IFCSLoginPage;

public class ValidateUtilitiesTestCases extends BaseTest {

	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test( groups = { "Regression" })
	public void validateUtilitiesErrorReports(@Optional("CZ") String clientCountry,
			@Optional("SHELL") String clientName, @Optional("APA") String cardType) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  03 Utilities -  Ad-Hoc Reports - Error - Date Range Issue","SHELL Utilities Reports");
		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);

		UtilitiesPage utilitiesPage = new UtilitiesPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);

		// Calling Functions
		IFCSloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, cardType);
		IFCSHomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);
		IFCSHomePage.gotoUtiliesAndClickUtilies();
		utilitiesPage.validateAdhocReportsInUtilities("Card Group Summary");
		
		utilitiesPage.validateAdhocReportsInDateRange("IFCS_SHELL_USERNAME");
		IFCSHomePage.exitIFCS();
	}

	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test( groups = { "Regression" })
	public void validateUtilitiesAdhocReports(@Optional("RU") String clientCountry,
			@Optional("SHELL") String clientName, @Optional("APA") String cardType) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  01 Utilities - Adhoc reports", "Adhoc reports");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCShomePage = new IFCSHomePage(driver, test);
		UtilitiesPage utilitiesPage = new UtilitiesPage(driver, test);
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, cardType);
		IFCSloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");

		IFCShomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);

		IFCShomePage.gotoUtiliesAndClickUtilies();
		utilitiesPage.chooseAdhocReportsFromUtilities();

		String adhocReportForClient = utilitiesPage.getRandomTableValueForAdhocReports("IFCS_SHELL_USERNAME");

		if (!adhocReportForClient.contains("No reports added")) {
			utilitiesPage.enterDataForReportAndGenerate(adhocReportForClient, clientName + "_" + clientCountry);
		} else {
			utilitiesPage.noReportLog();
		}

		IFCShomePage.exitIFCS();

	}

	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test( groups = { "Regression" })
	public void validateNoReportDataInAdhocReports(@Optional("RU") String clientCountry,
			@Optional("SHELL") String clientName, @Optional("APA") String cardType) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  02 Utilities - Adhoc reports - No Report Data", "Adhoc reports - No Report Data");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCShomePage = new IFCSHomePage(driver, test);
		UtilitiesPage utilitiesPage = new UtilitiesPage(driver, test);
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, cardType);
		IFCSloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");

		IFCShomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);

		IFCShomePage.gotoUtiliesAndClickUtilies();
		utilitiesPage.chooseAdhocReportsFromUtilities();

		// No Report
		utilitiesPage.generateReportForClientWhichHasNoData("IFCS_SHELL_USERNAME");

		IFCShomePage.exitIFCS();

	}
}
