package com.framework.testcases.AJS.BP.Interface;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.OrderCardPage;
import com.framework.pages.AJS.common.Common;
import com.framework.pages.AJS.common.CommonInterfacePage;
import com.framework.pages.AJS.common.IFCSCommonPage;
import com.framework.pages.AJS.common.IFCSHomePage;
import com.framework.pages.AJS.common.IFCSLoginPage;
import com.framework.pages.AJS.common.InterfacePage;

public class ValidateOrderNewCardsAndInterfaceCardEmbossTestCases extends BaseTest {

	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "Smoke" ,"BusinessFlow"})
	public void ValidateToCreateNewCards(@Optional("AU") String clientCountry,
			@Optional("BP") String clientName){
		String orderedDriverCardNumber[] =new String[4] ;
		String orderedVehicleCardNumber[] = new String[4] ;
		String orderedDriverAndVehicleCardNumber[]=null;
		
		String fileType, driverCard, vehicleCard;
		
		if(clientCountry.equals("NZ")) {
			fileType = "RM_G1_0236_BPFUEL";
			driverCard ="BP Fuelcard Driver";
			vehicleCard = "BP Fuelcard Vehicle";
		} else {
			fileType = "RM_G1_0236_BPPLUS";
			driverCard ="BP Plus cards Driver";
			vehicleCard = "BP Plus cards Vehicle";
		}

		test = extent.createTest(clientName+ ":" +clientCountry+"  Verify Interface BPNZ04_Card_NZ_001_Order cards and BPNZ05_Card_NZ_002_Emboss cards via ControlM", "Order Card and Card Embossing");

		// creating object for the Pages
		IFCSLoginPage ifcsLoginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage ifcsHomePage = new IFCSHomePage(driver, test);
		OrderCardPage orderCardpage = new OrderCardPage(driver, test);
		Common common = new Common(driver, test);
		IFCSCommonPage ifcsCommonPage = new IFCSCommonPage(driver, test);
		InterfacePage interfacePage = new InterfacePage(driver,test);
		CommonInterfacePage commonInterfacePage = new CommonInterfacePage(driver, test);
	
		ifcsLoginPage.login("IFCS_URL_BP", "IFCS_BP_USERNAME", "IFCS_BP_PASSWORD");
		ifcsLoginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		ifcsHomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);
		
		// Store the customer Number 
		//String customerNumber = common.getActiveCustomerNoUsingCardType();
		
		
		  String customerNumber = common.getActiveCustomerNoUsingCardType();
		  
		  ifcsHomePage.gotoCustomerMenuCustomerDetails();
		  common.chooseCustomerNoAndSearch(customerNumber); orderedDriverCardNumber
		  =orderCardpage.orderNewCardsAndValidate(driverCard,3);
		  
		  System.out.println("Ordered Driver cards length::"+orderedDriverCardNumber.
		  length);
		  System.out.println("Ordered Driver cards "+orderedDriverCardNumber[0]);
		  System.out.println("Ordered Driver cards "+orderedDriverCardNumber[1]);
		  System.out.println("Ordered Driver cards "+orderedDriverCardNumber[2]);
		  
		  orderedVehicleCardNumber =
		  orderCardpage.orderNewCardsAndValidate(vehicleCard, 3);
		  System.out.println("Ordered Vehicle cards length::"+orderedVehicleCardNumber.
		  length);
		  System.out.println("Ordered Vehicle cards "+orderedVehicleCardNumber[0]);
		  System.out.println("Ordered Vehicle cards "+orderedVehicleCardNumber[1]);
		  System.out.println("Ordered Vehicle cards "+orderedVehicleCardNumber[2]);
		  
		  orderedDriverAndVehicleCardNumber =
		  orderCardpage.concatTwoStringArrays(orderedDriverCardNumber, 		  orderedVehicleCardNumber);
		  System.out.println("Ordered Driver & Vehicle cards length::"
		  +orderedDriverAndVehicleCardNumber.length);
		  System.out.println("Ordered Driver & Vehicle cards "
		  +orderedDriverAndVehicleCardNumber[0]);
		  System.out.println("Ordered Driver & Vehicle cards "
		  +orderedDriverAndVehicleCardNumber[1]);
		 		 		
		// Executing the Control-M Jobs
		String folderName = ifcsCommonPage.getControlMFolder(clientName, clientCountry, "BP_jobS_emboss");
		String jobsInOrder;
		if(clientCountry.equals("AU")) {
			 jobsInOrder =  ifcsCommonPage.getJobsOfFolderInOrder("BPAU_jobS_emboss");
		}
		else {
			jobsInOrder =  ifcsCommonPage.getJobsOfFolderInOrder("BP_jobS_emboss");
		}
		interfacePage.establishAndExecuteControlMJobs("ControlM_AWS_UAT","ContorlM_AWS_userName","ContorlM_AWS_password",folderName,jobsInOrder);
		String fileName = commonInterfacePage.getRecentProcessedFileNames(clientName, clientCountry,fileType);		
		System.out.println("---fileNamRecent ::"+fileName);
		//ifcsCommonPage.establishThePuttyConnection("unzip file to xml ", "PUTTY_HOST", "PUTTY_USERNAME", "PUTTY_PASSWORD", "IFCS_OUTPUTFILE_FOLDER"+Constants.FILE_SEPARATOR+fileType+File.separator+"Archive"+File.separator+"2019-05", fileName);
	
		ifcsCommonPage.establishThePuttyConnection("unzip file to xml", "PUTTY_HOST", "PUTTY_USERNAME", "PUTTY_PASSWORD", "IFCS_OUTPUTFILE_FOLDER", fileName);
		fileName = fileName.split("\\.")[0];
		String cardEmbossFilePathLocal = System.getProperty("user.home")+System.getProperty("file.separator")+"Documents" + System.getProperty("file.separator") + fileName + ".xml";
		
		ifcsCommonPage.validateIncomingXMLFile(cardEmbossFilePathLocal , orderedDriverAndVehicleCardNumber, "ifcs:EmbossingDetails", "ifcs:EmbossLine1");
		
	}
}
