package com.framework.testcases.AJS.SHELL;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.CardMaintenancePage;
import com.framework.pages.AJS.MaintainCustomerPage;
import com.framework.pages.AJS.common.Common;
import com.framework.pages.AJS.common.IFCSHomePage;
import com.framework.pages.AJS.common.IFCSLoginPage;
import com.github.javafaker.Faker;

public class ValidateMaintainCustomerTestCases extends BaseTest {
	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test( groups = { "Regression" })
	public void validateAddNewCustomerPricingProfile(@Optional("RU") String clientCountry,
			@Optional("SHELL") String clientName, @Optional("APA") String cardType) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  Maintain Customer-Customer Profiles",
				"54 Maintain Customer -  Customer Profiles -  Pricing - Add a new Profile");
		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		MaintainCustomerPage MaintainCustomer = new MaintainCustomerPage(driver, test);
		Common common = new Common(driver, test);

		IFCSloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, cardType);
		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		String customerNo = common.getCustomerNoHavingCardsUsingCardType();
		if (customerNo.equals(" ")) {
			common.logForNoDataFound(this.getClass().getSimpleName(),
					"Need to Create A Customer with Account SubStatus as Payment Pending and rerun");
		} else {
			common.chooseCustomerNoAndSearch(customerNo);
			MaintainCustomer.verifyCustomerPricingProfile();
			MaintainCustomer.popupForPricingProfiles(clientName, clientCountry);
		}
		IFCSHomePage.exitIFCS();
	}

	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test( groups = { "Regression" })
	public void validateAddContacts(@Optional("RU") String clientCountry, @Optional("SHELL") String clientName,
			@Optional("APA") String cardType) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  IFCS Contact Page", "05 Maintain Customer -  Add a Contact");
		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		Common common = new Common(driver, test);
		MaintainCustomerPage MaintainCustomer = new MaintainCustomerPage(driver, test);
		IFCSloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, cardType);
		String customerNo=common.getActiveCustomerNoUsingCardType();
		if (customerNo.equals(" ")) {
			common.logForNoDataFound(this.getClass().getSimpleName(),
					"Need to Create A Customer with Account SubStatus as Payment Pending and rerun");
		} else {
		
		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		MaintainCustomer.verifyContactsInPopup(customerNo);
		}
		IFCSHomePage.exitIFCS();
	}

	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test( groups = { "Regression" })
	public void validateMaintainCustomerAddACostCentre(@Optional("RU") String clientCountry,
			@Optional("SHELL") String clientName, @Optional("PC") String cardType) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  SHELL IFCS Add a Cost Centre", "08 Maintain Customer -  Add a Cost Centre");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		Common common = new Common(driver, test);
		MaintainCustomerPage maintainCustomerPage = new MaintainCustomerPage(driver, test);

		IFCSloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, cardType);

		// getting Active Customer No from DB/
		String customerNumberUsingCardType = common.getActiveCustomerNoUsingCardType();
		if (customerNumberUsingCardType.equals(" ")) {
			common.logForNoDataFound(this.getClass().getSimpleName(),
					"Need to Create A Customer with Card Type and rerun");
		} else {
			// Add a Cost Centre
			IFCSHomePage.gotoCustomerMenuCustomerDetails();
			common.chooseCustomerNoAndSearch(customerNumberUsingCardType);
			maintainCustomerPage.chooseCostCentre();
			String costCenterCode = Faker.instance().number().digits(4);
			maintainCustomerPage.addCostCentreAndValidate(costCenterCode);

		}
		IFCSHomePage.exitIFCS();
	}

	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test( groups = { "Regression" })
	public void orderNewCardBalancedAllowed(@Optional("RU") String clientCountry, @Optional("SHELL") String clientName,
			@Optional("PC") String cardType) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  SHELL IFCS Order new Card-Balance Allowed",
				"21 Maintain Customer -  Card Details -  Order New Card -  Balance Allowed Card");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		Common common = new Common(driver, test);
		MaintainCustomerPage maintainCustomerPage = new MaintainCustomerPage(driver, test);

		IFCSloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, cardType);

		// getting Active Customer No from DB
		String customerNumberUsingCardType = common.getActiveCustomerNoUsingCardType();
		if (customerNumberUsingCardType.equals(" ")) {
			common.logForNoDataFound(this.getClass().getSimpleName(),
					"Need to Create A Customer with Account SubStatus as Payment Pending and rerun");
		} else {

			// Order New Card With Balance Allowed
			IFCSHomePage.gotoCustomerMenuCustomerDetails();
			common.chooseCustomerNoAndSearch(customerNumberUsingCardType);
			maintainCustomerPage.enterDetailsInCardDetailsTab(clientName, clientCountry);
			maintainCustomerPage.orderNewCardWithOrNoBalanceAllowedAndValidate("Checked");
		}
		IFCSHomePage.exitIFCS();

	}

	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test( groups = { "Regression" })
	public void orderNewCardNoBalancedAllowed(@Optional("RU") String clientCountry,
			@Optional("SHELL") String clientName, @Optional("PC") String cardType) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  SHELL IFCS Order new Card-No Balance Allowed",
				"20 Maintain Customer -  Card Details -  Order New Card - Non Balance Allowed Card");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		Common common = new Common(driver, test);
		MaintainCustomerPage maintainCustomerPage = new MaintainCustomerPage(driver, test);

		IFCSloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, cardType);

		// getting Active Customer No from DB
		String customerNumberUsingCardType = common.getActiveCustomerNoUsingCardType();
		if (customerNumberUsingCardType.equals(" ")) {
			common.logForNoDataFound(this.getClass().getSimpleName(),
					"Need to Create A Customer with Account SubStatus as Payment Pending and rerun");
		} else {

			// Order New Card With No Balance Allowed
			IFCSHomePage.gotoCustomerMenuCustomerDetails();
			common.chooseCustomerNoAndSearch(customerNumberUsingCardType);
			maintainCustomerPage.enterDetailsInCardDetailsTab(clientName, clientCountry);
			maintainCustomerPage.orderNewCardWithOrNoBalanceAllowedAndValidate("Unchecked");
		}

		IFCSHomePage.exitIFCS();

	}

	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test( groups = { "Regression" })
	public void orderNewCardWithDelivaryAddress(@Optional("RU") String clientCountry,
			@Optional("SHELL") String clientName, @Optional("PC") String cardType) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  SHELL IFCS Order new Card-With Delivary Address",
				"22 Maintain Customer -  Card Details -  Order New Card -  With Delivery Address");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		Common common = new Common(driver, test);
		MaintainCustomerPage maintainCustomerPage = new MaintainCustomerPage(driver, test);

		IFCSloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, cardType);

		// getting Active Customer No from DB
		String customerNumberUsingCardType = common.getActiveCustomerNoUsingCardType();
		if (customerNumberUsingCardType.equals(" ")) {
			common.logForNoDataFound(this.getClass().getSimpleName(),
					"Need to Create A Customer with Account SubStatus as Payment Pending and rerun");
		} else {

			// Order New Card with Delivary Date
			IFCSHomePage.gotoCustomerMenuCustomerDetails();
			common.chooseCustomerNoAndSearch(customerNumberUsingCardType);
			maintainCustomerPage.enterDetailsInCardDetailsTab(clientName, clientCountry);
			maintainCustomerPage.enterDetailsInCardGroup();
			maintainCustomerPage.enterDetailsInCardDelivaryAddressTab();
			maintainCustomerPage.orderNewCardWithOrNoBalanceAllowedAndValidate("Checked");
		}
		IFCSHomePage.exitIFCS();

	}
	
	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test( groups = { "Regression" })
	public void orderNewCardValidateExpiryDate(@Optional("RU") String clientCountry,
			@Optional("SHELL") String clientName, @Optional("PC") String cardType) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  SHELL IFCS Order new Card-Validate Expiry Date",
				"19 Maintain Customer -  Card Details -  Order New Card - Invalid Expiry Date");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		Common common = new Common(driver, test);
		MaintainCustomerPage maintainCustomerPage = new MaintainCustomerPage(driver, test);

		IFCSloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, cardType);

		// getting Active Customer No from DB
		String customerNumberUsingCardType = common.getActiveCustomerNoUsingCardType();
		if (customerNumberUsingCardType.equals(" ")) {
			common.logForNoDataFound(this.getClass().getSimpleName(),
					"Need to Create A Customer with Account SubStatus as Payment Pending and rerun");
		} else {

			// Validate Expiry Date and Order New Card
			IFCSHomePage.gotoCustomerMenuCustomerDetails();
			common.chooseCustomerNoAndSearch(customerNumberUsingCardType);
			maintainCustomerPage.enterExpiryDateAndValidate("48/51/3845", "Invalid Format.",
					"Date is not a valid date.");
			maintainCustomerPage.enterExpiryDateAndValidate("31/01/2001", "Validation failed", "Must be future dated");
			maintainCustomerPage.enterExpiryDateAndValidate("31/01/2056", "Validation failed",
					"Expiry date must be less than maximum for card product");
		}
		IFCSHomePage.exitIFCS();
	}

	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test( groups = { "Regression" })
	public void customerReportingStoredReports(@Optional("RU") String clientCountry,
			@Optional("SHELL") String clientName, @Optional("PC") String cardType) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  SHELL IFCS Customer Reporting-Stored Reports",
				"75 Maintain Customer -  Customer Reporting  -  Stored Reports ");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		Common common = new Common(driver, test);
		MaintainCustomerPage maintainCustomerPage = new MaintainCustomerPage(driver, test);

		IFCSloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, cardType);

		// Getting Past Three Months Processing Date From DB
		String currentIFCSDate = common.getCurrentIFCSDateFromDB(clientName + clientCountry);
		String pastThreeMonthsProcessingDate = common.enterADateValueInStatusBeginDateField("Past", currentIFCSDate);
		System.out.println("Past Three Months" + pastThreeMonthsProcessingDate);

		// View and Export Stored Reports
		String customerNumberWithStoredReports = common.getCustomerNoWithStoredReports(pastThreeMonthsProcessingDate);
		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		common.chooseCustomerNoAndSearch(customerNumberWithStoredReports);
		maintainCustomerPage.getStoredReport();
		maintainCustomerPage.viewAndExportStoredReport();
		IFCSHomePage.exitIFCS();

	}

	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test( groups = { "Regression" })
	public void orderNewCardUpdateCardFeeProfile(@Optional("RU") String clientCountry,
			@Optional("SHELL") String clientName, @Optional("PC") String cardType) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  SHELL IFCS Order New Card-Update Card Fee Profile",
				"16 Maintain Customer -  Card Details -  Order New Card - Update Card Fee Profile");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		Common common = new Common(driver, test);
		MaintainCustomerPage maintainCustomerPage = new MaintainCustomerPage(driver, test);

		IFCSloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, cardType);

		// getting Active Customer No from DB
		String customerNumberUsingCardType = common.getActiveCustomerNoUsingCardType();
		if (customerNumberUsingCardType.equals(" ")) {
			common.logForNoDataFound(this.getClass().getSimpleName(),
					"Need to Create A Customer with Card Type and rerun");
		} else {
			// Update Card Fee Profile
			IFCSHomePage.gotoCustomerMenuCustomerDetails();
			common.chooseCustomerNoAndSearch(customerNumberUsingCardType);
			maintainCustomerPage.updateOrderNewCardCardFeeProfile1();
			common.rightClickDeletePrivateProfileAndValidate("Profile Selection", "Description");

		}
		IFCSHomePage.exitIFCS();
	}

	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test( groups = { "Regression" })
	public void orderNewCardUpdateCardControlProfile(@Optional("RU") String clientCountry,
			@Optional("SHELL") String clientName, @Optional("PC") String cardType) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  SHELL IFCS Order New Card-Update Card Control Profile",
				"15 Maintain Customer -  Card Details -  Order New Card - Update Card Control Profile");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		Common common = new Common(driver, test);
		MaintainCustomerPage maintainCustomerPage = new MaintainCustomerPage(driver, test);

		IFCSloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, cardType);

		// getting Active Customer No from DB
		String customerNumberUsingCardType = common.getActiveCustomerNoUsingCardType();
		if (customerNumberUsingCardType.equals(" ")) {
			common.logForNoDataFound(this.getClass().getSimpleName(),
					"Need to Create A Customer with Card Type and rerun");
		} else {
			// Update Card Control Profile
			IFCSHomePage.gotoCustomerMenuCustomerDetails();
			common.chooseCustomerNoAndSearch(customerNumberUsingCardType);
			maintainCustomerPage.updateOrderNewCardCardControlProfile();
			maintainCustomerPage.enterDetailsInCardControlsPopUp(clientCountry);
			int row = maintainCustomerPage.getRowNumberForSelectProfile("Profiles", "Private");
			common.rightClickAndSelectProfile("Profiles", row, "Description");
			common.rightClickDeletePrivateProfileAndValidate("Profiles", "Description");
			common.rightClickAndSelectProfile("Profiles", 0, "Description");
			common.rightClickDeletePrivateProfileAndValidate("Profiles", "Description");

		}
		IFCSHomePage.exitIFCS();
	}

//Prakalpha
	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test( groups = { "Regression" })
	public void createPrivateFeeProfileAndSetDefault(@Optional("RU") String clientCountry,
			@Optional("SHELL") String clientName, @Optional("APA") String cardType) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  SHELL IFCS Create a Private Fee Profile ",
				"59 Maintain Customer -  Customer Profiles -  CardFees -  Create a Private Fee Profile");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		Common common = new Common(driver, test);
		MaintainCustomerPage maintainCustomerPage = new MaintainCustomerPage(driver, test);

		IFCSloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, cardType);

		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		String customerNo = common.getCustomerNoHavingCardsUsingCardType();
		if (customerNo.equals(" ")) {
			common.logForNoDataFound(this.getClass().getSimpleName(), "Need to Create A Customer with Cards and rerun");
		} else {
			common.chooseCustomerNoAndSearch(customerNo);
			maintainCustomerPage.chooseMaintainCardFeesFromCustomerProfile();
			maintainCustomerPage.createCardFeePrivateProfile();

		}
		IFCSHomePage.exitIFCS();
	}

	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test( groups = { "Regression" })
	public void createNewProfileForMaintainAccountVelocityControls(@Optional("RU") String clientCountry,
			@Optional("SHELL") String clientName, @Optional("APA") String cardType) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  SHELL IFCS Create a New Profile for Maintain Account Velocity Controls",
				"68 MaintainCustomer- CustomerProfiles-Maintain Account  Velocity Controls-Create New Profile");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		Common common = new Common(driver, test);
		MaintainCustomerPage maintainCustomerPage = new MaintainCustomerPage(driver, test);

		IFCSloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, cardType);
		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		String customerNo = common.getCustomerNoHavingCardsUsingCardType();
		if (customerNo.equals(" ")) {
			common.logForNoDataFound(this.getClass().getSimpleName(), "Need to Create A Customer with Cards and rerun");
		} else {
			common.chooseCustomerNoAndSearch(customerNo);
			maintainCustomerPage.chooseAccountVelocityControlsFromCustomerProfile();
			maintainCustomerPage.createMaintainAccountVelocityControlsProfile(clientCountry);

		}
		IFCSHomePage.exitIFCS();
	}

	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test( groups = { "Regression" })
	public void createNewProfileForCardReissueProfile(@Optional("RU") String clientCountry,
			@Optional("SHELL") String clientName, @Optional("APA") String cardType) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  SHELL IFCS Create New Profile for Card Reissue Profiles",
				"65 Maintain Customer -  Card  Profiles - Card Reissue Profiles  - Create New Profile");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		Common common = new Common(driver, test);
		MaintainCustomerPage maintainCustomerPage = new MaintainCustomerPage(driver, test);

		IFCSloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, cardType);
		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		String customerNo = common.getCustomerNoHavingCardsUsingCardType();
		if (customerNo.equals(" ")) {
			common.logForNoDataFound(this.getClass().getSimpleName(), "Need to Create A Customer with Cards and rerun");
		} else {
			common.chooseCustomerNoAndSearch(customerNo);
			maintainCustomerPage.chooseCardReissueProfileFromCustomerProfile();
			maintainCustomerPage.createCardReissueProfile();

		}
		IFCSHomePage.exitIFCS();
	}

	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test( groups = { "Regression" })
	public void createNewProfileForMaintainCardControls(@Optional("RU") String clientCountry,
			@Optional("SHELL") String clientName, @Optional("APA") String cardType) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  SHELL IFCS Create New Profile for Maintain Card Controls",
				"62 Maintain Customer -  Card  Profiles - Card Controls  - Create New Profile");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		Common common = new Common(driver, test);
		MaintainCustomerPage maintainCustomerPage = new MaintainCustomerPage(driver, test);

		IFCSloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, cardType);
		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		String customerNo = common.getCustomerNoHavingCardsUsingCardType();
		if (customerNo.equals(" ")) {
			common.logForNoDataFound(this.getClass().getSimpleName(), "Need to Create A Customer with Cards and rerun");
		} else {
			common.chooseCustomerNoAndSearch(customerNo);
			maintainCustomerPage.chooseMaintainCardControlsFromCustomerProfile();
			maintainCustomerPage.createMaintainCardControlsProfile(clientCountry);

		}
		IFCSHomePage.exitIFCS();
	}

	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test( groups = { "Regression" })
	public void addNewRebateProfile(@Optional("RU") String clientCountry, @Optional("SHELL") String clientName,
			@Optional("APA") String cardType) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  SHELL IFCS Create New Profile for Maintain Card Controls",
				"57 Maintain Customer -  Customer Profiles -  Rebates -   Add New Rebate Profile");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		Common common = new Common(driver, test);
		MaintainCustomerPage maintainCustomerPage = new MaintainCustomerPage(driver, test);

		IFCSloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, cardType);
		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		String customerNo = common.getActiveCustomerNoUsingCardType();
		String currentDate = common.getCurrentIFCSDateFromDB(clientName + clientCountry);
		String expiryDate = common.enterADateValueInStatusBeginDateField("WayFuture", currentDate);
		String effDate = common.enterADateValueInStatusBeginDateField("Current", currentDate);
		if (customerNo.equals(" ")) {
			common.logForNoDataFound(this.getClass().getSimpleName(), "Need to Create A Customer with Cards and rerun");
		} else {
			common.chooseCustomerNoAndSearch(customerNo);
			//maintainCustomerPage.createRebateProfile();
			int rownum =maintainCustomerPage.getRownumberAndCreateRebateProfile();
			if (rownum != 0) {
				maintainCustomerPage.enterDetailsInRebateDetailsPopup("random", effDate, expiryDate, " ", " ", "0",
						"15", "10", " ");
				
				common.clickOkButton();
			} else {
				maintainCustomerPage.enterDetailsInRebateProfilePopup(effDate, expiryDate);
				maintainCustomerPage.enterDetailsInRebateDetailsPopup("random", effDate, expiryDate, " ", " ", "0",
						"15", "10", " ");
				
				common.clickOkButton();
			}
			common.rightClickAndOptInout("Rebate Profiles", "Private");
			common.validateCheckBoxInTable("Rebate Profiles", "Opted Out");

		}
		IFCSHomePage.exitIFCS();
	}

	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test( groups = { "Regression" })
	public void addNewHierarchy(@Optional("RU") String clientCountry, @Optional("SHELL") String clientName,
			@Optional("APA") String cardType) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  SHELL IFCS Create New Profile for Maintain Card Controls",
				"50 Maintain Customer -  Hierarchies - Hierarchy Structure - Add new Hierarchy");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		Common common = new Common(driver, test);
		MaintainCustomerPage maintainCustomerPage = new MaintainCustomerPage(driver, test);

		IFCSloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, cardType);
        String cusNo = common.getCustomerNumberWithNoHierarchy();
		if (cusNo.equals(" ")) {
			common.logForNoDataFound(this.getClass().getSimpleName(),
					"Need to Create A Customer with No Hierarchy and rerun");
		} else {
			IFCSHomePage.gotoCustomerMenuCustomerDetails();
			common.chooseCustomerNoAndSearch(cusNo);
			maintainCustomerPage.createNewHierarchy(clientName, clientCountry);

		}
		IFCSHomePage.exitIFCS();
	}
// Added by Ayub 15-02-2019

	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test( groups = { "Regression" })
	public void validateOrderNewCardScreens(@Optional("RU") String clientCountry, @Optional("SHELL") String clientName,
			@Optional("APA") String cardType) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  Verify 14 Maintain Customer -  Card Details -  Order New Card - Screens",
				"Verifying 14 Maintain Customer -  Card Details -  Order New Card - Screens");
		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);

		CardMaintenancePage cardMaintenancePage = new CardMaintenancePage(driver, test);

		IFCSloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, cardType);
		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		// Get The customer numbers form DB and search
		cardMaintenancePage.chooseCustomerNumberAndValidateOrderNewCarPage(clientName + "_" + clientCountry);
		cardMaintenancePage.validateCardDetailsPage(clientCountry);
		cardMaintenancePage.validateCardProfilePage();
		cardMaintenancePage.validateCardFeesPage();
		cardMaintenancePage.validateCardDeliveryAddressPage();
		cardMaintenancePage.validateCardEmbossingDetailsPage();
		IFCSHomePage.exitIFCS();

	}

	// Added by Ayub 18-02-2019

	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test( groups = { "Regression" })
	public void validateOrderCardMaintenanceScreens(@Optional("RU") String clientCountry,
			@Optional("SHELL") String clientName, @Optional("APA") String cardType) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  Verify Maintain Customer -  Card Details -  Card Maintenance",
				"Verifying  Maintain Customer -  Card Details -  Card Maintenance");
		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);

		CardMaintenancePage cardMaintenancePage = new CardMaintenancePage(driver, test);

		IFCSloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, cardType);
		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		// Get the card number form DB and search
		cardMaintenancePage.chooseCardNumberAndValidateOrderNewCarPage(clientName + "_" + clientCountry);
		// Validate card details
		cardMaintenancePage.validateCardDetailsPage(clientCountry);
		// Validate Profile details
		cardMaintenancePage.validateCardProfilePage();
		// Validate card Fees
		cardMaintenancePage.validateCardFeesPage();
		// Validate Card Delivery Address Page
		cardMaintenancePage.validateCardDeliveryAddressPage();
		// Validate Request Details Page
		cardMaintenancePage.validateRequestDetailsPage();
		IFCSHomePage.exitIFCS();
	}

	/**
	 * Implemented by Nithya Manikandan
	 **/

	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test( groups = { "Regression" })
	public void ValidateAddNewPrivateProfileForAccountVelocity(@Optional("RU") String clientCountry,
			@Optional("SHELL") String clientName, @Optional("APA") String cardType) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  03 Account velocity - Add a private profile for a customer",
				"Add a private profile for a customer");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		Common common = new Common(driver, test);
		MaintainCustomerPage maintainCustomerPage = new MaintainCustomerPage(driver, test);
		IFCSloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");

		IFCSHomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, cardType);
		IFCSHomePage.gotoApplicationAndClickApplicationMenu();

		common.clearForm();
		maintainCustomerPage.selectExisitingApplication();
		maintainCustomerPage.createNewCustomerProfileInApplicationAndMakeitDefault("application", clientCountry);
		IFCSHomePage.exitIFCS();

	}

	/**
	 * Implemented by Nithya Manikandan - No Application Card Control profile is
	 * available
	 **/
	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test( groups = { "Regression" })
	public void ValidateDelectAndAddNewProfileForAccountVelocity(@Optional("RU") String clientCountry,
			@Optional("SHELL") String clientName, @Optional("APA") String cardType) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  04 Account velocity - Delete and add new profile", "Delete and add new profile");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		Common common = new Common(driver, test);
		MaintainCustomerPage maintainCustomerPage = new MaintainCustomerPage(driver, test);
		IFCSloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");
		IFCSHomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, cardType);
		IFCSHomePage.gotoApplicationAndClickApplicationMenu();

		common.clearForm();
		maintainCustomerPage.selectExisitingApplication();
		maintainCustomerPage.createNewCustomerProfileInApplicationAndMakeitDefault("application", clientCountry);
		

		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		
		maintainCustomerPage.createNewCustomerProfileInApplicationAndMakeitDefault("customer", clientCountry);
		maintainCustomerPage.changeDefaultProfileAndDeletePrivateProfile();
		IFCSHomePage.exitIFCS();

	}

	/**
	 * Implemented by Nithya Manikandan
	 **/
	@Parameters({ "clientCountry", "clientName", "cardType" })
	@Test( groups = { "Regression" })
	public void ValidateAddNewPrivateProfile(@Optional("RU") String clientCountry, @Optional("SHELL") String clientName,
			@Optional("APA") String cardType) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  06 Account velocity - New private profile different from default profile",
				"New private profile different from default profile");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		MaintainCustomerPage maintainCustomerPage = new MaintainCustomerPage(driver, test);
		Common common = new Common(driver, test);
		MaintainCustomerPage customerPage = new MaintainCustomerPage(driver, test);

		IFCSloginPage.login("IFCS_URL_SHELL", "IFCS_SHELL_USERNAME", "IFCS_SHELL_PASSWORD");

		IFCSHomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, cardType);
		// Get Customer having card from DB with Client
		String customerWithCards = customerPage.getCustomerNoHavingCardsUsingCardType();
		if (customerWithCards.equals(" ")) {
			common.logForNoDataFound(this.getClass().getSimpleName(), "Need to Create A Customer with Cards and rerun");
		} else {
			IFCSHomePage.gotoCustomerMenuCustomerDetails();

		
		common.chooseCustomerNoAndSearch(customerWithCards);

		maintainCustomerPage.createNewCustomerProfileInApplicationAndMakeitDefault("customer", clientCountry);

		// For rerunning purpose
		maintainCustomerPage.changeDefaultProfileAndDeletePrivateProfile();

		}
		IFCSHomePage.exitIFCS();

	}

}
