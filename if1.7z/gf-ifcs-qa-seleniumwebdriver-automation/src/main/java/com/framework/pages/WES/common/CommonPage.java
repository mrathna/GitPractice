package com.framework.pages.WES.common;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.ExtentTest;
import com.framework.basepage.BasePage;
import com.framework.repo.Locator_WES;
import com.framework.util.Constants;
import com.framework.util.PropUtils;
import com.framework.util.SikuliUtils;

public class CommonPage extends BasePage {

	@FindBy(xpath = Locator_WES.CREDIT_STATUS)
	public WebElement credit_Status;

	@FindBy(xpath = Locator_WES.REF_CREDIT_STATUS)
	public WebElement ref_CreditStatus;

	@FindBy(xpath = Locator_WES.CREDIT_APPLICATION_STATUS)
	public WebElement application_Status;

	@FindBy(xpath = Locator_WES.CREDIT_GET_REF)
	public WebElement credit_Ref;

	@FindBy(xpath = Locator_WES.MAINTENANCE)
	public WebElement maintenance;

	@FindBy(xpath = Locator_WES.MAINTENANCE_CALLSHEET)
	public WebElement callSheet;

	@FindBy(xpath = Locator_WES.MAINTENANCE_CALLSHEET_LIST_CAMPAIGN)
	public WebElement maintenanceCallSheetListCampaign;

	@FindBy(xpath = Locator_WES.CUSTOMER_CAMPAIGN_LIST)
	public WebElement customerCampaignList;

	public CommonPage(WebDriver driver, ExtentTest test) {
		super(driver, test);
		// TODO Auto-generated constructor stub
		PageFactory.initElements(driver, this);
	}

	/*
	 * Prakalpha -->22/07/2019 validate the Credit Status in the Page Credit Checks
	 */
	public void validateCreditStatusChanged(String refNo, String expectedStatus, String pageTitle) {
		verifyTitle("Cruise");
		isDisplayedThenClick(credit_Status, "Credit Status");
		if ("tabSelected".equalsIgnoreCase(credit_Status.getAttribute("class"))) {
			driver.switchTo().frame("creditNewFrame");
			isDisplayedThenEnterText(ref_CreditStatus, refNo + "RefNo Row", refNo);
			sleep(2);
			boolean tablePresence = waitToCheckElementIsDisplayed(
					By.xpath("//table[@id='homeCreditChecksNewGrid']/tbody/tr[2]"), 10);
			System.out.println("tablePresence : " + tablePresence);
			if (tablePresence) {

				String actualrefNo = credit_Ref.getText();
				if (refNo.equals(actualrefNo)) {
					logPass(actualrefNo + " expected Customer is clicked");
				} else {
					logFail(actualrefNo + " is not expected Customer");
				}
				String actualApplicationStatus = application_Status.getText();
				if (expectedStatus.equalsIgnoreCase(actualApplicationStatus)) {
					logPass(actualApplicationStatus + " Status Changed");
				} else {
					logFail(actualApplicationStatus + " is not expected Status");
				}
				// Taking ScreenShots
				takeScreenshot();
				sleep(2);
				Click(credit_Ref, "1st row is Clicked");
				sleep(10);
				verifyTitle(pageTitle);

			} else {
				logFail("No data's Found in a table");
			}
		} else {
			logFail("Expected Tab is not Selected");
		}
	}

	public void uploadOrSaveLatestCruiseFile(String fileName) {
		try {
			String downloadedFilePath;

			if (fileName.contains("ApplicationCreation")) {
				fileName = fileName + ".pdf";
				downloadedFilePath = System.getProperty("user.home") + "\\Downloads\\";
				System.out.println("The Downloaded File Path is" + downloadedFilePath);
				SikuliUtils.waitUntilObjectisLoaded(10.0);
				SikuliUtils.clearText(Constants.FILEName_INPUTPATH_PDF);
				SikuliUtils.waitUntilObjectisLoaded(10.0);
				SikuliUtils.clearText(Constants.FILEName_INPUTPATH_PDF);
				SikuliUtils.waitUntilObjectisLoaded(10.0);
				SikuliUtils.enterText(Constants.FILEName_INPUTPATH_PDF, downloadedFilePath + fileName);
				SikuliUtils.waitUntilObjectisLoaded(6.0);
				SikuliUtils.clickElement(Constants.SAVEICON);
				SikuliUtils.waitUntilObjectisLoaded(5.0);
			} else {
				String downloadedFileName = getLatestDownloadedFileFromDir(fileName).getName();
				System.out.println("The Downloaded File Name is" + downloadedFileName);
				downloadedFilePath = System.getProperty("user.home") + "\\Downloads\\";
				System.out.println("The Downloaded File Path is" + downloadedFilePath);
				SikuliUtils.enterText(Constants.FILEName_INPUTPATH, downloadedFilePath + downloadedFileName);
				SikuliUtils.clickElement(Constants.OPEN);
			}
			sleep(10);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/*
	 * Ayub DB query
	 */
	public void getTheNewlyCreatedCustomerNo(String customerName) {
		String customerNumber = "select CUSTOMER_NO from M_CUSTOMERS where name = '" + customerName
				+ "' order by CUSTOMER_NO desc";
		String customerNo = connectDBAndGetValue(customerNumber,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		System.out.println("********************" + customerNo);
		logInfo("customerNo : " + customerNo);
	}

	/*
	 * Sasi To get card numbers for the given customer
	 */
	public void getTheNewlyCreatedCardNo(String customerName, int n) {
		String customerMid = "select CUSTOMER_MID from M_CUSTOMERS where name = '" + customerName
				+ "' order by CUSTOMER_NO desc";
		String cusMid = connectDBAndGetValue(customerMid, PropUtils.getPropValue(configProp, "sqlODSServerName"));
		String cardNoQuery = "select card_no from cards where customer_mid = " + cusMid;
		for (int i = 0; i < n + 1; i++) {
			String cardNos = connectDBAndGetDBRowValue(cardNoQuery,
					PropUtils.getPropValue(configProp, "sqlODSServerName"), i);
			logInfo("CardNo --> " + cardNos);
			System.out.println("********************" + cardNos);
		}

	}

	/*
	 * Sasi To get card numbers for the given customer
	 */
	public String getCardNoByEmbossName(String customerNo, String embossName) {
		sleep(5);
		String cardNoQuery = "select c.card_no, c.EMBOSS_LINE_4 from cards c where c.CUSTOMER_MID in (select customer_mid from M_CUSTOMERS where CUSTOMER_NO='"
				+ customerNo + "') and" + " c.EMBOSS_LINE_4 = '" + embossName + "' order by c.CARD_NO desc";

		String cardNos = connectDBAndGetValue(cardNoQuery, PropUtils.getPropValue(configProp, "sqlODSServerName"));
		logInfo("CardNo --> " + cardNos);
		System.out.println("********************" + cardNos);
		return cardNos;
	}

	/*
	 * Sasi To get card numbers for the given customer
	 */
	public String getCustomerNo(String clientName, String clientCountry) {
		sleep(5);
		String cusNoQuery;
		if (clientCountry.equals("UK")) {
			cusNoQuery = "select CUSTOMER_NO from M_CUSTOMERS where CUSTOMER_MID in (select customer_mid from CUSTOMER_CARD_PRODUCTS"
					+ " where CARD_OFFER_OID in (select CARD_OFFER_OID from card_offers where CLIENT_MID=(select CLIENT_MID from m_clients where name='"
					+ clientName + " " + clientCountry + "' ) and"
					+ " DESCRIPTION in ('Esso','UK Fuels','EDC')) and IS_CARD_REQ_VALIDATION_RULE = 'N' "
					+ " group by customer_mid having count(*) = 3) order by customer_mid";
		} else {
			cusNoQuery = "select CUSTOMER_NO from M_CUSTOMERS where CUSTOMER_MID in (select customer_mid from CUSTOMER_CARD_PRODUCTS"
					+ " where CARD_OFFER_OID in (select CARD_OFFER_OID from card_offers where CLIENT_MID=(select CLIENT_MID from m_clients where short_name='"
					+ clientName + " " + clientCountry + "' ) and"
					+ " DESCRIPTION in ('Esso','EDC')) and IS_CARD_REQ_VALIDATION_RULE = 'N' "
					+ " group by customer_mid having count(*) = 2) order by customer_mid";
		}

		String cusNo = connectDBAndGetValue(cusNoQuery, PropUtils.getPropValue(configProp, "sqlODSServerName"));
		logInfo("cusNo --> " + cusNo);
		System.out.println("********************" + cusNo);
		return cusNo;
	}

	/*
	 * Sasi To get City name for the given customer
	 */
	public String getCityNameForCustomer(String customerNo) {
		sleep(5);
		String cityNameQuery = "select SUBURB from ADDRESSES where ADDRESS_OID=(select mc.STREET_ADDRESS_OID from M_CUSTOMERS mc where mc.CUSTOMER_NO='"
				+ customerNo + "')";

		String cityname = connectDBAndGetValue(cityNameQuery, PropUtils.getPropValue(configProp, "sqlODSServerName"));
		logInfo("ActualCityName --> " + cityname);
		System.out.println("********************" + cityname);
		return cityname;
	}

	
	/*  public void MyPropertyFileStore(String fileName,Map<String,String> cardNos) {
	  
	  String FILE_SEPARATOR = System.getProperty("file.separator");
	  
	  // Getting the current Project Directory 
	  String USER_DIR =System.getProperty("user.dir");
	  
	  // Folders names
	  String RESOURCES_FOLDER_NAME = "Resources"; 
	  String CONFIG_FOLDER_NAME = "Configuration"; String RESOURCES_DIR = USER_DIR +
	  FILE_SEPARATOR + RESOURCES_FOLDER_NAME + FILE_SEPARATOR; String CONFIG_DIR =
	  RESOURCES_DIR + CONFIG_FOLDER_NAME + FILE_SEPARATOR;
	  
	  OutputStream fos = null; 
	  Properties prop = new Properties();
	  
	  try {
		  fos = new FileOutputStream(CONFIG_DIR+fileName);
		  prop.putAll(cardNos);
	  prop.store(fos, "Dynamic Property File");
	  } catch (IOException e) {
	  e.printStackTrace(); }
	  
	  }*/
	 

}
