package com.framework.pages.AJS.common;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

import com.aventstack.extentreports.ExtentTest;
import com.framework.basepage.BasePage;
import com.framework.repo.Locator_IFCS;
import com.framework.util.PropUtils;
import com.framework.util.SeleniumWrappers;

public class IFCSHomePage extends BasePage {

	@FindBy(xpath = Locator_IFCS.RESTARTBUTTON)
	public WebElement restartButton;

	@FindBy(xpath = Locator_IFCS.ADMIN_MENU)
	public WebElement adminMenu;

	@FindBy(xpath = Locator_IFCS.CLIENT_SUBMENU)
	public WebElement clientMenu;

	@FindBy(xpath = Locator_IFCS.ADMIN_BATCH)
	public WebElement BatchMenu;

	@FindBy(xpath = Locator_IFCS.INTERFACES)
	public WebElement interfaces;

	@FindBy(xpath = Locator_IFCS.BATCH_SCHEDULING)
	public WebElement Scheduling;

	@FindBy(xpath = Locator_IFCS.TRANSACTIONS_MENU)
	public WebElement transactionsMenu;

	@FindBy(xpath = Locator_IFCS.MANAGE_TRANSACTION_SUBMENU)
	public WebElement manageTransactionSubMenu;

	@FindBy(xpath = Locator_IFCS.CUSTOMER_MENU)
	public WebElement customerMenu;

	@FindBy(xpath = Locator_IFCS.CUSTOMERS_DETAILS_SUBMENU)
	public WebElement customerDetailsSubMenu;
	@FindBy(xpath = Locator_IFCS.APPLICATION_MENU)
	public WebElement applicationMenu;
	@FindBy(xpath = Locator_IFCS.APPLICATION_SUBMENU)
	public WebElement applicationsSubMenu;

	@FindBy(xpath = Locator_IFCS.CLIENTCONFIG)
	public WebElement clientConfig;
	@FindBy(xpath = Locator_IFCS.MAINTAIN_APPLICATION_LEFT_PANEL)
	public WebElement maintainApplicationLeftPanel;
	@FindBy(xpath = Locator_IFCS.MAINTAIN_APPLICATION_MAIN_FRAME)
	public WebElement maintainApplicationMainFrame;
	@FindBy(xpath = Locator_IFCS.MAINTAIN_MERCHANTS_IN_LEFT_PANEL)
	public WebElement maintainMerchantsInLeftPanel;
	@FindBy(xpath = Locator_IFCS.MAINTAIN_MERCHANTS_IN_MAIN_FRAME)
	public WebElement maintainMerchantsInMainFrame;
	@FindBy(xpath = Locator_IFCS.MAINTAIN_CUSTOMER_IN_LEFTPANEL)
	public WebElement maintainCustomerInLeftPanel;
	@FindBy(xpath = Locator_IFCS.MAINTAIN_CUSTOMER_IN_MAIN_FRAME)
	public WebElement maintainCustomerInMainFrame;
	@FindBy(xpath = Locator_IFCS.CLIENT_TRANSACTION_MAIN_FRAME)
	public WebElement clientTransactionInMainFrame;
	@FindBy(xpath = Locator_IFCS.CLIENT_TRANSACTION_LEFT_PANEL)
	public WebElement clientTransactionInLeftPanel;
	@FindBy(xpath = Locator_IFCS.MAINTAIN_ACCOUNTS_IN_LEFT_PANEL)
	public WebElement maintainAccountsInLeftPanel;
	@FindBy(xpath = Locator_IFCS.MAINTAIN_ACCOUNTS_IN_MAIN_FRAME)
	public WebElement maintainAccountsInMainFrame;
	@FindBy(xpath = Locator_IFCS.AD_HOC_REPORTS_LEFT_PANEL)
	public WebElement adhocReportsLeftPanel;
	@FindBy(xpath = Locator_IFCS.AD_HOC_REPORTS__MAIN_FRAME)
	public WebElement adhocReportsMainFrame;

	@FindBy(xpath = Locator_IFCS.CUSTOMER_MAINTENANCE)
	public WebElement customerMaintenance;

	@FindBy(xpath = Locator_IFCS.SEARCH_MENU)
	public WebElement searchMenu;

	@FindBy(xpath = Locator_IFCS.TRANSACTION_SUBMENU)
	public WebElement transactionSubMenu;

	@FindBy(xpath = Locator_IFCS.FILE_MENU)
	public WebElement fileMenu;

	@FindBy(xpath = Locator_IFCS.EXIT_SUBMENU)
	public WebElement exitSubMenu;

	@FindBy(xpath = Locator_IFCS.SYSTEM_MENU)
	public WebElement systemMenu;

	@FindBy(xpath = Locator_IFCS.COUNTRIES)
	public WebElement countries;

	@FindBy(xpath = Locator_IFCS.UTILITIES_MENU)
	public WebElement utilitiesMenu;

	@FindBy(xpath = Locator_IFCS.ACCOUNT_MENU)
	public WebElement accountsMenu;
	@FindBy(xpath = Locator_IFCS.ACCOUNT_DETAILS_SUBMENU)
	public WebElement accountDetailsSubMenu;
	@FindBy(xpath = Locator_IFCS.UTILITIES_SUBMENU)
	public WebElement utilitiesSubMenu;

	@FindBy(xpath = Locator_IFCS.MERCHANTS_MENU)
	public WebElement merchantsMenu;

	@FindBy(xpath = Locator_IFCS.MERCHANT_DETAILS_SUBMENU)
	public WebElement merchantDetailsSubMenu;
	@FindBy(xpath = Locator_IFCS.SEARCH_CARDS_SUBMENU)
	public WebElement cardsSubMenu;

	@FindBy(xpath = Locator_IFCS.SEARCH_VEHICLES_SUBMENU)
	public WebElement vehiclesSubMenu;

	@FindBy(xpath = Locator_IFCS.SEARCH_DRIVERS_SUBMENU)
	public WebElement driversSubMenu;

	@FindBy(xpath = Locator_IFCS.SEARCH_DRIVERINVOICES_SUBMENU)
	public WebElement driverInvoicesSubMenu;

	@FindBy(xpath = Locator_IFCS.IFCS_BACK_BUTTON)
	public WebElement backIcon;

	@FindBy(xpath = Locator_IFCS.CLIENTGROUP_SUBMENU)
	public WebElement clientGroupMenu;

	@FindBy(xpath = Locator_IFCS.USER_LIMITES)
	public WebElement userLimites;

	@FindBy(xpath = Locator_IFCS.INTERNET_USER_LOGON_ID)
	public WebElement internetUserLogonId;

	@FindBy(xpath = Locator_IFCS.INTERNET_USER_ACCESS_MEMBER_NO)
	public WebElement internetUserMemberNo;

	@FindBy(xpath = Locator_IFCS.BOTTOM_LEFT_TEXT)
	public WebElement bottomLeftText;
	@FindBy(xpath = Locator_IFCS.USER_LIMITS_TABLE)
	public List<WebElement> userLimitsTable;

	@FindBy(xpath = Locator_IFCS.CLIENT_CONFIG_MAIN_FRAME)
	public WebElement clientConfigInMainFrame;
	@FindBy(xpath = Locator_IFCS.APPLICATION_APPLICATIONS)
	public WebElement applicationsearch;

	@FindBy(xpath = Locator_IFCS.Customer_Customer)
	public WebElement customersearch;

	@FindBy(xpath = Locator_IFCS.MANUAL_PAYMENT_LEFT_PANEL)
	public WebElement MANUAL_PAYMENT_LEFT_PANEL;
	
	@FindBy(xpath = Locator_IFCS.PAYMENT_LEFT_PANEL)
	public WebElement PAYMENT_LEFT_PANEL;
	
	@FindBy(css = Locator_IFCS.APPLICATION_TYPE_PREPAY)
	public WebElement applicationTypePrepay;

	@FindBy(xpath = Locator_IFCS.EXTERNALREF_NUM_APP)
	public WebElement externalrefnumapplication;

	@FindBy(xpath = Locator_IFCS.TORCH_SEARCH_LIST)
	public WebElement torchsearchicon;
	@FindBy(xpath = Locator_IFCS.APPLICATION_SEARCH_FIRST)
	public WebElement applicationsearchfirst;

	@FindBy(xpath = Locator_IFCS.ACCOUNTTYPE_SELECTED)
	public WebElement accountTypeSelected;

	@FindBy(css = Locator_IFCS.CARDPROGRAMS_BPPREPAID_CARDS)
	public WebElement cardProgramsBPPrepaidCards;

	@FindBy(xpath = Locator_IFCS.LOGON_ID_TEXT_BOX)
	public WebElement logonIdTextBox;

	@FindBy(xpath = Locator_IFCS.SEARCH_TORCH_USERS)
	public WebElement searchTorchUsers;

	@FindBy(xpath = Locator_IFCS.CARDS_TABLE_HEADER)
	public List<WebElement> cardsTableHeader;

	public IFCSHomePage(WebDriver driver, ExtentTest test) {
		super(driver, test);

		PageFactory.initElements(new AjaxElementLocatorFactory(driver, 15), this);

	}

	public void validateMenusPresenceInTheBody() {
		verifyTextPresenceNumOfTimes("Applications", 1, false);
		verifyTextPresenceNumOfTimes("Customers", 1, false);
		verifyTextPresenceNumOfTimes("Accounts", 1, false);
		verifyTextPresenceNumOfTimes("Transactions", 1, false);
		verifyTextPresenceNumOfTimes("Merchants/Loc", 1, false);
		verifyTextPresenceNumOfTimes("Search", 1, false);
		verifyTextPresenceNumOfTimes("Admin", 1, false);
	}

	public void validateFooter(String user) {
		verifyTextPresenceNumOfTimes(PropUtils.getPropValue(configProp, user), 1, false);
		verifyTextPresenceNumOfTimes("2018", 1, true);

	}

	public void gotoCustomerMenuCustomerDetails() {
		isDisplayedThenClick(customerMenu, "Customer is clicked");
		isDisplayedThenClick(customerDetailsSubMenu, "Customer Details is clicked");
		checkElementPresenceAndClick(maintainCustomerInLeftPanel, "Maintain Customer");
		validateIsPageDisplayed(maintainCustomerInLeftPanel, maintainCustomerInMainFrame);
	}

	public void exitIFCS() {
		sleep(5);
		isDisplayedThenClick(fileMenu, fileMenu.getText());
		sleep(5);
		isDisplayedThenClick(exitSubMenu, exitSubMenu.getText());
		sleep(5);
		checkTextInPageAndValidate("Session closed", 30);
		checkTextInPageAndValidate("To start a new session, click on Restart", 30);
		isDisplayed(restartButton, "Restart button");
	}

	public void exitIFCSwithoutValidation() {
		isDisplayedThenClick(fileMenu, fileMenu.getText());
		sleep(5);
		isDisplayedThenClick(exitSubMenu, exitSubMenu.getText());
		sleep(5);
	}

	public void validateHomePageImageIconsOrBrokenOrNot() {

		verifyimageActive();
	}

	public void VerifyTheHeadersPresence() {

		List<WebElement> headerElements = driver.findElements(By.xpath("//div[u and @class='htmlString']"));

		if (headerElements.size() > 0) {
			for (WebElement headerElement : headerElements) {
				isDisplayed(headerElement, headerElement.getText());
			}
		}

		else {
			logFail("Headers are not present");
		}

	}

	public void clickSystemInAdminAndVerify() {

		isDisplayedThenClick(adminMenu, adminMenu.getText());
		sleep(5);
		isDisplayedThenClick(systemMenu, systemMenu.getText());
		sleep(5);
		verifyTextPresenceNumOfTimes("System", 2, false);
		// verifyTextPresenceNumOfTimes("System Tables", 1,false);
		verifyTextPresenceNumOfTimes("Products", 1, false);
		// verifyTextPresenceNumOfTimes("Tax Codes", 1,false);
		verifyTextPresenceNumOfTimes("Customers", 1, false);
		verifyTextPresenceNumOfTimes("Collections", 1, false);
		verifyTextPresenceNumOfTimes("Transactions", 1, false);
		// verifyTextPresenceNumOfTimes("Integratioin Engine", 1,false);
		// verifyTextPresenceNumOfTimes("System Settings", 1,false);
		// verifyTextPresenceNumOfTimes("Stored Reports", 1,false);
		// verifyTextPresenceNumOfTimes("Audit Details", 1,false);
		verifyTextPresenceNumOfTimes("Security", 1, false);
	}

	public void clickCountriesAndVerify() {

		isDisplayedThenClick(countries, countries.getText());
		sleep(5);
		HashSet<String> headers = SeleniumWrappers
				.getAllTableHeaders(driver.findElements(By.xpath("//div[contains(@id,'JTableHeader')]")));
		System.out.println("---- All table Headers ---- " + headers.size());
		SeleniumWrappers.setCellValue(driver.findElements(By.xpath("//div[contains(@id,'FALTableCellEditor')]")));
		int totalCells = SeleniumWrappers
				.getTotalNumberOfCells(driver.findElements(By.xpath("//div[contains(@id,'FALTableCellEditor')]")));

		System.out.println("---- Total Cells ---- " + totalCells);

		System.out.println("---- Cell Value 10, 3 ---- " + SeleniumWrappers.getTableCellValue(10, 3));

		System.out.println("---- Cell Value 1, 3 ---- " + SeleniumWrappers.getTableCellValue(1, 3));

		System.out.println("---- Cell Value 1, 3 ---- " + SeleniumWrappers.getTableCellValue(1, 2));

		System.out.println("---- Cell Value 1, 3 ---- " + SeleniumWrappers.getTableCellValue(0, 0));

		System.out.println("---- Cell Value 1, 3 ---- " + SeleniumWrappers.getTableCellValue(0, 1));

		System.out.println("---- Cell Value 1, 3 ---- " + SeleniumWrappers.getTableCellValue(0, 2));

		System.out.println("---- Cell Value 1, 3 ---- " + SeleniumWrappers.getTableCellValue(0, 3));

		System.out.println("---- Cell Value 0, 4 ---- " + SeleniumWrappers.getTableCellValue(0, 4));

	}

	public void gotoAdminMenuAndChooseClient(String clientName) {
		Common common = new Common(driver, test);
		logInfo("Client on context::" + PropUtils.getPropValue(configProp, clientName));
		String clientNameInProp;
		isDisplayedThenClick(adminMenu, "AdminMenu");
		isDisplayedThenClick(clientMenu, "ClientSubMenu");
		common.searchTorch();
		clientNameInProp = PropUtils.getPropValue(configProp, clientName).trim().toString();
		chooseOptionFromDropdown("Client", clientNameInProp);
		sleep(3);
		common.findRecordTorch();
		sleep(5);
		common.closeFindRecordTorch();
		sleep(3);
	}

	public void gotoAdminAndClickClient() {
		isDisplayedThenClick(adminMenu, "AdminMenu");
		isDisplayedThenClick(clientMenu, "ClientSubMenu");
		checkElementPresenceAndClick(clientTransactionInLeftPanel, "Client Config");
		validateIsPageDisplayed(clientTransactionInLeftPanel, clientConfigInMainFrame);
	}

	public void gotoTansactionsAndClickManageTransaction() {
		isDisplayedThenClick(transactionsMenu, "Transactions Menu");
		isDisplayedThenClick(manageTransactionSubMenu, "Manage Transaction SubMenu");
		sleep(5);
	}

	public void gotoTransactionAndClickManageTransaction() {
		sleep(5);
		isDisplayedThenClick(transactionsMenu, "Transactions Menu");
		sleep(5);
		isDisplayedThenClick(manageTransactionSubMenu, "Manage Transaction SubMenu");
		checkElementPresenceAndClick(clientTransactionInLeftPanel, "Client Transactions");
		validateIsPageDisplayed(clientTransactionInLeftPanel, clientTransactionInMainFrame);
	}

	public void gotoSearchAndClickTransaction() {
		isDisplayedThenClick(searchMenu, "Search");
		isDisplayedThenClick(transactionSubMenu, "Transactions");
	}

	public void gotoUtiliesAndClickUtilies() {
		isDisplayedThenClick(utilitiesMenu, "Utilities Menu");
		isDisplayedThenClick(utilitiesSubMenu, "Utilities SubMenu");
		checkElementPresenceAndClick(adhocReportsLeftPanel, "AdHoc Reports");
		validateIsPageDisplayed(adhocReportsLeftPanel, adhocReportsMainFrame);

	}

	public void gotoMerchantAndClickMerchantDetails() {
		sleep(5);
		isDisplayedThenClick(merchantsMenu, "Merchants Menu");
		isDisplayedThenClick(merchantDetailsSubMenu, "Merchant Details SubMenu");
		checkElementPresenceAndClick(maintainMerchantsInLeftPanel, "Maintain Merchant");
		validateIsPageDisplayed(maintainMerchantsInLeftPanel, maintainMerchantsInMainFrame);
	}

	public void gotoApplicationAndClickApplicationMenu() {
		isDisplayedThenClick(applicationMenu, "Application Menu ");
		isDisplayedThenClick(applicationsSubMenu, "Application SubMenu");
		sleep(3);
		checkElementPresenceAndClick(maintainApplicationLeftPanel, "Maintain Application");
		sleep(3);
		validateIsPageDisplayed(maintainApplicationLeftPanel, maintainApplicationMainFrame);

	}

	public void verifyTheHeadersPresence() {

		List<WebElement> headerElements = driver.findElements(By.xpath("//div[u and @class='htmlString']"));
		if (headerElements.size() > 0) {
			for (WebElement headerElement : headerElements) {
				isDisplayed(headerElement, headerElement.getText());
			}
		} else {
			logFail("Headers are not present");
		}
	}

	public void gotoSearchAndClickCards() {
		isDisplayedThenClick(searchMenu, "Search");
		isDisplayedThenClick(cardsSubMenu, "Cards");
	}

	public void gotoAccountAndClickAccountDetails() {
		sleep(1);
		isDisplayedThenClick(accountsMenu, "Accounts Menu");
		isDisplayedThenClick(accountDetailsSubMenu, "Account Details SubMenu");
		checkElementPresenceAndClick(maintainAccountsInLeftPanel, " Maintain Account");
		validateIsPageDisplayed(maintainAccountsInLeftPanel, maintainAccountsInMainFrame);
	}

	public void gotoSearchAndClickVehicles() {
		isDisplayedThenClick(searchMenu, "Search");
		isDisplayedThenClick(vehiclesSubMenu, "Vehicles");
	}

	public void gotoSearchAndClickDrivers() {
		isDisplayedThenClick(searchMenu, "Search");
		isDisplayedThenClick(driversSubMenu, "Drivers");
	}

	public void gotoSearchAndClickTransactions() {
		isDisplayedThenClick(searchMenu, "Search");
		isDisplayedThenClick(transactionSubMenu, "Transactions");
	}

	public void gotoSearchAndClickCustomerInvoices() {
		isDisplayedThenClick(searchMenu, "Search");
		isDisplayedThenClick(driverInvoicesSubMenu, "Driver Invoices");
	}

	public void validateIsPageDisplayed(WebElement leftPanel, WebElement mainFrame) {
		if (getText(leftPanel).equals(getText(mainFrame))) {
			logPass("Expected Page is Displayed");
		} else {
			logFail("Expected Page is not displayed");
		}
	}

	public void clickBackIcon() {
		isDisplayedThenClick(backIcon, "Back Icon");
		sleep(10);
	}

	// Mamtha

	public void gotoApplicationsMenuAndChooseClient(String clientName) {
		Common common = new Common(driver, test);
		String clientNameInProp;
		chooseSubMenuFromLeftPanel("Applications", "");
		common.searchTorch();
		sleep(2);
		clientNameInProp = PropUtils.getPropValue(configProp, clientName).trim().toString();
		System.out.println("Client Name:" + clientNameInProp);
		chooseOptionFromDropdown("Client", clientNameInProp);
		sleep(3);
		common.findRecordTorch();
		sleep(5);
		common.closeFindRecordTorch();
		sleep(3);

	}


/*
	 * Added by Davu - 30/4/2020
	 * 
	 */
	
public void gotoCustomersMenuAndChooseClient(String clientName) {
	Common common=new Common(driver,test);
	String clientNameInProp;
	chooseSubMenuFromLeftPanel("Customers","Customer Details");	
	common.searchTorch();
	sleep(2);
	clientNameInProp = PropUtils.getPropValue(configProp, clientName).trim().toString();
	
	System.out.println("Client Name:"+clientNameInProp);
	chooseOptionFromDropdown("Client", clientNameInProp);
	sleep(3);
	common.findRecordTorch();
	sleep(5);
	common.closeFindRecordTorch();
	sleep(3);
	
}
	// Added by Ayub 2/4/2019

	public void gotoAdminMenuAndChooseClientGroup() {
		isDisplayedThenClick(adminMenu, "AdminMenu");
		isDisplayedThenClick(clientGroupMenu, "ClientGroupSubMenu");
		sleep(3);
	}

	// Added by Ayub 2/4/2019
	public void enterUserLimitsAndValidate(String clientName) {
		Common common = new Common(driver, test);
		// Get User Override rows and delete
		common.detailSearch();
		SeleniumWrappers.setCellValue(userLimitsTable);
		validateUserLimitCheckBoxInTableAndRemoveOverridenData("User Limits", "User Override");
		String clientNameInProp;
		rightClick(userLimites);
		common.addIteminPopup();
		clientNameInProp = PropUtils.getPropValue(configProp, clientName).trim().toString();
		chooseOptionFromDropdown("Client", clientNameInProp);
		common.clickOkButton();
		sleep(3);
		verifyText(bottomLeftText, "Record read OK");
		sleep(3);
		common.clickSaveIcon();
		sleep(2);
		verifyText(bottomLeftText, "Record saved OK");
	}

	// Added by Nithya - 12/04
	public int validateUserLimitCheckBoxInTableAndRemoveOverridenData(String seperatorLabelName,
			String tableHeaderName) {
		Common common = new Common(driver, test);
		int row = -1;
		String seperator = " ";
		try {
			seperator = splitStringAndGenerateXpath(seperatorLabelName);
			List<WebElement> tableHeaders = driver.findElements(By.xpath("//div[@class='JFALSeparator']//div["
					+ seperator
					+ "]/preceding::div[@class='JFALCompControlPanel'][1]//div[@class='JViewport']/div[@class='JTableHeader']//div[@class='HeaderRenderer']"));
			int colIndex = SeleniumWrappers.getColumnNoForColumnHeader(tableHeaderName, tableHeaders);
			System.out.println("ColIndex--->" + colIndex);
			List<WebElement> list = driver.findElements(By.xpath(
					"//div[contains(@class,'General') and contains(@class,'Viewer')]/div[contains(@class,'General')]//div[starts-with(@class,'FALTableCellEditor_StrikeThru')]"));
			SeleniumWrappers.setCellValue(list);
			int size = SeleniumWrappers.getTotalNumberOfRows(list, driver);
			for (row = 0; row < size; row++) {
				try {
					/*
					 * WebElement element =
					 * driver.findElement(By.xpath("//div[@class='JFALSeparator']//div[" + seperator
					 * +
					 * "]/preceding::div[@class='JFALCompControlPanel'][1]//div[@class='FALTableCellEditor_StrikeThruCheckBox enabled'][contains(@id,'"
					 * + row + "_" + colIndex + "')]/div[8]"));
					 */
					Click(driver.findElement(By.xpath("//input[contains(@id,'_" + row + "_1')]")), "Select Row " + row);
					rightClick(driver.findElement(By.xpath("//input[contains(@id,'_" + row + "_1')]")));
					common.deleteIteminPopup();
					common.clickSaveIcon();
					break;
				} catch (Exception ex) {
					logInfo("Expected Checkbox not selected on row:" + ex);
				}
			}
		} catch (Exception e) {
			logFail(e.getMessage());
		}
		return row;
	}
	
	/* 
	 * Updated by Davu - 01/05/2020 
	 */
	
	public void createNewOlsMerchantReadOnlyUser(String name, String clientName,String merchantNo) {
		Common common=new Common(driver,test);
		String clientNameInProp;
		rightClick(internetUserLogonId);
		common.addIteminPopup();
		validatePopupHeaderText("Internet Users");
		sleep(2);
		enterValueInTextBox("Details", "Logon Id", name);
		sleep(2);
		//enterValueInTextBox("Details", "Password", name);
		enterValueInTextBox("Details", "Name", name);
		sleep(2);
		enterValueInTextBox("Details", "Email Address", "Ayub.Khan@wexinc.com");
		sleep(2);
		chooseOptionFromDropdown("Role","Merchant Read Only");
		chooseOptionFromDropdown("Language","English (Guam)");
		sleep(2);
		common.clickOkButton();
		sleep(2);
		rightClick(internetUserMemberNo);
		common.addIteminPopup();
		validatePopupHeaderText("Internet Users Access");
		clientNameInProp = PropUtils.getPropValue(configProp, clientName).trim().toString();
		chooseOptionFromDropdown("Client", clientNameInProp);
		sleep(2);
		chooseOptionFromDropdown("Member Type","Merchant");
		//String merchantNo = common.getMerchantNoFromDB();
		sleep(2);
		enterValueInTextBox("Details", "Member No", merchantNo);
		sleep(2);
		common.clickOkButton();
		sleep(2);
		common.clickSaveIcon();
		sleep(2);
		// verifyText(bottomLeftText, "Record saved OK");
	}

	public void addCustomerToUser(String customerNumn) {
		Common common = new Common(driver, test);
		rightClick(internetUserMemberNo);
		common.addIteminPopup();
		validatePopupHeaderText("Internet Users Access");
		sleep(2);
		List<WebElement> element = driver
				.findElements(By.xpath("//div[@class='JFALSeparator']//div[contains(text(),'Details')]\r\n"
						+ "/preceding::div[@class='JFALLabel']/div[contains(text(),'Member') and contains(text(),'No')]/preceding::div[@class='JFALCompControlPanel'][1]//input"));
		element.get(1).sendKeys(customerNumn);
		/*
		 * enterValueInTextBox("Details", "Member No", customerNumn); sleep(10);
		 */
		sleep(2);
		common.clickOkButton();
		sleep(2);
		common.clickSaveIcon();
		sleep(2);
		verifyText(bottomLeftText, "Record saved OK");
	}

	public void gotoClientConfigAndChooseCardControl() {
		chooseSubMenuFromLeftPanel("Client Config", "Card Controls");
		sleep(3);
		validateHeaderLabel("Card Controls");

		chooseSubMenuFromLeftPanel("Card Controls", "Card Control Profiles");
		sleep(3);
		validateHeaderLabel("Card Controls");
	}
	public void createNewOlsMerchantOrCustomerUser(String name, String password, String memberRole,String merchantNo, String memberType, String clientName) {
		Common common=new Common(driver,test);
		String clientNameInProp;
		rightClick(internetUserLogonId);
		common.addIteminPopup();
		validatePopupHeaderText("Internet Users");
		sleep(2);
		enterValueInTextBox("Details", "Logon Id", name);
		sleep(2);
		//enterValueInTextBox("Details", "Password", password);
		enterValueInTextBox("Details", "Name", name);
		sleep(2);
		enterValueInTextBox("Details", "Email Address", "Nithya.Manikandan@wexinc.com");
		sleep(2);
		if(memberType.equalsIgnoreCase("Merchant")) {
		chooseOptionFromDropdown("Role",memberRole);
		}else {
			chooseOptionFromDropdown("Role",memberRole);
			//validateCheckBoxToCheckOrUncheck("Details", "Change Password on next Logon", "Checked");
		}
		
		System.out.println("client name  ::"+clientName );
		if(clientName.equals("BP")) {
			chooseOptionFromDropdown("Language","English (Australia)");
		}
		
		
		else if(clientName.equals("SHELL")) {
			chooseOptionFromDropdown("Language","English (GI)");
		}
		
		else {
		chooseOptionFromDropdown("Language","English (Guam)");
		}
		sleep(10);
		common.clickOkButton();
		sleep(10);
		rightClick(internetUserMemberNo);
		common.addIteminPopup();
		validatePopupHeaderText("Internet Users Access");
		String clientname=PropUtils.getPropValue(configProp, "clientName");
		String clientcountry=PropUtils.getPropValue(configProp, "clientCountry");
		clientNameInProp = PropUtils.getPropValue(configProp, clientname + "_" + clientcountry).trim().toString();
		chooseOptionFromDropdown("Client", clientNameInProp);
		sleep(2);
		chooseOptionFromDropdown("Member Type",memberType);
		//String merchantNo = common.getMerchantNoFromDB();
		sleep(2);
		enterValueInTextBox("Details", "Member No", merchantNo);
		sleep(2);
		common.clickOkButton();
		sleep(2);
		common.clickSaveIcon();
		sleep(2);
		verifyText(bottomLeftText, "Record saved OK");
	}

	public void gotoAdminBatchMenuAndChooseClient(String clientName, String ClientCountry) {
		Common common = new Common(driver, test);
		logInfo("Client on context::" + PropUtils.getPropValue(configProp, clientName));
		String clientNameInProp;
		isDisplayedThenClick(adminMenu, "AdminMenu");
		sleep(3);
		isDisplayedThenClick(BatchMenu, "BatchSubMenu");
		sleep(3);
		isDisplayedThenClick(Scheduling, "Schedulingleftmenu");
		sleep(3);
		common.searchTorch();
		clientNameInProp = PropUtils.getPropValue(configProp, clientName + "_" + ClientCountry).trim().toString();
		chooseOptionFromDropdown("Client", clientNameInProp);
		sleep(3);
		sleep(3);
		common.findRecordTorch();
		sleep(5);
		common.closeFindRecordTorch();
		sleep(3);

	}

	public void gotoClientMenuAndChooseClient(String clientNameInProp) {
		Common common = new Common(driver, test);
		isDisplayedThenClick(adminMenu, "AdminMenu");
		sleep(3);
		isDisplayedThenClick(clientMenu, "BatchSubMenu");
		sleep(3);
		common.searchTorch();
		chooseOptionFromDropdown("Client", clientNameInProp);
		sleep(3);
		common.findRecordTorch();
		sleep(5);
		common.closeFindRecordTorch();
		sleep(3);

	}

	public String getClientNameandCountry() {
		// logInfo("Client on context::" + PropUtils.getPropValue(configProp,
		// clientName));
		String clientNameInProp;
		String clientname = PropUtils.getPropValue(configProp, "clientName");
		String clientcountry = PropUtils.getPropValue(configProp, "clientCountry");
		System.out.println("te" + clientname + clientcountry);
		clientNameInProp = PropUtils.getPropValue(configProp, clientname + "_" + clientcountry);
		return clientNameInProp;
	}

	public void gotoClientConfigAndApplicationTypes() {
		chooseSubMenuFromLeftPanel("Client Config", "Card Programs");
		sleep(3);
		validateHeaderLabel("Card Programs");

		chooseSubMenuFromLeftPanel("Card Programs", "Application Types");
		sleep(3);
		validateHeaderLabel("Application Types");
	}

	public void clickPrePay() {
		// chooseSubMenuFromLeftPanel("Reporting","Report Categories");
		isDisplayedThenClick(applicationTypePrepay, "PrePay Description should be displayed and able to click");
	}

	public void gotoApplicationAndSearchApplication() {
		isDisplayedThenClick(applicationMenu, "Application Menu ");
		isDisplayedThenClick(applicationsSubMenu, "Application SubMenu");
		checkElementPresenceAndClick(maintainApplicationLeftPanel, "Maintain Application");
		validateIsPageDisplayed(maintainApplicationLeftPanel, maintainApplicationMainFrame);
		isDisplayedThenClick(applicationsearch, "Applications Menu");
		sleep(3);
		isDisplayedThenEnterText(externalrefnumapplication, "External Ref Number for Application", "113151803300");
		sleep(2);
		isDisplayedThenClick(torchsearchicon, "Search Application icon");
		sleep(3);
		isDisplayedThenClick(applicationsearchfirst, "Application List");
		doubleClick(applicationsearchfirst);

	}

	public void searchApplication(String applicationno) {
		isDisplayedThenClick(applicationsearch, "Applications Menu");//rax added
		isDisplayedThenEnterText(externalrefnumapplication, "External Ref Number for Application", applicationno);
		sleep(2);
		isDisplayedThenClick(torchsearchicon, "Search Application icon");
		sleep(3);
		isDisplayedThenClick(applicationsearchfirst, "Application List");
		sleep(3);
		doubleClick(applicationsearchfirst);
		sleep(2);
	}

	public void searchApllicationandSelect() {
		doubleClick(applicationsearchfirst);

	}

	/*
	 * Verify report type is present or not under Report type section
	 */
	public void verifyPresenceOfReport(String reportTypeName) {
		WebElement reportType = driver.findElement(
				By.cssSelector("div[class='FALTableCellEditor_StrikeThruField JTextComponent']>input[value='"
						+ reportTypeName + "']"));
		if (reportType.isDisplayed()) {
			logPass(reportTypeName + " is displayled as expected");
		} else {
			logFail(reportTypeName + " is not displayed");
		}
	}

	/*
	 * Click on BPPrepaidCards
	 */
	public void dblClickBpPrepaidCards() {
		doubleClick(cardProgramsBPPrepaidCards);
	}

	/*
	 * Click Card Programs option from Client Config
	 */
	public void clickCardProgramsFromClientConfig() {
		chooseSubMenuFromLeftPanel("Client Config", "Card Programs");
		sleep(3);
		validateHeaderLabel("Card Programs");
	}

	/*
	 * validated the selected account type is expected or not
	 */
	public void validateSelectedAccountType(String expAccountType) {
		String actAccountType = accountTypeSelected.getText();
		System.out.println(actAccountType);
		if (actAccountType.equals(expAccountType)) {
			logPass(expAccountType + " is matching " + actAccountType);
		} else {
			logFail(expAccountType + " is not matching " + actAccountType);
		}
	}

	/*
	 * Adding member in online users if not present
	 */
	public void addingMemberInOnlineUsersIfNotPresent(String memberNo, String logonId) {
		Common common = new Common(driver, test);
		enterText(logonIdTextBox, logonId);
		Boolean memberNumberPresence = false;
		isDisplayedThenClick(searchTorchUsers, "Clicking on search torch");
		common.detailSearch();
		sleep(5);
		List<WebElement> memberNoValues = driver.findElements(By.xpath(
				"//div[@class='JFALSeparator']//div[contains(text(),'Users') and contains(text(),'Access')][not(contains(text(),'Alert'))]/preceding::div[@class='JFALCompControlPanel'][1]//div[starts-with(@class,'FALTableCellEditor_StrikeThru')]"));
		SeleniumWrappers.setCellValue(memberNoValues);
		int noOfRows = SeleniumWrappers.getTotalNumberOfRows(memberNoValues, driver);
		for (int i = 0; i <= noOfRows; i++) {
			String value = SeleniumWrappers.getTableDataWithRowAndColumnNumber(0, i, driver);
			if (memberNo.equals(value)) {
				memberNumberPresence = true;
				break;
			}
		}
		System.out.println(memberNumberPresence);
		if (memberNumberPresence) {
			logPass("Member value is already present");
		} else {
			rightClick(internetUserMemberNo);
			common.addIteminPopup();
			validatePopupHeaderText("Internet Users Access");
			String clientname = PropUtils.getPropValue(configProp, "clientName");
			String clientcountry = PropUtils.getPropValue(configProp, "clientCountry");
			String clientNameInProp = PropUtils.getPropValue(configProp, clientname + "_" + clientcountry);
			sleep(3);
			chooseOptionFromDropdown("Member Type", "Customer");
			sleep(2);
			chooseOptionFromDropdown("Client", clientNameInProp);
			sleep(3);
			enterValueInTextBox("Details", "Member No", memberNo);
			sleep(2);
			common.clickOkButton();
			sleep(2);
			common.clickSaveIcon();
			sleep(2);
			verifyText(bottomLeftText, "Record saved OK");
		}
	}

	public String validateApplicationlist(HashMap<String, String> RefNum) {
		String keyValue = null;
		isDisplayedThenClick(applicationMenu, "Application Menu ");
		isDisplayedThenClick(applicationsSubMenu, "Application SubMenu");
		checkElementPresenceAndClick(maintainApplicationLeftPanel, "Maintain Application");
		validateIsPageDisplayed(maintainApplicationLeftPanel, maintainApplicationMainFrame);
		isDisplayedThenClick(applicationsearch, "Applications Menu");
		sleep(3);
		for (String key : RefNum.keySet()) {
			isDisplayedThenEnterText(externalrefnumapplication, "External Ref Number for Application", key);
			isDisplayedThenClick(torchsearchicon, "Search Application icon");
			sleep(2);
			int columnNumber = SeleniumWrappers.getColumnNoForColumnHeader("Name", cardsTableHeader);
			System.out.println("col number::" + columnNumber);
			List<WebElement> elements = driver
					.findElements(By.xpath("//div[@class='FALTableCellEditor_StrikeThruField JTextComponent']"));
			List<String> applicationName = SeleniumWrappers.getTableDataWithColumnNumber(columnNumber, elements,
					driver);
			System.out.println(applicationName.get(0) + "::" + (RefNum.get(key)));
			// String
			// applicationName=driver.findElement(By.xpath("//div[@class='VOTable']//div[@class='FALTableCellEditor_StrikeThruField
			// JTextComponent'][4]//div[@class='htmlString']")).getText();
			if (applicationName.get(0).equalsIgnoreCase(RefNum.get(key))) {
				logPass(RefNum.get(key) + " Application is uploaded successfully");
			} else {
				logFail(RefNum.get(key) + " Application is not uploaded successfully");
			}
			keyValue = key;

		}
		return keyValue;

	}

	public void gotoCustomerMenuCustomer() {
		isDisplayedThenClick(customerMenu, "Customer is clicked");
		isDisplayedThenClick(customerDetailsSubMenu, "Customer Details is clicked");
		checkElementPresenceAndClick(maintainCustomerInLeftPanel, "Maintain Customer");
		validateIsPageDisplayed(maintainCustomerInLeftPanel, maintainCustomerInMainFrame);
		isDisplayedThenClick(customersearch, "Customer Menu");
		sleep(3);
	}

	public void gotoTransactionAndClickManualPayment() {
		isDisplayedThenClick(transactionsMenu, "Transactions Menu");
		isDisplayedThenClick(manageTransactionSubMenu, "Manage Transaction SubMenu");
		checkElementPresenceAndClick(clientTransactionInLeftPanel, "Client Transactions");
		validateIsPageDisplayed(clientTransactionInLeftPanel, clientTransactionInMainFrame);
		isDisplayedThenClick(MANUAL_PAYMENT_LEFT_PANEL, "Manual payment");
		sleep(3);
	}
	
	
	public void gotoTransactionAndClickPayment() {
		isDisplayedThenClick(transactionsMenu, "Transactions Menu");
		isDisplayedThenClick(manageTransactionSubMenu, "Manage Transaction SubMenu");
		checkElementPresenceAndClick(clientTransactionInLeftPanel, "Client Transactions");
		validateIsPageDisplayed(clientTransactionInLeftPanel, clientTransactionInMainFrame);
		isDisplayedThenClick(PAYMENT_LEFT_PANEL, "Payment");
		isDisplayedThenClick(MANUAL_PAYMENT_LEFT_PANEL, "Manual payment");
		sleep(3);
	}

	public void clickingCalendarSubMenu() {
		chooseSubMenuFromLeftPanel("Client Config", "Calendar");
		sleep(2);
		validateHeaderLabel("Calendar");
	}

}
