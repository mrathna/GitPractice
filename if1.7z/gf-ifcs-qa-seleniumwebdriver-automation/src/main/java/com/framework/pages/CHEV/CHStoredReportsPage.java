package com.framework.pages.CHEV;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.ExtentTest;
import com.framework.basepage.BasePage;
import com.framework.repo.Locator;

public class CHStoredReportsPage extends BasePage {

	@FindBy(how = How.XPATH, using = Locator.SCHEDULE_REPORT_MAINTENANCE_PAGE)
	public WebElement storedReportsPageTitle;

	@FindBy(how = How.ID, using = Locator.CH_REPORTS_TABLE_REPORT_TYPE_COLUMN)
	public WebElement reportTypeHeader;

	@FindBy(how = How.ID, using = Locator.CH_REPORTS_TABLE_CREATED_COLUMN)
	public WebElement createdTypeHeader;

	@FindBy(how = How.ID, using = Locator.CH_REPORTS_TABLE_FILE_NAME_COLUMN)
	public WebElement fileNameHeader;

	@FindBy(how = How.ID, using = Locator.SEARCH_CARDS)
	public WebElement searchBtn;

	@FindBy(how = How.ID, using = Locator.CH_REPORTS_EXPORT_BTN)
	public WebElement exportBtn;
	
	@FindBy(how = How.ID, using = Locator.CH_REPORTS_REPORT_TYPE_FIELD)
	public WebElement reportTypeField;
	
	@FindBy(how = How.ID, using = Locator.CH_REPORTS_CREATED_FROM_FIELD)
	public WebElement createdFromField;
	
	@FindBy(how = How.ID, using = Locator.CH_REPORTS_CREATED_TO_FIELD)
	public WebElement createdToField;
	
	@FindBy(how = How.ID, using = Locator.CH_REPORTS_FILENAME_FIELD)
	public WebElement fileNameField;
	
	@FindBy(how = How.XPATH, using = Locator.REPORT_TYPE)
	public WebElement reporttype;
	
	@FindBy(how = How.ID, using = Locator.FROM_VALUE)
	public WebElement fromvalue;
	
	@FindBy(how = How.ID, using = Locator.TO_VALUE)
	public WebElement tovalue;
	
	@FindBy(how = How.ID, using = Locator.REPORT_SEARCH)
	public WebElement reportsearch;
	
	@FindBy(how = How.XPATH, using = Locator.REPORT_FILENAME)
	public WebElement reportfilename;
	
	@FindBy(how = How.XPATH, using = Locator.FOUND_ROWSIZE)
	public WebElement foundrowsize;
	
	@FindBy(how = How.XPATH, using = Locator.NO_REPORTS)
	public WebElement noreports;
	
	@FindBy(how = How.XPATH, using = Locator.GET_STOREDREPORT)
	public WebElement getstorereport;
	@FindBy(how = How.XPATH, using = Locator.GET_CONTACTREPORT)
	public WebElement getcontactreport;
	
	@FindBy(how = How.ID, using = Locator.STORED_EXPORT_BTN)
	public WebElement exportbutton;
	
	@FindBy(how = How.XPATH, using = Locator.STATEMENT_REPORTFILE)
	public WebElement statementreportfile;

	@FindBy(xpath = Locator.STATEMENT_REPORTTYPE)
	public WebElement statementReportFileType;

	@FindBy(how = How.XPATH, using = Locator.GET_STATEMENTREPORT)
	public WebElement getstatementreport;
	
	
	public CHStoredReportsPage(WebDriver driver, ExtentTest test) {
		super(driver, test); 
		PageFactory.initElements(driver, this);
	}

	public void verifyStoreReportPageTitle() {
		sleep(10);
		checkTextInPageAndValidate("Stored Reports", 20);
	}
	//Invoice
	public void verifyInvoicePageTitle() {
		sleep(10);
		checkTextInPageAndValidate("Invoices", 20);
	}
	public void verifyPageTitle() {
		sleep(10);
		checkTextInPageAndValidate("Stored Reports", 20);
	}

	public void searchResultsTableHeaders() {
		verifyText(createdTypeHeader, "Created");
		verifyText(reportTypeHeader, "Report Type");
		verifyText(fileNameHeader, "File Name");
	}
	
	public void verifySearchButtons() {
		if (searchBtn.isDisplayed()) {
			logPass("Search is displayed");
		} else {
			logFail("Search is not displayed");
		}

	}
public void verifyPageSubTitles() {
		verifyText(reportTypeField, "Report Type");
		verifyText(createdFromField, "Created From");
		verifyText(createdToField, "Created To");
		verifyText(fileNameField, "File Name");
	}
	
	public void verifyStoreReportPageSubTitles() {
		verifyText(reportTypeField, "Report Type");
		verifyText(createdFromField, "Created From");
		verifyText(createdToField, "Created To");
		verifyText(fileNameField, "File Name");
	}

	//Invoice
	public void verifyInvoicePageSubTitles() {
		
		verifyText(createdFromField, "Created From");
		verifyText(createdToField, "Created To");
		verifyText(fileNameField, "File Name");
	}
	
	public void verifyExportButtons() {
		if (exportBtn.isDisplayed()) {
			logPass("exportBtn is displayed");
		} else {
			logFail("exportBtn is not displayed");
		}

	}

	
	public void selectReportType() {
		sleep(3);
		selectDropDownOptionsRandomly(reporttype,"Report Type select");
		
	}
	public void enterfromtovalue() {
		sleep(3);
		enterText(fromvalue,"08/08/2010");
		enterText(tovalue,"08/09/2020");
	}
	public void selectsearch() {
		sleep(3);
		actionClick(reportsearch);		
	}
	public void verifyexport() {
		sleep(10);
		actionClick(exportbutton);
		
		//verifyTheDownloadedFile("tableStoredRepList");
		verifyTheDownloadedFile("table");
		
	}
	public void VerifystoreReports() {
		sleep(3);	
		int rowsize = getRowSize(foundrowsize);
		System.out.println(rowsize);
		if (rowsize >= 3 && !noreports.isDisplayed()) {
		
			
			logInfo("Stored Report(s) available");
			 actionClick(getstorereport);
			//actionClick(getcontactreport);
			
			sleep(10);
			String Rfilename= getText(reportfilename);
			System.out.println(Rfilename);
			verifyTheDownloadedFile(Rfilename);
			
		}			
		else {
			String Noreport = getText(noreports);
			if(Noreport.equals("No Stored Reports Found")) {
			System.out.println(Noreport);
			logInfo("No Stored Reports found in Result");
			}
		}
	}
	
	
	public void verifyStatementPageTitle() {
		sleep(10);
		checkTextInPageAndValidate("Statements", 20);
	}
	public void verifystatementreportPageSubTitles() {
		verifyText(createdFromField, "Created From");
		verifyText(createdToField, "Created To");
		verifyText(fileNameField, "File Name");
	}
	
	public boolean verifyStatementReports() {
        try {
        	sleep(10);
            noreports.isDisplayed();
        } catch (Exception e) {
            System.out.println("id is not present ");
            return false;
        }

        return true;
	}
	public void verifyReports() {
		if (verifyStatementReports() == false) {
			System.out.println("Statements Report(s) available ");
			logInfo("Statements Report(s) available");
		//	String Rfilename = getText(statementReportFileType);
			String Rfilename = getText(getstatementreport);
			System.out.println(Rfilename);
			logInfo("File Name Expected : " + Rfilename.replaceAll(" ", "_"));
			sleep(5);
			actionClick(getstatementreport);
			sleep(10);
			verifyTheDownloadedFile(Rfilename.replaceAll(" ", "_"));

   }
   else{
   String Noreport = getText(noreports);
			if(Noreport.equals("No Stored Reports Found")) {
			System.out.println(Noreport);
			logInfo("No Stored Reports found in Result");
			}
}
	}
		
}
