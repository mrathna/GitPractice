package com.framework.testcases.AJS.EMAP.Interface;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.common.Common;
import com.framework.pages.AJS.common.CommonInterfacePage;
import com.framework.pages.AJS.common.IFCSCommonPage;
import com.framework.pages.AJS.common.IFCSLoginPage;
import com.framework.pages.AJS.common.InterfacePage;

public class ValidateInterfaceDayEndAndMonthEndProcessTestCases  extends BaseTest{
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "Smoke" },enabled=false)
	public void ValidateCustomerWithPeroidicRebate(@Optional("SG") String clientCountry,
			@Optional("EMAP") String clientName) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  TST-SC-104-CR112 -Period Rebates to be calculated off Customer Pump Price - Manual Transaction",
				"Periodic rebates-Manual Transaction");

		// creating object for the Pages
		Common common = new Common(driver, test);
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		InterfacePage interfacePage = new InterfacePage(driver, test);
		CommonInterfacePage commonInterfacePage = new CommonInterfacePage(driver, test);
		IFCSCommonPage ifcsCommonPage = new IFCSCommonPage(driver, test);
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, " ");

		String cusNo = "6300048100";// 6300056922";//"6300048968";//SG
		// String cusNo ="0002680";
		String dayEndDatePath = "";

		// String cusNo = common.getCustomerNumberWithNoHierarchy();

		// Get Recent Processed File from IFCS Server
		String fileName = commonInterfacePage.getRecentProcessedReportFiles(clientName, clientCountry,
				"Customer Statement", cusNo);
		if (clientCountry.equals("SG")) {
			dayEndDatePath = commonInterfacePage.getFolderPathUsingPreviousProcessingDate(clientName, clientCountry,
					"IFCS_DAYEND_OUTPUTFILE_SG_CUSTOMER");
		} else if (clientCountry.equals("GU")) {
			dayEndDatePath = commonInterfacePage.getFolderPathUsingPreviousProcessingDate(clientName, clientCountry,
					"IFCS_DAYEND_OUTPUTFILE_GU_CUSTOMER");
		} else if (clientCountry.equals("HK")) {
			dayEndDatePath = commonInterfacePage.getFolderPathUsingPreviousProcessingDate(clientName, clientCountry,
					"IFCS_DAYEND_OUTPUTFILE_HK_CUSTOMER");
		}
		System.out.println("dayEndDatePath::" + dayEndDatePath);
		ifcsCommonPage.establishThePuttyConnection("incomingFile", "PUTTY_HOST", "PUTTY_USERNAME", "PUTTY_PASSWORD",
				dayEndDatePath, fileName);
		String localFolder = System.getProperty("user.home") + "\\Documents\\" + fileName;
		System.out.println("localFolder::" + localFolder);
		// String fileName = "33-Customer Statement(Standard) 01.05.2021-Account
		// 6300048100-20067782.pdf";

		String periodRebateCustomerAmount = commonInterfacePage.getCustomerAmountFromPeriodRebates(cusNo);

		String currentIFCSDate = common.getCurrentIFCSDateFromDB(clientName + clientCountry);

		String currentDate = commonInterfacePage.getTransactionMonthStartingDate("Current", currentIFCSDate);
		System.out.println("Transaction Month Current date " + currentDate);

		String transactionMonthStartingDate = commonInterfacePage.getTransactionMonthStartingDate("Past",
				currentIFCSDate);
		System.out.println("Transaction Month starting date " + transactionMonthStartingDate);

		String customerTotalTransactions = commonInterfacePage.getCustomerTotalTransactionsAmountFromDB(cusNo, "0003",
				transactionMonthStartingDate, currentDate);

		String customerRebateCalculation = commonInterfacePage.getRateValueFromDB(cusNo,
				"503", customerTotalTransactions);
		System.out.println("Customer rebate calculation is " + customerRebateCalculation);

		// For validation to get text value from DB

		interfacePage.validatePeriodicRebateAmountFromPDF(periodRebateCustomerAmount, customerRebateCalculation,
				fileName, 1, 5);
	}
	
	
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "Smoke" })
	public void ValidateMigratedCustomerWithPeroidicRebate(@Optional("SG") String clientCountry,
			@Optional("EMAP") String clientName) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  TST-SC-23 -Migrated Customer with Periodic rebates","Migrated Customer with Periodic rebate");

		// creating object for the Pages
		Common common = new Common(driver, test);
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		InterfacePage interfacePage = new InterfacePage(driver, test);
        CommonInterfacePage commonInterfacePage = new CommonInterfacePage(driver, test);
        IFCSCommonPage ifcsCommonPage = new IFCSCommonPage(driver, test);
        IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry," ");
      
        String cusNo = "6300048100";// 6300056922";//"6300048968";//SG
		// String cusNo ="0002680";
        String dayEndDatePath = "";
        
      //Get Recent Processed File from IFCS Server
    

		String fileName = commonInterfacePage.getRecentProcessedReportFiles(clientName, clientCountry,
				"Customer Statement", cusNo);
		if (clientCountry.equals("SG")) {
			dayEndDatePath = commonInterfacePage.getFolderPathUsingPreviousProcessingDate(clientName, clientCountry,
					"IFCS_DAYEND_OUTPUTFILE_SG_CUSTOMER");
		}  else if (clientCountry.equals("GU")) {
			dayEndDatePath = commonInterfacePage.getFolderPathUsingPreviousProcessingDate(clientName, clientCountry,
					"IFCS_DAYEND_OUTPUTFILE_GU_CUSTOMER");
		} else if (clientCountry.equals("HK")) {
			dayEndDatePath = commonInterfacePage.getFolderPathUsingPreviousProcessingDate(clientName, clientCountry,
					"IFCS_DAYEND_OUTPUTFILE_HK_CUSTOMER");
		}
		System.out.println("dayEndDatePath::" + dayEndDatePath);
		ifcsCommonPage.establishThePuttyConnection("incomingFile", "PUTTY_HOST", "PUTTY_USERNAME", "PUTTY_PASSWORD",
				dayEndDatePath, fileName);
		String localFolder = System.getProperty("user.home") + "\\Documents\\" + fileName;
		System.out.println("localFolder::" + localFolder);

        
        //Calculating periodic rebate amount
        String periodRebateCustomerAmount = commonInterfacePage.getCustomerAmountFromPeriodRebates(cusNo);

		String currentIFCSDate = common.getCurrentIFCSDateFromDB(clientName + clientCountry);

		String currentDate = commonInterfacePage.getTransactionMonthStartingDate("Current", currentIFCSDate);
		System.out.println("Transaction Month Current date " + currentDate);

		String transactionMonthStartingDate = commonInterfacePage.getTransactionMonthStartingDate("Past",
				currentIFCSDate);
		System.out.println("Transaction Month starting date " + transactionMonthStartingDate);

		String customerTotalTransactions = commonInterfacePage.getCustomerTotalTransactionsAmountFromDB(cusNo, "0003",
				transactionMonthStartingDate, currentDate);

		String customerRebateCalculation = commonInterfacePage.getRateValueFromDB(cusNo,
				"503", customerTotalTransactions);
		System.out.println("Customer rebate calculation is " + customerRebateCalculation);

		// For validation to get text value from DB
	//	 String fileName = "33-Customer Statement(Standard) 01.05.2021-Account 6300048100-20067782.pdf";

		interfacePage.validatePeriodicRebateAmountFromPDF(periodRebateCustomerAmount, customerRebateCalculation,
				fileName, 1, 5);
                                                                                                                                                     
        }
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "Smoke" },enabled=false)
	public void ValidateCustomerPeroidicRebateUsingFEP(@Optional("SG") String clientCountry,
			@Optional("EMAP") String clientName) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  TST-SC-105-CR112 -Period Rebates to be calculated off Customer Pump Price - FEP File- Inbound- TXN",
				"Periodic rebates-FEP File Transactions");

		// creating object for the Pages
		Common common = new Common(driver, test);
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		InterfacePage interfacePage = new InterfacePage(driver, test);
		CommonInterfacePage commonInterfacePage = new CommonInterfacePage(driver, test);
		IFCSCommonPage ifcsCommonPage = new IFCSCommonPage(driver, test);
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, " ");

		String cusNo = "6300048100";// 6300056922";//"6300048968";//SG
		// String cusNo ="0002680";
		String dayEndDatePath = "";

		// String cusNo = common.getCustomerNumberWithNoHierarchy();

		// Get Recent Processed File from IFCS Server
		String fileName = commonInterfacePage.getRecentProcessedReportFiles(clientName, clientCountry,
				"Customer Statement", cusNo);
		if (clientCountry.equals("SG")) {
			dayEndDatePath = commonInterfacePage.getFolderPathUsingPreviousProcessingDate(clientName, clientCountry,
					"IFCS_DAYEND_OUTPUTFILE_SG_CUSTOMER");
		}  else if (clientCountry.equals("GU")) {
			dayEndDatePath = commonInterfacePage.getFolderPathUsingPreviousProcessingDate(clientName, clientCountry,
					"IFCS_DAYEND_OUTPUTFILE_GU_CUSTOMER");
		} else if (clientCountry.equals("HK")) {
			dayEndDatePath = commonInterfacePage.getFolderPathUsingPreviousProcessingDate(clientName, clientCountry,
					"IFCS_DAYEND_OUTPUTFILE_HK_CUSTOMER");
		}
		System.out.println("dayEndDatePath::" + dayEndDatePath);
		ifcsCommonPage.establishThePuttyConnection("incomingFile", "PUTTY_HOST", "PUTTY_USERNAME", "PUTTY_PASSWORD",
				dayEndDatePath, fileName);
		String localFolder = System.getProperty("user.home") + "\\Documents\\" + fileName;
		System.out.println("localFolder::" + localFolder);
		
		// String fileName = "33-Customer Statement(Standard) 01.05.2021-Account
		// 6300048100-20067782.pdf";

		String periodRebateCustomerAmount = commonInterfacePage.getCustomerAmountFromPeriodRebates(cusNo);

		String currentIFCSDate = common.getCurrentIFCSDateFromDB(clientName + clientCountry);

		String currentDate = commonInterfacePage.getTransactionMonthStartingDate("Current", currentIFCSDate);
		System.out.println("Transaction Month Current date " + currentDate);

		String transactionMonthStartingDate = commonInterfacePage.getTransactionMonthStartingDate("Past",
				currentIFCSDate);
		System.out.println("Transaction Month starting date " + transactionMonthStartingDate);

		String customerTotalTransactions = commonInterfacePage.getCustomerTotalTransactionsAmountFromDB(cusNo, "0003",
				transactionMonthStartingDate, currentDate);

		String customerRebateCalculation = commonInterfacePage.getRateValueFromDB(cusNo,
				"503", customerTotalTransactions);
		System.out.println("Customer rebate calculation is " + customerRebateCalculation);

		// For validation to get text value from DB

		interfacePage.validatePeriodicRebateAmountFromPDF(periodRebateCustomerAmount, customerRebateCalculation,
				fileName, 1, 5);
	}

	
	
	
	
}