package com.framework.pages.AJS.common;

import java.io.BufferedReader;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Writer;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.commons.lang3.text.WordUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.openqa.selenium.WebDriver;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.aventstack.extentreports.ExtentTest;
import com.framework.basepage.BasePage;
import com.framework.pages.BusinessFlow.TransactionComponentPage;
import com.framework.util.Constants;
import com.framework.util.ExcelUtils;
import com.framework.util.PdfUtils;
import com.framework.util.PropUtils;
import com.framework.util.PuttyUtils;

public class IFCSCommonPage extends BasePage {

	String hostName, userName, passwordPutty, remoteDirectory = null;
	String getLoadCardCustomerNumber = null;

	static Set<Object> keys = new LinkedHashSet<Object>();

	public IFCSCommonPage(WebDriver driver, ExtentTest test) {
		super(driver, test);

	}

	// Reading All the Keys and Values from the Incoming and Outgoing Properties
	// file
	public ArrayList<String> updateOrValidateInterfaceFile(Properties properties, String type, String remoteDir,
			String validateNumbers, String clientCountry, String inputTemplateFileName) {

		logInfo("File moving in to the IE or IFCS server begin");
		// String uniqueVerficationNumber ="";
		ArrayList<String> uniqueVerficationNumber = new ArrayList<String>();

		try {
			keys = properties.keySet();
			if (type.equalsIgnoreCase("incomingFile")) {
				validateIncomingFile(properties, configProp, remoteDir, validateNumbers);
				logInfo("Validated the Incoming file");
			} else if (type.equalsIgnoreCase("OutgoingFile") || type.equalsIgnoreCase("OutgoingFileZip")) {
				uniqueVerficationNumber = updateValuesInOutgoingFile(properties, type, remoteDir, validateNumbers,
						clientCountry, inputTemplateFileName);
				logInfo("Updated the values of the Outgoing Flat file");
			} else if (type.equalsIgnoreCase("OLSIncoming")) {
				validateOLSIncomingFile(properties, validateNumbers, remoteDir);
				logInfo("validated the OLS Incoming file");
			} else if (type.equalsIgnoreCase("OutgoingXMLFile")) {
				uniqueVerficationNumber = updateValuesAndUploadToXMLFile(properties, remoteDir, clientCountry,
						inputTemplateFileName);
				logInfo("validated the OutGoing XML file");
			} else {
				logInfo("No type is selected");
			}
		} catch (IOException e) {
			logFail("--- Failure due to the exception caught ---" + e.getMessage());
		} catch (TransformerException e) {
			logFail("--- Failure due to the exception caught ---" + e.getMessage());
		}
		return uniqueVerficationNumber;
	}

	// Validating the Incoming file Contents
	public void validateIncomingFile(Properties properties, Properties configProp, String fileDirectory,
			String orderedCard) throws IOException {

		CommonInterfacePage commonInterfacePage = new CommonInterfacePage(driver, test);
		String fileLine[] = readFile(fileDirectory);
		String key, value, expectedValue, header = null, readLine = null, actualValue = null;
		String orderedCardList[] = null;
		String inputFields[];
		int lineNumber, startPos, endPos, numberOfSpaces, numberOfCards, numberOfFileLines = 0;
		Class<? extends CommonInterfacePage> cls;
		for (Object k : keys) {
			key = (String) k;
			value = PropUtils.getPropValue(properties, key);
			inputFields = value.split(",");
			lineNumber = Integer.parseInt(inputFields[0]) - 1;
			startPos = Integer.parseInt(inputFields[1]) - 1;
			endPos = Integer.parseInt(inputFields[2]);
			expectedValue = inputFields[3];

			if (expectedValue.equals("ValidateDynamicValue")) {
				expectedValue = orderedCard;
				System.out.println("Expected Value is:: " + expectedValue);
			}
			header = inputFields[4];
			numberOfSpaces = endPos - startPos;
			readLine = fileLine[lineNumber];
			actualValue = readLine.substring(startPos, endPos);
			cls = commonInterfacePage.getClass();

			try {
				if (expectedValue.contains("func")) {

					Method method = cls.getMethod(expectedValue, Properties.class, String.class);
					expectedValue = (String) method.invoke(commonInterfacePage, configProp, orderedCard);
				} else if (expectedValue.contains("filler")) {

					Method method = cls.getMethod(expectedValue, int.class);
					expectedValue = (String) method.invoke(commonInterfacePage, numberOfSpaces);
				} else {
					if (expectedValue.contains(",")) {
						orderedCardList = expectedValue.split(",");
					} else {
						orderedCardList[0] = expectedValue;

					}
					numberOfCards = orderedCardList.length;
					System.out.println("no.of.cards " + numberOfCards);
					numberOfFileLines = getFileLines(fileDirectory);
					System.out.println("no.of.lines " + numberOfFileLines);
					ArrayList<String> cardNo = new ArrayList<String>();
					StringBuilder sb = new StringBuilder();
					for (lineNumber = 1; lineNumber < numberOfFileLines - 1; lineNumber++) {
						if (!readLine.isEmpty()) {
							readLine = fileLine[lineNumber];
							actualValue = readLine.substring(startPos, endPos);
							cardNo.add(actualValue.trim());
						}
					}

					System.out.println("Card List size: " + cardNo.size());
					System.out.println("Actual Value is:: " + cardNo);

					for (int j = 0; j < numberOfCards; j++) {
						if (cardNo.contains(orderedCardList[j].trim())) {
							logPass(header + ":" + orderedCardList[j] + " are matched");
						} else {
							sb.append(":" + orderedCardList[j]);
							logInfo(header + ":" + orderedCardList[j] + " is not present in the file");
						}
					}
					if (sb.length() > 0) {
						logFail(sb + " were not Present in the File");
					}

				}
			} catch (NoSuchMethodException ex) {
				System.out.println(ex.getMessage());
			} catch (IllegalAccessException ex) {
				System.out.println(ex.getMessage());
			} catch (InvocationTargetException ex) {
				System.out.println(ex.getMessage());
			} catch (Exception e) {
				System.out.println(e.getMessage());
			}

		}

	}

	// Updating the Contents of the Outgoing file
	public ArrayList<String> updateValuesInOutgoingFile(Properties properties, String type, String remoteDir,
			String validateGeneratedNumbers, String clientCountry, String inputTemplateFileName) throws IOException {
		File outgoingFileCopy = null;
		CommonInterfacePage commonInterfacePage = new CommonInterfacePage(driver, test);
		// String verifyUniqueNumber ="";
		ArrayList<String> verifyUniqueNumber = new ArrayList<String>();
		String clientCountryName = PropUtils.getPropValue(configProp, "clientCountry");
		String outgoingFileTemplate = Constants.INPUTFILE_DIR + inputTemplateFileName;
		if (inputTemplateFileName.contains("A01")) {
			String fileNameBeforeDate = splitStringbasedOnOccuranceOfDelimiter(inputTemplateFileName, "_", "first");
			outgoingFileCopy = copyFile(outgoingFileTemplate, fileNameBeforeDate, clientCountry);
		} else if (inputTemplateFileName.contains("j09")) {
			String pvvFileName = commonInterfacePage.getPVVFileName(clientCountry);
			outgoingFileCopy = copyFile(outgoingFileTemplate, pvvFileName, clientCountry);
		} else if (inputTemplateFileName.contains("AC2")) {
			String fileNameAC2 = commonInterfacePage.createFileNameFormatforAC2(clientCountry);
			outgoingFileCopy = copyFile(outgoingFileTemplate, fileNameAC2, clientCountry);
		} else if (inputTemplateFileName.contains("ACC")) {
			String fileNameACC = commonInterfacePage.createFileNameFormatforACC(clientCountry);
			outgoingFileCopy = copyFile(outgoingFileTemplate, fileNameACC, clientCountry);
		} else if (inputTemplateFileName.contains("FLTRAN")) {
			String fileNameBeforeDate = splitStringbasedOnOccuranceOfDelimiter(inputTemplateFileName, "_", "first");
			System.out.println("fileNameBeforeDate : " + fileNameBeforeDate);

			String fileNameTran = commonInterfacePage.createFileNameFormatforLoadCardTransaction(fileNameBeforeDate,
					properties, clientCountry);
			System.out.println("fileNameACC : " + fileNameTran);

			outgoingFileCopy = copyFile(outgoingFileTemplate, fileNameTran, clientCountry);
		} else {
			outgoingFileCopy = copyFile(outgoingFileTemplate, inputTemplateFileName, clientCountry);
		}

		System.out.println("Outgoing file name is: " + outgoingFileName);
		
		logInfo("Outgoing file name is: " + outgoingFileName);
		String fileLine[] = readFile(outgoingFileName);
		Writer fileWriter = new FileWriter(outgoingFileCopy, false);
		String readLine = "";
		String key, value, newValue;
		int lineNumber, startPos, endPos;
		String inputFields[];
		Class<? extends CommonInterfacePage> cls;
		for (Object k : keys) {
			key = (String) k;
			value = PropUtils.getPropValue(properties, key);
			inputFields = value.split(",");
			lineNumber = Integer.parseInt(inputFields[0]) - 1;
			startPos = Integer.parseInt(inputFields[1]) - 1;
			endPos = Integer.parseInt(inputFields[2]);
			newValue = inputFields[3];
			
			System.out.println("value for key "+ value);
			System.out.println("value for line number "+ lineNumber);
			System.out.println("value for startPos "+ startPos);
			System.out.println("value for endPos "+ endPos);
			System.out.println("value for newValue "+ newValue);
			
			cls = commonInterfacePage.getClass();
			
			
			String squesnceNo = "0051";
			//String batchNo = "12532  ";
			

			try {
				if (newValue.contains("funcDate")) {
					Method method = cls.getMethod(newValue, Properties.class, String.class);
					newValue = (String) method.invoke(commonInterfacePage, configProp, clientCountry);
					
					if(clientCountry.contains("WFE"))
					{
						//String squesnceNo = commonInterfacePage.getSequenceNoForVinciiTransFromICPDB();
						String time = commonInterfacePage.getTimeBasedOnTimeZone();
						
						System.out.println("Sequence number value "+squesnceNo);
						
						if(key.equals("Header")||key.equals("Trailer")) {
						newValue=newValue+time+squesnceNo;
						System.out.println("value for newValue inside condition "+ newValue);
						}
						else if(key.contains("VinciiTrans")) {
							newValue=newValue+time;
							
						}
					}

					if (key.equals("referenceNumber1") || key.equals("DetailCustomerNumber")) {
						verifyUniqueNumber.add(newValue);
					} else if (key.equals("referenceNumber2")) {
						verifyUniqueNumber.add(newValue);
					} else if (key.equals("referenceNumber3")) {
						verifyUniqueNumber.add(newValue);
					}
				} else if(newValue.contains("funcBatch")) {
					
				int i =  Integer.parseInt(inputFields[4]);
				System.out.println("validateGeneratedNumbers value :::::::::::"+ validateGeneratedNumbers);
				
				System.out.println("i value :::::::::::"+ i);
				String[] badgeNumbers = validateGeneratedNumbers.split(",");
				
				newValue = badgeNumbers[i];
				System.out.println("new  value from string ARRY :::::::::::"+ newValue);
				
					
				}
				
				else {
					if (newValue.equals("PVVCustomerNumber") || newValue.equals("cardNumber")) {
						newValue = validateGeneratedNumbers;
					} else if (newValue.equals("StatementNumber")) {
						newValue = validateGeneratedNumbers;
					} else if (newValue.equals("clientCountry")) {
						if (clientCountryName.equals("MO")) {
							newValue = "MC";
						} else if (clientCountryName.equals("GU")) {
							newValue = "GM";
						} else
							newValue = clientCountryName;
					} else if (newValue.equals("countryCode")) {
						if (clientCountryName.equals("SP")) {
							newValue = "580";
						} else if (clientCountryName.equals("GU")) {
							newValue = "316";
						} else if (clientCountryName.equals("HK") || clientCountryName.equals("MO")) {
							newValue = "344";
						}
					} else if (newValue.contains("ULSDiesel") && clientCountryName.equals("HK")) {
						newValue = "SYNERGY DIESEL";
					}
				}
				System.out.println("newValue : " + newValue);
				readLine = fileLine[lineNumber];
				fileLine[lineNumber] = replaceInFile(readLine, newValue, startPos, endPos);
				logPass(key + ": updated Content is" + fileLine[lineNumber]);
			} catch (NoSuchMethodException ex) {
				System.out.println(ex.getMessage());
			} catch (IllegalAccessException ex) {
				System.out.println(ex.getMessage());
			} catch (InvocationTargetException ex) {
				System.out.println(ex.getMessage());
			} catch (Exception e) {
				System.out.println(e.getMessage());
			}

		}
		String updatedContent = String.join(System.getProperty("line.separator"), fileLine);

		if (inputTemplateFileName.contains("finsta")) {
			updatedContent = updatedContent.replaceAll("\\r\\n", "\n");
		}
		System.out.println("------------------START FILE UPDATE-----------------------------------");
		System.out.println("Updated Content" + updatedContent);
		System.out.println("-------------------END FILE UPDATE----------------------------------");
		fileWriter.write(updatedContent);
		fileWriter.close();
		establishThePuttyConnection(type, "PUTTY_HOST", "PUTTY_USERNAME", "PUTTY_PASSWORD", remoteDir,
				outgoingFileName);
		return verifyUniqueNumber;

	}

	// Validating the OLS Incoming file
	public void validateOLSIncomingFile(Properties cafConfigTemplate, String cardNumber, String remoteDir)
			throws IOException {

		String fileLine[] = readFile(remoteDir);
		String key, value;
		String inputFields[];
		int lineNumber, startPos, endPos;
		String expectedValue, header, readLine, actualValue;

		for (Object k : keys) {
			key = (String) k;
			value = PropUtils.getPropValue(cafConfigTemplate, key);
			inputFields = value.split(",");
			lineNumber = Integer.parseInt(inputFields[0]) - 1;
			startPos = Integer.parseInt(inputFields[1]) - 1;
			endPos = Integer.parseInt(inputFields[2]);
			expectedValue = cardNumber;
			header = inputFields[3];
			readLine = fileLine[lineNumber];
			actualValue = readLine.substring(startPos, endPos);
			System.out.println("Actual Value is" + actualValue);
			System.out.println("Expected Value is " + expectedValue);

			if (actualValue.trim().equals(expectedValue.trim())) {
				logPass(header + ":" + actualValue + "is matched with" + expectedValue);
			} else {
				logFail(header + ":" + actualValue + "is not matched with the" + expectedValue);
			}
		}
	}

	// Update and upload the XML file to IE
	public ArrayList<String> updateValuesAndUploadToXMLFile(Properties properties, String remoteDir,
			String clientCountry, String inputTemplateFileName) throws TransformerException {
		CommonInterfacePage commonInterfacePage = new CommonInterfacePage(driver, test);
		DocumentBuilder dbuilder;
		String getLoadCardStartDate = null;
		String getLoadCardClientMid = null;
		String getFileName = null;
		// String getGSDlocationNo = null;
		ArrayList<String> getGSDlocationNo = new ArrayList<String>();
		String key, value, xmlFilePath, clientName, getLoadCardSeqNo;
		String inputFields[];
		int randomNo;

		clientName = clientCountry.split(" ")[0];

		xmlFilePath = Constants.INPUTFILE_DIR + inputTemplateFileName;
		File xmlFile = new File(xmlFilePath);
		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();

		TransformerFactory transformerFactory = TransformerFactory.newInstance();
		Transformer transformer = transformerFactory.newTransformer();

		try {
			dbuilder = dbFactory.newDocumentBuilder();

			Document doc = dbuilder.parse(xmlFile);
			doc.getDocumentElement().normalize();

			for (Object k : keys) {
				key = (String) k;
				value = PropUtils.getPropValue(properties, key);
				inputFields = value.split(",");

				if (key.equals("Header")) {

					getLoadCardSeqNo = commonInterfacePage.funcFetchLoadCardTransSeqNoFromIFCSDB(configProp,
							clientCountry);
					updateElementValue(doc, key, inputFields[1], getLoadCardSeqNo);

					getLoadCardClientMid = commonInterfacePage.funcFetchLoadCardTransClientMidFromIFCSDB(configProp);
					getFileName = "LoadCardTransactions_" + getLoadCardClientMid + "_" + getLoadCardSeqNo + ".xml";
					updateElementValue(doc, key, inputFields[0], getFileName);

					getLoadCardStartDate = commonInterfacePage.funcFetchLoadCardTransStartDateFromIFCSDB(configProp,
							clientCountry);
					updateElementValue(doc, key, inputFields[2], getLoadCardStartDate);
					updateElementValue(doc, key, inputFields[3], getLoadCardStartDate);

				} else if (key.equals("RetailSite")) {

					String currentTime = getCurrentDateAndTime("yyyyMMdd_HHmmss");
					getFileName = "GSD.APAPC_" + currentTime + ".xml";
					clientCountry = clientCountry.split(" ", 2)[1];
					System.out.println("XML clientCountry inside" + clientCountry);
					getGSDlocationNo.add(
							commonInterfacePage.funcFetchLocationNoFromIFCSDB(configProp, clientCountry, clientName));
					updateElementValue(doc, key, inputFields[0], getGSDlocationNo.get(0));
					updateElementValue(doc, key, inputFields[1], getGSDlocationNo.get(0));

					getLoadCardStartDate = commonInterfacePage.funcFetchLoadCardTransStartDateFromIFCSDB(configProp,
							clientCountry);
					updateElementValue(doc, key, inputFields[2], getLoadCardStartDate);

				} else {

					randomNo = fakerAPI().number().randomDigit();
					updateElementValue(doc, key, inputFields[0], "CZ130" + randomNo);

					updateElementValue(doc, key, inputFields[1], getLoadCardStartDate + "T11:58:14");

					getLoadCardCustomerNumber = commonInterfacePage
							.funcFetchLoadCardTransCustomerNoFromIFCSDB(configProp, clientCountry);
					updateElementValue(doc, key, inputFields[2], getLoadCardCustomerNumber);
				}

			}
			System.out.println("finished the fetch values into DB and update");
			doc.getDocumentElement().normalize();
			DOMSource domSource = new DOMSource(doc);
			System.out.println("get file Name :: :: " + getFileName);

			System.out.println(
					"get file Path ##:: :: " + System.getProperty("user.home") + System.getProperty("file.separator")
							+ "Documents" + System.getProperty("file.separator") + getFileName);
			StreamResult result = new StreamResult(
					new File(System.getProperty("user.home") + System.getProperty("file.separator") + "Documents"
							+ System.getProperty("file.separator") + getFileName));

			transformer.setOutputProperty(OutputKeys.INDENT, "yes");
			transformer.transform(domSource, result);
			System.out.println("Result Local Path" + result);
			System.out.println("XML updated successfully");

			establishThePuttyConnection("outgoingFile", "PUTTY_HOST", "PUTTY_USERNAME", "PUTTY_PASSWORD", remoteDir,
					getFileName);

		} catch (SAXException se) {

			se.printStackTrace();
		} catch (ParserConfigurationException pe) {
			pe.printStackTrace();
		} catch (IOException ie) {
			ie.printStackTrace();
		}
		return getGSDlocationNo;
	}

	/**
	 * Update XML Tag Names.
	 * 
	 * @param doc
	 */
	public static void updateElementValue(Document doc, String parentTagName, String tagName, String fetchData) {
		NodeList users = doc.getElementsByTagName("ns0:" + parentTagName);
		System.out.println("ParentTagName@" + parentTagName);
		System.out.println("ImmediateChildTagName@" + tagName);
		Element user = null;
		Node name;
		System.out.println("Fetch Data :: :: " + fetchData);
		for (int i = 0; i < users.getLength(); i++) {
			user = (Element) users.item(i);
			name = user.getElementsByTagName(tagName).item(0).getFirstChild();
			System.out.println("Fetch Data :: for loop :: " + fetchData);
			name.setNodeValue(fetchData);
		}
	}

	/**
	 * Establish Putty conection.
	 * 
	 * @param doc
	 */
	public void establishThePuttyConnection(String fileAccess, String host, String user, String password,
			String remoteDir, String file) {

		hostName = PropUtils.getPropValue(configProp, host);
		userName = PropUtils.getPropValue(configProp, user);
		passwordPutty = PropUtils.getPropValue(configProp, password);
		remoteDirectory = PropUtils.getPropValue(configProp, remoteDir);

		System.out.println("--- host --- " + hostName + "  ----- user  " + userName + " ----- password ---- "
				+ passwordPutty + " ---- remoteDir ---- " + remoteDirectory + " --- file ---  " + file
				+ " --- fileAccess --- " + fileAccess + "Text:"+encryptText(passwordPutty,"lockUnlock"));
		// logInfo("Remote Dir is establish the Putty Connection"+remoteDir);
		if (!file.contains("NegativeCard")) {
			PuttyUtils.puttyConnection(fileAccess, hostName, userName, passwordPutty, remoteDirectory, file);
			logInfo("Connection established successfully to the " + remoteDirectory);
		} else {
			PuttyUtils.puttyConnection(fileAccess, hostName, userName, passwordPutty, remoteDir, file);
			logInfo("Connection established successfully to the " + remoteDir);
		}

		logInfo(file + " is successfully move to the server");
	}

	// To Generate remote directory path
	public void establishThePuttyConnectionbyUserGeneratedRemoteDirectory(String fileAccess, String host, String user,
			String password, String remoteDir, String file) {

		hostName = PropUtils.getPropValue(configProp, host);
		userName = PropUtils.getPropValue(configProp, user);
		passwordPutty = PropUtils.getPropValue(configProp, password);

		System.out.println("--- host --- " + hostName + "   ---- remoteDir ---- " + remoteDir + " --- file ---  " + file
				+ " --- fileAccess --- " + fileAccess);
		//System.out.println("Putty PWD" + decryptText(passwordPutty,"lockUnlock"));
		// logInfo("Remote Dir is establish the Putty Connection"+remoteDir);
		PuttyUtils.puttyConnection(fileAccess, hostName, userName, decryptText(passwordPutty,"lockUnlock"), remoteDir, file);
		logInfo("Connection established successfully to the " + remoteDir);
		logInfo(file + " is successfully move to the server");
	}

	/**
	 * Map the Contrl-M Folder
	 */

	public String getControlMFolder(String clientName, String clientCountry, String jobKey) {
		String folderName = null, shortFolderName = null, environment = null, shortClientName = null;

		shortClientName = getShortClientName(clientName);

		String FoldersAndJobs = PropUtils.getPropValue(batchJobsallClientsProp, jobKey);

		shortFolderName = FoldersAndJobs.split(":")[0];

		environment = PropUtils.getPropValue(configProp, "environment");

		if (environment.contains("awsemeauat")) {
			environment = "SU1";
		} else if (environment.contains("awsapacuat")) {
			environment = "AU1";
		}

		/*
		 * Add logic for other environments in else if
		 */
		if (jobKey.contains("jobA")) {
			folderName = shortClientName + "ALL" + environment + "-" + shortFolderName;
		} else {
			// Emap -->Guam would be GM in cardEmboss
			if (clientCountry.equals("GU")) {
				clientCountry = "GM";
			}
			folderName = shortClientName + clientCountry + environment + "-" + shortFolderName;
		}
		System.out.println("--- folderName ---- " + folderName);

		return folderName;
	}

	/**
	 * Folder and jobs Mapping Author Anton
	 */

	public String getJobsOfFolderInOrder(String jobKey) {
		String jobsInOrder = null;
		String FoldersAndJobs = PropUtils.getPropValue(batchJobsallClientsProp, jobKey);

		jobsInOrder = FoldersAndJobs.split(":")[1];

		return jobsInOrder;
	}

	/*
	 * Validate data in the CSV file Author Meenakshi Sundaram
	 * 
	 */

	public void validateCSVFormatIncomingFile(Properties configProp, String fileDirectory, String orderedCard) {
		BufferedReader br = null;
		String line = "";
		try {

			br = new BufferedReader(new FileReader(fileDirectory));
			while ((line = br.readLine()) != null) {
				if (line.contains(orderedCard)) {
					logPass("Ordered Card is present in the generated .csv file");
				} else {
					logInfo("Card was not present in the generated .csv file");
				}
			}

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (br != null) {
				try {
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}

	/*
	 * Update the Strings in the file Author anton
	 * 
	 */
	public String replaceInFile(String fullString, String newValue, int startPos, int endPos) {

		String replacedString = null;

		try {
			StringBuilder stringBuilder = new StringBuilder(fullString);

			System.out.println("String :- " + stringBuilder);

			stringBuilder.replace(startPos, endPos, newValue);

			replacedString = stringBuilder.toString();

			System.out.println("After Replace :-  " + replacedString);

			return replacedString;
		} catch (Exception e) {
			System.out.println("Exception caught in replaceInFile --- " + e.getStackTrace());
			return null;
		}
	}

	/*
	 * Validate data in the XML file Author Meenakshi Sundaram
	 * 
	 */

	public void validateIncomingXMLFile(String fileDirectory, String[] orderedCards, String nodeTag,
			String elementTagName) {
		DocumentBuilder dbuilder;
		File xmlFile = new File(fileDirectory);
		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();

		try {
			dbuilder = dbFactory.newDocumentBuilder();

			Document doc = dbuilder.parse(xmlFile);
			doc.getDocumentElement().normalize();

			System.out.println("finished the fetch values into DB and update");

			NodeList nList = doc.getElementsByTagName(nodeTag);
			System.out.println("============================");
			System.out.println("node size-" + nList.getLength());
			System.out.println(" orderedCards length-" + orderedCards.length);
			for (int i = 0; i < orderedCards.length; i++) {
				System.out.println("inside 1stt 1st for statement : " + i);
				for (int temp = 0; temp < nList.getLength(); temp++) {
					System.out.println("inside 1stt 2nd for statement : " + temp);

					Node node = nList.item(temp);
					System.out.println("node size-" + node);
					if (node.getNodeType() == Node.ELEMENT_NODE) {
						Element eElement = (Element) node;
						String xmlFileCardExpected = eElement.getElementsByTagName(elementTagName).item(0)
								.getTextContent();
						System.out.println("First Name : " + xmlFileCardExpected);
						xmlFileCardExpected = xmlFileCardExpected.replaceAll(" ", "");
						System.out.println("After trim First Name : " + xmlFileCardExpected);
						System.out.println("Ordered Cards: " + orderedCards[i]);
						System.out.println("Iteration Matrix Cards: " + "[" + i + "]" + "[" + temp + "]");

						if (orderedCards[i].equals(xmlFileCardExpected)) {

							logPass("Ordered card is present in the generated XML file");
							break;
						} else {
							continue;
						}

					}

				}
			}
		} catch (SAXException se) {
			se.printStackTrace();
		} catch (ParserConfigurationException pe) {
			pe.printStackTrace();
		} catch (IOException ie) {
			ie.printStackTrace();
		}
	}
	
	

	// Raxsana added 26/06/19
	public HashMap<String, String> readKeyAndValueFromPropertyFile(Properties excelInputValuesConfigProp,
			Properties configProp, String accountNumber, String expectedCardType) {
		HashMap<String, String> map = new HashMap<String, String>();
		HashMap<String, Integer> mapInteger = new HashMap<String, Integer>();
		Set<Object> keys = excelInputValuesConfigProp.keySet();
		String clientName = PropUtils.getPropValue(configProp, "clientName");
		String clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		// System.out.println("Keys---->"+ keys);
		int value1;
		for (Object k : keys) {
			boolean faker = false;
			String key = String.valueOf(k);
			// System.out.println("Key-->"+key);
			String value = PropUtils.getPropValue(excelInputValuesConfigProp, key);
			// System.out.println("Value---->"+value);
			if (value.equals("getFakerName")) {

				value = fakerAPI().name().firstName();
				map.put(key, value);
				faker = true;
			} else if (value.equals("getFakerPIN")) {
				value1 = Integer.parseInt(fakerAPI().number().digits(4));
				mapInteger.put(key, value1);
				faker = true;
			} else if (value.equals("getProductRestriction")) {

				if (clientCountry.equals("AU")) {
					map.put(key, "1A FUEL VM SHP C BG O DNR");
					faker = true;
				} else if (clientCountry.equals("NZ")) {
					map.put(key, "All Purchases");
					faker = true;
				}
			} else if (value.contains("func")) {
				value = accountNumber;
				map.put(key, value);
				faker = true;
			} else if (value.equals("getDriverOrVehicleCardTypeValues")) {
				if (expectedCardType.equals("Driver")) {
					SimpleDateFormat formatter = new SimpleDateFormat("YYMMddHHmmss");
					Date date = new Date();
					String currentDate = formatter.format(date);
					map.put("CardType", "Driver");
					map.put("DriverName", fakerAPI().name().firstName() + currentDate);
					map.put("DriverID", "Driver" + fakerAPI().number().digits(4));
					faker = true;
				} else if (expectedCardType.equals("Vehicle")) {
					SimpleDateFormat formatter = new SimpleDateFormat("YYMMmmss");
					Date date = new Date();
					String currentDate = formatter.format(date);
					map.put("CardType", "Vehicle");
					map.put("RegoNumber", currentDate);
					map.put("VehicleDescription", fakerAPI().name().firstName() + currentDate);
					faker = true;
				}

			} else if (value.equals("getFakerPermName")) {
				value = "PermName" + fakerAPI().number().digits(3);
				map.put(key, value);
				faker = true;
			} else if (value.equals("getFakerPermTitle")) {
				value = "PermTitle" + fakerAPI().number().digits(2);
				map.put(key, value);
				faker = true;
			} else if (value.equals("getFakerPermAddress")) {
				value = "PermAddress" + fakerAPI().number().digits(3);
				map.put(key, value);
				faker = true;
			} else if (value.equals("getFakerPermSubAddress")) {
				value = "PermSubAddress" + fakerAPI().number().digits(3);
				map.put(key, value);
				faker = true;
			} else if (value.equals("getFakerPermPostalCode")) {
				value = fakerAPI().number().digits(4);
				map.put(key, value);
				faker = true;
			} else if (value.equals("getFakerPermState")) {
				value = "PermState" + fakerAPI().number().digits(2);
				map.put(key, value);
				faker = true;
			} else if (value.equals("getFakerTempName")) {
				value = "TempName" + fakerAPI().number().digits(3);
				map.put(key, value);
				faker = true;
			} else if (value.equals("getFakerTempTitle")) {
				value = "TempTitle" + fakerAPI().number().digits(2);
				map.put(key, value);
				faker = true;
			} else if (value.equals("getFakerTempAddress")) {
				value = "TempAddress" + fakerAPI().number().digits(3);
				map.put(key, value);
				faker = true;
			} else if (value.equals("getFakerTempSubAddress")) {
				value = "TempSubAddress" + fakerAPI().number().digits(3);
				map.put(key, value);
				faker = true;
			} else if (value.equals("getFakerTempPostalCode")) {
				value = fakerAPI().number().digits(4);
				map.put(key, value);
				faker = true;
			} else if (value.equals("getFakerTempState")) {
				value = "TempState" + fakerAPI().number().digits(2);
				map.put(key, value);
				faker = true;
			} else if (value.equals("getExpiryDate")) {
				Common common = new Common(driver, test);
				String currentIFCSDate = common.getCurrentIFCSDateFromDB(clientName + clientCountry);
				value = common.enterADateValueInStatusBeginDateField("WayFuture", currentIFCSDate);
				map.put(key, value);
				faker = true;
			} else if (faker == false) {
				map.put(key, value);
			}
		}

		return map;

	}

	public void validateXMLFileAndValue(String fileDirectory, String[] eleexpectedValue, String nodeTag,
			String[] elementTagName) {
		DocumentBuilder dbuilder;
		File xmlFile = new File(fileDirectory);
		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		try {
			dbuilder = dbFactory.newDocumentBuilder();

			Document doc = dbuilder.parse(xmlFile);
			doc.getDocumentElement().normalize();

			System.out.println("finished the fetch values into DB and update");

			NodeList nList = doc.getElementsByTagName(nodeTag);
			System.out.println("============================");
			int temp = 0;
			String actualvalue;
			Node nNode = nList.item(temp);
			System.out.println("\nCurrent Element :" + nNode.getNodeName());
			if (nNode.getNodeType() == Node.ELEMENT_NODE) {
				Element eElement = (Element) nNode;
				// for (String eleactualvalue:eleexpectedValue) {
				// for(String elename:eletagname)
				for (int i = 0; i < elementTagName.length; i++) {
					System.out.println(elementTagName[i] + " :"
							+ eElement.getElementsByTagName(elementTagName[i]).item(0).getTextContent());
					actualvalue = eElement.getElementsByTagName(elementTagName[i]).item(0).getTextContent();
					if (actualvalue.equalsIgnoreCase(eleexpectedValue[i])) {
						logPass(elementTagName[i] + "= " + actualvalue + ": Value of element is correct");
					} else {
						softFail(elementTagName[i] + "= " + actualvalue
								+ ": Value of element is not correct ::But Expected Value is = " + eleexpectedValue[i]);
					}
				}
			}
		}

		catch (SAXException se) {
			se.printStackTrace();
		} catch (ParserConfigurationException pe) {
			pe.printStackTrace();
		} catch (IOException ie) {
			ie.printStackTrace();
		} catch (Exception ex) {
			ex.printStackTrace();
		}

	}

	/*
	 * Prakalpha-->09/04/2019 Read DayEnd and MonthEnd Reports from Properties file
	 * and establish Putty Connection and Validate report Present and Move reports
	 * to Local Directory
	 */

	public String establishThePuttyConnectionAndValidationDayAndMonthEndReport(String fileAccess,
			Properties reportPropertyFile, String host, String user, String password, String remoteDir,
			String clientCountry, String clientName) {
		CommonInterfacePage commonInterfacePage = new CommonInterfacePage(driver, test);
		Common common = new Common(driver, test);
		hostName = PropUtils.getPropValue(configProp, host);
		userName = PropUtils.getPropValue(configProp, user);
		passwordPutty = PropUtils.getPropValue(configProp, password);
		List<String> notGeneratedReports = new ArrayList<String>();
		String value = "";

		System.out.println("--- host --- " + hostName + "  ----- user  " + userName + " ----- password ---- "
				+ passwordPutty + " ---- FileAccess ---- " + fileAccess + " ---- remoteDir ---- " + remoteDir);
		// logInfo("Remote Dir is establish the Putty Connection"+remoteDir);

		Set<Object> keys = reportPropertyFile.keySet();
		String key;
		String midNumber;
		String dateIFCS;
		String dbProcessingDate;
		String fileName = "";
		System.out.println("Keys---->" + keys);
		for (Object k : keys) {
			key = String.valueOf(k);
			// System.out.println("Key-->"+key);

			if (reportPropertyFile.contains("dayendreports")) {
				value = PropUtils.getPropValue(reportPropertyFile, key);
				// System.out.println("Value---->"+value);
			} else {
				value = PropUtils.getPropValue(reportPropertyFile, key);
				// System.out.println("Value---->"+value);
			}

			midNumber = commonInterfacePage.funcFetchLoadCardTransClientMidFromIFCSDB(configProp);
			dateIFCS = common.getCurrentIFCSDateFromDB(clientName + clientCountry);
			dbProcessingDate = commonInterfacePage.getreportDateFormat(dateIFCS);
			value = "" + midNumber + "-" + value + " " + dbProcessingDate + "";
			fileName = commonInterfacePage.getRecentProcessedReport(value);
			System.out.println("fileName::" + fileName);
			if (fileName.equals("")) {

				notGeneratedReports.add(value);
				// System.out.println(fileName);
			} else {
				PuttyUtils.puttyConnection(fileAccess, hostName, userName, passwordPutty, remoteDir, fileName);
				logInfo("Connection established successfully to the " + remoteDir);
			}
		}
		if (notGeneratedReports.isEmpty()) {
			logPass("Given Reports are generated");
		} else {
			System.out.println("Not Generated Reports List are : " + notGeneratedReports);
			logFail(notGeneratedReports + " Given reports are not generated");
			logInfo("Some reports are generate based on adding the report in Application");
		}
		return fileName;
	}

	public void validateXMLFileForOneValue(String fileDirectory, String[] eletagname, String[] expvalue, String nodeTag,
			String totalQuantity) {
		DocumentBuilder dbuilder;
		File xmlFile = new File(fileDirectory);
		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		try {
			dbuilder = dbFactory.newDocumentBuilder();

			Document doc = dbuilder.parse(xmlFile);
			doc.getDocumentElement().normalize();
			// String[] eletagname =
			// {"core:ExternalDeliveryReference","core:ExternalProductCode","core:Quantity"};
			// String[] eleexpectedValue = {"0E39S","100000135", "49.69"};
			System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
			NodeList nList = doc.getElementsByTagName(nodeTag);
			System.out.println("----------------------------");
			System.out.println("Number of Record Count:" + nList.getLength());
			int List = nList.getLength();
			for (int temp = 0; temp < List; temp++) {
				Node nNode = nList.item(temp);
				if (nNode.getNodeType() == Node.ELEMENT_NODE) {
					Element eElement = (Element) nNode;

					String actualtagvalue = eElement.getElementsByTagName(eletagname[0]).item(0).getTextContent();
					String actualproductvalue = eElement.getElementsByTagName(eletagname[1]).item(0).getTextContent();
					if (actualtagvalue.trim().equalsIgnoreCase(expvalue[0])
							&& actualproductvalue.trim().equalsIgnoreCase(expvalue[1])) {
						logInfo("Location position in Report:  " + temp);
						logInfo("Location ExternalCode : " + actualtagvalue);
						logInfo("Product Code : " + actualproductvalue);
						String actualvalue = eElement.getElementsByTagName(eletagname[2]).item(0).getTextContent();
						if (actualvalue.trim().equalsIgnoreCase(totalQuantity)) {
							logPass(eletagname[2] + "= " + actualvalue + ": Value of Sum of Quantity is correct");
						} else {
							softFail(eletagname[2] + "= " + actualvalue + ": Value of Sum of Quantity is Incorrect");
							;
						}

						break;
					}
				}

			}
		}

		catch (SAXException se) {
			se.printStackTrace();
		} catch (ParserConfigurationException pe) {
			pe.printStackTrace();
		} catch (IOException ie) {
			ie.printStackTrace();
		} catch (Exception ex) {
			ex.printStackTrace();
		}

	}

	/*
	 * Prakalpha-->09/20/2019 Validate the Expected values present in PDF
	 */
	public void validateReportContent(String fileName, String expectedtext) {
		String localFolder = System.getProperty("user.home") + "\\Documents\\" + fileName;
		if (localFolder.contains(fileName)) {
			String actualtext = PdfUtils.readDocument(localFolder);
			System.out.println("Actual PDF text " + actualtext);
			if (actualtext.contains(expectedtext)) {
				logPass("Actual Value: " + actualtext + " and expected Value: " + expectedtext + " exists in pdf");
			} else {
				logFail("Actual Value: " + actualtext + " expected not exists in pdf");
			}
		} else {
			logFail("FileName " + fileName + " not found");
		}
	}

	// Added by raxsana 28/08/2019

	public void validateDailyReconciliationPDFReport(String fileName) {
		// Loading an existing document
		String pdfFilePathLocal = System.getProperty("user.home") + System.getProperty("file.separator") + "Documents"
				+ System.getProperty("file.separator") + fileName;
		System.out.println("file path local" + pdfFilePathLocal);
		List<String> textFromFile = new ArrayList<String>();
		textFromFile = PdfUtils.getTextPageWise(pdfFilePathLocal, 1, 2);
		System.out.println("textFromFile::" + textFromFile);
		try {
			for (int txt = 0; txt < textFromFile.size(); txt++) {
				String text = textFromFile.get(txt);
				if (text.contains("Reconciled") && !(text.contains("NOT Reconciled"))) {
					String[] str = text.split("\\r?\\n");
					ArrayList<String> textString = new ArrayList<String>();
					// int count = 0;
					for (int i = 0; i < str.length; i++) {
						if ((str[i].contains("OK Variance") || str[i].contains("VarianceOK"))
								&& !(str[i].contains("NOT OK Variance") || str[i].contains("VarianceNOT OK"))) {
							textString.add(str[i]);
							// count++;
						}
					}
					// System.out.println("arrayLists::" + textString);
					// System.out.println("Count::" + count);
					logPass("Report - Reconciled");
				} else {
					// System.out.println("NOT Reconciled");
					softFail("Report - NOT Reconciled");
				}
			}
		} catch (Exception e) {
			e.getMessage();
		}

	}

	/*
	 * Raxsana getting all tagnames and values for Card Sales Aggregate
	 */

	public ConcurrentHashMap<String, String> validateAllTagInXMLForCardSalesAggregate(Map<String, String> valuesFromDB,
			String nodeTag, String fileDirectory) {
		ConcurrentHashMap<String, String> concurrentMap = new ConcurrentHashMap<String, String>();
		for (String map1 : valuesFromDB.keySet()) {
			if (valuesFromDB.get(map1) != null) {
				concurrentMap.put(map1, valuesFromDB.get(map1));
				// System.out.println("afterValue::"+concurrentMap.get(map1));
			}
		}
		System.out.println("concurrentMap::" + concurrentMap);
		for (String map : concurrentMap.keySet()) {
			int flag = 0;
			if (map.equalsIgnoreCase("CUST_EXT_REF")) {
				String elementTagName = "core:ExternalDeliveryReference";
				String obj = concurrentMap.remove(map);
				concurrentMap.put(elementTagName, obj);
				// System.out.println("inside CUST_EXT_REF::"+concurrentMap);
				flag = 1;
			} else if (map.equalsIgnoreCase("THEVALUE")) {
				String elementTagName = "core:Value";
				String obj = concurrentMap.remove(map);
				concurrentMap.put(elementTagName, obj);
				flag = 1;
				// System.out.println("inside THEVALUE::"+concurrentMap);

			}
			if (map.contains("_") && flag == 0) {
				System.out.println("element::" + map);
				char[] delimiters = { ' ', '_' };
				String elementTagName = "core:" + WordUtils.capitalizeFully(map, delimiters).replace("_", "");
				String obj = concurrentMap.remove(map);
				concurrentMap.put(elementTagName, obj);
				// System.out.println("after replace::"+concurrentMap);
			} else if (flag == 0) {
				System.out.println("element::" + map);
				char[] delimiters = { ' ', '_' };
				String elementTagName = "core:" + WordUtils.capitalizeFully(map, delimiters);
				String obj = concurrentMap.remove(map);
				concurrentMap.put(elementTagName, obj);
				// concurrentMap.put(elementTagName, concurrentMap.get(map));
			}
		}
		return concurrentMap;
	}

	/*
	 * Raxsana validate all tagnames and values for Card Sales Aggregate
	 */

	public void validateXMLFileAndValueForCardSalesAggregate(String fileDirectory,
			Map<String, String> eleexpectedKeyAndValue, String nodeTag) {
		try {
			File fXmlFile = new File(fileDirectory);
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(fXmlFile);
			doc.getDocumentElement().normalize();
			int i = 0;
			String[] eletagname = new String[eleexpectedKeyAndValue.size()];
			String[] eleexpectedValue = new String[eleexpectedKeyAndValue.size()];
			for (String elementTagName : eleexpectedKeyAndValue.keySet()) {
				eletagname[i] = elementTagName;
				eleexpectedValue[i] = eleexpectedKeyAndValue.get(elementTagName);
				i++;
			}
			for (int a = 0; a < eleexpectedKeyAndValue.size(); a++) {
				System.out.println("tagnames::" + eletagname[a]);
				System.out.print("tagValues::" + eleexpectedValue[a]);
			}
			System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
			NodeList nList = doc.getElementsByTagName(nodeTag);
			System.out.println("----------------------------");
			System.out.println("Number of Record Count:" + nList.getLength());
			int List = nList.getLength();
			for (int temp = 0; temp < List; temp++) {
				Node nNode = nList.item(temp);
				if (nNode.getNodeType() == Node.ELEMENT_NODE) {
					Element eElement = (Element) nNode;

					String actualtagvalue = eElement.getElementsByTagName(eletagname[1]).item(1).getTextContent();
					// System.out.println(actualtagvalue);

					if (actualtagvalue.trim().equalsIgnoreCase(eleexpectedValue[1])) {
						System.out.println("Location position in Report:  " + temp);
						System.out.println("Location ExternalCode : " + actualtagvalue);
						for (int temp1 = 0; temp1 < eleexpectedValue.length; temp1++) {
							if (!eletagname[temp1].equals("core:ExternalDeliveryReference")) {

								String actualvalue = eElement.getElementsByTagName(eletagname[temp1]).item(0)
										.getTextContent();
								System.out.println("Value of " + eletagname[temp1] + " : " + actualvalue.trim());

								if (actualvalue.trim().equalsIgnoreCase(eleexpectedValue[temp1])) {
									logPass(actualvalue + "is present");

								} else {

									logFail(actualvalue + "is not present");
								}
							}
						}
						break;
					}
				}
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}

	}

	public void validateSuspensePostingReportForTransaction(String fileName, Map<String, String> transactionsDetails) {
		Common common = new Common(driver, test);
		String textFromPdfFile = common.getDataFromLatestDownloadedPdfFile(fileName);
		System.out.println("text from pdf::" + textFromPdfFile);
		String expectedValue = null;
		String customerNo;
		for (String keys : transactionsDetails.keySet()) {
			if (keys.equalsIgnoreCase("Card_no")) {
				customerNo = common.getCustomerNoForCardNumber(transactionsDetails.get(keys));
				expectedValue = transactionsDetails.get(keys) + " " + customerNo + " ";
			}
			if (keys.equalsIgnoreCase("Customer_amount")) {
				if (!(transactionsDetails.get(keys).contains("."))) {
					expectedValue = expectedValue + transactionsDetails.get(keys) + ".00" + " ";
				} else {
					expectedValue = expectedValue + transactionsDetails.get(keys) + " ";
				}
			}
			if (keys.equalsIgnoreCase("Merchant_amount")) {
				if (!(transactionsDetails.get(keys).contains("."))) {
					expectedValue = expectedValue + transactionsDetails.get(keys) + ".00";
				} else {
					expectedValue = expectedValue + transactionsDetails.get(keys);
				}
			}
		}
		System.out.println("Expected value format::" + expectedValue);
		common.validateTheTextRetrievedFromPdfFile(textFromPdfFile, expectedValue);

	}

	public String updateNodeValuesInPayment(String clientCountry, Node node) {
		String getPaymentStartDate = null;
		// String getPaymentClientMid = null;
		String getFileName = null;
		String getPaymentCustomerNumber;
		String getPaymentSeqNo;
		CommonInterfacePage commonInterfacePage = new CommonInterfacePage(driver, test);
		// clientName = PropUtils.getPropValue(configProp, clientName + "_" +
		// clientCountry);

		// clientName = clientCountry.split(" ")[0];
		System.out.println("Node:" + node.getNodeName());
		if ("ns1:FileName".equals(node.getNodeName())) {
			// getPaymentClientMid =
			// commonInterfacePage.funcFetchLoadCardTransClientMidFromIFCSDB(configProp,
			// clientCountry);
			getPaymentSeqNo = commonInterfacePage.funcFetchPaymentSeqNoFromIFCSDB(configProp, clientCountry, "");
			getFileName = "CustomerPayment" + "_" + PropUtils.getPropValue(configProp, "clientCountry") + "_"
					+ getPaymentSeqNo + ".xml";
			System.out.println("File Name in method:" + getFileName);
			node.setTextContent(getFileName);
		} else if ("ns1:SequenceNumber".equals(node.getNodeName())) {
			getPaymentSeqNo = commonInterfacePage.funcFetchPaymentSeqNoFromIFCSDB(configProp, clientCountry, "");
			System.out.println("Seq No:" + getPaymentSeqNo);
			node.setTextContent(getPaymentSeqNo);
		} else if ("ns1:StartDate".equals(node.getNodeName())) {
			getPaymentStartDate = commonInterfacePage.funcFetchLoadCardTransStartDateFromIFCSDB(configProp,
					clientCountry);
			System.out.println("Start Date:" + getPaymentStartDate);
			node.setTextContent(getPaymentStartDate);
		} else if ("ns1:CustomerNumber".equals(node.getNodeName())) {
			getPaymentCustomerNumber = commonInterfacePage.funcFetchPaymentCustomerNoFromIFCSDB(configProp,
					clientCountry);
			System.out.println("Customer No:" + getPaymentCustomerNumber);
			node.setTextContent(getPaymentCustomerNumber);
		} else if ("ns1:PaymentDate".equals(node.getNodeName())) {
			getPaymentStartDate = commonInterfacePage.funcFetchLoadCardTransStartDateFromIFCSDB(configProp,
					clientCountry);
			System.out.println("Payment Date:" + getPaymentStartDate);
			node.setTextContent(getPaymentStartDate);
		}
		return getFileName;
	}

	public void updateValuesInPaymentAndUploadToXMLFile(Properties properties, String remoteDir, String clientCountry,
			String inputTemplateFileName) throws TransformerException {
		String xmlFilePath;
		try {
			xmlFilePath = Constants.INPUTFILE_DIR + inputTemplateFileName;
			File xmlFile = new File(xmlFilePath);
			String fileName = "";

			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			Document doc = docBuilder.parse(xmlFile);

			// Get the root element
			Node root = doc.getFirstChild();

			NodeList list = root.getChildNodes();
			for (int i = 0; i < list.getLength(); i++) {
				System.out.println("Node Selected: 1" + list.item(i).getNodeName());

				NodeList node = list.item(i).getChildNodes();
				System.out.println(node.getLength());
				for (int j = 0; j < node.getLength(); j++) {
					System.out.println("Node Selected: 2" + node.item(j).getNodeName());
					// NodeList childNodes = node.item(j).getChildNodes();
					if ("ns1:FileName".equals(node.item(j).getNodeName())) {
						fileName = updateNodeValuesInPayment(clientCountry, node.item(j));
					} else {
						updateNodeValuesInPayment(clientCountry, node.item(5));
					}
				}
			}
			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer = transformerFactory.newTransformer();
			DOMSource source = new DOMSource(doc);
			StreamResult result = new StreamResult(
					new File(System.getProperty("user.home") + System.getProperty("file.separator") + "Documents"
							+ System.getProperty("file.separator") + fileName));
			transformer.transform(source, result);

			establishThePuttyConnection("XML", "PUTTY_HOST", "PUTTY_USERNAME", "PUTTY_PASSWORD", remoteDir, fileName);
		}

		catch (IOException | ParserConfigurationException | SAXException ie) {
			ie.printStackTrace();
		}
	}

	public ArrayList<String> updateValuesInPaymentXML(String CustomerNum, String clientNameInProp, String clientCountry,
			String PaymentType) throws TransformerException {
		Common common = new Common(driver, test);
		CommonInterfacePage commonInterfacePage = new CommonInterfacePage(driver, test);
		// String clientNameInProp = PropUtils.getPropValue(configProp, clientName + "_"
		// + clientCountry);
		ArrayList<String> RefNumber = new ArrayList<String>();

		String xmlFilePath;
		String remoteDir = null;
		String getFileName = null;
		String getPaymentSeqNo = null;
		String inputTemplateFileName = null;
		String RefNum = common.getUniqReferenceNumber();
		String date = commonInterfacePage.funcFetchLoadCardTransStartDateFromIFCSDB(configProp, clientNameInProp);
		System.out.println("Date value:::::"+date);
		
		String Time = common.getTime();
		String Customer = CustomerNum;
		if (PaymentType.equals("ns0:PaymentDetails")) {
			inputTemplateFileName = "CustomerPayment_" + clientCountry + "_nnnn.xml";
			getPaymentSeqNo = commonInterfacePage.funcFetchPaymentSeqNoFromIFCSDB(configProp, clientNameInProp,
					"RM_G1_0215");
			getFileName = "CustomerPayment_" + clientCountry + "_" + getPaymentSeqNo + ".xml";
			remoteDir = "IE_INPUTFILE_FOLDER_CUSTOMERPAYMENT";
			logInfo("File Name in method:" + getFileName);
		} else if (PaymentType.equals("ns0:DishonorDetails") && clientCountry.equals("AU")) {
			inputTemplateFileName = "ARDishonour_" + clientCountry + "_nnnn.xml";
			getPaymentSeqNo = commonInterfacePage.funcFetchPaymentSeqNoFromIFCSDB(configProp, clientNameInProp,
					"RM_GSD_0165");
			
			System.out.println("Seq number"+ getPaymentSeqNo);
			getFileName = "ARDishonour_" + clientCountry + "_" + getPaymentSeqNo + ".xml";
			remoteDir = "IE_INPUTFILE_FOLDER_AUCUSTOMERDISHONOUR";
			logInfo("File Name in method:" + getFileName);
		} else if (PaymentType.equals("ns0:DishonorDetails") && clientCountry.equals("NZ")) {
			inputTemplateFileName = "ARDishonour_" + clientCountry + "_nnnn.xml";
			getPaymentSeqNo = commonInterfacePage.funcFetchPaymentSeqNoFromIFCSDB(configProp, clientNameInProp,
					"RM_GSD_0173");
			
			System.out.println("Seq number"+ getPaymentSeqNo);
			getFileName = "ARDishonour_" + clientCountry + "_" + getPaymentSeqNo + ".xml";
			remoteDir = "IE_INPUTFILE_FOLDER_NZCUSTOMERDISHONOUR";
			logInfo("File Name in method:" + getFileName);
		}
		System.out.println(remoteDir);
		try {
			xmlFilePath = Constants.INPUTFILE_DIR + inputTemplateFileName;
			File xmlFile = new File(xmlFilePath);
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			Document doc = docBuilder.parse(xmlFile);
			String[] Headertagvalue = { "ns0:Header", PaymentType };
			String[] Paymentdetails = { "ns1:CustomerNumber", "ns1:ReferenceNumber", "ns1:PaymentDate" };
			String[] Header = { "ns1:FileName", "ns1:SequenceNumber", "ns1:StartDate", "ns1:StartTime" };
			System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
			for (String s : Headertagvalue) {
				NodeList nList = doc.getElementsByTagName(s);
				System.out.println(nList.getLength());
				for (int temp = 0; temp < nList.getLength(); temp++) {
					Node nNode = nList.item(temp);
					logInfo("\nCurrent Element :" + nNode.getNodeName());
					Element eElement = (Element) nNode;
					if (nNode.getNodeName().equalsIgnoreCase(PaymentType)) {
						for (int i = 0; i < Paymentdetails.length; i++) {

							String eleName = Paymentdetails[i];
							if (eleName.equalsIgnoreCase("ns1:CustomerNumber")) {
								eElement.getElementsByTagName(Paymentdetails[i]).item(0).setTextContent(Customer);
							} else if (eleName.equalsIgnoreCase("ns1:ReferenceNumber")) {
								eElement.getElementsByTagName(Paymentdetails[i]).item(0).setTextContent(RefNum + temp);
								RefNumber.add(RefNum + temp);
							} else if (eleName.equalsIgnoreCase("ns1:PaymentDate")) {
								eElement.getElementsByTagName(Paymentdetails[i]).item(0).setTextContent(date);
							}

						}
					} else if (nNode.getNodeName().equalsIgnoreCase("ns0:Header")) {
						for (int i = 0; i < Header.length; i++) {

							String eleName = Header[i];
							if (eleName.equalsIgnoreCase("ns1:FileName")) {
								eElement.getElementsByTagName(Header[i]).item(0).setTextContent(getFileName);
							} else if (eleName.equalsIgnoreCase("ns1:SequenceNumber")) {
								eElement.getElementsByTagName(Header[i]).item(0).setTextContent(getPaymentSeqNo);
							} else if (eleName.equalsIgnoreCase("ns1:StartDate")) {
								eElement.getElementsByTagName(Header[i]).item(0).setTextContent(date);
							} else if (eleName.equalsIgnoreCase("ns1:StartTime")) {
								eElement.getElementsByTagName(Header[i]).item(0).setTextContent(Time);
							}
						}
					}
				}
			}

			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer = transformerFactory.newTransformer();
			DOMSource source = new DOMSource(doc);
			StreamResult result = new StreamResult(
					new File(System.getProperty("user.home") + System.getProperty("file.separator") + "Documents"
							+ System.getProperty("file.separator") + getFileName));
			transformer.transform(source, result);

			establishThePuttyConnection("XML", "PUTTY_HOST", "PUTTY_USERNAME", "PUTTY_PASSWORD", remoteDir,
					getFileName);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return RefNumber;
	}

	public String validatePaymentandFee(Properties properties, ArrayList<String> RefNum) {
		String transactionOid;
		String transactionFee;
		float TotalPaymentFee = 0;
		DecimalFormat decimalFormat = new DecimalFormat("#.##");
		int length = RefNum.size();
		String getDBDetailsFromProperties = PropUtils.getPropValue(properties, "sqlODSServerName");
		for (int i = 0; i < length; i++) {
			// TransactionRefNum=RefNum;
			String transactionQuery = "select transaction_oid from transactions where reference='" + RefNum.get(i)
					+ "'";
			System.out.println(transactionQuery);
			transactionOid = connectDBAndGetValue(transactionQuery, getDBDetailsFromProperties);
			System.out.println("----- Transaction Oid -------" + transactionOid);
			if (transactionOid != null) {
				logPass("TransactionOid:" + transactionOid + "Payment Posted Successfully with Ref Number :" + RefNum);
			} else {
				logFail("TransactionOid:" + transactionOid + "Payment not Posted Successfully with Ref Number :"
						+ RefNum);
			}
			String transactionFeeQuery = "select customer_amount from transactions where reference='" + RefNum.get(i)
					+ " (1)Fee'";
			System.out.println(transactionFeeQuery);
			transactionFee = connectDBAndGetValue(transactionFeeQuery, getDBDetailsFromProperties);
			System.out.println(transactionFee);
			if (transactionFee != "") {
				TotalPaymentFee = TotalPaymentFee + Float.parseFloat(transactionFee);
				System.out.println(decimalFormat.format(TotalPaymentFee));
				logPass("TransactionOid:" + transactionOid + "Payment have FEE with Ref Number :" + RefNum
						+ "Payment Fee Amount is :" + transactionFee);
			} else {
				logInfo("TransactionOid:" + transactionOid + "Payment dont have FEE with Ref Number :" + RefNum
						+ "Payment Fee is NULL");
			}
		}
		return (decimalFormat.format(TotalPaymentFee));
	}

	public HashMap<String, String> updateValuescustomeruploadfileXML(String clientNameInProp, String clientCountry)
			throws TransformerException {
		Common common = new Common(driver, test);
		CommonInterfacePage commonInterfacePage = new CommonInterfacePage(driver, test);
		HashMap<String, String> hash_map = new HashMap<String, String>();

		String xmlFilePath;
		String remoteDir = null;
		String getFileName = null;
		String getCA3fileSeqNo = null;
		String inputTemplateFileName = null;
		String RefNum = common.getUniqReferenceNumber();
		String date = commonInterfacePage.funcFetchLoadCardTransStartDateFromIFCSDB(configProp, clientNameInProp);
		String Time = common.getTime();

		if (clientCountry.equals("AU")) {
			inputTemplateFileName = "UpdateCardCust_" + clientCountry + "_nnnn.xml";
			getCA3fileSeqNo = commonInterfacePage.funcFetchPaymentSeqNoFromIFCSDB(configProp, clientNameInProp,
					"RM_GSD_0080");
			getFileName = "UpdateCardCust_" + clientCountry + "_" + getCA3fileSeqNo + ".xml";
			remoteDir = "IE_INPUTFILE_FOLDER_BP_AU_CA3";
			logInfo("File Name in method:" + getFileName);
		} else if (clientCountry.equals("NZ")) {
			inputTemplateFileName = "UpdateCardCust_" + clientCountry + "_nnnn.xml";
			getCA3fileSeqNo = commonInterfacePage.funcFetchPaymentSeqNoFromIFCSDB(configProp, clientNameInProp,
					"RM_GSD_0011");
			getFileName = "UpdateCardCust_" + clientCountry + "_" + getCA3fileSeqNo + ".xml";
			remoteDir = "IE_INPUTFILE_FOLDER_BP_NZ_CA3";
			logInfo("File Name in method:" + getFileName);
		}
		String name = null;

		System.out.println(remoteDir);
		try {
			xmlFilePath = Constants.INPUTFILE_DIR + inputTemplateFileName;
			File xmlFile = new File(xmlFilePath);
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			Document doc = docBuilder.parse(xmlFile);
			String[] Headertagvalue = { "ns2:Header", "ns2:UpdateCardCustomerdetails" };
			String[] Customerdetails = { "ns3:Name", "ns3:TradingName", "ns3:StreetAddressLine",
					"ns3:StreetAddressSuburb", "ns3:PhoneBusiness", "ns3:PhoneFax", "ns3:EmailAddress",
					"ns3:ExternalDeliveryReference" };
			String[] Header = { "ns3:FileName", "ns3:SequenceNumber", "ns3:StartDate", "ns3:StartTime" };
			System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
			for (String s : Headertagvalue) {
				NodeList nList = doc.getElementsByTagName(s);
				System.out.println(nList.getLength());
				for (int temp = 0; temp < nList.getLength(); temp++) {
					Node nNode = nList.item(temp);
					logInfo("\nCurrent Element :" + nNode.getNodeName());
					Element eElement = (Element) nNode;
					if (nNode.getNodeName().equalsIgnoreCase("ns2:UpdateCardCustomerdetails")) {
						for (int i = 0; i < Customerdetails.length; i++) {

							String eleName = Customerdetails[i];
							if (eleName.equalsIgnoreCase("ns3:Name")) {
								name = fakerAPI().name().firstName();
								eElement.getElementsByTagName(Customerdetails[i]).item(0).setTextContent(name);
							} else if (eleName.equalsIgnoreCase("ns3:TradingName")) {
								eElement.getElementsByTagName(Customerdetails[i]).item(0)
										.setTextContent(name + " AUTrade");
							} else if (eleName.equalsIgnoreCase("ns3:StreetAddressLine")) {
								// String addressNumber=fakerAPI().number().digits(3);
								eElement.getElementsByTagName(Customerdetails[i]).item(0)
										.setTextContent(fakerAPI().address().buildingNumber());
							} else if (eleName.equalsIgnoreCase("ns3:StreetAddressSuburb")) {
								eElement.getElementsByTagName(Customerdetails[i]).item(0)
										.setTextContent(fakerAPI().address().streetName());
							} else if (eleName.equalsIgnoreCase("ns3:PhoneBusiness")) {
								eElement.getElementsByTagName(Customerdetails[i]).item(0)
										.setTextContent(fakerAPI().number().digits(10));
							} else if (eleName.equalsIgnoreCase("ns3:PhoneFax")) {
								eElement.getElementsByTagName(Customerdetails[i]).item(0)
										.setTextContent(fakerAPI().number().digits(10));
							} else if (eleName.equalsIgnoreCase("ns3:EmailAddress")) {
								eElement.getElementsByTagName(Customerdetails[i]).item(0)
										.setTextContent(name + "@email.com");
							} else if (eleName.equalsIgnoreCase("ns3:ExternalDeliveryReference")) {
								eElement.getElementsByTagName(Customerdetails[i]).item(0).setTextContent(RefNum + temp);
								// RefNumber.add(RefNum+temp);
								hash_map.put(RefNum + temp, name);
							}

						}
					} else if (nNode.getNodeName().equalsIgnoreCase("ns2:Header")) {
						for (int i = 0; i < Header.length; i++) {

							String eleName = Header[i];
							if (eleName.equalsIgnoreCase("ns3:FileName")) {
								eElement.getElementsByTagName(Header[i]).item(0).setTextContent(getFileName);
							} else if (eleName.equalsIgnoreCase("ns3:SequenceNumber")) {
								eElement.getElementsByTagName(Header[i]).item(0).setTextContent(getCA3fileSeqNo);
							} else if (eleName.equalsIgnoreCase("ns3:StartDate")) {
								eElement.getElementsByTagName(Header[i]).item(0).setTextContent(date);
							} else if (eleName.equalsIgnoreCase("ns3:StartTime")) {
								eElement.getElementsByTagName(Header[i]).item(0).setTextContent(Time);
							}
						}
					}
				}
			}

			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer = transformerFactory.newTransformer();
			DOMSource source = new DOMSource(doc);

			StreamResult result = new StreamResult(
					new File(System.getProperty("user.home") + System.getProperty("file.separator") + "Documents"
							+ System.getProperty("file.separator") + getFileName));
			System.out.println(getFileName);
			transformer.transform(source, result);

			establishThePuttyConnection("XML", "PUTTY_HOST", "PUTTY_USERNAME", "PUTTY_PASSWORD", remoteDir,
					getFileName);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return hash_map;
	}

	public HashMap<String, String> updateLocationfileXML(String clientNameInProp, String clientCountry)
			throws TransformerException {
		Common common = new Common(driver, test);
		CommonInterfacePage commonInterfacePage = new CommonInterfacePage(driver, test);
		HashMap<String, String> hash_map = new HashMap<String, String>();

		String xmlFilePath;
		String remoteDir = null;
		String getFileName = null;
		String getCA10fileSeqNo = null;
		String inputTemplateFileName = null;
		Map<String, String> MerchantDetails = null;
		String date = commonInterfacePage.funcFetchLoadCardTransStartDateFromIFCSDB(configProp, clientNameInProp);
		String Time = common.getTime();

		if (clientCountry.equals("AU")) {
			inputTemplateFileName = "UpdateLocation_" + clientCountry + "_nnnn.xml";
			getCA10fileSeqNo = commonInterfacePage.funcFetchPaymentSeqNoFromIFCSDB(configProp, clientNameInProp,
					"RM_GSD_0081");
			getFileName = "UpdateLocation_" + clientCountry + "_" + getCA10fileSeqNo + ".xml";
			remoteDir = "IE_INPUTFILE_FOLDER_BP_AU_CA10";
			logInfo("File Name in method:" + getFileName);
		} else if (clientCountry.equals("NZ")) {
			inputTemplateFileName = "UpdateLocation_" + clientCountry + "_nnnn.xml";
			getCA10fileSeqNo = commonInterfacePage.funcFetchPaymentSeqNoFromIFCSDB(configProp, clientNameInProp,
					"RM_GSD_0012");
			getFileName = "UpdateLocation_" + clientCountry + "_" + getCA10fileSeqNo + ".xml";
			remoteDir = "IE_INPUTFILE_FOLDER_BP_NZ_CA10";
			logInfo("File Name in method:" + getFileName);
		}
		String getMerchantDetailone = "select m.MERCHANT_NO,m.EXTERNAL_CODE,m.NAME,m.TRADING_NAME,m.TAX_NO,m.PHONE_BUSINESS,m.PHONE_FAX,m.EMAIL_ADDRESS,a.ADDRESS_LINE,a.POSTAL_CODE,a.SUBURB,s.SHORT_DESCRIPTION from M_merchants m\r\n"
				+ "inner join addresses a on a.ADDRESS_OID = m.STREET_ADDRESS_OID\r\n"
				+ "inner join states s on s.state_oid=a.state_oid\r\n"
				+ "where client_mid=(select client_mid from m_clients where name = '" + clientNameInProp
				+ "') and m.EXTERNAL_CODE !='null' and rownum= 1";
		Map<String, String> MerchantOneDetails = connectDBAndGetDBEntireRowValues(getMerchantDetailone,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		String getMerchantDetailTwo = "select m.MERCHANT_NO,m.EXTERNAL_CODE,m.NAME,m.TRADING_NAME,m.TAX_NO,m.PHONE_BUSINESS,m.PHONE_FAX,m.EMAIL_ADDRESS,a.ADDRESS_LINE,a.POSTAL_CODE,a.SUBURB,s.SHORT_DESCRIPTION from M_merchants m\r\n"
				+ "inner join addresses a on a.ADDRESS_OID = m.STREET_ADDRESS_OID\r\n"
				+ "inner join states s on s.state_oid=a.state_oid\r\n" + "where m.MERCHANT_NO !='"
				+ MerchantOneDetails.get("MERCHANT_NO")
				+ "' and client_mid=(select client_mid from m_clients where name = '" + clientNameInProp
				+ "') and m.EXTERNAL_CODE !='null' and rownum= 1";
		Map<String, String> MerchantTwoDetails = connectDBAndGetDBEntireRowValues(getMerchantDetailTwo,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		String getLocationtDetail = "select m.location_no,m.Name,m.external_code,a.ADDRESS_LINE,a.POSTAL_CODE,a.SUBURB,s.SHORT_DESCRIPTION,m.PHONE_BUSINESS,m.PHONE_FAX,m.EMAIL_ADDRESS,m.opened_on,m.closed_on from M_locations m\r\n"
				+ "inner join addresses a on a.ADDRESS_OID = m.STREET_ADDRESS_OID\r\n"
				+ "inner join states s on s.state_oid=a.state_oid\r\n"
				+ "where client_mid=(select client_mid from m_clients where name = '" + clientNameInProp
				+ "') and m.opened_on is not null and  m.external_code is not null";
		Map<String, String> LocationDetails = connectDBAndGetDBEntireRowValues(getLocationtDetail,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		System.out.println(MerchantOneDetails);
		System.out.println(MerchantTwoDetails);
		System.out.println(LocationDetails);
		System.out.println(remoteDir);
		hash_map.put("MerchantOne Number", MerchantOneDetails.get("MERCHANT_NO"));
		hash_map.put("MerchantTwo Number", MerchantTwoDetails.get("MERCHANT_NO"));
		hash_map.put("LocationTwo Number", LocationDetails.get("LOCATION_NO"));

		try {
			xmlFilePath = Constants.INPUTFILE_DIR + inputTemplateFileName;
			File xmlFile = new File(xmlFilePath);
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			Document doc = docBuilder.parse(xmlFile);
			String[] Headertagvalue = { "ns2:Header", "ns2:Merchant", "ns2:Location" };
			String[] Merchant = { "ns3:Name", "ns3:ExternalAccountNumber", "ns3:TradingName", "ns3:TaxNumber",
					"ns3:StreetAddressLine", "ns3:StreetAddressSuburb", "ns3:StreetAddressState",
					"ns3:StreetAddressPostalCode", "ns3:PhoneBusiness", "ns3:PhoneFax", "ns3:EmailAddress" };
			String[] Location = { "ns3:IdassNumber", "ns3:Name", "ns3:ExternalDeliveryReference",
					"ns3:StreetAddressLine", "ns3:StreetAddressSuburb", "ns3:StreetAddressState",
					"ns3:StreetAddressPostalCode", "ns3:PhoneBusiness", "ns3:PhoneFax", "ns3:EmailAddress",
					"ns3:OpenedOn", "ns3:ClosedOn" };
			String[] Header = { "ns3:FileName", "ns3:SequenceNumber", "ns3:StartDate", "ns3:StartTime" };
			System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
			for (String s : Headertagvalue) {
				NodeList nList = doc.getElementsByTagName(s);
				System.out.println(nList.getLength());

				for (int temp = 0; temp < nList.getLength(); temp++) {
					Node nNode = nList.item(temp);
					logInfo("\nCurrent Element :" + nNode.getNodeName());
					Element eElement = (Element) nNode;
					if (nNode.getNodeName().equalsIgnoreCase("ns2:Merchant")) {

						for (int i = 0; i < Merchant.length; i++) {
							if (temp == 0) {
								MerchantDetails = MerchantOneDetails;
							} else if (temp == 1) {
								MerchantDetails = MerchantTwoDetails;
							}
							String eleName = Merchant[i];

							if (eleName.equalsIgnoreCase("ns3:Name") && temp == 1) {
								eElement.getElementsByTagName(Merchant[i]).item(0)
										.setTextContent(fakerAPI().name().firstName() + " MNU");
							} else if (eleName.equalsIgnoreCase("ns3:TradingName") && temp == 1) {
								eElement.getElementsByTagName(Merchant[i]).item(0)
										.setTextContent(fakerAPI().name().firstName() + " MTU");
							} else if (eleName.equalsIgnoreCase("ns3:Name")) {
								eElement.getElementsByTagName(Merchant[i]).item(0)
										.setTextContent(MerchantDetails.get("NAME"));
							} else if (eleName.equalsIgnoreCase("ns3:TradingName")) {
								eElement.getElementsByTagName(Merchant[i]).item(0)
										.setTextContent(MerchantDetails.get("TRADING_NAME"));
							} else if (eleName.equalsIgnoreCase("ns3:StreetAddressLine")) {
								eElement.getElementsByTagName(Merchant[i]).item(0)
										.setTextContent(MerchantDetails.get("ADDRESS_LINE"));
							} else if (eleName.equalsIgnoreCase("ns3:StreetAddressSuburb")) {
								eElement.getElementsByTagName(Merchant[i]).item(0)
										.setTextContent(MerchantDetails.get("SUBURB"));
							} else if (eleName.equalsIgnoreCase("ns3:PhoneBusiness")) {
								eElement.getElementsByTagName(Merchant[i]).item(0)
										.setTextContent(MerchantDetails.get("PHONE_BUSINESS"));
							} else if (eleName.equalsIgnoreCase("ns3:PhoneFax")) {
								eElement.getElementsByTagName(Merchant[i]).item(0)
										.setTextContent(MerchantDetails.get("PHONE_FAX"));
							} else if (eleName.equalsIgnoreCase("ns3:EmailAddress")) {
								eElement.getElementsByTagName(Merchant[i]).item(0)
										.setTextContent(MerchantDetails.get("EMAIL_ADDRESS"));
							} else if (eleName.equalsIgnoreCase("ns3:ExternalAccountNumber")) {
								eElement.getElementsByTagName(Merchant[i]).item(0)
										.setTextContent(MerchantDetails.get("EXTERNAL_CODE"));
							} else if (eleName.equalsIgnoreCase("ns3:StreetAddressState")) {
								eElement.getElementsByTagName(Merchant[i]).item(0)
										.setTextContent(MerchantDetails.get("SHORT_DESCRIPTION"));
							} else if (eleName.equalsIgnoreCase("ns3:TaxNumber")) {
								eElement.getElementsByTagName(Merchant[i]).item(0)
										.setTextContent(MerchantDetails.get("TAX_NO"));
							} else if (eleName.equalsIgnoreCase("ns3:StreetAddressPostalCode")) {
								eElement.getElementsByTagName(Merchant[i]).item(0)
										.setTextContent(MerchantDetails.get("POSTAL_CODE"));
							}

						}
					} else if (nNode.getNodeName().equalsIgnoreCase("ns2:Location")) {

						for (int i = 0; i < Location.length; i++) {

							String eleName = Location[i];
							// System.out.println("Locatiohn"+eleName);

							if (eleName.equalsIgnoreCase("ns3:Name") && temp == 1) {
								// eElement.getElementsByTagName(Location[i]).item(0).setTextContent(LocationDetails.get("NAME")+"
								// UL");
								eElement.getElementsByTagName(Location[i]).item(0)
										.setTextContent(fakerAPI().name().firstName());
							} else if (eleName.equalsIgnoreCase("ns3:Name") && temp == 0) {
								eElement.getElementsByTagName(Location[i]).item(0)
										.setTextContent(fakerAPI().name().firstName());
							}

							else if (eleName.equalsIgnoreCase("ns3:IdassNumber") && temp == 0) {
								String LocationNo = fakerAPI().number().digits(8);
								eElement.getElementsByTagName(Location[i]).item(0).setTextContent(LocationNo);
								hash_map.put("LocationOne Number", LocationNo);
							} else if (eleName.equalsIgnoreCase("ns3:IdassNumber") && temp == 1) {
								eElement.getElementsByTagName(Location[i]).item(0)
										.setTextContent(LocationDetails.get("LOCATION_NO"));
							} else if (eleName.equalsIgnoreCase("ns3:StreetAddressLine") && temp == 0) {
								eElement.getElementsByTagName(Location[i]).item(0)
										.setTextContent(fakerAPI().address().buildingNumber());
							} else if (eleName.equalsIgnoreCase("ns3:StreetAddressLine") && temp == 1) {
								eElement.getElementsByTagName(Location[i]).item(0)
										.setTextContent(fakerAPI().address().buildingNumber());
							} else if (eleName.equalsIgnoreCase("ns3:StreetAddressSuburb") && temp == 0) {
								eElement.getElementsByTagName(Location[i]).item(0)
										.setTextContent(fakerAPI().address().streetName());
							} else if (eleName.equalsIgnoreCase("ns3:StreetAddressSuburb") && temp == 1) {
								eElement.getElementsByTagName(Location[i]).item(0)
										.setTextContent(fakerAPI().address().streetName());
							} else if (eleName.equalsIgnoreCase("ns3:PhoneBusiness") && temp == 0) {
								eElement.getElementsByTagName(Location[i]).item(0)
										.setTextContent(fakerAPI().number().digits(10));
							} else if (eleName.equalsIgnoreCase("ns3:PhoneBusiness") && temp == 1) {
								eElement.getElementsByTagName(Location[i]).item(0)
										.setTextContent(fakerAPI().number().digits(8) + "17");
							} else if (eleName.equalsIgnoreCase("ns3:PhoneFax") && temp == 0) {
								eElement.getElementsByTagName(Location[i]).item(0)
										.setTextContent(fakerAPI().number().digits(10));
							} else if (eleName.equalsIgnoreCase("ns3:PhoneFax") && temp == 1) {
								eElement.getElementsByTagName(Location[i]).item(0)
										.setTextContent(fakerAPI().number().digits(8) + "17");
							} else if (eleName.equalsIgnoreCase("ns3:EmailAddress") && temp == 0) {
								eElement.getElementsByTagName(Location[i]).item(0)
										.setTextContent(fakerAPI().name().firstName() + "@email.com");
							} else if (eleName.equalsIgnoreCase("ns3:EmailAddress") && temp == 1) {
								eElement.getElementsByTagName(Location[i]).item(0)
										.setTextContent(LocationDetails.get("EMAIL_ADDRESS"));
							} else if (eleName.equalsIgnoreCase("ns3:ExternalDeliveryReference") && temp == 0) {
								eElement.getElementsByTagName(Location[i]).item(0)
										.setTextContent(fakerAPI().number().digits(10));
							} else if (eleName.equalsIgnoreCase("ns3:ExternalDeliveryReference") && temp == 1) {
								eElement.getElementsByTagName(Location[i]).item(0)
										.setTextContent(LocationDetails.get("EXTERNAL_CODE"));
							} else if (eleName.equalsIgnoreCase("ns3:StreetAddressState") && temp == 0) {
								eElement.getElementsByTagName(Location[i]).item(0).setTextContent("TAS");
							} else if (eleName.equalsIgnoreCase("ns3:StreetAddressState") && temp == 1) {
								eElement.getElementsByTagName(Location[i]).item(0)
										.setTextContent(LocationDetails.get("SHORT_DESCRIPTION"));
							} else if (eleName.equalsIgnoreCase("ns3:OpenedOn") && temp == 0) {
								eElement.getElementsByTagName(Location[i]).item(0)
										.setTextContent("2000-01-01 00:00:00");
							} else if (eleName.equalsIgnoreCase("ns3:OpenedOn") && temp == 1) {
								eElement.getElementsByTagName(Location[i]).item(0)
										.setTextContent(LocationDetails.get("OPENED_ON"));
							} else if (eleName.equalsIgnoreCase("ns3:StreetAddressPostcode") && temp == 0) {
								eElement.getElementsByTagName(Location[i]).item(0)
										.setTextContent(fakerAPI().number().digits(4));
							} else if (eleName.equalsIgnoreCase("ns3:StreetAddressPostcode") && temp == 1) {
								eElement.getElementsByTagName(Location[i]).item(0)
										.setTextContent(LocationDetails.get("POSTAL_CODE"));
							} else if (eleName.equalsIgnoreCase("ns3:ClosedOn") && temp == 0) {
								eElement.getElementsByTagName(Location[i]).item(0).setTextContent("");
							} else if (eleName.equalsIgnoreCase("ns3:ClosedOn") && temp == 1) {
								eElement.getElementsByTagName(Location[i]).item(0)
										.setTextContent(LocationDetails.get("CLOSED_ON"));
							}
						}
					} else if (nNode.getNodeName().equalsIgnoreCase("ns2:Header")) {
						for (int i = 0; i < Header.length; i++) {

							String eleName = Header[i];
							if (eleName.equalsIgnoreCase("ns3:FileName")) {
								eElement.getElementsByTagName(Header[i]).item(0).setTextContent(getFileName);
							} else if (eleName.equalsIgnoreCase("ns3:SequenceNumber")) {
								eElement.getElementsByTagName(Header[i]).item(0).setTextContent(getCA10fileSeqNo);
							} else if (eleName.equalsIgnoreCase("ns3:StartDate")) {
								eElement.getElementsByTagName(Header[i]).item(0).setTextContent(date);
							} else if (eleName.equalsIgnoreCase("ns3:StartTime")) {
								eElement.getElementsByTagName(Header[i]).item(0).setTextContent(Time);
							}
						}
					}
				}
			}

			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer = transformerFactory.newTransformer();
			DOMSource source = new DOMSource(doc);
			String Filepath = System.getProperty("user.home") + System.getProperty("file.separator") + "Documents"
					+ System.getProperty("file.separator") + getFileName;
			StreamResult result = new StreamResult(
					new File(System.getProperty("user.home") + System.getProperty("file.separator") + "Documents"
							+ System.getProperty("file.separator") + getFileName));
			System.out.println(getFileName);
			transformer.transform(source, result);
			hash_map.put("File Path", Filepath);

			establishThePuttyConnection("XML", "PUTTY_HOST", "PUTTY_USERNAME", "PUTTY_PASSWORD", remoteDir,
					getFileName);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return hash_map;
	}

	public void validateDBandXMLfileValueCA10(String clientNameInProp, HashMap<String, String> resultXMLFile)
			throws TransformerException {
		Common common = new Common(driver, test);

		Map<String, String> MerchantDetails = null;
		Map<String, String> LocationDetails = null;
		String getMerchantDetailone = "select m.MERCHANT_NO,m.EXTERNAL_CODE,m.NAME,m.TRADING_NAME,m.TAX_NO,m.PHONE_BUSINESS,m.PHONE_FAX,m.EMAIL_ADDRESS,a.ADDRESS_LINE,a.POSTAL_CODE,a.SUBURB,s.SHORT_DESCRIPTION from M_merchants m\r\n"
				+ "inner join addresses a on a.ADDRESS_OID = m.STREET_ADDRESS_OID\r\n"
				+ "inner join states s on s.state_oid=a.state_oid\r\n"
				+ "where client_mid=(select client_mid from m_clients where name = '" + clientNameInProp
				+ "') and m.MERCHANT_NO ='" + resultXMLFile.get("MerchantOne Number") + "' and rownum= 1";
		Map<String, String> MerchantOneDetails = connectDBAndGetDBEntireRowValues(getMerchantDetailone,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		String getMerchantDetailTwo = "select m.MERCHANT_NO,m.EXTERNAL_CODE,m.NAME,m.TRADING_NAME,m.TAX_NO,m.PHONE_BUSINESS,m.PHONE_FAX,m.EMAIL_ADDRESS,a.ADDRESS_LINE,a.POSTAL_CODE,a.SUBURB,s.SHORT_DESCRIPTION from M_merchants m\r\n"
				+ "inner join addresses a on a.ADDRESS_OID = m.STREET_ADDRESS_OID\r\n"
				+ "inner join states s on s.state_oid=a.state_oid\r\n"
				+ "where client_mid=(select client_mid from m_clients where name = '" + clientNameInProp
				+ "') and m.MERCHANT_NO ='" + resultXMLFile.get("MerchantTwo Number") + "' and rownum= 1";
		Map<String, String> MerchantTwoDetails = connectDBAndGetDBEntireRowValues(getMerchantDetailTwo,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		String getLocationtDetail = "select m.location_no,m.Name,m.external_code,a.ADDRESS_LINE,a.POSTAL_CODE,a.SUBURB,s.SHORT_DESCRIPTION,m.PHONE_BUSINESS,m.PHONE_FAX,m.EMAIL_ADDRESS,m.opened_on,m.closed_on from M_locations m\r\n"
				+ "inner join addresses a on a.ADDRESS_OID = m.STREET_ADDRESS_OID\r\n"
				+ "inner join states s on s.state_oid=a.state_oid\r\n"
				+ "where client_mid=(select client_mid from m_clients where name = '" + clientNameInProp
				+ "') and m.location_no ='" + resultXMLFile.get("LocationOne Number") + "'";
		Map<String, String> LoactionOneDetails = connectDBAndGetDBEntireRowValues(getLocationtDetail,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		String getLocationtTwoDetail = "select m.location_no,m.Name,m.external_code,a.ADDRESS_LINE,a.POSTAL_CODE,a.SUBURB,s.SHORT_DESCRIPTION,m.PHONE_BUSINESS,m.PHONE_FAX,m.EMAIL_ADDRESS,m.opened_on,m.closed_on from M_locations m\r\n"
				+ "inner join addresses a on a.ADDRESS_OID = m.STREET_ADDRESS_OID\r\n"
				+ "inner join states s on s.state_oid=a.state_oid\r\n"
				+ "where client_mid=(select client_mid from m_clients where name = '" + clientNameInProp
				+ "') and m.location_no ='" + resultXMLFile.get("LocationTwo Number") + "'";
		Map<String, String> LocationtTwoDetail = connectDBAndGetDBEntireRowValues(getLocationtTwoDetail,
				PropUtils.getPropValue(configProp, "sqlODSServerName"));
		System.out.println(MerchantOneDetails);
		System.out.println(MerchantTwoDetails);
		System.out.println(LoactionOneDetails);
		System.out.println(LocationtTwoDetail);

		// System.out.println(remoteDir);
		try {

			File xmlFile = new File(resultXMLFile.get("File Path"));
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			Document doc = docBuilder.parse(xmlFile);
			String[] Headertagvalue = { "ns2:Merchant", "ns2:Location" };
			String[] Merchant = { "ns3:Name", "ns3:ExternalAccountNumber", "ns3:TradingName", "ns3:TaxNumber",
					"ns3:StreetAddressLine", "ns3:StreetAddressSuburb", "ns3:StreetAddressState",
					"ns3:StreetAddressPostalCode", "ns3:PhoneBusiness", "ns3:PhoneFax", "ns3:EmailAddress" };
			String[] Location = { "ns3:IdassNumber", "ns3:Name", "ns3:ExternalDeliveryReference",
					"ns3:StreetAddressLine", "ns3:StreetAddressSuburb", "ns3:StreetAddressState",
					"ns3:StreetAddressPostalCode", "ns3:PhoneBusiness", "ns3:PhoneFax", "ns3:EmailAddress",
					"ns3:OpenedOn", "ns3:ClosedOn" };
			System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
			for (String s : Headertagvalue) {
				NodeList nList = doc.getElementsByTagName(s);
				System.out.println(nList.getLength());

				for (int temp = 0; temp < nList.getLength(); temp++) {
					Node nNode = nList.item(temp);
					logInfo("\nCurrent Element :" + nNode.getNodeName());
					Element eElement = (Element) nNode;
					if (nNode.getNodeName().equalsIgnoreCase("ns2:Merchant")) {

						for (int i = 0; i < Merchant.length; i++) {
							if (temp == 0) {
								MerchantDetails = MerchantOneDetails;
							} else if (temp == 1) {
								MerchantDetails = MerchantTwoDetails;
							}
							String eleName = Merchant[i];

							if (eleName.equalsIgnoreCase("ns3:Name")) {
								common.validateTwoString(MerchantDetails.get("NAME"),
										eElement.getElementsByTagName(Merchant[i]).item(0).getTextContent(),
										"Merchant Name");
							} else if (eleName.equalsIgnoreCase("ns3:TradingName")) {
								common.validateTwoString(MerchantDetails.get("TRADING_NAME"),
										eElement.getElementsByTagName(Merchant[i]).item(0).getTextContent(),
										"Merchant Trade Name");
							} else if (eleName.equalsIgnoreCase("ns3:StreetAddressLine")) {
								common.validateTwoString(MerchantDetails.get("ADDRESS_LINE"),
										eElement.getElementsByTagName(Merchant[i]).item(0).getTextContent(),
										"Merchant ADDRESS LINE");
							} else if (eleName.equalsIgnoreCase("ns3:StreetAddressSuburb")) {
								common.validateTwoString(MerchantDetails.get("SUBURB"),
										eElement.getElementsByTagName(Merchant[i]).item(0).getTextContent(),
										"Merchant SUBURB");
							} else if (eleName.equalsIgnoreCase("ns3:PhoneBusiness")) {
								common.validateTwoString(MerchantDetails.get("PHONE_BUSINESS"),
										eElement.getElementsByTagName(Merchant[i]).item(0).getTextContent(),
										"Merchant Phone Business");
							} else if (eleName.equalsIgnoreCase("ns3:PhoneFax")) {
								common.validateTwoString(MerchantDetails.get("PHONE_FAX"),
										eElement.getElementsByTagName(Merchant[i]).item(0).getTextContent(),
										"Merchant Phone Fax");
							} else if (eleName.equalsIgnoreCase("ns3:EmailAddress")) {
								common.validateTwoString(MerchantDetails.get("EMAIL_ADDRESS"),
										eElement.getElementsByTagName(Merchant[i]).item(0).getTextContent(),
										"Merchant Email");
							} else if (eleName.equalsIgnoreCase("ns3:ExternalAccountNumber")) {
								common.validateTwoString(MerchantDetails.get("EXTERNAL_CODE"),
										eElement.getElementsByTagName(Merchant[i]).item(0).getTextContent(),
										"Merchant External Ref Number");
							} else if (eleName.equalsIgnoreCase("ns3:StreetAddressState")) {
								common.validateTwoString(MerchantDetails.get("SHORT_DESCRIPTION"),
										eElement.getElementsByTagName(Merchant[i]).item(0).getTextContent(),
										"Merchant State");
							} else if (eleName.equalsIgnoreCase("ns3:TaxNumber")) {
								common.validateTwoString(MerchantDetails.get("TAX_NO"),
										eElement.getElementsByTagName(Merchant[i]).item(0).getTextContent(),
										"Merchant Tax no");
							} else if (eleName.equalsIgnoreCase("ns3:StreetAddressPostalCode")) {
								common.validateTwoString(MerchantDetails.get("POSTAL_CODE"),
										eElement.getElementsByTagName(Merchant[i]).item(0).getTextContent(),
										"Merchant Postal code");
							}
						}
					} else if (nNode.getNodeName().equalsIgnoreCase("ns2:Location")) {

						for (int i = 0; i < Location.length; i++) {
							if (temp == 0) {
								LocationDetails = LoactionOneDetails;
							} else if (temp == 1) {
								LocationDetails = LocationtTwoDetail;
							}
							String eleName = Location[i];

							if (eleName.equalsIgnoreCase("ns3:Name")) {
								common.validateTwoString(LocationDetails.get("NAME"),
										eElement.getElementsByTagName(Location[i]).item(0).getTextContent(),
										"Location Name");
							} else if (eleName.equalsIgnoreCase("ns3:IdassNumber")) {
								common.validateTwoString(LocationDetails.get("LOCATION_NO"),
										eElement.getElementsByTagName(Location[i]).item(0).getTextContent(),
										"Location No");
							} else if (eleName.equalsIgnoreCase("ns3:StreetAddressLine")) {
								common.validateTwoString(LocationDetails.get("ADDRESS_LINE"),
										eElement.getElementsByTagName(Location[i]).item(0).getTextContent(),
										"Location ADDRESS_LINE");
							} else if (eleName.equalsIgnoreCase("ns3:StreetAddressSuburb")) {
								common.validateTwoString(LocationDetails.get("SUBURB"),
										eElement.getElementsByTagName(Location[i]).item(0).getTextContent(),
										"Location SUBURB");
							} else if (eleName.equalsIgnoreCase("ns3:PhoneBusiness")) {
								common.validateTwoString(LocationDetails.get("PHONE_BUSINESS"),
										eElement.getElementsByTagName(Location[i]).item(0).getTextContent(),
										"Location PHONE_BUSINESS");
							} else if (eleName.equalsIgnoreCase("ns3:PhoneFax")) {
								common.validateTwoString(LocationDetails.get("PHONE_FAX"),
										eElement.getElementsByTagName(Location[i]).item(0).getTextContent(),
										"Location PHONE_FAX");
							} else if (eleName.equalsIgnoreCase("ns3:EmailAddress")) {
								common.validateTwoString(LocationDetails.get("EMAIL_ADDRESS"),
										eElement.getElementsByTagName(Location[i]).item(0).getTextContent(),
										"Location EMAIL_ADDRESS");
							} else if (eleName.equalsIgnoreCase("ns3:ExternalDeliveryReference")) {
								common.validateTwoString(LocationDetails.get("EXTERNAL_CODE"),
										eElement.getElementsByTagName(Location[i]).item(0).getTextContent(),
										"Location EXTERNAL_CODE");
							} else if (eleName.equalsIgnoreCase("ns3:StreetAddressState")) {
								common.validateTwoString(LocationDetails.get("SHORT_DESCRIPTION"),
										eElement.getElementsByTagName(Location[i]).item(0).getTextContent(),
										"Location SHORT_DESCRIPTION");
							} else if (eleName.equalsIgnoreCase("ns3:OpenedOn")) {
								common.validateTwoString(LocationDetails.get("OPENED_ON"),
										eElement.getElementsByTagName(Location[i]).item(0).getTextContent(),
										"Location OPENED_ON");
							} else if (eleName.equalsIgnoreCase("ns3:StreetAddressPostcode")) {
								common.validateTwoString(LocationDetails.get("POSTAL_CODE"),
										eElement.getElementsByTagName(Location[i]).item(0).getTextContent(),
										"Location POSTAL_CODE");
							} else if (eleName.equalsIgnoreCase("ns3:ClosedOn")) {
								common.validateTwoString(LocationDetails.get("CLOSED_ON"),
										eElement.getElementsByTagName(Location[i]).item(0).getTextContent(),
										"Location CLOSED_ON");
							}
						}
					}

				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	// Raxsana
	public void validateCustomerReports(String fileNamePath, String cusNum, String ifcsDate) {
		String textFromFile = null;
		String expectedString, expectedString1;
		Common common = new Common(driver, test);
		Date date = null;
		try {
			date = new SimpleDateFormat("dd/MM/yyyy").parse(ifcsDate);
		} catch (java.text.ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String changedDateFormat = getDateInFormat(date, "MMM-YY");
		System.out.println("::::" + changedDateFormat);
		if (fileNamePath.contains("Tax Invoice Detail")) {
			textFromFile = PdfUtils.readDocument(fileNamePath);
			System.out.println("text from file::" + textFromFile);
			String value = common.getCardNumberForCustomerReports(cusNum, changedDateFormat);
			System.out.println("all values::" + value);
			String expectedValue = value + "\r\n" + "PAYMENT DUE";
			common.validateTheTextRetrievedFromPdfFile(textFromFile, expectedValue);
			String expectedValue1 = "The amount of $" + value + " will be direct debited to your Bank account";
			common.validateTheTextRetrievedFromPdfFile(textFromFile, expectedValue1);

		} else if (fileNamePath.contains("Card Management Report")) {
			Map<String, String> val = common.getCardNumberForCardTransactionReport(cusNum, changedDateFormat);
			textFromFile = PdfUtils.readDocument(fileNamePath);
			System.out.println("text from file::" + textFromFile);
			for (String keyVal : val.keySet()) {
				common.validateTheTextRetrievedFromPdfFile(textFromFile, keyVal);
			}
		} else if (fileNamePath.contains("Card Transaction Report")) {
			Map<String, String> val = common.getCardNumberForCardTransactionReport(cusNum, changedDateFormat);
			int size = PdfUtils.getNumberOfPages(fileNamePath);
			for (int i = 1; i <= size; i++) {
				for (String keyVal : val.keySet()) {
					textFromFile = PdfUtils.getTextFromExpectedPage(fileNamePath, i);
					expectedString = keyVal + "Card Number:";
					/* System.out.println("expectedString::"+expectedString); */
					if (textFromFile.contains(expectedString)) {
						expectedString1 = "CARD TOTAL " + val.get(keyVal);
						/* System.out.println("expectedString1::"+expectedString1); */
						common.validateTheTextRetrievedFromPdfFile(textFromFile, expectedString1);
					}
				}

			}

		}

	}

	public void validateMerchantStatementReports(String fileNamePath, String locationNo, String ifcsDate) {
		Common common = new Common(driver, test);
		String textFromFile;
		String expectedString = "";
		System.out.println("ifcsDate::" + ifcsDate);
		Date date = null;
		try {
			date = new SimpleDateFormat("dd/MM/yyyy").parse(ifcsDate);
		} catch (java.text.ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String changedDateFormat = getDateInFormat(date, "MMM-YY");
		System.out.println("::::" + changedDateFormat);

		Map<String, String> merchantTransactionDetails = new HashMap<String, String>();
		merchantTransactionDetails = common.getMerchantStatementAmount(locationNo, changedDateFormat.toUpperCase());
		String merchantAmount = merchantTransactionDetails.get("SUM(MERCHANT_VALUE)").toString();
		String merchantServiceFeeTotal = merchantTransactionDetails.get("SUM(MERCHANT_SERVICE_FEE_TOTAL)").toString();
		String originalValue = merchantTransactionDetails.get("SUM(ORIGINAL_VALUE)").toString();
		String merchantReimbuseAdjust = merchantTransactionDetails.get("SUM(MERCHANT_REIMBUSE_ADJUST)").toString();
		String merchantServiceFeeAdjust = merchantTransactionDetails.get("SUM(MERCHANT_SERVICE_FEE_ADJUST)").toString();
		Double value = Double.parseDouble(originalValue) - Double.parseDouble(merchantReimbuseAdjust);
		System.out.println("value::" + value);
		Double value1 = Double.parseDouble(merchantServiceFeeTotal) + Double.parseDouble(merchantServiceFeeAdjust);
		System.out.println("value1::" + value1);
		Double value2 = (value + value1);
		BigDecimal bigDecimal = new BigDecimal(value2);
		bigDecimal = bigDecimal.setScale(2, BigDecimal.ROUND_HALF_UP);
		bigDecimal.doubleValue();
		System.out.println("value2::" + bigDecimal.doubleValue());
		if (bigDecimal.doubleValue() == Double.parseDouble(merchantAmount)) {
			if (fileNamePath.contains("Merchant Statement")) {
				textFromFile = PdfUtils.getTextFromExpectedPage(fileNamePath, 3);
				System.out.println("text from file::" + textFromFile);
				int size = locationNo.length();
				String locNo = "";
				for (int i = size / 2; i < size; i++) {
					char LocChar = locationNo.charAt(i);
					locNo = locNo + LocChar;
				}
				if (!(merchantAmount.contains("."))) {
					expectedString = "$" + merchantAmount + "\r\n" + "Summary" + locNo;
				}
				System.out.println("expected String::" + expectedString);
				common.validateTheTextRetrievedFromPdfFile(textFromFile, expectedString);
			} else if (fileNamePath.contains("Merchant RCTI")) {
				textFromFile = PdfUtils.getTextFromExpectedPage(fileNamePath, 1);
				System.out.println("text from file::" + textFromFile);
				double expectedString1;
				expectedString1 = value;
				DecimalFormat decimalFormat = new DecimalFormat("#.##");
				decimalFormat.setGroupingUsed(true);
				decimalFormat.setGroupingSize(3);
				System.out.println(decimalFormat.format(expectedString1));
				common.validateTheTextRetrievedFromPdfFile(textFromFile,
						"$" + String.valueOf(decimalFormat.format(expectedString1)));
				System.out.println("expected String::" + decimalFormat.format(value1));
				common.validateTheTextRetrievedFromPdfFile(textFromFile,
						String.valueOf(decimalFormat.format(value1)).replace("-", "-$"));
			}
		} else {
			logFail("Merchant Statement values not correct");
		}
	}

	public void validateCardsfromCAFCHV(String Country, String fileNamePath, Map<String, String> CustCard) {
		try {
			String CardNumber;
			String AccountNumber;
			FileInputStream fstream = new FileInputStream(fileNamePath);
			BufferedReader br = new BufferedReader(new InputStreamReader(fstream));
			String strLine = br.readLine();
			for (Map.Entry<String, String> e : CustCard.entrySet()) {
				String cusNum = e.getKey();
				String CardNum = e.getValue();
				while ((strLine = br.readLine()) != null) {
					if (Country.equalsIgnoreCase("MY")) {
						CardNumber = strLine.substring(4, 22);
						AccountNumber = strLine.substring(165, 171);
					}
					CardNumber = strLine.substring(1, 19);
					AccountNumber = strLine.substring(253, 263);
					if (CardNumber.trim().equals(CardNum) && AccountNumber.trim().equals(cusNum)) {
						logInfo("CardNUmber:" + CardNumber + "  &&  AccNUmber:" + AccountNumber);
						logPass("Cardordered successfully and Verfied in CAF");
						break;
					}
				}
			}

			fstream.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void postManualPayments(String accountNumber, String paymentType, String ClientandCountry) {
		Common common = new Common(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		CommonInterfacePage commonInterfacePage = new CommonInterfacePage(driver, test);
		String clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		
		if (ClientandCountry.contains("EMAP"))
			IFCSHomePage.gotoTransactionAndClickPayment();
		else
			IFCSHomePage.gotoTransactionAndClickManualPayment();
		
		enterValueInTextBox("Manual Payment", "Account No", accountNumber);
		chooseOptionFromDropdown("Type", paymentType);
		String clientNameInProp = PropUtils.getPropValue(configProp, ClientandCountry).trim().toString();
		logInfo("client name::" + clientNameInProp);
		String date = commonInterfacePage.funcFetchLoadCardTransStartDateFromIFCSDB(configProp, clientNameInProp);
		logInfo("date::" + date);
		Date dateFormat = null;
		String dateFormatted = "";
		try {
			DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
			dateFormat = df.parse(date);
			// dateFormat1 = new SimpleDateFormat("dd/MM/yyyy").parse(processingDate);
			logInfo("Date Format" + dateFormat);
			dateFormatted = new SimpleDateFormat("dd/MM/yyyy").format(dateFormat);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		enterValueInTextBox("Manual Payment", "Effective Date", dateFormatted);
		String amount = fakerAPI().number().digits(2);
		enterValueInTextBox("Manual Payment", "Amount", amount);
		sleep(3);
		String refNo = clientNameInProp + clientCountry + fakerAPI().number().digits(3);
		enterValueInTextBox("Manual Payment", "Reference No", refNo);
		sleep(3);
		common.clickValidateIcon();
		verifyValidationResult("Validation successful");
		sleep(3);
		common.clickPostTransaction();
		verifyValidationResult("Record saved OK");

		IFCSHomePage.gotoTransactionAndClickManageTransaction();
		chooseSubMenuFromLeftPanel("Client Transactions", "Transactions");

		enterValueInTextBox("Transaction Filter Fields", "Process Date From", dateFormatted);
		enterValueInTextBox("Transaction Filter Fields", "Reference No", refNo);
		common.searchListTorch();

		common.validateSearchTable("Ref", refNo, true);
		common.writeDataInPropertyFile(paymentType.replaceAll(" ", "").replace("-", "_") + "_" + accountNumber + "_"
				+ refNo + "_" + clientCountry, amount, "chevronEndToEndTemplateFile.Properties");
	}
	
	
	public void postManualPaymentsByDD(String accountNumber, String paymentType, String ClientandCountry) {
		Common common = new Common(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		CommonInterfacePage commonInterfacePage = new CommonInterfacePage(driver, test);
		String clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		IFCSHomePage.gotoTransactionAndClickManualPayment();
		enterValueInTextBox("Manual Payment", "Account No", accountNumber);
		if (ClientandCountry.contains("HK")|| ClientandCountry.contains("MY"))
		chooseOptionContainsFromDropdown("Type", "DDeposit");
		else if (ClientandCountry.contains("PH") || ClientandCountry.contains("SG")||ClientandCountry.contains("TH"))
			chooseOptionContainsFromDropdown("Type", "Direct Deposit");
		
		String clientNameInProp = PropUtils.getPropValue(configProp, ClientandCountry).trim().toString();
		logInfo("client name::" + clientNameInProp);
		String date = commonInterfacePage.funcFetchLoadCardTransStartDateFromIFCSDB(configProp, clientNameInProp);
		logInfo("date::" + date);
		Date dateFormat = null;
		String dateFormatted = "";
		try {
			DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
			dateFormat = df.parse(date);
			// dateFormat1 = new SimpleDateFormat("dd/MM/yyyy").parse(processingDate);
			logInfo("Date Format" + dateFormat);
			dateFormatted = new SimpleDateFormat("dd/MM/yyyy").format(dateFormat);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		enterValueInTextBox("Manual Payment", "Effective Date", dateFormatted);
		String amount = fakerAPI().number().digits(2);
		enterValueInTextBox("Manual Payment", "Amount", amount);
		sleep(3);
		String refNo = clientNameInProp + clientCountry + fakerAPI().number().digits(3);
		enterValueInTextBox("Manual Payment", "Reference No", refNo);
		sleep(3);
		common.clickValidateIcon();
		verifyValidationResult("Validation successful");
		sleep(3);
		common.clickPostTransaction();
		verifyValidationResult("Record saved OK");

		IFCSHomePage.gotoTransactionAndClickManageTransaction();
		chooseSubMenuFromLeftPanel("Client Transactions", "Transactions");

		enterValueInTextBox("Transaction Filter Fields", "Process Date From", dateFormatted);
		enterValueInTextBox("Transaction Filter Fields", "Reference No", refNo);
		common.searchListTorch();

		common.validateSearchTable("Ref", refNo, true);
		common.writeDataInPropertyFile(paymentType.replaceAll(" ", "").replace("-", "_") + "_" + accountNumber + "_"
				+ refNo + "_" + clientCountry, amount, "chevronEndToEndTemplateFile.Properties");
	}


	public String returnCashCardNumCHV(String message) {
		String CardNum = null;
		try {

			String[] splited = message.split("\\s+");
			System.out.println(splited);
			CardNum = splited[1];
		}

		catch (Exception e) {
			e.printStackTrace();
		}
		return CardNum;
	}

	public void validateCardsEmbossEMBACHV(String Country, String fileNamePath, Map<String, String> CustCard) {
		try {
			String CardNumber;
			String AccountNumber;
			FileInputStream fstream = new FileInputStream(fileNamePath);
			BufferedReader br = new BufferedReader(new InputStreamReader(fstream));
			String strLine = br.readLine();
			for (Map.Entry<String, String> e : CustCard.entrySet()) {
				String cusNum = e.getKey();
				String CardNum = e.getValue();
				while ((strLine = br.readLine()) != null) {
					if (Country.equalsIgnoreCase("MY")) {
						CardNumber = strLine.substring(4, 22);
						AccountNumber = strLine.substring(165, 171);
					}
					CardNumber = strLine.substring(1, 19);
					AccountNumber = strLine.substring(253, 263);
					if (CardNumber.trim().equals(CardNum) && AccountNumber.trim().equals(cusNum)) {
						logInfo("CardNUmber:" + CardNumber + "  &&  AccNUmber:" + AccountNumber);
						logPass("Cardordered successfully and Verfied in CAF");
						break;
					}
				}
			}

			fstream.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void validateGLVarianceCHV(String filePath, String sheetName) {
		try {
			Sheet sheet = ExcelUtils.readExcel(filePath, sheetName);
			int lastRow = sheet.getLastRowNum();
			Row row = sheet.getRow(lastRow);
			Cell cell = row.getCell(24);
			double value = cell.getNumericCellValue();
			BigDecimal valuetwodigit = new BigDecimal(value).setScale(2, RoundingMode.DOWN);
			System.out.println(valuetwodigit);
			String GlValue = valuetwodigit.toString();
			if (GlValue.equals("0.00")) {
				logPass("GL Varience displaying correctly");
			} else {
				logFail("GL Varience not displaying correctly");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// Prakalpha-->chevron loadCard Transaction
	public HashMap<String, String> updateValuesInLoadCardTransactionXMLForChevron_SG(Map<String, String> cardNumValue,
			Map<String, String> Locationvalue, String clientNameInProp, String clientCountry) {
		Common common = new Common(driver, test);
		CommonInterfacePage commonInterfacePage = new CommonInterfacePage(driver, test);
		HashMap<String, String> hash_map = new HashMap<String, String>();
		// ArrayList<String> RefNumber = new ArrayList<String>();
		String xmlFilePath;
		String remoteDir = null;
		String getFileName = null;
		String loadCardTransactionSeqNo = null;
		String inputTemplateFileName = null;
		String RefNum = common.getUniqReferenceNumber();
		String referenceNumber = null;
		String cardNo = "";
		System.out.println("Ref No::" + RefNum);
		String date = commonInterfacePage.funcFetchLoadCardTransStartDateFromIFCSDB(configProp, clientNameInProp);
		System.out.println("Date::" + date);
		// String Time = common.getTime();
		String client_mid = commonInterfacePage.funcFetchLoadCardTransClientMidFromIFCSDB(configProp);
		System.out.println("client_mid ::" + client_mid);
		loadCardTransactionSeqNo = commonInterfacePage.funcFetchPaymentSeqNoFromIFCSDB(configProp, clientNameInProp,
				"LoadCardTransactions");
		inputTemplateFileName = "LoadCardTransaction_CHV_" + clientCountry + "_nnnn.xml";
		getFileName = "LoadCardTransactions_" + client_mid + "_" + loadCardTransactionSeqNo + ".xml";
		System.out.println("get File name::" + getFileName);
		remoteDir = "IFCS_INPUTFILE_FOLDER_LOADCARDTRANSACTION_CHV_SG";
		logInfo("File Name in method:" + getFileName);
		System.out.println(remoteDir);
		try {
			xmlFilePath = Constants.INPUTFILE_DIR + inputTemplateFileName;
			File xmlFile = new File(xmlFilePath);
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			Document doc = docBuilder.parse(xmlFile);
			String[] Headertagvalue = { "ns2:Header", "ns2:LoadCardTransaction" };
			String[] TransactionDetails = { "ns0:ReferenceNumber", "ns0:TransactionDateTime", "ns0:RetailSiteId",
					"ns0:IdassNumber", "ns0:TransactionCode", "ns0:CardNumber" };
			String[] Header = { "ns0:FileName", "ns0:SequenceNumber", "ns0:StartDate", "ns0:SettlementDate" };
			System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
			for (String s : Headertagvalue) {
				NodeList nList = doc.getElementsByTagName(s);
				System.out.println("length of nList::" + nList.getLength());
				for (int temp = 0; temp < nList.getLength(); temp++) {
					Node nNode = nList.item(temp);
					logInfo("\nCurrent Element :" + nNode.getNodeName());
					Element eElement = (Element) nNode;
					if (nNode.getNodeName().equalsIgnoreCase("ns2:LoadCardTransaction")) {

						for (int i = 0; i < TransactionDetails.length; i++) {
							String eleName = TransactionDetails[i];

							if (eleName.equalsIgnoreCase("ns0:ReferenceNumber")) {
								referenceNumber = RefNum + temp;

								eElement.getElementsByTagName(TransactionDetails[i]).item(0)
										.setTextContent(referenceNumber);

								System.out.println("ReferenceNumber::" + referenceNumber);
							} else if (eleName.equalsIgnoreCase("ns0:TransactionDateTime")) {
								eElement.getElementsByTagName(TransactionDetails[i]).item(0)
										.setTextContent(date + "T00:00:08");
								System.out.println("TransactionDateTime:::" + date);
							} else if (eleName.equalsIgnoreCase("ns0:RetailSiteId")) {
								eElement.getElementsByTagName(TransactionDetails[i]).item(0)
										.setTextContent(Locationvalue.get("Location_no_SG"));
								System.out.println("RetailSiteId:::" + Locationvalue.get("Location_No_SG"));
							} else if (eleName.equalsIgnoreCase("ns0:IdassNumber")) {
								eElement.getElementsByTagName(TransactionDetails[i]).item(0)
										.setTextContent(Locationvalue.get("Location_no_SG"));
								System.out.println("IdassNumber:::" + Locationvalue.get("Location_No_SG"));
							}

							else if (eleName.equalsIgnoreCase("ns0:TransactionCode") && temp == 0) {
								if (eElement.getElementsByTagName(TransactionDetails[i]).item(0).getTextContent()
										.equalsIgnoreCase("CW001")) {

									eElement.getElementsByTagName("ns0:CardNumber").item(0)
											.setTextContent(cardNumValue.get("cardNo_StarCard_Affinity_SG"));
									cardNo = cardNumValue.get("cardNo_StarCard_Affinity_SG");
									hash_map.put("RefNo_StarCard_Affinity_SG_CW001_" + cardNo, referenceNumber);
									common.writeDataInPropertyFile("RefNo_StarCard_Affinity_SG_CW001_" + cardNo,
											referenceNumber, "chevronEndToEndTemplateFile.properties");
								}
							} else if (eleName.equalsIgnoreCase("ns0:TransactionCode") && temp == 1) {
								if (eElement.getElementsByTagName(TransactionDetails[i]).item(0).getTextContent()
										.equalsIgnoreCase("CW002")) {
									System.out.println("CW002 loop inside");

									eElement.getElementsByTagName("ns0:CardNumber").item(0)
											.setTextContent(cardNumValue.get("cardNo_StarCard_Affinity_SG"));
									cardNo = cardNumValue.get("cardNo_StarCard_Affinity_SG");
									hash_map.put("RefNo_StarCard_Affinity_SG_CW002_" + cardNo, referenceNumber);
									common.writeDataInPropertyFile("RefNo_StarCard_Affinity_SG_CW002_" + cardNo,
											referenceNumber, "chevronEndToEndTemplateFile.properties");
								}
							} else if (eleName.equalsIgnoreCase("ns0:TransactionCode") && temp == 2) {
								if (eElement.getElementsByTagName(TransactionDetails[i]).item(0).getTextContent()
										.equalsIgnoreCase("CW003")) {
									System.out.println("CW003 loop inside");

									eElement.getElementsByTagName("ns0:CardNumber").item(0)
											.setTextContent(cardNumValue.get("cardNo_StarCard_Staff_SG"));
									cardNo = cardNumValue.get("cardNo_StarCard_Staff_SG");
									hash_map.put("RefNo_StarCard_Staff_SG_CW003_" + cardNo, referenceNumber);
									common.writeDataInPropertyFile("RefNo_StarCard_Staff_SG_CW003_" + cardNo,
											referenceNumber, "chevronEndToEndTemplateFile.properties");
								}
							} else if (eleName.equalsIgnoreCase("ns0:TransactionCode") && temp == 3) {
								if (eElement.getElementsByTagName(TransactionDetails[i]).item(0).getTextContent()
										.equalsIgnoreCase("CW004")) {
									System.out.println("CW004 loop inside");

									eElement.getElementsByTagName("ns0:CardNumber").item(0)
											.setTextContent(cardNumValue.get("cardNo_StarCard_Staff_SG"));
									cardNo = cardNumValue.get("cardNo_StarCard_Staff_SG");
									hash_map.put("RefNo_StarCard_Staff_SG_CW004_" + cardNo, referenceNumber);
									common.writeDataInPropertyFile("RefNo_StarCard_Staff_SG_CW004_" + cardNo,
											referenceNumber, "chevronEndToEndTemplateFile.properties");
								}
							} else if (eleName.equalsIgnoreCase("ns0:TransactionCode") && temp == 4) {

								if (eElement.getElementsByTagName(TransactionDetails[i]).item(0).getTextContent()
										.equalsIgnoreCase("4000")) {
									System.out.println("4000 loop inside");
									eElement.getElementsByTagName("ns0:CardNumber").item(0)
											.setTextContent(cardNumValue.get("cardNo_DiscountCard_Taxi_SG"));
									cardNo = cardNumValue.get("cardNo_DiscountCard_Taxi_SG");
									hash_map.put("RefNo_DiscountCard_Taxi_SG_4000_" + cardNo, referenceNumber);
									common.writeDataInPropertyFile("RefNo_DiscountCard_Taxi_SG_4000_" + cardNo,
											referenceNumber, "chevronEndToEndTemplateFile.properties");
								}
							} else if (eleName.equalsIgnoreCase("ns0:TransactionCode") && temp == 5) {
								if (eElement.getElementsByTagName(TransactionDetails[i]).item(0).getTextContent()
										.equalsIgnoreCase("4100")) {
									System.out.println("4100 loop inside");

									eElement.getElementsByTagName("ns0:CardNumber").item(0)
											.setTextContent(cardNumValue.get("cardNo_DiscountCard_Taxi_SG"));
									cardNo = cardNumValue.get("cardNo_DiscountCard_Taxi_SG");
									hash_map.put("RefNo_DiscountCard_Taxi_SG_4100_" + cardNo, referenceNumber);
									common.writeDataInPropertyFile("RefNo_DiscountCard_Taxi_SG_4100_" + cardNo,
											referenceNumber, "chevronEndToEndTemplateFile.properties");
								}
							} else if (eleName.equalsIgnoreCase("ns0:TransactionCode") && temp == 6) {

								if (eElement.getElementsByTagName(TransactionDetails[i]).item(0).getTextContent()
										.equalsIgnoreCase("CW001")) {
									System.out.println("3nd CW001 loop inside");
									eElement.getElementsByTagName("ns0:CardNumber").item(0)
											.setTextContent(cardNumValue.get("cardNo_StarCard_Personal_SG"));
									cardNo = cardNumValue.get("cardNo_StarCard_Personal_SG");
									hash_map.put("RefNo_StarCard_Personal_SG_CW001_" + cardNo, referenceNumber);
									common.writeDataInPropertyFile("RefNo_StarCard_Personal_SG_CW001_" + cardNo,
											referenceNumber, "chevronEndToEndTemplateFile.properties");
								}

							} else if (eleName.equalsIgnoreCase("ns0:TransactionCode") && temp == 7) {
								if (eElement.getElementsByTagName(TransactionDetails[i]).item(0).getTextContent()
										.equalsIgnoreCase("CW001")) {
									System.out.println("2nd CW001 loop inside");
									eElement.getElementsByTagName("ns0:CardNumber").item(0)
											.setTextContent(cardNumValue.get("cardNo_StarCard_Fleet_SG"));
									cardNo = cardNumValue.get("cardNo_StarCard_Fleet_SG");
									hash_map.put("RefNo_StarCard_Fleet_SG_CW001_" + cardNo, referenceNumber);
									common.writeDataInPropertyFile("RefNo_StarCard_Fleet_SG_CW001_" + cardNo,
											referenceNumber, "chevronEndToEndTemplateFile.properties");
								}
							} else if (eleName.equalsIgnoreCase("ns0:TransactionCode") && temp == 8) {
								if (eElement.getElementsByTagName(TransactionDetails[i]).item(0).getTextContent()
										.equalsIgnoreCase("4000")) {
									System.out.println("2nd 4000 loop inside");
									eElement.getElementsByTagName("ns0:CardNumber").item(0)
											.setTextContent(cardNumValue.get("cardNo_DiscountCard_Bus_SG"));
									cardNo = cardNumValue.get("cardNo_DiscountCard_Bus_SG");
									hash_map.put("RefNo_DiscountCard_Bus_SG_4000_" + cardNo, referenceNumber);
									common.writeDataInPropertyFile("RefNo_DiscountCard_Bus_SG_4000_" + cardNo,
											referenceNumber, "chevronEndToEndTemplateFile.properties");
								}
							}

						}

					} else if (nNode.getNodeName().equalsIgnoreCase("ns2:Header")) {
						for (int i = 0; i < Header.length; i++) {

							String eleName = Header[i];
							if (eleName.equalsIgnoreCase("ns0:FileName")) {
								eElement.getElementsByTagName(Header[i]).item(0).setTextContent(getFileName);
							} else if (eleName.equalsIgnoreCase("ns0:SequenceNumber")) {
								eElement.getElementsByTagName(Header[i]).item(0)
										.setTextContent(loadCardTransactionSeqNo);
							} else if (eleName.equalsIgnoreCase("ns0:StartDate")) {
								eElement.getElementsByTagName(Header[i]).item(0).setTextContent(date);
							} else if (eleName.equalsIgnoreCase("ns0:SettlementDate")) {
								eElement.getElementsByTagName(Header[i]).item(0).setTextContent(date);
							}

						}
					}
				}

			}

			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer = transformerFactory.newTransformer();
			DOMSource source = new DOMSource(doc);
			StreamResult result = new StreamResult(
					new File(System.getProperty("user.home") + System.getProperty("file.separator") + "Documents"
							+ System.getProperty("file.separator") + getFileName));
			transformer.transform(source, result);

			/*
			 * establishThePuttyConnection("XML", "PUTTY_HOST", "PUTTY_USERNAME",
			 * "PUTTY_PASSWORD", remoteDir,getFileName);
			 */
		} catch (Exception e) {
			e.printStackTrace();
		}
		return hash_map;
	}

	// Prakalpha-->For PH
	public HashMap<String, String> updateValuesInLoadCardTransactionXMLForChevron_PH(Map<String, String> cardNumValue,
			Map<String, String> Locationvalue, String clientNameInProp, String clientCountry) {
		Common common = new Common(driver, test);
		CommonInterfacePage commonInterfacePage = new CommonInterfacePage(driver, test);

		HashMap<String, String> hash_map = new HashMap<String, String>();
		String xmlFilePath;
		String remoteDir = null;
		String getFileName = null;
		String loadCardTransactionSeqNo = null;
		String inputTemplateFileName = null;
		String RefNum = common.getUniqReferenceNumber();
		String referenceNumber = null;
		String cardNo = "";
		System.out.println("Ref No::" + RefNum);
		String date = commonInterfacePage.funcFetchLoadCardTransStartDateFromIFCSDB(configProp, clientNameInProp);
		System.out.println("Date::" + date);
		// String Time = common.getTime();
		String client_mid = commonInterfacePage.funcFetchLoadCardTransClientMidFromIFCSDB(configProp);
		System.out.println("client_mid ::" + client_mid);
		loadCardTransactionSeqNo = commonInterfacePage.funcFetchPaymentSeqNoFromIFCSDB(configProp, clientNameInProp,
				"LoadCardTransactions");
		inputTemplateFileName = "LoadCardTransaction_CHV_" + clientCountry + "_nnnn.xml";
		getFileName = "LoadCardTransactions_" + client_mid + "_" + loadCardTransactionSeqNo + ".xml";
		System.out.println("get File name::" + getFileName);
		remoteDir = "IFCS_INPUTFILE_FOLDER_LOADCARDTRANSACTION_CHV_PH";
		logInfo("File Name in method:" + getFileName);
		System.out.println(remoteDir);
		try {
			xmlFilePath = Constants.INPUTFILE_DIR + inputTemplateFileName;
			File xmlFile = new File(xmlFilePath);
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			Document doc = docBuilder.parse(xmlFile);
			String[] Headertagvalue = { "ns2:Header", "ns2:LoadCardTransaction" };
			String[] TransactionDetails = { "ns0:ReferenceNumber", "ns0:TransactionDateTime", "ns0:RetailSiteId",
					"ns0:IdassNumber", "ns0:TransactionCode", "ns0:CardNumber" };
			String[] Header = { "ns0:FileName", "ns0:SequenceNumber", "ns0:StartDate", "ns0:SettlementDate" };
			System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
			for (String s : Headertagvalue) {
				NodeList nList = doc.getElementsByTagName(s);
				System.out.println("length of nList::" + nList.getLength());
				for (int temp = 0; temp < nList.getLength(); temp++) {
					Node nNode = nList.item(temp);
					logInfo("\nCurrent Element :" + nNode.getNodeName());
					Element eElement = (Element) nNode;
					if (nNode.getNodeName().equalsIgnoreCase("ns2:LoadCardTransaction")) {

						for (int i = 0; i < TransactionDetails.length; i++) {
							String eleName = TransactionDetails[i];

							if (eleName.equalsIgnoreCase("ns0:ReferenceNumber")) {
								referenceNumber = RefNum + temp;

								eElement.getElementsByTagName(TransactionDetails[i]).item(0)
										.setTextContent(referenceNumber);
								System.out.println("ReferenceNumber::" + referenceNumber);
							} else if (eleName.equalsIgnoreCase("ns0:TransactionDateTime")) {
								eElement.getElementsByTagName(TransactionDetails[i]).item(0)
										.setTextContent(date + "T00:00:08");
								System.out.println("TransactionDateTime:::" + date);
							} else if (eleName.equalsIgnoreCase("ns0:RetailSiteId")) {
								eElement.getElementsByTagName(TransactionDetails[i]).item(0)
										.setTextContent(Locationvalue.get("Location_no_PH"));
								System.out.println("RetailSiteId:::" + Locationvalue.get("Location_No_PH"));
							} else if (eleName.equalsIgnoreCase("ns0:IdassNumber")) {
								eElement.getElementsByTagName(TransactionDetails[i]).item(0)
										.setTextContent(Locationvalue.get("Location_no_PH"));
								System.out.println("IdassNumber:::" + Locationvalue.get("Location_No_PH"));
							}

							else if (eleName.equalsIgnoreCase("ns0:TransactionCode") && temp == 0) {
								if (eElement.getElementsByTagName(TransactionDetails[i]).item(0).getTextContent()
										.equalsIgnoreCase("CW001")) {

									eElement.getElementsByTagName("ns0:CardNumber").item(0)
											.setTextContent(cardNumValue.get("cardNo_StarCard_Debit_PH"));
									cardNo = cardNumValue.get("cardNo_StarCard_Debit_PH");
									hash_map.put("RefNo_StarCard_Debit_PH_CW001_" + cardNo, referenceNumber);
									common.writeDataInPropertyFile("RefNo_StarCard_Debit_PH_CW001_" + cardNo,
											referenceNumber, "chevronEndToEndTemplateFile.properties");
								}
							} else if (eleName.equalsIgnoreCase("ns0:TransactionCode") && temp == 1) {
								if (eElement.getElementsByTagName(TransactionDetails[i]).item(0).getTextContent()
										.equalsIgnoreCase("CW002")) {
									System.out.println("CW002 loop inside");

									eElement.getElementsByTagName("ns0:CardNumber").item(0)
											.setTextContent(cardNumValue.get("cardNo_StarCard_Debit_PH"));
									cardNo = cardNumValue.get("cardNo_StarCard_Debit_PH");
									hash_map.put("RefNo_StarCard_Debit_PH_CW002_" + cardNo, referenceNumber);
									common.writeDataInPropertyFile("RefNo_StarCard_Debit_PH_CW002_" + cardNo,
											referenceNumber, "chevronEndToEndTemplateFile.properties");

								}
							} else if (eleName.equalsIgnoreCase("ns0:TransactionCode") && temp == 2) {
								if (eElement.getElementsByTagName(TransactionDetails[i]).item(0).getTextContent()
										.equalsIgnoreCase("CW003")) {
									System.out.println("CW003 loop inside");

									eElement.getElementsByTagName("ns0:CardNumber").item(0)
											.setTextContent(cardNumValue.get("cardNo_StarCash_Chevron_PH"));
									cardNo = cardNumValue.get("cardNo_StarCash_Chevron_PH");
									hash_map.put("RefNo_StarCash_Chevron_PH_CW003_" + cardNo, referenceNumber);
									common.writeDataInPropertyFile("RefNo_StarCash_Chevron_PH_CW003_" + cardNo,
											referenceNumber, "chevronEndToEndTemplateFile.properties");

								}
							} else if (eleName.equalsIgnoreCase("ns0:TransactionCode") && temp == 3) {
								if (eElement.getElementsByTagName(TransactionDetails[i]).item(0).getTextContent()
										.equalsIgnoreCase("CW004")) {
									System.out.println("CW004 loop inside");

									eElement.getElementsByTagName("ns0:CardNumber").item(0)
											.setTextContent(cardNumValue.get("cardNo_StarCash_Chevron_PH"));
									cardNo = cardNumValue.get("cardNo_StarCash_Chevron_PH");
									hash_map.put("RefNo_StarCash_Chevron_PH_CW004_" + cardNo, referenceNumber);
									common.writeDataInPropertyFile("RefNo_StarCash_Chevron_PH_CW004_" + cardNo,
											referenceNumber, "chevronEndToEndTemplateFile.properties");
								}
							} else if (eleName.equalsIgnoreCase("ns0:TransactionCode") && temp == 4) {

								if (eElement.getElementsByTagName(TransactionDetails[i]).item(0).getTextContent()
										.equalsIgnoreCase("CW001")) {
									System.out.println("PH CW001 loop inside");
									eElement.getElementsByTagName("ns0:CardNumber").item(0)
											.setTextContent(cardNumValue.get("cardNo_StarCard_Staff_PH"));
									cardNo = cardNumValue.get("cardNo_StarCard_Staff_PH");
									hash_map.put("RefNo_StarCard_Staff_PH_CW001_" + cardNo, referenceNumber);
									common.writeDataInPropertyFile("RefNo_StarCard_Staff_PH_CW001_" + cardNo,
											referenceNumber, "chevronEndToEndTemplateFile.properties");

								}

							} else if (eleName.equalsIgnoreCase("ns0:TransactionCode") && temp == 5) {

								if (eElement.getElementsByTagName(TransactionDetails[i]).item(0).getTextContent()
										.equalsIgnoreCase("CW001")) {
									System.out.println("PH CW001 loop inside");
									eElement.getElementsByTagName("ns0:CardNumber").item(0)
											.setTextContent(cardNumValue.get("cardNo_StarCash_Customer_PH"));
									cardNo = cardNumValue.get("cardNo_StarCash_Customer_PH");
									hash_map.put("RefNo_StarCash_Customer_PH_CW001_" + cardNo, referenceNumber);
									common.writeDataInPropertyFile("RefNo_StarCash_Customer_PH_CW001_" + cardNo,
											referenceNumber, "chevronEndToEndTemplateFile.properties");
								}

							} else if (eleName.equalsIgnoreCase("ns0:TransactionCode") && temp == 6) {

								if (eElement.getElementsByTagName(TransactionDetails[i]).item(0).getTextContent()
										.equalsIgnoreCase("CW001")) {
									System.out.println("PH CW001 loop inside");
									eElement.getElementsByTagName("ns0:CardNumber").item(0)
											.setTextContent(cardNumValue.get("cardNo_StarCard_Fleet_PH"));
									cardNo = cardNumValue.get("cardNo_StarCard_Fleet_PH");
									hash_map.put("RefNo_StarCard_Fleet_PH_CW001_" + cardNo, referenceNumber);
									common.writeDataInPropertyFile("RefNo_StarCard_Fleet_PH_CW001_" + cardNo,
											referenceNumber, "chevronEndToEndTemplateFile.properties");

								}

							}

						}

					} else if (nNode.getNodeName().equalsIgnoreCase("ns2:Header")) {
						for (int i = 0; i < Header.length; i++) {

							String eleName = Header[i];
							if (eleName.equalsIgnoreCase("ns0:FileName")) {
								eElement.getElementsByTagName(Header[i]).item(0).setTextContent(getFileName);
							} else if (eleName.equalsIgnoreCase("ns0:SequenceNumber")) {
								eElement.getElementsByTagName(Header[i]).item(0)
										.setTextContent(loadCardTransactionSeqNo);
							} else if (eleName.equalsIgnoreCase("ns0:StartDate")) {
								eElement.getElementsByTagName(Header[i]).item(0).setTextContent(date);
							} else if (eleName.equalsIgnoreCase("ns0:SettlementDate")) {
								eElement.getElementsByTagName(Header[i]).item(0).setTextContent(date);
							}

						}
					}
				}

			}

			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer = transformerFactory.newTransformer();
			DOMSource source = new DOMSource(doc);
			StreamResult result = new StreamResult(
					new File(System.getProperty("user.home") + System.getProperty("file.separator") + "Documents"
							+ System.getProperty("file.separator") + getFileName));
			transformer.transform(source, result);

			/*
			 * establishThePuttyConnection("XML", "PUTTY_HOST", "PUTTY_USERNAME",
			 * "PUTTY_PASSWORD", remoteDir,getFileName);
			 */
		} catch (Exception e) {
			e.printStackTrace();
		}
		return hash_map;
	}

	public HashMap<String, String> updateValuesInLoadCardTransactionXMLForChevron_TH(Map<String, String> cardNumValue,
			Map<String, String> Locationvalue, String clientNameInProp, String clientCountry) {
		Common common = new Common(driver, test);
		CommonInterfacePage commonInterfacePage = new CommonInterfacePage(driver, test);
		HashMap<String, String> hash_map = new HashMap<String, String>();
		String xmlFilePath;
		String remoteDir = null;
		String getFileName = null;
		String loadCardTransactionSeqNo = null;
		String inputTemplateFileName = null;
		String RefNum = common.getUniqReferenceNumber();
		String referenceNumber = null;
		String cardNo = "";
		String date = commonInterfacePage.funcFetchLoadCardTransStartDateFromIFCSDB(configProp, clientNameInProp);
		System.out.println("Date::" + date);
		// String Time = common.getTime();
		String client_mid = commonInterfacePage.funcFetchLoadCardTransClientMidFromIFCSDB(configProp);
		System.out.println("client_mid ::" + client_mid);
		loadCardTransactionSeqNo = commonInterfacePage.funcFetchPaymentSeqNoFromIFCSDB(configProp, clientNameInProp,
				"LoadCardTransactions");
		inputTemplateFileName = "LoadCardTransaction_CHV_" + clientCountry + "_nnnn.xml";
		getFileName = "LoadCardTransactions_" + client_mid + "_" + loadCardTransactionSeqNo + ".xml";
		System.out.println("get File name::" + getFileName);
		remoteDir = "IFCS_INPUTFILE_FOLDER_LOADCARDTRANSACTION_CHV_TH";
		logInfo("File Name in method:" + getFileName);
		System.out.println(remoteDir);
		try {
			xmlFilePath = Constants.INPUTFILE_DIR + inputTemplateFileName;
			File xmlFile = new File(xmlFilePath);
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			Document doc = docBuilder.parse(xmlFile);
			String[] Headertagvalue = { "ns2:Header", "ns2:LoadCardTransaction" };
			String[] TransactionDetails = { "ns0:ReferenceNumber", "ns0:TransactionDateTime", "ns0:RetailSiteId",
					"ns0:IdassNumber", "ns0:TransactionCode", "ns0:CardNumber" };
			String[] Header = { "ns0:FileName", "ns0:SequenceNumber", "ns0:StartDate", "ns0:SettlementDate" };
			System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
			for (String s : Headertagvalue) {
				NodeList nList = doc.getElementsByTagName(s);
				System.out.println("length of nList::" + nList.getLength());
				for (int temp = 0; temp < nList.getLength(); temp++) {
					Node nNode = nList.item(temp);
					logInfo("\nCurrent Element :" + nNode.getNodeName());
					Element eElement = (Element) nNode;
					if (nNode.getNodeName().equalsIgnoreCase("ns2:LoadCardTransaction")) {

						for (int i = 0; i < TransactionDetails.length; i++) {
							String eleName = TransactionDetails[i];

							if (eleName.equalsIgnoreCase("ns0:ReferenceNumber")) {
								referenceNumber = RefNum + temp;
								eElement.getElementsByTagName(TransactionDetails[i]).item(0)
										.setTextContent(referenceNumber);

								System.out.println("ReferenceNumber::" + referenceNumber);
							} else if (eleName.equalsIgnoreCase("ns0:TransactionDateTime")) {
								eElement.getElementsByTagName(TransactionDetails[i]).item(0)
										.setTextContent(date + "T00:00:08");
								System.out.println("TransactionDateTime:::" + date);
							} else if (eleName.equalsIgnoreCase("ns0:RetailSiteId")) {
								eElement.getElementsByTagName(TransactionDetails[i]).item(0)
										.setTextContent(Locationvalue.get("Location_no_TH"));
								System.out.println("RetailSiteId:::" + Locationvalue.get("Location_No_TH"));
							} else if (eleName.equalsIgnoreCase("ns0:IdassNumber")) {
								eElement.getElementsByTagName(TransactionDetails[i]).item(0)
										.setTextContent(Locationvalue.get("Location_no_TH"));
								System.out.println("IdassNumber:::" + Locationvalue.get("Location_No_TH"));
							}

							else if (eleName.equalsIgnoreCase("ns0:TransactionCode") && temp == 0) {
								if (eElement.getElementsByTagName(TransactionDetails[i]).item(0).getTextContent()
										.equalsIgnoreCase("CW001")) {

									eElement.getElementsByTagName("ns0:CardNumber").item(0)
											.setTextContent(cardNumValue.get("cardNo_StarCard_Staff_TH"));
									cardNo = cardNumValue.get("cardNo_StarCard_Staff_TH");
									hash_map.put("RefNo_StarCard_Staff_TH_CW001_" + cardNo, referenceNumber);
									common.writeDataInPropertyFile("RefNo_StarCard_Staff_TH_CW001_" + cardNo,
											referenceNumber, "chevronEndToEndTemplateFile.properties");
								}
							} else if (eleName.equalsIgnoreCase("ns0:TransactionCode") && temp == 1) {
								if (eElement.getElementsByTagName(TransactionDetails[i]).item(0).getTextContent()
										.equalsIgnoreCase("CW002")) {
									System.out.println("CW002 loop inside");

									eElement.getElementsByTagName("ns0:CardNumber").item(0)
											.setTextContent(cardNumValue.get("cardNo_StarCard_Staff_TH"));
									cardNo = cardNumValue.get("cardNo_StarCard_Staff_TH");
									hash_map.put("RefNo_StarCard_Staff_TH_CW002_" + cardNo, referenceNumber);
									common.writeDataInPropertyFile("RefNo_StarCard_Staff_TH_CW002_" + cardNo,
											referenceNumber, "chevronEndToEndTemplateFile.properties");

								}
							} else if (eleName.equalsIgnoreCase("ns0:TransactionCode") && temp == 2) {
								if (eElement.getElementsByTagName(TransactionDetails[i]).item(0).getTextContent()
										.equalsIgnoreCase("CW003")) {
									System.out.println("CW003 loop inside");

									eElement.getElementsByTagName("ns0:CardNumber").item(0)
											.setTextContent(cardNumValue.get("cardNo_StarCard_Fleet_TH"));
									cardNo = cardNumValue.get("cardNo_StarCard_Fleet_TH");
									hash_map.put("RefNo_StarCard_Fleet_TH_CW003_" + cardNo, referenceNumber);
									common.writeDataInPropertyFile("RefNo_StarCard_Fleet_TH_CW003_" + cardNo,
											referenceNumber, "chevronEndToEndTemplateFile.properties");

								}
							} else if (eleName.equalsIgnoreCase("ns0:TransactionCode") && temp == 3) {
								if (eElement.getElementsByTagName(TransactionDetails[i]).item(0).getTextContent()
										.equalsIgnoreCase("CW004")) {
									System.out.println("CW004 loop inside");

									eElement.getElementsByTagName("ns0:CardNumber").item(0)
											.setTextContent(cardNumValue.get("cardNo_StarCard_Fleet_TH"));
									cardNo = cardNumValue.get("cardNo_StarCard_Fleet_TH");
									hash_map.put("RefNo_StarCard_Fleet_TH_CW004_" + cardNo, referenceNumber);
									common.writeDataInPropertyFile("RefNo_StarCard_Fleet_TH_CW004_" + cardNo,
											referenceNumber, "chevronEndToEndTemplateFile.properties");
								}
							}

						}

					} else if (nNode.getNodeName().equalsIgnoreCase("ns2:Header")) {
						for (int i = 0; i < Header.length; i++) {

							String eleName = Header[i];
							if (eleName.equalsIgnoreCase("ns0:FileName")) {
								eElement.getElementsByTagName(Header[i]).item(0).setTextContent(getFileName);
							} else if (eleName.equalsIgnoreCase("ns0:SequenceNumber")) {
								eElement.getElementsByTagName(Header[i]).item(0)
										.setTextContent(loadCardTransactionSeqNo);
							} else if (eleName.equalsIgnoreCase("ns0:StartDate")) {
								eElement.getElementsByTagName(Header[i]).item(0).setTextContent(date);
							} else if (eleName.equalsIgnoreCase("ns0:SettlementDate")) {
								eElement.getElementsByTagName(Header[i]).item(0).setTextContent(date);
							}

						}
					}
				}

			}

			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer = transformerFactory.newTransformer();
			DOMSource source = new DOMSource(doc);
			StreamResult result = new StreamResult(
					new File(System.getProperty("user.home") + System.getProperty("file.separator") + "Documents"
							+ System.getProperty("file.separator") + getFileName));
			transformer.transform(source, result);

			/*
			 * establishThePuttyConnection("XML", "PUTTY_HOST", "PUTTY_USERNAME",
			 * "PUTTY_PASSWORD", remoteDir,getFileName);
			 */
		} catch (Exception e) {
			e.printStackTrace();
		}
		return hash_map;
	}

	public HashMap<String, String> updateValuesInLoadCardTransactionXMLForChevron_MY(Map<String, String> cardNumValue,
			Map<String, String> Locationvalue, String clientNameInProp, String clientCountry) {
		Common common = new Common(driver, test);
		CommonInterfacePage commonInterfacePage = new CommonInterfacePage(driver, test);
		HashMap<String, String> hash_map = new HashMap<String, String>();
		String xmlFilePath;
		String remoteDir = null;
		String getFileName = null;
		String loadCardTransactionSeqNo = null;
		String inputTemplateFileName = null;
		String RefNum = common.getUniqReferenceNumber();
		String referenceNumber = null;
		String cardNo = "";
		String date = commonInterfacePage.funcFetchLoadCardTransStartDateFromIFCSDB(configProp, clientNameInProp);
		System.out.println("Date::" + date);
		// String Time = common.getTime();
		String client_mid = commonInterfacePage.funcFetchLoadCardTransClientMidFromIFCSDB(configProp);
		System.out.println("client_mid ::" + client_mid);
		loadCardTransactionSeqNo = commonInterfacePage.funcFetchPaymentSeqNoFromIFCSDB(configProp, clientNameInProp,
				"LoadCardTransactions");
		inputTemplateFileName = "LoadCardTransaction_CHV_" + clientCountry + "_nnnn.xml";
		getFileName = "LoadCardTransactions_" + client_mid + "_" + loadCardTransactionSeqNo + ".xml";
		System.out.println("get File name::" + getFileName);
		remoteDir = "IFCS_INPUTFILE_FOLDER_LOADCARDTRANSACTION_CHV_MY";
		logInfo("File Name in method:" + getFileName);
		System.out.println(remoteDir);
		try {
			xmlFilePath = Constants.INPUTFILE_DIR + inputTemplateFileName;
			File xmlFile = new File(xmlFilePath);
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			Document doc = docBuilder.parse(xmlFile);
			String[] Headertagvalue = { "ns2:Header", "ns2:LoadCardTransaction" };
			String[] TransactionDetails = { "ns0:ReferenceNumber", "ns0:TransactionDateTime", "ns0:RetailSiteId",
					"ns0:IdassNumber", "ns0:TransactionCode", "ns0:CardNumber" };
			String[] Header = { "ns0:FileName", "ns0:SequenceNumber", "ns0:StartDate", "ns0:SettlementDate" };
			System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
			for (String s : Headertagvalue) {
				NodeList nList = doc.getElementsByTagName(s);
				System.out.println("length of nList::" + nList.getLength());
				for (int temp = 0; temp < nList.getLength(); temp++) {
					Node nNode = nList.item(temp);
					logInfo("\nCurrent Element :" + nNode.getNodeName());
					Element eElement = (Element) nNode;
					if (nNode.getNodeName().equalsIgnoreCase("ns2:LoadCardTransaction")) {

						for (int i = 0; i < TransactionDetails.length; i++) {
							String eleName = TransactionDetails[i];

							if (eleName.equalsIgnoreCase("ns0:ReferenceNumber")) {
								referenceNumber = RefNum + temp;

								eElement.getElementsByTagName(TransactionDetails[i]).item(0)
										.setTextContent(referenceNumber);

								System.out.println("ReferenceNumber::" + referenceNumber);
							} else if (eleName.equalsIgnoreCase("ns0:TransactionDateTime")) {
								eElement.getElementsByTagName(TransactionDetails[i]).item(0)
										.setTextContent(date + "T00:00:08");
								System.out.println("TransactionDateTime:::" + date);
							} else if (eleName.equalsIgnoreCase("ns0:RetailSiteId")) {
								eElement.getElementsByTagName(TransactionDetails[i]).item(0)
										.setTextContent(Locationvalue.get("Location_no_MY"));
								System.out.println("RetailSiteId:::" + Locationvalue.get("Location_No_MY"));
							} else if (eleName.equalsIgnoreCase("ns0:IdassNumber")) {
								eElement.getElementsByTagName(TransactionDetails[i]).item(0)
										.setTextContent(Locationvalue.get("Location_no_MY"));
								System.out.println("IdassNumber:::" + Locationvalue.get("Location_No_MY"));
							}

							else if (eleName.equalsIgnoreCase("ns0:TransactionCode") && temp == 0) {
								if (eElement.getElementsByTagName(TransactionDetails[i]).item(0).getTextContent()
										.equalsIgnoreCase("1000")) {

									eElement.getElementsByTagName("ns0:CardNumber").item(0)
											.setTextContent(cardNumValue.get("cardNo_StarCard_Fleet_MY"));
									cardNo = cardNumValue.get("cardNo_StarCard_Fleet_MY");
									hash_map.put("RefNo_StarCard_Fleet_MY_1000_" + cardNo, referenceNumber);
									common.writeDataInPropertyFile("RefNo_StarCard_Fleet_MY_1000_" + cardNo,
											referenceNumber, "chevronEndToEndTemplateFile.properties");
								}
							} else if (eleName.equalsIgnoreCase("ns0:TransactionCode") && temp == 1) {
								if (eElement.getElementsByTagName(TransactionDetails[i]).item(0).getTextContent()
										.equalsIgnoreCase("1100")) {
									System.out.println("1100 loop inside");

									eElement.getElementsByTagName("ns0:CardNumber").item(0)
											.setTextContent(cardNumValue.get("cardNo_StarCard_Fleet_MY"));
									cardNo = cardNumValue.get("cardNo_StarCard_Fleet_MY");
									hash_map.put("RefNo_StarCard_Fleet_MY_1100_" + cardNo, referenceNumber);
									common.writeDataInPropertyFile("RefNo_StarCard_Fleet_MY_1100_" + cardNo,
											referenceNumber, "chevronEndToEndTemplateFile.properties");
								}
							} else if (eleName.equalsIgnoreCase("ns0:TransactionCode") && temp == 2) {
								if (eElement.getElementsByTagName(TransactionDetails[i]).item(0).getTextContent()
										.equalsIgnoreCase("CW003")) {
									System.out.println("CW003 loop inside");

									eElement.getElementsByTagName("ns0:CardNumber").item(0)
											.setTextContent(cardNumValue.get("cardNo_StarCash_Chevron_MY"));
									cardNo = cardNumValue.get("cardNo_StarCash_Chevron_MY");
									hash_map.put("RefNo_StarCash_Chevron_MY_CW003_" + cardNo, referenceNumber);
									common.writeDataInPropertyFile("RefNo_StarCash_Chevron_MY_CW003_" + cardNo,
											referenceNumber, "chevronEndToEndTemplateFile.properties");
								}
							} else if (eleName.equalsIgnoreCase("ns0:TransactionCode") && temp == 3) {
								if (eElement.getElementsByTagName(TransactionDetails[i]).item(0).getTextContent()
										.equalsIgnoreCase("CW004")) {
									System.out.println("CW004 loop inside");

									eElement.getElementsByTagName("ns0:CardNumber").item(0)
											.setTextContent(cardNumValue.get("cardNo_StarCash_Chevron_MY"));
									cardNo = cardNumValue.get("cardNo_StarCash_Chevron_MY");
									hash_map.put("RefNo_StarCash_Chevron_MY_CW004_" + cardNo, referenceNumber);
									common.writeDataInPropertyFile("RefNo_StarCash_Chevron_MY_CW004_" + cardNo,
											referenceNumber, "chevronEndToEndTemplateFile.properties");
								}
							} else if (eleName.equalsIgnoreCase("ns0:TransactionCode") && temp == 4) {

								if (eElement.getElementsByTagName(TransactionDetails[i]).item(0).getTextContent()
										.equalsIgnoreCase("4000")) {
									System.out.println("4000 loop inside");
									eElement.getElementsByTagName("ns0:CardNumber").item(0)
											.setTextContent(cardNumValue.get("cardNo_DiscountCard_SubsidyDiesel_MY"));
									cardNo = cardNumValue.get("cardNo_DiscountCard_SubsidyDiesel_MY");
									hash_map.put("RefNo_DiscountCard_SubsidyDiesel_MY_4000_" + cardNo, referenceNumber);
									common.writeDataInPropertyFile("RefNo_DiscountCard_SubsidyDiesel_MY_4000_" + cardNo,
											referenceNumber, "chevronEndToEndTemplateFile.properties");
								}
							} else if (eleName.equalsIgnoreCase("ns0:TransactionCode") && temp == 5) {
								if (eElement.getElementsByTagName(TransactionDetails[i]).item(0).getTextContent()
										.equalsIgnoreCase("4100")) {
									System.out.println("4100 loop inside");

									eElement.getElementsByTagName("ns0:CardNumber").item(0)
											.setTextContent(cardNumValue.get("cardNo_DiscountCard_SubsidyDiesel_MY"));
									cardNo = cardNumValue.get("cardNo_DiscountCard_SubsidyDiesel_MY");
									hash_map.put("RefNo_DiscountCard_SubsidyDiesel_MY_4100_" + cardNo, referenceNumber);
									common.writeDataInPropertyFile("RefNo_DiscountCard_SubsidyDiesel_MY_4100_" + cardNo,
											referenceNumber, "chevronEndToEndTemplateFile.properties");
								}
							} else if (eleName.equalsIgnoreCase("ns0:TransactionCode") && temp == 6) {
								if (eElement.getElementsByTagName(TransactionDetails[i]).item(0).getTextContent()
										.equalsIgnoreCase("1000")) {
									System.out.println("3nd 1000 loop inside");
									eElement.getElementsByTagName("ns0:CardNumber").item(0)
											.setTextContent(cardNumValue.get("cardNo_StarCard_Staff_MY"));
									cardNo = cardNumValue.get("cardNo_StarCard_Staff_MY");
									hash_map.put("RefNo_cardNo_StarCard_Staff_MY_1000_" + cardNo, referenceNumber);
									common.writeDataInPropertyFile("RefNo_cardNo_StarCard_Staff_MY_1000_" + cardNo,
											referenceNumber, "chevronEndToEndTemplateFile.properties");
								}

							} else if (eleName.equalsIgnoreCase("ns0:TransactionCode") && temp == 7) {
								if (eElement.getElementsByTagName(TransactionDetails[i]).item(0).getTextContent()
										.equalsIgnoreCase("1000")) {
									System.out.println("2nd 1000 loop inside");
									eElement.getElementsByTagName("ns0:CardNumber").item(0)
											.setTextContent(cardNumValue.get("cardNo_StarCash_Customer_MY"));
									cardNo = cardNumValue.get("cardNo_StarCash_Customer_MY");
									hash_map.put("RefNo_cardNo_StarCash_Customer_MY_1000_" + cardNo, referenceNumber);
									common.writeDataInPropertyFile("RefNo_StarCash_Customer_MY_1000_" + cardNo,
											referenceNumber, "chevronEndToEndTemplateFile.properties");
								}
							} else if (eleName.equalsIgnoreCase("ns0:TransactionCode") && temp == 8) {
								if (eElement.getElementsByTagName(TransactionDetails[i]).item(0).getTextContent()
										.equalsIgnoreCase("4000")) {
									System.out.println("2nd 4000 loop inside");
									eElement.getElementsByTagName("ns0:CardNumber").item(0)
											.setTextContent(cardNumValue.get("cardNo_DiscountCard_SubsidyPetrol_MY"));
									cardNo = cardNumValue.get("cardNo_DiscountCard_SubsidyPetrol_MY");
									hash_map.put("RefNo_DiscountCard_SubsidyPetrol_MY_4000_" + cardNo, referenceNumber);
									common.writeDataInPropertyFile("RefNo_DiscountCard_SubsidyPetrol_MY_4000_" + cardNo,
											referenceNumber, "chevronEndToEndTemplateFile.properties");
								}
							}

						}

					} else if (nNode.getNodeName().equalsIgnoreCase("ns2:Header")) {
						for (int i = 0; i < Header.length; i++) {

							String eleName = Header[i];
							if (eleName.equalsIgnoreCase("ns0:FileName")) {
								eElement.getElementsByTagName(Header[i]).item(0).setTextContent(getFileName);
							} else if (eleName.equalsIgnoreCase("ns0:SequenceNumber")) {
								eElement.getElementsByTagName(Header[i]).item(0)
										.setTextContent(loadCardTransactionSeqNo);
							} else if (eleName.equalsIgnoreCase("ns0:StartDate")) {
								eElement.getElementsByTagName(Header[i]).item(0).setTextContent(date);
							} else if (eleName.equalsIgnoreCase("ns0:SettlementDate")) {
								eElement.getElementsByTagName(Header[i]).item(0).setTextContent(date);
							}

						}
					}
				}

			}

			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer = transformerFactory.newTransformer();
			DOMSource source = new DOMSource(doc);
			StreamResult result = new StreamResult(
					new File(System.getProperty("user.home") + System.getProperty("file.separator") + "Documents"
							+ System.getProperty("file.separator") + getFileName));
			transformer.transform(source, result);

			/*
			 * establishThePuttyConnection("XML", "PUTTY_HOST", "PUTTY_USERNAME",
			 * "PUTTY_PASSWORD", remoteDir,getFileName);
			 */
		} catch (Exception e) {
			e.printStackTrace();
		}
		return hash_map;
	}

	public HashMap<String, String> updateValuesInLoadCardTransactionXMLForChevron_HK(Map<String, String> cardNumValue,
			Map<String, String> Locationvalue, String clientNameInProp, String clientCountry) {
		Common common = new Common(driver, test);
		CommonInterfacePage commonInterfacePage = new CommonInterfacePage(driver, test);
		HashMap<String, String> hash_map = new HashMap<String, String>();
		String xmlFilePath;
		String remoteDir = null;
		String getFileName = null;
		String loadCardTransactionSeqNo = null;
		String inputTemplateFileName = null;
		String RefNum = common.getUniqReferenceNumber();
		String referenceNumber = null;
		String cardNo = "";
		String date = commonInterfacePage.funcFetchLoadCardTransStartDateFromIFCSDB(configProp, clientNameInProp);
		System.out.println("Date::" + date);
		// String Time = common.getTime();
		String client_mid = commonInterfacePage.funcFetchLoadCardTransClientMidFromIFCSDB(configProp);
		System.out.println("client_mid ::" + client_mid);
		loadCardTransactionSeqNo = commonInterfacePage.funcFetchPaymentSeqNoFromIFCSDB(configProp, clientNameInProp,
				"LoadCardTransactions");
		inputTemplateFileName = "LoadCardTransaction_CHV_" + clientCountry + "_nnnn.xml";
		getFileName = "LoadCardTransactions_" + client_mid + "_" + loadCardTransactionSeqNo + ".xml";
		System.out.println("get File name::" + getFileName);
		remoteDir = "IFCS_INPUTFILE_FOLDER_LOADCARDTRANSACTION_CHV_MY";
		logInfo("File Name in method:" + getFileName);
		System.out.println(remoteDir);
		try {
			xmlFilePath = Constants.INPUTFILE_DIR + inputTemplateFileName;
			File xmlFile = new File(xmlFilePath);
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			Document doc = docBuilder.parse(xmlFile);
			String[] Headertagvalue = { "ns2:Header", "ns2:LoadCardTransaction" };
			String[] TransactionDetails = { "ns0:ReferenceNumber", "ns0:TransactionDateTime", "ns0:RetailSiteId",
					"ns0:IdassNumber", "ns0:TransactionCode", "ns0:CardNumber" };
			String[] Header = { "ns0:FileName", "ns0:SequenceNumber", "ns0:StartDate", "ns0:SettlementDate" };
			System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
			for (String s : Headertagvalue) {
				NodeList nList = doc.getElementsByTagName(s);
				System.out.println("length of nList::" + nList.getLength());
				for (int temp = 0; temp < nList.getLength(); temp++) {
					Node nNode = nList.item(temp);
					logInfo("\nCurrent Element :" + nNode.getNodeName());
					Element eElement = (Element) nNode;
					if (nNode.getNodeName().equalsIgnoreCase("ns2:LoadCardTransaction")) {

						for (int i = 0; i < TransactionDetails.length; i++) {
							String eleName = TransactionDetails[i];

							if (eleName.equalsIgnoreCase("ns0:ReferenceNumber")) {
								referenceNumber = RefNum + temp;

								eElement.getElementsByTagName(TransactionDetails[i]).item(0)
										.setTextContent(referenceNumber);

								System.out.println("ReferenceNumber::" + referenceNumber);
							} else if (eleName.equalsIgnoreCase("ns0:TransactionDateTime")) {
								eElement.getElementsByTagName(TransactionDetails[i]).item(0)
										.setTextContent(date + "T00:00:08");
								System.out.println("TransactionDateTime:::" + date);
							} else if (eleName.equalsIgnoreCase("ns0:RetailSiteId")) {
								eElement.getElementsByTagName(TransactionDetails[i]).item(0)
										.setTextContent(Locationvalue.get("Location_No_HK"));
								System.out.println("RetailSiteId:::" + Locationvalue.get("Location_No_HK"));
							} else if (eleName.equalsIgnoreCase("ns0:IdassNumber")) {
								eElement.getElementsByTagName(TransactionDetails[i]).item(0)
										.setTextContent(Locationvalue.get("Location_No_HK"));
								System.out.println("IdassNumber:::" + Locationvalue.get("Location_No_HK"));
							}

							else if (eleName.equalsIgnoreCase("ns0:TransactionCode") && temp == 0) {
								if (eElement.getElementsByTagName(TransactionDetails[i]).item(0).getTextContent()
										.equalsIgnoreCase("CW001")) {

									eElement.getElementsByTagName("ns0:CardNumber").item(0)
											.setTextContent(cardNumValue.get("cardNo_StarCardFleet_HK"));
									cardNo = cardNumValue.get("cardNo_StarCardFleet_HK");
									hash_map.put("RefNo_cardNo_StarCardFleet_HK_CW001_" + cardNo, referenceNumber);
									common.writeDataInPropertyFile("RefNo_cardNo_StarCardFleet_HK_CW001_" + cardNo,
											referenceNumber, "chevronEndToEndTemplateFile.properties");
								}
							} else if (eleName.equalsIgnoreCase("ns0:TransactionCode") && temp == 1) {
								if (eElement.getElementsByTagName(TransactionDetails[i]).item(0).getTextContent()
										.equalsIgnoreCase("CW002")) {
									System.out.println("CW002 loop inside");

									eElement.getElementsByTagName("ns0:CardNumber").item(0)
											.setTextContent(cardNumValue.get("cardNo_StarCardFleet_HK"));
									cardNo = cardNumValue.get("cardNo_StarCardFleet_HK");
									hash_map.put("RefNo_cardNo_StarCardFleet_HK_CW002_" + cardNo, referenceNumber);
									common.writeDataInPropertyFile("RefNo_cardNo_StarCardFleet_HK_CW002_" + cardNo,
											referenceNumber, "chevronEndToEndTemplateFile.properties");
								}
							} else if (eleName.equalsIgnoreCase("ns0:TransactionCode") && temp == 2) {
								if (eElement.getElementsByTagName(TransactionDetails[i]).item(0).getTextContent()
										.equalsIgnoreCase("CW003")) {
									System.out.println("CW003 loop inside");

									eElement.getElementsByTagName("ns0:CardNumber").item(0)
											.setTextContent(cardNumValue.get("cardNo_StarCard_Affinity_HK"));
									cardNo = cardNumValue.get("cardNo_StarCard_Affinity_HK");
									hash_map.put("RefNo_cardNo_StarCard_Affinity_HK_CW003_" + cardNo, referenceNumber);
									common.writeDataInPropertyFile("RefNo_cardNo_StarCard_Affinity_HK_CW003_" + cardNo,
											referenceNumber, "chevronEndToEndTemplateFile.properties");
								}
							} else if (eleName.equalsIgnoreCase("ns0:TransactionCode") && temp == 3) {
								if (eElement.getElementsByTagName(TransactionDetails[i]).item(0).getTextContent()
										.equalsIgnoreCase("CW004")) {
									System.out.println("CW004 loop inside");

									eElement.getElementsByTagName("ns0:CardNumber").item(0)
											.setTextContent(cardNumValue.get("cardNo_StarCard_Affinity_HK"));
									cardNo = cardNumValue.get("cardNo_StarCard_Affinity_HK");
									hash_map.put("RefNo_cardNo_StarCard_Affinity_HK_CW004_" + cardNo, referenceNumber);
									common.writeDataInPropertyFile("RefNo_cardNo_StarCard_Affinity_HK_CW004_" + cardNo,
											referenceNumber, "chevronEndToEndTemplateFile.properties");
								}
							} else if (eleName.equalsIgnoreCase("ns0:TransactionCode") && temp == 4) {

								if (eElement.getElementsByTagName(TransactionDetails[i]).item(0).getTextContent()
										.equalsIgnoreCase("CC001")) {
									System.out.println("CC001 loop inside");
									eElement.getElementsByTagName("ns0:CardNumber").item(0).setTextContent(
											cardNumValue.get("cardNo_DiscountCard_CashCard_ProfDrvrs_HK"));
									cardNo = cardNumValue.get("cardNo_DiscountCard_CashCard_ProfDrvrs_HK");
									hash_map.put("RefNo_cardNo_DiscountCard_CashCard_ProfDrvrs_HK_CC001_" + cardNo,
											referenceNumber);
									common.writeDataInPropertyFile(
											"RefNo_cardNo_DiscountCard_CashCard_ProfDrvrs_HK_CC001_" + cardNo,
											referenceNumber, "chevronEndToEndTemplateFile.properties");
								}
							} else if (eleName.equalsIgnoreCase("ns0:TransactionCode") && temp == 5) {
								if (eElement.getElementsByTagName(TransactionDetails[i]).item(0).getTextContent()
										.equalsIgnoreCase("CC002")) {
									System.out.println("CC002 loop inside");

									eElement.getElementsByTagName("ns0:CardNumber").item(0).setTextContent(
											cardNumValue.get("cardNo_DiscountCard_CashCard_ProfDrvrs_HK"));
									cardNo = cardNumValue.get("cardNo_DiscountCard_CashCard_ProfDrvrs_HK");
									hash_map.put("RefNo_cardNo_DiscountCard_CashCard_ProfDrvrs_HK_CC002_" + cardNo,
											referenceNumber);
									common.writeDataInPropertyFile(
											"RefNo_cardNo_DiscountCard_CashCard_ProfDrvrs_HK_CC002_" + cardNo,
											referenceNumber, "chevronEndToEndTemplateFile.properties");
								}
							} else if (eleName.equalsIgnoreCase("ns0:TransactionCode") && temp == 6) {
								if (eElement.getElementsByTagName(TransactionDetails[i]).item(0).getTextContent()
										.equalsIgnoreCase("CC001")) {
									System.out.println("3nd CC001 loop inside");
									eElement.getElementsByTagName("ns0:CardNumber").item(0).setTextContent(
											cardNumValue.get("cardNo_DiscountCard_CashCard_HybridTaxi_HK"));
									cardNo = cardNumValue.get("cardNo_DiscountCard_CashCard_HybridTaxi_HK");
									hash_map.put("RefNo_cardNo_DiscountCard_CashCard_HybridTaxi_HK_CC001_" + cardNo,
											referenceNumber);
									common.writeDataInPropertyFile(
											"RefNo_cardNo_DiscountCard_CashCard_HybridTaxi_HK_CC001_" + cardNo,
											referenceNumber, "chevronEndToEndTemplateFile.properties");
								}

							} else if (eleName.equalsIgnoreCase("ns0:TransactionCode") && temp == 7) {
								if (eElement.getElementsByTagName(TransactionDetails[i]).item(0).getTextContent()
										.equalsIgnoreCase("CC001")) {
									System.out.println("2nd CC001 loop inside");
									eElement.getElementsByTagName("ns0:CardNumber").item(0).setTextContent(
											cardNumValue.get("cardNo_DiscountCard_CashCard_PublicLightBus_HK"));
									cardNo = cardNumValue.get("cardNo_DiscountCard_CashCard_PublicLightBus_HK");
									hash_map.put("RefNo_cardNo_DiscountCard_CashCard_PublicLightBus_HK_CC001_" + cardNo,
											referenceNumber);
									common.writeDataInPropertyFile(
											"RefNo_cardNo_DiscountCard_CashCard_PublicLightBus_HK_CC001_" + cardNo,
											referenceNumber, "chevronEndToEndTemplateFile.properties");
								}
							} else if (eleName.equalsIgnoreCase("ns0:TransactionCode") && temp == 8) {
								if (eElement.getElementsByTagName(TransactionDetails[i]).item(0).getTextContent()
										.equalsIgnoreCase("CC001")) {
									System.out.println("2nd CC001 loop inside");
									eElement.getElementsByTagName("ns0:CardNumber").item(0)
											.setTextContent(cardNumValue.get("cardNo_DiscountCard_Hanberg_HK"));
									cardNo = cardNumValue.get("cardNo_DiscountCard_Hanberg_HK");
									hash_map.put("RefNo_cardNo_DiscountCard_Hanberg_HK_CC001_" + cardNo,
											referenceNumber);
									common.writeDataInPropertyFile(
											"RefNo_cardNo_DiscountCard_Hanberg_HK_CC001_" + cardNo, referenceNumber,
											"chevronEndToEndTemplateFile.properties");
								}
							} else if (eleName.equalsIgnoreCase("ns0:TransactionCode") && temp == 9) {
								if (eElement.getElementsByTagName(TransactionDetails[i]).item(0).getTextContent()
										.equalsIgnoreCase("CC001")) {
									System.out.println("2nd CC001 loop inside");
									eElement.getElementsByTagName("ns0:CardNumber").item(0).setTextContent(
											cardNumValue.get("cardNo_DiscountCard_CashCard_SiteCard_HK"));
									cardNo = cardNumValue.get("cardNo_DiscountCard_CashCard_SiteCard_HK");
									hash_map.put("RefNo_cardNo_DiscountCard_CashCard_SiteCard_HK_CC001_" + cardNo,
											referenceNumber);
									common.writeDataInPropertyFile(
											"RefNo_cardNo_DiscountCard_CashCard_SiteCard_HK_CC001_" + cardNo,
											referenceNumber, "chevronEndToEndTemplateFile.properties");
								}
							} else if (eleName.equalsIgnoreCase("ns0:TransactionCode") && temp == 10) {
								if (eElement.getElementsByTagName(TransactionDetails[i]).item(0).getTextContent()
										.equalsIgnoreCase("CC001")) {
									System.out.println("2nd CC001 loop inside");
									eElement.getElementsByTagName("ns0:CardNumber").item(0)
											.setTextContent(cardNumValue.get("cardNo_DiscountCard_Joyfuel_HK"));
									cardNo = cardNumValue.get("cardNo_DiscountCard_Joyfuel_HK");
									hash_map.put("RefNo_cardNo_DiscountCard_Joyfuel_HK_CC001_" + cardNo,
											referenceNumber);
									common.writeDataInPropertyFile(
											"RefNo_cardNo_DiscountCard_Joyfuel_HK_CC001_" + cardNo, referenceNumber,
											"chevronEndToEndTemplateFile.properties");
								}
							} else if (eleName.equalsIgnoreCase("ns0:TransactionCode") && temp == 11) {
								if (eElement.getElementsByTagName(TransactionDetails[i]).item(0).getTextContent()
										.equalsIgnoreCase("CC001")) {
									System.out.println("2nd CC001 loop inside");
									eElement.getElementsByTagName("ns0:CardNumber").item(0)
											.setTextContent(cardNumValue.get("cardNo_DiscountCard_CashCard_Diesel_HK"));
									cardNo = cardNumValue.get("cardNo_DiscountCard_CashCard_Diesel_HK");
									hash_map.put("RefNo_cardNo_DiscountCard_CashCard_Diesel_HK_CC001_" + cardNo,
											referenceNumber);
									common.writeDataInPropertyFile(
											"RefNo_cardNo_DiscountCard_CashCard_Diesel_HK_CC001_" + cardNo,
											referenceNumber, "chevronEndToEndTemplateFile.properties");
								}
							}

						}

					} else if (nNode.getNodeName().equalsIgnoreCase("ns2:Header")) {
						for (int i = 0; i < Header.length; i++) {

							String eleName = Header[i];
							if (eleName.equalsIgnoreCase("ns0:FileName")) {
								eElement.getElementsByTagName(Header[i]).item(0).setTextContent(getFileName);
							} else if (eleName.equalsIgnoreCase("ns0:SequenceNumber")) {
								eElement.getElementsByTagName(Header[i]).item(0)
										.setTextContent(loadCardTransactionSeqNo);
							} else if (eleName.equalsIgnoreCase("ns0:StartDate")) {
								eElement.getElementsByTagName(Header[i]).item(0).setTextContent(date);
							} else if (eleName.equalsIgnoreCase("ns0:SettlementDate")) {
								eElement.getElementsByTagName(Header[i]).item(0).setTextContent(date);
							}

						}
					}
				}

			}

			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer = transformerFactory.newTransformer();
			DOMSource source = new DOMSource(doc);
			StreamResult result = new StreamResult(
					new File(System.getProperty("user.home") + System.getProperty("file.separator") + "Documents"
							+ System.getProperty("file.separator") + getFileName));
			transformer.transform(source, result);

			establishThePuttyConnection("XML", "PUTTY_HOST", "PUTTY_USERNAME", "PUTTY_PASSWORD", remoteDir,
					getFileName);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return hash_map;
	}

	public void interfaceBatchJobwithIFCSLogin(String clientName, String clientCountry, String folderid) {
		try {
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		IFCSloginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, " ");
		String clientNameInProp = PropUtils.getPropValue(configProp, clientName + "_" + clientCountry);
		IFCSHomePage.gotoClientMenuAndChooseClient(clientNameInProp);
		sleep(5);
		Common common = new Common(driver, test);
		common.clientBatchJobExecution(folderid);
		}catch(Exception e) {
			e.getMessage();
		}

	}

	public void validateTransactionPostedOrNot(Map<String, String> refNoAndAmount) {
		CommonInterfacePage CommonInterfacePage = new CommonInterfacePage(driver, test);
		int i = 0;
		Map<String, String> refNoKeyAndValues = new HashMap<String, String>();
		for (String refNo : refNoAndAmount.keySet()) {
			String transactionAmount = CommonInterfacePage.getTransactionAmount(refNo);
			System.out.println("from parameter::" + Float.parseFloat(refNoAndAmount.get(refNo)) / 100);
			boolean transactionPos=true;
			try {
				Float.parseFloat(transactionAmount);
			} catch (Exception ex) {
				transactionPos=false;
				String suspended = "select was_corrected from suspended_line_items where pos_transaction_oid=(select pos_transaction_oid from pos_transactions where reference='"
						+ refNo + "')";
				if (connectDBAndGetValue(suspended, PropUtils.getPropValue(configProp, "sqlODSServerName")).toString()
						.equals("N")) {
					logInfo("Transaction Moved to Suspended" + refNo);
				} else {
					logFail("Transaction not Posted for" + refNo);
				}
			}if(transactionPos)
			{
			System.out.println("from db::" + Float.parseFloat(transactionAmount));
			if (!(transactionAmount.equals(""))) {
				if (Float.parseFloat(transactionAmount) == ((Float.parseFloat(refNoAndAmount.get(refNo))) / 100)) {
					refNoKeyAndValues.put("RefNo" + i, refNo);
					logPass("Transaction Posted for" + refNo);
				} else {
					logFail("Transaction not Posted for" + refNo);
				}
			} else {
				logFail("Transaction not Posted for" + refNo);
			}
		}
			i++;
		}
		PropUtils.creatingTempPropFile("TransactionReferenceNos", refNoKeyAndValues);

	}
	public void validateTransactionPostedAndSuspended(Map<String, String> refNoAndAmount) {
		CommonInterfacePage CommonInterfacePage = new CommonInterfacePage(driver, test);
		TransactionComponentPage transactionComponentPage=new TransactionComponentPage(driver,test);
		int i = 0;
		Map<String, String> refNoKeyAndValues = new HashMap<String, String>();
		for (String refNo : refNoAndAmount.keySet()) {
			String transactionAmount = CommonInterfacePage.getTransactionAmount(refNo);
			System.out.println("from parameter::" + Float.parseFloat(refNoAndAmount.get(refNo)) / 100);
			boolean transactionPos=true;
			try {
				Float.parseFloat(transactionAmount);
			} catch (Exception ex) {
				transactionPos=false;
				String suspended = "select was_corrected from suspended_line_items where pos_transaction_oid=(select pos_transaction_oid from pos_transactions where reference='"
						+ refNo + "')";
				if (connectDBAndGetValue(suspended, PropUtils.getPropValue(configProp, "sqlODSServerName")).toString()
						.equals("N")) {
					logInfo("Transaction Moved to Suspended" + refNo);
				} else {
					logFail("Transaction not Posted for" + refNo);
				}
			}if(transactionPos)
			{
			System.out.println("from db::" + Float.parseFloat(transactionAmount));
			if (!(transactionAmount.equals(""))) {
				if (Float.parseFloat(transactionAmount) == ((Float.parseFloat(refNoAndAmount.get(refNo))) / 100)) {
					refNoKeyAndValues.put("RefNo" + i, refNo);
					logPass("Transaction Posted for" + refNo);
				} else {
					logFail("Transaction not Posted for" + refNo);
				}
			} else {
				logFail("Transaction not Posted for" + refNo);
			}
		}
			transactionComponentPage.validateSuspendTransactionForDuplicateTransaction(refNoAndAmount,"Transaction goes to suspend");
			i++;
		}
		PropUtils.creatingTempPropFile("TransactionReferenceNos.properties", refNoKeyAndValues);
		System.out.println("Posted Transaction Ref Stored in Properties : " + refNoKeyAndValues
				+ "--> TransactionReferenceNos.properties");

	}
}
