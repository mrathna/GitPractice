using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using Common;
using Common.PageObjects;
using Common.ScenarioConfigurations;
using Common.Utility;

namespace EnCompass.Testing.Source.PageObjects.Organization.Admin.Proxy 
{
	/// <summary>
	/// Auto-generated Page Model Class
	/// Navigation Paths: 
		/// [Organization Home]->Administration->Proxies->Card Proxies
		/// </summary>
	[PageModel(@"/admin/proxy/CardProxy.aspx")]
	public partial class CardProxy : EnCompassOrgPageModel 
	{
		public override string RelativeUrl => @"/admin/proxy/CardProxy.aspx";
		public override string PageIdentifierXPath_Generated => @"//li[contains(@class, 'breadcrumb-item active')][text() = 'Card Proxies']";

		#region Navigation
				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Create Proxy']")]
		private IWebElement _administration_Proxies_CardProxies_CreateProxy { get; set; }
		public void NavigateTo_Administration_Proxies_CardProxies_CreateProxy()
		{
			NavigateToMenuItem(_administration_Proxies_CardProxies_CreateProxy);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='User Proxies']")]
		private IWebElement _administration_Proxies_CardProxies_UserProxies { get; set; }
		public void NavigateTo_Administration_Proxies_CardProxies_UserProxies()
		{
			NavigateToMenuItem(_administration_Proxies_CardProxies_UserProxies);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Card Proxies']")]
		private IWebElement _administration_Proxies_CardProxies_CardProxies { get; set; }
		public void NavigateTo_Administration_Proxies_CardProxies_CardProxies()
		{
			NavigateToMenuItem(_administration_Proxies_CardProxies_CardProxies);
		}

		
		private void NavigateToMenuItem(IWebElement element)
		{
			Driver.Url = element.GetAttribute("href");
		}
		#endregion

		public CardProxy(GlobalSettings settings) : base(settings) { }
	}  
}
