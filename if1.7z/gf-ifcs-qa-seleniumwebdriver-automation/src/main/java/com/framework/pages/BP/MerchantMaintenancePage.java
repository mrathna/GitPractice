package com.framework.pages.BP;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.ExtentTest;
import com.framework.basepage.BasePage;
import com.framework.pages.OLS.common.BPCommonPage;
import com.framework.repo.Locator;

public class MerchantMaintenancePage extends BasePage {

	@FindBy(id = Locator.ACCOUNTS_MENU)
	public WebElement accounts;

	@FindBy(how = How.ID, using = Locator.MERCHANT)
	public WebElement merchant;

	@FindBy(how = How.XPATH, using = Locator.PAGETITLE_SETTLEMENT)
	public WebElement pageTitleSettlement;

	@FindBy(how = How.ID, using = Locator.MERCHANT_DETAILS)
	public WebElement merchantDetails;
	@FindBy(how = How.ID, using = Locator.MERCHANT_ADDRESS)
	public WebElement merchantAddress;
	@FindBy(how = How.ID, using = Locator.MERCHANT_CONTACT_INFO)
	public WebElement merchantContactInfo;

	@FindBy(how = How.ID, using = Locator.MERCHANT_PHYSICAL_COUNTRY)
	public WebElement physicalCountry;
	@FindBy(how = How.ID, using = Locator.MERCHANT_POSTAL_COUNTRY)
	public WebElement postalCountry;

	@FindBy(how = How.ID, using = Locator.MERCHANT_CONTACT_INFORMATION_SAVE)
	public WebElement saveButton;
	@FindBy(how = How.ID, using = Locator.CONFIRMATIONMESSAGE)
	public WebElement confirmationMessage;

	BPCommonPage bpCommonPage = new BPCommonPage(driver, test);

	public MerchantMaintenancePage(WebDriver driver, ExtentTest test) {
		super(driver, test);
		// TODO Auto-generated constructor stub
		PageFactory.initElements(driver, this);
	}

	public void clickMerchantSubMenuAndValidatePage() {

		clickSubMenuAndValidate(accounts, merchant, pageTitleSettlement);

	}

	public void verifyMerchantMaitenanecePageFields() {
		isDisplayed(merchantDetails, "Merchant Details");
		isDisplayed(merchantAddress, "Merchant Address");
		isDisplayed(merchantContactInfo, "Merchant Contact Info");

	}

	public void updateMerchantDetailsForAccount() {
		String phyAddress = fakerAPI().address().buildingNumber() + ",\n" + fakerAPI().address().streetAddress() + ",\n"
				+ fakerAPI().address().cityName();

		String postalAddress = fakerAPI().address().buildingNumber() + ",\n" + fakerAPI().address().streetAddress()
				+ ",\n" + fakerAPI().address().cityName();

		// String phySuburb = FakerAPI().address().cityName();
		//
		// String postalSuburb = FakerAPI().address().cityName();

		isDisplayedThenEnterText(bpCommonPage.physicalAddress, "Physical Address", phyAddress);

		isDisplayedThenEnterText(bpCommonPage.postalAddress, "Mailing Address", postalAddress);

		// isDisplayedThenEnterText(bpCommonPage.physicalSuburb, "Physical Suburb",
		// phySuburb);

		// isDisplayedThenEnterText(bpCommonPage.postalSuburb, "Mailing Suburb",
		// postalSuburb);

		isDisplayedThenEnterText(bpCommonPage.postalCodePhy, "Postal code - Physical address",
				fakerAPI().number().digits(4));

		isDisplayedThenEnterText(bpCommonPage.postalCodeMailing, "Postal code - Postal address",
				fakerAPI().number().digits(4));

		// bpCommonPage.selectPhysicalState(); // physical state
		// bpCommonPage.selectPostalState(); // Postal state
		bpCommonPage.selectPhysicalCountry(); // PhysicalCountry
		bpCommonPage.selectPostalCountry(); // PostalCountry

		isDisplayedThenEnterText(bpCommonPage.contactName, "Contact Name", fakerAPI().name().name());

		isDisplayedThenEnterText(bpCommonPage.phone, "Phone", fakerAPI().phoneNumber().phoneNumber());

		isDisplayedThenEnterText(bpCommonPage.emailLocation, "Email", fakerAPI().internet().emailAddress());

		isDisplayedThenEnterText(bpCommonPage.mobile, "Mobile", fakerAPI().phoneNumber().cellPhone());

		isDisplayedThenEnterText(bpCommonPage.jobTitle, "Job Title", fakerAPI().job().title());

		isDisplayedThenEnterText(bpCommonPage.fax, "Fax", fakerAPI().number().digits(7));

	}

	public void updateMerchantPostalsubandstateforAccount(String clientCountry) {
		if (clientCountry.equalsIgnoreCase("AU")) {
			String phySuburb = fakerAPI().address().cityName();
			String postalSuburb = fakerAPI().address().cityName();
			isDisplayedThenEnterText(bpCommonPage.physicalSuburb, "Physical Suburb", phySuburb);

			isDisplayedThenEnterText(bpCommonPage.postalSuburb, "Mailing Suburb", postalSuburb);
			bpCommonPage.selectPhysicalState();// physical state
			bpCommonPage.selectPostalState(); // Postal state
			// bpCommonPage.selectPostalCountry(); // PostalCountry
		}
	}

	public void clickSaveButton() {

		isDisplayedThenActionClick(saveButton, "Save Button");

	}

	public void checkConfirmationMessage() {
		try {
			if (confirmationMessage.isDisplayed()) {
				String confirmationText = "Congratulations. Your merchant details have been saved.";
				logPass("Confirmation message is displayed");
				verifyText(confirmationMessage, confirmationText);
			
			} else {
				logFail("Confirmation message is not displayed");
			}
		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
	}
}
