package com.framework.testcases.OLS.BP.Location;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.BP.BPHomePage;
import com.framework.pages.OLS.common.BPCommonPage;
import com.framework.pages.OLS.common.LoginPage;
import com.framework.pages.OLS.common.ViewAndEditContactsPage;

public class ValidateLocationContactsPage extends BaseTest {
	@Parameters({"clientCountry", "clientName"})
	@Test( groups = { "Smoke", "Regression","BusinessFlow" })
	public void Validate_Location_Add_Contact(@Optional("AU") String clientCountry,@Optional("BP") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  BP Location Contacts Validation", "Location Contact Add/Edit Validation");
		LoginPage loginPage = new LoginPage(driver, test);
		BPHomePage bpHomePage = new BPHomePage(driver, test);
		loginPage.Login("BP_URL", "BP_UN_Location_" + clientCountry, "BP_PWD_Location_" + clientCountry, clientName);
		bpHomePage.ValidateBPLocOrMerchantLogo(clientCountry);
		BPCommonPage commonPage = new BPCommonPage(driver, test);
		ViewAndEditContactsPage BPviewAndEditContactPage = new ViewAndEditContactsPage(driver, test);

		// ** Add Contact
		commonPage.selectAccount();
		bpHomePage.loadAccountContactMenu();

		BPviewAndEditContactPage.getContactsAlreadyHave("Location");
		BPviewAndEditContactPage.clickAddContactButton("Location");
		BPviewAndEditContactPage.chooseUniqueContactType("Location");
		if (BPviewAndEditContactPage.isUniqueContactPresent()) {
			BPviewAndEditContactPage.setContactAsDefault();
			BPviewAndEditContactPage.enterContactInformationDetails();
			BPviewAndEditContactPage.enterContactAddressDetails(clientCountry, "Location");
			BPviewAndEditContactPage.saveContactDetails("Location");
			BPviewAndEditContactPage.clickBackToContactList();
		}

		// ** Edit Contact
		commonPage.selectAccount();

		bpHomePage.loadAccountContactMenu();
		BPviewAndEditContactPage.selectAContactFromMercOrLocContacts("Location");
		BPviewAndEditContactPage.editContactName();
		BPviewAndEditContactPage.saveContactDetails("Location");
		BPviewAndEditContactPage.clickBackToContactList();
		BPviewAndEditContactPage.checkContactExportOptionInMercOrLoc();
		
		loginPage.Logout();

	}

}
