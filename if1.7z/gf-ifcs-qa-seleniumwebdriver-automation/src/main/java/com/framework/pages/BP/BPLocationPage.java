package com.framework.pages.BP;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.ExtentTest;
import com.framework.basepage.BasePage;
import com.framework.pages.OLS.common.BPCommonPage;
import com.framework.repo.Locator;

public class BPLocationPage extends BasePage {

	public BPLocationPage(WebDriver driver, ExtentTest test) {
		super(driver, test);
		PageFactory.initElements(driver, this);
		// TODO Auto-generated constructor stub
	}

	@FindBy(id = Locator.ACCOUNTS_MENU)
	public WebElement accounts;

	@FindBy(id = Locator.AU_LOCATION)
	public WebElement locationSubMenu;

	@FindBy(xpath = Locator.LOCATION_MAIN_TITLE)
	public WebElement locMainTitle;

	@FindBy(id = Locator.BPLOGO_LOC_MERCH)
	public WebElement bpLogoLocation;

	@FindBy(id = Locator.ACCOUNTS_DROPDOWN)
	public WebElement accountsDropDown;

	@FindBy(id = Locator.LOC_ACC_NAME)
	public WebElement locAccName;

	@FindBy(id = Locator.AU_SAVE)
	public WebElement saveBTN;

	BPCommonPage bpCommonPage = new BPCommonPage(driver, test);

	public void clickLocationSubMenuAndValidatePage() {

		clickSubMenuAndValidate(accounts, locationSubMenu, locMainTitle);

	}

	public void getAccountDetailsAndValidate() {
		// System.out.println("------ Comes in here ------");

		String expAccName = bpCommonPage.selectAccount();

		// System.out.println("------ expAccName ------"+expAccName);
		try {
			if (locAccName.isDisplayed()) {
				String locAccNameText = locAccName.getText().trim();
				if (expAccName.contains(locAccNameText)) {
					logPass("Expected " + expAccName + " and Actual Account name " + locAccNameText
							+ " in Location Maintenance page are equal");
				}

				else {
					logFail("Expected " + expAccName + " and Actual Account name " + locAccNameText
							+ " in Location Maintenance page are not equal");
				}
			}
		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
	}

	public void updateLocationDetailsForAccount(String clientCountry) {
		String phyAddress = fakerAPI().address().buildingNumber() + ",\n" + fakerAPI().address().streetAddress() + ",\n"
				+ fakerAPI().address().cityName();

		String postalAddress = fakerAPI().address().buildingNumber() + ",\n" + fakerAPI().address().streetAddress()
				+ ",\n" + fakerAPI().address().cityName();

		String phySuburb = fakerAPI().address().cityName();

		String postalSuburb = fakerAPI().address().cityName();

		isDisplayedThenEnterText(bpCommonPage.physicalAddress, "Physical Address", phyAddress);

		isDisplayedThenEnterText(bpCommonPage.postalAddress, "Mailing Address", postalAddress);

		isDisplayedThenEnterText(bpCommonPage.physicalSuburb, "Physical Suburb", phySuburb);

		isDisplayedThenEnterText(bpCommonPage.postalCodePhy, "Postal code - Physical address",
				fakerAPI().number().digits(4));

		isDisplayedThenEnterText(bpCommonPage.postalCodeMailing, "Postal code - Postal address",
				fakerAPI().number().digits(4));

		if (clientCountry.equals("AU")) {
			isDisplayedThenEnterText(bpCommonPage.postalSuburb, "Mailing Suburb", postalSuburb);

			bpCommonPage.selectPhysicalState(); // physical state

			bpCommonPage.selectPostalState(); // Postal state

		}

		isDisplayedThenEnterText(bpCommonPage.contactName, "Contact Name", fakerAPI().name().name());

		isDisplayedThenEnterText(bpCommonPage.phone, "Phone", fakerAPI().phoneNumber().phoneNumber());

		isDisplayedThenEnterText(bpCommonPage.emailLocation, "Email", fakerAPI().internet().emailAddress());

		isDisplayedThenEnterText(bpCommonPage.mobile, "Mobile", fakerAPI().phoneNumber().cellPhone());

		isDisplayedThenEnterText(bpCommonPage.jobTitle, "Job Title", fakerAPI().job().title());

		isDisplayedThenEnterText(bpCommonPage.fax, "Fax", fakerAPI().number().digits(7));

	}

	public void saveDetailsAndValidate() {
		isDisplayedThenClick(saveBTN, "Save Button");
		scrollUpPage();

		boolean isContactsSaved = waitForTextToAppear("Congratulations. Your location details have been saved.", 10);

		if (isContactsSaved) {
			logPass("All Location details are saved");
		}

		else {
			logFail("Location details are not saved");
		}

	}

}
