package com.framework.testcases.AJS.EMAP;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.MaintainCustomerPage;
import com.framework.pages.AJS.common.Common;
import com.framework.pages.AJS.common.IFCSHomePage;
import com.framework.pages.AJS.common.IFCSLoginPage;

public class ValidateCloneApplicationTestCase extends BaseTest {
	/** Completed - Nithya Manikandan **/
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "Regression" })
	public void validateCloneApplication(@Optional("SG") String clientCountry, @Optional("EMAP") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  Desktop - Clone the Application", "Clone application");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCShomePage = new IFCSHomePage(driver, test);
		Common common = new Common(driver, test);
		MaintainCustomerPage maintainCustomerPage = new MaintainCustomerPage(driver, test);

		IFCSloginPage.login("IFCS_URL_EMAP", "IFCS_EMAP_USERNAME", "IFCS_EMAP_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		IFCShomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);

		IFCShomePage.gotoApplicationAndClickApplicationMenu();
		maintainCustomerPage.selectApplicationWithStatus("TL APP approved");
		common.clickCloneIcon();

		maintainCustomerPage.createNewApplication(clientCountry+" General");
		// Validate and clone
		maintainCustomerPage.clickSaveIcon();
		
		//Validate cloned Form
		maintainCustomerPage.validateClonedApplication();

		IFCShomePage.exitIFCS();

	}

}
