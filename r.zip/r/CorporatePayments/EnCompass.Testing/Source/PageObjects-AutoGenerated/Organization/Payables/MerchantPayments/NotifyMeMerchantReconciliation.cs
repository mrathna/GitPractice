using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using Common;
using Common.PageObjects;
using Common.ScenarioConfigurations;
using Common.Utility;

namespace EnCompass.Testing.Source.PageObjects.Organization.Payables.MerchantPayments 
{
	/// <summary>
	/// Auto-generated Page Model Class
	/// Navigation Paths: 
		/// [Organization Home]->Payables->Accounts Payable->Merchant Log Reconciliation
		/// </summary>
	[PageModel(@"/payables/merchantPayments/NotifyMeMerchantReconciliation.aspx")]
	public partial class NotifyMeMerchantReconciliation : EnCompassOrgPageModel 
	{
		public override string RelativeUrl => @"/payables/merchantPayments/NotifyMeMerchantReconciliation.aspx";
		public override string PageIdentifierXPath_Generated => @"//li[contains(@class, 'breadcrumb-item active')][text() = 'Merchant Log Reconciliation']";

		#region Navigation
				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Merchant Logs']")]
		private IWebElement _payables_AccountsPayable_MerchantLogReconciliation_MerchantLogs { get; set; }
		public void NavigateTo_Payables_AccountsPayable_MerchantLogReconciliation_MerchantLogs()
		{
			NavigateToMenuItem(_payables_AccountsPayable_MerchantLogReconciliation_MerchantLogs);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Create Merchant Log']")]
		private IWebElement _payables_AccountsPayable_MerchantLogReconciliation_CreateMerchantLog { get; set; }
		public void NavigateTo_Payables_AccountsPayable_MerchantLogReconciliation_CreateMerchantLog()
		{
			NavigateToMenuItem(_payables_AccountsPayable_MerchantLogReconciliation_CreateMerchantLog);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Merchant Log Reconciliation']")]
		private IWebElement _payables_AccountsPayable_MerchantLogReconciliation_MerchantLogReconciliation { get; set; }
		public void NavigateTo_Payables_AccountsPayable_MerchantLogReconciliation_MerchantLogReconciliation()
		{
			NavigateToMenuItem(_payables_AccountsPayable_MerchantLogReconciliation_MerchantLogReconciliation);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Merchant Log Settings']")]
		private IWebElement _payables_AccountsPayable_MerchantLogReconciliation_MerchantLogSettings { get; set; }
		public void NavigateTo_Payables_AccountsPayable_MerchantLogReconciliation_MerchantLogSettings()
		{
			NavigateToMenuItem(_payables_AccountsPayable_MerchantLogReconciliation_MerchantLogSettings);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Disputes']")]
		private IWebElement _payables_AccountsPayable_MerchantLogReconciliation_Disputes { get; set; }
		public void NavigateTo_Payables_AccountsPayable_MerchantLogReconciliation_Disputes()
		{
			NavigateToMenuItem(_payables_AccountsPayable_MerchantLogReconciliation_Disputes);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Merchants']")]
		private IWebElement _payables_AccountsPayable_MerchantLogReconciliation_Merchants { get; set; }
		public void NavigateTo_Payables_AccountsPayable_MerchantLogReconciliation_Merchants()
		{
			NavigateToMenuItem(_payables_AccountsPayable_MerchantLogReconciliation_Merchants);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Merchant Enrollment Status']")]
		private IWebElement _payables_AccountsPayable_MerchantLogReconciliation_MerchantEnrollmentStatus { get; set; }
		public void NavigateTo_Payables_AccountsPayable_MerchantLogReconciliation_MerchantEnrollmentStatus()
		{
			NavigateToMenuItem(_payables_AccountsPayable_MerchantLogReconciliation_MerchantEnrollmentStatus);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='EnCircle Enrollment']")]
		private IWebElement _payables_AccountsPayable_MerchantLogReconciliation_EncircleEnrollment { get; set; }
		public void NavigateTo_Payables_AccountsPayable_MerchantLogReconciliation_EncircleEnrollment()
		{
			NavigateToMenuItem(_payables_AccountsPayable_MerchantLogReconciliation_EncircleEnrollment);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='AR-Exchange Invoices']")]
		private IWebElement _payables_AccountsPayable_MerchantLogReconciliation_ArExchangeInvoices { get; set; }
		public void NavigateTo_Payables_AccountsPayable_MerchantLogReconciliation_ArExchangeInvoices()
		{
			NavigateToMenuItem(_payables_AccountsPayable_MerchantLogReconciliation_ArExchangeInvoices);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Create Single-Use Accounts']")]
		private IWebElement _payables_AccountsPayable_MerchantLogReconciliation_CreateSingleUseAccounts { get; set; }
		public void NavigateTo_Payables_AccountsPayable_MerchantLogReconciliation_CreateSingleUseAccounts()
		{
			NavigateToMenuItem(_payables_AccountsPayable_MerchantLogReconciliation_CreateSingleUseAccounts);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Create Test Transactions']")]
		private IWebElement _payables_AccountsPayable_MerchantLogReconciliation_CreateTestTransactions { get; set; }
		public void NavigateTo_Payables_AccountsPayable_MerchantLogReconciliation_CreateTestTransactions()
		{
			NavigateToMenuItem(_payables_AccountsPayable_MerchantLogReconciliation_CreateTestTransactions);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Start CLU or ECLU']")]
		private IWebElement _payables_AccountsPayable_MerchantLogReconciliation_StartCluOrEclu { get; set; }
		public void NavigateTo_Payables_AccountsPayable_MerchantLogReconciliation_StartCluOrEclu()
		{
			NavigateToMenuItem(_payables_AccountsPayable_MerchantLogReconciliation_StartCluOrEclu);
		}

		
		private void NavigateToMenuItem(IWebElement element)
		{
			Driver.Url = element.GetAttribute("href");
		}
		#endregion

		public NotifyMeMerchantReconciliation(GlobalSettings settings) : base(settings) { }
	}  
}
