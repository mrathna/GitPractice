﻿using AventStack.ExtentReports;
using Common;
using Common.Utility;
using NFluent;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EnCompass.Testing.Source.PageObjects.Organization.Payables.MerchantPayments
{
    [PageModel(@"/payables/merchantPayments/EditPaymentMethod.aspx")]
    public partial class EditPaymentMethod : EnCompassOrgPageModel
    {
        public override string RelativeUrl => @"/payables/merchantPayments/EditPaymentMethod.aspx";
        public override string PageIdentifierXPath_Override => @"//h1[normalize-space(text())='Create Payment Method' or normalize-space(text())='Edit Payment Method']";

        #region XPath page Elements
        private const string _saveXPath = @"//input[contains(@id,'btnSubmit')]";
        private const string _emailXPath = @"//textarea[contains(@id,'Email')]";
        private const string _faxCountryXPath = @"//select[contains(@id,'ddlCountry')]";
        private const string _faxNumberXPath = @"//input[contains(@id,'Fax_txtPhone')]";
        private const string _billingCurrencyXPath = @"//select[contains(@id,'CurrencyDropdown')]";
        private const string _accountNumberXPath = @"//input[contains(@id,'txtAccountNumber')]";
        private const string _ACHaccountNumberXPath = @"//input[contains(@id,'txtACHAccountNumber')]";
        private const string _newAccountNumberXPath = @"//input[contains(@id,'cbRequestNewCard')]";
        private const string _newAccountNumberLabelXPath = @"//label[contains(@for,'cbRequestNewCard')]";
        private const string _paymentMethodXPath = @".//select[contains(@id,'ddlPaymentMethod')]";
        private const string _singleUseAccCheckboxXPath = @"//input[contains(@id,'chkUseRotatingAccounts')]";
        private const string _singleUseAccCheckboxLabelXPath = @"//label[contains(@for,'chkUseRotatingAccounts')]";
        private const string _paymentGatewayIdXPath = @"//input[contains(@id,'PaymentGatewayId')]";
        private const string _taxPayerIdXPath = @"//input[contains(@id,'TaxPayerId')]";
        private const string _routingNumberXPath = "//input[contains(@id,'ACHRoutingNumber')]";
        private const string _confirmBtnXPath = "//button[text()='Confirm']";
        private const string _txtUniqueIdentifierXPath = "//input[contains(@id,'txtUniqueIdentifier')]";
        private const string _notificationMethodNoneRBXPath = @"//input[contains(@id,'rblDeliveryMethod_0')]";
        private const string _notificationMethodEmailRBXPath = @"//input[contains(@id,'rblDeliveryMethod_1')]";
        private const string _notificationMethodFaxRBXPath = @"//input[contains(@id,'rblDeliveryMethod_2')]";
        private const string _notificationMethodBothRBXPath = @"//input[contains(@id,'rblDeliveryMethod_3')]";
        private const string _notificationMethodNoneLabelXPath = @"//label[contains(@for,'rblDeliveryMethod')][text()='None']";
        private const string _notificationMethodEmailLabelXPath = @"//label[contains(@for,'rblDeliveryMethod')][text()='Email']";
        private const string _notificationMethodFaxLabelXPath = @"//label[contains(@for,'rblDeliveryMethod')][text()='Fax']";
        private const string _notificationMethodBothLabelXPath = @"//label[contains(@for,'rblDeliveryMethod')][text()='Both']";
        private const string _merchantCaptionXPath = @"//input[contains(@id, 'ltCaption')]";
        private const string _requiredPINXPath = @"//select[contains(@id, 'RequirePin')]";
        private const string _accountViewPINXPath = @"//input[contains(@id, 'txtPIN')]";
        private const string _emailPINNoticeXPath = @"//select[contains(@id, 'EmailPinToDefinedMerchant')]";
        private const string _cancelXPath = @"//input[contains(@id,'btnCancel')]";
        private const string _txtACHRoutingNumberXPath = @"//input[contains(@id,'txtACHRoutingNumber')]";
        private const string _txtACHAccountNumberXPath = @"//input[contains(@id,'txtACHAccountNumber')]";
        private const string _authPaymentGatwayXPath = @"//input[contains(@id, 'cbVendorEnrollment')]";
        private const string _paymentGatwayFirstNameXPath = @"//input[contains(@id, 'txtFirstNameMerchantOrgEnroll')]";
        private const string _paymentGatwayLastNameXPath = @"//input[contains(@id, 'txtLastNameMerchantOrgEnroll')]";
        private const string _cardProductXPath = @"//select[contains(@id, 'ddlCardProduct')]";
        private const string _paymentGatewayIdLabelXPath = @"//label[contains(@id, 'PaymentGatewayLabel')]";
        private const string _enrollmentStatusXPath = @"//input[contains(@id, 'txtEnrollmentStatus')]";
        private const string _numberOfPlasticsXPath = @"//select[contains(@id, 'ddlPlastics')]";
        private const string _chkManagedCreditLimitXPath = @"//input[contains(@id, 'chkManagedCreditLimit')]";
        private const string _chkManagedCreditLimitLabelXPath = "//label[contains(@for, 'chkManagedCreditLimit')]";
        private const string _achCreditFormatXPath = @".//select[contains(@id,'ddlACHStandardEntryClassCode')]";
        #endregion
        
        #region Page Elements
        private IWebElement _save
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_saveXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_save element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _email
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_emailXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_email element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _faxCountry
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_faxCountryXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_faxCountry element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _faxNumber
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_faxNumberXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_faxNumber element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _billingCurrency
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_billingCurrencyXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_billingCurrency element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _accountNumber
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_accountNumberXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_accountNumber element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _ACHaccountNumber
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_ACHaccountNumberXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_ACHaccountNumber element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _newAccountNumber
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_newAccountNumberXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_newAccountNumber element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _newAccountNumberLabel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_newAccountNumberLabelXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_newAccountNumberLabel element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _paymentMethod
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_paymentMethodXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_paymentMethod element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _singleUseAccCheckbox
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_singleUseAccCheckboxXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_singleUseAccCheckbox element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _singleUseAccCheckboxLabel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_singleUseAccCheckboxLabelXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_singleUseAccCheckboxLabel element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _paymentGatewayId
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_paymentGatewayIdXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_paymentGatewayId element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _taxPayerId
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_taxPayerIdXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_taxPayerId element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _routingNumber
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_routingNumberXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_routingNumber element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _confirmBtn
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_confirmBtnXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_confirmBtn element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _txtUniqueIdentifier
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_txtUniqueIdentifierXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_txtUniqueIdentifier element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _notificationMethodNoneRB
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_notificationMethodNoneRBXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_notificationMethodNoneRB element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _notificationMethodEmailRB
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_notificationMethodEmailRBXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_notificationMethodEmailRB element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _notificationMethodFaxRB
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_notificationMethodFaxRBXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_notificationMethodFaxRB element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _notificationMethodBothRB
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_notificationMethodBothRBXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_notificationMethodBothRB element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _notificationMethodNoneLabel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_notificationMethodNoneLabelXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_notificationMethodNoneLabel element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _notificationMethodEmailLabel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_notificationMethodEmailLabelXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_notificationMethodEmailLabel element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _notificationMethodFaxLabel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_notificationMethodFaxLabelXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_notificationMethodFaxLabel element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _notificationMethodBothLabel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_notificationMethodBothLabelXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_notificationMethodBothLabel element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _merchantCaption
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_merchantCaptionXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_merchantCaption element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _requiredPIN
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_requiredPINXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_requiredPIN element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _accountViewPIN
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_accountViewPINXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_accountViewPIN element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _emailPINNotice
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_emailPINNoticeXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_emailPINNotice element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _cancel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_cancelXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_cancel element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _txtACHRoutingNumber
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_txtACHRoutingNumberXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_txtACHRoutingNumber element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _txtACHAccountNumber
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_txtACHAccountNumberXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_txtACHAccountNumber element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _authPaymentGatway
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_authPaymentGatwayXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_authPaymentGatway element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _paymentGatwayFirstName
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_paymentGatwayFirstNameXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_paymentGatwayFirstName element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _paymentGatwayLastName
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_paymentGatwayLastNameXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_paymentGatwayLastName element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _cardProduct
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_cardProductXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_cardProduct element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _paymentGatewayIdLabel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_paymentGatewayIdLabelXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_paymentGatewayIdLabel element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _enrollmentStatus
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_enrollmentStatusXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_enrollmentStatus element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _numberOfPlastics
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_numberOfPlasticsXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_numberOfPlastics element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _chkManagedCreditLimit
        {
            get
            {
                bool found = Driver.TryWaitForElement(By.XPath(_chkManagedCreditLimitXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_chkManagedCreditLimit element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _chkManagedCreditLimitLabel
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_chkManagedCreditLimitLabelXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_chkManagedCreditLimitLabel element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        private IWebElement _achCreditFormat
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_achCreditFormatXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_achCreditFormat element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        #endregion

        public string GetMerchantCreatedMessage
        {
            get { return SuccessMessage; }
        }
        
        public string ACHRoutingNumber
        {
            get { return _txtACHRoutingNumber.GetAttribute("value"); }
            set { _txtACHRoutingNumber.Clear(); _txtACHRoutingNumber.SendKeys(value); }
        }

        public string ACHAccountNumber
        {
            get { return _txtACHAccountNumber.GetAttribute("value"); }
            set { _txtACHAccountNumber.Clear(); _txtACHAccountNumber.SendKeys(value); }
        }

        public string Email
        {
			get { return _email.GetAttribute("value").Trim(); }
            set
            {
                //Email is wrongly entered in IE hence JS sendkeys is used
                _email.JSSendKeys(Driver,value);
                Settings.EnCompassExtentTest.Info("Email:" + value);
				Settings.Scenario["MerchantEmail"] = value;
				Settings.EnCompassExtentTest.Info("Storing MerchantEmail as:" + value);
			}
        }

        public string EmailPayments
        {
            get
            {
                string val = _email.GetAttribute("value");
                Settings.EnCompassExtentTest.Info("Email for Payment Method:" + val);
                return val;
            }
            set
            {
                _email.SendKeys(value + ";");
                Settings.EnCompassExtentTest.Info("Email for Payment Method set to:" + value);
            }
        }

        private string remitTemplateXpath = "//select[contains(@id,'_ddlNotificationTemplate')]";
		public string RemitTemplate
		{
			set
			{
				IWebElement _element = Driver.WaitForVisible(By.XPath(remitTemplateXpath));				
				_element.SetListboxByText(value, SelectTextOptions.Contains);
				Settings.EnCompassExtentTest.Info("Remit Template:" + value);
			}
		}

		public string FaxCountry
		{
			get { return new SelectElement(_faxCountry).SelectedOption.Text; }
			set
			{
				var element = new SelectElement(_faxCountry);
				element.SelectByText(value);
			}
		}
		
        public string RequiredPIN
		{
			get { return new SelectElement(_requiredPIN).SelectedOption.Text; }
			set
            {
                // Mobile specific change
                _requiredPIN.SetListboxByText(value, SelectTextOptions.StartsWith, Driver, Settings, _requiredPINXPath);
            }
		}

		public string EmailPINNotice
		{
			get { return new SelectElement(_emailPINNotice).SelectedOption.Text; }
			set { _emailPINNotice.SetListboxByText(value, SelectTextOptions.StartsWith); }
		}

		public bool IsAccountViewPINEnabled
		{
			get { return _accountViewPIN.Enabled; }
		}

		public void WaitForAccountViewPINToBeDisabled()
		{
			int ctr = 0;
			while( IsAccountViewPINEnabled && ctr<10)
			{
				System.Threading.Thread.Sleep(500);
				ctr++;
			}
		}

		public string AccountViewPIN
		{
			get { return _accountViewPIN.GetAttribute("value").Trim(); }
			set
			{
				_accountViewPIN.WaitUntilElementIsInteractable();
				_accountViewPIN.Clear();
				_accountViewPIN.SendKeys(value);
				Settings.EnCompassExtentTest.Info("AccountViewPIN = " + value);
			}
		}
		public string FaxNumber
		{
			get { return _faxNumber.GetAttribute("value"); }
			set { _faxNumber.Clear(); _faxNumber.SendKeys(value); }
		}

		public string BillingCurrency
		{
			get { return new SelectElement(_billingCurrency).SelectedOption.Text; }
			set
			{
                if (Driver.IsElementPresent(By.XPath(_billingCurrencyXPath)))
                {
                    var element = new SelectElement(_billingCurrency);
                    var option = element.Options.FirstOrDefault(o => o.Text.StartsWith(value));
                    if (option != null)
                    {
                        element.SelectByText(option.Text);
                        Settings.EnCompassExtentTest.Info($"Billing Currency DDL set to {value}.");
                    }
                    else
                    {
                        throw new Exception($"Select Option not present in the list.");
                    }
                }

			}
		}

		public string BankAccountNumber
        {
            set
            {
                _accountNumber.Clear();
                _accountNumber.SendKeys(value);
				Settings.EnCompassExtentTest.Info("BankAccountNumber = " + value);
			}
        }

        public string ACHBankAccountNumber
        {
            set
            {
                _ACHaccountNumber.Clear();
                _ACHaccountNumber.SendKeys(value);
                Settings.EnCompassExtentTest.Info("ACH BankAccountNumber = " + value);
            }
        }

    public string RoutingNumber
		{
			set
			{
				_routingNumber.Clear();
				_routingNumber.SendKeys(value);
				Settings.EnCompassExtentTest.Info("RoutingNumber = " + value);
			}
		}

        public bool IsRoutingNumberDisabled()
        {

            if (!_routingNumber.Enabled)
                return true;

            else
                return false;

        }
        public bool IsAccountNumDisabled()
        {
            if (!_ACHaccountNumber.Enabled)
                return true;
            else
                return false;
        }

        public bool IsACHCreditFormatDisabled()
        {
            if (!_achCreditFormat.Enabled)
                return true;
            else
                return false;
        }

        public string ACHCreditFormat
        {
            get
            {
                return new SelectElement(_achCreditFormat).SelectedOption.Text;
            }
            set
            {
                new SelectElement(_achCreditFormat).SelectByText(value);
                Settings.EnCompassExtentTest.Info("ACH Credt Format:" + value);
            }
        }
        private static string _uniqueIdXpath = ".//input[contains(@id,'txtUniqueIdentifier')]";
		public string UniqueIdentifier
		{
			set
			{
				IWebElement _element = Driver.WaitForVisible(By.XPath(_uniqueIdXpath), TimeSpan.FromSeconds(10));
				_element.Clear();
				_element.SendKeys(value);
				Settings.EnCompassExtentTest.Info("UniqueIdentifier = " + value);
			}
		}


        public string MerchantNameCaption => _merchantCaption.GetAttribute("value");

		public bool RequestNewAccountNumber
		{
			get { return _newAccountNumber.Selected; }
			set
            {
                _newAccountNumber.SetCheckboxStateWithLabel(_newAccountNumberLabel, true);
                Settings.EnCompassExtentTest.Info("Request New Account Number:" + _newAccountNumber.Selected);
            }
		}

		public string PaymentGatewayId
		{
			get { return _paymentGatewayId.GetAttribute("value"); }
			set { _paymentGatewayId.Clear(); _paymentGatewayId.SendKeys(value); }
		}

		public string TaxPayerId
		{
			get { return _taxPayerId.GetAttribute("value"); }
			set
            {
                try
                {
                    _taxPayerId.Clear();
                    _taxPayerId.SendKeys(value);
                    Settings.EnCompassExtentTest.Info("TaxPayer ID =" + value);
                } catch (Exception)
                {
                    Settings.EnCompassExtentTest.Warning("Expected TaxPayer ID field but not found!!. Proceeding without setting the value.");
                }                 
            }
		}

		public bool NotificationNone
		{
			get { return _notificationMethodNoneRB.Selected; }
			set
			{
				_notificationMethodNoneRB.SetRadioButtonStateWithLabel(_notificationMethodNoneLabel, value);
                Settings.EnCompassExtentTest.Info($"Radio Button 'None' for Payment Method set to {value}.");
			}
		}

		public bool NotificationEmail
		{
			get { return _notificationMethodEmailRB.Selected; }
			set
			{
				_notificationMethodEmailRB.SetRadioButtonStateWithLabel(_notificationMethodEmailLabel, value);
                Settings.EnCompassExtentTest.Info($"Checkbox 'Email' for Payment Method set to {value}.");

            }
        }

		public bool NotificationFax
		{
			get { return _notificationMethodFaxRB.Selected; }
			set
			{
				_notificationMethodFaxRB.SetRadioButtonStateWithLabel(_notificationMethodFaxLabel, value);
                Settings.EnCompassExtentTest.Info($"Checkbox 'Fax' for Payment Method set to {value}.");
            }
        }

		public bool NotificationBoth
		{
			get { return _notificationMethodBothRB.Selected; }
			set
			{
				_notificationMethodBothRB.SetRadioButtonStateWithLabel(_notificationMethodBothLabel, value);
                Settings.EnCompassExtentTest.Info($"Checkbox 'Both' for Payment Method set to {value}.");
            }
        }

        public bool EnableManagedCreditLimit
        {
            get { return _chkManagedCreditLimit.Selected; }
            set
            {
                _chkManagedCreditLimit.SetCheckboxStateWithLabel(_chkManagedCreditLimitLabel, value);
                Settings.EnCompassExtentTest.Info("Checking the Managed Credit Limit Checkbox with value: " + value);
            }
        }

        private const string _cardPRodDDLXpath = ".//select[contains(@id,'ddlCardProduct')]";

        public string CardProduct
		{
			get
			{
				IWebElement element = Driver.WaitForVisible(By.XPath(_cardPRodDDLXpath));
				return new SelectElement(element).SelectedOption.Text;
			}
			set
			{
				IWebElement element = Driver.WaitForVisible(By.XPath(_cardPRodDDLXpath));
				
                // Mobile Specific change
                if (GlobalSettings.DeviceType.Equals(GlobalSettings.Device.MOBILE.ToString()))
                    Driver.SelectDDLOptionByTextViaJS(Settings, _cardPRodDDLXpath, value);
                else
                    new SelectElement(element).SelectByText(value);

                Settings.EnCompassExtentTest.Info("Card Product:" + value);
                this.WaitForFormLoadingOverlay();
            }
		}

        public void Cancel()
        {
            _cancel.JSClickWithFocus(Driver);
            Settings.EnCompassExtentTest.Info("Clicked on Cancel button");
        }

        public void Save()
        {
            _save.JSClickWithFocus(Driver);
			Settings.EnCompassExtentTest.Info("Clicked on Save button on Edit Payment Method");
            //Removed wait logic used here because it throw exception for some scenarios
			this.AttachOnDemandScreenShot();
		}

        public void Confirm()
        {
            _confirmBtn.JSClickWithFocus(Driver);
            Settings.EnCompassExtentTest.Info("Clicked on Confirm button on Edit Payment Method");
        }

        public new string GetErrorMessages
        {
            get
            {
                return Settings.EnCompassWebDriver.WaitForVisible(By.XPath("//div[contains(@id,'ValidationSummary')]/ul/li")).Text.Trim();
            }
        }

        /// <summary>
        /// Auto select Payment method as per the FI specific branding configured
        /// </summary>
        public void SetPaymentMethodAsPerFI()
        {
            StringKeys.APBrandingPerFI.TryGetValue(GlobalSettings.FI, out string value);
			_paymentMethod.SetListboxByText(value, SelectTextOptions.Exact, Driver, Settings, _paymentMethodXPath);			
            WaitForFormLoadingOverlay();
            Settings.EnCompassExtentTest.Info("Payment method selected, value: " + PaymentMethod);
        }

        public void SetBankCheckDelayToPaymentMethod(string whichText)
        {
            var selectElement = new SelectElement(_paymentMethod);
            selectElement.SelectByText(whichText);
        }

		/// <summary>
		/// set Payment Method
		/// </summary>
        public string PaymentMethod
        {
            get
            {
                return new SelectElement(_paymentMethod).SelectedOption.Text;
            }
            set
            {
				_paymentMethod.SetListboxByText(value,SelectTextOptions.Exact,Driver,Settings,_paymentMethodXPath);	
                Settings.EnCompassExtentTest.Info("Payment Method:" + PaymentMethod);
            }
        }

		public void CheckRequestNewAccountNumber(string cardProduct, ExtentTest test)
        {
            RequestNewAccountNumber = true;
            test.Info("Check the box Request New AccountNumber");
            WaitForLoad();
            CardProduct = cardProduct;
            test.Info("Select Card Product");
        }

        public void AuthPaymentGatway()
        {
            _authPaymentGatway.ClickCheckBox();
        }

		public bool AuthPaymentGatwaySelected()
		{
			return _authPaymentGatway.Selected;
		}


		public string PaymentGatwayFirstName
        {
            set
            {
                _paymentGatwayFirstName.Clear();
                _paymentGatwayFirstName.SendKeys(value);
            }
        }

		public string PaymentGatewayIdLable()
		{
			return _paymentGatewayIdLabel.Text;
		}

		public bool PaymentGatewayIdVisable()
		{
			return Driver.IsElementPresent(By.XPath(_paymentGatewayIdLabelXPath));
		}

		public bool PaymenetGatewayIdEditable()
		{
			return _paymentGatewayId.Enabled;
		}

		public bool EnrollmentStatusVisable()
		{
			return Driver.IsElementPresent(By.XPath(_enrollmentStatusXPath));
		}

		public string PaymentGatwayLastName
        {
            set
            {
                _paymentGatwayLastName.Clear();
                _paymentGatwayLastName.SendKeys(value);
            }
        }

        //Set Payment Method to the merchant
        public void SetPaymentMethodMerchant(string paymentMethodMerchant)
        {
            SetBankCheckDelayToPaymentMethod(paymentMethodMerchant);
            Settings.EnCompassExtentTest.Info("Set Payment method to merchant");
            Email = Settings.CeatedOrgId + "@wexinc.com";
            Settings.EnCompassExtentTest.Info("Set email address to merchant");
            if (!paymentMethodMerchant.ToLowerInvariant().Equals("check") && !paymentMethodMerchant.ToLowerInvariant().Equals("none"))
            {
                ACHAccountNumber = Settings.Scenario["ACHBankAccountNumber"].ToString();
                Settings.EnCompassExtentTest.Info("Set bank account Number");
                ACHRoutingNumber = "123456789";
                Settings.EnCompassExtentTest.Info("Set Routing Number");
            }
        }
		public void SetCardProductByCardProductType(string productType)
		{
			var selectElement = new SelectElement(_cardProduct);
			var cardProduct = selectElement.Options.First(c => c.Text.ToLower().Contains(productType.ToLower()));
			selectElement.SelectByText(cardProduct.Text);
		}

		public bool UseSingleUseAccounts
        {
            get { return _singleUseAccCheckbox.Selected; }
            set
            {
                    _singleUseAccCheckbox.SetCheckboxStateWithLabelJS(Driver, value);
                    this.WaitForFormLoadingOverlay();
                    Settings.EnCompassExtentTest.Info($"Use Single Use Accounts checkbox set To: {value}.");
            }
        }

        public string NumberOfPlastics
        {
            get { return new SelectElement(_numberOfPlastics).SelectedOption.Text; }
            set
            {
                var element = new SelectElement(_numberOfPlastics);
                element.SelectByText(value);
                Settings.EnCompassExtentTest.Info("Number of Plastics:" + value);
            }
        }

        public void CheckAbsenceACHProhibitedElements()
        {
            Settings.EnCompassExtentTest.Info("Checking for the absence of fields which should not be present when ACH is set.");
            Check.That(Driver.IsElementPresent(By.XPath(_chkManagedCreditLimitXPath))).IsFalse();
            Check.That(Driver.IsElementPresent(By.XPath(_accountNumberXPath))).IsFalse();
            Check.That(Driver.IsElementPresent(By.XPath(_billingCurrencyXPath))).IsFalse();
        }

        public void EnableNotificationMethodRadioButton(string notificationMethod)
        {
            // Enabling notification radioButton
            switch(notificationMethod.ToUpperInvariant().Trim())
            {
                case "NONE":
                    if (NotificationNone == false)
                    {
                        NotificationNone = true;
                        WaitForFormLoadingOverlay();
                        WaitForLoad();
                    }
                    break;

                case "EMAIL":
                    if (notificationMethod.ToLowerInvariant().Trim() == "email")
                    {
                        if (NotificationEmail == false)
                        {
                            NotificationEmail = true;
                            WaitForFormLoadingOverlay();
                            WaitForLoad();
                        }
                    }
                    break;

                case "FAX":
                    if (NotificationFax == false)
                    {
                        NotificationFax = true;
                        WaitForFormLoadingOverlay();
                        WaitForLoad();
                    }
                    break;

                case "BOTH":
                    if (NotificationBoth == false)
                    {
                        NotificationBoth = true;
                        WaitForFormLoadingOverlay();
                        WaitForLoad();
                    }
                    break;

                default:
                    throw new Exception($"Radio Button {notificationMethod} nonexistent in Payment Method.");
            }

            Settings.EnCompassExtentTest.Info($"Enabled Radio Button for Notification Method {notificationMethod}.");
        }

        public EditPaymentMethod(GlobalSettings Settings) : base(Settings) { }
    }
}
