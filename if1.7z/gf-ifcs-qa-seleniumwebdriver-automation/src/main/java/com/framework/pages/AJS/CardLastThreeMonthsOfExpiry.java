package com.framework.pages.AJS;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.ExtentTest;
import com.framework.basepage.BasePage;
import com.framework.pages.AJS.common.Common;
import com.framework.repo.Locator_IFCS;
import com.framework.util.SeleniumWrappers;

public class CardLastThreeMonthsOfExpiry extends BasePage {

	@FindBy(xpath=Locator_IFCS.SHELL_PARTNER_CARD)
	public WebElement shellPartnerCard;

	@FindBy(xpath=Locator_IFCS.POPUP_IFCS)
	public WebElement popupIFCS;

	

	@FindBy(xpath=Locator_IFCS.EXTEND_EXPIRY_PERIOD_WITHIN)
	public WebElement extendexpiryperiodwithin;

	@FindBy(xpath=Locator_IFCS.SH_PC_OPEN)
	public WebElement shPcOpen;
	@FindBy(xpath=Locator_IFCS.CARD_PRODUCTS)
	public WebElement CardProducts;

	@FindBy(xpath=Locator_IFCS.EMBOSSING_TAB)
	public WebElement Embossing;

	@FindBy(xpath=Locator_IFCS.OK_BUTTON)
	public WebElement okButton;
	@FindBy(xpath=Locator_IFCS.CANCEL_BUTTON)
	public WebElement cancelButton;
	@FindBy(xpath=Locator_IFCS.CUSTOMER_MAINTENANCE)
	public WebElement customerMaintenance;

	@FindBy(xpath=Locator_IFCS.CARD_REIISUE_PROFILE)
	public WebElement cardReissueProfile;

	


	Common common=new Common(driver,test);

	public CardLastThreeMonthsOfExpiry(WebDriver driver, ExtentTest test) {
		super(driver, test);
		PageFactory.initElements(driver, this);
	}

	public  void selectCardFromLeftPanel() {
		chooseSubMenuFromLeftPanel("Cards","Card Reissue Profiles");
		sleep(5);
		isDisplayed(shellPartnerCard,"Shell Partner card  is dispalyed");
		/*List<WebElement> list=driver.findElements(By.xpath("//div[@class='FALTableCellEditor_StrikeThruField JTextComponent']"));*/
		WebElement cellElement=SeleniumWrappers.getTableDataWithCellElement(0,1,driver);
		doubleClick(cellElement);

		isDisplayed(popupIFCS,"IFCS Text ");
		//isDisplayed(popupCardResissuProfile,"CardReissueProfile text Popup");
	}
	
	public void verifyExtendExpiryPeriodWithin() {
		verifyEnableFieldFromLabelAndTextInPopup("Controls","Extend Expiry Period Within","submittedvalue","3");
		isDisplayedThenClick(okButton,"OK button is displayed");	


	}

	public void selectCardOffersFromLeftPanel() {
		chooseSubMenuFromLeftPanel("Card Offers","Card Products");
		isDisplayed(shPcOpen,"Shell Pc Open is displayed");
		WebElement cellElement=SeleniumWrappers.getTableDataWithCellElement(0,1,driver);
		doubleClick(cellElement);
		switchTabDetails("Embossing");
	}
	
	public void verifyExpiryMonthAndMaximumExpiryMonth() {
		verifyEnableFieldFromLabelAndTextInPopup("Embossing Details","Expiry Month","submittedvalue","48");
		verifyEnableFieldFromLabelAndTextInPopup("Embossing Details","Maximum Expiry Month","submittedvalue","48");
		isDisplayedThenClick(okButton,"OK button is displayed");
	}

	public void selectCustomerProfilesFromCustomerMaintenmance(String customernumber) {
		isDisplayed(customerMaintenance,"Customer Maintenance text ");
		common.searchTorch();
		chooseOptionFromComboPopup("customernumber",customernumber);
		common.findRecordTorch();
		common.closeFindRecordTorch();
		chooseSubMenuFromLeftPanel("Customer Profiles","Card Reissue Profiles");
		isDisplayed(cardReissueProfile,"Card ReissueProfile Text is Displayed");
		//isDisplayed(shellPrePaidCard,"Shell Pre Paid Card is Displayed");
		WebElement cellElement=SeleniumWrappers.getTableDataWithCellElement(0,2,driver);
		doubleClick(cellElement);
		sleep(5);
	}
	
	public void verifyFromProtectedText() {
		verifyProtectedFieldFromLabelAndTextInPopup("Extend Expiry Period Within","3");
		isDisplayedThenClick(cancelButton,"cancel button is displayed");
		sleep(5);

	}








}
