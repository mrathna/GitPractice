package com.framework.testcases.BusinessFlow;


import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.Map;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.MaintainAccountPage;
import com.framework.pages.AJS.TransactionListPage;
import com.framework.pages.AJS.common.Common;
import com.framework.pages.AJS.common.IFCSCommonPage;
import com.framework.pages.AJS.common.IFCSHomePage;
import com.framework.pages.AJS.common.IFCSLoginPage;
import com.framework.pages.BusinessFlow.TransactionComponentPage;
import com.framework.pages.BusinessFlow.WFECommon;
import com.github.javafaker.Faker;


public class ValidatePaymentBusinessFlows2 extends BaseTest {

	/**
	 * Implemented by Nithya
	 * 
	 * @param clientCountry
	 * @param clientName    Business Flow ID:BF-102
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow" })
	public void postManualPaymentFromIFCS(@Optional("BE") String clientCountry, @Optional("WFE") String clientName) {

		test = extent.createTest(clientName + ":" + clientCountry + " TC-1496 TC01_Pymt_Mnulpymt_Unallocate the allocated_Manual payments",
				"RQ-902 CSR is paying using Manual payments for any other reason");
		IFCSLoginPage ifcsLoginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage ifcsHomePage = new IFCSHomePage(driver, test);
		IFCSCommonPage ifcsCommonPage = new IFCSCommonPage(driver, test);
		Common common = new Common(driver, test);
		ifcsLoginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		ifcsLoginPage.setClientCountryCardTypeDetails(clientName, clientCountry, " ");
		// Selecting client from Application Menu
		ifcsHomePage.gotoApplicationAndClickApplicationMenu();
		ifcsHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);
		String customerNumber = common.getActiveOrTemporaryBlockCustomerNoHavingCardsAndRowIndex(1, "Active");
		ifcsCommonPage.postManualPayments(customerNumber, "Other Payments", clientName + "_" + clientCountry);

		ifcsHomePage.exitIFCS();
	}

	/**
	 * Implemented by Raxsana Babu
	 * 
	 * @param clientCountry
	 * @param clientName    RQ-914
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow" })
	public void postManualWriteOffPaymentFromIFCS(@Optional("BE") String clientCountry,
			@Optional("WFE") String clientName) {

		test = extent.createTest(clientName + ":" + clientCountry + "TC-1493 TC07_Pymt_Write OFf Txn ",
				"RQ-914 TC-1493 TC07_Pymt_Write OFf Txn");
		IFCSLoginPage ifcsLoginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage ifcsHomePage = new IFCSHomePage(driver, test);
		WFECommon wfeCommon = new WFECommon(driver, test);
		ifcsLoginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		ifcsLoginPage.setClientCountryCardTypeDetails(clientName, clientCountry, " ");
		// Selecting client from Application Menu
		ifcsHomePage.gotoApplicationAndClickApplicationMenu();
		ifcsHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);
		wfeCommon.postManualWriteOffPayments("Manual Cheque Payment", clientName, clientCountry);
		ifcsHomePage.exitIFCS();
	}

	/**
	 * Implemented by Raxsana Babu
	 * 
	 * @param clientCountry
	 * @param clientName    RQ-914
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow" })
	public void postOpenCreditInvoiceToOpenInvoiceFromIFCS(@Optional("BE") String clientCountry,
			@Optional("WFE") String clientName) {

		test = extent.createTest(
				clientName + ":" + clientCountry
						+ "TC-1491 TC05_Pymt_partially allocate the Open Credit invoice to Open Invoice",
				"RQ-914 TC-1491 TC05_Pymt_partially allocate the Open Credit invoice to Open Invoice");
		IFCSLoginPage ifcsLoginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage ifcsHomePage = new IFCSHomePage(driver, test);
		TransactionComponentPage transactionComponentPage = new TransactionComponentPage(driver, test);
		WFECommon wfeCommon = new WFECommon(driver, test);
		Map<String, String> inputvalues = new HashMap<String, String>();
		TransactionListPage transactionListPage = new TransactionListPage(driver, test);
		Common common = new Common(driver, test);
		ifcsLoginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		ifcsLoginPage.setClientCountryCardTypeDetails(clientName, clientCountry, " ");
		// Selecting client from Application Menu
		ifcsHomePage.gotoApplicationAndClickApplicationMenu();
		ifcsHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);
		Faker fakerN = new Faker();
		String f_referenceNo = fakerN.number().digits(5);
		inputvalues = transactionComponentPage.inputValuesForTransaction(clientName, clientCountry, "Y", "");
		Map<String, String> inputValues = wfeCommon.getAccountDetailsForManualPayments(clientName, clientCountry,
				"Full");
		String cardNumber = common.getCardNumberForCustomerNo(inputValues.get("ACCOUNT_NO"));
		ifcsHomePage.gotoTransactionAndClickManageTransaction();

		transactionListPage.enterTransactionBatchDetails(true, inputValues.get("AMOUNT"), "1", clientName);
		transactionListPage.enterManualTransactionDetails(inputvalues.get("date"), f_referenceNo, cardNumber, "",
				inputvalues.get("LocationNumber"), inputValues.get("AMOUNT"), "");
		transactionListPage.enterTransactionLineItems("135", inputValues.get("AMOUNT"), inputValues.get("AMOUNT"),
				"100");
		transactionListPage.validatePostManualTransaction("Validation successful");
		transactionListPage.validatePostedInTransaction(f_referenceNo);

		ifcsHomePage.gotoTransactionAndClickManageTransaction();
		wfeCommon.postManualPayments("Cheque Payment", inputValues, clientName, clientCountry);
		wfeCommon.validateFullAlloctedAmount(inputValues);

		DecimalFormat df = new DecimalFormat("##.##");
		df.setRoundingMode(RoundingMode.UP);
		String returnTotal = String.valueOf(df.format(Double.parseDouble(inputValues.get("AMOUNT")) / 2));
		inputValues.replace("AMOUNT", returnTotal);

		wfeCommon.postManualPayments("Cheque Dishonour", inputValues, clientName, clientCountry);

		wfeCommon.validateUnallocatedDishonourPayment("Cheque Dishonour", inputValues);
		Faker faker = new Faker();
		String f_referenceNoReturn = faker.number().digits(5);
		ifcsHomePage.gotoTransactionAndClickManageTransaction();
		transactionListPage.enterTransactionBatchDetails(true, returnTotal, "1", clientName);
		transactionListPage.enterManualTransactionDetails(inputvalues.get("date"), f_referenceNoReturn, cardNumber, "",
				inputvalues.get("LocationNumber"), returnTotal, "Return");
		transactionListPage.enterTransactionLineItems("135", returnTotal, returnTotal, "100");
		transactionListPage.validatePostManualTransaction("Validation successful");
		transactionListPage.validatePostedInTransaction(f_referenceNoReturn);
		ifcsHomePage.exitIFCS();
	}

	/**
	 * Implemented by Raxsana Babu
	 * 
	 * @param clientCountry
	 * @param clientName    RQ-914
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow" })
	public void postOpenManualPaymentToOpenInvoiceFromIFCS(@Optional("BE") String clientCountry,
			@Optional("WFE") String clientName) {

		test = extent.createTest(
				clientName + ":" + clientCountry
						+ "TC-1492 TC06_Pymt_partially allocate the Open Manual Payment to Open invoice_same account",
				"RQ-914 TC-1492 TC06_Pymt_partially allocate the Open Manual Payment to Open invoice_same account");
		IFCSLoginPage ifcsLoginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage ifcsHomePage = new IFCSHomePage(driver, test);
		WFECommon wfeCommon = new WFECommon(driver, test);
		ifcsLoginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		ifcsLoginPage.setClientCountryCardTypeDetails(clientName, clientCountry, " ");
		// Selecting client from Application Menu
		ifcsHomePage.gotoApplicationAndClickApplicationMenu();
		ifcsHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);
		Map<String, String> inputValues = wfeCommon.getAccountDetailsForManualPayments(clientName, clientCountry,
				"Partial");
		wfeCommon.postManualPayments("Cheque Payment", inputValues, clientName, clientCountry);
		wfeCommon.validateAlloctedAmount(inputValues);
		String unllocatedAmount = wfeCommon.getAmountForPartialPayment();
		inputValues.replace("AMOUNT", unllocatedAmount);
		wfeCommon.postManualPayments("Cheque Payment", inputValues, clientName, clientCountry);
		wfeCommon.validateFullAlloctedAmount(inputValues);
		ifcsHomePage.exitIFCS();
	}

	/**
	 * Implemented by Rathna
	 * 
	 * @param clientCountry
	 * @param clientName    Business Flow ID:RQ-1016
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow" })
	public void postCustomerDDPaymentFromManualPayment(@Optional("BE") String clientCountry,
			@Optional("WFE") String clientName) {

		test = extent.createTest(clientName + ":" + clientCountry + "TC-1767 TC01_Manual_Payment_DD_Payment",
				"RQ-1016 : Customer payment using DD (DD Payment_ManualPayment)");
		IFCSLoginPage ifcsLoginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage ifcsHomePage = new IFCSHomePage(driver, test);
		IFCSCommonPage ifcsCommonPage = new IFCSCommonPage(driver, test);
		Common common = new Common(driver, test);
		ifcsLoginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		ifcsLoginPage.setClientCountryCardTypeDetails(clientName, clientCountry, " ");
		// Selecting client from Application Menu
		ifcsHomePage.gotoApplicationAndClickApplicationMenu();
		ifcsHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);
		String customerNumber = common.getActiveOrTemporaryBlockCustomerNoHavingCardsAndRowIndex(1, "Active");
		ifcsCommonPage.postManualPayments(customerNumber, "Direct Debit", clientName + "_" + clientCountry);

		ifcsHomePage.exitIFCS();
	}

	/**
	 * Implemented byRathna
	 *
	 * @param clientCountry
	 * @param clientName
	 * 
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow" })
	public void validatePaymentAutoAlloctionForDishonouredDD(@Optional("BE") String clientCountry,
			@Optional("WFE") String clientName) {

		test = extent.createTest(
				clientName + ":" + clientCountry
						+ "TC-1497 TC01_Pymt_Dishonoured DD payment_un-allocated automatically",
				"RQ-913: Processed DD entries are auto allocated to the DD Customers");
		IFCSLoginPage ifcsLoginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage ifcsHomePage = new IFCSHomePage(driver, test);
		WFECommon wfeCommon = new WFECommon(driver, test);
		//MaintainAccountPage maintainAccountPage = new MaintainAccountPage(driver, test);
		//Common common = new Common(driver, test);
		ifcsLoginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		ifcsLoginPage.setClientCountryCardTypeDetails(clientName, clientCountry, " ");
		// Selecting client from Application Menu
		ifcsHomePage.gotoApplicationAndClickApplicationMenu();
		ifcsHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);
		wfeCommon.postManualPayments("Manual DD Dishonour", "Direct Debit Dishonour", clientName, clientCountry);
		ifcsHomePage.gotoAccountAndClickAccountDetails();

		wfeCommon.CheckPaymentIsPosted("Maintain Unallocated Funds", "Debits");
		ifcsHomePage.exitIFCS();
	}

	/**
	 * Implemented byRathna
	 *
	 * @param clientCountry
	 * @param clientName
	 * 
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow" })
	public void validatePaymentAutoAlloctionForNonDDCustomers(@Optional("BE") String clientCountry,
			@Optional("WFE") String clientName) {

		test = extent.createTest(
				clientName + ":" + clientCountry
						+ "TC-1506 TC02_Pymt_Auto allocation of Payments_cover all billing document types",
				"TRQ-913: Processed DD entries are auto allocated to the DD Customers");
		IFCSLoginPage ifcsLoginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage ifcsHomePage = new IFCSHomePage(driver, test);
		WFECommon wfeCommon = new WFECommon(driver, test);
		MaintainAccountPage maintainAccountPage = new MaintainAccountPage(driver, test);
		Common common = new Common(driver, test);
		ifcsLoginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		ifcsLoginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		// Selecting client from Application Menu
		ifcsHomePage.gotoApplicationAndClickApplicationMenu();
		ifcsHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);
		wfeCommon.postManualPayments("Manual Cheque Payment", "Cheque Payment", clientName, clientCountry);
		ifcsHomePage.gotoAccountAndClickAccountDetails();
		wfeCommon.CheckPaymentIsPosted("Maintain Unallocated Funds", "Credits");
		ifcsHomePage.exitIFCS();
	}

	/**
	 * Implemented byRathna
	 *
	 * @param clientCountry
	 * @param clientName
	 * 
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow" })
	public void validatePaymentAutoAlloctionForNonDDCustomersAndAmmountMatched(@Optional("BE") String clientCountry,
			@Optional("WFE") String clientName) {

		test = extent.createTest(
				clientName + ":" + clientCountry
						+ "TC-1517 TC03_Pymt_Auto allocation for Non DD customers_document number and amount",
				"RQ-913: Processed DD entries are auto allocated to the DD Customers");
		IFCSLoginPage ifcsLoginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage ifcsHomePage = new IFCSHomePage(driver, test);
		WFECommon wfeCommon = new WFECommon(driver, test);
		MaintainAccountPage maintainAccountPage = new MaintainAccountPage(driver, test);
		Common common = new Common(driver, test);
		ifcsLoginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		ifcsLoginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		// Selecting client from Application Menu
		ifcsHomePage.gotoApplicationAndClickApplicationMenu();
		ifcsHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);

		wfeCommon.postManualPayments("Manual Cheque Payment", "Cheque Payment", clientName, clientCountry, "970106620",
				"401.67");
		ifcsHomePage.gotoAccountAndClickAccountDetails();
		wfeCommon.VerifyPostTransaction("Maintain Allocated Funds", "Credits", true);// Payment Reference"
		ifcsHomePage.exitIFCS();
	}

	/**
	 * Implemented byRathna
	 *
	 * @param clientCountry
	 * @param clientName
	 * 
	 */
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "BusinessFlow" })
	public void validatePaymentAutoAlloctionForNonDDCustomersAndAmmountNotMatched(@Optional("BE") String clientCountry,
			@Optional("WFE") String clientName) {

		test = extent.createTest(clientName + ":" + clientCountry
				+ "TC-1518 TC04_Pymt_Auto allocation should not happen for Non DD customers_mismatching the document number and amount",
				"RQ-913: Processed DD entries are auto allocated to the DD Customers");
		IFCSLoginPage ifcsLoginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage ifcsHomePage = new IFCSHomePage(driver, test);
		WFECommon wfeCommon = new WFECommon(driver, test);
		MaintainAccountPage maintainAccountPage = new MaintainAccountPage(driver, test);
		Common common = new Common(driver, test);
		ifcsLoginPage.login("IFCS_URL_" + clientName, "IFCS_" + clientName + "_USERNAME",
				"IFCS_" + clientName + "_PASSWORD");
		ifcsLoginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		// Selecting client from Application Menu
		ifcsHomePage.gotoApplicationAndClickApplicationMenu();
		ifcsHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);

		wfeCommon.postManualPayments("Manual Cheque Payment", "Cheque Payment", clientName, clientCountry, "970106620",
				"789.00");
		ifcsHomePage.gotoAccountAndClickAccountDetails();
		wfeCommon.VerifyPostTransaction("Maintain Allocated Funds", "Credits", false);// Payment Reference"
		ifcsHomePage.exitIFCS();
	}

}
	

