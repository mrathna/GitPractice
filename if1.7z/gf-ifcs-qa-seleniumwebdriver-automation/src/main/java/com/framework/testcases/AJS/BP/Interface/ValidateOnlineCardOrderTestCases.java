package com.framework.testcases.AJS.BP.Interface;


import java.util.ArrayList;
import java.util.HashMap;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.common.Common;
import com.framework.pages.AJS.common.IFCSHomePage;
import com.framework.pages.AJS.common.IFCSLoginPage;
import com.framework.pages.BP.BPHomePage;
import com.framework.pages.BP.BPOrderCard;
import com.framework.pages.OLS.common.BPCommonPage;
import com.framework.pages.OLS.common.FindAndUpdateCardPage;
import com.framework.pages.OLS.common.LoginPage;

public class ValidateOnlineCardOrderTestCases extends BaseTest{
	 
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "Smoke","BusinessFlow" })
	public void validateOnlineCardOrder(@Optional("AU") String clientCountry,
			@Optional("BP") String clientName) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  Onl_AU_002_Online Card order,Onl_AU_003_Online Card status", "Onl_AU_002_Online Card order,Onl_AU_003_Online Card status");
		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		BPOrderCard bpOrderCard = new BPOrderCard(driver, test);
		LoginPage loginPage = new LoginPage(driver, test);
		BPHomePage bpHomePage = new BPHomePage(driver, test);
		BPCommonPage bpCommonPage = new BPCommonPage(driver, test);
		FindAndUpdateCardPage findAndUpdateCardPage = new FindAndUpdateCardPage(driver, test);
		Common common=new Common(driver, test);
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		
		//OLS Order Card
		loginPage.Login("BP_URL", "BP_UN_Customer_" + clientCountry, "BP_PWD_Customer_" + clientCountry, clientName);
		
		// Calling Functions
		
		bpHomePage.ValidateBPCustomerLogo();
        bpCommonPage.selectAccount();
        String accountNumber = bpCommonPage.getAccountNumber();
		bpOrderCard.clickOrderCardAndValidatePage();
		bpOrderCard.orderCard("Driver");
	
		bpOrderCard.clickOrderCardAndValidatePage();
        bpOrderCard.clickBulkOrderAndUpdateCard();
        bpOrderCard.clickBulkCardOrderBtnAndValidate("Bulk_Order");
     
        //Fill the bulk card order template sheet
        HashMap<String, String> driverKeysAndValues=bpOrderCard.bulkCardOrderUsingExcelSheetTemplate("Bulk_Order",accountNumber,"Driver",5);
		System.out.println("KeysAndValues::"+driverKeysAndValues);
		
		bpOrderCard.assertColumnHeaders("BULKCARD");
		bpOrderCard.bulkOrderUpload("Bulk_Order");
		loginPage.Logout();
	
		IFCSloginPage.login("IFCS_URL_BP", "IFCS_BP_USERNAME", "IFCS_BP_PASSWORD");
		
		//Run Control-M jobs
		IFCSHomePage.gotoAdminBatchMenuAndChooseClient(clientName,clientCountry);
		common.batchJobExecution("Card Processing", "Online Card Management Request",
				"Online Card Ordering Request Processor");
		common.batchJobExecution("Card Processing", "Card Emboss Catalog", "Card Emboss Catalog");
		ArrayList<String> driverCardNos = bpOrderCard.getBulkCardNumberForCardType(driverKeysAndValues, "Driver");
		
		//validate bulk card ordered card numbers in IFCS
		common.validateBulkOrderedCardNumbersInIFCS(driverCardNos);
		
		IFCSHomePage.exitIFCS();
		
		loginPage.Login("BP_URL", "BP_UN_Customer_" + clientCountry, "BP_PWD_Customer_" + clientCountry, clientName);

		bpHomePage.loadFindAndUpdateCardPage();

		// Search in Find Update Card Page
		findAndUpdateCardPage.selectAccountFromFindUpdateCardPage();
		//validate bulk card ordered card numbers in OLS
		bpOrderCard.validateBulkOrderedCardsInOLS(driverCardNos);
		loginPage.Logout();
	
	}
}
