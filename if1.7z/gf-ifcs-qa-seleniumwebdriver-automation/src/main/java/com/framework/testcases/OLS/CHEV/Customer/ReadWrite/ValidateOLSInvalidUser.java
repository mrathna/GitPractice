package com.framework.testcases.OLS.CHEV.Customer.ReadWrite;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.OLS.common.LoginPage;
import com.framework.util.PropUtils;

public class ValidateOLSInvalidUser extends BaseTest {
	@Parameters({ "clientCountry", "clientName" })
	@Test(priority = 1)
	public void testCustomerReadWriteOLSInvalidUser(@Optional("TH") String clientCountry,
			@Optional("CHV") String clientName) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  OLS - Invalid User - Block on Multiple Times",
				"Chevron Customer Screens Read / Write / View Only / Status Change");

		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);

		loginPage.validateLoginPageFooterLinks(clientName, "CHV_URL");
		// Reset Log on Count as 0
		loginPage.resetLogonCountAsZeroForUser(
				PropUtils.getPropValue(configProp, "CHV_UN_ReadWrite_Customer_LockChk_" + clientCountry));

		// 1st Attempt
		loginPage.loginWithUsernameAndPwd(
				PropUtils.getPropValue(configProp, "CHV_UN_ReadWrite_Customer_LockChk_" + clientCountry),
				"invalidLoginPwd");
		loginPage.validateErrorMsgValidUsernameAndWrongPassword();

		// 2nd Attempt
		loginPage.loginWithUsernameAndPwd(
				PropUtils.getPropValue(configProp, "CHV_UN_ReadWrite_Customer_LockChk_" + clientCountry),
				"invalidLoginPwd");
		loginPage.validateErrorMsgValidUsernameAndWrongPassword();

		// 3rd Attempt
		loginPage.loginWithUsernameAndPwd(
				PropUtils.getPropValue(configProp, "CHV_UN_ReadWrite_Customer_LockChk_" + clientCountry),
				"invalidLoginPwd");
		loginPage.validateErrorMsgValidUsernameAndWrongPassword();

		// 4th Attempt
		loginPage.loginWithUsernameAndPwd(
				PropUtils.getPropValue(configProp, "CHV_UN_ReadWrite_Customer_LockChk_" + clientCountry),
				"invalidLoginPwd");
		loginPage.validateErrorMsgValidUsernameAndWrongPasswordAccountLock();

		// 5th Attempt
		loginPage.loginWithUsernameAndPwd(
				PropUtils.getPropValue(configProp, "CHV_UN_ReadWrite_Customer_LockChk_" + clientCountry),
				"invalidLoginPwd");
		loginPage.validateErrorMsgAccountLock();
	}
}
