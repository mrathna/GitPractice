package com.framework.testcases.OLS.EMAP.Customer;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.EMAP.EMAPLoginPage;
import com.framework.pages.OLS.common.LoginPage;

public class ValidateLinksInLoginPage extends BaseTest {
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "Regression" })
	public void validateAllLinksInLoginPage(@Optional("SP") String clientCountry, @Optional("EMAP") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  TST-SC-70-OLS - All links in Logon Page", "Check the links in login page");
		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		loginPage.validateLoginPageFooterLinks(clientName, "EMAP_URL");
		EMAPLoginPage emapLoginPage = new EMAPLoginPage(driver, test);
		emapLoginPage.validateUsernameAndPasswordFields();
	}
}
