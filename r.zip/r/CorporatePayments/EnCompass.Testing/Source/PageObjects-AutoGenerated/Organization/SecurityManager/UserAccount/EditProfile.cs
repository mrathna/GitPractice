using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using Common;
using Common.PageObjects;
using Common.ScenarioConfigurations;
using Common.Utility;

namespace EnCompass.Testing.Source.PageObjects.Organization.SecurityManager.UserAccount 
{
	/// <summary>
	/// Auto-generated Page Model Class
	/// Navigation Paths: 
		/// [Organization Home]->UserAccount->->Preferences
		/// </summary>
	[PageModel(@"/securityManager/userAccount/EditProfile.aspx")]
	public partial class EditProfile : EnCompassOrgPageModel 
	{
		public override string RelativeUrl => @"/securityManager/userAccount/EditProfile.aspx";
		public override string PageIdentifierXPath_Generated => @"//li[contains(@class, 'breadcrumb-item active')][text() = 'Preferences']";

		#region Navigation
				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Contact Information']")]
		private IWebElement _useraccount__Preferences_ContactInformation { get; set; }
		public void NavigateTo_Useraccount__Preferences_ContactInformation()
		{
			NavigateToMenuItem(_useraccount__Preferences_ContactInformation);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Login Credentials']")]
		private IWebElement _useraccount__Preferences_LoginCredentials { get; set; }
		public void NavigateTo_Useraccount__Preferences_LoginCredentials()
		{
			NavigateToMenuItem(_useraccount__Preferences_LoginCredentials);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Challenge Questions']")]
		private IWebElement _useraccount__Preferences_ChallengeQuestions { get; set; }
		public void NavigateTo_Useraccount__Preferences_ChallengeQuestions()
		{
			NavigateToMenuItem(_useraccount__Preferences_ChallengeQuestions);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Preferences']")]
		private IWebElement _useraccount__Preferences_Preferences { get; set; }
		public void NavigateTo_Useraccount__Preferences_Preferences()
		{
			NavigateToMenuItem(_useraccount__Preferences_Preferences);
		}

		
		private void NavigateToMenuItem(IWebElement element)
		{
			Driver.Url = element.GetAttribute("href");
		}
		#endregion

		public EditProfile(GlobalSettings settings) : base(settings) { }
	}  
}
