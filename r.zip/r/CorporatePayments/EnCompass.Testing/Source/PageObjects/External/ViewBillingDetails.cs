﻿using Common;
using Common.Utility;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EnCompass.Testing.Source.PageObjects.External
{
	public class ViewBillingDetails : EnCompassPageModel
	{
		public ViewBillingDetails(GlobalSettings settings) : base(settings) { }


		public override string RelativeUrl => @"/external/ViewBillingDetails.aspx";
		public override string PageIdentifierXPath_Override => @"//h1[contains(@id,'Logo')]";



		public static string _billingInfoTitle = "//div[contains(@id,'contents_phAuth')]//h2";
		public static string _amount = "//div[contains(@id,'contents_phAuth')]//li[normalize-space(text())='Charge amount:']/strong";
		public static string _cardNum = "//div[contains(@id,'contents_phAuth')]//li[normalize-space(text())='Card number:']/strong";
		public static string _expDate = "//div[contains(@id,'contents_phAuth')]//li[contains(@id,'rowExpiration')]/strong";
		public static string _cardSecurityCode = "//div[contains(@id,'contents_phAuth')]//li[contains(@id,'rowCSC')]/strong";

		public string ChargeAmount
		{
			get
			{
				string value = Settings.EnCompassWebDriver.WaitFor(By.XPath(_amount)).GetAttribute("innerText");
				Settings.EnCompassExtentTest.Info("Retrieved ChargeAmount on Billing Details page as :" + value);
				return value;
			}
		}

		public string CardNumber
		{
			get
			{
				string value = Settings.EnCompassWebDriver.WaitFor(By.XPath(_cardNum)).GetAttribute("innerText");				
				Settings.EnCompassExtentTest.Info("Retrieved Card Number on Billing Details page as :" + value);
				return value;
			}
		}

		public string CardExpiryDate
		{
			get
			{
				string value = Settings.EnCompassWebDriver.WaitFor(By.XPath(_expDate)).GetAttribute("innerText");
				Settings.EnCompassExtentTest.Info("Retrieved CardExpiryDate on Billing Details page as :" + value);
				return value;
			}
		}

		public string CardCvvNum
		{
			get
			{
				string value = Settings.EnCompassWebDriver.WaitFor(By.XPath(_cardSecurityCode)).GetAttribute("innerText");
				Settings.EnCompassExtentTest.Info("Retrieved CardCvvNum on Billing Details page as :" + value);
				return value;
			}
		}
	}
}
