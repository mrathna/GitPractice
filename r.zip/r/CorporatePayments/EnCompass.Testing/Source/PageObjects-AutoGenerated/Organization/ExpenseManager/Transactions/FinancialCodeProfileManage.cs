using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using Common;
using Common.PageObjects;
using Common.ScenarioConfigurations;
using Common.Utility;

namespace EnCompass.Testing.Source.PageObjects.Organization.ExpenseManager.Transactions 
{
	/// <summary>
	/// Auto-generated Page Model Class
	/// Navigation Paths: 
		/// [Organization Home]->Transactions->Financial Codes->Profiles
		/// </summary>
	[PageModel(@"/expenseManager/transactions/FinancialCodeProfileManage.aspx")]
	public partial class FinancialCodeProfileManage : EnCompassOrgPageModel 
	{
		public override string RelativeUrl => @"/expenseManager/transactions/FinancialCodeProfileManage.aspx";
		public override string PageIdentifierXPath_Generated => @"//li[contains(@class, 'breadcrumb-item active')][text() = 'Profiles']";

		#region Navigation
				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Profiles']")]
		private IWebElement _transactions_FinancialCodes_Profiles_Profiles { get; set; }
		public void NavigateTo_Transactions_FinancialCodes_Profiles_Profiles()
		{
			NavigateToMenuItem(_transactions_FinancialCodes_Profiles_Profiles);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Assign Cards']")]
		private IWebElement _transactions_FinancialCodes_Profiles_AssignCards { get; set; }
		public void NavigateTo_Transactions_FinancialCodes_Profiles_AssignCards()
		{
			NavigateToMenuItem(_transactions_FinancialCodes_Profiles_AssignCards);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Assign Hierarchies']")]
		private IWebElement _transactions_FinancialCodes_Profiles_AssignHierarchies { get; set; }
		public void NavigateTo_Transactions_FinancialCodes_Profiles_AssignHierarchies()
		{
			NavigateToMenuItem(_transactions_FinancialCodes_Profiles_AssignHierarchies);
		}

		
		private void NavigateToMenuItem(IWebElement element)
		{
			Driver.Url = element.GetAttribute("href");
		}
		#endregion

		public FinancialCodeProfileManage(GlobalSettings settings) : base(settings) { }
	}  
}
