package com.framework.pages.OLS.common;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.ExtentTest;
import com.framework.basepage.BasePage;
import com.framework.repo.Locator;

public class CardsPage extends BasePage {

	public CardsPage(WebDriver driver, ExtentTest test) {
		super(driver, test);
		PageFactory.initElements(driver, this);
	}

	@FindBy(how = How.ID, using = Locator.ACCOUNT_LIST)
	public WebElement accountListDropdown;

	@FindBy(how = How.ID, using = Locator.SEARCH_BTN)
	public WebElement searchbutton;
	
	@FindBy(id = Locator.CARD_STATUS)
	public WebElement filterCardStatus;
	
	@FindBy(xpath = Locator.ACCOUNT_LIST_BOX)
	public WebElement accountList;
	
	@FindBy(id = Locator.SEARCH_BTN)
	public WebElement searchButton;
	
	@FindBy(how = How.ID, using = Locator.CARD_OFFER)
	public WebElement cardOffer;

	@FindBy(how = How.ID, using = Locator.CARD_PRODUCT)
	public WebElement cardProduct;

	@FindBy(xpath = Locator.VIEW_CARD_MENU)
	public WebElement viewCardMenu;

	@FindBy(xpath = Locator.CUSTOMER_NUMBER_LIST)
	public List<WebElement> customerNumberList;

	@FindBy(xpath = Locator.Z_CLONE_CARD)
	public WebElement cloneCard;

	@FindBy(id = Locator.CH_VIEW_CARD_BACK_BUTTON)
	public WebElement backToCardList;
	
	@FindBy(id = Locator.CARD_LIST_TABLE)
	public WebElement cardListTable;
	
	@FindBy(id = Locator.VEHICLES_TABLE)
	public WebElement VehicleTable;

	@FindBy(id = Locator.UPDATE_BUTTON)
	public WebElement updateButton;

	@FindBy(id=Locator.DELETE_BUTTON)
	public WebElement acceptBTN;

	@FindBy(id = Locator.CONFIRMATIONMESSAGE)
	public WebElement confirmationMsg;

	@FindBy(id = Locator.DOWNLOAD_BULK_CARD_ORDER_TEMPLATE)
	public WebElement downloadBulkCardOrder;

	@FindBy(id = Locator.BROWSE_FILE)
	public WebElement browseFile;

	@FindBy(xpath = Locator.SHELL_UPLOAD_FILE)
	public WebElement upLoadFile;

	@FindBy(xpath = Locator.UPLOAD_BULK_CARD_ORDER_TEMPLATE)
	public WebElement upLoadBulkOrder;

	@FindBy(xpath = Locator.UPLOAD_BULK_CARD_UPDATE_TEMPLATE)
	public WebElement upLoadBulkUpdate;

	@FindBy(xpath = Locator.UPLOAD_BULK_CARD_UPDATE_CLEAR_TEMPLATE)
	public WebElement clearBulkUpdate;

	@FindBy(id = Locator.CLOSE_UPLOAD_POPUP)
	public WebElement closePopUp;
	
	@FindBy(id = Locator.CLOSE_IMAGE)
	public WebElement closeImage;

	@FindBy(id=Locator.SEARCH_BULK_CARD)
	public WebElement searchBulkCard;

	@FindBy(id=Locator.SELECT_ALL_CB)
	public WebElement selectAllCb;

	@FindBy(id=Locator.BULK_CARD_UPDATE_TABLE)
	public WebElement bulkCardUpdateTable;

	@FindBy(id=Locator.DOWNLOAD_CARDS_TO_EXCEL)
	public WebElement download;

	@FindBy(xpath = Locator.Z_CARD_NUMBER)
	public WebElement cardNumber;

	@FindBy(xpath = Locator.Z_REGO_NUMBER)
	public WebElement regoNumber;

	@FindBy(xpath = Locator.Z_DRIVER_NAME)
	public WebElement driverName;

	@FindBy(xpath = Locator.Z_REFERENCE_NUMBER)
	public WebElement referenceNumber;

	@FindBy(xpath = Locator.Z_VEHICLE_DISCRIPTION)
	public WebElement vehicleDiscription;

	@FindBy(xpath = Locator.Z_COSTCENTRE_CODE)
	public WebElement costCentreCode;

	@FindBy(id = Locator.SEARCH_BTN)
	public WebElement searchVehicleButton;

	@FindBy(id = Locator.CURRENT_CARD_NUMBER)
	public WebElement currentCardNumber;

	@FindBy(xpath = Locator.Z_TABLES_LIST)
	public WebElement tablesList;

	@FindBy(xpath = Locator.EDIT_CARD_MENU_OPTION)
	public WebElement editCardMenuButton;

	@FindBy(xpath = Locator.PAGE_HEADER)
	public WebElement pageTitle;

	@FindBy(id = Locator.CARD_INFORMATION_DRIVER_NAME)
	public WebElement driverNameEditPage;

	@FindBy(id = Locator.CARD_INFORMATION_VEHICLE_REGO_NUMBER)
	public WebElement vehicleRegoNumber;

	@FindBy(id = Locator.CDA_TITLE)
	public WebElement contactTitleName;

	@FindBy(id = Locator.CDA_CONTACT_NAME)
	public WebElement contactName;

	@FindBy(id = Locator.CDA_CONTACT_ADDRESS)
	public WebElement contactAddress;

	@FindBy(id = Locator.CDA_SUBURB)
	public WebElement cityName;

	@FindBy(id = Locator.CDA_POSTCOAD)
	public WebElement postCode;

	@FindBy(id = Locator.CDA_SATE)
	public WebElement stateName;

	@FindBy(id = Locator.CDA_COUNTRY)
	public WebElement countryName;

	@FindBy(id = Locator.CARD_PURCHASE_PRODUCTS_DURING_TIME)
	public WebElement timeLimit;

	@FindBy(xpath = Locator.CARD_PURCHASE_PRODUCTS_LOCATION_RESTRICTION)
	public WebElement locationRes;

	@FindBy(xpath = Locator.CARD_PURCHASE_PRODUCTS_PRODUCT_RESTRICTION)
	public WebElement productRes;

	@FindBy(xpath = Locator.CARD_LIMITS_MONTHLY_DOLLAR)
	public WebElement monthlyLimit;

	@FindBy(xpath = Locator.CARD_LIMITS_TRANSACTION_DOLLAR_LIMIT)
	public WebElement transactionDolarLimit;

	@FindBy(xpath = Locator.CARD_LIMITS_DAILY_DOLLAR)
	public WebElement dailyDolarLimit;

	@FindBy(xpath = Locator.CARD_LIMITS_TRANSACTION_LIMIT)
	public WebElement transactionLimit;
	
	@FindBy(id=Locator.REISSUE_EXPORT_BUTTON)
	public WebElement reissueControlExportButton;
	//sasi
	@FindBy(xpath = Locator.Z_EDIT_CARD_VALIDATION_FAILED) 
	public WebElement validationFailed;

	private String cardAccNo = "";

	private String cardNo = "";

	private String status = "";


	private String offer = "";

	private String rego = "";

	String vehicleResultCount = "";


	public void selectAllAccountOptionFromAccountDropdown() {
		selectDropDownByVisibleText(accountListDropdown, "All Accounts");
		sleep(5);
	}

	public void clickSearchButton() {
		isDisplayedThenClick(searchbutton, "Search button");
		sleep(10);
	}
	
	public void clickCardNumber(int index) {
		try {
			isDisplayedThenActionClick(customerNumberList.get(index - 1), "Click selected Card from card list");
			// System.out.println("Get Text for element"+ expAccount.getr);
			sleep(3);

		} catch (Exception e) {
			logInfo(e.getMessage());

		}

	}
	
	public void clickCardTableMenuOption(WebElement option) {
		isDisplayedThenActionClick(option, "Card Table Menu");
		// isDisplayedThenClick(option, "Card Table Menu");
		sleep(5);
		// verifyHeaderTitle(titleTOCheck);
	}
	
//	Sasi	
	public void selectAllAccountsAndActiveCard() {

		selectDropDownByVisibleText(accountList, "All Accounts");
		waitUntilElementDisplayed(accountList);
		selectDropDownByVisibleText(filterCardStatus, "Active");
		waitUntilElementDisplayed(filterCardStatus);
//		clickSearchButton();
		sleep(2);
	}
//	Sasi
	public void selectAllAccountsAlone() {

		selectDropDownByVisibleText(accountList, "All Accounts");
		waitUntilElementDisplayed(accountList);
//		clickSearchButton();
		sleep(2);
	}
	
	public void clickSearchButtonAndValidate() {

		isDisplayedThenActionClick(searchButton, "Click search button");
		
		System.out.println("clicked");

		waitUntilElementDisplayed(searchButton);

		scrollDownPage();
		
		if(cardListTable.isDisplayed()) {
			isDisplayed(cardListTable, "Verify Table displayed");	
		} else {
			checkTextInPageAndValidate("No Cards Found", 20);
		}
		
		sleep(5);

	}
	
//	Sasi
	public void searchAndValidate(WebElement searchTB, WebElement searchButton, String keyWord, int colValue,
			int reqColValue) {
		sleep(3);

		flushHashMap(tableSpec);

		if (searchTB.isDisplayed()) {
			searchTB.clear();
			searchTB.sendKeys(keyWord);
		}

		sleep(3);

		if (searchButton.isDisplayed()) {
			searchButton.click();
		}

		sleep(3);

		if (!keyWord.equals("")) {
			// System.out.println(" comes in here ------ ");

//			setCellDataFromTable(VehicleTable, reqColValue, true);
			
			setCellDataFromTable(cardListTable, reqColValue, true);

			String actualValue = getCellDataFromTable(1, colValue, true);

			if (actualValue.equals(keyWord)) {
				logPass(" Search " + keyWord + " is validated and it is working fine");
			}

			else {
				logFail(" Search " + keyWord + " validation is failed: The Actual Value is = " + actualValue);
			}
		}

		else {
			boolean checkVFoundText = waitForTextToAppear(vehicleResultCount, 10);

			if (checkVFoundText) {
				logPass(vehicleResultCount + " is present");
			}

			else {
				logFail(vehicleResultCount + " is not Present");
			}
		}

	}

	public void clickUpdateButton() {

		scrollDownPage();
		scrollDownPage();
		sleep(10);
		isDisplayedThenClick(updateButton, "Click Update Button");
		sleep(10);
		scrollToTopPage();
		scrollToTopPage();
	}

	public void validateTheEditCard() {

		sleep(3);
		isDisplayedThenClick(acceptBTN, "Accept button");
		sleep(3);
		boolean text = waitForTextToAppear("Validation Failed",10);
		
		if(text) {
			logFail("Unable to edit card");
		}
		else {
		verifyText(confirmationMsg, "Success!  Your card details have been saved.");
		logPass("Successfully Updated the card");
		}

	}

	/* Sasi (31-01-2019)
	 * This Method download as well as upload the bulk template
	 * for both Bulk Order as well as Bulk Update
	 */
	public void uploadBulkOrderAndUpdate(String text, String action) {
		if (action.equals("bulkUpdate")) {
			System.out.println("comes inside a loop");

			// Select First customer and Download
			selectOneAccountAndDownload();

			isDisplayedThenActionClick(upLoadBulkUpdate, "UpLoad the Bulk Order");
			// sleep(5);
		} else {
			isDisplayedThenClick(downloadBulkCardOrder, "Download Bulk Card Order");
			// sleep(10);
			isDisplayedThenActionClick(upLoadBulkOrder, "UpLoad the Bulk Order");
			// sleep(5);
		}
		System.out.println("goes outside a loop");

		mouseHover(browseFile);
		isDisplayedThenActionClick(browseFile, "Browse File");
		// sleep(10);
		uploadTheExcelSheetFromTheLocal(text);
		sleep(2);

		isDisplayedThenActionClick(upLoadFile, "Up Load File");

		try {
			isDisplayedThenActionClick(closePopUp, "Close the popup");
		} catch (Exception e) {
			logInfo(e.getMessage());
			isDisplayedThenActionClick(closeImage, "Clicking x icon");
		}
	}

public void downloadBulkTemplate(String text, String action) {
		if (action.equals("bulkUpdate")) {
			System.out.println("comes inside a loop");

			// Select First customer and Download
			selectOneAccountAndDownload();
		} else {
			isDisplayedThenClick(downloadBulkCardOrder, "Download Bulk Card Order");
			sleep(7);
		}
		sleep(3);
	}
	
	public void uploadBulkTemplate(String text, String action) {
		if (action.equals("bulkUpdate")) {
			System.out.println("comes inside a loop");
			isDisplayedThenActionClick(upLoadBulkUpdate, "UpLoad the Bulk Order");
		} else {
			isDisplayedThenActionClick(upLoadBulkOrder, "UpLoad the Bulk Order");
		}
		sleep(3);
		mouseHover(browseFile);
		sleep(2);
		isDisplayedThenActionClick(browseFile, "Browse File");
		sleep(10);
		// sleep(10);
		uploadTheExcelSheetFromTheLocal(text);
		sleep(2);

		isDisplayedThenActionClick(upLoadFile, "Up Load File");
		
		try {
			isDisplayedThenActionClick(closePopUp, "Close the popup");
		} catch (Exception e) {
			logInfo(e.getMessage());
			isDisplayedThenActionClick(closeImage, "Clicking x icon");
		}
	}
	

	public void clickBulkCardUpdateSearch() {

		isDisplayedThenActionClick(searchBulkCard, "Click Search Bulk Card Update Button");
		sleep(5);
//		sleep(30);
	}

	public void UnCheckSelectALL()
	{
		selectORNotSelectElement(selectAllCb, "Select All check box");
//		sleep(20);
	}

	public void selectOneAccountAndDownload()
	{
		isDisplayed(bulkCardUpdateTable, "Bulk Card Update Table");

		selectFirstRowCustomer(bulkCardUpdateTable, "Bulk card Update Table");

		sleep(5);

		isDisplayedThenClick(download, "Download Button");

		sleep(5);
	}

	private void selectFirstRowCustomer(WebElement tableElement, String message) {
		// TODO Auto-generated method stub

		WebElement firstCustomer = null;

		try {		
			firstCustomer = tableElement.findElement(By.xpath("./tbody/tr[1]"));

			isDisplayed(firstCustomer, "First customer");

			WebElement firstCustomerCheckBox= firstCustomer.findElement(By.xpath("./td[1]/p/input"));

			isDisplayed(firstCustomerCheckBox, "First Customer checkbox");			

			selectORNotSelectElement(firstCustomerCheckBox, "First customer");

		}

		catch(Exception e)
		{
			logFail(e.getMessage());
		}
	}

	public void verifyAllRequiredFieldsBulkCardUpdate(String client) {
		// TODO Auto-generated method stub

		checkTextInPageAndValidate("Account Number", 20);
		checkTextInPageAndValidate("Card Number From", 20);
		checkTextInPageAndValidate("Card Number To", 20);
		checkTextInPageAndValidate("Card Offer", 20);
		checkTextInPageAndValidate("Card Status", 20);
		checkTextInPageAndValidate("Additional Card Reference", 20);
		checkTextInPageAndValidate("Card Last Transaction Date", 20);
		if(client.equals("shell")) {
			checkTextInPageAndValidate("Card Group ID", 20);
			checkTextInPageAndValidate("Card Expires On", 20);
		}
		else {
			checkTextInPageAndValidate("Cost Centre Code", 20);
			checkTextInPageAndValidate("Expiry Date", 20);
		}

	}

	public void validateBuldCardUpdatePage(String client) {
		if(client.equals("shell")) {
			checkTextInPageAndValidate("BULK UPDATE", 20);
		}
		else {
			checkTextInPageAndValidate("Bulk Update", 20);
		}
	}

	public void clickViewCardGoToViewCardPageAndValidate(String client) {

		if(client.equals("shell")) {
			setCellDataFromTable(cardListTable, 9, true);
			//List<WebElement> rowElements =  cardListTable.findElements(By.xpath("./tbody[contains(@id,'lform:tableCardList:tb')]/tr"));
			//System.out.println("tableCardNumberListSize---"+rowElements.size());

			cardAccNo = getCellDataFromTable(1, 0, true);

			System.out.println("cardAccNo---"+cardAccNo); 

			clickCardNumber(1);

			clickCardTableMenuOption(viewCardMenu);

			sleep(5);

			checkTextInPageAndValidate("VIEW CARD", 30);

			checkTextInPageAndValidate(cardAccNo, 30);
		}
		else {

			setCellDataFromTable(cardListTable, 7, true);

			cardNo = getCellDataFromTable(1, 0, true);

			status = getCellDataFromTable(1, 1, true);

			offer = getCellDataFromTable(1, 2, true);

			rego = getCellDataFromTable(1, 3, true);


			System.out.println("cardAccNo---"+cardAccNo); 
			
			System.out.println("cardNo---"+cardNo); 
			
			System.out.println("status---"+status);
			
			System.out.println("offer---"+offer);
			
			System.out.println("rego---"+rego);

			clickCardNumber(1);

			clickCardTableMenuOption(viewCardMenu);

			sleep(5);

			checkTextInPageAndValidate("View Card", 20);

			checkTextInPageAndValidate(cardNo, 10);

			checkTextInPageAndValidate(status, 10);

			checkTextInPageAndValidate(offer, 10);

			checkTextInPageAndValidate(rego, 10);

		}
	}

	public void goToCardMenuReissueControl() { 
		mouseHoverClickMenuAndSubMenu("Cards", "Reissue Control");
	}
	
	public void printNoReissueDataPresent() {
		logInfo("No Reissue Data are present");		
	}
	
public void clickExportButton() {
		
		isDisplayedThenActionClick(reissueControlExportButton, "Click Reissue Control Export button");
	}

}
