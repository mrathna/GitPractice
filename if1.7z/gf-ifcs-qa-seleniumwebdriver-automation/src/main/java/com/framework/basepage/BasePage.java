package com.framework.basepage;

import static org.testng.Assert.fail;

import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.LineNumberReader;
import java.io.OutputStreamWriter;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.regex.Pattern;

import javax.imageio.ImageIO;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.io.comparator.LastModifiedFileComparator;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.framework.basetest.BaseTest;
import com.framework.main.InitExecution;
import com.framework.pages.AJS.common.IFCSHomePage;
import com.framework.pages.BusinessFlow.SalesForceCommon;
import com.framework.pages.OLS.common.LoginPage;
import com.framework.util.Constants;
import com.framework.util.DatabaseUtils;
import com.framework.util.PropUtils;
import com.framework.util.SeleniumWrappers;
import com.framework.util.SikuliUtils;
import com.framework.util.StringEncryptUtils;
import com.github.javafaker.Faker;

public class BasePage<T> extends BaseTest {
	protected WebDriver driver;
	private static final long TIMEOUT = 30;

	protected static String outgoingFileName = "";

	public HashMap<String, String> tableValues = new HashMap<String, String>();

	public HashMap<String, String> tableSpec = new HashMap<String, String>();
	private String dbUserName = PropUtils.getPropValue(configProp, "sqlUserId");
	private String dbPassword = PropUtils.getPropValue(configProp, "sqlPassword");

	private String dbIEUserName = PropUtils.getPropValue(configProp, "ieUserId");
	private String dbIEPassword = PropUtils.getPropValue(configProp, "iePassword");

	private String dbICPUserName = PropUtils.getPropValue(configProp, "icpUserId");
	private String dbICPPassword = PropUtils.getPropValue(configProp, "icpPassword");

	public static List<File> fileBucket = new ArrayList<File>();

	public static String textFieldVal = " ";
    
	// WebDriverWait wait = new WebDriverWait(driver, 30);

	/**
	 * @param driver
	 * @param test
	 */
	 protected BasePage(WebDriver wd, ExtentTest et) {
			this.driver = wd;
			this.test = et;
		
		}
	 @SuppressWarnings("unchecked")
		protected T getURL(String url)
			{
				
				driver.get(url);
				return (T) this;
			}

	/**
	 * @param locator
	 * @param message
	 */
	public void isDisplayed(WebElement locator, String message) {
		try {
			if (locator != null) {
				waitUntilElementDisplayed(locator);
				if (locator.isDisplayed()) {
					logPass(message + " is Displayed");
				} else {
					logFail(message + " is Not Displayed");
				}
			}

			else {
				logInfo("Locator is Null");
			}
		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
	}

	/**
	 * @param locator
	 * @param message
	 */
	public void isDisplayedThenClick(WebElement locator, String message) {
		try {

		waitForElementTobeClickable(locator, 30);
			if (locator.isDisplayed()) {
				locator.click();
				logPass(message + " id Displayed and Clicked on it.");
			} else {
				logFail(message + " is Not Displayed");
			}
		} catch (Exception ex) {
			System.out.println("Click failed and Action Click performed");
			isDisplayedThenActionClick(locator, "Combo Dropdown");
			//logFail(ex.getMessage());
			
		}
	}

	/**
	 * @param locator
	 * @param message
	 */
	public void Click(WebElement locator, String message) {
		try {
			waitForElementTobeClickable(locator, 30);
			System.out.println(locator);
			locator.click();
			logPass(message + " id Clicked on it.");
		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
	}

	public void isDisplayedThenActionClick(WebElement locator, String message) {
		try {
			waitUntilElementDisplayed(locator);
			if (locator.isDisplayed()) {
				actionClick(locator);
				logPass(message + " id Displayed and Clicked on it.");
			} else {
				logFail(message + " is Not Displayed");
			}
		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
	}

	// Rathna -- Params : Object
		/**
		 * @param locator
		 * @param label
		 */
	// for
	public void JSClick(WebElement locator, String message) {
		try {
			waitUntilElementDisplayed(locator);
			if (locator.isDisplayed()) {
				((JavascriptExecutor) driver).executeScript("arguments[0].click();", locator);
				actionClick(locator);
				logPass(message + " id Displayed and JSClick is done.");
			} else {
				logFail(message + " is Not Displayed-JSClick is not done");
			}
		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
	}
	
	
	// Rathna -- Params : Object
			/**
			 * @param locator
			 * @param label
			 */
		// for
		public void JSEnterText(WebElement locator, String message, String sendText) {
			try {
				waitUntilElementDisplayed(locator);
				if (locator.isDisplayed()) {
					((JavascriptExecutor) driver).executeScript("arguments[0].value='" + sendText + "';", locator);
					logPass(message + " id Displayed and JSClick is done.");
				} else {
					logFail(message + " is Not Displayed-JSClick is not done");
				}
			} catch (Exception ex) {
				logFail(ex.getMessage());
			}
		}
		
		
	/**
	 * @param locator
	 * @param message
	 * @param sendText
	 */
	public void isDisplayedThenEnterText(WebElement locator, String message, String sendText) {
		try {
			waitUntilElementDisplayed(locator);
			System.out.println("element present ----- ");
			isDisplayed(locator, message);
			
			locator.clear();
			sleep(1);
			locator.sendKeys(sendText);
			logInfo("Text entered : "+sendText);
		} catch (Exception ex) {
			logFail(ex.getMessage());
		}

	}

	/**
	 * @param locator
	 * @param message
	 */
	public void isDisplayedThenClearText(WebElement locator, String message) {
		try {
			waitUntilElementDisplayed(locator);
			System.out.println("element present ----- ");
			isDisplayed(locator, message);
			locator.clear();

		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
	}

	/**
	 * @param locator
	 * @param message
	 */
	public void isDisplayedThenClickRadioBTN(WebElement locator, String message) {
		try {
			waitUntilElementDisplayed(locator);
			isDisplayed(locator, message);
			boolean isEnabledORNot = locator.isSelected();
			if (!isEnabledORNot) {
				locator.click();
				logPass(message + " is selected");
			}

			else {
				logInfo(message + " already selected");
			}

		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
	}

	/**
	 * @param locator
	 * @param message
	 * @return
	 */
	public boolean isElementEnabled(WebElement locator, String message) {
		boolean isEnabledORNot = true;
		try {
			isEnabledORNot = locator.isEnabled();
			if (isEnabledORNot) {
				logInfo(message + " Enabled");
			}

		} catch (Exception ex) {

			isEnabledORNot = false;
			logInfo(message + " Not Enabled");
		}
		return isEnabledORNot;
	}

	/**
	 * @param locator
	 * @param message
	 */
	public void selectORNotSelectElement(WebElement locator, String message) {
		try {

			boolean isEnabledORNot = locator.isEnabled();

			System.out.println("------ isEnabledORNot ----- " + isEnabledORNot);

			if (isEnabledORNot) {

				boolean isSelectedOrnot = locator.isSelected();

				System.out.println("-------- isSelectedOrnot -------" + isSelectedOrnot);

				if (isSelectedOrnot) {

					locator.click();
					logPass(message + " is Unchecked");
				}

				else {
					locator.click();
					logPass(message + " is checked");
				}

			}

			else {
				logFail(message + " is not enabled");

			}

		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
	}

	// NK
	/**
	 * @param locator
	 * @param message
	 */
	/**
	 * @param locator
	 * @param message
	 */
	public void selectIfEnabledOrNotSelect(WebElement locator, String message) {
		try {

			boolean isEnabledORNot = locator.isEnabled();

			System.out.println("------ isEnabledORNot ----- " + isEnabledORNot);

			if (isEnabledORNot) {

				boolean isSelectedOrnot = locator.isSelected();

				System.out.println("-------- isSelectedOrnot -------" + isSelectedOrnot);

				if (isSelectedOrnot) {
					logPass(message + "is already checked");
				}

				else {
					locator.click();
					logPass(message + " is checked");
				}

			}

			else {
				logPass(message + " is disabled");

			}

		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
	}

	/**
	 * @param locator
	 */
	public void actionClick(WebElement locator) {
		try {
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(locator));
			Actions act = new Actions(driver);
			act.moveToElement(locator).click(locator).build().perform();
		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
	}

	/**
	 * @param locator
	 */
	public void mouseHover(WebElement locator) {
		try {

			System.out.print("Mouse Hover Action");
			WebDriverWait wait = new WebDriverWait(driver, 10);
			wait.until(ExpectedConditions.visibilityOf(locator));
			Actions act = new Actions(driver);
			act.moveToElement(locator).build().perform();
		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
	}

	/**
	 * @param locator
	 * @param xOffset
	 * @param yOffset
	 */
	public void mouseHoverOverSpecificPixel(WebElement locator, int xOffset, int yOffset) {
		try {

			System.out.print("Mouse Hover Action using offset");
			WebDriverWait wait = new WebDriverWait(driver, 10);
			wait.until(ExpectedConditions.visibilityOf(locator));
			Actions act = new Actions(driver);
			act.moveToElement(locator, xOffset, yOffset).build().perform();
		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
	}

	/**
	 * @param From
	 * @param xOffset
	 * @param yOffset
	 */
	public void dragAndDropToSpecificPixel(WebElement From, int xOffset, int yOffset) {
		try {

			System.out.print("Mouse Drag and Drop Action using offset");
			WebDriverWait wait = new WebDriverWait(driver, 10);
			wait.until(ExpectedConditions.visibilityOf(From));
			Actions act = new Actions(driver);
			act.dragAndDropBy(From, xOffset, yOffset).build().perform();
		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
	}

	/**
	 * @param From
	 * @param To
	 */
	public void dragAndDrop(WebElement From, WebElement To) {
		try {

			System.out.print("Mouse Drag and Drop Action");
			WebDriverWait wait = new WebDriverWait(driver, 10);
			wait.until(ExpectedConditions.visibilityOf(From));
			wait.until(ExpectedConditions.visibilityOf(To));
			Actions act = new Actions(driver);
			act.dragAndDrop(From, To).build().perform();
		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
	}

	/**
	 * @param locator
	 * @return
	 */
	public String getText(WebElement locator) {
		String text = "";
		try {

			if (locator.isDisplayed()) {
				waitUntilElementDisplayed(locator);
				text = locator.getText().trim();
				if (text == "") {
					text = locator.getAttribute("submittedvalue");

				}
			}
			return text;
		} catch (Exception ex) {
			logFail(ex.getMessage());
			return null;
		}
	}

	/*
	 * 30-04-2018 Ayub Khan
	 */
	/**
	 * @param locator
	 * @param min
	 */
	public void selectInputFromDropdown(WebElement locator, int min) {
		try {
			WebDriverWait wait = new WebDriverWait(driver, 10);
			wait.until(ExpectedConditions.visibilityOf(locator));
			Select accounts = new Select(locator);
			int maxSize = accounts.getOptions().size();
			if (maxSize == 1) {
				accounts.selectByIndex(0);
			} else if (maxSize == 2) {
				accounts.selectByIndex(1);
			} else {
				int accountToBeChoosen = getRandomNumber(min, maxSize - 1);
				accounts.selectByIndex(accountToBeChoosen);
			}
		} catch (Exception ex) {
			logFail(ex.getMessage());

		}
	}

	/**
	 * @param locator
	 * @return
	 */
	public String selectedStringFrmDropDown(WebElement locator) {
		WebDriverWait wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.visibilityOf(locator));
		Select accounts = new Select(locator);
		String selectedString = accounts.getFirstSelectedOption().getText();
		return selectedString;
	}

	/*
	 * Added by Anton 21.05.2018 - To select different option instead of
	 * defaultValue
	 */
	public void selectDifferentValueInsteadOfDefault(WebElement locator, String defaultString, String headerText) {
		try {
			WebDriverWait wait = new WebDriverWait(driver, 10);
			wait.until(ExpectedConditions.visibilityOf(locator));
			Select selectElement = new Select(locator);

			List<WebElement> allOptions = selectElement.getOptions();

			String tmpOption = "";
			String tmpOptionTrim = "";

			defaultString = defaultString.replaceAll("\\s", "");

			System.out.println("Default String ===== " + defaultString);

			for (WebElement option : allOptions) {
				tmpOption = option.getText();

				tmpOptionTrim = tmpOption.replaceAll("\\s", "");

				System.out.println("Temp Option ---- ====== " + tmpOption);

				if (!tmpOptionTrim.contains(defaultString) && !tmpOption.equals(headerText)) {

					selectElement.selectByVisibleText(tmpOption);

					logInfo(tmpOption + " is Selected");

					break;
				}

			}
		} catch (Exception e) {
			logFail(e.getMessage());
		}

	}

	// Added by Ayub 22.05.2018 - To get the dropdown size from the drop down
	public int getDropdownSize(WebElement locator) {
		try {
			WebDriverWait wait = new WebDriverWait(driver, 10);
			wait.until(ExpectedConditions.visibilityOf(locator));
			Select dropDown = new Select(locator);
			int dropdownsize = dropDown.getOptions().size();
			return dropdownsize;
		} catch (Exception ex) {
			logFail(ex.getMessage());
			return 0;
		}
	}

	/**
	 * @param locator
	 * @param index
	 */
	public void selectDropDownByIndex(WebElement locator, int index) {
		try {
			WebDriverWait wait = new WebDriverWait(driver, 10);
			wait.until(ExpectedConditions.visibilityOf(locator));
			Select selectDropDown = new Select(locator);
			selectDropDown.selectByIndex(index);
		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
	}

	/*
	 * Added By Anton 22.05.2018 - To Select new options instead already created
	 * options
	 * 
	 */

	/**
	 * @param locator
	 * @param alreadySelected
	 * @param headerText
	 */
	public void selectDifferentOptionInsteadOfAlreadyCreated(WebElement locator, Set<String> alreadySelected,
			String headerText) {
		try {
			/*
			 * WebDriverWait wait = new WebDriverWait(driver, 10);
			 * wait.until(ExpectedConditions.elementToBeSelected(locator));
			 */
			Select selectElement = new Select(locator);
			List<WebElement> allOptions = selectElement.getOptions();
			String tmpOption = "";

			for (String s : alreadySelected) {
				System.out.println("---- alreadySelected ----" + s);
			}

			if (!headerText.equals("")) {

				System.out.println("--- Comes in if Part ---");

				for (WebElement option : allOptions) {
					tmpOption = option.getText().trim();

					if (!alreadySelected.contains(tmpOption) && !tmpOption.equals(headerText)) {
						selectElement.selectByVisibleText(tmpOption);
						logInfo(tmpOption + " is Selected");
						break;
					}

				}

			}

			else {

				System.out.println("--- Comes in Else Part ---");

				for (WebElement option : allOptions) {
					tmpOption = option.getText().trim();

					if (!alreadySelected.contains(tmpOption)) {
						selectElement.selectByVisibleText(tmpOption);
						logInfo(tmpOption + " is Selected");
						break;
					}
				}
			}

		} catch (Exception e) {
			logFail(e.getMessage());
		}

	}

	/**
	 * @param locator
	 * @param attribute
	 * @return
	 */
	public String getAttribute(WebElement locator, String attribute) {
		try {
			WebDriverWait wait = new WebDriverWait(driver, 10);
			wait.until(ExpectedConditions.attributeToBeNotEmpty(locator, attribute));
			String attr = locator.getAttribute(attribute);
			return attr;
		} catch (Exception ex) {
			logFail(ex.getMessage());
			return null;
		}
	}

	/**
	 * @param locator
	 * @param text
	 */
	public void verifyText(WebElement locator, String text) {
		try {
			WebDriverWait wait = new WebDriverWait(driver, 10);
			wait.until(ExpectedConditions.textToBePresentInElement(locator, text));
			Assert.assertEquals(locator.getText().trim(), text);
			logInfo("Text Present");
		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
	}

	/**
	 * @param text
	 */
	public void verifyTheDownloadedFile(String text) {
		try {
			String fileName = getLatestDownloadedFileFromDir(text).getName();
			System.out.println("Downloaded File Name isssss" + fileName);
			if (fileName.contains(text)) {
				logPass("File is Downloaded Sucessfully in your Local");
			}
		} catch (NullPointerException ex) {
			logFail("Downloaded File Does not Exist" + ex.getMessage());
		}
	}

	/**
	 * @param text
	 * @return
	 */
	public int getCurrentDirFileCount(String text) {
		try {
			String filePath;
			filePath = System.getProperty("user.home") + "//" + text + "//";
			File userDirectory = new File(filePath);
			return userDirectory.list().length;

		} catch (NullPointerException ex) {
			logFail("File Path not Exist" + ex.getMessage());
			return 0;
		}
	}

	/**
	 * 
	 */
	public void verifyReportFilePresenceUsingRegex() {
		try {
			String filePath, fileName;
			File lastModifiedFile;
			filePath = System.getProperty("user.home") + "//" + "Downloads" + "//";
			File userDirectory = new File(filePath);
			File[] files = userDirectory.listFiles();
			Arrays.sort(files, LastModifiedFileComparator.LASTMODIFIED_REVERSE);
			lastModifiedFile = files[0];
			fileName = lastModifiedFile.getName();
			if (fileName.matches(Pattern.quote("^[A-Za-z0-9/./_/-]*$"))) {
				logPass("File name matched expeceted format !:" + fileName);
			} else {
				logInfo("File name not matched expeceted format !:" + fileName);
			}
		} catch (Exception e) {
			logFail("FilePath not exist" + e);
		}
	}

	/*
	 * 30-04-2018 Ayub khan
	 */
	/**
	 * @param locator
	 * @param text
	 */
	public void verifyTextFromDropdown(WebElement locator, String text) {
		Select accounts = new Select(locator);
		String actual = accounts.getFirstSelectedOption().getText();
		if (actual.equals(text))
			logInfo("Expected Text Present in dropdown");
		else
			logFail("Expected Text not Present in dropdown");
	}

	/**
	 * @param locator
	 * @param attribute
	 * @param text
	 */
	public void verifyAttribute(WebElement locator, String attribute, String text) {
		String actual = locator.getAttribute(attribute).trim();
		if (actual.equals(text))
			logInfo("Expected Text Present in attribute");
		else
			logFail("Expected Text not Present in attribute");
	}

	/**
	 * @param text
	 */
	public void verifyTitle(String text) {
		String actual = driver.getTitle();
		if (actual.equals(text))
			logInfo("Expected Text Present in PageTitle");
		else
			logFail("Expected Text not Present in PageTitle Actual-->" + actual + " Expected-->" + text);
	}

	/**
	 * @param text
	 */
	public void verifyCurrentURL(String text) {
		String actual = driver.getTitle();
		if (actual.equals(text))
			logInfo("Expected Text Present in URL");
		else
			logFail("Expected Text not Present in URL");
	}

	/**
	 * @param msg
	 */
	public void logInfo(String msg) {
		test.info(MarkupHelper.createLabel(msg, ExtentColor.BLUE));
	}

	/**
	 * @param msg
	 */
	public void logFail(String msg) {
		test.fail(MarkupHelper.createLabel(msg, ExtentColor.RED));
		Assert.assertFalse(true, msg);
	}

	/**
	 * @param msg
	 */
	public void softFail(String msg) {
		SoftAssert softAssert = new SoftAssert();
		test.fail(MarkupHelper.createLabel(msg, ExtentColor.PINK));
		softAssert.assertFalse(true, msg);
	}

	/**
	 * @param msg
	 */
	public void logPass(String msg) {
		test.pass(MarkupHelper.createLabel(msg, ExtentColor.GREEN));
	}

	/**
	 * @param seconds
	 */
	public void sleep(int seconds) {
		try {
			Thread.sleep(seconds * 1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

	}

	/**
	 * @return
	 */
	public Faker fakerAPI() {
		Faker faker = new Faker();
		return faker;
	}

	// Country Specific Faker API
	/**
	 * @param clientCountry
	 * @return
	 */
	public Faker countrySpecificFakerAPI(String clientCountry) {
		Faker faker;
		if (clientCountry.equals("AU")) {
			Locale locale = new Locale("en-AU");
			faker = new Faker(locale);
		} else {
			Locale locale = new Locale("en-NZ");
			faker = new Faker(locale);

		}

		return faker;
	}

	// window handle by Anton 02.05.2018

	/**
	 * @param parent
	 * @param allWindows
	 */
	public void switchToNewWindow(String parent, Set<String> allWindows) {
		Iterator<String> I1 = allWindows.iterator();

		while (I1.hasNext()) {

			String child_window = I1.next();

			if (!parent.equals(child_window)) {
				driver.switchTo().window(child_window);
			}

			else {
				System.out.println("Both are same window");
			}
		}
	}

	/**
	 * @param parent
	 */
	public void closeChildAndMoveToParent(String parent) {
		driver.close();
		driver.switchTo().window(parent);
	}

	/**
	 * @param child
	 * @param allWindows
	 */
	public void closeChildWindowAndswitchToParent(String child, Set<String> allWindows) {
		Iterator<String> I1 = allWindows.iterator();

		while (I1.hasNext()) {
			String parent = I1.next();

			// Here we will compare if parent window is not equal to child window then we
			// will close

			// System.out.println("parent---- "+parent);

			// System.out.println("child ------"+child_window);

			if (!child.equals(parent)) {
				driver.close();
				driver.switchTo().window(parent);
			}

			else {
				System.out.println("Both are same window");
			}
		}
	}

	/**
	 * @param min
	 * @param max
	 * @return
	 */
	public int getRandomNumber(int min, int max) {
		Random rand = new Random();
		return rand.nextInt(max) + min;
	}

	/**
	 * 
	 */
	public void printTime() {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSSS");
		Date dt = new Date();
		String strDate = sdf.format(dt);
		System.out.println(strDate);
		logInfo(strDate);

	}

	/**
	 * Connect DB and get row value
	 * 
	 * @throws InterruptedException
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 *             30-04-2018 Ayub Khan
	 */
	public String connectDBAndGetValue(String query, String getDBDetailsFromProperties) {

		String value = null;
		try {
			value = DatabaseUtils.getMySQLConnection(query, getDBDetailsFromProperties, dbUserName, dbPassword);
		} catch (ClassNotFoundException e) {
			logFail(e.getMessage());
		} catch (SQLException e) {

			logFail(e.getMessage());
		} catch (InterruptedException e) {

			logFail(e.getMessage());
		}

		if (!(value.equals(null))) {
			logPass("Retrieved Value from DB: " + value);
		}

		return value;
	}

	/**
	 * @param query
	 * @param getDBDetailsFromProperties
	 * @return
	 */
	public String connectIEDBAndGetValue(String query, String getDBDetailsFromProperties) {

		String value = null;
		try {
			value = DatabaseUtils.getMySQLConnection(query, getDBDetailsFromProperties, dbIEUserName, dbIEPassword);
		} catch (ClassNotFoundException e) {
			logFail(e.getMessage());
		} catch (SQLException e) {

			logFail(e.getMessage());
		} catch (InterruptedException e) {

			logFail(e.getMessage());
		}

		if (value != null) {
			logPass("Retrieved Value from DB: " + value);
		}

		return value;
	}

	/**
	 * @param query
	 * @param getDBDetailsFromProperties
	 * @return
	 */
	public String connectICPDBAndGetValue(String query, String getDBDetailsFromProperties) {

		String value = null;
		try {
			value = DatabaseUtils.getMySQLConnection(query, getDBDetailsFromProperties, dbICPUserName, dbICPPassword);
		} catch (ClassNotFoundException e) {
			logFail(e.getMessage());
		} catch (SQLException e) {

			logFail(e.getMessage());
		} catch (InterruptedException e) {

			logFail(e.getMessage());
		}

		if (value != null) {
			logPass("Retrieved Value from DB: " + value);
		}

		return value;
	}

	/**
	 * @param query
	 * @param noOfRows
	 * @param getDBDetailsFromProperties
	 * @return
	 */
	public String[] connectICPDBAndGetDBResults(String query, int noOfRows, String getDBDetailsFromProperties) {

		String value[] = null;
		try {
			value = DatabaseUtils.getMySQLConnectionAndGetResultSetValue(query, noOfRows, getDBDetailsFromProperties,
					dbICPUserName, dbICPPassword);
		} catch (ClassNotFoundException e) {
			logFail(e.getMessage());
		} catch (SQLException e) {

			logFail(e.getMessage());
		} catch (InterruptedException e) {

			logFail(e.getMessage());
		}

		if (value != null) {
			logPass("Retrieved Value from DB: " + value);
		}

		return value;
	}

	/**
	 * Connect DB and get row value
	 * 
	 * @throws InterruptedException
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 *             20-02-2019 Nithya
	 */
	public String connectDBAndGetDBRowValue(String query, String getDBDetailsFromProperties, int rowIndex) {

		String value = null;
		try {
			value = DatabaseUtils.getMySQLConnectionAndGetValueForRowIndex(query, getDBDetailsFromProperties,
					dbUserName, dbPassword, rowIndex);
		} catch (ClassNotFoundException e) {
			logFail(e.getMessage());
		} catch (SQLException e) {

			logFail(e.getMessage());
		} catch (InterruptedException e) {

			logFail(e.getMessage());
		}

		if (value != null) {
			logPass("Retrieved Value from DB: " + value);
		}

		return value;
	}

	/**
	 * @param query
	 * @param getDBDetailsFromProperties
	 * @return
	 */
	public String[] connectDBAndGetDBResults(String query, String getDBDetailsFromProperties) {

		String value[] = null;
		try {
			value = DatabaseUtils.getMySQLConnectionAndGetResultSetValue(query, getDBDetailsFromProperties, dbUserName,
					dbPassword);
		} catch (ClassNotFoundException e) {
			logFail(e.getMessage());
		} catch (SQLException e) {

			logFail(e.getMessage());
		} catch (InterruptedException e) {

			logFail(e.getMessage());
		}

		if (value != null) {
			logPass("Retrieved Value from DB: " + value);
		}

		return value;
	}

	/**
	 * @param query
	 * @param noOfRows
	 * @param getDBDetailsFromProperties
	 * @return
	 */
	public String[] connectDBAndGetDBResults(String query, int noOfRows, String getDBDetailsFromProperties) {

		String value[] = null;
		try {
			value = DatabaseUtils.getMySQLConnectionAndGetResultSetValue(query, noOfRows, getDBDetailsFromProperties,
					dbUserName, dbPassword);
		} catch (ClassNotFoundException e) {
			logFail(e.getMessage());
		} catch (SQLException e) {

			logFail(e.getMessage());
		} catch (InterruptedException e) {

			logFail(e.getMessage());
		}

		if (value != null) {
			logPass("Retrieved Value from DB: " + value);
		}

		return value;
	}

	/**
	 * @param query
	 * @param getDBDetailsFromProperties
	 * @return
	 */
	public Map<String, String> connectDBAndGetDBEntireRowValues(String query, String getDBDetailsFromProperties) {

		Map<String, String> value = null;
		try {
			value = DatabaseUtils.getMySQLConnectionAndEntireRowValue(query, getDBDetailsFromProperties, dbUserName,
					dbPassword);
		} catch (ClassNotFoundException e) {
			logFail(e.getMessage());
		} catch (SQLException e) {

			logFail(e.getMessage());
		} catch (InterruptedException e) {

			logFail(e.getMessage());
		}

		if (value != null) {
			logPass("Retrieved Value from DB: " + value);
		}

		return value;
	}

	/**
	 * @param query
	 * @param getDBDetailsFromProperties
	 * @return
	 */
	public ArrayList<String> connectDBAndGetDBEntireColumnValues(String query, String getDBDetailsFromProperties) {

		ArrayList<String> value = null;
		try {
			value = DatabaseUtils.getMySQLConnectionAndEntireColumnValues(query, getDBDetailsFromProperties, dbUserName,
					dbPassword);
		} catch (ClassNotFoundException e) {
			logFail(e.getMessage());
		} catch (SQLException e) {

			logFail(e.getMessage());
		} catch (InterruptedException e) {

			logFail(e.getMessage());
		}

		if (value != null) {
			logPass("Retrieved Value from DB: " + value);
		}

		return value;
	}

	/**
	 * @param query
	 * @param getDBDetailsFromProperties
	 */
	public void executeQueryAndCommit(String query, String getDBDetailsFromProperties) {

		// String value = null;
		try {
			DatabaseUtils.executeQueryAndCommit(query, getDBDetailsFromProperties, dbUserName, dbPassword);
			logInfo("");
		} catch (ClassNotFoundException e) {
			logFail(e.getMessage());
		} catch (SQLException e) {

			logFail(e.getMessage());
		} catch (InterruptedException e) {

			logFail(e.getMessage());
		}
		/*
		 * if (value != null) { logPass("Retrieved Value from DB: " + value); }
		 */

	}

	/**
	 * @param locator
	 * @param textToChoose
	 */
	public void selectDropDownByVisibleText(WebElement locator, String textToChoose) {
		try {
			Select selectDropDown = new Select(locator);
			selectDropDown.selectByVisibleText(textToChoose);
		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
	}

	// NK
	/**
	 * @param locator
	 * @param textToChoose
	 */
	public void selectDropDownByVisibleTextUsingValue(WebElement locator, String textToChoose) {
		try {
			Select selectDropDown = new Select(locator);
			selectDropDown.selectByValue(textToChoose);
		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
	}

	/**
	 * @param locator
	 * @return
	 */
	public List<WebElement> selectDropdownOptionValues(WebElement locator) {
		try {
			Select getOptionValues = new Select(locator);
			List<WebElement> all = getOptionValues.getOptions();
			return all;
		} catch (Exception ex) {
			logFail(ex.getMessage());
			return null;
		}

	}

	/**
	 * @param locator
	 * @param text
	 */
	public void enterText(WebElement locator, String text) {
		locator.clear();
		locator.sendKeys(text);
	}

	/*
	 * 02-05-2018 Ayub Khan
	 */
	public String getTagNameForLocators(WebElement locator) {
		try {
			String tagName = locator.getTagName();
			return tagName;
		} catch (Exception ex) {
			logFail(ex.getMessage());
			return null;
		}

	}

	/*
	 * Added by Anton 03-05-2018
	 * 
	 * 
	 */

	public void clickLinkAndValidateNavigation(WebElement linkOrElement, WebElement footerElementTitle) {
		if (linkOrElement.isDisplayed()) {
			String expText = linkOrElement.getText();
			System.out.println("expText ---- " + expText);
			String actualText = "";
			String parentNew = "";
			linkOrElement.click();
			logInfo(expText + " link or menu is clicked");
			String pageTitleText = "";

			if (expText.trim().equals("Online User Guide")) {
				parentNew = driver.getWindowHandle();

				Set<String> allWindow = driver.getWindowHandles();
				switchToNewWindow(parentNew, allWindow);

				if (footerElementTitle.isDisplayed()) {
					pageTitleText = footerElementTitle.getText();

					if (pageTitleText.equals("Using BP Fuelcard online")) {
						logPass(pageTitleText + " is navigated to the new window");
					}

					closeChildAndMoveToParent(parentNew);
				} else {
					logFail(pageTitleText + " is not navigated to the page");
				}

			}

			else if (expText.trim().equals("Legal notice")) {
				parentNew = driver.getWindowHandle();

				Set<String> allWindow = driver.getWindowHandles();
				switchToNewWindow(parentNew, allWindow);

				if (footerElementTitle.isDisplayed()) {
					pageTitleText = footerElementTitle.getText();

					if (pageTitleText.equals("Legal")) {
						logPass(pageTitleText + " is navigated to the new window");
					}

					closeChildAndMoveToParent(parentNew);
				}

				else {
					logFail(pageTitleText + " is not navigated to the page");
				}
			}

			else if (expText.trim().contains("Privacy statement")) {
				parentNew = driver.getWindowHandle();

				Set<String> allWindow = driver.getWindowHandles();
				switchToNewWindow(parentNew, allWindow);

				if (footerElementTitle.isDisplayed()) {
					pageTitleText = footerElementTitle.getText();

					if (pageTitleText.equals("Privacy")) {
						logPass(pageTitleText + " is navigated to the new window");
					}

					closeChildAndMoveToParent(parentNew);
				}

				else {
					logFail(pageTitleText + " is not navigated to the page");
				}
			}

			else {
				System.out.println("------ Comes in here -----");

				if (footerElementTitle.isDisplayed()) {
					actualText = footerElementTitle.getText();

					System.out.println("----- actualText ---- " + actualText);

					if (expText.trim().equalsIgnoreCase(actualText.trim())) {
						logPass("We are navigated to the " + actualText + " page");
					}

					else {
						logFail("The titles are not matching " + actualText + " and " + expText);
					}
				} else {
					logFail("We are not navigated to the " + expText + " page");
				}
			}

		}
	}

	/**
	 * @param parentLocator
	 * @param childLocator
	 * @param pageTitleEle
	 */
	public void clickSubMenuAndValidate(WebElement parentLocator, WebElement childLocator, WebElement pageTitleEle) {

		try {
			System.out.println("----- Comes in here 000 ----");
			String childLocText = "";
			String pageTitleText = "";
			String parentLocText = "";

			sleep(5);

			System.out.println("------ parentLocator -----" + parentLocator);

			if (parentLocator.isDisplayed()) {
				parentLocText = parentLocator.getText();
				System.out.println("----- Comes in here 11 ----");

				mouseHover(parentLocator);

				sleep(5);

				System.out.println("----- Comes in here 22 ----");

				if (childLocator.isDisplayed()) {

					System.out.println("----- Comes in here 33 ----");

					childLocText = childLocator.getText();

					//actionClick(childLocator);
					JavascriptExecutor executor = (JavascriptExecutor) driver;
					executor.executeScript("arguments[0].click();", childLocator);


					logInfo(childLocText + " Element is clicked");

					if (childLocText.equals("User Help Guide")) {
						String parent = driver.getWindowHandle();
						Set<String> allWindow = driver.getWindowHandles();
						switchToNewWindow(parent, allWindow);
						if (pageTitleEle.isDisplayed()) {
							pageTitleText = pageTitleEle.getText();
							if (childLocText.contains(pageTitleText)) {
								logPass(parentLocText + "menu's submenu" + pageTitleText + " navigated to new window");
							}

							closeChildAndMoveToParent(parent);
						}

						else {
							// logFail(pageTitleEle.getText() + " is not navigated to the page"); BP AU and
							// NZ Alone
							logInfo(pageTitleEle.getText() + " is not navigated to the page");
						}
					}

					else {
						if (pageTitleEle.isDisplayed()) {
							pageTitleText = pageTitleEle.getText();

							if (childLocText.contains(pageTitleText)) {
								logPass(parentLocText + "menu's submenu" + pageTitleText + " navigated is correct");
							}
						}

						else {
							logFail(pageTitleEle.getText() + " is not navigated to the page");
						}
					}

				}

				else {
					System.out.println("------ comes in here ------ else ------");
					logFail(childLocator.getText() + " Element is Not Displayed");
				}
			}

			else {
				logFail(parentLocator.getText() + " Element is Not Displayed");
			}
		} catch (Exception e) {
			logFail(e.getMessage());
		}

	}

	// Sowmiya-->24/07/2019

	/**
	 * 
	 */
	public void scrollRightPageInCreditCardsUser() {
		System.out.println("Inside Scroll Right Page");
		WebElement element = driver.findElement(By.xpath("//*[@id='gview_unassignedChecksGrid']/div[3]"));
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		jse.executeScript("arguments[0].scrollIntoView();", element);
	}

	// Prakalpha-->29/07/2019
	/**
	 * 
	 */
	public void scrollRightPage() {
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		jse.executeScript("window.scrollBy(2000,0)", "");
		System.out.println("Page has scrolled");
	}

	/*
	 * 03-05-2018 Meenakshi Sundaram
	 */

	/**
	 * 
	 */
	public void scrollDownPage() {
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		jse.executeScript("window.scrollBy(0,500)", "");
	}

	/**
	 * 
	 */
	public void scrollUpPage() {
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		jse.executeScript("window.scrollBy(0,-250)", "");
	}

	/**
	 * 
	 */
	public void scrollToTopPage() {
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		jse.executeScript("window.scrollBy(0,-1000)", "");
	}

	// Rathna -- Params : section name and label

	/**
	 * @param seperatorLabelName
	 * @param labelName
	 */
	public void ScrollToElement(String seperatorLabelName, String labelName) {
		sleep(3);
		String seperator = " ";
		String label = " ";
		seperator = splitStringAndGenerateXpath(seperatorLabelName);
		label = splitStringAndGenerateXpath(labelName);
		String strXPath = "//div[" + seperator + "]/preceding::div[" + label + "]";
		System.out.println("Scroll to xpath : " + strXPath);
		WebElement element = driver.findElement(By.xpath("//div[" + seperator + "]/preceding::div[" + label + "]"));
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		jse.executeScript("arguments[0].scrollIntoView();", element);
		logInfo("Scrolled to element:" + label);
		sleep(5);

	}

	// Rathna -- Params : Object(eg: ok button), label
	/**
	 * @param locator
	 * @param label
	 */
	public void ScrollToElement(WebElement locator, String label) {
		sleep(3);

		JavascriptExecutor jse = (JavascriptExecutor) driver;
		jse.executeScript("arguments[0].scrollIntoView();", locator);
		logInfo("Scrolled to element:" + label);
		sleep(5);

	}

	/**
	 * @param seconds
	 */
	public void waitForPageLoad(int seconds) {
		driver.manage().timeouts().pageLoadTimeout(seconds, TimeUnit.SECONDS);
	}

	/**
	 * @param locator
	 * @param text
	 * @param attributeName
	 * @return
	 */
	public boolean selectRadioButtonFromList(List<WebElement> locator, String text, String attributeName) {
		boolean radioButtonflag = false;
		int size = locator.size();
		for (int i = 0; i < size; i++) {
			String value = locator.get(i).getAttribute(attributeName);
			System.out.println("Value is " + value);
			if (value.equalsIgnoreCase(text)) {
				locator.get(i).click();
				radioButtonflag = true;
				break;
			}
		}
		return radioButtonflag;
	}

	/*
	 * public boolean waitForTextToAppearDriver(String textToAppear, long timeOut) {
	 * 
	 * boolean isTextPresent = false;
	 * 
	 * try { WebElement bodyElement = driver.findElement(By.tagName("body"));
	 * WebDriverWait wait = new WebDriverWait(driver, timeOut); isTextPresent =
	 * wait.until(ExpectedConditions.textToBePresentInElement(bodyElement,
	 * textToAppear)); logInfo(isTextPresent + "====> Is Text Presentttt======== " +
	 * bodyElement.getText()); } catch (Exception e) {
	 * logInfo(" Exception in the wait for Text To Appear" + e); }
	 * 
	 * return isTextPresent; }
	 */

	/**
	 * @param locator
	 * @param elementText
	 */
	public void checkElementPresenceAndClick(WebElement locator, String elementText) {
		if (locator.isDisplayed()) {
			actionClick(locator);
			sleep(3);
			logPass(elementText + " clicked successfully");
		} else {
			logFail(elementText + " not clickable");
		}
	}

	/**
	 * @param textToAppear
	 * @param timeOut
	 * @return
	 */
	public boolean waitForTextToAppear(String textToAppear, long timeOut) {

		boolean isTextPresent = false;
		WebElement bodyElement = null;

		try {
			bodyElement = driver.findElement(By.tagName("body"));
			WebDriverWait wait = new WebDriverWait(driver, timeOut);
			isTextPresent = wait.until(ExpectedConditions.textToBePresentInElement(bodyElement, textToAppear));
			logInfo(textToAppear + "is present in the page = " + isTextPresent);
		} catch (Exception e) {
			logInfo(" Exception in the wait for Text To Appear" + e);
		}

		return isTextPresent;
	}

	// Added by Suganthi

	/**
	 * @param locator
	 * @param timeOut
	 * @return
	 */
	public boolean waitToCheckElementIsDisplayed(final By locator, int timeOut) {

		WebDriverWait wait = new WebDriverWait(driver, timeOut);
		try {
			if (wait.until(ExpectedConditions.visibilityOfElementLocated(locator)).isDisplayed() == true) {
				return true;
			} else {
				return false;
			}
		} catch (NoSuchElementException e) {
			logInfo(" Exception in the wait for element To Appear" + e);
			return false;
		} catch (TimeoutException e) {
			return false;
		} catch (StaleElementReferenceException e) {
			return false;
		}
	}

	/**
	 * @param element
	 * @param timeOut
	 * @return
	 */
	public boolean waitForElementTobeClickable(WebElement element, long timeOut) {

		WebElement isElementClickable = null;

		try {

			WebDriverWait wait = new WebDriverWait(driver, timeOut);
			isElementClickable = wait.until(ExpectedConditions.elementToBeClickable(element));
			logInfo("element present");
		} catch (Exception e) {
			logInfo(" Exception in the wait for 30 seconds for the  Element To Appear" + e);
		}

		return isElementClickable.isDisplayed();
	}

	/**
	 * @param table
	 * @param expColSize
	 * @param isSearchSpec
	 */
	public void setCellDataFromTable(WebElement table, int expColSize, boolean isSearchSpec) {

		List<WebElement> colsT;
		int actualColSize = 0;
		List<WebElement> rowTable = table.findElements(By.tagName("tr"));
		// HashMap<String, String> tableValues = new HashMap<String, String>();
		// System.out.println(rowTable.size());
		for (int i = 0; i < rowTable.size(); i++) {

			colsT = rowTable.get(i).findElements(By.tagName("td"));
			// System.out.println(colsT.size());
			actualColSize = colsT.size();

			System.out.println("actualColSize ---- " + actualColSize);

			System.out.println("expColSize ---- " + expColSize);

			if (actualColSize == expColSize) {

				for (int j = 0; j < actualColSize; j++) {

					String key = i + ":" + j;

					String value = colsT.get(j).getText();

					if (isSearchSpec) {
						tableSpec.put(key, value);
					} else {
						tableValues.put(key, value);
					}
					// System.out.print("Cell Value of Row Number "+i+" and Column number "+j+ " is
					// "+cellText);
				}
			}

			else {
				System.out.println("Unwanted Columns");
			}
		}
	}

	/**
	 * @param table
	 * @param expColSize
	 * @param isSearchSpec
	 */
	public void setTableHeaderFromTable(WebElement table, int expColSize, boolean isSearchSpec) {

		List<WebElement> colsT;
		int actualColSize = 0;
		List<WebElement> rowTable = table.findElements(By.tagName("thead"));
		// HashMap<String, String> tableValues = new HashMap<String, String>();
		// System.out.println(rowTable.size());
		for (int i = 0; i < rowTable.size(); i++) {

			colsT = rowTable.get(i).findElements(By.tagName("th"));
			// System.out.println(colsT.size());
			actualColSize = colsT.size();

			if (actualColSize == expColSize) {

				for (int j = 0; j < actualColSize; j++) {
					String key = i + ":" + j;

					String value = colsT.get(j).getText();

					if (isSearchSpec) {
						tableSpec.put(key, value);
					} else {
						tableValues.put(key, value);
					}

					// System.out.print("Cell Value of Row Number "+i+" and Column number "+j+ " is
					// "+cellText);
				}
			}

			else {
				System.out.println("Unwanted Columns");
			}
		}
	}

	/**
	 * @param row
	 * @param col
	 * @param isSearchSpec
	 * @return
	 */
	public String getCellDataFromTable(int row, int col, boolean isSearchSpec) {
		String rowAndCol = row + ":" + col;

		System.out.println("rowAndCol ---- " + rowAndCol);

		String cellValue = null;

		if (isSearchSpec) {
			// System.out.println(tableSpec.size());

			cellValue = tableSpec.get(rowAndCol);
		} else {
			cellValue = tableValues.get(rowAndCol);
		}

		return cellValue;
	}

	/**
	 * @param map
	 */
	public void flushHashMap(HashMap<String, String> map) {

		if (map.size() > 0)
			map.clear();

	}

	/**
	 * @param table
	 * @return
	 */
	public int getRowSize(WebElement table) {
		int size = 0;
		try {
			List<WebElement> rowTable = table.findElements(By.tagName("tr"));
			size = rowTable.size();
		} catch (Exception e) {
			logFail(e.getMessage());
		}
		return size;
	}

	/**
	 * @param driver
	 * @param timeOutInSeconds
	 */
	public static void waitForAjaxProcessing(WebDriver driver, final int... timeOutInSeconds) {
		final int MAX_TIMEOUT_IN_SECONDS = (timeOutInSeconds.length > 0) ? timeOutInSeconds[0] : 10;
		final WebDriverWait wait = new WebDriverWait(driver, MAX_TIMEOUT_IN_SECONDS);
		final ExpectedCondition<Boolean> ajaxProcessingGetsCompleted = new ExpectedCondition<Boolean>() {
			public Boolean apply(final WebDriver driver) {
				if (isAnyActiveAjaxProcessingAvailable(driver))
					return false;
				else
					return true;
			}
		};
		try {
			wait.until(ajaxProcessingGetsCompleted);
		} catch (final TimeoutException exception) {
			fail("Timed out waiting for the ajax processing in the page. (" + MAX_TIMEOUT_IN_SECONDS + " seconds)");
		}
	}

	/**
	 * check whether an ajax processing is available
	 * 
	 * @param driver
	 * @return
	 */

	public static boolean isAnyActiveAjaxProcessingAvailable(WebDriver driver) {
		return (Boolean) executeJavaScript("return jQuery.active != 0;", driver);
	}

	/**
	 * @param javaScript
	 * @param driver
	 * @param args
	 * @return
	 */
	public static Object executeJavaScript(final String javaScript, WebDriver driver, final Object... args) {
		return ((JavascriptExecutor) driver).executeScript(javaScript, args);
	}

	/**
	 * @param table
	 * @param TableName
	 * @return
	 */
	public WebElement getLastRowFromTable(WebElement table, String TableName) {

		WebElement lastRow = null;
		try {
			lastRow = table.findElement(By.xpath("./tbody[@id='lform:manTrans:tb']/tr[last()]"));

		} catch (Exception e) {
			logFail(e.getMessage());
		}

		return lastRow;
	}

	/**
	 * @param textToAppear
	 * @param timeOut
	 */
	public void checkTextInPageAndValidate(String textToAppear, int timeOut) {
		boolean isCheckTextPresent = waitForTextToAppear(textToAppear, timeOut);

		if (isCheckTextPresent) {
			logPass(textToAppear + " text present");
		} else {
			logFail(textToAppear + " text is not present");
		}
	}

	/**
	 * @param textToAppear
	 * @param timeOut
	 */
	public void checkTextNotInPageAndValidate(String textToAppear, int timeOut) {
		boolean isCheckTextPresent = waitForTextToAppear(textToAppear, timeOut);

		try {
			if (isCheckTextPresent) {
				logFail(textToAppear + " text present");
			}
		} catch (NoSuchElementException e) {
			logPass(textToAppear + " text is not present");
		}
	}

	/**
	 * Calendar control - Added By Meenakshi Sundaram
	 * 
	 * @param( { "inputdate", "datePickerButtonLocator", "calendarDialogBox"} )
	 * 
	 * @throws Exception
	 */

	public enum MonthEnum {
		JANUARY, FEBRUARY, MARCH, APRIL, MAY, JUNE, JULY, AUGUST, SEPTEMBER, OCTOBER, NOVEMBER, DECEMBER
	}

	/**
	 * @param date
	 * @param datePicker
	 * @param calendarDialogBoxLocator
	 * @throws Exception
	 */
	public void pickDate(Date date, WebElement datePicker, WebElement calendarDialogBoxLocator) throws Exception {

		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		int year = calendar.get(Calendar.YEAR);
		int month = calendar.get(Calendar.MONTH);
		int day = calendar.get(Calendar.DAY_OF_MONTH);
		show(datePicker);

		pickYear(year, calendarDialogBoxLocator);
		pickMonth(month, calendarDialogBoxLocator);
		pickDay(day, calendarDialogBoxLocator);
	}

	/**
	 * @param element
	 * @throws Exception
	 */
	private void show(WebElement element) throws Exception {

		isDisplayedThenActionClick(element, "Date Picker");
	}

	/**
	 * @param year
	 * @param calendarDialogBox
	 */
	private void pickYear(int year, WebElement calendarDialogBox) {

		if (displayedYear(calendarDialogBox) < year) {
			while (displayedYear(calendarDialogBox) != year) {
				nextYear(calendarDialogBox);
			}
		} else if (displayedYear(calendarDialogBox) > year) {
			while (displayedYear(calendarDialogBox) != year) {
				previousYear(calendarDialogBox);
			}
		}
	}

	/**
	 * @param month
	 * @param calendarDialogBox
	 */
	private void pickMonth(int month, WebElement calendarDialogBox) {

		if (displayedMonth(calendarDialogBox) < month) {
			while (displayedMonth(calendarDialogBox) != month) {
				nextMonth(calendarDialogBox);
			}
		} else if (displayedMonth(calendarDialogBox) > month) {
			while (displayedMonth(calendarDialogBox) != month) {
				previousMonth(calendarDialogBox);
			}
		}
	}

	/**
	 * @param day
	 * @param calendarDialogBox
	 * @throws Exception
	 */
	private void pickDay(int day, WebElement calendarDialogBox) throws Exception {
		System.out.println("int day" + day);
		List<WebElement> tds = calendarDialogBox.findElements(By.cssSelector("td[class*='rf-cal-btn']"));
		for (WebElement td : tds) {
			waitForElementTobeClickable(td, 1);

			if (td.getText().equals(String.valueOf(day))) {
				isDisplayedThenActionClick(td, "Day");
				break;
			}
		}
	}

	/**
	 * @param calendarDialogBox
	 */
	private void nextYear(WebElement calendarDialogBox) {

		calendarDialogBox.findElement(By.cssSelector("div[onclick*='nextYear()']")).click();

	}

	/**
	 * @param calendarDialogBox
	 */
	private void previousYear(WebElement calendarDialogBox) {

		calendarDialogBox.findElement(By.cssSelector("div[onclick*='prevYear()']")).click();

	}

	/**
	 * @param calendarDialogBox
	 */
	private void nextMonth(WebElement calendarDialogBox) {

		calendarDialogBox.findElement(By.cssSelector("div[onclick*='nextMonth()']")).click();

	}

	/**
	 * @param calendarDialogBox
	 */
	private void previousMonth(WebElement calendarDialogBox) {

		calendarDialogBox.findElement(By.cssSelector("div[onclick*='prevMonth()']")).click();
	}

	/**
	 * @param calendarBox
	 * @return
	 */
	private int displayedYear(WebElement calendarBox) {

		waitForElementTobeClickable(calendarBox, 3);
		String year = calendarBox.findElement(By.cssSelector("div[onclick*='showDateEditor']")).getText().split(",")[1]
				.trim();
		return Integer.parseInt(year);
	}

	/**
	 * @param calendarBox
	 * @return
	 */
	private int displayedMonth(WebElement calendarBox) {

		String month = calendarBox.findElement(By.cssSelector("div[onclick*='showDateEditor']")).getText().split(",")[0]
				.trim();
		return MonthEnum.valueOf(month.toUpperCase()).ordinal();
	}

	/*
	 * 
	 * added by Anton 22.05
	 * 
	 */

	public HashSet<String> getDataFromSet(HashSet<String> setData, int j) {
		HashSet<String> firstData = new HashSet<String>();
		String reportType;

		for (String dd : setData) {
			reportType = dd.split("-", 2)[j].trim();
			firstData.add(reportType);
		}

		return firstData;
	}

	/**
	 * @throws Exception
	 */
	public void LogoutIfFailure() throws Exception {
		LoginPage loginPage = new LoginPage(driver, test);
		java.util.Set<String> allWindow = driver.getWindowHandles();
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		if (driver.getCurrentUrl().contains("ajaxswing")) {
			System.out.println("ajax swing window");

			try {

				List<WebElement> popupList = driver.findElements(By.xpath("//div[@class='ajaxswingv4 v4init']"));
				int closePopupSize = popupList.size();
				System.out.println(closePopupSize);
				for (int size = closePopupSize; size > 1; size--) {
					WebElement closePopup = driver.findElement(By.xpath("//div[@class='ajaxswingv4 v4init'][" + size
							+ "]//div[@class='JButton enabled']//img[contains(@src,'close.gif')]"));
					System.out.println(closePopup);
					sleep(3);
					checkElementPresenceAndClick(closePopup, "Pop Up");
				}
			}

			catch (Exception e) {
				logFail(e.getMessage());
			}
			IFCSHomePage.exitIFCS();
		} else if (driver.getCurrentUrl().contains("cruise")) {
			System.out.println("Cruise");
			try {
				driver.navigate().refresh();
				WebElement cruiseMainMenuLogOut = driver
						.findElement(By.xpath("//div[@id='bar']//li/a[contains(text(),'Log Out')]"));
				mouseHover(cruiseMainMenuLogOut);
				WebElement subMenuOptionLogOut = driver.findElement(By.xpath("//ul//form[@id='logout']"));
				Click(subMenuOptionLogOut, "LogOut submenu");
			} catch (Exception e) {
				logFail(e.getMessage());
			}
		}

		else if (driver.getCurrentUrl().contains("velocity")) {
			System.out.println("velocity");
			try {
				driver.navigate().refresh();
				WebElement VelocityMainMenuLogout = driver.findElement(By.xpath("//a[contains(text(),'Logout')]"));
				isDisplayedThenActionClick(VelocityMainMenuLogout, "clicking logout");
			} catch (Exception e) {
				logFail(e.getMessage());
			}

		}
		else if (driver.getCurrentUrl().contains("wfestage.lightning.force")) {
			
			try {
				SalesForceCommon salesforce = new SalesForceCommon(driver, test);
				salesforce.logOutSalesForce();
			} catch (Exception e) {
				logFail(e.getMessage());
			}

		}


		else {
			if (allWindow.size() > 1) {

				// sleep(10);

				String window = driver.getWindowHandle();
				System.out.println("title ---- " + driver.getTitle());
				closeChildWindowAndswitchToParent(window, allWindow);
				loginPage.LogoutSession();
				// sleep(10);
				closeChildAndMoveToParent(window);
				scrollUpPage();
				loginPage.LogoutSession();
			}

			else {
				scrollUpPage();
				loginPage.LogoutSession();
			}
		}

	}

	/**
	 * 
	 */
	public void clearData() {
		// TODO Auto-generated method stub
		flushHashMap(tableValues);
		flushHashMap(tableSpec);
	}

	// Added by Anton 07.06

	public void selectOptionByVisibleText(WebElement locator, String text) {
		try {
			Select selectElement = new Select(locator);
			selectElement.selectByVisibleText(text);
			logInfo(text + " is Selected");
		} catch (Exception e) {
			logFail(e.getMessage());
		}

	}

	/*
	 * Added by Anton
	 * 
	 */
	public void waitUntilElementDisplayed(final WebElement webElement) {
		// driver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS);
		WebDriverWait wait = new WebDriverWait(driver, TIMEOUT);
		ExpectedCondition<Boolean> elementIsDisplayed = new ExpectedCondition<Boolean>() {
			public Boolean apply(WebDriver arg0) {
				try {
					webElement.isDisplayed();
					return true;
				} catch (NoSuchElementException e) {
					return false;
				} catch (StaleElementReferenceException f) {
					return false;
				}
			}
		};
		wait.until(elementIsDisplayed);
		// driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}

	/**
	 * @param headerMenuText
	 * @param subMenuText
	 */
	public void mouseHoverClickMenuAndSubMenu(String headerMenuText, String subMenuText) {

		List<WebElement> headers = driver.findElements(By.xpath("//ul[@id='levelOne']/li/a"));

		List<WebElement> subMenus;

		JavascriptExecutor executor = (JavascriptExecutor) driver;

		boolean isClicked = false;

		boolean ismouseHover = false;

		for (WebElement headerMenu : headers) {

			if (ismouseHover)
				break;

			waitUntilElementDisplayed(headerMenu);

			if (headerMenu.getText().equals(headerMenuText)) {

				mouseHover(headerMenu);

				ismouseHover = true;

				subMenus = driver.findElements(By.xpath("//ul[@class='levelTwo']/li/a"));

				for (WebElement subMenuProfile : subMenus) {

					if (isClicked)
						break;

					waitUntilElementDisplayed(subMenuProfile);

					if (subMenuProfile.getText().equals(subMenuText)) {

						executor.executeScript("arguments[0].click();", subMenuProfile);
						isClicked = true;

					}
				}

			}
		}
	}

	/**
	 * @param element
	 * @return
	 */
	public String clickAndSwitchToNewWindow(WebElement element) {
		String parentNew;
		isDisplayedThenClick(element, "Element");
		parentNew = driver.getWindowHandle();
		Set<String> allWindow = driver.getWindowHandles();
		switchToNewWindow(parentNew, allWindow);
		return parentNew;
	}

	/**
	 * @param selectElement
	 * @param message
	 */
	public void selectDropDownOptionsRandomly(WebElement selectElement, String message) {
		try {
			Select selDropDown = new Select(selectElement);

			List<WebElement> options = selDropDown.getOptions();

			int optionsSize = options.size();

			System.out.println("---- optionsSize ----" + optionsSize);

			int index = 0;

			String firstOption = options.get(0).getText();

			if (firstOption.equals("--Select One--")) {
				index = getRandomNumber(1, optionsSize - 1);
			}

			else {
				index = getRandomNumber(0, optionsSize - 1);
			}

			selDropDown.selectByIndex(index);
			logInfo(index + " is Selected");
		} catch (Exception e) {
			logFail(e.getMessage());
		}
	}

	/**
	 * @param table
	 * @param subMenu
	 * @param validationMsg
	 * @param isSubMenu
	 * @return
	 */
	public boolean selectFirstColumnAndChooseMenu(WebElement table, WebElement subMenu, String validationMsg,
			boolean isSubMenu) {
		try {

			boolean isDisplayNamePresent = false;

			isDisplayed(table, "Card Table");

			sleep(3);

			WebElement firstRow = table.findElement(By.xpath("./tbody[contains(@id,':tb')]/tr[1]"));

			isDisplayed(firstRow, "First Row");

			WebElement firstCol = firstRow.findElement(By.xpath("./td[1]/p/span"));

			if (firstCol.isDisplayed()) {

				Click(firstCol, "First Column");

				logInfo("First Column is clicked");

				isDisplayNamePresent = true;

				sleep(5);

				if (isSubMenu) {

					isDisplayedThenActionClick(subMenu, validationMsg);

					sleep(5);

					checkTextInPageAndValidate(validationMsg, 30);
				}

				return isDisplayNamePresent;
			}

			else {
				logInfo("First Column display name is not present");

				WebElement secondRow = table.findElement(By.xpath("./tbody[contains(@id,':tb')]/tr[2]"));

				isDisplayed(secondRow, "Second Row");

				WebElement firstColSR = secondRow.findElement(By.xpath("./td[1]/p/span"));

				if (firstColSR.isDisplayed())

				{
					Click(firstColSR, "First Column Second Row");
					logInfo("Second Column is clicked");
					isDisplayNamePresent = true;

					sleep(5);

					if (isSubMenu) {

						isDisplayedThenActionClick(subMenu, validationMsg);

						sleep(5);

						checkTextInPageAndValidate(validationMsg, 30);
					}

					return isDisplayNamePresent;
				}

				else {
					logInfo("Second Row DisplayName also not present");
					isDisplayNamePresent = false;
					return isDisplayNamePresent;
				}

			}

		} catch (Exception e) {
			logFail(e.getMessage());
			return false;
		}
	}

	/**
	 * @param element
	 * @param logMessage
	 */
	public void checkAnElementIsDisabled(WebElement element, String logMessage) {
		boolean isDisabled = false;

		String disabledVal = "";

		try {

			System.out.println("----- element --- " + element);

			if (element.isDisplayed()) {
				disabledVal = element.getAttribute("disabled");

				if (disabledVal != null) {
					if (disabledVal.equals("true")) {
						isDisabled = true;
					} else {
						isDisabled = false;
					}
				}

				if (isDisabled) {
					logPass(logMessage + " Disabled");
				} else {
					logPass(logMessage + " Enabled");
				}

			}

			else {
				logInfo("element is not displayed ==== ");
			}

		} catch (Exception e) {
			System.out.println("catch ---- " + element);

			logFail(e.getMessage());
		}
	}

	/**
	 * @param headerMenuText
	 * @param subMenuText
	 * @return
	 */
	public boolean checkSubMenuPresence(String headerMenuText, String subMenuText) {

		List<WebElement> headers = driver.findElements(By.xpath("//ul[@id='levelOne']/li/a"));

		List<WebElement> subMenus;

		boolean isPresent = false;

		boolean ismouseHover = false;

		for (WebElement headerMenu : headers) {

			if (ismouseHover)
				break;

			waitUntilElementDisplayed(headerMenu);

			if (headerMenu.getText().equals(headerMenuText)) {

				mouseHover(headerMenu);

				ismouseHover = true;

				subMenus = driver.findElements(By.xpath("//ul[@class='levelTwo']/li/a"));

				for (WebElement subMenuProfile : subMenus) {

					if (isPresent)
						break;

					if (subMenuProfile.getText().equals(subMenuText)) {
						isPresent = true;
					}
				}

			}
		}
		return isPresent;
	}

	/**
	 * @return
	 */
	public String getCurrentDate() {
		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
		Date date = new Date();
		String currentDate = formatter.format(date);
		return currentDate;
	}

	/**
	 * @param dateValue
	 * @param formatNeeded
	 * @return
	 */
	public String getDateInFormat(Date dateValue, String formatNeeded) {
		SimpleDateFormat formatter = new SimpleDateFormat(formatNeeded);

		String currentDate;
		currentDate = formatter.format(dateValue);
		return currentDate;
	}

	// Added by Anton on 26.06.2018

	public String getFutureDate(int futureDateVal) {
		String futureDate = null;

		SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");

		Date currentDate = new Date();

		// convert date to calendar
		Calendar c = Calendar.getInstance();
		c.setTime(currentDate);

		// manipulate date
		c.add(Calendar.DATE, futureDateVal); // same with c.add(Calendar.DAY_OF_MONTH, 1);
		// convert calendar to date
		Date currentDatePlusOne = c.getTime();

		futureDate = dateFormat.format(currentDatePlusOne);

		return futureDate;
	}

	/**
	 * Get The Latest Downloaded Excel File From The Directory
	 * 
	 * @return
	 */
	public static File getLatestDownloadedFileFromDir(final String fileName) {
		String filePath;
		if (fileName == "ShellLogo") {
			filePath = System.getProperty("user.dir") + "/" + "Image" + "/";
		} else {
			filePath = System.getProperty("user.home") + "//" + "Downloads" + "//";
		}
		File userDirectory = new File(filePath);
		// System.out.println("User Directory"+userDirectory);
		File lastModifiedFile = null;

		/*
		 * File recentFile = null;
		 * 
		 * long allFile = null;
		 */

		File[] files = userDirectory.listFiles(new FilenameFilter() {

			public boolean accept(File dir, String name) {
				// TODO Auto-generated method stub
				// System.out.println(name.contains(fileName));
				return name.contains(fileName);
			}
		});

		if (files != null) {
			try {
				lastModifiedFile = files[0];

				System.out.println(lastModifiedFile.getName());
			} catch (NullPointerException e) {
				return null;
			} catch (ArrayIndexOutOfBoundsException e) {
				return null;
			}

			for (int initialFileCount = 0; initialFileCount < files.length; initialFileCount++) {

				if (lastModifiedFile.lastModified() <= files[initialFileCount].lastModified()) {
					System.out.println("last modified file" + lastModifiedFile.lastModified());
					lastModifiedFile = files[initialFileCount];
				}
			}

		}
		fileBucket.add(lastModifiedFile);
		return lastModifiedFile;
	}

	/**
	 * Upload The File From The Local Added by Anton 12-07-2018
	 */
	public void uploadTheExcelSheetFromTheLocal(String fileName) {
		try {
			String downloadedFilePath;
			// System.out.println("The Downloaded File Path is" + downloadedFilePath);
			String downloadedFileName = getLatestDownloadedFileFromDir(fileName).getName();
			System.out.println("The Downloaded File Name is" + downloadedFileName);
			if (getOSDetails().contains("WINDOWS")) {
				if (downloadedFileName.contains("ShellLogo")) {
					downloadedFilePath = System.getProperty("user.dir") + "\\Image\\";
					System.out.println("The Downloaded File Path is" + downloadedFilePath);
				} else {
					downloadedFilePath = System.getProperty("user.home") + "\\Downloads\\";
					System.out.println("The Downloaded File Path is" + downloadedFilePath);
				}
				SikuliUtils.waitUntilObjectisLoaded(2.0);
				SikuliUtils.enterText(Constants.FILEName_INPUTPATH, downloadedFilePath);
				SikuliUtils.waitUntilObjectisLoaded(2.0);
				SikuliUtils.clickElement(Constants.OPEN);
				SikuliUtils.waitUntilObjectisLoaded(2.0);
				SikuliUtils.clearText(Constants.FILEName_INPUTPATH);
				SikuliUtils.waitUntilObjectisLoaded(2.0);
				SikuliUtils.enterText(Constants.FILEName_INPUTPATH, downloadedFileName);
				SikuliUtils.clickElement(Constants.OPEN);
				SikuliUtils.clearText(Constants.FILEName_INPUTPATH);
			} else if (getOSDetails().equals("LINUX")) {
				if (downloadedFileName.contains("ShellLogo")) {
					System.out.println(fileName);
					downloadedFilePath = System.getProperty("user.dir") + "/Image/";
					System.out.println("The Downloaded File Path is" + downloadedFilePath);
				} else {
					downloadedFilePath = System.getProperty("user.home") + "/Downloads/";
					System.out.println("The Downloaded File Path is" + downloadedFilePath);
				}
				SikuliUtils.enterText(Constants.LOCATIONName_INPUTPATH, downloadedFilePath + downloadedFileName);
				// SikuliUtils.waitUntilObjectisLoaded(2.0);
				SikuliUtils.clickElement(Constants.OPENICON);
				SikuliUtils.waitUntilObjectisLoaded(2.0);
			}
			sleep(10);
		} catch (NullPointerException e) {
			System.out.println("Downloaded File Does not Exist" + e);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	/**
	 * 
	 */
	public static void deleteExcelFile() {
		if (fileBucket.size() != 0) {
			for (int initialBucketSize = 0; initialBucketSize < fileBucket.size(); initialBucketSize++) {
				fileBucket.get(initialBucketSize).delete();
				System.out.println("File is Deleted");
			}
		}

	}

	/**
	 * @param linkButton
	 * @param pageText
	 */
	public void validateClickableLinkRedirection(WebElement linkButton, String pageText) {
		String firstTab = driver.getWindowHandle();
		clickAndSwitchToNewWindow(linkButton);
		sleep(10);
		String url = driver.getCurrentUrl().split(":")[1];
		System.out.println("get URL" + url);
		System.out.println("get pageText" + pageText);
		if (url.equals(pageText)) {
			closeChildAndMoveToParent(firstTab);
			sleep(5);
			logPass("Successfully Page is Redirected new tab");
		} else {
			logFail("Page is not Redirected new tab");
		}
	}

	/*
	 * Page will be redirected to appended href links Added "contains" methods for
	 * asserting
	 */

	public void validateClickableLinkRedirectionContains(WebElement linkButton, String pageText) {
		String firstTab = driver.getWindowHandle();
		clickAndSwitchToNewWindow(linkButton);
		sleep(10);
		String url = driver.getCurrentUrl().split(":")[1];
		System.out.println("get URL" + url);
		System.out.println("get pageText" + pageText);
		if (url.contains(pageText)) {
			closeChildAndMoveToParent(firstTab);
			sleep(5);
			logPass("Successfully Page is Redirected new tab");
		} else {
			logFail("Page is not Redirected new tab");
		}
	}

	/**
	 * @param inputElement
	 * @return
	 */
	public boolean checkOptionalElementIsPresentOrNot(List<WebElement> inputElement) {

		Boolean isPresent = inputElement.size() > 0;

		if (isPresent) {
			logInfo("Element is present");
		}

		else {
			logInfo("Element is not present");
		}

		return isPresent;
	}

	/**
	 * @param frmDate
	 * @param numberOfYears
	 * @return
	 */
	public String getNewDate(WebElement frmDate, int numberOfYears) {
		String traFromText = getAttribute(frmDate, "value");

		String date = traFromText.split("/")[0];

		String month = traFromText.split("/")[1];

		String year = traFromText.split("/")[2];

		int yearVal = Integer.parseInt(year) - numberOfYears;

		String year1 = String.valueOf(yearVal);

		String newDate = date + "/" + month + "/" + year1;

		return newDate;
	}

	/*
	 * Added by Anton. It is to verify the text present in the Drop down
	 * 
	 * 
	 */

	public boolean isTextPresentInDropDown(WebElement dropdownElement, String textValue) {
		Boolean found = false;

		Select selectElement = new Select(dropdownElement);

		List<WebElement> allOptions = selectElement.getOptions();

		String optionVal = null;

		for (WebElement option : allOptions) {
			optionVal = option.getText();

			System.out.println("----- Option ---- " + optionVal);

			System.out.println("----- textValue ---- " + textValue);

			if (optionVal.equals(textValue)) {
				found = true;
				break;
			}
		}

		return found;
	}

	/***
	 * 
	 * Navigate Back
	 * 
	 */
	public void gotoLastPage() {
		driver.navigate().back();

		sleep(5);

		logInfo("The Driver navigated to previous page");

	}

	// Reading the file
	public static String[] readFile(String fileToBeRead) throws IOException {
		BufferedReader in = new BufferedReader(new FileReader(fileToBeRead));
		String str;
		List<String> list = new ArrayList<String>();
		while ((str = in.readLine()) != null) {
			list.add(str);
		}
		String[] fileContents = list.toArray(new String[list.size()]);
		in.close();
		return fileContents;
	}

	// Copy the File
	public static File copyFile(String source, String fileNames, String client) throws FileNotFoundException {

		String fileFormat = "";
		String currentDateandTime = getCurrentDateAndTime("yyyyMMdd_HHmmss");

		if (fileNames.contains("A01")) {
			if (client.equals("ООО Шелл Нефть")) {
				fileFormat = ".dat";
			}

			else if (client.equals("SHELL Czech Republic")) {
				fileFormat = ".txt";
			}
			outgoingFileName = System.getProperty("user.home") + "\\Documents\\" + fileNames + "_" + currentDateandTime
					+ fileFormat;
			System.out.println("Created outgoing fileName is" + outgoingFileName);
		} else if (fileNames.contains("FLTRAN")) {

			fileFormat = ".txt";

			outgoingFileName = System.getProperty("user.home") + "\\Documents\\" + fileNames + fileFormat;
			System.out.println("Created outgoing fileName is : " + outgoingFileName);

		} else {

			outgoingFileName = System.getProperty("user.home") + "\\Documents\\" + fileNames;
			System.out.println("Created outgoing fileName is" + outgoingFileName);
		}

		File destinationFile = new File(outgoingFileName);

		try {
			boolean flag = destinationFile.createNewFile();
			BufferedReader br = new BufferedReader(
					new InputStreamReader(new FileInputStream(new File(source)), StandardCharsets.UTF_8));
			BufferedWriter bw = new BufferedWriter(
					new OutputStreamWriter(new FileOutputStream(destinationFile), StandardCharsets.UTF_8));
			System.out.println("Created fileName is" + outgoingFileName + flag + destinationFile.getAbsolutePath());

			char[] cbuf = new char[1024];
			int len;

			while ((len = br.read(cbuf)) > 0) {
				bw.write(cbuf, 0, len);
			}
			bw.write('\n');
			br.close();
			bw.close();
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}
		fileBucket.add(destinationFile);
		return destinationFile;
	}

	/**
	 * @param text
	 * @param numberOfTime
	 * @param isContains
	 */
	public void verifyTextPresenceNumOfTimes(String text, int numberOfTime, boolean isContains) {
		List<WebElement> textsInPage = null;

		if (isContains) {
			textsInPage = driver.findElements(By.xpath("//*[contains(text(),'" + text + "')]"));
		} else {
			textsInPage = driver.findElements(By.xpath("//*[text()='" + text + "']"));
		}
		int sizeList = 0;

		System.out.println("----text ---" + text);

		if (numberOfTime > 0) {
			sizeList = textsInPage.size();

			System.out.println("----size List -----" + sizeList);

			if (sizeList == numberOfTime) {
				logPass(text + " Texts present and number of times are equal");
			}

			else {
				logFail(text + " Texts present and number of times are not equal");
			}

		}

		else {
			logInfo("Number of time is Zero.");
		}
	}

	/*
	 * Created By Anton
	 * 
	 * 20/12/2018
	 * 
	 * To Find Broken Images
	 * 
	 */
	public void verifyimageActive() {

		boolean isValidImage = false;

		String imageName = null;

		try {

			List<WebElement> allImgsHP = driver.findElements(By.xpath("//div[@class='htmlImage']"));

			int imgsSize = allImgsHP.size();

			if (imgsSize > 0) {

				for (WebElement imgDivElement : allImgsHP)

				{
					String imgURLFull = imgDivElement.getAttribute("style");

					System.out.println("---- imgURLFull -------" + imgURLFull);

					String requestURI = getUrl(imgURLFull);

					System.out.println("----- requestURI ----" + requestURI);

					isValidImage = imageValidatity(requestURI);

					imageName = getImageName(requestURI);

					if (isValidImage) {
						logPass(imageName + " image in IFCS Home Page is not broken, Size also matching.");
					}

					else {
						logInfo(imageName
								+ " image in IFCS Home Page is broken Or Size is not matching Or excption caught for the image.");
					}
				}
			}

			else {
				logInfo("No image icons present in the homepage.");
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	/**
	 * @param fullUrl
	 * @return
	 */
	private String getUrl(String fullUrl) {
		String urlValue = null;

		String partUrl = fullUrl.split("\\(")[1];

		String urlWithQuotes = partUrl.split("\\)")[0];

		// urlValue= urlWithQuotes.substring(1, urlWithQuotes.length()-1); alternate

		urlValue = urlWithQuotes.replaceAll("^\"|\"$", "");

		return urlValue;
	}

	/**
	 * @param url
	 * @return
	 */
	private boolean imageValidatity(String url) {
		boolean isvalidImage = false;

		try {

			BufferedImage img = ImageIO.read(new URL(url));

			if (img.getHeight() == 16 && img.getWidth() == 16) {
				isvalidImage = true;
			}

			else {
				isvalidImage = false;
			}

			return isvalidImage;
		} catch (IllegalArgumentException e) {
			return isvalidImage;
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			return isvalidImage;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			return isvalidImage;
		}
	}

	/**
	 * @param url
	 * @return
	 */
	private String getImageName(String url) {
		String imageName = null;

		try {
			imageName = FilenameUtils.getBaseName(new URL(url).getPath());
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return imageName;
	}

	/**
	 * @param locator
	 */
	public void rightClick(WebElement locator) {
		try {
			/* WebDriverWait wait = new WebDriverWait(driver, 30);
			 wait.until(ExpectedConditions.visibilityOf(locator));*/
			Actions act = new Actions(driver);
			act.contextClick(locator).build().perform();
		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
	}

	// Prakalpha -->Added Double click

	/**
	 * @param locator
	 */
	public void doubleClick(WebElement locator) {
		try {
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(locator));
			Actions act = new Actions(driver);
			act.doubleClick(locator).build().perform();
		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
	}

	/**
	 * @param locator
	 * @param message
	 */
	public void isDisplayedThenDoubleClick(WebElement locator, String message) {
		try {
			waitUntilElementDisplayed(locator);
			if (locator.isDisplayed()) {
				doubleClick(locator);
				logPass(message + " is Displayed and Clicked on it.");
			} else {
				logFail(message + " is Not Displayed");
			}
		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
	}

	// Nithya
	/**
	 * @param comboTitle
	 * @param option
	 */
	public void chooseOptionFromComboPopup(String comboTitle, String option) {
		boolean isOptionPresent = false;
	/*	try {
			WebElement textEditor = driver.findElement(
					By.xpath("//div[@class='BasicComboBoxEditor_BorderlessTextField JTextComponent']/input"));
			isDisplayedThenActionClick(textEditor, "Dropdown is displayed");
			// textEditor.click();
			// sleep(10);
			textEditor.sendKeys(option);
			sleep(10);
			isOptionPresent = true;
		} catch (Exception ex) {
			// logFail(ex.getMessage());
			isOptionPresent = false;
		}*/
		try {
			if (!isOptionPresent) {
				WebElement comboDropDown = null;
				List<WebElement> comboOptions = null;
				comboDropDown = driver.findElement(By.xpath(
						"//div[@class='JFALCompControlPanel']/following::div[@class='JFALLabel']/div[contains(text(),'"
								+ comboTitle
								+ "')]//preceding::div[@class='JFALComboBox']//div[@class='MetalComboBoxButton enabled JButton']"));
				isDisplayedThenClick(comboDropDown, "Combo Dropdown");
				comboOptions = driver
						.findElements(By.xpath("//div[@class='BasicComboPopup_1']/div/div[@class='htmlString']"));

				for (int i = 0; i < comboOptions.size(); i++) {
					System.out.println("Options: " + getText(comboOptions.get(i)));
					if (option.toLowerCase().equals(getText(comboOptions.get(i)).toLowerCase())) {
						isOptionPresent = true;
						isDisplayedThenActionClick(comboOptions.get(i), comboTitle + "->" + option);

						break;
					}
				}
				if (!isOptionPresent) {
					logFail("Given client name was not present");
				}
			}
		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
	}

	/**
	 * @param mainMenuOption
	 * @param subMenuOption
	 */
	public void chooseSubMenuFromLeftPanel(String mainMenuOption, String subMenuOption) {
		try {
			List<WebElement> menuOptions = driver
					.findElements(By.xpath("//div[@class='ExtTree']//div[@class='htmlString']"));
			boolean isMainMenuChosen = false, isSubmenuChosen = false;
			for (WebElement mainMenu : menuOptions) {
				if (getText(mainMenu).equals(mainMenuOption)) {
					isDisplayedThenActionClick(mainMenu, mainMenuOption + "Tree menu option");
					sleep(10);
					isMainMenuChosen = true;
					break;
				}
			}
			if (!isMainMenuChosen) {
				logFail("Expected main menu not present in the left panel");
			}
			if (isMainMenuChosen && !(subMenuOption.equals(""))) {
				List<WebElement> menuOption = driver
						.findElements(By.xpath("//div[@class='ExtTree']//div[@class='htmlString']"));
				for (WebElement subMenu : menuOption) {
					if (getText(subMenu).equals(subMenuOption)) {
						isDisplayedThenActionClick(subMenu, subMenuOption + "Tree submenu option");
						sleep(10);
						isSubmenuChosen = true;
						break;
					}
				}
				if (!isSubmenuChosen) {
					logFail("Expected submenu not present in the left panel");
				}
			}
		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
		sleep(10);
	}

	/*
	 * Prakalpha
	 * 
	 * Validating size of the tab and Order of the Tab
	 */

	public void verifyTabNameAndSize(String nameofthetabs) {
		List<String> expectedTabList = Arrays.asList(nameofthetabs.split(","));
		List<String> actualTabList = new ArrayList<String>();
		try {
			System.out.println("expectedtabname--->" + expectedTabList);
			List<WebElement> actualListofTab = driver
					.findElements(By.xpath("//div[@class='JFALTabbedPane']/div[@class='htmlString']"));
			for (int i = 0; i < actualListofTab.size(); i++) {
				String labelName = actualListofTab.get(i).getText();
				actualTabList.add(labelName);
			}
			System.out.println("ActualTabname--->" + actualTabList);
			if (actualTabList.equals(expectedTabList)) {
				logPass("Size and Order of the Tab is Matched");
			} else {
				logFail("Size and Order of the Tab is not Matched");
			}
		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
	}
	/*
	 * Prakalpha Switch from one tab to another
	 */

	public void switchTabDetails(String tabnameToSwitch) {

		try {
			List<WebElement> listOfTab = driver
					.findElements(By.xpath("//div[@class='JFALTabbedPane']/div[@class='htmlString']"));
			int tabListSize = listOfTab.size();
			logPass("Size of the tab" + tabListSize);
			for (int k = 0; k < tabListSize; k++) {
				if (listOfTab.get(k).getText().equals(tabnameToSwitch)) {
					WebElement expectedtab = listOfTab.get(k);
					isDisplayedThenClick(expectedtab, "Expected Tab");
					break;
				}
			}
			logPass("switched the tab");
		} catch (Exception ex) {
			logFail(ex.getMessage());
		}

	}

	/**
	 * @param inputText
	 * @return
	 */
	public String splitStringAndGenerateXpath(String inputText) {
		String text = " ";
		if (inputText.contains(" ")) {
			String splitText[] = inputText.split(" ");
			for (int i = 0; i < splitText.length; i++) {
				// System.out.println(splitText[i]);
				if (i == 0) {
					text = text.concat("starts-with(text(),'" + splitText[i] + "')and ");
				} else if (i == splitText.length - 1) {
					text = text.concat("contains(text(),'" + splitText[i] + "')");
				} else {
					text = text.concat("contains(text(),'" + splitText[i] + "')and ");
				}
			}
			return text;
		} else {
			text = text.concat("(text()='" + inputText + "')");
			return text;
		}
	}

	public boolean isNumeric(String inputValue) {
		try {
			Integer.parseInt(inputValue);
			return true;
		} catch (NumberFormatException ex) {
			logFail(ex.getMessage());
		}
		return false;
	}

	public void checkIsNumericOrString(String labelName, String inputValue, String actualValue) {
		int actualResult;
		int expectedResult;

		try {
			boolean isNumeric = isNumeric(inputValue);
			if (isNumeric) {
				actualResult = Integer.parseInt(actualValue);
				expectedResult = Integer.parseInt(inputValue);
				// System.out.println(expectedresult);
				// Integer comparison
				if (actualResult == expectedResult) {
					logPass(labelName + " is verified as ExpectedResult");
				} else {
					logFail(labelName + " is not verified as ExpectedResult");
				}
			}
			// String comparison
			else if (actualValue.equals(inputValue)) {
				logPass(labelName + " is verified as ExpectedResult");

			} else {
				logFail(labelName + " is not verified as ExpectedResult");
			}
		}

		catch (Exception ex) {
			logFail(ex.getMessage());
		}

	}

	// sowmiya
	// verify the IFCS popup in expected input is present in expected label
	public void verifyEnableFieldFromLabelAndTextInPopup(String seperator, String fieldName, String attributeName,
			String inputValue) {
		String labelText = " ";
		String actualValue = " ";
		WebElement enableTextElement;
		String textSeperator = " ";
		// if the string is too long,we can split the string and pass into locators
		try {
			textSeperator = splitStringAndGenerateXpath(seperator);
			// System.out.println(textSeperator);
			labelText = splitStringAndGenerateXpath(fieldName);
			enableTextElement = driver.findElement(By.xpath("//div[@class='JFALSeparator']//div[" + textSeperator
					+ " ]/preceding::div[@class='JFALLabel']/div[" + labelText
					+ " ]/preceding::div[@class='JFALCompControlPanel'][1]//div[@class='JFALTextField JTextComponent']/input"));
			// System.out.println(enableTextElement);
			actualValue = getAttribute(enableTextElement, attributeName);
			checkIsNumericOrString(fieldName, inputValue, actualValue);
		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
	}

	public void verifyProtectedFieldFromLabelAndTextInPopup(String labelName, String expectedValue) {
		String labelInput = " ";
		WebElement protectedInputElement;
		String actualValue;
		// int inputNumber;
		// int textInput;
		try {
			labelInput = splitStringAndGenerateXpath(labelName);
			protectedInputElement = driver.findElement(By.xpath(
					"//div[@class='IFCSPopupDialog window modal v4init']//div[@class='JFALLabel'][descendant::div["
							+ labelInput
							+ " ]]/preceding::div[@class='JFALCompControlPanel'][1]/div[@class='JFALTextField JTextComponent']"));
			// System.out.println(protectedInputElement);
			actualValue = protectedInputElement.getText();
			System.out.println(actualValue);
			checkIsNumericOrString(labelName, expectedValue, actualValue);
		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
	}

	/*
	 * Prakalpha To Validate the Fields is Protected/Editable
	 */
	public int validateFieldType() {
		int countProtected = 0;
		try {
			List<WebElement> box = driver.findElements(By.xpath("//div[@class='JFALTextField JTextComponent']"));
			int boxSize = box.size();
			System.out.println("total text field" + boxSize);
			for (int i = 0; i < boxSize; i++) {
				String tagName = box.get(i)
						.findElement(By.xpath("//div[@class='htmlString'] | //input[@class='htmlInput']")).getTagName();
				System.out.println(tagName);
				if (tagName.equals("div")) {
					countProtected++;
					logPass("Field are Protected");
				} else if (tagName.equals("input")) {
					logPass("Field are editable");
				} else
					logFail("Invalid Tag");
			}
			System.out.println("count protected" + countProtected);
		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
		return countProtected;
	}

	public void validateTextFieldsAreProtectedInATab() {
		try {
			List<WebElement> box = driver.findElements(By.xpath(
					"//div[@class='JFALCompControlPanel'][descendant::div[@class='JFALTextField JTextComponent']]"));
			int boxSize = box.size();
			System.out.println("List1 Size" + boxSize);
			List<WebElement> box1 = driver.findElements(By.xpath(
					"//div[@class='JFALCompControlPanel']/div[@class='JFALTextField JTextComponent'][descendant::*[not(@class='htmlInput')]]"));
			int box1Size = box1.size();
			System.out.println("List2 Size" + box1Size);
			if (boxSize == box1Size) {
				logPass("All Fields are Protected");
			} else {
				logFail("All Fields are not Protected");
			}
			/*
			 * for (int i = 0; i < boxSize; i++) { try { System.out.println("inside try");
			 * WebElement checkType=driver.findElement(By.
			 * xpath("//div[@class='JFALCompControlPanel'][descendant::div[@class='JFALTextField JTextComponent']][i]//input"
			 * )); //Click(box.get(i),"Element is clickable");
			 * logInfo(i+" Field is Editable");
			 * 
			 * }catch (Exception ex) { System.out.println("inside catch");
			 * logInfo(i+" Field is protected");//logFail(ex.getMessage()); } }
			 */
		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
	}

	// Prakalpha : 02/01/19

	public void enterValueInTextBox(String seperatorLabelName, String labelName, String input) {
		String seperator = " ";
		String label = " ";
		WebElement textBox;
		try {
			seperator = splitStringAndGenerateXpath(seperatorLabelName);
			label = splitStringAndGenerateXpath(labelName);
			sleep(2);
					textBox = driver.findElement(By.xpath("//div[@class='JFALSeparator']//div[" + seperator + "]/preceding::div[@class='JFALLabel']/div["
					+ label + "]/preceding::div[@class='JFALCompControlPanel'][1]//input"));
			
			
             // updated rathna-  textbox clear is required for cases but here getting exeption,so entering data again in catch
			try {
				textBox.clear();
				sleep(2);
				textBox.sendKeys(input);
				logPass(input + " is entered in text field");
			} catch (Exception ex) {
				textBox.sendKeys(input);
				logInfo(input + " is entered in text field");
			}

		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
	}

	// Added by NK
	public void enterValueInTextBoxUsingAJSID(String ajsID, String input) {
		WebElement textBox;
		try {
			textBox = driver.findElement(By.xpath("//div[@ajs_id='" + ajsID + "']/input"));
			textBox.clear();
			isDisplayedThenEnterText(textBox, "TextBox", input);
			logPass(input + " is entered in text field");

		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
	}

	public void enterValueInTextArea(String seperatorLabelName, String labelName, String input) {
		// div[@class='JFALSeparator']//div[contains(text(),'Agreement')]/preceding::div[@class='JFALLabel']/div[contains(text(),'VAT')]/preceding::div[@class='JFALCompControlPanel'][1]//input

		String seperator = " ";
		String label = " ";
		WebElement textBox;
		try {
			seperator = splitStringAndGenerateXpath(seperatorLabelName);
			label = splitStringAndGenerateXpath(labelName);
			textBox = driver.findElement(By.xpath(
					"//div[@class='JFALSeparator']//div[" + seperator + "]/preceding::div[@class='JFALLabel']/div["
							+ label + "]/preceding::div[@class='JFALCompControlPanel'][1]//textarea"));
			textBox.clear();
			isDisplayedThenEnterText(textBox, "TextArea", input);

		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
	}

	public void enterDateInDropdown(String labelName, String input) {
		String labelLocator = " ";
		WebElement textBox;
		try {

			labelLocator = splitStringAndGenerateXpath(labelName);
			textBox = driver.findElement(By.xpath("//div[@class='JFALLabel']//div[" + labelLocator
					+ "]//preceding::div[@class='JFALCompControlPanel'][1]/div[@class='JFALDateComboBox']//div[@class='JFALDateLocaleTextField JTextComponent']//input"));
			textBox.clear();
			textBox.sendKeys(input);

		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
	}

	public String getValueFromProtectedTextBox(String seperatorLabelName, String labelName) {
		String seperator = " ";
		String label = " ";
		WebElement textBox;
		String text = " ";
		try {
			seperator = splitStringAndGenerateXpath(seperatorLabelName);
			label = splitStringAndGenerateXpath(labelName);

			// on few screens xpath ends with //input and getAttribute is working to get
			// vlaue(Else null)
			// on few screens xpath ends with//div[@class='htmlString'] in this case text is
			// working to get value
			try {

				textBox = driver.findElement(By.xpath(
						"//div[@class='JFALSeparator']//div[" + seperator + "]/preceding::div[@class='JFALLabel']/div["
								+ label + "]/preceding::div[@class='JFALCompControlPanel'][1]//input"));

				text = textBox.getAttribute("submittedvalue");

			} catch (Exception ex) {

				textBox = driver.findElement(By.xpath("//div[@class='JFALSeparator']//div[" + seperator
						+ "]/preceding::div[@class='JFALLabel']/div[" + label
						+ "]/preceding::div[@class='JFALCompControlPanel'][1]//div[@class='htmlString']"));

				text = getText(textBox);

			}
			sleep(5);
			logPass("Text value is " + text);
		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
		return text;
	}

	public void verifyValueInTextBox(String seperatorLabelName, String labelName, String expectedValue) {
		try {

			String actualValue = getValueFromTextBox(seperatorLabelName, labelName);
			System.out.println(actualValue);
			if (actualValue.equals(expectedValue)) {
				logPass(actualValue + " and " + expectedValue + "Matched");
			} else {
				logFail(actualValue + " and " + expectedValue + "Not Matched");
			}
		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
	}

	public void verifyValueInTextArea(String seperatorLabelName, String labelName, String expectedValue) {
		try {

			String actualValue = getValueFromTextArea(seperatorLabelName, labelName);
			System.out.println(actualValue);
			if (actualValue.equals(expectedValue)) {
				logPass(actualValue + " and " + expectedValue + "Matched");
			} else {
				logFail(actualValue + " and " + expectedValue + "Not Matched");
			}
		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
	}

	public String getValueFromTextArea(String seperatorLabelName, String labelName) {
		String seperator = " ";
		String label = " ";
		WebElement textBox;
		String text = " ";
		try {
			seperator = splitStringAndGenerateXpath(seperatorLabelName);
			label = splitStringAndGenerateXpath(labelName);
			textBox = driver.findElement(By.xpath(
					"//div[@class='JFALSeparator']//div[" + seperator + "]/preceding::div[@class='JFALLabel']/div["
							+ label + "]/preceding::div[@class='JFALCompControlPanel'][1]//textarea"));
			// sleep(5);
			text = textBox.getAttribute("submittedvalue");

			logPass("Text value is " + text);
		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
		return text;
	}

	public String verifyTextFromAttributeFields(String seperatorLabelName, String labelName, String expectedValue) {
		String seperator = " ";
		String label = " ";
		WebElement textField;
		String textValue = " ";
		try {
			seperator = splitStringAndGenerateXpath(seperatorLabelName);
			label = splitStringAndGenerateXpath(labelName);
			textField = driver.findElement(By.xpath(
					"//div[@class='JFALSeparator']//div[" + seperator + "]/preceding::div[@class='JFALLabel']/div["
							+ label + "]/preceding::div[@class='JFALCompControlPanel'][1]//input"));

			textValue = textField.getAttribute("submittedvalue");
			System.out.println(textValue);
			if (textValue.equals(expectedValue)) {
				logPass(textValue + " and " + expectedValue + "Matched");
			} else {
				logFail(textValue + " and " + expectedValue + "Not Matched");
			}

		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
		return textValue;
	}

	public String getValueFromTextBox(String seperatorLabelName, String labelName) {
		String seperator = " ";
		String label = " ";
		WebElement textBox;
		String text = " ";
		try {
			seperator = splitStringAndGenerateXpath(seperatorLabelName);
			label = splitStringAndGenerateXpath(labelName);

			if (seperatorLabelName.equals("From") || seperatorLabelName.equals("To")
					|| seperatorLabelName.equals("Permanent") || seperatorLabelName.equals("Temporary")) {
				textBox = driver.findElement(By.xpath("//div[@class='JFALSeparator']//div[" + seperator
						+ "]/preceding::div[@class='JFALLabel'][1]/div[" + label
						+ "]/preceding::div[@class='JFALCompControlPanel'][1]//input"));
			} else {

				textBox = driver.findElement(By.xpath(
						"//div[@class='JFALSeparator']//div[" + seperator + "]/preceding::div[@class='JFALLabel']/div["
								+ label + "]/preceding::div[@class='JFALCompControlPanel'][1]//input"));
				sleep(5);
			}
			// text = textBox.getText();
			textFieldVal = textBox.getAttribute("submittedvalue");
			logPass("Text value is " + textFieldVal);
		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
		return textFieldVal;
	}

	public void verifyTextInDropDownForProtected(String seperatorLabelName, String labelName, String expectedValue) {
		String seperator = " ";
		String textLabel = " ";
		WebElement dropDownBox;
		try {
			seperator = splitStringAndGenerateXpath(seperatorLabelName);
			textLabel = splitStringAndGenerateXpath(labelName);
			dropDownBox = driver.findElement(By.xpath("//div[@class='JFALSeparator']//div[" + seperator
					+ "]/preceding::div[@class='JFALLabel']/div[" + textLabel
					+ "]//preceding::div[@class='JFALCompControlPanel'][1]/div[@class='JFALComboBox']/div[@class='MetalComboBoxButton JButton']"));// MetalComboBoxButton
																																					// JButton//MetalComboBoxButton
																																					// enabled
																																					// JButton
			String actualValue = getText(dropDownBox);
			logInfo("Actual Value: " + actualValue);
			if (actualValue.equals(expectedValue)) {
				logPass(actualValue + " and " + expectedValue + "Matched");
			} else {
				logFail(actualValue + " and " + expectedValue + "Not Matched");
			}
		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
	}

	public void verifyTextInDropDownForEditable(String seperatorLabelName, String labelName, String expectedValue) {
		String seperator = " ";
		String textLabel = " ";
		WebElement dropDownBox;
		try {
			seperator = splitStringAndGenerateXpath(seperatorLabelName);
			textLabel = splitStringAndGenerateXpath(labelName);
			dropDownBox = driver.findElement(By.xpath("//div[@class='JFALSeparator']//div[" + seperator
					+ "]/preceding::div[@class='JFALLabel']/div[" + textLabel
					+ "]//preceding::div[@class='JFALCompControlPanel'][1]/div[@class='JFALComboBox']/div[@class='MetalComboBoxButton enabled JButton']"));
			String actualValue = getText(dropDownBox);
			logInfo("Actual Value: " + actualValue);
			// if (actualValue.equals(expectedValue)) {
			if (actualValue.contains("Card") || actualValue.equals(expectedValue)) {
				logPass(actualValue + " and " + expectedValue + "Matched");
			} else {
				logFail(actualValue + " and " + expectedValue + "Not Matched");
			}
		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
	}

	public String chooseOptionFromDropdownChe(String labelName, String option) {
		String label;
		boolean isOptionPresent = false;
		WebElement comboDropDown = null;
		List<WebElement> comboOptions = null;
		try {
			// seperator=split(seperatorLabelName);
			label = splitStringAndGenerateXpath(labelName);

			comboDropDown = driver.findElement(By.xpath("//div[@class='JFALLabel']//div[" + label
					+ "]//preceding::div[@class='JFALCompControlPanel'][1]/div[@class='JFALComboBox']//div[@class='MetalComboBoxButton enabled JButton']"));
			isDisplayedThenClick(comboDropDown, "Combo Dropdown");

			comboOptions = driver
					.findElements(By.xpath("//div[@class='BasicComboPopup_1']/div/div[@class='htmlString']"));

		} catch (Exception ex) {
			logFail(ex.getMessage());
		}

		if (comboOptions.size() != 0) {

			for (int i = 0; i < comboOptions.size(); i++) {
				option = option.replaceAll("\"", "");
				System.out.println("option : " + option);
				System.out.println("option : " + comboOptions.get(i));
				if (option.toLowerCase().equals(getText(comboOptions.get(i)).toLowerCase())) {
					isOptionPresent = true;
					isDisplayedThenActionClick(comboOptions.get(i), labelName + "->" + option);
					sleep(2);
					break;
				}
			}
			if (!isOptionPresent) {
				logFail("Given options was not present");
			}
		}

		return option;
	}

	/** Need to validate with all scenarios **/

	public String chooseOptionFromDropdown(String labelName, String option) {
		// String seperator=" ";
		String label = " ";

		// commented by rathna - added below TextField logic as separate method to improve performance
		boolean isOptionPresent = false;
		/*try {

			WebElement textEditor = driver.findElement(
					By.xpath("//div[@class='BasicComboBoxEditor_BorderlessTextField JTextComponent']/input"));
			isDisplayedThenActionClick(textEditor, "Dropdown is displayed");

			textEditor.clear();
			textEditor.sendKeys(option);
			sleep(5);
			isOptionPresent = true;
		} catch (Exception ex) {
			// logFail(ex.getMessage());
			isOptionPresent = false;
		}*/
		try {
			// seperator=split(seperatorLabelName);
			label = splitStringAndGenerateXpath(labelName);
			System.out.println("Lable name: " + label);
			if (!isOptionPresent) {
				WebElement comboDropDown = null;
				List<WebElement> comboOptions = null;
				comboDropDown = driver.findElement(By.xpath("//div[@class='JFALLabel']//div[" + label
						+ "]//preceding::div[@class='JFALCompControlPanel'][1]/div[@class='JFALComboBox']//div[@class='MetalComboBoxButton enabled JButton']"));
				//Parallel - Fix
				
				if(InitExecution.parallel_Mode.equalsIgnoreCase("yes")) {
					logInfo("Action Click to select dropdown");
					isDisplayedThenActionClick(comboDropDown, "Combo Dropdown"); 
					logInfo("ActionClick Done");
				}
				else {
								
				isDisplayedThenClick(comboDropDown, "Combo Dropdown");}
				
				
				comboOptions = driver
						.findElements(By.xpath("//div[@class='BasicComboPopup_1']/div/div[@class='htmlString']"));
				if (option.equalsIgnoreCase("random")) {
					System.out.println("Size of Drop Down" + comboOptions.size());
					if (comboOptions.size() == 1) {
						option = getText(comboOptions.get(0));
					} else if (comboOptions.size() == 0) {
						chooseBlankOptionFromDropdown(labelName);

					} else {
						System.out.println("comboOptions size:" + comboOptions.size());
						int randomNo = getRandomNumber(0, comboOptions.size() - 1);
						option = getText(comboOptions.get(randomNo));
					}
				}
				if (comboOptions.size() != 0) {
					for (int i = 0; i < comboOptions.size(); i++) {
						option = option.replaceAll("\"", "");
						if (option.toLowerCase().equals(getText(comboOptions.get(i)).toLowerCase())) {
							isOptionPresent = true;
							 isDisplayedThenActionClick(comboOptions.get(i), labelName + "->" + option);
							//JSClick(comboOptions.get(i), labelName + "->" + option);
							logInfo("Selected item : "+option);
							sleep(2);
							break;
						}
					}
					if (!isOptionPresent) {
						logFail("Given options was not present");
					}
				}
			}
		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
		return option;
	}
	
	
		
	public String chooseOptionContainsFromDropdown(String labelName, String option) {
		// String seperator=" ";
		String label = " ";

		// commented by rathna - added below TextField logic as separate method to improve performance
		boolean isOptionPresent = false;
		/*try {

			WebElement textEditor = driver.findElement(
					By.xpath("//div[@class='BasicComboBoxEditor_BorderlessTextField JTextComponent']/input"));
			isDisplayedThenActionClick(textEditor, "Dropdown is displayed");

			textEditor.clear();
			textEditor.sendKeys(option);
			sleep(5);
			isOptionPresent = true;
		} catch (Exception ex) {
			// logFail(ex.getMessage());
			isOptionPresent = false;
		}*/
		try {
			// seperator=split(seperatorLabelName);
			label = splitStringAndGenerateXpath(labelName);
			System.out.println("Lable name: " + label);
			if (!isOptionPresent) {
				WebElement comboDropDown = null;
				List<WebElement> comboOptions = null;
				comboDropDown = driver.findElement(By.xpath("//div[@class='JFALLabel']//div[" + label
						+ "]//preceding::div[@class='JFALCompControlPanel'][1]/div[@class='JFALComboBox']//div[@class='MetalComboBoxButton enabled JButton']"));
				isDisplayedThenClick(comboDropDown, "Combo Dropdown");
				comboOptions = driver
						.findElements(By.xpath("//div[@class='BasicComboPopup_1']/div/div[@class='htmlString']"));
				if (option.equalsIgnoreCase("random")) {
					System.out.println("Size of Drop Down" + comboOptions.size());
					if (comboOptions.size() == 1) {
						option = getText(comboOptions.get(0));
					} else if (comboOptions.size() == 0) {
						chooseBlankOptionFromDropdown(labelName);

					} else {
						System.out.println("comboOptions size:" + comboOptions.size());
						int randomNo = getRandomNumber(0, comboOptions.size() - 1);
						option = getText(comboOptions.get(randomNo));
					}
				}
				if (comboOptions.size() != 0)
				{
					for (int i = 0; i < comboOptions.size(); i++) {
						option = option.replaceAll("\"", "");
					//	if (option.toLowerCase().equals(getText(comboOptions.get(i)).toLowerCase())) 
						if (getText(comboOptions.get(i)).toLowerCase().contains(option.toLowerCase()))
						{
							isOptionPresent = true;
							 isDisplayedThenActionClick(comboOptions.get(i), labelName + "->" + option);
							//JSClick(comboOptions.get(i), labelName + "->" + option);
							logInfo("Selected item : "+option);
							sleep(2);
							break;
						}
					}
					if (!isOptionPresent) {
						logFail("Given option is not present");
					}
				}
				else
					logFail("Dropdown has no options - Its empty");
					
				
			}
		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
		return option;
	}


	/*
	 * Dropdown Selection with Option
	 */
	public void ajaxswingDropdownSelection(String separator, String dropdownOption) {
		if (dropdownOption.equalsIgnoreCase("random")) {
			ajaxswingDropdownRandomSelection(separator);
		} else {
			WebElement comboDropDown, element;
			separator = splitStringAndGenerateXpath(separator);
			try {
				comboDropDown = driver.findElement(By.xpath("//div[@class='JFALLabel']//div[" + separator
						+ "]//preceding::div[@class='JFALCompControlPanel'][1]/div[@class='JFALComboBox']//div[@class='MetalComboBoxButton enabled JButton']"));
				isDisplayedThenActionClick(comboDropDown, "Dropdown");
				element = driver.findElement(By.xpath("//div[@class='BasicComboPopup_1']/div/div[@class='htmlString']["
						+ splitStringAndGenerateXpath(dropdownOption) + "]"));
				executeJavaScript("arguments[0].scrollIntoView(true);arguments[0].click();", driver, element);
			} catch (Exception ex) {
				logFail("Error " + ex.getMessage());
			}
		}
	}

	/*
	 * Dropdown Selection Random Option
	 */
	public String ajaxswingDropdownRandomSelection(String separator) {
		JavascriptExecutor je = (JavascriptExecutor) driver;
		WebElement comboDropDown, element;
		List<WebElement> comboOptions;
		int randomNo = 0;
		String optionText="";
		separator = splitStringAndGenerateXpath(separator);
		try {
			comboDropDown = driver.findElement(By.xpath("//div[@class='JFALLabel']//div[" + separator
					+ "]//preceding::div[@class='JFALCompControlPanel'][1]/div[@class='JFALComboBox']//div[@class='MetalComboBoxButton enabled JButton']"));

			waitForElementTobeClickable(comboDropDown, 5);
			isDisplayedThenActionClick(comboDropDown, "Dropdown");
			comboOptions = driver
					.findElements(By.xpath("//div[@class='BasicComboPopup_1']/div/div[@class='htmlString']"));
			if (comboOptions.size() == 0) {
				WebElement option = driver.findElement(By.xpath(
						"//div[@class='BasicComboPopup_1']/div[@class='JFALComboBox_CustomComboboxRenderer'][descendant::div[last()][not(@class='htmlString')]]"))
						;
				option.click();
				optionText= getText(option);
			} else {
				if (comboOptions.size() > 1) {
					randomNo = getRandomNumber(0, comboOptions.size() - 1);
				}
				logInfo("Option Choosen:" + getText(comboOptions.get(randomNo)));
				element = comboOptions.get(randomNo);
				je.executeScript("arguments[0].scrollIntoView(true);", element);
				element.click();
				optionText= getText(comboOptions.get(randomNo));
			}
			
		} catch (Exception ex) {
			logFail("Error " + ex.getMessage());
		}
		return optionText;
	}

	public String chooseOptionFromDropdownUsingIndex(String labelName, int optionIndex) {
		// String seperator=" ";
		String label = " ";
		boolean isOptionPresent = false;
		WebElement comboDropDown = null;
		List<WebElement> comboOptions = null;
		try {
			// seperator=split(seperatorLabelName);
			label = splitStringAndGenerateXpath(labelName);

			comboDropDown = driver.findElement(By.xpath("//div[@class='JFALLabel']//div[" + label
					+ "]//preceding::div[@class='JFALCompControlPanel'][1]/div[@class='JFALComboBox']//div[@class='MetalComboBoxButton enabled JButton']"));
			isDisplayedThenClick(comboDropDown, "Combo Dropdown");
			comboOptions = driver
					.findElements(By.xpath("//div[@class='BasicComboPopup_1']/div/div[@class='htmlString']"));
			if (optionIndex <= comboOptions.size()) {
				for (int i = 0; i < comboOptions.size(); i++) {
					if (getText(comboOptions.get(optionIndex)).toLowerCase()
							.equals(getText(comboOptions.get(i)).toLowerCase())) {
						isOptionPresent = true;
						isDisplayedThenActionClick(comboOptions.get(i), labelName + "->" + optionIndex);
						sleep(5);
						break;
					}
				}
			} else {
				logFail("Dropdown size lesser than given index");
			}
			if (!isOptionPresent) {
				logFail("Given options was not present");
			}

		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
		return getText(comboOptions.get(optionIndex));
	}

	public void chooseBlankOptionFromDropdown(String labelName) {
		String label = " ";
		WebElement comboDropDown = null;
		WebElement comboBlankOption = null;
		try {
			label = splitStringAndGenerateXpath(labelName);
			comboDropDown = driver.findElement(By.xpath("//div[@class='JFALLabel']//div[" + label
					+ "]//preceding::div[@class='JFALCompControlPanel'][1]/div[@class='JFALComboBox']//div[@class='MetalComboBoxButton enabled JButton']"));
			isDisplayedThenClick(comboDropDown, "Combo Dropdown");

			comboBlankOption = driver.findElement(By.xpath(
					"//div[@class='BasicComboPopup_1']/div[@class='JFALComboBox_CustomComboboxRenderer'][descendant::div[last()][not(@class='htmlString')]]"));

			isDisplayedThenClick(comboBlankOption, "Blank Option");
		} catch (Exception ex) {

			logInfo("Blank Option for label:" + labelName + " not present");
		}
	}

	public void verifyValidationResult(String expectedResult) {
		WebElement validateElement=null;
		String validationMsg = splitStringAndGenerateXpath(expectedResult);
		try {
			sleep(5);
			
			waitToCheckElementIsDisplayed(By.xpath(
					"//div[@class='JPanel']//div[@class='ExtLabel']//div[@class='htmlString'][" + validationMsg + "]"),
					10);
			validateElement = driver.findElement(By.xpath(
					"//div[@class='JPanel']//div[@class='ExtLabel']//div[@class='htmlString'][" + validationMsg + "]"));
			if (getText(validateElement).contains(expectedResult)) {
				logPass("Expected results displayed " + expectedResult);
			} else {
				logFail("Expected results not displayed");
			}

		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
	}
	

	public void verifyPopupValidationResult(String expectedResult) {
		WebElement validateElement;
		try {
			String validationMsg = splitStringAndGenerateXpath(expectedResult);
			waitToCheckElementIsDisplayed(By.xpath(
					"//div[@class='ajaxswingv4 v4init'][2]//div[@class='JLayeredPane']//div[@class='JLabel']//div[@class='htmlString']["
							+ validationMsg + "]"),
					10);
			validateElement = driver.findElement(By.xpath(
					"//div[@class='ajaxswingv4 v4init'][2]//div[@class='JLayeredPane']//div[@class='JLabel']//div[@class='htmlString']["
							+ validationMsg + "]"));
			if (getText(validateElement).contains(expectedResult)) {
				logPass("Expected results displayed " + expectedResult);
			} else {
				logFail("Expected results not displayed");
			}

		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
	}

	public void validateFieldisPresent(String seperatorLabelName, String labelName) {
		String seperator = " ";
		String label = " ";
		WebElement field;
		try {
			seperator = splitStringAndGenerateXpath(seperatorLabelName);
			label = splitStringAndGenerateXpath(labelName);
			field = driver.findElement(By.xpath(
					"//div[@class='JFALSeparator']//div[" + seperator + "]//preceding::div[@class='JFALLabel']/div["
							+ label + "]//preceding::div[@class='JFALCompControlPanel'][1]"));
			isDisplayed(field, "Field is Present");

		} catch (Exception e) {
			logFail(e.getMessage());
		}

	}

	public void validateCheckBoxToCheckOrUncheck(String seperatorLabelName, String labelName, String expectedResult) {
		String seperator = " ";
		String label = " ";
		String valueForLabel = null;
		WebElement chechBoxElement=null;
		String checkBoxIsSelectedOrNot;
		try {
			seperator = splitStringAndGenerateXpath(seperatorLabelName);
			label = splitStringAndGenerateXpath(labelName);
			try {
				checkBoxIsSelectedOrNot = driver.findElement(By.xpath("//div[@class='JFALSeparator']//div[" + seperator
						+ "]/preceding::div[@class='JFALLabel']/div[" + label + "]"
						+ "/preceding::div[@class='JFALCompControlPanel'][1]//div[@class='JFALCheckBox enabled']/child::div//div"))
						.getCssValue("border-right-color");
			
			

			
			} catch (Exception e) {
				logInfo("No Value is present");
				checkBoxIsSelectedOrNot = "";
			}
			logInfo("Check Box CSS: " + checkBoxIsSelectedOrNot);
			if (checkBoxIsSelectedOrNot.equals("")) {
				valueForLabel = "Unchecked";
			} else {
				valueForLabel = "Checked";
			}
			if (valueForLabel.equals(expectedResult)) {
				logPass(expectedResult);
			} else {
				chechBoxElement = driver.findElement(By.xpath("//div[@class='JFALSeparator']//div[" + seperator
						+ "]/preceding::div[@class='JFALLabel']" + "/div[" + label
						+ "]/preceding::div[@class='JFALCompControlPanel'][1]//div[@class='JFALCheckBox enabled']"));
				
				chechBoxElement.click();
				
			}
		} catch (Exception ex) {
			isDisplayedThenActionClick(chechBoxElement,"");
			//logFail(ex.getMessage());
		}

	}
	
	// Prakalpha

	public void validateCheckBoxToCheckOrUncheckInTableRow(String seperatorLabelName, String tableHeaderName,
			int rowNum, String expectedResult) {
		String seperator = " ";
		String valueForLabel = null;
		WebElement chechBoxElement;
		String checkBoxIsSelectedOrNot;
		int index = 1;
		if (seperatorLabelName.equals("Card Bulk Status")) {
			index = 3;
		}
		try {
			seperator = splitStringAndGenerateXpath(seperatorLabelName);
			List<WebElement> tableHeaders = driver.findElements(By.xpath("//div[@class='JFALSeparator']//div["
					+ seperator
					+ "]/preceding::div[@class='JFALCompControlPanel']//div[@class='JViewport']/div[@class='JTableHeader']//div[@class='HeaderRenderer']"));
			int colIndex = SeleniumWrappers.getColumnNoForColumnHeader(tableHeaderName, tableHeaders);
			System.out.println("ColIndex--->" + colIndex);

			List<WebElement> list = driver.findElements(By.xpath("//div[@class='JFALSeparator']//div[" + seperator
					+ "]/preceding::div[@class='JFALCompControlPanel'][" + index
					+ "]//div[@class='FALTableCellEditor_StrikeThruField JTextComponent']"));
			SeleniumWrappers.setCellValue(list);
			int size = SeleniumWrappers.getTotalNumberOfRows(list, driver);
			System.out.println("Size of table" + size);
			try {

				System.out.println("Inside Try block");
				checkBoxIsSelectedOrNot = driver.findElement(By.xpath("//div[@class='JFALSeparator']//div[" + seperator
						+ "]/preceding::div[@class='JFALCompControlPanel'][" + index
						+ "]//div[@class='FALTableCellEditor_StrikeThruCheckBox enabled'][contains(@id,'" + rowNum + "_"
						+ colIndex + "')]/child::div//div")).getCssValue("border-right-color");
			} catch (Exception e) {
				logInfo("No Value is present");
				checkBoxIsSelectedOrNot = "";
			}
			logInfo("Check Box CSS: " + checkBoxIsSelectedOrNot);
			if (checkBoxIsSelectedOrNot == "") {
				valueForLabel = "Unchecked";
			} else {
				valueForLabel = "Checked";
			}
			if (valueForLabel.equals(expectedResult)) {
				logPass(expectedResult);
			} else {
				System.out.println("Else part");
				chechBoxElement = driver.findElement(By.xpath("//div[@class='JFALSeparator']//div[" + seperator
						+ "]/preceding::div[@class='JFALCompControlPanel'][" + index
						+ "]//div[@class='FALTableCellEditor_StrikeThruCheckBox enabled'][contains(@id,'" + rowNum + "_"
						+ colIndex + "')]/child::div[3]"));
				chechBoxElement.click();
				logPass("CheckBox Clicked");
			}
		} catch (Exception ex) {
			logFail(ex.getMessage());
		}

	}

	// Prakalpha
	public void validatePopupHeaderText(String PopupHeaderName) {
		String popUpHeaderText = splitStringAndGenerateXpath(PopupHeaderName);
		WebElement element = driver.findElement(
				By.xpath("//div[@class='ReadOnlyHeaderPanel']//div[@class='JPanel']//div[@class='ExtLabel']/div["
						+ popUpHeaderText + "]"));
		verifyText(element, PopupHeaderName);
	}

	public void validateHeaderLabel(String headerName) {
		String headerText = splitStringAndGenerateXpath(headerName);
		WebElement element = driver.findElement(By.xpath("//div[@class='JLabel']/div[" + headerText + "]"));
		verifyText(element, headerName);
	}

	public void validateLabelText(String labelName) {
		String labelText = splitStringAndGenerateXpath(labelName);
		WebElement element = driver.findElement(By.xpath("//div[@class='JFALLabel']/div[" + labelText + "]"));
		verifyText(element, labelName);
	}

	public void checkFieldisPresent(String seperatorLabelName, String labelName) {
		String seperator = " ";
		String label = " ";
		WebElement field;
		try {
			seperator = splitStringAndGenerateXpath(seperatorLabelName);
			label = splitStringAndGenerateXpath(labelName);
			field = driver.findElement(By.xpath(
					"//div[@class='JFALSeparator']//div[" + seperator + "]//preceding::div[@class='JFALLabel']/div["
							+ label + "]//preceding::div[@class='JFALCompControlPanel'][1]"));
			isDisplayed(field, "Field is Present");

		} catch (Exception e) {
			logFail(e.getMessage());
		}

	}

	// prakalpha-->In Popup,Dropdown in table(cell)
	public void dropdownInPopupTable(String locator, String headerName, String option) {
		int size;
		int colHeaderIndex;
		WebElement webLocator;
		List<WebElement> tabledropdownList;
		try {
			List<WebElement> comboOptions = null;
			webLocator = driver.findElement(By.xpath(locator));
			System.out.println("WebLocator" + webLocator);
			System.out.println("Dropdown For Table");
			tabledropdownList = webLocator
					.findElements(By.xpath(".//div[@class='FALTableCellEditor_StrikeThruField JTextComponent']"));
			SeleniumWrappers.setCellValueforPopup(tabledropdownList, locator, driver);
			size = SeleniumWrappers.getTotalNumberOfRows(tabledropdownList, driver);
			colHeaderIndex = SeleniumWrappers.getColumnNoForColumnHeader(headerName,
					webLocator.findElements(By.xpath(".//div[@class='HeaderRenderer']")));
			System.out.println("Column header" + colHeaderIndex);
			for (int row = 0; row < size; row++) {
				tabledropdownList = webLocator
						.findElements(By.xpath(".//div[@class='FALTableCellEditor_StrikeThruField JTextComponent']"));// div[@class='FALTableCellEditor_StrikeThruField
																														// JTextComponent']/input"));////div[@class='FALTableCellEditor_StrikeThruField
																														// JTextComponent']/input"));////div[@class='IFCSPopupDialog
																														// window
																														// modal
																														// v4init']//div[@class='JFALCompControlPanel']//div[@class='FALTableCellEditor_StrikeThruField
																														// JTextComponent']/input
				System.out.println("+++++++ execution came here +++++++++++++");
				SeleniumWrappers.setCellValueforPopup(tabledropdownList, locator, driver);
				//WebElement cellElement = SeleniumWrappers.getTableDataWithCellElement(row, 1, driver);

				WebElement cellElement=driver.findElement(By.xpath(locator+"//input[contains(@id,'_" + row + "_" + colHeaderIndex + "')]"));
				System.out.println("+++++++ +"+ cellElement +"+++++++++++++");
				sleep(5);
				//SeleniumWrappers.getTableDataWithRowAndColumnNumber(colHeaderIndex, row, driver);
				cellElement.click();
				//doubleClick(cellElement);
				System.out.println("+++++++ +After click+++++++++++++");
				sleep(5);

				comboOptions = driver
				.findElements(By.xpath("//div[@class='BasicComboPopup_1']/div/div[@class='htmlString']"));

				System.out.println("Option size" + comboOptions.size());
				if (option.equalsIgnoreCase("random")) {
				if (comboOptions.size() == 1) {
				option = getText(comboOptions.get(0));
				} else {
				System.out.println("comboOptions size:" + comboOptions.size());
				int randomNo = getRandomNumber(0, comboOptions.size() - 1);
				option = getText(comboOptions.get(randomNo));
				}
				}
				for (int i = 0; i < comboOptions.size(); i++) {
				if (option.toLowerCase().equals(getText(comboOptions.get(i)).toLowerCase())) {

				isDisplayedThenActionClick(comboOptions.get(i), "->" + option);
				sleep(5);
				break;
				}
				}

				}

				} catch (Exception ex) {
				logFail(ex.getMessage());
				}
				}		public void validateTableHeaderValues(String seperatorLabelName, String nameOfTheTableHeader) {
		List<String> expectedTableHeaderList = Arrays.asList(nameOfTheTableHeader.split(","));
		List<String> actualTableHeaderList = new ArrayList<String>();
		String seperator = " ";
		try {
			seperator = splitStringAndGenerateXpath(seperatorLabelName);
			System.out.println("expectedtabname--->" + expectedTableHeaderList);
			List<WebElement> actualListofTableHeader = driver
					.findElements(By.xpath("//div[@class='JFALSeparator']//div[" + seperator
							+ "]//preceding::div[@class='JFALCompControlPanel'][1]//div[@class='JTableHeader']//div[@class='HeaderRenderer']"));
			for (int i = 0; i < actualListofTableHeader.size(); i++) {
				String labelName = actualListofTableHeader.get(i).getText();
				actualTableHeaderList.add(labelName);
			}
			System.out.println("ActualTabname--->" + actualTableHeaderList);
			if (actualTableHeaderList.equals(expectedTableHeaderList)) {
				logPass("Size and Order of the Tab is Matched");
			} else {
				logFail("Size and Order of the Tab is not Matched");
			}
		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
	}

	public void validateDropdownProtectedTextInPopup(String labelName, String expectedValue) {
		String labelInput = " ";
		WebElement protectedInputElement;
		String actualValue;

		try {
			labelInput = splitStringAndGenerateXpath(labelName);
			protectedInputElement = driver.findElement(By.xpath(
					"//div[@class='IFCSPopupDialog window modal v4init']//div[@class='JFALLabel']//div[" + labelInput
							+ "]/preceding::div[@class='JFALCompControlPanel'][1]//div[@class='htmlString']"));
			actualValue = protectedInputElement.getText();
			System.out.println(actualValue);
			if (actualValue.equals(expectedValue)) {
				logPass(actualValue + " and " + expectedValue + "Matched");
			} else {
				logFail(actualValue + " and " + expectedValue + "Not Matched");
			}
		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
	}

	// Raxsana
	public void validateTextFieldIsEditable(String labelName) {
		try {
			String label = splitStringAndGenerateXpath(labelName);
			System.out.println(label);
			driver.navigate().refresh();
			List<WebElement> element = driver
					.findElements(By.xpath("//div[@class='JFALSeparator']/preceding::div[@class='JFALLabel']/div["
							+ label + "]/preceding::div[@class='JFALCompControlPanel'][1]"));
			int size = element.size();
			// System.out.println(size);
			for (int i = 0; i < size; i++) {
				try {
					WebElement elementEditable = element.get(i)
							.findElement(By.xpath("//div[@class='JFALTextField JTextComponent']//input"));
					String elementClassName = elementEditable.getAttribute("class");
					// System.out.println(elementClassName);
					if (elementClassName.equals("htmlInput")) {
						logPass(labelName + " field is editable");
					}
				} catch (Exception e) {
					logInfo(labelName + " field is not editable");
				}
			}
		} catch (Exception e) {
			logFail(e.getMessage());
		}
	}

	public void validateFieldIsProtected(String seperatorLabelName, String labelName) {
		String seperator = " ";
		String label = " ";
		WebElement comboBox;

		try {
			seperator = splitStringAndGenerateXpath(seperatorLabelName);
			label = splitStringAndGenerateXpath(labelName);

			comboBox = driver.findElement(By.xpath(
					"//div[@class='JFALSeparator']//div[" + seperator + "]/preceding::div[@class='JFALLabel']/div["
							+ label + "]/preceding::div[@class='JFALCompControlPanel'][1]//div[@class='htmlString']"));
			sleep(5);
			String color = comboBox.getCssValue("color");
			System.out.println(color);
			String hexColor = convertrgbColorToHex(color);
			System.out.println(hexColor);
			if (hexColor.equals("#b8cfe5")) {
				logPass("Field is Protected");
			} else
				logFail("Field is not Protected");
		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
	}

	public String convertrgbColorToHex(String color) {
		// String color = driver.findElement(By.xpath("//div[@class='gb_e gb_f gb_g
		// gb_xb']/a")).getCssValue("color");
		String[] numbers = color.replace("rgba(", "").replace(")", "").split(",");
		int r = Integer.parseInt(numbers[0].trim());
		int g = Integer.parseInt(numbers[1].trim());
		int b = Integer.parseInt(numbers[2].trim());
		// int a = Integer.parseInt(numbers[3].trim());
		System.out.println("r: " + r + "g: " + g + "b: " + b);
		String hex = "#" + Integer.toHexString(r) + Integer.toHexString(g) + Integer.toHexString(b);
		System.out.println(hex);
		return hex;
	}

	/**
	 * GET Short client Name For Chevron and BP already shortName so need. Anton
	 */

	public String getShortClientName(String clientName) {
		String shortClientName = null;

		if (clientName.equals("SHELL")) {
			shortClientName = "SH";
		}

		else if (clientName.equals("EMAP")) {
			shortClientName = "EX";
		}

		else if (clientName.equals("BP")) {
			shortClientName = "BP";
		} else if (clientName.equals("OTI")) {
			shortClientName = "OT";
		}

		else if (clientName.equals("CHEVRON")) {
			shortClientName = "CHV";
		}

		else if (clientName.equals("ZEnergy")) {
			shortClientName = "ZE";
		} else if (clientName.equals("WFE")) {
			shortClientName = "eurogarage";
		}

		return shortClientName;
	}

	/*
	 * Get Client Country Short Name
	 * 
	 * @Meenakshi Sundaram
	 */

	public String getShortCountryName(String countryName) {
		String shortClientName = null;

		if (countryName.equals("Czech")) {
			shortClientName = "CZ";
		}

		else if (countryName.equals("Russia")) {
			shortClientName = "RU";
		} else if (countryName.equals("Austria")) {
			shortClientName = "AT";
		}

		else if (countryName.equals("Belgium")) {
			shortClientName = "BE";
		}

		else if (countryName.equals("Bulgaria")) {
			shortClientName = "BG";
		}

		else if (countryName.equals("Germany")) {
			shortClientName = "DE";
		} else if (countryName.equals("Hungary")) {
			shortClientName = "HU";
		}

		else if (countryName.equals("Malaysia")) {
			shortClientName = "MY";
		}

		else if (countryName.equals("Netherlands")) {
			shortClientName = "NL";
		} else if (countryName.equals("Philippines")) {
			shortClientName = "PH";
		} else if (countryName.equals("Poland")) {
			shortClientName = "PL";
		}

		else if (countryName.equals("Singapore")) {
			shortClientName = "SG";
		}

		else if (countryName.equals("Slovakia")) {
			shortClientName = "SL";
		} else if (countryName.equals("Macau")) {
			shortClientName = "MO";
		}

		else if (countryName.equals("Hong Kong")) {
			shortClientName = "HK";
		}

		else if (countryName.equals("Saipan")) {
			shortClientName = "SP";
		}

		else if (countryName.equals("Guam")) {
			shortClientName = "GU";
		}

		return shortClientName;
	}

	/**
	 * 
	 * get Client Full Name Anton authored
	 * 
	 */

	/*
	 * public String getClientFullName(String clientName, String clientCountry) {
	 * String client = null, clientFullName =null, clientCountryFull=null;
	 * 
	 * if(clientName.equals("SH") || clientName.equals("SHELL")) { clientFullName =
	 * "SHELL";
	 * 
	 * if(clientCountry.equals("CZ")) { clientCountryFull="Czech Republic"; }
	 * 
	 * else if(clientCountry.equals("AT")) { clientCountryFull="Austria"; }
	 * 
	 * else if(clientCountry.equals("BE")) { clientCountryFull="Belgium"; }
	 * 
	 * else if(clientCountry.equals("BG")) { clientCountryFull="Bulgaria"; }
	 * 
	 * else if(clientCountry.equals("DE")) { clientCountryFull="Germany"; }
	 * 
	 * 
	 * else if(clientCountry.equals("HU")) { clientCountryFull="Hungary"; }
	 * 
	 * else if(clientCountry.equals("MY")) { clientCountryFull="Malaysia"; }
	 * 
	 * else if(clientCountry.equals("NL")) { clientCountryFull="Netherlands"; } else
	 * if(clientCountry.equals("PH")) { clientCountryFull="Philippines"; } else
	 * if(clientCountry.equals("PL")) { clientCountryFull="Poland"; }
	 * 
	 * else if(clientCountry.equals("RU")) { clientCountryFull="Russia"; }
	 * 
	 * else if(clientCountry.equals("SG")) { clientCountryFull="Singapore"; }
	 * 
	 * else if(clientCountry.equals("SL")) { clientCountryFull="Slovakia"; } else {
	 * clientCountryFull = null; } }
	 * 
	 * else { clientFullName = null; }
	 * 
	 * if(clientFullName != null && clientCountryFull !=null) { client =
	 * clientFullName +" "+clientCountryFull;
	 * 
	 * if(client.equals("SHELL Russia")) { client = "ООО Шелл Нефть"; } } else {
	 * logFail("Client Name and Client Country is not passed correctly, Please check. Method Name ::: getClientFullName"
	 * ); }
	 * 
	 * return client; }
	 */

	// Prakalpha-->tried for Emap future Use
	public String getClientFullName(String clientName, String clientCountry) {
		String client = null, clientFullName = null, clientCountryFull = null;

		if (clientName.equals("SH") || clientName.equals("SHELL")) {
			clientFullName = "SHELL";

			if (clientCountry.equals("CZ")) {
				clientCountryFull = "Czech Republic";
			}

			else if (clientCountry.equals("AT")) {
				clientCountryFull = "Austria";
			}

			else if (clientCountry.equals("BE")) {
				clientCountryFull = "Belgium";
			}

			else if (clientCountry.equals("BG")) {
				clientCountryFull = "Bulgaria";
			}

			else if (clientCountry.equals("DE")) {
				clientCountryFull = "Germany";
			}

			else if (clientCountry.equals("HU")) {
				clientCountryFull = "Hungary";
			}

			else if (clientCountry.equals("MY")) {
				clientCountryFull = "Malaysia";
			}

			else if (clientCountry.equals("NL")) {
				clientCountryFull = "Netherlands";
			} else if (clientCountry.equals("PH")) {
				clientCountryFull = "Philippines";
			} else if (clientCountry.equals("PL")) {
				clientCountryFull = "Poland";
			}

			else if (clientCountry.equals("RU")) {
				clientCountryFull = "Russia";
			}

			else if (clientCountry.equals("SG")) {
				clientCountryFull = "Singapore";
			}

			else if (clientCountry.equals("SL")) {
				clientCountryFull = "Slovakia";
			} else {
				clientCountryFull = null;
			}
		} else if (clientName.equals("EX") || clientName.equals("EMAP")) {

			clientFullName = "EMAP";

			if (clientCountry.equals("MO")) {
				clientCountryFull = "Macau";
			} else if (clientCountry.equals("HK")) {
				clientCountryFull = "Hong kong";
			} else if (clientCountry.equals("GU")) {
				clientCountryFull = "Guam";
			} else if (clientCountry.equals("SP")) {
				clientCountryFull = "Saipan";
			} else if (clientCountry.equals("SG")) {
				clientCountryFull = "Singapore";
			} else {
				clientFullName = null;
			}
		}

		if (clientFullName != null && clientCountryFull != null) {
			/*
			 * if(clientName.equals("EX") || clientName.equals("EMAP")) { client =
			 * clientFullName+clientCountryFull; } else {
			 */
			client = clientFullName + " " + clientCountryFull;

			/*
			 * if(client.equals("SHELL Russia")) { client = "ООО Шелл Нефть"; }
			 */
			// }
		} else {
			logFail("Client Name and Client Country is not passed correctly, Please check. Method Name ::: getClientFullName");
		}

		return client;
	}

	/**
	 * Added by Anton
	 * 
	 */
	public void waitForVisibilityOfElements(By locatorVal) {
		// driver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS);
		WebDriverWait wait = new WebDriverWait(driver, TIMEOUT);
		wait.until(ExpectedConditions.visibilityOfElementLocated(locatorVal));
		// driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}

	public String splitStringbasedOnOccuranceOfDelimiter(String actualString, String delimiter, String occurance) {
		int index = 0;

		System.out.println("actualString ------ " + actualString);

		if (occurance.equalsIgnoreCase("first")) {
			index = actualString.indexOf(delimiter);
		}

		else if (occurance.equalsIgnoreCase("last")) {
			index = actualString.lastIndexOf(delimiter);
		}

		String yourCuttedString = actualString.substring(0, index);

		System.out.println("yourCuttedString ---- " + yourCuttedString);

		return yourCuttedString;
	}

	public static String getCurrentDateAndTime(String format) {

		DateTimeFormatter dtf = DateTimeFormatter.ofPattern(format);
		LocalDateTime now = LocalDateTime.now();
		String currentDateandTime = dtf.format(now);
		return currentDateandTime;

	}

	/**
	 * Added by Meenakshi Sundaram
	 * 
	 */
	public void verifySearchResultCustomerNumber(String expectedResult) {
		WebElement validateElement;
		try {
			waitToCheckElementIsDisplayed(By
					.xpath("//div[@class='JPanel']//div[@class='ExtLabel']//div[@class='htmlString'][contains(text(),'"
							+ expectedResult + "')]"),
					10);
			validateElement = driver.findElement(By
					.xpath("//div[@class='JPanel']//div[@class='ExtLabel']//div[@class='htmlString'][contains(text(),'"
							+ expectedResult + "')]"));
			if (getText(validateElement).contains(expectedResult)) {
				logPass("Expected results displayed");
			} else {
				logFail("Expected results not displayed");
			}

		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
	}
	// Prakalpha -04/15/2019

	public void verifyFieldIsMandatory(String seperatorLabelName, String labelName) {
		String seperator = " ";
		String label = " ";
		WebElement box;

		try {
			seperator = splitStringAndGenerateXpath(seperatorLabelName);
			label = splitStringAndGenerateXpath(labelName);

			box = driver.findElement(By.xpath(
					"//div[@class='JFALSeparator']//div[" + seperator + "]/preceding::div[@class='JFALLabel']/div["
							+ label + "]/preceding::div[@class='JFALCompControlPanel'][1]//div[@class='htmlImage']"));// div[@class='htmlImage'][contains(@style,'F_mandatory.gif')]"));
			sleep(5);
			String image = box.getCssValue("background-image");
			System.out.println(image);

			if (image.contains("F_mandatory.gif")) {
				logPass("Field is Mandatory");
			} else
				logFail("Field is not Mandatory for " + labelName);
		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
	}

	// Prakalpha-04/16/2019
	public void textFieldisPresentForLabel(String seperatorLabelName, String labelName) {
		String seperator = " ";
		String label = " ";
		WebElement field;
		try {
			seperator = splitStringAndGenerateXpath(seperatorLabelName);
			label = splitStringAndGenerateXpath(labelName);
			field = driver.findElement(By.xpath(
					"//div[@class='JFALSeparator']//div[" + seperator + "]//preceding::div[@class='JFALLabel']/div["
							+ label + "]//preceding::div[@class='JFALCompControlPanel'][1]//input"));
			isDisplayed(field, "Input Field is Present for " + labelName);

		} catch (Exception e) {
			logFail(e.getMessage());
		}
	}

	public void textAreaFieldisPresentForLabel(String seperatorLabelName, String labelName) {
		String seperator = " ";
		String label = " ";
		WebElement field;
		try {
			seperator = splitStringAndGenerateXpath(seperatorLabelName);
			label = splitStringAndGenerateXpath(labelName);
			field = driver.findElement(By.xpath(
					"//div[@class='JFALSeparator']//div[" + seperator + "]//preceding::div[@class='JFALLabel']/div["
							+ label + "]//preceding::div[@class='JFALCompControlPanel'][1]//textarea"));
			isDisplayed(field, "TextArea Field is Present for " + labelName);

		} catch (Exception e) {
			logFail(e.getMessage());
		}

	}

	public void dropdownFieldisPresentForLabel(String seperatorLabelName, String labelName) {
		String seperator = " ";
		String label = " ";
		WebElement field;
		try {
			seperator = splitStringAndGenerateXpath(seperatorLabelName);
			label = splitStringAndGenerateXpath(labelName);
			field = driver.findElement(By.xpath("//div[@class='JFALSeparator']//div[" + seperator
					+ "]//preceding::div[@class='JFALLabel']/div[" + label
					+ "]//preceding::div[@class='JFALCompControlPanel'][1]//div[@class='JFALComboBox']"));
			isDisplayed(field, "Dropdown Field is Present for " + labelName);

		} catch (Exception e) {
			logFail(e.getMessage());
		}

	}

	public void dateFieldisPresentForLabel(String seperatorLabelName, String labelName) {
		String seperator = " ";
		String label = " ";
		WebElement field;
		try {
			seperator = splitStringAndGenerateXpath(seperatorLabelName);
			label = splitStringAndGenerateXpath(labelName);
			field = driver.findElement(By.xpath("//div[@class='JFALSeparator']//div[" + seperator
					+ "]//preceding::div[@class='JFALLabel']/div[" + label
					+ "]//preceding::div[@class='JFALCompControlPanel'][1]//div[@class='JFALDateComboBox']"));
			isDisplayed(field, "Date Field is Present for " + labelName);

		} catch (Exception e) {
			logFail(e.getMessage());
		}

	}

	public void checkBoxFieldisPresentForLabel(String seperatorLabelName, String labelName) {
		String seperator = " ";
		String label = " ";
		WebElement field;
		try {
			seperator = splitStringAndGenerateXpath(seperatorLabelName);
			label = splitStringAndGenerateXpath(labelName);
			field = driver.findElement(By.xpath("//div[@class='JFALSeparator']//div[" + seperator
					+ "]//preceding::div[@class='JFALLabel']/div[" + label
					+ "]//preceding::div[@class='JFALCompControlPanel'][1]//div[@class='JFALCheckBox enabled']"));
			isDisplayed(field, "Date Field is Present for" + labelName);

		} catch (Exception e) {
			logFail(e.getMessage());
		}

	}

	// Reading the file line
	public static int getFileLines(String fileToBeRead) throws IOException {
		BufferedReader in = new BufferedReader(new FileReader(fileToBeRead));
		LineNumberReader lineNumberReader = new LineNumberReader(in);
		int lineNumber = 0;
		while ((lineNumberReader.readLine()) != null) {
			lineNumber++;
		}
		in.close();
		return lineNumber;
	}

	public void isDisplayedThenVerifyText(List<WebElement> locators, String expectedMsg, String message) {
		try {
			for (WebElement locator : locators) {
				waitUntilElementDisplayed(locator);
				System.out.println("element present ----- ");
				isDisplayed(locator, message);
				System.out.println("actualMsg : " + locator.getText().trim());
				System.out.println("expectedMsg : " + expectedMsg);
				if (locator.getText().trim().contains(expectedMsg)) {
					logPass("expectedMsg founded");
				} else
					logFail("expectedMsg not founded");
			}
		} catch (Exception ex) {
			logFail(ex.getMessage());
		}

	}

	public String returnValidationResult(String expectedResult) {
		WebElement validateElement;
		String ValidationMsg = null;
		try {
			String validationMsg = splitStringAndGenerateXpath(expectedResult);
			waitToCheckElementIsDisplayed(By.xpath(
					"//div[@class='JPanel']//div[@class='ExtLabel']//div[@class='htmlString'][" + validationMsg + "]"),
					10);
			validateElement = driver.findElement(By.xpath(
					"//div[@class='JPanel']//div[@class='ExtLabel']//div[@class='htmlString'][" + validationMsg + "]"));
			ValidationMsg = getText(validateElement);

		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
		return ValidationMsg;
	}

	public String encryptText(String message, String key) {

		return StringEncryptUtils.encryptXOR(message, key);

	}

	public String decryptText(String message, String key) {
		return StringEncryptUtils.decryptXOR(message, key);
	}

	// Added by NK
	// changing the format of processig date in IFCS
	public String dateFormatChange(String processDateFromDB, String neededDateFormat) throws ParseException {
		String processingDate = processDateFromDB;
		SimpleDateFormat currentDateFormat = new SimpleDateFormat("yyyy-MM-dd");
		Date date = currentDateFormat.parse(processingDate);

		SimpleDateFormat newDateFormat = new SimpleDateFormat(neededDateFormat);
		String result = newDateFormat.format(date);
		return result;
	}
	
	/**
	 * 
	 * @param message
	 * @return
	 * added by rathna
	 */
	public void compareTwoValues(String expValue,String actValue) {
		if(expValue.equals(actValue))
		   logPass("Both values are equal - "+expValue+":"+actValue);
		else
			logFail("Both values are different - "+expValue+":"+actValue);
	}

}
