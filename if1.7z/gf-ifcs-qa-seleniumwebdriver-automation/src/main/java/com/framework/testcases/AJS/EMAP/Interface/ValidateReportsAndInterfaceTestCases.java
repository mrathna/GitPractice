package com.framework.testcases.AJS.EMAP.Interface;

import java.util.ArrayList;
import java.util.Map;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.common.Common;
import com.framework.pages.AJS.common.CommonInterfacePage;
import com.framework.pages.AJS.common.IFCSCommonPage;
import com.framework.pages.AJS.common.IFCSLoginPage;

public class ValidateReportsAndInterfaceTestCases  extends BaseTest {

	
	
	
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "Smoke" },enabled=false)
	public void ValidateClientLevelReportsAssignmentsWithDailyFrequency(@Optional("SG") String clientCountry,
			@Optional("EMAP") String clientName) {
		
		test = extent.createTest(clientName+ ":" +clientCountry+"  TST-SC-15-Client level report assignments with daily frequency","validating client Level Daily Frequency Reports");
		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		CommonInterfacePage commonInterfacePage = new CommonInterfacePage(driver, test);
		Common common = new Common(driver,test);
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry," ");
		
		//Account Audit Report
		String auditActionAccount = common.getAuditActionForCustomer("7800344182093000112", "uatxom");
		System.out.println("audit action::" + auditActionAccount);
		common.convertCsvToXLS("");
		ArrayList<String> accountColumnValues = new ArrayList<String>();
		accountColumnValues.add("");
		accountColumnValues.add("uatxom");
		accountColumnValues.add(auditActionAccount);
		String[] AccountColumnHeaders = { "Account Number", "Username", "Action" };
		commonInterfacePage.validateValuesIsPresentInExcel(".xls","sheet1",
				AccountColumnHeaders, accountColumnValues,1);
				
				
		//applications Audit Reports
		String auditActionappl=common.getAuditActionForApplication("1000444649","uatxom");
		System.out.println("audit action::" + auditActionappl);
		common.convertCsvToXLS("32-Applications Audit Report 01.10.2019");
		ArrayList<String> appColumnValues = new ArrayList<String>();
		appColumnValues.add("1000444649");
		appColumnValues.add("uatxom");
		appColumnValues.add(auditActionappl);
		String[] appColumnHeaders = { "Application Number", "Username", "Action" };
		commonInterfacePage.validateValuesIsPresentInExcel("32-Applications Audit Report 01.10.2019.xls","sheet1",
				appColumnHeaders, appColumnValues,1);
		
		//Card Maintenance Audit Report
		String auditActionCard = common.getAuditActionForCustomer("7800344182093000112", "uatxom");
		System.out.println("audit action::" + auditActionCard);
		common.convertCsvToXLS("32-Card Maintenance Audit Report 01.10.2019");
		ArrayList<String> cardColumnValues = new ArrayList<String>();
		cardColumnValues.add("7800344182093000112");
		cardColumnValues.add("uatxom");
		cardColumnValues.add(auditActionCard);
		String[] cardColumnHeaders = { "Card Number", "Username", "Action" };
		commonInterfacePage.validateValuesIsPresentInExcel("32-Card Maintenance Audit Report 01.10.2019.xls","sheet1",
				cardColumnHeaders, cardColumnValues,1);
		
				
		
		//Customer Audit Reports
		String auditActionCus = common.getAuditActionForCustomer("0700000", "uatxom");
		System.out.println("audit action::" + auditActionCus);
		common.convertCsvToXLS("32-Customers Audit Report 01.10.2019");
		ArrayList<String> CusColumnValues = new ArrayList<String>();
		CusColumnValues.add("0700000");
		CusColumnValues.add("uatxom");
		CusColumnValues.add(auditActionCus);
		String[] cusColumnHeaders = { "Customer Number", "Username", "Action" };
		commonInterfacePage.validateValuesIsPresentInExcel("32-Customers Audit Report 01.10.2019.xls","sheet1",
				cusColumnHeaders, CusColumnValues,1);
		
		//Client Excessive Transaction Reports.xls
		String refNumber="183";
		String transactionValue=common.getClientTransactionValue(refNumber);
		System.out.println("Transaction Value::"+transactionValue);
		Map<String, String> customerNo = common.getCustomerTransactions(refNumber);
	    String cusNo= customerNo.get("CUSTOMER_NO").toString();
	    ArrayList<String> transactionValues = new ArrayList<String>();
	    transactionValues.add(cusNo);
	    transactionValues.add(refNumber);
	    transactionValues.add(transactionValue);
	    String[] transColumnHeaders = { "Customer Number", "Transaction Receipt Number", "Value" };
	    commonInterfacePage.validateValuesIsPresentInExcel("32-Client Excessive Transactions Report - XLS 01.10.2019.xls","ExcessiveTransactionsVolume_XLS",
	    		transColumnHeaders, transactionValues,10);
		
  		
	   System.out.println("****Account Status and Sub-status change Report,Collections Account Report,Client Excessive Transaction Value Report - PDF,Client Excessive Transaction Value Report - XLS and Client Excessive Transactions Report - PDF were handled file moving and for values validation please do it manually****");
				
	}
	
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "Smoke" })
	public void ValidateClientLevelReportsAssignmentsWithMonthlyFrequency(@Optional("SG") String clientCountry,
			@Optional("EMAP") String clientName) {
		
		test = extent.createTest(clientName+ ":" +clientCountry+"  TST-SC-16-Client-level report assignments with monthly frequency","validating client Level Monthly Frequency Reports");
		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSCommonPage ifcsCommonPage = new IFCSCommonPage(driver, test);
		CommonInterfacePage commonInterfacePage = new CommonInterfacePage(driver, test);
		Common common = new Common(driver,test);
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry," ");
		
		//Card Status Report
		String cardNumber="7800702011282000268";
		String cardDescription=common.getCardStatusDesription(cardNumber);
		System.out.println("Card Description::"+cardDescription);
		common.convertCsvToXLS("33-Card Status Report 01.03.2021");
		ArrayList<String> cardStatusValues = new ArrayList<String>();
		cardStatusValues.add(cardNumber);
		cardStatusValues.add(cardDescription);
	    String[] cardColumnHeaders = { "Card Number", "Card Status"};
		commonInterfacePage.validateValuesIsPresentInExcel("33-Card Status Report 01.03.2021.xls","sheet1",
				cardColumnHeaders, cardStatusValues,1);
		
		//Duty Summary Report
		String dutySummaryReport="33-Duty Summary 01.07.2021.pdf";
		String previousDate=common.getPreviousProcessingDate("dd-MMM-yy");
		System.out.println("previousDate::"+previousDate);
		String dutyFreeMerchantNo=common.getDutySummaryMerchantNo(previousDate);
		System.out.println("dutyFreeMerchantNo::"+dutyFreeMerchantNo);
		ifcsCommonPage.validateReportContent(dutySummaryReport,dutyFreeMerchantNo);
		
		//EI80 Duty Exemption Report
		String dutyExemptionReport="33-EI80 Duty Exemption Report 01.07.2021.pdf";
	    String dutyCardNo=common.getDutyExemptionCardNo(previousDate);
	    System.out.println("dutyFreeMerchantNo::"+dutyCardNo);
		ifcsCommonPage.validateReportContent(dutyExemptionReport,dutyCardNo);
	}
	
	
}
