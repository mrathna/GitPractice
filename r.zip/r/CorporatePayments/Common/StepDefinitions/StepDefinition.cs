﻿using Common;
using Common.Utility;
using NFluent;
using OpenQA.Selenium;
using RestSharp;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Xml.Linq;
using TechTalk.SpecFlow;

namespace Common.StepDefinitions
{
	[Binding]
	public abstract class StepDefinition : Steps
	{
		private GlobalSettings _settings;

		public GlobalSettings Settings => _settings;
        
        public StepDefinition(GlobalSettings settings)
		{
			_settings = settings;
		}

        /// <summary>
        /// Private Helper which takes care of reading the href link from the input IWebElement, 
        /// opening a new tab and navigate to the url on the new tab i.e last tab.
        /// </summary>
        protected void OpenExternalPageOnNewTab(IWebElement _linkToRead, int _expWindowCount)
        {
            // Read the Url from the Web Element
            string _urlToGo = _linkToRead.GetAttribute("href");
            Settings.EnCompassExtentTest.Info("Got the href details from the External Page on UI - " + _urlToGo);

            this.OpenExternalPageOnNewTab(_urlToGo, _expWindowCount);
        }

        /// <summary>
        /// Opens the given link on a new Tab. It stores its instance on 'Settings.Scenario["ExternalPageWindow"]'.
        /// </summary>
        protected void OpenExternalPageOnNewTab(string _urlToGo, int _expWindowCount)
        {
            // Open a new tab in the browser
            IJavaScriptExecutor js = (IJavaScriptExecutor)Settings.EnCompassWebDriver;
            js.ExecuteScript("window.open();");
            Settings.EnCompassExtentTest.Info("Executed Javascript to open a new tab/window");

            // Get the list of window handles
            List<string> windows = Settings.EnCompassWebDriver.WindowHandles.ToList();
            Check.That(windows.Count).IsEqualTo(_expWindowCount);
            Settings.EnCompassExtentTest.Info("Verified total window handles matched expected count of : " + _expWindowCount);

            // Switch to new Tab (i.e 2nd tab) and navigate to the External Page url stored
            Settings.EnCompassWebDriver.SwitchTo().Window(windows.ElementAt(_expWindowCount - 1));
            Settings.Scenario["ExternalPageWindow"] = Settings.EnCompassWebDriver.CurrentWindowHandle;
            Settings.EnCompassExtentTest.Info("Switched to the new window handle");

            // Cannot use Navigate call as this is not a encompass page
            Settings.EnCompassWebDriver.Url = _urlToGo;
            Settings.EnCompassExtentTest.Info("Navigating to Url : " + _urlToGo);
        }

        /// <summary>
        /// To print the Xml payload for debugging purpose in html report
        /// </summary>
        public void PrintXmlRequestPayloadAsDebugLog(XDocument reqDoc, HttpWebRequest request)
        {
            using (StringWriter writer = new StringWriter())
            {
                reqDoc.Save(writer, SaveOptions.DisableFormatting);
                Settings.EnCompassExtentTest.Debug("Request body: ");
                string reqPayLoad = "<textarea>" + writer.ToString() + " </textarea>";
                Settings.EnCompassExtentTest.Debug(reqPayLoad + "\n");
            }

            Settings.EnCompassExtentTest.Debug("Printing the Request properties: \n");
            Settings.EnCompassExtentTest.Debug(request.Host + " : Host");
            Settings.EnCompassExtentTest.Debug(request.MediaType + " : Media Type");
            Settings.EnCompassExtentTest.Debug(request.ProtocolVersion + " : protocol Version");
            Settings.EnCompassExtentTest.Debug(request.Accept + " : Accept");
            Settings.EnCompassExtentTest.Debug(request.ContentType + " : Content Type");
            Settings.EnCompassExtentTest.Debug(request.RequestUri.AbsoluteUri + " : Request URI");
            Settings.EnCompassExtentTest.Debug(request.Connection + " : Connection Http Header");
            StringBuilder builder = new StringBuilder();
            request.Headers.AllKeys.ToList().ForEach(s => builder.Append(s + ","));
            Settings.EnCompassExtentTest.Debug("Request Header Keys : " + builder.ToString());
        }

        /// <summary>
        /// To print the Json request
        /// </summary>
        public void PrintJSonRequestPayloadAsDebugLog(IRestResponse request)
        {
            Settings.EnCompassExtentTest.Debug("Printing the Request properties: \n");
            Settings.EnCompassExtentTest.Debug(request.ErrorMessage + " : Error Message");
            Settings.EnCompassExtentTest.Debug(request.ResponseStatus + " : Response Status");
            Settings.EnCompassExtentTest.Debug(request.Headers + " : Headers");
            Settings.EnCompassExtentTest.Debug(request.Server + " : Server");
            Settings.EnCompassExtentTest.Debug(request.ResponseUri + " : Response Uri");
            Settings.EnCompassExtentTest.Debug(request.ErrorException + " : Error Exception");
            Settings.EnCompassExtentTest.Debug(request.IsSuccessful + " : IsSuccessful");
            Settings.EnCompassExtentTest.Debug(request.StatusCode + " : Status Code");
            Settings.EnCompassExtentTest.Debug(request.Content + " : Content");
            Settings.EnCompassExtentTest.Debug(request.ContentEncoding + " : Content Encoding");
            Settings.EnCompassExtentTest.Debug(request.ContentLength + " : Content Length");
            Settings.EnCompassExtentTest.Debug(request.ContentType + " : Content Type");
            Settings.EnCompassExtentTest.Debug(request.StatusDescription + " : Status Description");
            Settings.EnCompassExtentTest.Debug(request.ProtocolVersion + " : protocol Version");
            
            StringBuilder builder = new StringBuilder();
            request.Headers.ToList().ForEach(s => builder.Append(s + ","));
            Settings.EnCompassExtentTest.Debug("Request Header Keys : " + builder.ToString());
        }

        /// <summary>
        /// To print the Xml response payload for debugging purpose in html report
        /// </summary>
        public void PrintXmlResponsePayloadAsDebugLog(XDocument respDoc, WebResponse response)
		{
			using (StringWriter writer = new StringWriter())
			{
				respDoc.Save(writer, SaveOptions.DisableFormatting);
				Settings.EnCompassExtentTest.Debug("Response body: ");
				string respPayLoad = "<textarea>" + writer.ToString() + " </textarea>";
				Settings.EnCompassExtentTest.Debug(respPayLoad + "\n");
			}

			Settings.EnCompassExtentTest.Debug("Printing the Response properties: \n");
			Settings.EnCompassExtentTest.Debug(response.ContentType + " : Content Type");
			Settings.EnCompassExtentTest.Debug(response.ResponseUri.AbsoluteUri + " : Response URI");
			StringBuilder builder = new StringBuilder();
			response.Headers.AllKeys.ToList().ForEach(s => builder.Append(s + ","));
			Settings.EnCompassExtentTest.Debug("Response Header Keys : " + builder.ToString());
		}
	}
}
