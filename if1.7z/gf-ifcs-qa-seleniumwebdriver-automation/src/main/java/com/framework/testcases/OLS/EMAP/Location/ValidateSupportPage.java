package com.framework.testcases.OLS.EMAP.Location;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.EMAP.EMAPHomePage;
import com.framework.pages.EMAP.EMAPSupportPage;
import com.framework.pages.OLS.common.LoginPage;

public class ValidateSupportPage extends BaseTest {
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "Regression" })
	public void validateSupportPage(@Optional("SP") String clientCountry, @Optional("EMAP") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  EMAP Validate Support Page",
				"Login to EMAP Location - Read Only User and check the support page");
		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		EMAPHomePage emapHomePage = new EMAPHomePage(driver, test);
		EMAPSupportPage supportPage = new EMAPSupportPage(driver, test);
		loginPage.Login("EMAP_URL", "EMAP_UN_ReadOnly_Location_" + clientCountry,
				"EMAP_PWD_ReadOnly_Location_" + clientCountry, clientName);

		//emapHomePage.checkThePresenceOfQuickLinksOnHomePage("Loc-Read-Only");
		emapHomePage.clickChangePasswordAndValidatePage();
		//supportPage.checkThePasswordResetFieldsAreEnabled();
		supportPage.validateThePasswordMaintenanceFields();

		// Support - Contact Us
		if (!(clientCountry.equals("MO"))) {
			emapHomePage.clickContactUsAndValidatePage();
		} else {
			emapHomePage.clickContactUsMOAndValidatePage();
		}
		supportPage.checkMerchantClientLogo();
		supportPage.checkTheContactInfo(clientCountry);

		// Empty Query Type
		supportPage.enterCommentInContactUsField("Texting at comment field");
		supportPage.enterAContactName();
		supportPage.enterAContactPhone();
		supportPage.enterAContactEmail();
		supportPage.submitTheContactQuery();
		supportPage.validateTheErrorMessage("query");

		// Empty Comment
		supportPage.selectAQueryType();
		supportPage.clearCommentSection();
		supportPage.enterAContactName();
		supportPage.enterAContactPhone();
		supportPage.enterAContactEmail();
		supportPage.submitTheContactQuery();
		supportPage.validateTheErrorMessage("comment");

		// Empty Contact name
		supportPage.selectAQueryType();
		supportPage.enterCommentInContactUsField("Texting at comment field");
		supportPage.enterAContactPhone();
		supportPage.clearContactName();
		supportPage.enterAContactEmail();
		supportPage.submitTheContactQuery();
		supportPage.validateTheErrorMessage("name");

		// Empty Phone
		// Support - Contact Us
		if (!(clientCountry.equals("MO"))) {
			emapHomePage.clickContactUsAndValidatePage();
		} else {
			emapHomePage.clickContactUsMOAndValidatePage();
		}
		supportPage.selectAQueryType();
		supportPage.enterCommentInContactUsField("Texting at comment field");
		supportPage.enterAContactName();
		supportPage.enterAContactEmail();
		supportPage.submitTheContactQuery();
		supportPage.validateTheErrorMessage("phone");

		// // Empty Email
		// supportPage.selectAQueryType();
		// supportPage.enterCommentInContactUsField("Texting at comment field");
		// supportPage.enterAContactName();
		// supportPage.enterAContactPhone();
		// supportPage.submitTheContactQuery();
		// supportPage.enterAEmptyContactEmail();
		// supportPage.validateTheErrorMessage("email");

		// Invalid Email
		supportPage.selectAQueryType();
		supportPage.enterCommentInContactUsField("Texting at comment field");
		supportPage.enterAContactName();
		supportPage.enterAContactPhone();
		supportPage.enterAInvalidEmail();
		supportPage.submitTheContactQuery();
		supportPage.validateTheErrorMessage("invalidemail");

		// Valid Entry
		supportPage.selectAQueryType();
		supportPage.enterCommentInContactUsField("Texting at comment field");
		supportPage.enterAContactName();
		supportPage.enterAContactPhone();
		supportPage.enterAContactEmail();
		supportPage.submitTheContactQuery();
		supportPage.validateTheConfirmationMessage();

		// Footer Links - Exxon Mobil Corporation link
		// emapHomePage.clickExxonMobilCorporationInFooterAndValidatePage();
		// emapHomePage.clickHomeMenuAndValidatePage("Loc");

		// Footer Links - Contact Us
		emapHomePage.clickContactUsInFooterAndValidatePage();
		emapHomePage.clickHomeMenuAndValidatePage("Loc");

		// Footer Links - Copyright
		emapHomePage.clickCopyRightAndValidatePage(clientName);

		// Footer Links - Terms And Condition
		emapHomePage.checkThePresenceOfTermsAndConditionInFooter();

		// Footer Links - Privacy Statement
		//emapHomePage.clickPrivacyPolicyAndValidatePage();

		// Footer Links - Client Logos
		/*emapHomePage.clickExxonMobilLogoAndValidatePage();
		//emapHomePage.clickEssoLogoAndValidatePage();
		emapHomePage.clickMobilLogoAndValidatePage();*/

		// Logout
		loginPage.Logout();

	}
}
