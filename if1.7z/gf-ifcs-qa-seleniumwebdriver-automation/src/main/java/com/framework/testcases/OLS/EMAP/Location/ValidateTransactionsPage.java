package com.framework.testcases.OLS.EMAP.Location;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.EMAP.EMAPHomePage;
import com.framework.pages.EMAP.EMAPTransactionsPage;
import com.framework.pages.OLS.common.LoginPage;

/**
 *
 * @author Nithya Manikandan
 */
public class ValidateTransactionsPage extends BaseTest {
	@Parameters({ "clientCountry", "clientName" })
	@Test( groups = { "Regression" })
	public void validateAccountPage(@Optional("SP") final String clientCountry,
			@Optional("EMAP") final String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  TST-SC-86-OLS Location Site - Transactions",
				"Login to EMAP Location - Read Only User and check the Transaction page");
		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		EMAPHomePage emapHomePage = new EMAPHomePage(driver, test);
		EMAPTransactionsPage transactionPage = new EMAPTransactionsPage(driver, test);
		loginPage.Login("EMAP_URL", "EMAP_UN_ReadOnly_Location_" + clientCountry,
				"EMAP_PWD_ReadOnly_Location_" + clientCountry, clientName);
		//emapHomePage.checkThePresenceOfQuickLinksOnHomePage("Loc-Read-Only");

		// Transaction Settlement
		emapHomePage.clickSettlementsAndValidatePage();
		transactionPage.checkPresenceOfExportSettlementOption();
		transactionPage.checkPresenceOfSearchSettlementOption("Loc");
		transactionPage.checkPresenceOfSettlementSearchFilterFields();
		transactionPage.validateTheSettlementsTableFields();

		// Export Transaction
		emapHomePage.clickExportTransactionListAndValidate();
		// Footer Links - Exxon Mobil Corporation link
		// emapHomePage.clickExxonMobilCorporationInFooterAndValidatePage();
		// emapHomePage.clickHomeMenuAndValidatePage("Loc");

		// Footer Links - Contact Us
		emapHomePage.clickContactUsInFooterAndValidatePage();
		emapHomePage.clickHomeMenuAndValidatePage("Loc");

		// Footer Links - Copyright
		emapHomePage.clickCopyRightAndValidatePage(clientName);

		// Footer Links - Terms And Condition
		emapHomePage.checkThePresenceOfTermsAndConditionInFooter();

		// Footer Links - Privacy Statement
		// emapHomePage.clickPrivacyPolicyAndValidatePage();

		// Footer Links - Client Logos
		emapHomePage.clickExxonMobilLogoAndValidatePage();
		// emapHomePage.clickEssoLogoAndValidatePage();
		emapHomePage.clickMobilLogoAndValidatePage();

		if (transactionPage.checkLoginHaveTransactionDetails("Loc")) {
			emapHomePage.clickTransactionListAndValidatePage();
			boolean isTransactionPresent = transactionPage.getACardNumberWithTransaction();

			if (isTransactionPresent) {
				transactionPage.validateSearchResultsAndClickViewTransactionsOption(false);
				transactionPage.verifyTransactionDetailsHeaderTitle();
				transactionPage.validateTransactionPageFields("Loc");
			} else {
				transactionPage.selectATransactionWithoutCardAndVerify();
			}
		}

		// Logout
		loginPage.Logout();
	}
}
