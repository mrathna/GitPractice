using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using Common;
using Common.PageObjects;
using Common.ScenarioConfigurations;
using Common.Utility;

namespace EnCompass.Testing.Source.PageObjects.SuperAdmin.Apmanagement 
{
	/// <summary>
	/// Auto-generated Page Model Class
	/// Navigation Paths: 
		/// [Organization Home]->Payables->Accounts Payable
		/// [Organization Home]->Payables->Accounts Payable->Organizations
		/// </summary>
	[PageModel(@"/SuperAdmin/APManagement/ManageAP.aspx")]
	public partial class ManageAp : EnCompassSuperPageModel 
	{
		public override string RelativeUrl => @"/SuperAdmin/APManagement/ManageAP.aspx";
		public override string PageIdentifierXPath_Generated => @"//li[contains(@class, 'breadcrumb-item active')][text() = 'Organizations']";

		#region Navigation
				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Organizations']")]
		private IWebElement _payables_AccountsPayable_Organizations { get; set; }
		public void NavigateTo_Payables_AccountsPayable_Organizations()
		{
			NavigateToMenuItem(_payables_AccountsPayable_Organizations);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Prefund Solution Final Close']")]
		private IWebElement _payables_AccountsPayable_PrefundSolutionFinalClose { get; set; }
		public void NavigateTo_Payables_AccountsPayable_PrefundSolutionFinalClose()
		{
			NavigateToMenuItem(_payables_AccountsPayable_PrefundSolutionFinalClose);
		}

		[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Active Funds Final Close']")]
		private IWebElement _payables_AccountsPayable_ActiveFundsFinalClose { get; set; }
		public void NavigateTo_Payables_AccountsPayable_ActiveFundsFinalClose()
		{
			NavigateToMenuItem(_payables_AccountsPayable_ActiveFundsFinalClose);
		}

		[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Prefund Solution Payments']")]
		private IWebElement _payables_AccountsPayable_PrefundSolutionPayments { get; set; }
		public void NavigateTo_Payables_AccountsPayable_PrefundSolutionPayments()
		{
			NavigateToMenuItem(_payables_AccountsPayable_PrefundSolutionPayments);
		}

		[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Active Funds Payments']")]
		private IWebElement _payables_AccountsPayable_ActiveFundsPayments { get; set; }
		public void NavigateTo_Payables_AccountsPayable_ActiveFundsPayments()
		{
			NavigateToMenuItem(_payables_AccountsPayable_ActiveFundsPayments);
		}

		[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Non-Card Payments']")]
		private IWebElement _payables_AccountsPayable_ApNonCardPayments { get; set; }
		public void NavigateTo_Payables_AccountsPayable_ApNonCardPayments()
		{
			NavigateToMenuItem(_payables_AccountsPayable_ApNonCardPayments);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='EnCircle Enrollment']")]
		private IWebElement _payables_AccountsPayable_EncircleEnrollment { get; set; }
		public void NavigateTo_Payables_AccountsPayable_EncircleEnrollment()
		{
			NavigateToMenuItem(_payables_AccountsPayable_EncircleEnrollment);
		}

		[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Non-Card Payments']")]
		private IWebElement _payables_AccountsPayable_NonCardPayments { get; set; }
		public void NavigateTo_Payables_AccountsPayable_NonCardPayments()
		{
			NavigateToMenuItem(_payables_AccountsPayable_NonCardPayments);
		}

		private void NavigateToMenuItem(IWebElement element)
		{
			Driver.Url = element.GetAttribute("href");
		}
		#endregion

		public ManageAp(GlobalSettings settings) : base(settings) { }
	}  
}
