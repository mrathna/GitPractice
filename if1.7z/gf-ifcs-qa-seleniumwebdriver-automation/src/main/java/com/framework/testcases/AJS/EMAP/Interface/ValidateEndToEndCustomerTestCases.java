package com.framework.testcases.AJS.EMAP.Interface;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.MaintainCustomerPage;
import com.framework.pages.AJS.common.Common;
import com.framework.pages.AJS.common.CommonInterfacePage;
import com.framework.pages.AJS.common.IFCSCommonPage;
import com.framework.pages.AJS.common.IFCSHomePage;
import com.framework.pages.AJS.common.IFCSLoginPage;
import com.framework.pages.AJS.common.InterfacePage;

public class ValidateEndToEndCustomerTestCases extends BaseTest {

	// Covered 11 TestCases

	private String cardsListReturned = "";
	private String testcasesName = "";

	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "Smoke" },enabled=false)
	public void ValidateAndOrderCardForRequiredCustomers(@Optional("SG") String clientCountry,
			@Optional("EMAP") String clientName) {

		if (clientCountry.equals("SG")) {
			testcasesName = "TST-SC-42- E2E - New Customer" + "TST-SC-43-E2E -Migrated Customer"
					+ "TST-SC-46-E2E - Duty Free Customer";
		} else if (clientCountry.equals("SP")) {
			testcasesName = "TST-SC-42- E2E - New Customer"
					+ "TST-SC-44- E2E - Hierarchy Customers with periodic rebates"
					+ "TST-SC-45 -E2E - Hierarchy Customers";
		} else if (clientCountry.equals("GU")) {
			testcasesName = "TST-SC-42- E2E - New Customer" + "TST-SC-45 -E2E - Hierarchy Customers";
		} else if (clientCountry.equals("HK")) {
			testcasesName = "TST-SC-42- E2E - New Customer"
					+ "TST-SC-43- E2E - Hierarchy Customers with periodic rebates"
					+ "TST-SC-46-E2E - Duty Free Customer";
		}
		test = extent.createTest(testcasesName, "End to End Process");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		MaintainCustomerPage maintaincustomerPage = new MaintainCustomerPage(driver, test);

		// login the application
		IFCSloginPage.login("IFCS_URL_EMAP", "IFCS_EMAP_USERNAME", "IFCS_EMAP_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, " ");

		// getOrderedCardsForAllCountryCustomers
		ArrayList<String> AllCusNo = maintaincustomerPage.getAllCustomerNumbers(clientCountry);
		System.out.println("All Cus Numbers:: " + AllCusNo);
		cardsListReturned = maintaincustomerPage.validateAndOrderCardsForAllCustomers(AllCusNo, clientCountry);

	}

	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "Smoke" }, enabled=false,dependsOnMethods = "ValidateAndOrderCardForRequiredCustomers")
	public void ValidateReportGeneratedViaJobs(@Optional("SG") String clientCountry,
			@Optional("EMAP") String clientName) {

		if (clientCountry.equals("SG")) {
			testcasesName = "TST-SC-42- E2E - New Customer" + "TST-SC-43-E2E -Migrated Customer"
					+ "TST-SC-46-E2E - Duty Free Customer";
		} else if (clientCountry.equals("SP")) {
			testcasesName = "TST-SC-42- E2E - New Customer"
					+ "TST-SC-44- E2E - Hierarchy Customers with periodic rebates"
					+ "TST-SC-45 -E2E - Hierarchy Customers";
		} else if (clientCountry.equals("GU")) {
			testcasesName = "TST-SC-42- E2E - New Customer" + "TST-SC-45 -E2E - Hierarchy Customers";
		} else if (clientCountry.equals("HK")) {
			testcasesName = "TST-SC-42- E2E - New Customer"
					+ "TST-SC-43- E2E - Hierarchy Customers with periodic rebates"
					+ "TST-SC-46-E2E - Duty Free Customer";
		}
		test = extent.createTest(testcasesName,
				"Control-M Jobs-CardEmboss,Card CAF,TransProc,DayEnd & MonthEnd and Validated the Report are generated");

		IFCSCommonPage ifcsCommonPage = new IFCSCommonPage(driver, test);
		InterfacePage interfacePage = new InterfacePage(driver, test);
		CommonInterfacePage commonInterfacePage = new CommonInterfacePage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		ArrayList<String> refNumberUpdated = new ArrayList<String>();

		// Card Embossing job

		String folderName = "";
		String jobsInOrder = "";

		if (clientCountry.equals("GU") || clientCountry.equals("SP")) {
			folderName = ifcsCommonPage.getControlMFolder(clientName, clientCountry, "jobS_emap_SP_GU_emboss");

			jobsInOrder = ifcsCommonPage.getJobsOfFolderInOrder("jobS_emap_SP_GU_emboss");
		} else {
			folderName = ifcsCommonPage.getControlMFolder(clientName, clientCountry, "jobS_emap_emboss");
			jobsInOrder = ifcsCommonPage.getJobsOfFolderInOrder("jobS_emap_emboss");
		}
		// Executing the Control-M Jobs
		interfacePage.establishAndExecuteControlMJobs("ControlM_AWS_UAT", "ContorlM_AWS_userName",
				"ContorlM_AWS_password", folderName, jobsInOrder);

		// Get Recent Processed File from IE Server
		String embossFileName = commonInterfacePage.getEMAPRecentProcessedFileName(configProp, clientName,
				clientCountry, "EmbossCards");
		commonInterfacePage.getEMAPRecentProcessedFileName(configProp, clientName, clientCountry, "PinMailer");

		ifcsCommonPage.establishThePuttyConnection("incomingFile", "PUTTY_HOST", "PUTTY_USERNAME", "PUTTY_PASSWORD",
				"IE_OUTPUTFILE_FOLDER_CAF", embossFileName);
		System.out.println("fileNamefileName::" + embossFileName);
		String localFolder = System.getProperty("user.home") + "\\Documents\\" + embossFileName;

		// Validate new Card Present in a File
		interfacePage.updateOrValidateFlatFile(emapcardembossCongifProp, "incomingFile", localFolder, cardsListReturned,
				clientName, clientCountry, "");

		// Card-CAF job
		if (clientCountry.equals("GU") || clientCountry.equals("SP")) {
			folderName = ifcsCommonPage.getControlMFolder(clientName, clientCountry, "jobS_emap_SP_GU_CAF");
			jobsInOrder = ifcsCommonPage.getJobsOfFolderInOrder("jobS_emap_SP_GU_CAF");
		} else {
			folderName = ifcsCommonPage.getControlMFolder(clientName, clientCountry, "jobS_emap_CAF");
			jobsInOrder = ifcsCommonPage.getJobsOfFolderInOrder("jobS_emap_CAF");
		}
		// Executing the Control-M Jobs
		interfacePage.establishAndExecuteControlMJobs("ControlM_AWS_UAT", "ContorlM_AWS_userName",
				"ContorlM_AWS_password", folderName, jobsInOrder);

		// Get Recent Processed CAF File from IE Server
		commonInterfacePage.getEMAPRecentProcessedFileName(configProp, clientName, clientCountry, "CAF");

		if (clientCountry.equals("SG")) {
			refNumberUpdated = interfacePage.updateOrValidateFlatFile(emapLoadcardflatconfigPropOnlySG, "OutgoingFile",
					"IE_INPUTFILE_FOLDER_LOADCARDTRANSACTIONS", cardsListReturned, clientName, clientCountry,
					"FLTRAN_SG_20190528.txt");
		} else if (clientCountry.equals("GU") || clientCountry.equals("SP")) {
			refNumberUpdated = interfacePage.updateOrValidateFlatFile(emapLoadcardflatconfigPropAllClients,
					"OutgoingFile", "IE_INPUTFILE_FOLDER_LOADCARDTRANSACTIONS", cardsListReturned, clientName,
					clientCountry, "FLTRAN_GU_SP_20190618.txt");
		} else if (clientCountry.equals("HK") || clientCountry.equals("MO")) {
			refNumberUpdated = interfacePage.updateOrValidateFlatFile(emapLoadcardflatconfigPropAllClients,
					"OutgoingFile", "IE_INPUTFILE_FOLDER_LOADCARDTRANSACTIONS", cardsListReturned, clientName,
					clientCountry, "FLTRAN_HK_MO_20190618.txt");
		}

		// TransProc jobs
		if (!refNumberUpdated.equals("")) {
			folderName = ifcsCommonPage.getControlMFolder(clientName, clientCountry, "jobS_emap_TransProc");

			jobsInOrder = ifcsCommonPage.getJobsOfFolderInOrder("jobS_emap_TransProc");

			interfacePage.establishAndExecuteControlMJobs("ControlM_AWS_UAT", "ContorlM_AWS_userName",
					"ContorlM_AWS_password", folderName, jobsInOrder);
		}

		// DayEnd jobs

		folderName = ifcsCommonPage.getControlMFolder(clientName, clientCountry, "jobS_emap_SG_Dayend");

		jobsInOrder = ifcsCommonPage.getJobsOfFolderInOrder("jobS_emap_Dayend");

		// Executing the Control-M Jobs
		interfacePage.establishAndExecuteControlMJobs("ControlM_AWS_UAT", "ContorlM_AWS_userName",
				"ContorlM_AWS_password", folderName, jobsInOrder);

		// MonthEnd Jobs
		folderName = ifcsCommonPage.getControlMFolder(clientName, clientCountry, "jobS_emap_SG_Monthend");
		jobsInOrder = ifcsCommonPage.getJobsOfFolderInOrder("jobS_emap_Monthend");

		// Executing the Control-M Jobs
		interfacePage.establishAndExecuteControlMJobs("ControlM_AWS_UAT", "ContorlM_AWS_userName",
				"ContorlM_AWS_password", folderName, jobsInOrder);

		
		//Get Recent Processed File from IFCS Server
		
		IFCSHomePage.exitIFCS();
	}
	//Report Validation
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "Smoke" })
	public void ValidateReportsGeneratedFromDayEndAndMonthEnd(@Optional("SG") String clientCountry,
			@Optional("EMAP") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  E2E testCases","All E2E TestCases");
		// creating object for the Pages
				IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
			    CommonInterfacePage commonInterfacePage = new CommonInterfacePage(driver, test);
		        IFCSCommonPage ifcsCommonPage = new IFCSCommonPage(driver, test);
		        Common common = new Common(driver,test);
				IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry," ");
		
				
				String dayEndDatePath="";
				String fileName="";
				String localFolder="";
				
				
	//Run Month End and validate Customer Statement Report
	
	String refNo="567";
    Map<String, String> customerTransactionDetails = common.getCustomerTransactions(refNo);
    String cusNo= customerTransactionDetails.get("CUSTOMER_NO").toString();
    System.out.println("Customer No "+cusNo);
	fileName=commonInterfacePage.getRecentProcessedReportFiles( clientName, clientCountry,
						"Customer Statement",cusNo);
	if(clientCountry.equals("SG")) {
		dayEndDatePath=commonInterfacePage.getFolderPathUsingPreviousProcessingDate(clientName, clientCountry,"IFCS_DAYEND_OUTPUTFILE_SG_CUSTOMER");
		}
	else if(clientCountry.equals("SP")) {
	   dayEndDatePath=commonInterfacePage.getFolderPathUsingPreviousProcessingDate(clientName, clientCountry,"IFCS_DAYEND_OUTPUTFILE_SP_CUSTOMER");
	}else if(clientCountry.equals("GU")) {
		dayEndDatePath=commonInterfacePage.getFolderPathUsingPreviousProcessingDate(clientName, clientCountry,"IFCS_DAYEND_OUTPUTFILE_GU_CUSTOMER");
	}else if(clientCountry.equals("HK")) {
	    dayEndDatePath=commonInterfacePage.getFolderPathUsingPreviousProcessingDate(clientName, clientCountry,"IFCS_DAYEND_OUTPUTFILE_HK_CUSTOMER");
		}
	System.out.println("dayEndDatePath::" +dayEndDatePath);
	ifcsCommonPage.establishThePuttyConnection("incomingFile", "PUTTY_HOST", "PUTTY_USERNAME", "PUTTY_PASSWORD",
						dayEndDatePath, fileName);
    localFolder = System.getProperty("user.home") + "\\Documents\\" +fileName;
	System.out.println("localFolder::" +localFolder);
	commonInterfacePage.validateTextFromPDF(fileName,refNo,"customer_no",1,1);
	
	//Run dayend and Validate Merchant Statement Report
	 String merchantReimbursementAmt="";
	  customerTransactionDetails = common.getCustomerTransactions(refNo);
	  String merchantNo= customerTransactionDetails.get("merchant_no").toString();
		fileName=commonInterfacePage.getRecentProcessedReportFiles( clientName, clientCountry,
				"Merchant Statement",merchantNo);
		
		if(clientCountry.equals("SG")) {
		    dayEndDatePath=commonInterfacePage.getFolderPathUsingCurrentSystemDate(clientName, clientCountry,"IFCS_DAYEND_OUTPUTFILE_SG_MERCHANT");
		    }else if(clientCountry.equals("SP")) {
			dayEndDatePath=commonInterfacePage.getFolderPathUsingCurrentSystemDate(clientName, clientCountry,"IFCS_DAYEND_OUTPUTFILE_SP_MERCHANT");
			}else if(clientCountry.equals("GU")) {
			 dayEndDatePath=commonInterfacePage.getFolderPathUsingCurrentSystemDate(clientName, clientCountry,"IFCS_DAYEND_OUTPUTFILE_GU_MERCHANT");
			}else if(clientCountry.equals("HK")) {
				 dayEndDatePath=commonInterfacePage.getFolderPathUsingCurrentSystemDate(clientName, clientCountry,"IFCS_DAYEND_OUTPUTFILE_HK_MERCHANT");
				}
		System.out.println("dayEndDatePath::" +dayEndDatePath);
		ifcsCommonPage.establishThePuttyConnection("incomingFile", "PUTTY_HOST", "PUTTY_USERNAME", "PUTTY_PASSWORD",
									dayEndDatePath, fileName);
		localFolder = System.getProperty("user.home") + "\\Documents\\" +fileName;
	    System.out.println("localFolder::" +localFolder);
	    commonInterfacePage.validateTextFromPDF(fileName,refNo,"merchant_no",1,1);
	    if(clientCountry.equals("HK")) {
	    	  merchantReimbursementAmt=common.getReimbursementAmountForMerchant(merchantNo, "MonthEnd");
	    }
	    else {
	     merchantReimbursementAmt=common.getReimbursementAmountForMerchant(merchantNo, "DayEnd");
	    }
	    ifcsCommonPage.validateReportContent(fileName,merchantReimbursementAmt); 
	    
	//JDE or SAP Report
	    fileName= commonInterfacePage.getGeneratedSAPFile(clientCountry,"IFIP");
	    ifcsCommonPage.establishThePuttyConnection("incomingFile", "PUTTY_HOST", "PUTTY_USERNAME", "PUTTY_PASSWORD",
				"IE_OUTPUTFILE_FOLDER_CAF",fileName );
        localFolder = System.getProperty("user.home") + "\\Documents\\" +fileName;
        System.out.println("localFolder::" +localFolder);
        System.out.println("*****SAP Files Values are not be automate please do it manually******");
				
      //Client Reports File Moving
        List<String>  fileNames;
        List<String> listFilesPath=new ArrayList<String>();
        String dateIFCS = common.getCurrentIFCSDateFromDB(clientName + clientCountry);
		String dbProcessingDate = commonInterfacePage.getreportDateFormat(dateIFCS);
		 fileNames=commonInterfacePage.createClientReportFileFormatByDateAppend(clientCountry,emapdayendreportsConfigFile,dbProcessingDate);
		  for(int i=0;i<=fileNames.size();i++) {
				  fileName= fileNames.get(i);
		  if(clientCountry.equals("SG")) {
		  dayEndDatePath=commonInterfacePage.getFolderPathUsingPreviousProcessingDate(clientName, clientCountry,"IFCS_DAYEND_OUTPUTFILE_SG_CLIENT");
		  }else if(clientCountry.equals("SP")) {
				 dayEndDatePath=commonInterfacePage.getFolderPathUsingPreviousProcessingDate(clientName, clientCountry,"IFCS_DAYEND_OUTPUTFILE_SP_CLIENT");
		  }else if(clientCountry.equals("GU")) {
				 dayEndDatePath=commonInterfacePage.getFolderPathUsingPreviousProcessingDate(clientName, clientCountry,"IFCS_DAYEND_OUTPUTFILE_GU_CLIENT");
		  }else if(clientCountry.equals("HK")) {
				 dayEndDatePath=commonInterfacePage.getFolderPathUsingPreviousProcessingDate(clientName, clientCountry,"IFCS_DAYEND_OUTPUTFILE_HK_CLIENT");
		  }
		  System.out.println("dayEndDatePath::" +dayEndDatePath);
		  ifcsCommonPage.establishThePuttyConnection("incomingFile", "PUTTY_HOST", "PUTTY_USERNAME", "PUTTY_PASSWORD",
					dayEndDatePath, fileName);
		  localFolder = System.getProperty("user.home") + "\\Documents\\" +fileName;
		  listFilesPath.add(localFolder);
		  }
        
        System.out.println("******Generated files moved to Local if need validation please do it manually******" );
        
        
	}
        
    
}
