﻿using Common.Utility;
using EnCompass.Testing.Source.PageObjects.Controls;
using NFluent;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EnCompass.Testing.Source.PageObjects.Organization.DecisionStream.AccountMaintenance
{
	public partial class History
	{
        #region XPath page Elements
        private const string _editBtnXPath = @"//a[contains(@id, 'actionLink0')]";
        private const string _searchCriteriaSearchTermXPath = @"//div[contains(@id, 'SearchOutput')]/select[1]";
        private const string _searchCriteriaFilterTypeXPath = @"//div[contains(@id, 'SearchOutput')]/select[2]";
        private const string _searchCriteriaTextSearchValueXPath = @"//div[contains(@id, 'SearchOutput')]/input[1]";
        private const string _searchCriteriaListboxSearchValueXPath = @"//div[contains(@id, 'SearchOutput')]/select[3]";
        private const string _searchCriteriaResetBtnXPath = @"//div[contains(@id, 'SearchOutput')]/input[5]";
        private const string _searchCriteriaAddBtnXPath = @"//div[contains(@id, 'SearchOutput')]/input[4]";
        private const string _searchXPath = @"//input[contains(@id, 'btnSearch')]";
        private const string _pagingXPath = @"//select[contains(@id, 'Top_pageSizesDropdown')]";
        private const string _gridCaptionXPath = @"//table[contains(@id, 'dgAccounts')]/caption";
        private const string _viewChangeDetailsXPath = @"//a[contains(@id, 'actionLink1')]";
        private const string _createTestCardsXPath = @"//a[text()='Cards']";
        private const string _headerFirstXPath = @"//a[text()='Card Holder']";
        private const string _headerSecondXPath = @"//td[text()='Employee ID']";
        private const string _headerThirdXPath = @"//a[text()='Submitted Date']";
        private const string _headerFourthXPath = @"//a[text()='Status']";
        #endregion

        #region Page Elements

		private IWebElement _editBtn
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_editBtnXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_editBtn element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _searchCriteriaSearchTerm
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_searchCriteriaSearchTermXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_searchCriteriaSearchTerm element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _searchCriteriaFilterType
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_searchCriteriaFilterTypeXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_searchCriteriaFilterType element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _searchCriteriaTextSearchValue
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_searchCriteriaTextSearchValueXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_searchCriteriaTextSearchValue element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _searchCriteriaListboxSearchValue
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_searchCriteriaListboxSearchValueXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_searchCriteriaListboxSearchValue element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _searchCriteriaResetBtn
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_searchCriteriaResetBtnXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_searchCriteriaResetBtn element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _searchCriteriaAddBtn
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_searchCriteriaAddBtnXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_searchCriteriaAddBtn element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _search
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_searchXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_search element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _paging
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_pagingXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_paging element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _gridCaption
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_gridCaptionXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_gridCaption element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _viewChangeDetails
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_viewChangeDetailsXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_viewChangeDetails element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _createTestCards
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_createTestCardsXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_createTestCards element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _headerFirst
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_headerFirstXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_headerFirst element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _headerSecond
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_headerSecondXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_headerSecond element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _headerThird
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_headerThirdXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_headerThird element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }

        private IWebElement _headerFourth
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_headerFourthXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info($"_headerFourth element exist is {found}");
                Check.That(found).IsTrue();
                return element;
            }
        }
        #endregion

        public void ViewChangeDetails()
		{
			_viewChangeDetails.JSClickWithFocus(Driver);
			Driver.WaitForAbsence(By.XPath(_viewChangeDetailsXPath));
		}

		public void SetSearchCriteriaSearchTerm(string whichText)
		{
			var selectElement = new SelectElement(_searchCriteriaSearchTerm);
			selectElement.SelectByText(whichText);
		}

		public string SearchTermvalues
		{
			get
			{
				return _searchCriteriaSearchTerm.Text;
			}
		}

		public void SetSearchCriteriaSearchTermByValue(string whichText)
		{
			var selectElement = new SelectElement(_searchCriteriaSearchTerm);
			selectElement.SelectByValue(whichText);
		}

		public void SetSearchCriteriaFilterType(string whichText)
		{
			var selectElement = new SelectElement(_searchCriteriaFilterType);
			selectElement.SelectByText(whichText);
		}

		public void SetSearchCriteriaFilterTypeByValue(string whichValue)
		{
			var selectElement = new SelectElement(_searchCriteriaFilterType);
			selectElement.SelectByValue(whichValue);
		}
		
		public string SearchCriteriaTextSearchValue
		{
			set
			{
				_searchCriteriaTextSearchValue.SendKeys(value);
			}
		}

		private GridControl _accountChanges;
		public GridControl AccountChanges
		{
		get
			{
				return _accountChanges ?? (_accountChanges = new GridControl("dgAccounts", Driver));
			}
		}
		
		public void SetSearchCriteriaListboxSearchValue(string whichText)
		{
			var selectElement = new SelectElement(_searchCriteriaListboxSearchValue);
			selectElement.SelectByText(whichText);
		}

		public void Reset()
		{
			_searchCriteriaResetBtn.JSClickWithFocus(Driver);
		}
		public void Add()
		{
			_searchCriteriaAddBtn.JSClickWithFocus(Driver);
		}

		public void Search()
		{
			_search.JSClickWithFocus(Driver);
			WaitForLoad();
		}
		
		public void EditBtn()
		{
			_editBtn.JSClickWithFocus(Driver);
		}

		private GridControl _cardHistoryListGrid;
		public GridControl CardHistoryListGrid
		{
			get
			{
				return _cardHistoryListGrid ?? (_cardHistoryListGrid = new GridControl("dgAccounts", Driver));
			}
		}
				
		public bool IsItHistoryLandinPage()
		{
			if(_gridCaption.Text.Equals("Card Edits", StringComparison.InvariantCultureIgnoreCase))
			{
                CardHistoryListGrid.WaitForGrid();
                return true;
			}
			else
			{
				return false;
			}
		}

        public void GoToCreateTestCardsPage()
        {
            _createTestCards.JSClickWithFocus(Driver);
        }

        public string GetHeader1
        {
            get
            {
                _headerFirst.WaitUntilElementIsInteractable();
                return _headerFirst.Text;
            }
        }

        public string GetHeader2
        {
            get
            {
                _headerSecond.WaitUntilElementIsInteractable();
                return _headerSecond.Text;
            }
        }
        public string GetHeader3
        {
            get
            {
                Driver.JsScrollToBottom();
               
                _headerThird.WaitUntilElementIsInteractable();
                return _headerThird.Text;
            }
        }

        public string GetHeader4
        {
            get
            {
                _headerFourth.WaitUntilElementIsInteractable();
                Settings.EnCompassWebDriver.ScrollToXPATH(_headerFourthXPath);
                return _headerFourth.Text;
            }
        }

        private GridControl _cardGrid;
        public GridControl CardGrid
        {
            get
            {
                _cardGrid = new GridControl("dgAccounts", Driver);
                _cardGrid.WaitForGrid();
                return _cardGrid;
            }
        }
       
    }
}
