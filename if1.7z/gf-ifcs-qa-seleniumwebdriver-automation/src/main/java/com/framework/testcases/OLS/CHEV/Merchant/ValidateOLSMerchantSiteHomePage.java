package com.framework.testcases.OLS.CHEV.Merchant;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.CHEV.CHChangePasswordPage;
import com.framework.pages.CHEV.CHHomePage;
import com.framework.pages.OLS.common.CommonPage;
import com.framework.pages.OLS.common.LoginPage;

public class ValidateOLSMerchantSiteHomePage extends BaseTest {
	@Parameters({ "clientCountry", "clientName" })
	@Test(priority = 1)
	public void testOLSMerchantSiteHomePage(@Optional("TH") String clientCountry, @Optional("CHV") String clientName) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  OLS - Merchant Site - Home Page", "Chevron Merchant Screens Read Only");

		LoginPage loginPage = new LoginPage(driver, test);
		CHHomePage chHomePage = new CHHomePage(driver, test);
		//CHTransactionPage chTransactionPage = new CHTransactionPage(driver, test);
		CHChangePasswordPage chChangePasswordPage = new CHChangePasswordPage(driver, test);
		CommonPage commonPage = new CommonPage(driver, test);
		/*if (clientCountry.equals("SG")) {
			loginPage.Login("CHV_URL", "CHV_Merchant_UN_"+clientCountry, "CHV_Merchant_PWD_"+clientCountry, "CHV");
//			chHomePage.verifyUserName("Hello, Test");
			chHomePage.verifyMerchantAccountDetails();
		} else if (clientCountry.equals("TH")) {
			loginPage.Login("CHV_URL", "CHV_Merchant_UN_"+clientCountry, "CHV_Merchant_PWD_"+clientCountry, "CHV");
//			chHomePage.verifyUserName("Hello, THuser");
		} else if (clientCountry.equals("PH")) {
			loginPage.Login("CHV_URL", "CHV_Merchant_UN_"+clientCountry, "CHV_Merchant_PWD_"+clientCountry, "CHV");
//			chHomePage.verifyUserName("Hello, PHuser");
		}*/
		
	//	chHomePage.verifyMerchantQuickLinks();
	//	chHomePage.clickOnTransactionQuickLink();
	//	chTransactionPage.verifyTransactionPage();
		loginPage.Login("CHV_URL", "CHV_Merchant_UN_"+clientCountry, "CHV_Merchant_PWD_"+clientCountry, "CHV");
		chHomePage.clickOnHome();
		chHomePage.clickOnExportTransactionLink();
		//chHomePage.checkForFileDownload(1);
		String checkFileDate=chHomePage.validateDateInDownloadedFile();
		commonPage.isFileDownloaded(checkFileDate);
		//commonPage.isFileDownloaded("0700031161__20190408_");
		chHomePage.clickOnUsername();
		chHomePage.clickOnChangePwdLink();
		chChangePasswordPage.verifyPasswordMaintenancePage();

		chChangePasswordPage.enterRandomValuesExceptPasswordField();
		chChangePasswordPage.clickSubmitButton();
		chChangePasswordPage.verifyErrorMessage("Validation failed");

		chChangePasswordPage.enterRandomValuesExceptConfirmationPasswordField("CHV_Merchant_PWD_PH");
		chChangePasswordPage.clickSubmitButton();
		chChangePasswordPage.verifyErrorMessage("Validation failed");

		chChangePasswordPage.enterRandomValuesWithDiffNewAndConfirm("CHV_Merchant_PWD_PH");
		chChangePasswordPage.clickSubmitButton();
		chChangePasswordPage.verifyErrorMessage("Validation failed");

		chChangePasswordPage.enterNewValues("CHV_Merchant_PWD_PH", "password03");
		//chChangePasswordPage.clickSubmitButton();

//		// TODO CHeck Confirmation Message Web Element if the TC is failing
		//chChangePasswordPage.checkConfirmationMessage();
		chHomePage.verifyFooterLinks(); 
		chChangePasswordPage.sleep(20);

		loginPage.Logout();
	}
}
