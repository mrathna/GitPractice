package com.framework.testcases.AJS.EMAP.Interface;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.ApplicationsPage;
import com.framework.pages.AJS.CardMaintenancePage;
import com.framework.pages.AJS.MaintainCustomerPage;
import com.framework.pages.AJS.TransactionListPage;
import com.framework.pages.AJS.common.Common;
import com.framework.pages.AJS.common.CommonInterfacePage;
import com.framework.pages.AJS.common.IFCSCommonPage;
import com.framework.pages.AJS.common.IFCSHomePage;
import com.framework.pages.AJS.common.IFCSLoginPage;
import com.framework.pages.AJS.common.InterfacePage;
import com.github.javafaker.Faker;

public class ValidateInterfaceCardEmbossTestCases extends BaseTest {

	// Prakalpha
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "Smoke" })
	public void orderNewCardForDualCardDriverAndValidateCardEmbossing(@Optional("MO") String clientCountry,
			@Optional("EMAP") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  TST-SC-01_Order New Card  - Dual Card Driver",
				"EMAP Order DualCard Driver and validate new card via CardEmbossing Job through ControlM");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		Common common = new Common(driver, test);
		MaintainCustomerPage maintaincustomerPage = new MaintainCustomerPage(driver, test);
		IFCSCommonPage ifcsCommonPage = new IFCSCommonPage(driver, test);
		InterfacePage interfacePage = new InterfacePage(driver, test);
		CommonInterfacePage commonInterfacePage = new CommonInterfacePage(driver, test);

		// Logon the Application
		IFCSloginPage.login("IFCS_URL_EMAP", "IFCS_EMAP_USERNAME", "IFCS_EMAP_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, " ");

		// choose Client from Application Page
		IFCSHomePage.gotoApplicationAndClickApplicationMenu();
		IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);

		// Get Active customer No
		String customerNumber = common.getActiveCustomerNoUsingCardType();
		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		common.chooseCustomerNoAndSearch(customerNumber);

		// filling mandatory info and create a profile
		maintaincustomerPage.fillMandatoryFieldsAndCreateProfile("Dual Card Driver", "0001", " ", false, false);

		
		/*  //Set Profile as default
		  maintaincustomerPage.setPrivateProfileAsDefault("Profiles");*/
		 

		// Order new card
		String orderedCardNumber = maintaincustomerPage.getCardNumberandValidateOrderedCard();

		// New card Status
		maintaincustomerPage.validateNewCardStatus(orderedCardNumber);

		// Get Card Status
		String cardStatus = maintaincustomerPage.getStatusforCard("Card List", "Status");
		System.out.println("Before Card Embossing Cards Status:" + cardStatus);
		common.validateSearchTable("Status", "Requested Not Issued", true);

		// Card Embossing
		String folderName = ifcsCommonPage.getControlMFolder(clientName, clientCountry, "jobS_emap_emboss");
		String jobsInOrder = ifcsCommonPage.getJobsOfFolderInOrder("jobS_emap_emboss");

		// Executing the Control-M Jobs
		interfacePage.establishAndExecuteControlMJobs("ControlM_AWS_UAT", "ContorlM_AWS_userName",
				"ContorlM_AWS_password", folderName, jobsInOrder);

		// Get Recent Processed File from IE Server
		String fileName = commonInterfacePage.getEMAPRecentProcessedFileName(configProp, clientName, clientCountry,
				"EmbossCards");
		ifcsCommonPage.establishThePuttyConnection("incomingFile", "PUTTY_HOST", "PUTTY_USERNAME", "PUTTY_PASSWORD",
				"IE_OUTPUTFILE_FOLDER_CAF", fileName);
		System.out.println("fileNamefileName::" + fileName);
		String localFolder = System.getProperty("user.home") + "\\Documents\\" + fileName;

		// Validate new Card Present in a File
		interfacePage.updateOrValidateFlatFile(emapcardembossCongifProp, "incomingFile", localFolder, orderedCardNumber,
				clientName, clientCountry, "");

		// exit the application
		// IFCSHomePage.exitIFCS();
	}

	// Prakalpha
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "Smoke" })
	public void orderNewCardForDualCardVehicleAndValidateCardEmbossing(@Optional("MO") String clientCountry,
			@Optional("EMAP") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  TST-SC-02-Order New Card  - Dual Card vehicle",
				"EMAP Order DualCardVehicle and validate New Card via CardEmbossing Job through ControlM");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		Common common = new Common(driver, test);
		MaintainCustomerPage maintaincustomerPage = new MaintainCustomerPage(driver, test);
		IFCSCommonPage ifcsCommonPage = new IFCSCommonPage(driver, test);
		InterfacePage interfacePage = new InterfacePage(driver, test);
		CommonInterfacePage commonInterfacePage = new CommonInterfacePage(driver, test);

		// Logon the application
		IFCSloginPage.login("IFCS_URL_EMAP", "IFCS_EMAP_USERNAME", "IFCS_EMAP_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, " ");

		// Choose client from Application Page
		IFCSHomePage.gotoApplicationAndClickApplicationMenu();
		IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);

		// Get Active CustomerNo
		String customerNumber = common.getActiveCustomerNoUsingCardType();
		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		common.chooseCustomerNoAndSearch(customerNumber);

		// filling mandatory info and create a profile
		maintaincustomerPage.fillMandatoryFieldsAndCreateProfile("Dual Card Vehicle", "0001", " ", false, false);

		
		 /** //Set Profile as default
		 * maintaincustomerPage.setPrivateProfileAsDefault("Profiles");*/
		 
		// Order A new Card
		String orderedCardNumber = maintaincustomerPage.getCardNumberandValidateOrderedCard();

		// New card Status
		maintaincustomerPage.validateNewCardStatus(orderedCardNumber);

		// Get Card Status
		String cardStatus = maintaincustomerPage.getStatusforCard("Card List", "Status");
		System.out.println(cardStatus);
		common.validateSearchTable("Status", "Requested Not Issued", true);

		// Card Embossing
		String folderName = ifcsCommonPage.getControlMFolder(clientName, clientCountry, "jobS_emap_emboss");
		String jobsInOrder = ifcsCommonPage.getJobsOfFolderInOrder("jobS_emap_emboss");

		// Executing the Control-M Jobs
		interfacePage.establishAndExecuteControlMJobs("ControlM_AWS_UAT", "ContorlM_AWS_userName",
				"ContorlM_AWS_password", folderName, jobsInOrder);

		// Get Recent Processed File from IE Server
		String fileName = commonInterfacePage.getEMAPRecentProcessedFileName(configProp, clientName, clientCountry,
				"EmbossCards");
		ifcsCommonPage.establishThePuttyConnection("incomingFile", "PUTTY_HOST", "PUTTY_USERNAME", "PUTTY_PASSWORD",
				"IE_OUTPUTFILE_FOLDER_CAF", fileName);
		System.out.println("fileNamefileName::" + fileName);
		String localFolder = System.getProperty("user.home") + "\\Documents\\" + fileName;

		// Validate new Card Present in a File
		interfacePage.updateOrValidateFlatFile(emapcardembossCongifProp, "incomingFile", localFolder, orderedCardNumber,
				clientName, clientCountry, "");

		// exit the application
		IFCSHomePage.exitIFCS();
	}

	// Prakalpha
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "Smoke" })
	public void orderNewCardForFleetCardVehicleAndValidateCardEmbossing(@Optional("HK") String clientCountry,
			@Optional("EMAP") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  TST-SC-03_Order New Card  - Fleet Card vehicle",
				"EMAP Order FleetCard Vehicle and validate New Card via CardEmbossing Job through ControlM");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		Common common = new Common(driver, test);
		MaintainCustomerPage maintaincustomerPage = new MaintainCustomerPage(driver, test);
		IFCSCommonPage ifcsCommonPage = new IFCSCommonPage(driver, test);
		InterfacePage interfacePage = new InterfacePage(driver, test);
		CommonInterfacePage commonInterfacePage = new CommonInterfacePage(driver, test);

		// Logon the application
		IFCSloginPage.login("IFCS_URL_EMAP", "IFCS_EMAP_USERNAME", "IFCS_EMAP_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, " ");

		// Choose client from Application Page
		IFCSHomePage.gotoApplicationAndClickApplicationMenu();
		IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);

		// Get Active CustomerNo
		String customerNumber = common.getActiveCustomerNoUsingCardType();
		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		common.chooseCustomerNoAndSearch(customerNumber);

		// filling mandatory info and create a profile
		maintaincustomerPage.fillMandatoryFieldsAndCreateProfile("Fleet Card Vehicle", "0001", " ", false, false);

		
		 /* //Set Profile as default
		  maintaincustomerPage.setPrivateProfileAsDefault("Profiles");*/
		 

		// Order A new Card
		String orderedCardNumber = maintaincustomerPage.getCardNumberandValidateOrderedCard();

		// New card Status
		maintaincustomerPage.validateNewCardStatus(orderedCardNumber);

		// Get Card Status
		String cardStatus = maintaincustomerPage.getStatusforCard("Card List", "Status");
		System.out.println(cardStatus);
		common.validateSearchTable("Status", "Requested Not Issued", true);

		// Card Embossing
		String folderName = ifcsCommonPage.getControlMFolder(clientName, clientCountry, "jobS_emap_emboss");
		String jobsInOrder = ifcsCommonPage.getJobsOfFolderInOrder("jobS_emap_emboss");

		// Executing the Control-M Jobs
		interfacePage.establishAndExecuteControlMJobs("ControlM_AWS_UAT", "ContorlM_AWS_userName",
				"ContorlM_AWS_password", folderName, jobsInOrder);

		// Get Recent Processed File from IE Server
		String fileName = commonInterfacePage.getEMAPRecentProcessedFileName(configProp, clientName, clientCountry,
				"EmbossCards");
		ifcsCommonPage.establishThePuttyConnection("incomingFile", "PUTTY_HOST", "PUTTY_USERNAME", "PUTTY_PASSWORD",
				"IE_OUTPUTFILE_FOLDER_CAF", fileName);
		System.out.println("fileNamefileName::" + fileName);
		String localFolder = System.getProperty("user.home") + "\\Documents\\" + fileName;

		// Validate new Card Present in a File
		interfacePage.updateOrValidateFlatFile(emapcardembossCongifProp, "incomingFile", localFolder, orderedCardNumber,
				clientName, clientCountry, "");

		// exit the application
		IFCSHomePage.exitIFCS();
	}

	// Prakalpha
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "Smoke" })
	public void orderNewCardForWildCardAndValidateCardEmbossing(@Optional("HK") String clientCountry,
			@Optional("EMAP") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  TST-SC-04-Order New Card   - Wild Card",
				"EMAP Order WildCard and validate New Card via CardEmbossing Job via ControlM");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		Common common = new Common(driver, test);
		MaintainCustomerPage maintaincustomerPage = new MaintainCustomerPage(driver, test);
		IFCSCommonPage ifcsCommonPage = new IFCSCommonPage(driver, test);
		InterfacePage interfacePage = new InterfacePage(driver, test);
		CommonInterfacePage commonInterfacePage = new CommonInterfacePage(driver, test);

		// Logon the application
		IFCSloginPage.login("IFCS_URL_EMAP", "IFCS_EMAP_USERNAME", "IFCS_EMAP_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, " ");

		// Choose client from Application Page
		IFCSHomePage.gotoApplicationAndClickApplicationMenu();
		IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);

		// Get Active CustomerNo
		String customerNumber = common.getActiveCustomerNoUsingCardType();
		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		common.chooseCustomerNoAndSearch(customerNumber);

		// filling mandatory info and create a profile
		maintaincustomerPage.fillMandatoryFieldsAndCreateProfile("Wild Card", "0001", " ", false, false);

		
		/* * //Set Profile as default
		 * maintaincustomerPage.setPrivateProfileAsDefault("Profiles");*/
		 
		// Order A new Card
		String orderedCardNumber = maintaincustomerPage.getCardNumberandValidateOrderedCard();

		// New card Status
		maintaincustomerPage.validateNewCardStatus(orderedCardNumber);
		String cardStatus = maintaincustomerPage.getStatusforCard("Card List", "Status");
		System.out.println(cardStatus);
		common.validateSearchTable("Status", "Requested Not Issued", true);

		// Card Embossing
		String folderName = ifcsCommonPage.getControlMFolder(clientName, clientCountry, "jobS_emap_emboss");
		String jobsInOrder = ifcsCommonPage.getJobsOfFolderInOrder("jobS_emap_emboss");

		// Executing the Control-M Jobs
		interfacePage.establishAndExecuteControlMJobs("ControlM_AWS_UAT", "ContorlM_AWS_userName",
				"ContorlM_AWS_password", folderName, jobsInOrder);

		// Get Recent Processed File from IE Server
		String fileName = commonInterfacePage.getEMAPRecentProcessedFileName(configProp, clientName, clientCountry,
				"EmbossCards");
		ifcsCommonPage.establishThePuttyConnection("incomingFile", "PUTTY_HOST", "PUTTY_USERNAME", "PUTTY_PASSWORD",
				"IE_OUTPUTFILE_FOLDER_CAF", fileName);
		System.out.println("fileNamefileName::" + fileName);
		String localFolder = System.getProperty("user.home") + "\\Documents\\" + fileName;

		// Validate new Card Present in a File
		interfacePage.updateOrValidateFlatFile(emapcardembossCongifProp, "incomingFile", localFolder, orderedCardNumber,
				clientName, clientCountry, "");

		// exit the application
		IFCSHomePage.exitIFCS();

	}
	// Prakalpha

	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "Smoke" })
	public void orderNewCardForNewCustomerWithNetOffRebateAndValidateCardEmbossing(@Optional("SG") String clientCountry,
			@Optional("EMAP") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  TST-SC-22-Create a New customer with net off rebate of CPL and Post Transaction",
				"EMAP Order Card for New Customer With NetOff Rebate and and validate New Card via CardEmbossing Job through ControlM");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		Common common = new Common(driver, test);
		MaintainCustomerPage maintaincustomerPage = new MaintainCustomerPage(driver, test);
		IFCSCommonPage ifcsCommonPage = new IFCSCommonPage(driver, test);
		InterfacePage interfacePage = new InterfacePage(driver, test);
		CommonInterfacePage commonInterfacePage = new CommonInterfacePage(driver, test);
		ApplicationsPage applicationPage = new ApplicationsPage(driver, test);
		TransactionListPage transactionListPage = new TransactionListPage(driver, test);

		// Logon the application
		IFCSloginPage.login("IFCS_URL_EMAP", "IFCS_EMAP_USERNAME", "IFCS_EMAP_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, " ");

		// Choose client from Application Page
		IFCSHomePage.gotoApplicationAndClickApplicationMenu();
		IFCSHomePage.gotoApplicationsMenuAndChooseClient(clientName + "_" + clientCountry);
		// common.chooseNameFromApplicationList("Freda Haag IV");
		common.chooseApplicationNumberFromApplicationList("TL APP approved");

		// Clear Existing application and Create a new application
		if (clientCountry.equals("HK")) {
			applicationPage.clearExistingFormAndCreateNewApplicationWithMandatoryField("0");
		} else {
			applicationPage.clearExistingFormAndCreateNewApplicationWithMandatoryField("random");
		}

		// get Date from IFCS
		String currentDate = common.getCurrentIFCSDateFromDB(clientName + clientCountry);
		String expiryDate = common.enterADateValueInStatusBeginDateField("WayFuture", currentDate);
		String ifcsCurrentDate = common.enterADateValueInStatusBeginDateField("Current", currentDate);

		// Create Card Offer In Application Page
		applicationPage.createCardOfferForNewApplication(clientCountry);

		// Choose Pricing Profile and Set as Default
		applicationPage.choosePricingFromCustomerProfile();
		applicationPage.pricingProfileSetDefaultForNewApplication();

		// Choose Card Reissue Profile and set as default
		maintaincustomerPage.chooseCardReissueProfileFromCustomerProfile();
		applicationPage.reissueProfileSetDefaultForNewApplication();

		// Verify and Approve the Application
		applicationPage.verifyNewApplicationToApprove();
		IFCSHomePage.gotoCustomerMenuCustomerDetails();

		// Create Rebate Profile and get RowNumber
		//maintaincustomerPage.createRebateProfile();
		int rownum = maintaincustomerPage.getRownumberAndCreateRebateProfile();
		System.out.println("rownum::"+rownum);
		if (rownum == -1) {
		
			maintaincustomerPage.enterDetailsInRebateProfilePopup(ifcsCurrentDate, expiryDate);
			
		}
		
		maintaincustomerPage.enterDetailsInRebateDetailsPopup("CPL All Sites - Net Off", ifcsCurrentDate, expiryDate,
				" ", " ", "3", "15", "1", "875968");
		common.clickOkButton();
		common.rightClickAndOptInout("Rebate Profiles", "Private");
		common.validateCheckBoxInTable("Rebate Profiles", "Opted Out");

		// Order a Card by filling mandatory info and create a profile
		if (clientCountry.equals("HK")) {
			maintaincustomerPage.fillMandatoryFieldsAndCreateProfile("Dual Card Vehicle", "0001", expiryDate, true,
					true);
		} else {
			maintaincustomerPage.fillMandatoryFieldsAndCreateProfile("Fleet Card", "0001", expiryDate, true, true);

		}

		
		 //Set Profile as default
		 // maintaincustomerPage.setPrivateProfileAsDefault("Profiles");
		 
		String orderedCardNumber = maintaincustomerPage.getCardNumberandValidateOrderedCard();
		System.out.println("Ordered Card Number::" + orderedCardNumber);

		// Card Embossing

		String folderName = ifcsCommonPage.getControlMFolder(clientName, clientCountry, "jobS_emap_emboss");
		String jobsInOrder = ifcsCommonPage.getJobsOfFolderInOrder("jobS_emap_emboss");

		// Executing the Control-M Jobs
		interfacePage.establishAndExecuteControlMJobs("ControlM_AWS_UAT", "ContorlM_AWS_userName",
				"ContorlM_AWS_password", folderName, jobsInOrder);

		// Get Recent Processed File from IE Server
		String fileName = commonInterfacePage.getEMAPRecentProcessedFileName(configProp, clientName, clientCountry,
				"EmbossCards");
		ifcsCommonPage.establishThePuttyConnection("incomingFile", "PUTTY_HOST", "PUTTY_USERNAME", "PUTTY_PASSWORD",
				"IE_OUTPUTFILE_FOLDER_CAF", fileName);
		System.out.println("fileNamefileName::" + fileName);
		String localFolder = System.getProperty("user.home") + "\\Documents\\" + fileName;

		// Validate new Card Present in a File
		interfacePage.updateOrValidateFlatFile(emapcardembossCongifProp, "incomingFile", localFolder, "7800344721286000015",
				clientName, clientCountry, "");

		// Manual Transaction Validation and Post the Suspended Transaction
		//System.out.println("Date ::" + ifcsCurrentDate);
		Faker fakerN = new Faker();
		String f_referenceNo = fakerN.number().digits(3);
		String locationNo = common.chooseALocationWithNonFuelProduct("Y");
		String productCode = common.chooseANonFuelProductExtCodeInTheLocation(locationNo, "Y", "externalCode");
		if (locationNo.equals(" ") && productCode.equals(" ")) {
			common.logForNoDataFound(this.getClass().getSimpleName(), "Need to Create A Cards with Account and rerun");
		} else {

			IFCSHomePage.gotoTransactionAndClickManageTransaction();
			if (clientCountry.equals("SG")) {
				/*transactionListPage.validateToPostManualTransactionEntry(ifcsCurrentDate, f_referenceNo, clientCountry,
						orderedCardNumber, "", locationNo, productCode, false);*/
				transactionListPage.enterTransactionBatchDetails(false,"160","1",clientName);
				transactionListPage.enterManualTransactionDetails(ifcsCurrentDate,f_referenceNo,orderedCardNumber,"",locationNo,"160","");
				transactionListPage.enterTransactionLineItems(productCode,"160","100","160");
				transactionListPage.validatePostManualTransaction("Validation successful");
			}
			/*transactionListPage.validateToPostManualTransactionEntry(ifcsCurrentDate, f_referenceNo, clientCountry,
					orderedCardNumber, orderedCardNumber, locationNo, productCode, false);*/
			transactionListPage.enterTransactionBatchDetails(false,"160","1",clientName);
			transactionListPage.enterManualTransactionDetails(ifcsCurrentDate,f_referenceNo,orderedCardNumber,"",locationNo,"160","");
			transactionListPage.enterTransactionLineItems(productCode,"160","100","160");
			transactionListPage.validatePostManualTransaction("Validation successful");
			transactionListPage.validatePostSuspendedtransaction(f_referenceNo);
			IFCSHomePage.gotoCustomerMenuCustomerDetails();
			transactionListPage.validateCustomerTransaction(orderedCardNumber, ifcsCurrentDate, f_referenceNo);

		}

		// exit the application
		IFCSHomePage.exitIFCS();

	}

	// Prakalpha
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "Smoke" })
	public void createFleetCardAndOrderNewCardAndValidateCardEmbossing(@Optional("GU") String clientCountry,
			@Optional("EMAP") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  TST-SC-51- Create Cards-Fleet",
				"EMAP Create FleetCards and Order New Card and validate New Card via CardEmbossing Job through ControlM");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		Common common = new Common(driver, test);
		MaintainCustomerPage maintaincustomerPage = new MaintainCustomerPage(driver, test);
		IFCSCommonPage ifcsCommonPage = new IFCSCommonPage(driver, test);
		InterfacePage interfacePage = new InterfacePage(driver, test);
		CommonInterfacePage commonInterfacePage = new CommonInterfacePage(driver, test);
		CardMaintenancePage cardMaintainPage = new CardMaintenancePage(driver, test);

		// Logon the application
		IFCSloginPage.login("IFCS_URL_EMAP", "IFCS_EMAP_USERNAME", "IFCS_EMAP_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, " ");

		// Update any field and validate Status of the card
		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		String cardNumber = common.getVehicleCardNumberFromDB(clientName + clientCountry);

		// Get expiry Date from IFCS
		String currentDate = common.getCurrentIFCSDateFromDB(clientName + clientCountry);
		String expiryDate = common.enterADateValueInStatusBeginDateField("WayFuture", currentDate);
		String replacedCard = cardMaintainPage.validatUpdateFieldsInCard(cardNumber, expiryDate);
		maintaincustomerPage.validateNewCardStatus(replacedCard);
		String cardStatus = maintaincustomerPage.getStatusforCard("Card List", "Status");
		System.out.println("Card Status::" + cardStatus);

		// To Get Mirated Customer number using application Type
		String receivedOn = common.getReceivedOnDateForMigratedCustomer();
		String migratedCustomerNo = common.getMigratedCustomerNo(receivedOn, clientCountry + " General");

		// filling mandatory info and create a profile
		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		common.chooseCustomerNoAndSearch(migratedCustomerNo);
		if (clientCountry.equals("GU")) {
			maintaincustomerPage.fillMandatoryFieldsAndCreateProfile("Fleet Card", "1501", " ", false, false);
		} else {
			maintaincustomerPage.fillMandatoryFieldsAndCreateProfile("Fleet Card", "0001", " ", false, false);
		}

	
		  //Set Profile as default
		  maintaincustomerPage.setPrivateProfileAsDefault("Private");
		 

		// Order A new Card
		String orderedCardNumber = maintaincustomerPage.getCardNumberandValidateOrderedCard();

		// New card Status
		maintaincustomerPage.validateNewCardStatus(orderedCardNumber);
		String NewcardStatus = maintaincustomerPage.getStatusforCard("Card List", "Status");
		System.out.println(NewcardStatus);
		common.validateSearchTable("Status", "Requested Not Issued", true);
		String cardNumbers = replacedCard + "," + orderedCardNumber;

		// Card Embossing
		String folderName = "";
		String jobsInOrder = "";

		if (clientCountry.equals("GU")) {
			folderName = ifcsCommonPage.getControlMFolder(clientName, clientCountry, "jobS_emap_SP_GU_emboss");

			jobsInOrder = ifcsCommonPage.getJobsOfFolderInOrder("jobS_emap_SP_GU_emboss");
		} else {
			folderName = ifcsCommonPage.getControlMFolder(clientName, clientCountry, "jobS_emap_emboss");

			jobsInOrder = ifcsCommonPage.getJobsOfFolderInOrder("jobS_emap_emboss");
		}

		// Executing the Control-M Jobs
		interfacePage.establishAndExecuteControlMJobs("ControlM_AWS_UAT", "ContorlM_AWS_userName",
				"ContorlM_AWS_password", folderName, jobsInOrder);

		// Get Recent Processed File from IE Server
		String fileName = commonInterfacePage.getEMAPRecentProcessedFileName(configProp, clientName, clientCountry,
				"EmbossCards");
		//String fileName="EMA1_SG_000045_20190812_094533.txt";
		ifcsCommonPage.establishThePuttyConnection("incomingFile", "PUTTY_HOST", "PUTTY_USERNAME", "PUTTY_PASSWORD",
				"IE_OUTPUTFILE_FOLDER_CAF", fileName);
		System.out.println("fileNamefileName::" + fileName);
		String localFolder = System.getProperty("user.home") + "\\Documents\\" + fileName;

		// Validate new Card Present in a File
		interfacePage.updateOrValidateFlatFile(emapcardembossCongifProp, "incomingFile", localFolder, cardNumbers,
				clientName, clientCountry, "");

		// exit the application
		//IFCSHomePage.exitIFCS();

	}

	// Prakalpha

	/*@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "Smoke" })
	public void createDualCardDriverAndOrderNewCardAndValidateCardEmbossing(@Optional("MO") String clientCountry,
			@Optional("EMAP") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  TST-SC-51- Create Cards- Dual Card Driver",
				"EMAP Create DualCard Driver and Order New Card and validate new card via CardEmbossing Job");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		Common common = new Common(driver, test);
		MaintainCustomerPage maintaincustomerPage = new MaintainCustomerPage(driver, test);
		IFCSCommonPage ifcsCommonPage = new IFCSCommonPage(driver, test);
		InterfacePage interfacePage = new InterfacePage(driver, test);
		CommonInterfacePage commonInterfacePage = new CommonInterfacePage(driver, test);
		CardMaintenancePage cardMaintainPage = new CardMaintenancePage(driver, test);

		// Logon the application
		IFCSloginPage.login("IFCS_URL_EMAP", "IFCS_EMAP_USERNAME", "IFCS_EMAP_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, " ");

		// Update any field and validate Status of the card
		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		String cardNumber = common.getVehicleCardNumberFromDB(clientName + clientCountry);

		// get expiry Date from IFCS
		String currentDate = common.getCurrentIFCSDateFromDB(clientName + clientCountry);
		String expiryDate = common.enterADateValueInStatusBeginDateField("WayFuture", currentDate);
		String replacedCard = cardMaintainPage.validatUpdateFieldsInCard(cardNumber, expiryDate);
		maintaincustomerPage.validateNewCardStatus(replacedCard);
		String cardStatus = maintaincustomerPage.getStatusforCard("Card List", "Status");
		System.out.println("Card Status::" + cardStatus);

		// To Get Mirated Customer number using application Type

		String receivedOn = common.getReceivedOnDateForMigratedCustomer();
		String migratedCustomerNo = common.getMigratedCustomerNo(receivedOn, "MO Fleet Customers");

		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		common.chooseCustomerNoAndSearch(migratedCustomerNo);

		// filling mandatory info and create a profile
		maintaincustomerPage.fillMandatoryFieldsAndCreateProfile("Dual Card Driver", "0001", " ", false, false);
		// maintaincustomerPage.setPrivateProfileAsDefault("Profiles");
		String orderedCardNumber = maintaincustomerPage.getCardNumberandValidateOrderedCard();
		maintaincustomerPage.validateNewCardStatus(orderedCardNumber);
		String NewcardStatus = maintaincustomerPage.getStatusforCard("Card List", "Status");

		System.out.println(NewcardStatus);

		String cardNumbers = replacedCard + "," + orderedCardNumber;

		// Card Embossing
		String folderName = "";
		String jobsInOrder = "";

		folderName = ifcsCommonPage.getControlMFolder(clientName, clientCountry, "jobS_emap_emboss");
		jobsInOrder = ifcsCommonPage.getJobsOfFolderInOrder("jobS_emap_emboss");

		// Executing the Control-M Jobs
		interfacePage.establishAndExecuteControlMJobs("ControlM_AWS_UAT", "ContorlM_AWS_userName",
				"ContorlM_AWS_password", folderName, jobsInOrder);

		// Get Recent Processed File from IE Server
		String fileName = commonInterfacePage.getEMAPRecentProcessedFileName(configProp, clientName, clientCountry,
				"EmbossCards");

		ifcsCommonPage.establishThePuttyConnection("incomingFile", "PUTTY_HOST", "PUTTY_USERNAME", "PUTTY_PASSWORD",
				"IE_OUTPUTFILE_FOLDER_CAF", fileName);
		System.out.println("fileNamefileName::" + fileName);
		String localFolder = System.getProperty("user.home") + "\\Documents\\" + fileName;

		// Validate new Card Present in a File
		interfacePage.updateOrValidateFlatFile(emapcardembossCongifProp, "incomingFile", localFolder, cardNumbers,
				clientName, clientCountry, "");

		// exit the application
		IFCSHomePage.exitIFCS();

	}

	// Prakalpha
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "Smoke" })
	public void createcardsDutyFreeAndOrderNewCardAndValidateCardEmbossing(@Optional("SG") String clientCountry,
			@Optional("EMAP") String clientName) {
		test = extent.createTest(clientName+ ":" +clientCountry+"  TST-SC-52- Create Cards-Duty Free",
				"EMAP Create DutyFree-Order New Card and validate New Card via CardEmbossing Job");

		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		Common common = new Common(driver, test);
		MaintainCustomerPage maintaincustomerPage = new MaintainCustomerPage(driver, test);
		IFCSCommonPage ifcsCommonPage = new IFCSCommonPage(driver, test);
		InterfacePage interfacePage = new InterfacePage(driver, test);
		CommonInterfacePage commonInterfacePage = new CommonInterfacePage(driver, test);
		CardMaintenancePage cardMaintainPage = new CardMaintenancePage(driver, test);

		// Logon the application
		IFCSloginPage.login("IFCS_URL_EMAP", "IFCS_EMAP_USERNAME", "IFCS_EMAP_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, " ");

		// Update any field and validate Status of the card
		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		String cardNumber = common.getVehicleCardNumberFromDB(clientName + clientCountry);

		// get expiry Date From IFCS
		String currentDate = common.getCurrentIFCSDateFromDB(clientName + clientCountry);
		String expiryDate = common.enterADateValueInStatusBeginDateField("WayFuture", currentDate);
		String replacedCard = cardMaintainPage.validatUpdateFieldsInCard(cardNumber, expiryDate);
		maintaincustomerPage.validateNewCardStatus(replacedCard);
		String cardStatus = maintaincustomerPage.getStatusforCard("Card List", "Status");
		System.out.println("Card Status::" + cardStatus);

		// To Get Mirated Customer number using application Type

		String receivedOn = common.getReceivedOnDateForMigratedCustomer();
		String migratedCustomerNo = common.getMigratedCustomerNo(receivedOn, "Duty Free Customer");

		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		common.chooseCustomerNoAndSearch(migratedCustomerNo);

		// filling mandatory info and create a profile
		maintaincustomerPage.fillMandatoryFieldsAndCreateProfile("Duty Free", "0001", " ", false, true);

		
		 * //Set Profile as default
		 * maintaincustomerPage.setPrivateProfileAsDefault("Profiles");
		 
		String orderedCardNumber = maintaincustomerPage.getCardNumberandValidateOrderedCard();
		maintaincustomerPage.validateNewCardStatus(orderedCardNumber);
		String NewcardStatus = maintaincustomerPage.getStatusforCard("Card List", "Status");
		System.out.println(NewcardStatus);
		common.validateSearchTable("Status", "Requested Not Issued", true);

		String cardNumbers = replacedCard + "," + orderedCardNumber;

		// Card Embossing
		String folderName = "";
		String jobsInOrder = "";

		folderName = ifcsCommonPage.getControlMFolder(clientName, clientCountry, "jobS_emap_emboss");
		jobsInOrder = ifcsCommonPage.getJobsOfFolderInOrder("jobS_emap_emboss");

		// Executing the Control-M Jobs
		interfacePage.establishAndExecuteControlMJobs("ControlM_AWS_UAT", "ContorlM_AWS_userName",
				"ContorlM_AWS_password", folderName, jobsInOrder);

		// Get Recent Processed File from IE Server
		String fileName = commonInterfacePage.getEMAPRecentProcessedFileName(configProp, clientName, clientCountry,
				"EmbossCards");

		ifcsCommonPage.establishThePuttyConnection("incomingFile", "PUTTY_HOST", "PUTTY_USERNAME", "PUTTY_PASSWORD",
				"IE_OUTPUTFILE_FOLDER_CAF", fileName);
		System.out.println("fileNamefileName::" + fileName);
		String localFolder = System.getProperty("user.home") + "\\Documents\\" + fileName;

		// Validate new Card Present in a File
		interfacePage.updateOrValidateFlatFile(emapcardembossCongifProp, "incomingFile", localFolder, cardNumbers,
				clientName, clientCountry, "");

		// exit the application
		IFCSHomePage.exitIFCS();

	}*/
}
