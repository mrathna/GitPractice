package com.framework.pages.AJS;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

import com.aventstack.extentreports.ExtentTest;
import com.framework.basepage.BasePage;
import com.framework.pages.AJS.common.Common;
import com.framework.pages.AJS.common.IFCSCommonPage;
import com.framework.pages.AJS.common.IFCSHomePage;
import com.framework.repo.Locator_IFCS;
import com.framework.util.PropUtils;
import com.framework.util.SeleniumWrappers;
import com.github.javafaker.Faker;

public class TransactionListPage extends BasePage {

	@FindBy(xpath=Locator_IFCS.SEARCH_CARDS_TEXTBOX)
	public List<WebElement> textBoxes;

	@FindBy(xpath = Locator_IFCS.SEARCH_RESULTS_TABLE)
	public List<WebElement> cardsTable;

	@FindBy(xpath = Locator_IFCS.CARDS_TABLE_HEADER)
	public List<WebElement> cardsTableHeaders;
	// Added 4/4/2019
	@FindBy(xpath = Locator_IFCS.TRANSACTION_TABLE)
	public WebElement transactionTable;

	@FindBy(xpath = Locator_IFCS.LINE_ITEMS_TABLE)
	public WebElement lineItemsTable;

	@FindBy(xpath = Locator_IFCS.ADMIN_MENU)
	public WebElement adminMenu;

	@FindBy(xpath = Locator_IFCS.CLIENT_SUBMENU)
	public WebElement clientMenu;

	@FindBy(xpath = Locator_IFCS.BOTTOM_LEFT_TEXT)
	public WebElement bottomLeftText;

	@FindBy(how = How.XPATH, using = Locator_IFCS.DRIVERNAME_CARDMAINTENANCE)
	public WebElement driverNameCardMaintenance;
	@FindBy(how = How.XPATH, using = Locator_IFCS.SHORTNAME_CARDMAINTENANCE)
	public WebElement shortNameCardMaintenance;

	@FindBy(how = How.XPATH, using = Locator_IFCS.DATE_RANGE)
	public List<WebElement> dateRange;

	IFCSCommonPage ifcsCommonPage = new IFCSCommonPage(driver, test);

	public TransactionListPage(WebDriver driver, ExtentTest test) {
		super(driver, test);
		PageFactory.initElements(new AjaxElementLocatorFactory(driver, 15), this);

	}

	String toAvailableBalance;
	String fromAvailableBalance;
	String amountInput;
	double amt;
	Faker fakerN = new Faker();
	String referenceNo = fakerN.number().digits(3);

	Common common = new Common(driver, test);
	MaintainCustomerPage maintainCustomer = new MaintainCustomerPage(driver, test);

	IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);

	String labelAccountToAccount[] = { "Amount", "Status", "Available Balance", "Name", "Account No", "Status",
			"Available Balance", "Name", "Account No", "Transfer Type" };
	String labelAccountToCard[] = { "Amount", "Status", "Available Balance", "Name", "Card No", "Status",
			"Available Balance", "Name", "Account No", "Transfer Type" };
	String labelCardToAccount[] = { "Amount", "Status", "Available Balance", "Name", "Account No", "Status",
			"Available Balance", "Name", "Card No", "Transfer Type" };
	String cardtoCardTransferLabel[] = { "Amount", "Status", "Available Balance", "Name", "Card No", "Status",
			"Available Balance", "Name", "Card No", "Transfer Type" };

	public void verifyFundTransferAccountToAccount(String fromTypeNo, String toTypeNo, String validationMessage,
			boolean insufficentType) {
		chooseSubMenuFromLeftPanel("Client Transactions", "Funds Transfer");
		chooseOptionFromComboPopup("Transfer", "Account to Account");
		sleep(10);// Must Add sleep
		validateFundTransferLabels(labelAccountToAccount);
		sleep(10);
		common.enterDetailsWithSameLabelName("From", "Account No", fromTypeNo);
		common.enterDetailsWithSameLabelName("To", "Account No", toTypeNo);
		if (insufficentType) {
			double reduceAmt = 0.0;
			try {
				double debit;
				System.out.println("goin");
				driver.navigate().refresh();
				WebElement availableBalanceFields = driver.findElement(By.xpath(
						"//div[@class='JFALSeparator']/preceding::div[@class='JFALLabel']/div[contains(text(),'Available') and contains(text(),'Balance')]/preceding::div[@class='JFALCompControlPanel'][1]//div[@class='htmlString']"));
				fromAvailableBalance = availableBalanceFields.getText();
				System.out.println("after");
				debit = Double.parseDouble(fromAvailableBalance);
				reduceAmt = debit + 1;
				String amount = Double.toString(reduceAmt);
				System.out.println("amount : " + amount);
				common.enterDetailsWithSameLabelName("Transfer", "Amount", amount);
				sleep(5);
//				logPass("To Available Balance " + reduceAmt);
			} catch (Exception ex) {
				logFail(ex.getMessage());
			}
		} else {
			common.enterDetailsWithSameLabelName("Transfer", "Amount", "2");
			sleep(5);
		}
		validateFieldProtectedForTransferLabel("Available Balance");
		validateFieldProtectedForTransferLabel("Name");
		validateFieldProtectedForTransferLabel("Status");
		validateTextFieldIsEditable("Reference");
		sleep(2);
		common.clickValidateIcon();
		sleep(2);
		verifyValidationResult(validationMessage);

	}

	public void validateFundTransferInCardToCard(String fromTypeNo, String toTypeNo, String validationMessage,
			boolean insufficentType) {
		chooseSubMenuFromLeftPanel("Client Transactions", "Funds Transfer");
		chooseOptionFromDropdown("Transfer Type", "Card to Card");
		sleep(5);
		validateFundTransferLabels(cardtoCardTransferLabel);
		sleep(2);
		common.enterDetailsWithSameLabelName("From", "Card No", fromTypeNo);
		sleep(2);
		common.enterDetailsWithSameLabelName("To", "Card No", toTypeNo);
		if (insufficentType) {
			double reduceAmt = 0.0;
			try {
				double debit;
				System.out.println("goin");
				driver.navigate().refresh();
				WebElement availableBalanceFields = driver.findElement(By.xpath(
						"//div[@class='JFALSeparator']/preceding::div[@class='JFALLabel']/div[contains(text(),'Available') and contains(text(),'Balance')]/preceding::div[@class='JFALCompControlPanel'][1]//div[@class='htmlString']"));
				fromAvailableBalance = availableBalanceFields.getText();
				System.out.println("after");
				debit = Double.parseDouble(fromAvailableBalance);
				reduceAmt = debit + 1;
				String amount = Double.toString(reduceAmt);
				System.out.println("amount : " + amount);
				common.enterDetailsWithSameLabelName("Transfer", "Amount", amount);
				sleep(5);
			} catch (Exception ex) {
				logFail(ex.getMessage());
			}
		} else {
			common.enterDetailsWithSameLabelName("Transfer", "Amount", "2");
			sleep(5);
		}
		validateFieldProtectedForTransferLabel("Name");
		validateFieldProtectedForTransferLabel("Status");
		validateFieldProtectedForTransferLabel("Available Balance");
		validateTextFieldIsEditable("Reference");
		common.clickValidateIcon();
		sleep(2);
		verifyValidationResult(validationMessage);
		common.clickPostTransaction();
		sleep(5);

	}

	public void verifyFundTransferCardToAccount(String cardNo, String accountNo, String validationMessage) {

		chooseSubMenuFromLeftPanel("Client Transactions", "Funds Transfer");
		chooseOptionFromDropdown("Transfer Type", "Card to Account");
		sleep(5);// Must Add sleep
		// validateFundTransferLabels(labelCardToAccount);
		// sleep(5);
		common.enterValueInTextBox("From", "Card No", cardNo);
		common.enterValueInTextBox("To", "Account No", accountNo);
		common.enterValueInTextBox("Transfer", "Amount", "2");
		sleep(5);
		validateFieldProtectedForTransferLabel("Available Balance");
		validateFieldProtectedForTransferLabel("Name");
		validateFieldProtectedForTransferLabel("Status");
		validateTextFieldIsEditable("Reference");
		sleep(2);
		common.clickValidateIcon();
		validateTransactionMessage();
		// verifyValidationResult(validationMessage);

		sleep(3);
	}

	public void verifyFundTransferAccountToCard(String accountNo, String cardNo, String validationMessage) {

		chooseSubMenuFromLeftPanel("Client Transactions", "Funds Transfer");
		chooseOptionFromComboPopup("Transfer", "Account to Card");
		sleep(10);// Must Add sleep
		validateFundTransferLabels(labelAccountToCard);
		sleep(10);
		common.enterDetailsWithSameLabelName("From", "Account No", accountNo);
		common.enterDetailsWithSameLabelName("To", "Card No", cardNo);
		common.enterDetailsWithSameLabelName("Transfer", "Amount", "2");
		sleep(10);
		validateFieldProtectedForTransferLabel("Available Balance");
		validateFieldProtectedForTransferLabel("Name");
		validateFieldProtectedForTransferLabel("Status");
		validateTextFieldIsEditable("Reference");
		sleep(2);
		common.clickValidateIcon();
		verifyValidationResult(validationMessage);
		sleep(3);
	}

	public void validateCreditAndDebitAmount(String fromType, String toType, String fromTypeNo, String toTypeNo,
			String expectedDropDown) {
		try {

			double creditAvailableBalances = getAmountCreditedToAvailableBalance();
			System.out.println("After credit account" + creditAvailableBalances);
			sleep(5);
			double debitAvailableBalances = getAmountDebitedFromAvailableBalance();
			System.out.println("After Debit Account" + debitAvailableBalances);
			sleep(5);
			chooseSubMenuFromLeftPanel("Client Transactions", "Funds Transfer");
			chooseOptionFromComboPopup("Transfer", expectedDropDown);
			common.enterDetailsWithSameLabelName("From", fromType, fromTypeNo);
			common.enterDetailsWithSameLabelName("To", toType, toTypeNo);
			common.enterDetailsWithSameLabelName("Transfer", "Amount", " ");

			WebElement elementTo = driver.findElement(By.xpath(
					"//div[ (text()='To')]/preceding::div[@class='JFALLabel']/div[ starts-with(text(),'Available')and contains(text(),'Balance')]/preceding::div[@class='JFALCompControlPanel'][1]/div/input"));
			// List<WebElement>availableBalanceFields=driver.findElements(By.xpath("//div[
			// (text()='From')]/preceding::div[@class='JFALLabel']/div[
			// starts-with(text(),'Available')and
			// contains(text(),'Balance')]/preceding::div[@class='JFALCompControlPanel'][1]"));
			// toAvailableBalance = availableBalanceFields.get(0).getText();
			toAvailableBalance = elementTo.getAttribute("submittedvalue");
			// System.out.println("after clearing to balance"+toAvailableBalance);
			WebElement elementFrom = driver.findElement(By.xpath(
					"//div[@class='JFALSeparator']//div[ (text()='From')]/preceding::div[@class='JFALLabel']/div[ starts-with(text(),'Available')and contains(text(),'Balance')]/preceding::div[@class='JFALCompControlPanel'][6]//input"));
			// fromAvailableBalance =availableBalanceFields.get(1).getText();
			fromAvailableBalance = elementFrom.getAttribute("submittedvalue");
			// System.out.println("after clearing from balance"+fromAvailableBalance);
			if (creditAvailableBalances == Double.parseDouble(toAvailableBalance)
					&& debitAvailableBalances == Double.parseDouble(fromAvailableBalance)) {
				logPass("Available Balance Credited and Debited");
			} else {
				logFail("Available Balance not Credited And Debited");
			}

		} catch (Exception e) {
			logFail(e.getMessage());
		}

	}

	public void verifyFundTransferSuccessfulMessage(String fromType, String toType, String type) {
		try {
			String fromInput;
			String toInput;

			String validatetransferMessage = " ";

			fromInput = getValueFromTextBox("From", fromType);
			// System.out.println("From " +fromType +fromInput);
			toInput = getValueFromTextBox("To", toType);
			// System.out.println("To "+toType +toInput);

			amountInput = getValueFromTextBox("Transfer", "Amount");

			if (type.equalsIgnoreCase("AccToAcc")) {
				validatetransferMessage = "Funds transfer successful " + amountInput + " from Account: " + fromInput
						+ " to Account:" + toInput + ".";
				System.out.println(validatetransferMessage);
			} else if (type.equalsIgnoreCase("AccToCard")) {
				validatetransferMessage = "Funds transfer successful " + amountInput + " from Account: " + fromInput
						+ " to Card:" + toInput + ".";
				System.out.println(validatetransferMessage);
			} else if (type.equalsIgnoreCase("CardToAcc")) {
				validatetransferMessage = "Funds transfer successful " + amountInput + " from Card: " + fromInput
						+ " to Account:" + toInput + ".";
				System.out.println(validatetransferMessage);
			} else if (type.equalsIgnoreCase("CardToCard")) {
				validatetransferMessage = "Funds transfer successful " + amountInput + " from Card: " + fromInput
						+ " to Card:" + toInput + ".";
				System.out.println(validatetransferMessage);
			}

			verifyValidationResult(validatetransferMessage);

		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
	}

	public double getAmountCreditedToAvailableBalance() {
		double addedAmt = 0.0;
		try {

			double credit;

			WebElement element = driver.findElement(By.xpath(
					"//div[ (text()='To')]/preceding::div[@class='JFALLabel']/div[ starts-with(text(),'Available')and contains(text(),'Balance')]/preceding::div[@class='JFALCompControlPanel'][1]/div/input"));
			// List<WebElement>availableBalanceFields=driver.findElements(By.xpath("//div[
			// (text()='From')]/preceding::div[@class='JFALLabel']/div[
			// starts-with(text(),'Available')and
			// contains(text(),'Balance')]/preceding::div[@class='JFALCompControlPanel'][1]"));
			// toAvailableBalance = availableBalanceFields.get(0).getText();
			toAvailableBalance = element.getAttribute("submittedvalue");
			credit = Double.parseDouble(toAvailableBalance);
			// System.out.println("Before parsing"+toAvailableBalance);
			// toAvailableBalance=getText(element);

			amountInput = getValueFromTextBox("Transfer", "Amount");
			// System.out.println("Before parsing AMOUNT"+amountInput);
			amt = Double.parseDouble(amountInput);
			// System.out.println("before addtion of amt" +amt);
			addedAmt = credit + amt;
			// System.out.println("beforeCreditReturn"+addedAmt);
			logPass("To Available Balance " + addedAmt);
		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
		return addedAmt;
	}

	public double getAmountDebitedFromAvailableBalance() {
		double reduceAmt = 0.0;
		try {
			double debit;
			WebElement element = driver.findElement(By.xpath(
					"//div[@class='JFALSeparator']//div[ (text()='From')]/preceding::div[@class='JFALLabel']/div[ starts-with(text(),'Available')and contains(text(),'Balance')]/preceding::div[@class='JFALCompControlPanel'][6]//input"));
			// fromAvailableBalance =availableBalanceFields.get(1).getText();
			fromAvailableBalance = element.getAttribute("submittedvalue");
			debit = Double.parseDouble(fromAvailableBalance);
			// System.out.println("Before parsing"+fromAvailableBalance);

			amountInput = getValueFromTextBox("Transfer", "Amount");
			// System.out.println("Before parsing AMOUNT"+amountInput);
			amt = Double.parseDouble(amountInput);
			// System.out.println("before sub of amt" +amt);
			reduceAmt = debit - amt;
			// System.out.println("Before Debit return"+reduceAmt);
			logPass("To Available Balance " + reduceAmt);
		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
		return reduceAmt;
	}

	public void validateFieldProtectedForTransferLabel(String labelName) {

		String label = " ";
		List<WebElement> protectedFields;
		String text = " ";
		String color;
		String hexColorS;
		try {

			label = splitStringAndGenerateXpath(labelName);
			protectedFields = driver
					.findElements(By.xpath("//div[@class='JFALSeparator']/preceding::div[@class='JFALLabel']/div["
							+ label + "]/preceding::div[@class='JFALCompControlPanel'][1]//div[@class='htmlString']"));
			int protectedFieldsSize = protectedFields.size();
			for (int i = 0; i < protectedFieldsSize; i++) {
				color = protectedFields.get(i).getCssValue("color");
				System.out.println(color);
				hexColorS = convertrgbColorToHex(color);
				System.out.println(hexColorS);
				if (hexColorS.equals("#b8cfe5")) {
					logPass("Field is Protected");
					text = protectedFields.get(i).getText();
					logPass("Protected Text value for " + text);
				} else
					logFail("Field is not Protected");
			}

		} catch (Exception ex) {
			logFail(ex.getMessage());
		}

	}

//To Validate and compare all label name is matched

	public void validateFundTransferLabels(String label[]) {

		try {
			List<WebElement> labelName = driver
					.findElements(By.xpath("//div[@class='JFALLabel']/div[@class='htmlString']"));
			int labelSize = labelName.size();
			logPass("Size of the tab" + labelSize);
			for (int j = 0; j < label.length; j++) {
				for (int k = 0; k < labelSize; k++) {
					if (label[j].equals(labelName.get(k).getText())) {
						System.out.println(labelName.get(k).getText());
						break;
					}
				}
			}
			logPass("All LabelNames are Validated");
		} catch (Exception ex) {
			logFail(ex.getMessage());
		}

	}

	public void verifyColumnDetailsInTableForTransaction() {
		// sleep(5);
		chooseSubMenuFromLeftPanel("Client Transactions", "Transactions");
		// Click(transactionsSubMenu,"Transaction SubMenu");
		common.validateHeaderLabel("Transactions");
		// validateTableHeaderValues("Transaction Summary","Customer No,Card
		// Number,Transaction Type,Ref,Location No,Cost
		// C...,Effectiv...,Proces...,Customer ...,Merchant T...,Points,Atte...");
		validateTableHeaderValues("Transaction Summary",
				"Customer No,Card Number,Transaction Type,Ref,Location No,Cost Centre,Effective ...,Processe...,Customer Total,Merchant Total,Points,Atten...");
	}

	public void verifyColumnsOnScreenforBankingStatements() {

		sleep(5);
		chooseSubMenuFromLeftPanel("Banking Statements", "");
		common.validateHeaderLabel("Banking Statements");
		validateTableHeaderValues("Statements",
				"Description,Statement No,Opening Balance Date,Closing Balance Date,Opening Balance,Closing Balance,Difference");
	}

	public void drillDownToDetailsOfTransaction() {
		chooseSubMenuFromLeftPanel("Customer Transactions", "Transactions");

		common.clickDetailSearchIfFilterFieldsNotPresent();
		sleep(3);
		chooseOptionFromDropdown("Transaction Type", "Purchase");
		common.searchListTorch();
		// verifyValidationResult("Record Read OK - Page Size 250 Rows");
		verifyValidationResult("Record read OK");
		common.selectFirstRowNumberInSearchList();
		// waitUntilElementDisplayed(driver.findElement(By.xpath("//div[@class='SimpleInternalFrame_GradientPanel']//div[@class='htmlString'][contains(text(),'Transaction')
		// and contains(text(),'Detail')]")));
	}

	public void verifyDetailsInTransactionInformationTab() {
		switchTabDetails("Transaction Information");
		System.out.println("Transaction Information");
		validateTextFieldsAreProtectedInATab();
		common.validateComboDropDownFieldIsProtected("Header Details", "Transaction Status");
		common.validateComboDropDownFieldIsProtected("Header Details", "Capture Type");
		common.validateComboDropDownFieldIsProtected("Header Details", "Transaction Currency");
	}

	public void verifyDetailsInCustomerBreakdown() {
		sleep(5);
		switchTabDetails("Customer Breakdown");
		System.out.println("Customer Breakdown");
		validateTextFieldsAreProtectedInATab();
		sleep(5);
	}

	public void verifyDetailsInMerchantBreakdown() {
		sleep(5);
		switchTabDetails("Merchant Breakdown");
		System.out.println("Merchant Breakdown");
		validateTextFieldsAreProtectedInATab();

	}

	public void verifyFilterConditionforTransactions(String clientName, String clientCountry) {
		chooseSubMenuFromLeftPanel("Transactions", "");
		common.validateHeaderLabel("Transactions");
		common.clickDetailSearchIfFilterFieldsNotPresent();
		sleep(5);
		int rowNumber = SeleniumWrappers.getTotalNumberOfRows(
				driver.findElements(By.xpath("//div[@class='FALTableCellEditor_StrikeThruField JTextComponent']")),
				driver);
		if (rowNumber == 0) {
			logFail("No Transaction has been processed for this client ");

		} else {
			String cusNo = common.getSpecifiedColValueInSearchTable("Customer No");
			enterInputAndValidateFilterTable("Transaction Filter Fields", "Customer No", "Customer No", cusNo);
			common.clearingAllTextBoxes(textBoxes);
			common.searchListTorch();

			String loc = common.getSpecifiedColValueInSearchTable("Location No");

			enterInputAndValidateFilterTable("Transaction Filter Fields", "Location No", "Location No", loc);
			common.clearingAllTextBoxes(textBoxes);
			common.searchListTorch();

			String cardNo = common.getSpecifiedColValueInSearchTable("Card Number");

			enterInputAndValidateFilterTable("Transaction Filter Fields", "Card Number", "Card Number", cardNo);
			common.clearingAllTextBoxes(textBoxes);
			common.searchListTorch();

			String refNo = common.getSpecifiedColValueInSearchTable("Ref");
			refNo = common.getPartialValue(refNo);
			common.validateSearchTablePresence("Transaction Filter Fields");
			common.clearingAllTextBoxes(textBoxes);
			common.searchListTorch();

			// String effDate =common.getSpecifiedColValueInSearchTable("Effectiv...");
			String currentIFCSDateforEffAt = common.getCurrentIFCSDateFromDB(clientName + clientCountry);
			String effAt = common.enterADateValueInStatusBeginDateField("Current", currentIFCSDateforEffAt);
			sleep(3);
			enterInputAndValidateTablePresence("Transaction Filter Fields", "Effective Date To", effAt, "Effectiv...");
			common.clearingAllTextBoxes(textBoxes);
			common.searchListTorch();

			// String processAt =common.getSpecifiedColValueInSearchTable("Proces...");
			String currentIFCSDateForProcessAt = common.getCurrentIFCSDateFromDB(clientName + clientCountry);
			String processAt = common.enterADateValueInStatusBeginDateField("Current", currentIFCSDateForProcessAt);
			sleep(3);
			enterInputAndValidateTablePresence("Transaction Filter Fields", "Process Date To", processAt, "Proces...");
			common.clearingAllTextBoxes(textBoxes);
			common.searchListTorch();
			sleep(3);
			// String transType=common.getSpecifiedColValueInSearchTable("Transaction
			// Type");
			chooseOptionAndValidateFilterTable("Transaction Type", "Transaction Type", "Purchase");
		}
	}

	public void chooseOptionAndValidateFilterTable(String labelName, String colHeaderName, String option) {
		chooseOptionFromDropdown(labelName, option);
		common.searchListTorch();
		sleep(3);
		common.validateSearchTable(colHeaderName, "SH " + option, true);
	}

	public void enterInputAndValidateFilterTable(String seperatorLabelName, String labelName, String colHeaderName,
			String input) {
		common.clearingAllTextBoxes(textBoxes);
		enterValueInTextBox(seperatorLabelName, labelName, input);
		common.searchListTorch();
		sleep(5);
		common.validateSearchTable(colHeaderName, input, true);
	}

	// added by sasi 20-02-19
	public void verifyingTheDetailsOfBankingStatements() {

		String statementNo;
		String description;

		sleep(5);

		chooseSubMenuFromLeftPanel("Banking Statements", "");
		common.clickDetailSearchIfFilterFieldsNotPresent();
		sleep(5);
		int rowNumber = SeleniumWrappers.getTotalNumberOfRows(
				driver.findElements(By.xpath("//div[@class='FALTableCellEditor_StrikeThruField JTextComponent']")),
				driver);
		if (rowNumber == 0) {
			logFail("No Transaction has been processed for this client ");

		} else {

			statementNo = common.getSpecifiedColValueInSearchTable("Statement No");
			description = common.getSpecifiedColValueInSearchTable("Description");
			System.out.println("expectedValue  :  " + statementNo);
			System.out.println("expectedValue  :  " + description);
			common.selectFirstRowNumberInSearchList();
			System.out.println("going to check finance text box");
			sleep(5);
			common.verifyValueInTextBox("Filter By", "Statement No", statementNo);
			System.out.println("going to check finance table statementNo");
			sleep(5);
			common.validateSearchTableWhenMultipleTablePresents("Financial Transactions", "Statem...", statementNo,
					true);
			System.out.println("going to check finance table description");
			common.validateSearchTableWhenMultipleTablePresents("Financial Transactions", "Bankin...", description,
					true);

		}
	}

	public void verifyFilterConditionforBankingSatements() {

		chooseSubMenuFromLeftPanel("Banking Statements", "");

		common.validateHeaderLabel("Banking Statements");
		common.clickDetailSearchIfFilterFieldsNotPresent();
		sleep(5);
		int rowNumber = SeleniumWrappers.getTotalNumberOfRows(
				driver.findElements(By.xpath("//div[@class='FALTableCellEditor_StrikeThruField JTextComponent']")),
				driver);
		if (rowNumber == 0) {
			logFail("No Transaction for this client ");

		} else {

			String statementNo = common.getSpecifiedColValueInSearchTable("Statement No");
			enterInputAndValidateFilterTable("Filtered By", "Statement No", "Statement No", statementNo);
			common.clearingAllTextBoxes(textBoxes);
			common.searchListTorch();
			sleep(5);

			String openingbalancedate = common.getSpecifiedColValueInSearchTable("Opening Balance Date");
			enterInputAndValidateTablePresence("Filtered By", "Opening Balance Date From", openingbalancedate,
					"Statements");
			common.clearingAllTextBoxes(textBoxes);

			common.searchListTorch();
			sleep(5);

			String closingbalancedate = common.getSpecifiedColValueInSearchTable("Closing Balance Date");
			enterInputAndValidateTablePresence("Filtered By", "Closing Balance Date From", closingbalancedate,
					"Statements");
			common.clearingAllTextBoxes(textBoxes);

			common.searchListTorch();
			sleep(5);

			String openingbalanceTodate = common.getSpecifiedColValueInSearchTable("Closing Balance Date");
			enterInputAndValidateTablePresence("Filtered By", "Opening Balance Date To", openingbalanceTodate,
					"Statements");
			common.clearingAllTextBoxes(textBoxes);

			common.searchListTorch();
			sleep(5);

			String closingbalanceTodate = common.getSpecifiedColValueInSearchTable("Closing Balance Date");
			enterInputAndValidateTablePresence("Filtered By", "Closing Balance Date To", closingbalanceTodate,
					"Statements");
			common.clearingAllTextBoxes(textBoxes);

			common.searchListTorch();
			sleep(5);

		}
	}

	public void verifyColumnsOnScreenforSuspendedTran() {
		sleep(5);
		chooseSubMenuFromLeftPanel("Suspended Transactions", "");
		validateHeaderLabel("Suspended Transactions");
		validateTableHeaderValues("Suspended Transaction Summary",
				"Location,External Code,Batch Nu...,Reference,Admin Territory,State,Transaction Error,Suspense St...,Effective Date,Processed At");
	}

	public void enterInputAndValidateTablePresence(String seperator, String label, String input,
			String tableSeperator) {
		common.clearingAllTextBoxes(textBoxes);
		enterValueInTextBox(seperator, label, input);
		common.searchListTorch();
		sleep(3);
		common.validateSearchTablePresence(tableSeperator);
	}

	public void validateLocationSearchTable(String expectedValue) {
		try {
			int totalRowsInTable = SeleniumWrappers.getTotalNumberOfRows(cardsTable, driver);

			int locColIndex = SeleniumWrappers.getColumnNoForColumnHeader("Location", cardsTableHeaders);

			int extColIndex = SeleniumWrappers.getColumnNoForColumnHeader("External Code", cardsTableHeaders);

			for (int i = 0; i <= totalRowsInTable - 1; i++) {
				if (SeleniumWrappers.getTableDataWithRowAndColumnNumber(locColIndex, i, driver)
						.equalsIgnoreCase(expectedValue)
						|| SeleniumWrappers.getTableDataWithRowAndColumnNumber(extColIndex, i, driver)
								.equalsIgnoreCase(expectedValue)) {
					logPass("Expected value present in LocationRow: " + i + " Col: " + locColIndex
							+ "Expected value present in External Code Row: " + i + "col: " + extColIndex
							+ "Expected:: " + expectedValue + "Location Actual::"
							+ SeleniumWrappers.getTableDataWithRowAndColumnNumber(locColIndex, i, driver)
							+ "External Code Actual:: "
							+ SeleniumWrappers.getTableDataWithRowAndColumnNumber(extColIndex, i, driver));
				} else {
					logFail("\"Expected value Not present in LocationRow: " + i + " Col: " + locColIndex
							+ "Expected value present in External Code Row: " + i + "col: " + extColIndex
							+ "Expected:: " + expectedValue + "Location Actual::"
							+ SeleniumWrappers.getTableDataWithRowAndColumnNumber(locColIndex, i, driver)
							+ "External Code Actual:: "
							+ SeleniumWrappers.getTableDataWithRowAndColumnNumber(extColIndex, i, driver));

				}

			}
		} catch (Exception e) {
			logFail(e.getMessage());
		}
	}

	public void verifyFilterConditionforSuspendedTran() {
		chooseSubMenuFromLeftPanel("Suspended Transactions", "");

		validateHeaderLabel("Suspended Transactions");
		common.clickDetailSearchIfFilterFieldsNotPresent();
		sleep(5);
		int rowNumber = SeleniumWrappers.getTotalNumberOfRows(
				driver.findElements(By.xpath("//div[@class='FALTableCellEditor_StrikeThruField JTextComponent']")),
				driver);
		if (rowNumber == 0) {
			logFail("No Transaction has been processed for this client ");

		} else {
			String loc = common.getSpecifiedColValueInSearchTable("Location");
			common.clearingAllTextBoxes(textBoxes);
			enterValueInTextBox("Filter By", "Location", loc);
			sleep(3);
			common.searchListTorch();
			sleep(3);
			validateLocationSearchTable(loc);
			sleep(5);
			common.clearingAllTextBoxes(textBoxes);
			common.searchListTorch();
			sleep(3);

			String batch = common.getSpecifiedColValueInSearchTable("Batch Nu...");
			enterInputAndValidateFilterTable("Filter By", "Batch Number", "Batch Nu...", batch);
			common.clearingAllTextBoxes(textBoxes);
			common.searchListTorch();
			sleep(3);

			String effDate = common.getSpecifiedColValueInSearchTable("Effective Date");
			enterInputAndValidateTablePresence("Filter By", "Process Date From", effDate,
					"Suspended Transaction Summary");
			common.clearingAllTextBoxes(textBoxes);
			common.searchListTorch();
			sleep(3);

			String processAt = common.getSpecifiedColValueInSearchTable("Processed At");
			enterInputAndValidateTablePresence("Filter By", "Process Date To", processAt,
					"Suspended Transaction Summary");
			common.clearingAllTextBoxes(textBoxes);
			common.searchListTorch();
			sleep(3);

			String ref = common.getSpecifiedColValueInSearchTable("Reference");
			enterInputAndValidateFilterTable("Filter By", "Reference No", "Reference", ref);
			common.clearingAllTextBoxes(textBoxes);
			common.searchListTorch();
			sleep(3);

			chooseOptionFromDropdown("Transaction Error", "random");
			common.searchListTorch();
			sleep(3);
			verifyValidationResult("Details not found");
			chooseBlankOptionFromDropdown("Transaction Error");
			common.searchListTorch();
		}
	}

	public void deleteTheSuspendedTransaction() {
		chooseSubMenuFromLeftPanel("Suspended Transactions", "");

		validateHeaderLabel("Suspended Transactions");
		int rowNumber = SeleniumWrappers.getTotalNumberOfRows(
				driver.findElements(By.xpath("//div[@class='FALTableCellEditor_StrikeThruField JTextComponent']")),
				driver);
		if (rowNumber == 0) {
			logFail("No Transaction has been processed for this client ");

		} else {

			common.selectFirstRowNumberInSearchList();

			validatePopupHeaderText("Suspended Transaction");
			validateLabelsinSuspendedTranPopup();

			common.clickDeleteTransactionInPopup();
			sleep(5);
			validateDropdownProtectedTextInPopup("Suspense Status", "Deleted");
			common.clickOkButton();
			sleep(10);
			common.verifyValidationResultInPopUp("Record deleted OK ");

		}

	}

	public void verifySuspendedTransactionLabelsInPopup() {
		sleep(5);
		chooseSubMenuFromLeftPanel("Suspended Transactions", "");

		validateHeaderLabel("Suspended Transactions");
		int rowNumber = SeleniumWrappers.getTotalNumberOfRows(
				driver.findElements(By.xpath("//div[@class='FALTableCellEditor_StrikeThruField JTextComponent']")),
				driver);
		if (rowNumber == 0) {
			logFail("No Transaction has been processed for this client ");

		} else {
			common.clickDetailSearchIfFilterFieldsNotPresent();
			common.selectFirstRowNumberInSearchList();
			/*
			 * List<WebElement> list = driver .findElements(By.
			 * xpath("//div[@class='FALTableCellEditor_StrikeThruField JTextComponent']"));
			 * 
			 * 
			 * WebElement cellElement = SeleniumWrappers.getTableDataWithCellElement(5, 0,
			 * driver); doubleClick(cellElement);
			 */
			validatePopupHeaderText("Suspended Transaction");
			validateLabelsinSuspendedTranPopup();
			validateTableHeaderValues("Suspended Transaction Line Item Summary",
					"Produc...,Product Description,Quantity,Unit Price,Discou...,Discou...,Origina...,Tax Rat...,Net Co...");
			common.clickOkButton();
			sleep(5);
		}
	}

	public void validateLabelsinSuspendedTranPopup() {
		validateLabelText("Location");
		common.validateComboDropDownFieldIsProtected("Details", "Suspense Status");
		validateLabelText("Batch Number");
		validateLabelText("Reference");
		common.validateComboDropDownFieldIsProtected("Details", "Transaction Error");
		validateLabelText("Transaction Code");
		validateLabelText("Capture Type");
		validateLabelText("External Supplier ID");
		validateFieldIsProtected("Details", "Processed At");
		validateLabelText("Effective Date");
		validateLabelText("Card Number");
		validateLabelText("Odometer");
		validateLabelText("Vehicle ID");
		validateLabelText("Driver Id");
		validateLabelText("Order No");
		validateLabelText("Customer Reference");
		validateLabelText("Auth No");
		validateLabelText("Notes");
		validateLabelText("Original Amount");
	}

	public void validatePostedSundryadjustmentTransaction(String ifcsDate, String referenceNo) {
		chooseSubMenuFromLeftPanel("Client Transactions", "Transactions");
		sleep(3);
		enterValueInTextBox("Transaction Filter Fields", "Effective Date From", ifcsDate);
		sleep(3);
		enterValueInTextBox("Transaction Filter Fields", "Reference No", referenceNo);
		sleep(3);
		common.searchListTorch();
		sleep(3);
		common.validateSearchTable("Ref", referenceNo, true);
	}

	public void selectBatchTypeInTransactionDetails(String batchType) {
		chooseOptionFromDropdown("Batch Type", batchType);

	}

	public void enterTransactionBatchDetails(boolean notprotected, String controlTotal, String controlCount,
			String clientName) {
		String referenceNo = fakerN.number().digits(5);
		try {
			chooseSubMenuFromLeftPanel("Client Transactions", "Manual Transactions");
			sleep(3);
			chooseSubMenuFromLeftPanel("Manual Transactions", "Manual Transaction Entry");
			if (!clientName.equals("BP")) {
				enterValueInTextBox("Transaction Batch Details", "Reference", referenceNo);
				sleep(3);
			}
			enterValueInTextBox("Transaction Batch Details", "Control Count", controlCount);
			sleep(3);
			enterValueInTextBox("Transaction Batch Details", "Control Total", controlTotal);
			sleep(5);
		} catch (Exception e) {
			e.getMessage();
		}
	}

	public void enterManualTransactionDetails(String ifcsDate, String referenceNo, String CardNumber,
			String CardNumber2, String LocNo, String origPrice, String returnvalue) {
		String clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		try {
			rightClick(transactionTable);
			common.addIteminPopup();
			sleep(5);
			validatePopupHeaderText("Transactions");
			sleep(3);
			enterValueInTextBox("Details", "Ref", referenceNo);
			sleep(2);
			if (clientCountry.equals("SG") || clientCountry.equals("GU") || clientCountry.equals("NZ")
					|| clientCountry.equals("AU")) {
				enterValueInTextBox("Details", "Card No", CardNumber);
			} else {
				sleep(5);
				List<WebElement> textBox = driver.findElements(By.xpath(
						"//div[@class='JFALSeparator']//div[contains(text(),'Details')]/preceding::div[@class='JFALLabel']/div[contains(text(),'Card') and contains(text(),'No')]/preceding::div[@class='JFALCompControlPanel'][1]//input"));
				textBox.get(0).sendKeys(CardNumber2);
				sleep(2);
				textBox.get(1).sendKeys(CardNumber);
			}
			sleep(2);

			enterValueInTextBox("Details", "Location", LocNo);
			sleep(2);
			enterValueInTextBox("Details", "Orig Price", origPrice);
			sleep(3);
			driver.findElement(By.xpath(
					"//div[@class='JFALSeparator']//div[contains(text(),'Details')]/preceding::div[@class='JFALLabel']/div[starts-with(text(),'Transaction') and contains(text(),'Date')]/preceding::div[@class='JFALCompControlPanel'][1]//input[contains(@name,'JFALDateLocaleTextField')]"))
					.sendKeys(ifcsDate);
			sleep(3);
			enterValueInTextBox("Details", "Transaction Date", "12:30:00 pm");
			sleep(5);
			if (returnvalue.equalsIgnoreCase("Return")) {
				driver.findElement(By.xpath(
						"//div[@class='JFALSeparator']//div[contains(text(),'Details')]/preceding::div[@class='JFALLabel']/div[starts-with(text(),'Credit')]/preceding::div[@class='JFALCheckBox enabled'][1]//div[3]"))
						.click();
				sleep(3);
			}

			common.clickOkButton();
			sleep(5);
		} catch (Exception e) {
			e.getMessage();
		}
	}

	/*
	 * Updated by raxsana 0n 17/07/2020
	 */
	public void enterTransactionLineItems(String externalCode, String originalValue, String quantity,
			String unitPrice) {
		try {
		//driver.manage().window().fullscreen();
			rightClick(lineItemsTable);
			
			common.addIteminPopup();
			validatePopupHeaderText("Line Items");
			sleep(3);
			enterValueInTextBox("Details", "Product Code", externalCode);
			sleep(2);
			enterValueInTextBox("Details", "Quantity", quantity);
			sleep(2);
			enterValueInTextBox("Details", "Unit Price", unitPrice);
			sleep(2);
			enterValueInTextBox("Details", "Original Value", originalValue);// String.valueOf((Integer.parseInt(quantity)*Integer.parseInt(unitPrice))/100));
			sleep(5);
			common.clickOkButton();
			sleep(2);
		} catch (Exception e) {
			e.getMessage();
		}
	}

	/*
	 * raxsana Added on 17/07/2020
	 */
	public void validatePostManualTransaction(String validationMessage) {
		common.clickSaveIcon();
		sleep(5);
		verifyValidationResult("Record saved OK");
		sleep(2);
		common.clickValidateManualTransactionIcon();
		sleep(5);
		if (validationMessage.equalsIgnoreCase("Validation successful")) {
			verifyValidationResult("Validation successful");
			sleep(2);
			common.clickPostTransaction();
			sleep(2);
			common.verifyValidationResult("Record Posted Successfully");
		} else {
			verifyValidationResult(validationMessage);
		}
	}

	public void validateToPostManualTransactionEntry(String ifcsDate, String referenceNo, String clientCountry,
			String CardNumber, String CardNumber2, String LocNo, String externalCode, boolean notprotected) {
		chooseSubMenuFromLeftPanel("Client Transactions", "Manual Transactions");
		sleep(3);
		chooseSubMenuFromLeftPanel("Manual Transactions", "Manual Transaction Entry");

		if (notprotected == true) {
			enterValueInTextBox("Transaction Batch Details", "Reference", referenceNo);
		}
		enterValueInTextBox("Transaction Batch Details", "Control Count", "1");
		sleep(3);
		enterValueInTextBox("Transaction Batch Details", "Control Total", "160");
		sleep(5);
		rightClick(transactionTable);
		common.addIteminPopup();
		sleep(5);
		validatePopupHeaderText("Transactions");
		sleep(3);

		enterValueInTextBox("Details", "Ref", referenceNo);
		sleep(2);
		if (clientCountry.equals("SG") || clientCountry.equals("GU") || clientCountry.equals("NZ")) {
			enterValueInTextBox("Details", "Card No", CardNumber);

		}

		else {

			sleep(5);
			List<WebElement> textBox = driver.findElements(By.xpath(
					"//div[@class='JFALSeparator']//div[contains(text(),'Details')]/preceding::div[@class='JFALLabel']/div[contains(text(),'Card') and contains(text(),'No')]/preceding::div[@class='JFALCompControlPanel'][1]//input"));
			textBox.get(0).sendKeys(CardNumber2);
			sleep(2);
			textBox.get(1).sendKeys(CardNumber);
		}
		sleep(2);

		enterValueInTextBox("Details", "Location", LocNo);
		sleep(2);
		enterValueInTextBox("Details", "Orig Price", "160");
		sleep(3);
		driver.findElement(By.xpath(
				"//div[@class='JFALSeparator']//div[contains(text(),'Details')]/preceding::div[@class='JFALLabel']/div[starts-with(text(),'Effective') and contains(text(),'Date')]/preceding::div[@class='JFALCompControlPanel'][1]//input[contains(@name,'JFALDateLocaleTextField')]"))
				.sendKeys(ifcsDate);
		sleep(3);
		// enterValueInTextBox("Details", "Effective Date", ifcsDate);
		enterValueInTextBox("Details", "Effective Date", "12:30:00 pm");
		sleep(5);

		common.clickOkButton();
		sleep(5);
		rightClick(lineItemsTable);
		common.addIteminPopup();
		validatePopupHeaderText("Line Items");
		sleep(3);
		enterValueInTextBox("Details", "Product Code", externalCode);
		// enterValueInTextBox("Details", "Product Code", "0003");
		// enterValueInTextBox("Details", "Product Code", "B8");//OTI
		sleep(2);
		enterValueInTextBox("Details", "Quantity", "100");
		sleep(2);
		enterValueInTextBox("Details", "Original Value", "160");
		sleep(2);
		enterValueInTextBox("Details", "Unit Price", "160");

		sleep(5);
		common.clickOkButton();
		sleep(5);

		common.clickSaveIcon();
		sleep(5);
		verifyValidationResult("Record saved OK");
		sleep(2);
		common.clickValidateManualTransactionIcon();
		sleep(5);
		verifyValidationResult("Validation successful");
		sleep(5);
		common.clickPostTransaction();
		sleep(2);
		// common.verifyValidationResult("Record Posted Successfully");
	}

	public void validateManualTransaction(String referenceNo) {

		try {
			chooseSubMenuFromLeftPanel("Client Transactions", "Transactions");
			sleep(2);
			enterValueInTextBox("Transaction Filter Fields", "Reference No", referenceNo);
			common.searchListTorch();
			verifyReferenceNoInTransaction(referenceNo);
		} catch (Exception ex) {
			logFail(ex.getMessage());
		}

	}

	public void verifyReferenceNoInTransaction(String referenceNo) {

		WebElement textElement;
		String transactionReferenceNo;
		int column;
		int size;
		try {
			List<WebElement> list = driver
					.findElements(By.xpath("//div[@class='FALTableCellEditor_StrikeThruField JTextComponent']"));

			List<WebElement> cardsTableHeaders = driver.findElements(
					By.xpath("//div[@class='JViewport']/div[@class='JTableHeader']//div[@class='HeaderRenderer']"));
			column = SeleniumWrappers.getColumnNoForColumnHeader("Ref", cardsTableHeaders);
			size = SeleniumWrappers.getTotalNumberOfRows(list, driver);
			System.out.println(size);
			for (int row = 0; row <= size; row++) {
				System.out.println(row + " " + column);
				System.out.println(SeleniumWrappers.getTableDataWithRowAndColumnNumber(column, row, driver));
				textElement = SeleniumWrappers.getTableDataWithCellElement(row, column, driver);
				System.out.println(textElement);
				transactionReferenceNo = textElement.getAttribute("submittedvalue");
				System.out.println(transactionReferenceNo);
				if (transactionReferenceNo.equals(referenceNo)) {
					logPass("Expected Reference Number is displayed in transaction");
					break;
				} else {
					logFail("Expected Reference Number is not displayed in transaction");
				}
			}

		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
	}

	public void validatePostSuspendedtransaction(String referenceNo) {
		chooseSubMenuFromLeftPanel("Suspended Transactions", "");
		validateHeaderLabel("Suspended Transactions");
		common.detailSearch();
		common.clearingAllTextBoxes(textBoxes);
		enterInputAndValidateFilterTable("Filter By", "Reference No", "Reference", referenceNo);
		sleep(2);
		common.searchListTorch();
		sleep(3);
		common.selectFirstRowNumberInSearchList();
		validatePopupHeaderText("Suspended Transaction");
		sleep(3);
		common.clickPopupForcePostTransactionIcon();
		sleep(10);
		validateDropdownProtectedTextInPopup("Suspense Status", "Posted");
		common.verifyValidationResultInPopUp("Record Posted Successfully");
		sleep(5);
		common.clickOkButton();
		sleep(5);
	}

	public void validatePostedInTransaction(String referenceNo) {

		chooseSubMenuFromLeftPanel("Transactions", "");
		sleep(2);
		common.clickDetailSearchIfFilterFieldsNotPresent();
		common.clearingAllTextBoxes(textBoxes);
		enterInputAndValidateFilterTable("Transaction Filter Fields", "Reference No", "Ref", referenceNo);
		sleep(2);
		common.searchListTorch();
		sleep(2);
		common.selectFirstRowNumberInSearchList();
		sleep(3);

		validateHeaderLabel("Transaction Detail");
		sleep(3);
		String transactionStatus = getValueFromProtectedTextBox("Header Details", "Transaction Status");
		System.out.println("Status::" + transactionStatus);
		if (transactionStatus.equals("Posted")) {
			logPass("Status Updated as Posted");
		} else {
			logFail(transactionStatus);
		}
		sleep(5);
	}

	public void validateCustomerTransaction(String CardNo, String ifcsDate, String referenceNo) {
		chooseSubMenuFromLeftPanel("Card Details", "Card Maintenance");
		common.chooseCardNoAndSearch(CardNo);
		chooseSubMenuFromLeftPanel("Customer Transactions", "Transactions");
		sleep(3);
		enterValueInTextBox("Transaction Filter Fields", "Effective Date From", ifcsDate);
		sleep(3);
		enterValueInTextBox("Transaction Filter Fields", "Reference No", referenceNo);
		sleep(3);
		common.searchListTorch();
		sleep(3);
		common.validateSearchTable("Ref", referenceNo, true);
	}

//Added by sowmiya
	public void validateFullDayTransactionSearch() {
		String clientCountry = PropUtils.getPropValue(configProp, "clientCountry");
		String clientName = PropUtils.getPropValue(configProp, "clientName");
		chooseSubMenuFromLeftPanel("Client Transactions", "Transactions");
		String processingDateFrom = common.getCurrentIFCSDateFromDB(clientName + clientCountry);
		String effDateFrom = common.enterADateValueInStatusBeginDateField("Past", processingDateFrom);
		enterValueInTextBox("Transaction Filter Fields", "Process Date From", effDateFrom);
		enterValueInTextBox("Transaction Filter Fields", "Process Date To", effDateFrom);
		sleep(2);
		common.searchListTorch();
		sleep(5);
		verifyValidationResult("Record Read OK - Page Size");
		// sleep(5);

	}

	public void validateNextPageIsDisplayed() {
		int row = 0;
		List<WebElement> transactionTableheader = driver.findElements(
				By.xpath("//div[@class='JViewport']/div[@class='JTableHeader']//div[@class='HeaderRenderer']"));
		int columnNo = SeleniumWrappers.getColumnNoForColumnHeader("Ref", transactionTableheader);
		System.out.println("Column Number is" + columnNo);
		// List<WebElement>
		// list=driver.findElements(By.xpath("//div[@class='FALTableCellEditor_StrikeThruField
		// JTextComponent']"));
		//
		String refNo = SeleniumWrappers.getTableDataWithRowAndColumnNumber(row, columnNo, driver);
		System.out.println("First Page Reference Number is " + refNo);
		if (isElementEnabled(common.readNextInTransaction, "Read Next")) {
			common.clickReadNextButton();
			// sleep(5);
			driver.navigate().refresh();
			// List<WebElement>
			// transactionList=driver.findElements(By.xpath("//div[@class='FALTableCellEditor_StrikeThruField
			// JTextComponent']"));
			// SeleniumWrappers.setCellValue(transactionList);
			String nextPageRefNo = SeleniumWrappers.getTableDataWithRowAndColumnNumber(row, columnNo, driver);

			System.out.println("Next Page Reference Number is " + nextPageRefNo);
		}

	}

//Added by Nithya 17/04/4019
	public void postATransactionWithRebateProfileForNonFuelProduct(String externalCode) {
		MaintainCustomerPage maintainCustomer = new MaintainCustomerPage(driver, test);
		String cardNumber = chooseActiveCardAndSetInContext("100 Normal Service");
		maintainCustomer.createRebateProfile();
		common.clickSaveIcon();
		verifyValidationResult("Record saved ok");

		// Post a Transaction
		validateToPostManualTransactionEntry("", fakerAPI().number().digits(3),
				PropUtils.getPropValue(configProp, "clientCountry"), cardNumber, "", "", externalCode, true);

	}

	public String chooseActiveCardAndSetInContext(String cardStatus) {
		String cardNumber = common.getCardsWithStatusAndWithBalance(cardStatus);
		IFCSHomePage.gotoSearchAndClickCards();
		common.clearingAllTextBoxes(textBoxes);
		enterValueInTextBox("Filter By", "Card Number", cardNumber);
		common.searchListTorch();
		sleep(5);

		doubleClick(SeleniumWrappers.getTableDataWithCellElement(0, 0, driver));
		verifyValidationResult("Record read OK");
		return cardNumber;
	}

	public void financialState() {
		chooseSubMenuFromLeftPanel("Maintain Account", "Financial State");
	}

	public void clickingForcePostAndValidate() {

		common.clickPopupForcePostTransactionIcon();
		sleep(5);
		validateDropdownProtectedTextInPopup("Suspense Status", "Posted");
		common.verifyValidationResultInPopUp("Record Posted Successfully");
		sleep(5);
		common.clickOkButton();
		sleep(5);

	}

	public void clickingPostAndValidate() {

		common.clickPostTransactionInPopup();
		sleep(5);
		validateDropdownProtectedTextInPopup("Suspense Status", "Posted");
		common.verifyValidationResultInPopUp("Record Posted Successfully");
		sleep(5);
		common.clickOkButton();
		sleep(5);

	}

// Added by Ayub 21/05/2019

	public void goToIncomingInterfacesPage() {
		chooseSubMenuFromLeftPanel("Client Config", "Interfaces");
		chooseSubMenuFromLeftPanel("Interfaces", "Incoming Interfaces");

	}

	public void goToBankingStatements() {
		chooseSubMenuFromLeftPanel("Client Transactions", "Banking Statements");
		sleep(3);

	}

	public void enterStatementNoAndValidate(String StatementNo) {
		enterValueInTextBox("Filtered By", "Statement No", StatementNo);
		common.searchListTorch();
		common.validateSearchTable("Statement No", StatementNo, true);

	}

	public void goToAdminClientIncomingInterFacepage() {
		isDisplayedThenClick(adminMenu, "AdminMenu");
		isDisplayedThenClick(clientMenu, "ClientSubMenu");
		goToIncomingInterfacesPage();
	}

	public void validateStatementOrAcknowledgementsNumber(String beforeStatementNo, String UpdatedStatementNo,
			String compareValue) {
		int beforeStatementNumber = Integer.parseInt(beforeStatementNo);
		int currentStatementNumber;
		if (compareValue.equalsIgnoreCase("increase")) {
			currentStatementNumber = beforeStatementNumber + 1;
		} else {
			currentStatementNumber = beforeStatementNumber;
		}

		System.out.println(
				"current Statement Number::" + currentStatementNumber + "Updated Statement No::" + UpdatedStatementNo);

		if (currentStatementNumber == Integer.parseInt(UpdatedStatementNo)) {
			logPass("Statement Number was successsfully updated " + "current Statement Number::"
					+ currentStatementNumber + "Updated Statement No::" + UpdatedStatementNo);
		} else {
			logFail("Statement Number is not updated");
		}

	}

	public String enterStatementNoAndValidatess(String expectedResult) {
		String fStatementNo, validateElement;
		do {
			fStatementNo = fakerAPI().number().digits(3);
			System.out.println("Inside method Statement No::" + fStatementNo);
			enterValueInTextBox("Filtered By", "Statement No", fStatementNo);
			common.searchListTorch();
			sleep(3);
			validateElement = getText(bottomLeftText);
		} while (!(validateElement).contains(expectedResult));
		return fStatementNo;
	}

//Rax 
	public ArrayList<String> getDriverNameinCardMaintenance(String cardNumber) {

		ArrayList<String> driverNameList = new ArrayList<String>();
		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		common.chooseSubMenuFromLeftPanel("Card Details", "Card Maintenance");
		common.chooseCardNo(cardNumber);
		sleep(5);
		String driverNameBefore = getValueFromTextBox("Driver Details", "Driver Name");
		driverNameList.add(driverNameBefore);
		String licensePlateValue = getValueFromTextBox("Vehicle Details", "License Plate");
		String vehicleDescriptionValue = getValueFromTextBox("Vehicle Details", "Description");
		common.isDisplayedThenClearText(driverNameCardMaintenance, "Driver Name");
		common.isDisplayedThenClearText(shortNameCardMaintenance, "Short Name");
		common.enterValueInTextBox("Requested By", "Phone", fakerAPI().phoneNumber().phoneNumber());
		sleep(3);
		common.clickSaveIcon();
		sleep(5);
		verifyValidationResult("Record saved OK");
		sleep(5);
		String driverOidForCardNumber = common.getDriverOidForCardNumber(cardNumber);
		System.out.println("driver oid " + driverOidForCardNumber);
		if (driverOidForCardNumber == null) {
			logPass("Expected result displayed " + driverOidForCardNumber);
		} else {
			logFail("Expected result not displayed");
		}

		String driverNameAfter = fakerAPI().name().fullName();
		driverNameList.add(driverNameAfter);
		common.enterValueInTextBox("Driver Details", "Driver Name", driverNameAfter);
		common.clickSaveIcon();
		sleep(3);
		verifyValidationResult("Record saved OK");
		String driverOidForCardNumberNotNull = common.getDriverOidForCardNumber(cardNumber);
		if (driverOidForCardNumberNotNull.equals("")) {
			logFail("Expected result not displayed");
		} else {
			logPass("Expected result displayed " + driverOidForCardNumberNotNull);
		}
		driverNameList.add(licensePlateValue);
		driverNameList.add(vehicleDescriptionValue);

		return driverNameList;
	}

	public void enterDetailsInCustomizedFleetControlReportsPopup(String cardNumber, String customerNumber,
			String ifcsDate) {
		try {
			driver.findElement(By.xpath(
					"//div[@class='JLayeredPane']//div[@class='MetalTitlePane titlePane']//div[@class='htmlString'][contains(text(),'Define') and contains(text(),'Parameters')]"));
			WebElement accountNumber = driver.findElement(By.xpath(
					"//div[@class='JLabel']/div[@class='htmlString'][contains(text(),'Account') and contains(text(),'Number')]/preceding::div[@class='JFALTextField JTextComponent'][1]/input"));
			enterText(accountNumber, customerNumber);
			int size = dateRange.size();
			Date ifcsDateFormat = null;
			String ifcsCurrentDate;
			for (int i = 0; i < size; i++) {
				try {
					ifcsDateFormat = new SimpleDateFormat("yyyy-MM-dd").parse(ifcsDate);
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				ifcsCurrentDate = getDateInFormat(ifcsDateFormat, "dd/MM/yyyy");
				enterText(dateRange.get(i), ifcsCurrentDate);
			}
			WebElement popupCardNumber = driver.findElement(By.xpath(
					"//div[@class='JLabel']/div[@class='htmlString'][contains(text(),'Card') and contains(text(),'Number')]/preceding::div[@class='JFALTextField JTextComponent'][1]/input"));
			enterText(popupCardNumber, cardNumber);
			WebElement okButton = driver
					.findElement(By.xpath("//div[@class='JButton enabled']//div[@class='htmlString'][text()='OK']"));
			Click(okButton, "Ok Button");
			sleep(3);
			verifyValidationResult("Report Created Successfully");
			sleep(5);
		} catch (Exception e) {
			e.getMessage();
		}

	}

	public void validateTheTextRetrievedFromPdfFile(String textFromPdfFile, String expectedValue) {

		if ((textFromPdfFile.toString()).contains(expectedValue)) {

			logPass("Pdf File contains the expected text");
		} else {
			logFail("Pdf File does not contains the expected text");
		}

	}

	public void validateIFCSCardOrder(String cardNumber) {
		try {
			common.clearingAllTextBoxes(textBoxes);
			enterValueInTextBox("Filter By", "Card Number", cardNumber);
			common.searchListTorch();
			sleep(5);
			verifyValidationResult("Record Read OK - Page Size 200 Rows");
		} catch (Exception e) {
			e.getMessage();
		}

	}

	/*
	 * unused updated by raxsana on 25/06/2020
	 */
	/*
	 * public void validateIFCSBulkCardOrder(String customerNo,String[]
	 * expectedValue) { try { common.clearingAllTextBoxes(textBoxes);
	 * enterValueInTextBox("Filter By", "Customer No", customerNo);
	 * common.searchListTorch(); sleep(5);
	 * verifyValidationResult("Record Read OK - Page Size 200 Rows");
	 * List<WebElement> cardsTableHeaders = driver.findElements( By.xpath(
	 * "//div[@class='JViewport']/div[@class='JTableHeader']//div[@class='HeaderRenderer']"
	 * )); int column = SeleniumWrappers.getColumnNoForColumnHeader("Driver Name",
	 * cardsTableHeaders); List<WebElement> list = driver .findElements(By.
	 * xpath("//div[@class='FALTableCellEditor_StrikeThruField JTextComponent']"));
	 * String value; int size = SeleniumWrappers.getTotalNumberOfRows(list, driver);
	 * for(int i=0;i<size;i++) {
	 * value=SeleniumWrappers.getTableDataWithRowAndColumnNumber(column, i, driver);
	 * for(int j=0;j<size;j++) { if(value.equals(expectedValue[j])) { //Logic Issue
	 * } } } }catch(Exception e) { e.getMessage(); } }
	 */

	// Prakalpha-->06/26/2019
	public double getUnitPriceFromCustomerBreakdown(String refNo) {
		double unitValue = 0.0;
		try {
			chooseSubMenuFromLeftPanel("Transactions", "");
			sleep(2);
			common.clickDetailSearchIfFilterFieldsNotPresent();
			common.clearingAllTextBoxes(textBoxes);
			enterInputAndValidateFilterTable("Transaction Filter Fields", "Reference No", "Ref", refNo);
			sleep(2);
			common.searchListTorch();
			sleep(5);
			common.selectFirstRowNumberInSearchList();
			sleep(5);

			validateHeaderLabel("Transaction Detail");
			sleep(3);
			switchTabDetails("Customer Breakdown");
			String unitPriceValue = getValueFromProtectedTextBox("Breakdown Details", "Customer Unit Price");
			unitValue = Double.parseDouble(unitPriceValue);
		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
		return unitValue;
	}

	// Prakalpha-->06/26/2019

	public void validateUnitPriceIsUpdated(double unitPriceValue) {
		double valueAfterDayEnd = 0.0;
		try {
			String actualValue = getValueFromProtectedTextBox("Breakdown Details", "Customer Unit Price");
			valueAfterDayEnd = Double.parseDouble(actualValue);
			System.out.println("Actual Value ::" + actualValue);
			if (unitPriceValue > valueAfterDayEnd || unitPriceValue < valueAfterDayEnd) {
				logPass("Before Dayend " + unitPriceValue + "AfterDayend " + valueAfterDayEnd + "Values Updated");
			} else {
				logFail("OOPS somethig wrong!!---Before Dayend " + unitPriceValue + "AfterDayend " + valueAfterDayEnd
						+ "Values Not Updated");
			}

		} catch (Exception ex) {
			logFail(ex.getMessage());
		}
	}
// raxsana --> 25/11/2019

	public String validateAccountAlertMessage(String processingDate, String customerNumber) {
		String getAlertMessage = null;
		Date dateFormat = null;
		String dateFormatted = "";
		try {
			DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
			dateFormat = df.parse(processingDate);
			System.out.println("Date Format" + dateFormat);
			dateFormatted = new SimpleDateFormat("dd-MMM-yy").format(dateFormat);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			String alertMessage = "Select message from stored_alerts where create_at like '%"
					+ dateFormatted.toUpperCase()
					+ "%' and customer_mid = (Select customer_mid from m_customers where customer_no = '"
					+ customerNumber + "')";
			getAlertMessage = connectDBAndGetValue(alertMessage,
					PropUtils.getPropValue(configProp, "sqlODSServerName"));
			String getCreditPercentage = "select alert_threshold_percentage from accounts  where account_no='"
					+ customerNumber + "'";
			String creditPercentage = connectDBAndGetValue(getCreditPercentage,
					PropUtils.getPropValue(configProp, "sqlODSServerName"));
			if (getAlertMessage.contains(
					"(" + customerNumber + "), has exceeded " + creditPercentage + "% of its credit limit.")) {
				logPass("Account Balance Alert Mail is sent");
			} else {
				logFail("Account Balance Alert Mail is not sent");
			}
		} catch (Exception e) {
			e.getMessage();
		}
		return getAlertMessage;
	}

	public void validateTransactionMessage() {
		// WebElement availableBalanceFields = driver.findElement(By.xpath(
		// "//div[@class='JFALSeparator']//div[
		// (text()='From')]/preceding::div[@class='JFALLabel']/div[
		// starts-with(text(),'Available')and
		// contains(text(),'Balance')]/preceding::div[@class='JFALCompControlPanel'][1]//input"));
		// fromAvailableBalance = availableBalanceFields.getAttribute("submittedvalue");
		fromAvailableBalance = "0.00";
		System.out.println("after");
		double debit = Double.parseDouble(fromAvailableBalance);

		if (debit > 0) {
			verifyValidationResult("Validation successful");
			logPass("Transfer Done");
		} else {
			logInfo("Card has no balance");
		}

	}

}
