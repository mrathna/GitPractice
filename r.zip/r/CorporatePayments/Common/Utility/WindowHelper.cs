﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Common.Utility
{
	public class WindowHelper : IDisposable
	{
		private IWebDriver _driver;
		public WindowHelper(IWebDriver driver)
		{
			_driver = driver;
		}

		/// <summary>
		/// Finds element on all the open windows INCLUDING the main window
		/// </summary>
		public IWebElement FindElementOnAllOpenWindows(By by)
		{
			if (_driver == null)
			{
				return null;
			}

			//Handle different windows
			foreach (string handle in _driver.WindowHandles)
			{
				//Verify if the element is present on the current window
				if (_driver.SwitchTo().Window(handle).TryWaitForElement(by, out IWebElement element))
				{
					return element;
				}
			}
			return null;
		}

		/// <summary>
		/// Finds element on all the open windows EXCEPT the main window
		/// </summary>
		public IWebElement FindElementOnAllNewlyOpenedWindows(By by, string mainWindowId)
		{
			if (_driver == null)
			{
				return null;
			}

			// Filter out the main window handle id to exclude it
			IReadOnlyCollection<string> _handles = _driver.WindowHandles.Where(d => !d.Equals(mainWindowId)).ToList();

			//Handle different windows
			foreach (string handle in _handles)
			{
				//Verify if the element is present on the current window
				if (_driver.SwitchTo().Window(handle).TryWaitForElement(by, out IWebElement element))
				{
					return element;
				}
			}
			return null;
		}

		public virtual void Dispose()
		{
			if (_driver != null)
			{
				_driver.SwitchTo().DefaultContent();
			}
		}
	}
}
