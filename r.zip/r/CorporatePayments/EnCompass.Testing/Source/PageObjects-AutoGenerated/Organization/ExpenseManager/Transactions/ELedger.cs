using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using Common;
using Common.PageObjects;
using Common.ScenarioConfigurations;
using Common.Utility;

namespace EnCompass.Testing.Source.PageObjects.Organization.ExpenseManager.Transactions 
{
	/// <summary>
	/// Auto-generated Page Model Class
	/// Navigation Paths: 
		/// [Organization Home]->Transactions->Financial Codes->Map Codes
		/// </summary>
	[PageModel(@"/expenseManager/transactions/eLedger.aspx")]
	public partial class ELedger : EnCompassOrgPageModel 
	{
		public override string RelativeUrl => @"/expenseManager/transactions/eLedger.aspx";
		public override string PageIdentifierXPath_Generated => @"//li[contains(@class, 'breadcrumb-item active')][text() = 'Map Codes']";

		#region Navigation
				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Create or Edit']")]
		private IWebElement _transactions_FinancialCodes_MapCodes_CreateOrEdit { get; set; }
		public void NavigateTo_Transactions_FinancialCodes_MapCodes_CreateOrEdit()
		{
			NavigateToMenuItem(_transactions_FinancialCodes_MapCodes_CreateOrEdit);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Profiles']")]
		private IWebElement _transactions_FinancialCodes_MapCodes_Profiles { get; set; }
		public void NavigateTo_Transactions_FinancialCodes_MapCodes_Profiles()
		{
			NavigateToMenuItem(_transactions_FinancialCodes_MapCodes_Profiles);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Map Codes']")]
		private IWebElement _transactions_FinancialCodes_MapCodes_MapCodes { get; set; }
		public void NavigateTo_Transactions_FinancialCodes_MapCodes_MapCodes()
		{
			NavigateToMenuItem(_transactions_FinancialCodes_MapCodes_MapCodes);
		}

				[FindsBy(How = How.XPath, Using = @"//ul[contains(@id, 'sideNav')]//a[text()='Priority']")]
		private IWebElement _transactions_FinancialCodes_MapCodes_Priority { get; set; }
		public void NavigateTo_Transactions_FinancialCodes_MapCodes_Priority()
		{
			NavigateToMenuItem(_transactions_FinancialCodes_MapCodes_Priority);
		}

		
		private void NavigateToMenuItem(IWebElement element)
		{
			Driver.Url = element.GetAttribute("href");
		}
		#endregion

		public ELedger(GlobalSettings settings) : base(settings) { }
	}  
}
