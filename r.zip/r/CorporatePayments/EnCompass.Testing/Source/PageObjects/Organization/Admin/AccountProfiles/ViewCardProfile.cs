﻿using Common;
using Common.Utility;
using EnCompass.Testing.Source.PageObjects.Controls;
using NFluent;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using System;

namespace EnCompass.Testing.Source.PageObjects.Organization.Admin.AccountProfiles
{
    [PageModel(@"/admin/accountProfiles/viewCardProfile.aspx")]
    public class ViewCardProfile : EnCompassOrgPageModel
    {
        public override string RelativeUrl => @"/admin/accountProfiles/viewCardProfile.aspx";
        public override string PageIdentifierXPath_Override => @"//h1[contains(@id,'title')]";

        #region XPath page Elements

        private const string _backXPath = @"//input[contains(@id,'backButton')]";
        private const string _nameXPath = "(//div[@class='card-body']//ul[@class='list-unstyled']//li)[1]";
        private const string _descXPath = "(//div[@class='card-body']//ul[@class='list-unstyled']//li)[2]";
        private const string _hierarchyXPath = "((//div[@class='card-body']//ul[@class='list-unstyled'])[2]//li)[4]";
        private const string _creditLimitXPath = "((//div[@class='card-body']//ul[@class='list-unstyled'])[3]//li)[1]";
        private const string _mccgProfilesXPath = "//div[@class='card-body']//ul[contains(@id,'phMCC')]//li[contains(@id,'profile')]";
        private const string _financialCode9XPath = "((//div[@class='card-body']//ul[@class='list-unstyled'])[9]//li)[1]";
        private const string _financialCode8XPath = "((//div[@class='card-body']//ul[@class='list-unstyled'])[8]//li)[1]";
        #endregion

        #region Page Elements

        private IWebElement _back
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_backXPath), out IWebElement element);
                Check.That(found).IsTrue();
                Settings.EnCompassExtentTest.Info("Found _back");
                return element;
            }
        }
        #endregion

        public void CheckNameInformation()
        {
            var Name = Settings.EnCompassWebDriver.WaitForVisible(By.XPath(_nameXPath));
            Check.That(Name.Text).Contains("CP1");
        }

        public void CheckDescriptionInformation()
        {
            var Desc = Settings.EnCompassWebDriver.WaitForVisible(By.XPath(_descXPath));
            Check.That(Desc.Text).Contains("CP1");
        }

        public void CheckHierarchyInformation()
        {
            var Hier = Settings.EnCompassWebDriver.WaitForVisible(By.XPath(_hierarchyXPath));
            Check.That(Hier.Text).Contains(Settings.CreatedOrgName);

        }

        public void CheckCreditLimitInformation()
        {
            var Limt = Settings.EnCompassWebDriver.WaitForVisible(By.XPath(_creditLimitXPath));
            Check.That(Limt.Text).Contains("1,000.00");
        }

        public void CheckMCCGProfilesInformation()
        {
            var MCC = Settings.EnCompassWebDriver.WaitForVisible(By.XPath(_mccgProfilesXPath));
            Check.That(MCC.Text).Contains("MCCG Profile");
        }

        public void CheckFinancialCodeInformation()
        {
            if (StringKeys.FIsWithFinancialCodeInformation.Contains(GlobalSettings.FI))
            {
                var FCPinfo = Settings.EnCompassWebDriver.WaitForVisible(By.XPath(_financialCode9XPath));
                Check.That(FCPinfo.Text).Contains("PROFILE1");
            }
            else
            {
                var FCPinfo = Settings.EnCompassWebDriver.WaitForVisible(By.XPath(_financialCode8XPath));
                Check.That(FCPinfo.Text).Contains("PROFILE1");
            }                
        }

        public void PressBack()
        {
            _back.JSClickWithFocus(Driver);
        }

        public ViewCardProfile(GlobalSettings settings) : base(settings) { }
    }
}