package com.framework.testcases.OLS.CHEV.Customer.ReadWrite;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.CHEV.CHHomePage;
import com.framework.pages.CHEV.CHStoredReportsPage;
import com.framework.pages.OLS.common.LoginPage;

public class ValidateOLSStatements extends BaseTest {
	@Parameters({ "clientCountry", "clientName" })
	@Test
	public void testCustomerReadWriteReportReceiptsStatements(@Optional("PH") String clientCountry, @Optional("CHV") String clientName) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  OLS - Statements", "Chevron Customer Screens Read/Write");
		LoginPage loginPage = new LoginPage(driver, test);
		if (clientCountry.equals("SG")||clientCountry.equals("MY")||clientCountry.equals("HK")) {
			loginPage.Login("CHV_URL", "CHV_Customer_UN_RW_ONLY_"+clientCountry, "CHV_Customer_PWD_RW_ONLY_"+clientCountry, "CHV");
		} else if (clientCountry.equals("TH")) {
			loginPage.Login("CHV_URL", "CHV_Customer_UN_"+clientCountry, "CHV_Customer_PWD_"+clientCountry, "CHV");
		} else if (clientCountry.equals("PH")) {
			loginPage.Login("CHV_URL", "CHV_Customer_UN_"+clientCountry, "CHV_Customer_PWD_"+clientCountry, "CHV");
		}
		CHHomePage chHomePage = new CHHomePage(driver, test);
		CHStoredReportsPage chStoredReportsPage = new CHStoredReportsPage(driver, test);
		
		chHomePage.loadFindAndUpdateStatementPage();	
		chStoredReportsPage.verifyStatementPageTitle();
		chStoredReportsPage.verifystatementreportPageSubTitles();
		chStoredReportsPage.enterfromtovalue();
		chStoredReportsPage.selectsearch();
		chStoredReportsPage.verifyexport();
		chStoredReportsPage.verifyReports();		
		chHomePage.clickOnHome();
		loginPage.Logout();

	}
}
