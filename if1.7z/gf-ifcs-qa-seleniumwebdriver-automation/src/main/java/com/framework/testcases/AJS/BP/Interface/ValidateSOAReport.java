package com.framework.testcases.AJS.BP.Interface;

import javax.xml.transform.TransformerException;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.CardMaintenancePage;
import com.framework.pages.AJS.MaintainCustomerPage;
import com.framework.pages.AJS.TransactionListPage;
import com.framework.pages.AJS.common.Common;
import com.framework.pages.AJS.common.CommonInterfacePage;
import com.framework.pages.AJS.common.IFCSCommonPage;
import com.framework.pages.AJS.common.IFCSHomePage;
import com.framework.pages.AJS.common.IFCSLoginPage;
import com.github.javafaker.Faker;

public class ValidateSOAReport extends BaseTest {
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "Smoke" })
	public void validateSOAReportGenerationForCustomers(@Optional("AU") String clientCountry,
			@Optional("BP") String clientName) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  TC00189-Statement of Account Report",
				"Post a transaction for Preparid customer and check the SOA report generation");
		// creating object for the Pages
		IFCSLoginPage IFCSloginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage IFCSHomePage = new IFCSHomePage(driver, test);
		TransactionListPage transactions = new TransactionListPage(driver, test);
		MaintainCustomerPage maintainCustomerPage = new MaintainCustomerPage(driver, test);
		CardMaintenancePage cardMaintenancePage = new CardMaintenancePage(driver, test);
		Common common = new Common(driver, test);
		CommonInterfacePage commoninterface = new CommonInterfacePage(driver, test);
		IFCSCommonPage ifcsCommonPage = new IFCSCommonPage(driver, test);

		// Calling Functions
		IFCSloginPage.login("IFCS_URL_BP", "IFCS_BP_USERNAME", "IFCS_BP_PASSWORD");
		IFCSloginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "Prepaid");

		// Pick a customer which is having Pre paid active card
		// selecting customer details

		IFCSHomePage.gotoCustomerMenuCustomerDetails();
		common.chooseCustomerNoAndSearch(common.getBPPrepaidCustomerNo());

		// select Individual Reports from left panel
		cardMaintenancePage.getIndividualReport();
		// Report Type
		String reportType = "Statement Of Account";
		// Select Report type from drop down and validate report was saved or not
		maintainCustomerPage.selectIndividualReportsForCustomer(reportType);

		// Data for Transaction
		String currentDate = common.getCurrentIFCSDateFromDB(clientName + clientCountry);
		Faker fakerN = new Faker();
		String f_referenceNo = fakerN.number().digits(3);
		String locationNo = common.chooseALocationWithNonFuelProduct("Y");
		String ifcsCurrentDate = common.enterADateValueInStatusBeginDateField("Current", currentDate);

		String cardNumber = common.getNotReplacedCardNumberWithCustomerNumber("100 Normal Service", "0100122002");
		IFCSHomePage.gotoTransactionAndClickManageTransaction();
		/*transactions.validateToPostManualTransactionEntry(ifcsCurrentDate, f_referenceNo, clientCountry, cardNumber, "",
				locationNo, "04", false);*/
		transactions.enterTransactionBatchDetails(false,"160","1",clientName);
		transactions.enterManualTransactionDetails(ifcsCurrentDate,f_referenceNo,cardNumber,"",locationNo,"160","");
		transactions.enterTransactionLineItems("04","160","100","160");
		transactions.validatePostManualTransaction("Validation successful");

		try {
			ifcsCommonPage.updateValuesInPaymentAndUploadToXMLFile(customerPaymentXML,
					"IE_INPUTFILE_FOLDER_CUSTOMERPAYMENT", "BP Australia Pty Ltd", "CustomerPayment_AU_0005.xml");
		} catch (TransformerException e) {
			e.printStackTrace();
		}
		
		// Run Control-M Day End Job - Manually
		
		String dayEndDatePath="";
		// Get Generated report
		 dayEndDatePath=commoninterface.getFolderPathUsingPreviousProcessingDate(clientName, clientCountry,"IFCS_DAYEND_OUTPUTFILE_AU_CUSTOMER");
		String fileNameExpected =  ifcsCommonPage.establishThePuttyConnectionAndValidationDayAndMonthEndReport("incomingFile",bpdayendreportsAU,"PUTTY_HOST", "PUTTY_USERNAME", "PUTTY_PASSWORD",
  				dayEndDatePath,clientCountry,clientName);
		
		// Validate Generated Report
		ifcsCommonPage.validateReportContent(fileNameExpected, "2116482743");
	}

}
