package com.framework.testcases.OLS.CHEV.Customer.ViewOnly;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.CHEV.CHBulkCardOrderPage;
import com.framework.pages.CHEV.CHBulkCardUpdatePage;
import com.framework.pages.CHEV.CHCardListPage;
import com.framework.pages.CHEV.CHHomePage;
import com.framework.pages.OLS.common.LoginPage;

public class ValidateOLSCardsMenu extends BaseTest {
	@Parameters({ "clientCountry", "clientName", "cardNumberStr" })
	@Test(priority = 1)
	public void testCustomerViewOnlyOLSCardsMenu(@Optional("SG") String clientCountry, @Optional("CHV") String clientName,
			@Optional("CHV_PH_CARD_MENU_CREDIT_CARD") String cardNumberStr) {

		test = extent.createTest(clientName+ ":" +clientCountry+"  View Only OLS - Cards Menu", "Chevron Customer Screens View Only");

		// Creating Objects for the Pages
		LoginPage loginPage = new LoginPage(driver, test);
		if (clientCountry.equals("SG")||clientCountry.equals("MY")||clientCountry.equals("HK")) {
			loginPage.Login("CHV_URL", "CHV_Customer_UN_VIEW_ONLY_"+clientCountry, "CHV_Customer_PWD_VIEW_ONLY_"+clientCountry, "CHV");
		} else if (clientCountry.equals("TH")) {
			loginPage.Login("CHV_URL", "CHV_Customer_UN_"+clientCountry, "CHV_Customer_PWD_"+clientCountry, "CHV");
		} else if (clientCountry.equals("PH")) {
			loginPage.Login("CHV_URL", "CHV_Customer_UN_"+clientCountry, "CHV_Customer_PWD_"+clientCountry, "CHV");
		}

		CHHomePage chHomePage = new CHHomePage(driver, test);
		CHCardListPage cardListPage = new CHCardListPage(driver, test);
		// CHViewCardPage chViewCardPage = new CHViewCardPage(driver, test);
		CHBulkCardOrderPage chBulkCardOrderPage = new CHBulkCardOrderPage(driver, test);
		CHBulkCardUpdatePage chBulkCardUpdatePage = new CHBulkCardUpdatePage(driver, test);

		chHomePage.loadFindAndUpdateCardPage();
		cardListPage.verifySearchButton();
		cardListPage.verifyExportButton();
		cardListPage.verifyPageSubTitles();

		// TODO All Fields are disabled in the read only account.

		// String cardNumber = PropUtils.getPropValue(configProp, cardNumberStr);
		//
		// cardListPage.enterCardNumber(cardNumber);
		// cardListPage.clickSearchCard();
		// cardListPage.validateCardNumber(cardNumber);
		// cardListPage.clickFirstCardNumberFromCardsList();
		// cardListPage.verifyContextMenu();
		// cardListPage.pickCardDetailsOption();
		//
		// chViewCardPage.verifySubTitles();
		// chViewCardPage.verifyReadOnlyMode();
		// chViewCardPage.navigateBacktoCardList();

		chHomePage.loadFindAndBulkOrderPage();
		chBulkCardOrderPage.verifyDownloadButton();
		chBulkCardOrderPage.verifyUploadButton();
		chHomePage.loadFindAndBulkUpdatePage();
		chBulkCardUpdatePage.verifyDownloadButton();
		chBulkCardUpdatePage.verifyUploadButton();

		loginPage.Logout();

	}

}
