package com.framework.testcases.AJS.BP;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.framework.basetest.BaseTest;
import com.framework.pages.AJS.ClientConfigPage;
import com.framework.pages.AJS.MaintainCustomerPage;
import com.framework.pages.AJS.common.Common;
import com.framework.pages.AJS.common.IFCSHomePage;
import com.framework.pages.AJS.common.IFCSLoginPage;

public class ValidateAndCreateNewProfilesTestCases extends BaseTest{
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "Regression" ,"BusiessFlow"})
	public void validateToCreateAndDeleteNewCardFeeProfile(@Optional("AU") String clientCountry,
			@Optional("BP") String clientName){
		test = extent.createTest(clientName+ ":" +clientCountry+"  TC0001 - Create a new card fee profile,TC0002- Create a new card fee profile and navigate away,"
				+ "TC0003- Create a new card fee profile and edit the profile,"
				+"TC0004- Validate the old card fee profile,"
				+"TC00020- Delete the  fee profile in Card Fee Profiles", "Validate and Create ,Delete a New Card Fee Profile");
		// creating object for the Pages
		IFCSLoginPage ifcsLoginPage = new IFCSLoginPage(driver, test);
		IFCSHomePage ifcsHomePage = new IFCSHomePage(driver, test);
		ClientConfigPage clientConfigPage = new ClientConfigPage(driver, test);
		ifcsLoginPage.login("IFCS_URL_BP", "IFCS_BP_USERNAME", "IFCS_BP_PASSWORD");
		ifcsLoginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		ifcsHomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);
		//TC0001 - Create a new card fee profile
		String desc=clientConfigPage.createANewCardFeeProfile(clientName,clientCountry,"BP PrePay Cards","280 Card Issue Fee (GST Incl)","210 Card Admin Fee (GST inc)");
		//TC0002- Create a new card fee profile and navigate away 
		clientConfigPage.navigateAwayAndValidateCreatedCardFeeProfiles(desc);
		//TC0004- Validate the old card fee profile
		clientConfigPage.validateOldCardFeeProfiles("BP PrePay Cards",desc);
		//TC0003- Create a new card fee profile and edit the profile
		clientConfigPage.editCardFeeProfilesAndValidate(desc,clientName,clientCountry,"BP Plus cards","random","random");
		//TC00020- Delete the  fee profile in Card Fee Profiles
		String description=clientConfigPage.createANewCardFeeProfile(clientName,clientCountry,"BP PrePay Cards","280 Card Issue Fee (GST Incl)","210 Card Admin Fee (GST inc)");
		clientConfigPage.deleteCardFeeProfile(description);
		ifcsHomePage.exitIFCS();
	}
	
	//customer number and card number staticly given --need changes
	@Parameters({ "clientCountry", "clientName" })
	@Test(groups = { "Regression" })
	public void validateToDeletePrivateFeeProfileInCardMaintenance(@Optional("AU") String clientCountry,
			@Optional("BP") String clientName){
		test = extent.createTest(clientName+ ":" +clientCountry+"  TC00019- Delete the private fee profile in Card Maintenance", "Validate and Delete Private Fee Profile In Card Maintenance");
		// creating object for the Pages
				IFCSLoginPage ifcsLoginPage = new IFCSLoginPage(driver, test);
				IFCSHomePage ifcsHomePage = new IFCSHomePage(driver, test);
				ClientConfigPage clientConfigPage = new ClientConfigPage(driver, test);
				Common common = new Common(driver, test);
				MaintainCustomerPage maintainCustomerPage = new MaintainCustomerPage(driver, test);
		ifcsLoginPage.login("IFCS_URL_BP", "IFCS_BP_USERNAME", "IFCS_BP_PASSWORD");
		ifcsLoginPage.setClientCountryCardTypeDetails(clientName, clientCountry, "");
		ifcsHomePage.gotoAdminMenuAndChooseClient(clientName + "_" + clientCountry);
		clientConfigPage.createANewCardFeeProfile(clientName,clientCountry,"BP PrePay Cards","280 Card Issue Fee (GST Incl)","210 Card Admin Fee (GST inc)");
		clientConfigPage.chooseFeesFromFeeConfig();
		clientConfigPage.verifyFeeConfigProfileFields("Verify");
		clientConfigPage.verifyFeeAgreementFields("Verify",clientName,clientCountry);
		clientConfigPage.verifyFeeConfigProfileFields("create");
		clientConfigPage.verifyFeeAgreementFields("create",clientName,clientCountry);	
		clientConfigPage.verifyFeeValueFields("create");
		common.clickSaveIcon();
		common.checkRecordSaved();

		// Customer set Prepay Customer
		ifcsHomePage.gotoCustomerMenuCustomerDetails();
		String prepaidCustomer = "2616452838";
		maintainCustomerPage.chooseCustomerNoAndSearch(prepaidCustomer);
		//Go to Customer -> Maintain Card Fees -> Add Available Profile and Add Card Fee
		maintainCustomerPage.chooseMaintainCardFeesFromCustomerProfile();
		maintainCustomerPage.createCardFeePrivateProfile();
		String cardNo="70505000000005010";
		maintainCustomerPage.deletePrivateFeeProfileInCardMaintenance(cardNo);
		ifcsHomePage.exitIFCS();
	}
	
	
}
