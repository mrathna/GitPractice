﻿using Common;
using Common.Utility;
using EnCompass.Testing.Source.PageObjects.Controls;
using NFluent;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;

namespace EnCompass.Testing.Source.PageObjects.Organization.Admin.MccGroups
{
	public class MccGroup : EnCompassOrgPageModel
	{		
		public override string RelativeUrl => @"/Admin/MccGroups/mccGroup.aspx";
		public override string PageIdentifierXPath_Override => @"//li[contains(@class, 'breadcrumb-item active')][text() = 'Create Group']";
        
		#region private elements

		private const string _groupName = "//input[contains(@id, 'contents_Name')]";
		private const string _groupDesc = "//input[contains(@id, 'contents_Description')]";
		private const string _mccCodesCheckbox = "//input[contains(@id, 'SearchOnCodes')]";
		private const string _mccCodesCheckboxLabel = "//label[contains(@for, 'SearchOnCodes')]";
		private const string _mccSearchButton = "//input[contains(@id, 'btnSearch')]";
        private const string _mccCodesXPath = @"//textarea[contains(@id, 'contents_Mccs')]";
        private const string _saveBtn = "//input[contains(@id, 'btnSave')]";

		private IWebDriver _driver;
		private GridControl _MccgsGrid;

        #endregion


        #region public properties/methods

        public IWebElement _mccCodes
        {
            get
            {
                bool found = Driver.TryWaitForElementToBeVisible(By.XPath(_mccCodesXPath), out IWebElement element);
                Settings.EnCompassExtentTest.Info("_mccCodes element exist is" + found);
                Check.That(found).IsTrue();
                return element;
            }
        }

        public string GroupName
		{
			get
			{
                Driver.TryWaitForElementToBeVisible(By.XPath(_groupName), out IWebElement element);
				return element.GetAttribute("value");
			}
			set
			{
				Driver.TryWaitForElementToBeVisible(By.XPath(_groupName), out IWebElement element);
				element.SendKeys(value);
				Settings.EnCompassExtentTest.Info("Entered GroupName =" + value + " while creating company MCCGs");				
			}
		}

		public string GroupDescription
		{
			get
			{
				return _driver.WaitForVisible(By.XPath(_groupDesc)).GetAttribute("value");
			}
			set
			{
				IWebElement element = _driver.WaitForVisible(By.XPath(_groupDesc));
				element.SendKeys(value);
				Settings.EnCompassExtentTest.Info("Entered GroupDescription =" + value + " while creating company MCCGs");
			}
		}

		public bool ShowCodes
		{
			set
			{
				IWebElement _CodesCheckBox = Driver.WaitFor(By.XPath(_mccCodesCheckbox));
				IWebElement _CodesCheckBoxLabel = Driver.WaitFor(By.XPath(_mccCodesCheckboxLabel));
				_CodesCheckBox.SetCheckboxStateWithLabel(_CodesCheckBoxLabel, value);
			}
		}

		public void SearchMCC()
		{
			IWebElement _searchMCCBtn = Driver.WaitFor(By.XPath(_mccSearchButton));
			_searchMCCBtn.Click();
			Settings.EnCompassExtentTest.Info("Clicked on Search MCC button");
		}

		public GridControl MccgsGrid
		{
			get
			{
				var grid = _MccgsGrid ?? (_MccgsGrid = new GridControl("dgResults", Driver));
				grid.WaitForGrid();
				return grid;
			}
		}

		public void SaveMCCG()
		{
            Driver.TryWaitForElementToBeVisible(By.XPath(_saveBtn), out IWebElement element);
            element.JSClickWithFocus(Driver);
			Settings.EnCompassExtentTest.Info("Clicked on Save button on Create MCCG page");
			this.AttachOnDemandScreenShot();
		}

		public string MCCCodes
		{
			get{ return _mccCodes.Text; }
			set { _mccCodes.SendKeys(value); Settings.EnCompassExtentTest.Info($"Set MCC Value to {value}"); }
		}
        #endregion

        public  MccGroup(GlobalSettings Settings) : base(Settings)
		{ 
		  _driver = Settings.EnCompassWebDriver; 
        }
	}
}
