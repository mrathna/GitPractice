package com.framework.main;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.ss.usermodel.Cell;
import org.testng.TestNG;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.testng.collections.Lists;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.framework.util.Constants;
import com.framework.util.ExcelUtils;
import com.framework.util.PropUtils;

public class InitExecution {
	public static String fileName;
	public static String sheetName;
	public static String environment;
	public static String browser;
	public static String country;
	public static String node;
	public static String parallel_Mode;
	public static String parallel_At;
	public static String thread_Count;
	public static File configFile = PropUtils.getPropFile(Constants.CONFIG_DIR, Constants.CONFIG_FILE_NAME);
	public static Properties configProp = PropUtils.getProps(configFile);
	List<String> envArgs = new ArrayList<String>();
	List<String> nodeArgs = new ArrayList<String>();
	List<String> parallelArgs = new ArrayList<String>();
	List<String> browserArgs = new ArrayList<String>();
	
	String brwValue;

	// @Test(priority=1)
	public void readSuite() {
		
		HSSFSheet sheet = ExcelUtils.readExcel(
				Constants.USER_DIR + Constants.FILE_SEPARATOR + PropUtils.getPropValue(configProp, "SuiteName") + ".xls", "Master_Suite");// BusinessFlow_Suite

		for (int row = 1; row <= sheet.getLastRowNum(); row++) {
			HSSFCell cellVal = sheet.getRow(row).getCell(3);

			String runStatus = "";
			try {
				runStatus = cellVal.getStringCellValue();
				if (cellVal.getStringCellValue().equalsIgnoreCase("Yes")) {
					String envVal = sheet.getRow(row).getCell(0).getStringCellValue();
					 brwValue = sheet.getRow(row).getCell(1).getStringCellValue();
					String nodeURL = sheet.getRow(row).getCell(2).getStringCellValue();
				//	String Parallel = sheet.getRow(1).getCell(3).getStringCellValue();  parallel  execution at  master suite level
					String Parallel = sheet.getRow(row).getCell(4).getStringCellValue();//  parallel  execution at  suite level
					envArgs.add(envVal);
					nodeArgs.add(nodeURL);
					parallelArgs.add(Parallel);
					browserArgs.add(brwValue);
					
				}
			} catch (NullPointerException e) {
				break;

			}
		}

		for (int i = 0; i <= envArgs.size() - 1; i++) {
			System.out.println(envArgs.get(i));
			System.out.println(nodeArgs.get(i));
			System.out.println(parallelArgs.get(0));
			System.out.println(browserArgs.get(0));
		}
	}

	@Test
	public void executeSuite() {
		readSuite();
		String browserNames[]=brwValue.split(";");
		// get env from excel
		for (int i = 0; i <= envArgs.size() - 1; i++) {
			
			for (int brwIndex = 0; brwIndex <= browserNames.length - 1; brwIndex++) {
			
			
			
			// System.out.println(environment1.get(i)); argv[0].split(";")
			String[] arg = envArgs.get(i).split(";");// envronment details
			//String[] para = parallelArgs.get(0).split(";");// parallel  execution at master suite level
			String[] para = parallelArgs.get(i).split(";");// parallel  execution at  suite level
			// env print
			System.out.println(arg[0]);
			System.out.println(arg[1]);
			System.out.println(arg[2]);
			System.out.println(nodeArgs.get(i));
			// parallel print
			System.out.println(para[0]);
			System.out.println(para[1]);
			System.out.println(para[2]);
			// }

			// env
			fileName = arg[0];
			sheetName = arg[1];
			environment = arg[2];
			//browser = arg[3];========================================================
			browser = browserNames[brwIndex];
			node = nodeArgs.get(i);
			parallel_Mode = para[0];
			parallel_At = para[1];
			thread_Count = para[2];
			

			// ==========================

			// ====================

			System.out.println(" ******************************** " + sheetName + " Execution started"
					+ " ********************************");
			Map<String, Integer> colIndex = new HashMap<String, Integer>();
			Set<String> className = new HashSet<String>();

			HSSFSheet sheet = ExcelUtils.readExcel(Constants.USER_DIR + Constants.FILE_SEPARATOR + fileName + ".xls",
					sheetName);
			HSSFCell value = null;
			ArrayList<String> headerList = ExcelUtils.readHeaderInList(sheet, 0);
			for (int j = 0; j < headerList.size(); j++) {
				if (headerList.get(j).equalsIgnoreCase("Execution")) {

					colIndex.put(headerList.get(j), j);
				} else if (headerList.get(j).equalsIgnoreCase("Country")) {
					colIndex.put(headerList.get(j), j);
				} else if (headerList.get(j).equalsIgnoreCase("Class Name")) {
					colIndex.put(headerList.get(j), j);
				} else if (headerList.get(j).equalsIgnoreCase("Method Name")) {
					colIndex.put(headerList.get(j), j);
				}
			}
			int row;
			for (row = 1; row <= sheet.getLastRowNum(); row++) {
				value = sheet.getRow(row).getCell(colIndex.get("execution"));

				String value1 = "";
				try {
					value1 = value.getStringCellValue();
					if (value.getStringCellValue().equalsIgnoreCase("Yes")) {
						String valueee = sheet.getRow(row).getCell(colIndex.get("class name")).getStringCellValue();

						className.add(valueee);
					}
				} catch (NullPointerException e) {
					break;

				}
			}

			if (!sheetName.toLowerCase().contains("card") && !sheetName.toLowerCase().contains("payments")
					&& !sheetName.toLowerCase().contains("location") && !sheetName.toLowerCase().contains("merchant")
					&& !sheetName.toLowerCase().contains("fullsuite"))

			{
				try {

					DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
					DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
					Document doc = docBuilder.newDocument();

					// suit
					// nodee=======================================================================================
					Element rootElement = doc.createElement("suite");
					doc.appendChild(rootElement);

					rootElement.setAttribute("name",
							sheetName.split("_")[0] + "_" + sheetName.split("_")[1] + "_" + fileName.split("_")[0]);

					if (parallel_Mode.equalsIgnoreCase("yes")) {
						rootElement.setAttribute("parallel", parallel_At);
						rootElement.setAttribute("thread-count", thread_Count);
						rootElement.setAttribute("verbose", "10");
					}

					Element parameterele = doc.createElement("parameter");
					parameterele.setAttribute("name", "clientCountry");
					System.out.println("Client ::" + sheetName.split("_")[0]);
					System.out.println("Client Country::" + sheetName.split("_")[1]);
					System.out.println("Group Name::" + fileName.split("_")[0]);

					if (sheetName.split("_")[1].equals("ZEnergy")) {
						parameterele.setAttribute("value", "Z Energy");
						rootElement.appendChild(parameterele);
					}

					else {
						parameterele.setAttribute("value", sheetName.split("_")[1]);
						rootElement.appendChild(parameterele);
					}

					Element parameterele1 = doc.createElement("parameter");
					parameterele1.setAttribute("name", "clientName");
					parameterele1.setAttribute("value", sheetName.split("_")[0]);
					rootElement.appendChild(parameterele1);
					Element parameterele3 = doc.createElement("parameter");
					parameterele3.setAttribute("name", "cardCount");
					parameterele3.setAttribute("value", "1");
					rootElement.appendChild(parameterele3);

					// add group
					// info=======================================================================================
					System.out.print(sheetName.split("_")[1]);
					if (sheetName.split("_")[0].contains("EMAP")) {
						Element groupsele = doc.createElement("groups");
						Element run = doc.createElement("run");
						Element include = doc.createElement("include");
						include.setAttribute("name", fileName.split("_")[0]);

						rootElement.appendChild(groupsele);
						groupsele.appendChild(run);
						run.appendChild(include);
					}

					System.out.print(sheetName.split("_")[1]);
					if (sheetName.split("_")[0].contains("WFE")) {
						Element groupsele = doc.createElement("groups");
						Element run = doc.createElement("run");
						Element include = doc.createElement("include");
						include.setAttribute("name", fileName.split("_")[0]);
						//include.setAttribute("name", "rr");
						rootElement.appendChild(groupsele);
						groupsele.appendChild(run);
						run.appendChild(include);
					}
					if (sheetName.split("_")[0].equals("SHELL")) {
						Element parameterele2 = doc.createElement("parameter");
						parameterele2.setAttribute("name", "cardType");
						parameterele2.setAttribute("value", sheetName.split("_")[2]);
						rootElement.appendChild(parameterele2);

					}

					// Logic to add tests and calsses inside
					// tests=======================================================================================

					int classIndex = 0;
					for (String s : className) {
						classIndex++;
						System.out.print(s);
						System.out.print(className.size());

						// class
						Element classname = doc.createElement("class");
						classname.setAttribute("name", String.valueOf(s));

						try {
                            // create test node
							Element testele = doc.createElement("test");
							rootElement.appendChild(testele);
							// test name
							testele.setAttribute("name",
							sheetName.split("_")[0] + "_" + fileName.split("_")[0] + classIndex);
							Element classesele = doc.createElement("classes");
							
							// Add parallel attribute to test node---------------------------------------
						//	testele.setAttribute("parallel", "methods");
						//	testele.setAttribute("thread-count","2");
							
							testele.appendChild(classesele);
							classesele.appendChild(classname);
							
							Element methods = doc.createElement("methods");
							for (row = 1; row <= sheet.getLastRowNum(); row++) {

								value = sheet.getRow(row).getCell(colIndex.get("class name"));
								String value1 = null;
								try {
									value1 = sheet.getRow(row).getCell(colIndex.get("execution")).getStringCellValue();
									if (value.getStringCellValue().equalsIgnoreCase(s) && value1.equalsIgnoreCase("Yes")) {
										String methodValue = sheet.getRow(row).getCell(colIndex.get("method name"))
												.getStringCellValue();
										Element method = doc.createElement("include");
										method.setAttribute("name", String.valueOf(methodValue));
										classesele.appendChild(classname);
										classname.appendChild(methods);
										methods.appendChild(method);
									}
								} catch (NullPointerException e) {
									break;
								}
							}
							

						} catch (NullPointerException e) {
							break;
						}

					}

					DOMSource source = new DOMSource(doc);

					StreamResult result1 = new StreamResult(new File("ExecutionSuite.xml"));

					TransformerFactory transformerFactory = TransformerFactory.newInstance();
					Transformer transformer = transformerFactory.newTransformer();

					transformer.setOutputProperty(OutputKeys.INDENT, "yes");
					transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "4");
					transformer.transform(source, result1);
					TestNG testng = new TestNG();
					List<String> suites = Lists.newArrayList();
					suites.add("ExecutionSuite.xml");// path to xml..
					System.out.println(" ******************************** Suite File created from " + sheetName
							+ " sheet ********************************");

					testng.setTestSuites(suites);
					Thread.sleep(5000);
					testng.run();
					System.out.println(
							" ******************************** Execution Completed ********************************");

				}

				catch (Exception ex) {
					ex.printStackTrace();
				}
			} else {
				// Read Component Execution Sheet
				readComponentSheet(sheet, row, colIndex);
			}
			
			
			}// end of browser list for loop
			
		}// end of args for loop
		
	}

	public static void readComponentSheet(HSSFSheet sheet, int row, Map<String, Integer> colIndex) {
		try {

			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			Document doc = docBuilder.newDocument();
			Element rootElement = doc.createElement("suite");
			doc.appendChild(rootElement);
			rootElement.setAttribute("name",
					sheetName.split("_")[0] + "_" + sheetName.split("_")[1] + "_" + fileName.split("_")[0]);
			Element groupsele = doc.createElement("groups");
			Element run = doc.createElement("run");
			Element include = doc.createElement("include");
			rootElement.appendChild(groupsele);
			groupsele.appendChild(run);
			run.appendChild(include);
			include.setAttribute("name", fileName.split("_")[0]);
			String value1 = null;
			for (row = 1; row <= sheet.getLastRowNum(); row++) {
				value1 = sheet.getRow(row).getCell(colIndex.get("execution")).getStringCellValue();
				if (value1.equalsIgnoreCase("Yes")) {
					Element testele = doc.createElement("test");
					rootElement.appendChild(testele);

					Element classesele = doc.createElement("classes");

					testele.appendChild(classesele);

					testele.setAttribute("name", sheetName.split("_")[0] + "_" + fileName.split("_")[0] + "_" + row);
					Element parameterele = doc.createElement("parameter");
					parameterele.setAttribute("name", "clientCountry");
					parameterele.setAttribute("value",
							sheet.getRow(row).getCell(colIndex.get("country")).getStringCellValue());
					testele.appendChild(parameterele);
					Element parameterele1 = doc.createElement("parameter");
					parameterele1.setAttribute("name", "clientName");
					parameterele1.setAttribute("value",
							sheet.getRow(row).getCell(colIndex.get("client")).getStringCellValue());
					testele.appendChild(parameterele1);

					if (sheetName.toLowerCase().contains("creation")) {
						Element parameterele3 = doc.createElement("parameter");
						parameterele3.setAttribute("name", "customerNo");
						parameterele3.setAttribute("value",
								sheet.getRow(row).getCell(colIndex.get("customer no")).getStringCellValue());
						testele.appendChild(parameterele3);
						Element parameterele4 = doc.createElement("parameter");
						parameterele4.setAttribute("name", "carProduct");
						Cell cardProd = sheet.getRow(row).getCell(colIndex.get("card product"));
						if (cardProd == null || cardProd.getCellType() == Cell.CELL_TYPE_BLANK) {
							parameterele4.setAttribute("value", "");
						} else {
							parameterele4.setAttribute("value",
									sheet.getRow(row).getCell(colIndex.get("card product")).getStringCellValue());
						}
						testele.appendChild(parameterele4);
						Element parameterele2 = doc.createElement("parameter");
						parameterele2.setAttribute("name", "cardType");
						Cell cardType = sheet.getRow(row).getCell(colIndex.get("card product"));
						if (cardType == null || cardType.getCellType() == Cell.CELL_TYPE_BLANK) {
							parameterele2.setAttribute("value", "");
						} else {
							parameterele2.setAttribute("value",
									sheet.getRow(row).getCell(colIndex.get("card type")).getStringCellValue());
						}
						testele.appendChild(parameterele2);
					} else if (sheetName.toLowerCase().contains("status_change")) {
						Element parameterele4 = doc.createElement("parameter");
						parameterele4.setAttribute("name", "cardNo");
						String card = sheet.getRow(row).getCell(colIndex.get("card no")).getStringCellValue();
						parameterele4.setAttribute("value", card);
						testele.appendChild(parameterele4);
						Element parameterele2 = doc.createElement("parameter");
						parameterele2.setAttribute("name", "fromStatus");
						parameterele2.setAttribute("value",
								sheet.getRow(row).getCell(colIndex.get("from status")).getStringCellValue());
						testele.appendChild(parameterele2);
						Element parameterele5 = doc.createElement("parameter");
						parameterele5.setAttribute("name", "toStatus");
						parameterele5.setAttribute("value",
								sheet.getRow(row).getCell(colIndex.get("to status")).getStringCellValue());
						testele.appendChild(parameterele5);
						Element parameterele6 = doc.createElement("parameter");
						parameterele6.setAttribute("name", "replaceCard");
						parameterele6.setAttribute("value",
								sheet.getRow(row).getCell(colIndex.get("replace card")).getStringCellValue());
						testele.appendChild(parameterele6);
					} else if (sheetName.toLowerCase().contains("update_card")) {
						Element parameterele4 = doc.createElement("parameter");
						parameterele4.setAttribute("name", "cardNo");
						parameterele4.setAttribute("value",
								sheet.getRow(row).getCell(colIndex.get("card no")).getStringCellValue());
						testele.appendChild(parameterele4);
						Element parameterele2 = doc.createElement("parameter");
						parameterele2.setAttribute("name", "fieldName");
						parameterele2.setAttribute("value",
								sheet.getRow(row).getCell(colIndex.get("field name")).getStringCellValue());
						testele.appendChild(parameterele2);
						Element parameterele5 = doc.createElement("parameter");
						parameterele5.setAttribute("name", "value");
						parameterele5.setAttribute("value",
								sheet.getRow(row).getCell(colIndex.get("value")).getStringCellValue());
						testele.appendChild(parameterele5);
						Element parameterele6 = doc.createElement("parameter");
						parameterele6.setAttribute("name", "replaceCard");
						parameterele6.setAttribute("value",
								sheet.getRow(row).getCell(colIndex.get("replace card")).getStringCellValue());
						testele.appendChild(parameterele6);
					} else if (sheetName.toLowerCase().contains("transfer")) {
						Element parameterele4 = doc.createElement("parameter");
						parameterele4.setAttribute("name", "cardNo");
						parameterele4.setAttribute("value",
								sheet.getRow(row).getCell(colIndex.get("card no")).getStringCellValue());
						testele.appendChild(parameterele4);
						Element parameterele2 = doc.createElement("parameter");
						parameterele2.setAttribute("name", "fromCustomer");
						parameterele2.setAttribute("value",
								sheet.getRow(row).getCell(colIndex.get("from customer")).getStringCellValue());
						testele.appendChild(parameterele2);
						Element parameterele5 = doc.createElement("parameter");
						parameterele5.setAttribute("name", "toCustomer");
						parameterele5.setAttribute("value",
								sheet.getRow(row).getCell(colIndex.get("to customer")).getStringCellValue());
						testele.appendChild(parameterele5);
					} else if (sheetName.toLowerCase().contains("SHELL")
							&& sheetName.toLowerCase().contains("fullsuite")) {
						Element parameterele2 = doc.createElement("parameter");
						parameterele2.setAttribute("name", "cardType");
						parameterele2.setAttribute("value",
								sheet.getRow(row).getCell(colIndex.get("card type")).getStringCellValue());
						testele.appendChild(parameterele2);
					}

					Element classname = doc.createElement("class");
					classname.setAttribute("name",
							sheet.getRow(row).getCell(colIndex.get("class name")).getStringCellValue());

					Element methods = doc.createElement("methods");
					Element method = doc.createElement("include");
					method.setAttribute("name",
							sheet.getRow(row).getCell(colIndex.get("method name")).getStringCellValue());
					classesele.appendChild(classname);
					classname.appendChild(methods);
					methods.appendChild(method);

				}
			}

			DOMSource source = new DOMSource(doc);

			StreamResult result1 = new StreamResult(new File("ExecutionSuite.xml"));

			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer = transformerFactory.newTransformer();

			transformer.setOutputProperty(OutputKeys.INDENT, "yes");
			transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "4");
			transformer.transform(source, result1);
			TestNG testng = new TestNG();
			List<String> suites = Lists.newArrayList();
			suites.add("ExecutionSuite.xml");// path to xml..
			System.out.println(" ******************************** Suite File created from " + sheetName
					+ " sheet ********************************");
			testng.setTestSuites(suites);
			Thread.sleep(5000);
			testng.run();
			System.out
					.println(" ******************************** Execution Completed ********************************");

		}

		catch (Exception ex) {
			ex.printStackTrace();
		}

	}
}
